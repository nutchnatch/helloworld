/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { DateParserFormaterServices } from './date-parser-formater.service';

describe('Service: DateParserFormater.services', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DateParserFormaterServices]
    });
  });

  it('should ...', inject([DateParserFormaterServices], (service: DateParserFormaterServices) => {
    expect(service).toBeTruthy();
  }));
});
