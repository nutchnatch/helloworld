import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { Injectable } from '@angular/core';

@Injectable()
export class DateParserFormaterServices {

  constructor() { }

  ngbDatepickerUTC(date: NgbDateStruct): string {
    return date ? new Date(Date.UTC(date.year, date.month - 1, date.day)).toISOString() : null;
  }

  ngbDatepickerUTCDate(date: NgbDateStruct): string {
    // TODO: change hours 10
    const newData = new Date(date.year, date.month - 1, date.day, 10).toISOString().split('T')[0];
    return date ? newData : null;
  }
}
