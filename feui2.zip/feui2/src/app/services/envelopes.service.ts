import { remove } from 'lodash';
import { QueryParams } from 'app/models/paged';
import { Envelope } from './../models/envelope';

import { RestResponse } from './../models/rest-response';
import { Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { LoggerService } from './logger/logger.service';
import { HttpClientService } from './http-client.service';
import { BaseService } from './base.service';
import { Injectable } from '@angular/core';
import { EnvelopeCreationResult } from 'app/models/envelope-creation-result';


@Injectable()
export class EnvelopesService extends BaseService<Envelope> {

  constructor(
    http: HttpClientService,
    logger: LoggerService
  ) {
    super(http, logger);
  }

  /**
   * Performs A 'Search Envelopes'
   *
   * @param {QueryParams} params
   * @returns {Observable<RestResponse<Envelope>>}
   * @memberof EnvelopesService
   */
  getEnvelopes(params: QueryParams): Observable<RestResponse<Envelope>> {
    this.logger.debug('EnvelopesService', 'getEnvelopes() called');

    // const queryParams: URLSearchParams = new URLSearchParams();
    // Object.assign(queryParams, params);
    return this.http.get(this.baseUrl + '/envelopes', { search: params })
      .map((resp: Response) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));
  }

 /**
  * Performs a get Envelope by is ID
  *
  * @param {string} id
  * @param {string} [scope]
  * @returns {Observable<RestResponse<Envelope>>}
  * @memberof EnvelopesService
  */
  getEnvelopeById(id: string, scope?: string): Observable<RestResponse<Envelope>> {
    this.logger.debug('EnvelopesService', 'getEnvelopeById called');
    let queryParams = {};
    if (scope) {
      queryParams = Object.assign({}, { scope : scope });
    }

    return this.http.get(this.baseUrl + '/envelopes/' + id , { search: queryParams })
      .map((resp: Response) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));
  }

    /**
   * Put Envelope
   *
   * @param id
   * @param body
   * @memberOf EnvelopeService
   */
  putEnvelopesById(id: string, body: Envelope): Observable<RestResponse<EnvelopeCreationResult>> {
    this.logger.debug('EnvelopeService', 'putEnvelopesById() called', { id: id, body: body } );
    return this.http.put(this.baseUrl + '/envelopes/' + id, body)
      .map((resp: Response) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));

  }

  /**
   * Post Envelope
   * @param formData
   * @memberOf EnvelopeService
   */
  postEnvelopes(formData: FormData): Observable<RestResponse<EnvelopeCreationResult>> {
    this.logger.debug('EnvelopesService', 'postEnvelopes called with this data: ', formData);

    let headers: Headers;
    headers =  this.http.addDefaultHeaders();
    // headers.set('Content-Type', 'multipart/form-data; boundary=');
    headers.delete('Content-Type');
    headers.delete('X-Requested-With');

    // headers.append('Accept', 'application/json');
    return this.http.post(this.baseUrl + '/envelopes' , formData , { headers: headers })
      .map((resp: Response) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));
  }

  /**
   * Post Envelope
   * @param formData
   * @memberOf EnvelopeService
   */
  postEnvelopesDocuments(id: string, formData: FormData): Observable<RestResponse<EnvelopeCreationResult>> {
    this.logger.debug('EnvelopesService', 'postEnvelopes called with this data: ', formData);

    let headers: Headers;
    headers =  this.http.addDefaultHeaders();
    // headers.set('Content-Type', 'multipart/form-data; boundary=');
    headers.delete('Content-Type');
    headers.delete('X-Requested-With');

    // headers.append('Accept', 'application/json');
    return this.http.post(this.baseUrl + '/envelopes/' + id + '/documents' , formData , { headers: headers })
      .map((resp: Response) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));
  }

}
