import { Info } from './../models/info';

import { RestResponse } from './../models/rest-response';
import { Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { LoggerService } from './logger/logger.service';
import { HttpClientService } from './http-client.service';
import { BaseService } from './base.service';
import { Injectable } from '@angular/core';


@Injectable()
export class InfoService extends BaseService<Info> {

  constructor(
    http: HttpClientService,
    logger: LoggerService
  ) {
    super(http, logger);
    this.baseUrl = '/sugar-frontend-webapp/application';
  }

  /**
   *
   * @returns {Observable<RestResponse<Document>>}
   *
   * @memberOf DocumentService
   */
  getInfoVersion(): Observable<String> {
    this.logger.debug('InfoService', 'getInfoVersion() called');

    // const queryParams: URLSearchParams = new URLSearchParams();
    // Object.assign(queryParams, params);
    // console.log(queryParams.toString())

    return this.http.get(this.baseUrl + '/info')
      .map((resp: Response) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));
  }

  // postInfo(formData: any): Observable<RestResponse<EnvelopeCreationResult>> {
  //   this.logger.debug('InfoService', 'postInfo called with this data: ', formData.getAll('filesList'));

  //   let headers: Headers;
  //   headers =  this.http.addDefaultHeaders();
  //   headers.set('Content-Type', 'multipart/form-data');
  //   // headers.append('Accept', 'application/json');
  //   // TODO: CHANGE END POINT NAME
  //   return this.http.post(this.baseUrl + '/envelopes' ,  formData , { headers: headers })
  //     .map((resp: Response) => this.handleResponse(resp, false))
  //     .catch(error => this.handleError(error));
  // }

}
