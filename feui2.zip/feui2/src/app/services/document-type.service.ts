import { RestResponse } from './../models/rest-response';
import { Observable } from 'rxjs/Observable';
import { LoggerService } from './logger/logger.service';
import { HttpClientService } from './http-client.service';
import { DocumentTypes } from 'app/models/document-types';
import { Injectable } from '@angular/core';
import { BaseService } from 'app/services/base.service';

@Injectable()
export class DocumentTypeService extends BaseService<DocumentType> {

  constructor(
    http: HttpClientService,
    logger: LoggerService
  ) {
    super(http, logger);
  }
  /**
   * Get Document Type List
   *
   * @returns {Observable<RestResponse<DocumentType>>}
   * @memberof DocumentTypeService
   */
  getDocumentsTypes(): Observable<RestResponse<DocumentType>> {
    this.logger.debug('DocumentTypeService', 'getDocumentsTypes() called');
    return this.http.get(this.baseUrl + '/document-types')
      .map((resp: any ) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));
  }
}
