import { QueryParams } from 'app/models/paged';
import { Document } from 'app/models/document';
import { RestResponse } from 'app/models/rest-response';
import { Paging } from 'app/models/paging';
import { PagedQuery } from 'app/models/paged';
import { Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { LoggerService } from './logger/logger.service';
import { HttpClientService } from './http-client.service';
import { BaseService } from './base.service';
import { Injectable } from '@angular/core';
import { DocumentCreationResult } from 'app/models/document-creation-result';


@Injectable()
export class DocumentService extends BaseService<Document> {

  constructor(
    http: HttpClientService,
    logger: LoggerService
  ) {
    super(http, logger);
  }

  /**
   *
   * @returns {Observable<RestResponse<Document>>}
   *
   * @memberOf DocumentService
   */
  getDocuments(params: QueryParams): Observable<RestResponse<Document>> {
    this.logger.debug('DocumentService', 'getDocuments() called');

    // const queryParams: URLSearchParams = new URLSearchParams();
    // Object.assign(queryParams, params);
    // console.log(queryParams.toString())

    return this.http.get(this.baseUrl + '/documents', { search: params })
      .map((resp: Response) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));
  }

  /**
   *
   * @param id
   * @returns {Observable<RestResponse<Document>>}
   * @memberOf DocumentService
   */
  getDocumentsById(id: string): Observable<RestResponse<Document>> {
    this.logger.debug('DocumentService', 'getDocumentsById() called', id);
    return this.http.get(this.baseUrl + '/documents/' + id)
      .map((resp: Response) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));

  }
  /**
   *
   * @param id
   * @param body
   * @memberOf DocumentService
   */
  putDocumentsById(id: string, body: Document): Observable<RestResponse<DocumentCreationResult>> {
    this.logger.debug('DocumentService', 'putDocumentsById() called', { id: id, body: body } );
    return this.http.put(this.baseUrl + '/documents/' + id, body)
      .map((resp: Response) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));

  }
}
