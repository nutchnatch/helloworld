import { DocumentAttachedToFoldersResult } from './../models/document-attached-to-folder-result';
import { RestResponse } from './../models/rest-response';
import { Observable } from 'rxjs/Observable';
import { QueryParams } from './../models/paged';
import { Response } from '@angular/http';

import { LoggerService } from './logger/logger.service';
import { HttpClientService } from './http-client.service';
import { BaseService } from './base.service';
import { Injectable } from '@angular/core';
import { Folder } from 'app/models/folder';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/switchMap';
import { FolderCreationResult } from 'app/models/folder-creation-result';

@Injectable()
export class FolderService extends BaseService<Folder> {

  constructor(
    http: HttpClientService,
    logger: LoggerService
  ) {
    super(http, logger);
  }

  /**
   * Performs A 'Live Search Folder'
   *
   * @param {Observable<any>} terms
   * @returns {Observable<RestResponse<Folder>>}
   * @memberof FolderService
   */
  getFolderLive(terms: Observable<any>) {
    this.logger.debug('FolderService', 'getFolderLive() called');
    return terms.debounceTime(400)
      .distinctUntilChanged()
      .switchMap(term => this.getFolder(term));
  }

  /**
  * Performs A 'Search Folder'
  *
  * @param {QueryParams} params
  * @returns {Observable<RestResponse<Folder>>}
  * @memberof FolderService
  */
  getFolder(params: QueryParams): Observable<RestResponse<Folder>> {
    this.logger.debug('FolderService', 'getFolder() called');

    // const queryParams: URLSearchParams = new URLSearchParams();
    // Object.assign(queryParams, params);
    return this.http.get(this.baseUrl + '/folders', { search: params })
      .map((resp: Response) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));
  }

  /**
   * Performs a get Folder by is ID
   *
   * @param {string} id
   * @param {string} [scope]
   * @returns {Observable<RestResponse<Folder>>}
   * @memberof FolderService
   */
  getFolderById(id: string, scope?: string): Observable<RestResponse<Folder>> {
    this.logger.debug('FolderService', 'getFolderById called');
    let queryParams = {};
    if (scope) {
      queryParams = Object.assign({}, { scope: scope });
    }

    return this.http.get(this.baseUrl + '/folders/' + id, { search: queryParams })
      .map((resp: Response) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));
  }

  /**
  * Post Folder
  *
  * @param {Folder} body
  * @memberOf FolderService
  */
  postFolders(body: Folder): Observable<RestResponse<FolderCreationResult>> {
    this.logger.debug('FolderService', 'postFolders() called', { body: body });
    return this.http.post(this.baseUrl + '/folders', body)
      .map((resp: Response) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));
  }

  /**
   * Post Folder With Document
   *
   * @param {string} id
   * @param {Array<string>} docId
   * @memberOf FolderService
   */
  postFoldersDocument(id: string, docId: Array<string>): Observable<RestResponse<FolderCreationResult>> {
    this.logger.debug('FolderService', 'putFoldersById() called', { id: id, documentIds: docId });
    return this.http.post(this.baseUrl + '/folders/' + id + '/documents', docId)
      .map((resp: Response) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));
  }

  /**
  * Put Folder
  *
  * @param id
  * @param body
  * @memberOf FolderService
  */
  putFoldersById(id: string, body: Folder): Observable<RestResponse<FolderCreationResult>> {
    this.logger.debug('FolderService', 'putFoldersById() called', { id: id, body: body });
    return this.http.put(this.baseUrl + '/folders/' + id, body)
      .map((resp: Response) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));

  }

  /**
    * Delete Folder
    *
    * @param id
    * @param body
    * @memberOf FolderService
    */
  deleteFoldersDocument(id: string, docId: Array<string>): Observable<RestResponse<DocumentAttachedToFoldersResult>> {
    this.logger.debug('FolderService', 'deleteFoldersDocument() called', { id: id, documentIds: docId });
    return this.http.delete(this.baseUrl + '/folders/' + id + '/documents', { body: docId })
      .map((resp: Response) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));
  }



}
