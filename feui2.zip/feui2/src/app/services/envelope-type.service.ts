import { RestResponse } from './../models/rest-response';
import { Observable } from 'rxjs/Observable';
import { LoggerService } from './logger/logger.service';
import { HttpClientService } from './http-client.service';
import { EnvelopeTypes } from 'app/models/envelope-types';
import { Injectable } from '@angular/core';
import { BaseService } from 'app/services/base.service';

@Injectable()
export class EnvelopeTypeService extends BaseService<EnvelopeTypes> {

  constructor(
    http: HttpClientService,
    logger: LoggerService
  ) {
    super(http, logger);
  }
  /**
   * Get Document Type List
   *
   * @returns {Observable<RestResponse<EnvelopeTypes>>}
   * @memberof DocumentTypeService
   */
  getEnvelopeTypes(): Observable<RestResponse<EnvelopeTypes>> {
    this.logger.debug('EnvelopeTypeService', 'getEnvelopeTypes() called');
    return this.http.get(this.baseUrl + '/envelope-types')
      .map((resp: any ) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));
  }

  /**
   * Get Document Type List
   *
   * @returns {Observable<RestResponse<EnvelopeTypes>>}
   * @memberof DocumentTypeService
   */
  getEnvelopeTypesById(id: string, version: number): Observable<RestResponse<EnvelopeTypes>> {
    this.logger.debug('EnvelopeTypeService', 'getEnvelopeTypesById() called');

    return this.http.get(this.baseUrl + '/envelope-types/' + id + '/' + version)
      .map((resp: any ) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));
  }
}
