import { Observable } from 'rxjs/Observable';
import { LoggerService } from './logger/logger.service';
import { HttpClientService } from './http-client.service';
import { Injectable } from '@angular/core';
import { Response, Headers } from '@angular/http';

import { RestResponse } from './../models/rest-response';
import { Error } from './../models/error';

@Injectable()
export class BaseService<T> {

  baseUrl = '/sugar-frontend-webapp/v1';  // URL to web user api
  headers: Headers;

  constructor(
    protected http: HttpClientService,
    protected logger: LoggerService) { }

  public getHeaders(): Headers {
    this.headers = this.http.addDefaultHeaders();
    return this.headers;
  }
  /**
   * Handle the server call's
   *
   * @private
   * @param {Response} resp
   * @returns {*}
   *
   * @memberOf BaseService
   */
  protected handleResponse(resp: Response, mandatoryContent?: boolean): RestResponse<T> {

    if (resp.status === 404 || resp.status === 401 || resp.status === 403) {
      throw Observable.throw(resp);
    }

    const restResp: RestResponse<T> = resp.json();
    if (restResp.error) {
      throw Observable.throw(resp);
    }

    // test content is not empty only if the mandatoryContent variable is set
    /*
    if (mandatoryContent === true) {
      if (restResp.result.length === 0) {
        const error = new Error();
        error.code = 'TE002';
        error.message = 'get called but returned no result';
        throw Observable.throw(error);
      }
    }
    */
    return restResp;
  }

  /**
  * Handle the server call's errors
  *
  * @private
  * @param {Response} error
  * @returns {(Observable<Object>|string)}
  *
  * @memberOf AuthenticationService
  */

  protected handleError(error: Response): Observable<any> | string {
    if (error.status === 400) {
      this.logger.error('BaseService', 'the call failed: Server error');
      const restError = new Error();
      restError.code = '' + error.status;
      restError.message = error.statusText;
      return Observable.throw(restError || 'Server error');
    } if (error.status === 403 || error.status === 401 || error.status.toString() === '403') {
      this.logger.error('BaseService', 'the call failed: ', error.json() || 'Server error');
      const restError = new Error();
      restError.code = '' + error.status;
      restError.message = error.statusText;
      restError.stack = error.json();
      return Observable.throw(restError || 'Server error');
    } else {
      this.logger.error('BaseService', 'get called but returned no result ');
      return Observable.throw(error);
    }
  }
}
