/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { FolderTypesService } from './folder-types.service';

describe('Service: FolderTypes', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FolderTypesService]
    });
  });

  it('should ...', inject([FolderTypesService], (service: FolderTypesService) => {
    expect(service).toBeTruthy();
  }));
});
