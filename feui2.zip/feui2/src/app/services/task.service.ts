import { RestResponse } from './../models/rest-response';
import { LoggerService } from './logger/logger.service';
import { HttpClientService } from './http-client.service';
import { Injectable } from '@angular/core';
import { BaseService } from 'app/services/base.service';
import { Task } from 'app/models/task';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http/src/static_response';

@Injectable()
export class TaskService extends BaseService<any> {

  constructor(
    http: HttpClientService,
    logger: LoggerService
  ) {
    super(http, logger);
  }

  /**
  *
  * @param id
  * @returns {Observable<RestResponse<Task>>}
  * @memberOf TaskService
  */
  getTasksById(id: string): Observable<RestResponse<Task>> {
    this.logger.debug('TaskService', 'getTasksById() called', id);
    return this.http.get(this.baseUrl + '/tasks/' + id)
      .map((resp: Response) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));
  }

  /**
     * Perfomr a transfer Task
     * @param formId
     * @param toId
     */
  putTaskByIdTransfer(formId: string, toId: string): Observable<RestResponse<string>> {
    this.logger.debug('BasketService', 'putTaskByIdTransfer() called', { formId: formId, toId: toId });
    return this.http.put(this.baseUrl + '/tasks/' + formId + '/transfer', toId)
      .map((resp: any) => this.handleResponse(resp))
      .catch(error => this.handleError(error));
  }

  /**
     * Perfomr a transfer Task
     * @param id
     * @param status (CLOSE,  PENDING, NEW;)
     */
    putTaskByIdStatus(id: string, status: string): Observable<RestResponse<string>> {
      this.logger.debug('BasketService', 'putTaskByIdStatus() called', { id: id, status: status });
      return this.http.put(this.baseUrl + '/tasks/' + id + '/status', status)
        .map((resp: any) => this.handleResponse(resp))
        .catch(error => this.handleError(error));
    }
}
