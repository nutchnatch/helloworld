import { RestResponse } from './../models/rest-response';
import { Observable } from 'rxjs/Observable';
import { LoggerService } from './logger/logger.service';
import { HttpClientService } from './http-client.service';
import { FolderTypes } from 'app/models/folder-types';
import { Injectable } from '@angular/core';
import { BaseService } from 'app/services/base.service';

@Injectable()
export class FolderTypesService extends BaseService<FolderTypes> {

  constructor(
    http: HttpClientService,
    logger: LoggerService
  ) {
    super(http, logger);
  }
  /**
   * Get Document Type List
   *
   * @returns {Observable<RestResponse<FolderTypes>>}
   * @memberof FolderTypesService
   */
  getFolderTypes(): Observable<RestResponse<FolderTypes>> {
    this.logger.debug('FolderTypesService', 'getFolderTypes() called');
    return this.http.get(this.baseUrl + '/folder-types')
      .map((resp: any ) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));
  }
}
