import { QueryParams } from 'app/models/paged';
import { RestResponse } from 'app/models/rest-response';
import { Paging } from 'app/models/paging';
import { PagedQuery } from 'app/models/paged';
import { Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { LoggerService } from './logger/logger.service';
import { HttpClientService } from './http-client.service';
import { BaseService } from './base.service';
import { Injectable } from '@angular/core';
import { Basket } from 'app/models/basket';


@Injectable()
export class BasketService extends BaseService<Basket> {

  constructor(
    http: HttpClientService,
    logger: LoggerService
  ) {
    super(http, logger);
  }

  /**
   *
   * @returns {Observable<RestResponse<Basket>>}
   *
   * @memberOf BasketService
   */
  getBaskets(params?: QueryParams): Observable<RestResponse<Basket>> {
    this.logger.debug('BasketService', 'getBaskets() called');

    // const queryParams: URLSearchParams = new URLSearchParams();
    // Object.assign(queryParams, params);
    // console.log(queryParams.toString())

    return this.http.get(this.baseUrl + '/baskets', { search: params })
      .map((resp: Response) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));
  }

  /**
   *
   * @param id
   * @returns {Observable<RestResponse<Task>>}
   * @memberOf BasketService
   */
  getBasketsTasksById(id: string, params?: QueryParams ): Observable<RestResponse<Basket>> {
    this.logger.debug('BasketService', 'getBasketsTasksById() called', id);
    return this.http.get(this.baseUrl + '/baskets/' + id + '/tasks',  { search: params })
      .map((resp: Response) => this.handleResponse(resp, false))
      .catch(error => this.handleError(error));

  }

  // /**
  //  * Perfomr a transfer Basket
  //  * @param formId
  //  * @param toId
  //  */
  // putBasketByIdTransfer(formId: string, toId: string): Observable<RestResponse<string>> {
  //   this.logger.debug('BasketService', 'putBasketByIdTransfer() called', {formId : formId, toId: toId});
  //   return this.http.put(this.baseUrl + '/tasks/' + formId + '/transfer',  toId)
  //     .map((resp: Response) => this.handleResponse(resp, false))
  //     .catch(error => this.handleError(error));
  // }

  // /**
  //  *
  //  * @param id
  //  * @param body
  //  * @memberOf BasketService
  //  */
  // putBasketsById(id: string, body: Basket): Observable<RestResponse<BasketCreationResult>> {
  //   this.logger.debug('BasketService', 'putBasketsById() called', { id: id, body: body } );
  //   return this.http.put(this.baseUrl + '/documents/' + id, body)
  //     .map((resp: Response) => this.handleResponse(resp, false))
  //     .catch(error => this.handleError(error));

  // }
}
