/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { EnvelopesService } from './envelopes.service';

describe('Service: Envelopes', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EnvelopesService]
    });
  });

  it('should ...', inject([EnvelopesService], (service: EnvelopesService) => {
    expect(service).toBeTruthy();
  }));
});
