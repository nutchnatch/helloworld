import * as Document from 'app/states/document.state';
import * as documentActions from '../actions/documents.actions';
import * as sharedActions from '../actions/shared.actions';

export class State extends Document.State { }

const initialState: Document.State = Document.initialState;

export function reducer(state = initialState, action: documentActions.Actions): Document.State {
  switch (action.type) {
    case documentActions.ActionTypes.LOADING_DOCUMENT:
      state = Object.assign({}, state, { result: null, loading: true, status: null, error: null });
      return state;
    case documentActions.ActionTypes.UPDATING_DOCUMENT:
      state = Object.assign({}, state, { updateResult: null, updating: true, status: null, updateError: null });
      return state;
    case documentActions.ActionTypes.PUT_DOCUMENT:
      state = Object.assign({}, state, { result: action.payload, loading: false, status: true, error: null });
      return state;
    case documentActions.ActionTypes.PUT_UPDATE_DOCUMENT:
      state = Object.assign({}, state, { updateResult: action.payload, updating: false, updateError: null });
      return state;
    case documentActions.ActionTypes.PUT_DOCUMENT_ERROR:
      /** result: null, */
      state = Object.assign({}, state, { loading: false, updating: false, status: true, error: action.payload });
      return state;
    case documentActions.ActionTypes.PUT_UPDATE_DOCUMENT_ERROR:
      /** result: null, */
      state = Object.assign({}, state, { updateResult: null, updateError: action.payload, updating: false, status: true });
      return state;
    case documentActions.ActionTypes.PUT_UPDATE_DOCUMENT_INIT:
      state = Object.assign({}, state, { updateResult: null, updateError: null, updating: false, status: false });
      return state;
    case documentActions.ActionTypes.INIT:
      state = Object.assign({}, state, initialState);
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState);
      return state;
    default:
      return state;
  }
}

export const getDocuments = (state: Document.State) => state;
export const getDocumentsResult = (state: Document.State) => state.result;
export const getDocumentsLoading = (state: Document.State) => state.loading;
export const getDocumentsUpdating = (state: Document.State) => state.updating;
export const getDocumentsUpdateResult = (state: Document.State) => state.updateResult;
export const getDocumentsError = (state: Document.State) => state.error;
export const getDocumentsUpdateError = (state: Document.State) => state.updateError;
