import * as Tag from 'app/states/tag.state';
import * as tagActions from '../actions/tag.actions';
import * as sharedActions from '../actions/shared.actions';

export class State extends Tag.State { }

const initialState: Tag.State = Tag.initialState;

export function reducer(state = initialState, action: tagActions.Actions): Tag.State {
  switch (action.type) {
    case tagActions.ActionTypes.LOADING_TAG:
      state = Object.assign({}, state, { result: null, loading: action.payload, status: null, error: null });
    return state;
    case tagActions.ActionTypes.PUT_TAG:
      state = Object.assign({}, state, { result: action.payload, loading: false, status: true, error: null });
      return state;
    case tagActions.ActionTypes.PUT_TAG_ERROR:
      state = Object.assign({}, state, { result: null, loading: false, status: false, error: action.payload });
      return state;
    case tagActions.ActionTypes.INIT_TAG:
      state = Object.assign({}, state, initialState);
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState);
      return state;
    default:
      return state;
  }
}

export const getTags = (state: Tag.State) => state;
export const getTagsResult = (state: Tag.State) =>  state.result;
export const getTagsLoading = (state: Tag.State) => state.loading;
export const getTagsError = (state: Tag.State) => state.error;
