import * as ExtraFields from './../states/extra-fields.state';
import * as extraFieldsActions from '../actions/extra-fields.actions';
import * as sharedActions from '../actions/shared.actions';

import { remove, find } from 'lodash';

export class State extends ExtraFields.State { }

const initialState: ExtraFields.State = ExtraFields.initialState;

export function reducer(state = initialState, action: extraFieldsActions.Actions): ExtraFields.State {
  switch (action.type) {
    case extraFieldsActions.ActionTypes.LOADING_EXTRA_FIELDS:
      state = Object.assign({}, state, { metadataFields: null, loaded: false });
      return state;
    case extraFieldsActions.ActionTypes.PUT_EXTRA_FIELDS:
      const tags = action.payload['tags'];
      const docTypeInputs = action.payload['documentType'].map(
        types => Object.assign({}, types, {
          // tslint:disable-next-line:max-line-length
          inputsFields: types.tagList.map(type => Object.assign({}, find(tags, tag => tag.name === type.symbolicName), { mandatory: type.mandatory }))
        }));
      state = Object.assign({}, state, { metadataFields: docTypeInputs, loaded: true });
      return state;
    case extraFieldsActions.ActionTypes.PUT_ENVELOPE_EXTRA_FIELDS:
      const tagsEnvelope = action.payload['tags'];
      const envTypeInputs = action.payload['envelopeType'].map(
        types => Object.assign({}, types, {
          // tslint:disable-next-line:max-line-length
          inputsFields: types.tagList.map(type => Object.assign({}, find(tagsEnvelope, tag => tag.name === type.symbolicName), { mandatory: type.mandatory }))
        }));
      state = Object.assign({}, state, { envelopeMetadataFields: envTypeInputs, loaded: true });
      return state;
    case extraFieldsActions.ActionTypes.PUT_FOLDER_EXTRA_FIELDS:
      const folderEnvelope = action.payload['tags'];
      const folderTypeInputs = action.payload['folderType'].map(
        types => Object.assign({}, types, {
          // tslint:disable-next-line:max-line-length
          inputsFields: types.tagList.map(type => Object.assign({}, find(folderEnvelope, tag => tag.name === type.symbolicName), { mandatory: type.mandatory }))
        }));
      state = Object.assign({}, state, { folderMetadataFields: folderTypeInputs, loaded: true });
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState);
      return state;
    default:
      return state;
  }
}

export const getExtraFields = (state: ExtraFields.State) => state;
export const getExtraFieldsMetadataFields = (state: ExtraFields.State) => state.metadataFields;
export const getExtraFieldsEnvelopeMetadataFields = (state: ExtraFields.State) => state.envelopeMetadataFields;
export const getExtraFieldsFolderMetadataFields = (state: ExtraFields.State) => state.folderMetadataFields;
export const getExtraFieldsLoaded = (state: ExtraFields.State) => state.loaded;
