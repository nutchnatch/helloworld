
import * as AdvanceSearchState from 'app/states/advance-search.state';
import * as advanceSearchActions from '../actions/advance-search.actions';
import * as sharedActions from '../actions/shared.actions';

import { flattenDepth, uniqBy, filter, remove } from 'lodash';
import { AdvanceQuery } from 'app/states/advance-search.state';

export class State extends AdvanceSearchState.State { }

const initialState: AdvanceSearchState.State = AdvanceSearchState.initialState;


export function reducer(state = initialState, action: advanceSearchActions.Actions): AdvanceSearchState.State {
  switch (action.type) {
    case advanceSearchActions.ActionTypes.PUT_DOMAIN:
      state = Object.assign({}, state, { domain: action.payload });
      return state;
    case advanceSearchActions.ActionTypes.PUT_DOMAIN_SELECTED:
      state = Object.assign({}, state, { domainSelected: action.payload });
      return state;
    case advanceSearchActions.ActionTypes.PUT_TAGS_LIST:
      const allUniqueTags = flattenDepth(action.payload.map(type => type.inputsFields));
      const combinedTags = state.defaultTags.concat(uniqBy(allUniqueTags, 'name'));
      state = Object.assign({}, state, { tagsList: combinedTags });
      return state;
    case advanceSearchActions.ActionTypes.PUT_ADVANCE_SEARCH:
      state = Object.assign({}, state, { advanceSearchQuery: state.advanceSearchQuery.concat(action.payload) });
      return state;
    case advanceSearchActions.ActionTypes.PUT_ADVANCE_SEARCH_BY_ID:
      // state = Object.assign({}, state, { advanceSearchQuery: state.advanceSearchQuery.concat(action.payload) });
      return state;
    case advanceSearchActions.ActionTypes.REMOVE_ADVANCE_SEARCH_BY_ID:
      const newArray = [...state.advanceSearchQuery];
      // tslint:disable-next-line:max-line-length
      state = Object.assign({}, state, { advanceSearchQuery: remove(newArray, (query, i) => { if (i !== action.payload) { return query; } }) });
      return state;
    case advanceSearchActions.ActionTypes.REMOVE_ALL_ADVANCE_SEARCH:
      state = Object.assign({}, state, { advanceSearchQuery: [] });
      return state;
    case advanceSearchActions.ActionTypes.PUT_TYPE_ID:
      state = Object.assign({}, state, { typeId: action.payload });
      return state;
    case advanceSearchActions.ActionTypes.PUT_FORM_GROUP:
      state = Object.assign({}, state, { formGroup: action.payload });
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState);
      return state;
    default:
      return state;

  }
}

export const getAdvanceSearch = (state: AdvanceSearchState.State) => state;
export const getAdvanceSearchDomain = (state: AdvanceSearchState.State) => state.domain;
export const getAdvanceSearchDomainSelected = (state: AdvanceSearchState.State) => state.domainSelected;
export const getAdvanceSearchDefaultTags = (state: State) => state.defaultTags;
export const getAdvanceSearchDefaultOperators = (state: State) => state.defaultOperators;
export const getAdvanceSearchTagsList = (state: AdvanceSearchState.State) => state.tagsList;
export const getAdvanceSearchTypeId = (state: AdvanceSearchState.State) => state.typeID;
export const getAdvanceSearchQuery = (state: AdvanceSearchState.State) => state.advanceSearchQuery;
export const getAdvanceSearchFormGroup = (state: AdvanceSearchState.State) => state.formGroup;

