import * as FolderState from 'app/states/folder.state';
import * as folderActions from '../actions/folder.actions';
import * as sharedActions from '../actions/shared.actions';

export class State extends FolderState.State { }

const initialState: FolderState.State = FolderState.initialState;


export function reducer(state = initialState, action: folderActions.Actions): FolderState.State {
  switch (action.type) {
    case folderActions.ActionTypes.LOADING_FOLDER:
      state = Object.assign({}, state, { loading: true, error: null, status: false });
      return state;
    case folderActions.ActionTypes.UPDATING_FOLDER:
      state = Object.assign({}, state, { updateResult: null, updating: true, status: null, updateError: null });
      return state;
    case folderActions.ActionTypes.PUT_FOLDER_RESULT:
      state = Object.assign({}, state, { loading: false, error: null, result: action.payload, status: true });
      return state;

    case folderActions.ActionTypes.PUT_UPDATE_FOLDER:
      state = Object.assign({}, state, { updateResult: action.payload, updating: false, updateError: null });
      return state;
    case folderActions.ActionTypes.PUT_FOLDER_ERROR:
      state = Object.assign({}, state, { loading: false, error: action.payload, status: false });
      return state;
    case folderActions.ActionTypes.PUT_UPDATE_FOLDER_ERROR:
      state = Object.assign({}, state, { updateResult: null, updateError: action.payload, updating: false, status: false });
      return state;
    case folderActions.ActionTypes.PUT_UPDATE_FOLDER_INIT:
      state = Object.assign({}, state, { updateResult: null, updateError: null, updating: false, status: false });
      return state;

    case folderActions.ActionTypes.POST_FOLDER_CREATING:
      state = Object.assign({}, state, { creatingResult: null, creating: action.payload, creatingError: null });
      return state;
    case folderActions.ActionTypes.POST_FOLDER_ERROR:
      state = Object.assign({}, state, { creatingResult: null, creating: false, creatingError: action.payload });
      return state;
    case folderActions.ActionTypes.POST_FOLDER_RESULT:
      state = Object.assign({}, state, { creatingResult: action.payload, creating: false, creatingError: null });
      return state;
    case folderActions.ActionTypes.POST_FOLDER_INIT:
      state = Object.assign({}, state, { creatingResult: null, creating: false, creatingError: null });
      return state;

    case folderActions.ActionTypes.DELETE_FOLDER_DELETING:
      state = Object.assign({}, state, { deletingResult: null, deleting: action.payload, deletingError: null });
      return state;
    case folderActions.ActionTypes.DELETE_FOLDER_ERROR:
      state = Object.assign({}, state, { deletingResult: null, deleting: false, deletingError: action.payload });
      return state;
    case folderActions.ActionTypes.DELETE_FOLDER_RESULT:
      state = Object.assign({}, state, { deletingResult: action.payload, deleting: false, deletingError: null });
      return state;
    case folderActions.ActionTypes.DELETE_FOLDER_INIT:
      state = Object.assign({}, state, { deletingResult: null, deleting: false, deletingError: null });
      return state;

    case folderActions.ActionTypes.INIT_FOLDER:
      state = Object.assign({}, state, initialState);
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState);
      return state;
    default:
      return state;

  }
}

export const getFolder = (state: FolderState.State) => state;
export const getFolderResult = (state: FolderState.State) => state.result;
export const getFolderLoading = (state: FolderState.State) => state.loading;
export const getFolderError = (state: FolderState.State) => state.error;
export const getFolderStatus = (state: FolderState.State) => state.status;
export const getFolderUpdating = (state: FolderState.State) => state.updating;
export const getFolderUpdateResult = (state: FolderState.State) => state.updateResult;
export const getFolderUpdateError = (state: FolderState.State) => state.updateError;
export const getFolderCreateCreating = (state: FolderState.State) => state.creating;
export const getFolderCreateError = (state: FolderState.State) => state.creatingError;
export const getFolderCreateResult = (state: FolderState.State) => state.creatingResult;

export const getFolderDeletingDeleting = (state: FolderState.State) => state.deleting;
export const getFolderDeletingError = (state: FolderState.State) => state.deletingError;
export const getFolderDeletingResult = (state: FolderState.State) => state.deletingResult;
