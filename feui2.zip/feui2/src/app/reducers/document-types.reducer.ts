import * as DocumentTypes from 'app/states/document-types.state';
import * as documentTypesActions from '../actions/document-types.actions';
import * as sharedActions from '../actions/shared.actions';

export class State extends DocumentTypes.State { }

const initialState: DocumentTypes.State = DocumentTypes.initialState;

export function reducer(state = initialState, action: documentTypesActions.Actions): DocumentTypes.State {
  switch (action.type) {
    case documentTypesActions.ActionTypes.LOADING_DOCUMENT_TYPES:
      state = Object.assign({}, state, { result: null, loading: action.payload, status: null, error: null });
    return state;
    case documentTypesActions.ActionTypes.PUT_DOCUMENT_TYPES:
      state = Object.assign({}, state, { result: action.payload, loading: false, status: true, error: null });
      return state;
    case documentTypesActions.ActionTypes.PUT_DOCUMENT_TYPES_ERROR:
      state = Object.assign({}, state, { result: null, loading: false, status: false, error: action.payload });
      return state;
    case documentTypesActions.ActionTypes.INIT_DOCUMENT_TYPES:
      state = Object.assign({}, state, initialState);
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState);
      return state;
    default:
      return state;
  }
}

export const getDocumentTypes = (state: DocumentTypes.State) => state;
export const getDocumentTypesResult = (state: DocumentTypes.State) =>  state.result;
export const getDocumentTypesLoading = (state: DocumentTypes.State) => state.loading;
export const getDocumentTypesError = (state: DocumentTypes.State) => state.error;
