

import * as InfoState from 'app/states/info.state';
import * as infoActions from '../actions/info.actions';
import * as sharedActions from '../actions/shared.actions';

// import { get, find } from 'lodash';

export class State extends InfoState.State { }

const initialState: InfoState.State = InfoState.initialState;


export function reducer(state = initialState, action: infoActions.Actions): InfoState.State {
  switch (action.type) {
    case infoActions.ActionTypes.LOADING_INFO:
      state = Object.assign({}, state, { loading: true, version: null, error: null });
      return state;
    case infoActions.ActionTypes.PUT_INFO_VERSION:
      state = Object.assign({}, state, { loading: false, ...action.payload , error: null });
      return state;
    case infoActions.ActionTypes.INIT_INFO:
      state = Object.assign({}, state, initialState);
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState);
      return state;
    default:
      return state;

  }
}

export const getInfo = (state: InfoState.State) => state;
export const getInfoVersion = (state: InfoState.State) => state.version;
