import * as EnvelopeTypes from 'app/states/envelope-types.state';
import * as envelopeTypesActions from '../actions/envelope-types.actions';
import * as sharedActions from '../actions/shared.actions';

import { find } from 'lodash';

export class State extends EnvelopeTypes.State { }

const initialState: EnvelopeTypes.State = EnvelopeTypes.initialState;

export function reducer(state = initialState, action: envelopeTypesActions.Actions): EnvelopeTypes.State {
  switch (action.type) {
    case envelopeTypesActions.ActionTypes.LOADING_ENVELOPE_TYPES:
      state = Object.assign({}, state, { result: null, loading: action.payload, status: null, error: null });
      return state;
    case envelopeTypesActions.ActionTypes.PUT_ENVELOPE_TYPES:
      state = Object.assign({}, state, { result: action.payload, loading: false, status: true, error: null });
      return state;
    case envelopeTypesActions.ActionTypes.PUT_ENVELOPE_TYPES_BY_ID:
      state = Object.assign({}, state, { result: state.result.concat(action.payload), loading: false, status: true, error: null });
      return state;
    case envelopeTypesActions.ActionTypes.PUT_ENVELOPE_TYPES_ERROR:
      state = Object.assign({}, state, { result: null, loading: false, status: false, error: action.payload });
      return state;
    case envelopeTypesActions.ActionTypes.INIT_ENVELOPE_TYPES:
      state = Object.assign({}, state, initialState);
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState);
      return state;
    default:
      return state;
  }
}

export const getEnvelopeTypes = (state: EnvelopeTypes.State) => state;
export const getEnvelopeTypesResult = (state: EnvelopeTypes.State) => state.result;
export const getEnvelopeTypesLoading = (state: EnvelopeTypes.State) => state.loading;
export const getEnvelopeTypesError = (state: EnvelopeTypes.State) => state.error;
