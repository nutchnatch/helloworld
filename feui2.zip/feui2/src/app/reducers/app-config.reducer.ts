import { Link } from './../models/breadcrumb';
import { Sidebar, MetadataBar } from 'app/models/sidesbars-config';

import * as sharedActions from 'app/actions/shared.actions';
import * as appConfigActions from 'app/actions/app-config.actions';

import * as appConfigState from 'app/states/app-config.state';


export class State extends appConfigState.State { }

export const initialState: appConfigState.State = appConfigState.initialState;

/**
 *
 * This state is stored in localstorage
 * note: if new property is not appear on redux-devTools, clean yours localstorage ('config' key);
 *
 * @export
 * @param {any} [state=initialState]
 * @param {{ type: 'null'}} [action]
 * @returns {AppConfigState.State}
 */
export function reducer(state = initialState, action?: appConfigActions.Actions): appConfigState.State {
  switch (action.type) {
    case appConfigActions.ActionTypes.PUT_PAGE_SIZE:
      state = Object.assign({}, state, { pageSize: action.payload });
      return state;
    case appConfigActions.ActionTypes.PUT_SCOPE:
      state = Object.assign({}, state, { scope: action.payload });
      return state;
    case appConfigActions.ActionTypes.PUT_COPIED_TAGS:
      state = Object.assign({}, state, { copiedTags: action.payload });
      return state;

    default:
      return state;
  }
}

export const getAppConfigParams = (state: State) => state;
export const getAppConfigLocaleList = (state: State) => state.localeList;
export const getAppConfigConfidentialLevels = (state: State) => state.confidentialLevels;
export const getAppConfigScope = (state: State) => state.scope;
export const getAppConfigSearchTypes = (state: State) => state.searchTypes;
export const getAppConfigPageSizeList = (state: State) => state.pageSizeList;
export const getAppConfigPageSize = (state: State) => state.pageSize;
export const getAppConfigDashboard = (state: State) => state.dashboard;
export const getAppConfigSearch = (state: State) => state.search;
export const getAppConfigEnvelop = (state: State) => state.envelop;
export const getAppConfigFolder = (state: State) => state.folder;
export const getAppConfigNew = (state: State) => state.new;
export const getAppConfigUploadDocuments = (state: State) => state.upload;
export const getAppConfigDefaultTags = (state: State) => state.defaultTags;
export const getAppConfigDefaultOperators = (state: State) => state.defaultOperators;
export const getAppConfigCopiedTags = (state: State) => state.copiedTags;
export const getAppConfigLangISO = (state: State) => state.langISO;





