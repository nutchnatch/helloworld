

import * as SearchPagedState from 'app/states/search-paged.state';
import * as searchPagedActions from '../actions/search-paged.actions';
import * as sharedActions from '../actions/shared.actions';

// import { get, find } from 'lodash';

export class State extends SearchPagedState.State { }

const initialState: SearchPagedState.State = SearchPagedState.initialState;


export function reducer(state = initialState, action: searchPagedActions.Actions): SearchPagedState.State {
  switch (action.type) {
    case searchPagedActions.ActionTypes.PUT_SEARCHING_RESULTS:
      state = Object.assign({}, state, { loading: false, results: action.payload['result'], paging: action.payload['paging'] });
      return state;
    case searchPagedActions.ActionTypes.PUT_SEARCHING_RESULTS_BY_ID:
      // const updatedDoc = Object.assign( {}, find(state.results, (obj) => obj['id'] === action.payload['id'] ) , {...action.payload } );
      state = Object.assign({}, state, {
        results: state.results.map(obj => obj['id'] === action.payload['id'] ? { ...action.payload } : obj)
      });
      return state;
    case searchPagedActions.ActionTypes.PUT_SEARCHING_QUERY:
      state = Object.assign({}, state, { query: action.payload });
      return state;
    case searchPagedActions.ActionTypes.PUT_SEARCHING_TYPE:
      state = Object.assign({}, state, { type: action.payload.toLocaleLowerCase() });
      return state;
    case searchPagedActions.ActionTypes.PUT_SEARCHING_ERROR:
      state = Object.assign({}, state, { error: action.payload, loading: false, results: null });
      return state;
    case searchPagedActions.ActionTypes.SEARCHING:
      state = Object.assign({}, state, { loading: true, results: null, error: null });
      return state;
    case searchPagedActions.ActionTypes.INIT_SEARCH:
      state = Object.assign({}, state, initialState);
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState);
      return state;
    default:
      return state;

  }
}

export const getSearchPaged = (state: SearchPagedState.State) => state;
export const getSearchPagedResults = (state: SearchPagedState.State) => state.results;
export const getSearchPagedPaging = (state: SearchPagedState.State) => state.paging;
export const getSearchPagedLoading = (state: SearchPagedState.State) => state.loading;
export const getSearchPagedQuery = (state: SearchPagedState.State) => state.query;
export const getSearchPagedType = (state: SearchPagedState.State) => state.type;
export const getSearchPagedError = (state: SearchPagedState.State) => state.error;
