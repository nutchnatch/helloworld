import * as UploadDocuments from 'app/states/upload-documents.state';
import * as uploadDocumentsActions from '../actions/upload-documents.actions';
import * as sharedActions from '../actions/shared.actions';

import { isEqual, filter, find } from 'lodash';

export class State extends UploadDocuments.State { }

const initialState: UploadDocuments.State = UploadDocuments.initialState;

export function reducer(state = initialState, action: uploadDocumentsActions.Actions): UploadDocuments.State {
  switch (action.type) {
    case uploadDocumentsActions.ActionTypes.LOADING:
      state = Object.assign({}, state, { loading: true, error: null,  uploaded: false });
      return state;
    case uploadDocumentsActions.ActionTypes.PUT_DOCUMENT_LIST:
      let fileList: Array<File>;
      if (state.documentsList.length > 0) {
        // tslint:disable-next-line:max-line-length
        fileList = find(state.documentsList, (file) => file.name === action.payload.name) ? fileList = state.documentsList : state.documentsList.concat(action.payload);
      } else {
        fileList = state.documentsList.concat(action.payload);
      }
      state = Object.assign({}, state, { documentsList: fileList, loading: false, error: null });
      return state;
    case uploadDocumentsActions.ActionTypes.REMOVE_DOCUMENT_LIST_BY_NAME:
      state = Object.assign({}, state, { documentsList: state.documentsList.filter(file => file.name !== action.payload) });
      return state;
    case uploadDocumentsActions.ActionTypes.PUT_RESULT:
      state = Object.assign({}, state, { result: action.payload, uploaded: true });
      return state;
    case uploadDocumentsActions.ActionTypes.PUT_DOCUMENT_LIST_ERROR:
      state = Object.assign({}, state, { result: null, loading: false, error: action.payload, uploaded: false });
      return state;
    case uploadDocumentsActions.ActionTypes.INIT_DOCUMENT_LIST:
      state = Object.assign({}, state, initialState);
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState);
      return state;
    default:
      return state;
  }
}

export const getUploadDocuments = (state: UploadDocuments.State) => state;
export const getUploadDocumentsList = (state: UploadDocuments.State) => state.documentsList;
export const getUploadDocumentsLoading = (state: UploadDocuments.State) => state.loading;
export const getUploadDocumentsError = (state: UploadDocuments.State) => state.error;
export const getUploadDocumentsResult = (state: UploadDocuments.State) => state.result;
