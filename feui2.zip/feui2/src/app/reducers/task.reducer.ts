
import * as Task from 'app/states/task.state';
import * as taskActions from '../actions/task.actions';
import * as sharedActions from '../actions/shared.actions';

export class State extends Task.State { }

const initialState: Task.State = Task.initialState;

export function reducer(state = initialState, action: taskActions.Actions): Task.State {
  switch (action.type) {
    case taskActions.ActionTypes.LOADING_TASK:
      state = Object.assign({}, state, { result: null, loading: true, status: null, error: null });
      return state;

    case taskActions.ActionTypes.PUT_TASK_RESULTS:
      state = Object.assign({}, state, { result: action.payload, loading: false, status: true, error: null });
      return state;
    case taskActions.ActionTypes.PUT_TASK_ERROR:
      /** result: null, */
      state = Object.assign({}, state, { loading: false, updating: false, status: true, error: action.payload });
      return state;

    case taskActions.ActionTypes.LOADING_TASK_TRANSFER:
      state = Object.assign({}, state, { resultTransfer: null, errorTransfer: null, loadingTransfer: true });
      return state;
    case taskActions.ActionTypes.PUT_TASK_ERROR_TRANSFER:
      /** result: null, */
      state = Object.assign({}, state, { resultTransfer: null, errorTransfer: action.payload, loadingTransfer: false });
      return state;
    case taskActions.ActionTypes.PUT_TASK_RESULTS_TRANSFER:
      state = Object.assign({}, state, { resultTransfer: action.payload, errorTransfer: null, loadingTransfer: false });
      return state;

    case taskActions.ActionTypes.LOADING_TASK_STATUS:
      state = Object.assign({}, state, { resultStatus: null, errorStatus: null, loadingStatus: true });
      return state;
    case taskActions.ActionTypes.PUT_TASK_ERROR_STATUS:
      /** result: null, */
      state = Object.assign({}, state, { resultStatus: null, errorStatus: action.payload, loadingStatus: false });
      return state;
    case taskActions.ActionTypes.PUT_TASK_RESULTS_STATUS:
      state = Object.assign({}, state, { resultStatus: action.payload, errorStatus: null, loadingStatus: false });
      return state;


    case taskActions.ActionTypes.INIT_STATUS:
      state = Object.assign({}, state, { resultStatus: null, errorStatus: null, loadingStatus: false });
      return state;
    case taskActions.ActionTypes.INIT_TRANSFER:
      state = Object.assign({}, state, { resultTransfer: null, errorTransfer: null, loadingTransfer: false });
      return state;
    case taskActions.ActionTypes.INIT:
      state = Object.assign({}, state, initialState);
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState);
      return state;
    default:
      return state;
  }
}

export const getTasks = (state: Task.State) => state;
export const getTasksResult = (state: Task.State) => state.result;
export const getTasksLoading = (state: Task.State) => state.loading;
export const getTasksError = (state: Task.State) => state.error;

export const getTasksTransferLoading = (state: Task.State) => state.loadingTransfer;
export const getTasksTransferResult = (state: Task.State) => state.resultTransfer;
export const getTasksTransferError = (state: Task.State) => state.errorTransfer;

export const getTasksStatusLoading = (state: Task.State) => state.loadingStatus;
export const getTasksStatusResult = (state: Task.State) => state.resultStatus;
export const getTasksStatusError = (state: Task.State) => state.errorStatus;
