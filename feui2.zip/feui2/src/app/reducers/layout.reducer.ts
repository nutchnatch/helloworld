import * as layoutActions from '../actions/layout.actions';
import * as sharedActions from '../actions/shared.actions';
import { Sidebar, MetadataBar, SidebarParams } from 'app/models/sidesbars-config';

/**
 * Layout State
 *
 * @export
 * @class State
 */
export class State {
  fromSearch: string;
  advanceSearch: Boolean;
  showSidenav: boolean;
  sideBarPined: boolean;
  url: string;
  sidebar: Sidebar;
  metadataBar: MetadataBar;
  tablesCompact: Boolean;
}

const initialState: State = {
  fromSearch: null,
  advanceSearch: false,
  showSidenav: true,
  sideBarPined: true,
  url: '/',
  sidebar: new Sidebar,
  metadataBar: new MetadataBar,
  tablesCompact: true
};

/**
 * Layout Reducer
 *
 * @export
 * @param {any} [state=initialState]
 * @param {layoutActions.Actions} action
 * @returns {State}
 */

export function reducer(state = initialState, action: layoutActions.Actions): State {
  switch (action.type) {
    case layoutActions.ActionTypes.CLOSE_SIDENAV:
      state = Object.assign({}, state, { showSidenav: false });
      return state;
    case layoutActions.ActionTypes.OPEN_SIDENAV:
      state = Object.assign({}, state, { showSidenav: true });
      return state;
    case layoutActions.ActionTypes.CURRENT_URL:
      state = Object.assign({}, state, { url: action.payload });
      return state;
    case layoutActions.ActionTypes.PIN_SIDEBAR:
      state = Object.assign({}, state, { sideBarPined: true });
      return state;
    case layoutActions.ActionTypes.UNPIN_SIDEBAR:
      state = Object.assign({}, state, { sideBarPined: false });
      return state;
    case layoutActions.ActionTypes.PUT_SIDEBAR_PARAMS:
      state = Object.assign({}, state, { sidebar: action.payload });
      return state;
    case layoutActions.ActionTypes.PUT_METADATABAR_PARAMS:
      state = Object.assign({}, state, { metadataBar: action.payload });
      return state;
    case layoutActions.ActionTypes.PUT_TABLE_COMPACT:
      state = Object.assign({}, state, { tablesCompact: action.payload });
      return state;
    case layoutActions.ActionTypes.PUT_FROM_SEARCH:
      state = Object.assign({}, state, { fromSearch: action.payload });
      return state;
    case layoutActions.ActionTypes.PUT_ADVANCE_SEARCH:
      state = Object.assign({}, state, { advanceSearch: action.payload });
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState);
      return state;
    default:
      return state;
  }
}

export const getShowSidenav = (state: State) => state.showSidenav;
export const getSideBarPined = (state: State) => state.sideBarPined;
export const getLayoutUrl = (state: State) => state.url;
export const getSideBarParams = (state: State) => state.sidebar;
export const getMetadataBarParams = (state: State) => state.metadataBar;
export const getMetadataBarShow = (state: State) => state.metadataBar.show;
export const getLayoutTableCompact = (state: State) => state.tablesCompact;
export const getLayoutFromSearch = (state: State) => state.fromSearch;
export const getLayoutAdvanceSearch = (state: State) => state.advanceSearch;

