import * as EnvelopeState from 'app/states/envelope.state';
import * as envelopeActions from '../actions/envelope.actions';
import * as sharedActions from '../actions/shared.actions';



export class State extends EnvelopeState.State { }

const initialState: EnvelopeState.State = EnvelopeState.initialState;


export function reducer(state = initialState, action: envelopeActions.Actions): EnvelopeState.State {
  switch (action.type) {
    case envelopeActions.ActionTypes.LOADING_ENVELOPE:
      state = Object.assign({}, state, { loading: true, error: null, status: false });
      return state;
    case envelopeActions.ActionTypes.UPDATING_ENVELOPE:
      state = Object.assign({}, state, { updateResult: null, updating: true, status: null, updateError: null });
      return state;
    case envelopeActions.ActionTypes.PUT_ENVELOPE_RESULT:
      state = Object.assign({}, state, { loading: false, error: null, result: action.payload, status: true });
      return state;
    case envelopeActions.ActionTypes.PUT_UPDATE_ENVELOPE:
      state = Object.assign({}, state, { updateResult: action.payload, updating: false, updateError: null });
      return state;
    case envelopeActions.ActionTypes.PUT_ENVELOPE_ERROR:
      state = Object.assign({}, state, { loading: false, error: action.payload, status: false });
      return state;
    case envelopeActions.ActionTypes.PUT_UPDATE_ENVELOPE_ERROR:
      state = Object.assign({}, state, { updateResult: null, updating: false, updateError: action.payload, status: false });
      return state;

    case envelopeActions.ActionTypes.PUT_UPDATE_ENVELOPE_INIT:
      state = Object.assign({}, state, { updateResult: null, updateError: null, updating: false, status: false });
      return state;

    case envelopeActions.ActionTypes.PUT_UNDER_CONSTRUCTION:
      state = Object.assign({}, state, { underConstructionStep2: action.payload });
      return state;

    case envelopeActions.ActionTypes.INIT_ENVELOPE:
      state = Object.assign({}, state, initialState);
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState);
      return state;
    default:
      return state;

  }
}

export const getEnvelope = (state: EnvelopeState.State) => state;
export const getEnvelopeResult = (state: EnvelopeState.State) => state.result;
export const getEnvelopeLoading = (state: EnvelopeState.State) => state.loading;
export const getEnvelopeError = (state: EnvelopeState.State) => state.error;
export const getEnvelopeStatus = (state: EnvelopeState.State) => state.status;
export const getEnvelopeUpdating = (state: EnvelopeState.State) => state.updating;
export const getEnvelopeUpdateResult = (state: EnvelopeState.State) => state.updateResult;
export const getEnvelopeUpdateError = (state: EnvelopeState.State) => state.updateError;
export const getEnvelopeUnderConstructionStep2 = (state: EnvelopeState.State) => state.underConstructionStep2;

