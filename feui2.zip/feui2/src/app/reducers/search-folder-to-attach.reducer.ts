import * as SearchFolderToAttachState from 'app/states/search-folder-to-attach.state';
import * as searchFolderToAttachActions from '../actions/search-folder-to-attach.actions';
import * as sharedActions from '../actions/shared.actions';
import { Folder } from 'app/models/folder';

export class State extends SearchFolderToAttachState.State { }

const initialState: SearchFolderToAttachState.State = SearchFolderToAttachState.initialState;


export function reducer(state = initialState, action: searchFolderToAttachActions.Actions): SearchFolderToAttachState.State {
  switch (action.type) {
    case searchFolderToAttachActions.ActionTypes.SEARCHING:
      state = Object.assign({}, state, { loading: true });
      return state;
    case searchFolderToAttachActions.ActionTypes.UPLOADING:
      state = Object.assign({}, state, { uploading: action.payload });
      return state;
    case searchFolderToAttachActions.ActionTypes.PUT_ATTACH_RESULTS_ID:
      state = Object.assign({}, state, { resultId: action.payload });
      return state;
    case searchFolderToAttachActions.ActionTypes.PUT_ATTACH_RESULTS:
      // console.log(action.payload['id']);
      state = Object.assign({}, state, { loading: false, uploading: false, hasResults: true, results: action.payload, success: null });
      return state;
    case searchFolderToAttachActions.ActionTypes.PUT_ATTACH_RESULTS_SELECTED:
      // console.log(action.payload['id']);
      state = Object.assign({}, state, { foldersSelected: action.payload });
      return state;
    case searchFolderToAttachActions.ActionTypes.PUT_ATTACH_RESULTS_SUCCESS:
      // console.log(action.payload['id']);
      // tslint:disable-next-line:max-line-length
      state = Object.assign({}, state, { resultId: null, loading: false, uploading: false, hasResults: false, results: null, success: action.payload });
    return state;
    case searchFolderToAttachActions.ActionTypes.INIT_ATTACH_PREVIEW:
      state = Object.assign({}, state, initialState);
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState);
      return state;
    default:
      return state;

  }
}

export const getSearchFolderToAttach = (state: SearchFolderToAttachState.State) => state;
export const getSearchFolderToAttachHasResult = (state: SearchFolderToAttachState.State) => state.hasResults;
export const getSearchFolderToAttachLoading = (state: SearchFolderToAttachState.State) => state.loading;
export const getSearchFolderToAttachResultId = (state: SearchFolderToAttachState.State) => state.resultId;
export const getSearchFolderToAttachResults = (state: SearchFolderToAttachState.State) => state.results;
export const getSearchFolderToAttachResultsSelected = (state: SearchFolderToAttachState.State) => state.foldersSelected;
export const getSearchFolderToAttachType = (state: SearchFolderToAttachState.State) => state.type;
export const getSearchFolderToAttachUploading = (state: SearchFolderToAttachState.State) => state.uploading;
export const getSearchFolderToAttachSuccess = (state: SearchFolderToAttachState.State) => state.success;
