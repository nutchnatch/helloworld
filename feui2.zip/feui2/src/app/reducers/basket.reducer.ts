
import * as Basket from 'app/states/basket.state';
import * as basketActions from '../actions/basket.actions';
import * as sharedActions from '../actions/shared.actions';

export class State extends Basket.State { }

const initialState: Basket.State = Basket.initialState;

export function reducer(state = initialState, action: basketActions.Actions): Basket.State {
  switch (action.type) {
    case basketActions.ActionTypes.LOADING_BASKET:
      state = Object.assign({}, state, { result: null, loading: true, status: null, error: null });
      return state;

    case basketActions.ActionTypes.PUT_BASKET_RESULTS:
      state = Object.assign({}, state, { result: action.payload, loading: false, status: true, error: null });
      return state;
    case basketActions.ActionTypes.PUT_UPDATE_BASKET:
      state = Object.assign({}, state, { updateResult: action.payload, updating: false, updateError: null });
      return state;
    case basketActions.ActionTypes.PUT_BASKET_ERROR:
      /** result: null, */
      state = Object.assign({}, state, { loading: false, updating: false, status: true, error: action.payload });
      return state;
    // case basketActions.ActionTypes.UPDATING_BASKET:
    //   state = Object.assign({}, state, { updateResult: null, updating: true, status: null, updateError: null });
    //   return state;
    // case basketActions.ActionTypes.PUT_UPDATE_BASKET_ERROR:
    //   /** result: null, */
    //   state = Object.assign({}, state, { updateResult: null, updateError: action.payload, updating: false, status: true });
    //   return state;
    // case basketActions.ActionTypes.PUT_UPDATE_BASKET_INIT:
    //   state = Object.assign({}, state, { updateResult: null, updateError: null, updating: false, status: false });
    //   return state;
    case basketActions.ActionTypes.INIT:
      state = Object.assign({}, state, initialState);
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState);
      return state;
    default:
      return state;
  }
}

export const getBaskets = (state: Basket.State) => state;
export const getBasketsResult = (state: Basket.State) => state.result;
export const getBasketsLoading = (state: Basket.State) => state.loading;
export const getBasketsError = (state: Basket.State) => state.error;

// export const getBasketsUpdating = (state: Basket.State) => state.updating;
// export const getBasketsUpdateResult = (state: Basket.State) => state.updateResult;
// export const getBasketsUpdateError = (state: Basket.State) => state.updateError;
