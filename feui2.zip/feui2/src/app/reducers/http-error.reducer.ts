import { Error } from './../models/error';
import * as httpErrorActions from '../actions/http-error.actions';
import * as sharedActions from '../actions/shared.actions';

/**
 * Http Error State
 *
 * @export
 * @class State
 */
export class State {
  httpError: Error;
  errorLoaded: boolean;
}

const initialState: State = {
  httpError: null,
  errorLoaded: false
};

export function reducer(state = initialState, action: httpErrorActions.Actions): State {

  switch (action.type) {
    case httpErrorActions.ActionTypes.PUT_HTTP_ERROR:
      state = Object.assign({}, state, { httpError: action.payload });
      return state;
    case httpErrorActions.ActionTypes.PUT_LOADED_ERROR:
      state = Object.assign({}, state, { errorLoaded: action.payload });
      return state;
    case httpErrorActions.ActionTypes.ERASE_HTTP_ERROR:
      state = Object.assign({}, state, initialState );
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState );
      return state;
    default:
      return state;
  }
}

export const getHttpError = (state: State) => state.httpError;
export const getLoadedError = (state: State) => state.errorLoaded;
