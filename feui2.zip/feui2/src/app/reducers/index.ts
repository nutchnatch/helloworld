import { createSelector } from 'reselect';
import { ActionReducer } from '@ngrx/store';
/*import * as fromRouter from '@ngrx/router-store';*/
import { environment } from '../../environments/environment';

/**
 * The compose function is one of our most handy tools. In basic terms, you give
 * it any number of functions and it returns a function. This new function
 * takes a value and chains it through every composed function, returning
 * the output.
 *
 * More: https://drboolean.gitbooks.io/mostly-adequate-guide/content/ch5.html
 */
import { compose } from '@ngrx/core/compose';

/**
 * storeFreeze prevents state from being mutated. When mutation occurs, an
 * exception will be thrown. This is useful during development mode to
 * ensure that none of the reducers accidentally mutates the state.
 */
import { storeFreeze } from 'ngrx-store-freeze';

/**
 * combineReducers is another useful metareducer that takes a map of reducer
 * functions and creates a new reducer that gathers the values
 * of each reducer and stores them using the reducer's key. Think of it
 * almost like a database, where every reducer is a table in the db.
 *
 * More: https://egghead.io/lessons/javascript-redux-implementing-combinereducers-from-scratch
 */
import { combineReducers } from '@ngrx/store';

/**
 * localStorageSync is another useful library that takes part/all store sync with localstorage
 * Simple syncing between ngrx store and local storage.
 *
 * More: https://github.com/btroncone/ngrx-store-localstorage
 */
import { localStorageSync } from 'ngrx-store-localstorage';


/**
 * Every reducer module's default export is the reducer function itself. In
 * addition, each module should export a type or interface that describes
 * the state of the reducer plus any selector functions. The `* as`
 * notation packages up all of the exports into a single object.
 */

import * as fromAppConfig from './app-config.reducer';
import * as fromClientSettings from './client-settings.reducer';
import * as fromLayout from './layout.reducer';
import * as fromLanguage from './language.reducer';
import * as fromBreadcrumb from './breadcrumb.reducer';
import * as fromUserDetail from './user-detail.reducer';
import * as fromSearchPaged from './search-paged.reducer';
import * as fromAdvanceSearch from './advance-search.reducer';
import * as fromSearchPreview from './search-preview.reducer';
import * as fromSearchFolderToAttach from './search-folder-to-attach.reducer';
import * as fromHttpError from './http-error.reducer';
import * as fromEnvelope from './envelope.reducer';
import * as fromEnvelopeTypes from './envelope-types.reducer';
import * as fromDocumentsFilter from './documents-filter.reducer';
import * as fromDocuments from './document.reducer';
import * as fromDocumentTypes from './document-types.reducer';
import * as fromFolder from './folder.reducer';
import * as fromFolderTypes from './folder-types.reducer';
import * as fromBasket from './basket.reducer';
import * as fromTask from './task.reducer';
import * as fromTags from './tag.reducer';
import * as fromExtraFields from './extra-fields.reducer';
import * as fromUploadDocuments from './upload-documents.reducer';
import * as fromInfo from './info.reducer';

/**
 * As mentioned, we treat each reducer like a table in a database. This means
 * our top level state interface is just a map of keys to inner state types.
 */
export class State {
  errors: fromHttpError.State;
  info: fromInfo.State;
  config: fromAppConfig.State;
  clientSettings: fromClientSettings.State;
  layout: fromLayout.State;
  breadcrumb: fromBreadcrumb.State;
  language: fromLanguage.State;
  user: fromUserDetail.State;
  searchPaged: fromSearchPaged.State;
  searchPreview: fromSearchPreview.State;
  searchFolderToAttach: fromSearchFolderToAttach.State;
  advanceSearch: fromAdvanceSearch.State;
  envelope: fromEnvelope.State;
  envelopeTypes: fromEnvelopeTypes.State;
  documentsFilter: fromDocumentsFilter.State;
  document: fromDocuments.State;
  documentTypes: fromDocumentTypes.State;
  folder: fromFolder.State;
  folderTypes: fromFolderTypes.State;
  basket: fromBasket.State;
  task: fromTask.State;
  tags: fromTags.State;
  extraFields: fromExtraFields.State;
  uploadDocuments: fromUploadDocuments.State;
}

/**
 * Because metareducers take a reducer function and return a new reducer,
 * we can use our compose helper to chain them together. Here we are
 * using combineReducers to make our top level reducer, and then
 * wrapping that in storeLogger. Remember that compose applies
 * the result from right to left.
 */
export const reducers = {
  config: fromAppConfig.reducer,
  layout: fromLayout.reducer,
  info: fromInfo.reducer,
  errors: fromHttpError.reducer,
  clientSettings: fromClientSettings.reducer,
  breadcrumb: fromBreadcrumb.reducer,
  language : fromLanguage.reducer,
  user: fromUserDetail.reducer,
  searchPaged:  fromSearchPaged.reducer,
  searchPreview: fromSearchPreview.reducer,
  searchFolderToAttach: fromSearchFolderToAttach.reducer,
  advanceSearch: fromAdvanceSearch.reducer,
  envelope: fromEnvelope.reducer,
  envelopeTypes: fromEnvelopeTypes.reducer,
  documentsFilter: fromDocumentsFilter.reducer,
  document: fromDocuments.reducer,
  documentTypes: fromDocumentTypes.reducer,
  folder: fromFolder.reducer,
  folderTypes: fromFolderTypes.reducer,
  basket: fromBasket.reducer,
  task: fromTask.reducer,
  tags: fromTags.reducer,
  extraFields: fromExtraFields.reducer,
  uploadDocuments: fromUploadDocuments.reducer
};

/**
 * List of part of store to be sync in localstorage. Each key represent a reducer in store.
 * ex: 'language' is the key of language: fromLanguage.State
 */
const syncStoreLocalStorage: Array<string|any> = [
  'language',
  'layout',
  'clientSettings',
  'basket'
  // 'config', // { config: ['pageSize'] }
  ];


// tslint:disable-next-line:max-line-length
const developmentReducer: ActionReducer<State> = compose(storeFreeze, localStorageSync( { keys: syncStoreLocalStorage , rehydrate: true } ) , combineReducers)(reducers);
// tslint:disable-next-line:max-line-length
const productionReducer: ActionReducer<State> =  compose(localStorageSync( { keys: syncStoreLocalStorage, rehydrate: true }  ) , combineReducers)(reducers);

export function reducer(state: any, action: any) {
  if (environment.production) {
    return productionReducer(state, action);
  } else {
    return developmentReducer(state, action);
  }
}


/**
 * SELECTOR HELP ON THE BOTTOM OF DOCUMENT
 */

/**
 * HTTP ERRORS Reducers
 */
export const getStateErrors = (state: State) => state.errors;
export const getHttpError: any = createSelector(getStateErrors, fromHttpError.getHttpError );
export const getLoadedError: any = createSelector(getStateErrors, fromHttpError.getLoadedError );

/**
 * Info Reducers
 */
export const getInfoState = (state: State) => state.info;
export const getInfoVersion: any = createSelector(getInfoState, fromInfo.getInfoVersion );


/**
 * Layout Reducers
 */
export const getLayoutState = (state: State) => state.layout;
// get show side menu state from a store <boolean>
export const getShowSidenav: any = createSelector(getLayoutState, fromLayout.getShowSidenav );
export const getSideBarPined: any = createSelector(getLayoutState, fromLayout.getSideBarPined );
export const getLayoutUrl: any = createSelector(getLayoutState, fromLayout.getLayoutUrl );
export const getSideBarParams: any = createSelector(getLayoutState, fromLayout.getSideBarParams );
export const getMetadataBarParams: any = createSelector(getLayoutState, fromLayout.getMetadataBarParams );
export const getMetadataBarShow: any = createSelector(getLayoutState, fromLayout.getMetadataBarShow );
export const getLayoutTableCompact: any = createSelector(getLayoutState, fromLayout.getLayoutTableCompact );
export const getLayoutFromSearch: any = createSelector(getLayoutState, fromLayout.getLayoutFromSearch );
export const getLayoutAdvanceSearch: any = createSelector(getLayoutState, fromLayout.getLayoutAdvanceSearch );



/**
 * AppConfig  Reducers and Client Settings
 */
export const getConfig = (state: State) => state.config;
export const getClientSettings = (state: State) => state.clientSettings;
// get show side menu state from a store <boolean>
export const getAppConfigParams: any = createSelector(getConfig, fromAppConfig.getAppConfigParams );
export const getAppConfigLocaleList: any = createSelector(getConfig, fromAppConfig.getAppConfigLocaleList );
export const getAppConfigConfidentialLevels: any = createSelector(getConfig, fromAppConfig.getAppConfigConfidentialLevels );
// export const getAppConfigScope: any = createSelector(getConfig, fromAppConfig.getAppConfigScope );
export const getAppConfigSearchTypes: any = createSelector(getConfig, fromAppConfig.getAppConfigSearchTypes );
// export const getAppConfigPageSize: any = createSelector(getConfig, fromAppConfig.getAppConfigPageSize );
export const getAppConfigPageSizeList: any = createSelector(getConfig, fromAppConfig.getAppConfigPageSizeList );
export const getAppConfigDashboard: any = createSelector(getConfig, fromAppConfig.getAppConfigDashboard );
export const getAppConfigSearch: any = createSelector(getConfig, fromAppConfig.getAppConfigSearch );
export const getAppConfigEnvelop: any = createSelector(getConfig, fromAppConfig.getAppConfigEnvelop );
export const getAppConfigFolder: any = createSelector(getConfig, fromAppConfig.getAppConfigFolder );
export const getAppConfigNew: any = createSelector(getConfig, fromAppConfig.getAppConfigNew );
export const getAppConfigUploadDocuments: any = createSelector(getConfig, fromAppConfig.getAppConfigUploadDocuments );
export const getAppConfigDefaultTags: any = createSelector(getConfig, fromAppConfig.getAppConfigDefaultTags );
export const getAppConfigDefaultOperators: any = createSelector(getConfig, fromAppConfig.getAppConfigDefaultOperators );
export const getAppConfigCopiedTags: any = createSelector(getConfig, fromAppConfig.getAppConfigCopiedTags );
export const getAppConfigLangISO: any = createSelector(getConfig, fromAppConfig.getAppConfigLangISO );

export const getAppConfigScope: any = createSelector(getClientSettings, fromClientSettings.getClientSettingsScope );
export const getAppConfigPageSize: any = createSelector(getClientSettings, fromClientSettings.getClientSettingsPageSize );


/**
 * Breadcrumb Reducers
 */
export const getBreadcrumbState = (state: State) => state.breadcrumb;
export const getCurrentBreadcrumb: any = createSelector(getBreadcrumbState, fromBreadcrumb.getCurrentBreadcrumb);

/**
 * Language Reducers
 */
export const getLanguageState = (state: State) => state.language;

/*
 * get current language from the store <string>
 */
export const getCurrentLanguage: any = createSelector(getLanguageState, fromLanguage.getCurrentLanguage);


/**
 * User Reducers
 */
export const getUserDetailsState = (state: State) => state.user;
export const getUserDetailsLoaded: any = createSelector(getUserDetailsState, fromUserDetail.getUserDetailLoaded);
export const getUserDetailsIsLoading: any = createSelector(getUserDetailsState, fromUserDetail.getUserDetailisLoading);
export const getUserDetailsUserName: any = createSelector(getUserDetailsState, fromUserDetail.getUserDetailUserName);
export const getUserDetailsFullUserName: any = createSelector(getUserDetailsState, fromUserDetail.getUserDetailFullUserName);
export const getUserDetailsAuthorities: any = createSelector(getUserDetailsState, fromUserDetail.getUserDetailAuthorities);
export const getErrorUserDetails: any = createSelector(getUserDetailsState, fromUserDetail.getErrorUserDetails);

export const getUserDetailHttpError: any = createSelector(getUserDetailsState, fromUserDetail.getUserDetailHttpError);
export const getUserDetailHttpErrorMessage: any = createSelector(getUserDetailsState, fromUserDetail.getUserDetailHttpErrorMessage);
export const getUserDetailHttpErrorDetails: any = createSelector(getUserDetailsState, fromUserDetail.getUserDetailHttpErrorDetails);


/**
 * Search Paged
 */
export const getSearchPaged = (state: State) => state.searchPaged;
export const getSearchPagedResults: any = createSelector(getSearchPaged, fromSearchPaged.getSearchPagedResults);
export const getSearchPagedPaging: any = createSelector(getSearchPaged, fromSearchPaged.getSearchPagedPaging);
export const getSearchPagedLoading: any = createSelector(getSearchPaged, fromSearchPaged.getSearchPagedLoading);
export const getSearchPagedQuery: any = createSelector(getSearchPaged, fromSearchPaged.getSearchPagedQuery);
export const getSearchPagedType: any = createSelector(getSearchPaged, fromSearchPaged.getSearchPagedType);
export const getSearchPagedError: any = createSelector(getSearchPaged, fromSearchPaged.getSearchPagedError);


/**
 * Search Preview
 */
export const getSearchPreview = (state: State) => state.searchPreview;
export const getSearchPreviewHasResult: any = createSelector(getSearchPreview, fromSearchPreview.getSearchPreviewHasResult);
export const getSearchPreviewResultId: any = createSelector(getSearchPreview, fromSearchPreview.getSearchPreviewResultId);
export const getSearchPreviewLoading: any = createSelector(getSearchPreview, fromSearchPreview.getSearchPreviewLoading);
export const getSearchPreviewResults: any = createSelector(getSearchPreview, fromSearchPreview.getSearchPreviewResults);
export const getSearchPreviewType: any = createSelector(getSearchPreview, fromSearchPreview.getSearchPreviewType);

/**
 * Search Folder to Attach
 */
export const getSearchFolderToAttach = (state: State) => state.searchFolderToAttach;
// tslint:disable-next-line:max-line-length
export const getSearchFolderToAttachHasResult: any = createSelector(getSearchFolderToAttach, fromSearchFolderToAttach.getSearchFolderToAttachHasResult);
export const getSearchFolderToAttachResultId: any = createSelector(getSearchFolderToAttach, fromSearchFolderToAttach.getSearchFolderToAttachResultId);
// tslint:disable-next-line:max-line-length
export const getSearchFolderToAttachLoading: any = createSelector(getSearchFolderToAttach, fromSearchFolderToAttach.getSearchFolderToAttachLoading);
export const getSearchFolderToAttachResults: any = createSelector(getSearchFolderToAttach, fromSearchFolderToAttach.getSearchFolderToAttachResults);
// tslint:disable-next-line:max-line-length
export const getSearchFolderToAttachType: any = createSelector(getSearchFolderToAttach, fromSearchFolderToAttach.getSearchFolderToAttachType);
export const getSearchFolderToAttachResultsSelected: any = createSelector(getSearchFolderToAttach, fromSearchFolderToAttach.getSearchFolderToAttachResultsSelected);
// tslint:disable-next-line:max-line-length
export const getSearchFolderToAttachUploading: any = createSelector(getSearchFolderToAttach, fromSearchFolderToAttach.getSearchFolderToAttachUploading);
export const getSearchFolderToAttachSuccess: any = createSelector(getSearchFolderToAttach, fromSearchFolderToAttach.getSearchFolderToAttachSuccess);



/**
 * Advance Preview
 */
export const getAdvanceSearch = (state: State) => state.advanceSearch;
export const getAdvanceSearchDomain: any = createSelector(getAdvanceSearch, fromAdvanceSearch.getAdvanceSearchDomain);
export const getAdvanceSearchDomainSelected: any = createSelector(getAdvanceSearch, fromAdvanceSearch.getAdvanceSearchDomainSelected);
export const getAdvanceSearchDefaultTags: any = createSelector(getAdvanceSearch, fromAdvanceSearch.getAdvanceSearchDefaultTags);
export const getAdvanceSearchDefaultOperators: any = createSelector(getAdvanceSearch, fromAdvanceSearch.getAdvanceSearchDefaultOperators);
export const getAdvanceSearchTagsList: any = createSelector(getAdvanceSearch, fromAdvanceSearch.getAdvanceSearchTagsList);
export const getAdvanceSearchTypeId: any = createSelector(getAdvanceSearch, fromAdvanceSearch.getAdvanceSearchTypeId);
export const getAdvanceSearchQuery: any = createSelector(getAdvanceSearch, fromAdvanceSearch.getAdvanceSearchQuery);
export const getAdvanceSearchFormGroup: any = createSelector(getAdvanceSearch, fromAdvanceSearch.getAdvanceSearchFormGroup);

/**
 *  Envelope
 */
export const getEnvelope = (state: State) => state.envelope;
export const getEnvelopeResult: any = createSelector(getEnvelope, fromEnvelope.getEnvelopeResult);
export const getEnvelopeFirstResult: any = createSelector(getEnvelopeResult, (result) => result && result['0'] );
export const getEnvelopeLoading: any = createSelector(getEnvelope, fromEnvelope.getEnvelopeLoading);
export const getEnvelopeError: any = createSelector(getEnvelope, fromEnvelope.getEnvelopeError);
export const getEnvelopeStatus: any = createSelector(getEnvelope, fromEnvelope.getEnvelopeStatus);
export const getEnvelopeListDocuments: any = createSelector(getEnvelopeResult, (result) => {
  return result && result['0'].listOfDocumentId;
});
export const getEnvelopeUpdating: any = createSelector(getEnvelope, fromEnvelope.getEnvelopeUpdating);
export const getEnvelopeUpdateResult: any = createSelector(getEnvelope, fromEnvelope.getEnvelopeUpdateResult);
export const getEnvelopeUpdateError: any = createSelector(getEnvelope, fromEnvelope.getEnvelopeUpdateError);
export const getEnvelopeUnderConstructionStep2: any = createSelector(getEnvelope, fromEnvelope.getEnvelopeUnderConstructionStep2);

/**
 * Envelope Types
 */
export const getEnvelopeTypes = (state: State) => state.envelopeTypes;
export const getEnvelopeTypesResult: any = createSelector(getEnvelopeTypes, fromEnvelopeTypes.getEnvelopeTypesResult);
export const getEnvelopeTypesLoading: any = createSelector(getEnvelopeTypes, fromEnvelopeTypes.getEnvelopeTypesLoading);
export const getEnvelopeTypesError: any = createSelector(getEnvelopeTypes, fromEnvelopeTypes.getEnvelopeTypesError);

/**
 *  Documents Filter
 */
export const getDocumentsFilter = (state: State) => state.documentsFilter;
export const getDocumentsFilterMultiple: any = createSelector(getDocumentsFilter, fromDocumentsFilter.getDocumentsFilterMultiple);
export const getDocumentsFilterSelected: any = createSelector(getDocumentsFilter, fromDocumentsFilter.getDocumentsFilterSelected);
export const getDocumentsFilterList: any = createSelector(getDocumentsFilter, fromDocumentsFilter.getDocumentsFilterList);
// tslint:disable-next-line:max-line-length
export const getDocumentsFilterListSelected: any = createSelector(getDocumentsFilter, fromDocumentsFilter.getDocumentsFilterListSelected);
export const getDocumentsFilterListSelectedCount: any = createSelector(getDocumentsFilter, fromDocumentsFilter.getDocumentsFilterListSelectedCount);


/**
 * Documents
 */

export const getDocuments = (state: State) => state.document;
export const getDocumentsResult: any = createSelector(getDocuments, fromDocuments.getDocumentsResult);
export const getDocumentsLoading: any = createSelector(getDocuments, fromDocuments.getDocumentsLoading);
export const getDocumentsError: any = createSelector(getDocuments, fromDocuments.getDocumentsError);
export const getDocumentsUpdating: any = createSelector(getDocuments, fromDocuments.getDocumentsUpdating);
export const getDocumentsUpdateResult: any = createSelector(getDocuments, fromDocuments.getDocumentsUpdateResult);
export const getDocumentsUpdateError: any = createSelector(getDocuments, fromDocuments.getDocumentsUpdateError);

/**
 * Document Types
 */

export const getDocumentTypes = (state: State) => state.documentTypes;
export const getDocumentTypesResult: any = createSelector(getDocumentTypes, fromDocumentTypes.getDocumentTypesResult);
export const getDocumentTypesLoading: any = createSelector(getDocumentTypes, fromDocumentTypes.getDocumentTypesLoading);
export const getDocumentTypesError: any = createSelector(getDocumentTypes, fromDocumentTypes.getDocumentTypesError);

/**
 * Folder
 */

export const getFolder = (state: State) => state.folder;
export const getFolderResult: any = createSelector(getFolder, fromFolder.getFolderResult);
export const getFolderFirstResult: any = createSelector(getFolderResult, (result) => result && result['0'] );
export const getFolderLoading: any = createSelector(getFolder, fromFolder.getFolderLoading);
export const getFolderError: any = createSelector(getFolder, fromFolder.getFolderError);
export const getFolderListDocuments: any = createSelector(getFolderResult, (result) => {
  return result && result['0'].listOfDocumentId;
});
export const getFolderUpdating: any = createSelector(getFolder, fromFolder.getFolderUpdating);
export const getFolderUpdateResult: any = createSelector(getFolder, fromFolder.getFolderUpdateResult);
export const getFolderUpdateError: any = createSelector(getFolder, fromFolder.getFolderUpdateError);
export const getFolderCreateCreating: any = createSelector(getFolder, fromFolder.getFolderCreateCreating);
export const getFolderCreateError: any = createSelector(getFolder, fromFolder.getFolderCreateError);
export const getFolderCreateResult: any = createSelector(getFolder, fromFolder.getFolderCreateResult);

export const getFolderDeletingDeleting: any = createSelector(getFolder, fromFolder.getFolderDeletingDeleting);
export const getFolderDeletingError: any = createSelector(getFolder, fromFolder.getFolderDeletingError);
export const getFolderDeletingResult: any = createSelector(getFolder, fromFolder.getFolderDeletingResult);


/**
 * Basket
 */

export const getBasket = (state: State) => state.basket;
export const getBasketsResult: any = createSelector(getBasket, fromBasket.getBasketsResult);
export const getBasketsLoading: any = createSelector(getBasket, fromBasket.getBasketsLoading);
export const getBasketsError: any = createSelector(getBasket, fromBasket.getBasketsError);



/**
 * Task
 */

export const getTask = (state: State) => state.task;
export const getTasksResult: any = createSelector(getTask, fromTask.getTasksResult);
export const getTasksLoading: any = createSelector(getTask, fromTask.getTasksLoading);
export const getTasksError: any = createSelector(getTask, fromTask.getTasksError);
export const getTasksTransferLoading: any = createSelector(getTask, fromTask.getTasksTransferLoading);
export const getTasksTransferResult: any = createSelector(getTask, fromTask.getTasksTransferResult);
export const getTasksTransferError: any = createSelector(getTask, fromTask.getTasksTransferError);
export const getTasksStatusLoading: any = createSelector(getTask, fromTask.getTasksStatusLoading);
export const getTasksStatusResult: any = createSelector(getTask, fromTask.getTasksStatusResult);
export const getTasksStatusError: any = createSelector(getTask, fromTask.getTasksStatusError);

/**
 * Folder Types
 */
export const getFolderTypes = (state: State) => state.folderTypes;
export const getFolderTypesResult: any = createSelector(getFolderTypes, fromFolderTypes.getFolderTypesResult);
export const getFolderTypesLoading: any = createSelector(getFolderTypes, fromFolderTypes.getFolderTypesLoading);
export const getFolderTypesError: any = createSelector(getFolderTypes, fromFolderTypes.getFolderTypesError);

/**
 * Tags
 */

export const getTags = (state: State) => state.tags;
export const getTagsResult: any = createSelector(getTags, fromTags.getTagsResult);
export const getTagsLoading: any = createSelector(getTags, fromTags.getTagsLoading);
export const getTagsError: any = createSelector(getTags, fromTags.getTagsError);


/**
 * Extra Fields
 */

export const getExtraFields = (state: State) => state.extraFields;
export const getExtraFieldsMetadataFields: any = createSelector(getExtraFields, fromExtraFields.getExtraFieldsMetadataFields);
// tslint:disable-next-line:max-line-length
export const getExtraFieldsEnvelopeMetadataFields: any = createSelector(getExtraFields, fromExtraFields.getExtraFieldsEnvelopeMetadataFields);
export const getExtraFieldsFolderMetadataFields: any = createSelector(getExtraFields, fromExtraFields.getExtraFieldsFolderMetadataFields);
export const getExtraFieldsLoaded: any = createSelector(getExtraFields, fromExtraFields.getExtraFieldsLoaded);


/**
 * Upload Documents
 */

export const getUploadDocuments = (state: State) => state.uploadDocuments;
export const getUploadDocumentsList: any = createSelector(getUploadDocuments, fromUploadDocuments.getUploadDocumentsList);
export const getUploadDocumentsLoading: any = createSelector(getUploadDocuments, fromUploadDocuments.getUploadDocumentsLoading);
export const getUploadDocumentsError: any = createSelector(getUploadDocuments, fromUploadDocuments.getUploadDocumentsError);
export const getUploadDocumentsResult: any = createSelector(getUploadDocuments, fromUploadDocuments.getUploadDocumentsResult);



/**
 * AUX DOCUMENTACTION / HELPER / EXPLANATION ON SELECTORS
 */
/**
 * A selector function is a map function factory. We pass it parameters and it
 * returns a function that maps from the larger state tree into a smaller
 * piece of state. This selector simply selects the `books` state.
 *
 * Selectors are used with the `select` operator.
 *
 * ```ts
 * class MyComponent {
 * 	constructor(state$: Observable<State>) {
 * 	  this.languageState$ = state$.select(getLanguageState);
 * 	}
 * }
 * ```
 * export const getLanguageState = (state: State) => state.language;
 */

/**
 * Every reducer module exports selector functions, however child reducers
 * have no knowledge of the overall state tree. To make them useable, we
 * need to make new selectors that wrap them.
 *
 * The createSelector function from the reselect library creates
 * very efficient selectors that are memoized and only recompute when arguments change.
 * The created selectors can also be composed together to select different
 * pieces of state.
 *
 * export const getCurrentLanguage:any = createSelector(getLanguageState, fromLanguage.getCurrentLanguage);
 *
 */
