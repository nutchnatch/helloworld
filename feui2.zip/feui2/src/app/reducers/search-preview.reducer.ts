import * as SearchPreviewState from 'app/states/search-preview.state';
import * as searchPreviewActions from '../actions/search-preview.actions';
import * as sharedActions from '../actions/shared.actions';
import { Folder } from 'app/models/folder';

export class State extends SearchPreviewState.State { }

const initialState: SearchPreviewState.State = SearchPreviewState.initialState;


export function reducer(state = initialState, action: searchPreviewActions.Actions): SearchPreviewState.State {
  switch (action.type) {
    case searchPreviewActions.ActionTypes.SEARCHING:
      state = Object.assign({}, state, { loading: true });
      return state;
    case searchPreviewActions.ActionTypes.PUT_SEARCH_PREVIEW_RESULTS:
      // console.log(action.payload['id']);
      state = Object.assign({}, state, { results: action.payload, loading: false, hasResults: true, resultId: action.payload.id });
      return state;
    case searchPreviewActions.ActionTypes.PUT_SEARCH_PREVIEW_TYPE:
      // console.log(action.payload['id']);
      state = Object.assign({}, state, { type: action.payload });
      return state;
    case searchPreviewActions.ActionTypes.INIT_SEARCH_PREVIEW:
      state = Object.assign({}, state, initialState);
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState);
      return state;
    default:
      return state;

  }
}

export const getSearchPreview = (state: SearchPreviewState.State) => state;
export const getSearchPreviewHasResult = (state: SearchPreviewState.State) => state.hasResults;
export const getSearchPreviewResultId = (state: SearchPreviewState.State) => state.resultId;
export const getSearchPreviewLoading = (state: SearchPreviewState.State) => state.loading;
export const getSearchPreviewResults = (state: SearchPreviewState.State) => state.results;
export const getSearchPreviewType = (state: SearchPreviewState.State) => state.type;
