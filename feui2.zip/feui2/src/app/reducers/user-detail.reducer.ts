import { HttpError } from './../models/http-error';
import { Error } from './../models/error';
import { createSelector } from 'reselect';
import * as userDetailActions from '../actions/user-detail.actions';
import * as sharedActions from '../actions/shared.actions';

import * as userDetailsState from 'app/states/user-detail.state';

import { RestResponse } from 'app/models/rest-response';


export class State extends userDetailsState.State { }

export const initialState: userDetailsState.State = userDetailsState.initialState;


/**
 * User Reducer
 *
 * @export
 * @param {any} [state=initialState]
 * @param {userDetailActions.Actions} action
 * @returns {State}
 */
export function reducer(state = initialState, action: userDetailActions.Actions): userDetailsState.State {

  switch (action.type) {
    case userDetailActions.ActionTypes.PUT_USER_DETAIL:
      state = Object.assign({}, state, {
        loading: false,
        loaded: true,
        result: action.payload['result'],
        // result: UserDetailsFormatizer(action.payload),
        error: new Error
      });
      return state;
    case userDetailActions.ActionTypes.LOADING_USER_DETAIL:
      state = Object.assign({}, state, { loading: true });
      return state;
    case userDetailActions.ActionTypes.DELETE_USER_DETAIL:
      state = Object.assign({}, state, initialState );
      return state;
    case userDetailActions.ActionTypes.PUT_HTTP_ERROR:
      state = Object.assign({}, state, { loading: false, httpError: action.payload });
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState );
      return state;
    default:
      return state;
  }
}

export const getUserDetail = (state: userDetailsState.State) => state.result;
export const getUserDetailisLoading = (state: userDetailsState.State) => state.loading;
export const getUserDetailLoaded = (state: State) => state.loaded;
export const getUserDetailUserName = (state: userDetailsState.State) => state.result && state.result[0].username;
export const getUserDetailFirstName = (state: userDetailsState.State) => state.result && state.result[0].firstName;
export const getUserDetailLastName = (state?: userDetailsState.State) => state.result && state.result[0].lastName;
export const getUserDetailFullUserName: any = createSelector(getUserDetailFirstName, getUserDetailLastName, (firstName, lastName) => {
  return `${firstName} ${lastName}`;
});

export const getUserDetailAuthorities = (state: userDetailsState.State) => state.result[0].authorities;

export const getUserDetailHttpError = (state: userDetailsState.State) => state.httpError;
export const getUserDetailHttpErrorMessage = (state: userDetailsState.State) => state.httpError;
// tslint:disable-next-line:max-line-length
export const getUserDetailHttpErrorDetails: any = createSelector(getUserDetailHttpError, getUserDetailHttpErrorMessage, (httpError, message) => {
  return httpError ? `code: ${httpError.status} - ${httpError.statusText}` : null;
});


/**LEGACY */
export const getHttpError = (state: userDetailsState.State) => state.error;
export const getErrorMessage = (state: userDetailsState.State) => state.error.message;
export const getErrorCode = (state: userDetailsState.State) => state.error.code;
export const getErrorUserDetails: any = createSelector(getErrorMessage, getErrorMessage, (code, message) => {
  return code ? `code: ${code} - ${message}` : null;
});
