import * as DocumentsFilter from 'app/states/documents-filter.state';
import * as documentsFilterActions from '../actions/documents-filter.actions';
import * as sharedActions from '../actions/shared.actions';

import { remove, reject } from 'lodash';


export class State extends DocumentsFilter.State { }

const initialState: DocumentsFilter.State = DocumentsFilter.initialState;

export function reducer(state = initialState, action: documentsFilterActions.Actions ): DocumentsFilter.State {
  switch (action.type) {
    case documentsFilterActions.ActionTypes.PUT_DOCUMENT_LIST:
      state = Object.assign({}, state, { documentsList: action.payload });
      return state;
    case documentsFilterActions.ActionTypes.PUT_DOCUMENT_LIST_BY_ID:
      const newState = state.documentsList.map( (doc) => {
        if ( doc['id'] === action.payload) { return Object.assign({}, doc , { selected: !doc['selected'] }); }
        return doc;
      });
      state = Object.assign({}, state, { documentsList: newState });
      return state;
    case documentsFilterActions.ActionTypes.PUT_SELECTED_DOCUMENT_LIST:
      const oldState = state.documentsList;
      state = Object.assign({}, state, { documentsSelectedList: reject(oldState, doc => !doc['selected']) });
      return state;
    case documentsFilterActions.ActionTypes.PUT_SELECTED:
      state = Object.assign({}, state, { selected: action.payload });
      return state;
    case documentsFilterActions.ActionTypes.PUT_MULTIPLE:
      state = Object.assign({}, state, { multiple : action.payload } );
      return state;
    case documentsFilterActions.ActionTypes.INIT:
      state = Object.assign({}, state, initialState);
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState);
      return state;
    default:
      return state;
  }
}

export const getDocumentsFilter = (state: DocumentsFilter.State) => state;
export const getDocumentsFilterMultiple = (state: DocumentsFilter.State) => state.multiple;
export const getDocumentsFilterSelected = (state: DocumentsFilter.State) => state.selected;
export const getDocumentsFilterList = (state: DocumentsFilter.State) => state.documentsList;
export const getDocumentsFilterListSelected = (state: DocumentsFilter.State) => state.documentsSelectedList;
// tslint:disable-next-line:max-line-length
export const getDocumentsFilterListSelectedCount = (state: DocumentsFilter.State) => { return state.documentsSelectedList ? state.documentsSelectedList.length : 0; };
