import * as FolderTypes from 'app/states/folder-types.state';
import * as folderTypesActions from '../actions/folder-types.actions';
import * as sharedActions from '../actions/shared.actions';

import { find } from 'lodash';

export class State extends FolderTypes.State { }

const initialState: FolderTypes.State = FolderTypes.initialState;

export function reducer(state = initialState, action: folderTypesActions.Actions): FolderTypes.State {
  switch (action.type) {
    case folderTypesActions.ActionTypes.LOADING_FOLDER_TYPES:
      state = Object.assign({}, state, { result: null, loading: action.payload, status: null, error: null });
      return state;
    case folderTypesActions.ActionTypes.PUT_FOLDER_TYPES:
      state = Object.assign({}, state, { result: action.payload, loading: false, status: true, error: null });
      return state;
    case folderTypesActions.ActionTypes.PUT_FOLDER_TYPES_BY_ID:
      state = Object.assign({}, state, { result: state.result.concat(action.payload), loading: false, status: true, error: null });
      return state;
    case folderTypesActions.ActionTypes.PUT_FOLDER_TYPES_ERROR:
      state = Object.assign({}, state, { result: null, loading: false, status: false, error: action.payload });
      return state;
    case folderTypesActions.ActionTypes.INIT_FOLDER_TYPES:
      state = Object.assign({}, state, initialState);
      return state;
    case sharedActions.ActionTypes.INIT_STORE:
      state = Object.assign({}, state, initialState);
      return state;
    default:
      return state;
  }
}

export const getFolderTypes = (state: FolderTypes.State) => state;
export const getFolderTypesResult = (state: FolderTypes.State) => state.result;
export const getFolderTypesLoading = (state: FolderTypes.State) => state.loading;
export const getFolderTypesError = (state: FolderTypes.State) => state.error;
