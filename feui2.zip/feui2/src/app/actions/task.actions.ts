// import { TaskCreationResult } from 'app/models/basket-creation-result';
import { Task } from './../models/task';
import { Error } from './../models/error';
import { Action } from '@ngrx/store';
import { type } from '../util';

export const ActionTypes = {
  LOADING_TASK: type('[Task] loading'),
  PUT_TASK_RESULTS: type('[Task] put task'),
  PUT_TASK_ERROR: type('[Task] put task error'),
  // PUT_UPDATE_TASK: type('[Task] put update task results'),
  LOADING_TASK_TRANSFER: type('[Task] loading task transfer results'),
  PUT_TASK_ERROR_TRANSFER: type('[Task] put task transfer error'),
  PUT_TASK_RESULTS_TRANSFER: type('[Task] put task transfer'),

  LOADING_TASK_STATUS: type('[Task] loading task status results'),
  PUT_TASK_ERROR_STATUS: type('[Task] put task status error'),
  PUT_TASK_RESULTS_STATUS: type('[Task] put task status'),

  INIT_TRANSFER: type('[Task] init state transfer'),
  INIT_STATUS: type('[Task] init state status'),
  INIT:  type('[Task] init state'),
};

export class LoadingTask implements Action {
  type = ActionTypes.LOADING_TASK;
  /**
   * Creates an instance of LoadingEnvelope.
   * @param {Boolean} payload
   *
   * @memberOf LoadingEnvelope
   */
  constructor(public payload?: Boolean) { }
}

export class PutTaskResults implements Action {
  type = ActionTypes.PUT_TASK_RESULTS;
  /**
   * Creates an instance of PutTask.
   * @param {Task} payload
   * @memberof PutTask
   */
  constructor(public payload: Task ) { }
}

export class PutTaskError implements Action {
  type = ActionTypes.PUT_TASK_ERROR;
 /**
  * Creates an instance of PutTaskError.
  * @param {Error} payload
  * @memberof PutTaskError
  */
  constructor(public payload: Error ) { }
}

export class LoadingTaskTransfer implements Action {
  type = ActionTypes.LOADING_TASK_TRANSFER;
  /**
   * Creates an instance of LoadingTaskTransfer.
   * @param {Boolean} payload
   *
   * @memberOf LoadingTaskTransfer
   */
  constructor(public payload?: Boolean) { }
}

export class PutTransferTask implements Action {
  type = ActionTypes.PUT_TASK_RESULTS_TRANSFER;
  /**
   * Creates an instance of TransferTask.
   * @param {string} payload
   *
   * @memberOf TransferTask
   */
  constructor(public payload: string) { }
}

export class PutUpdateTaskTransferError implements Action {
  type = ActionTypes.PUT_TASK_ERROR_TRANSFER;
 /**
  * Creates an instance of PutUpdateTaskTransferError.
  * @param {Error} payload
  * @memberof PutUpdateTaskTransferError
  */
  constructor(public payload: Error ) { }
}

export class LoadingTaskStatus implements Action {
  type = ActionTypes.LOADING_TASK_STATUS;
  /**
   * Creates an instance of LoadingTaskStatus.
   * @param {Boolean} payload
   *
   * @memberOf LoadingTaskStatus
   */
  constructor(public payload?: Boolean) { }
}

export class PutStatusTask implements Action {
  type = ActionTypes.PUT_TASK_RESULTS_STATUS;
  /**
   * Creates an instance of StatusTask.
   * @param {string} payload
   *
   * @memberOf StatusTask
   */
  constructor(public payload: string) { }
}

export class PutUpdateTaskStatusError implements Action {
  type = ActionTypes.PUT_TASK_ERROR_STATUS;
 /**
  * Creates an instance of PutUpdateTaskStatusError.
  * @param {Error} payload
  * @memberof PutUpdateTaskStatusError
  */
  constructor(public payload: Error ) { }
}

export class InitPutTask implements Action {
  type = ActionTypes.INIT;
  /**
   * Creates an instance of InitPutTask.
   * @param {any} [payload]
   * @memberof InitPutTask
   */
  constructor(public payload? ) { }
}

export class InitTransferTask implements Action {
  type = ActionTypes.INIT_TRANSFER;
  /**
   * Creates an instance of InitTransferTask.
   * @param {any} [payload]
   * @memberof InitTransferTask
   */
  constructor(public payload? ) { }
}

export class InitStatusTask implements Action {
  type = ActionTypes.INIT_TRANSFER;
  /**
   * Creates an instance of InitStatusTask.
   * @param {any} [payload]
   * @memberof InitStatusTask
   */
  constructor(public payload? ) { }
}


export type Actions
= PutTaskResults
| LoadingTask
| PutTaskError
| LoadingTaskTransfer
| PutTransferTask
| PutUpdateTaskTransferError
| LoadingTaskStatus
| PutStatusTask
| PutUpdateTaskStatusError
| InitTransferTask
| InitStatusTask
| InitPutTask;

