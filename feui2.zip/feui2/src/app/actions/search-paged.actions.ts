import { Envelope } from './../models/envelope';
import { Folder } from './../models/folder';
import { QueryParams } from 'app/models/paged';
import { PagedQuery } from 'app/models/paged';
import { Error } from 'app/models/error';
import { Action } from '@ngrx/store';
import { type } from '../util';

import { Document } from './../models/document';
import { Basket } from 'app/models/basket';


export const ActionTypes = {
  SEARCHING: type('[SearchPaged] searching'),
  PUT_SEARCHING_RESULTS: type('[SearchPaged] put search results'),
  PUT_SEARCHING_RESULTS_BY_ID: type('[SearchPaged] put search result by id'),
  PUT_SEARCHING_QUERY: type('[SearchPaged] put search query'),
  PUT_SEARCHING_TYPE: type('[SearchPaged] put search type'),
  PUT_SEARCHING_ERROR: type('[SearchPaged] put search error'),
  STOP_SEARCHING: type('[SearchPaged] Stop Search'),
  INIT_SEARCH: type('[SearchPaged] Init state')
};


export class SearchingSearchPaged implements Action {
  type = ActionTypes.SEARCHING;
  /**
   * Creates an instance of SearchingSearchPaged.
   * @param {Boolean} payload
   *
   * @memberOf SearchingSearchPaged
   */
  constructor(public payload?: Boolean) { }
}



export class PutSearchResultsSearchPaged implements Action {
  type = ActionTypes.PUT_SEARCHING_RESULTS;
  /**
   * Creates an instance of PutSearchResultsSearchPaged.
   * @param { PagedQuery< Array<Document | Folder | Envelope>> )} payload
   *
   * @memberOf PutSearchResultsSearchPaged
   */
  constructor(public payload: PagedQuery< Array<Document | Folder | Envelope | Basket>> ) { }
}

export class PutSearchResultsSearchByID implements Action {
  type = ActionTypes.PUT_SEARCHING_RESULTS_BY_ID;
  /**
   * Creates an instance of PutSearchResultsSearchByID.
   * @param { Document } payload
   *
   * @memberOf PutSearchResultsSearchByID
   */
  constructor(public payload: Document ) { }
}

export class PutSearchResultsQuery implements Action {
  type = ActionTypes.PUT_SEARCHING_QUERY;
  /**
   * Creates an instance of PutSearchResultsQuery.
   * @param { QueryParams } payload
   *
   * @memberOf PutSearchResultsSearchByID
   */
  constructor(public payload: QueryParams | any) { }
}

export class PutSearchResultsType implements Action {
  type = ActionTypes.PUT_SEARCHING_TYPE;
  /**
   * Creates an instance of PutSearchResultsType.
   * @param {String} payload
   * @memberof PutSearchResultsType
   */
  constructor(public payload: String ) { }
}

export class PutSearchResultsError implements Action {
  type = ActionTypes.PUT_SEARCHING_ERROR;
  /**
   * Creates an instance of PutSearchResultsError.
   * @param { Error } payload
   *
   * @memberOf PutSearchResultsSearchByID
   */
  constructor(public payload: Error ) { }
}

export class InitSearchResults implements Action {
  type = ActionTypes.INIT_SEARCH;
  /**
   * Creates an instance of InitSearchResults
   * @param payload
   */
  constructor(public payload? ) { }
}

export type Actions
  = SearchingSearchPaged
  | PutSearchResultsSearchPaged
  | PutSearchResultsQuery
  | PutSearchResultsType
  | PutSearchResultsError
  | PutSearchResultsSearchByID
  | InitSearchResults;
