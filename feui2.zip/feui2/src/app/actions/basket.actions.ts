// import { BasketCreationResult } from 'app/models/basket-creation-result';
import { Basket } from './../models/basket';
import { Error } from './../models/error';
import { Action } from '@ngrx/store';
import { type } from '../util';

export const ActionTypes = {
  LOADING_BASKET: type('[Basket] loading'),
  PUT_BASKET_RESULTS: type('[Basket] put basket'),
  PUT_BASKET_ERROR: type('[Basket] put basket error'),
  PUT_UPDATE_BASKET: type('[Basket] put upadate basket results'),
  INIT:  type('[Basket] init state'),
};

export class LoadingBasket implements Action {
  type = ActionTypes.LOADING_BASKET;
  /**
   * Creates an instance of LoadingEnvelope.
   * @param {Boolean} payload
   *
   * @memberOf LoadingEnvelope
   */
  constructor(public payload?: Boolean) { }
}

export class PutBasketResults implements Action {
  type = ActionTypes.PUT_BASKET_RESULTS;
  /**
   * Creates an instance of PutBasket.
   * @param {Basket} payload
   * @memberof PutBasket
   */
  constructor(public payload: Basket ) { }
}

export class PutBasketError implements Action {
  type = ActionTypes.PUT_BASKET_ERROR;
 /**
  * Creates an instance of PutBasketError.
  * @param {Error} payload
  * @memberof PutBasketError
  */
  constructor(public payload: Error ) { }
}

export class InitPutBasket implements Action {
  type = ActionTypes.INIT;
  /**
   * Creates an instance of InitPutBasket.
   * @param {any} [payload]
   * @memberof InitPutBasket
   */
  constructor(public payload? ) { }
}

// export class UpdatingBasket implements Action {
//   type = ActionTypes.UPDATING_BASKET;
//   /**
//    * Creates an instance of LoadingEnvelope.
//    * @param {Boolean} payload
//    *
//    * @memberOf LoadingEnvelope
//    */
//   constructor(public payload?: Boolean) { }
// }

// export class PutUpdateBasket implements Action {
//   type = ActionTypes.PUT_UPDATE_BASKET;
//   /**
//    * Creates an instance of PutUpdateBasket.
//    * @param {Basket} payload
//    * @memberof PutUpdateBasket
//    */
//   constructor(public payload: Basket ) { }
// }

// export class PutUpdateBasketError implements Action {
//   type = ActionTypes.PUT_UPDATE_BASKET_ERROR;
//  /**
//   * Creates an instance of PutUpdateBasketError.
//   * @param {Error} payload
//   * @memberof PutUpdateBasketError
//   */
//   constructor(public payload: Error ) { }
// }

// export class InitUpdateBasket implements Action {
//   type = ActionTypes.PUT_UPDATE_BASKET_INIT;

//   /**
//    * Creates an instance of InitUpdateBasket.
//    * @param {any} [payload]
//    * @memberof InitUpdateBasket
//    */
//   constructor(public payload? ) { }
// }


export type Actions
= PutBasketResults
| LoadingBasket
| PutBasketError
// | PutUpdateBasket
// | UpdatingBasket
// | PutUpdateBasketError
// | InitUpdateBasket
| InitPutBasket;

