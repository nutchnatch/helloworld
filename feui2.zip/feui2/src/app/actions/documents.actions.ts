import { DocumentCreationResult } from 'app/models/document-creation-result';
import { Document } from './../models/document';
import { Error } from './../models/error';
import { Action } from '@ngrx/store';
import { type } from '../util';


export const ActionTypes = {
  LOADING_DOCUMENT: type('[Document] loading'),
  PUT_DOCUMENT: type('[Document] put document'),
  PUT_DOCUMENT_ERROR: type('[Document] put document error'),
  PUT_UPDATE_DOCUMENT: type('[Document] put upadate document results'),
  UPDATING_DOCUMENT: type('[Document] put upadateing document'),
  PUT_UPDATE_DOCUMENT_ERROR: type('[Document] put update document error'),
  PUT_UPDATE_DOCUMENT_INIT: type('[Document] put update document init'),
  INIT:  type('[Document] init state'),
};

export class LoadingDocument implements Action {
  type = ActionTypes.LOADING_DOCUMENT;
  /**
   * Creates an instance of LoadingEnvelope.
   * @param {Boolean} payload
   *
   * @memberOf LoadingEnvelope
   */
  constructor(public payload?: Boolean) { }
}

export class UpdatingDocument implements Action {
  type = ActionTypes.UPDATING_DOCUMENT;
  /**
   * Creates an instance of LoadingEnvelope.
   * @param {Boolean} payload
   *
   * @memberOf LoadingEnvelope
   */
  constructor(public payload?: Boolean) { }
}

export class PutDocument implements Action {
  type = ActionTypes.PUT_DOCUMENT;
  /**
   * Creates an instance of PutDocument.
   * @param {Document} payload
   * @memberof PutDocument
   */
  constructor(public payload: Document ) { }
}

export class PutUpdateDocument implements Action {
  type = ActionTypes.PUT_UPDATE_DOCUMENT;
  /**
   * Creates an instance of PutUpdateDocument.
   * @param {DocumentCreationResult} payload
   * @memberof PutUpdateDocument
   */
  constructor(public payload: DocumentCreationResult ) { }
}

export class PutDocumentError implements Action {
  type = ActionTypes.PUT_DOCUMENT_ERROR;
 /**
  * Creates an instance of PutDocumentError.
  * @param {Error} payload
  * @memberof PutDocumentError
  */
  constructor(public payload: Error ) { }
}


export class PutUpdateDocumentError implements Action {
  type = ActionTypes.PUT_UPDATE_DOCUMENT_ERROR;
 /**
  * Creates an instance of PutUpdateDocumentError.
  * @param {Error} payload
  * @memberof PutUpdateDocumentError
  */
  constructor(public payload: Error ) { }
}

export class InitUpdateDocument implements Action {
  type = ActionTypes.PUT_UPDATE_DOCUMENT_INIT;

  /**
   * Creates an instance of InitUpdateDocument.
   * @param {any} [payload]
   * @memberof InitUpdateDocument
   */
  constructor(public payload? ) { }
}

export class InitPutDocument implements Action {
  type = ActionTypes.INIT;
  /**
   * Creates an instance of InitPutDocument.
   * @param {any} [payload]
   * @memberof InitPutDocument
   */
  constructor(public payload? ) { }
}


export type Actions
= PutDocument
| PutUpdateDocument
| UpdatingDocument
| LoadingDocument
| PutDocumentError
| PutUpdateDocumentError
| InitUpdateDocument
| InitPutDocument;

