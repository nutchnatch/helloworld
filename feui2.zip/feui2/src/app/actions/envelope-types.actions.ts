import { EnvelopeTypes } from './../models/envelope-types';
import { Error } from './../models/error';
import { Action } from '@ngrx/store';
import { type } from '../util';


export const ActionTypes = {
  LOADING_ENVELOPE_TYPES: type('[Envelope Types] loading'),
  PUT_ENVELOPE_TYPES: type('[Envelope Types] put document'),
  PUT_ENVELOPE_TYPES_BY_ID: type('[Envelope Types] put document by ID'),
  PUT_ENVELOPE_TYPES_ERROR: type('[Envelope Types] put document error'),
  INIT_ENVELOPE_TYPES:  type('[Envelope Types] init state'),
};

export class LoadingEnvelopeTypes implements Action {
  type = ActionTypes.LOADING_ENVELOPE_TYPES;
  /**
   * Creates an instance of LoadingEnvelopeTypes.
   * @param {Boolean} [payload]
   * @memberof LoadingEnvelopeTypes
   */
  constructor(public payload?: Boolean) { }
}

export class PutEnvelopeTypes implements Action {
  type = ActionTypes.PUT_ENVELOPE_TYPES;
  /**
   * Creates an instance of PutEnvelopeTypes.
   * @param {Array<EnvelopeTypes> | Array<any>} payload
   * @memberof PutEnvelopeTypes
   */
  constructor(public payload: Array<EnvelopeTypes> | Array<any>) { }
}

export class PutEnvelopeTypesById implements Action {
  type = ActionTypes.PUT_ENVELOPE_TYPES_BY_ID;
  /**
   * Creates an instance of PutEnvelopeTypes.
   * @param {EnvelopeTypes} payload
   * @memberof PutEnvelopeTypes
   */
  constructor(public payload: EnvelopeTypes ) { }
}

export class PutEnvelopeTypesError implements Action {
  type = ActionTypes.PUT_ENVELOPE_TYPES_ERROR;
  /**
   * Creates an instance of PutEnvelopeTypesError.
   * @param {Error} payload
   * @memberof PutEnvelopeTypesError
   */
  constructor(public payload: Error) { }
}

export class InitPutEnvelopeTypes implements Action {
  type = ActionTypes.INIT_ENVELOPE_TYPES;
  /**
   * Creates an instance of InitPutEnvelopeTypes.
   * @param {any} [payload]
   * @memberof InitPutEnvelopeTypes
   */
  constructor(public payload? ) { }
}

export type Actions
= PutEnvelopeTypes
| PutEnvelopeTypesById
| LoadingEnvelopeTypes
| PutEnvelopeTypesError
| InitPutEnvelopeTypes;
