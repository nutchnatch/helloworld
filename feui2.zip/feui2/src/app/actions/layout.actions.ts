import { Sidebar, MetadataBar } from 'app/models/sidesbars-config';
import { Action } from '@ngrx/store';
import { type } from '../util';

export const ActionTypes = {
  OPEN_SIDENAV:   type('[Layout] Open Sidenav'),
  CLOSE_SIDENAV:  type('[Layout] Close Sidenav'),
  PIN_SIDEBAR: type('[Layout] pined sidebar'),
  UNPIN_SIDEBAR: type('[Layout] unpined sidebar'),
  CURRENT_URL: type('[Layout] current url'),
  PUT_SIDEBAR_PARAMS: type('[Layout] Put Sidebar Params'),
  PUT_METADATABAR_PARAMS: type('[Layout] Put MetadataBar Params'),
  PUT_TABLE_COMPACT: type('[Layout] Put Table Compact'),
  PUT_FROM_SEARCH: type('[Layout] Put from search'),
  PUT_ADVANCE_SEARCH: type('[Layout] Put advance search')
};


export class OpenSidenavAction implements Action {
  type = ActionTypes.OPEN_SIDENAV;
  constructor(public payload? ) {}
}

export class CloseSidenavAction implements Action {
  type = ActionTypes.CLOSE_SIDENAV;
  constructor( public payload?) {}
}

export class PinSidenavAction implements Action {
  type = ActionTypes.PIN_SIDEBAR;
  constructor( public payload?) {}
}

export class UnPinSidenavAction implements Action {
  type = ActionTypes.UNPIN_SIDEBAR;
  constructor( public payload?) {}
}

export class PutSidebarParams implements Action {
  type = ActionTypes.PUT_SIDEBAR_PARAMS;
  constructor( public payload: Sidebar) {}
}

export class PutMetadataBarParams implements Action {
  type = ActionTypes.PUT_METADATABAR_PARAMS;
  constructor( public payload: MetadataBar) {}
}

export class CurrentUrlAction implements Action {
  type = ActionTypes.CURRENT_URL;

  constructor( public payload: string) {}
}

export class PutCompactTableAction implements Action {
  type = ActionTypes.PUT_TABLE_COMPACT;

  constructor( public payload: boolean) {}
}

export class PutFromSearchAction implements Action {
  type = ActionTypes.PUT_FROM_SEARCH;
  constructor(public payload: string ) {}
}

export class PutAdvanceSearch implements Action {
  type = ActionTypes.PUT_ADVANCE_SEARCH;
  constructor(public payload: Boolean ) {}
}


export type Actions
  = OpenSidenavAction
  | CloseSidenavAction
  | PinSidenavAction
  | UnPinSidenavAction
  | CurrentUrlAction
  | PutCompactTableAction
  | PutAdvanceSearch
  | PutFromSearchAction;
