import { Action } from '@ngrx/store';
import { type } from '../util';
import { TagClone } from 'app/models/tag';

export const ActionTypes = {
  PUT_PAGE_SIZE: type('[AppConfig] Put pageSize'),
  PUT_SCOPE: type('[AppConfig] Put scope'),
  PUT_COPIED_TAGS: type('[AppConfig] Put Copied Tags'),
};

/**
 * Action Update PageSize to store
 *
 * @export
 * @class PutPageSizeAction
 * @implements {Action}
 */
export class PutPageSizeAction implements Action {
  type = ActionTypes.PUT_PAGE_SIZE;
  /**
   * @param {number} [payload]
   * @memberof PutPageSizeAction
   */
  constructor(public payload?: number ) {}
}
/**
 * Action Update Scope to store
 *
 * @export
 * @class PutScopeAction
 * @implements {Action}
 */
export class PutScopeAction implements Action {
  type = ActionTypes.PUT_SCOPE;
  /**
   * Creates an instance of PutScopeAction.
   * @param {string} [payload]
   * @memberof PutScopeAction
   */
  constructor(public payload?: string ) {}
}
/**
 * Action Update Scope to store
 *
 * @export
 * @class PutScopeAction
 * @implements {Action}
 */
export class PutCopiedTagsAction implements Action {
  type = ActionTypes.PUT_COPIED_TAGS;
  /**
   * Creates an instance of PutCopiedTagsAction.
   * @param {Array<TagClone> } [payload]
   * @memberof PutCopiedTagsAction
   */
  constructor(public payload: Array<TagClone | any> ) {}
}


export type Actions
= PutPageSizeAction
| PutScopeAction
| PutCopiedTagsAction;
