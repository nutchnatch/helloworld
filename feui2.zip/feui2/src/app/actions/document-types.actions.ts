import { DocumentTypes } from './../models/document-types';
import { Error } from './../models/error';
import { Action } from '@ngrx/store';
import { type } from '../util';


export const ActionTypes = {
  LOADING_DOCUMENT_TYPES: type('[Document Types] loading'),
  PUT_DOCUMENT_TYPES: type('[Document Types] put document'),
  PUT_DOCUMENT_TYPES_ERROR: type('[Document Types] put document error'),
  INIT_DOCUMENT_TYPES:  type('[Document Types] init state'),
};

export class LoadingDocumentTypes implements Action {
  type = ActionTypes.LOADING_DOCUMENT_TYPES;
  /**
   * Creates an instance of LoadingDocumentTypes.
   * @param {Boolean} [payload]
   * @memberof LoadingDocumentTypes
   */
  constructor(public payload?: Boolean) { }
}

export class PutDocumentTypes implements Action {
  type = ActionTypes.PUT_DOCUMENT_TYPES;
  /**
   * Creates an instance of PutDocumentTypes.
   * @param {DocumentTypes} payload
   * @memberof PutDocumentTypes
   */
  constructor(public payload: Array<DocumentTypes> | Array<any>) { }
}

export class PutDocumentTypesError implements Action {
  type = ActionTypes.PUT_DOCUMENT_TYPES_ERROR;
  /**
   * Creates an instance of PutDocumentTypesError.
   * @param {Error} payload
   * @memberof PutDocumentTypesError
   */
  constructor(public payload: Error) { }
}

export class InitPutDocumentTypes implements Action {
  type = ActionTypes.INIT_DOCUMENT_TYPES;
  /**
   * Creates an instance of InitPutDocumentTypes.
   * @param {any} [payload]
   * @memberof InitPutDocumentTypes
   */
  constructor(public payload? ) { }
}

export type Actions
= PutDocumentTypes
| LoadingDocumentTypes
| PutDocumentTypesError
| InitPutDocumentTypes;
