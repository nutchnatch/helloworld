import { Action } from '@ngrx/store';
import { type } from '../util';

export const ActionTypes = {
  PUT_INFO_VERSION:   type('[Info] put info version'),
  LOADING_INFO: type('[Info] loading info'),
  INIT_INFO: type('[Info] init info')
};


export class PutInfoVersionAction implements Action {
  type = ActionTypes.PUT_INFO_VERSION;

  /**
   * Creates an instance of PutInfoVersionAction.
   * @param {string} payload
   *
   * @memberOf PutInfoVersionAction
   */
  constructor(public payload: string ) {}
}


export class InitInfoAction implements Action {
  type = ActionTypes.PUT_INFO_VERSION;
  constructor(public payload? ) {}
}

export class LoadinInfoAction implements Action {
  type = ActionTypes.LOADING_INFO;
  constructor(public payload? ) {}
}


export type Actions
  = PutInfoVersionAction
  | InitInfoAction
  | LoadinInfoAction;
