import { FolderCreationResult } from './../models/folder-creation-result';
import { Folder } from './../models/folder';
import { RestResponse } from 'app/models/rest-response';
import { Error } from 'app/models/error';
import { Action } from '@ngrx/store';
import { type } from '../util';

import { Document } from './../models/document';
import { DocumentAttachedToFoldersResult } from 'app/models/document-attached-to-folder-result';


export const ActionTypes = {
  LOADING_FOLDER: type('[Folder] loading'),
  PUT_FOLDER_RESULT: type('[Folder] put folder result'),
  PUT_FOLDER_ERROR: type('[Folder] put folder error'),
  PUT_UPDATE_FOLDER: type('[Folder] put upadate Folder results'),
  UPDATING_FOLDER: type('[Folder] put upadateing Folder'),
  PUT_UPDATE_FOLDER_ERROR: type('[Folder] put update folder error'),
  PUT_UPDATE_FOLDER_INIT:  type('[Folder] put update init error'),
  POST_FOLDER_CREATING:  type('[Folder] create folder creating'),
  POST_FOLDER_ERROR:  type('[Folder] create folder error'),
  POST_FOLDER_RESULT:  type('[Folder] create folder Result'),
  POST_FOLDER_INIT:  type('[Folder] create folder init'),
  DELETE_FOLDER_DELETING:  type('[Folder] delete folder deleting'),
  DELETE_FOLDER_ERROR:  type('[Folder] delete folder error'),
  DELETE_FOLDER_RESULT:  type('[Folder] delete folder Result'),
  DELETE_FOLDER_INIT:  type('[Folder] delete folder init'),
  INIT_FOLDER: type('[Folder] folder init')
};


export class LoadingFolder implements Action {
  type = ActionTypes.LOADING_FOLDER;
  /**
   * Creates an instance of LoadingFolder.
   * @param {Boolean} payload
   *
   * @memberOf LoadingFolder
   */
  constructor(public payload?: Boolean) { }
}

export class UpdatingFolder implements Action {
  type = ActionTypes.UPDATING_FOLDER;
  /**
   * Creates an instance of UpdatingFolder.
   * @param {Boolean} payload
   *
   * @memberOf UpdatingFolder
   */
  constructor(public payload?: Boolean) { }
}

export class PutFolderResult implements Action {
  type = ActionTypes.PUT_FOLDER_RESULT;
  /**
   * Creates an instance of PutFolderResult.
   * @param {  Array<Folder> )} payload
   *
   * @memberOf PutFolderResult
   */
  constructor(public payload:  Array<Folder> ) { }
}

export class PutUpdateFolder implements Action {
  type = ActionTypes.PUT_UPDATE_FOLDER;
  /**
   * Creates an instance of PutUpdateFolder.
   * @param {FolderCreationResult} payload
   * @memberof PutUpdateFolder
   */
  constructor(public payload: FolderCreationResult ) { }
}

export class PutFolderError implements Action {
  type = ActionTypes.PUT_FOLDER_ERROR;
  /**
   * Creates an instance of PutFolderError.
   * @param { Error } payload
   *
   * @memberOf PutFolderError
   */
  constructor(public payload: Error ) { }
}

export class PutUpdateFolderError implements Action {
  type = ActionTypes.PUT_UPDATE_FOLDER_ERROR;
  /**
   * Creates an instance of PutUpdateFolderError.
   * @param { Error } payload
   *
   * @memberOf PutUpdateFolderError
   */
  constructor(public payload: Error ) { }
}

export class InitUpdateFolder implements Action {
  type = ActionTypes.PUT_UPDATE_FOLDER_INIT;

  /**
   * Creates an instance of InitUpdateFolder.
   * @param {any} [payload]
   * @memberof InitUpdateFolder
   */
  constructor(public payload? ) { }
}

export class InitFolder implements Action {
  type = ActionTypes.INIT_FOLDER;

  /**
   * Creates an instance of InitFolder.
   * @param {any} [payload]
   * @memberof InitFolder
   */
  constructor(public payload? ) { }
}


export class InitCreateFolder implements Action {
  type = ActionTypes.POST_FOLDER_INIT;
  /**
   * Creates an instance of InitCreateFolder.
   * @param {any} [payload]
   * @memberof InitCreateFolder
   */
  constructor(public payload? ) { }
}

export class PostCreateFolderCreating implements Action {
  type = ActionTypes.POST_FOLDER_CREATING;
  /**
   * Creates an instance of PostCreateFolderCreating.
   * @param {any} [payload]
   * @memberof PostCreateFolderCreating
   */
  constructor(public payload? ) { }
}

export class PostCreateFolderResult implements Action {
  type = ActionTypes.POST_FOLDER_RESULT;
  /**
   * Creates an instance of PostCreateFolderResult.
   * @param {FolderCreationResult} [payload]
   * @memberof PostCreateFolderResult
   */
  constructor(public payload: FolderCreationResult ) { }
}

export class PostCreateFolderError implements Action {
  type = ActionTypes.POST_FOLDER_ERROR;
  /**
   * Creates an instance of PostCreateFolderError.
   * @param {Error} [payload]
   * @memberof PostCreateFolderError
   */
  constructor(public payload: Error ) { }
}

export class InitDeleteFolder implements Action {
  type = ActionTypes.DELETE_FOLDER_INIT;
  /**
   * Deletes an instance of InitDeleteFolder.
   * @param {any} [payload]
   * @memberof InitDeleteFolder
   */
  constructor(public payload? ) { }
}

export class DeleteFolderDeleting implements Action {
  type = ActionTypes.DELETE_FOLDER_DELETING;
  /**
   * Deletes an instance of DeleteFolderDeleting.
   * @param {any} [payload]
   * @memberof DeleteFolderDeleting
   */
  constructor(public payload? ) { }
}

export class DeleteFolderResult implements Action {
  type = ActionTypes.DELETE_FOLDER_RESULT;
  /**
   * Deletes an instance of DeleteFolderResult.
   * @param {DocumentAttachedToFoldersResult} [payload]
   * @memberof DeleteFolderResult
   */
  constructor(public payload: DocumentAttachedToFoldersResult ) { }
}

export class DeleteFolderError implements Action {
  type = ActionTypes.DELETE_FOLDER_ERROR;
  /**
   * Deletes an instance of DeleteFolderError.
   * @param {Error} [payload]
   * @memberof DeleteFolderError
   */
  constructor(public payload: Error ) { }
}

export type Actions
  = LoadingFolder
  | PutFolderResult
  | PutFolderError
  | PutUpdateFolder
  | UpdatingFolder
  | PutUpdateFolderError
  | InitFolder
  | InitCreateFolder
  | PostCreateFolderCreating
  | PostCreateFolderResult
  | PostCreateFolderError
  | InitDeleteFolder
  | DeleteFolderDeleting
  | DeleteFolderError
  | DeleteFolderResult;
