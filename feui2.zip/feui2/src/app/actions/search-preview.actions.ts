import { Folder } from './../models/folder';
import { Envelope } from 'app/models/envelope';
import { PagedQuery } from 'app/models/paged';
import { Action } from '@ngrx/store';
import { type } from '../util';

import { Document } from './../models/document';


export const ActionTypes = {
  SEARCHING: type('[SearchPreview] searching'),
  PUT_SEARCH_PREVIEW_RESULTS: type('[SearchPreview] put search preview results'),
  PUT_SEARCH_PREVIEW_TYPE: type('[SearchPreview] put search preview type'),
  INIT_SEARCH_PREVIEW: type('[SearchPreview] Init state')
};


export class SearchingSearchPreview implements Action {
  type = ActionTypes.SEARCHING;
  /**
   * Creates an instance of SearchingSearchPreview.
   * @param {Boolean} payload
   *
   * @memberOf SearchingSearchPreview
   */
  constructor(public payload?: Boolean) { }
}

export class PutSearchResultsSearchPreview implements Action {
  type = ActionTypes.PUT_SEARCH_PREVIEW_RESULTS;
  /**
   * Creates an instance of PutSearchResultsSearchPreview.
   * @param { Document | Envelope | Folder  } payload
   *
   * @memberOf PutSearchResultsSearchPreview
   */
  constructor(public payload: Document | Envelope | Folder ) { }
}

export class PutSearchTypeSearchPreview implements Action {
  type = ActionTypes.PUT_SEARCH_PREVIEW_TYPE;
  /**
   * Creates an instance of PutSearchTypeSearchPreview.
   * @param { string  } payload
   *
   * @memberOf PutSearchTypeSearchPreview
   */
  constructor(public payload: string ) { }
}

export class InitSearchResultsSearchPreview implements Action {
  type = ActionTypes.INIT_SEARCH_PREVIEW;
  /**
   * Creates an instance of InitSearchResultsSearchPreview.
   * @param { Document } payload
   *
   * @memberOf InitSearchResultsSearchPreview
   */
  constructor(public payload? ) { }
}


export type Actions
  = SearchingSearchPreview
  | PutSearchResultsSearchPreview
  | InitSearchResultsSearchPreview
  | PutSearchTypeSearchPreview;
