import { AdvanceQuery } from './../states/advance-search.state';
import { ExtraFields } from './../states/extra-fields.state';
import { Action } from '@ngrx/store';
import { type } from '../util';

export const ActionTypes = {
  PUT_DOMAIN: type('[Advance Search] Put domain'),
  PUT_DOMAIN_SELECTED: type('[Advance Search] Put domain selected '),
  PUT_ADVANCE_SEARCH: type('[Advance Search] Put search query'),
  PUT_ADVANCE_SEARCH_BY_ID: type('[Advance Search] Put search query by id'),
  PUT_TAGS_LIST: type('[Advance Search] Put tags list'),
  PUT_TYPE_ID: type('[Advance Search] Put type id'),
  PUT_FORM_GROUP: type('[Advance Search] Put form group'),
  REMOVE_ADVANCE_SEARCH_BY_ID: type('[Advance Search] Remove search query by id'),
  REMOVE_ALL_ADVANCE_SEARCH: type('[Advance Search] Remove All search query by id'),
};

/**
 * Action Update Domians for advance search on the store
 *
 * @export
 * @class PutDomain
 * @implements {Action}
 */
export class PutDomain implements Action {
  type = ActionTypes.PUT_DOMAIN;
  /**
   * @param {string} [payload]
   * @memberof PutDomain
   */
  constructor(public payload: string ) {}
}

/**
 * Action Update Domians for advance search on the store
 *
 * @export
 * @class PutDomain
 * @implements {Action}
 */
export class PutDomainSelected implements Action {
  type = ActionTypes.PUT_DOMAIN_SELECTED;
  /**
   * @param {Array<any>} [payload]
   * @memberof PutDomain
   */
  constructor(public payload: Array<any> ) {}
}

/**
 * Action Update Tags List for advance search on the store
 *
 * @export
 * @class PutTagsList
 * @implements {Action}
 */
export class PutTagsList implements Action {
  type = ActionTypes.PUT_TAGS_LIST;
  /**
   * @param {any} [payload]
   * @memberof PutTagsList
   */
  constructor(public payload: any ) {}
}

/**
 * Action Update Domians for advance search on the store
 *
 * @export
 * @class PutAdvanceSearch
 * @implements {Action}
 */
export class PutAdvanceSearch implements Action {
  type = ActionTypes.PUT_ADVANCE_SEARCH;
  /**
   * @param {AdvanceQuery} [payload]
   * @memberof PutTypeId
   */
  constructor(public payload: AdvanceQuery ) {}
}

/**
 * Action Update Domians for advance search on the store by ID
 *
 * @export
 * @class PutAdvanceSearchById
 * @implements {Action}
 */
export class PutAdvanceSearchById implements Action {
  type = ActionTypes.PUT_ADVANCE_SEARCH_BY_ID;
  /**
   * @param {id , AdvanceQuery} [payload]
   * @memberof PutTypeId
   */
  constructor(public payload: { id , AdvanceQuery } ) {}
}

/**
 * Action Update Domians for advance search on the store
 *
 * @export
 * @class RemoveAdvanceSearchByID
 * @implements {Action}
 */
export class RemoveAdvanceSearchByID implements Action {
  type = ActionTypes.REMOVE_ADVANCE_SEARCH_BY_ID;
  /**
   * @param {number} [payload]
   * @memberof PutTypeId
   */
  constructor(public payload: number ) {}
}

/**
 * Action Update Domians for advance search on the store
 *
 * @export
 * @class RemoveAdvanceSearchByID
 * @implements {Action}
 */
export class RemoveAllAdvanceSearch implements Action {
  type = ActionTypes.REMOVE_ALL_ADVANCE_SEARCH;
  /**
   * @param {?} [payload]
   * @memberof PutTypeId
   */
  constructor(public payload? ) {}
}

/**
 * Action Update Domians for advance search on the store
 *
 * @export
 * @class PutTypeId
 * @implements {Action}
 */
export class PutTypeId implements Action {
  type = ActionTypes.PUT_TYPE_ID;
  /**
   * @param {string} [payload]
   * @memberof PutTypeId
   */
  constructor(public payload: string ) {}
}

/**
 * Action Update Form Group (last search)
 *
 * @export
 * @class PutFromGroup
 * @implements {Action}
 */
export class PutFromGroup implements Action {
  type = ActionTypes.PUT_FORM_GROUP;
  /**
   * @param {any} [payload]
   * @memberof PutTypeId
   */
  constructor(public payload: any ) {}
}

export type Actions
= PutDomain
| PutAdvanceSearch
| PutDomainSelected
| PutTagsList
| RemoveAdvanceSearchByID
| RemoveAllAdvanceSearch
| PutTypeId;
