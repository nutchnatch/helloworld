import { DocumentLite } from './../models/document-lite';
import { Action } from '@ngrx/store';
import { type } from '../util';


export const ActionTypes = {
  PUT_DOCUMENT_LIST: type('[Document Selected] put document list'),
  PUT_DOCUMENT_LIST_BY_ID: type('[Document Selected] put document list by id'),
  PUT_SELECTED_DOCUMENT_LIST: type('[Document Selected] put selected document list'),
  PUT_SELECTED: type('[Document Selected] put selected document'),
  PUT_MULTIPLE:  type('[Document Selected] put multiple files'),
  INIT:  type('[Document Selected] init state'),
};


export class PutDocumentSelecedList implements Action {
  type = ActionTypes.PUT_DOCUMENT_LIST;
  /**
   * Creates an instance of PutDocumentSelecedList.
   * @param {(Array<DocumentLite> | DocumentLite)} payload
   * @memberof PutDocumentSelecedList
   */
  constructor(public payload: Array<DocumentLite> | DocumentLite ) { }
}

export class PutDocumentSelecedListById implements Action {
  type = ActionTypes.PUT_DOCUMENT_LIST_BY_ID;
 /**
  * Creates an instance of PutDocumentSelecedListById.
  * @param {string} payload
  * @memberof PutDocumentSelecedListById
  */
  constructor(public payload: string ) { }
}

export class PutSelectedDocumentSelecedList implements Action {
  type = ActionTypes.PUT_SELECTED_DOCUMENT_LIST;
  /**
   * Creates an instance of PutSelectedDocumentSelecedList.
   * @param {(Array<DocumentLite> | DocumentLite)} payload
   * @memberof PutDocumentSelecedList
   */
  constructor(public payload: Array<DocumentLite> | DocumentLite ) { }
}

export class PutDocumentSeleced implements Action {
  type = ActionTypes.PUT_SELECTED;
  /**
   * Creates an instance of PutDocumentSeleced.
   * @param {string} payload
   * @memberof PutDocumentSeleced
   */
  constructor(public payload: string ) { }
}


export class PutDocumentSelecedMultiple implements Action {
  type = ActionTypes.PUT_MULTIPLE;
 /**
  * Creates an instance of PutDocumentSelecedMultiple.
  * @param {boolean} payload
  * @memberof PutDocumentSelecedMultiple
  */
  constructor(public payload: boolean ) { }
}

export class InitDocumentSelecedList implements Action {
  type = ActionTypes.INIT;
/**
 * Creates an instance of InitDocumentSelecedList.
 * @param {any} [payload]
 * @memberof InitDocumentSelecedList
 */
  constructor( public payload? ) { }
}

export type Actions
= PutDocumentSelecedList
| PutDocumentSelecedListById
| PutSelectedDocumentSelecedList
| PutDocumentSeleced
| PutDocumentSelecedMultiple
| InitDocumentSelecedList;
