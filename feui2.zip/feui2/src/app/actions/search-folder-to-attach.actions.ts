import { DocumentAttachedToFoldersResult } from './../models/document-attached-to-folder-result';
import { Folder } from './../models/folder';
import { Action } from '@ngrx/store';
import { type } from '../util';


export const ActionTypes = {
  SEARCHING: type('[SearchFolderToAttach] searching'),
  UPLOADING: type('[SearchFolderToAttach] uploading'),
  PUT_ATTACH_RESULTS_ID: type('[SearchFolderToAttach] put search folder results id'),
  PUT_ATTACH_RESULTS: type('[SearchFolderToAttach] put search folder results'),
  PUT_ATTACH_RESULTS_SUCCESS: type('[SearchFolderToAttach] put search folder success'),
  PUT_ATTACH_RESULTS_SELECTED: type('[SearchFolderToAttach] put search folder results selected'),
  PUT_ATTACH_TYPE: type('[SearchFolderToAttach] put search preview type'),
  INIT_ATTACH_PREVIEW: type('[SearchFolderToAttach] Init state')
};


export class SearchingFolderToAttach implements Action {
  type = ActionTypes.SEARCHING;
  /**
   * Creates an instance of SearchingSearch.
   * @param {Boolean} payload
   *
   * @memberOf SearchingSearch
   */
  constructor(public payload?: Boolean) { }
}

export class UploadingFolderToAttach implements Action {
  type = ActionTypes.UPLOADING;
  /**
   * Creates an instance of UploadingFolderToAttach.
   * @param {Boolean} payload
   *
   * @memberOf UploadingFolderToAttach
   */
  constructor(public payload?: Boolean) { }
}

export class PutSearchFolderIdToAttach implements Action {
  type = ActionTypes.PUT_ATTACH_RESULTS_ID;
  /**
   * Creates an instance of PutSearchFolderIdToAttach.
   * @param { string } payload
   *
   * @memberOf PutSearchFolderIdToAttach
   */
  constructor(public payload: string ) { }
}

export class PutSearchResultsToAttach implements Action {
  type = ActionTypes.PUT_ATTACH_RESULTS;
  /**
   * Creates an instance of PutSearchResultsToAttach.
   * @param { Array<Folder>  } payload
   *
   * @memberOf PutSearchResultsToAttach
   */
  constructor(public payload: Array<Folder> ) { }
}

export class PutSearchResultsToAttachSelected implements Action {
  type = ActionTypes.PUT_ATTACH_RESULTS_SELECTED;
  /**
   * Creates an instance of PutSearchResultsToAttachSelected.
   * @param { Folder  } payload
   *
   * @memberOf PutSearchResultsToAttach
   */
  constructor(public payload: Folder ) { }
}

export class PutSearchResultsToAttachSuccess implements Action {
  type = ActionTypes.PUT_ATTACH_RESULTS_SUCCESS;
  /**
   * Creates an instance of PutSearchResultsToAttachSuccess.
   * @param { DocumentAttachedToFoldersResult } payload
   *
   * @memberOf PutSearchResultsToAttachSuccess
   */
  constructor(public payload: DocumentAttachedToFoldersResult ) { }
}

export class InitSearchFolderToAttach implements Action {
  type = ActionTypes.INIT_ATTACH_PREVIEW;
  /**
   * Creates an instance of InitSearchResultsSearchPreview.
   * @param { Document } payload
   *
   * @memberOf InitSearchResultsSearchPreview
   */
  constructor(public payload? ) { }
}




export type Actions
  = PutSearchFolderIdToAttach
  | UploadingFolderToAttach
  | PutSearchResultsToAttach
  | PutSearchResultsToAttachSelected
  | SearchingFolderToAttach
  | InitSearchFolderToAttach
  | PutSearchResultsToAttachSuccess;
