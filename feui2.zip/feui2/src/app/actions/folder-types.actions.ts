import { FolderTypes } from './../models/folder-types';
import { Error } from './../models/error';
import { Action } from '@ngrx/store';
import { type } from '../util';


export const ActionTypes = {
  LOADING_FOLDER_TYPES: type('[Folder Types] loading'),
  PUT_FOLDER_TYPES: type('[Folder Types] put document'),
  PUT_FOLDER_TYPES_BY_ID: type('[Folder Types] put document by ID'),
  PUT_FOLDER_TYPES_ERROR: type('[Folder Types] put document error'),
  INIT_FOLDER_TYPES:  type('[Folder Types] init state'),
};

export class LoadingFolderTypes implements Action {
  type = ActionTypes.LOADING_FOLDER_TYPES;
  /**
   * Creates an instance of LoadingFolderTypes.
   * @param {Boolean} [payload]
   * @memberof LoadingFolderTypes
   */
  constructor(public payload?: Boolean) { }
}

export class PutFolderTypes implements Action {
  type = ActionTypes.PUT_FOLDER_TYPES;
  /**
   * Creates an instance of PutFolderTypes.
   * @param {Array<FolderTypes> | Array<any>} payload
   * @memberof PutFolderTypes
   */
  constructor(public payload: Array<FolderTypes> | Array<any>) { }
}

export class PutFolderTypesById implements Action {
  type = ActionTypes.PUT_FOLDER_TYPES_BY_ID;
  /**
   * Creates an instance of PutFolderTypes.
   * @param {FolderTypes} payload
   * @memberof PutFolderTypes
   */
  constructor(public payload: FolderTypes ) { }
}

export class PutFolderTypesError implements Action {
  type = ActionTypes.PUT_FOLDER_TYPES_ERROR;
  /**
   * Creates an instance of PutFolderTypesError.
   * @param {Error} payload
   * @memberof PutFolderTypesError
   */
  constructor(public payload: Error) { }
}

export class InitPutFolderTypes implements Action {
  type = ActionTypes.INIT_FOLDER_TYPES;
  /**
   * Creates an instance of InitPutFolderTypes.
   * @param {any} [payload]
   * @memberof InitPutFolderTypes
   */
  constructor(public payload? ) { }
}

export type Actions
= PutFolderTypes
| PutFolderTypesById
| LoadingFolderTypes
| PutFolderTypesError
| InitPutFolderTypes;
