import { Tag } from 'app/models/tag';
import { Error } from './../models/error';
import { Action } from '@ngrx/store';
import { type } from '../util';


export const ActionTypes = {
  LOADING_TAG: type('[Tag] loading'),
  PUT_TAG: type('[Tag] put tag'),
  PUT_TAG_ERROR: type('[Tag] put tag error'),
  INIT_TAG:  type('[Tag] init state'),
};

export class LoadingTag implements Action {
  type = ActionTypes.LOADING_TAG;
  /**
   * Creates an instance of LoadingTag.
   * @param {Boolean} [payload]
   * @memberof LoadingTag
   */
  constructor(public payload?: Boolean) { }
}

export class PutTag implements Action {
  type = ActionTypes.PUT_TAG;
  /**
   * Creates an instance of PutTag.
   * @param {Tag} payload
   * @memberof PutTag
   */
  constructor(public payload: Array<Tag> | Array<any>) { }
}

export class PutTagError implements Action {
  type = ActionTypes.PUT_TAG_ERROR;
  /**
   * Creates an instance of PutTagError.
   * @param {Error} payload
   * @memberof PutTagError
   */
  constructor(public payload: Error) { }
}

export class InitPutTag implements Action {
  type = ActionTypes.INIT_TAG;
  /**
   * Creates an instance of InitPutTag.
   * @param {any} [payload]
   * @memberof InitPutTag
   */
  constructor(public payload? ) { }
}

export type Actions
= PutTag
| LoadingTag
| PutTagError
| InitPutTag;
