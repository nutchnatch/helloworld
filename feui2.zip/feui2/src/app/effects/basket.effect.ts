// import { PutUpdateBasketError } from './../actions/baskets.actions';
// import { BasketCreationResult } from './../models/basket-creation-result';
import { RestResponse } from './../models/rest-response';
import { QueryParams } from 'app/models/paged';
import { Error } from 'app/models/error';
import { Basket } from 'app/models/basket';
import { LoggerService } from 'app/services/logger/logger.service';

import { HttpClientService } from 'app/services/http-client.service';
import { Observable } from 'rxjs/Observable';
import { BasketService } from 'app/services/basket.service';

import { Store } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as basketAction from '../actions/basket.actions';
import * as httpErrorAction from '../actions/http-error.actions';
import * as searchPagedAction from '../actions/search-paged.actions';

import { Injectable } from '@angular/core';

/**
 * This Class is the Sample Controler Store/{@link BasketService}
 * @export
 * @class SampleEffect
 */
@Injectable()
export class BasketEffect {

  // private actionMethod: string;
  private query$: Observable<QueryParams>;
  query: QueryParams;

  constructor(
    private basketService: BasketService,
    private store: Store<fromRoot.State>,
    private logger: LoggerService
  ) {

    this.query$ = store.select(fromRoot.getSearchPagedQuery);
    this.query$.subscribe((q) => this.query = q);
  }

  /**
   * Get Basket List
   *
   * Get List from the Store, if not exist, call the {@link BasketService}
   * also change set loading = true, on sample state
   *
   */
  getBaskets(params?: QueryParams): any {

    this.logger.debug('BasketEffect', 'getBaskets() with this params: ', params);
    this.store.dispatch(new basketAction.LoadingBasket());

    this.basketService.getBaskets(params)
      .subscribe(
      (resp: any) => {
        this.logger.debug('BasketEffect', 'getBaskets success with result: ', resp);
        this.store.dispatch(new basketAction.PutBasketResults(resp['result']));
      },
      (error: Error) => {
        this.logger.error('BasketEffect', 'getBaskets error!! ', error);
        this.errorToGlobalState(error);
      }
      );
  }

  /**
 * Get Basket by id
 *
 * Get List from the Store, if not exist, call the {@link BasketService}
 * also change set loading = true, on sample state
 *
 */
  getBasketsTasksById(id: string, params?: QueryParams): any {

    this.logger.debug('BasketEffect', 'getBasketsTasksById() with id: ', id);
    // this.store.dispatch(new basketAction.LoadingBasket());
    this.store.dispatch(new searchPagedAction.SearchingSearchPaged());

    this.basketService.getBasketsTasksById(id, params)
      .subscribe(
      (resp: any) => {
        this.logger.debug('BasketEffect', 'getBasketsTasksById success with result: ', resp);
        // this.store.dispatch(new basketAction.PutBasket(resp.result[0]));
        this.store.dispatch(new searchPagedAction.PutSearchResultsSearchPaged(resp));

      },
      (error: Error) => {
        this.logger.error('BasketEffect', 'getBasketsTasksById error!! ', error);
        this.errorToGlobalState(error, true);
      }
      );
  }


  // putBasketByIdTransfer(fromId: string, toId: string): any {

  //   this.logger.debug('BasketEffect', 'putBasketsById() with ', {formId : fromId, toId: toId});
  //   // this.store.dispatch(new basketAction.UpdatingBasket());

  //   this.basketService.putBasketByIdTransfer(fromId, toId)
  //     .subscribe(
  //     (resp: RestResponse<String>) => {
  //       this.logger.debug('BasketEffect', 'putBasketsById success with result: ', resp);
  //       // this.store.dispatch(new basketAction.PutUpdateBasket(resp.result[0]));
  //     },
  //     (error: Error) => {
  //       this.logger.error('BasketEffect', 'putBasketsById error!! ', error);
  //       this.errorToGlobalState(error);
  //     }
  //     );
  // }

  /**
   * Error To Global State
   * This method filters the http error, to swicth to local scope or global scope
   *
   * @private
   * @param {*} error
   * @param {boolean} selected
   *
   * @memberOf BasketEffect
   */
  private errorToGlobalState(error: Error, search?: Boolean) {
    this.logger.error('BasketEffect', 'errorToGlobalState called | ErrorCode: ' + error.code);
    // this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
    if (error.code === 400 || error.code === '400' || error.code === 'error') {
      this.logger.debug('BasketEffect', 'Dispatch Scope Error to Store', error);
      // tslint:disable-next-line:max-line-length
      // search ? this.store.dispatch(new searchPagedAction.PutSearchResultsError(error)) : this.store.dispatch(new basketAction.PutUpdateBasketError(error));
    } else {
      this.logger.debug('BasketEffect', 'ErrorCode != 400 | Dispatch Global HttpError to Store');
      this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error));
    }

  }
}
