import { RestResponse } from './../models/rest-response';
import { QueryParams } from 'app/models/paged';
import { Envelope } from './../models/envelope';
import { EnvelopesService } from './../services/envelopes.service';
import { Error } from 'app/models/error';
import { LoggerService } from 'app/services/logger/logger.service';

import { HttpClientService } from 'app/services/http-client.service';
import { Observable } from 'rxjs/Observable';

import { Store } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as httpErrorAction from '../actions/http-error.actions';
import * as envelopeAction from '../actions/envelope.actions';
import * as searchPagedAction from '../actions/search-paged.actions';
import * as uploadDocumentsAction from 'app/actions/upload-documents.actions';

import { Injectable } from '@angular/core';
import { EnvelopeCreationResult } from 'app/models/envelope-creation-result';
import { DocumentFileService } from 'app/services/document-file.service';

/**
 *
 *
 * @export
 * @class DocumentFileEffect
 */
@Injectable()
export class DocumentFileEffect {

  // private actionMethod: string;
  private scope$: Observable<string>;
  scope: string;

  envelopeState$: Observable<Envelope>;
  envelopeStateID: string;

  constructor(
    private documentFile: DocumentFileService,
    private store: Store<fromRoot.State>,
    private logger: LoggerService
  ) {

    this.scope$ = store.select(fromRoot.getAppConfigScope);
    this.scope$.subscribe( (v) =>  this.scope = v );

    this.envelopeState$ = store.select(fromRoot.getEnvelopeFirstResult);
    this.envelopeState$.subscribe( envelope => this.envelopeStateID = envelope && envelope['id'] );
  }

  postDocumentFile(formData: FormData ): any {

    this.logger.debug('DocumentFileEffect', 'postDocumentFile() with this form data: ', formData.getAll('file') );

    this.store.dispatch(new uploadDocumentsAction.LoadingDocumentList());
    // console.log( formData.getAll('fileList') );

    this.documentFile.postDocumentFile( formData )
       .subscribe(
         (resp: RestResponse<EnvelopeCreationResult>) => {
            this.logger.debug('DocumentFileEffect', 'postDocumentFile success with result: ', resp.result);
            this.store.dispatch(new uploadDocumentsAction.PutResult( resp.result ));
          } ,
         (error: Error ) => {
           this.logger.error('DocumentFileEffect', 'postDocumentFile error!! ', error);
           this.errorToGlobalState(error);
        }
    );

  }
  /**
   * Error To Global State
   * This method filters the http error, to swicth to local scope or global scope
   *
   * @private
   * @param {*} error
   * @param {boolean} selected
   *
   * @memberOf DocumentFileEffect
   */
  private errorToGlobalState(error: Error) {
    this.logger.error('DocumentFileEffect', 'errorToGlobalState called | ErrorCode: ' + error.code);
    // this.store.dispatch(new envelopeAction.PutEnvelopeError( error ) );
    if ( error.code === 400 || error.code === '400' || error.code === 'error') {
      this.logger.debug('DocumentFileEffect', 'Dispatch Scope Error to Store');
      this.store.dispatch(new envelopeAction.PutEnvelopeError( error ) );
    } else {
      this.logger.debug('DocumentFileEffect', 'ErrorCode != 400 | Dispatch Global HttpError to Store');
      this.store.dispatch(new httpErrorAction.PutHttpErrorAction( error ));
    }

  }
}
