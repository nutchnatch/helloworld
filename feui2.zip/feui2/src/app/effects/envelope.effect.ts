import { RestResponse } from './../models/rest-response';
import { QueryParams } from 'app/models/paged';
import { Envelope } from './../models/envelope';
import { EnvelopesService } from './../services/envelopes.service';
import { Error } from 'app/models/error';
import { LoggerService } from 'app/services/logger/logger.service';

import { HttpClientService } from 'app/services/http-client.service';
import { Observable } from 'rxjs/Observable';

import { Store } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as httpErrorAction from '../actions/http-error.actions';
import * as envelopeAction from '../actions/envelope.actions';
import * as searchPagedAction from '../actions/search-paged.actions';
import * as uploadDocumentsAction from 'app/actions/upload-documents.actions';

import { Injectable } from '@angular/core';
import { EnvelopeCreationResult } from 'app/models/envelope-creation-result';

/**
 *
 *
 * @export
 * @class EnvelopeEffect
 */
@Injectable()
export class EnvelopeEffect {

  // private actionMethod: string;
  private scope$: Observable<string>;
  scope: string;

  envelopeState$: Observable<Envelope>;
  envelopeStateID: string;

  constructor(
    private envelopeService: EnvelopesService,
    private store: Store<fromRoot.State>,
    private logger: LoggerService
  ) {

    this.scope$ = store.select(fromRoot.getAppConfigScope);
    this.scope$.subscribe((v) => this.scope = v);

    this.envelopeState$ = store.select(fromRoot.getEnvelopeFirstResult);
    this.envelopeState$.subscribe(envelope => this.envelopeStateID = envelope && envelope['id']);
  }

  /**
   * Get Document List
   *
   * Get List from the Store, if not exist, call the {@link DocumentService}
   * also change set loading = true, on sample state
   *
   */
  getEnvelopes(params: QueryParams): any {

    this.logger.debug('EnvelopeEffect', 'getEnvelopes() with this params: ', params);
    this.store.dispatch(new searchPagedAction.SearchingSearchPaged());

    this.envelopeService.getEnvelopes(params)
      .subscribe(
      (resp: any) => {
        this.logger.debug('EnvelopeEffect', 'getEnvelopes success with result: ', resp);
        this.store.dispatch(new searchPagedAction.PutSearchResultsSearchPaged(resp));
      },
      (error: Error) => {
        this.logger.error('EnvelopeEffect', 'getEnvelopes error!! ', error);
        this.errorToGlobalState(error, true);
      }
      );
  }

  /**
   * Get Envelope by Id
   *
   * Get List from the Store, if not exist, call the {@link EnvelopeService}
   * also change set loading = true, on sample state
   */
  getEnvelopeById(id: string, refresh?: Boolean): any {

    // if (id === this.envelopeStateID) { return; }

    this.logger.debug('EnvelopeEffect', 'getEnvelopeById() with this id: ', id);

    this.store.dispatch(new envelopeAction.LoadingEnvelope());

    this.envelopeService.getEnvelopeById(id, this.scope)
      .subscribe(
      (resp: RestResponse<Envelope>) => {
        this.logger.debug('EnvelopeEffect', 'getEnvelopeById success with result: ', resp.result);
        this.store.dispatch(new envelopeAction.PutEnvelopeResult(resp.result));
      },
      (error: Error) => {
        this.logger.error('EnvelopeEffect', 'getEnvelopeById error!! ', error);
        this.errorToGlobalState(error);
      }
      );
  }

  /**
  * Put Envelope by id
  * {@link EnvelopeService}
  *
  */
  putEnvelopeById(id: string, body: Envelope): any {

    this.logger.debug('EnvelopeEffect', 'putEnvelopeById() with ', { id: id, body: body });
    this.store.dispatch(new envelopeAction.UpdatingEnvelope());

    this.envelopeService.putEnvelopesById(id, body)
      .subscribe(
      (resp: RestResponse<EnvelopeCreationResult>) => {
        this.logger.debug('EnvelopeEffect', 'putEnvelopeById success with result: ', resp);
        this.store.dispatch(new envelopeAction.PutUpdateEnvelope(resp.result[0]));
      },
      (error: Error) => {
        this.logger.error('EnvelopeEffect', 'putEnvelopeById error!! ', error);
        this.errorToGlobalState(error);
      }
      );
  }


  postEnvelopes(formData: FormData): any {

    this.logger.debug('EnvelopeEffect', 'postEnvelopes() with this form data: ', formData);

    this.store.dispatch(new uploadDocumentsAction.LoadingDocumentList());
    // console.log( formData.getAll('fileList') );

    this.envelopeService.postEnvelopes(formData)
      .subscribe(
      (resp: RestResponse<EnvelopeCreationResult>) => {
        this.logger.debug('EnvelopeEffect', 'postEnvelopes success with result: ', resp.result);
        this.store.dispatch(new uploadDocumentsAction.PutResult(resp.result));
      },
      (error: Error) => {
        this.logger.error('EnvelopeEffect', 'postEnvelopes error!! ', error);
        this.errorToGlobalState(error);
      }
      );

  }

  postEnvelopesDocuments(id: string, formData: FormData): any {

    this.logger.debug('EnvelopeEffect', 'with this id: ', id);
    this.logger.debug('EnvelopeEffect', 'postEnvelopesDocuments() with this form data: ', formData);

    this.store.dispatch(new uploadDocumentsAction.LoadingDocumentList());
    // console.log( formData.getAll('fileList') );

    this.envelopeService.postEnvelopesDocuments(id, formData)
      .subscribe(
      (resp: RestResponse<EnvelopeCreationResult>) => {
        this.logger.debug('EnvelopeEffect', 'postEnvelopesDocuments success with result: ', resp.result);
        this.store.dispatch(new uploadDocumentsAction.PutResult(resp.result));
      },
      (error: Error) => {
        this.logger.error('EnvelopeEffect', 'postEnvelopesDocuments error!! ', error);
        this.errorToGlobalState(error);
      }
      );

  }

  /**
   * Error To Global State
   * This method filters the http error, to swicth to local scope or global scope
   *
   * @private
   * @param {*} error
   * @param {boolean} selected
   *
   * @memberOf DocumentEffect
   */
  private errorToGlobalState(error: Error, search?: Boolean) {
    this.logger.error('EnvelopeEffect', 'errorToGlobalState called | ErrorCode: ' + error.code);
    // this.store.dispatch(new envelopeAction.PutEnvelopeError( error ) );
    if (error.code === 400 || error.code === '400' || error.code === 'error') {
      this.logger.debug('EnvelopeEffect', 'Dispatch Scope Error to Store');
      // tslint:disable-next-line:max-line-length
      search ? this.store.dispatch(new envelopeAction.PutEnvelopeError(error)) : this.store.dispatch(new envelopeAction.PutUpdateEnvelopeError(error));

    } else {
      this.logger.debug('EnvelopeEffect', 'ErrorCode != 400 | Dispatch Global HttpError to Store');
      this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error));
    }

  }
}
