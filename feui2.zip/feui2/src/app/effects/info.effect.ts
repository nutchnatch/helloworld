import { InfoService } from './../services/info.services';
import { getInfoVersion } from './../reducers/info.reducer';
import { FolderCreationResult } from './../models/folder-creation-result';
import { Subject } from 'rxjs/Subject';
import { LoggerService } from 'app/services/logger/logger.service';
import { Error } from 'app/models/error';
import { HttpClientService } from 'app/services/http-client.service';
import { Observable } from 'rxjs/Observable';

import { Store } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as infoAction from '../actions/info.actions';
import * as httpErrorAction from '../actions/http-error.actions';

import { Injectable } from '@angular/core';

/**
 * This Class is the Sample Controler Store/{@link InfoService}
 * @export
 * @class InfoEffect
 */
@Injectable()
export class InfoEffect {

  // private actionMethod: string;

  constructor(
    private infoService: InfoService,
    private store: Store<fromRoot.State>,
    private logger: LoggerService
  ) {

  }


  /**
   * Get App builded Version
   *
   * Get App Version {@link InfoService}
   *
   */
  getInfoVersion(): any {

    this.logger.debug('InfoEffect', 'getInfoVersion()');
    this.store.dispatch(new infoAction.LoadinInfoAction());

    this.infoService.getInfoVersion()
      .subscribe(
      (resp: any) => {
        this.logger.debug('InfoEffect', 'getInfoVersion success with result: ', resp);
        this.store.dispatch(new infoAction.PutInfoVersionAction(resp));
      },
      (error: Error) => {
        this.logger.error('InfoEffect', 'getInfoVersion error!! ', error);
        this.errorToGlobalState(error);
      }
      );
  }


  /**
   * Error To Global State
   * This method filters the http error, to swicth to local scope or global scope
   *
   * @private
   * @param {*} error
   * @param {boolean} selected
   *
   * @memberOf InfoEffect
   */
  private errorToGlobalState(error: Error) {
    this.logger.error('InfoEffect', 'errorToGlobalState called | ErrorCode: ' + error.code);
    // this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
    if (error.code === 400 || error.code === '400' || error.code === 'error') {
      this.logger.debug('InfoEffect', 'Dispatch Scope Error to Store');
      // tslint:disable-next-line:max-line-length
      // this.store.dispatch(new infoAction(error));
    } else {
      this.logger.debug('InfoEffect', 'ErrorCode != 400 | Dispatch Global HttpError to Store');
      this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error));
    }

  }
}
