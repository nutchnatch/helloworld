import { PutUpdateDocumentError } from './../actions/documents.actions';
import { DocumentCreationResult } from './../models/document-creation-result';
import { RestResponse } from './../models/rest-response';
import { QueryParams } from 'app/models/paged';
import { Error } from 'app/models/error';
import { Document } from 'app/models/document';
import { LoggerService } from 'app/services/logger/logger.service';

import { HttpClientService } from 'app/services/http-client.service';
import { Observable } from 'rxjs/Observable';
import { DocumentService } from 'app/services/document.service';

import { Store } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as searchPagedAction from '../actions/search-paged.actions';
import * as documentAction from '../actions/documents.actions';
import * as httpErrorAction from '../actions/http-error.actions';

import { Injectable } from '@angular/core';

/**
 * This Class is the Sample Controler Store/{@link DocumentService}
 * @export
 * @class SampleEffect
 */
@Injectable()
export class DocumentEffect {

  // private actionMethod: string;
  private query$: Observable<QueryParams>;
  query: QueryParams;

  constructor(
    private documentService: DocumentService,
    private store: Store<fromRoot.State>,
    private logger: LoggerService
  ) {

    this.query$ = store.select(fromRoot.getSearchPagedQuery);
    this.query$.subscribe((q) => this.query = q);
  }

  /**
   * Get Document List
   *
   * Get List from the Store, if not exist, call the {@link DocumentService}
   * also change set loading = true, on sample state
   *
   */
  getDocuments(params: QueryParams): any {

    this.logger.debug('DocumentEffect', 'getDocuments() with this params: ', params);
    this.store.dispatch(new searchPagedAction.SearchingSearchPaged());

    this.documentService.getDocuments(params)
      .subscribe(
      (resp: any) => {
        this.logger.debug('DocumentEffect', 'getDocuments success with result: ', resp);
        this.store.dispatch(new searchPagedAction.PutSearchResultsSearchPaged(resp));
      },
      (error: Error) => {
        this.logger.error('DocumentEffect', 'getDocuments error!! ', error);
        this.errorToGlobalState(error);
      }
      );
  }
  /**
 * Get Document by id
 *
 * Get List from the Store, if not exist, call the {@link DocumentService}
 * also change set loading = true, on sample state
 *
 */
  getDocumentsById(id: string): any {

    this.logger.debug('DocumentEffect', 'getDocumentsById() with id: ', id);
    this.store.dispatch(new documentAction.LoadingDocument());

    this.documentService.getDocumentsById(id)
      .subscribe(
      (resp: RestResponse<Document>) => {
        this.logger.debug('DocumentEffect', 'getDocumentsById success with result: ', resp);
        this.store.dispatch(new documentAction.PutDocument(resp.result[0]));
      },
      (error: Error) => {
        this.logger.error('DocumentEffect', 'getDocumentsById error!! ', error);
        this.errorToGlobalState(error, true);
      }
      );
  }

   /**
 * Get Document by id
 *
 * Get List from the Store, if not exist, call the {@link DocumentService}
 * also change set loading = true, on sample state
 *
 */
putDocumentsById(id: string, body: Document): any {

  this.logger.debug('DocumentEffect', 'putDocumentsById() with ', { id: id, body: body });
  this.store.dispatch(new documentAction.UpdatingDocument());

  this.documentService.putDocumentsById(id, body)
    .subscribe(
    (resp: RestResponse<DocumentCreationResult>) => {
      this.logger.debug('DocumentEffect', 'putDocumentsById success with result: ', resp);
      this.store.dispatch(new documentAction.PutUpdateDocument(resp.result[0]));
    },
    (error: Error) => {
      this.logger.error('DocumentEffect', 'putDocumentsById error!! ', error);
      this.errorToGlobalState(error);
    }
    );
}

  /**
   * Error To Global State
   * This method filters the http error, to swicth to local scope or global scope
   *
   * @private
   * @param {*} error
   * @param {boolean} selected
   *
   * @memberOf DocumentEffect
   */
  private errorToGlobalState(error: Error, search?: Boolean) {
    this.logger.error('DocumentEffect', 'errorToGlobalState called | ErrorCode: ' + error.code);
    // this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
    if (error.code === 400 || error.code === '400' || error.code === 'error') {
      this.logger.debug('DocumentEffect', 'Dispatch Scope Error to Store', error);
      // tslint:disable-next-line:max-line-length
      search ? this.store.dispatch(new searchPagedAction.PutSearchResultsError(error)) : this.store.dispatch(new documentAction.PutUpdateDocumentError(error));
    } else {
      this.logger.debug('DocumentEffect', 'ErrorCode != 400 | Dispatch Global HttpError to Store');
      this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error));
    }

  }
}
