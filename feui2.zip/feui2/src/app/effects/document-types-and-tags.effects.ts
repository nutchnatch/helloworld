import { EnvelopeTypeService } from './../services/envelope-type.service';
import { FolderTypesService } from './../services/folder-types.service';
import { DocumentTypes } from 'app/models/document-types';
import { TagsService } from './../services/tags.services';
import { Injectable } from '@angular/core';
import { HttpClientService } from 'app/services/http-client.service';
import { Observable } from 'rxjs/Observable';
import { DocumentTypeService } from 'app/services/document-type.service';
import { LoggerService } from 'app/services/logger/logger.service';

import { Store } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as documentTypeAction from '../actions/document-types.actions';
import * as tagAction from '../actions/tag.actions';
import * as envelopeTypeAction from '../actions/envelope-types.actions';
import * as folderTypeAction from '../actions/folder-types.actions';
import * as extraFieldAction from '../actions/extra-fields.actions';


@Injectable()
export class DocumentTypesAndTagsEffect {

  constructor(
    private documentTypeService: DocumentTypeService,
    private envelopeTypeService: EnvelopeTypeService,
    private folderTypesService: FolderTypesService,
    private tagsService: TagsService,
    private store: Store<fromRoot.State>,
    private logger: LoggerService
  ) {

  }

  getDocumentAndTagsTypes(): any {

    this.logger.debug('DocumentTypesAndTagsEffect', 'getDocumentAndTagsTypes()');

    this.store.dispatch( new documentTypeAction.LoadingDocumentTypes());
    this.store.dispatch( new tagAction.LoadingTag());
    this.store.dispatch( new envelopeTypeAction.LoadingEnvelopeTypes());
    this.store.dispatch( new folderTypeAction.LoadingFolderTypes());

    const types = this.documentTypeService.getDocumentsTypes().map( res => res ) ;
    const tags = this.tagsService.getTags().map( res => res ) ;
    const envelopeType = this.envelopeTypeService.getEnvelopeTypes().map( res => res ) ;
    const folderTypes = this.folderTypesService.getFolderTypes().map( res => res );

    Observable.forkJoin([ types, tags, envelopeType, folderTypes ])
      .subscribe( ( results ) => {
        this.logger.debug('DocumentTypesAndTagsEffect', 'getDocumentAndTagsTypes() success with result: ', results);
        this.store.dispatch( new documentTypeAction.PutDocumentTypes( results[0].result ));
        this.store.dispatch( new tagAction.PutTag( results[1].result ));
        this.store.dispatch( new envelopeTypeAction.PutEnvelopeTypes( results[2].result ));
        this.store.dispatch( new folderTypeAction.PutFolderTypes( results[3].result ));

        this.store.dispatch( new extraFieldAction.PutExtraFields( { tags: results[1].result , documentType: results[0].result } ));
        this.store.dispatch( new extraFieldAction.PutEnvelopeExtraFields( { tags: results[1].result , envelopeType: results[2].result } ));
        this.store.dispatch( new extraFieldAction.PutFolderExtraFields( { tags: results[1].result , folderType: results[3].result } ));

      },
      (error: Error) => {
        this.logger.error('DocumentTypesAndTagsEffect', 'getDocumentAndTagsTypes() error!! ', error);
        // this.errorToGlobalState(error);
        // this.store.dispatch( new documentTypeAction.PutDocumentTypes( error[0].result ));
        // this.store.dispatch( new tagAction.PutTag( error[1].result ))
      });
  }

}
