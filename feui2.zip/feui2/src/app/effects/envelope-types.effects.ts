import { Subscription } from 'rxjs/Subscription';
import { EnvelopeTypes } from 'app/models/envelope-types';
import { EnvelopeTypeService } from './../services/envelope-type.service';
import { RestResponse } from './../models/rest-response';
import { QueryParams } from 'app/models/paged';
import { Error } from 'app/models/error';
import { Document } from 'app/models/document';
import { LoggerService } from 'app/services/logger/logger.service';

import { HttpClientService } from 'app/services/http-client.service';
import { Observable } from 'rxjs/Observable';

import { Store } from '@ngrx/store';

import * as fromRoot from '../reducers';
import * as searchPagedAction from '../actions/search-paged.actions';
import * as envelopeTypesAction from '../actions/envelope-types.actions';
import * as httpErrorAction from '../actions/http-error.actions';

import { Injectable } from '@angular/core';

import { find } from 'lodash';

/**
 * This Class is the Sample Controler Store/{@link EnvelopeTypeService}
 * @export
 * @class EnvelopeTypeEffect
 */
@Injectable()
export class EnvelopeTypeEffect {

  private envelopeTypes$: Observable<Array<EnvelopeTypes>>;
  private subsciberEnvelopeType: Subscription;

  envTypes: Array<EnvelopeTypes>;

  constructor(
    private envelopeTypesServices: EnvelopeTypeService,
    private store: Store<fromRoot.State>,
    private logger: LoggerService
  ) {

    this.envelopeTypes$ = store.select(fromRoot.getEnvelopeTypesResult);
    this.subsciberEnvelopeType = this.envelopeTypes$.subscribe(envTypes => {
      this.envTypes = envTypes;
    });

  }


  /**
 * Get Envelope Type by id
 *
 * Get List from the Store, if not exist, call the {@link EnvelopeTypeService}
 * also change set loading = true, on sample state
 *
 */
  getEnvelopeTypeById(id: string, version: number): any | EnvelopeTypes {

    this.logger.debug('EnvelopeTypeEffect', 'getEnvelopeTypeById() with id ($1) and version ($2): ', { $1: id, $2: version });
    // this.store.dispatch(new envelopeTypesAction.LoadingEnvelopeTypes());


    this.envelopeTypesServices.getEnvelopeTypesById(id, version)
      .subscribe(
      (resp: RestResponse<EnvelopeTypes>) => {
        this.logger.debug('EnvelopeTypeEffect', 'getEnvelopeTypeById success with result: ', resp);
        this.store.dispatch(new envelopeTypesAction.PutEnvelopeTypesById(resp.result[0]));
      },
      (error: Error) => {
        this.logger.error('EnvelopeTypeEffect', 'getEnvelopeTypeById error!! ', error);
        this.errorToGlobalState(error);
      }
      );
  }

  /**
   * Error To Global State
   * This method filters the http error, to swicth to local scope or global scope
   *
   * @private
   * @param {*} error
   * @param {boolean} selected
   *
   * @memberOf DocumentEffect
   */
  private errorToGlobalState(error: Error) {
    this.logger.error('DocumentEffect', 'errorToGlobalState called | ErrorCode: ' + error.code);
    this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
    if (error.code === 400 || error.code === '400' || error.code === 'error') {
      this.logger.debug('DocumentEffect', 'Dispatch Scope Error to Store');
      this.store.dispatch(new searchPagedAction.PutSearchResultsError(error));
    } else {
      this.logger.debug('DocumentEffect', 'ErrorCode != 400 | Dispatch Global HttpError to Store');
      this.store.dispatch(new httpErrorAction.PutHttpErrorAction(error));
    }

  }
}
