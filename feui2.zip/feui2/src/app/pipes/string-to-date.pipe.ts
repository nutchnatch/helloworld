import { PipeTransform, Pipe } from '@angular/core';

/**
 *
 * @export
 * @class StringToDatePipe
 * @implements {PipeTransform}
 */
@Pipe({ name: 'stringToDate' })
export class StringToDatePipe implements PipeTransform {
  transform(value): any {
    if (value) {
      const month = value.month;
      const day = value.dayOfMonth;
      const year = value.year;
      const hour = value.hour;
      const min = value.minute;
      const text = year + ' ' + month + ' ' + day + ' ' + hour + ':' + min;
      const date = new Date(text);
      return date;
    }
  }
}
/* && value.dayOfMonth
"dayOfMonth": 8,
"dayOfWeek": "FRIDAY",
"dayOfYear": 251,
"month": "SEPTEMBER",
"year": 2017,
"monthValue": 9,
"hour": 14,
"minute": 39,
"nano": 0,
"second": 0,
"chronology": {
  "id": "ISO",
  "calendarType": "iso8601"
}*/
