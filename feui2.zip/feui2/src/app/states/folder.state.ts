import { FolderCreationResult } from './../models/folder-creation-result';
import { Folder } from './../models/folder';
import { RestResponse } from './../models/rest-response';
import { Paging } from 'app/models/paging';
import { Error } from './../models/error';

export class State extends RestResponse<Array<Folder>> {
    loading: Boolean;
    updateResult: FolderCreationResult;
    updating: boolean;
    updateError: Error;
    creating: boolean;
    creatingError: Error;
    creatingResult: FolderCreationResult;
    deleting: boolean;
    deletingError: Error;
    deletingResult: FolderCreationResult;
}

export const initialState: State = {
    result: null,
    paging: new Paging,
    loading: false,
    error: null,
    updateError: null,
    status: null,
    updateResult: null,
    updating: false,
    creating: false,
    creatingError: null,
    creatingResult: null,
    deleting: false,
    deletingError: null,
    deletingResult: null
};


export const initialStateFolder: Folder = {
    creationDate: null,
    folderTypeId: null,
    folderTypeVersion: null,
    id: null,
    lastUpdateDate: null,
    listOfDocumentId: null,
    name: null,
    owner: null,
    retentionDate: null,
    status: 'OPEN',
    tagList: null
};
