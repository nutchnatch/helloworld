import { RestResponse } from './../models/rest-response';
import { DocumentTypes } from './../models/document-types';


export class State extends RestResponse<Array<DocumentTypes>> {
  loading: boolean;
}

export const initialState: State = {
  loading: false,
  error: null,
  result: null,
  status: null,
  paging: null
};
