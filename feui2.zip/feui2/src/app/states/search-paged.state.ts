import { Paging } from 'app/models/paging';
import { Document } from 'app/models/document';
import { PagedQuery } from './../models/paged';


export class State extends PagedQuery<Array<Document>> {
    loading: Boolean;
    type: string;
}

export const initialState: State = {
    query: null,
    results: null,
    paging: new Paging,
    type: null,
    loading: false,
    error: null
};
/**
query:
  export class QueryParams {
  type: string;
  name: string;
  page?: PageParams;
}
*/
