import { Tag } from './../models/tag';
import { RestResponse } from './../models/rest-response';


export class State extends RestResponse<Array<Tag>> {
  loading: boolean;
}

export const initialState: State = {
  loading: false,
  error: null,
  result: null,
  status: null,
  paging: null
};
