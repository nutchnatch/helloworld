import { Envelope } from 'app/models/envelope';
import { Document } from 'app/models/document';
import { Folder } from 'app/models/folder';


export class State {
    hasResults: Boolean;
    resultId: string;
    results: Document | Envelope | Folder;
    loading: Boolean;
    type: string;
}

export const initialState: State = {
    hasResults: false,
    resultId: null,
    results: new Document,
    loading: false,
    type: null
};
