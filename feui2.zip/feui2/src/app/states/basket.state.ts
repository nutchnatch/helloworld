import { RestResponse } from 'app/models/rest-response';
import { Basket } from 'app/models/basket';
import { Error } from './../models/error';

export class State extends RestResponse<Array<Basket>> {
  loading: Boolean;
  loadingTransfer: false;
  errorTransfer: Error;
  resultTransfer: RestResponse<string>;
}

export const initialState: State = {
  loading: false,
  error: null,
  result: null,
  status: null,
  paging: null,

  loadingTransfer: false,
  errorTransfer: null,
  resultTransfer: null
};
