import { DocumentAttachedToFoldersResult } from './../models/document-attached-to-folder-result';
import { Folder } from 'app/models/folder';


export class State {
    hasResults: Boolean;
    resultId: string;
    results: Array<Folder>;
    foldersSelected: Array<Folder>;
    loading: Boolean;
    type: string;
    uploading: Boolean;
    success: DocumentAttachedToFoldersResult;
}

export const initialState: State = {
    hasResults: false,
    resultId: null,
    results: null,
    foldersSelected: null,
    loading: false,
    type: null,
    uploading: false,
    success: null
};
