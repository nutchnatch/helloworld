import { ExtraFields } from './extra-fields.state';

export class AdvanceQuery {
  name: string;
  type: string;
  value: string;
  defaultTag: boolean;
}

/**
 *
 *
 * @export
 * @class State
 */
export class State {
 domain: string;
 domainSelected: Array<any>;
 defaultTags: Array<any>;
 defaultOperators: Array<any>;
 tagsList: Array<ExtraFields>;
 typeID: string;
 advanceSearchQuery: Array<AdvanceQuery>;
 formGroup: any;
}

export const initialState: State = {
  domain: null,
  domainSelected: null,
  defaultTags: [
    {
      name: 'creationDate',
      type: 'timestamp',
      operador: ['greater_than', 'less_than'],
      default: true,
      diplayNameItem: [
        {
          language: 'FR',
          value: 'Création'
        },
        {
          language: 'EN',
          value: 'Create date'
        }
      ],
    },
    {
      name: 'updateDate',
      type: 'timestamp',
      operador: ['greater_than', 'less_than'],
      default: true,
      diplayNameItem: [
        {
          language: 'FR',
          value: 'Édité'
        },
        {
          language: 'EN',
          value: 'Edited date'
        }
      ],
    },
    {
      name: 'creator',
      type: 'string',
      operador: ['contains', 'starts_with', 'ends_with', 'equals_to'],
      default: true,
      diplayNameItem: [
        {
          language: 'FR',
          value: 'Créé per'
        },
        {
          language: 'EN',
          value: 'Created by'
        }
      ],
    },
    {
      name: 'lastModifier',
      type: 'string',
      operador: ['contains', 'starts_with', 'ends_with', 'equals_to'],
      default: true,
      diplayNameItem: [
        {
          language: 'FR',
          value: 'Mis à jour par'
        },
        {
          language: 'EN',
          value: 'Updated by'
        }
      ],
    },
    {
      name: 'name',
      type: 'string',
      operador: ['contains', 'starts_with', 'ends_with', 'equals_to'],
      default: true,
      diplayNameItem: [
        {
          language: 'FR',
          value: 'Nom'
        },
        {
          language: 'EN',
          value: 'Name'
        }
      ],
    },
    {
      name: 'validity',
      type: 'choicelist',
      values: [ { 'label': 'VALID', 'value': 'equals_to|VALID' }, { 'label': 'NOT_VALID', 'value': 'not_equals_to|VALID' }],
      operador: [],
      default: true,
      diplayNameItem: [
        {
          language: 'FR',
          value: 'Validité'
        },
        {
          language: 'EN',
          value: 'Validity'
        }
      ]
    },
  ],
  defaultOperators: [{
    'string': ['CONTAINS', 'EQUALS_TO', 'STARTS_WITH', 'ENDS_WITH'],
    'timestamp': ['LESS_THAN', 'GREATER_THAN', 'EQUALS_TO'],
    'type': ['EQUALS_TO'],
    'code': ['EQUALS_TO']
  }],
  tagsList: null,
  typeID: null,
  advanceSearchQuery: [],
  formGroup: null
};
