import { RestResponse } from './../models/rest-response';
import { DocumentsFilter } from './../models/documents-filter';
import { Document } from './../models/document';
import { DocumentCreationResult } from 'app/models/document-creation-result';
import { Error } from './../models/error';


export class State extends RestResponse<Array<Document>> {
  loading: boolean;
  updateResult: DocumentCreationResult;
  updating: boolean;
  updateError: Error;
}

export const initialState: State = {
  loading: false,
  updating: false,
  error: null,
  updateError: null,
  result: null,
  status: null,
  paging: null,
  updateResult: null
};
