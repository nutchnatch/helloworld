import { RestResponse } from './../models/rest-response';
import { EnvelopeTypes } from './../models/envelope-types';


export class State extends RestResponse<Array<EnvelopeTypes>> {
  loading: boolean;
}

export const initialState: State = {
  loading: false,
  error: null,
  result: null,
  status: null,
  paging: null
};
