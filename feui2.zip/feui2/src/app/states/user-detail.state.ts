import { HttpError } from './../models/http-error';
import { UserDetails } from 'app/models/user-details';
import { RestResponse } from './../models/rest-response';
import { Document } from 'app/models/document';
import { Error } from './../models/error';


export class State extends RestResponse<UserDetails> {
  loading: boolean;
  loaded: boolean;
  httpError: HttpError;
}

export const initialState: State = {
    error: new Error,
    httpError: null,
    paging: null,
    result: null,
    status: null,
    loading: false,
    loaded: null
};

