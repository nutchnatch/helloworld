

export class State {
  scope: string;
  pageSize: number;
}


export const initialState: State = {
  scope: '',
  pageSize: 20
};
