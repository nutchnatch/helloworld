import { DocumentsFilter } from './../models/documents-filter';
import { DocumentLite } from './../models/document-lite';


export class State extends DocumentsFilter<Array<DocumentLite>> {}

export const initialState: State = {
    multiple: false,
    selected: null,
    documentsList: null,
    documentsSelectedList: null
};
