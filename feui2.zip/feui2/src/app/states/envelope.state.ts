import { EnvelopeCreationResult } from 'app/models/envelope-creation-result';
import { Envelope } from './../models/envelope';
import { RestResponse } from './../models/rest-response';
import { Paging } from 'app/models/paging';
import { Error } from './../models/error';

export class State extends RestResponse<Array<Envelope>> {
  loading: Boolean;
  updateResult: EnvelopeCreationResult;
  updating: Boolean;
  updateError: Error;
  underConstructionStep2: Boolean;
  tabActive: string;
}

export const initialState: State = {
  result: null,
  paging: new Paging,
  loading: false,
  error: null,
  updateError: null,
  status: null,
  updateResult: null,
  updating: false,
  underConstructionStep2: false,
  tabActive: null
};
