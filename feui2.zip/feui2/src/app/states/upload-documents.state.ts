import { Tag } from './../models/tag';
import { RestResponse } from './../models/rest-response';
import { UploadDocuments } from 'app/models/upload-documents';


export class State extends UploadDocuments {}

export const initialState: State = {
  documentsList: [],
  loading: false,
  error: null,
  result: null,
  uploaded: null
};
