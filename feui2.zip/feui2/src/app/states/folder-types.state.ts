import { RestResponse } from './../models/rest-response';
import { FolderTypes } from './../models/folder-types';


export class State extends RestResponse<Array<FolderTypes>> {
  loading: boolean;
}

export const initialState: State = {
  loading: false,
  error: null,
  result: null,
  status: null,
  paging: null
};
