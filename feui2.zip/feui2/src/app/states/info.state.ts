import { Info } from 'app/models/info';

export class State extends Info {
  loading: Boolean;
  error: string;
}

export const initialState: State = {
    version: null,
    loading: false,
    error: null
};
