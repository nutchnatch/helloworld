import { Envelope } from 'app/models/envelope';
import { Document } from './../models/document';
import { Tag } from './../models/tag-element';
import { DocumentTypes } from 'app/models/document-types';

export class ExtraFields extends DocumentTypes {
  inputsFields: Array<Tag>;
}

export class State {
  metadataFields: Array<ExtraFields>;
  envelopeMetadataFields: Array<ExtraFields>;
  folderMetadataFields: Array<ExtraFields>;
  // currentDocument: Document;
  // currentEnvelope: Envelope;
  loaded: Boolean;
}

export const initialState: State = {
  metadataFields: null,
  envelopeMetadataFields: null,
  folderMetadataFields: null,
  // currentDocument: null,
  // currentEnvelope: null,
  loaded: false
};

