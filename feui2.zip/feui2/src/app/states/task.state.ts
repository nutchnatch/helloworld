import { RestResponse } from 'app/models/rest-response';
import { Task } from 'app/models/task';
import { Error } from './../models/error';

export class State extends RestResponse<Array<Task>> {
  loading: Boolean;

  loadingTransfer: false;
  errorTransfer: Error;
  resultTransfer: RestResponse<string>;

  loadingStatus: false;
  errorStatus: Error;
  resultStatus: RestResponse<string>;
}

export const initialState: State = {
  loading: false,
  error: null,
  result: null,
  status: null,
  paging: null,

  loadingTransfer: false,
  errorTransfer: null,
  resultTransfer: null,

  loadingStatus: false,
  errorStatus: null,
  resultStatus: null

};
