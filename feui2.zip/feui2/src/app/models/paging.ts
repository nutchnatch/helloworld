export class Paging {
  totalItems: number;
  totalPages: number;
  pageSize: number;
  currentPage: number;
}
