import { TagElement } from './tag-element';
import { Folder } from 'app/models/folder';

export class Document {
  id: string;
  name: string;
  docFileID: string;
  envelopeID: string;
  creationDate: string;
  language: string;
  retentionStartDate: string;
  retentionEndDate: string;
  confidentiality: string;
  docTypeSymbolicName: string;
  docTypeId: string;
  listOfTags: TagElement;
  direction: string;
  tagList: Array<TagElement>;
  validity: string;
  docViewURL: string;
  folderList?: Array<Folder>;
}
