import { TagElement } from './tag-element';
/**
 *
 *
 * @export
 * @class Folder
 */
export class Folder {
  creationDate: string;
  folderTypeId: string;
  folderTypeVersion: string;
  id: string;
  lastUpdateDate: string;
  listOfDocumentId: Array<string>;
  name: string;
  owner: string;
  retentionDate: string;
  status: string;
  tagList: Array<TagElement>;
}


