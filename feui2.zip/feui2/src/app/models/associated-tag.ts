export class AssociateTag {
  mandatory: Boolean;
  multivalued: Boolean;
  symbolicName: String;
}
