import { Paging } from './paging';
import { Document } from './document';
import { Error } from './error';

export class PagedDocument {
  document: Array<Document>;
  paging: Paging;
}

export class PageParams {
  pageNumber: number;
  pageSize: number;
}

export class QueryParams {
  type?: string;
  name: string;
  page?: PageParams;
  pageSize: number;
  pageNumber: number;
}

export class PagedQuery<T> {
  results: Array<T>;
  paging: Paging;
  query: QueryParams;
  error: Error;
}
