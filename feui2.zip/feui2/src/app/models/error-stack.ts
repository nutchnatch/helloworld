export class ErrorStack {
    code: string;
    detail: string;
    message: string;
}
