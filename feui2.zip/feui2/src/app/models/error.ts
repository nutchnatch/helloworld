import { ErrorStack } from './error-stack';

export class Error {
  code: string | number;
  erroDate: string;
  errorType: string;
  message: string;
  stack?: ErrorStack;
}
