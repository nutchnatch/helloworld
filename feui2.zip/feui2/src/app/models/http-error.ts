export class HttpError {
  ok: boolean;
  status: number;
  statusText: string;
  type: number;
}
