/**
 *
 *
 * @export
 * @class EnvelopeCreationResult
 */
export class EnvelopeCreationResult {
  envelopeId: string;
}
