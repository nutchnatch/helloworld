export class Info {
  version: string;
}
