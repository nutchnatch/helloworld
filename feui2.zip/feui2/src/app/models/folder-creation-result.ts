
/**
 *
 *
 * @export
 * @class FolderCreationResult
 */
export class FolderCreationResult {
  folderId: string;
}
