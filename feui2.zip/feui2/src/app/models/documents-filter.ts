
export class DocumentsFilter<T> {
  multiple: boolean;
  selected: string;
  documentsList: Array<T>;
  documentsSelectedList: Array<T>;
}
