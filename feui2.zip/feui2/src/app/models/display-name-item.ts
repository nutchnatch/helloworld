export class DisplayNameItem {
  language: string;
  value: string;
}
