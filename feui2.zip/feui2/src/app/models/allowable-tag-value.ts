import { DisplayNameItem } from './display-name-item';

export class AllowableTagValue {
  displayNameValues: Array<DisplayNameItem>;
  symbolicName: string;
}
