import { AssociateTag } from './associated-tag';
import { DisplayNameItem } from './display-name-item';

export class EnvelopeTypes {
  displayNameList: Array<DisplayNameItem>;
  id: string;
  name: string;
  tagList: Array<AssociateTag>;
  version: number;
}
