import { Router } from '@angular/router';
import { ModalExpiredSessionComponent } from 'app/modules/tsp-ui/modals/modal-expired-session/modal-expired-session.component';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { DocumentTypesAndTagsEffect } from './effects/document-types-and-tags.effects';
import { TagsService } from './services/tags.services';
import { DocumentTypeService } from 'app/services/document-type.service';
// import { DocumentTypesEffect } from './effects/document-types.effects';
import { Observable } from 'rxjs/Observable';
import { Component, ChangeDetectionStrategy, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { HttpClientService } from './services/http-client.service';
import { LoggerService } from './services/logger/logger.service';
import { Error } from 'app/models/error';


import { Store } from '@ngrx/store';

import * as fromRoot from './reducers';
import * as layout from './actions/layout.actions';
import * as language from './actions/language.actions';
import * as documentTypes from './actions/document-types.actions';
import * as layoutAction from './actions/layout.actions';
import * as httpErrorAction from 'app/actions/http-error.actions';

import 'rxjs/add/observable/forkJoin';
import 'rxjs/add/operator/catch';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  currentLanguage$: Observable<string>;
  showSidenav$: Observable<boolean>;
  userDetailsLoaded$: Observable<boolean>;
  httpError$: Observable<Error>;
  userName$: Observable<string>;
  userName: string;
  fullUserName$: Observable<string>;
  fullUserName: string;

  loadedError: boolean;

  modalExpiredSession;

  constructor(
    private http: HttpClientService,
    private logger: LoggerService,
    private documentTypesAndTagsEffect: DocumentTypesAndTagsEffect,
    private store: Store<fromRoot.State>,
    private translate: TranslateService,
    protected router: Router,
    protected modalService: NgbModal
  ) {
    /**
    * debug store uncoment line bellow
    */
    // store.subscribe( (state)=> console.log(state));

    // this language will be used as a fallback when a translation isn't found in the current language
    translate.setDefaultLang('en');

    /**
    * Selectors can be applied with the `select` operator which passes the state
    * tree to the provided selector
    */
    this.currentLanguage$ = store.select(fromRoot.getCurrentLanguage);
    this.currentLanguage$.subscribe((selectedLanguage) => { translate.use(selectedLanguage); });

    this.showSidenav$ = store.select(fromRoot.getShowSidenav);
    // this.showSidenav$.subscribe((open) => console.log(open))

    this.userDetailsLoaded$ = store.select(fromRoot.getUserDetailsLoaded);
    this.userDetailsLoaded$.subscribe(userLoaded => userLoaded && this.documentTypesAndTagsEffect.getDocumentAndTagsTypes());

    this.fullUserName$ = store.select(fromRoot.getUserDetailsFullUserName);
    this.fullUserName$.subscribe((fullname) => this.fullUserName = fullname);

    this.userName$ = store.select(fromRoot.getUserDetailsUserName);
    this.userName$.subscribe((username) => this.userName = username);

    this.httpError$ = store.select(fromRoot.getHttpError);
    this.httpError$.subscribe(error => error && this.errorHandler(error));

    this.store.dispatch(new layoutAction.PutFromSearchAction(null));
    this.store.dispatch(new layoutAction.PutAdvanceSearch(false));

  }

  ngOnInit() {

  }

  protected errorHandler(error: Error) {
    this.store.dispatch(new httpErrorAction.PutLoadedErrorAction(true));
    if (error.code === '401' || error.code === 401) {
      this.openExpiredModal();
      // if (!this.modalExpiredSession) {
      //   this.modalExpiredSession = this.modalService.open(ModalExpiredSessionComponent);
      //   this.modalExpiredSession.componentInstance.fullName = this.fullUserName;
      //   this.modalExpiredSession.componentInstance.username = this.userName;
      // }

      // this.modalExpiredSession.result.then((result) => {
      //   this.store.dispatch(new httpErrorAction.PutLoadedErrorAction(false));
      //   this.modalExpiredSession = undefined;
      // }, (reason) => {
      //   this.getDismissReason(reason);
      //   this.store.dispatch(new httpErrorAction.PutLoadedErrorAction(false));
      // });

    } else if (error.code === '403' || error.code === 403) {
      // TODO: SHOW A MODAL BOX WITH MISSING CORRECTS ROLES / AUTORIZATION
      //  alert('Missing Role!');
      this.openExpiredModal();

      // this.onError403();
    } else if (error.code === '404' || error.code === 404) {
      // TODO: SHOW A MODAL WITH PAGE NOT FOUND
      alert('PAGE NOT FOUND');
      // this.onError404();
    }
  }

  getDismissReason(reason: any) {
    if (reason === ModalDismissReasons.ESC) {
      this.router.navigate(['app/user/logout']);
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      this.router.navigate(['app/user/logout']);
    } else { }
    this.modalExpiredSession = undefined;
  }

  openExpiredModal() {

    if (!this.modalExpiredSession) {
      this.modalExpiredSession = this.modalService.open(ModalExpiredSessionComponent);
      this.modalExpiredSession.componentInstance.fullName = this.fullUserName;
      this.modalExpiredSession.componentInstance.username = this.userName;
    }

    this.modalExpiredSession.result.then((result) => {
      this.store.dispatch(new httpErrorAction.PutLoadedErrorAction(false));
      this.modalExpiredSession = undefined;
    }, (reason) => {
      this.getDismissReason(reason);
      this.store.dispatch(new httpErrorAction.PutLoadedErrorAction(false));
    });
  }
}
