import { Subscription } from 'rxjs/Subscription';
import { Title } from '@angular/platform-browser';

import { Observable } from 'rxjs/Observable';
import { Breadcrumb, Link } from 'app/models/breadcrumb';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { BaseComponent } from 'app/modules/containers/base/base.component';
import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as breadcrumbAction from 'app/actions/breadcrumb.actions';
import * as layoutAction from 'app/actions/layout.actions';
import * as searchPreviewAction from 'app/actions/search-preview.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';

import { PageConfig } from 'app/states/app-config.state';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent extends BaseComponent implements OnInit, OnDestroy {

  private pageConfig$: Observable<PageConfig>;
  private subscribePageConfig: Subscription;

  private breadcrumb: Breadcrumb = new Breadcrumb;

  page = 1;

  constructor(
    store: Store<fromRoot.State>,
    private titleService: Title,
    ) {
    super(store);

    this.pageConfig$ = store.select(fromRoot.getAppConfigDashboard);


    this.subscribePageConfig = this.pageConfig$.subscribe( config => {
      this.breadcrumb.links = config.breadcrumb;
      this.store.dispatch( new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb) );
      this.store.dispatch( new layoutAction.PutSidebarParams(config.sidebar) );
      this.store.dispatch( new layoutAction.PutMetadataBarParams(config.metadataBar) );
      this.store.dispatch( new searchPreviewAction.InitSearchResultsSearchPreview() );

    });

  }

  ngOnInit() {
     this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
     this.titleService.setTitle( 'Sugar // Dashboard' );

    this.store.dispatch(new searchPagedAction.InitSearchResults());

  }

  ngOnDestroy() {
    this.subscribePageConfig.unsubscribe();
  }
}
