import { EnvelopeComponent } from './envelope/envelope.component';
import { SearchResultsComponent } from './search-results/search-results.component';
import { AuthGuardService } from 'app/services/auth-guard.services';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RefreshUrlComponent } from 'app/modules/tsp-ui/refresh-url/refresh-url.component';
import { FolderComponent } from 'app/modules/containers/folder/folder.component';
import { UploadDocumentComponent } from 'app/modules/containers/upload-document/upload-document.component';


const routes: Routes = [
  {
    path: 'app/dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'app/envelope/:id',
    component: EnvelopeComponent,
    canActivate: [AuthGuardService],
  },
  {
    path: 'app/envelope/:id/:docid',
    component: EnvelopeComponent,
    canActivate: [AuthGuardService],
  },
  {
    path: 'app/folder/:id',
    component: FolderComponent,
    canActivate: [AuthGuardService],
  },
  {
    path: 'app/folder/:id/:docid',
    component: FolderComponent,
    canActivate: [AuthGuardService],
  },
  {
    path: 'app/search',
    component: SearchResultsComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'app/basket',
    component: SearchResultsComponent,
    canActivate: [AuthGuardService],
    data: { title: 'Basket', type: 'BASKET' }
  },
  {
    path: 'app/basket/:id',
    component: SearchResultsComponent,
    canActivate: [AuthGuardService],
    data: { title: 'Basket', type: 'BASKET' }
  },
  {
    path: 'app/documents',
    component: SearchResultsComponent,
    canActivate: [AuthGuardService],
    data: { title: 'Documents', type: 'DOCUMENTS' }
  },
  {
    path: 'app/envelopes',
    component: SearchResultsComponent,
    canActivate: [AuthGuardService],
    data: { title: 'Envelopes', type: 'ENVELOPES' }
  },
  {
    path: 'app/folders',
    component: SearchResultsComponent,
    canActivate: [AuthGuardService],
    data: { title: 'Folders', type: 'FOLDERS' }
  },
  {
    path: 'app/upload-document',
    component: UploadDocumentComponent,
    canActivate: [AuthGuardService],
    data: { title: 'Upload Documents', type: 'Upload Documents' }
  },
  {
    path: 'app/refresh',
    component: RefreshUrlComponent,
    // canActivate: [AuthGuardService]
  },
  {
    path: '**',
    redirectTo: 'app/basket', pathMatch: 'full',
    // component: DashboardComponent,
    canActivate: [AuthGuardService]
  }
];

/**
 * Containers (Pages) Modulos Routes
 *
 * Login Module Routes:
 *  - Homepage/welcome - 'welcome'
 *
 * @export
 * @class LoginRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContainersRoutingModule { }
