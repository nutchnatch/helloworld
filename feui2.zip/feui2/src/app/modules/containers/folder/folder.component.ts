import { Subscription } from 'rxjs/Subscription';
import { Document } from './../../../models/document';
import { DocumentEffect } from './../../../effects/document.effect';
import { Title } from '@angular/platform-browser';
import { FolderEffect } from './../../../effects/folder.effect';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { BaseComponent } from './../base/base.component';
import { Breadcrumb, Link } from 'app/models/breadcrumb';
import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as breadcrumbAction from 'app/actions/breadcrumb.actions';
import * as layoutAction from 'app/actions/layout.actions';
import * as folderAction from 'app/actions/folder.actions';
import * as searchPreviewAction from 'app/actions/search-preview.actions';
import * as documentsFilterAction from 'app/actions/documents-filter.actions';
import * as searchPagedActions from 'app/actions/search-paged.actions';
import * as searchPreviewActions from 'app/actions/search-preview.actions';

import { PageConfig } from 'app/states/app-config.state';



@Component({
  selector: 'app-folder',
  templateUrl: './folder.component.html',
  styleUrls: ['./folder.component.scss']
})
export class FolderComponent extends BaseComponent implements OnInit, OnDestroy {

  private pageConfig$: Observable<PageConfig>;
  private documentsResult$: Observable<Document>;
  private subscribeDocumentResult: Subscription;

  private subscribePageConfig: Subscription;

  private breadcrumb: Breadcrumb = new Breadcrumb;
  private linksToBreadcrumb: Link[];
  private showMetadataBar$: Observable<Boolean>;

  private subscribeActiveRoute: Subscription;

  constructor(
    store: Store<fromRoot.State>,
    router: Router,
    private activatedRouter: ActivatedRoute,
    private folderEffect: FolderEffect,
    private documentEffect: DocumentEffect,
    private titleService: Title
    ) {
    super(store);

    this.breadcrumb.links = this.linksToBreadcrumb;
    this.pageConfig$ = store.select(fromRoot.getAppConfigFolder);
    this.showMetadataBar$ = store.select(fromRoot.getMetadataBarShow);

    this.subscribePageConfig = this.pageConfig$.subscribe(config => {
      this.store.dispatch(new layoutAction.PutSidebarParams(config.sidebar));
      this.store.dispatch(new layoutAction.PutMetadataBarParams(config.metadataBar));
    });

    this.documentsResult$ = store.select(fromRoot.getDocumentsResult);
    this.subscribeDocumentResult = this.documentsResult$.subscribe( document => {
      if (document) { this.store.dispatch(new searchPreviewAction.PutSearchResultsSearchPreview(document)); }
    });

    this.store.dispatch( new searchPagedActions.InitSearchResults);
    this.store.dispatch( new searchPreviewActions.PutSearchTypeSearchPreview('documents_single'));

    // this.store.dispatch(new searchPreviewAction.InitSearchResultsSearchPreview);
    // this.store.dispatch(new searchPreviewAction.PutSearchResultsSearchPreview(doc)

  }

  ngOnInit() {
    this.subscribeActiveRoute = this.activatedRouter.paramMap.subscribe((params: ParamMap) => {

      this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
      this.titleService.setTitle('Sugar // Folder - ' +  params.get('id') );

      if ( params.get('docid') !== null) {
        const docid =  params.get('docid');
        this.documentEffect.getDocumentsById(docid);
        this.store.dispatch( new documentsFilterAction.PutDocumentSeleced( docid ) );

       }

      this.folderEffect.getFoldersById(params.get('id'));
    });
  }

  ngOnDestroy() {
    this.subscribePageConfig.unsubscribe();
    this.subscribeActiveRoute.unsubscribe();
    this.subscribeDocumentResult.unsubscribe();
    this.store.dispatch(new searchPreviewActions.PutSearchTypeSearchPreview(null));

  }
}
