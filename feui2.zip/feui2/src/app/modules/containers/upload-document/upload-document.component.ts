import { EnvelopeEffect } from 'app/effects/envelope.effect';
import { Paging } from './../../../models/paging';
import { Link, Breadcrumb } from './../../../models/breadcrumb';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Store } from '@ngrx/store';
import { BaseComponent } from './../base/base.component';
import { PageConfig } from 'app/states/app-config.state';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';

import * as fromRoot from 'app/reducers';
import * as breadcrumbAction from 'app/actions/breadcrumb.actions';
import * as layoutAction from 'app/actions/layout.actions';
import * as uploadDocumentsAction from 'app/actions/upload-documents.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';

@Component({
  selector: 'app-upload-document',
  templateUrl: './upload-document.component.html',
  styleUrls: ['./upload-document.component.scss']
})
export class UploadDocumentComponent extends BaseComponent implements OnInit, OnDestroy {

  private pageConfig$: Observable<PageConfig>;
  private uploadDocument$: Observable<Array<File>>;
  private error$: Observable<any>;

  private subscribePageConfig: Subscription;
  private subscribeActiveRouteData: Subscription;
  private subscribeActiveRoute: Subscription;

  breadcrumb: Breadcrumb = new Breadcrumb;
  linksToBreadcrumb: Link[];
  title: string;
  searchType: string;

  pageSize$: Observable<number>;
  currentLang$: Observable<string>;
  advanceQueryResult$: Observable<string>;

  subscriberPageSize: Subscription;
  subscriberExtraFields: Subscription;
  searchQuery$: Observable<any>;
  subscriberSearchQuery: Subscription;

  paging$: Observable<Paging>;
  page: number;
  subscriberPaging: Subscription;

  pageSize: number;
  searchQuery: any;
  loaded: Boolean = false;

  constructor(
    private activatedRouter: ActivatedRoute,
    private envelopeEffect: EnvelopeEffect,
    store: Store<fromRoot.State>,
  ) {

    super(store);

    this.breadcrumb.links = this.linksToBreadcrumb;

    this.pageConfig$ = store.select(fromRoot.getAppConfigUploadDocuments);

    this.subscribePageConfig = this.pageConfig$.subscribe(config => {
      this.store.dispatch(new layoutAction.PutSidebarParams(config.sidebar));
      this.store.dispatch(new layoutAction.PutMetadataBarParams(config.metadataBar));
      this.store.dispatch(new layoutAction.CloseSidenavAction());
    });

    this.uploadDocument$ = store.select(fromRoot.getUploadDocumentsList);

    this.pageSize$ = store.select(fromRoot.getAppConfigPageSize);
    this.subscriberPageSize = this.pageSize$.subscribe(value => this.pageSize = value);

    this.paging$ = store.select(fromRoot.getSearchPagedPaging);
    this.subscriberPaging = this.paging$.subscribe(page => this.page = page.currentPage);

    this.currentLang$ = store.select(fromRoot.getCurrentLanguage);

    this.searchQuery$ = this.store.select(fromRoot.getSearchPagedQuery);
    this.subscriberSearchQuery = this.searchQuery$.subscribe( query => {
       this.searchQuery = query;
       if ( query && query.hasOwnProperty('validity') ) { this.getEnvelopeUnderConstruction(this.searchQuery); }
      //  console.log(query['validity'])
      });

    this.advanceQueryResult$ = store.select(fromRoot.getAdvanceSearchQuery);
  }

  getEnvelopeUnderConstruction(params) {
    this.envelopeEffect.getEnvelopes(params);
  }

  ngOnInit() {
    // this.store.dispatch(new uploadDocumentsAction.InitDocumentList());
    this.subscribeActiveRouteData = this.activatedRouter.data.subscribe((data) => {
      this.title = data.title ? data.type : 'documents';
      this.searchType = data.type ? data.type : 'DOCUMENTS';
    });

    this.subscribeActiveRoute = this.activatedRouter.paramMap.subscribe((paramsMap: ParamMap | any) => {

      this.linksToBreadcrumb = [
        { 'label': '<strong> ' + this.title + ' </strong>' },
        // { 'label': paramsMap.get('name').split('|')[1] }
      ];

      this.breadcrumb = new Breadcrumb;
      this.breadcrumb.links = this.linksToBreadcrumb;

      this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));


    });
    // tslint:disable-next-line:max-line-length
    // const query = Object.assign({},
    //   this.toQueryParams(searchQueryString.value['advanceSearchQuery']),
    //   { pageNumber: 1, pageSize: this.pageSize }
    // );

    // tslint:disable-next-line:max-line-length
    this.store.dispatch(new searchPagedAction.PutSearchResultsQuery( { validity: 'equals_to|INVALID', pageNumber: 1, pageSize: this.pageSize } ));

  }



  ngOnDestroy() {
    this.store.dispatch(new layoutAction.OpenSidenavAction());
    this.subscribePageConfig.unsubscribe();
    this.subscribeActiveRoute.unsubscribe();
    this.subscribeActiveRouteData.unsubscribe();
    this.subscriberSearchQuery.unsubscribe();
  }

}
