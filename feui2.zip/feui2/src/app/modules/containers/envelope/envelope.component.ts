import { Subscription } from 'rxjs/Subscription';
import { Document } from './../../../models/document';
import { DocumentEffect } from './../../../effects/document.effect';
import { Title } from '@angular/platform-browser';
import { EnvelopeEffect } from './../../../effects/envelope.effect';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { BaseComponent } from './../base/base.component';
import { Breadcrumb, Link } from 'app/models/breadcrumb';
import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as breadcrumbAction from 'app/actions/breadcrumb.actions';
import * as appConfigActions from 'app/actions/app-config.actions';
import * as layoutAction from 'app/actions/layout.actions';
import * as envelopeAction from 'app/actions/envelope.actions';
import * as searchPreviewAction from 'app/actions/search-preview.actions';
import * as documentsFilterAction from 'app/actions/documents-filter.actions';
import * as searchPagedActions from 'app/actions/search-paged.actions';
import * as searchPreviewActions from 'app/actions/search-preview.actions';

import { PageConfig } from 'app/states/app-config.state';



@Component({
  selector: 'app-envelope',
  templateUrl: './envelope.component.html',
  styleUrls: ['./envelope.component.scss']
})
export class EnvelopeComponent extends BaseComponent implements OnInit, OnDestroy {
  subscribeActiveRouteQueryParam: Subscription;

  private pageConfig$: Observable<PageConfig>;
  private documentsResult$: Observable<Document>;
  private subscribeDocumentResult: Subscription;

  private subscribePageConfig: Subscription;

  private breadcrumb: Breadcrumb = new Breadcrumb;
  private linksToBreadcrumb: Link[];
  private showMetadataBar$: Observable<Boolean>;

  private subscribeActiveRoute: Subscription;

  currentId;
  hasTask;

  constructor(
    store: Store<fromRoot.State>,
    router: Router,
    private activatedRouter: ActivatedRoute,
    private envelopeEffect: EnvelopeEffect,
    private documentEffect: DocumentEffect,
    private titleService: Title
  ) {
    super(store);

    this.breadcrumb.links = this.linksToBreadcrumb;
    this.pageConfig$ = store.select(fromRoot.getAppConfigEnvelop);
    this.showMetadataBar$ = store.select(fromRoot.getMetadataBarShow);

    this.subscribePageConfig = this.pageConfig$.subscribe(config => {
      this.store.dispatch(new layoutAction.PutSidebarParams(config.sidebar));
      this.store.dispatch(new layoutAction.PutMetadataBarParams(config.metadataBar));
    });

    this.documentsResult$ = store.select(fromRoot.getDocumentsResult);
    this.subscribeDocumentResult = this.documentsResult$.subscribe(document => {
      if (document) { this.store.dispatch(new searchPreviewAction.PutSearchResultsSearchPreview(document)); }
    });

    this.store.dispatch(new searchPagedActions.InitSearchResults);
    this.store.dispatch(new searchPreviewActions.PutSearchTypeSearchPreview('documents_single'));

    // this.store.dispatch(new searchPreviewAction.InitSearchResultsSearchPreview);
    // this.store.dispatch(new searchPreviewAction.PutSearchResultsSearchPreview(doc)

  }

  ngOnInit() {

    // this.subscribeActiveRouteQueryParam = this.activatedRouter.queryParamMap.subscribe((params: ParamMap) => {
    //   if (params.get('taskId') ) {
    //     this.hasTask = params.get('taskId');
    //   }
    // });

    this.subscribeActiveRoute = this.activatedRouter.paramMap.subscribe((params: ParamMap) => {
      this.currentId = params.get('id');

      this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
      this.titleService.setTitle('Sugar // Envelope - ' + this.currentId);

      if (params.get('docid') !== null) {
        const docid = params.get('docid');
        this.documentEffect.getDocumentsById(docid);
        this.store.dispatch(new documentsFilterAction.PutDocumentSeleced(docid));
      }
      this.envelopeEffect.getEnvelopeById(this.currentId);
    });
  }

  ngOnDestroy() {
    this.subscribePageConfig.unsubscribe();
    this.subscribeActiveRoute.unsubscribe();
    this.subscribeDocumentResult.unsubscribe();
    // this.subscribeActiveRouteQueryParam.unsubscribe();
    this.store.dispatch(new searchPreviewActions.PutSearchTypeSearchPreview(null));
    this.store.dispatch(new appConfigActions.PutCopiedTagsAction(null));

  }
}
