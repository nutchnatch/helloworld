import { Basket } from './../../../models/basket';
import { BasketEffect } from 'app/effects/basket.effect';

import { Subscriber } from 'rxjs/Subscriber';
import { Title } from '@angular/platform-browser';
import { DocumentEffect } from 'app/effects/document.effect';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { BaseComponent } from './../base/base.component';
import { Breadcrumb, Link } from 'app/models/breadcrumb';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as breadcrumbAction from 'app/actions/breadcrumb.actions';
import * as layoutAction from 'app/actions/layout.actions';
import * as appConfigAction from 'app/actions/app-config.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';
import * as searchPreviewAction from 'app/actions/search-preview.actions';
import * as documentsFilterAction from 'app/actions/documents-filter.actions';
import * as envelopeSelectedAction from 'app/actions/envelope.actions';


import { PageConfig } from 'app/states/app-config.state';
import { Subscription } from 'rxjs/Subscription';
import { EnvelopeEffect } from 'app/effects/envelope.effect';
import { FolderEffect } from 'app/effects/folder.effect';



@Component({
  selector: 'app-search-results',
  templateUrl: './search-results.component.html',
  styleUrls: ['./search-results.component.scss']
})
export class SearchResultsComponent extends BaseComponent implements OnInit, OnDestroy {

  private pageConfig$: Observable<PageConfig>;
  private subscribePageConfig: Subscription;
  private searching$: Observable<boolean>;
  private error$: Observable<any>;
  private searchType$: Observable<string>;
  private searchResult$: Observable<any>;
  // private basketsResult$: Observable<Array<Basket>>;

  private breadcrumb: Breadcrumb = new Breadcrumb;
  private linksToBreadcrumb: Link[];

  private clickPreview: any;

  private subscribeActiveRoute: Subscription;
  private subscribeActiveRouteData: Subscription;
  // private subscribeBasketResults: Subscription;
  // private route: ActivatedRoute;

  title: string;
  searchType: string;
  firstTaskId: string;

  constructor(
    store: Store<fromRoot.State>,
    private activatedRouter: ActivatedRoute,
    private documentEffect: DocumentEffect,
    private envelopeEffect: EnvelopeEffect,
    private folderEffect: FolderEffect,
    private basketEffect: BasketEffect,
    private titleService: Title,

  ) {

    super(store);

    this.breadcrumb.links = this.linksToBreadcrumb;

    this.searching$ = store.select(fromRoot.getSearchPagedLoading);
    this.searchResult$ = store.select(fromRoot.getSearchPagedResults);

    this.error$ = store.select(fromRoot.getSearchPagedError);

    this.pageConfig$ = store.select(fromRoot.getAppConfigSearch);

    this.subscribePageConfig = this.pageConfig$.subscribe(config => {
      this.store.dispatch(new layoutAction.PutSidebarParams(config.sidebar));
      this.store.dispatch(new layoutAction.PutMetadataBarParams(config.metadataBar));
    });


    this.store.dispatch(new documentsFilterAction.InitDocumentSelecedList());
    this.store.dispatch(new envelopeSelectedAction.InitEnvelope());
    this.store.dispatch(new searchPreviewAction.InitSearchResultsSearchPreview());

  }

  ngOnInit() {

    // tslint:disable-next-line:max-line-length
    this.subscribeActiveRouteData = this.activatedRouter.data.subscribe((data) => {

      this.title = data.title ? data.type : 'documents';
      this.searchType = data.type ? data.type : 'DOCUMENTS';
      this.store.dispatch(new searchPagedAction.PutSearchResultsType(this.searchType));
    });

    this.subscribeActiveRoute = this.activatedRouter.paramMap.subscribe((paramsMap: ParamMap | any) => {

      this.linksToBreadcrumb = [
        { 'label': 'Search by <strong> ' + this.title + ' </strong>' },
        // { 'label': paramsMap.get('name').split('|')[1] }
      ];

      // this.titleService.setTitle('Sugar // Search by - ' + this.title + ' - ' + paramsMap.get('name').split('|')[1]);

      this.breadcrumb = new Breadcrumb;
      this.breadcrumb.links = this.linksToBreadcrumb;

      if (paramsMap.get('pageSize')) { this.store.dispatch(new appConfigAction.PutPageSizeAction(paramsMap.get('pageSize'))); }


      this.store.dispatch(new breadcrumbAction.PutBreadcrumbAction(this.breadcrumb));
      this.store.dispatch(new searchPagedAction.PutSearchResultsQuery(paramsMap.params));

      // console.log(paramsMap.params);
      // this.store.dispatch(new searchPagedAction.InitSearchResults());
      if (this.searchType === 'ENVELOPES') { this.envelopeEffect.getEnvelopes(paramsMap.params); }
      if (this.searchType === 'DOCUMENTS') { this.documentEffect.getDocuments(paramsMap.params); }
      if (this.searchType === 'FOLDERS') { this.folderEffect.getFolders(paramsMap.params); }
      if (this.searchType === 'BASKET' && paramsMap.get('id')) {
        this.basketEffect.getBasketsTasksById(paramsMap.get('id'), paramsMap.params);
      }


    });
  }

  ngOnDestroy() {

    this.subscribePageConfig.unsubscribe();
    this.subscribeActiveRoute.unsubscribe();
    this.subscribeActiveRouteData.unsubscribe();
    // this.subscribeBasketResults.unsubscribe();
  }
}
