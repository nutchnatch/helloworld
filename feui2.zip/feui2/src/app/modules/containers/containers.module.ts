import { TaskEffect } from 'app/effects/task.effect';
import { ModalCreateFolderComponent } from 'app/modules/sugar/modals/modal-create-folder/modal-create-folder.component';
import { InfoEffect } from './../../effects/info.effect';
import { DocumentTypesAndTagsEffect } from './../../effects/document-types-and-tags.effects';
import { EnvelopeEffect } from './../../effects/envelope.effect';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DocumentEffect } from 'app/effects/document.effect';
import { SugarModule } from './../sugar/sugar.module';
import { ModalExpiredSessionComponent } from 'app/modules/tsp-ui/modals/modal-expired-session/modal-expired-session.component';
import { TspUIModule } from 'app/modules/tsp-ui/tsp-ui.module';
import { ContainersRoutingModule } from './containers-routing.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BaseComponent } from './base/base.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SearchResultsComponent } from './search-results/search-results.component';
import { EnvelopeComponent } from './envelope/envelope.component';
import { EnvelopeTypeEffect } from 'app/effects/envelope-types.effects';
import { FolderEffect } from 'app/effects/folder.effect';
import { FolderComponent } from 'app/modules/containers/folder/folder.component';
import { ModalSearchFolderComponent } from 'app/modules/sugar/modals/modal-search-folder/modal-search-folder.component';
import { UploadDocumentComponent } from './upload-document/upload-document.component';
import { BasketEffect } from 'app/effects/basket.effect';
import { ModalAlertEnvelopeComponent } from 'app/modules/sugar/modals/modal-alert-envelope/modal-alert-envelope.component';

@NgModule({
  imports: [
    CommonModule,
    NgbModule,
    ContainersRoutingModule,
    TspUIModule,
    SugarModule
  ],
   providers: [
    DocumentEffect,
    DocumentTypesAndTagsEffect,
    EnvelopeEffect,
    EnvelopeTypeEffect,
    FolderEffect,
    InfoEffect,
    BasketEffect,
    TaskEffect
    // EnvelopeTypeEffect
  ],
  entryComponents: [
    ModalExpiredSessionComponent,
    ModalSearchFolderComponent,
    ModalCreateFolderComponent,
    ModalAlertEnvelopeComponent
  ],
  declarations: [
    BaseComponent,
    DashboardComponent,
    SearchResultsComponent,
    EnvelopeComponent,
    FolderComponent,
    UploadDocumentComponent
  ]
})
export class ContainersModule { }
