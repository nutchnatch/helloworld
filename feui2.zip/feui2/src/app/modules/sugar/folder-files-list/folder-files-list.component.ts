import { Subscription } from 'rxjs/Subscription';
import { Folder } from './../../../models/folder';
import { Router, ActivatedRoute } from '@angular/router';
import { DocumentEffect } from 'app/effects/document.effect';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { element } from 'protractor';
import { DocumentLite } from './../../../models/document-lite';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as documentsFilterAction from 'app/actions/documents-filter.actions';


@Component({
  selector: 'app-folder-files-list',
  templateUrl: './folder-files-list.component.html',
  styleUrls: ['./folder-files-list.component.scss']
})
export class FolderFilesListComponent implements OnInit, OnDestroy {


  listOfDocument$: Observable<Array<string>>;
  listOfDocumentObject$: Observable<Array<DocumentLite>>;
  listOfDocumentObjectSelected$: Observable<Array<DocumentLite>>;
  selectedDocument$: Observable<string>;
  folderState$: Observable<Folder>;
  filterOn$: Observable<any>;

  folderStateID: string;
  subscribesFolderStateID: Subscription;

  listOfDocument;
  subscribesListOfDocument: Subscription;


  constructor(
    private store: Store<fromRoot.State>,
    private documentEffect: DocumentEffect,
    private router: Router,
    private activatedRouter: ActivatedRoute,
    ) {


    this.folderState$ = store.select(fromRoot.getFolderFirstResult);
    this.subscribesFolderStateID = this.folderState$.subscribe( folder => this.folderStateID = folder && folder['id'] );

    this.listOfDocument$ = store.select(fromRoot.getFolderListDocuments);
    this.subscribesListOfDocument = this.listOfDocument$.subscribe( list => list && this.initForm(list));

    this.listOfDocumentObject$ = store.select(fromRoot.getDocumentsFilterList);
    this.listOfDocumentObjectSelected$ = store.select(fromRoot.getDocumentsFilterListSelected);

    this.selectedDocument$ = store.select(fromRoot.getDocumentsFilterSelected);

    this.filterOn$ = store.select(fromRoot.getDocumentsFilterMultiple);
  }

  initForm(list) {
    const listOfDocument = list.map(element => Object.assign({...element} , { selected: false }));
    this.store.dispatch( new documentsFilterAction.PutDocumentSelecedList( listOfDocument ) );
  }

  updateSelected(document) {
    this.store.dispatch( new documentsFilterAction.PutDocumentSelecedListById( document.id ) );
    this.store.dispatch( new documentsFilterAction.PutSelectedDocumentSelecedList( document.id ) );
  }

  documentSelect(document) {

    this.store.dispatch( new documentsFilterAction.PutDocumentSeleced( document.id ) );

    this.router.navigate(['/app/folder', this.folderStateID, document.id ]);
    // this.documentEffect.getDocumentsById(document.id);
  }

  ngOnInit() {

  }

  ngOnDestroy() {
    this.subscribesFolderStateID.unsubscribe();
    this.subscribesListOfDocument.unsubscribe();
  }

}
