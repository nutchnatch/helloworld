import { Paging } from './../../../../../models/paging';
import { FolderEffect } from 'app/effects/folder.effect';
import { AdvanceQuery } from 'app/states/advance-search.state';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { Subscription } from 'rxjs/Subscription';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as advanceSearchActions from 'app/actions/advance-search.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';

import { FolderTypes } from 'app/models/folder-types';

import { flattenDepth, uniqBy, filter, find } from 'lodash';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';

@Component({
  selector: 'app-search-on-modal',
  templateUrl: './search-on-modal.component.html',
  styleUrls: ['./search-on-modal.component.scss']
})
export class SearchOnModalComponent implements OnInit, OnDestroy {

  pageSize$: Observable<number>;
  currentLang$: Observable<string>;
  advanceQueryResult$: Observable<string>;
  formGroup$: Observable<any>;
  extraFields$: Observable<any>;

  subscriberPageSize: Subscription;
  subscriberFormGroup: Subscription;
  subscriberExtraFields: Subscription;
  searchQuery$: Observable<any>;
  subscriberSearchQuery: Subscription;

  paging$: Observable<Paging>;
  page: number;
  subscriberPaging: Subscription;

  searchQueryString: FormGroup;

  pageSize: number;
  searchQuery: any;
  loaded: Boolean = false;

  constructor(
    private store: Store<fromRoot.State>,
    private router: Router,
    private folderEffect: FolderEffect,

  ) {

    this.store.dispatch(new advanceSearchActions.PutDomain('Folders'));
    this.store.dispatch(new advanceSearchActions.RemoveAllAdvanceSearch());

    this.extraFields$ = store.select(fromRoot.getExtraFields);
    this.subscriberExtraFields = this.extraFields$.subscribe(extraFields => {
      // this.extraFields = extraFields;
      this.store.dispatch(new advanceSearchActions.PutDomainSelected(extraFields['folderMetadataFields']));
      this.store.dispatch(new advanceSearchActions.PutTagsList(extraFields['folderMetadataFields']));
      this.store.dispatch(new advanceSearchActions.PutAdvanceSearch( new AdvanceQuery ));

    });

    this.pageSize$ = store.select(fromRoot.getAppConfigPageSize);
    this.subscriberPageSize = this.pageSize$.subscribe(value => this.pageSize = value);

    this.paging$ = store.select(fromRoot.getSearchPagedPaging);
    this.subscriberPaging = this.paging$.subscribe(page => this.page = page.currentPage);

    this.currentLang$ = store.select(fromRoot.getCurrentLanguage);

    this.searchQuery$ = this.store.select(fromRoot.getSearchPagedQuery);
    this.subscriberSearchQuery = this.searchQuery$.subscribe( query => {
       this.searchQuery = query;
       this.getFolder(this.searchQuery);
       // console.log(this.searchQuery)
      });

    this.advanceQueryResult$ = store.select(fromRoot.getAdvanceSearchQuery);

    this.initForm();
    // this.advanceQuery$.subscribe(v => c)
  }

  initForm() {

    this.searchQueryString = new FormGroup({
      type: new FormControl('Folders', Validators.required),
    });
    this.searchQueryString.addControl('advanceSearchQuery', new FormArray([]));

  }

  onSearch(searchQueryString: FormGroup) {
    const query = Object.assign({},
      this.toQueryParams(searchQueryString.value['advanceSearchQuery']),
      { pageNumber: this.page, pageSize: this.pageSize }
    );
    this.store.dispatch(new searchPagedAction.PutSearchResultsQuery( query ));
  }

  getFolder(params) {
    this.folderEffect.getFolders(params, true);
  }

  ngOnInit() {
    // this.getFolder({name: 'contains| ', pageNumber: 1, pageSize: this.pageSize});
    this.store.dispatch(new searchPagedAction.PutSearchResultsQuery( { name: 'contains| ', pageNumber: 1, pageSize: this.pageSize } ));

  }

  ngOnDestroy() {
    this.subscriberPageSize.unsubscribe();
  }

  toQueryParams(formValues): any {

    let paramsObj;
    const tagArray = [];

    const example = [
      {
        'tagName': 'updateDate',
        'operator': 'great_than',
        'type': 'timestamp',
        'value': '2017-11-10',
        'defaultTag': true
      },
      {
        'tagName': 'name',
        'operator': 'equals_to',
        'type': 'string',
        'value': 'dev',
        'defaultTag': true
      },
      {
        'tagName': 'policy',
        'operator': 'equals_to',
        'type': 'string',
        'value': 'test1'
      },
      {
        'tagName': 'policy2',
        'operator': 'equals_to',
        'type': 'string',
        'value': 'test2'
      }
    ];

    filter(formValues, tag => tag['defaultTag'])
      .map(tag => paramsObj = Object.assign({}, paramsObj, { [tag.tagName]: tag.operator + '|' + tag.value }));

    filter(formValues, (tag) => !tag['defaultTag'])
      .map(tag => {
        // const b = a.concat(tag.tagName + '|' + tag.type + '|' + tag.operator + '|' + tag.value);
        tagArray.push(tag.tagName + '|' + tag.type + '|' + tag.operator + '|' + tag.value);
        paramsObj = Object.assign({}, paramsObj, { tags: tagArray });
      });
    // name=operator|value
    // tags=tagName|type|operator|value

    return paramsObj;
  }

}
