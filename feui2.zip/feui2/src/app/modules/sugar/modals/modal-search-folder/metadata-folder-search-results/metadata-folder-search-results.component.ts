import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { FolderEffect } from 'app/effects/folder.effect';
import { Store } from '@ngrx/store';
import { Component, OnInit, OnDestroy } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as searchPagedAction from 'app/actions/search-paged.actions';
import * as searchPreviewAction from 'app/actions/search-preview.actions';
import * as searchFolderToAttachActions from 'app/actions/search-folder-to-attach.actions';
import * as folderActions from 'app/actions/folder.actions';


@Component({
  selector: 'app-metadata-folder-search-results',
  templateUrl: './metadata-folder-search-results.component.html',
  styleUrls: ['./metadata-folder-search-results.component.scss']
})
export class MetadataFolderSearchResultsComponent implements OnInit, OnDestroy {

  subscriberCurrentDocumentId: Subscription;
  currentDocumentId$: Observable<string>;
  currentDocumentId: string;

  private uploading$: Observable<Boolean>;

  private searching$: Observable<boolean>;
  private error$: Observable<any>;
  private errorAttach$: Observable<Error>;

  // private searchType$: Observable<string>;
  private searchResult$: Observable<any>;
  private folderToAttach$: Observable<any>;

  private subscribeFolderToAttach: Subscription;
  // private subscribeActiveRoute: Subscription;
  // private subscribeActiveRouteData: Subscription;
  folderId;

  constructor(
    private store: Store<fromRoot.State>,
    private folderEffect: FolderEffect,
    public activeModal: NgbActiveModal
  ) {

    this.currentDocumentId$ = store.select(fromRoot.getSearchPreviewResultId);
    this.subscriberCurrentDocumentId = this.currentDocumentId$.subscribe(currentDocumentId => this.currentDocumentId = currentDocumentId);

    this.uploading$ = store.select(fromRoot.getSearchFolderToAttachUploading);

    this.searching$ = store.select(fromRoot.getSearchPagedLoading);
    this.searchResult$ = store.select(fromRoot.getSearchPagedResults);

    this.error$ = store.select(fromRoot.getSearchPagedError);
    this.errorAttach$ = store.select(fromRoot.getFolderUpdateError);

    this.folderToAttach$ = store.select(fromRoot.getSearchFolderToAttachResultId);
    this.subscribeFolderToAttach = this.folderToAttach$.subscribe( folderId => this.folderId = folderId );
    // this.store.dispatch(new searchPreviewAction.InitSearchResultsSearchPreview());
  }

  attachFolder(folderId: string) {
    // console.log('attach', this.folderId);
    if (this.currentDocumentId && this.folderId) {
      this.folderEffect.postFolderDocuments(this.folderId, [this.currentDocumentId]);
    }
  }

  close() {
    this.store.dispatch(new folderActions.InitUpdateFolder());

    this.activeModal.close();
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscriberCurrentDocumentId.unsubscribe();
    this.subscribeFolderToAttach.unsubscribe();
  }

}
