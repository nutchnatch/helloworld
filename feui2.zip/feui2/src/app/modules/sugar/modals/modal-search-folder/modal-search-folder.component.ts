import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-search-folder',
  templateUrl: './modal-search-folder.component.html',
  styleUrls: ['./modal-search-folder.component.scss']
})
export class ModalSearchFolderComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }

}
