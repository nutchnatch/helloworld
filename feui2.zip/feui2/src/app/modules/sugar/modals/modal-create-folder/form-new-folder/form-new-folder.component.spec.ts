import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormNewFolderComponent } from './form-new-folder.component';

describe('FormNewFolderComponent', () => {
  let component: FormNewFolderComponent;
  let fixture: ComponentFixture<FormNewFolderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormNewFolderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormNewFolderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
