import { DocumentAttachedToFoldersResult } from 'app/models/document-attached-to-folder-result';
import { Subscription } from 'rxjs/Subscription';
import { FolderCreationResult } from 'app/models/folder-creation-result';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { FolderEffect } from 'app/effects/folder.effect';
import { Folder } from 'app/models/folder';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit, OnDestroy } from '@angular/core';

import * as FolderState from 'app/states/folder.state';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import * as fromRoot from 'app/reducers';
import * as folderAction from 'app/actions/folder.actions';


export class State extends FolderState.State { }

// this.documentEffect.getDocumentsById(docid);
@Component({
  selector: 'app-form-new-folder',
  templateUrl: './form-new-folder.component.html',
  styleUrls: ['./form-new-folder.component.scss']
})
export class FormNewFolderComponent implements OnInit, OnDestroy {
  errorUploading$: Observable<{}>;

  uploading$: Observable<Boolean>;
  subscribeActiveRoute: Subscription;
  subscriptionResult: Subscription;

  private metadataForm: FormGroup;
  private extraMetadataForm: FormGroup;
  private creatingFolderCreating$: Observable<Boolean>;
  private creatingFolderError$: Observable<Error>;
  private creatingFolderResult$: Observable<FolderCreationResult>;
  private attachSuccess$: Observable<DocumentAttachedToFoldersResult>;

  folderModal: Folder = FolderState.initialStateFolder;
  selectedFolderType: string;

  private folderId: string;

  private currentDocumentId$: Observable<string>;
  private currentDocumentId: string;
  private subscriptionDocumentId: Subscription;

  constructor(
    private store: Store<fromRoot.State>,
    private formBuilder: FormBuilder,
    public activeModal: NgbActiveModal,
    private folderEffect: FolderEffect,

  ) {

    this.extraMetadataForm = this.formBuilder.group({});
    this.metadataForm = formBuilder.group(this.folderModal);

    this.creatingFolderCreating$ = store.select(fromRoot.getFolderCreateCreating);
    this.creatingFolderError$ = store.select(fromRoot.getFolderCreateError);
    this.creatingFolderResult$ = store.select(fromRoot.getFolderCreateResult);

    this.subscriptionResult = this.creatingFolderResult$.subscribe( result => {
      if (result) { this.folderId = result.folderId; }
    });

    this.currentDocumentId$ = store.select(fromRoot.getSearchPreviewResultId);
    this.subscriptionDocumentId = this.currentDocumentId$.subscribe( currentDocumentId => {
      if ( currentDocumentId ) {  this.currentDocumentId = currentDocumentId; }
    });

    this.errorUploading$ = store.select(fromRoot.getFolderUpdateError);
    this.uploading$ = store.select(fromRoot.getSearchFolderToAttachUploading);
    this.attachSuccess$ = store.select(fromRoot.getSearchFolderToAttachSuccess);

  }

  removeControls(fg: FormGroup) {
    Object.keys(fg.controls).map(fc => this.extraMetadataForm.removeControl(fc));
  }

  save(metadataForm, extraMetadataForm) {

    const formModel = Object.assign({}, metadataForm, {
      tagList: Object.keys(extraMetadataForm).map(function (key) {
        // return { 'tagName': extraMetadataForm[key], 'tagValue': key };
        return { 'tagValue': extraMetadataForm[key], 'tagName': key };

      }),
      folderTypeId: this.selectedFolderType
    });
    // console.log(this.metadataForm, this.extraMetadataForm);
    // console.log(formModel);
    // this.folderEffect.putFolderById(formModel.id, formModel);
    this.folderEffect.postFolders(formModel);
    // this.store.dispatch(new searchPagedAction.PutSearchResultsSearchByID(document));
  }

  updateDocTypeId(folderTypeId) {
    this.selectedFolderType = folderTypeId;
  }

  cancel() {
    // this.store.dispatch(new folderActions.InitUpdateFolder());
    this.store.dispatch(new folderAction.InitCreateFolder());
    this.activeModal.close();
  }

  attachFolder() {
    // console.log('attach', this.currentDocumentId);
    if (this.currentDocumentId && this.folderId) {
      this.folderEffect.postFolderDocuments(this.folderId, [this.currentDocumentId]);
    }
  }

  ngOnInit() {
    this.removeControls(this.extraMetadataForm);
    // this.subscribeActiveRoute = this.activatedRouter.children[0]..paramsMap.subscribe((params: Params) => {
    //   // this.currentDocumentId = params.get('docid');
    //   console.log('.....', params)
    // });
  }

  ngOnDestroy() {
    this.subscriptionResult.unsubscribe();
    this.subscriptionDocumentId.unsubscribe();
  }

}
