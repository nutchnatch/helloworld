import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-create-folder',
  templateUrl: './modal-create-folder.component.html',
  styleUrls: ['./modal-create-folder.component.scss']
})
export class ModalCreateFolderComponent implements OnInit {

  constructor(

  ) { }

  ngOnInit() {
  }

}
