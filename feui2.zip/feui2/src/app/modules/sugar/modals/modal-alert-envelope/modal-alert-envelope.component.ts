import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-alert-envelope',
  templateUrl: './modal-alert-envelope.component.html',
  styleUrls: ['./modal-alert-envelope.component.scss']
})
export class ModalAlertEnvelopeComponent implements OnInit {

  modalWarning;

  constructor(
    public activeModal: NgbActiveModal
  ) { }

  ngOnInit() {
  }

}
