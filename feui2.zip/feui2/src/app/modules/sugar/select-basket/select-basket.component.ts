import { TaskEffect } from 'app/effects/task.effect';
import { Subscription } from 'rxjs/Subscription';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { BasketEffect } from './../../../effects/basket.effect';
import { Component, OnInit, OnDestroy, Input, Output, EventEmitter } from '@angular/core';
import { Basket } from 'app/models/basket';
import { Router, ActivatedRoute, ParamMap, RouterStateSnapshot } from '@angular/router';


import * as fromRoot from 'app/reducers';
import * as taksAction from 'app/actions/task.actions';


@Component({
  selector: 'app-select-basket',
  templateUrl: './select-basket.component.html',
  styleUrls: ['./select-basket.component.scss']
})
export class SelectBasketComponent implements OnInit, OnDestroy {
  subscriberTransferSuccess: Subscription;
  subscribeActiveRouteQueryParams: Subscription;

  @Input() toChangeBasket: boolean;
  @Input() currentTaskId: string;
  // @Output() changeBasketType: EventEmitter<string> = new EventEmitter<string>();

  subscribeBasketResults: Subscription;
  subscriberPageSize: Subscription;

  private basketTypes$: Observable<Basket>;
  private currentLang$: Observable<string>;
  private pageSize$: Observable<number>;

  private transferingTask$: Observable<boolean>;
  private transferingError$: Observable<Error>;
  private transferingSuccess$: Observable<string>;

  private subscribeActiveRoute: Subscription;

  private routerSnapshot: RouterStateSnapshot;

  currentBasketId: string;
  pageSize: number;
  firstTaskId: string;
  selectedId: string;
  toChange: boolean;

  constructor(
    private store: Store<fromRoot.State>,
    private basketEffect: BasketEffect,
    private taskEffect: TaskEffect,
    private router: Router,
    private activatedRouter: ActivatedRoute,
  ) {

    this.basketTypes$ = store.select(fromRoot.getBasketsResult);
    // tslint:disable-next-line:max-line-length
    this.subscribeBasketResults = this.basketTypes$.subscribe( basketResult => {
      if (basketResult) {
        this.firstTaskId = basketResult[0].basketId;
      }
    });


    this.currentLang$ = store.select(fromRoot.getCurrentLanguage);
    this.pageSize$ = store.select(fromRoot.getAppConfigPageSize);
    this.subscriberPageSize = this.pageSize$.subscribe( value => this.pageSize = value);

    this.transferingTask$ = store.select(fromRoot.getTasksTransferLoading);
    this.transferingError$ = store.select(fromRoot.getTasksTransferError);

    this.transferingSuccess$ = store.select(fromRoot.getTasksTransferResult);
    this.subscriberTransferSuccess = this.transferingSuccess$.subscribe( result => {
      if ( result ) {
        this.store.dispatch(new taksAction.InitTransferTask());

        this.router.navigate(['app/refresh', { url: this.router.routerState.snapshot.url }]);
      }
    });

  }

  onSearch(basketId: string) {
    this.selectedId = basketId;
    const baseUrl = 'app/basket/' + basketId; // + searchQueryString.value.type.toLowerCase();
    if (!this.toChange) {
      this.router.navigate([ baseUrl, Object.assign( {}, { pageNumber: 1, pageSize: this.pageSize }) ]);
    }
  }

  onUpdate(basketId: string) {
    // console.log(this.selectedId)
    this.taskEffect.putTaskByIdTransfer(this.currentBasketId, this.selectedId);
    // this.changeBasketType.emit(this.selectedId);
  }


  ngOnInit() {

    this.store.dispatch(new taksAction.InitTransferTask());

    this.toChange = this.toChangeBasket;

    this.basketEffect.getBaskets();

    this.subscribeActiveRoute = this.activatedRouter.paramMap.subscribe((paramsMap: ParamMap | any) => {
      if ( !paramsMap.get('id') && this.firstTaskId  ) {
        // this.basketEffect.getBasketsTasksById(this.firstTaskId, paramsMap.params);
        this.selectedId = this.firstTaskId;
        const baseUrl = 'app/basket/' + this.firstTaskId; // + searchQueryString.value.type.toLowerCase();
        this.router.navigate([ baseUrl, Object.assign( {}, { pageNumber: 1, pageSize: this.pageSize }) ]);
      } else {
        this.selectedId = paramsMap.get('id');

      }
    });

    this.subscribeActiveRouteQueryParams = this.activatedRouter.queryParamMap.subscribe((paramsMap: ParamMap | any) => {
      if ( paramsMap.get('taskId') ) {
        this.currentBasketId = paramsMap.get('taskId');
        this.selectedId = this.currentTaskId;
      }
    });
  }



  ngOnDestroy() {
    this.subscribeActiveRoute.unsubscribe();
    this.subscribeBasketResults.unsubscribe();
  }

}
