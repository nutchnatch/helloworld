import { Subscription } from 'rxjs/Subscription';
import { Envelope } from './../../../models/envelope';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { DocumentEffect } from 'app/effects/document.effect';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { element } from 'protractor';
import { DocumentLite } from './../../../models/document-lite';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as documentsFilterAction from 'app/actions/documents-filter.actions';


@Component({
  selector: 'app-envelope-files-list',
  templateUrl: './envelope-files-list.component.html',
  styleUrls: ['./envelope-files-list.component.scss']
})
export class EnvelopeFilesListComponent implements OnInit, OnDestroy {
  subscribeActiveRouteQueryParams: Subscription;


  listOfDocument$: Observable<Array<string>>;
  listOfDocumentObject$: Observable<Array<DocumentLite>>;
  listOfDocumentObjectSelected$: Observable<Array<DocumentLite>>;
  selectedDocument$: Observable<string>;
  envelopeState$: Observable<Envelope>;
  filterOn$: Observable<any>;

  envelopeStateID: string;
  subscribesEnvelopeStateID: Subscription;

  listOfDocument;
  subscribesListOfDocument: Subscription;

  taskId: string;

  constructor(
    private store: Store<fromRoot.State>,
    private documentEffect: DocumentEffect,
    private router: Router,
    private activatedRouter: ActivatedRoute,
    ) {


    this.envelopeState$ = store.select(fromRoot.getEnvelopeFirstResult);
    this.subscribesEnvelopeStateID = this.envelopeState$.subscribe( envelope => this.envelopeStateID = envelope && envelope['id'] );

    this.listOfDocument$ = store.select(fromRoot.getEnvelopeListDocuments);
    this.subscribesListOfDocument = this.listOfDocument$.subscribe( list => list && this.initForm(list));

    this.listOfDocumentObject$ = store.select(fromRoot.getDocumentsFilterList);
    this.listOfDocumentObjectSelected$ = store.select(fromRoot.getDocumentsFilterListSelected);

    this.selectedDocument$ = store.select(fromRoot.getDocumentsFilterSelected);

    this.filterOn$ = store.select(fromRoot.getDocumentsFilterMultiple);
  }

  initForm(list) {
    const listOfDocument = list.map(element => Object.assign({...element} , { selected: false }));
    this.store.dispatch( new documentsFilterAction.PutDocumentSelecedList( listOfDocument ) );
  }

  updateSelected(document) {
    this.store.dispatch( new documentsFilterAction.PutDocumentSelecedListById( document.id ) );
    this.store.dispatch( new documentsFilterAction.PutSelectedDocumentSelecedList( document.id ) );
  }

  documentSelect(document) {

    this.store.dispatch( new documentsFilterAction.PutDocumentSeleced( document.id ) );
    if (this.taskId) {
      this.router.navigate(['/app/envelope', this.envelopeStateID, document.id ], { queryParams: { taskId: this.taskId } });
    } else {
      this.router.navigate(['/app/envelope', this.envelopeStateID, document.id ] );

    }
    // this.documentEffect.getDocumentsById(document.id);
  }

  ngOnInit() {
    this.subscribeActiveRouteQueryParams = this.activatedRouter.queryParamMap.subscribe((paramsMap: ParamMap | any) => {
      // this.currentBasketId = paramsMap.get('taskId');
      if (paramsMap.get('taskId')) {
        this.taskId = paramsMap.get('taskId');
      }
    });

  }

  ngOnDestroy() {
    this.subscribesEnvelopeStateID.unsubscribe();
    this.subscribesListOfDocument.unsubscribe();
  }

}
