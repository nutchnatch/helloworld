import { Document } from 'app/models/document';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';


@Component({
  selector: 'app-envelope-arender-iframe',
  templateUrl: './envelope-arender-iframe.component.html',
  styleUrls: ['./envelope-arender-iframe.component.scss']
})
export class EnvelopeArenderIframeComponent implements OnInit {

  private multiDocumentFilter$: Observable<boolean>;
  private documentsResult$: Observable<Document>;
  private documentList$: Observable<Array<Document>>;
  private documentSelected$: Observable<string>;

  constructor(
    private store: Store<fromRoot.State>,
  ) {

    this.multiDocumentFilter$ = store.select(fromRoot.getDocumentsFilterMultiple);
    this.documentList$ = store.select(fromRoot.getDocumentsFilterListSelected);
    this.documentSelected$ = store.select(fromRoot.getDocumentsFilterSelected);
    this.documentsResult$ = store.select(fromRoot.getDocumentsResult);
  }

  ngOnInit() {
  }

}
