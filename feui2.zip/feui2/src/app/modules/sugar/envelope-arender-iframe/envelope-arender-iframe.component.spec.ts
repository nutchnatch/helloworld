import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnvelopeArenderIframeComponent } from './envelope-arender-iframe.component';

describe('EnvelopeArenderIframeComponent', () => {
  let component: EnvelopeArenderIframeComponent;
  let fixture: ComponentFixture<EnvelopeArenderIframeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnvelopeArenderIframeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnvelopeArenderIframeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
