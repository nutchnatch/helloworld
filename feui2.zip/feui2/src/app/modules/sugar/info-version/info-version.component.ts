import { Observable } from 'rxjs/Observable';
import { InfoEffect } from './../../../effects/info.effect';
import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
@Component({
  selector: 'app-info-version',
  templateUrl: './info-version.component.html',
  styleUrls: ['./info-version.component.scss']
})
export class InfoVersionComponent implements OnInit {
  private infoVersion$: Observable<String>;

  constructor(
    store: Store<fromRoot.State>,
    private infoEffect: InfoEffect,

  ) {

    this.infoVersion$ = store.select(fromRoot.getInfoVersion);
  }

  ngOnInit() {
    this.infoEffect.getInfoVersion();
  }

}
