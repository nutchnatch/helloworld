import { Sidebar } from 'app/models/sidesbars-config';
import { Observable } from 'rxjs/Observable';
import { Component, Input, OnDestroy } from '@angular/core';
import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as layoutActions from 'app/actions/layout.actions';
import { Folder } from 'app/models/folder';

@Component({
  selector: 'app-folder-metadata-sidebar',
  templateUrl: './folder-metadata-sidebar.component.html',
  styleUrls: ['./folder-metadata-sidebar.component.scss']
})
export class FolderMetadataSidebarComponent implements OnDestroy {

  private sidebarConfig$: Observable<Sidebar>;
  private folderState$: Observable<Folder>;

  constructor(
    private store: Store<fromRoot.State>
  ) {

    this.sidebarConfig$ = store.select(fromRoot.getSideBarParams);
    this.folderState$ = store.select(fromRoot.getFolderFirstResult);

  }

  ngOnDestroy() {
    this.store.dispatch(new layoutActions.PutFromSearchAction(null));
  }
}
