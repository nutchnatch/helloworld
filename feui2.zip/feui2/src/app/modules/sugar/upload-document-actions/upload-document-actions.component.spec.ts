import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadDocumentActionsComponent } from './upload-document-actions.component';

describe('UploadDocumentActionsComponent', () => {
  let component: UploadDocumentActionsComponent;
  let fixture: ComponentFixture<UploadDocumentActionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadDocumentActionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadDocumentActionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
