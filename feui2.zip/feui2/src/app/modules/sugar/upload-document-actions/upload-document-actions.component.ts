import { EnvelopeCreationResult } from './../../../models/envelope-creation-result';
import { EnvelopeEffect } from 'app/effects/envelope.effect';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { Subscription } from 'rxjs/Subscription';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Input } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as uploadDocumentsAction from 'app/actions/upload-documents.actions';
import { Router } from '@angular/router';

@Component({
  selector: 'app-upload-document-actions',
  templateUrl: './upload-document-actions.component.html',
  styleUrls: ['./upload-document-actions.component.scss']
})
export class UploadDocumentActionsComponent implements OnInit, OnDestroy {


  @Input() put: Boolean;

  private uploadDocument$: Observable<Array<File>>;
  private error$: Observable<Error>;
  private isUpLoading$: Observable<Boolean>;
  private result$: Observable<Array<EnvelopeCreationResult>>;

  private currentEnvelope$: Observable<any>;

  subsribeDocument: Subscription;
  subsribeResults: Subscription;
  subscribeCurrentEnvelope: Subscription;

  uploadDocument;
  formData: FormData;
  currentEnvelopeID: string;

  constructor(
    private store: Store<fromRoot.State>,
    private envelopeEffect: EnvelopeEffect,
    private router: Router

  ) {
    this.uploadDocument$ = store.select(fromRoot.getUploadDocumentsList);

    this.subsribeDocument = this.uploadDocument$.subscribe((files) => this.uploadDocument = files);

    this.error$ = store.select(fromRoot.getUploadDocumentsError);
    this.isUpLoading$ = store.select(fromRoot.getUploadDocumentsLoading);

    this.result$ = store.select(fromRoot.getUploadDocumentsResult);

    this.subsribeResults = this.result$.subscribe( result => {
      if ( result && result.length > 0 ) {
        // console.log(result[0].envelopeId)
        this.router.navigate(['app/envelope', result[0].envelopeId]);
      }

      if ( result && result.length > 0 && this.put ) {
        this.router.navigate(['app/refresh', { url: 'app/envelope/' + result[0].envelopeId }]);
      }
      // this.router.navigate(['/envelope', d]);
    });

  }

  removeAll() {
    this.store.dispatch(new uploadDocumentsAction.InitDocumentList());
  }

  upload() {
    if ( !this.put && !this.subscribeCurrentEnvelope ) {
      this.envelopeEffect.postEnvelopes(this.formDataFormarter());
    } else {
      this.envelopeEffect.postEnvelopesDocuments(this.currentEnvelopeID, this.formDataFormarter());
    }

  }

  formDataFormarter(): FormData {
    this.formData = new FormData();
    this.uploadDocument.map((file, i) => { this.formData.append('fileList', file, file.name); });
    return this.formData;
  }

  ngOnInit() {
    // console.log('......', this.put);
    if ( this.put ) {
      this.currentEnvelope$ = this.store.select(fromRoot.getEnvelopeFirstResult);
      this.subscribeCurrentEnvelope = this.currentEnvelope$.subscribe( currentEnvelope => this.currentEnvelopeID = currentEnvelope.id );
    }
   }

  ngOnDestroy() {
    this.subsribeDocument.unsubscribe();
    this.subsribeResults.unsubscribe();
    if ( this.put && this.subscribeCurrentEnvelope) { this.subscribeCurrentEnvelope.unsubscribe(); }
  }

}
