import { MetadataBar } from 'app/models/sidesbars-config';
import { Observable } from 'rxjs/Observable';
import { Component, Input } from '@angular/core';
import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as layoutAction from 'app/actions/layout.actions';

@Component({
  selector: 'app-metadata-sidebar',
  templateUrl: './metadata-sidebar.component.html',
  styleUrls: ['./metadata-sidebar.component.scss']
})
export class MetadataSidebarComponent  {

  private metadataBarConfig$: Observable<MetadataBar>;
  private searchResult$: Observable<Document>;
  private searchType$: Observable<string>;

  constructor(
    store: Store<fromRoot.State>
  ) {
    this.metadataBarConfig$ = store.select(fromRoot.getMetadataBarParams);
    this.searchResult$ = store.select(fromRoot.getSearchPreviewResults);
    this.searchType$ = store.select(fromRoot.getSearchPagedType);
  }
}
