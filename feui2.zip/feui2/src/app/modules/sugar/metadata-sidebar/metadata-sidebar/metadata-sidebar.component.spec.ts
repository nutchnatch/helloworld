import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MetadataSidebarComponent } from './metadata-sidebar.component';

describe('MetadataSidebarComponent', () => {
  let component: MetadataSidebarComponent;
  let fixture: ComponentFixture<MetadataSidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MetadataSidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MetadataSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
