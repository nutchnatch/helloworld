import { QueryParams } from 'app/models/paged';
import { DocumentEffect } from 'app/effects/document.effect';
import { Subscription } from 'rxjs/Subscription';
import { TagElement } from 'app/models/tag-element';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store } from '@ngrx/store';
import { Document } from 'app/models/document';
import { Error } from 'app/models/error';

import 'rxjs/add/operator/debounceTime';

import {
  FormsModule,
  ReactiveFormsModule,
  FormGroup,
  FormArray,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';

import * as fromRoot from 'app/reducers';
import * as searchPreviewActions from 'app/actions/search-preview.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';
import * as documentsActions from 'app/actions/documents.actions';
import { TagClone } from 'app/models/tag';
import { NgbDateStruct, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { DateParserFormaterServices } from 'app/services/date-parser-formater/date-parser-formater.service';

@Component({
  selector: 'app-metadata-document-form',
  templateUrl: './metadata-document-form.component.html',
  styleUrls: ['./metadata-document-form.component.scss']
})
export class MetadataDocumentFormComponent implements OnInit, OnDestroy {

  private metadataForm: FormGroup;
  private extraMetadataForm: FormGroup;
  private searchResult$: Observable<Document>;
  private isUpdateting$: Observable<Boolean>;
  private langs$: Observable<Array<any>>;
  private error$: Observable<Error>;
  private updated$: Observable<any>;
  private lastQuery$: Observable<QueryParams>;
  private confidentialLevel$: Observable<Array<any>>;


  private subscriberSearchResult: Subscription;
  private subscriberLastQuery: Subscription;
  private subscriberUpdateResult: Subscription;
  private copiedTags$: Observable<Array<TagClone>>;


  lastQuery: QueryParams;
  selectedDocType: string;
  dpDate; // = {year: 2000, month: 2};
  parseDate;

  constructor(
    private store: Store<fromRoot.State>,
    private formBuilder: FormBuilder,
    private documentEffect: DocumentEffect,
    private dateToUCT: DateParserFormaterServices,
    private dateParserFormatter: NgbDateParserFormatter
  ) {

    this.extraMetadataForm = this.formBuilder.group({});

    // this.metadataForm = formBuilder.group(new Document);
    this.searchResult$ = store.select(fromRoot.getSearchPreviewResults);
    this.subscriberSearchResult = this.searchResult$.subscribe(document => {

      this.store.dispatch(new documentsActions.InitUpdateDocument());

      if (document && document.id) {
        // this.metadataForm = formBuilder.group(new Document);
        this.selectedDocType = document.docTypeId;
        this.metadataForm = this.formBuilder.group(
          Object.assign({}, document, { tagList: null, folderList: null }),
        );
        this.dpDate = dateParserFormatter.parse(this.metadataForm.value.retentionStartDate);
        this.parseDate = this.metadataForm.value.retentionStartDate;
        this.removeControls(this.extraMetadataForm);
      }

    });

    this.isUpdateting$ = store.select(fromRoot.getDocumentsUpdating);
    this.error$ = store.select(fromRoot.getDocumentsUpdateError);

    this.lastQuery$ = store.select(fromRoot.getSearchPagedQuery);

    this.updated$ = store.select(fromRoot.getDocumentsUpdateResult);
    this.subscriberLastQuery = this.lastQuery$.subscribe(lastQuery => this.lastQuery = lastQuery);

    this.subscriberUpdateResult = this.updated$.subscribe(id => {
      if (id && this.lastQuery) {
        this.documentEffect.getDocuments(this.lastQuery);
      }

      if (id && !this.lastQuery) {
        this.documentEffect.getDocumentsById(id.documentId);
        // this.documentEffect.getDocuments(id.envelopeId);
      }
    });

    this.copiedTags$ = store.select(fromRoot.getAppConfigCopiedTags);
    this.confidentialLevel$ = store.select(fromRoot.getAppConfigConfidentialLevels);

    this.langs$ = store.select(fromRoot.getAppConfigLangISO);
    // this.langs$.subscribe( v => console.log(v));

  }

  removeControls(fg: FormGroup) {
    Object.keys(fg.controls).map(fc => this.extraMetadataForm.removeControl(fc));
  }

  update(document) {
    this.store.dispatch(new searchPreviewActions.PutSearchResultsSearchPreview(document));
  }

  updateDocTypeId(docTypeId) {
    // console.log(docTypeId);
    this.selectedDocType = docTypeId;
    // Object.assign({}, this.metadataForm, { docTypeId: docTypeId });
  }

  updateToModel(newValue) {
    this.parseDate = this.dateToUCT.ngbDatepickerUTCDate(newValue);
  }

  save(metadataForm, extraMetadataForm) {

    const formModel = Object.assign({}, metadataForm, {
      tagList: Object.keys(extraMetadataForm).map(function (key) {
        // return { 'tagName': extraMetadataForm[key], 'tagValue': key };
        return { 'tagValue': extraMetadataForm[key], 'tagName': key };
      }),
      docTypeId: this.selectedDocType
    });

    const formDateFINAL = Object.assign({}, formModel, {
      retentionStartDate: this.parseDate // this.dateToUCT.ngbDatepickerUTCDate(this.metadataForm.value.retentionStartDate),
      // retentionEndDate: this.dateToUCT.ngbDatepickerUTCDate(this.metadataForm.value.retentionEndDate),
    });
    // console.log(formDateFINAL, this.parseDate)
    this.documentEffect.putDocumentsById(formModel.id, formDateFINAL);
    // this.store.dispatch(new searchPagedAction.PutSearchResultsSearchByID(document));
  }

  cancel() {
    // this.store.dispatch(new searchPreviewActions.InitSearchResultsSearchPreview());
  }

  ngOnInit() {
    // this.initSubcrition();
    // this.store.dispatch(new searchPagedAction.PutSearchResultsSearchByID())
  }

  ngOnDestroy() {
    this.subscriberSearchResult.unsubscribe();
    this.subscriberUpdateResult.unsubscribe();
    this.subscriberLastQuery.unsubscribe();

  }

}
