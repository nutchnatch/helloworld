import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MetadataSidebarEnvelopComponent } from './metadata-sidebar-envelop.component';

describe('MetadataSidebarEnvelopComponent', () => {
  let component: MetadataSidebarEnvelopComponent;
  let fixture: ComponentFixture<MetadataSidebarEnvelopComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MetadataSidebarEnvelopComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MetadataSidebarEnvelopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
