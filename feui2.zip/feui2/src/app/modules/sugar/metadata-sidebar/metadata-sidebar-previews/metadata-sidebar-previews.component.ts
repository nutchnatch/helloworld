import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';


import * as fromRoot from 'app/reducers';
import * as searchPreviewActions from 'app/actions/search-preview.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';

@Component({
  selector: 'app-metadata-sidebar-previews',
  templateUrl: './metadata-sidebar-previews.component.html',
  styleUrls: ['./metadata-sidebar-previews.component.scss']
})
export class MetadataSidebarPreviewsComponent implements OnInit {

  private searchType$: Observable<string>;

  constructor(
    private store: Store<fromRoot.State>,
  ) {

    this.searchType$ = store.select(fromRoot.getSearchPreviewType);
   }

  ngOnInit() {
  }

}
