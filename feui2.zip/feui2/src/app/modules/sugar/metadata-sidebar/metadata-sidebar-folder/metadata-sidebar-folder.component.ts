import { Folder } from 'app/models/folder';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { Component, OnInit } from '@angular/core';

import * as fromRoot from 'app/reducers';

@Component({
  selector: 'app-metadata-sidebar-folder',
  templateUrl: './metadata-sidebar-folder.component.html',
  styleUrls: ['./metadata-sidebar-folder.component.scss']
})
export class MetadataSidebarFolderComponent implements OnInit {

  folderState$: Observable<Folder>;

  constructor(
    private store: Store<fromRoot.State>,
  ) {

    this.folderState$ = store.select(fromRoot.getFolderFirstResult);
  }

  ngOnInit() {
  }

}
