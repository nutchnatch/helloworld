import { QueryParams } from 'app/models/paged';
import { EnvelopeEffect } from './../../../../effects/envelope.effect';
import { Subscription } from 'rxjs/Subscription';
import { Envelope } from 'app/models/envelope';

import { TagElement } from 'app/models/tag-element';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store } from '@ngrx/store';

import 'rxjs/add/operator/debounceTime';

import {
  FormsModule,
  ReactiveFormsModule,
  FormGroup,
  FormArray,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';

import * as fromRoot from 'app/reducers';
import * as searchPreviewActions from 'app/actions/search-preview.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';
import * as envelopeActions from 'app/actions/envelope.actions';

@Component({
  selector: 'app-metadata-envelope-form',
  templateUrl: './metadata-envelope-form.component.html',
  styleUrls: ['./metadata-envelope-form.component.scss']
})
export class MetadataEnvelopeFormComponent implements OnInit, OnDestroy {

  private metadataForm: FormGroup;
  private extraMetadataForm: FormGroup;
  private searchResult$: Observable<Envelope>;
  private isUpdateting$: Observable<Boolean>;
  private error$: Observable<Error>;
  private updated$: Observable<any>;
  private lastQuery$: Observable<QueryParams>;

  private subscriberSearchResult: Subscription;
  private subscriberUpdateResult: Subscription;
  private subscriberLastQuery: Subscription;

  lastQuery: QueryParams;
  selecteEnvType: string;

  constructor(
    private store: Store<fromRoot.State>,
    private formBuilder: FormBuilder,
    private envelopeEffect: EnvelopeEffect
  ) {

    this.extraMetadataForm = this.formBuilder.group({});

    // this.metadataForm = formBuilder.group(new Document);
    this.searchResult$ = store.select(fromRoot.getSearchPreviewResults);
    this.subscriberSearchResult = this.searchResult$.subscribe(envelope => {
      this.store.dispatch(new envelopeActions.InitUpdateEnvelope());

      const envelopeNew = Object.assign(Object.assign({}, envelope, { tagList: null, listOfDocumentId: null }));

      if (envelope && envelopeNew.id) {
        // this.metadataForm = formBuilder.group(new Document);
        this.selecteEnvType = envelopeNew.envTypeId;
        // console.log(Object.assign({}, envelope, { tagList: null, listOfDocumentId: null }))
        this.metadataForm = this.formBuilder.group(envelopeNew);
        this.removeControls(this.extraMetadataForm);
      }

    });

    this.isUpdateting$ = store.select(fromRoot.getEnvelopeUpdating);
    this.error$ = store.select(fromRoot.getEnvelopeUpdateError);

    this.lastQuery$ = store.select(fromRoot.getSearchPagedQuery);

    this.updated$ = store.select( fromRoot.getEnvelopeUpdateResult);
    this.subscriberLastQuery = this.lastQuery$.subscribe( lastQuery => this.lastQuery = lastQuery );

    this.subscriberUpdateResult = this.updated$.subscribe( id => {
      if (id && this.lastQuery) {
        this.envelopeEffect.getEnvelopes(this.lastQuery);
      }
    });
  }

  removeControls(fg: FormGroup) {
    Object.keys(fg.controls).map(fc => this.extraMetadataForm.removeControl(fc));
  }

  update(envelope) {
    this.store.dispatch(new searchPreviewActions.PutSearchResultsSearchPreview(envelope));
  }

  updateDocTypeId(envTypeId) {
    this.selecteEnvType = envTypeId;
    // Object.assign({}, this.metadataForm, { docTypeId: docTypeId });
  }

  save(metadataForm, extraMetadataForm) {

    const formModel = Object.assign({}, metadataForm, {
      tagList: Object.keys(extraMetadataForm).map(function (key) {
        // return { 'tagName': extraMetadataForm[key], 'tagValue': key };
        return { 'tagValue': extraMetadataForm[key], 'tagName': key };

      }),
      envTypeId: this.selecteEnvType
    });
    // console.log(this.metadataForm, this.extraMetadataForm);
    // console.log(formModel);
    this.envelopeEffect.putEnvelopeById(formModel.id, formModel);
    // this.store.dispatch(new searchPagedAction.PutSearchResultsSearchByID(document));
  }

  cancel() {
    // this.store.dispatch(new searchPreviewActions.InitSearchResultsSearchPreview());
  }

  ngOnInit() {
    // this.initSubcrition();
    // this.store.dispatch(new searchPagedAction.PutSearchResultsSearchByID())
  }

  ngOnDestroy() {
    this.subscriberSearchResult.unsubscribe();
    this.subscriberUpdateResult.unsubscribe();
    this.subscriberLastQuery.unsubscribe();
  }

}
