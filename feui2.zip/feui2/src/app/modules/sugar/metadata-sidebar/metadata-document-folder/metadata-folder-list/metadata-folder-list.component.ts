import { DocumentEffect } from 'app/effects/document.effect';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { DocumentAttachedToFoldersResult } from './../../../../../models/document-attached-to-folder-result';
import { FolderEffect } from 'app/effects/folder.effect';
import { Subscription } from 'rxjs/Subscription';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Document } from 'app/models/document';


import * as fromRoot from 'app/reducers';
// import * as searchPreviewAction from 'app/actions/search-preview.actions';
import * as folderAction from 'app/actions/folder.actions';

@Component({
  selector: 'app-metadata-folder-list',
  templateUrl: './metadata-folder-list.component.html',
  styleUrls: ['./metadata-folder-list.component.scss']
})
export class MetadataFolderListComponent implements OnInit, OnDestroy {
  subscriberCurrentDocumentId: Subscription;
  currentDocumentId$: Observable<{}>;
  subscribeActiveRoute: Subscription;

  private documentsResult$: Observable<Document>;
  private subscribeDocumentResult: Subscription;

  private deleting$: Observable<Boolean>;
  private deletingError$: Observable<Boolean>;
  private deletingResult$: Observable<DocumentAttachedToFoldersResult>;

  private subscribeDeletingResult: Subscription;

  private currentId: string;
  private currentDocumentIdToDeleting: string;
  private currentDocumentId;

  constructor(
    private store: Store<fromRoot.State>,
    private folderEffect: FolderEffect,
    private activatedRouter: ActivatedRoute,
    private documentEffect: DocumentEffect,

  ) {

    this.documentsResult$ = store.select(fromRoot.getDocumentsResult);
    // this.subscribeDocumentResult = this.documentsResult$.subscribe( document => {
    //   if (document) {
    //     console.log(document);
    //     // this.store.dispatch(new searchPreviewAction.PutSearchResultsSearchPreview(document));
    //   }
    // });

    this.deleting$ = store.select(fromRoot.getFolderDeletingDeleting);
    this.deletingError$ = store.select(fromRoot.getFolderDeletingError);


    this.deletingResult$ = store.select(fromRoot.getFolderDeletingResult);
    this.currentDocumentId$ = store.select(fromRoot.getSearchPreviewResultId);
    this.subscriberCurrentDocumentId = this.currentDocumentId$.subscribe( currentDocumentId => this.currentDocumentId = currentDocumentId);


    this.subscribeDeletingResult = this.deletingResult$.subscribe( result => {
      if (result ) {
        // console.log('id -> ' , success.documentIdArray[0])
        // console.log(this.currentDocumentId)
        this.documentEffect.getDocumentsById(this.currentDocumentId);
        // if (this.modalSearch) { this.modalSearch.close(); }
      }
    });
  }

  onRemove(id) {
    this.currentDocumentIdToDeleting = id;
    // console.log( this.currentDocumentId, id)
    if ( this.currentDocumentId && id) {
      this.folderEffect.deleteFolderDocuments( id, [ this.currentDocumentId] );
    }
    // this.folderEffect.deleteFolderDocuments()
  }

  ngOnInit() {

    this.subscribeActiveRoute = this.activatedRouter.paramMap.subscribe((params: ParamMap) => {
      // console.log(params.get('id'))
      this.currentId = params.get('id');
      // this.folderEffect.getFoldersById(params.get('id'));
    });
  }

  ngOnDestroy() {
    this.store.dispatch(new folderAction.InitDeleteFolder());
    this.subscribeActiveRoute.unsubscribe();
    this.subscribeDeletingResult.unsubscribe();
  }

}
