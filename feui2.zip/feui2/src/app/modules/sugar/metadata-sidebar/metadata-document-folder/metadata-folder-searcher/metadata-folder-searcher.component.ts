import { DocumentEffect } from 'app/effects/document.effect';
import { DocumentAttachedToFoldersResult } from './../../../../../models/document-attached-to-folder-result';
import { Subscription } from 'rxjs/Subscription';
import { Store } from '@ngrx/store';
import { Folder } from 'app/models/folder';
import { Observable } from 'rxjs/Observable';
import { FolderEffect } from 'app/effects/folder.effect';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ModalSearchFolderComponent } from 'app/modules/sugar/modals/modal-search-folder/modal-search-folder.component';
import { ModalCreateFolderComponent } from 'app/modules/sugar/modals/modal-create-folder/modal-create-folder.component';
import { Subject } from 'rxjs/Subject';

import * as fromRoot from 'app/reducers';
import * as searchFolderToAttachActions from 'app/actions/search-folder-to-attach.actions';
import * as folderActions from 'app/actions/folder.actions';

import { filter } from 'lodash';

// this.documentEffect.getDocumentsById(docid);
@Component({
  selector: 'app-metadata-folder-searcher',
  templateUrl: './metadata-folder-searcher.component.html',
  styleUrls: ['./metadata-folder-searcher.component.scss']
})
export class MetadataFolderSearcherComponent implements OnInit, OnDestroy {
  subscriberCurrentDocumentId: Subscription;

  uploading$: Observable<Boolean>;
  searching$: Observable<Boolean>;
  error$: Observable<Error>;
  attachSuccess$: Observable<DocumentAttachedToFoldersResult>;

  subscriberAttachSuccess: Subscription;

  currentDocumentId$: Observable<string>;
  currentDocumentId: string;

  modalSearch;
  searchTerm$ = new Subject<any>();

  folderResults$: Observable<Array<Folder>>;
  folderResults: Array<Folder>;

  folderSelected$: Observable<string>;
  folderSelected: any;

  show: Boolean = false;
  to: any;
  // modalON: Boolean = false;

  constructor(
    protected modalService: NgbModal,
    private folderEffect: FolderEffect,
    private documentEffect: DocumentEffect,
    private store: Store<fromRoot.State>,
  ) {

    this.currentDocumentId$ = store.select(fromRoot.getSearchPreviewResultId);
    this.subscriberCurrentDocumentId = this.currentDocumentId$.subscribe(currentDocumentId => this.currentDocumentId = currentDocumentId);

    this.uploading$ = store.select(fromRoot.getSearchFolderToAttachUploading);
    this.searching$ = store.select(fromRoot.getSearchFolderToAttachLoading);
    this.error$ = store.select(fromRoot.getFolderUpdateError);

    // this.folderResults$ = store.select(fromRoot.getSearchPagedResults);
    this.folderResults$ = store.select(fromRoot.getSearchFolderToAttachResults);

    this.folderResults$.subscribe(folders => this.folderResults = folders);

    this.folderSelected$ = store.select(fromRoot.getSearchFolderToAttachResultId);
    this.folderSelected$.subscribe(id => {
      this.folderSelected = filter(this.folderResults, folder => folder.id === id);
    });

    this.attachSuccess$ = store.select(fromRoot.getSearchFolderToAttachSuccess);

    this.subscriberAttachSuccess = this.attachSuccess$.subscribe(success => {

      if (success && success.documentIdArray.length > 0) {
        // console.log('id -> ' , success.documentIdArray[0])
        // console.log(this.currentDocumentId)
        this.documentEffect.getDocumentsById(this.currentDocumentId);
        if (this.modalSearch) { this.modalSearch.close(); }
      }
    });
  }

  open() {

    this.store.dispatch(new folderActions.InitUpdateFolder());
    this.modalSearch = this.modalService.open(ModalSearchFolderComponent, { windowClass: 'modal-xl', backdrop: 'static' });
  }

  openCreateFolder() {
    // this.store.dispatch(new folderActions.InitUpdateFolder());
    this.modalSearch = this.modalService.open(ModalCreateFolderComponent, { backdrop: 'static' });
  }


  onBlur() {
    if (this.to) { clearTimeout(this.to); }
    this.to = setTimeout(() => { this.show = false; }, 500);
  }
  onFocus() {
    this.show = true;
  }

  attachThis(id) {
    this.store.dispatch(new searchFolderToAttachActions.PutSearchFolderIdToAttach(id));
    // setTimeout( () => this.show = false, 400);
    this.show = false;
  }

  onAttach(folderId: string) {
    if (this.currentDocumentId) {
      this.folderEffect.postFolderDocuments(folderId, [this.currentDocumentId]);
    }
  }

  searchTerm(query) {
    this.folderEffect.getFoldersLive(query);
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscriberCurrentDocumentId.unsubscribe();
    this.subscriberAttachSuccess.unsubscribe();
  }

}
