import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Component, OnInit } from '@angular/core';
import { ModalSearchFolderComponent } from 'app/modules/sugar/modals/modal-search-folder/modal-search-folder.component';

@Component({
  selector: 'app-metadata-document-folder',
  templateUrl: './metadata-document-folder.component.html',
  styleUrls: ['./metadata-document-folder.component.scss']
})
export class MetadataDocumentFolderComponent implements OnInit {

  modalSearch;

  constructor(
    protected modalService: NgbModal
  ) { }

  open() {
    this.modalSearch = this.modalService.open(ModalSearchFolderComponent, { windowClass: 'modal-xl', backdrop: 'static' });
  }

  ngOnInit( ) {
  }

}
