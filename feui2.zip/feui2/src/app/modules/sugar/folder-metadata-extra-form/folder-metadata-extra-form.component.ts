import { Subscription } from 'rxjs/Subscription';
import { Store } from '@ngrx/store';
import { Document } from './../../../models/document';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Input, OnDestroy, EventEmitter, Output } from '@angular/core';
import { ExtraFields } from 'app/states/extra-fields.state'; // Model

import {
  FormsModule,
  ReactiveFormsModule,
  FormGroup,
  FormArray,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';

import * as fromRoot from 'app/reducers';


@Component({
  selector: 'app-folder-metadata-extra-form',
  templateUrl: './folder-metadata-extra-form.component.html',
  styleUrls: ['./folder-metadata-extra-form.component.scss']
})
export class FolderMetadataExtraFormComponent implements OnInit, OnDestroy {

  @Input() extraMetadataForm: FormGroup;
  @Input() preview: Boolean;
  @Output() folderTypeIdSelected = new EventEmitter();

  // extraMetadataForm: FormGroup;
  currentLang$: Observable<string>;
  folderTypes$: Observable<Array<ExtraFields>>;
  currentFolder$: Observable<Document>;

  subFolderTypes: Subscription;
  subCurrentFolder: Subscription;

  folderTypeId;
  currentFolder;
  folderTypes;
  metadataFormSubscrition;

  constructor(
    private store: Store<fromRoot.State>,
    private formBuilder: FormBuilder
  ) {

    this.currentLang$ = store.select(fromRoot.getCurrentLanguage);

    this.folderTypes$ = store.select(fromRoot.getExtraFieldsFolderMetadataFields);
    this.subFolderTypes = this.folderTypes$.subscribe(folderTypes => this.folderTypes = folderTypes );

  }

  initExtraMetadaFormCurrentDoc() {
    if (this.currentFolder.tagList) {
      this.removeControls(this.extraMetadataForm);
      for (let i = 0; i < this.currentFolder.tagList.length; i++) {
        // tslint:disable-next-line:max-line-length
        this.extraMetadataForm.addControl(this.currentFolder.tagList[i].tagName, new FormControl(this.currentFolder.tagList[i].tagValue));
      }
    }
  }

  initExtraMetadaForm() {
    this.removeControls(this.extraMetadataForm);
    this.folderTypes.map(folderType => {
      if (folderType.id === this.folderTypeId) {
        for (let i = 0; i < folderType.inputsFields.length; i++) {
          // tslint:disable-next-line:max-line-length
          this.extraMetadataForm.addControl(folderType.inputsFields[i].name, new FormControl('', folderType.inputsFields[i].mandatory && Validators.required));
        }
      }
    });
  }

  removeControls(fg: FormGroup) {
    Object.keys(fg.controls).map(fc => this.extraMetadataForm.removeControl(fc));
  }

  onChange(folderTypeId) {
    if (this.currentFolder.folderTypeId === folderTypeId) {
      this.initExtraMetadaFormCurrentDoc();
    } else {
      this.initExtraMetadaForm();
    }

    this.folderTypeIdSelected.emit(folderTypeId);
  }


  ngOnInit() {
    if ( !this.preview ) {
      this.currentFolder$ = this.store.select(fromRoot.getFolderFirstResult);
      this.subCurrentFolder = this.currentFolder$.subscribe((folder) => {
        if (folder && folder.id) {
          this.folderTypeId = folder['folderTypeId'];
          this.currentFolder = folder;
          this.initExtraMetadaFormCurrentDoc();
        }
      });
    } else {
      this.currentFolder$ = this.store.select(fromRoot.getSearchPreviewResults);
      this.subCurrentFolder = this.currentFolder$.subscribe((folder) => {

        if (folder && folder.id) {
          this.folderTypeId = folder['folderTypeId'];
          this.currentFolder = folder;
          this.initExtraMetadaFormCurrentDoc();
        }
      });
    }



  }

  ngOnDestroy() {
    this.subCurrentFolder.unsubscribe();
    this.subFolderTypes.unsubscribe();
  }

}
