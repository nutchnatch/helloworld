import { TagClone } from 'app/models/tag';
import { Subscription } from 'rxjs/Subscription';
import { Store } from '@ngrx/store';
import { Document } from './../../../models/document';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Input, OnDestroy, EventEmitter, Output } from '@angular/core';
import { ExtraFields } from 'app/states/extra-fields.state'; // Model

import { find } from 'lodash';


import {
  FormsModule,
  ReactiveFormsModule,
  FormGroup,
  FormArray,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';

import * as fromRoot from 'app/reducers';


@Component({
  selector: 'app-metadata-extra-form',
  templateUrl: './metadata-extra-form.component.html',
  styleUrls: ['./metadata-extra-form.component.scss']
})
export class MetadataExtraFormComponent implements OnInit, OnDestroy {
  subscribeCopiedTags: Subscription;


  @Input() extraMetadataForm: FormGroup;
  @Output() docTypeIdSelected = new EventEmitter();

  // extraMetadataForm: FormGroup;
  currentLang$: Observable<string>;
  documentTypes$: Observable<Array<ExtraFields>>;
  currentDocument$: Observable<Document>;
  copiedTags$: Observable<Array<TagClone>>;
  copiedTags: Array<TagClone>;

  subDocumentTypes: Subscription;
  subCurrentDocument: Subscription;

  docTypeId;
  currentDocument;
  documentTypes;
  metadataFormSubscrition;

  constructor(
    private store: Store<fromRoot.State>,
    private formBuilder: FormBuilder
  ) {

    this.currentLang$ = store.select(fromRoot.getCurrentLanguage);

    this.currentDocument$ = store.select(fromRoot.getSearchPreviewResults);

    this.documentTypes$ = store.select(fromRoot.getExtraFieldsMetadataFields);
    this.subDocumentTypes = this.documentTypes$.subscribe(documentTypes => this.documentTypes = documentTypes);

    this.copiedTags$ = store.select(fromRoot.getAppConfigCopiedTags);
    this.subscribeCopiedTags = this.copiedTags$.subscribe( copiedTags => {
      if ( copiedTags && this.documentTypes ) {
        this.copiedTags = copiedTags;
        if (this.currentDocument && this.currentDocument.docTypeId) {
          this.initExtraMetadaFormCurrentDoc();
        } else {
          this.initExtraMetadaForm();
        }
      }
    });

  }

  initExtraMetadaFormCurrentDoc() {
    if (this.currentDocument.tagList.length > 0) {
      this.removeControls(this.extraMetadataForm);
      for (let i = 0; i < this.currentDocument.tagList.length; i++) {
        const copiedTag: any = find(this.copiedTags, ( t ) => t['tagName'] === this.currentDocument.tagList[i].tagName );
        if ( copiedTag ) {
          this.extraMetadataForm.addControl(this.currentDocument.tagList[i].tagName,
            // tslint:disable-next-line:max-line-length
            new FormControl(this.currentDocument.tagList[i].tagName === copiedTag.tagName ? copiedTag.tagValue : '')
          );
        } else {
          // tslint:disable-next-line:max-line-length
          this.extraMetadataForm.addControl(this.currentDocument.tagList[i].tagName, new FormControl(this.currentDocument.tagList[i].tagValue));
        }
      }
    } else {
      this.initExtraMetadaForm();
    }
  }

  initExtraMetadaForm() {
    if (this.extraMetadataForm) { this.removeControls(this.extraMetadataForm); }
    this.documentTypes.map(docType => {
      if (docType.id === this.docTypeId) {
        for (let i = 0; i < docType.inputsFields.length; i++) {
          // tslint:disable-next-line:max-line-length
          const copiedTag: any = find(this.copiedTags, ( t ) => t['tagName'] === docType.inputsFields[i].name );
          if ( copiedTag ) {
            // tslint:disable-next-line:max-line-length
            this.extraMetadataForm.addControl(docType.inputsFields[i].name,
              new FormControl(docType.inputsFields[i].name === copiedTag.tagName ? copiedTag.tagValue : '', docType.inputsFields[i].mandatory && Validators.required)
            );
          } else {
            // tslint:disable-next-line:max-line-length
            this.extraMetadataForm.addControl(docType.inputsFields[i].name, new FormControl('', docType.inputsFields[i].mandatory && Validators.required));
          }
        }
      }
    });
  }

  removeControls(fg: FormGroup) {
    Object.keys(fg.controls).map(fc => this.extraMetadataForm.removeControl(fc));
  }

  onChange(docTypeId) {
    if (this.currentDocument.docTypeId === docTypeId) {
      this.initExtraMetadaFormCurrentDoc();
    } else {
      this.initExtraMetadaForm();
    }

    this.docTypeIdSelected.emit(docTypeId);
  }


  ngOnInit() {
    this.subCurrentDocument = this.currentDocument$.subscribe((doc) => {
      if (doc.id) {
        this.docTypeId = doc['docTypeId'];
        this.currentDocument = doc;
        this.initExtraMetadaFormCurrentDoc();
        this.docTypeIdSelected.emit(this.docTypeId);
      }
    });
  }

  ngOnDestroy() {
    if (this.subCurrentDocument) { this.subCurrentDocument.unsubscribe(); }
    this.subDocumentTypes.unsubscribe();
  }

}
