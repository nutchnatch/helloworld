import { DocumentTypes } from './../../../../models/document-types';
import { Subscription } from 'rxjs/Subscription';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Document } from 'app/models/document';
import { Paging } from 'app/models/paging';
import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as layoutActions from 'app/actions/layout.actions';
import * as searchPreviewActions from 'app/actions/search-preview.actions';
import * as documentsFilterAction from 'app/actions/documents-filter.actions';
import * as layoutAction from 'app/actions/layout.actions';
import * as searchPagedActions from 'app/actions/search-paged.actions';

import { find } from 'lodash';
import { Router } from '@angular/router';


@Component({
  selector: 'app-table-document',
  templateUrl: './table-document.component.html',
  styleUrls: ['./table-document.component.scss']
})
export class TableDocumentComponent implements OnInit, OnDestroy {

  private searchResult$: Observable<Document[]>;
  private pagingResult$: Observable<Paging>;
  private compactTables$: Observable<Boolean>;
  private previewIndex$: Observable<any>;
  private pageSizeList$: Observable<Array<number>>;
  private currentLang$: Observable<string>;

  private subsrcribeCurrentLang: Subscription;
  private subscrisbePreviewIndex: Subscription;

  private tableCompactState: Boolean;
  private previewIndex: number = null;

  private documentTypes$: Observable<Array<DocumentTypes>>;
  private subsciberDocumentType: Subscription;

  docTypes: Array<DocumentTypes>;
  currentLang: string;

  constructor(
    private store: Store<fromRoot.State>,
    private router: Router
  ) {

    this.searchResult$ = store.select(fromRoot.getSearchPagedResults);
    this.previewIndex$ = store.select(fromRoot.getSearchPreviewResultId);
    this.subscrisbePreviewIndex = this.previewIndex$.subscribe( id => this.previewIndex = id);

    this.compactTables$ = store.select(fromRoot.getLayoutTableCompact);
    // this.compactTables$.subscribe(compact => this.tableCompactState = compact );

    this.pageSizeList$ = store.select(fromRoot.getAppConfigPageSizeList);

    this.documentTypes$ = store.select(fromRoot.getDocumentTypesResult);
    this.subsciberDocumentType = this.documentTypes$.subscribe(docTypes => {
      // console.log(docTypes)
      this.docTypes = docTypes;
    });

    this.currentLang$ = store.select(fromRoot.getCurrentLanguage);
    this.subsrcribeCurrentLang = this.currentLang$.subscribe(currentLang => {
      this.currentLang = currentLang.toUpperCase();
    });

  }

  changeTableStyle() {
    this.store.dispatch(new layoutActions.PutCompactTableAction( !this.tableCompactState ));
  }

  preview(doc: Document): void {
    if ( doc.id === '' + this.previewIndex ) {
      this.store.dispatch(new searchPreviewActions.InitSearchResultsSearchPreview());
      this.store.dispatch(new searchPreviewActions.PutSearchTypeSearchPreview(null));
    } else {
      this.store.dispatch(new searchPreviewActions.PutSearchResultsSearchPreview(doc));
      this.store.dispatch(new searchPreviewActions.PutSearchTypeSearchPreview('documents'));
    }
  }

  selectedDocument(doc: Document) {
    // this.store.dispatch( new documentsFilterAction.PutDocumentSeleced( doc.id ) );
  }

  getDocumentTypeName(id: string, version: number): string {

    const docType: DocumentTypes = find(this.docTypes, { id: id, version: version });
    if (!docType) {
      // this.envelopeTypeEffect.getEnvelopeTypeById(id, version);
      return 'Error';
    }
    const displayName = find(docType.displayNameList, { language: this.currentLang });
    return displayName  ? displayName['value'] : '' ;
  }

  fromSearch() {
    this.store.dispatch(new layoutAction.PutFromSearchAction(this.router.url));
  }

  ngOnInit() {}

  ngOnDestroy() {
    this.subscrisbePreviewIndex.unsubscribe();
    this.subsciberDocumentType.unsubscribe();
    this.subsrcribeCurrentLang.unsubscribe();
  }
}
