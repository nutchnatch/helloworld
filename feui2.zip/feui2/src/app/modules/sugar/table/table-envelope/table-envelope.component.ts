import { getLanguageState } from './../../../../reducers/index';
import { EnvelopeTypes } from 'app/models/envelope-types';
import { EnvelopeTypeEffect } from 'app/effects/envelope-types.effects';
import { Subscription } from 'rxjs/Subscription';
import { Envelope } from 'app/models/envelope';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy, Input} from '@angular/core';
import { Paging } from 'app/models/paging';
import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as layoutActions from 'app/actions/layout.actions';
import * as searchPreviewActions from 'app/actions/search-preview.actions';
import * as searchPagedActions from 'app/actions/search-paged.actions';

import { find } from 'lodash';
import { Router } from 'testing/router.stub';

@Component({
  selector: 'app-table-envelope',
  templateUrl: './table-envelope.component.html',
  styleUrls: ['./table-envelope.component.scss']
})
export class TableEnvelopeComponent implements OnInit, OnDestroy {

  @Input() modalMode: boolean;

  private searchResult$: Observable<Envelope[]>;
  private pagingResult$: Observable<Paging>;
  private compactTables$: Observable<Boolean>;
  private previewIndex$: Observable<any>;
  private pageSizeList$: Observable<Array<number>>;
  private currentLang$: Observable<string>;

  private subscrisbePreviewIndex: Subscription;
  private subsrcribeCurrentLang: Subscription;

  private tableCompactState: Boolean;
  private previewIndex: number = null;

  private envelopeTypes$: Observable<Array<EnvelopeTypes>>;
  private subsciberEnvelopeType: Subscription;

  envTypes: Array<EnvelopeTypes>;
  currentLang: string;
  isModalMode: boolean;

  constructor(
    private store: Store<fromRoot.State>,
    private router: Router
  ) {
    this.searchResult$ = store.select(fromRoot.getSearchPagedResults);
    this.previewIndex$ = store.select(fromRoot.getSearchPreviewResultId);
    this.subscrisbePreviewIndex = this.previewIndex$.subscribe(id => this.previewIndex = id);

    this.compactTables$ = store.select(fromRoot.getLayoutTableCompact);
    // this.compactTables$.subscribe(compact => this.tableCompactState = compact );

    this.pageSizeList$ = store.select(fromRoot.getAppConfigPageSizeList);

    this.envelopeTypes$ = store.select(fromRoot.getEnvelopeTypesResult);
    this.subsciberEnvelopeType = this.envelopeTypes$.subscribe(envTypes => {
      // console.log(envTypes)
      this.envTypes = envTypes;
    });

    this.currentLang$ = store.select(fromRoot.getCurrentLanguage);
    this.subsrcribeCurrentLang = this.currentLang$.subscribe(currentLang => {
      this.currentLang = currentLang.toUpperCase();
    });

  }

  changeTableStyle() {
    this.store.dispatch(new layoutActions.PutCompactTableAction(!this.tableCompactState));
  }

  preview(env: Envelope): void {
    if ( env.id === '' + this.previewIndex ) {
      this.store.dispatch(new searchPreviewActions.InitSearchResultsSearchPreview());
      this.store.dispatch(new searchPreviewActions.PutSearchTypeSearchPreview(null));
    } else {
      this.store.dispatch(new searchPreviewActions.PutSearchResultsSearchPreview(env));
      this.store.dispatch(new searchPreviewActions.PutSearchTypeSearchPreview('envelopes'));
    }
  }

  selectedEnvelope(env: Envelope) {

    // getEnvelopeTypeById
    // this.store.dispatch( new documentsFilterAction.PutDocumentSeleced( doc.id ) );
  }

  fromSearch() {
    this.store.dispatch(new layoutActions.PutFromSearchAction(this.router.url));
  }


  getEnvelopeTypeName(id: string, version: number): string {
    const envType: EnvelopeTypes = find(this.envTypes, { id: id, version: version });
    if (!envType) {
      return 'Error';
    }
    const displayName = find(envType.displayNameList, { language: this.currentLang });
    return displayName['value'];
  }

  ngOnInit() {
    this.isModalMode = this.modalMode;
  }

  ngOnDestroy() {
    // this.store.dispatch( new searchPagedActions.InitSearchResults);
    this.subscrisbePreviewIndex.unsubscribe();
    this.subsciberEnvelopeType.unsubscribe();
    this.subsrcribeCurrentLang.unsubscribe();
  }

}
