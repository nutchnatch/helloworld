import { Component, Input, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as uploadDocumentsAction from 'app/actions/upload-documents.actions';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-table-files-to-upload',
  templateUrl: './table-files-to-upload.component.html',
  styleUrls: ['./table-files-to-upload.component.scss']
})
export class TableFilesToUploadComponent implements OnInit {

  @Input() compact: Boolean = false;

  isCompact;

  private uploadDocument$: Observable<Array<File>>;
  private isUpLoading$: Observable<Boolean>;

  constructor(
    private store: Store<fromRoot.State>
  ) {

    this.uploadDocument$ = store.select(fromRoot.getUploadDocumentsList);
    this.isUpLoading$ = store.select(fromRoot.getUploadDocumentsLoading);
  }

  removeThis(name: string) {
    this.store.dispatch(new uploadDocumentsAction.RemoveDocumentListByName(name));
  }

  removeAll() {
    this.store.dispatch(new uploadDocumentsAction.InitDocumentList());
  }

  upload() {
    console.log('aaa');
  }

  ngOnInit() {
    this.isCompact = this.compact;
  }
}
