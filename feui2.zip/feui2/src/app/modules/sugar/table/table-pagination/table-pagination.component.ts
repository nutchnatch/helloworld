import { Subscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Paging } from 'app/models/paging';
import { Observable } from 'rxjs/Observable';
import { Component, OnDestroy, Input, OnInit } from '@angular/core';


import * as fromRoot from 'app/reducers';
import * as layoutActions from 'app/actions/layout.actions';
import * as searchPreviewActions from 'app/actions/search-preview.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';

@Component({
  selector: 'app-table-pagination',
  templateUrl: './table-pagination.component.html',
  styleUrls: ['./table-pagination.component.scss']
})
export class TablePaginationComponent implements OnInit, OnDestroy {

  @Input() modalMode: Boolean;

  paging$: Observable<Paging>;
  page: number;
  subscriberPaging: Subscription;

  searchQuery$: Observable<any>;
  searchQuery: any;
  subscriberSearchQuery: Subscription;

  searching$: Observable<boolean>;

  searchType$: Observable<string>;
  searchType: string;
  subscriberSearchType: Subscription;

  isModalMode: Boolean;

  constructor(
    private store: Store<fromRoot.State>,
    private router: Router

  ) {

    this.paging$ = store.select(fromRoot.getSearchPagedPaging);
    this.subscriberPaging = this.paging$.subscribe(page => this.page = page.currentPage);

    this.searchQuery$ = this.store.select(fromRoot.getSearchPagedQuery);
    this.subscriberSearchQuery = this.searchQuery$.subscribe(query => this.searchQuery = query);

    this.searching$ = this.store.select(fromRoot.getSearchPagedLoading);

    this.searchType$ = this.store.select(fromRoot.getSearchPagedType);
    this.subscriberSearchType = this.searchType$.subscribe(type => this.searchType = type);

  }

  pageChange(page) {
    if (page) {
      if ( this.isModalMode ) {
        this.store.dispatch(new searchPagedAction.PutSearchResultsQuery( Object.assign({}, this.searchQuery, { pageNumber: page })));
      } else {
        this.router.navigate(['app/' + this.searchType, Object.assign({}, this.searchQuery, { pageNumber: page })]);
      }
    }
  }

  ngOnInit() {
    this.isModalMode = this.modalMode;
  }
  ngOnDestroy() {
    this.subscriberPaging.unsubscribe();
    this.subscriberSearchQuery.unsubscribe();
    this.subscriberSearchType.unsubscribe();

  }
}
