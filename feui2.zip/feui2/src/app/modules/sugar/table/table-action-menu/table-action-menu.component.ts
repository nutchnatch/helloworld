import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { Component } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as layoutActions from 'app/actions/layout.actions';

@Component({
  selector: 'app-table-action-menu',
  templateUrl: './table-action-menu.component.html',
  styleUrls: ['./table-action-menu.component.scss']
})
export class TableActionMenuComponent {

  private compactTables$: Observable<Boolean>;
  private tableCompactState: Boolean;


  constructor(
    private store: Store<fromRoot.State>
  ) {

    this.compactTables$ = store.select(fromRoot.getLayoutTableCompact);
    this.compactTables$.subscribe(compact => this.tableCompactState = compact );

  }

  changeTableStyle() {
    this.store.dispatch(new layoutActions.PutCompactTableAction( !this.tableCompactState ));
  }
}
