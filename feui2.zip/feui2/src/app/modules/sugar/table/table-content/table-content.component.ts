import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { Component, Input } from '@angular/core';

import * as fromRoot from 'app/reducers';


@Component({
  selector: 'app-table-content',
  templateUrl: './table-content.component.html',
  styleUrls: ['./table-content.component.scss']
})
export class TableContentComponent {
  private searchType$: Observable<string>;

  constructor(
    store: Store<fromRoot.State>,
  ) {
    this.searchType$ = store.select(fromRoot.getSearchPagedType);
  }

}
