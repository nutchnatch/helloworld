import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs/Subscription';
import { Paging } from 'app/models/paging';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as layoutActions from 'app/actions/layout.actions';


@Component({
  selector: 'app-table-basket',
  templateUrl: './table-basket.component.html',
  styleUrls: ['./table-basket.component.scss']
})
export class TableBasketComponent implements OnInit, OnDestroy {

  private searchResult$: Observable<Document[]>;
  private pagingResult$: Observable<Paging>;
  private compactTables$: Observable<Boolean>;
  private pageSizeList$: Observable<Array<number>>;
  private currentLang$: Observable<string>;

  private subsrcribeCurrentLang: Subscription;
  // private subscrisbePreviewIndex: Subscription;
  // private subsciberDocumentType: Subscription;

  private tableCompactState: Boolean;
  private previewIndex: number = null;

  // private documentTypes$: Observable<Array<DocumentTypes>>;

  // docTypes: Array<DocumentTypes>;
  currentLang: string;
  page = 1;

  constructor(
    private store: Store<fromRoot.State>,
    private router: Router
  ) {
    this.searchResult$ = store.select(fromRoot.getSearchPagedResults);
    // this.previewIndex$ = store.select(fromRoot.getSearchPreviewResultId);
    // this.subscrisbePreviewIndex = this.previewIndex$.subscribe( id => this.previewIndex = id);

    this.compactTables$ = store.select(fromRoot.getLayoutTableCompact);
    // this.compactTables$.subscribe(compact => this.tableCompactState = compact );

    this.pageSizeList$ = store.select(fromRoot.getAppConfigPageSizeList);

    // this.documentTypes$ = store.select(fromRoot.getDocumentTypesResult);
    // this.subsciberDocumentType = this.documentTypes$.subscribe(docTypes => {
    //   // console.log(docTypes)
    //   this.docTypes = docTypes;
    // });

    this.currentLang$ = store.select(fromRoot.getCurrentLanguage);
    this.subsrcribeCurrentLang = this.currentLang$.subscribe(currentLang => {
      this.currentLang = currentLang.toUpperCase();
    });

  }

  fromSearch() {
    this.store.dispatch(new layoutActions.PutFromSearchAction(this.router.url));
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    // this.subscrisbePreviewIndex.unsubscribe();
    // this.subsciberDocumentType.unsubscribe();
    this.subsrcribeCurrentLang.unsubscribe();
  }

}
