import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TablePagesizeSelectComponent } from './table-pagesize-select.component';

describe('TablePagesizeSelectComponent', () => {
  let component: TablePagesizeSelectComponent;
  let fixture: ComponentFixture<TablePagesizeSelectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TablePagesizeSelectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TablePagesizeSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
