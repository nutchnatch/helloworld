import { Subscription } from 'rxjs/Subscription';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { Component, OnDestroy, Input, OnInit } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as appConfigActions from 'app/actions/app-config.actions';
import * as searchPagedAction from 'app/actions/search-paged.actions';

import { Router } from '@angular/router';
import { Output } from '@angular/core/src/metadata/directives';

@Component({
  selector: 'app-table-pagesize-select',
  templateUrl: './table-pagesize-select.component.html',
  styleUrls: ['./table-pagesize-select.component.scss']
})
export class TablePagesizeSelectComponent implements OnInit, OnDestroy  {

  @Input() modalMode: Boolean;
  // @Output()

  pageSize$: Observable<number>;
  pageSizeList$: Observable<Array<number>>;
  subscriberPageSize: Subscription;

  searchQuery$: Observable<any>;
  subscriberSearchQuery: Subscription;

  searchType$: Observable<string>;
  searchType: string;
  subscriberSearchType: Subscription;

  pageSize: number;
  searchQuery: any;
  isModalMode: Boolean;

  constructor(
    private store: Store<fromRoot.State>,
    private router: Router
  ) {
    this.pageSize$ = this.store.select(fromRoot.getAppConfigPageSize);
    this.subscriberPageSize = this.pageSize$.subscribe( value => this.pageSize = value);

    this.pageSizeList$ = this.store.select(fromRoot.getAppConfigPageSizeList);

    this.searchQuery$ = this.store.select(fromRoot.getSearchPagedQuery);
    this.subscriberSearchQuery = this.searchQuery$.subscribe( query => this.searchQuery = query );

    this.searchType$ = this.store.select(fromRoot.getSearchPagedType);
    this.subscriberSearchType = this.searchType$.subscribe( type => this.searchType = type );

  }

  updateSelectedValue(event: number) {
    this.store.dispatch(new appConfigActions.PutPageSizeAction( event ));
    if (this.isModalMode) {
      // Object.assign({}, this.searchQuery, { pageSize: event })
      this.store.dispatch(new searchPagedAction.PutSearchResultsQuery( Object.assign({}, this.searchQuery, { pageSize: event })));

    } else {
      this.router.navigate(['app/' + this.searchType, Object.assign({}, this.searchQuery, { pageSize: event }) ]);
    }
  }

  ngOnInit() {
    this.isModalMode = this.modalMode;
  }

  ngOnDestroy() {
    this.subscriberPageSize.unsubscribe();
    this.subscriberSearchQuery.unsubscribe();
    this.subscriberSearchType.unsubscribe();
  }

}
