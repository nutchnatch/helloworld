import { Subscription } from 'rxjs/Subscription';
import { Store } from '@ngrx/store';
import { Document } from './../../../models/document';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Input, OnDestroy, EventEmitter, Output } from '@angular/core';
import { ExtraFields } from 'app/states/extra-fields.state'; // Model

import {
  FormsModule,
  ReactiveFormsModule,
  FormGroup,
  FormArray,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';

import * as fromRoot from 'app/reducers';


@Component({
  selector: 'app-envelope-metadata-extra-form',
  templateUrl: './envelope-metadata-extra-form.component.html',
  styleUrls: ['./envelope-metadata-extra-form.component.scss']
})
export class EnvelopeMetadataExtraFormComponent implements OnInit, OnDestroy {

  @Input() extraMetadataForm: FormGroup;
  @Input() preview: Boolean;
  @Output() envTypeIdSelected = new EventEmitter();

  // extraMetadataForm: FormGroup;
  currentLang$: Observable<string>;
  envelopeTypes$: Observable<Array<ExtraFields>>;
  currentEnvelope$: Observable<Document>;

  subEnvelopeTypes: Subscription;
  subCurrentEnvelope: Subscription;

  envTypeId;
  currentEnvelope;
  envelopeTypes;
  metadataFormSubscrition;

  constructor(
    private store: Store<fromRoot.State>,
    private formBuilder: FormBuilder
  ) {

    this.currentLang$ = store.select(fromRoot.getCurrentLanguage);


    this.envelopeTypes$ = store.select(fromRoot.getExtraFieldsEnvelopeMetadataFields);
    this.subEnvelopeTypes = this.envelopeTypes$.subscribe(envelopeTypes => this.envelopeTypes = envelopeTypes);

  }

  initExtraMetadaFormCurrentDoc() {
    if (this.currentEnvelope.tagList) {
      this.removeControls(this.extraMetadataForm);
      for (let i = 0; i < this.currentEnvelope.tagList.length; i++) {
        // tslint:disable-next-line:max-line-length
        this.extraMetadataForm.addControl(this.currentEnvelope.tagList[i].tagName, new FormControl(this.currentEnvelope.tagList[i].tagValue));
      }
    }
  }

  initExtraMetadaForm() {
    this.removeControls(this.extraMetadataForm);
    this.envelopeTypes.map(envType => {
      if (envType.id === this.envTypeId) {
        for (let i = 0; i < envType.inputsFields.length; i++) {
          // tslint:disable-next-line:max-line-length
          this.extraMetadataForm.addControl(envType.inputsFields[i].name, new FormControl('', envType.inputsFields[i].mandatory && Validators.required));
        }
      }
    });
  }

  removeControls(fg: FormGroup) {
    Object.keys(fg.controls).map(fc => this.extraMetadataForm.removeControl(fc));
  }

  onChange(envTypeId) {
    if (this.currentEnvelope.envTypeId === envTypeId) {
      this.initExtraMetadaFormCurrentDoc();
    } else {
      this.initExtraMetadaForm();
    }

    this.envTypeIdSelected.emit(envTypeId);
  }


  ngOnInit() {

    if ( !this.preview ) {
      this.currentEnvelope$ = this.store.select(fromRoot.getEnvelopeFirstResult);
      this.subCurrentEnvelope = this.currentEnvelope$.subscribe((env) => {
        if (env && env.id) {
          this.envTypeId = env['envTypeId'];
          this.currentEnvelope = env;
          this.initExtraMetadaFormCurrentDoc();
        }
      });
    } else {
      this.currentEnvelope$ = this.store.select(fromRoot.getSearchPreviewResults);
      this.subCurrentEnvelope = this.currentEnvelope$.subscribe((env) => {
        if (env && env.id) {
          this.envTypeId = env['envTypeId'];
          this.currentEnvelope = env;
          this.initExtraMetadaFormCurrentDoc();
        }
      });
    }
  }

  ngOnDestroy() {
    this.subCurrentEnvelope.unsubscribe();
    this.subEnvelopeTypes.unsubscribe();
  }

}
