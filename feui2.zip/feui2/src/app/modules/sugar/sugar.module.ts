// tslint:disable-next-line:max-line-length
import { MetadataFolderSearchResultsComponent } from './modals/modal-search-folder/metadata-folder-search-results/metadata-folder-search-results.component';
import { SearchOnModalComponent } from './modals/modal-search-folder/search-on-modal/search-on-modal.component';
import { ModalSearchFolderComponent } from './modals/modal-search-folder/modal-search-folder.component';
import { MetadataDocumentFolderComponent } from './metadata-sidebar/metadata-document-folder/metadata-document-folder.component';
import { FilterTypesComponent } from './advance-search/filter-types/filter-types.component';
import { TypeSelectComponent } from './advance-search/type-select/type-select.component';
import { SafeUrlPipe } from './../../pipes/safe-url.pipe';
import { FolderMetadataFormComponent } from 'app/modules/sugar/folder-metadata-form/folder-metadata-form.component';
import { TableFolderComponent } from './table/table-folder/table-folder.component';
import { MetadataEnvelopeFormComponent } from './metadata-sidebar/metadata-envelope-form/metadata-envelope-form.component';
import { MetadataSidebarPreviewsComponent } from './metadata-sidebar/metadata-sidebar-previews/metadata-sidebar-previews.component';
import { TableEnvelopeComponent } from './table/table-envelope/table-envelope.component';
import { EnvelopeMetadataExtraFormComponent } from './envelope-metadata-extra-form/envelope-metadata-extra-form.component';
import { LoadingComponent } from './loading-bars/loading-bars.component';
import { TspUIModule } from 'app/modules/tsp-ui/tsp-ui.module';
import { EnvelopeFilterToogleComponent } from './envelope-filter-toogle/envelope-filter-toogle.component';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule } from '@ngx-translate/core';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// import { GuardedContentComponent } from './guarded-content/guarded-content.component';
import { SugarSidebarComponent } from './sidebar/sugar-sidebar/sugar-sidebar.component';
import { SearchOnSidebarComponent } from './sidebar/search-on-sidebar/search-on-sidebar.component';
import { SidebarContentComponent } from './sidebar/sidebar-content/sidebar-content.component';
import { TableBasketComponent } from './table/table-basket/table-basket.component';
import { TableContentComponent } from './table/table-content/table-content.component';
import { TableDocumentComponent } from './table/table-document/table-document.component';
import { MetadataSidebarComponent } from './metadata-sidebar/metadata-sidebar/metadata-sidebar.component';
import { MetadataSidebarEnvelopeComponent } from './metadata-sidebar/metadata-sidebar-envelope/metadata-sidebar-envelope.component';
import { TableActionMenuComponent } from './table/table-action-menu/table-action-menu.component';
import { TablePagesizeSelectComponent } from './table/table-pagesize-select/table-pagesize-select.component';
import { TablePaginationComponent } from './table/table-pagination/table-pagination.component';
// import { StringToDatePipe } from 'app/pipes/string-to-date.pipe';
import { EnvelopeFilesListComponent } from './envelope-files-list/envelope-files-list.component';
import { EnvelopeMetadataSidebarComponent } from './envelope-metadata-sidebar/envelope-metadata-sidebar.component';
import { MetadataDocumentFormComponent } from './metadata-sidebar/metadata-document-form/metadata-document-form.component';
import { EnvelopeArenderIframeComponent } from './envelope-arender-iframe/envelope-arender-iframe.component';
import { MetadataExtraFormComponent } from './metadata-extra-form/metadata-extra-form.component';
import { EnvelopeMetadataFormComponent } from './envelope-metadata-form/envelope-metadata-form.component';
import { GoToSearchResultsComponent } from 'app/modules/sugar/sidebar/go-to-search-results/go-to-search-results.component';
import { MetadataFolderFormComponent } from 'app/modules/sugar/metadata-sidebar/metadata-folder-form/metadata-folder-form.component';
import { FolderMetadataExtraFormComponent } from 'app/modules/sugar/folder-metadata-extra-form/folder-metadata-extra-form.component';
import { FolderMetadataSidebarComponent } from 'app/modules/sugar/folder-metadata-sidebar/folder-metadata-sidebar.component';
import { FolderFilesListComponent } from 'app/modules/sugar/folder-files-list/folder-files-list.component';
// tslint:disable-next-line:max-line-length
import { MetadataSidebarFolderComponent } from 'app/modules/sugar/metadata-sidebar/metadata-sidebar-folder/metadata-sidebar-folder.component';
import { AdvanceSearchComponent } from './advance-search/advance-search.component';
import { DomainSelectComponent } from 'app/modules/sugar/advance-search/domain-select/domain-select.component';
// tslint:disable-next-line:max-line-length
import { MetadataFolderListComponent } from 'app/modules/sugar/metadata-sidebar/metadata-document-folder/metadata-folder-list/metadata-folder-list.component';
import { MetadataFolderSearcherComponent } from 'app/modules/sugar/metadata-sidebar/metadata-document-folder/metadata-folder-searcher/metadata-folder-searcher.component';
import { FileDropModule } from 'ngx-file-drop';
import { FileDropComponent } from './file-drop/file-drop.component';
import { TableFilesToUploadComponent } from './table/table-files-to-upload/table-files-to-upload.component';
import { UploadDocumentActionsComponent } from './upload-document-actions/upload-document-actions.component';
// tslint:disable-next-line:max-line-length
import { UnderConstructionEnvelopeResultsComponent } from './under-construction-envelope-results/under-construction-envelope-results.component';
import { InfoVersionComponent } from './info-version/info-version.component';
import { ModalCreateFolderComponent } from './modals/modal-create-folder/modal-create-folder.component';
import { FormNewFolderComponent } from './modals/modal-create-folder/form-new-folder/form-new-folder.component';
import { SelectBasketComponent } from './select-basket/select-basket.component';
import { TaksHandlersComponent } from './sidebar/taks-handlers/taks-handlers.component';
import { ModalAlertEnvelopeComponent } from 'app/modules/sugar/modals/modal-alert-envelope/modal-alert-envelope.component';

@NgModule({
  imports: [
    CommonModule,
    NgbModule,
    RouterModule,
    TranslateModule,
    FormsModule,
    // TspUIModule,
    ReactiveFormsModule,
    FileDropModule,
  ],
  exports: [
    SugarSidebarComponent,
    TableBasketComponent,
    TableContentComponent,
    TranslateModule,
    MetadataSidebarComponent,
    TablePaginationComponent,
    LoadingComponent,
    EnvelopeArenderIframeComponent,
    FileDropComponent,
    TableFilesToUploadComponent,
    UploadDocumentActionsComponent,
    TableEnvelopeComponent,
    UnderConstructionEnvelopeResultsComponent,
    InfoVersionComponent,
    SelectBasketComponent,
    TaksHandlersComponent,

    ModalCreateFolderComponent,
    ModalAlertEnvelopeComponent,
    ModalSearchFolderComponent,

  ],
  declarations: [
    EnvelopeFilterToogleComponent,
    EnvelopeFilesListComponent,
    EnvelopeMetadataSidebarComponent,
    EnvelopeMetadataExtraFormComponent,
    SugarSidebarComponent,
    SearchOnSidebarComponent,
    SidebarContentComponent,
    TableBasketComponent,
    TableContentComponent,
    TableDocumentComponent,
    TableEnvelopeComponent,
    TableFolderComponent,
    MetadataSidebarComponent,
    MetadataSidebarPreviewsComponent,
    MetadataSidebarEnvelopeComponent,
    TableActionMenuComponent,
    TablePagesizeSelectComponent,
    TablePaginationComponent,
    // StringToDatePipe,
    SafeUrlPipe,
    EnvelopeFilesListComponent,
    LoadingComponent,
    MetadataDocumentFormComponent,
    MetadataEnvelopeFormComponent,
    MetadataFolderFormComponent,
    EnvelopeArenderIframeComponent,
    MetadataExtraFormComponent,
    EnvelopeMetadataFormComponent,
    GoToSearchResultsComponent,
    FolderMetadataExtraFormComponent,
    FolderMetadataSidebarComponent,
    FolderFilesListComponent,
    FolderMetadataFormComponent,
    MetadataSidebarFolderComponent,
    AdvanceSearchComponent,
    DomainSelectComponent,
    TypeSelectComponent,
    FilterTypesComponent,
    MetadataDocumentFolderComponent,
    MetadataFolderListComponent,
    MetadataFolderSearcherComponent,
    SearchOnModalComponent,
    MetadataFolderSearchResultsComponent,
    FileDropComponent,
    TableFilesToUploadComponent,
    UploadDocumentActionsComponent,
    UnderConstructionEnvelopeResultsComponent,
    InfoVersionComponent,
    FormNewFolderComponent,
    SelectBasketComponent,
    TaksHandlersComponent,

    ModalSearchFolderComponent,
    ModalCreateFolderComponent,
    ModalAlertEnvelopeComponent

  ]
})
export class SugarModule { }
