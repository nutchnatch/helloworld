import { FolderEffect } from 'app/effects/folder.effect';
import { Subscription } from 'rxjs/Subscription';
import { QueryParams } from 'app/models/paged';
import { Store } from '@ngrx/store';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Folder } from 'app/models/folder';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as folderActions from 'app/actions/folder.actions';


@Component({
  selector: 'app-folder-metadata-form',
  templateUrl: './folder-metadata-form.component.html',
  styleUrls: ['./folder-metadata-form.component.scss']
})
export class FolderMetadataFormComponent implements OnInit, OnDestroy {

  private folderState$: Observable<Folder>;
  private metadataForm: FormGroup;
  private extraMetadataForm: FormGroup;
  private searchResult$: Observable<Folder>;
  private isUpdateting$: Observable<Boolean>;
  private updated$: Observable<any>;

  private lastQuery$: Observable<QueryParams>;

  private error$: Observable<Error>;
  private subscriberfolderState: Subscription;
  private subscriberUpdateResult: Subscription;
  private subscriberLastQuery: Subscription;

  lastQuery: QueryParams;
  selectedFolderType: string;

  constructor(
    private store: Store<fromRoot.State>,
    private formBuilder: FormBuilder,
    private folderEffect: FolderEffect,

  ) {
    this.extraMetadataForm = this.formBuilder.group({});

    this.folderState$ = store.select(fromRoot.getFolderFirstResult);

    this.subscriberfolderState = this.folderState$.subscribe((folder: Folder) => {

      this.store.dispatch(new folderActions.InitUpdateFolder());

      const folderNew = Object.assign(Object.assign({}, folder, { tagList: null, listOfDocumentId: null }));
      if (folderNew.id) {
        this.metadataForm = this.formBuilder.group(folderNew);
        this.removeControls(this.extraMetadataForm);
      }
    });

    this.isUpdateting$ = store.select(fromRoot.getFolderUpdating);
    this.error$ = store.select(fromRoot.getFolderUpdateError);

    this.lastQuery$ = store.select(fromRoot.getSearchPagedQuery);

    this.updated$ = store.select( fromRoot.getFolderUpdateResult);
    this.subscriberLastQuery = this.lastQuery$.subscribe( lastQuery => this.lastQuery = lastQuery );

    this.subscriberUpdateResult = this.updated$.subscribe( id => {
      if (id && this.lastQuery) {
        this.folderEffect.getFolders(this.lastQuery);
      }
    });

  }

  updateDocTypeId( folderTypeId ) {
    this.selectedFolderType = folderTypeId;
    // Object.assign({}, this.metadataForm, { docTypeId: docTypeId });
  }

  removeControls(fg: FormGroup) {
    Object.keys(fg.controls).map(fc => this.extraMetadataForm.removeControl(fc));
  }

  save(metadataForm, extraMetadataForm) {
    const formModel = Object.assign({}, metadataForm, {
      tagList: Object.keys(extraMetadataForm).map(function (key) {
        // return { 'tagName': extraMetadataForm[key], 'tagValue': key };
        return { 'tagValue': extraMetadataForm[key], 'tagName': key };

      }),
      folderTypeId: this.selectedFolderType
    });
    // console.log(this.metadataForm, this.extraMetadataForm);
    // console.log(formModel);
    this.folderEffect.putFolderById(formModel.id, formModel);
  }

  ngOnInit() { }

  ngOnDestroy() {
    this.subscriberfolderState.unsubscribe();
    this.subscriberUpdateResult.unsubscribe();
    this.subscriberLastQuery.unsubscribe();
  }
}
