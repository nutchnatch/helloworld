import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { Subscription } from 'rxjs/Subscription';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Sidebar } from 'app/models/sidesbars-config';
import { Observable } from 'rxjs/Observable';
import { Component, Input, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as layoutActions from 'app/actions/layout.actions';
import { Envelope } from 'app/models/envelope';

@Component({
  selector: 'app-envelope-metadata-sidebar',
  templateUrl: './envelope-metadata-sidebar.component.html',
  styleUrls: ['./envelope-metadata-sidebar.component.scss']
})
export class EnvelopeMetadataSidebarComponent implements OnInit, OnDestroy {
  subscribeActiveRouteQueryParam: Subscription;

  private sidebarConfig$: Observable<Sidebar>;
  private envelopeState$: Observable<Envelope>;
  taskId;

  constructor(
    private store: Store<fromRoot.State>,
    private activatedRouter: ActivatedRoute,

  ) {

    this.sidebarConfig$ = store.select(fromRoot.getSideBarParams);
    this.envelopeState$ = store.select(fromRoot.getEnvelopeFirstResult);

  }

  ngOnInit () {
    this.subscribeActiveRouteQueryParam = this.activatedRouter.queryParamMap.subscribe((params: ParamMap) => {
      if (params.get('taskId')) {
        this.taskId = params.get('taskId');
      }
      // console.log(this.taskId)
    });
  }

  ngOnDestroy () {
    this.store.dispatch(new layoutActions.PutFromSearchAction(null));
  }


}
