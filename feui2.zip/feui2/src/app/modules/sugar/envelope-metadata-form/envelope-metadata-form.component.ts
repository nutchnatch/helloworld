import { TagClone } from 'app/models/tag';
import { EnvelopeEffect } from 'app/effects/envelope.effect';
import { Subscription } from 'rxjs/Subscription';
import { QueryParams } from 'app/models/paged';
import { Store } from '@ngrx/store';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Envelope } from 'app/models/envelope';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as envelopeActions from 'app/actions/envelope.actions';
import * as appConfigActions from 'app/actions/app-config.actions';


@Component({
  selector: 'app-envelope-metadata-form',
  templateUrl: './envelope-metadata-form.component.html',
  styleUrls: ['./envelope-metadata-form.component.scss']
})
export class EnvelopeMetadataFormComponent implements OnInit, OnDestroy {

  private metadataForm: FormGroup;
  private extraMetadataForm: FormGroup;
  private envelopeState$: Observable<Envelope>;
  private isUpdateting$: Observable<Boolean>;
  private error$: Observable<Error>;
  private updated$: Observable<any>;
  private lastQuery$: Observable<QueryParams>;
  private copiedTags$: Observable<Array<TagClone>>;

  private subscriberSearchResult: Subscription;
  private subscriberUpdateResult: Subscription;
  private subscriberLastQuery: Subscription;

  lastQuery: QueryParams;
  selecteEnvType: string;
  listOfDocumentIDMemory: Array<any>;

  constructor(
    private store: Store<fromRoot.State>,
    private formBuilder: FormBuilder,
    private envelopeEffect: EnvelopeEffect

  ) {
    this.extraMetadataForm = this.formBuilder.group({});

    this.envelopeState$ = store.select(fromRoot.getEnvelopeFirstResult);

    this.subscriberSearchResult = this.envelopeState$.subscribe((envelope: Envelope) => {
      this.store.dispatch(new envelopeActions.InitUpdateEnvelope());

      if (envelope) {

        this.listOfDocumentIDMemory = envelope.listOfDocumentId;
        this.metadataForm = this.formBuilder.group(Object.assign({}, envelope, { tagList: null, listOfDocumentId: null }));
        this.removeControls(this.extraMetadataForm);
      }
    });

    this.isUpdateting$ = store.select(fromRoot.getEnvelopeUpdating);
    this.error$ = store.select(fromRoot.getEnvelopeUpdateError);

    this.lastQuery$ = store.select(fromRoot.getSearchPagedQuery);

    this.updated$ = store.select( fromRoot.getFolderUpdateResult);
    this.subscriberLastQuery = this.lastQuery$.subscribe( lastQuery => this.lastQuery = lastQuery );

    this.subscriberUpdateResult = this.updated$.subscribe( id => {
      if (id && this.lastQuery) {
        this.envelopeEffect.getEnvelopes(this.lastQuery);
      }
    });

    this.copiedTags$ = store.select(fromRoot.getAppConfigCopiedTags);
  }

  updateDocTypeId(envTypeId) {
    // console.log(envTypeId);
    this.selecteEnvType = envTypeId;
    this.store.dispatch(new appConfigActions.PutCopiedTagsAction(null));

    // Object.assign({}, this.metadataForm, { docTypeId: docTypeId });
  }

  removeControls(fg: FormGroup) {
    Object.keys(fg.controls).map( fc => this.extraMetadataForm.removeControl(fc));
  }

  save(metadataForm, extraMetadataForm) {
    // console.log('on submit', metadataForm);
    // console.log(this.metadataForm, this.extraMetadataForm);

    const formModel = Object.assign({}, metadataForm, {
      tagList: Object.keys(extraMetadataForm).map(function (key) {
        // return { 'tagName': extraMetadataForm[key], 'tagValue': key };
        return { 'tagValue': extraMetadataForm[key], 'tagName': key };

      }),
      envTypeId: this.selecteEnvType,
      listOfDocumentId: this.listOfDocumentIDMemory
    });
    // console.log(this.metadataForm, this.extraMetadataForm);
    // console.log(formModel.id, formModel);
    this.envelopeEffect.putEnvelopeById(formModel.id, formModel);
    // this.store.dispatch(new searchPagedAction.PutSearchResultsSearchByID(document));
  }

  copyMetadata() {
    const extraMetadata = this.extraMetadataForm.value;
    const tagList = Object.keys(extraMetadata).map(function (key) {
      return { 'tagName': key, 'tagValue': extraMetadata[key]  };
    });
    this.store.dispatch(new appConfigActions.PutCopiedTagsAction(tagList));
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    this.subscriberSearchResult.unsubscribe();
    this.subscriberUpdateResult.unsubscribe();
    this.subscriberLastQuery.unsubscribe();
  }

}
