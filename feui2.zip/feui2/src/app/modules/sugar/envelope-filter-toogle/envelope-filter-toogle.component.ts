import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { Component } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as documentsFilterAction from 'app/actions/documents-filter.actions';

@Component({
  selector: 'app-envelope-filter-toogle',
  templateUrl: './envelope-filter-toogle.component.html',
  styleUrls: ['./envelope-filter-toogle.component.scss']
})
export class EnvelopeFilterToogleComponent {

  selectedCount$: Observable<any>;

  constructor(
    private store: Store<fromRoot.State>,
  ) {
    this.selectedCount$ = store.select(fromRoot.getDocumentsFilterListSelectedCount);
   }

  onChange(e) {
    this.store.dispatch( new documentsFilterAction.PutDocumentSelecedMultiple(e));
  }
}
