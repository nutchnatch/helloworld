import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { DateParserFormaterServices } from 'app/services/date-parser-formater/date-parser-formater.service';

import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';

import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as advanceSearch from 'app/actions/advance-search.actions';
import { DocumentTypes } from 'app/models/document-types';
import { EnvelopeTypes } from 'app/models/envelope-types';
import { FolderTypes } from 'app/models/folder-types';
import { concat } from 'rxjs/operator/concat';

import { flattenDepth, uniqBy, filter, find } from 'lodash';

@Component({
  selector: 'app-advance-search',
  templateUrl: './advance-search.component.html',
  styleUrls: ['./advance-search.component.scss']
})
export class AdvanceSearchComponent implements OnInit, OnDestroy {

  pageSize$: Observable<number>;
  currentLang$: Observable<string>;
  advanceQuery$: Observable<string>;
  formGroup$: Observable<any>;

  subscriberPageSize: Subscription;
  subscriberFormGroup: Subscription;

  searchQueryString: FormGroup;

  pageSize: number;

  constructor(
    private store: Store<fromRoot.State>,
    private router: Router,
    private dateParserFormatter: NgbDateParserFormatter
  ) {

    this.pageSize$ = store.select(fromRoot.getAppConfigPageSize);
    this.subscriberPageSize = this.pageSize$.subscribe(value => this.pageSize = value);
    this.currentLang$ = store.select(fromRoot.getCurrentLanguage);

    this.advanceQuery$ = store.select(fromRoot.getAdvanceSearchQuery);

    // this.advanceQuery$.subscribe(v => v && console.log(v.length));
  }

  onSearch(searchQueryString: FormGroup) {
    // console.log(searchQueryString.value.type.toLowerCase())
    // console.log(searchQueryString.value['advanceSearchQuery'])
    // tslint:disable-next-line:max-line-length
    const baseUrl = 'app/' + searchQueryString.value.type.toLowerCase();

    const query = Object.assign({},
      this.toQueryParams(searchQueryString.value['advanceSearchQuery']),
      { pageNumber: 1, pageSize: this.pageSize }
    );
    // tslint:disable-next-line:max-line-length
    this.router.navigate([baseUrl, query]);

  }

  ngOnInit() {
    // this.extraMetadataForm = this.formBuilder.group({});

    this.searchQueryString = new FormGroup({
      type: new FormControl('', Validators.required),
    });

    this.searchQueryString.addControl('advanceSearchQuery', new FormArray([]));
  }

  ngOnDestroy() {
    this.subscriberPageSize.unsubscribe();
  }

  toQueryParams(formValues): any {
    let paramsObj;
    const tagArray = [];

    const example = [
      {
        'tagName': 'updateDate',
        'operator': 'greater_than',
        'type': 'timestamp',
        'value': '2017-11-10',
        'defaultTag': true
      },
      {
        'tagName': 'name',
        'operator': 'equals_to',
        'type': 'string',
        'value': 'dev',
        'defaultTag': true
      },
      {
        'tagName': 'policy',
        'operator': 'equals_to',
        'type': 'string',
        'value': 'test1'
      },
      {
        'tagName': 'policy2',
        'operator': 'equals_to',
        'type': 'string',
        'value': 'test2'
      }
    ];



    filter(formValues, tag => tag['defaultTag'])
      .map(tag => {
        const value = tag.type === 'timestamp' ? this.dateParserFormatter.format(tag.value) : tag.value;
        paramsObj = Object.assign({}, paramsObj, { [tag.tagName]: tag.operator + '|' + value } );
      });

    filter(formValues, (tag) => !tag['defaultTag'])
      .map(tag => {
        // const b = a.concat(tag.tagName + '|' + tag.type + '|' + tag.operator + '|' + tag.value);
        const value = tag.type === 'timestamp' ? this.dateParserFormatter.format(tag.value) : tag.value;
        tagArray.push(tag.tagName + '|' + tag.type + '|' + tag.operator + '|' + value);
        paramsObj = Object.assign({}, paramsObj, { tags: tagArray });
      });
    // name=operator|value
    // tags=tagName|type|operator|value
    return paramsObj;
  }

}
