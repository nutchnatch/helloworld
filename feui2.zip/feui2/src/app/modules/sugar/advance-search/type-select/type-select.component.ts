import { AdvanceQuery } from './../../../../states/advance-search.state';
import { FormControl, Validators, FormGroup, FormArray } from '@angular/forms';
import { ExtraFields } from './../../../../states/extra-fields.state';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { Component, OnInit, OnDestroy, Input } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as advanceSearchActions from 'app/actions/advance-search.actions';
import { Subscription } from 'rxjs/Subscription';

import { filter } from 'lodash';

@Component({
  selector: 'app-type-select',
  templateUrl: './type-select.component.html',
  styleUrls: ['./type-select.component.scss']
})
export class TypeSelectComponent implements OnInit, OnDestroy {

  @Input() formGroup: FormGroup;
  @Input() index: number;
  @Input() length: number;
  @Input() last: Boolean;
  @Input() first: Boolean;

  private currentLang$: Observable<string>;
  private tagsList$: Observable<Array<ExtraFields>>;
  private subTagsList: Subscription;

  private operators$: Observable<Array<string>>;
  private subOperators: Subscription;

  operatorsSelected;
  tagsList;
  tagSelected;
  operators;
  minus: Boolean = false;
  // last: Boolean = false;

  constructor(
    private store: Store<fromRoot.State>,
  ) {

    this.currentLang$ = store.select(fromRoot.getCurrentLanguage);
    this.tagsList$ = store.select(fromRoot.getAdvanceSearchTagsList);

    this.subTagsList = this.tagsList$.subscribe(tagsList => this.tagsList = tagsList);

    this.operators$ = store.select(fromRoot.getAdvanceSearchDefaultOperators);
    this.subOperators = this.operators$.subscribe(operators => this.operators = operators );

  }

  onChange(type) {
    this.tagSelected = filter(this.tagsList, tag => tag.name === type);
    this.operatorsSelected = this.operators[0][this.tagSelected[0].type];
  }

  addRow() {
    this.minus = this.index === this.length - 1;
    this.store.dispatch(new advanceSearchActions.PutAdvanceSearch( new AdvanceQuery ));
  }

  removeRow(index: number) {
    const controls = <FormArray>this.formGroup.controls['advanceSearchQuery'];
    controls.removeAt(index);
    this.store.dispatch(new advanceSearchActions.RemoveAdvanceSearchByID( index ));
  }

  ngOnInit() {

    const controls = <FormArray>this.formGroup.controls['advanceSearchQuery'];
    controls.push( new FormGroup({
      tagName: new FormControl('', Validators.required),
      operator: new FormControl('', Validators.required),
      type: new FormControl('', Validators.required),
      value: new FormControl('', Validators.required),
      defaultTag: new FormControl('false')
    }));

  }

  ngOnDestroy() {
    this.subTagsList.unsubscribe();
    this.subOperators.unsubscribe();
  }

}
