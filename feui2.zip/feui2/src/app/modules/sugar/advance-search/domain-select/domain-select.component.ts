import { AdvanceQuery } from 'app/states/advance-search.state';
import { FormGroup, FormArray } from '@angular/forms';
import { DocumentTypes } from './../../../../models/document-types';
import { FolderTypes } from './../../../../models/folder-types';
import { EnvelopeTypes } from './../../../../models/envelope-types';
import { Subscription } from 'rxjs/Subscription';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { Component, OnInit, OnDestroy, Input } from '@angular/core';

import * as fromRoot from 'app/reducers';
import * as advanceSearchActions from 'app/actions/advance-search.actions';
import { Router } from '@angular/router';


@Component({
  selector: 'app-domain-select',
  templateUrl: './domain-select.component.html',
  styleUrls: ['./domain-select.component.scss']
})
export class DomainSelectComponent implements OnInit, OnDestroy {

  @Input() formGroup: any;

  searchList$: Observable<Object>;
  extraFields$: Observable<any>;
  domain$: Observable<string>;

  subscriberExtraFields: Subscription;
  subscriberDomain: Subscription;

  extraFields;
  type;
  constructor(
    private store: Store<fromRoot.State>,
    private router: Router,
  ) {
    this.searchList$ = store.select(fromRoot.getAppConfigSearchTypes);
    this.extraFields$ = store.select(fromRoot.getExtraFields);
    this.subscriberExtraFields = this.extraFields$.subscribe(extraFields => this.extraFields = extraFields);

    this.domain$ = store.select(fromRoot.getAdvanceSearchDomain);
    // this.type = 'Documents';
    this.subscriberDomain = this.domain$.subscribe( domain => this.type = domain ? domain : '' );
    // this.subscriberExtraFields = this.extraFields$.subscribe(extraFields => this.extraFields = extraFields);
  }

  onChangeType(type) {


    this.store.dispatch(new advanceSearchActions.PutDomain(type));
    this.store.dispatch(new advanceSearchActions.RemoveAllAdvanceSearch());

    const ControlsArray = <FormArray>this.formGroup.controls['advanceSearchQuery'];
    ControlsArray.controls = [];


    let extraFieldSelected;
    switch (type) {
      case 'Documents':
        extraFieldSelected = this.extraFields['metadataFields'];
        break;
      case 'Folders':
        extraFieldSelected = this.extraFields['folderMetadataFields'];
        break;
      case 'Envelopes':
        extraFieldSelected = this.extraFields['envelopeMetadataFields'];
        break;
      default:
        extraFieldSelected = this.extraFields['metadataFields'];

    }
    this.store.dispatch(new advanceSearchActions.PutDomainSelected(extraFieldSelected));
    this.store.dispatch(new advanceSearchActions.PutTagsList(extraFieldSelected));
    this.store.dispatch(new advanceSearchActions.PutAdvanceSearch( new AdvanceQuery ));

    const baseUrl = 'app/' + type.toLowerCase();
    this.router.navigate([ baseUrl ]);
  }

  ngOnInit() {
    // console.log(this.formGroup)
  }

  ngOnDestroy() {
    this.subscriberExtraFields.unsubscribe();
  }

}
