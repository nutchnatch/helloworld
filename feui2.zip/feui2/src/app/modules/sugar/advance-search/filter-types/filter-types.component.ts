import { Store } from '@ngrx/store';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import * as fromRoot from 'app/reducers';
import * as advanceSearchActions from 'app/actions/advance-search.actions';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-filter-types',
  templateUrl: './filter-types.component.html',
  styleUrls: ['./filter-types.component.scss']
})
export class FilterTypesComponent implements OnInit {

  private currentLang$: Observable<string>;
  private domainsSelected$: Observable<any>;
  private subDomainsSelected: Subscription;

  domainsSelected;
  domainsSelectedId;
  selected;

  constructor(
    private store: Store<fromRoot.State>,
  ) {
    this.currentLang$ = store.select(fromRoot.getCurrentLanguage);
    this.domainsSelected$ = store.select(fromRoot.getAdvanceSearchDomainSelected);

    this.subDomainsSelected = this.domainsSelected$.subscribe( domainsSelected => this.domainsSelected = domainsSelected );
  }

  onChange() {

    const extraFieldSelected = this.domainsSelected.filter( types => types.id === this.domainsSelectedId  );
    this.store.dispatch(new advanceSearchActions.PutTagsList(extraFieldSelected));
  }

  onFilter() {
    if (!this.selected) { this.store.dispatch(new advanceSearchActions.PutTagsList( this.domainsSelected )); }
  }

  ngOnInit() {
  }

}
