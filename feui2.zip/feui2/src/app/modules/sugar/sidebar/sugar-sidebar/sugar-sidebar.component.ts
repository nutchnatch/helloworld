import { Component, Input } from '@angular/core';
import { TranslateService }	from '@ngx-translate/core';
import { Observable } from 'rxjs/Observable';

import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as layoutAction from 'app/actions/layout.actions';

@Component({
  selector: 'app-sugar-sidebar',
  templateUrl: './sugar-sidebar.component.html',
  styleUrls: ['./sugar-sidebar.component.scss']
})

export class SugarSidebarComponent  {

  @Input() sidebarComponent;
  @Input() open = false;
  @Input() sidebarOpened = true;

  private sideBarPined$: Observable<boolean>;

  constructor(
     private store: Store<fromRoot.State>,
  ) {
    this.sideBarPined$ = store.select(fromRoot.getSideBarPined);
  }

  openSideBarMenu() {
    // tslint:disable-next-line:max-line-length
    (this.sidebarOpened) ? this.store.dispatch( new layoutAction.CloseSidenavAction() ) : this.store.dispatch( new layoutAction.OpenSidenavAction() );
  }

  tooglePinedSideBarMenu(bool: boolean) {

    // tslint:disable-next-line:max-line-length
    (!bool) ? this.store.dispatch( new layoutAction.PinSidenavAction() ) : this.store.dispatch( new layoutAction.UnPinSidenavAction() );
  }


}
