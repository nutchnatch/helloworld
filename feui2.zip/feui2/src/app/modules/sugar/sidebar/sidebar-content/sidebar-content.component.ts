import { Sidebar } from 'app/models/sidesbars-config';
import { Observable } from 'rxjs/Observable';
import { Component, Input } from '@angular/core';
import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as layoutAction from 'app/actions/layout.actions';

@Component({
  selector: 'app-sidebar-content',
  templateUrl: './sidebar-content.component.html',
  styleUrls: ['./sidebar-content.component.scss']
})
export class SidebarContentComponent  {

  private sideConfig$: Observable<Sidebar>;

  constructor(
    store: Store<fromRoot.State>
  ) {

    this.sideConfig$ = store.select(fromRoot.getSideBarParams);

  }
}
