import { Subscription } from 'rxjs/Subscription';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit, OnDestroy } from '@angular/core';


import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as layoutAction from 'app/actions/layout.actions';

@Component({
  selector: 'app-search-on-sidebar',
  templateUrl: './search-on-sidebar.component.html',
  styleUrls: ['./search-on-sidebar.component.scss']
})
export class SearchOnSidebarComponent implements OnInit, OnDestroy {

  searchList$: Observable<Object>;
  pageSize$: Observable<number>;
  subscriberPageSize: Subscription;

  searchQueryString: FormGroup;
  pageSize: number;
  advanceSearch$: Observable<Boolean>;
  subscriberAdvanceSearch: Subscription;
  selected = 'Documents';

  constructor(
    private store: Store<fromRoot.State>,
    private router: Router,
  ) {
    this.searchList$ = store.select(fromRoot.getAppConfigSearchTypes);
    this.pageSize$ = store.select(fromRoot.getAppConfigPageSize);
    this.subscriberPageSize = this.pageSize$.subscribe( value => this.pageSize = value);

    this.advanceSearch$ = store.select(fromRoot.getLayoutAdvanceSearch);

  }

  ngOnInit() {

    this.searchQueryString = new FormGroup({
      name: new FormControl(' '),
      type: new FormControl('', Validators.required)
    });

  }
  advanceSearch(bool) {
    this.store.dispatch(new layoutAction.PutAdvanceSearch(bool));
  }

  onSearch(searchQueryString: FormGroup) {
    // tslint:disable-next-line:max-line-length
    const baseUrl = 'app/' + searchQueryString.value.type.toLowerCase();
    // tslint:disable-next-line:max-line-length
    // console.log(baseUrl, Object.assign( {}, { name: 'contains|' + searchQueryString.value.name , pageNumber: 1, pageSize: this.pageSize }))
    this.router.navigate([ baseUrl, Object.assign( {}, { name: 'contains|' + searchQueryString.value.name , pageNumber: 1, pageSize: this.pageSize }) ]);
  }

  ngOnDestroy() {
    this.subscriberPageSize.unsubscribe();
  }

}
