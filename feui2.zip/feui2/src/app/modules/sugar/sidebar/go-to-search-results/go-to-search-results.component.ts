import { Router } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { Component, OnInit, OnDestroy } from '@angular/core';

import { Observable } from 'rxjs/Observable';

import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as layoutAction from 'app/actions/layout.actions';
import * as searchPreviewActions from 'app/actions/search-preview.actions';

@Component({
  selector: 'app-go-to-search-results',
  templateUrl: './go-to-search-results.component.html',
  styleUrls: ['./go-to-search-results.component.scss']
})
export class GoToSearchResultsComponent implements OnInit, OnDestroy {
  subFromSearch: Subscription;

  private fromSearch$: Observable<string>;
  private searchRoute: string;
  private routerEvent;
  private subscribeRouter: Subscription;


  constructor(
    private router: Router,
    private store: Store<fromRoot.State>
  ) {


    this.fromSearch$ = store.select(fromRoot.getLayoutFromSearch);
    this.subFromSearch = this.fromSearch$.subscribe( url => this.searchRoute = url );

  }

  goBack() {
    this.store.dispatch(new searchPreviewActions.InitSearchResultsSearchPreview());
    this.router.navigateByUrl(this.searchRoute);
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    // this.store.dispatch(new layoutAction.PutFromSearchAction(false));
    // this.subscribeRouter.unsubscribe();

    this.subFromSearch.unsubscribe();
  }

}
