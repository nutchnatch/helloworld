import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaksHandlersComponent } from './taks-handlers.component';

describe('TaksHandlersComponent', () => {
  let component: TaksHandlersComponent;
  let fixture: ComponentFixture<TaksHandlersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaksHandlersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaksHandlersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
