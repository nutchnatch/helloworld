import { TaskService } from 'app/services/task.service';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { Task } from './../../../../models/task';
import { Subscription } from 'rxjs/Subscription';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Component, OnInit } from '@angular/core';
import { TaskEffect } from 'app/effects/task.effect';
import * as fromRoot from 'app/reducers';
import { Observable } from 'rxjs/Observable';

import * as taskAction from 'app/actions/task.actions';

@Component({
  selector: 'app-taks-handlers',
  templateUrl: './taks-handlers.component.html',
  styleUrls: ['./taks-handlers.component.scss']
})
export class TaksHandlersComponent implements OnInit, OnDestroy {
  subscribeStatus: Subscription;
  subscribeActiveRouteQueryParams: Subscription;

  private task$: Observable<Task>;
  private taskError$: Observable<Error>;

  private status$: Observable<string>;
  private statusError$: Observable<Error>;
  private statusLoading$: Observable<Boolean>;

  currentBasketId: string;

  constructor(
    private store: Store<fromRoot.State>,
    private taskEffect: TaskEffect,
    private router: Router,
    private activatedRouter: ActivatedRoute,
    private taskService: TaskService) {
    this.taskError$ = store.select(fromRoot.getTasksError);

    this.task$ = store.select(fromRoot.getTasksResult);

    this.statusError$ = store.select(fromRoot.getTasksStatusError);
    this.statusLoading$ = store.select(fromRoot.getTasksStatusLoading);
    this.status$ = store.select(fromRoot.getTasksStatusResult);

    this.subscribeStatus = this.status$.subscribe(result => {
      if (result) {
        this.router.navigate(['app/refresh', { url: 'app/envelope/' + this.activatedRouter.snapshot.url[2].path }]);
      }
    });
  }

  closeTask() {
    if (this.currentBasketId) {
      this.taskEffect.putTaskByIdStatus(this.currentBasketId, 'CLOSE');
    }
  }

  ngOnDestroy() {
    this.store.dispatch(new taskAction.InitStatusTask());
    this.subscribeStatus.unsubscribe();
    this.subscribeActiveRouteQueryParams.unsubscribe();

  }

  ngOnInit() {
    this.subscribeActiveRouteQueryParams = this.activatedRouter.queryParamMap.subscribe((paramsMap: ParamMap | any) => {
      // this.currentBasketId = paramsMap.get('taskId');
      if (paramsMap.get('taskId')) {
        this.currentBasketId = paramsMap.get('taskId');
        this.taskEffect.getTasksById(paramsMap.get('taskId'));
      }
    });
  }



}
