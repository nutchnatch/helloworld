import { RemoveDocumentListByName } from './../../../actions/upload-documents.actions';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { Component, OnInit } from '@angular/core';
import { FileDropModule, UploadFile, UploadEvent } from 'ngx-file-drop';

import * as fromRoot from 'app/reducers';
import * as uploadDocumentsAction from 'app/actions/upload-documents.actions';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';

@Component({
  selector: 'app-file-drop',
  templateUrl: './file-drop.component.html',
  styleUrls: ['./file-drop.component.scss']
})
export class FileDropComponent implements OnInit, OnDestroy {

  private uploadDocument$: Observable<Array<File>>;

  public files: UploadFile[] = [];
  formData: FormData = new FormData();

  constructor(
    private store: Store<fromRoot.State>) {

    this.uploadDocument$ = store.select(fromRoot.getUploadDocumentsList);
    // this.uploadDocument$.subscribe( file => console.log('fiel' , file));
  }

  public dropped(event: UploadEvent) {
    const files = event.files;
    for (const file of files) {
      file.fileEntry.file( fileInfo => {
        this.store.dispatch(new uploadDocumentsAction.PutDocumentList(fileInfo));
        // this.formData.append('files', fileInfo, fileInfo.name);
        // console.log(this.formData.getAll('files'));
      });
    }
  }

  public fileOver(event) {  /*console.log(event);*/ }

  public fileLeave(event) {  /*console.log(event); */}

  fileChange(event) {
    const files = event.target.files;
    if (files.length > 0) {
      for (const fileInfo of files) {
        this.store.dispatch(new uploadDocumentsAction.PutDocumentList(fileInfo));
      }
    }
  }

  removeThis(name: string) {
    this.store.dispatch(new uploadDocumentsAction.RemoveDocumentListByName(name));
  }

  ngOnInit() {

  }

  ngOnDestroy() {
    this.store.dispatch(new uploadDocumentsAction.InitDocumentList());
  }

}
