import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnderConstructionEnvelopeResultsComponent } from './under-construction-envelope-results.component';

describe('UnderConstructionEnvelopeResultsComponent', () => {
  let component: UnderConstructionEnvelopeResultsComponent;
  let fixture: ComponentFixture<UnderConstructionEnvelopeResultsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnderConstructionEnvelopeResultsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnderConstructionEnvelopeResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
