import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';


import * as fromRoot from 'app/reducers';
import * as searchPagedAction from 'app/actions/search-paged.actions';
import * as searchPreviewAction from 'app/actions/search-preview.actions';

@Component({
  selector: 'app-under-construction-envelope-results',
  templateUrl: './under-construction-envelope-results.component.html',
  styleUrls: ['./under-construction-envelope-results.component.scss']
})
export class UnderConstructionEnvelopeResultsComponent implements OnInit {

  private searching$: Observable<boolean>;
  private error$: Observable<any>;
  // private searchType$: Observable<string>;
  private searchResult$: Observable<any>;

  constructor(
    private store: Store<fromRoot.State>,
  ) {
    this.searching$ = store.select(fromRoot.getSearchPagedLoading);
    this.searchResult$ = store.select(fromRoot.getSearchPagedResults);

    this.error$ = store.select(fromRoot.getSearchPagedError);

  }

  ngOnInit() {
  }

}
