import { Component, Input } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { Store } from '@ngrx/store';

import * as fromRoot from 'app/reducers';
import * as layout from 'app/actions/layout.actions';

@Component({
  selector: 'app-guarded-content',
  templateUrl: './guarded-content.component.html',
  styleUrls: ['./guarded-content.component.scss']
})
export class GuardedContentComponent {

  @Input() metadataComponent: boolean;

  showSidenav$: Observable<boolean>;
  sideBarPined$: Observable<boolean>;
  showMetadataBar$: Observable<boolean>;
  hasPreviewResult$: Observable<boolean>;

  constructor(
    private store: Store<fromRoot.State>,
  ) {
    this.showSidenav$ = store.select(fromRoot.getShowSidenav);
    this.sideBarPined$ = store.select(fromRoot.getSideBarPined);
    this.showMetadataBar$ = store.select(fromRoot.getMetadataBarShow);
    this.hasPreviewResult$ = store.select(fromRoot.getSearchPreviewHasResult);
   }
}
