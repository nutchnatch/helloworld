import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { Component, Input } from '@angular/core';
import * as fromRoot from 'app/reducers';

@Component({
  selector: 'app-main-content',
  templateUrl: './main-content.component.html',
  styleUrls: ['./main-content.component.scss']
})
export class MainContentComponent {
  hasPreviewResult$: Observable<any>;
  // showMetadataBar$: Observable<any>;

  @Input() sidebarOpened: Boolean = false;
  @Input() sidebarPined: Boolean = false;
  @Input() metadataOpened: Boolean = false;

  constructor(
    private store: Store<fromRoot.State>,

  ) {
    // this.showMetadataBar$ = store.select(fromRoot.getMetadataBarShow);
    this.hasPreviewResult$ = store.select(fromRoot.getSearchPreviewHasResult);
   // this.hasPreviewResult$.subscribe(v=> console.log(v))
  }
}
