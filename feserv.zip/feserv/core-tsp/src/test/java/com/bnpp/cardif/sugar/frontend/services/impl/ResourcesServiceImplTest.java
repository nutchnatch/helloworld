/**
 * 
 */
package com.bnpp.cardif.sugar.frontend.services.impl;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.security.AuthenticatedUser;

/**
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ResourcesServiceImplTest extends FrontendGenericServiceTest {

    @InjectMocks
    private ResourcesServiceImpl sesourcesServiceImpl = new ResourcesServiceImpl();

    /**
     * Test method for
     * {@link com.bnpp.cardif.sugar.frontend.services.impl.ResourcesServiceImpl#getCurrentUser()}.
     * @throws TechnicalException 
     */
    @Test
    public void testGetCurrentUser() throws TechnicalException {

        AuthenticatedUser finalResult = sesourcesServiceImpl.getCurrentUser();

        // Validation
        assertNotNull(finalResult);
        assertEquals(commercialVersion, finalResult.getCommercialVersion());
        assertEquals(userName, finalResult.getUsername());
        assertEquals(password, finalResult.getPassword());
        assertEquals(fakeToken, finalResult.getToken());
        assertEquals(firstName, finalResult.getFirstName());
        assertEquals(lastName, finalResult.getLastName());
    }

}
