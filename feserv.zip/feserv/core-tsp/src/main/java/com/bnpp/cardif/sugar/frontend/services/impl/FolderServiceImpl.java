package com.bnpp.cardif.sugar.frontend.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenCreator;
import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.DocumentService;
import com.bnpp.cardif.sugar.frontend.services.FolderService;
import com.bnpp.cardif.sugar.frontend.services.model.PagingList;
import com.bnpp.cardif.sugar.security.AuthenticatedUser;
import com.bnpp.cardif.sugar.utils.CollectionUtils;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.MCOFolderType.ChildComponents;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderStatusCodeType;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Item;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Operators;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Types;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.CreateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.FindRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.FindResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.SugarFolder;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.UpdateResponse;

/**
 * 
 * @author 831743
 *
 */
@Service("folderService")
@Scope("singleton")
public class FolderServiceImpl extends FrontendGenericServiceImpl implements FolderService {

    private static final int MAX_FOLDER_PER_DOC = 20;

    private static final Logger LOGGER = LoggerFactory.getLogger(FolderServiceImpl.class);

    @Autowired
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    @Autowired
    private DocumentService documentService;

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.FolderService#getFolderByID(java.
     * lang.String)
     */
    public Folder getFolderByID(String id) throws TechnicalException, FunctionalException {

        LOGGER.debug("getFolderByID called");
        // validate input
        this.validateInputFolderById(id);
        // create Input
        List<String> ids = new ArrayList<>();
        ids.add(id);
        // call
        List<Folder> folderList = this.getFolderByIDs(ids, true);
        if (folderList.isEmpty()) {
            // error 1 document expected 0 are returned.
            throw new TechnicalException(ErrorCode.TE002);
        }
        // extract result
        LOGGER.debug("getFolderByID end");
        return folderList.get(0);
    }

    private void validateInputFolderById(String id) throws InvalidInputException {
        if (id == null || id.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "ID");
        }
    }

    private List<Folder> getFolderByIDs(final List<String> ids, boolean includeChild)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("getFolderByIDs called");
        List<Folder> folderList = new ArrayList<>();
        // validate input
        this.validateInputFolderByIds(ids);
        // call webService
        SugarFolder service = sugarWebServiceClientFactory.getSugarFolderWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        GetRequest parameters = new GetRequest();
        parameters.setScope(getScope());
        List<FolderId> folderIdList = parameters.getFolderId();
        fillFolderIdList(ids, folderIdList);
        try {

            GetResponse result = service.get(parameters, securityToken);
            folderList = result.getFolder();
            // add the child documents if required.
            enrichFolderListWithChilds(includeChild, folderList);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("getFolderByIDs end");
        return folderList;
    }

    private void enrichFolderListWithChilds(boolean includeChild, List<Folder> folderList)
            throws TechnicalException, FunctionalException {
        if (includeChild) {
            for (Folder folder : folderList) {
                ChildComponents childObject = folder.getChildComponents();
                addChildDocument(childObject);
            }
        }
    }

    private void addChildDocument(ChildComponents childObject) throws TechnicalException, FunctionalException {
        if (childObject != null && childObject.getId() != null && !childObject.getId().isEmpty()) {
            List<Id> childIdList = childObject.getId();
            List<String> childIds = new ArrayList<>();
            for (Id id : childIdList) {
                childIds.add(id.getValue());
            }
            LOGGER.debug("childIdList : {}", childIdList);
            List<Document> childDocumentList = documentService.getDocumentByIDs(childIds);
            if (childDocumentList != null && !childDocumentList.isEmpty()) {
                List<Document> childObjectDocumentList = childObject.getDocument();
                if (childObjectDocumentList == null) {
                    childObjectDocumentList = new ArrayList<>();
                }
                childObjectDocumentList.clear();
                childObjectDocumentList.addAll(childDocumentList);
            }
        }
    }

    private void validateInputFolderByIds(List<String> ids) throws InvalidInputException {
        if (ids == null || ids.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "ids");
        }
    }

    @SuppressWarnings("squid:S1226")
    private void fillFolderIdList(final List<String> ids, List<FolderId> folderIdList) {
        if (folderIdList == null) {
            folderIdList = new ArrayList<>();
        }
        for (String id : ids) {
            FolderId content = new FolderId();
            content.setIssuer(ISSUER);
            content.setScheme(SCHEME);
            content.setValue(id);
            folderIdList.add(content);
        }
    }

    public PagingList<Folder> findFolders(long start, long maximum, String quickSearchValue,
            List<Criterion> criterionList, OrderClause orderClause, boolean includeChild)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("findFolders called");
        PagingList<Folder> folderList = null;
        List<Criterion> searchCriterionList = new ArrayList<>();
        OrderClause searchOrderClause = null;
        // validate input
        this.validateInputFindDocuments(start, maximum);
        // call web service
        try {
            TokenType securityToken = TokenCreator.getTokenType();
            SugarFolder service = sugarWebServiceClientFactory.getSugarFolderWSP();
            FindRequest requestParam = new FindRequest();
            requestParam.setIncludeChild(includeChild);
            requestParam.setIncludeFiles(false);
            // paging
            requestParam.setStart(start);
            requestParam.setMax(maximum);
            buildSearchCriteria(quickSearchValue, criterionList, searchCriterionList);
            // search criteria
            Criteria searchCriteria = new Criteria(searchCriterionList, Item.FOLDER, false);
            requestParam.setCriteria(searchCriteria);
            // ordering
            if (orderClause == null) {
                searchOrderClause = generateDefaultOrderClause();
            }
            else {
                searchOrderClause = orderClause;
            }
            requestParam.setOrder(searchOrderClause);
            LOGGER.info("findFolders Starting search for {} folders and criteria {} with order {}", maximum - start,
                    searchCriteria, orderClause);
            FindResponse result = service.find(requestParam, securityToken);
            if (result != null && result.getFolder() != null) {
                folderList = new PagingList<>();
                folderList.setItemList(result.getFolder());
                folderList.setItemMax(result.getMaxSearch());
                folderList.setItemNumber(result.getFound());
            }
            else {
                folderList = new PagingList<>();
            }
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("findFolders end");
        return folderList;
    }

    private void validateInputFindDocuments(long start, long maximum) throws InvalidInputException {
        List<String> missingInputs = new ArrayList<>();
        if (start < 0) {
            missingInputs.add("start");
        }
        if (maximum < 1) {
            missingInputs.add("maximum");
        }
        if (!missingInputs.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + CollectionUtils.collectionToString(missingInputs));
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.FolderService#
     * getFoldersByDocumentId(java.lang.String)
     */
    public List<Folder> getFoldersByDocumentId(String documentId) throws TechnicalException, FunctionalException {

        LOGGER.debug("getFoldersByDocumentId called");
        List<Folder> folderList = null;
        List<Criterion> searchCriterionList = new ArrayList<>();
        OrderClause searchOrderClause = null;
        // validate input
        if (documentId == null || documentId.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "documentId");
        }
        // call web service
        try {
            TokenType securityToken = TokenCreator.getTokenType();
            SugarFolder service = sugarWebServiceClientFactory.getSugarFolderWSP();
            FindRequest requestParam = new FindRequest();
            requestParam.setIncludeChild(false);
            requestParam.setIncludeFiles(false);
            // paging
            requestParam.setStart(0);
            requestParam.setMax(MAX_FOLDER_PER_DOC);
            // search criteria
            buildFolderByDocIDCriteria(documentId, searchCriterionList);
            Criteria searchCriteria = new Criteria(searchCriterionList, Item.FOLDER, false);
            requestParam.setCriteria(searchCriteria);
            // ordering
            searchOrderClause = generateDefaultOrderClause();
            requestParam.setOrder(searchOrderClause);
            LOGGER.info("getFoldersByDocumentId Starting search for {} folders and criteria {} with order {}",
                    MAX_FOLDER_PER_DOC, searchCriteria, searchOrderClause);
            FindResponse result = service.find(requestParam, securityToken);
            if (result != null && result.getFolder() != null) {
                folderList = result.getFolder();
            }
            else {
                folderList = new ArrayList<>();
            }
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("getFoldersByDocumentId end");
        return folderList;
    }

    private void buildFolderByDocIDCriteria(String documentId, List<Criterion> searchCriterionList)
            throws TechnicalException {

        // build the Document ID criteria
        List<Criterion> criterionList = new ArrayList<>();
        List<String> documentIdValues = new ArrayList<>();
        documentIdValues.add(ISSUER);
        documentIdValues.add(SCHEME);
        documentIdValues.add(documentId);
        Criterion criterion = new Criterion(Levels.CHILD, "Id", Operators.EQUALS_TO, Types.STRING, documentIdValues);
        criterionList.add(criterion);
        // build the final criteria
        buildSearchCriteria(null, criterionList, searchCriterionList);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.FolderService#createFolders(java.
     * util.List)
     */
    public List<Folder> createFolders(List<Folder> folderList) throws FunctionalException, TechnicalException {

        LOGGER.debug("createFolders called");
        List<Folder> outputFolderList = null;
        // validate input
        if (folderList == null || folderList.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "folderList");
        }
        // call web service
        try {
            // assign current User as owner of the folders.
            assignFolderOwner(folderList);
            TokenType securityToken = TokenCreator.getTokenType();
            SugarFolder service = sugarWebServiceClientFactory.getSugarFolderWSP();
            CreateRequest parameters = new CreateRequest();
            List<Folder> inpuFolderList = parameters.getFolder();
            inpuFolderList.addAll(folderList);
            CreateResponse result = service.create(parameters, securityToken);
            outputFolderList = result.getFolder();
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("createFolders end");
        return outputFolderList;
    }

    private void assignFolderOwner(List<Folder> folderList) throws TechnicalException {
        AuthenticatedUser currentUser = getCurrentUser();
        if (currentUser != null) {
            for (Folder folder : folderList) {
                FolderDataType folderData = folder.getData();
                folderData.setOwner(currentUser.getUsername());
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.FolderService#updateFolders(java.
     * util.List)
     */
    public List<Folder> updateFolders(List<Folder> folderList) throws FunctionalException, TechnicalException {

        LOGGER.debug("updateFolders called");
        List<Folder> outputFolderList = null;
        // validate input
        if (folderList == null || folderList.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "folderList");
        }
        // call web service
        try {
            TokenType securityToken = TokenCreator.getTokenType();
            SugarFolder service = sugarWebServiceClientFactory.getSugarFolderWSP();
            UpdateRequest parameters = new UpdateRequest();
            List<Folder> inpuFolderList = parameters.getFolder();
            inpuFolderList.addAll(folderList);
            UpdateResponse result = service.update(parameters, securityToken);
            outputFolderList = result.getFolder();
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("updateFolders end");
        return outputFolderList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.FolderService#
     * attachDocumentToFolder(java.lang.String, java.util.List)
     */
    public Folder attachDocumentToFolder(String folderId, List<String> documentIdlist)
            throws FunctionalException, TechnicalException {

        LOGGER.debug("attachDocumentToFolder called");
        Folder outputFolder = null;
        // validate input
        if (folderId == null || folderId.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "folderId");
        }
        if (documentIdlist == null || documentIdlist.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + "documentIdlist");
        }
        // call web service
        try {
            TokenType securityToken = TokenCreator.getTokenType();
            SugarFolder service = sugarWebServiceClientFactory.getSugarFolderWSP();
            // Retrieve existing folder
            Folder existingFolder = getFolderByID(folderId);
            if (!FolderStatusCodeType.OPEN.equals(existingFolder.getData().getStatusCode())) {
                // the folder is not opened cannot add documents
                throw new FunctionalException(ErrorCode.FE004);
            }
            // add the document to the folder
            ChildComponents childComponents = existingFolder.getChildComponents();
            List<Id> idList = childComponents.getId();
            for (String documentId : documentIdlist) {
                Id id = new Id(documentId, ISSUER, SCHEME);
                if (!idList.contains(id)) {
                    idList.add(id);
                }
                else {
                    throw new FunctionalException(ErrorCode.FE005.getCode(), ErrorCode.FE005.getMessage()
                            + "document Id : " + documentId + "already in folder : " + folderId);
                }
            }
            // save the updated folder
            UpdateRequest parameters = new UpdateRequest();
            List<Folder> inpuFolderList = parameters.getFolder();
            inpuFolderList.add(existingFolder);
            UpdateResponse result = service.update(parameters, securityToken);
            List<Folder> outputFolderList = result.getFolder();
            if (outputFolderList.isEmpty()) {
                // error 1 document expected 0 are returned.
                throw new TechnicalException(ErrorCode.TE002);
            }
            // extract result
            outputFolder = outputFolderList.get(0);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("attachDocumentToFolder end");
        return outputFolder;
    }

    public Folder detachDocumentFromFolder(String folderId, List<String> documentIdlist)
            throws FunctionalException, TechnicalException {

        LOGGER.debug("attachDocumentToFolder called");
        Folder outputFolder = null;
        // validate input
        if (folderId == null || folderId.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "folderId");
        }
        if (documentIdlist == null || documentIdlist.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + "documentIdlist");
        }
        // call web service
        try {
            TokenType securityToken = TokenCreator.getTokenType();
            SugarFolder service = sugarWebServiceClientFactory.getSugarFolderWSP();
            // Retrieve existing folder
            Folder existingFolder = getFolderByID(folderId);
            if (!FolderStatusCodeType.OPEN.equals(existingFolder.getData().getStatusCode())) {
                // the folder is not opened cannot add documents
                throw new FunctionalException(ErrorCode.FE004);
            }
            // remove the document to the folder
            ChildComponents childComponents = existingFolder.getChildComponents();
            List<Id> idList = childComponents.getId();
            for (String documentId : documentIdlist) {
                Id id = new Id(documentId, ISSUER, SCHEME);
                if (idList.contains(id)) {
                    idList.remove(id);
                }
                else {
                    throw new FunctionalException(ErrorCode.FE006.getCode(), ErrorCode.FE006.getMessage()
                            + "document Id : " + documentId + "is not in folder : " + folderId);
                }
            }
            // save the updated folder
            UpdateRequest parameters = new UpdateRequest();
            List<Folder> inpuFolderList = parameters.getFolder();
            inpuFolderList.add(existingFolder);
            UpdateResponse result = service.update(parameters, securityToken);
            List<Folder> outputFolderList = result.getFolder();
            if (outputFolderList.isEmpty()) {
                // error 1 document expected 0 are returned.
                throw new TechnicalException(ErrorCode.TE002);
            }
            // extract result
            outputFolder = outputFolderList.get(0);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("attachDocumentToFolder end");
        return outputFolder;
    }

}
