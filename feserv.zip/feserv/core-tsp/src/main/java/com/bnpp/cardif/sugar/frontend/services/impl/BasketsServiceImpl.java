package com.bnpp.cardif.sugar.frontend.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenCreator;
import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.BasketsService;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.CreateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.DeleteRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.GetAllRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.GetAllResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.SugarBasket;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.UpdateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;

/**
 * 
 * @author 831743
 *
 */
@Service("basketsService")
@Scope("singleton")
public class BasketsServiceImpl extends FrontendGenericServiceImpl implements BasketsService {

    private static final Logger LOGGER = LoggerFactory.getLogger(BasketsServiceImpl.class);

    @Autowired
    SugarWebServiceClientFactory sugarWebServiceClientFactory;

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.BasketsService#getAllBasketList()
     */
    public List<Basket> getAllBasketList() throws TechnicalException, FunctionalException {

        LOGGER.debug("getAllBasketList called");
        List<Basket> basketList = null;
        // call webService
        try {
            SugarBasket service = sugarWebServiceClientFactory.getSugarBasketWSP();
            TokenType securityToken = TokenCreator.getTokenType();
            GetAllRequest parameters = new GetAllRequest();
            parameters.setScope(this.getScope());
            GetAllResponse result = service.getAll(parameters, securityToken);
            if (result != null) {
                basketList = result.getBasket();
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("getAllBasketList end");
        return basketList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.BasketsService#getBasketListByIds
     * (java.util.List)
     */
    public List<Basket> getBasketListByIds(List<String> idList) throws TechnicalException, FunctionalException {

        LOGGER.debug("getBasketListByIds called");
        List<Basket> basketList = null;
        if (idList == null || idList.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "idList");
        }
        // call webService
        SugarBasket service = sugarWebServiceClientFactory.getSugarBasketWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        try {
            GetRequest parameters = new GetRequest();
            parameters.setScope(this.getScope());
            List<BasketId> basketIds = parameters.getBasketId();
            for (String id : idList) {
                BasketId basketId = new BasketId(id, ISSUER, SCHEME);
                basketIds.add(basketId);
            }
            GetResponse result = service.get(parameters, securityToken);
            if (result != null) {
                basketList = result.getBasket();
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("getBasketListByIds end");
        return basketList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.BasketsService#getBasketByID(java
     * .lang.String)
     */
    public Basket getBasketByID(String id) throws TechnicalException, FunctionalException {

        LOGGER.debug("getBasketByID called");
        // validate input
        if (id == null || id.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "id");
        }
        // create Input
        List<String> ids = new ArrayList<>();
        ids.add(id);
        // call
        List<Basket> basketList = this.getBasketListByIds(ids);
        if (basketList.isEmpty()) {
            // error 1 basket expected 0 are returned.
            throw new TechnicalException(ErrorCode.TE002);
        }
        // extract result
        LOGGER.debug("getBasketByID end");
        return basketList.get(0);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.BasketsService#createBaskets(java
     * .util.List)
     */
    public List<Basket> createBaskets(List<Basket> basketList) throws FunctionalException, TechnicalException {

        LOGGER.debug("createBaskets called");
        List<Basket> outputBasketList = null;
        // validate input
        if (basketList == null || basketList.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "basketList");
        }
        // call web service
        try {
            TokenType securityToken = TokenCreator.getTokenType();
            SugarBasket service = sugarWebServiceClientFactory.getSugarBasketWSP();
            CreateRequest parameters = new CreateRequest();
            List<Basket> inpuFolderList = parameters.getBasket();
            inpuFolderList.addAll(basketList);
            CreateResponse result = service.create(parameters, securityToken);
            outputBasketList = result.getBasket();
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("createBaskets end");
        return outputBasketList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.BasketsService#createBasket(com.
     * bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket)
     */
    public Basket createBasket(Basket inputBasket) throws TechnicalException, FunctionalException {

        LOGGER.debug("createBasket called");
        // validate input
        if (inputBasket == null) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "inputBasket");
        }
        // create Input
        List<Basket> inputBasketList = new ArrayList<>();
        inputBasketList.add(inputBasket);
        // call
        List<Basket> basketList = this.createBaskets(inputBasketList);
        if (basketList.isEmpty()) {
            // error 1 basket expected 0 are returned.
            throw new TechnicalException(ErrorCode.TE002);
        }
        // extract result
        LOGGER.debug("createBasket end");
        return basketList.get(0);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.BasketsService#updateBaskets(java
     * .util.List)
     */
    public List<Basket> updateBaskets(List<Basket> basketList) throws FunctionalException, TechnicalException {

        LOGGER.debug("updateBaskets called");
        List<Basket> outputFolderList = null;
        // validate input
        if (basketList == null || basketList.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "basketList");
        }
        // call web service
        try {
            TokenType securityToken = TokenCreator.getTokenType();
            SugarBasket service = sugarWebServiceClientFactory.getSugarBasketWSP();
            UpdateRequest parameters = new UpdateRequest();
            List<Basket> inpuFolderList = parameters.getBasket();
            inpuFolderList.addAll(basketList);
            UpdateResponse result = service.update(parameters, securityToken);
            outputFolderList = result.getBasket();
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("updateBaskets end");
        return outputFolderList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.BasketsService#updateBasket(com.
     * bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket)
     */
    public Basket updateBasket(Basket inputBasket) throws TechnicalException, FunctionalException {

        LOGGER.debug("updateBasket called");
        // validate input
        if (inputBasket == null) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "inputBasket");
        }
        // create Input
        List<Basket> inputBasketList = new ArrayList<>();
        inputBasketList.add(inputBasket);
        // call
        List<Basket> basketList = this.updateBaskets(inputBasketList);
        if (basketList.isEmpty()) {
            // error 1 basket expected 0 are returned.
            throw new TechnicalException(ErrorCode.TE002);
        }
        // extract result
        LOGGER.debug("updateBasket end");
        return basketList.get(0);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.BasketsService#deleteBaskets(java
     * .util.List)
     */
    public void deleteBaskets(List<String> idList) throws FunctionalException, TechnicalException {

        LOGGER.debug("deleteBaskets called");
        // validate input
        if (idList == null || idList.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "idList");
        }
        // call web service
        try {
            TokenType securityToken = TokenCreator.getTokenType();
            SugarBasket service = sugarWebServiceClientFactory.getSugarBasketWSP();
            DeleteRequest parameters = new DeleteRequest();
            parameters.setScope(getScope());
            List<BasketId> basketIds = parameters.getBasketId();
            for (String id : idList) {
                BasketId basketId = new BasketId(id, ISSUER, SCHEME);
                basketIds.add(basketId);
            }
            service.delete(parameters, securityToken);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("deleteBaskets end");
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.BasketsService#deleteBasket(java.
     * lang.String)
     */
    public void deleteBasket(String inputBasketId) throws TechnicalException, FunctionalException {

        LOGGER.debug("deleteBasket called");
        // validate input
        if (inputBasketId == null) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + "inputBasketId");
        }
        // create Input
        List<String> inputBasketList = new ArrayList<>();
        inputBasketList.add(inputBasketId);
        // call
        this.deleteBaskets(inputBasketList);
        // extract result
        LOGGER.debug("deleteBasket end");
    }
}
