package com.bnpp.cardif.sugar.frontend.services.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenCreator;
import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.TasksService;
import com.bnpp.cardif.sugar.frontend.services.model.PagingList;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.GetAllInBasketRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.GetAllInBasketResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.GetWithDocRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.GetWithDocResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.LockRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.LockResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.SugarTask;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.TransferRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.TransferResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.UnlockRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.UnlockResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.UpdateStatusRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.UpdateStatusResponse;

/**
 * 
 * @author 831743
 *
 */
@Service("tasksService")
@Scope("singleton")
public class TasksServiceImpl extends FrontendGenericServiceImpl implements TasksService {

    private static final Logger LOGGER = LoggerFactory.getLogger(TasksServiceImpl.class);

    @Autowired
    SugarWebServiceClientFactory sugarWebServiceClientFactory;

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.TasksService#getTaskListByBasket(
     * java.lang.String, long, long)
     */
    public PagingList<Task> getTaskListByBasket(String basketIdValue, long start, long maximum)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("getTaskListByBasket called");
        PagingList<Task> taskList = null;
        // validate input
        this.validateInputGetByBasket(basketIdValue, start, maximum);
        // call webService
        try {
            SugarTask service = sugarWebServiceClientFactory.getSugarTaskWSP();
            TokenType securityToken = TokenCreator.getTokenType();
            GetAllInBasketRequest parameters = new GetAllInBasketRequest();
            BasketId basketId = new BasketId(basketIdValue, ISSUER, SCHEME);
            parameters.setBasketId(basketId);
            parameters.setMax(maximum);
            parameters.setScope(getScope());
            parameters.setStart(start);
            GetAllInBasketResponse result = service.getAllInBasket(parameters, securityToken);
            taskList = new PagingList<>();
            if (result != null) {
                taskList.setItemList(result.getTask());
                taskList.setItemMax(maximum);
                taskList.setItemNumber(result.getNbFind());
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("getTaskListByBasket end");
        return taskList;
    }

    private void validateInputGetByBasket(String basketIdValue, long start, long maximum) throws InvalidInputException {
        if (start < 0) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "start");
        }
        if (maximum < 1) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "maximum");
        }
        if (basketIdValue == null || basketIdValue.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + "basketIdValue");
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.TasksService#getTaskByID(java.
     * lang.String)
     */
    public Task getTaskByID(String taskIdValue) throws TechnicalException, FunctionalException {

        LOGGER.debug("getTaskByID called");
        Task task = null;
        // validate input
        if (taskIdValue == null || taskIdValue.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "taskIdValue");
        }
        // call webService
        try {
            SugarTask service = sugarWebServiceClientFactory.getSugarTaskWSP();
            TokenType securityToken = TokenCreator.getTokenType();
            GetRequest parameters = new GetRequest();
            List<TaskId> idList = parameters.getTaskId();
            TaskId id = new TaskId(taskIdValue, ISSUER, SCHEME);
            idList.add(id);
            parameters.setScope(getScope());
            GetResponse result = service.get(parameters, securityToken);
            if (result != null && result.getTask() != null && !result.getTask().isEmpty()) {
                task = result.getTask().get(0);
            }
            else {
                // error 1 Task expected 0 are returned.
                throw new TechnicalException(ErrorCode.TE002);
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("getTaskByID end");
        return task;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.TasksService#transferTask(java.
     * lang.String, java.lang.String)
     */
    public String transferTask(String taskIdValue, String basketIdValue)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("transferTask called");
        String updatedTaskIdValue = null;
        // validate input
        if (taskIdValue == null || taskIdValue.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "taskIdValue");
        }
        if (basketIdValue == null || basketIdValue.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + "basketIdValue");
        }
        // call webService
        try {
            SugarTask service = sugarWebServiceClientFactory.getSugarTaskWSP();
            TokenType securityToken = TokenCreator.getTokenType();
            TransferRequest parameters = new TransferRequest();
            List<TaskId> taskIdList = parameters.getTaskId();
            TaskId taskId = new TaskId(taskIdValue, ISSUER, SCHEME);
            taskIdList.add(taskId);
            parameters.setScope(getScope());
            BasketId basketId = new BasketId(basketIdValue, ISSUER, SCHEME);
            parameters.setBasketId(basketId);
            TransferResponse result = service.transfer(parameters, securityToken);
            if (result != null && result.getTaskId() != null && !result.getTaskId().isEmpty()) {
                TaskId updatedTaskId = result.getTaskId().get(0);
                updatedTaskIdValue = updatedTaskId.getValue();
            }
            else {
                // error 1 Task expected 0 are returned.
                throw new TechnicalException(ErrorCode.TE002);
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("transferTask end");
        return updatedTaskIdValue;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.TasksService#lockTask(java.lang.
     * String)
     */
    public String lockTask(String taskIdValue) throws TechnicalException, FunctionalException {

        LOGGER.debug("lockTask called");
        String updatedTaskIdValue = null;
        // validate input
        if (taskIdValue == null || taskIdValue.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "taskIdValue");
        }
        // call webService
        try {
            SugarTask service = sugarWebServiceClientFactory.getSugarTaskWSP();
            TokenType securityToken = TokenCreator.getTokenType();
            LockRequest parameters = new LockRequest();
            List<TaskId> taskIdList = parameters.getTaskId();
            TaskId taskId = new TaskId(taskIdValue, ISSUER, SCHEME);
            taskIdList.add(taskId);
            parameters.setScope(getScope());
            parameters.setLocker(getCurrentUser().getUsername());
            LockResponse result = service.lock(parameters, securityToken);
            if (result != null && result.getTaskId() != null && !result.getTaskId().isEmpty()) {
                TaskId updatedTaskId = result.getTaskId().get(0);
                updatedTaskIdValue = updatedTaskId.getValue();
            }
            else {
                // error 1 Task expected 0 are returned.
                throw new TechnicalException(ErrorCode.TE002);
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("lockTask end");
        return updatedTaskIdValue;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.TasksService#unlockTask(java.lang
     * .String)
     */
    public String unlockTask(String taskIdValue) throws TechnicalException, FunctionalException {

        LOGGER.debug("unlockTask called");
        String updatedTaskIdValue = null;
        // validate input
        if (taskIdValue == null || taskIdValue.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "taskIdValue");
        }
        // call webService
        try {
            SugarTask service = sugarWebServiceClientFactory.getSugarTaskWSP();
            TokenType securityToken = TokenCreator.getTokenType();
            UnlockRequest parameters = new UnlockRequest();
            List<TaskId> taskIdList = parameters.getTaskId();
            TaskId taskId = new TaskId(taskIdValue, ISSUER, SCHEME);
            taskIdList.add(taskId);
            parameters.setScope(getScope());
            UnlockResponse result = service.unlock(parameters, securityToken);
            if (result != null && result.getTaskId() != null && !result.getTaskId().isEmpty()) {
                TaskId updatedTaskId = result.getTaskId().get(0);
                updatedTaskIdValue = updatedTaskId.getValue();
            }
            else {
                // error 1 Task expected 0 are returned.
                throw new TechnicalException(ErrorCode.TE002);
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("unlockTask end");
        return updatedTaskIdValue;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.TasksService#updateTaskStatus(
     * java.lang.String, java.lang.String)
     */
    public String updateTaskStatus(String taskIdValue, String statusValue)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("updateTaskStatus called");
        String updatedTaskStatus = null;
        // validate input
        if (taskIdValue == null || taskIdValue.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "taskIdValue");
        }
        if (statusValue == null || statusValue.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "statusValue");
        }
        // call webService
        try {
            SugarTask service = sugarWebServiceClientFactory.getSugarTaskWSP();
            TokenType securityToken = TokenCreator.getTokenType();
            UpdateStatusRequest parameters = new UpdateStatusRequest();
            List<TaskId> taskIdList = parameters.getTaskId();
            TaskId taskId = new TaskId(taskIdValue, ISSUER, SCHEME);
            taskIdList.add(taskId);
            parameters.setScope(getScope());
            parameters.setStatus(statusValue);
            UpdateStatusResponse result = service.updateStatus(parameters, securityToken);
            if (result != null && result.getStatus() != null && !result.getStatus().isEmpty()) {
                updatedTaskStatus = result.getStatus();
            }
            else {
                // error 1 Task expected 0 are returned.
                throw new TechnicalException(ErrorCode.TE002);
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("updateTaskStatus end");
        return updatedTaskStatus;
    }
}
