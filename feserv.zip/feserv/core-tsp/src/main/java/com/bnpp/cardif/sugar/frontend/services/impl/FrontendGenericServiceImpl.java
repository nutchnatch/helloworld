package com.bnpp.cardif.sugar.frontend.services.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.security.AuthenticatedUser;
import com.bnpparibas.assurance.ea.internal.schema.mco.exception.v1.FunctionalBaseFaultType;
import com.bnpparibas.assurance.ea.internal.schema.mco.exception.v1.TechnicalBaseFaultType;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Operators;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Types;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;

public class FrontendGenericServiceImpl {

    private static final Logger GENERIC_LOGGER = LoggerFactory.getLogger(FrontendGenericServiceImpl.class);
    
    protected static final String ISSUER = "CARDIF";
    
    protected static final String SCHEME = "Sugar";
    
    private static final String SCOPE = "Scope";

    /**
     * Get user scope.
     * 
     * @return the scope to get
     * @throws TechnicalException
     */
    protected String getScope() throws TechnicalException {

        String scope = null;

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            AuthenticatedUser springAuthenticatedUser = (AuthenticatedUser) authentication.getPrincipal();
            scope = springAuthenticatedUser.getCurrentBusinessScope();
        }
        else {
            GENERIC_LOGGER.warn("No Authentication found");
            throw new TechnicalException(ErrorCode.TE002);
        }
        return scope;
    }

    /**
     * Get current authenticated user.
     * 
     * @return AuthenticatedUser
     * @throws TechnicalException
     */
    protected AuthenticatedUser getCurrentUser() throws TechnicalException {

        AuthenticatedUser result = null;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null) {
            UsernamePasswordAuthenticationToken usernamePasswrodAuthenticationToken = (UsernamePasswordAuthenticationToken) auth;
            result = (AuthenticatedUser) usernamePasswrodAuthenticationToken.getPrincipal();
        }
        else {
            GENERIC_LOGGER.warn("No Authentication found");
            throw new TechnicalException(ErrorCode.TE002);
        }
        return result;
    }
    
    /**
     * Generate a TechnicalException based on the TechFaultMessage
     * @param e TechFaultMessage
     * @throws TechnicalException
     */
    protected void generateTechnicalException(TechFaultMessage e) throws TechnicalException {
        String code = "TE000";
        String message = e.getMessage();
        TechnicalBaseFaultType info = e.getFaultInfo();
        if(info != null) {
            code = info.getCode();
            if(message == null || message.isEmpty()) {
                message = info.getDescription();
            }
        }
        throw new TechnicalException(code, message, e);
    }

    /**
     * Generate a FunctionalException based on the FuncFaultMessage
     * @param e FuncFaultMessage
     * @throws FunctionalException
     */
    protected void generateFunctionalException(FuncFaultMessage e) throws FunctionalException {
        String code = "FE000";
        String message = e.getMessage();
        FunctionalBaseFaultType info = e.getFaultInfo();
        if(info != null) {
            code = info.getCode();
            if(message == null || message.isEmpty()) {
                message = info.getDescription();
            }
        }
        throw new FunctionalException(code, message, e);
    }
    
    protected OrderClause generateDefaultOrderClause() {
        OrderClause orderClause;
        orderClause = new OrderClause();
        orderClause.setAscending(false);
        orderClause.setLevel(Levels.DATA);
        orderClause.setName("CreatnDate");
        orderClause.setType(Types.TIMESTAMP);
        return orderClause;
    }
    
    protected void buildSearchCriteria(String quickSearchValue, List<Criterion> criterionList,
            List<Criterion> searchCriterionList) throws TechnicalException {
        // Add scope criteria
        Criterion scopeCriterion = new Criterion();
        scopeCriterion.setLevel(Levels.ATTRIBUTE);
        scopeCriterion.setName(SCOPE);
        scopeCriterion.setOperator(Operators.EQUALS_TO);
        scopeCriterion.setType(Types.STRING);
        scopeCriterion.getValues().add(this.getScope());
        searchCriterionList.add(scopeCriterion);
        if (quickSearchValue != null && !quickSearchValue.isEmpty()) {
            // add the qucikSearch parameter
            // search with "QUICK" type
            Criterion criterion = new Criterion();
            criterion.setLevel(Levels.QUICK);
            criterion.setName("ALL");
            criterion.setOperator(Operators.EQUALS_TO);
            criterion.setType(Types.STRING);
            List<String> critValues = criterion.getValues();
            critValues.add(quickSearchValue);
            searchCriterionList.add(criterion);
        }
        else {
            // add the full search parameters
            if (criterionList != null && !criterionList.isEmpty()) {
                searchCriterionList.addAll(criterionList);
            }
        }
    }

}
