package com.bnpp.cardif.sugar.frontend.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.BuisnessRulesService;
import com.bnpp.cardif.sugar.frontend.services.DocumentTypeService;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ElectronicDocumentDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tags;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOTagReference;

/**
 * 
 * @author 831743
 *
 */
@Service("buisnessRulesService")
@Scope("singleton")
public class BuisnessRulesServiceImpl implements BuisnessRulesService {

    private static final Logger LOGGER = LoggerFactory.getLogger(BuisnessRulesServiceImpl.class);

    @Autowired
    DocumentTypeService documentTypeService;

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.BuisnessRulesService#
     * computeValidityCode(com.bnpparibas.assurance.ea.internal.schema.mco.
     * document.v1.Document)
     */
    public ValdtyCode computeValidityCode(Document testedDocument) throws TechnicalException, FunctionalException {

        ValdtyCode result = ValdtyCode.VALID;
        // get documentClass
        Category docCategory = testedDocument.getCategory();
        ElectronicDocumentDataType docData = testedDocument.getData();
        if (docData != null) {
            if (ValdtyCode.UNDER_CONSTRUCTION.equals(docData.getValidityCode()) || docData.getValidityCode() == null) {
                // no check for document under construction.
                return ValdtyCode.UNDER_CONSTRUCTION;
            }
            ClassId docClassId = docData.getClassId();
            if (docClassId != null) {
                result = checkDocMatchClass(testedDocument, result, docCategory, docClassId);
            }
            else {
                LOGGER.info("the document doesn't have a class");
                result = ValdtyCode.INVALID;
            }
        }
        else {
            throw new FunctionalException(ErrorCode.FE002);
        }
        return result;
    }

    private ValdtyCode checkDocMatchClass(Document testedDocument, ValdtyCode result, Category docCategory,
            ClassId docClassId) throws TechnicalException, FunctionalException {
        
        DocumentClass docClass = null;
        // get the list of active document class
        List<DocumentClass> validClassList = documentTypeService.getAllDocumentType(docCategory, true);
        // check the select document class is in the list of valid
        // classes for this category
        List<ClassId> validClassIdList = new ArrayList<>();
        for (DocumentClass documentClass : validClassList) {
            validClassIdList.add(documentClass.getClassId());
            if (documentClass.getClassId().equals(docClassId)) {
                docClass = documentClass;
            }
        }
        if (!validClassIdList.contains(docClassId)) {
            LOGGER.info(
                    "the document class used is not valid (not in the list of active class for this category of document)");
            result = ValdtyCode.INVALID;
        }
        // check document tags
        if (docClass != null) {
            List<String> docTagNameList = new ArrayList<>();
            // get the list of tags from the document class
            List<MCOTagReference> tagRefList = docClass.getTagReference();
            Tags docTags = testedDocument.getTags();
            if (docTags != null) {
                result = checkTagsForNonEmptyDocs(result, docTagNameList, tagRefList, docTags);
            }
            else {
                // document has no tag. It is a valid case only when the
                // document Class has no mandatory tags
                result = checkMandatoryTagsForEmptyDocs(result, tagRefList);
            }
        }
        return result;
    }

    private ValdtyCode checkTagsForNonEmptyDocs(ValdtyCode result, List<String> docTagNameList,
            List<MCOTagReference> tagRefList, Tags docTags) {

        List<String> tagNameList = new ArrayList<>();
        for (MCOTagReference mcoTagReference : tagRefList) {
            tagNameList.add(mcoTagReference.getSymbolicName());
        }
        // check document tags are in the list defined by the class
        List<Tag> docTagList = docTags.getTag();
        for (Tag tag : docTagList) {
            if (!tagNameList.contains(tag.getName())) {
                LOGGER.info("Tag : {} exist but is not configured for document class", tag.getName());
                result = ValdtyCode.INVALID;
            }
            if (tag.getValue() != null && !tag.getValue().isEmpty()) {
                docTagNameList.add(tag.getName());
            }
        }
        // check that all mandatory tags defined by class are in the document
        for (MCOTagReference mcoTagReference : tagRefList) {
            if (mcoTagReference.isMandatory() && !docTagNameList.contains(mcoTagReference.getSymbolicName())) {
                LOGGER.info("Tag : {} is mandatory but doesn't exist in document", mcoTagReference.getSymbolicName());
                result = ValdtyCode.INVALID;
            }
        }
        return result;
    }

    private ValdtyCode checkMandatoryTagsForEmptyDocs(ValdtyCode result, List<MCOTagReference> tagRefList) {
        for (MCOTagReference mcoTagReference : tagRefList) {
            if (mcoTagReference.isMandatory()) {
                LOGGER.info("Tag : {} is mandatory but doesn't exist in the document",
                        mcoTagReference.getSymbolicName());
                result = ValdtyCode.INVALID;
            }
        }
        return result;
    }

}
