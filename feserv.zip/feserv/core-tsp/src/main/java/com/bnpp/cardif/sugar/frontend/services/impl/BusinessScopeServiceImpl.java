package com.bnpp.cardif.sugar.frontend.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenCreator;
import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.BusinessScopeService;
import com.bnpp.cardif.sugar.frontend.services.DocumentFilesService;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.MCOBusinessScope.FileData;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.GetBySymbolicNameRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.GetBySymbolicNameResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.SugarBusinessScope;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.UpdateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;

/**
 * 
 * @author 831743
 *
 */
@Service("businessScopeService")
@Scope("singleton")
public class BusinessScopeServiceImpl extends FrontendGenericServiceImpl implements BusinessScopeService {

    private static final Logger LOGGER = LoggerFactory.getLogger(BusinessScopeServiceImpl.class);

    @Autowired
    SugarWebServiceClientFactory sugarWebServiceClientFactory;

    @Autowired
    DocumentFilesService documentFilesService;

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.BusinessScopeService#
     * getBusinessScope()
     */
    public BusinessScope getBusinessScope() throws TechnicalException, FunctionalException {

        LOGGER.debug("getBusinessScope called");
        BusinessScope businessScope = null;
        // call webService
        SugarBusinessScope service = sugarWebServiceClientFactory.getSugarBusinessScopeWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        try {
            GetBySymbolicNameRequest parameters = new GetBySymbolicNameRequest();
            List<String> symbolicNameList = parameters.getSymbolicNames();
            symbolicNameList.add(getScope());
            GetBySymbolicNameResponse result = service.getBySymbolicName(parameters, securityToken);
            if (result != null) {
                List<BusinessScope> businessScopeList = result.getBusinessScope();
                if (businessScopeList.isEmpty()) {
                    // error 1 basket expected 0 are returned.
                    throw new TechnicalException(ErrorCode.TE002);
                }
                else {
                    businessScope = businessScopeList.get(0);
                    getAttachedRuleFile(businessScope);
                }
            }

        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        // extract result
        LOGGER.debug("getBusinessScope end");
        return businessScope;
    }

    private void getAttachedRuleFile(BusinessScope businessScope) throws TechnicalException, FunctionalException {
        // get the attached file:
        FileData data = businessScope.getFileData();
        if (data != null) {
            String uri = data.getURI();
            if (uri != null && !uri.isEmpty()) {
                DocumentFile documentFile = documentFilesService.getDocumentFilesByID(uri);
                if (documentFile != null) {
                    data.setDocumentFile(documentFile);
                }
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.BusinessScopeService#
     * updateBusinessScope(com.bnpparibas.assurance.ea.internal.schema.mco.
     * businessscope.v1.BusinessScope)
     */
    public BusinessScope updateBusinessScope(BusinessScope inputBS) throws TechnicalException, FunctionalException {

        LOGGER.debug("updateBusinessScope called");
        // validate input
        if (inputBS == null) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "inputBS");
        }
        BusinessScope businessScope = null;
        // call webService
        SugarBusinessScope service = sugarWebServiceClientFactory.getSugarBusinessScopeWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        try {
            UpdateRequest parameters = new UpdateRequest();
            List<BusinessScope> bsList = parameters.getBusinessScope();
            bsList.add(inputBS);
            UpdateResponse result = service.update(parameters, securityToken);
            if (result != null) {
                List<BusinessScope> businessScopeList = result.getBusinessScope();
                if (businessScopeList.isEmpty()) {
                    // error 1 basket expected 0 are returned.
                    throw new TechnicalException(ErrorCode.TE002);
                }
                else {
                    businessScope = businessScopeList.get(0);
                    getAttachedRuleFile(businessScope);
                }
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        // extract result
        LOGGER.debug("updateBusinessScope end");
        return businessScope;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.BusinessScopeService#
     * updateRuleFile(com.bnpparibas.assurance.ea.internal.schema.mco.
     * documentfile.v1.DocumentFile)
     */
    public BusinessScope updateRuleFile(DocumentFile inputDocFile) throws TechnicalException, FunctionalException {

        LOGGER.debug("updateRuleFile called");
        // validate input
        if (inputDocFile == null) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "inputDocFile");
        }
        BusinessScope businessScope = null;
        // retreive businessScope
        BusinessScope existingBusinessScope = this.getBusinessScope();
        // create document file
        List<DocumentFile> inputDocFileList = new ArrayList<>();
        inputDocFileList.add(inputDocFile);
        List<DocumentFile> documentFileList = documentFilesService.createDocumentFiles(inputDocFileList);
        if (documentFileList != null && !documentFileList.isEmpty() && documentFileList.get(0) != null) {
            DocumentFile docFile = documentFileList.get(0);
            // now delete the old file.
            if (existingBusinessScope.getFileData() != null && existingBusinessScope.getFileData().getURI() != null
                    && !existingBusinessScope.getFileData().getURI().isEmpty()) {
                documentFilesService.deleteDocumentFilesByID(existingBusinessScope.getFileData().getURI());
            }
            // update the BusinessScope with the new file ID
            FileData data = existingBusinessScope.getFileData();
            data.setURI(docFile.getURI());
            // and save the updated BusinessScope
            businessScope = this.updateBusinessScope(existingBusinessScope);
        }
        // extract result
        LOGGER.debug("updateRuleFile end");
        return businessScope;
    }

}
