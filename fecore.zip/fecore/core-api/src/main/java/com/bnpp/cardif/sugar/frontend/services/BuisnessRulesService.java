package com.bnpp.cardif.sugar.frontend.services;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;

/**
 * 
 * @author 831743
 *
 */
@SuppressWarnings("squid:S1609")
public interface BuisnessRulesService {
    
    /**
     * Check the documenty to return its Valididty.
     * 
     * @param testedDocument
     * @return ValdtyCode
     */
    public ValdtyCode computeValidityCode(Document testedDocument) throws TechnicalException, FunctionalException;

}
