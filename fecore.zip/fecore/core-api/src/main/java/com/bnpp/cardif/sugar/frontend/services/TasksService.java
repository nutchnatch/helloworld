package com.bnpp.cardif.sugar.frontend.services;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.model.PagingList;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;

/**
 * 
 * @author 831743
 *
 */
public interface TasksService {

    /**
     * Get the paginated list of all tasks related to the basket passed.
     * 
     * @param basketIdValue
     * @param start
     * @param maximum
     * @return PagingList<Task>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public PagingList<Task> getTaskListByBasket(String basketIdValue, long start, long maximum)
            throws TechnicalException, FunctionalException;

    /**
     * Get the task identified by its ID.
     * 
     * @param taskIdValue
     * @return Task
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public Task getTaskByID(String taskIdValue) throws TechnicalException, FunctionalException;

    /**
     * Transfer the task identified by its ID to the basket identified by its
     * ID.
     * 
     * @param taskIdValue
     * @param basketIdValue
     * @return String the Id of the transfered task.
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public String transferTask(String taskIdValue, String basketIdValue) throws TechnicalException, FunctionalException;

    /**
     * Lock a task for the current User.
     * 
     * @param taskIdValue
     * @return String the Id of the locked task.
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public String lockTask(String taskIdValue) throws TechnicalException, FunctionalException;

    /**
     * Unlock a task.
     * 
     * @param taskIdValue
     * @return String the Id of the unlocked task.
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public String unlockTask(String taskIdValue) throws TechnicalException, FunctionalException;

    /**
     * Update the task status
     * 
     * @param taskIdValue
     * @param statusValue possible values are "NEW, PENDING, CLOSE"
     * @return String the updated status.
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public String updateTaskStatus(String taskIdValue, String statusValue)
            throws TechnicalException, FunctionalException;

}
