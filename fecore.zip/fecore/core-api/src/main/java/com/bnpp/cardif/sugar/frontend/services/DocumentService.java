package com.bnpp.cardif.sugar.frontend.services;

import java.util.List;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.model.PagingList;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;

/**
 * 
 * @author 831743
 *
 */
@SuppressWarnings("squid:S1609")
public interface DocumentService {

    /**
     * Get a document identified by its ID
     * 
     * @param value
     *            : ID value
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public Document getDocumentByID(final String id) throws TechnicalException, FunctionalException;

    /**
     * Get a document identified by its ID including its child
     * 
     * @param value
     *            : ID value
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public Document getDocumentWithChildByID(final String id) throws TechnicalException, FunctionalException;

    /**
     * Get a list of documents identified by their IDs
     * 
     * @param value
     *            : ID value
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<Document> getDocumentByIDs(final List<String> ids) throws TechnicalException, FunctionalException;

    /**
     * Get all the documents matching the criteria passed.
     * 
     * @param start
     * @param maximum
     * @param quickSearchValue
     * @param criterionList
     * @param orderClause
     * @return PagingList<Document>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public PagingList<Document> findDocuments(long start, long maximum, String quickSearchValue,
            List<Criterion> criterionList, OrderClause orderClause) throws TechnicalException, FunctionalException;

    /**
     * Get all the envelopes matching the criteria passed.
     * 
     * @param start
     * @param maximum
     * @param quickSearchValue
     * @param criterionList
     * @param orderClause
     * @return PagingList<Document>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public PagingList<Document> findEnvelopes(long start, long maximum, String quickSearchValue,
            List<Criterion> criterionList, OrderClause orderClause) throws TechnicalException, FunctionalException;

    /**
     * Update the Document indexing parameters
     * 
     * @param inputDocumentlist
     *            : the list of document to update, cannot be null.
     * @return List<Document> the list of updated documents.
     * @throws FunctionalException
     * @throws TechnicalException
     */
    public List<Document> reindexDocument(List<Document> inputDocumentlist)
            throws FunctionalException, TechnicalException;

    /**
     * Create an empty envelope with a list of empty document that contains the
     * passed DocumentFile.
     * 
     * @param inputDocFile
     * @param defaultEnvelope
     * @param defaultDocument
     * @return List<Document>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<Document> createEnvelopeWithFile(List<DocumentFile> inputDocFileList, Document defaultEnvelope,
            List<Document> defaultDocumentList) throws TechnicalException, FunctionalException;

    /**
     * Add the list of empty document an existing envelope identified by its ID.
     * The documents contains the passed DocumentFiles.
     * 
     * @param inputDocFileList
     * @param envelopeId
     * @param defaultDocumentList
     * @return List<Document>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<Document> addFileToEnvelope(List<DocumentFile> inputDocFileList, String envelopeId,
            List<Document> defaultDocumentList) throws TechnicalException, FunctionalException;

    /**
     * Get the list of all documents attached to the envelope identified by the
     * passed ID.
     * 
     * @param envelopeId
     * @return List<Document>
     * @throws FunctionalException
     * @throws TechnicalException
     */
    public List<Document> getDocumentsFromEnvelope(String envelopeId) throws FunctionalException, TechnicalException;

    /**
     * Delete the envelope identified by its ID. Only UNDER_CONSTRUCTION
     * envelope can be deleted.
     * 
     * @param envelopeId
     * @throws FunctionalException
     * @throws TechnicalException
     */
    public void deleteEnvelope(String envelopeId) throws FunctionalException, TechnicalException;
}
