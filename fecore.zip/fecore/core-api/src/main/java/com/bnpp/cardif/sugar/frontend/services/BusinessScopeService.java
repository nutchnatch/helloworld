package com.bnpp.cardif.sugar.frontend.services;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;

/**
 * 
 * @author 831743
 *
 */
public interface BusinessScopeService {

    /**
     * Get a BusinessScope identified by its ID
     * 
     * @return BusinessScope
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public BusinessScope getBusinessScope() throws TechnicalException, FunctionalException;
    
    /**
     * Update the BusinessScope.
     * 
     * @param inputBS : BusinessScope
     * @return BusinessScope
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public BusinessScope updateBusinessScope(BusinessScope inputBS) throws TechnicalException, FunctionalException;
    
    /**
     * Apply the new passed basket Rule file and delete the old one.
     * 
     * @param inputDocFile
     * @return BusinessScope
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public BusinessScope updateRuleFile(DocumentFile inputDocFile) throws TechnicalException, FunctionalException;

}
