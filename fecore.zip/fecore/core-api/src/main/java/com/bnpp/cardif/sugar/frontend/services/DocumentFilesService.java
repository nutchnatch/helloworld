package com.bnpp.cardif.sugar.frontend.services;

import java.util.List;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;

/**
 * 
 * @author 831743
 *
 */
public interface DocumentFilesService {

    /**
     * Get a list of DocumentFile identified by their id(URI)
     * 
     * @param ids
     *            : cannot be null or empty;
     * @return List<DocumentFile>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<DocumentFile> getDocumentFilesByIDs(final List<String> ids)
            throws TechnicalException, FunctionalException;

    /**
     * Get a DocumentFile identified by its id(URI)
     * 
     * @param id
     *            : cannot be null or empty;
     * @return DocumentFile
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public DocumentFile getDocumentFilesByID(final String id) throws TechnicalException, FunctionalException;

    /**
     * Add a list of DocumentFile into the database.
     * 
     * @param inputDocFileList
     *            : the DocumentFile List to add, cannot be null or already have
     *            an URI.
     * @return List<DocumentFile> : the list of DocumentFile created.
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<DocumentFile> createDocumentFiles(List<DocumentFile> inputDocFileList)
            throws TechnicalException, FunctionalException;

    /**
     * Add a DocumentFile into the database.
     * 
     * @param inputDocFile
     *            : the DocumentFile to add, cannot be null or already have an
     *            URI.
     * @return DocumentFile : the DocumentFile created.
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public DocumentFile createDocumentFile(DocumentFile inputDocFile) throws TechnicalException, FunctionalException;

    /**
     * Remove a list of DocumentFile from the database.
     * 
     * @param ids
     *            : cannot be null or empty;
     * @return List<Boolean> : the boolean indicate if the document has been
     *         deleted or not.
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<Boolean> deleteDocumentFilesByIDs(final List<String> ids)
            throws TechnicalException, FunctionalException;

    /**
     * Remove a list of DocumentFile from the database.
     * 
     * @param documentFileList
     *            : cannot be null or empty;
     * @return List<Boolean> : the boolean indicate if the document has been
     *         deleted or not.
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<Boolean> deleteDocumentFiles(final List<DocumentFile> documentFileList)
            throws TechnicalException, FunctionalException;

    /**
     * Remove a DocumentFile from the database.
     * 
     * @param id
     *            : cannot be null or empty;
     * @return Boolean : the boolean indicate if the document has been deleted
     *         or not.
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public Boolean deleteDocumentFilesByID(final String id) throws TechnicalException, FunctionalException;
}
