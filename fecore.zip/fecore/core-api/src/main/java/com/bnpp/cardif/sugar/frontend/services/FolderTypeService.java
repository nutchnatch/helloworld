package com.bnpp.cardif.sugar.frontend.services;

import java.util.List;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

/**
 * 
 * @author 831743
 *
 */
public interface FolderTypeService {

    /**
     * Get a FolderClass identified by its ID and version.
     * 
     * @param id
     * @param version
     * @return FolderClass
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public FolderClass getFolderTypeByID(String id, int version) throws TechnicalException, FunctionalException;

    /**
     * Get all FolderClass
     * 
     * @return List<FolderClass>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<FolderClass> getAllFolderType() throws TechnicalException, FunctionalException;
    
    /**
     * Get all FolderClass including the inactive one.
     * 
     * @return List<FolderClass>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<FolderClass> getAllFolderTypeWithInactive() throws TechnicalException, FunctionalException;

    /**
     * Get the list of tags associated to a FolderClass identified by its ID and
     * version.
     * 
     * @param id
     * @param version
     * @return List<TagClass>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<TagClass> getFolderTypeTags(String id, int version) throws TechnicalException, FunctionalException;

    /**
     * Create a new FolderClass.
     * 
     * @param input
     *            FolderClass
     * @return FolderClass
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public FolderClass createFolderType(FolderClass input) throws TechnicalException, FunctionalException;

    /**
     * Update an existing FolderClass.
     * 
     * @param input
     *            FolderClass
     * @return FolderClass
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public FolderClass updateFolderType(FolderClass input) throws TechnicalException, FunctionalException;

    /**
     * Activate a FolderClass into the current businessScope.
     * 
     * @param folderTypeId
     * @param version
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public void activateFolderType(String folderTypeId, int version) throws TechnicalException, FunctionalException;

    /**
     * Deactivate a FolderClass into the current businessScope.
     * 
     * @param folderTypeId
     * @param version
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public void deactivateFolderType(String folderTypeId, int version) throws TechnicalException, FunctionalException;

}
