Transcend Material Project
===

Index
---
- Introduction
- Launching the framework showcase application
- Using this library
- Contributing
- Resources

Introduction
---
For Transcend Web Products a 'Material Design' approach was chosen, since a well defined style guide is already present for Material Design. When in doubt, or for anything this framework does not cover,
go there for support (see 'Resources');    

Launching the framework showcase application
---
To launch the application in development mode (live reload included, run the following steps on a command line):
- npm install
- npm run dev
- npm run live

Open your browser and navigate to 'http://localhost:8080/webpack-dev-server/'
Changes to the lib code will automatically be refreshed, while to refresh the demo code you'll have to exit the dev mode and repeat the last two commands.     

Using this library
---
Install this library in any npm project by running
- npm install transcend-material --save

This command will install the library and save it as a runtime dependency. To use it, include the project with the tag name 'transcend-material':
- require('transcend-material');

By default, transcend-material will include the un-minified version of the library. If you wish to include the minified version, the inclusion should be
- require('transcend-material/transcend-material.min.js)

It is also required to load the css provided with transcend-material
- require('transcend-material/transcend-material.css');

Contributing
---
Welcome to. 
     

Resources
---
- [Material Design](https://material.google.com)
- [Angular Material v1.1.1](https://material.angularjs.org/1.1.1/)
- [Material Icons](https://design.google.com/icons/)      

---
Coriant 2016, All rights reserved