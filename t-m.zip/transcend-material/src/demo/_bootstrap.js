angular.module( 'transcendMaterialDemoApp', [
   'ngMaterial',
   'transcendMaterial'
] )

.controller( 'MainController', [ '$scope', '$log', function( $scope, $log ) {

   var _self = this;

   _self.selected = {};

   _self.nodes = [
      {
         name: 'LISBON1_1',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI',
            isValid: false,
            invalidMsg: 'Reason #1'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI',
            isValid: true,
            invalidMsg: 'irrelevant'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI',
            isValid: false,
            invalidMsg: 'Reason #2'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI',
            isValid: false,
            invalidMsg: 'Reason #3'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI',
            invalidMsg: 'irrelevant'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_2',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_2-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_2-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_2-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_2-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_2-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_2-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_3',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_3-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_3-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_3-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_3-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_3-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_3-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_4',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_4-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_4-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_4-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_4-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_4-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_4-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_5',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_5-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_5-1-1-22-1',
            type: 'INNE'
         }, {
            name: 'Gb100m_LISBON1_5-1-1-22-1',
            type: 'ENNI'
         }, {
            name: 'Gb100m_LISBON1_5-1-1-22-1',
            type: 'ENNI'
         }, {
            name: 'Gb100m_LISBON1_5-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_5-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_6',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_6-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_6-1-1-22-1',
            type: 'ENNI'
         }, {
            name: 'Gb100m_LISBON1_6-1-1-22-1',
            type: 'ENNI'
         }, {
            name: 'Gb100m_LISBON1_6-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_6-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_6-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_7',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_7-1-1-22-1',
            type: 'INNE'
         }, {
            name: 'Gb100m_LISBON1_7-1-1-22-1',
            type: 'ENNI'
         }, {
            name: 'Gb100m_LISBON1_7-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_7-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_7-1-1-22-1',
            type: 'ENNI'
         }, {
            name: 'Gb100m_LISBON1_7-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_8',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_8-1-1-22-1',
            type: 'ENNI'
         }, {
            name: 'Gb100m_LISBON1_8-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_8-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_8-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_8-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_8-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_9',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_9-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_9-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_9-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_9-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_9-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_9-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_0',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_0-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_0-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_0-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_0-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_0-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_0-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_1',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_1',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_12',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_12-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_12-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_12-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_12-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_12-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_12-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_88',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_88-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_88-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_88-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_88-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_88-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_88-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_2',
         type: 'MTERA',
         endpoints: [ {
            name: 'Gb100m_LISBON1_2-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_2-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_2-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_2-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_2-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_2-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_1',
         type: 'MTERA',
         endpoints: [ {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_1',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_1',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_1',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_1',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_1',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_1',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_1',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_1',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_1',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_1',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         }, {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         } ]
      },
      {
         name: 'LISBON1_1',
         type: 'NANO1',
         endpoints: [ {
            name: 'Gb100m_LISBON1_1-1-1-22-1',
            type: 'UNI'
         } ]
      }
    ];


   var availableEndpoints = {

      idPrefix: 'endpoint-column',
      flexWidth: '75',
      searchLabel: 'Search for Endpoints',
      searchQuery: '',
      noResultLabel: 'No available endpoints found.',
      itemTitleField: 'name',
      itemSubtitleField: 'type',
      selected: {},
      items: [],
      isSelected: function() {

         return Object.keys( availableEndpoints.selected ).length > 0;
      },
      onSelect: function( item ) {

         _self.onEndpointSelect( item, availableEndpoints, false );
      },
      onDblClick: function( item ) {

         _self.onEndpointSelect( item, availableEndpoints, true );
      },
      onDeselect: function( item ) {

         $log.debug( 'ENDPOINTS::onDeselect() called.' );

         _self.selected = {};
      },
      onFilter: function() {

         $log.debug( 'Filter ENDPOINTS:', availableEndpoints.searchQuery );
      }
   };

   var availableNodes = {

      idPrefix: 'node-column',
      flexWidth: '25',
      searchLabel: 'Search for Nodes',
      searchQuery: '',
      noResultLabel: 'No availabe nodes found.',
      itemTitleField: 'name',
      itemSubtitleField: 'type',
      selected: {},
      items: _self.nodes,
      onSelect: function( item ) {

         $log.debug( 'NODES: item selected:', item );

         availableEndpoints.selected = {};

         availableEndpoints.items = item.endpoints;
      },
      onDeselect: function() {

         $log.debug( 'NODES::onDeselect() called.' );

         availableEndpoints.selected = {};
         availableEndpoints.items = [];
      },
      onFilter: function() {

         $log.debug( 'Filter NODES:', availableNodes.searchQuery );
      }
   };

   _self.millerStructure = [

      availableNodes,
      availableEndpoints
   ];

   _self.onEndpointSelect = function( item, endpoints, applySelection ) {

      $log.debug( 'ENDPOINTS: item selected:', item );

      if ( item.isValid != null && !item.isValid ) {

         endpoints.selected = {};

         alert( 'Endpoint ' + item.name + ' not valid. Reason: ' + item.invalidMsg );
      }
      else {

         _self.selected = item;

         // if ( applySelection ) {

         //    _self.applySelected();
         // }
      }
   };

    $log.info( _self.millerStructure );
} ] );