'use strict';

var webpack = require( 'webpack' );
var path = require( 'path' );
var extractor = require( 'extract-text-webpack-plugin' );
var node_modules_dir = path.resolve( __dirname, 'node_modules' );
var UglifyJsPlugin = webpack.optimize.UglifyJsPlugin;


/**
 * Build related variables
 */
var libraryName = 'transcendMaterial',
    fileName = 'transcend-material',
    outputFormat,
    cssOutputFormat,
    libraryTarget = 'umd',
    plugins = [],
    loaders = [],
    preloaders = [];


/**
 *  if the type of bundle is of 'build' type, then minify
 */
if ( process.env.npm_lifecycle_event === 'build' ) {

   plugins.push( new UglifyJsPlugin( {
      minimize: true
   } ) );
   outputFormat = '.min.js';
   cssOutputFormat = '.min.css';
}
else {

   outputFormat = '.js';
   cssOutputFormat = '.css';
}


/**
 * Common plugins, loaders and preloaders
 */
plugins.push( new extractor( 'css/[name]' + cssOutputFormat ) );

loaders.push.apply( loaders, [
   // fonts
   {
      test: /\.(ttf|eot|woff(2)?|svg)(\?[a-zA-Z0-9=&.#]+)?$/,
      loader: 'file?name=fonts/[name].[ext]'
   },
   // images
   {
      test: /\.(png|jpe?g|gif)$/,
      loaders: [ 'file?hash=sha512&digest=hex&name=img/[hash].[ext]', 'image-webpack?bypassOnDebug&optimizationLevel=7&interlaced=false' ]
   },
   // css
   {
      test: /\.css$/,
      exclude: [ /build/ ],
      loader: extractor.extract( 'style-loader', 'css-loader', {
         publicPath: '../'
      } )
   },
   {
      test: /\.less$/,
      exclude: [ /node_modules/, /build/ ],
      loader: extractor.extract( 'style-loader', 'css-loader!less-loader', {
         publicPath: '../'
      } )
   },

   {
      test: /index.html/,
      loader: 'file?name=[name].[ext]'
   }
] );

preloaders.push( [
   {
      test: /\.js$/,
      exclude: /node_modules/,
      loader: 'jshint-loader'
   }
] );


/**
 * Defines the lib configuration
 */
var libConfiguration = {

   entry: {

      'transcend-material': [
         './src/lib/directives/_directives.js',
         './src/lib/services/_services.js',
         './src/lib/_bootstrap.js',
         './src/lib/style/main.css'
     ]
   },
   devtool: 'source-map',
   output: {

      path: path.resolve( __dirname, 'dist/lib/' ),
      publicPath: 'dist/lib',
      filename: 'js/[name]' + outputFormat,
      library: libraryName,
      libraryTarget: libraryTarget,
      umdNamedDefine: true
   },
   externals: [
      'angular',
      'angular-animate',
      'angular-aria',
      'angular-material',
      'angular-material-data-table',
      'angular-resource',
      'angular-ui-router',
      'leaflet',
      'material-design-icons',
      'roboto-font'
    ],
   module: {

      preloaders: preloaders,
      loaders: loaders
   },
   plugins: plugins
};


/**
 * Defines the demo configuration
 */
var demoConfiguration = {
   entry: {

      'demo': [
         './src/demo/_bootstrap.js',
      ],
      'demo-vendors': [
         'angular',
         'angular-resource',
         'angular-ui-router',
         'angular-aria',
         'angular-animate',
         'angular-material-data-table/dist/md-data-table.min.css',
         'angular-material-data-table/dist/md-data-table.min.js',
         'angular-material',
         'angular-material/angular-material.css',
         'roboto-font/css/fonts.css',
         'material-design-icons',
         'material-design-icons/iconfont/material-icons.css'
      ]
   },
   devtool: 'source-map',
   output: {

      path: path.resolve( __dirname, 'dist/demo/' ),
      publicPath: 'dist/demo',
      filename: 'js/[name]' + outputFormat,
      library: libraryName,
      libraryTarget: libraryTarget,
      umdNamedDefine: true
   },
   module: {

      preloaders: preloaders,
      loaders: loaders
   },
   plugins: plugins
};


// module exports
module.exports = [

   libConfiguration,
   demoConfiguration
];