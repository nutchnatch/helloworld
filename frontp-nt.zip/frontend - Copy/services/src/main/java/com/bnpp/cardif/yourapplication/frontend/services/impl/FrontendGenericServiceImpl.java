package com.bnpp.cardif.yourapplication.frontend.services.impl;

import java.nio.charset.Charset;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.codec.Base64;
import org.springframework.web.client.RestTemplate;

import com.bnpp.cardif.sesame.security.AuthenticatedUser;

/**
 * Base class for all services.
 * 
 * @author 831743
 *
 */
public abstract class FrontendGenericServiceImpl
{

    private static final Logger LOGGER = LoggerFactory.getLogger(FrontendGenericServiceImpl.class);

    /**
     * Spring's central class for synchronous client-side HTTP access. It
     * simplifies communication with HTTP servers, and enforces RESTful
     * principles. It handles HTTP connections, leaving application code to
     * provide URLs (with possible template variables) and extract results.
     */
    @Autowired
    protected RestTemplate restTemplate;

    public HttpHeaders createHeaders()
    {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = "DefaultFakeUser";
        String token = "DefaultFakeToken";
        if (auth != null)
        {
            UsernamePasswordAuthenticationToken usernamePasswrodAuthenticationToken = (UsernamePasswordAuthenticationToken) auth;
            AuthenticatedUser authenticationUser = (AuthenticatedUser) usernamePasswrodAuthenticationToken.getPrincipal();
            username = authenticationUser.getUsername();
            token = authenticationUser.getToken();
        }
        else
        {
            LOGGER.warn("No Authentication found.");
        }

        HttpHeaders headers = new HttpHeaders();
        // generate Basic authentication header
        String authentication = username + ":" + token;
        byte[] encodedAuth = Base64.encode(authentication.getBytes(Charset.forName("UTF-8")));
        String authHeader = "Basic " + new String(encodedAuth);
        headers.set("Authorization", authHeader);
        // Add content type header
        headers.setContentType(MediaType.APPLICATION_JSON);

        return headers;
    }

    /**
     * @return the restTemplate
     */
    public RestTemplate getRestTemplate()
    {
        return restTemplate;
    }

    /**
     * @param restTemplate
     *            the restTemplate to set
     */
    public void setRestTemplate(RestTemplate restTemplate)
    {
        this.restTemplate = restTemplate;
    }
}
