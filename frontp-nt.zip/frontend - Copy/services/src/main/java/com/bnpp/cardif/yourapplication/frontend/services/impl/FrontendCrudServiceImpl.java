package com.bnpp.cardif.yourapplication.frontend.services.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;

import com.bnpp.cardif.yourapplication.beans.RestResponse;
import com.bnpp.cardif.yourapplication.exception.ErrorCode;
import com.bnpp.cardif.yourapplication.exception.TechnicalException;

/**
 * Frontend generic service implementation. Contains methods which are common to
 * all entities
 * 
 * @author a84252
 *
 * @param <E>
 *            the frontend entity
 * @param <K>
 *            the backend entity
 */
public abstract class FrontendCrudServiceImpl<E, K> extends FrontendGenericServiceImpl
{

    private static final Logger LOGGER = LoggerFactory.getLogger(FrontendCrudServiceImpl.class);

    /**
     * Get the backend url for the given entity.
     * 
     * @return the backend url
     */
    public abstract String getBackendUrl();

    /**
     * Get the backend class.
     * 
     * @return the backend class
     */
    public abstract Class<K> getBackendClass();

    /**
     * Get the identifier for the given ID.
     * 
     * @param entity
     *            the entity to get id
     * @return the identifier of the entity
     */
    public abstract Long getId(E entity);

    /**
     * Convert entity from frontend to backend.
     * 
     * @param entity
     *            the entity to convert
     * @return the backend entity
     */
    public abstract K convertEntityToBackend(E entity);

    /**
     * Convert entity from backend to frontend.
     * 
     * @param entity
     *            the entity to convert
     * @return the frontend entity
     */
    public abstract E convertEntityFromBackend(LinkedHashMap<String, Object> entity);

    /**
     * Save a list of entities
     * 
     * @param entities
     *            the entity list
     * 
     * @return the list of saved entities
     * @throws TechnicalException
     */
    public List<E> createEntityList(List<E> entities) throws TechnicalException
    {
        LOGGER.debug("Create entity list: " + entities);

        List<E> result = new ArrayList<>();
        if (entities == null)
        {
            throw new IllegalArgumentException("Entity List to create may not be null.");
        }

        List<K> requestList = new ArrayList<>();
        for (E entity : entities)
        {
            if (entity != null)
            {
                K saveRequest = convertEntityToBackend(entity);
                requestList.add(saveRequest);
            }
        }

        HttpEntity<List<K>> httpRequestEntity = new HttpEntity<>(requestList, createHeaders());

        ResponseEntity<RestResponse<LinkedHashMap<String, Object>>> saveResponse = null;
        try
        {
            saveResponse = getRestTemplate().exchange(getBackendUrl() + "/create/list", HttpMethod.PUT, httpRequestEntity,
                    new ParameterizedTypeReference<RestResponse<LinkedHashMap<String, Object>>>()
                    {
                    });
        }
        catch (HttpClientErrorException ex)
        {
            LOGGER.warn("Error calling backend", ex);
            String errorCode = ex.getStatusCode().toString();
            String errorMessage = ex.getMessage();
            throw new TechnicalException(errorCode, errorMessage);
        }

        if (saveResponse != null)
        {
            HttpStatus status = saveResponse.getStatusCode();
            if (HttpStatus.OK.equals(status))
            {
                // call to call OK
                RestResponse<LinkedHashMap<String, Object>> responseBody = saveResponse.getBody();
                List<LinkedHashMap<String, Object>> responseContent = responseBody.getContent();
                for (LinkedHashMap<String, Object> responseEntity : responseContent)
                {
                    E entity = convertEntityFromBackend(responseEntity);
                    result.add(entity);
                }
            }
            else
            {
                // Error during call : re-create the exception
                RestResponse<LinkedHashMap<String, Object>> responseBody = saveResponse.getBody();
                String errorCode = responseBody.getErrorCode();
                String errorMessage = responseBody.getErrorMessage();
                throw new TechnicalException(errorCode, errorMessage);
            }
        }
        else
        {
            throw new TechnicalException("The service call returned a null result");
        }
        LOGGER.debug("Created entity list" + result);
        return result;
    }

    /**
     * Save One entity.
     * 
     * @param entity
     *            : the entity to be saved.
     * @return the saved entity.
     * @throws TechnicalException
     */
    public E createEntity(E entity) throws TechnicalException
    {
        LOGGER.debug("Creating entity " + entity);

        if (entity == null)
        {
            throw new IllegalArgumentException("Entity to create may not be null.");
        }
        K saveRequest = convertEntityToBackend(entity);
        E resultEntity;
        HttpEntity<K> httpRequestEntity = new HttpEntity<>(saveRequest, createHeaders());
        ResponseEntity<RestResponse<LinkedHashMap<String, Object>>> saveResponse = null;
        try
        {
            saveResponse = getRestTemplate().exchange(getBackendUrl() + "/create/single", HttpMethod.PUT, httpRequestEntity,
                    new ParameterizedTypeReference<RestResponse<LinkedHashMap<String, Object>>>()
                    {
                    });
        }
        catch (HttpClientErrorException ex)
        {
            LOGGER.warn("Error calling backend", ex);
            String errorCode = ex.getStatusCode().toString();
            String errorMessage = ex.getMessage();
            throw new TechnicalException(errorCode, errorMessage);
        }

        if (saveResponse != null)
        {
            HttpStatus status = saveResponse.getStatusCode();
            if (HttpStatus.OK.equals(status))
            {
                // call to call OK
                RestResponse<LinkedHashMap<String, Object>> responseBody = saveResponse.getBody();
                List<LinkedHashMap<String, Object>> responseContent = responseBody.getContent();
                checkIsOneResult(responseBody);
                LinkedHashMap<String, Object> responseEntity = responseContent.get(0);
                resultEntity = convertEntityFromBackend(responseEntity);
            }
            else
            {
                // Error during call : re-create the exception
                RestResponse<LinkedHashMap<String, Object>> responseBody = saveResponse.getBody();
                String errorCode = responseBody.getErrorCode();
                String errorMessage = responseBody.getErrorMessage();
                throw new TechnicalException(errorCode, errorMessage);
            }
        }
        else
        {
            throw new TechnicalException("The service call returned a null result");
        }
        LOGGER.debug("Created entity " + resultEntity);
        return resultEntity;
    }

    /**
     * Save a list of entities
     * 
     * @param entities
     *            the entity list
     * 
     * @return the list of saved entities
     * @throws TechnicalException
     */
    public List<E> updateEntityList(List<E> entities) throws TechnicalException
    {
        LOGGER.debug("Updating entity list: " + entities);

        List<E> result = new ArrayList<>();
        if (entities == null)
        {
            throw new IllegalArgumentException("Entity List to update may not be null.");
        }

        List<K> requestList = new ArrayList<>();
        for (E entity : entities)
        {
            if (entity != null)
            {
                K saveRequest = convertEntityToBackend(entity);
                requestList.add(saveRequest);
            }
        }

        HttpEntity<List<K>> httpRequestEntity = new HttpEntity<>(requestList, createHeaders());
        ResponseEntity<RestResponse<LinkedHashMap<String, Object>>> saveResponse = null;
        try
        {
            saveResponse = getRestTemplate().exchange(getBackendUrl() + "/update/list", HttpMethod.PUT, httpRequestEntity,
                    new ParameterizedTypeReference<RestResponse<LinkedHashMap<String, Object>>>()
                    {
                    });
        }
        catch (HttpClientErrorException ex)
        {
            LOGGER.warn("Error calling backend", ex);
            String errorCode = ex.getStatusCode().toString();
            String errorMessage = ex.getMessage();
            throw new TechnicalException(errorCode, errorMessage);
        }

        if (saveResponse != null)
        {
            HttpStatus status = saveResponse.getStatusCode();
            if (HttpStatus.OK.equals(status))
            {
                // call to call OK
                RestResponse<LinkedHashMap<String, Object>> responseBody = saveResponse.getBody();
                List<LinkedHashMap<String, Object>> responseContent = responseBody.getContent();
                for (LinkedHashMap<String, Object> responseEntity : responseContent)
                {
                    E entity = convertEntityFromBackend(responseEntity);
                    result.add(entity);
                }
            }
            else
            {
                // Error during call : re-create the exception
                RestResponse<LinkedHashMap<String, Object>> responseBody = saveResponse.getBody();
                String errorCode = responseBody.getErrorCode();
                String errorMessage = responseBody.getErrorMessage();
                throw new TechnicalException(errorCode, errorMessage);
            }
        }
        else
        {
            throw new TechnicalException("The service call returned a null result");
        }
        LOGGER.debug("Update entity list" + result);
        return result;
    }

    /**
     * Save One entity.
     * 
     * @param entity
     *            : the entity to be saved.
     * @return the saved entity.
     * @throws TechnicalException
     */
    public E updateEntity(E entity) throws TechnicalException
    {
        LOGGER.debug("Updating entity " + entity);

        if (entity == null)
        {
            throw new IllegalArgumentException("Entity to update may not be null.");
        }
        K saveRequest = convertEntityToBackend(entity);
        E resultEntity;

        HttpEntity<K> httpRequestEntity = new HttpEntity<>(saveRequest, createHeaders());
        ResponseEntity<RestResponse<LinkedHashMap<String, Object>>> saveResponse = null;
        try
        {
            saveResponse = getRestTemplate().exchange(getBackendUrl() + "/update/single", HttpMethod.PUT, httpRequestEntity,
                    new ParameterizedTypeReference<RestResponse<LinkedHashMap<String, Object>>>()
                    {
                    });
        }
        catch (HttpClientErrorException ex)
        {
            LOGGER.warn("Error calling backend", ex);
            String errorCode = ex.getStatusCode().toString();
            String errorMessage = ex.getMessage();
            throw new TechnicalException(errorCode, errorMessage);
        }

        if (saveResponse != null)
        {
            HttpStatus status = saveResponse.getStatusCode();
            if (HttpStatus.OK.equals(status))
            {
                // call to call OK
                RestResponse<LinkedHashMap<String, Object>> responseBody = saveResponse.getBody();
                List<LinkedHashMap<String, Object>> responseContent = responseBody.getContent();
                checkIsOneResult(responseBody);
                LinkedHashMap<String, Object> responseEntity = responseContent.get(0);
                resultEntity = convertEntityFromBackend(responseEntity);
            }
            else
            {
                // Error during call : re-create the exception
                RestResponse<LinkedHashMap<String, Object>> responseBody = saveResponse.getBody();
                String errorCode = responseBody.getErrorCode();
                String errorMessage = responseBody.getErrorMessage();
                throw new TechnicalException(errorCode, errorMessage);
            }
        }
        else
        {
            throw new TechnicalException("The service call returned a null result");
        }
        LOGGER.debug("Updated entity " + resultEntity);
        return resultEntity;
    }

    /**
     * Retrieve one entity identified by its ID.
     * 
     * @param id
     *            : the entity identifier.
     * @return the found entity.
     * @throws TechnicalException
     */
    public E findOneEntity(Long id) throws TechnicalException
    {
        LOGGER.debug("Finding entity with identifier " + id);

        if (id == null)
        {
            throw new IllegalArgumentException("Identifier is mandatory to find one entity: " + id);
        }

        HttpEntity<K> httpRequestEntity = new HttpEntity<>(null, createHeaders());
        ResponseEntity<RestResponse<LinkedHashMap<String, Object>>> responseRequest = null;
        try
        {
            responseRequest = getRestTemplate().exchange(getBackendUrl() + "/get/" + id, HttpMethod.GET, httpRequestEntity,
                    new ParameterizedTypeReference<RestResponse<LinkedHashMap<String, Object>>>()
                    {
                    });
        }
        catch (HttpClientErrorException ex)
        {
            LOGGER.warn("Error calling backend", ex);
            String errorCode = ex.getStatusCode().toString();
            String errorMessage = ex.getMessage();
            throw new TechnicalException(errorCode, errorMessage);
        }

        E resultEntity;
        if (responseRequest != null)
        {
            HttpStatus status = responseRequest.getStatusCode();
            if (HttpStatus.OK.equals(status))
            {
                // call to call OK
                RestResponse<LinkedHashMap<String, Object>> responseBody = responseRequest.getBody();
                List<LinkedHashMap<String, Object>> responseContent = responseBody.getContent();
                checkIsOneResult(responseBody);
                LinkedHashMap<String, Object> responseEntity = responseContent.get(0);
                resultEntity = convertEntityFromBackend(responseEntity);
            }
            else
            {
                // Error during call : re-create the exception
                RestResponse<LinkedHashMap<String, Object>> responseBody = responseRequest.getBody();
                String errorCode = responseBody.getErrorCode();
                String errorMessage = responseBody.getErrorMessage();
                throw new TechnicalException(errorCode, errorMessage);
            }
        }
        else
        {
            throw new TechnicalException("The service call returned a null result");
        }
        LOGGER.debug("Found entity " + resultEntity);
        return resultEntity;
    }

    /**
     * Check for the existence of one entity with the given identifier.
     * 
     * @param id
     *            : the entity identifier.
     * @return boolean : true if one entity is found, False otherwise.
     * @throws TechnicalException
     */
    public boolean existsEntity(Long id) throws TechnicalException
    {
        LOGGER.debug("Checking if entity with identifier " + id + " exists.");
        if (id == null)
        {
            throw new IllegalArgumentException("Id is mandatory to check if id exists.");
        }
        HttpEntity<K> httpRequestEntity = new HttpEntity<>(null, createHeaders());
        ResponseEntity<RestResponse<Boolean>> responseRequest = null;
        try
        {
            responseRequest = getRestTemplate().exchange(getBackendUrl() + "/exists/" + id, HttpMethod.GET, httpRequestEntity,
                    new ParameterizedTypeReference<RestResponse<Boolean>>()
                    {
                    });
        }
        catch (HttpClientErrorException ex)
        {
            LOGGER.warn("Error calling backend", ex);
            String errorCode = ex.getStatusCode().toString();
            String errorMessage = ex.getMessage();
            throw new TechnicalException(errorCode, errorMessage);
        }

        boolean exists = false;
        if (responseRequest != null)
        {
            HttpStatus status = responseRequest.getStatusCode();
            if (HttpStatus.OK.equals(status))
            {
                // call to call OK
                RestResponse<Boolean> responseBody = responseRequest.getBody();
                List<Boolean> responseContent = responseBody.getContent();
                checkIsOneResult(responseBody);
                Boolean existsBool = responseContent.get(0);
                if (existsBool != null)
                {
                    exists = existsBool.booleanValue();
                }
            }
            else
            {
                // Error during call : re-create the exception
                RestResponse<Boolean> responseBody = responseRequest.getBody();
                String errorCode = responseBody.getErrorCode();
                String errorMessage = responseBody.getErrorMessage();
                throw new TechnicalException(errorCode, errorMessage);
            }
        }
        else
        {
            throw new TechnicalException("The service call returned a null result");
        }
        LOGGER.debug("Entity with identifier " + id + " exists? " + exists);
        return exists;
    }

    /**
     * Retrieve all entities.
     * 
     * @return List<E> : the list of all entities found.
     * @throws TechnicalException
     */
    public List<E> findAllEntities() throws TechnicalException
    {
        LOGGER.debug("Finding all entities.");

        HttpEntity<String> stringRequestEntity = new HttpEntity<>(null, createHeaders());
        ResponseEntity<RestResponse<LinkedHashMap<String, Object>>> response = null;
        try
        {
            response = getRestTemplate().exchange(getBackendUrl() + "/list", HttpMethod.GET, stringRequestEntity,
                    new ParameterizedTypeReference<RestResponse<LinkedHashMap<String, Object>>>()
                    {
                    });
        }
        catch (HttpClientErrorException ex)
        {
            LOGGER.warn("Error calling backend", ex);
            String errorCode = ex.getStatusCode().toString();
            String errorMessage = ex.getMessage();
            throw new TechnicalException(errorCode, errorMessage);
        }

        List<E> entityList = new ArrayList<>();
        if (response != null)
        {
            HttpStatus status = response.getStatusCode();
            if (HttpStatus.OK.equals(status))
            {
                // call to call OK
                RestResponse<LinkedHashMap<String, Object>> responseBody = response.getBody();
                List<LinkedHashMap<String, Object>> responseContent = responseBody.getContent();
                for (LinkedHashMap<String, Object> responseEntity : responseContent)
                {
                    E entity = convertEntityFromBackend(responseEntity);
                    entityList.add(entity);
                }
            }
            else
            {
                // Error during call : re-create the exception
                RestResponse<LinkedHashMap<String, Object>> responseBody = response.getBody();
                String errorCode = responseBody.getErrorCode();
                String errorMessage = responseBody.getErrorMessage();
                throw new TechnicalException(errorCode, errorMessage);
            }
        }
        else
        {
            throw new TechnicalException("The service call returned a null result");
        }
        LOGGER.debug("Found " + entityList.size() + " entities.");
        return entityList;
    }

    /**
     * Retrieve a list of entities identified by the list of ID.
     * 
     * @param ids
     *            : List<Long> the list of identifiers.
     * @return List<E> : the list of all entities found.
     * @throws TechnicalException
     */
    public List<E> findAllEntities(List<Long> ids) throws TechnicalException
    {
        LOGGER.debug("Finding all entities for ids: " + ids);

        HttpEntity<List<Long>> stringRequestEntity = new HttpEntity<>(ids, createHeaders());
        ResponseEntity<RestResponse<LinkedHashMap<String, Object>>> response = null;
        try
        {
            response = getRestTemplate().exchange(getBackendUrl() + "/search", HttpMethod.POST, stringRequestEntity,
                    new ParameterizedTypeReference<RestResponse<LinkedHashMap<String, Object>>>()
                    {
                    });
        }
        catch (HttpClientErrorException ex)
        {
            LOGGER.warn("Error calling backend", ex);
            String errorCode = ex.getStatusCode().toString();
            String errorMessage = ex.getMessage();
            throw new TechnicalException(errorCode, errorMessage);
        }

        List<E> entityList = new ArrayList<>();
        if (response != null)
        {
            HttpStatus status = response.getStatusCode();
            if (HttpStatus.OK.equals(status))
            {
                // call to call OK
                RestResponse<LinkedHashMap<String, Object>> responseBody = response.getBody();
                List<LinkedHashMap<String, Object>> responseContent = responseBody.getContent();
                for (LinkedHashMap<String, Object> responseEntity : responseContent)
                {
                    E entity = convertEntityFromBackend(responseEntity);
                    entityList.add(entity);
                }
            }
            else
            {
                // Error during call : re-create the exception
                RestResponse<LinkedHashMap<String, Object>> responseBody = response.getBody();
                String errorCode = responseBody.getErrorCode();
                String errorMessage = responseBody.getErrorMessage();
                throw new TechnicalException(errorCode, errorMessage);
            }
        }
        else
        {
            throw new TechnicalException("The service call returned a null result");
        }
        LOGGER.debug("Found " + entityList.size() + " entities.");

        return entityList;
    }

    /**
     * Count the number of entities.
     * 
     * @return long : the number of entities found.
     * @throws TechnicalException
     */
    public long countEntities() throws TechnicalException
    {
        LOGGER.debug("Counting number of entities");
        HttpEntity<String> stringRequestEntity = new HttpEntity<>(null, createHeaders());
        ResponseEntity<RestResponse<Long>> response = null;
        try
        {
            response = getRestTemplate().exchange(getBackendUrl() + "/count", HttpMethod.GET, stringRequestEntity,
                    new ParameterizedTypeReference<RestResponse<Long>>()
                    {
                    });
        }
        catch (HttpClientErrorException ex)
        {
            LOGGER.warn("Error calling backend", ex);
            String errorCode = ex.getStatusCode().toString();
            String errorMessage = ex.getMessage();
            throw new TechnicalException(errorCode, errorMessage);
        }

        long count = 0;
        if (response != null)
        {
            HttpStatus status = response.getStatusCode();
            if (HttpStatus.OK.equals(status))
            {
                // call to call OK
                RestResponse<Long> responseBody = response.getBody();
                List<Long> responseContent = responseBody.getContent();
                checkIsOneResult(responseBody);
                Long countLong = responseContent.get(0);
                if (countLong != null)
                {
                    count = countLong.longValue();
                }
            }
            else
            {
                // Error during call : re-create the exception
                RestResponse<Long> responseBody = response.getBody();
                String errorCode = responseBody.getErrorCode();
                String errorMessage = responseBody.getErrorMessage();
                throw new TechnicalException(errorCode, errorMessage);
            }
        }
        else
        {
            throw new TechnicalException("The service call returned a null result");
        }
        LOGGER.debug("Counted " + count + " entities.");
        return count;
    }

    /**
     * Delete one entity identified by its ID.
     * 
     * @param id
     *            : the entity identifier.
     * @throws TechnicalException
     */
    public void deleteEntity(Long id) throws TechnicalException
    {
        LOGGER.debug("Deleting entity with id " + id);
        if (id == null)
        {
            throw new IllegalArgumentException("Id is mandatory to delete entity.");
        }
        HttpEntity<String> request = new HttpEntity<>(null, createHeaders());
        ResponseEntity<RestResponse<LinkedHashMap<String, Object>>> response = null;
        try
        {
            response = getRestTemplate().exchange(getBackendUrl() + "/delete/" + id, HttpMethod.DELETE, request,
                    new ParameterizedTypeReference<RestResponse<LinkedHashMap<String, Object>>>()
                    {
                    });
        }
        catch (HttpClientErrorException ex)
        {
            LOGGER.warn("Error calling backend", ex);
            String errorCode = ex.getStatusCode().toString();
            String errorMessage = ex.getMessage();
            throw new TechnicalException(errorCode, errorMessage);
        }

        if (response != null)
        {
            HttpStatus status = response.getStatusCode();
            if (HttpStatus.OK.equals(status))
            {
                // do nothing no result expected.
            }
            else
            {
                // Error during call : re-create the exception
                RestResponse<LinkedHashMap<String, Object>> responseBody = response.getBody();
                String errorCode = responseBody.getErrorCode();
                String errorMessage = responseBody.getErrorMessage();
                throw new TechnicalException(errorCode, errorMessage);
            }
        }
        else
        {
            throw new TechnicalException("The service call returned a null result");
        }
        LOGGER.debug("Deleted entity with id " + id);
    }

    /**
     * Delete one entity.
     * 
     * @param entity
     *            : the entity to be deleted.
     * @throws TechnicalException
     */
    public void deleteEntity(E entity) throws TechnicalException
    {
        LOGGER.debug("Deleting entity: " + entity);
        Long id = getId(entity);
        if (id == null)
        {
            throw new IllegalArgumentException("Entity id is mandatory!");
        }
        deleteEntity(id);
        LOGGER.debug("Deleted entity " + entity);
    }

    /**
     * Delete a list of entities.
     * 
     * @param entities
     *            : List<E> the list of entities to be deleted.
     * @throws TechnicalException
     */
    public void deleteEntities(List<E> entities) throws TechnicalException
    {
        LOGGER.debug("Deleting entities " + entities);

        List<K> requestList = new ArrayList<>();
        for (E entity : entities)
        {
            if (entity != null)
            {
                K deleteRequest = convertEntityToBackend(entity);
                requestList.add(deleteRequest);
            }
        }
        HttpEntity<List<K>> httpRequestEntity = new HttpEntity<>(requestList, createHeaders());
        ResponseEntity<RestResponse<LinkedHashMap<String, Object>>> response = null;
        try
        {
            response = getRestTemplate().exchange(getBackendUrl() + "/delete", HttpMethod.POST, httpRequestEntity,
                    new ParameterizedTypeReference<RestResponse<LinkedHashMap<String, Object>>>()
                    {
                    });
        }
        catch (HttpClientErrorException ex)
        {
            LOGGER.warn("Error calling backend", ex);
            String errorCode = ex.getStatusCode().toString();
            String errorMessage = ex.getMessage();
            throw new TechnicalException(errorCode, errorMessage);
        }

        if (response != null)
        {
            HttpStatus status = response.getStatusCode();
            if (HttpStatus.OK.equals(status))
            {
                // do nothing no result expected.
            }
            else
            {
                // Error during call : re-create the exception
                RestResponse<LinkedHashMap<String, Object>> responseBody = response.getBody();
                String errorCode = responseBody.getErrorCode();
                String errorMessage = responseBody.getErrorMessage();
                throw new TechnicalException(errorCode, errorMessage);
            }
        }
        else
        {
            throw new TechnicalException("The service call returned a null result");
        }
        LOGGER.debug("Deleted entities " + entities);
    }

    /**
     * Check that there is one and only one result in the passed response
     * object.
     * 
     * @param responseBody
     *            RestResponse<?> : the object to check.
     * @throws TechnicalException
     *             in case there is not 1 result in the response content.
     */
    private void checkIsOneResult(RestResponse<?> responseBody) throws TechnicalException
    {
        int resultNumber = responseBody.getContentNumber();
        if (resultNumber < 1)
        {
            throw new TechnicalException(ErrorCode.TE002);
        }
        if (resultNumber > 1)
        {
            throw new TechnicalException(ErrorCode.TE001);
        }
    }

    /**
     * Extract an attribute Integer value.
     * 
     * @param linkedHashMap
     *            : the attribute map.
     * @param name
     *            : the attribute name.
     * @return Integer : the attribute value.
     */
    public static Integer getAsInteger(LinkedHashMap<String, Object> linkedHashMap, String name)
    {
        Integer integerValue = null;
        if (linkedHashMap != null && name != null && linkedHashMap.get(name) != null)
        {
            integerValue = Integer.parseInt(linkedHashMap.get(name).toString());
        }
        else
        {
            LOGGER.warn("getAsInteger : No value found for attribute : " + name);
        }
        return integerValue;
    }

    /**
     * Extract an attribute Long value.
     * 
     * @param linkedHashMap
     *            : the attribute map.
     * @param name
     *            : the attribute name.
     * @return Long : the attribute value.
     */
    public static Long getAsLong(LinkedHashMap<String, Object> linkedHashMap, String name)
    {
        Long longValue = null;
        if (linkedHashMap != null && name != null && linkedHashMap.get(name) != null)
        {
            longValue = Long.parseLong(linkedHashMap.get(name).toString());
        }
        else
        {
            LOGGER.warn("getAsLong : No value found for attribute : " + name);
        }
        return longValue;
    }

    /**
     * Extract an attribute String value.
     * 
     * @param linkedHashMap
     *            : the attribute map.
     * @param name
     *            : the attribute name.
     * @return String : the attribute value.
     */
    public static String getAsString(LinkedHashMap<String, Object> linkedHashMap, String name)
    {
        String string = null;
        if (linkedHashMap != null && name != null && linkedHashMap.get(name) != null)
        {
            string = linkedHashMap.get(name).toString();
        }
        else
        {
            LOGGER.warn("getAsString : No value found for attribute : " + name);
        }
        return string;
    }

    /**
     * Extract an attribute Date value.
     * 
     * @param linkedHashMap
     *            : the attribute map.
     * @param name
     *            : the attribute name.
     * @return Date : the attribute value.
     */
    public static Date getAsDate(LinkedHashMap<String, Object> linkedHashMap, String name)
    {
        Date date = null;
        if (linkedHashMap != null && name != null && linkedHashMap.get(name) != null)
        {
            date = new Date(Long.parseLong(linkedHashMap.get(name).toString()));
        }
        else
        {
            LOGGER.warn("getAsDate : No value found for attribute : " + name);
        }
        return date;
    }

    /**
     * Extract an attribute Boolean value.
     * 
     * @param linkedHashMap
     *            : the attribute map.
     * @param name
     *            : the attribute name.
     * @return Boolean : the attribute value.
     */
    public static Boolean getAsBoolean(LinkedHashMap<String, Object> linkedHashMap, String name)
    {
        Boolean booleanValue = null;
        if (linkedHashMap != null && name != null && linkedHashMap.get(name) != null)
        {
            booleanValue = Boolean.parseBoolean(linkedHashMap.get(name).toString());
        }
        else
        {
            LOGGER.warn("getAsBoolean : No value found for attribute : " + name);
        }
        return booleanValue;
    }

    /**
     * Extract an attribute List<LinkedHashMap<String, Object>> value.
     * 
     * @param linkedHashMap
     *            : the attribute map.
     * @param name
     *            : the attribute name.
     * @return List<LinkedHashMap<String, Object>> : the attribute value.
     */
    @SuppressWarnings("unchecked")
    public static List<LinkedHashMap<String, Object>> getAsList(LinkedHashMap<String, Object> linkedHashMap, String name)
    {
        List<LinkedHashMap<String, Object>> listValue = null;
        if (linkedHashMap != null && name != null && linkedHashMap.get(name) != null)
        {
            listValue = (List<LinkedHashMap<String, Object>>) linkedHashMap.get(name);
        }
        else
        {
            LOGGER.warn("getAsList : No value found for attribute : " + name);
        }
        return listValue;
    }
}
