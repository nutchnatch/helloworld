package com.bnpp.cardif.yourapplication.frontend.services;

import com.bnpp.cardif.yourapplication.frontend.beans.JSONSample;

/**
 * Interface for the service related to Sample Entities.
 * 
 * @author 831743
 *
 */
public interface SampleService extends FrontendBaseService<JSONSample>
{

}
