package com.bnpp.cardif.yourapplication.frontend.security;

import org.opensaml.common.SAMLException;
import org.opensaml.saml2.core.AuthnRequest;
import org.opensaml.saml2.metadata.AssertionConsumerService;
import org.opensaml.saml2.metadata.SingleSignOnService;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.saml.context.SAMLMessageContext;
import org.springframework.security.saml.websso.WebSSOProfileImpl;
import org.springframework.security.saml.websso.WebSSOProfileOptions;

/**
 * Customized version of SesameWebSSOProfileImpl to add the following behavior:
 * In the AuthnRequest we set the requested AttributeConsumingServiceIndex.
 * 
 * @author 831743
 *
 */
public class SesameWebSSOProfileImpl extends WebSSOProfileImpl
{
    // Logger
    private static final Logger LOGGER = LoggerFactory.getLogger(SesameWebSSOProfileImpl.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * org.springframework.security.saml.websso.WebSSOProfileImpl#getAuthnRequest
     * (org.springframework.security.saml.context.SAMLMessageContext,
     * org.springframework.security.saml.websso.WebSSOProfileOptions,
     * org.opensaml.saml2.metadata.AssertionConsumerService,
     * org.opensaml.saml2.metadata.SingleSignOnService)
     */
    @Override
    protected AuthnRequest getAuthnRequest(SAMLMessageContext context, WebSSOProfileOptions options, AssertionConsumerService assertionConsumer,
            SingleSignOnService bindingService) throws SAMLException, MetadataProviderException
    {

        AuthnRequest request = super.getAuthnRequest(context, options, assertionConsumer, bindingService);
        LOGGER.debug("getAuthnRequest : adding AttributeConsumerIndex");
        // add cast to the customize object to retreive the added attributes.
        SesameWebSSOProfileOptions sesameOption = (SesameWebSSOProfileOptions) options;
        request.setAttributeConsumingServiceIndex(sesameOption.getAttributeConsumerIndex());
        return request;
    }
}
