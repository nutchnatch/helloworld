package com.bnpp.cardif.yourapplication.frontend.web;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.NoHandlerFoundException;

/**
 * Class that handle exception from all the MVC controllers.
 * 
 * @author 831743
 *
 */
@ControllerAdvice
public class GlobalExceptionHandler
{

    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(NoHandlerFoundException.class)
    @ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "Requested URL not found")
    public ModelAndView handleError404(HttpServletRequest request, Exception e)
    {
        // log the error
        LOGGER.error("Request: " + request.getRequestURL() + " raised " + e);
        // then return 404 content
        ModelAndView model = new ModelAndView("404");
        model.addObject("exception", e);
        return model;
    }
}
