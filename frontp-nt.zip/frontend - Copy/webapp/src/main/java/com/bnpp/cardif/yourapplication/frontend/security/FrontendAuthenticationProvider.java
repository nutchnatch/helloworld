package com.bnpp.cardif.yourapplication.frontend.security;

import java.util.ArrayList;
import java.util.List;

import javax.xml.ws.WebServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.AbstractUserDetailsAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.bnpp.cardif.sesame.security.AuthenticatedUser;
import com.bnpp.cardif.sesame.security.SesameWebServiceFactory;
import com.bnppa.sesame.services.common.model.UserIdentity;
import com.bnppa.sesame.services.standard.proxy.ArrayOfTns3NillableJoining;
import com.bnppa.sesame.services.standard.proxy.ArrayOfXsdNillableString;
import com.bnppa.sesame.services.standard.proxy.AuthenticationServicesWSP;
import com.bnppa.sesame.services.standard.proxy.AuthorizationServicesWSP;
import com.bnppa.sesame.services.standard.proxy.ExpiredPasswordException;
import com.bnppa.sesame.services.standard.proxy.IdentityServicesWSP;
import com.bnppa.sesame.services.standard.proxy.InvalidParameterException;
import com.bnppa.sesame.services.standard.proxy.InvalidTokenException;
import com.bnppa.sesame.services.standard.proxy.LockedLoginException;
import com.bnppa.sesame.services.standard.proxy.LoginException;
import com.bnppa.sesame.services.standard.proxy.TechnicalException;

/**
 * A base AuthenticationProvider that works with
 * org.springframework.security.core.userdetails.UserDetails objects. The class
 * is designed to respond to UsernamePasswordAuthenticationToken authentication
 * requests.
 * 
 * This authenticator uses: Username from authentication.getName() and Password
 * from authentication.getCredentials() to call Sesame to validate the user.
 * 
 * @author 831743
 *
 */
@Component
public class FrontendAuthenticationProvider extends AbstractUserDetailsAuthenticationProvider
{

    private static final Logger LOGGER = LoggerFactory.getLogger(FrontendAuthenticationProvider.class);

    @Autowired
    private SesameWebServiceFactory sesameWebServiceFactory;

    @Value("${authentication-provider.contactMessage}")
    private String contactMessage;

    @Value("${authentication-provider.appDomain}")
    private String appDomain;

    @Value("${authentication-provider.authenticationType}")
    private String authenticationType;

    @Value("${authentication-provider.is-security-enabled}")
    private Boolean isSecurityEnabled;

    /**
     * @return the contactMessage
     */
    public String getContactMessage()
    {
        return contactMessage;
    }

    /**
     * @param contactMessage
     *            the contactMessage to set
     */
    public void setContactMessage(String contactMessage)
    {
        this.contactMessage = contactMessage;
    }

    /**
     * @return the appDomain
     */
    public String getAppDomain()
    {
        return appDomain;
    }

    /**
     * @param appDomain
     *            the appDomain to set
     */
    public void setAppDomain(String appDomain)
    {
        this.appDomain = appDomain;
    }

    /**
     * @return the authenticationType
     */
    public String getAuthenticationType()
    {
        return authenticationType;
    }

    /**
     * @param authenticationType
     *            the authenticationType to set
     */
    public void setAuthenticationType(String authenticationType)
    {
        this.authenticationType = authenticationType;
    }

    /**
     * @return the isSecurityEnabled
     */
    public Boolean isSecurityEnabled()
    {
        return isSecurityEnabled;
    }

    /**
     * @param isSecurityEnabled
     *            the isSecurityEnabled to set
     */
    public void setSecurityEnabled(Boolean isSecurityEnabled)
    {
        this.isSecurityEnabled = isSecurityEnabled;
    }

    /**
     * Returns true if this AuthenticationProvider supports the indicated
     * Authentication object.
     * 
     * Returning true does not guarantee an AuthenticationProvider will be able
     * to authenticate the presented instance of the Authentication class. It
     * simply indicates it can support closer evaluation of it. An
     * AuthenticationProvider can still return null from the
     * authenticate(Authentication) method to indicate another
     * AuthenticationProvider should be tried.
     * 
     * Selection of an AuthenticationProvider capable of performing
     * authentication is conducted at runtime the ProviderManager.
     */
    @Override
    public boolean supports(Class<?> authentication)
    {
        LOGGER.debug("[*** IMPORTANT ***] authentication = " + authentication);
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }

    /**
     * Performs authentication with the same contract as
     * org.springframework.security
     * .authentication.AuthenticationManager.authenticate(Authentication) .
     */
    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException
    {
        String username = authentication.getName();
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        AuthenticatedUser authenticatedUser = (AuthenticatedUser) retrieveUser(username, (UsernamePasswordAuthenticationToken) authentication);
        stopWatch.stop();
        authenticatedUser.setTimeToSpentOnAuthentication(stopWatch.getTotalTimeMillis());

        UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(authenticatedUser, null,
                authenticatedUser.getAuthorities());
        return authenticationToken;
    }

    /**
     * Allows subclasses to actually retrieve the UserDetails from an
     * implementation-specific location, with the option of throwing an
     * AuthenticationException immediately if the presented credentials are
     * incorrect (this is especially useful if it is necessary to bind to a
     * resource as the user in order to obtain or generate a UserDetails).
     * 
     * Subclasses are not required to perform any caching, as the
     * AbstractUserDetailsAuthenticationProvider will by default cache the
     * UserDetails. The caching of UserDetails does present additional
     * complexity as this means subsequent requests that rely on the cache will
     * need to still have their credentials validated, even if the correctness
     * of credentials was assured by subclasses adopting a binding-based
     * strategy in this method. Accordingly it is important that subclasses
     * either disable caching (if they want to ensure that this method is the
     * only method that is capable of authenticating a request, as no
     * UserDetails will ever be cached) or ensure subclasses implement
     * additionalAuthenticationChecks(UserDetails,
     * UsernamePasswordAuthenticationToken) to compare the credentials of a
     * cached UserDetails with subsequent authentication requests.
     * 
     * Most of the time subclasses will not perform credentials inspection in
     * this method, instead performing it in
     * additionalAuthenticationChecks(UserDetails,
     * UsernamePasswordAuthenticationToken) so that code related to credentials
     * validation need not be duplicated across two methods.
     */
    @Override
    protected UserDetails retrieveUser(String username, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException
    {
        String password = (String) authentication.getCredentials();
        if (isSecurityEnabled() != null && !isSecurityEnabled().booleanValue())
        {
            LOGGER.debug("Security is not enable not performing check with Sesame");
            List<GrantedAuthority> grantedAuthorities = new ArrayList<GrantedAuthority>();
            grantedAuthorities.add(new SimpleGrantedAuthority("Empty_Role"));
            return new AuthenticatedUser(username, null, "FakeToken", username, "", grantedAuthorities);
        }
        try
        {
            // Login User
            AuthenticationServicesWSP loginService = sesameWebServiceFactory.getAuthenticationServicesWSP();
            String token = loginService.loginInUserRef(username, password, getAuthenticationType());
            LOGGER.debug("Username : " + username + " got token : " + token);
            // Retrieve User Roles
            AuthorizationServicesWSP roleService = sesameWebServiceFactory.getAuthorizationServicesWSP();
            ArrayOfXsdNillableString roles = roleService.getRoles(token, getAppDomain());
            List<GrantedAuthority> grantedAuthorities = buildGrantedAuthorities(roles);
            // Retrieve User Identity
            IdentityServicesWSP identityService = sesameWebServiceFactory.getIdentityServicesWSP();
            UserIdentity userIdentity = identityService.getUserIdentity(token);
            // Retrieve User joinings
            AuthorizationServicesWSP authorizationServicesWSP = sesameWebServiceFactory.getAuthorizationServicesWSP();
            ArrayOfTns3NillableJoining joiningList = authorizationServicesWSP.getJoinings(token, getAppDomain());

            // Build the AuthenticatedUser object based on all the data
            AuthenticatedUser authenticatedUser = new AuthenticatedUser(userIdentity.getLogin(), null, token, userIdentity.getFirstName(),
                    userIdentity.getLastName(), grantedAuthorities);
            // Add the joining
            if (joiningList != null && joiningList.getJoining() != null)
            {
                authenticatedUser.getJoinings().addAll(joiningList.getJoining());
            }
            return authenticatedUser;
        }
        catch (ExpiredPasswordException e)
        {
            LOGGER.debug("Your password is expired. Please reset your password with the Refog", e);
            throw new BadCredentialsException("Your password is expired. Please reset your password with the Refog");
        }
        catch (LockedLoginException e)
        {
            LOGGER.debug("Your account is locked. ", e);
            throw new BadCredentialsException("Your account is locked. " + contactMessage);
        }
        catch (LoginException e)
        {
            LOGGER.debug("The login or the password filled is not correct. ", e);
            throw new BadCredentialsException("The login or the password filled is not correct. " + contactMessage);
        }
        catch (WebServiceException e)
        {
            LOGGER.debug("The connection cannot be established to Sesame. ", e);
            throw new AuthenticationServiceException("The connection cannot be established to Sesame. " + contactMessage, e);
        }
        catch (InvalidTokenException e)
        {
            LOGGER.debug("The token filled is not correct. ", e);
            throw new BadCredentialsException("The token filled is not correct. " + contactMessage);
        }
        catch (InvalidParameterException e)
        {
            LOGGER.debug("A technical error occurs during authentication. ", e);
            throw new AuthenticationServiceException("A technical error occurs during authentication. " + contactMessage, e);
        }
        catch (TechnicalException e)
        {
            LOGGER.debug("A technical error occurs during authentication. ", e);
            throw new AuthenticationServiceException("A technical error occurs during authentication. " + contactMessage, e);
        }
    }

    /**
     * Build the list of GrantedAuthority objects from the Sesame Role list.
     * 
     * @param roles
     * @return
     */
    private static List<GrantedAuthority> buildGrantedAuthorities(ArrayOfXsdNillableString roles)
    {
        List<GrantedAuthority> grantedAuthorities = new ArrayList<GrantedAuthority>();
        for (String role : roles.getString())
        {
            grantedAuthorities.add(new SimpleGrantedAuthority(role));
        }
        return grantedAuthorities;
    }

    /**
     * Allows subclasses to perform any additional checks of a returned (or
     * cached) UserDetails for a given authentication request. Generally a
     * subclass will at least compare the Authentication.getCredentials() with a
     * UserDetails.getPassword(). If custom logic is needed to compare
     * additional properties of UserDetails and/or
     * UsernamePasswordAuthenticationToken, these should also appear in this
     * method.
     */
    @Override
    protected void additionalAuthenticationChecks(UserDetails arg0, UsernamePasswordAuthenticationToken arg1) throws AuthenticationException
    {
        // Nothing to do.
    }

}
