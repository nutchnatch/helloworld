package com.bnpp.cardif.yourapplication.frontend;

import org.springframework.boot.builder.SpringApplicationBuilder;

import com.bnpp.cardif.yourapplication.frontend.config.RootConfiguration;

public class SpringBootRunner
{

    public static void main(String[] args)
    {
        SpringApplicationBuilder applicationBuilder = new SpringApplicationBuilder();
        applicationBuilder.sources(RootConfiguration.class);
        applicationBuilder.web(true);
        applicationBuilder.run(args);
    }

}
