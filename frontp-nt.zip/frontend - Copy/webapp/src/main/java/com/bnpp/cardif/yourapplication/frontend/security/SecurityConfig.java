package com.bnpp.cardif.yourapplication.frontend.security;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.commons.httpclient.protocol.ProtocolSocketFactory;
import org.apache.velocity.app.VelocityEngine;
import org.opensaml.saml2.metadata.provider.FilesystemMetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.opensaml.xml.parse.ParserPool;
import org.opensaml.xml.parse.StaticBasicParserPool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.MethodInvokingFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.saml.SAMLAuthenticationProvider;
import org.springframework.security.saml.SAMLBootstrap;
import org.springframework.security.saml.SAMLDiscovery;
import org.springframework.security.saml.SAMLEntryPoint;
import org.springframework.security.saml.SAMLLogoutFilter;
import org.springframework.security.saml.SAMLLogoutProcessingFilter;
import org.springframework.security.saml.SAMLProcessingFilter;
import org.springframework.security.saml.SAMLWebSSOHoKProcessingFilter;
import org.springframework.security.saml.context.SAMLContextProviderImpl;
import org.springframework.security.saml.key.JKSKeyManager;
import org.springframework.security.saml.key.KeyManager;
import org.springframework.security.saml.log.SAMLDefaultLogger;
import org.springframework.security.saml.metadata.CachingMetadataManager;
import org.springframework.security.saml.metadata.ExtendedMetadata;
import org.springframework.security.saml.metadata.ExtendedMetadataDelegate;
import org.springframework.security.saml.metadata.MetadataDisplayFilter;
import org.springframework.security.saml.metadata.MetadataGenerator;
import org.springframework.security.saml.metadata.MetadataGeneratorFilter;
import org.springframework.security.saml.parser.ParserPoolHolder;
import org.springframework.security.saml.processor.HTTPArtifactBinding;
import org.springframework.security.saml.processor.HTTPPAOS11Binding;
import org.springframework.security.saml.processor.HTTPPostBinding;
import org.springframework.security.saml.processor.HTTPRedirectDeflateBinding;
import org.springframework.security.saml.processor.HTTPSOAP11Binding;
import org.springframework.security.saml.processor.SAMLBinding;
import org.springframework.security.saml.processor.SAMLProcessorImpl;
import org.springframework.security.saml.trust.httpclient.TLSProtocolConfigurer;
import org.springframework.security.saml.trust.httpclient.TLSProtocolSocketFactory;
import org.springframework.security.saml.util.VelocityFactory;
import org.springframework.security.saml.websso.ArtifactResolutionProfile;
import org.springframework.security.saml.websso.ArtifactResolutionProfileImpl;
import org.springframework.security.saml.websso.SingleLogoutProfile;
import org.springframework.security.saml.websso.SingleLogoutProfileImpl;
import org.springframework.security.saml.websso.WebSSOProfile;
import org.springframework.security.saml.websso.WebSSOProfileConsumer;
import org.springframework.security.saml.websso.WebSSOProfileConsumerHoKImpl;
import org.springframework.security.saml.websso.WebSSOProfileConsumerImpl;
import org.springframework.security.saml.websso.WebSSOProfileECPImpl;
import org.springframework.security.saml.websso.WebSSOProfileOptions;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.DefaultSecurityFilterChain;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.access.channel.ChannelProcessingFilter;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.csrf.CsrfFilter;
import org.springframework.security.web.csrf.CsrfTokenRepository;
import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

/**
 * Configuration object for Spring Security. The SecurityConfig will:
 * 
 * - Require authentication to every URL in your application
 * 
 * - Generate a login form for you
 * 
 * - Allow the user with the Username user and the Password password to
 * authenticate with form based authentication
 * 
 * - Allow the user to logout
 * 
 * - CSRF attack prevention
 * 
 * - Session Fixation protection
 * 
 * - Security Header integration
 * 
 * -- HTTP Strict Transport Security for secure requests
 * 
 * -- X-Content-Type-Options integration
 * 
 * -- Cache Control (can be overridden later by your application to allow
 * caching of your static resources)
 * 
 * -- X-XSS-Protection integration
 * 
 * -- X-Frame-Options integration to help prevent Clickjacking
 * 
 * -Integrate with the following Servlet API methods
 * 
 * -- HttpServletRequest#getRemoteUser()
 * 
 * -- HttpServletRequest.html#getUserPrincipal()
 * 
 * -- HttpServletRequest.html#isUserInRole(java.lang.String)
 * 
 * -- HttpServletRequest.html#login(java.lang.String, java.lang.String)
 * 
 * -- HttpServletRequest.html#logout()
 * 
 * @author 831743
 *
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter
{
    private static final Logger LOGGER = LoggerFactory.getLogger(SecurityConfig.class);

    @Autowired
    private ResourceLoader resourceLoader;

    @Autowired
    AuthenticationProvider frontendAuthenticationProvider;

    @Autowired
    private SAMLUserDetailsServiceImpl samlUserDetailsServiceImpl;

    @Autowired
    AccessDeniedHandler customAccessDeniedHandler;

    @Autowired
    AuthenticationEntryPoint customAuthenticationEntryPoint;

    /**
     * Activate the SAMl authentication, if false, then standard sesame
     * webService authentication is used.
     */
    @Value("${authentication.use-saml}")
    private Boolean useSAML;

    @Value("${authentication.sesame-idp-metadata-file-path}")
    private String sesameIdpMetadataFilePath;

    /**
     * Unique identifier of the service provider.
     */
    @Value("${authentication.service-provider-entity-id}")
    private String serviceProviderEntityId;

    /**
     * Base URL to construct SAML endpoints from, needs to be a URL with
     * protocol, server, port and context path.
     */
    @Value("${authentication.service-provider-entity-base-url}")
    private String serviceProviderEntityBaseURL;

    /**
     * Name of the application used to generate the AttributeConsumingService
     * ServiceName.
     */
    @Value("${authentication.service-provider-application-name}")
    private String serviceProviderApplicationName;

    /**
     * Password of the keyStrore used for SSL connection in the SAML
     * authentication process.
     */
    @Value("${authentication.service-provider-key-store-password}")
    private String keyStorePass;

    /**
     * Default Key of the keyStrore used for SSL connection in the SAML
     * authentication process.
     */
    @Value("${authentication.service-provider-key-store-default-key}")
    private String keyStoreDefaultKey;

    /**
     * SAML parameter RelayState sent in the authentication request.
     */
    @Value("${authentication.service-provider-saml-relay-state}")
    private String samlRelayState;

    /**
     * Supplies the default target Url that will be used if no saved request is
     * found in the session. If not set, defaults to {@code /}. It will be
     * treated as relative to the web-app's context path, and should include the
     * leading <code>/</code>. Alternatively, inclusion of a scheme name (such
     * as "http://" or "https://") as the prefix will denote a fully-qualified
     * URL and this is also supported.
     */
    @Value("${authentication.service-provider-saml-default-target-url}")
    private String samlDefaultTargetUrl;

    /**
     * The URL which will be used as the failure destination. It will be treated
     * as relative to the web-app's context path, and should include the leading
     * /.
     */
    @Value("${authentication.service-provider-saml-default-failure-url}")
    private String samlDefaultFailureUrl;

    /**
     * Supplies the default logout Url that will be used if no saved request is
     * found in the session. If not set, defaults to {@code /}. It will be
     * treated as relative to the web-app's context path, and should include the
     * leading <code>/</code>. Alternatively, inclusion of a scheme name (such
     * as "http://" or "https://") as the prefix will denote a fully-qualified
     * URL and this is also supported.
     */
    @Value("${authentication.service-provider-saml-default-logout-url}")
    private String samlDefaultLogoutUrl;

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception
    {
        LOGGER.debug("configureGlobal");
        if (getUseSAML() != null && getUseSAML().booleanValue())
        {
            LOGGER.warn("Using SAML authentication");
            auth.authenticationProvider(samlAuthenticationProvider());
        }
        else
        {
            LOGGER.warn("Using WEB SERVICES authentication");
            auth.authenticationProvider(frontendAuthenticationProvider);
        }
    }

    /**
     * Configuring the global Web security to ignore some directories.
     */
    @Override
    public void configure(WebSecurity web) throws Exception
    {
        LOGGER.debug("configure WebSecurity");
        // Spring Security should completely ignore URLs starting with
        // /static/assets/
        web.ignoring().antMatchers("/static/assets/**").and();
        // Spring Security should completely ignore URLs for the js / images /
        // font
        web.ignoring().antMatchers("/static/*.ico").and();
        web.ignoring().antMatchers("/static/*.eot").and();
        web.ignoring().antMatchers("/static/*.svg").and();
        web.ignoring().antMatchers("/static/*.ttf").and();
        web.ignoring().antMatchers("/static/*.woff").and();
        web.ignoring().antMatchers("/static/*.woff2").and();
        web.ignoring().antMatchers("/static/*.js").and();
        web.ignoring().antMatchers("/static/*.map").and();
        web.ignoring().antMatchers("/static/*.png").and();
        web.ignoring().antMatchers("/static/*.jpg").and();
    }

    /**
     * Configuring the security to specify the various access level of resources
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception
    {
        LOGGER.debug("configure HttpSecurity");
        // Set Http basic authentication
        http.httpBasic().and();
        // Set custom accessDenied
        http.exceptionHandling().accessDeniedHandler(customAccessDeniedHandler);
        // Set SAML entryPoint
        if (getUseSAML() != null && getUseSAML().booleanValue())
        {
            http.httpBasic().authenticationEntryPoint(samlEntryPoint()).and();
        }
        else
        {
            http.exceptionHandling().authenticationEntryPoint(customAuthenticationEntryPoint);
        }
        // Set the authorized pages for unAuthenticated users
        http.authorizeRequests().antMatchers("/jsp/404.jsp").permitAll().and();
        http.authorizeRequests().antMatchers("/index.html", "/", "/logout.html").permitAll().and();
        http.authorizeRequests().antMatchers("/logout").permitAll().and();

        if (getUseSAML() != null && getUseSAML().booleanValue())
        {
            // when using SAML, we authorize access to SAMl endpoint without
            // being authenticated. This allow the SAML authentication process
            // to be performed.
            http.authorizeRequests().antMatchers("/saml/**").permitAll().and();
        }
        else
        {
            // when not using SAML, we authorize access to application pages
            // without being authenticated. This allow the application to
            // display the login page.
            http.authorizeRequests().antMatchers("/static/index.html", "/static/").permitAll().and();
        }
        // Set all other requests requires authentication.
        http.authorizeRequests().anyRequest().authenticated().and();
        // configure the csrfTokenRepository
        http.csrf().csrfTokenRepository(csrfTokenRepository()).and();
        // Set SAML filters
        if (getUseSAML())
        {
            FilterChainProxy samlFilter = samlFilter();
            http.addFilterBefore(metadataGeneratorFilter(), ChannelProcessingFilter.class);
            http.addFilterAfter(samlFilter, BasicAuthenticationFilter.class);
            http.addFilterBefore(samlFilter, CsrfFilter.class);
        }
        else
        {
            // configure the logout
            http.logout().invalidateHttpSession(true).and();
            http.logout().logoutSuccessUrl(getSamlDefaultLogoutUrl()).and();
            // configure to use GET logout to avoid CSRF errors.
            http.logout().logoutRequestMatcher(new AntPathRequestMatcher("/logout")).and();
        }
        // Add the csrf filter
        http.addFilterAfter(new CsrfHeaderFilter(), CsrfFilter.class);
    }

    /**
     * Csrf Token Repository that contains the header named "X-XSRF-TOKEN".
     * 
     * @return CsrfTokenRepository
     */
    private static CsrfTokenRepository csrfTokenRepository()
    {
        HttpSessionCsrfTokenRepository repository = new HttpSessionCsrfTokenRepository();
        repository.setHeaderName("X-XSRF-TOKEN");
        return repository;
    }

    // ********************** SAML objects *********************************

    // Initialization of the velocity engine
    @Bean
    public VelocityEngine velocityEngine()
    {
        return VelocityFactory.getEngine();
    }

    // XML parser pool needed for OpenSAML parsing
    @Bean(initMethod = "initialize")
    public StaticBasicParserPool parserPool()
    {
        return new StaticBasicParserPool();
    }

    @Bean(name = "parserPoolHolder")
    public ParserPoolHolder parserPoolHolder()
    {
        return new ParserPoolHolder();
    }

    // Bindings, encoders and decoders used for creating and parsing messages
    @Bean
    public MultiThreadedHttpConnectionManager multiThreadedHttpConnectionManager()
    {
        return new MultiThreadedHttpConnectionManager();
    }

    @Bean
    public HttpClient httpClient()
    {
        return new HttpClient(multiThreadedHttpConnectionManager());
    }

    // SAML Authentication Provider responsible for validating of received SAML
    // messages
    @Bean
    public SAMLAuthenticationProvider samlAuthenticationProvider()
    {
        SAMLAuthenticationProvider samlAuthenticationProvider = new SAMLAuthenticationProvider();
        samlAuthenticationProvider.setUserDetails(samlUserDetailsServiceImpl);
        samlAuthenticationProvider.setForcePrincipalAsString(false);
        return samlAuthenticationProvider;
    }

    // Provider of default SAML Context
    @Bean
    public SAMLContextProviderImpl contextProvider()
    {
        return new SAMLContextProviderImpl();
    }

    // Initialization of OpenSAML library
    @Bean
    public static SAMLBootstrap samlBootstrap()
    {
        SAMLBootstrap bootStrap = new SesameSAMLBootstrap();
        return bootStrap;
    }

    // Logger for SAML messages and events
    @Bean
    public SAMLDefaultLogger samlLogger()
    {
        return new SAMLDefaultLogger();
    }

    // SAML 2.0 WebSSO Assertion Consumer
    @Bean
    public WebSSOProfileConsumer webSSOprofileConsumer()
    {
        WebSSOProfileConsumerImpl consumer = new SesameWebSSOProfileConsumerImpl();
        consumer.setIncludeAllAttributes(true);
        // System allows users to single sign-on for up to 7200 seconds since
        // their initial authentication with the IDP (based on value
        // AuthInstance of the Authentication statement).
        consumer.setMaxAuthenticationAge(7200);
        // Validity of assertions processed during the signle sign-on process is
        // limited to 3000 seconds.
        consumer.setMaxAssertionTime(3000);
        return consumer;
    }

    // SAML 2.0 Holder-of-Key WebSSO Assertion Consumer
    @Bean
    public WebSSOProfileConsumerHoKImpl hokWebSSOprofileConsumer()
    {
        WebSSOProfileConsumerHoKImpl consumer = new WebSSOProfileConsumerHoKImpl();
        return consumer;
    }

    // SAML 2.0 Web SSO profile
    @Bean
    public WebSSOProfile webSSOprofile()
    {
        SesameWebSSOProfileImpl profile = new SesameWebSSOProfileImpl();
        return profile;
    }

    // SAML 2.0 Holder-of-Key Web SSO profile
    @Bean
    public WebSSOProfileConsumerHoKImpl hokWebSSOProfile()
    {
        WebSSOProfileConsumerHoKImpl profile = new WebSSOProfileConsumerHoKImpl();
        return profile;
    }

    // SAML 2.0 ECP profile
    @Bean
    public WebSSOProfileECPImpl ecpprofile()
    {
        WebSSOProfileECPImpl profile = new WebSSOProfileECPImpl();
        return profile;
    }

    // SAML 2.0 Logout Profile
    @Bean
    public SingleLogoutProfile logoutprofile()
    {
        return new SingleLogoutProfileImpl();
    }

    // Central storage of cryptographic keys
    @Bean
    public KeyManager keyManager()
    {
        DefaultResourceLoader loader = new DefaultResourceLoader();
        Resource storeFile = loader.getResource("classpath:/saml/samlKeystore.jks");
        Map<String, String> passwords = new HashMap<>();
        passwords.put(getKeyStoreDefaultKey(), getKeyStorePass());
        return new JKSKeyManager(storeFile, getKeyStorePass(), passwords, getKeyStoreDefaultKey());
    }

    // Setup TLS Socket Factory
    @Bean
    public TLSProtocolConfigurer tlsProtocolConfigurer()
    {
        return new TLSProtocolConfigurer();
    }

    @Bean
    public ProtocolSocketFactory socketFactory()
    {
        return new TLSProtocolSocketFactory(keyManager(), null, "default");
    }

    @Bean
    public Protocol socketFactoryProtocol()
    {
        return new Protocol("https", socketFactory(), 443);
    }

    @Bean
    public MethodInvokingFactoryBean socketFactoryInitialization()
    {
        MethodInvokingFactoryBean methodInvokingFactoryBean = new MethodInvokingFactoryBean();
        methodInvokingFactoryBean.setTargetClass(Protocol.class);
        methodInvokingFactoryBean.setTargetMethod("registerProtocol");
        Object[] args = { "https", socketFactoryProtocol() };
        methodInvokingFactoryBean.setArguments(args);
        return methodInvokingFactoryBean;
    }

    @Bean
    public WebSSOProfileOptions sesameWebSSOProfileOptions()
    {
        SesameWebSSOProfileOptions webSSOProfileOptions = new SesameWebSSOProfileOptions();
        webSSOProfileOptions.setIncludeScoping(false);
        webSSOProfileOptions.setRelayState(getSamlRelayState());
        //
        webSSOProfileOptions.setAssertionConsumerIndex(0);
        webSSOProfileOptions.setAttributeConsumerIndex(0);
        //
        return webSSOProfileOptions;
    }

    // Entry point to initialize authentication, default values taken from
    // properties file
    @Bean
    public SAMLEntryPoint samlEntryPoint()
    {
        SAMLEntryPoint samlEntryPoint = new SAMLEntryPoint();
        samlEntryPoint.setWebSSOprofile(webSSOprofile());
        samlEntryPoint.setDefaultProfileOptions(sesameWebSSOProfileOptions());
        return samlEntryPoint;
    }

    // Setup advanced info about metadata
    @Bean
    public ExtendedMetadata extendedIDPMetadata()
    {
        ExtendedMetadata extendedMetadata = new ExtendedMetadata();
        extendedMetadata.setLocal(false);
        // deactivate IDP discovery.
        extendedMetadata.setIdpDiscoveryEnabled(false);
        // deactivate metaData signing.
        extendedMetadata.setSignMetadata(false);
        return extendedMetadata;
    }

    // Setup advanced info about metadata
    @Bean
    public ExtendedMetadata extendedSPMetadata()
    {
        ExtendedMetadata extendedMetadata = new ExtendedMetadata();
        extendedMetadata.setLocal(true);
        // deactivate IDP discovery.
        extendedMetadata.setIdpDiscoveryEnabled(false);
        // deactivate metaData signing.
        extendedMetadata.setSignMetadata(false);
        return extendedMetadata;
    }

    // IDP Discovery Service
    @Bean
    public SAMLDiscovery samlIDPDiscovery()
    {
        SAMLDiscovery idpDiscovery = new SAMLDiscovery();
        idpDiscovery.setIdpSelectionPath("/saml/idpSelection");
        return idpDiscovery;
    }

    @Bean
    @Qualifier("idp-sesame")
    public ExtendedMetadataDelegate sesameExtendedMetadataProvider() throws MetadataProviderException
    {
        Timer backgroundTaskTimer = new Timer(true);
        File metadata;
        Resource resource = resourceLoader.getResource(getSesameIdpMetadataFilePath());
        if (resource != null)
        {
            try
            {
                metadata = resource.getFile();
            }
            catch (IOException e)
            {
                LOGGER.error("Cannot read metadata file : ", e);
                throw new MetadataProviderException("Cannot read metadata file : ", e);
            }
        }
        else
        {
            LOGGER.error("Cannot find metadata file : ");
            throw new MetadataProviderException("Cannot find metadata file : " + getSesameIdpMetadataFilePath());
        }
        FilesystemMetadataProvider filesystemMetadataProvider = new FilesystemMetadataProvider(backgroundTaskTimer, metadata);
        filesystemMetadataProvider.setParserPool(parserPool());
        ExtendedMetadataDelegate extendedMetadataDelegate = new ExtendedMetadataDelegate(filesystemMetadataProvider, extendedIDPMetadata());
        extendedMetadataDelegate.setMetadataTrustCheck(false);
        extendedMetadataDelegate.setMetadataRequireSignature(false);
        return extendedMetadataDelegate;
    }

    // IDP Metadata configuration - paths to metadata of IDPs in circle of trust
    // is here
    // Do no forget to call initialize method on providers
    @Bean
    @Qualifier("metadata")
    public CachingMetadataManager metadata() throws MetadataProviderException
    {
        List<MetadataProvider> providers = new ArrayList<>();
        providers.add(sesameExtendedMetadataProvider());
        return new CachingMetadataManager(providers);
    }

    // Filter automatically generates default SP metadata
    @Bean
    public MetadataGenerator metadataGenerator()
    {
        SesameMetadataGenerator metadataGenerator = new SesameMetadataGenerator();
        metadataGenerator.setApplicationName(getServiceProviderApplicationName());
        metadataGenerator.setEntityId(getServiceProviderEntityId());
        metadataGenerator.setEntityBaseURL(getServiceProviderEntityBaseURL());
        metadataGenerator.setRequestSigned(true);
        metadataGenerator.setWantAssertionSigned(true);
        metadataGenerator.setIncludeDiscoveryExtension(false);
        metadataGenerator.setKeyManager(keyManager());
        metadataGenerator.setExtendedMetadata(extendedSPMetadata());
        return metadataGenerator;
    }

    // The filter is waiting for connections on URL suffixed with filterSuffix
    // and presents SP metadata there
    @Bean
    public MetadataDisplayFilter metadataDisplayFilter()
    {
        return new MetadataDisplayFilter();
    }

    // Handler deciding where to redirect user after successful login
    @Bean
    public SavedRequestAwareAuthenticationSuccessHandler successRedirectHandler()
    {
        SavedRequestAwareAuthenticationSuccessHandler successRedirectHandler = new SavedRequestAwareAuthenticationSuccessHandler();
        successRedirectHandler.setDefaultTargetUrl(getSamlDefaultTargetUrl());
        return successRedirectHandler;
    }

    // Handler deciding where to redirect user after failed login
    @Bean
    public SimpleUrlAuthenticationFailureHandler authenticationFailureHandler()
    {
        SimpleUrlAuthenticationFailureHandler failureHandler = new SimpleUrlAuthenticationFailureHandler();
        failureHandler.setUseForward(true);
        failureHandler.setDefaultFailureUrl(getSamlDefaultFailureUrl());
        return failureHandler;
    }

    @Bean
    public SAMLWebSSOHoKProcessingFilter samlWebSSOHoKProcessingFilter() throws Exception
    {
        SAMLWebSSOHoKProcessingFilter samlWebSSOHoKProcessingFilter = new SAMLWebSSOHoKProcessingFilter();
        samlWebSSOHoKProcessingFilter.setAuthenticationSuccessHandler(successRedirectHandler());
        samlWebSSOHoKProcessingFilter.setAuthenticationManager(authenticationManager());
        samlWebSSOHoKProcessingFilter.setAuthenticationFailureHandler(authenticationFailureHandler());
        return samlWebSSOHoKProcessingFilter;
    }

    // Processing filter for WebSSO profile messages
    @Bean
    public SAMLProcessingFilter samlWebSSOProcessingFilter() throws Exception
    {
        SAMLProcessingFilter samlWebSSOProcessingFilter = new SAMLProcessingFilter();
        samlWebSSOProcessingFilter.setAuthenticationManager(authenticationManager());
        samlWebSSOProcessingFilter.setAuthenticationSuccessHandler(successRedirectHandler());
        samlWebSSOProcessingFilter.setAuthenticationFailureHandler(authenticationFailureHandler());
        return samlWebSSOProcessingFilter;
    }

    @Bean
    public MetadataGeneratorFilter metadataGeneratorFilter()
    {
        return new MetadataGeneratorFilter(metadataGenerator());
    }

    // Handler for successful logout
    @Bean
    public SimpleUrlLogoutSuccessHandler successLogoutHandler()
    {
        SimpleUrlLogoutSuccessHandler successLogoutHandler = new SimpleUrlLogoutSuccessHandler();
        successLogoutHandler.setDefaultTargetUrl(getSamlDefaultLogoutUrl());
        return successLogoutHandler;
    }

    // Logout handler terminating local session
    @Bean
    public SecurityContextLogoutHandler logoutHandler()
    {
        SecurityContextLogoutHandler logoutHandler = new SecurityContextLogoutHandler();
        logoutHandler.setInvalidateHttpSession(true);
        logoutHandler.setClearAuthentication(true);
        return logoutHandler;
    }

    // Filter processing incoming logout messages
    // First argument determines URL user will be redirected to after successful
    // global logout
    @Bean
    public SAMLLogoutProcessingFilter samlLogoutProcessingFilter()
    {
        return new SAMLLogoutProcessingFilter(successLogoutHandler(), logoutHandler());
    }

    // Overrides default logout processing filter with the one processing SAML
    // messages
    @Bean
    public SAMLLogoutFilter samlLogoutFilter()
    {
        return new SAMLLogoutFilter(successLogoutHandler(), new LogoutHandler[] { logoutHandler() }, new LogoutHandler[] { logoutHandler() });
    }

    // Bindings
    private ArtifactResolutionProfile artifactResolutionProfile()
    {
        final ArtifactResolutionProfileImpl artifactResolutionProfile = new ArtifactResolutionProfileImpl(httpClient());
        artifactResolutionProfile.setProcessor(new SAMLProcessorImpl(soapBinding()));
        return artifactResolutionProfile;
    }

    @Bean
    public HTTPArtifactBinding artifactBinding(ParserPool parserPool, VelocityEngine velocityEngine)
    {
        return new HTTPArtifactBinding(parserPool, velocityEngine, artifactResolutionProfile());
    }

    @Bean
    public HTTPSOAP11Binding soapBinding()
    {
        return new HTTPSOAP11Binding(parserPool());
    }

    @Bean
    public HTTPPostBinding httpPostBinding()
    {
        return new HTTPPostBinding(parserPool(), velocityEngine());
    }

    @Bean
    public HTTPRedirectDeflateBinding httpRedirectDeflateBinding()
    {
        return new HTTPRedirectDeflateBinding(parserPool());
    }

    @Bean
    public HTTPSOAP11Binding httpSOAP11Binding()
    {
        return new HTTPSOAP11Binding(parserPool());
    }

    @Bean
    public HTTPPAOS11Binding httpPAOS11Binding()
    {
        return new HTTPPAOS11Binding(parserPool());
    }

    // Processor
    @Bean
    public SAMLProcessorImpl processor()
    {
        Collection<SAMLBinding> bindings = new ArrayList<>();
        bindings.add(httpRedirectDeflateBinding());
        bindings.add(httpPostBinding());
        bindings.add(artifactBinding(parserPool(), velocityEngine()));
        bindings.add(httpSOAP11Binding());
        bindings.add(httpPAOS11Binding());
        return new SAMLProcessorImpl(bindings);
    }

    /**
     * Define the security filter chain in order to support SSO Auth by using
     * SAML 2.0
     * 
     * @return Filter chain proxy
     * @throws Exception
     */
    @Bean
    public FilterChainProxy samlFilter() throws Exception
    {
        List<SecurityFilterChain> chains = new ArrayList<>();
        chains.add(new DefaultSecurityFilterChain(new AntPathRequestMatcher("/saml/login/**"), samlEntryPoint()));
        chains.add(new DefaultSecurityFilterChain(new AntPathRequestMatcher("/saml/logout/**"), samlLogoutFilter()));
        chains.add(new DefaultSecurityFilterChain(new AntPathRequestMatcher("/saml/metadata/**"), metadataDisplayFilter()));
        chains.add(new DefaultSecurityFilterChain(new AntPathRequestMatcher("/saml/SSO/**"), samlWebSSOProcessingFilter()));
        chains.add(new DefaultSecurityFilterChain(new AntPathRequestMatcher("/saml/SSOHoK/**"), samlWebSSOHoKProcessingFilter()));
        chains.add(new DefaultSecurityFilterChain(new AntPathRequestMatcher("/saml/SingleLogout/**"), samlLogoutProcessingFilter()));
        chains.add(new DefaultSecurityFilterChain(new AntPathRequestMatcher("/saml/discovery/**"), samlIDPDiscovery()));
        return new FilterChainProxy(chains);
    }

    // *********************************************************************

    /**
     * @return the frontendAuthenticationProvider
     */
    public AuthenticationProvider getFrontendAuthenticationProvider()
    {
        return frontendAuthenticationProvider;
    }

    /**
     * @param frontendAuthenticationProvider
     *            the frontendAuthenticationProvider to set
     */
    public void setFrontendAuthenticationProvider(AuthenticationProvider frontendAuthenticationProvider)
    {
        this.frontendAuthenticationProvider = frontendAuthenticationProvider;
    }

    /**
     * @return the samlUserDetailsServiceImpl
     */
    public SAMLUserDetailsServiceImpl getSamlUserDetailsServiceImpl()
    {
        return samlUserDetailsServiceImpl;
    }

    /**
     * @param samlUserDetailsServiceImpl
     *            the samlUserDetailsServiceImpl to set
     */
    public void setSamlUserDetailsServiceImpl(SAMLUserDetailsServiceImpl samlUserDetailsServiceImpl)
    {
        this.samlUserDetailsServiceImpl = samlUserDetailsServiceImpl;
    }

    /**
     * @return the useSAML
     */
    public Boolean getUseSAML()
    {
        return useSAML;
    }

    /**
     * @param useSAML
     *            the useSAML to set
     */
    public void setUseSAML(Boolean useSAML)
    {
        this.useSAML = useSAML;
    }

    /**
     * @return the sesameIdpMetadataFilePath
     */
    public String getSesameIdpMetadataFilePath()
    {
        return sesameIdpMetadataFilePath;
    }

    /**
     * @param sesameIdpMetadataFilePath
     *            the sesameIdpMetadataFilePath to set
     */
    public void setSesameIdpMetadataFilePath(String sesameIdpMetadataFilePath)
    {
        this.sesameIdpMetadataFilePath = sesameIdpMetadataFilePath;
    }

    /**
     * @return the serviceProviderEntityId
     */
    public String getServiceProviderEntityId()
    {
        return serviceProviderEntityId;
    }

    /**
     * @param serviceProviderEntityId
     *            the serviceProviderEntityId to set
     */
    public void setServiceProviderEntityId(String serviceProviderEntityId)
    {
        this.serviceProviderEntityId = serviceProviderEntityId;
    }

    /**
     * @return the serviceProviderEntityBaseURL
     */
    public String getServiceProviderEntityBaseURL()
    {
        return serviceProviderEntityBaseURL;
    }

    /**
     * @param serviceProviderEntityBaseURL
     *            the serviceProviderEntityBaseURL to set
     */
    public void setServiceProviderEntityBaseURL(String serviceProviderEntityBaseURL)
    {
        this.serviceProviderEntityBaseURL = serviceProviderEntityBaseURL;
    }

    /**
     * @return the serviceProviderApplicationName
     */
    public String getServiceProviderApplicationName()
    {
        return serviceProviderApplicationName;
    }

    /**
     * @param serviceProviderApplicationName
     *            the serviceProviderApplicationName to set
     */
    public void setServiceProviderApplicationName(String serviceProviderApplicationName)
    {
        this.serviceProviderApplicationName = serviceProviderApplicationName;
    }

    /**
     * @return the keyStorePass
     */
    public String getKeyStorePass()
    {
        return keyStorePass;
    }

    /**
     * @param keyStorePass
     *            the keyStorePass to set
     */
    public void setKeyStorePass(String keyStorePass)
    {
        this.keyStorePass = keyStorePass;
    }

    /**
     * @return the keyStoreDefaultKey
     */
    public String getKeyStoreDefaultKey()
    {
        return keyStoreDefaultKey;
    }

    /**
     * @param keyStoreDefaultKey
     *            the keyStoreDefaultKey to set
     */
    public void setKeyStoreDefaultKey(String keyStoreDefaultKey)
    {
        this.keyStoreDefaultKey = keyStoreDefaultKey;
    }

    /**
     * @return the samlRelayState
     */
    public String getSamlRelayState()
    {
        return samlRelayState;
    }

    /**
     * @param samlRelayState
     *            the samlRelayState to set
     */
    public void setSamlRelayState(String samlRelayState)
    {
        this.samlRelayState = samlRelayState;
    }

    /**
     * @return the samlDefaultTargetUrl
     */
    public String getSamlDefaultTargetUrl()
    {
        return samlDefaultTargetUrl;
    }

    /**
     * @param samlDefaultTargetUrl
     *            the samlDefaultTargetUrl to set
     */
    public void setSamlDefaultTargetUrl(String samlDefaultTargetUrl)
    {
        this.samlDefaultTargetUrl = samlDefaultTargetUrl;
    }

    /**
     * @return the samlDefaultFailureUrl
     */
    public String getSamlDefaultFailureUrl()
    {
        return samlDefaultFailureUrl;
    }

    /**
     * @param samlDefaultFailureUrl
     *            the samlDefaultFailureUrl to set
     */
    public void setSamlDefaultFailureUrl(String samlDefaultFailureUrl)
    {
        this.samlDefaultFailureUrl = samlDefaultFailureUrl;
    }

    /**
     * @return the samlDefaultLogoutUrl
     */
    public String getSamlDefaultLogoutUrl()
    {
        return samlDefaultLogoutUrl;
    }

    /**
     * @param samlDefaultLogoutUrl
     *            the samlDefaultLogoutUrl to set
     */
    public void setSamlDefaultLogoutUrl(String samlDefaultLogoutUrl)
    {
        this.samlDefaultLogoutUrl = samlDefaultLogoutUrl;
    }

}
