package com.bnpp.cardif.yourapplication.frontend.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.opensaml.saml2.metadata.AttributeConsumingService;
import org.opensaml.saml2.metadata.LocalizedString;
import org.opensaml.saml2.metadata.RequestedAttribute;
import org.opensaml.saml2.metadata.SPSSODescriptor;
import org.opensaml.saml2.metadata.ServiceName;
import org.opensaml.saml2.metadata.impl.AttributeConsumingServiceBuilder;
import org.opensaml.saml2.metadata.impl.RequestedAttributeBuilder;
import org.opensaml.saml2.metadata.impl.ServiceNameBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.saml.metadata.MetadataGenerator;

/**
 * Customize version of the
 * org.springframework.security.saml.metadata.MetadataGenerator. This version
 * adds the generation of the AttributeConsumingService elements.
 * 
 * @author 831743
 *
 */
public class SesameMetadataGenerator extends MetadataGenerator
{

    // Logger
    private static final Logger LOGGER = LoggerFactory.getLogger(SesameMetadataGenerator.class);

    private String applicationName;

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.security.saml.metadata.MetadataGenerator#
     * buildSPSSODescriptor(java.lang.String, java.lang.String, boolean,
     * boolean, java.util.Collection)
     */
    @Override
    protected SPSSODescriptor buildSPSSODescriptor(String entityBaseURL, String entityAlias, boolean requestSigned, boolean wantAssertionSigned,
            Collection<String> includedNameID)
    {
        SPSSODescriptor descriptor = super.buildSPSSODescriptor(entityBaseURL, entityAlias, requestSigned, wantAssertionSigned, includedNameID);
        List<AttributeConsumingService> attributeConsumingServiceList = descriptor.getAttributeConsumingServices();
        // normally the list should be empty there.
        if (attributeConsumingServiceList == null)
        {
            LOGGER.warn("AttributeConsumingService List is Null ");
        }
        else
        {
            if (attributeConsumingServiceList.size() > 0)
            {
                LOGGER.warn("AttributeConsumingService List is not empty, list size = " + attributeConsumingServiceList.size());
            }
            AttributeConsumingServiceBuilder builder = new AttributeConsumingServiceBuilder();
            RequestedAttributeBuilder attrBuilder = new RequestedAttributeBuilder();
            ServiceNameBuilder serviceNameBuilder = new ServiceNameBuilder();
            AttributeConsumingService service0 = buildLigthAttributeConsumingService(builder, attrBuilder, serviceNameBuilder);
            attributeConsumingServiceList.add(service0);
            AttributeConsumingService service1 = buildFullAttributeConsumingService(builder, attrBuilder, serviceNameBuilder);
            attributeConsumingServiceList.add(service1);
        }
        return descriptor;
    }

    /**
     * Create an AttributeConsumingService with all the attributes handled by
     * Sesame IdentityProvider.
     * 
     * @param builder
     *            AttributeConsumingServiceBuilder : the service builder.
     * @param attrBuilder
     *            RequestedAttributeBuilder : the attribute builder.
     * @param serviceNameBuilder
     *            ServiceNameBuilder : the serviceName builder.
     * @return AttributeConsumingService : the created service.
     */
    private AttributeConsumingService buildFullAttributeConsumingService(AttributeConsumingServiceBuilder builder, RequestedAttributeBuilder attrBuilder,
            ServiceNameBuilder serviceNameBuilder)
    {
        // build the AttributeConsumingService
        AttributeConsumingService service = builder.buildObject();
        service.setIndex(1);
        service.setIsDefault(false);
        // Add the service name
        ServiceName serviceName = serviceNameBuilder.buildObject();
        LocalizedString newName = new LocalizedString(getApplicationName() + " full profile", "en");
        serviceName.setName(newName);
        serviceName.setParent(service);
        List<ServiceName> serviceNameList = service.getNames();
        if (serviceNameList == null)
        {
            serviceNameList = new ArrayList<ServiceName>();
        }
        serviceNameList.add(serviceName);
        // Add the list of RequestedAttribute
        List<RequestedAttribute> attributeList = service.getRequestAttributes();
        if (attributeList == null)
        {
            attributeList = new ArrayList<RequestedAttribute>();
        }
        RequestedAttribute attr1 = createFullAttribute(attrBuilder, service, "urn:oid:2.16.840.1.113730.3.1.241", "displayName",
                "urn:oasis:names:tc:SAML:2.0:attrname-format:uri");
        attributeList.add(attr1);
        RequestedAttribute attr2 = createSimpleAttribute(attrBuilder, service, "urn:bnpparibas:cardif:saml:sesame:attribute:token");
        attributeList.add(attr2);
        RequestedAttribute attr3 = createSimpleAttribute(attrBuilder, service, "urn:bnpparibas:cardif:saml:sesame:attribute:user-identity");
        attributeList.add(attr3);
        RequestedAttribute attr4 = createSimpleAttribute(attrBuilder, service, "urn:bnpparibas:cardif:saml:sesame:attribute:permissions-id");
        attributeList.add(attr4);
        RequestedAttribute attr5 = createSimpleAttribute(attrBuilder, service, "urn:bnpparibas:cardif:saml:sesame:attribute:roles-id");
        attributeList.add(attr5);
        RequestedAttribute attr6 = createSimpleAttribute(attrBuilder, service, "urn:bnpparibas:cardif:saml:sesame:attribute:using-right");
        attributeList.add(attr6);
        RequestedAttribute attr7 = createSimpleAttribute(attrBuilder, service, "urn:bnpparibas:cardif:saml:sesame:attribute:joinings");
        attributeList.add(attr7);
        RequestedAttribute attr8 = createSimpleAttribute(attrBuilder, service, "urn:bnpparibas:cardif:saml:sesame:attribute:extended-attributes");
        attributeList.add(attr8);

        return service;
    }

    /**
     * Create a RequestedAttribute object with all the properties set.
     * 
     * @param attrBuilder
     *            RequestedAttributeBuilder : the attribute builder.
     * @param service
     *            AttributeConsumingService : the parent service for this
     *            attribute.
     * @param attrname
     *            String : the attribute Name.
     * @param friendlyName
     *            String : the attribute FriendlyName.
     * @param nameFormat
     *            String : the attribute NameFormat.
     * @return RequestedAttribute : the created object.
     */
    private RequestedAttribute createFullAttribute(RequestedAttributeBuilder attrBuilder, AttributeConsumingService service, String attrname,
            String friendlyName, String nameFormat)
    {
        RequestedAttribute attribute = createSimpleAttribute(attrBuilder, service, attrname);
        attribute.setNameFormat(nameFormat);
        attribute.setFriendlyName(friendlyName);
        return attribute;
    }

    /**
     * Create a RequestedAttribute object with the specified name.
     * 
     * @param attrBuilder
     *            RequestedAttributeBuilder : the attribute builder.
     * @param service
     *            AttributeConsumingService : the parent service for this
     *            attribute.
     * @param attrname
     *            String : the attribute Name.
     * @return RequestedAttribute : the created object.
     */
    private RequestedAttribute createSimpleAttribute(RequestedAttributeBuilder attrBuilder, AttributeConsumingService service, String attrname)
    {
        RequestedAttribute attribute = attrBuilder.buildObject();
        attribute.setName(attrname);
        attribute.setParent(service);
        return attribute;
    }

    /**
     * Create an AttributeConsumingService with the smallest set of attributes
     * handled by Sesame IdentityProvider.
     * 
     * @param builder
     *            AttributeConsumingServiceBuilder : the service builder.
     * @param attrBuilder
     *            RequestedAttributeBuilder : the attribute builder.
     * @param serviceNameBuilder
     *            ServiceNameBuilder : the serviceName builder.
     * @return AttributeConsumingService : the created service.
     */
    private AttributeConsumingService buildLigthAttributeConsumingService(AttributeConsumingServiceBuilder builder, RequestedAttributeBuilder attrBuilder,
            ServiceNameBuilder serviceNameBuilder)
    {
        // build the AttributeConsumingService
        AttributeConsumingService service = builder.buildObject();
        service.setIndex(0);
        service.setIsDefault(true);
        // Add the service name
        ServiceName serviceName = serviceNameBuilder.buildObject();
        LocalizedString newName = new LocalizedString(getApplicationName() + " ligth profile", "en");
        serviceName.setName(newName);
        serviceName.setParent(service);
        List<ServiceName> serviceNameList = service.getNames();
        if (serviceNameList == null)
        {
            serviceNameList = new ArrayList<ServiceName>();
        }
        serviceNameList.add(serviceName);
        // Add the list of RequestedAttribute
        List<RequestedAttribute> attributeList = service.getRequestAttributes();
        if (attributeList == null)
        {
            attributeList = new ArrayList<RequestedAttribute>();
        }
        RequestedAttribute attr1 = createFullAttribute(attrBuilder, service, "urn:oid:2.16.840.1.113730.3.1.241", "displayName",
                "urn:oasis:names:tc:SAML:2.0:attrname-format:uri");
        attributeList.add(attr1);
        RequestedAttribute attr2 = createSimpleAttribute(attrBuilder, service, "urn:bnpparibas:cardif:saml:sesame:attribute:token");
        attributeList.add(attr2);
        RequestedAttribute attr3 = createSimpleAttribute(attrBuilder, service, "urn:bnpparibas:cardif:saml:sesame:attribute:user-identity");
        attributeList.add(attr3);
        RequestedAttribute attr4 = createSimpleAttribute(attrBuilder, service, "urn:bnpparibas:cardif:saml:sesame:attribute:roles-id");
        attributeList.add(attr4);
        RequestedAttribute attr5 = createSimpleAttribute(attrBuilder, service, "urn:bnpparibas:cardif:saml:sesame:attribute:joinings");
        attributeList.add(attr5);
        RequestedAttribute attr6 = createSimpleAttribute(attrBuilder, service, "urn:bnpparibas:cardif:saml:sesame:attribute:permissions-id");
        attributeList.add(attr6);
        return service;
    }

    /**
     * @return the applicationName
     */
    public String getApplicationName()
    {
        return applicationName;
    }

    /**
     * @param applicationName
     *            the applicationName to set
     */
    public void setApplicationName(String applicationName)
    {
        this.applicationName = applicationName;
    }

}
