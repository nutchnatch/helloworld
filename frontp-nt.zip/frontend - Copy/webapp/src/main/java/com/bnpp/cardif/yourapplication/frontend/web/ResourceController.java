package com.bnpp.cardif.yourapplication.frontend.web;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bnpp.cardif.sesame.security.AuthenticatedUser;

@RestController
public class ResourceController
{
    private static final Logger LOGGER = LoggerFactory.getLogger(ResourceController.class);
    {
        LOGGER.debug("ResourceController initialize");
    }

    @RequestMapping(value = "/resource", method = RequestMethod.GET)
    public Map<String, Object> home(HttpSession session)
    {
        LOGGER.debug("resource controller");
        Map<String, Object> model = new HashMap<String, Object>();
        model.put("id", session.getId());

        model.put("content", "Hello World");
        model.put("creationTime", session.getCreationTime());
        model.put("lastAccessedTime", session.getLastAccessedTime());
        return model;
    }

    @RequestMapping(value = "/user", method = RequestMethod.GET)
    public AuthenticatedUser user()
    {
        LOGGER.debug("user controller");
        AuthenticatedUser authenticationUser = null;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null)
        {
            UsernamePasswordAuthenticationToken usernamePasswrodAuthenticationToken = (UsernamePasswordAuthenticationToken) auth;
            authenticationUser = (AuthenticatedUser) usernamePasswrodAuthenticationToken.getPrincipal();
        }
        else
        {
            LOGGER.warn("No Authentication found");
        }

        return authenticationUser;
    }

    @RequestMapping(value = "/token", method = RequestMethod.GET)
    public Map<String, String> token(HttpSession session)
    {
        return Collections.singletonMap("token", session.getId());
    }
}