package com.bnpp.cardif.yourapplication.frontend.web;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.bnpp.cardif.yourapplication.beans.RestResponse;
import com.bnpp.cardif.yourapplication.exception.TechnicalException;
import com.bnpp.cardif.yourapplication.frontend.beans.JSONSample;
import com.bnpp.cardif.yourapplication.frontend.services.SampleService;

/**
 * Unit tests for {@link SampleController}
 * 
 * @author Andre Macedo
 */
public class SampleControllerTest
{
    private static final Logger LOGGER = LoggerFactory.getLogger(SampleControllerTest.class);

    @Test
    public void testCreateSample()
    {
        try
        {
            SampleController sampleController = spy(new SampleController());

            JSONSample jsonSampleRequest = new JSONSample();
            jsonSampleRequest.setDescription(UUID.randomUUID().toString());

            SampleService sampleService = mock(SampleService.class);
            when(sampleController.getSampleService()).thenReturn(sampleService);

            RestResponse<JSONSample> restResponse = new RestResponse<>();
            JSONSample object = new JSONSample();
            object.setId(4L);
            object.setDescription(jsonSampleRequest.getDescription());
            List<JSONSample> objectList = new ArrayList<>();
            objectList.add(object);
            restResponse.setContent(objectList);
            restResponse.setContentNumber(1);
            ResponseEntity<RestResponse<JSONSample>> expectedJSONResponse = new ResponseEntity<>(restResponse, HttpStatus.OK);
            when(sampleController.createEntity(jsonSampleRequest)).thenReturn(expectedJSONResponse);

            ResponseEntity<RestResponse<JSONSample>> readlJSONResponse = sampleController.createEntity(jsonSampleRequest);

            verify(sampleService, times(1)).create(jsonSampleRequest);
            assertNotNull(readlJSONResponse);
            assertEquals(expectedJSONResponse.getBody().getContent().get(0).getId(), readlJSONResponse.getBody().getContent().get(0).getId());
            assertEquals(expectedJSONResponse.getBody().getContent().get(0).getDescription(), readlJSONResponse.getBody().getContent().get(0).getDescription());
        }
        catch (TechnicalException tex)
        {
            LOGGER.error("Error testing testCreateSample", tex);
            Assert.fail("Error testing testCreateSample : " + tex);
        }
    }

    @Test
    public void testDeleteSample()
    {
        try
        {
            SampleController sampleController = spy(new SampleController());
            long id = 7;

            SampleService sampleService = mock(SampleService.class);
            when(sampleController.getSampleService()).thenReturn(sampleService);

            doNothing().when(sampleService).delete(id);

            sampleController.deleteEntity(id);

            verify(sampleService).delete(id);
        }
        catch (TechnicalException tex)
        {
            LOGGER.error("Error testing testDeleteSample", tex);
            Assert.fail("Error testing testDeleteSample : " + tex);
        }
    }

    @Test
    public void testListSample()
    {
        try
        {
            SampleController sampleController = spy(new SampleController());
            List<JSONSample> objectList = new ArrayList<>();
            objectList.add(createJSONSample(null));
            objectList.add(createJSONSample(null));
            RestResponse<JSONSample> restResponse = new RestResponse<>();
            restResponse.setContent(objectList);
            restResponse.setContentNumber(2);
            ResponseEntity<RestResponse<JSONSample>> expectedJSONResponse = new ResponseEntity<>(restResponse, HttpStatus.OK);

            SampleService sampleService = mock(SampleService.class);
            when(sampleController.getSampleService()).thenReturn(sampleService);
            when(sampleService.findAll()).thenReturn(objectList);

            ResponseEntity<RestResponse<JSONSample>> realJSONResponse = sampleController.listEntity();

            assertEquals(expectedJSONResponse, realJSONResponse);
        }
        catch (TechnicalException tex)
        {
            LOGGER.error("Error testing testListSample", tex);
            Assert.fail("Error testing testListSample : " + tex);
        }
    }

    @Test
    public void testReadSample()
    {
        try
        {
            SampleController sampleController = spy(new SampleController());
            long id = new Random().nextLong();

            SampleService sampleService = mock(SampleService.class);
            when(sampleController.getSampleService()).thenReturn(sampleService);

            JSONSample expectedJSONSample = createJSONSample(Long.parseLong(id + ""));
            when(sampleService.findOne(id)).thenReturn(expectedJSONSample);

            RestResponse<JSONSample> restResponse = new RestResponse<>();
            List<JSONSample> objectList = new ArrayList<>();
            objectList.add(expectedJSONSample);
            restResponse.setContent(objectList);
            restResponse.setContentNumber(1);
            ResponseEntity<RestResponse<JSONSample>> expectedJSONResponse = new ResponseEntity<>(restResponse, HttpStatus.OK);

            ResponseEntity<RestResponse<JSONSample>> realJSONResponse = sampleController.readEntity(id);

            assertEquals(expectedJSONResponse, realJSONResponse);
        }
        catch (TechnicalException tex)
        {
            LOGGER.error("Error testing testReadSample", tex);
            Assert.fail("Error testing testReadSample : " + tex);
        }
    }

    @Test
    public void testReadSampleList()
    {
        try
        {
            SampleController sampleController = spy(new SampleController());

            SampleService sampleService = mock(SampleService.class);
            when(sampleController.getSampleService()).thenReturn(sampleService);

            List<JSONSample> expectedJSONList = new ArrayList<>();
            expectedJSONList.add(createJSONSample(null));
            expectedJSONList.add(createJSONSample(null));
            RestResponse<JSONSample> restResponse = new RestResponse<>();
            restResponse.setContent(expectedJSONList);
            restResponse.setContentNumber(2);
            ResponseEntity<RestResponse<JSONSample>> expectedJSONResponse = new ResponseEntity<>(restResponse, HttpStatus.OK);

            when(sampleService.findAll(anyListOf(Long.class))).thenReturn(expectedJSONList);

            ResponseEntity<RestResponse<JSONSample>> realJSONResponse = sampleController.readEntityList(new ArrayList<Long>());

            assertEquals(expectedJSONResponse, realJSONResponse);
        }
        catch (TechnicalException tex)
        {
            LOGGER.error("Error testing testReadSample", tex);
            Assert.fail("Error testing testReadSample : " + tex);
        }
    }

    @Test
    public void testUpdateSample()
    {
        try
        {
            SampleController sampleController = spy(new SampleController());

            JSONSample expectedJSONSample = createJSONSample(null);
            SampleService sampleService = mock(SampleService.class);
            when(sampleController.getSampleService()).thenReturn(sampleService);
            when(sampleService.update(expectedJSONSample)).thenReturn(expectedJSONSample);

            RestResponse<JSONSample> restResponse = new RestResponse<>();
            List<JSONSample> objectList = new ArrayList<>();
            objectList.add(expectedJSONSample);
            restResponse.setContent(objectList);
            restResponse.setContentNumber(1);
            ResponseEntity<RestResponse<JSONSample>> expectedJSONResponse = new ResponseEntity<>(restResponse, HttpStatus.OK);

            ResponseEntity<RestResponse<JSONSample>> readlJSONResponse = sampleController.updateEntity(expectedJSONSample);

            verify(sampleService, times(1)).update(expectedJSONSample);
            assertNotNull(readlJSONResponse);
            assertEquals(expectedJSONResponse, readlJSONResponse);
        }
        catch (TechnicalException tex)
        {
            LOGGER.error("Error testing testUpdateSample", tex);
            Assert.fail("Error testing testUpdateSample : " + tex);
        }
    }

    @Test
    public void testUpdateSampleList()
    {
        try
        {
            SampleController sampleController = spy(new SampleController());
            SampleService sampleService = mock(SampleService.class);
            when(sampleController.getSampleService()).thenReturn(sampleService);

            List<JSONSample> expectedJSONList = new ArrayList<>();
            expectedJSONList.add(createJSONSample(null));
            expectedJSONList.add(createJSONSample(null));
            RestResponse<JSONSample> restResponse = new RestResponse<>();
            restResponse.setContent(expectedJSONList);
            restResponse.setContentNumber(2);
            ResponseEntity<RestResponse<JSONSample>> expectedJSONResponse = new ResponseEntity<>(restResponse, HttpStatus.OK);

            when(sampleService.update(expectedJSONList)).thenReturn(expectedJSONList);

            ResponseEntity<RestResponse<JSONSample>> readlJSONResponse = sampleController.updateEntityList(expectedJSONList);

            assertEquals(expectedJSONResponse, readlJSONResponse);
        }
        catch (TechnicalException tex)
        {
            LOGGER.error("Error testing testUpdateSampleList", tex);
            Assert.fail("Error testing testUpdateSampleList : " + tex);
        }
    }

    private static JSONSample createJSONSample(Long id)
    {
        JSONSample jsonSample = new JSONSample();

        jsonSample.setId(id != null ? id : new Random().nextLong());
        jsonSample.setDescription(UUID.randomUUID().toString());

        return jsonSample;
    }
}
