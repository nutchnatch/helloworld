/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   GeneralServerLifeCycleController
 * Author:      Jogender
 * Substitute	Babu B
 * Created on	13-10-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.ADVISORY_CONFIGURE
 *        : TNMS.DX2.SM.PASSWORD.COMPLEXITY
 * 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 05-May-2005  Babu B           CF001312   Master-Master Replication for Sun ONE DS
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.general;

import com.ossnms.bicnet.securitymanagement.api.server.general.IGSWrapper;
import com.ossnms.bicnet.securitymanagement.common.utils.InternalUSMBeanLocator;
import com.ossnms.bicnet.securitymanagement.server.basic.USMServerLifeCycleControllerIfc;
import org.apache.log4j.Logger;

/**
*
* This is the single point of initialization for the General Setting
* subsystem on the server side. 
*/
public final class GeneralServerLifeCycleController
    implements USMServerLifeCycleControllerIfc {
    /**
    * Data member for the Logging of the class.
    */
    private static final Logger LOGGER =
        Logger.getLogger(GeneralServerLifeCycleController.class);

    /**
    * Data member to hold the singleton instance of the Server LifeCycle
    * Controller
    */
    private static GeneralServerLifeCycleController instance =
        new GeneralServerLifeCycleController();

    /**
    * Constructor
    */
    private GeneralServerLifeCycleController() {

    }

    /**
    * Method called so that GS subsystem can do the initialization. This is
    * called at the time of startup of the server
    *
    * @return boolean Indicates whether it was possible to initialize
    *         successfully or not.
    */
    @Override
    public boolean initialize() {
        LOGGER.debug("initialize()	Enter");
        
        IGSWrapper gsWrapper = InternalUSMBeanLocator.getEJB(IGSWrapper.class);

        //Initialize the GS subsystem
        gsWrapper.init();

//        new GSLdapInterface();

//        LWNotifHandler ldapNotifHandler = new GSLdapNotifHandler();
//
//        // Register for LDAP notifications
//		LWInterface.registerSSForNotif(GenericLdapNames.ATTRIB_GENERAL_SETTINGS_OU, ldapNotifHandler);

        LOGGER.debug("initialize()	Exit");
        return true;
    }

    /**
    * Method called so that GS subsystem can do the cleanup. This is called at
    * the time of shutdown of the server
    *
    * @return boolean Indicates whether it was possible to cleanup
    *         successfully or not. Always returns true.
    */
    @Override
    public boolean cleanup() {
        LOGGER.debug("cleanup()	Enter");
        if (instance != null) {
            instance = null;
        }
        LOGGER.debug("cleanup()	Exit");
        return true;
    }

    /**
    * Function to provide the singleton instance of the class.
    *
    * @return GeneralServerLifeCycleController The singleton
    *         instance of the class.
    */
    public static GeneralServerLifeCycleController getInstance() {
        LOGGER.debug("getInstance()	Enter");
        return instance;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.securitymanagement.server.basic.USMServerLifeCycleControllerIfc#reinitialize()
     */
    @Override
    public boolean reinitialize() {
        LOGGER.debug("reinitialize()	Enter");
        LOGGER.debug("reinitialize()	Exit");
        return true;
    }

}