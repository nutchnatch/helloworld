/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMBaseController
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.basic;

/**
 * Helper class to calculate the time that has elapsed since the time the
 * task was started. This is needed for the Performance checks.
 * The following are the check points that can be used - 
 * 1. Creation of the Job
 * 2. Adding the Job into the Queue
 * 3. Start of Execute
 * 4. End of Execute
 * 5. Start of GUI update
 * 6. Finishing of GUI update
 * 
 * The time differences are calculated as follows - 
 * a. Client sending a request (2 - 1)
 * b. Total wait time of Job before starting of execution (3 - 2)
 * c. Total time spent at server (4 - 3)
 * d. Time taken for GUI updates (6 - 5)
 * e. Total time taken for operation (6 - 1) 
 */
public class USMTimeTracer {
	/**
	 * Data member to hold the conversion ratio between milliseconds to seconds.
	 * Problems with seeing the data in seconds. Set it to milli seconds. 
	private static final long CONV_RATIO_MILLI_TO_SECS = 1000;
	 */

	/**
	 * Data member to hold the time in Millisecond for the creation time.
	 */
	private long creationTime = currentTimeSeconds();

	/**
	 * Data member to hold the time in Millisecond when the Job was added to Queue
	 */
	private long addToQueueTime = 0;

	/**
	 * Data member to hold the time in Millisecond when the execute of the Job was called.
	 */
	private long startExecuteTime = 0;

	/**
	 * Data member to hold the time in Millisecond when the execution of the Job was completed.
	 */
	private long finishExecuteTime = 0;

	/**
	 * Data member to hold the time in Millisecond when the GUI updates commenced.
	 */
	private long startGUIUpdateTime = 0;

	/**
	 * Data member to hold the time in Millisecond when the GUI updates are completed. 
	 */
	private long finishGUIUpdateTime = 0;

	/**
	 * Constructor
	 * @param p_Job The Job which is being profiled.
	 */
	public USMTimeTracer() {
	}

	/**
	 * Function to be called some task has finished
	 *
	 */
	public void registerFinish() {
		finishGUIUpdateTime = currentTimeSeconds();
	}

	/**
	 * Function to register that the Job has been added to the Queue.
	 */
	public void registerJobAddedToQueue() {
		addToQueueTime = currentTimeSeconds();
	}

	/**
	 * Function to register that the Job has been added to the Queue.
	 */
	public void registerExecuteJobStarted() {
		startExecuteTime = currentTimeSeconds();
	}

	/**
	 * Function to register that the Job has been added to the Queue.
	 */
	public void registerExecuteJobComplete() {
		finishExecuteTime = currentTimeSeconds();
	}

	/**
	 * Function to register that the Job has been added to the Queue.
	 */
	public void registerGUIUpdateStarted() {
		startGUIUpdateTime = currentTimeSeconds();
	}

	/**
	 * Function to register that the Job has been added to the Queue.
	 */
	public void registerGUIUpdateCompleted() {
		finishGUIUpdateTime = currentTimeSeconds();
	}

	/**
	 * Helper function to return the Time taken by the Client for creation of the Job and 
	 * placing of the Job into the Queue. 
	 * @return long Time taken by the Client for creation of the Job and 
	 * placing of the Job into the Queue. 
	 */
	public long getTimeForStartOfJob() {
		return addToQueueTime - creationTime;
	}

	/**
	 * Helper function to return the Time taken between placing of Job in Pool and calling of
	 * the run method on the Job. 
	 * @return long Time taken between placing of Job in Pool and calling of
	 * the run method on the Job. 
	 */
	public long getTimeForWaitingInPool() {
		return startExecuteTime - addToQueueTime;
	}

	/**
	 * Helper function to return the Time taken for the Server to complete the
	 * operation. 
	 * @return long Time taken for the Server to complete the
	 * operation. 
	 */
	public long getTimeForServerProcessing() {
		return finishExecuteTime - startExecuteTime;
	}

	/**
	 * Helper function to return the Time taken for the Swing to update the GUI update 
	 * call. 
	 * @return long Time taken for the Swing to update the GUI update 
	 * call. 
	 */
	public long getTimeForWaitingForSwingUpdate() {
		return startGUIUpdateTime - finishExecuteTime;
	}

	/**
	 * Helper function to return the Time taken for the GUI Update.
	 * @return long Time taken for the GUI Update.
	 */
	public long getTimeForGUIUpdate() {
		return finishGUIUpdateTime - startGUIUpdateTime;
	}

	/**
	 * Helper function to return the Time taken for the Complete Job. 
	 * @return long Time taken for the Complete Job. 
	 */
	public long getTimeForCompleteJob() {
		return finishGUIUpdateTime - creationTime;
	}

	/**
	 * Helper function to get the current time in Seconds.
	 * @return long The current time in seconds.
	 */
	private static long currentTimeSeconds() {
		//		return System.currentTimeMillis() / CONV_RATIO_MILLI_TO_SECS;
		return System.currentTimeMillis();
	}

}
