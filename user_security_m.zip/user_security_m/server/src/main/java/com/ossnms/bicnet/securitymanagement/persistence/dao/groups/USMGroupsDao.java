package com.ossnms.bicnet.securitymanagement.persistence.dao.groups;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.groups.IUSMGroupsDao;
import com.ossnms.bicnet.securitymanagement.persistence.dao.AbstractBaseDao;
import com.ossnms.bicnet.securitymanagement.persistence.model.groups.USMGroups;

/**
 * created on 28/8/2014
 */
@Stateless(name="IUSMGroupsDao")
@Local
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class USMGroupsDao extends AbstractBaseDao<USMGroups, String> implements IUSMGroupsDao{

	@Override
	public List<String> findGroupsOfUser(String userName) {
		
		List<String> groups = new ArrayList<String>();
		
		//gets all the existing groups from database
		List<USMGroups> allGroups = findAll();
		
		for(USMGroups group: allGroups) {
			String users = group.getMembersOfGroup();
			
			if(users.contains(userName)) {
				groups.add(group.getName());
			}
		}
		
		return groups;
	}
}
