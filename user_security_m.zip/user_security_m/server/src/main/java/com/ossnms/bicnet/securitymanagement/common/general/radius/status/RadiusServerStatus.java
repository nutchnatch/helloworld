package com.ossnms.bicnet.securitymanagement.common.general.radius.status;

/**
 *
 */
public enum RadiusServerStatus {

    AVAILABLE,
    REJECTED,
    CONNECTION_FAILED

}
