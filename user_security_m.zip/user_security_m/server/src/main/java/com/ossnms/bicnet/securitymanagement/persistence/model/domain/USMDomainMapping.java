package com.ossnms.bicnet.securitymanagement.persistence.model.domain;

import com.ossnms.bicnet.securitymanagement.persistence.model.BaseUSMEntity;

import javax.persistence.*;


/**
 * created on 28/8/2014
 */
@Entity
@Table(name = "USM_DOMAIN_MAPPING")
@NamedQueries({
        @NamedQuery(name="usmDomainMapping.findByName", query = "from USMDomainMapping m where m.name = :mappingName"),
        @NamedQuery(name="usmDomainMapping.findByDomain", query = "from USMDomainMapping m where m.domainId = :domainId"),
        @NamedQuery(name="usmDomainMapping.findByPolicy", query = "from USMDomainMapping m where m.policyId = :policyId"),
        @NamedQuery(name="usmDomainMapping.findByUserGroup", query = "from USMDomainMapping m where m.userGroup = :userGroup")
})
public class USMDomainMapping extends BaseUSMEntity {

    public static final String QUERY_FIND_BY_NAME = "usmDomainMapping.findByName";
    public static final String PARAM_1_FIND_BY_NAME = "mappingName";

    public static final String QUERY_FIND_BY_POLICY = "usmDomainMapping.findByPolicy";
    public static final String PARAM_1_FIND_BY_POLICY = "policyId";

    public static final String QUERY_FIND_BY_USER_GROUP = "usmDomainMapping.findByUserGroup";
    public static final String PARAM_1_FIND_BY_USER_GROUP = "userGroup";

    public static final String QUERY_FIND_BY_DOMAIN = "usmDomainMapping.findByDomain";
    public static final String PARAM_1_FIND_BY_DOMAIN = "domainId";

    private static final long serialVersionUID = 1490453306307261585L;

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO, generator="USMDomainMappingSequence")
    @SequenceGenerator(name="USMDomainMappingSequence", sequenceName="USM_SEQ_DOMAIN_MAPPING")
    @Column(name = "CONT")
    private Integer id;

    @Column(name = "NAME", unique = true, nullable = false)
    private String name;

    @Column(name = "DOMAIN_ID")
    private int domainId;

    @Column(name = "POLICY_ID")
    private int policyId;

    @Column(name = "USER_GROUP")
    private String userGroup;

    public USMDomainMapping() {
        super();
    }

    @Override
    public boolean isNew() {
        return id == null || id == 0;
    }

    /**
     *
     * @param name name of the domain
     * @param domainId id of the domain
     * @param policyId policy id
     * @param userGroup user group name
     */
    public USMDomainMapping(String name, int domainId, int policyId, String userGroup) {
        super();
        this.name = name;
        this.domainId = domainId;
        this.policyId = policyId;
        this.userGroup = userGroup;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDomainId() {
        return domainId;
    }

    public void setDomainId(int domainId) {
        this.domainId = domainId;
    }

    public int getPolicyId() {
        return policyId;
    }

    public void setPolicyId(int policyId) {
        this.policyId = policyId;
    }

    public String getUserGroup() {
        return userGroup;
    }

    public void setUserGroup(String userGroupId) {
        this.userGroup = userGroupId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }

        USMDomainMapping that = (USMDomainMapping) o;

        if (domainId != that.domainId){
            return false;
        }
        if (policyId != that.policyId){
            return false;
        }
        if (id != null ? !id.equals(that.id) : that.id != null){
            return false;
        }
        if (name != null ? !name.equals(that.name) : that.name != null){
            return false;
        }

        return !(userGroup != null ? !userGroup.equals(that.userGroup) : that.userGroup != null);

    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + domainId;
        result = 31 * result + policyId;
        result = 31 * result + (userGroup != null ? userGroup.hashCode() : 0);
        return result;
    }
}
