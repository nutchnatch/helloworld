/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCDomainMappingController
 * Author      	Muyeen Munaver
 * Substitute	Asifullakhan
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.MAPPING.CREATE
 * 		:	TNMS.DX2.SM.MAPPING.VIEW    
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 10-Feb-2005	Asif 			CF000834 - Command Log Entries
 * 11-Mar-2005	Asif			CF000845 - System Event Log Entries
 * 22-Mar-2005	Muyeen Munaver	CF0001791 - Problems with Login
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessageType;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import com.ossnms.bicnet.securitymanagement.server.basic.notification.USMNotifier;
import com.ossnms.bicnet.securitymanagement.server.bicnetserver.BSServerHelper;
import com.ossnms.bicnet.securitymanagement.server.logging.LMInterFace;
import com.ossnms.bicnet.securitymanagement.server.logging.LMLogRecordData;
import com.ossnms.bicnet.securitymanagement.server.logging.LMLogRecordEnum;
import org.apache.log4j.Logger;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Controller for handling features pertaining to showing, creating and modifying
 * the domain mappings.
 */
class DCDomainMappingController {

	/**
	 * Data member for the Logging of the class.
	 */
    private static final Logger LOGGER = Logger.getLogger(DCDomainMappingController.class);

	/**
	 * Constructor
	 */
	public DCDomainMappingController() {
	}

	/**
	 * Function to get the domain mapping for a user group, including mappings concerning not assigned policies (no mapping)
	 * 
	 * @param userGroup The user group for which the mappings are requested
	 */
	List<DCDomainMapping> getMappingsForUserGroup(String userGroup) {

		LOGGER.debug("getMappingsForUserGroup() - Enter");

        List<DCDomainMapping> mappings = new ArrayList<DCDomainMapping>();
        DCServerDataManager.getInstance().getDomainMappings(userGroup, mappings);
        
		//Now we have the list of mappings for the group selected,

		List<DCDomainData> domains = new ArrayList<DCDomainData>();
		DCServerDataManager.getInstance().getAllConfiguredDomains(domains);

		//This vector would store the list of mappings that were unassigned
		//for this selected user group. The policy id which goes in would be -1
		List<DCDomainMapping> unAssignedUserMapping = new ArrayList<DCDomainMapping>();
		
		//Now for each domain got from the OS
		//check if it is already part of some mapping
		//If it is not part of some mapping, then mark it as having policy id -1 which
		//is NONE. The client now will display the mappings for this domain
		for (DCDomainData dom : domains) {
			DCDomainMapping noneMapping =
					new DCDomainMapping(
						dom.getDomainID(),
						userGroup,
						-1);
			boolean bMappExists = false;
			for (DCDomainMapping map : mappings) {
				if (map.equals(noneMapping)) {
					bMappExists = true;
					break;
				}
			}
			//If mapping existed for this domain, then do nothing
			//If mapping didnot exist for this domain, we have to
			//add -1 as policy to the mapping
			if (!bMappExists) {
				unAssignedUserMapping.add(noneMapping);
			}
		}
		
		mappings.addAll(unAssignedUserMapping);

		LOGGER.debug("getMappingsForUserGroup() - Exit");

		return mappings;
	}
	
	
	/**
	 * Function to handle the request for changing the domain mapping. 
	 *
	 * @param mappings  The mappings that need to be created or changed
	 */
	USMMessage changeMappings(ISessionContext ctx, List mappings) {

		LOGGER.debug("changeMappings() - Entry");

        // This is to check if the policy id passed is valid, it could so happen that the policy which is selected by
        // the user might have been deleted
		List policyIdPair = DCExternalInterface.getPolicies();
		//Create a map of policy id, so that searching is easier
		Set mapPolicyIds = new HashSet();
        for(int nDx = 0; nDx < policyIdPair.size(); ++nDx) {
            PAPolicyId pol = (PAPolicyId) policyIdPair.get(nDx);
            mapPolicyIds.add(Integer.valueOf(pol.getPolicyID()));
        }

		//This is to check if the User group passed is valid, it could so
		//happen that the user group which is selceted by the user might have
		//been deleted
		String[] userGrps = DCExternalInterface.getGlobalUserGroups();
		//Create a map of policy id, so that searching is easier
		Set mapGrps = new HashSet();
		for (int nDx = 0; nDx < userGrps.length; ++nDx) {
			mapGrps.add(userGrps[nDx]);
		}

		int nMapp = mappings.size();
		List mappingsToBeModified = new ArrayList();
		List mappingsInvalid = new ArrayList();
		List mappingsToDelete = new ArrayList();
		for (int nDx = 0; nDx < nMapp; ++nDx) {
			boolean bValid = false;
			DCDomainMapping domMap = (DCDomainMapping) mappings.get(nDx);
			//Check if mapping has to be created/modified
			if (-1 != domMap.getPolicyID()) {
				//Check if the domain id is invalid
                if(null == DCServerDataManager.getInstance().getDomainData(domMap.getDomainID())) {
                    domMap.setErrorId(DCMessages.DC_ERROR_DOMAIN_INVALID);
                    LOGGER.error("changeMappings() - Domain with id not valid " + domMap.getDomainID());
				} //Check if the selected policy is invalid 
                else if(!mapPolicyIds.contains(Integer.valueOf(domMap.getPolicyID()))) {
                    domMap.setErrorId(DCMessages.DC_ERROR_POLICY_INVALID);
                    LOGGER.error("changeMappings() - Policy with id not valid " + domMap.getPolicyID());
				} //Check if the user group is not valid 
				else if (!mapGrps.contains(domMap.getUserGroup())) {
                    domMap.setErrorId(DCMessages.DC_ERROR_GROUP_INVALID);
                    LOGGER.error("changeMappings() - User group not valid " + domMap.getUserGroup());
				} //All three are valid, and you can go ahead with the creation
				else {
					bValid = true;
				}
				if (bValid) {
					//This mapping has passed the first test, and can go ahead for change
					mappingsToBeModified.add(domMap);
				} else {
					//This is an invalid mapping
					mappingsInvalid.add(domMap);
				}
			} else {
				mappingsToDelete.add(domMap);
			}
		}

        LOGGER.debug("changeMappings() - Exit");
        return changeMappingsAndSendNotif(ctx, mappingsToBeModified, mappingsToDelete, mappingsInvalid);
	}

	/**
	 * Modifies the list of mappings as passed in the parameter list by asking the
	 * DCServerDataManager to suitably create/modify or delete a mapping. Once
	 * this is done, it sends back the response message
	 *
	 * @param mappingsToBeModified  Contains the mappings which are to be modified.
	 * @param mappingsToDelete  Contains mappings which are to be deleted. Since
	 * the policy id to be assigned is -1, it means that it has to be deleted.
	 * @param mappingsInvalid  This contains invalid mappings.
	 * @return  returns the message which contains the response to the mappings modified
	 */
    USMMessage changeMappingsAndSendNotif(ISessionContext ctx, List mappingsToBeModified, List mappingsToDelete, List mappingsInvalid) {

		LOGGER.debug("sendMappingsResponse() - Entry");
		if (LOGGER.isInfoEnabled()) {
            String traceStr = "Mappings to be modified " + mappingsToBeModified.size() + " Mappings to be deleted " + mappingsToDelete.size() + " Mappings invalid " + mappingsInvalid.size();
			LOGGER.info(traceStr);
		} //The second parameter tells for which all mappings there was a success
		List successfullModifiedMappings = new ArrayList();
        List erroredMapppings = new ArrayList();
        DCServerDataManager.getInstance().modifyMappings(mappingsToBeModified, successfullModifiedMappings, erroredMapppings);
		List successfullDeletedMappings = new ArrayList();
		List erroredDeletedMapppings = new ArrayList();
        DCServerDataManager.getInstance().deleteMappings(mappingsToDelete, successfullDeletedMappings, erroredDeletedMapppings);
		//Fill in the Message that has to be sent
        USMMessage message = new USMMessage(DCMessageType.DC_RES_ASSIGN_MAPPING, USMMessage.USMMESSAGE_RESPONSE);
		//all mappings were successfully modified/deleted
		//Send a no error response back to the user
        if(successfullModifiedMappings.size() == mappingsToBeModified.size() && successfullDeletedMappings.size() == mappingsToDelete.size() && 0 == mappingsInvalid.size()) {
            message.pushInteger(DCMessages.DC_NO_ERROR);
		} else {
			//Mapping could not be created, as it could be an LDAP error, or user is trying to modify global
			//mapping.User trying to modify global mapping should already be checked on client side
			List errMapps = erroredMapppings;
			errMapps.addAll(erroredDeletedMapppings);
			errMapps.addAll(mappingsInvalid);
			//The mappings were invalid, as the group or policy or domain is invalid
			DCDomainMapping.pushMappingsToMessage(errMapps, message);
			message.pushInteger(DCMessages.DC_NOT_ALL_MAPPINGS_ASSIGNED);
		} // Fault 3 - Send Mapping Change Notificaiton
        sendNotificationOfChangedMappings(ctx, successfullModifiedMappings, successfullDeletedMappings);
		LOGGER.debug("sendMappingsResponse() - Exit");
		return message;
	}

	/**
	 * This function sends a notification about the number and the contents of the
	 * mappings which are modified and deleted.
	 *
	 * @param successfullModifiedMappings  This contains the vector of successfully
	 * modified mappings.
	 * @param successfullDeletedMappings  Contains the list of successfully deleted
	 * mappings.
	 */
    void sendNotificationOfChangedMappings(ISessionContext ctx, List successfullModifiedMappings, List successfullDeletedMappings) {

		LOGGER.debug("sendNotificationOfChangedMappings() - Entry");
		//Send a notification only if atleast one mapping got changed
        if(0 != (successfullModifiedMappings.size() + successfullDeletedMappings.size())) {
			//Fetch the list of domain data as the name and domain id is mapped from here
			//The mappings contains only the domain id
			List allDomains = new ArrayList();
			DCServerDataManager.getInstance().getAllConfiguredDomains(allDomains);
			//Create a map of domain id, so that searching is easier
			//I am creating a map of domain id and domain data even though
			//i could have retrieved the same from DCServerDataCacheMangager by calling
			//getDomainData as this method is synchrnonized in the DCServerDataManager
			Map mapDomainIds = new HashMap();
			for (int nDx = 0; nDx < allDomains.size(); ++nDx) {
				DCDomainData dom = (DCDomainData) allDomains.get(nDx);
				mapDomainIds.put(Integer.valueOf(dom.getDomainID()), dom);
			} //Fetch all policies and send in the policies which are of interest to the caller
			List allPolicies = DCExternalInterface.getPolicies();
			//Create a map of policy id, so that searching is easier
			Map mapPolicyIds = new HashMap();
			for (int nDx = 0; nDx < allPolicies.size(); ++nDx) {
				PAPolicyId pol =
					(PAPolicyId) allPolicies.get(nDx);
				mapPolicyIds.put(Integer.valueOf(pol.getPolicyID()), pol);
			} //Now is the part of sending the filtered list of domain data and the policy
			//data that is of interest to the caller
			List policyNameIds = new ArrayList();
			List domDataToBePushed = new ArrayList();
            for(int nDx = 0; nDx < successfullModifiedMappings.size(); ++nDx) {
                DCDomainMapping mapping = (DCDomainMapping) successfullModifiedMappings.get(nDx);
				int policyId = mapping.getPolicyID();

				Object obj = mapPolicyIds.get(Integer.valueOf(policyId));
				//The policy should be found, if not found, log it as an error
				if (null != obj) {
					PAPolicyId polData = (PAPolicyId) obj;
					policyNameIds.add(polData);
				} else {
					LOGGER.error(
						"There exists a mapping where  the policy with id not found "
							+ policyId);
				}

				int domainId = mapping.getDomainID();
				obj = mapDomainIds.get(Integer.valueOf(domainId));
				//The domain should be found, if not found, log it as an error
				if (null != obj) {
					DCDomainData domData = (DCDomainData) obj;
					domDataToBePushed.add(domData);
                } else {
                    LOGGER.error("There exists a mapping, where the domain id is invalid " + domainId);
				}
			} //Finally send notification saying that mappings have been created/modified
            USMMessage notifMsg = new USMMessage(DCMessageType.DC_NOT_MAPPINGS_MODIFIED, USMMessage.USMMESSAGE_NOTIFICATION);
			for (int nDx = 0; nDx < policyNameIds.size(); ++nDx) {
				PAPolicyId pol =
					(PAPolicyId) policyNameIds.get(nDx);
				pol.pushMe(notifMsg);
			}
			notifMsg.pushInteger(Integer.valueOf(policyNameIds.size()));
			DCDomainData.pushDomainsToMessage(domDataToBePushed, notifMsg);
            for(int nDx = 0; nDx < successfullModifiedMappings.size(); ++nDx) {
                DCDomainMapping map = (DCDomainMapping) successfullModifiedMappings.get(nDx);
                map.pushMe(notifMsg);

                String participatingDomain = ((DCDomainData) mapDomainIds.get(Integer.valueOf(map.getDomainID()))).getDomainName();
                String participatingPolicy = mapPolicyIds.get(Integer.valueOf(map.getPolicyID())).toString();

                String displayStr = MessageFormat.format(USMCommonStrings.IDS_DC_MAPPING_CHANGED, new Object[] { map.getUserGroup(), participatingDomain, participatingPolicy, ctx.getUserName(),
                        ((IEnhancedSessionContext) ctx).getClientMachineName() });

                LMLogRecordData usmLogRecord = new LMLogRecordData(LMLogRecordEnum.MAPPING_CHANGED, map.getUserGroup() + "<->" + participatingDomain + "<->" + participatingPolicy,
                        LMLogRecordData._SUCCESS, null, LogSeverity.MESSAGE.guiLabel(), null, displayStr);
                LMInterFace.getInstance().createSecurityLogRecord(ctx, usmLogRecord);
            }
            for(int nDx = 0; nDx < successfullDeletedMappings.size(); ++nDx) {
                DCDomainMapping map = (DCDomainMapping) successfullDeletedMappings.get(nDx);
                map.pushMe(notifMsg);

                String participatingDomain = ((DCDomainData) mapDomainIds.get(Integer.valueOf(map.getDomainID()))).getDomainName();
                String displayStr = MessageFormat.format(USMCommonStrings.IDS_DC_MAPPING_DELETION,
                        new Object[] { map.getUserGroup(), participatingDomain, ctx.getUserName(), ((IEnhancedSessionContext) ctx).getClientMachineName() });

                LMLogRecordData usmLogRecord = new LMLogRecordData(LMLogRecordEnum.MAPPING_CHANGED, map.getUserGroup() + "<->" + participatingDomain + "<->NONE", LMLogRecordData._SUCCESS, null,
                        LogSeverity.MESSAGE.guiLabel(), null, displayStr);
                LMInterFace.getInstance().createSecurityLogRecord(ctx, usmLogRecord);
            }
            notifMsg.pushInteger(Integer.valueOf(successfullModifiedMappings.size() + successfullDeletedMappings.size()));
            USMNotifier.getInstance().sendNotification(notifMsg);

			// notify mapping modified
			String userGroupAffected;
			if (successfullModifiedMappings.size() > 0){
				userGroupAffected = ((DCDomainMapping)successfullModifiedMappings.get(0)).getUserGroup();
			}else {
				userGroupAffected = ((DCDomainMapping)successfullDeletedMappings.get(0)).getUserGroup();
			}
			// send notification
			BSServerHelper.notifyMappingModified(Collections.emptyList(), userGroupAffected);

        }

		LOGGER.debug("sendNotificationOfChangedMappings() - Exit");
	}
}