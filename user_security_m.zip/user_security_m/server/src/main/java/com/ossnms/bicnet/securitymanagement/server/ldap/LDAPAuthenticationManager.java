package com.ossnms.bicnet.securitymanagement.server.ldap;

import com.ossnms.bicnet.securitymanagement.common.auth.LDAPSearchScope;
import com.ossnms.bicnet.securitymanagement.common.general.ldap.LDAPConfigurationData;
import com.ossnms.bicnet.securitymanagement.server.ldap.api.ILDAPAuthenticationManager;
import com.ossnms.bicnet.securitymanagement.server.ldap.dto.LDAPGroup;
import com.ossnms.bicnet.securitymanagement.server.ldap.dto.LDAPUser;
import com.ossnms.bicnet.securitymanagement.server.ldap.dto.LDAPUserContext;
import com.ossnms.bicnet.securitymanagement.server.ldap.mapper.UserAttributesMapper;
import com.ossnms.bicnet.securitymanagement.server.ldap.mapper.UserGroupAttributesMapper;
import com.ossnms.bicnet.securitymanagement.server.useradministration.UASubsystemSAP;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ldap.query.SearchScope;

import java.util.List;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;

/**
 *
 */
public final class LDAPAuthenticationManager extends LDAPManager implements ILDAPAuthenticationManager {

    private static final Logger LOGGER = LoggerFactory.getLogger(LDAPAuthenticationManager.class);

    private static final int COUNT_LIMIT = 1000;

    private String
            userSearchBase,
            userSearchFilter,
            userIdAttribute,
            groupSearchBase,
            groupSearchFilter,
            groupIdAttribute,
            groupMemberAttribute;

    private SearchScope
            userSearchScope,
            groupSearchScope;

    private boolean
            isUserParametersSet,
            isGroupParametersSet;

    public LDAPAuthenticationManager(LDAPConfigurationData ldap){
        this(ldap.getHost(), ldap.getPortAsInt(), ldap.isSslIndicator(), ldap.getSearchAccount(), ldap.getSearchPassword());

        userSearchBase = ldap.getUserSearchBase();
        userSearchFilter = ldap.getUserSearchFilter();
        userSearchScope = fromLDAPSearchScope(ldap.getUserSearchScope());
        userIdAttribute = ldap.getUserIdAttribute();
        // signal that all user parameters have been set
        isUserParametersSet = true;

        groupSearchBase = ldap.getGroupSearchBase();
        groupSearchFilter = ldap.getGroupSearchFilter();
        groupSearchScope = fromLDAPSearchScope(ldap.getGroupSearchScope());
        groupIdAttribute = ldap.getGroupIdAttribute();
        groupMemberAttribute = ldap.getGroupMemberAttribute();
        // signal that all user parameters have been set
        isGroupParametersSet = true;
    }

    /**
     * {@inheritDoc}
     */
    public LDAPAuthenticationManager(String url, int port, boolean sslIndicator, String userDn, String password) {
        super(url, port, sslIndicator, userDn, password);
    }

    /**
     * {@inheritDoc}
     */
    public ILDAPAuthenticationManager setUserSearchParameters(String searchBase, String searchFilter, LDAPSearchScope searchScope, String idAttribute) {
        if(isNullOrEmpty(searchBase) || isNullOrEmpty(searchFilter) || searchScope == null || isNullOrEmpty(idAttribute)){
            return this;
        }

        userSearchBase = searchBase;
        userSearchFilter = searchFilter;
        userSearchScope = fromLDAPSearchScope(searchScope);
        userIdAttribute = idAttribute;
        // signal that all user parameters have been set
        isUserParametersSet = true;

        return this;
    }

    /**
     * {@inheritDoc}
     */
    public ILDAPAuthenticationManager setGroupSearchParameters(String searchBase, String searchFilter, LDAPSearchScope searchScope, String idAttribute, String memberAttribute) {
        if(isNullOrEmpty(searchBase) || isNullOrEmpty(searchFilter) || searchScope == null || isNullOrEmpty(idAttribute) || isNullOrEmpty(memberAttribute)){
            return this;
        }

        groupSearchBase = searchBase;
        groupSearchFilter = searchFilter;
        groupSearchScope = fromLDAPSearchScope(searchScope);
        groupIdAttribute = idAttribute;
        groupMemberAttribute = memberAttribute;
        // signal that all user parameters have been set
        isGroupParametersSet = true;

        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getUserCount() {
        // search users with the given parameters
        return this.search(
                COUNT_LIMIT,
                userSearchBase,
                userSearchFilter,
                userSearchScope,
                new UserAttributesMapper(userIdAttribute)
        ).size();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getUserGroupCount() {

        List<LDAPGroup> groups = this.search(
                COUNT_LIMIT,
                groupSearchBase,
                groupSearchFilter,
                groupSearchScope,
                new UserGroupAttributesMapper(groupIdAttribute)
        ).stream()
                .filter(UASubsystemSAP.ldapGroupBySupportedGroups())
                .collect(Collectors.toList());

        // search user groups with the given parameters
        return groups.size();
    }


    /**
     * {@inheritDoc}
     */
    public LDAPUser authenticate(String username, String password) {
        LOGGER.debug("LDAP Authentication request for {}", username);

        if(!isGroupParametersSet){
            // group parameters are not valid
            LOGGER.warn("LDAP Authentication Group Search Configuration must be set");
            return null;
        }

        if(!isUserParametersSet){
            // user parameters are not valid
            LOGGER.warn("LDAP Authentication User Search Configuration must be set");
            return null;
        }

        if(isNullOrEmpty(username) || isNullOrEmpty(password)){
            // authentication parameters are not valid
            LOGGER.warn("LDAP Authentication, username or password must be set");
            return null;
        }

        // authenticate this user against LDAP
        LDAPUserContext context = this.authenticate(
                userSearchBase,
                userSearchFilter,
                userIdAttribute,
                false,
                username,
                userSearchScope,
                password
        );

        LOGGER.debug("LDAP Authentication successful, absolute DN  - {}", context.getAbsoluteDN());

        // search users with the given parameters
        List<LDAPUser> users = this.search(
                1,
                userSearchBase,
                userSearchFilter,
                userIdAttribute,
                false,
                username,
                userSearchScope,
                new UserAttributesMapper(userIdAttribute)
        );

        users.forEach(user -> LOGGER.debug(" - Found information for user {}", user.getUserID()));

        // search groups with the given parameters
        List<LDAPGroup> groups = this.search(
                5,
                groupSearchBase,
                groupSearchFilter,
                groupMemberAttribute,
                false,
                context.getAbsoluteDN(),
                groupSearchScope,
                new UserGroupAttributesMapper(groupIdAttribute)
        );

        // debug message to print found users
        groups.forEach(group -> LOGGER.debug("  - Found user group {}", group));
        //
        List<LDAPGroup> tnmsGroups = groups
                .stream()
                .filter(UASubsystemSAP.ldapGroupBySupportedGroups())
                .collect(toList());

        if(tnmsGroups.size() == 0){
            // user parameters are not valid
            LOGGER.warn("User {} has no associated TNMS UserClass or member identifying attribute is incorrect.", username);
            return null;
        }

        LDAPUser user = users.get(0);
        user.setUserGroups(tnmsGroups);
        return user;
    }

    /**
     * Checks if the string is null or empty
     * @param str the string to test
     * @return true if is null or empty; false otherwise
     */
    private boolean isNullOrEmpty(String str){
        return str == null || str.isEmpty();
    }

    /**
     * Parses the {@link LDAPSearchScope} to a {@link SearchScope}

     * @param searchScope the {@link LDAPSearchScope} to parse
     * @return the parsed value or the value ONELEVEL, if null was sent
     */
    private SearchScope fromLDAPSearchScope(LDAPSearchScope searchScope){
        return searchScope == null ? SearchScope.ONELEVEL : SearchScope.valueOf(searchScope.name());
    }
}
