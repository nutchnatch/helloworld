package com.ossnms.bicnet.securitymanagement.api.server.groups;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAIEUserGroup;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserGroup;

import java.util.List;

/**
 * created on 15/9/2014
 */
public interface  IUAGroupWrapper{

    void init();

    /**
     * This method creates a new user group
     * @param usrGrp - this contains the user group attributes
     * @param users - list of users that are the members of this group
     * @return the operation result
     */
    boolean createUserGroup(UAUserGroup usrGrp, List<String> users);

    /**
     * This method deletes a user group
     * @param usrGroupName - user group to be deleted
     * @return the operation result
     */
    boolean deleteUserGroup(String usrGroupName);
    
    /**
     * This method modifies a user group
     * @param usrGrp - user group to be modified
     * @param users - users associated with this group
     * @return the operation result
     */
    boolean modifyUserGroup(UAUserGroup usrGrp, List<String> users);
    
    /**
     * Returns a List with all the existing User Groups
     * @return list of existing user groups
     */
    List<UAIEUserGroup> retrieveAllUserGroups();

    /**
     * Returns the user group information identified with the specified group name
     * @param userGroupName the name of the user group
     * @return an instance of UAIEUserGroup if the group exists, null otherwise
     */
    UAIEUserGroup retrieveUserGroup(String userGroupName);
    
    /**
     * Retrieves user groups from Active Direction for accountName. All user groups are retrieved recursively.
     * @param accountName
     * @return user groups from Active Direction for accountName
     */
    List<String> getTnmsUserGroupsFromActiveDirectory(String accountName) throws BcbSecurityException;
    
    /**
     * It retrieves user group list to which user has been assigned
     *
     * @param userName - User name
     * @return List<String> - List of the user group
     */
    List<String> getUserGroups(String userName);
}
