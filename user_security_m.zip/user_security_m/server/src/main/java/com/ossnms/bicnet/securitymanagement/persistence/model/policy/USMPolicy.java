package com.ossnms.bicnet.securitymanagement.persistence.model.policy;

import com.ossnms.bicnet.securitymanagement.persistence.model.BaseUSMEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import java.util.List;

/**
 * Policy is a set of Permissions as defined for TNMS
 */
@Entity
@Table(name = "USM_POLICY",
 	uniqueConstraints = { @UniqueConstraint(columnNames = {  "NAME" }) }
)

@NamedQueries({
		@NamedQuery(name = "usmPolicy.findByName", query = "from USMPolicy d where d.name = :name"),
})
public class USMPolicy extends BaseUSMEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "USMPolicySequence")
	@SequenceGenerator(name = "USMPolicySequence", sequenceName = "USM_SEQ_POLICY")
	@Column(name = "ID")
	private Integer id;

	@Column(name = "NAME", nullable = false)
	private String name;

	@Column(name = "DESCRIPTION")
	private String description;

	@Column(name = "CREATION_STAMP")
	private Integer creationStamp;
	
	@Column(name = "MODIFICATION_STAMP")
	private Integer modificationStamp;

	/**
	 * Defaults to <code>FetchType.LAZY</code>
	 * Requires a call to Hibernate.initialize(...)
	 */
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(
			name = "USM_POLICY_PERMISSION",
			joinColumns = @JoinColumn(name="POLICY_ID", referencedColumnName="ID"),
			inverseJoinColumns = @JoinColumn(name="PERMISSION_ID", referencedColumnName="ID")
	)
	private List<USMPermission> permissions;

	public USMPolicy() {
		super();
	}

	
	public USMPolicy(String name, String description, Integer creationStamp, Integer modificationStamp) {
		super();
		this.name = name;
		this.description = description;
		this.creationStamp = creationStamp;
		this.modificationStamp = modificationStamp;
	}


	@Override
	public boolean isNew() {
		return id == null || id == 0;
	}

	/**
	 *
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 *
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 *
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}


	/**
	 *
	 */
	public Integer getCreationStamp() {
		return creationStamp;
	}

	/**
	 * @param creationStamp
	 */
	public void setCreationStamp(Integer creationStamp) {
		this.creationStamp = creationStamp;
	}

	/**
	 *
	 */
	public Integer getModificationStamp() {
		return modificationStamp;
	}

	/**
	 * @param modificationStamp
	 */
	public void setModificationStamp(Integer modificationStamp) {
		this.modificationStamp = modificationStamp;
	}

	/**
	 *
	 */
	public List<USMPermission> getPermissions() {
		return permissions;
	}

	/**
	 * @param permissions
	 */
	public void setPermissions(List<USMPermission> permissions) {
		this.permissions = permissions;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj){
            return true;
        }
		if (obj == null){
            return false;
        }
		if (getClass() != obj.getClass()){
            return false;
        }
		USMPolicy other = (USMPolicy) obj;
		if (name == null) {
			if (other.name != null){
                return false;
            }
		} else if (!name.equals(other.name)){
            return false;
        }

		return true;
	}
	
}
