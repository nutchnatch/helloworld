package com.ossnms.bicnet.securitymanagement.persistence.dao.general;


import com.ossnms.bicnet.securitymanagement.api.persistence.dao.general.IUSMGeneralSettingsDao;
import com.ossnms.bicnet.securitymanagement.api.server.general.GSProperty;
import com.ossnms.bicnet.securitymanagement.persistence.dao.AbstractBaseDao;
import com.ossnms.bicnet.securitymanagement.persistence.model.general.USMGeneral;
import org.apache.log4j.Logger;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.Query;
import java.util.List;

/**
 * created on 15/9/2014
 */
@Stateless(name="IUSMGeneralSettingsDao")
@Local
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class USMGeneralSettingsDao extends AbstractBaseDao<USMGeneral, String> implements IUSMGeneralSettingsDao {
	
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger logger = Logger.getLogger(USMGeneralSettingsDao.class);

    /**
     * Finds a list of general settings by subdomain
     *
     * @param subDomain the name of the subdomain to be looked up
     * @return a list with all the settings for such subdomain
     */
    @Override
    public List<USMGeneral> findBySubDomain(String subDomain) {
        Query query = getEntityManager()
                .createNamedQuery(USMGeneral.QUERY_FIND_BY_SUBDOMAIN)
                .setParameter(USMGeneral.PARAM_1_FIND_BY_SUBDOMAIN, subDomain);

        return query.getResultList();
    }

    /**
     * Accepts a list of general settings to persist
     *
     * @param settings the list of <code>USMGeneral</code>
     * @return the list of persisted items.
     */
    @Override
    public List<USMGeneral> saveAll(List<USMGeneral> settings) {
        for(USMGeneral setting : settings){
            save(setting);
        }

        return settings;
    }

    /**
     * Retrieves the value of the property identified by the name
     * send as attribute.
     *
     * @param property the name of the property.
     * @return the value of the property
     */
	@Override
	public String getPropertyValue(String property) {
		USMGeneral setting = findById(property);
        String propertyValue = null;

        if(setting == null) {
            logger.debug("General Setting Property doesn't exist in database: ");
        }else{
            propertyValue = setting.getValue();
        }

		
		return propertyValue;
	}

    @Override
    public String getPropertyValue(GSProperty property) {
        return getPropertyValue(property.name());
    }
}
