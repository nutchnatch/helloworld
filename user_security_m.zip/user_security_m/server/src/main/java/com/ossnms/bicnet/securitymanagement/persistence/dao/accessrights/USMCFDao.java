package com.ossnms.bicnet.securitymanagement.persistence.dao.accessrights;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.accessrights.IUSMCFDao;
import com.ossnms.bicnet.securitymanagement.persistence.dao.AbstractBaseDao;
import com.ossnms.bicnet.securitymanagement.persistence.model.accessrights.USMCF;
import org.hibernate.Hibernate;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

/**
 * created on 24/9/2014
 */
@Stateless(name="IUSMCFDao")
@Local
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class USMCFDao
        extends AbstractBaseDao<USMCF, String>
        implements IUSMCFDao {

    @Override
    public void loadSecurableElements(USMCF cf) {
        USMCF temp = findById(cf.getCfId());

        //Call Hibernate.initialize to initialize the ACL lazy collection
        Hibernate.initialize(temp.getSecurableElements());

        //set ACL in the element
        cf.setSecurableElements(temp.getSecurableElements());
    }

    @Override
    public void loadSecurableElementContainers(USMCF cf) {
        USMCF temp = findById(cf.getCfId());

        //Call Hibernate.initialize to initialize the ACL lazy collection
        Hibernate.initialize(temp.getSecurableElementContainers());

        //set ACL in the element
        cf.setSecurableElementContainers(temp.getSecurableElementContainers());
    }
}
