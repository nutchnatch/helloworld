package com.ossnms.bicnet.securitymanagement.persistence.dao.domain;


import com.ossnms.bicnet.securitymanagement.api.persistence.dao.domain.IUSMDomainMappingDao;
import com.ossnms.bicnet.securitymanagement.persistence.dao.AbstractBaseDao;
import com.ossnms.bicnet.securitymanagement.persistence.model.domain.USMDomainMapping;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.Query;
import java.util.List;

/**
 * created on 28/8/2014
 *
 * Data access object for the Entity USMDomainMapping
 *
 */
@Stateless(name = "IUSMDomainMappingDao")
@Local
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class USMDomainMappingDao extends AbstractBaseDao<USMDomainMapping, Integer> implements IUSMDomainMappingDao{

    @Override
    public USMDomainMapping findByName(String name) {
        Query query = getEntityManager()
                .createNamedQuery(USMDomainMapping.QUERY_FIND_BY_NAME)
                .setParameter(USMDomainMapping.PARAM_1_FIND_BY_NAME, name);

        return getSingleResult(query);
    }

    @Override
    public List<USMDomainMapping> findByDomain(int domainId) {
        Query query = getEntityManager()
                .createNamedQuery(USMDomainMapping.QUERY_FIND_BY_DOMAIN)
                .setParameter(USMDomainMapping.PARAM_1_FIND_BY_DOMAIN, domainId);

        return query.getResultList();
    }

    @Override
    public List<USMDomainMapping> findByPolicy(int policyId) {
        Query query = getEntityManager()
                .createNamedQuery(USMDomainMapping.QUERY_FIND_BY_POLICY)
                .setParameter(USMDomainMapping.PARAM_1_FIND_BY_POLICY, policyId);

        return query.getResultList();
    }

    @Override
    public List<USMDomainMapping> findByUserGroup(String userGroup) {
        Query query = getEntityManager()
                .createNamedQuery(USMDomainMapping.QUERY_FIND_BY_USER_GROUP)
                .setParameter(USMDomainMapping.PARAM_1_FIND_BY_USER_GROUP, userGroup);

        return query.getResultList();
    }

}
