package com.ossnms.bicnet.securitymanagement.api.persistence.dao.general;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.IBaseDAO;
import com.ossnms.bicnet.securitymanagement.api.server.general.GSProperty;
import com.ossnms.bicnet.securitymanagement.persistence.model.general.USMGeneral;

import java.util.List;

/**
 * created on 15/9/2014
 */
public interface IUSMGeneralSettingsDao extends IBaseDAO<USMGeneral,String> {
    List<USMGeneral> findBySubDomain(String subDomain);
    List<USMGeneral> saveAll(List<USMGeneral> settings);
    String getPropertyValue(String property);
    String getPropertyValue(GSProperty property);
}
