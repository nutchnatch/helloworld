package com.ossnms.bicnet.securitymanagement.common.general.radius.configuration;

import com.ossnms.bicnet.securitymanagement.common.auth.RadiusUserGroupAttribute;

import java.io.Serializable;
import java.util.Objects;

/**
 * This class is to be used as a DTO, containing configuration regarding LDAP Authentication
 */
public class RadiusConfigurationData implements Serializable {

    private static final long serialVersionUID = 1505444693544943771L;

    private boolean isEnabled;

    private int timeout;
    private int retries;
    private RadiusUserGroupAttribute userGroupAttribute;

    private String serverHostname;
    private int serverPort;
    private String serverSharedSecret;

    private String altServerHostname;
    private int altServerPort;
    private String altServerSharedSecret;

    public boolean isEnabled() {
        return isEnabled;
    }

    public void setEnabled(boolean enabled) {
        isEnabled = enabled;
    }

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public int getRetries() {
        return retries;
    }

    public void setRetries(int retries) {
        this.retries = retries;
    }

    public RadiusUserGroupAttribute getUserGroupAttribute() {
        return userGroupAttribute;
    }

    public void setUserGroupAttribute(RadiusUserGroupAttribute userGroupAttribute) {
        this.userGroupAttribute = userGroupAttribute;
    }

    public String getServerHostname() {
        return serverHostname;
    }

    public void setServerHostname(String serverHostname) {
        this.serverHostname = serverHostname;
    }

    public int getServerPort() {
        return serverPort;
    }

    public void setServerPort(int serverPort) {
        this.serverPort = serverPort;
    }

    public String getServerSharedSecret() {
        return serverSharedSecret;
    }

    public void setServerSharedSecret(String serverSharedSecret) {
        this.serverSharedSecret = serverSharedSecret;
    }

    public String getAltServerHostname() {
        return altServerHostname;
    }

    public void setAltServerHostname(String altServerHostname) {
        this.altServerHostname = altServerHostname;
    }

    public int getAltServerPort() {
        return altServerPort;
    }

    public void setAltServerPort(int altServerPort) {
        this.altServerPort = altServerPort;
    }

    public String getAltServerSharedSecret() {
        return altServerSharedSecret;
    }

    public void setAltServerSharedSecret(String altServerSharedSecret) {
        this.altServerSharedSecret = altServerSharedSecret;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RadiusConfigurationData that = (RadiusConfigurationData) o;
        return isEnabled() == that.isEnabled() &&
                getTimeout() == that.getTimeout() &&
                getRetries() == that.getRetries() &&
                getServerPort() == that.getServerPort() &&
                getAltServerPort() == that.getAltServerPort() &&
                getUserGroupAttribute() == that.getUserGroupAttribute() &&
                Objects.equals(getServerHostname(), that.getServerHostname()) &&
                Objects.equals(getServerSharedSecret(), that.getServerSharedSecret()) &&
                Objects.equals(getAltServerHostname(), that.getAltServerHostname()) &&
                Objects.equals(getAltServerSharedSecret(), that.getAltServerSharedSecret());
    }

    @Override
    public int hashCode() {
        return Objects.hash(isEnabled(), getTimeout(), getRetries(), getUserGroupAttribute(), getServerHostname(), getServerPort(), getServerSharedSecret(), getAltServerHostname(), getAltServerPort(), getAltServerSharedSecret());
    }
}
