/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 19-Jan-2005	Muyeen Munaver	CF000297 - Sync Step 1a)
 * 05-Mar-2005  Muyeen Munaver  CF001936    Change Password throws exception, but password has been changed
 * 05-May-2005  Muyeen Munaver  CF001312   Master-Master Replication for Sun ONE DS
 * 11-Jan-2006  Balasubramanya  CF002773 - Missing correct computer name in window User Administration
 * 31-Jan-2007  Shrinidhi G V   CF004362-  9320_MR_0775: Any user can bring down the application.
 * 26-Aug-2005  Babu B          CF002773 - Missing correct computer name in window User Administration
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.componentinterface;

import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmReply;
import com.ossnms.bicnet.bcb.facade.security.*;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.*;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmMaskConfiguration;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmId;
import com.ossnms.bicnet.bcb.model.scs.ScsComponentState;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncMode;
import com.ossnms.bicnet.bcb.model.security.*;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityMgrFacadeLocal;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityMgrFacadeRemote;

import javax.ejb.*;
import javax.security.auth.kerberos.KerberosTicket;
import java.util.Properties;

/**
 * Bean implementation for the Public Facade
 */
@Stateless(name = "USMSecurityProviderSLSBFacade")
@Local(ISecurityMgrFacadeLocal.class)
@Remote(ISecurityMgrFacadeRemote.class)
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class USMSecurityProviderSLSBFacadeBean implements ISecurityMgrFacadeLocal, ISecurityMgrFacadeRemote {

    private USMSecurityProviderPOJOImpl pojo = new USMSecurityProviderPOJOImpl();

    @Override
    public String getName(ISessionContext sessionContext) throws BcbException {
        return pojo.getName(sessionContext);
    }

    @Override
    public String getDescription(ISessionContext sessionContext)
            throws BcbException {
        return pojo.getDescription(sessionContext);
    }

    @Override
    public BiCNetComponentType getComponentType(ISessionContext sessionContext)
            throws BcbException {
        return pojo.getComponentType(sessionContext);
    }

    @Override
    public Log4jLevel getLog4JDefaultLevel(ISessionContext sessionContext)
            throws BcbException {
        return pojo.getLog4JDefaultLevel(sessionContext);
    }

    @Override
    public ComponentVersionInformation getVersion(ISessionContext sessionContext)
            throws BcbException {
        return pojo.getVersion(sessionContext);
    }

    @Override
    public void start(ISessionContext sessionContext) throws BcbException {
        pojo.start(sessionContext);
    }

    @Override
    public void init(ISessionContext sessionContext) throws BcbException {
        pojo.init(sessionContext);
    }

    @Override
    public void shutDown(ISessionContext sessionContext) throws BcbException {
        pojo.shutDown(sessionContext);
    }

    @Override
    public void stop(ISessionContext sessionContext) throws BcbException {
        pojo.stop(sessionContext);
    }

    @Override
    public ScsComponentState getState(ISessionContext sessionContext)
            throws BcbException {
        return pojo.getState(sessionContext);
    }

    @Override
    public boolean isStartSupported(ISessionContext sessionContext)
            throws BcbException {
        return pojo.isStartSupported(sessionContext);
    }

    @Override
    public boolean isStopSupported(ISessionContext sessionContext)
            throws BcbException {
        return pojo.isStopSupported(sessionContext);
    }

    @Override
    public boolean isSyncSupported(ISessionContext sessionContext)
            throws BcbException {
        return pojo.isSyncSupported(sessionContext);
    }

    @Override
    public String[] getOperations() {
        return pojo.getOperations();
    }

    @Override
    public ISecurableObject[] getSecurableObjects() {
        return pojo.getSecurableObjects();
    }

    @Override
    public ISecureServerSession getServerSession(ISessionContext sessionContext)
            throws BcbSecurityException {
        return pojo.getServerSession(sessionContext);
    }

    @Override
    public void changePassword(
            String userId,
            String currentPassword,
            String newPassword)
            throws BcbSecurityException {
        pojo.changePassword(userId, currentPassword, newPassword);
    }

    @Override
    public ISessionContext logon(String userId, String password, String clientComputerName)
            throws BcbSecurityException {
        return pojo.logon(userId, password, clientComputerName);
    }
    
    @Override
    public ISessionContext authenticate(String userId, String password, String clientComputerName)
            throws BcbSecurityException {
        return pojo.authenticate(userId, password, clientComputerName);
    }

    @Override
    public ISessionContext nbiLogon(String userId, String password,
                                    String computerName) throws BcbSecurityException {
        return pojo.nbiLogon(userId, password, computerName);
    }

    @Override
    public boolean isLoggedOn(String userId) {
        return pojo.isLoggedOn(userId);
    }

    @Override
    public void addLogonListener(ILogonListener listener) {
        pojo.addLogonListener(listener);
    }

    @Override
    public void removeLogonListener(ILogonListener listener) {
        pojo.removeLogonListener(listener);
    }

    @Override
    public void registerObject(BiCNetComponentType componentType, ISecurableObject securableObject) {
        pojo.registerObject(componentType, securableObject);
    }

    @Override
    public boolean unregisterObject(BiCNetComponentType componentType, ISecurableObject securableObject) {
        return pojo.unregisterObject(componentType, securableObject);
    }

    @Override
    public ISessionContext getSystemAccountContext()
            throws UnsupportedOperationException {
        throw new UnsupportedOperationException();
    }

    @Override
    public void doSync(ISessionContext sessionContext, IBiCNetComponentId[] with, ScsSyncMode syncMode, SyncCategory syncCategory)
            throws BcbException {
        pojo.doSync(sessionContext, with, syncMode, syncCategory);
    }

    @Override
    public void doForcedSync(ISessionContext sessionContext, IBiCNetComponentId[] with, ScsSyncMode syncMode, SyncCategory syncCategory)
            throws BcbException {
        pojo.doForcedSync(sessionContext, with, syncMode, syncCategory);
    }

    @Override
    public void updateObject(BiCNetComponentType componentType, ISecurableObject securableObject) {
        pojo.updateObject(componentType, securableObject);
    }

    @Override
    public void logoff(ISessionContext sessionContext)
            throws BcbSecurityException {
        pojo.logoff(sessionContext);
    }

    @Override
    public void logoff(ISecureServerSession serverSession)
            throws BcbSecurityException {
        pojo.logoff(serverSession);
    }

    @Override
    public AlarmReply getAlarmList(
            ISessionContext sessionContext,
            IAlarmId startAfter,
            IManagedObjectId[] filter,
            int howMany)
            throws BcbException {
        return pojo.getAlarmList(sessionContext, startAfter, filter, howMany);
    }

    @Override
    public void enableAlarms(ISessionContext iSessionContext, IManagedObjectId[] iManagedObjectIds, AlarmMaskConfiguration alarmMaskConfiguration, TrafficDirection trafficDirection, boolean b) throws BcbException {
        pojo.enableAlarms(iSessionContext, iManagedObjectIds, alarmMaskConfiguration, trafficDirection, b);
    }

    @Override
    public void doFullSync(ISessionContext sessionContext)
            throws BcbException {
        pojo.doFullSync(sessionContext);
    }

    @Override
    public Properties getLdapCredentials() throws BcbSecurityException {
        return pojo.getLdapCredentials();
    }

    @Override
    public boolean isTraceDataCollectionSupported(ISessionContext arg0) throws BcbException {
        return false;
    }

    @Override
    public void collectTraceData(ISessionContext arg0, File arg1) throws BcbException {
    }

    @Override
    public ISessionContext logon(KerberosTicket kTicket, byte[] userName, byte[] host, byte[] clientIpAddress, byte[] encoded, Handle userSessionBean) throws BcbSecurityException {
        return pojo.logon(kTicket, userName, host, clientIpAddress, encoded, userSessionBean);
    }

    @Override
    public void updateObjectContainer(BiCNetComponentType componentType, ISecurableObjectContainer securableContainer) {
        pojo.updateObjectContainer(componentType, securableContainer);
    }

    @Override
    public void disableAlarms(ISessionContext arg0, IManagedObjectId[] arg1, AlarmMaskConfiguration arg2, TrafficDirection direction) throws BcbException {
    }
    
    @Override
    public byte[] getUserPasswordSalt(String userName) throws BcbSecurityException {
    	return pojo.getUserPasswordSalt(userName);
    }


    /**
     * *****************************************************************************************
     * Node Manager Integration (INMSecurityFacade)
     * *****************************************************************************************
     */

    /**
     * {@inheritDoc}
     *
     * <br><br><strong>NOTE: Arguments startAfter, filter and howMany will be ignored.</strong>
     */
    @Override
    public NMSecurityMappingsReply getNMSecurityMappingsList(ISessionContext sessionContext, INMSecurityMappingsId startAfter, INMSecurityMappingsMarkable[] filter, int howMany) throws BcbException {
        return pojo.getNMSecurityMappingsList(sessionContext, startAfter, filter, howMany);
    }

    /**
     * {@inheritDoc}
     *
     * <br><br><strong>NOTE: Arguments startAfter, filter and howMany will be ignored.</strong>
     */
    @Override
    public NMSecurityMappingsReply getNMSecurityMappingsList(ISessionContext iSessionContext, INMSecurityMappingsId inmSecurityMappingsId, INMSecurityMappingsMarkable[] inmSecurityMappingsMarkables, int i, ISecurityUserGroupId iSecurityUserGroupId) throws BcbException {
        return pojo.getNMSecurityMappingsList(iSessionContext, inmSecurityMappingsId, inmSecurityMappingsMarkables, i, iSecurityUserGroupId);
    }

    @Override
    public NMSecurityMappingsReply getNMSecurityMappingsList(ISessionContext sessionContext, INMSecurityMappingsId startAfter, INMSecurityMappingsMarkable[] filter, int howMany, ISecurityUserId securityUser) throws BcbException {
        return pojo.getNMSecurityMappingsList(sessionContext, startAfter, filter, howMany, securityUser);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ISecurableObject getSingleSecurableObject(ISessionContext sessionContext, ISecurableObjectId securableObjectId) throws BcbException {
        return pojo.getSingleSecurableObject(sessionContext, securableObjectId);
    }

    /**
     * {@inheritDoc}
     *
     * <br><br><strong>NOTE: Arguments startAfter, filter and howMany will be ignored.</strong>
     */
    @Override
    public SecurableObjectReply getSecurableObjectList(ISessionContext sessionContext, ISecurableObjectId startAfter, ISecurableObjectMarkable[] filter, int howMany) throws BcbException {
        return pojo.getSecurableObjectList(sessionContext, startAfter, filter, howMany);
    }

    /**
     * {@inheritDoc}
     *
     * <br><br><strong>NOTE: Arguments startAfter, filter and howMany will be ignored.</strong>
     */
    @Override
    public SecurableObjectReply getSecurableObjectList(ISessionContext sessionContext, ISecurableObjectId startAfter, ISecurableObjectMarkable[] filter, int howMany, ISecurityDomainId securityDomain) throws BcbException {
        return pojo.getSecurableObjectList(sessionContext, startAfter, filter, howMany, securityDomain);
    }

    /**
     * {@inheritDoc}
     *
     * <br><br><strong>NOTE: Arguments startAfter, filter and howMany will be ignored.</strong>
     */
    @Override
    public SecurableObjectIdReply getSecurableObjectIdList(ISessionContext sessionContext, ISecurableObjectId startAfter, ISecurableObjectMarkable[] filter, int howMany) throws BcbException {
        return pojo.getSecurableObjectIdList(sessionContext, startAfter, filter, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ISecurityDomain getSingleSecurityDomain(ISessionContext sessionContext, ISecurityDomainId securityDomainId) throws BcbException {
        return pojo.getSingleSecurityDomain(sessionContext, securityDomainId);
    }

    /**
     * {@inheritDoc}
     *
     * <br><br><strong>NOTE: Arguments startAfter, filter and howMany will be ignored.</strong>
     */
    @Override
    public SecurityDomainReply getSecurityDomainList(ISessionContext sessionContext, ISecurityDomainId startAfter, ISecurityDomainMarkable[] filter, int howMany) throws BcbException {
        return pojo.getSecurityDomainList(sessionContext, startAfter, filter, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ISecurityUserGroup getSingleSecurityUserGroup(ISessionContext sessionContext, ISecurityUserGroupId securityUserGroupId) throws BcbException {
        return pojo.getSingleSecurityUserGroup(sessionContext, securityUserGroupId);
    }

    /**
     * {@inheritDoc}
     *
     * <br><br><strong>NOTE: Arguments startAfter, filter and howMany will be ignored.</strong>
     */
    @Override
    public SecurityUserGroupReply getSecurityUserGroupList(ISessionContext sessionContext, ISecurityUserGroupId startAfter, ISecurityUserGroupMarkable[] filter, int howMany) throws BcbException {
        return pojo.getSecurityUserGroupList(sessionContext, startAfter, filter, howMany);
    }

    /**
     * {@inheritDoc}
     *
     * <br><br><strong>NOTE: Arguments startAfter, filter and howMany will be ignored.</strong>
     */
    @Override
    public SecurityUserGroupIdReply getSecurityUserGroupIdList(ISessionContext sessionContext, ISecurityUserGroupId startAfter, ISecurityUserGroupMarkable[] filter, int howMany) throws BcbException {
        return pojo.getSecurityUserGroupIdList(sessionContext, startAfter, filter, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ISecurityUser getSingleSecurityUser(ISessionContext sessionContext, ISecurityUserId securityUserId) throws BcbException {
        return pojo.getSingleSecurityUser(sessionContext, securityUserId);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SecurityUserReply getSecurityUserList(ISessionContext sessionContext, ISecurityUserId startAfter, ISecurityUserMarkable[] filter, int howMany) throws BcbException {
        return pojo.getSecurityUserList(sessionContext, startAfter, filter, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SecurityUserIdReply getSecurityUserIdList(ISessionContext sessionContext, ISecurityUserId startAfter, ISecurityUserMarkable[] filter, int howMany) throws BcbException {
        return pojo.getSecurityUserIdList(sessionContext, startAfter, filter, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SecurityUserGroupAssignmentReply getSecurityUserGroupAssignmentList(ISessionContext sessionContext, ISecurityUserGroupAssignmentId startAfter, ISecurityUserGroupAssignmentMarkable[] filter, int howMany) throws BcbException {
        return pojo.getSecurityUserGroupAssignmentList(sessionContext, startAfter, filter, howMany);
    }
}
