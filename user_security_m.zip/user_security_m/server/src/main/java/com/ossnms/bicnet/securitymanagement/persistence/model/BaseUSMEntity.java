package com.ossnms.bicnet.securitymanagement.persistence.model;

import javax.persistence.MappedSuperclass;
import java.io.Serializable;

/**
 * created on 28/8/2014
 *
 * This class should hold common fields, but for now it is only a common aggregator for USM Domain classes
 *
 */
@MappedSuperclass
public abstract class BaseUSMEntity implements Serializable {

    private static final long serialVersionUID = 6538230668570414809L;

    public BaseUSMEntity() {
    }

    /**
     * Implement this method to inform is the object is new or not.
     * e.g. when the id is a long, the object is new if the id == 0
     *
     * @return true is the object is new, false otherwise
     */
    public abstract boolean isNew();
}
