package com.ossnms.bicnet.securitymanagement.common.importexport;

import java.io.Serializable;
import java.util.List;

import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;

/**
 * Security domain data info for import/export purposes.
 */
public class IEDomainData implements Serializable {

	private static final long serialVersionUID = -66309253087127064L;
	
	DCDomainData domain;
	List<String> securableObjectNames;
	
	public IEDomainData (DCDomainData domain, List<String> securableObjectNames) {
		this.domain = domain;
		this.securableObjectNames = securableObjectNames;
	}
	
	public DCDomainData getDomain() {
		return domain;
	}
	
	public List<String> getSecurableObjectNames() {
		return securableObjectNames;
	}
	
	
	public String toString() {
		return domain + "=" + securableObjectNames;
	}
	
}
