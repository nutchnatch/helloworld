/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	BSTransSecurableObjInfo
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_OBJECTS
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_ACL 
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_SECURITY
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.INSERT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 19-Jan-2005	Muyeen Munaver	CF000137 - #678: Add a method getType or so to the ISecurableObject
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.bicnetserver;

import com.ossnms.bicnet.bcb.model.ManagedObjectType;
import com.ossnms.bicnet.bcb.model.common.IIconPair;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import org.apache.log4j.Logger;

import java.io.Serializable;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;

/**
 * Transient data to hold the Securable Object details. This data is used to
 * transfer information about the Securable Object from the Server to the
 * Client. This class is equivalent to the BSPersSecurableObjInfo. The only
 * difference is that it does not derive from the LWElement
 */
public class BSSecurableObject extends BSSecurableBase implements Serializable {

    private static final long serialVersionUID = 7618035292475385916L;

    /**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(BSSecurableObject.class);

	/**
	 * The ACL of this Securable Object.
	 */
	private BSAccessControlList acl = null;
	
	/**
	 * Constructor
	 * @param dispName Display Name of the Securable Object
	 * @param uniqueName Unique Name of the Securable Object
	 * @param cfId Identifier for the CF which owns the Securable Object
	 * @param cfDisplayName Display Name for the CF which owns the Securable Object
	 * @param acl Access Control List of the Securable Object
	 */
	public BSSecurableObject(String dispName, String uniqueName, String cfId, String cfDisplayName, BSAccessControlList acl,
							 IIconPair icon, List<BSSecurableObjectContainer> containers, ManagedObjectType moType) {
	    
	    super(dispName, uniqueName, cfId, cfDisplayName, icon, moType, containers);
	    
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Creating BSSecurableObject. Display Name : " + dispName + " Unique Name : " + uniqueName + " CF ID : " + cfId
					+ " CF Name : " + cfDisplayName + " ACL : " + acl + " Icon: " + icon +" Type : " + moType);
		}
//
//		if (acl == null) {
//			LOGGER.error("ACL value is null");
//			throw new InvalidParameterException();
//		}
		
		this.acl = acl;

		LOGGER.debug("Exiting Constructor.");
	}

	/**
	 * This function is invoked when the BSSecurableObject needs to be passed
	 * from the Server to Client or vice versa. This function will push the
	 * BSSecurableObject into the message.
	 * @param msg  The message into which the object should be pushed.
	 */
	public void pushTo(USMMessage msg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering pushTo. Message : " + msg);
		}

		if (msg == null) {
			LOGGER.error("Message to push the object cannot be null.");
			throw new InvalidParameterException();
		}

		msg.pushString(displayName);
		msg.pushString(uniqueName);
		msg.pushString(ownerCfId);
		msg.pushString(ownerCfDisplayName);
		msg.pushString(acl == null ? "" : acl.toString());
		msg.pushObject(icon);

		if(objectContainers != null){
			for (BSSecurableObjectContainer container : objectContainers) {
				container.pushMe(msg);
			}
		}
		msg.pushInteger(objectContainers == null ? -1 : objectContainers.size());
		
		Integer nType = managedObjectType.getOrdinal();
		msg.pushInteger(nType);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting pushTo. Message : " + msg);
		}
	}

	/**
	 * This function is invoked when the BSSecurableObject needs to be created
	 * after recieving a message from the Server to Client or vice versa. This
	 * function will pop the BSSecurableObject from the message.
	 * @param msg  The message from which the object should be poped.
	 * @return BSSecurableObject Newly Poped out BSSecurableObject
	 */
	public static BSSecurableObject popMe(USMMessage msg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering popMe. Message : " + msg);
		}

		if (msg == null) {
			LOGGER.error("Message to pop the object cannot be null.");
			throw new InvalidParameterException();
		}
		int nType = msg.popInteger();
		ManagedObjectType type = ManagedObjectType.fromOrdinal(nType);

		List<BSSecurableObjectContainer> containers = null;
		int containerSize = msg.popInteger();
		if(containerSize != -1){
			containers = new ArrayList<>(containerSize);
			for (int i = 0; i < containerSize; i++) {
				BSSecurableObjectContainer container = BSSecurableObjectContainer.popMe(msg);
				containers.add(container);
			}
		}
		
		IIconPair icon = (IIconPair) msg.popObject();
		
		String strACL = msg.popString();
		BSAccessControlList acl = new BSAccessControlList(strACL);

		String strOwnerCFName = msg.popString();
		String strCFID = msg.popString();
		String strUniqueName = msg.popString();
		String strDisplayName = msg.popString();

		BSSecurableObject transCF = new BSSecurableObject(strDisplayName, strUniqueName, strCFID, strOwnerCFName, acl, icon, containers, type);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting popMe. Object created is : " + transCF);
		}

		return transCF;
	}

	/**
	 * This function is invoked to assign this Securable Object to a domain. This function
	 * is responsible to update the ACL of this object with the domainID that has
	 * been passed.
	 * @param domainID  The Domain to which this Securable Object should be assigned.
	 */
	public void addToDomainID(int domainID) {
		acl.addToDomain(domainID);
	}

	/**
	 * This function is invoked to unassign this Securable Object from a domain. This
	 * function is responsible to update the ACL of this object with the
	 * domain that has been passed.
	 * @param domainID  The Domain to which this Securable Object should be unassigned.
	 */
	public void removeFromDomainID(int domainID) {
		acl.removeFromDomain(domainID);
	}

	/**
	 * This function is invoked to check if the Securable Object belongs to the domain that is
	 * passed as a parameter.
	 * @param domainID  This is the Domain ID.
	 * @return boolean  Indicates whether the Securable Object belongs to the passed domain or not.
	 */
	public boolean belongsToDomain(int domainID) {
		return acl.belongsToDomain(domainID);
	}


	/**
	 * Access method for the acl property.
	 * @return java.lang.String  The current value of the acl property
	 */
	public BSAccessControlList getACL() {
		return acl;
	}

	/**
	 * Function gets the internal BitSet data member
	 * @return java.util.BitSet  The Current Bitset which holds the ACL.
	 */
	public java.util.BitSet getBitSetACL() {
		return acl.getACL();
	}

	/**
	 * Sets the value of the acl property.
	 * @param accessControlList  The new value of the acl property
	 */
	public void setACL(BSAccessControlList accessControlList) {
		this.acl = accessControlList;
	}

	/**
	 *
	 */
	public String getObjectName(){
		return uniqueName.replace(managedObjectType.getKeyName() + '=', "");
	}
	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
    public boolean equals(Object obj) {
		boolean bEquals = false;
		if (obj instanceof BSSecurableObject) {
			BSSecurableObject transObj = (BSSecurableObject) obj;
			if (uniqueName.compareTo(transObj.uniqueName) == 0) {
				bEquals = true;
			}
		}
		return bEquals;
	}

	/**
	 * @see java.lang.Object#hashCode()
	 */
	@Override
    public int hashCode() {
		return uniqueName.hashCode();
	}

	/**
	 * Function to check if the Securable Object belongs only to the Global domain.
	 * @return boolean Returns true if it belongs only to the Global domain
	 * otherwise it returns false.
	 */
	public boolean belongOnlyToGlobalDomain() {
		return acl.onlyGLOBALBitSet();
	}
}
