/*
 * Project      BiCNET Common Functions
 *
 * Component    CF:USM
 * Class Name   BWCommonFuncRetrievalManager
 * Author       Muyeen M
 * Substitute   Asif Khan R
 * Created on   18-11-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 02-Feb-2005  Babu B          CF000199-11 Unification of GUI-Labels for Enums
 * 05-May-2005  Muyeen Munaver  CF001312   Master-Master Replication for Sun ONE DS
 * 08-Aug-2005	Balasubramanya	CF002760 - 9320_MR_0291 Users, User Groups, Policies lose associations after import
 * 08-Aug-2005	Balasubramanya	CF002759 - 9320_MR_0289 Security information discarded for user after deletion and restore
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.bcbwrapper;

import com.ossnms.bicnet.bcb.facade.IMgrFacade;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.servicelocator.BiCNetServiceLocator;
import com.ossnms.bicnet.servicelocator.ServiceLocatorException;
import com.ossnms.bicnet.util.UnexpectedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Manager class to get information about the different CFs
 */
public final class BWCommonFuncRetrievalManager {

    /**
     * Data member for the logging of the class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(BWCommonFuncRetrievalManager.class);

    /**
     * Data member to hold the type for the caller.
     */
    private static final BiCNetComponentType m_Type = BiCNetComponentType.SECURITY_MANAGER;

    /**
     * Data member to hold the singleton instance
     */
    private static BWCommonFuncRetrievalManager instance = new BWCommonFuncRetrievalManager();

    /**
     * Function to return the singleton instance of the class
     *
     * @return BWCommonFuncRetrievalManager
     *          The singleton instance of the class.
     */
    public static BWCommonFuncRetrievalManager getInstance() {
        return instance;
    }

    /**
     * Constructor
     */
    private BWCommonFuncRetrievalManager() {
        LOGGER.debug("Creating an instance of BWCommonFuncRetrievalManager");
    }

    /**
     * Function to return the Array of the String identifiers
     * for the Private Facades.
     *
     * @return String[]
     *      The Array of objects which are available
     */
    public String[] getAllRegisteredCFs() {
        LOGGER.debug("Entering getAllRegisteredCFs");

        BiCNetServiceLocator bclSL = BiCNetServiceLocator.getInstance();

        if (bclSL == null) {
            LOGGER.error("The returned BiCNetServiceLocator is null.");
            return null;
        }

        Map<BiCNetComponentType, IMgrFacade> mp = null;
        try {
            mp = bclSL.getRegisteredPublicCFFacades(BiCNetComponentType.SECURITY_MANAGER);
        } catch (UnexpectedException e) {
            LOGGER.error("getAllRegisteredCFs : ", e);
        }

        if (mp == null) {
            LOGGER.error("The Map Object retrieved from ServiceLocator is null.");
            return null;
        }

        // create a list of cf types (String)
        List<String> cfTypes = new ArrayList<>();

        // for each one, add the name to the list
        mp.keySet().forEach(componentType ->  {
            LOGGER.debug("Retrieved an object of type : {}", componentType);
            cfTypes.add(componentType.toString());
        });

        return cfTypes.toArray(new String[cfTypes.size()]);
    }

    /**
     * Helper function to return an Object which is equivalent to
     * IBicNetService.
     *
     * @param strType
     *          The String which indicates the type of the object that
     * is required.
     *
     * @return The Object which is equivalent to the IBicNetService.
     */
    public BWCommonFuncObject getCommonFunctionObject(String strType) {
        LOGGER.debug("Entering getCommonFunctionObject. String being passed is {}", strType);

        BiCNetComponentType retrievedType = BiCNetComponentType.fromName(strType);

        LOGGER.debug("retrievedType = {}", retrievedType);
        
        if (retrievedType == null) {
            LOGGER.error("Null Object retreived from ServiceLocator for String : {}", strType);
            return null;
        }

        BiCNetServiceLocator bclSL = BiCNetServiceLocator.getInstance();

        if (bclSL == null) {
            LOGGER.error("The returned BiCNetServiceLocator is null.");
            return null;
        }

        IMgrFacade objMgrFacade = null;
        try {
            objMgrFacade = bclSL.getPublicFacade(retrievedType, m_Type);
        } catch (UnsupportedOperationException | UnexpectedException | ServiceLocatorException e) {
        	LOGGER.error("Unable to get public facade for " + retrievedType, e);
        }

        if (objMgrFacade == null) {
            LOGGER.error("Retrieved IMgrFacade object is null.");
            return null;
        }

        BWCommonFuncObject obj = new BWCommonFuncObject(retrievedType, objMgrFacade);
        LOGGER.debug( "Exiting getCommonFunctionObject after proper creation of object {} {}.", objMgrFacade, obj);
        return obj;
    }

}
