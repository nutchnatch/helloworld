package com.ossnms.bicnet.securitymanagement.server.bicnetserver;

import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 *
 */
final class BSCacheManager {

    /**
     * Private constructor
     */
    private BSCacheManager(){}


    private static Map<String, BSSecurableObject>   securableObjects                = new ConcurrentHashMap<>();
    private static Map<String, List<String>>        securableObjectByFunction       = new ConcurrentHashMap<>();
    private static Map<String, String>              securableObjectByDisplayName    = new ConcurrentHashMap<>();

    /**
     *
     * @param securableObjects
     */
    public static void add(List<BSSecurableObject> securableObjects){
        securableObjects.stream().forEach(BSCacheManager::add);
    }

    /**
     *
     * @param securableObject
     */
    public static void add(BSSecurableObject securableObject){
        // add to the list of securable objects
        securableObjects.put(securableObject.getUniqueName(), securableObject);

        // map this object by function
        if(!securableObjectByFunction.containsKey(securableObject.getOwnerCfId())){
            securableObjectByFunction.put(securableObject.getOwnerCfId(), new ArrayList<>());
        }
        securableObjectByFunction.get(securableObject.getOwnerCfId()).add(securableObject.getUniqueName());

        // map this object by display name
        securableObjectByDisplayName.put(securableObject.getDisplayName(), securableObject.getUniqueName());
    }

    /**
     *
     */
    static void initializeCache(List<BSSecurableObject> securableObjects){
        add(securableObjects);
    }

    /**
     *
     * @return
     */
    public static List<BSSecurableObject> getAll(){
        return (List<BSSecurableObject>) securableObjects.values();
    }

    /**
     *
     * @param function
     * @return
     */
    public static List<BSSecurableObject> getAll(BSTransBicNetCFInfo function){
        List<BSSecurableObject> securableObjectList = new ArrayList<>();

        securableObjectByFunction.getOrDefault(function.getCFid(), new ArrayList<>()).stream().forEach(uniqueName -> {
            securableObjectList.add(
                securableObjects.get(uniqueName)
            );
        });

        return securableObjectList;
    }

    /**
     *
     * @param uniqueName
     * @return
     */
    public static BSSecurableObject findById(String uniqueName){
        return securableObjects.get(uniqueName);
    }

    /**
     *
     * @param displayName
     * @return
     */
    public static BSSecurableObject findByDisplayName(String displayName){
        String uniqueName = securableObjectByDisplayName.get(displayName);

        if(uniqueName == null){
            return null;
        }

        return securableObjects.get(uniqueName);
    }

    /**
     *
     * @return
     */
    public static int count(){
        return 0;
    }

    /**
     *
     * @param functionId
     * @return
     */
    public static int count(String functionId){
        if(!securableObjectByFunction.containsKey(functionId)){
            return 0;
        }

        return securableObjectByFunction.get(functionId).size();
    }
}
