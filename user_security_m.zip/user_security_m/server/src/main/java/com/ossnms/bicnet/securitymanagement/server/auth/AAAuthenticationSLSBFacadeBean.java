/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AAAuthenticationSLSBFacadeBean
 * Author      	Jogender Singh
 * Substitute	Babu B
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.AUTHENTHICATE.USER
 *        TNMS.DX2.SM.LOGIN.USERID
 *		  TNMS.DX2.SM.LOGOUT.USER 
 *        TNMS.DX2.SM.SERVER.AUTHORIZATION
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 * 10-May-2005	Muyeen Munaver	CF002170 - Resolve the Host name into the IP address fails
 * 09-10-2007   Shrinidhi G V   CF004512-07  Improvement for server side filtering
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.auth;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.bcb.model.security.InvalidCredentialsException;
import com.ossnms.bicnet.securitymanagement.api.common.OperationResult;
import com.ossnms.bicnet.securitymanagement.common.auth.AAChangePasswordDetails;
import com.ossnms.bicnet.securitymanagement.common.auth.AAClientCacheData;
import com.ossnms.bicnet.securitymanagement.common.basic.SecurableObjectACL;
import com.ossnms.bicnet.securitymanagement.common.basic.SessionEvent;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityAuthenticationPrivateFacadeLocal;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityAuthenticationPrivateFacadeRemote;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import java.util.Properties;
import java.util.Set;

@Stateless(name = "AAAuthenticationSLSBFacade")
@Local(ISecurityAuthenticationPrivateFacadeLocal.class)
@Remote(ISecurityAuthenticationPrivateFacadeRemote.class)
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AAAuthenticationSLSBFacadeBean implements ISecurityAuthenticationPrivateFacadeLocal, ISecurityAuthenticationPrivateFacadeRemote {
    private static final long serialVersionUID = 1L;

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(AAAuthenticationSLSBFacadeBean.class);

    /**
     * The implementation class.
     */
    private AAAuthenticationPOJOImpl objAuthenticationPOJO = new AAAuthenticationPOJOImpl();

    @Override
    public ISessionContext logon(String userName, byte[] password, String host, String strClientIpAddress) throws BcbSecurityException {
        LOGGER.debug("logon({}, ******, {}) Entry", userName, host);

        // Calling pojo implementation
        ISessionContext objSessionContext = objAuthenticationPOJO.logon(userName, password, host, strClientIpAddress);

        LOGGER.debug("logon(...)  Exit");
        return objSessionContext;
    }

    @Override
    public ISessionContext logon(byte[] token, String userName, String host, String clientIpAddress) throws BcbSecurityException {
        LOGGER.debug("logon() - with Kerberos Entry");

        // Calling pojo implementation
        ISessionContext objSessionContext = objAuthenticationPOJO.logon(token, userName, host, clientIpAddress);

        LOGGER.debug("logon() - with Kerberos Exit");

        return objSessionContext;
    }

    @Override
    public void logoff(ISessionContext sessionToLogoffContext) throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("logoff(" + sessionToLogoffContext + ") Entry");
        }
        objAuthenticationPOJO.logoff(sessionToLogoffContext);
        LOGGER.debug("logoff(...) Exit");
    }

    @Override
    public void forceLogoff(ISessionContext sessionToLogoffContext, SessionEvent event) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("forceLogoff(" + sessionToLogoffContext + ") Entry");
        }

        objAuthenticationPOJO.forceLogoff(sessionToLogoffContext, event);

        LOGGER.debug("forceLogoff(...) Exit");
    }

    @Override
    public USMMessage getAdvisoryDetails(ISessionContext sessionContext) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getAdvisoryDetails(" + sessionContext + ") Entry");
        }

        USMMessage objUSMMessage = objAuthenticationPOJO.getAdvisoryDetails(sessionContext);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getAdvisoryDetails(...) Exit. Returning : " + objUSMMessage);
        }
        return objUSMMessage;
    }

    @Override
    public USMMessage changePassword(ISessionContext sessionContext, AAChangePasswordDetails userDetails) throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("changePassword(" + sessionContext + ", " + userDetails + ") Entry");
        }

        USMMessage objUSMMessage = objAuthenticationPOJO.changePassword(sessionContext, userDetails);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("changePassword(...) Exit. Returning : " + objUSMMessage);
        }
        return objUSMMessage;
    }

    @Override
    public AAClientCacheData getClientSecurityData(ISessionContext sessionContext) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getClientSecurityData(" + sessionContext + ") Entry");
        }

        AAClientCacheData objClientData = AAServerCache.getInstance().retrieveClientSecurityData(sessionContext);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getClientSecurityData(...) Exit. Returning : " + objClientData);
        }
        return objClientData;
    }

    @Override
    public USMMessage isPasswordMustChanged(ISessionContext sessionContext) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("isPasswordMustChanged(" + sessionContext + ") 	Entry");
        }
        USMMessage objUSMMessage = objAuthenticationPOJO.isPasswordMustChanged(sessionContext);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("isPasswordMustChanged(...) Exit. Returning : " + objUSMMessage);
        }
        return objUSMMessage;

    }

    @Override
    public byte[] getUserPasswordSalt(String userName) throws InvalidCredentialsException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getUserPasswordSalt(" + userName + ") 	Entry");
        }
        byte[] salt = objAuthenticationPOJO.getUserPasswordSalt(userName);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getUserPasswordSalt(...) Exit. Returning : " + salt);
        }
        return salt;

    }
    
    @Override
    public Set<SecurableObjectACL> getSecurableObjects(ISessionContext sessionContext) throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getSecurableObjects(" + sessionContext + ")    Entry");
        }
        Set<SecurableObjectACL> objUSMMessage = objAuthenticationPOJO.getSecurableObjects(sessionContext);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getSecurableObjects(...) Exit. Returning : " + objUSMMessage);
        }
        return objUSMMessage;
    }

    @Override
    public USMMessage getProfile(ISessionContext sessionContext) throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getProfile(" + sessionContext + ")    Entry");
        }
        USMMessage objUSMMessage = objAuthenticationPOJO.getProfile(sessionContext);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getProfile(...) Exit. Returning : " + objUSMMessage);
        }
        return objUSMMessage;
    }

    @Override
    public USMMessage setProfile(ISessionContext sessionContext, String appUID, Properties profile) throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setProfile(" + sessionContext + "," + appUID + "," + profile + ")    Entry");
        }
        USMMessage objUSMMessage = objAuthenticationPOJO.setProfile(sessionContext, appUID, profile);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setProfile(...) Exit. Returning : " + objUSMMessage);
        }
        return objUSMMessage;
    }

    @Override
    public USMMessage removeUserProfile(ISessionContext sessionContext, String appUID) throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("removeUserProfile(" + sessionContext + "," + appUID + ")    Entry");
        }
        USMMessage objUSMMessage = objAuthenticationPOJO.removeUserProfile(sessionContext, appUID);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("removeUserProfile(...) Exit. Returning : " + objUSMMessage);
        }
        return objUSMMessage;
    }

    @Override
    public USMMessage getServerVersionAndProductType(ISessionContext sessionContext) throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getServerVersionAndProductType(" + sessionContext + ")    Entry");
        }
        return objAuthenticationPOJO.getServerVersionAndProductType(sessionContext);
    }

	@Override
	public OperationResult setActive(ISessionContext sessionContext) {
		return objAuthenticationPOJO.setActive(sessionContext);
	}

    @Override
    public USMMessage getInactivityTimeout(ISessionContext sessionContext) throws BcbSecurityException {
        LOGGER.debug("getInactivityTimeout(" + sessionContext + ")    Entry");
        USMMessage objUSMMessage = objAuthenticationPOJO.getInactivityTimeout(sessionContext);
        LOGGER.debug("getInactivityTimeout(...) Exit. Returning : " + objUSMMessage);
        return objUSMMessage;
    }

    @Override
    public USMMessage getInactivityTimeoutWarningTime(ISessionContext sessionContext) throws BcbSecurityException {
        LOGGER.debug("getInactivityTimeoutWarningTime()    Entry");
        USMMessage objUSMMessage = objAuthenticationPOJO.getInactivityTimeoutWarningTime(sessionContext);
        LOGGER.debug("getInactivityTimeoutWarningTime() Exit. Returning : " + objUSMMessage);
        return objUSMMessage;
    }
}
