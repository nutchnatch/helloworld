/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	BSServerLifeCycleController
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_OBJECTS
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_ACL 
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_SECURITY
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.INSERT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 05-May-2005  Muyeen Munaver  CF001312   Master-Master Replication for Sun ONE DS
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.bicnetserver;

import com.ossnms.bicnet.securitymanagement.server.basic.USMServerLifeCycleControllerIfc;
import org.apache.log4j.Logger;

/**
 * This class is responsible for the initialization and cleanup activities
 * to be performed by the subsystem BS. These activities are performed at the
 * start of the Server process and at the closure of the Server process. 
 * 
 */
public final class BSServerLifeCycleController
    implements USMServerLifeCycleControllerIfc {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER =
        Logger.getLogger(BSServerLifeCycleController.class);

    /**
     * Data member to hold the singleton instance of this class
     */
    private static BSServerLifeCycleController theInstance =
        new BSServerLifeCycleController();

    /**
     * Constructor
     */
    private BSServerLifeCycleController() {
        LOGGER.debug("Entering constructor of BSServerLifeCycleController");
        LOGGER.debug("Exiting constructor of BSServerLifeCycleController");
    }

    /**
     * This method is invoked to initialize the BS subsystem in the 
     * Server start up flow.
     * @return boolean Indicates whether it was possible to initialize the Object 
     * correctly. True indicates successful initialization.
     */
    @Override
    public boolean initialize() {
        LOGGER.debug("Entering initialize");

        boolean bInitialized = BSCentralController.getInstance().initialize();

//        LWNotifHandler ldapNotifHandler = new BSLdapNotifHandler();
//
//        // Register for LDAP notifications
//        LWInterface.registerSSForNotif(
//            BSLWInterface.SECURABLE_OBJECTS_OU,
//            ldapNotifHandler);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting initialize. Result : " + bInitialized);
        }

        return bInitialized;
    }

    /**
     * This method is invoked to cleanup the BS subsystem in the Server shut 
     * down flow. 
     * @return boolean Indicates whether it was possible to cleanup the object. True indicates
     * successful cleanup
     */
    @Override
    public boolean cleanup() {
        LOGGER.debug("Entering cleanup");

        boolean bCleanedUp = BSCentralController.getInstance().cleanup();

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting cleanup. Result : " + bCleanedUp);
        }

        return bCleanedUp;
    }

    /**
     * Static function to get the singleton instance of the Class
     * @return BSServerLifeCycleController The singleton 
     * instance of the class
     */
    public static BSServerLifeCycleController getInstance() {
        return theInstance;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.securitymanagement.server.basic.USMServerLifeCycleControllerIfc#reinitialize()
     */
    @Override
    public boolean reinitialize() {
        boolean bCleanUp = BSCentralController.getInstance().cleanup();
        boolean bInitialized = BSCentralController.getInstance().initialize();
        return bCleanUp && bInitialized;
    }

}
