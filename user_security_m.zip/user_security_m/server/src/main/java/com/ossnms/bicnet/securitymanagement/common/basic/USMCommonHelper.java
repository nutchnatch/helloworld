/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 22-Mar-2005	Muyeen Munaver	CF0001791 - Problems with Login
 * 25-Apr-2005	Muyeen Munaver	CF001917 - Policy with FM menu associated - not possible to do ACK or Add Note
 * 26-Apr-2005	Asif			CF000834 - Command Log Entries	CF USM
 * 10-May-2005	Muyeen Munaver	CF002170 - Resolve the Host name into the IP address fails
 * 22-Jun-2005  Muyeen Munaver  CF002307 - BST, GMT and CST -> wrong hours
 * 08-Aug-2005	Balasubramanya	CF002760 - 9320_MR_0291 Users, User Groups, Policies lose associations after import
 * 08-Aug-2005	Balasubramanya	CF002759 - 9320_MR_0289 Security information discarded for user after deletion and restore
 * 06-Oct-2005	Balasubramanya	CF002924 - USM Error messages in server.log
 * 11-Jan-2006  Balasubramanya  CF002773 - Missing correct computer name in window User Administration
 * 11-Jan-2006	Balasubramanya	CF003349 - Import User Group fails for Administrator users
 * 12-Apr-2006	Shrinidhi G V	CF003762 - Wrong IP-address in security log with failed user login
 * 26-Aug-2005  Babu B          CF002773 - Missing correct computer name in window User Administration
 * 06-Oct-2005	Balasubramanya	CF002924 - USM Error messages in server.log
 * 14-Dec-2005	Balasubramanya	CF003140 - Several Problems after "Import Configuration..."
 * 22-Feb-2006	Balasubramanya	CF003643 - Exception while starting the Client
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.basic;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.securitymanagement.common.auth.AASessionContext;
import com.ossnms.bicnet.securitymanagement.server.servicelocator.USMCallStyleProperties;
import com.ossnms.bicnet.util.ApplicationProperties;
import org.apache.log4j.Logger;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Helper class for the whole of CF USM, both on the client as well
 * as the server side.
 */
public final class USMCommonHelper {
	/**
	 * Data member for the Logging
	 */
	private final static Logger LOGGER = Logger.getLogger(USMCommonHelper.class);

	/**
	 * Data member for storing if Security is enabled or not.
	 */
	private static boolean m_SecurityChkDisabled = false;

	/**
	 * Global AA Trace Configuration
	 */
	public static final boolean m_bDetailedTraces = true;

	/**
	 * Data member to hold the String that will be used for the formatting of the date
	 */
	private static final String DATE_FORMAT_STR = "dd MM yyyy HH:mm:ss zzz";

    static {
        try {
            ApplicationProperties appProp = USMCallStyleProperties.getInstance();
            String securityCheckProperty = appProp.getProperty("securityManager.SecurityCheckDisabled");
            LOGGER.info("Value of securityManager.SecurityCheckDisabled is : " + securityCheckProperty);
            m_SecurityChkDisabled = Boolean.parseBoolean(securityCheckProperty);

        } catch (Exception e) {
            LOGGER.warn("Couldn't load USM callstyle properties. Using default values: " + e.getMessage());
        }
    }

	/**
	 * Private Constructor.
	 */
	private USMCommonHelper() {
		LOGGER.debug("Entering Constructor");

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting Constructor. Value of m_SecuritySwitchedOff : " + m_SecurityChkDisabled);
		}
	}

	/**
	 * This function should be called from the client side only.
	 * SHOULD NOT BE CALLED IN THE SERVER. Problem due to class loading
	 * prevent the domainobject classes to invoke methods on the service locator.
	 *
	 * @param bSecurityDisabled The value of the state.
	 */
	public static void setSecurityDisabledState(boolean bSecurityDisabled) {
		LOGGER.info("Entering setSecurityDisabledState.");
		m_SecurityChkDisabled = bSecurityDisabled;
	}

	/**
	 * Function to return whether or not Security has been switched off. Rather
	 * than all classes making calls to the USMCallStyleProperties, it is better
	 * if this class makes the call. It will be easier to remove the code in
	 * later versions. To prevent security breach.
	 *
	 * @return boolean Indicates whether security should be switched off. True
	 *         indicates switch off security.
	 */
	public static boolean isSecurityCheckDisabled() {
		LOGGER.debug("Entering isSecurityCheckDisabled");

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting isSecurityCheckDisabled. Returning : " + m_SecurityChkDisabled);
		}
		return m_SecurityChkDisabled;
	}

	/**
	 * Helper function to return the String equivalent of the Array of ManagedObjects
	 * @param p_arr Array containing the objects
	 * @return String String which is a representation of the Array.
	 */
	public static String getStringForArrayOfIManagedObjectId(IManagedObjectId[] p_arr) {
		StringBuffer str = new StringBuffer();
		if (p_arr != null) {
			str.append("Number of elements in the array are : ");
			str.append(p_arr.length);
			for (int index = 0; index < p_arr.length; index++) {
				IManagedObjectId id = p_arr[index];
				if (id != null) {
                    str.append(index);
                    str.append(" key : ");
                    str.append(getUSMizedStringForKey(id.key()));
				} else {
					str.append("Null Object passed at index : ");
					str.append(index);
				}
				str.append("::");
			}
		} else {
			str.append("Array passed is null");
		}
		return str.toString();
	}

	/**
	 * Helper function to return the String equivalent of the Array of ManagedObjects
	 * @param p_arr Array containing the objects
	 * @return String String which is a representation of the Array.
	 */
	public static String printIManagedObjectArray(IManagedObject[] p_arr) {
		StringBuilder str = new StringBuilder();
		if (p_arr != null) {
			str.append("Number of elements in the array are : "); 
			str.append(p_arr.length);
			for (int index = 0; index < p_arr.length; index++) {
				IManagedObject id = p_arr[index];
				if (id != null) {
                    str.append(index);
                    str.append(" name : ");
                    str.append(id.getNativeName());
                    str.append(" key : ");
                    str.append(getUSMizedStringForKey(id.key()));
				} else {
					str.append("Null Object passed at index : ");
					str.append(index);
				}
				str.append("::");
			}
		} else {
			str.append("Array passed is null");
		}
		return str.toString();
	}

	/**
	 * Helper function to return the Dummy Context.
	 *
	 * @param username The User name that should be associated with the context
	 * @return IEnhancedSessionContext - The Context with the user.
	 *
	 */
	public static IEnhancedSessionContext getDummySessionContext(String username) {
		LOGGER.debug("Entering getDummySessionContext");

		String password = "Dummy";
		String host = "localhost";
		String ipaddress = "127.0.0.1";
		List<String> userGroups = new ArrayList<String>();
		boolean isLoggedin = true;
        IEnhancedSessionContext ctx = new AASessionContext(username, password, host, host, ipaddress, userGroups, isLoggedin);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting getDummySessionContext. Returning : " + ctx);
		}
		return ctx;
	}

	/**
	 * @return
	 */
	public static boolean isDetailedTracesEnabled() {
		return USMCommonHelper.m_bDetailedTraces;
	}

	/**
	 * Helper function to return the Local Host Name
	 * @return String The Local Host Name
	 */
	public static String getLocalHostName() {
		String hostName = null;
		try {
			hostName = InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException e) {
			LOGGER.error("Exception raised : ", e);
		}
		return hostName;
	}

	/**
	 * Helper function to return the canonical host name
	 * @return String The canonical host name
	 */
	public static String getCanonicalHostName(){
	    String canonicalHostName = null;
        try {
            canonicalHostName = InetAddress.getLocalHost().getCanonicalHostName();
        } catch (UnknownHostException e) {
            LOGGER.error("Exception raised : ", e);
        }
        return canonicalHostName;
	}
	
	/**
	 * Helper function to return the ip-address of the current host
	 * @return String The ip-address
	 */
	public static String getLocalHostAddress() {

		String hostName = null;
		try {
			hostName = InetAddress.getLocalHost().getHostAddress();
		} catch (UnknownHostException e) {
			LOGGER.error("Exception raised : ", e);
		}
		return hostName;
	}

	/**
	 * Function to find the ipAddress of the specified Host
	 * @param host Host Name
	 * @return String The ipAddress
	 */
	public static String getIpAddressForHost(String host) {
		//3762-Send the p_host name itself and print in the security log record coloumn if UnknownHost Exception occurs
	    String ipAddress = USMCommonStrings.UNKNOWN_HOST;
		try {
	        InetAddress[] arr = InetAddress.getAllByName(host);
	        if((arr != null) && (arr.length > 0)) {
	            ipAddress = arr[0].getHostAddress();
	        } else {
	        	LOGGER.warn("IP Address of the client machine name is null or ip address length is zero:Hence display host name itself ");
				ipAddress=host;
				LOGGER.warn("ip address:"+ipAddress);
	        }
	    } catch (UnknownHostException e) {
			LOGGER.warn("Unknown host exception has occured, hence send computer name to security log record:");
			ipAddress=host;
			LOGGER.warn("ip address:"+ipAddress);
	        LOGGER.error("Exception raised for Host : " + host, e);
	    }
	    return ipAddress;
	}


	/**
	 * This is sort of a helper method to create a string given the parameters.
	 * The main reason is to encapsualte in a try catch block, so that this does
	 * not lead to unnecessary exceptions getting thrown
	 * @param p_msg  The main message string
	 * @param p_msgObjects The list of objects which will be added to the main string
	 */
	public static String createFormattedString(String p_msg, Object... p_msgObjects) {

		String strMessage = USMCommonStrings.IDS_SECURITY;

		try {
			strMessage = MessageFormat.format(p_msg, p_msgObjects);
		} catch (Exception e) {
			LOGGER.warn("Some exception occured while formatting message", e);
		}

		LOGGER.info(strMessage);
		return strMessage;

	}

	/**
	 * Helper function to return a string who's case has been changed to
	 * CAPITAL. This is needed since EM-NE Obj Mgr gives NE= <id>when key()
	 * method called, and the other CF's give ne= <id>. And checks within USM
	 * fail.
	 *
	 * @param p_strKey
	 *            The String which represents the key to the Managed object
	 * @return String The new String that should be used within USM
	 */
	public static String getUSMizedStringForKey(String p_strKey) {
		return p_strKey.toUpperCase();
	}

	/**
	 * Function to return the Formatter which should be used by CF USM
	 * @return DateFormat The Object which should be used by CF USM formatting
	 */
	public static DateFormat getUSMDateFormatter() {
		LOGGER.info("Setting the USM Date Formatter");
		DateFormat dtFormmatter = new SimpleDateFormat(DATE_FORMAT_STR);
		LOGGER.info("Locale Object Before Setting"+Locale.getDefault());
		LOGGER.info("USM Date Formatter"+dtFormmatter);
		LOGGER.info("Locale Object After Setting"+Locale.getDefault());
		return dtFormmatter;
	}

	/**
	 * Function to return the GMT equivalent string for the date that has been passed
	 * @param p_Dt The Date object for which we require a representation
	 * @return String The String which represents the Date
	 */
	public static String getGMTStringForDate(Date p_Dt) {
		DateFormat df = new SimpleDateFormat(DATE_FORMAT_STR);
		df.setTimeZone(TimeZone.getTimeZone("GMT"));
		return df.format(p_Dt);
	}

	/**
	 * Function to return the GMT equivalent string for the current time.
	 * @return String The string which represents the current time
	 */
	public static String getGMTStringForCurrentDate() {
		return getGMTStringForDate(new Date());
	}
}