package com.ossnms.bicnet.securitymanagement.server.ldap;

import com.ossnms.bicnet.securitymanagement.server.ldap.callback.LDAPContextCallback;
import com.ossnms.bicnet.securitymanagement.server.ldap.dto.LDAPUserContext;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.SearchScope;

import java.text.MessageFormat;
import java.util.List;

import static org.springframework.ldap.query.LdapQueryBuilder.query;

/**
 *
 */
public class LDAPManager {

    public static final int AUTH_COUNT_LIMIT = 1;

    public static final String LDAPS = "ldaps";
    public static final String LDAP = "ldap";
    public static final String SEPARATOR_PROTOCOL = "://";
    public static final String SEPARATOR_PORT = ":";
    public static final String PATTERN_BASE_FILTER = "(&({0})({1}))";
    public static final String PATTERN_CONTAINING_FILTER = "{0}=*{1}*";
    public static final String PATTERN_EQUALS_FILTER = "{0}={1}";

    private LdapContextSource contextSource;

    /**
     *
     * @param url
     * @param port
     * @param sslIndicator
     * @param userDn
     * @param password
     */
    public LDAPManager(String url, int port, boolean sslIndicator, String userDn, String password) {
        contextSource = new LdapContextSource();
        String protocol = LDAP;

        if(sslIndicator){
            protocol = LDAPS;
        }

        contextSource.setUrl(protocol + SEPARATOR_PROTOCOL + url + SEPARATOR_PORT + port);
        contextSource.setUserDn(userDn);
        contextSource.setPassword(password);
        contextSource.setPooled(false);

        contextSource.afterPropertiesSet();
    }

    /**
     * {@inheritDoc}
     */
    protected LDAPUserContext authenticate(String searchBase, String searchFilter, SearchScope searchScope, String password) {
        return new LdapTemplate(contextSource).authenticate(
                getBaseQuery(AUTH_COUNT_LIMIT, searchBase, searchScope, searchFilter),
                password,
                new LDAPContextCallback()
        );
    }

    /**
     * {@inheritDoc}
     */
    protected LDAPUserContext authenticate(String searchBase, String searchFilter, String idAttribute, boolean containing, String idValue, SearchScope searchScope, String password) {
        return new LdapTemplate(contextSource).authenticate(
                getBaseQuery(AUTH_COUNT_LIMIT, searchBase, searchScope, searchFilter, idAttribute, containing, idValue),
                password,
                new LDAPContextCallback()
        );
    }


    /**
     * {@inheritDoc}
     */
    protected <T> List<T> search(int countLimit, String searchBase, String searchFilter, SearchScope searchScope, AttributesMapper<T> attributesMapper) {
        return new LdapTemplate(contextSource).search(
                getBaseQuery(countLimit, searchBase, searchScope, searchFilter),
                attributesMapper
        );
    }

    /**
     * {@inheritDoc}
     */
    protected <T> List<T> search(int countLimit, String searchBase, String searchFilter, String idAttribute, boolean containing, String idValue, SearchScope searchScope, AttributesMapper<T> attributesMapper) {
        return new LdapTemplate(contextSource).search(
                getBaseQuery(countLimit, searchBase, searchScope, searchFilter, idAttribute, containing, idValue),
                attributesMapper
        );
    }

    /**
     *
     * @param countLimit
     * @param searchBase
     * @param searchScope
     * @return
     */
    private LdapQuery getBaseQuery(int countLimit, String searchBase, SearchScope searchScope, String searchFilter) {
        return query()
                .countLimit(countLimit)
                .base(searchBase)
                .searchScope(searchScope)
                .filter(searchFilter);
    }

    /**
     *
     * @param countLimit
     * @param searchBase
     * @param searchScope
     * @return
     */
    private LdapQuery getBaseQuery(int countLimit, String searchBase, SearchScope searchScope, String searchFilter, String idAttribute, boolean containing, String idValue) {
        String filterFormat = MessageFormat.format(
                PATTERN_BASE_FILTER,
                searchFilter,
                containing ? PATTERN_CONTAINING_FILTER : PATTERN_EQUALS_FILTER
        );

        return query()
                .countLimit(countLimit)
                .base(searchBase)
                .searchScope(searchScope)
                .filter(filterFormat, idAttribute, idValue);
    }
}
