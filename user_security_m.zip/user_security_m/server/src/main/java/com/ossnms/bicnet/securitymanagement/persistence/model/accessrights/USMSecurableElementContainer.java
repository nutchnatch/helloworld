package com.ossnms.bicnet.securitymanagement.persistence.model.accessrights;

import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import java.util.List;

/**
 * created on 24/9/2014
 */
@Entity
@Table(name = "USM_SEC_ELEMENT_CONTAINER")
@NamedQueries({
        @NamedQuery(
                name = "usmSecurableElementContainer.findByFunction",
                query = "from USMSecurableElementContainer c where c.cf.cfId = :functionId"
        )
})
public class USMSecurableElementContainer extends USMSecurableBase {

    private static final String TYPE_BOOLEAN = "yes_no";

    private static final String TABLE_USM_SEC_CONTAINER_SEC_ELEMENT = "USM_SEC_CONTAINER_SEC_ELEMENT";
    private static final String TABLE_USM_SEC_PARENT_SEC_CONTAINER = "USM_SEC_PARENT_SEC_CONTAINER";

    private static final String COLUMN_UNIQUE_NAME = "UNIQUE_NAME";
    private static final String COLUMN_CONTAINER_NAME = "CONTAINER_NAME";
    private static final String COLUMN_ELEMENT_NAME = "ELEMENT_NAME";
    private static final String COLUMN_PARENT_CONTAINER_NAME = "PARENT_CONTAINER_NAME";

    private static final long serialVersionUID = -1608599402039998092L;

    @Type(type = TYPE_BOOLEAN)
    @Column(name = "COMPOUND")
    private boolean compound;

    @ManyToMany
    @JoinTable(name=TABLE_USM_SEC_CONTAINER_SEC_ELEMENT,
        joinColumns = @JoinColumn(name=COLUMN_CONTAINER_NAME, referencedColumnName = COLUMN_UNIQUE_NAME),
        inverseJoinColumns = @JoinColumn(name=COLUMN_ELEMENT_NAME, referencedColumnName = COLUMN_UNIQUE_NAME)
    )
    private List<USMSecurableElement> securableElements;

    @ManyToMany
    @JoinTable(name=TABLE_USM_SEC_PARENT_SEC_CONTAINER,
            joinColumns = @JoinColumn(name=COLUMN_PARENT_CONTAINER_NAME, referencedColumnName = COLUMN_UNIQUE_NAME),
            inverseJoinColumns = @JoinColumn(name=COLUMN_CONTAINER_NAME, referencedColumnName = COLUMN_UNIQUE_NAME)
    )
    private List<USMSecurableElementContainer> childContainers;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name=TABLE_USM_SEC_PARENT_SEC_CONTAINER,
            joinColumns = @JoinColumn(name=COLUMN_CONTAINER_NAME, referencedColumnName = COLUMN_UNIQUE_NAME),
            inverseJoinColumns = @JoinColumn(name=COLUMN_PARENT_CONTAINER_NAME, referencedColumnName = COLUMN_UNIQUE_NAME)
    )
    private List<USMSecurableElementContainer> parentContainers;

    public USMSecurableElementContainer(){}

    public USMSecurableElementContainer(String uniqueName, String name, int type, String iconId, boolean compound) {
        super(uniqueName, name, type, iconId);
        this.compound = compound;
    }

    public boolean isCompound() {
        return compound;
    }

    public void setCompound(boolean compound) {
        this.compound = compound;
    }

    public List<USMSecurableElement> getSecurableElements() {
        return securableElements;
    }

    public void setSecurableElements(List<USMSecurableElement> securableElements) {
        this.securableElements = securableElements;
    }

    public List<USMSecurableElementContainer> getChildContainers() {
        return childContainers;
    }

    public void setChildContainers(List<USMSecurableElementContainer> childContainers) {
        this.childContainers = childContainers;
    }

    public List<USMSecurableElementContainer> getParentContainers() {
        return parentContainers;
    }

    public void setParentContainers(List<USMSecurableElementContainer> parentContainers) {
        this.parentContainers = parentContainers;
    }

    @Override
    public boolean equals(Object o) {
        return super.equals(o);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
