package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.bcb.facade.ManagedObjectIdReply;
import com.ossnms.bicnet.bcb.facade.security.SecurityDomainIdItem;
import com.ossnms.bicnet.bcb.facade.security.SecurityDomainItem;
import com.ossnms.bicnet.bcb.facade.security.SecurityDomainMarkableItem;
import com.ossnms.bicnet.bcb.facade.security.SecurityDomainReply;
import com.ossnms.bicnet.bcb.model.security.ISecurityDomain;
import com.ossnms.bicnet.bcb.model.security.ISecurityDomainId;
import com.ossnms.bicnet.bcb.model.security.ISecurityDomainMarkable;
import com.ossnms.bicnet.securitymanagement.api.common.utils.AbstractManagedObjectFacade;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import org.apache.commons.lang.NotImplementedException;

import java.util.List;

/**
 *
 */
public class SecurityDomainFacade
        extends AbstractManagedObjectFacade<DCDomainData, ISecurityDomainId, ISecurityDomain, ISecurityDomainMarkable, SecurityDomainReply, ManagedObjectIdReply> {

    @Override
    protected List<DCDomainData> getList() {
        return DCSubsystemSAP.getAllDomains();
    }

    @Override
    protected DCDomainData getSingleItem(ISecurityDomainId id) {
        return DCSubsystemSAP.getDomain(id.getName());
    }

    @Override
    protected ISecurityDomain toItem(DCDomainData data) {
        SecurityDomainItem domainItem = new SecurityDomainItem();
        domainItem.setName(data.getDomainName());
        domainItem.setDescription(data.getDomainDescr());
        return domainItem;
    }

    @Override
    protected ISecurityDomainId toIdItem(DCDomainData data) {
        return new SecurityDomainIdItem(data.getDomainName());
    }

    @Override
    protected ISecurityDomainMarkable toMarkableItem(DCDomainData data) {
        ISecurityDomainMarkable markable = new SecurityDomainMarkableItem(toItem(data));
        markable.markDescription(true);
        markable.markName(true);

        return markable;
    }

    @Override
    protected SecurityDomainReply toItemReply(boolean eof, ISecurityDomain[] items) {
        return new SecurityDomainReply(
                items,
                eof,
                items.length > 0 ? items[items.length - 1].getSecurityDomainId() : null
        );
    }

    @Override
    protected ManagedObjectIdReply toIdReply(boolean eof, ISecurityDomainId[] ids) {
        throw new NotImplementedException();
    }

    @Override
    protected boolean matchesFilter(ISecurityDomainMarkable filter, ISecurityDomain data) {
        if(filter.isMarkedName() && !data.getName().matches(filter.getName())){
            return false;
        }

        return !(filter.isMarkedDescription() && !data.getDescription().matches(filter.getDescription()));

    }
}
