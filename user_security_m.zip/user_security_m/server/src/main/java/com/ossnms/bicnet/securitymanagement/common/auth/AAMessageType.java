/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AAMessageType
 * Author      	Jogender Singh
 * Substitute	Babu B
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.AUTHENTHICATE.USER
 *        TNMS.DX2.SM.PASSWORD.CHANGE 
 *
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 10-Feb-2005	Asif 			CF001104 - Administrator accounts lockout duration is not working
 * 16-Feb-2005	Asif 			CF000995 - Password Expiration Interval
 * 16-Feb-2005	Asif 			CF001006 - "Make user change inital password after ...Days" doesn't work properly
 * 14-Apr-2005	Muyeen Munaver	CF001025	Stop the Server - message to the clients
 * 09-10-2007   Shrinidhi G V   CF004512-07  Improvement for server side filtering
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.auth;

import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;

/**
 * This class stores all the primitives used by DC internally across the client
 * and the server for its messages
 */
public final class AAMessageType {

    /**
     * Message primitives for User Successful logon
     */
    public static final USMBaseMsgType AA_NOTIFICATION_SERVER_SHUTDOWN =
            new USMBaseMsgType("AA_NOTIFICATION_SERVER_SHUTDOWN");

    /**
     * Message primitives for User Successful logon
     */
    public static final USMBaseMsgType AA_NOTIFICATION_USER_LOGGEDIN =
            new USMBaseMsgType("AA_NOTIFICATION_USER_LOGGEDIN");

    /**
     * Message primitives for Un-Successful User logon
     */
    public static final USMBaseMsgType AA_NOTIFICATION_USER_LOGIN_FAILED =
            new USMBaseMsgType("AA_NOTIFICATION_USER_LOGIN_FAILED");

    /**
     * Message primitives for Unsuccessful User logon because of
     * communication issues with Active Directory
     */
    public static final USMBaseMsgType AA_NOTIFICATION_ACTIVE_DIRECTORY_DOWN =
            new USMBaseMsgType("AA_NOTIFICATION_ACTIVE_DIRECTORY_DOWN");

    /**
     * Message primitives for Un-Successful User logon
     */
    public static final USMBaseMsgType AA_NOTIFICATION_USER_PASSWORD_CHANGED =
            new USMBaseMsgType("AA_NOTIFICATION_USER_PASSWORD_CHANGED");

    /**
     * Message primitives for User Successful logoff
     */
    public static final USMBaseMsgType AA_NOTIFICATION_USER_LOGGEDOUT =
            new USMBaseMsgType("AA_NOTIFICATION_USER_LOGGEDOUT");

    /**
     * Message primitives for a User being forcefully logged off by Administrator
     */
    public static final USMBaseMsgType AA_NOTIFICATION_USER_FORCE_LOGOUT =
            new USMBaseMsgType("AA_NOTIFICATION_USER_FORCE_LOGOUT");

    /**
     * Message primitives for a User being forcefully logged off due to trial license expiration
     */
    public static final USMBaseMsgType AA_NOTIFICATION_USER_FORCE_LOGOUT_TRIAL_EXPIRED =
            new USMBaseMsgType("AA_NOTIFICATION_USER_FORCE_LOGOUT_TRIAL_EXPIRED");


    /**
     * Message primitives for User Successfull change password
     */
    public static final USMBaseMsgType AA_RESPONSE_USER_CHANGEPASSWORD =
            new USMBaseMsgType("AA_RESPONSE_USER_CHANGEPASSWORD");

    /**
     * Message primitive for Securable Object Retrieval
     */
    public static final USMBaseMsgType AA_REQUEST_SECURABLE_OBJECTS =
            new USMBaseMsgType("AA_REQUEST_SECURABLE_OBJECTS");

    /**
     * Message primitive for Securable Object Retrieval
     */
    public static final USMBaseMsgType AA_RESPONSE_SECURABLE_OBJECTS =
            new USMBaseMsgType("AA_RESPONSE_SECURABLE_OBJECTS");
    /**
     * Message primitive for Securable Object Retrieval
     */
    public static final USMBaseMsgType AA_USER_PROFILE_REQUEST =
            new USMBaseMsgType("AA_USER_PROFILE_REQUEST");
    /**
     * Message primitive for Securable Object Retrieval
     */
    public static final USMBaseMsgType AA_USER_PROFILE_SET_RESPONSE =
            new USMBaseMsgType("AA_USER_PROFILE_RESPONSE");

    /**
     * Message primitive for Securable Object Retrieval
     */
    public static final USMBaseMsgType AA_USER_PROFILE_REMOVE_RESPONSE =
            new USMBaseMsgType("AA_USER_PROFILE_REMOVE_RESPONSE");

    /**
     * Message primitive for server version and product type Retrieval
     */
    public static final USMBaseMsgType AA_GET_SERVER_VERSION_PRODUCT_RESPONSE =
            new USMBaseMsgType("AA_GET_SERVER_VERSION_PRODUCT_RESPONSE");

    /**
     * Message primitive for Securable Object Retrieval
     */
    public static final USMBaseMsgType AA_USER_PROFILE_GET_RESPONSE =
            new USMBaseMsgType("AA_USER_PROFILE_RESPONSE");

    /**
     * Message primitive for user profile Retrieval
     */
    public static final USMBaseMsgType AA_NOT_PROFILE_UPDATED =
            new USMBaseMsgType("AA_NOT_PROFILE_UPDATED");

    /**
     * Message primitive for user profile Retrieval
     */
    public static final USMBaseMsgType AA_NOT_PROFILE_DELETED =
            new USMBaseMsgType("AA_NOT_PROFILE_DELETED");

    /**
     * Message primitive for user login attempt
     */
    public static final USMBaseMsgType AA_NOTIFICATION_USER_LOGIN_ATTEMPT =
            new USMBaseMsgType("AA_NOTIFICATION_USER_LOGIN_ATTEMPT");

    /**
     * Creates a new instance of AAMessageType
     */
    private AAMessageType() {
    }
}