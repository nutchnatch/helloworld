/*
 * --------------------------------------------------------
 *
 * Project: TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   GSGeneralSettingSLSBFacadeBean
 * Author:      Jogender
 * Substitute   Babu B
 * Created on   13-10-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.ADVISORY_CONFIGURE
 *        : TNMS.DX2.SM.PASSWORD.COMPLEXITY
 * 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.general;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.bicnet.securitymanagement.common.general.ResponseMessage;
import com.ossnms.bicnet.securitymanagement.common.general.ldap.LDAPConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.radius.configuration.RadiusConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.radius.status.RadiusServerStatus;
import com.ossnms.bicnet.securitymanagement.common.general.radius.status.RadiusTestConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.sso.SSOConfigurationData;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityGeneralSettingPrivateFacadeLocal;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityGeneralSettingPrivateFacadeRemote;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

/**
 * It is a bean interface by which general setting data can be retrieved and
 * updated. Client calls interface methods to perform operation. All request
 * will be delegated to corresponding POJO class to process the request.
 **/
@Stateless(name = "GSGeneralSettingSLSBFacade")
@Local(ISecurityGeneralSettingPrivateFacadeLocal.class)
@Remote(ISecurityGeneralSettingPrivateFacadeRemote.class)
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class GSGeneralSettingSLSBFacadeBean implements ISecurityGeneralSettingPrivateFacadeLocal, ISecurityGeneralSettingPrivateFacadeRemote {

	/**
	 * POJO for all business logic
	 */
	private final GSGeneralSettingPOJOImpl objUAdminPOJO = new GSGeneralSettingPOJOImpl();

	/**
	 * {@inheritDoc}
	 */
	@Override
	public GSGeneralSettingData getGeneralSettingData(ISessionContext sessionContext) throws BcbSecurityException {
		return this.objUAdminPOJO.getGeneralSettingData(sessionContext);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public ResponseMessage setGeneralSettingData(ISessionContext sessionContext, GSGeneralSettingData generalSettingData) throws BcbException {
		return this.objUAdminPOJO.setGeneralSettingData(sessionContext, generalSettingData);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public RadiusServerStatus testRadiusServer(ISessionContext sessionContext, RadiusTestConfigurationData configurationData) throws BcbSecurityException{
		return this.objUAdminPOJO.testRadiusServer(sessionContext, configurationData);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public SSOConfigurationData getSingleSignOnData() throws BcbSecurityException {
		return this.objUAdminPOJO.getSingleSignOnData();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public LDAPConfigurationData getLdapConfigurationData() throws BcbSecurityException {
		return this.objUAdminPOJO.getLdapConfigurationData();
	}

	/**
	 * {@inheritDoc}
	 */
    @Override
    public USMMessage getPasswordVerificationRulesConfigurationData() throws BcbSecurityException {
        return this.objUAdminPOJO.getPasswordVerificationRulesConfigurationData();
    }

	/**
	 * {@inheritDoc}
	 */
	@Override
	public RadiusConfigurationData getRadiusConfigurationData() throws BcbSecurityException {
		return this.objUAdminPOJO.getRadiusConfigurationData();
	}
}