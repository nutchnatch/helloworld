/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCInvalidNameException
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CREATE   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.securitymanagement.common.domain.DCException;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;

/**
 * This exception is thrown to indicate an invalid domain name
 * Domain name is invalid, if it begins or ends with space. has more than 64
 * characters
 * Contains characters \/<>:*|?"#
 */
class DCInvalidNameException extends DCException {

    private static final long serialVersionUID = 1L;

    /**
	 * Constructor
	 */
	public DCInvalidNameException() {

		super(
			DCMessages.getInstance().getString(
				DCMessages.DC_DOMAIN_NAME_INVALID));
	}

	/**
	*	Creates a new instance of DCInvalidNameException
	*	@param reason  The user descriptive string associated with the Exception
	*/
	public DCInvalidNameException(String reason) {
		super(reason);
	}
}
