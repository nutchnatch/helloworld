package com.ossnms.bicnet.securitymanagement.server.auth;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.securitymanagement.api.persistence.dao.profile.IUSMProfileDao;
import com.ossnms.bicnet.securitymanagement.api.server.profile.IProfileWrapper;
import com.ossnms.bicnet.securitymanagement.persistence.model.profile.USMProfile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.ejb.Local;
import javax.ejb.Stateless;
import java.util.*;

/**
 * This class abstracts all request DB operations to Profile Information.
 */

@Stateless(name = "IProfileWrapper")
@Local
public class AAProfileWrapper implements IProfileWrapper {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(AAProfileWrapper.class);

	private static final String UNIQUE_CHAR = "ççç";

	private static final String UNIQUE_STR = ";;;";

	@EJB
	@SuppressWarnings("unassigned")
	private IUSMProfileDao usmProfileDao;

	/**
	 * Converts given properties object into string format to store in DB.
	 * 
	 * @param prop
	 *            - profile data for Cf in format of java properties format
	 * @return String - String format of given properties object
	 */
	private String convertPropertiesToString(Properties prop) {

		LOGGER.debug("convertPropertiesToAttribute Enter : " + prop);

		StringBuilder stringProp = new StringBuilder();

		if (prop != null) {
			Enumeration e = prop.propertyNames();

			while (e.hasMoreElements()) {
				try {
					String strName = (String) e.nextElement();
					String strValue = prop.getProperty(strName);
					if ((strName != null) && (strValue != null)) {
						stringProp.append(strName + UNIQUE_CHAR + strValue + UNIQUE_STR);
					} else {
						LOGGER.warn("Some of the entries in the properties object are null. " + strName + " : " + strValue);
					}
				} catch (Exception ex) {
					LOGGER.error("Exception : ", ex);
				}
			}
		}

		if (stringProp.length() == 0) {
			stringProp.append("");
		}

		LOGGER.debug("Exiting convertPropertiesToAttribute. Returning : " + stringProp.toString());

		return stringProp.toString();
	}

	/**
	 * Converts given string object into Properties format to send back to
	 * client.
	 * 
	 * @param properties
	 *            - String format of properties object
	 * @return Properties - profile data in format of java properties format
	 */
	private Properties convertStringToProperties(String properties) {

		LOGGER.debug("convertAttributeToProperties Enter : " + properties);

		Properties prop = new Properties();

		if (properties != null && !properties.isEmpty()) {

			for (String str : properties.split(UNIQUE_STR)) {

				int idx = str.indexOf(UNIQUE_CHAR);

				if (idx != -1) {
					String strKey = str.substring(0, idx);
					String strValue = str.substring(idx + UNIQUE_STR.length());
					prop.setProperty(strKey, strValue);
				} else {
					LOGGER.warn("Someone tampered with profile data");
				}

			}
		} else {
			LOGGER.warn("Null List passed in convertAttributeToProperties.");
		}

		LOGGER.debug("convertAttributeToProperties Exiting. Returning : " + prop);

		return prop;
	}

	@Override
	public Map<String, Properties> getProfile(ISessionContext session) {

		LOGGER.debug("getProfile(" + session + ")		Entry");

		if (session == null) {
			LOGGER.error("getProfile Failed session is Null ");
			return null;
		}

		Map<String, Properties> profileData = new HashMap<>();
		List<USMProfile> result = null;

		try {
			String username = getUniqueUsername((IEnhancedSessionContext) session);
			result = usmProfileDao.findByUser(username);
		} catch (EJBException e) {
			LOGGER.debug("Can't find User\n");
		}

		if (result != null){
			for (USMProfile usmProfile : result) {
				Properties profleProp = convertStringToProperties(usmProfile.getProperties());
				LOGGER.debug("NAME :" + usmProfile.getUserId() + " Description :" + profleProp);
				profileData.put(usmProfile.getAppUid(), profleProp);
			}
		}
	

		LOGGER.debug("getProfile Exit. Returning : " + profileData);

		return profileData;

	}

	@Override
	public boolean setProfile(ISessionContext session, String appUID, Properties profile) {

		LOGGER.debug("createProfile(" + session + ")		Entry");

		if (session == null || appUID == null) {
			LOGGER.error("setProfile Failed session or appUID is Null ");
			return false;
		}
		// get the username into uppercase
		String username = getUniqueUsername((IEnhancedSessionContext) session);

		USMProfile usmProfile = null;
		boolean bStatus = false;

		try {
			usmProfile = usmProfileDao.findByUserAndAppUid(username, appUID);
			LOGGER.debug("Update Profile");
			bStatus = (usmProfile != null);
		} catch (EJBException e) {
			LOGGER.debug("Create New Prfile");
		}

		if (!bStatus) {
			usmProfile = new USMProfile(username, appUID, convertPropertiesToString(profile));
		} else {
			usmProfile.setProperties(convertPropertiesToString(profile));
		}

		bStatus = false;

		try {
			if(usmProfileDao.save(usmProfile) != null){
                LOGGER.debug("Save Profile");
                bStatus = true;
            }
		} catch (EJBException e) {
			LOGGER.error("Create Profile Failed\n" + e.getMessage());
		}

		LOGGER.debug("createProfile Exit. Returning : " + bStatus);

		return bStatus;
	}

	@Override
	public boolean deleteUserProfileContainer(String userID) {

		LOGGER.debug("deleteUserProfileContainer(" + userID + ")    Enter");

		if (userID == null) {
			LOGGER.error("deleteUserProfileContainer Failed userID is Null ");
			return false;
		}

		boolean bStatus = false;
		List<USMProfile> result = null;

		try {
			result = usmProfileDao.findByUser(userID.toUpperCase());
			LOGGER.debug("Delete NAME :" + userID.toUpperCase());
			bStatus = true;
		} catch (EJBException e) {
			LOGGER.error("deleteUserProfileContainer: User not found\n");
		}

		if (result != null){
            if(result.isEmpty()){
                return false;
            }

			for (USMProfile usmProfile : result) {
				LOGGER.debug("Delete NAME :" + usmProfile.getUserId() + " Description :" + usmProfile.getProperties());
				try {
					usmProfileDao.delete(usmProfile.getId());
					bStatus = true;
				} catch (EJBException e) {
					LOGGER.error("Delete User Profile Container Failed\n" + e.getMessage());
					bStatus = false;
					break;
				}
			}
		}

		LOGGER.debug("deleteUserProfileContainer Exit :: Return :" + bStatus);

		return bStatus;

	}

	@Override
	public boolean removeUserProfile(ISessionContext session, String appUID) {

		LOGGER.debug("removeUserProfile(" + session + " , " + appUID + ")    Enter");

		if (session == null || appUID == null) {
			LOGGER.error("Create Profile Failed session or appUID is Null ");
			return false;
		}

		String username = getUniqueUsername((IEnhancedSessionContext) session);

		LOGGER.debug("removeUserProfile(" + username + "," + appUID + ")    Enter");
		boolean bStatus = false;
		USMProfile usmProfile = null;

		
		try {
			usmProfile = usmProfileDao.findByUserAndAppUid(username, appUID);
			bStatus = (usmProfile != null);
		} catch (EJBException e) {
			LOGGER.debug("User not found\n");
		}
		
		if(!bStatus){
            LOGGER.debug("Profile not found.");
			return bStatus;
		}else{
            LOGGER.debug("Delete NAME :" + usmProfile.getUserId() + " Description :" + usmProfile.getProperties());
        }


		try {
			usmProfileDao.delete(usmProfile.getId());
			bStatus = true;
		} catch (EJBException e) {
			LOGGER.error("Delete Profile Failed\n" + e.getMessage());
		}

		LOGGER.debug("removeUserProfile Exit :: Return :" + bStatus);

		return bStatus;
	}

	private String getUniqueUsername(IEnhancedSessionContext objSessionContext) {
		return objSessionContext.getUserName().toUpperCase();
	}
}
