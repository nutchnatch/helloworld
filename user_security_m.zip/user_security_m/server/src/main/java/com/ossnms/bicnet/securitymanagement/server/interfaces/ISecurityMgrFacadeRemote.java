package com.ossnms.bicnet.securitymanagement.server.interfaces;

import com.ossnms.bicnet.bcb.facade.security.ISecurityMgrFacade;

public interface ISecurityMgrFacadeRemote extends ISecurityMgrFacade{	
}