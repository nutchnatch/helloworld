package com.ossnms.bicnet.securitymanagement.common.general.sso;

import java.io.Serializable;

/**
 * This class will be used as a DTO, between client and server,
 * regarding to Kerberos configuration, either for Authentication and Authorization
 * purposes. For Authorization, this class holds too the information regarding
 * to Active Directory, in order to retrieve information about user groups for TNMS Users.
 */
public final class SSOConfigurationData implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final String FORMAT_STRING = "\nDomain name = %s\nActive Directory Server = %s\nTCP/IP port = %s\nTNMS principal name = %s\nIs SSO enabled = %s\n";

    /**
     * Check if SSO is enabled in order activate in server side
     */
    private boolean isEnabled;

    /**
     * Domain name in which the Kerberos and LDAP is available to perform SSO authentication. This is case sensitive.
     */
    private String domainName;

    /**
     * FQDN or IP address of Active Directory server for authentication and authorization purposes.
     */
    private String domainServer;


    /**
     * Domain name supplied in uppercase (e.g. OCEANS.SEVEN.DOMAIN).
     */
    private String krbDomainName;

    /**
     * TCP/IP port where the LDAP of the Active Directory is listening.
     */
    private String ldapTcpPort;

    /**
     * Principal name defined in Active Directory for TNMS server. This must be equal to the principal used by keytab.
     */
    private String tnmsPrincipalName;

    public SSOConfigurationData() {
    }

    public SSOConfigurationData(String domainName, String domainServer, String ldapTcpPort, String tnmsPrincipalName, boolean isEnabled) {
        this.domainName = domainName;
        this.domainServer = domainServer;
        this.krbDomainName = domainName.toUpperCase();
        this.ldapTcpPort = ldapTcpPort;
        this.tnmsPrincipalName = tnmsPrincipalName;
        this.isEnabled = isEnabled;
    }

    public boolean isEnabled() {
        return isEnabled;
    }

    public void setEnabled(boolean isEnabled) {
        this.isEnabled = isEnabled;
    }


    public String getDomainName() {
        return this.domainName;
    }

    public String getDomainServer() {
        return this.domainServer;
    }

    public String getKrbDomainName() {
        return this.krbDomainName;
    }

    public String getLdapTcpPort() {
        return this.ldapTcpPort;
    }


    @Override
    public String toString() {
        return String.format(FORMAT_STRING, this.domainName, this.domainServer, this.ldapTcpPort, this.tnmsPrincipalName, this.isEnabled);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((tnmsPrincipalName == null) ? 0 : tnmsPrincipalName.hashCode());
        result = prime * result + ((domainName == null) ? 0 : domainName.hashCode());
        result = prime * result + ((domainServer == null) ? 0 : domainServer.hashCode());
        result = prime * result + (isEnabled ? 1231 : 1237);
        result = prime * result + ((ldapTcpPort == null) ? 0 : ldapTcpPort.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        SSOConfigurationData other = (SSOConfigurationData) obj;
        if (tnmsPrincipalName == null) {
            if (other.tnmsPrincipalName != null) {
                return false;
            }
        } else if (!tnmsPrincipalName.equals(other.tnmsPrincipalName)) {
            return false;
        }
        if (domainName == null) {
            if (other.domainName != null) {
                return false;
            }
        } else if (!domainName.equals(other.domainName)) {
            return false;
        }
        if (domainServer == null) {
            if (other.domainServer != null) {
                return false;
            }
        } else if (!domainServer.equals(other.domainServer)) {
            return false;
        }
        if (isEnabled != other.isEnabled) {
            return false;
        }
        if (ldapTcpPort == null) {
            if (other.ldapTcpPort != null) {
                return false;
            }
        } else if (!ldapTcpPort.equals(other.ldapTcpPort)) {
            return false;
        }

        return true;
    }
}
