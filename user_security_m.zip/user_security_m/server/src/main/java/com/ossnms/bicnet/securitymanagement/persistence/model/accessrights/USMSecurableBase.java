package com.ossnms.bicnet.securitymanagement.persistence.model.accessrights;

import com.ossnms.bicnet.securitymanagement.persistence.model.BaseUSMEntity;

import javax.persistence.*;

/**
 * Securable Object Base
 */
@MappedSuperclass
public class USMSecurableBase extends BaseUSMEntity {

    private static final long serialVersionUID = -2820167191143879134L;

    @Id
    @Column(name = "UNIQUE_NAME", nullable = false)
    private String uniqueName;

    @Column(name = "NAME", nullable = false)
    private String name;

    @Column(name = "TYPE")
    private int type;

    @ManyToOne
    @JoinColumn(name = "CF_ID", nullable = false)
    private USMCF cf;

    @Column(name = "ICON_ID")
    private String iconId;

    public USMSecurableBase() {}

    public USMSecurableBase(String uniqueName, String name, int type, String iconId) {
        this.uniqueName = uniqueName;
        this.name = name;
        this.type = type;
        this.iconId = iconId;
    }

    @Override
    public boolean isNew() {
        return false;
    }

    public String getUniqueName() {
        return uniqueName;
    }

    public void setUniqueName(String uniqueName) {
        this.uniqueName = uniqueName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getIconId() {
        return iconId;
    }

    public void setIconId(String iconId) {
        this.iconId = iconId;
    }

    public USMCF getCf() {
        return cf;
    }

    public void setCf(USMCF cf) {
        this.cf = cf;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        USMSecurableBase that = (USMSecurableBase) o;

        if (type != that.type) {
            return false;
        }
        if (!cf.equals(that.cf)) {
            return false;
        }
        if (iconId != null ? !iconId.equals(that.iconId) : that.iconId != null) {
            return false;
        }
        if (!name.equals(that.name)) {
            return false;
        }
        return uniqueName.equals(that.uniqueName);

    }

    @Override
    public int hashCode() {
        int result = uniqueName.hashCode();
        result = 31 * result + name.hashCode();
        result = 31 * result + type;
        result = 31 * result + cf.hashCode();
        result = 31 * result + (iconId != null ? iconId.hashCode() : 0);
        return result;
    }
}
