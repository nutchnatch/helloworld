package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.bcb.facade.security.NMSecurityMappingsIdItem;
import com.ossnms.bicnet.bcb.facade.security.NMSecurityMappingsItem;
import com.ossnms.bicnet.bcb.facade.security.NMSecurityMappingsMarkableItem;
import com.ossnms.bicnet.bcb.facade.security.NMSecurityMappingsReply;
import com.ossnms.bicnet.bcb.facade.security.SecurityDomainIdItem;
import com.ossnms.bicnet.bcb.facade.security.SecurityUserGroupIdItem;
import com.ossnms.bicnet.bcb.model.IManagedObjectIdReply;
import com.ossnms.bicnet.bcb.model.security.INMSecurityMappings;
import com.ossnms.bicnet.bcb.model.security.INMSecurityMappingsId;
import com.ossnms.bicnet.bcb.model.security.INMSecurityMappingsMarkable;
import com.ossnms.bicnet.bcb.model.security.ISecurityDomainId;
import com.ossnms.bicnet.bcb.model.security.ISecurityUserGroupId;
import com.ossnms.bicnet.bcb.model.security.ISecurityUserId;
import com.ossnms.bicnet.bcb.model.security.NMPrivilegeLevel;
import com.ossnms.bicnet.securitymanagement.api.common.utils.AbstractManagedObjectFacade;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionItemData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.bicnet.securitymanagement.server.policy.PASubsystemSAP;
import com.ossnms.bicnet.securitymanagement.server.useradministration.UASubsystemSAP;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


/**
 *
 */
public class NMSecurityMappingFacade extends AbstractManagedObjectFacade<DCDomainMapping, INMSecurityMappingsId, INMSecurityMappings, INMSecurityMappingsMarkable, NMSecurityMappingsReply, IManagedObjectIdReply>{

    /**
     *
     * @return
     */
    @Override
    protected List<DCDomainMapping> getList() {
        List<DCDomainMapping> allMappings = DCSubsystemSAP.getAllDomainMappings();
        List<DCDomainMapping> filteredMappings = new ArrayList<>(allMappings.size());

        for(DCDomainMapping mapping : allMappings) {
            int policyId = mapping.getPolicyID();
            PAPolicyData policyData = PASubsystemSAP.getPolicyData(policyId);

            if(policyData == null) {
                continue;
            }

            for(NodeManagerPermission permission : NodeManagerPermission.values()) {
                if (containsPermissionItem(policyData, permission.getPermission())) {
                    filteredMappings.add(mapping);
                }
            }
        }

        return filteredMappings;
    }

    /**
     *
     * @param id instance of type <MOID>
     * @return
     */
    @Override
    protected DCDomainMapping getSingleItem(INMSecurityMappingsId id) {
        return null;
    }

    @Override
    protected INMSecurityMappings toItem(DCDomainMapping data) {
        INMSecurityMappings mapping = new NMSecurityMappingsItem();

        NodeManagerPermission permissionToSet = null;
        PAPolicyData policyData = PASubsystemSAP.getPolicyData(data.getPolicyID());

        if(policyData != null) {
            for(NodeManagerPermission permission : NodeManagerPermission.values()) {
                if (containsPermissionItem(policyData, permission.getPermission())) {
                    permissionToSet = permission;
                    break;
                }
            }
        }

        //Set PrivilegeLevel
        if(permissionToSet == null){
            return null;
        }

        mapping.setPrivilegeLevel(permissionToSet.getNmPrivilegeLevel());

        //Set Security Domain
        DCDomainData domainData = DCSubsystemSAP.getDomain(data.getDomainID());
        ISecurityDomainId securityDomain = new SecurityDomainIdItem(domainData.getDomainName());
        mapping.setSecurityDomain(securityDomain);

        //Set Security User Group
        ISecurityUserGroupId userGroupId = new SecurityUserGroupIdItem(data.getUserGroup());
        mapping.setUserGroup(userGroupId);

        return mapping;
    }

    @Override
    protected INMSecurityMappingsId toIdItem(DCDomainMapping data) {
        return new NMSecurityMappingsIdItem(data.getUserGroup(), DCSubsystemSAP.getDomain(data.getDomainID()).getDomainName());
    }

    @Override
    protected INMSecurityMappingsMarkable toMarkableItem(DCDomainMapping data) {
        INMSecurityMappings mapping = toItem(data);
        INMSecurityMappingsMarkable markable = new NMSecurityMappingsMarkableItem(mapping);

        markable.markPrivilegeLevel(true);
        markable.markSecurityDomainName(true);
        markable.markUserGroupName(true);

        return markable;
    }

    @Override
    protected NMSecurityMappingsReply toItemReply(boolean eof, INMSecurityMappings[] items) {
        return new NMSecurityMappingsReply(
                items,
                eof,
                items.length > 0 ? items[items.length - 1].getNMSecurityMappingsId() : null
        );
    }

    @Override
    protected IManagedObjectIdReply toIdReply(boolean eof, INMSecurityMappingsId[] ids) {
        return null;
    }

    @Override
    protected boolean matchesFilter(INMSecurityMappingsMarkable filter, INMSecurityMappings data) {
        if(filter.isMarkedPrivilegeLevel() && !data.getPrivilegeLevel().equals(filter.getPrivilegeLevel())){
            return false;
        }

        if(filter.isMarkedSecurityDomainName() && !data.getSecurityDomainName().matches(filter.getSecurityDomainName())) {
            return false;
        }

        return !(filter.isMarkedUserGroupName() && !data.getUserGroupName().matches(filter.getUserGroupName()));
    }

    /**
     * Returns a Facade that allows to retrieve information filtered by a user Group
     *
     * @param securityUserGroup the SecurityUserGroupId instance
     * @return an instance of NMSecurityMappingFacade with an overridden getList() method
     */
    public static NMSecurityMappingFacade getFilteredFacade(final ISecurityUserGroupId securityUserGroup){
        return new NMSecurityMappingFacade(){
            @Override
            protected List<DCDomainMapping> getList() {
                List<DCDomainMapping> allMappings = DCSubsystemSAP.getAllDomainMappings();
                List<DCDomainMapping> filteredMappings = new ArrayList<>(allMappings.size());

                for(DCDomainMapping mapping : allMappings) {
                    if(!mapping.getUserGroup().equals(securityUserGroup.getName())){
                        continue;
                    }

                    int policyId = mapping.getPolicyID();
                    PAPolicyData policyData = PASubsystemSAP.getPolicyData(policyId);

                    if(policyData == null) {
                        continue;
                    }

                    for(NodeManagerPermission permission : NodeManagerPermission.values()) {
                        if (containsPermissionItem(policyData, permission.getPermission())) {
                            filteredMappings.add(mapping);
                        }
                    }
                }

                return filteredMappings;
            }
        };
    }

    /**
     *
     * @param securityUserId
     * @return
     */
    public static NMSecurityMappingFacade getFilteredFacade(final ISecurityUserId securityUserId){
        return new NMSecurityMappingFacade(){
            @Override
            protected List<DCDomainMapping> getList() {
                List<DCDomainMapping> allMappings = super.getList();
                // ensure that there are no duplicates
                Set<DCDomainMapping> filteredMappings = new HashSet<>();

                List<String> groups = UASubsystemSAP.getAllUserGroupNameForUser(securityUserId.getUsername());

                for(DCDomainMapping mapping : allMappings) {
                    if(!groups.contains(mapping.getUserGroup())){
                        continue;
                    }

                    filteredMappings.add(mapping);
                }

                return new ArrayList<>(filteredMappings);
            }
        };
    }


    /**
     * The enum which contains the mapping between TPLauncher Menu Items and NMPrivilegeLevel
     */
    private enum NodeManagerPermission {
        ADMINISTRATION  ("Third Party->Node Manager->Administration", NMPrivilegeLevel.LEVEL1),
        POWER_USER      ("Third Party->Node Manager->Power User",     NMPrivilegeLevel.LEVEL2),
        COMMISSIONER    ("Third Party->Node Manager->Commissioner",   NMPrivilegeLevel.LEVEL3),
        READ_ONLY       ("Third Party->Node Manager->Read Only",      NMPrivilegeLevel.LEVEL4);

        private String tnmsActionItem;
        private NMPrivilegeLevel nmPrivilegeLevel;

        NodeManagerPermission(String permisssion, NMPrivilegeLevel nmPrivilegeLevel) {
            this.tnmsActionItem = permisssion;
            this.nmPrivilegeLevel = nmPrivilegeLevel;
        }

        /**
         *
         * @return TNMS action Item
         */
        public String getPermission() {
            return tnmsActionItem;
        }

        /**
         *
         * @return NM Privilege Level
         */
        public NMPrivilegeLevel getNmPrivilegeLevel() {
            return nmPrivilegeLevel;
        }
    }

    /**
     * Returns an empty reply
     *
     * @return an empty reply
     */
    protected boolean containsPermissionItem(PAPolicyData policyData, String permissionItem){
        for(PAPermissionData permissionData : policyData.getPermissionDataList()){
            if(containsPermissionItem(permissionData, permissionItem)){
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if the specified permission contains a specified permission item name
     *
     * @param permissionData the permission data
     * @param permissionItem the string which represents the permission item
     * @return true if the permission contains said permission item, false otherwise.
     */
    private boolean containsPermissionItem(PAPermissionData permissionData, String permissionItem){
        for(PAPermissionItemData permissionItemData : permissionData.getPermissionItems()){
            if(permissionItemData.getName().equals(permissionItem)){
                return true;
            }
        }
        return false;
    }
}
