package com.ossnms.bicnet.securitymanagement.server.basic.notification;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.licensing.ILicenseKeyId;
import com.ossnms.bicnet.bcb.model.platform.Notification;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.bicnet.messaging.layering.listener.BiCNetLayeringMessageListener;
import org.apache.log4j.Logger;

/**
 *
 */
public final class USMMessageListener extends BiCNetLayeringMessageListener {
	protected static final Logger LOGGER = Logger.getLogger(USMMessageListener.class);

	private static final USMMessageListener instance = new USMMessageListener();

	public static USMMessageListener getInstance(){
		return instance;
	}

	private USMMessageListener(){

	}

	@Override
	protected void onLayerMessage(ISessionContext sessionContext, IBiCNetMessage message, IBiCNetMessageDispatcher dispatcher) throws BcbException {
		LOGGER.debug("onMessage got a new message from dispatcher: " + message);

		Object obj = message.getObject();
		if (obj instanceof Notification[]) {
			Notification[] notifications = (Notification[]) message.getObject();
			for (Notification notification : notifications) {
				if (notification instanceof ObjectDeletion) {
					onObjectDeletion(sessionContext, (ObjectDeletion) notification);
				}
			}
		}
	}

	/**
	 *
	 * @param sessionContext
	 * @param notif
     */
	private void onObjectDeletion(ISessionContext sessionContext, ObjectDeletion notif) {
		IManagedObjectId moId = notif.getDeletedObject();
		if (moId instanceof ILicenseKeyId) {
			ExternalUSMNotificationHandler.getInstance().handleLicenseDeletion(sessionContext, (ILicenseKeyId) moId);
		}
	}
}
