/*
 * --------------------------------------------------------
 *
 * Copyright (C) Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 */
package com.ossnms.bicnet.securitymanagement.common.useradministration;
import java.io.Serializable;

/**
 * A Transient Serializable class containing all data for a User Account for importing/exporting.
 */
public class UAIEUser extends UAUser implements Serializable {

    private static final long serialVersionUID = 1L;

    private String userClass;
	/**
	 * Default constructor
	 *
	 */
	public UAIEUser() {
	}

	/**
	 * Returns the user class association
	 * @return Object - type of user class
	 */
	public String getUserClass() {
		return userClass;
	}

	/**
	 * Sets the user class association
	 * @param userClass - type of user class
	 */
	public void setUserClass(String userClass) {
		this.userClass = userClass;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
    public int hashCode() {
		return getUserId().hashCode();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
    public boolean equals(Object obj) {
		boolean bEquals = false;
		int hc = hashCode();
		if ((obj != null) && (obj instanceof UAIEUser)) {
			UAIEUser usr = (UAIEUser) obj;
			int other = usr.hashCode();
			bEquals = (hc == other);
		}
		return bEquals;
	}

}
