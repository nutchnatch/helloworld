/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMServerLifeCycleControllerIfc
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 05-May-2005  Muyeen Munaver  CF001312   Master-Master Replication for Sun ONE DS
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.basic;

/**
 * This is the base interface for all the Client side Life cycle controllers.
 * Methods like initialize and cleanup are defined in this interface
 */
public interface USMServerLifeCycleControllerIfc {

	/**
	 * Method which gets called when the subsystem is getting intialized. 
	 * All subsystem initialization are done here. This is a single point of entry for 
	 * subsystems.
	 * @return boolean  Subsystem should return true when successfully initialized
	 */
	boolean initialize();

	/**
	 * Method which gets called when the subsystem has to be 
	 * cleaned up. All subsystem cleanup are done here.
	 * @return boolean  Subsystem should return true after a successfull cleanup
	 */
	boolean cleanup();

	/**
	 * Method which gets called when the subsystem has to be
	 * reinitialized.
	 * @return boolean Subsystem should return true if successfully re-initialized.
	 */
	boolean reinitialize();

}
