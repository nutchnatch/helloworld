/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AADummyLocalSecurityProviderFacadeImpl
 * Author      	Muyeen Munaver
 * Substitute	
 * Created on	24-11-2004
 *
 * --------------------------------------------------------
  * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	CR
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 * 14-June-2005  Muyeen Munaver  CF002457 - Manual Export not working
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.auth;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ILocalSecurityProviderFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.securitymanagement.common.auth.AASessionContext;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import org.apache.log4j.Logger;

/**
 This class provides the funcationality for creating and returning System context 
 to be used by in ejb server by Scheduler and NBI interfaces
 */
public final class AADummyLocalSecurityProviderFacadeImpl
	implements ILocalSecurityProviderFacade {

	/**
	 * Data member to hold logger for the class
	 */
	private static final Logger logger = Logger.getLogger(AADummyLocalSecurityProviderFacadeImpl.class);

	/**
	* Holds singleton instance
	*/
	private static final AADummyLocalSecurityProviderFacadeImpl instance = new AADummyLocalSecurityProviderFacadeImpl();
	
	/**
	 * Data member to hold the Dummy Server context.
	 */
	private static final IEnhancedSessionContext dummyServerContext = USMCommonHelper.getDummySessionContext("Server Context");

	/**
	* prevents instantiation
	*/
	private AADummyLocalSecurityProviderFacadeImpl() {
		// prevent creation
	}

	/**
	 * Returns the singleton instance.
	 * @return	the singleton instance
	 */
	public static AADummyLocalSecurityProviderFacadeImpl getInstance() {
		return instance;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.server.auth.ILocalSecurityProviderFacade#getSystemAccountContext()
	 */
	@Override
    public ISessionContext getSystemAccountContext() {
		if (logger.isDebugEnabled()) {
			logger.debug("getSystemAccountContext() Called : Returning :" + dummyServerContext);
		}
		return ((AASessionContext) dummyServerContext).toSessionContext();
	}

}
