package com.ossnms.bicnet.securitymanagement.api.server.profile;

import java.util.Map;
import java.util.Properties;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;

/**
 * created on 9/9/2014
 */
public interface IProfileWrapper {

	/**
	 * It retrieves user profile data which user has been set
	 * 
	 * @param session
	 *            - Session token created at the time of login for the user.
	 * @return Map - User client profile data
	 */
	Map<String, Properties> getProfile(ISessionContext session);

	/**
	 * It creates the profile container for storing user profiles
	 */

	boolean setProfile(ISessionContext session, String appUID, Properties profile);

	/**
	 * Deletes the user profile container on deletion of the user
	 * 
	 * @param userID
	 *            - User id for that profile container has to be deleted
	 * @return Boolean - Status of the operation. If container is deleted
	 *         successfully then true else false.
	 */
	boolean deleteUserProfileContainer(String userID);

	/**
	 * It removes the user profile data which user has been set
	 * 
	 * @param session
	 *            - Session token created at the time of login for the user.
	 * @param appUID
	 *            - CF unique identifier .
	 * @return boolean - if User client profile is updated successfully in DS
	 *         then it returns true else false
	 */
	boolean removeUserProfile(ISessionContext session, String appUID);

}
