package com.ossnms.bicnet.securitymanagement.common.general.ldap;

import com.ossnms.bicnet.securitymanagement.common.auth.LDAPSearchScope;

import java.io.Serializable;
import java.util.Objects;

/**
 * This class will be used as a DTO, containing configuration regarding LDAP Authentication
 */
public final class LDAPConfigurationData implements Serializable{

    private static final long serialVersionUID = -291234159839955350L;

    private boolean
            enabled,
            isSslIndicator;

    private String
            host,
            port,
            searchAccount,
            searchPassword,
            userSearchBase,
            userSearchFilter,
            userIdAttribute,
            groupSearchBase,
            groupSearchFilter,
            groupIdAttribute,
            groupMemberAttribute;

    private LDAPSearchScope
            userSearchScope,
            groupSearchScope;

    /**
     *
     */
    public LDAPConfigurationData(){

    }

    /**
     *
     * @param enabled
     * @param isSslIndicator
     * @param host
     * @param port
     * @param searchAccount
     * @param searchPassword
     * @param userSearchBase
     * @param userSearchFilter
     * @param userSearchScope
     * @param userIdAttribute
     * @param groupSearchBase
     * @param groupSearchFilter
     * @param groupSearchScope
     * @param groupIdAttribute
     * @param groupMemberAttribute
     */
    public LDAPConfigurationData(
            boolean enabled,
            boolean isSslIndicator,
            String host,
            String port,
            String searchAccount,
            String searchPassword,
            String userSearchBase,
            String userSearchFilter,
            LDAPSearchScope userSearchScope,
            String userIdAttribute,
            String groupSearchBase,
            String groupSearchFilter,
            LDAPSearchScope groupSearchScope,
            String groupIdAttribute,
            String groupMemberAttribute
    ) {
        this.enabled = enabled;
        this.isSslIndicator = isSslIndicator;
        this.host = host;
        this.port = port;
        this.searchAccount = searchAccount;
        this.searchPassword = searchPassword;
        this.userSearchBase = userSearchBase;
        this.userSearchFilter = userSearchFilter;
        this.userSearchScope = userSearchScope;
        this.userIdAttribute = userIdAttribute;
        this.groupSearchBase = groupSearchBase;
        this.groupSearchFilter = groupSearchFilter;
        this.groupSearchScope = groupSearchScope;
        this.groupIdAttribute = groupIdAttribute;
        this.groupMemberAttribute = groupMemberAttribute;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isSslIndicator() {
        return isSslIndicator;
    }

    public void setSslIndicator(boolean sslIndicator) {
        isSslIndicator = sslIndicator;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getPort() {
        return port;
    }

    public int getPortAsInt(){
        return Integer.parseInt(port);
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getSearchAccount() {
        return searchAccount;
    }

    public void setSearchAccount(String searchAccount) {
        this.searchAccount = searchAccount;
    }

    public String getSearchPassword() {
        return searchPassword;
    }

    public void setSearchPassword(String searchPassword) {
        this.searchPassword = searchPassword;
    }

    public String getUserSearchBase() {
        return userSearchBase;
    }

    public void setUserSearchBase(String userSearchBase) {
        this.userSearchBase = userSearchBase;
    }

    public String getUserSearchFilter() {
        return userSearchFilter;
    }

    public void setUserSearchFilter(String userSearchFilter) {
        this.userSearchFilter = userSearchFilter;
    }

    public LDAPSearchScope getUserSearchScope() {
        return userSearchScope;
    }

    public void setUserSearchScope(LDAPSearchScope userSearchScope) {
        this.userSearchScope = userSearchScope;
    }

    public String getGroupSearchBase() {
        return groupSearchBase;
    }

    public void setGroupSearchBase(String groupSearchBase) {
        this.groupSearchBase = groupSearchBase;
    }

    public String getGroupSearchFilter() {
        return groupSearchFilter;
    }

    public void setGroupSearchFilter(String groupSearchFilter) {
        this.groupSearchFilter = groupSearchFilter;
    }

    public LDAPSearchScope getGroupSearchScope() {
        return groupSearchScope;
    }

    public void setGroupSearchScope(LDAPSearchScope groupSearchScope) {
        this.groupSearchScope = groupSearchScope;
    }

    public String getUserIdAttribute() {
        return userIdAttribute;
    }

    public void setUserIdAttribute(String userIdAttribute) {
        this.userIdAttribute = userIdAttribute;
    }

    public String getGroupIdAttribute() {
        return groupIdAttribute;
    }

    public void setGroupIdAttribute(String groupIdAttribute) {
        this.groupIdAttribute = groupIdAttribute;
    }

    public String getGroupMemberAttribute() {
        return groupMemberAttribute;
    }

    public void setGroupMemberAttribute(String groupMemberAttribute) {
        this.groupMemberAttribute = groupMemberAttribute;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof LDAPConfigurationData)) return false;
        LDAPConfigurationData that = (LDAPConfigurationData) o;
        return isEnabled() == that.isEnabled() &&
                isSslIndicator() == that.isSslIndicator() &&
                Objects.equals(getHost(), that.getHost()) &&
                Objects.equals(getPort(), that.getPort()) &&
                Objects.equals(getSearchAccount(), that.getSearchAccount()) &&
                Objects.equals(getSearchPassword(), that.getSearchPassword()) &&
                Objects.equals(getUserSearchBase(), that.getUserSearchBase()) &&
                Objects.equals(getUserSearchFilter(), that.getUserSearchFilter()) &&
                Objects.equals(getUserSearchScope(), that.getUserSearchScope()) &&
                Objects.equals(getUserIdAttribute(), that.getUserIdAttribute()) &&
                Objects.equals(getGroupSearchBase(), that.getGroupSearchBase()) &&
                Objects.equals(getGroupSearchFilter(), that.getGroupSearchFilter()) &&
                Objects.equals(getGroupSearchScope(), that.getGroupSearchScope()) &&
                Objects.equals(getGroupIdAttribute(), that.getGroupIdAttribute()) &&
                Objects.equals(getGroupMemberAttribute(), that.getGroupMemberAttribute());
    }

    @Override
    public int hashCode() {
        return Objects.hash(isEnabled(), isSslIndicator(), getHost(), getPort(), getSearchAccount(), getSearchPassword(), getUserSearchBase(), getUserSearchFilter(), getUserSearchScope(), getUserIdAttribute(), getGroupSearchBase(), getGroupSearchFilter(), getGroupSearchScope(), getGroupIdAttribute(), getGroupMemberAttribute());
    }
}
