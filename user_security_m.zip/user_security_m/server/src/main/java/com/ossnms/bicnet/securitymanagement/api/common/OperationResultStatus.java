package com.ossnms.bicnet.securitymanagement.api.common;

/**
 *
 */
public enum OperationResultStatus {

    OK,
    UNAUTHORIZED,
    FORBIDDEN,
    INTERNAL_ERROR

}
