/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AAChangePasswordDetails
 * Author      	Jogender Singh
 * Substitute	Babu B
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.PASSWORD.CHANGE
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.common.auth;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;

/**
 * This class holds the data of User transiently.
 * Whenever Change password request is fired from client side,
 * this class object will be populated and sends over the network.
 * On server side, data will be extracted and change password operation will get performed
 */
public class AAChangePasswordDetails implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(AAChangePasswordDetails.class);

    /**
     * User id used to login in system
     */
    private String userName;
    /**
     * Server host address where user has logged in
     */
    private String serverName;
    /**
     * Password used to login in system
     */
    private String oldPassword;
    /**
     * New Password
     */
    private String newPassword;

    /**
     * Default Constructor
     */
    public AAChangePasswordDetails() {
    }

    /**
     * Constructor
     *
     * @param userId - User id
     * @param oldPass - Old password
     * @param newPass - New password
     */
    public AAChangePasswordDetails(
            String userId,
            String host,
            String oldPass,
            String newPass) {

        if (LOGGER.isDebugEnabled()) {
            String str =
                    "AAChangePasswordDetails(User id - "
                            + userId
                            + ", From Host - "
                            + host
                            + " Entry";
            LOGGER.debug(str);
        }

        this.userName = userId;
        this.serverName = host;
        this.oldPassword = oldPass;
        this.newPassword = newPass;
        LOGGER.debug(
                "AAChangePasswordDetails(String userId,String host, String oldPass, String newPass) 	Exit");
    }

    /**
     * Returns the new password
     *
     * @return String - password set will be returned
     */
    public String getNewPassword() {
        return newPassword;
    }

    /**
     * Returns the old password
     *
     * @return String  -old password set will be returned
     */
    public String getOldPassword() {
        return oldPassword;
    }

    /**
     * Returns the server name
     *
     * @return String - Server Host address
     */
    public String getServerName() {
        return serverName;
    }

    /**
     * returns the user name
     *
     * @return String - user name
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets new password*
     *
     * @param newPass - new password
     */
    public void setNewPassword(String newPass) {
        this.newPassword = newPass;
    }

    /**
     * Sets old password
     *
     * @param oldPass - old password
     */
    public void setOldPassword(String oldPass) {
        this.oldPassword = oldPass;
    }

    /**
     * Sets server name
     *
     * @param serverName - Server name
     */
    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    /**
     * Sets user name
     *
     * @param username - user name
     */
    public void setUserName(String username) {
        this.userName = username;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "User ID : " + userName + " : Server Name : " + serverName;
    }

}
