package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.securitymanagement.api.common.USMConstants;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserGroup;
import com.ossnms.bicnet.securitymanagement.server.bicnetserver.BSSubsystemSAP;
import com.ossnms.bicnet.securitymanagement.server.policy.PASubsystemSAP;
import com.ossnms.bicnet.securitymanagement.server.useradministration.UASubsystemSAP;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * This class is responsible for making all calls to external subsystems for
 * getting object data or for getting policies or getting user groups etc. It
 * interacts with subsystem like BS or PA or UG/UA
 */
public class DCExternalInterface {

	private static final PAPolicyId NO_VISIBILITY = USMConstants.POLICY_NO_VISIBILITY;

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(DCExternalInterface.class);

	/**
	 * Gets the list of all configured policies
	 *
	 */
	static List<PAPolicyId> getPolicies() {
		LOGGER.debug("getPolicies() - Enter");

		List<PAPolicyId> policyNameIdsPair = new ArrayList<>();
		List<PAPolicyData> policies = PASubsystemSAP.getAllPolicies();

		LOGGER.debug("The policies are {}", policies);

		//I only need, the policy name and id, other things are not of relevance to me
		policyNameIdsPair.addAll(
				policies
						.stream()
						.map(policy -> new PAPolicyId(policy.getPolicyID(), policy.getPolicyName()))
						.collect(Collectors.toList()));

		//NO_VISIBILITY is a system policy and should be added
		policyNameIdsPair.add(NO_VISIBILITY);

		LOGGER.info("The number of policies which were fetched were {}", policyNameIdsPair.size());
		LOGGER.debug("getPolicies() - Enter");

		return policyNameIdsPair;
	}

	/**
	 * Get the list of network elements for the given server(CF).
	 *  Needed when a new server is inserted
	 * @param pCfInfo The server(CF) for which the objects are requested
	 * @param pSecurableObjects The vector of BSTransSecObjectInfo of the given
	 * server(CF).
	 */
	static void getSecurableObjects(BSTransBicNetCFInfo pCfInfo, List<BSSecurableObject> pSecurableObjects, int domainId) {
		LOGGER.debug("getSecurableObjects() - Enter");

		//Ask BS to give the objects for the server
		if (domainId == 0) {
			// if it is domain id == 0, then it's the global domain. Return them all
			BSSubsystemSAP.getSecurableObjects(pCfInfo, pSecurableObjects);
		} else {
			BSSubsystemSAP.getSecurableObjects(pCfInfo, pSecurableObjects, domainId);
		}

		LOGGER.info("getSecurableObjects() :: Sec Objects of server that were received are {}, server name being {}",
				pSecurableObjects.size(),
				pCfInfo
		);

		LOGGER.debug("getSecurableObjects() - Exit");
	}

	/**
	 * Sets the domain for the given list of objects. Sec obj can be assigend and
	 * unassigned from the domain. A value of true indicates that the domain
	 * has to be assigned to that NE and a value of false indicates that the
	 * domain has to be unassigned to that NE.
	 * @param pVecNetElem Vector of ASTransNEInfo that have to be assigned/unassigned to.
	 * @param pDomain The domain to which the NEs are assigned/unassigned to.
	 * @param pSet boolean to indicate whether the NEs have to be assigned or unassigned true value indicates NEs to be
	 *             assigned to the domain.
	 * @return boolean Returns true if it is was successfull in setting domains of the Network element.
	 */
	static boolean setDomainOfSecurableObjects(List<BSSecurableObject> pVecNetElem, DCDomainData pDomain, boolean pSet) {
		LOGGER.debug("setDomainOfSecurableObjects() - Exit");

		//Only the domain id is what is valid and checked by BS
		//Failed objects meaning that some objects were deleted, no special
		//handling in this case for DC
		//The result given by DC suggests if some error occured or not

		boolean result;
		List<BSSecurableObject> failedObjects = new ArrayList<>();
		String traceStr;

		if (pSet) {
			traceStr = "Setting Objects of Domain ";
			result = BSSubsystemSAP.setDomainForSecObjs(pVecNetElem, pDomain, failedObjects);
		} else {
			traceStr = "UnSetting Objects of Domain ";
			result = BSSubsystemSAP.unsetDomainForSecObjs(pVecNetElem, pDomain, failedObjects);
		}

		if (LOGGER.isInfoEnabled()) {
			traceStr += pDomain + ".Numbmer of objects being - " + pVecNetElem.size();
			LOGGER.info("setDomainOfSecurableObjects - " + traceStr);
		}

		LOGGER.debug("setDomainOfSecurableObjects() - Exit");
		return result;
	}

	/**
	 * Gets the list of assigned objects for a particaular domain. This is needed
	 * for displaying in the configuartion domain window.
	 * @param pDomainId The domain id for which the objects have to be fetched
	 * @param pAssignedObjects Vector of BSTransSecObjectInfo that belong to the domain
	 */
	public static void getAssignedObjectsOfDomain(int pDomainId, List<BSSecurableObject> pAssignedObjects) {
		LOGGER.debug("getAssignedObjectsOfDomain() - Entry");
		List<BSSecurableObject> objectsOfServer = new ArrayList<>();

		DCDomainData domain = new DCDomainData("", pDomainId, 1, "");

		List<BSTransBicNetCFInfo> servers = getAllServers();

        for (BSTransBicNetCFInfo server : servers) {
            objectsOfServer.clear();
            getSecurableObjectsOfDomainForServer(domain, server, true, objectsOfServer);

			LOGGER.debug("Objects for the domain with domain ID for server : {} are {}", pDomainId, objectsOfServer.size());
			if(objectsOfServer.size() > 0){
				pAssignedObjects.addAll(objectsOfServer);
			}
		}

		LOGGER.info("Objects for the domain with domain ID : {} are {}", pDomainId, pAssignedObjects.size());
		LOGGER.debug("getAssignedObjectsOfDomain() - Exit");
	}

	/**
	 * This method is called to inform BS that the domain has been deleted
	 * 
	 * @param pDomain The domain that has been deleted.
	 */
	static void domainDeleted(DCDomainData pDomain) {
		LOGGER.debug("domainDeleted() - Entry");

		List<BSSecurableObject> objectsOfDomain = new ArrayList<>();
		//Get the list of objects
		getAssignedObjectsOfDomain(pDomain.getDomainID(), objectsOfDomain);
		//Get the list of objects from BS and unassign all objects from this domain
		//The third parameter is not of interest to us.
		List<BSSecurableObject> unSuccessfulObjects = new ArrayList<>();

		LOGGER.info("domainDeleted() - No of objects for which ACL has to be reset for the domain {} are {}", pDomain, objectsOfDomain.size());
		BSSubsystemSAP.unsetDomainForSecObjs(objectsOfDomain, pDomain, unSuccessfulObjects);

		LOGGER.debug("domainDeleted() - Exit");
	}

	/**
	 * This method gets all the global user group from UA/UG. 
	 * We need a list of fully qualified user groups and we get it.
	 * @return String[] Returns array of fully qualified user group.
	 */
	static String[] getGlobalUserGroups() {
		LOGGER.debug("getGlobalUserGroups() - Entry");

		List<UAUserGroup> userGrps = UASubsystemSAP.getAllUserGroups();
		String[] str = new String[userGrps.size()];

		for (int i = 0; i < userGrps.size(); ++i) {
			str[i] = userGrps.get(i).getName();
		}

		LOGGER.info("getGlobalUserGroups() - The number of user groups fetched from UG are {}", str.length);
		LOGGER.debug("getGlobalUserGroups() - The user groups fetched are {}", Arrays.toString(str));
		LOGGER.debug("getGlobalUserGroups() - Exit");
		return str;
	}

	/**
	 * This method gets all the servers which have been configured within the
	 * global security. This is needed, as it is very long wait on the client
	 * to get all the objects of say..global domain or otherwise. So first we show
	 * all the servers(CF) and then when the user clicks on the server(CF) node to
	 * expand, the list of objects are later fetched for the domain
	 * @return Returns The list of servers(CF) which have been 
	 * inserted into security.
	 */
	static List<BSTransBicNetCFInfo> getAllServers() {
		LOGGER.debug("getAllServers() - Entry");
		
		List<BSTransBicNetCFInfo> commonFunctions = BSSubsystemSAP.getAllConfiguredCFs();

		LOGGER.info("The number of CFs retrieved are {}", commonFunctions.size());
		LOGGER.debug("The CFs retrieved are {}", commonFunctions);
		LOGGER.debug("getAllServers() - Exit");
		return commonFunctions;
	}

	/**
	 * This method return the list of all securable object that exist on server.
	 * The securable object will have information regarding to the common function that it belongs. Is id and is display name.
	 * The acl will say witch domain he belongs. The acl 0 refers to global domain the other ids refers to domain name.
	 * The list of securable object container will have all the information of is containers.
	 * 
	 * @return list - securable object list
	 */
	static List<BSSecurableObject> getAllSecurableObjects() {
		return  BSSubsystemSAP.getAllSecurableObjects();
	}
	
	/**
	 * This method gets all the sec objects of a given server. After the objects
	 * are fetched, this method checks whether the objects are part of the
	 * domain and only if the objects are part of the domain the list of objects
	 * are populated.
	 * @param domain The domain for which the objects are requested.
	 * @param commonFunction The server whose objects are requested.
	 * @param assign True value to indicate to fetch the elements belonging to
	 * domain and false to indicate to fetch elements not belonging to the domain.
	 * @param objects The objects of the retreived server which belong to the
	 * given domain.
	 * @return Returns true on successful retrievation of objects.
	 */
	static boolean getSecurableObjectsOfDomainForServer(DCDomainData domain, BSTransBicNetCFInfo commonFunction, boolean assign, List<BSSecurableObject> objects) {
		LOGGER.debug("getSecurableObjectsOfDomainForServer() - Entry");

		List<BSSecurableObject> serverObjects = new ArrayList<>();
		getSecurableObjects(commonFunction, serverObjects, domain.getDomainID());

		//Iterate through the list to get the objects of this domain
		//Now push the assigned objects
		//Be sure what you are changing here
		objects.addAll(
				serverObjects
		);

		LOGGER.info("getSecurableObjectsOfDomainForServer() - Objects for the domain with domain ID : {} are {}", domain, objects.size());
		LOGGER.debug("getSecurableObjectsOfDomainForServer() - Exit");
		return true;
	}

	/**
	 * Helper function to retrieve the list of first level node for the list of
	 * network elements for this domain. Since first the server tree is listed
	 * and later on when the user clicks on the server node, the network
	 * elements need to be displayed. This method returns the list of servers
	 * only in the first step.
	 * @param pDomain The domain for which the securable objects are requested.
	 * @param pAssign True if the securable objects are assigned to the domain
	 * @return List - Returns a vector of ASTransAppServerInfo.
	 */
	static List<BSTransBicNetCFInfo> getFirstLevelDetailsForDomain(DCDomainData pDomain, boolean pAssign) {
		LOGGER.debug("getFirstLevelDetailsForDomain() - Enter");
		//Servers to send to the client
		List<BSTransBicNetCFInfo> serverListToSend = new ArrayList<>();
		//List of ASTransAppServerInfo
		List<BSTransBicNetCFInfo> servers = DCExternalInterface.getAllServers();
		//Get the Nes of this servers. If this server contains atleast one NE(it could
		//be a domain manager, in which case, it does not contain any NEs) or it could so happen
		//that the domain doesnot contain any NE from this server.
		for (BSTransBicNetCFInfo server : servers) {
			//This is just to find whether we need to send this server details to the
			//client or not. Discard the details. As keeping it, would un necessary have
			//a toll on the server memory.
			if(DCExternalInterface.hasSecurableObjectsOfDomainForServer(pDomain, server, pAssign)){
				serverListToSend.add(server);
			}
		}

		LOGGER.info("getFirstLevelDetailsForDomain() - Number of first level server objects for the domain with domain ID : {} are {}",
				pDomain,
				serverListToSend.size()
		);

		LOGGER.info("getFirstLevelDetailsForDomain() - First level server objects for the domain with domain ID : {} are {}", pDomain, serverListToSend);
		LOGGER.debug("getFirstLevelDetailsForDomain() - Exit");
		return serverListToSend;
	}

	/**
	 *
	 * @param pDomain
	 * @param server
	 * @param pAssign
     * @return
     */
	private static boolean hasSecurableObjectsOfDomainForServer(DCDomainData pDomain, BSTransBicNetCFInfo server, boolean pAssign) {
		if(pDomain.getDomainID() == 0){
			if(pAssign){
				return BSSubsystemSAP.getSecurableObjectsCount(server) > 0;
			} else {
				return BSSubsystemSAP.getSecurableObjectsCount(server) == 0;
			}
		} else {
			if(pAssign){
				return BSSubsystemSAP.getSecurableObjectsCount(server, pDomain.getDomainID()) > 0;
			} else {
				return BSSubsystemSAP.getSecurableObjectsCount(server, pDomain.getDomainID()) == 0;
			}
		}


	}
}
