/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMServerLifeCycleControllerIfc
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 18-01-2005	Asif		CF001111 - Login Failure - Internal error occured Check the traces and try again.
 * 14-Apr-2005	Muyeen Munaver	CF001025   Stop the Server - message to the clients
 * 05-May-2005  Muyeen Munaver  CF001312   Master-Master Replication for Sun ONE DS
 * 26-May-2005  Muyeen Munaver  CF002374 - USM Erros/Exceptions during server start-up
 * 26-July-2007 Shrinidhi       CF004514 - User operations possible before Initialization is finished
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.basic;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.securitymanagement.server.IScsControllableImpl;
import com.ossnms.bicnet.securitymanagement.server.servicelocator.USMServiceLocator;
import com.ossnms.bicnet.servicelocator.BiCNetServiceLocator;
import com.ossnms.bicnet.util.UnexpectedException;
import org.apache.log4j.Logger;

/**
 * Represents a singleton. This class is responsible for initialization
 * of the Basic subsytem.
 */
public final class USMServerLifeCycleController
	implements USMServerLifeCycleControllerIfc {

	/**
	 * Data member to hold the Logger.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(USMServerLifeCycleController.class);
	/**
	* Holds singleton instance
	*/
	private static USMServerLifeCycleController instance = new USMServerLifeCycleController();

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.server.basic.USMServerLifeCycleControllerIfc#initialize()
	 */
	public boolean initialize() {
		LOGGER.debug("Entering initialize");
		// Register the Service Locator
		try {
			BiCNetServiceLocator bcbsl = BiCNetServiceLocator.getInstance();
			USMServiceLocator secMgmtServiceLocator =
				USMServiceLocator.getInstance();
			bcbsl.registerServiceLocator(
				BiCNetComponentType.SECURITY_MANAGER,
				secMgmtServiceLocator);

			initialize = true;
		} catch (Exception ex) {
			LOGGER.error(ex);
		}

		LOGGER.debug("Exiting initialize");
		return true;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.server.basic.USMServerLifeCycleControllerIfc#cleanup()
	 */
	public boolean cleanup() {
		return true;
	}

	/**
	* prevents instantiation
	*/
	private USMServerLifeCycleController() {
	}

	/**
	* Returns the singleton instance.
	 @return	the singleton instance
	*/
	public static USMServerLifeCycleController getInstance() {
		return instance;
	}

	/**
	 * Field to indicate that USM has been properly/completely initialized
	 */
	private boolean initialize = false;

	/**
	 * Gets the current state of initialization of USM
	 */
	public synchronized boolean isInitialized() {
		
		// Check for the complete TNMS Server is up and running 
		// If this is true then only allow login to TNMS Client else dont allow the login...
		// First get the local session context to give to @P SCS as at server start up we will still not have a valid session
		// context.	
		boolean initialized = false;
		
		if(initialize){
			
            ISessionContext ctx = IScsControllableImpl.getLocalSecurityProviderFacade().getSystemAccountContext();

            try {
                try {
                    LOGGER.debug("Calling the SCS Control Facade to fetch the Server Initialization State");
                    initialized = USMServiceLocator.getInstance().getSCSControlFacade().isServerInitialized(ctx);
                    LOGGER.debug("Is Initialized ?"+initialized);
                } catch (BcbException e) {
                    LOGGER.error("BCB Exception while checking for server is initialized", e);
                }
            } catch (UnexpectedException e) {
                LOGGER.error("Un expected Exception while checking for server is initialized", e);
            }
            LOGGER.debug("Server Initialized completely or not: -" + "DX Complete Server Status "+initialized+"USM Server Status" +initialize);
	    }else{
		    LOGGER.debug("USM itself is not completely initialized and hence log in is not allowed"+initialize);
	    }
		return initialize && initialized;
	}

	/**
	 * Sets the current state of the initialization of USM
	 */
	public synchronized void setInitialized(boolean initialized, String reason) {
		initialize = initialized;

		//Ideally trace statements are not needed to be synchronized,
		//but since this will not be called very often(mostly once)
		//it is okay to have these trace statements inside the sync function

		LOGGER.info(
			"State of USM initialization state changed to "
				+ initialized
				+ " for reason"
				+ reason);
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.server.basic.USMServerLifeCycleControllerIfc#reinitialize()
	 */
	public boolean reinitialize() {
		return true;
	}

}
