package com.ossnms.bicnet.securitymanagement.common.useradministration;

import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;

/**
 * Enum for the types of accounts from external sources which can be created on TNMS
 */
public enum UAUserAccountType {

    SSO(
            USMCommonStrings.IDS_AA_USER_CREATE_USER_PERFORMED,
            USMCommonStrings.IDS_AA_USER_CREATE_USER_NOT_PERFORMED,
            USMCommonStrings.IDS_AA_USER_MODIFY_GROUPS_PERFORMED,
            USMCommonStrings.IDS_AA_USER_MODIFY_GROUPS_NOT_PERFORMED,
            UAAuthenticationType.SSO
    ),
    LDAP(
            USMCommonStrings.IDS_AA_LDAP_USER_CREATE_USER_PERFORMED,
            USMCommonStrings.IDS_AA_LDAP_USER_CREATE_USER_NOT_PERFORMED,
            USMCommonStrings.IDS_AA_LDAP_USER_MODIFY_GROUPS_PERFORMED,
            USMCommonStrings.IDS_AA_LDAP_USER_MODIFY_GROUPS_NOT_PERFORMED,
            UAAuthenticationType.LDAP
    ),
    RADIUS(
            USMCommonStrings.IDS_AA_RADIUS_USER_CREATE_USER_PERFORMED,
            USMCommonStrings.IDS_AA_RADIUS_USER_CREATE_USER_NOT_PERFORMED,
            USMCommonStrings.IDS_AA_RADIUS_USER_MODIFY_GROUPS_PERFORMED,
            USMCommonStrings.IDS_AA_RADIUS_USER_MODIFY_GROUPS_NOT_PERFORMED,
            UAAuthenticationType.RADIUS
    );

    private String
            creationSuccessMessage,
            creationFailureMessage,
            modificationSuccessMessage,
            modificationFailureMessage;

    private UAAuthenticationType authenticationType;

    /**
     *
     * @param creationSuccessMessage
     * @param creationFailureMessage
     * @param modificationSuccessMessage
     * @param modificationFailureMessage
     * @param authenticationType
     */
    UAUserAccountType(
            String creationSuccessMessage,
            String creationFailureMessage,
            String modificationSuccessMessage,
            String modificationFailureMessage,
            UAAuthenticationType authenticationType){
        this.creationSuccessMessage = creationSuccessMessage;
        this.creationFailureMessage = creationFailureMessage;
        this.modificationSuccessMessage = modificationSuccessMessage;
        this.modificationFailureMessage = modificationFailureMessage;
        this.authenticationType = authenticationType;
    }

    /**
     *
     * @return
     */
    public String getCreationSuccessMessage() {
        return creationSuccessMessage;
    }

    /**
     *
     * @param creationSuccessMessage
     */
    public void setCreationSuccessMessage(String creationSuccessMessage) {
        this.creationSuccessMessage = creationSuccessMessage;
    }

    /**
     *
     * @return
     */
    public String getCreationFailureMessage() {
        return creationFailureMessage;
    }

    /**
     *
     * @param creationFailureMessage
     */
    public void setCreationFailureMessage(String creationFailureMessage) {
        this.creationFailureMessage = creationFailureMessage;
    }

    /**
     *
     * @return
     */
    public String getModificationSuccessMessage() {
        return modificationSuccessMessage;
    }

    /**
     *
     * @param modificationSuccessMessage
     */
    public void setModificationSuccessMessage(String modificationSuccessMessage) {
        this.modificationSuccessMessage = modificationSuccessMessage;
    }

    /**
     *
     * @return
     */
    public String getModificationFailureMessage() {
        return modificationFailureMessage;
    }

    /**
     *
     * @param modificationFailureMessage
     */
    public void setModificationFailureMessage(String modificationFailureMessage) {
        this.modificationFailureMessage = modificationFailureMessage;
    }

    /**
     *
     * @return
     */
    public UAAuthenticationType getAuthenticationType() {
        return authenticationType;
    }

    /**
     *
     * @param authenticationType
     */
    public void setAuthenticationType(UAAuthenticationType authenticationType) {
        this.authenticationType = authenticationType;
    }
}
