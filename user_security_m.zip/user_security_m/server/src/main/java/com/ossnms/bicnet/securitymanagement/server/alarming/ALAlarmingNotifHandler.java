/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	ALAlarmingNotifHandler
 * Author      	Babu B
 * Substitute	Vinay Purohit
 * Created on	30-11-2004
 *
 * --------------------------------------------------------
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.LOGGING.ALARM
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 13-Jan-05    Babu B          TCM Id 309 Trace statements insufficient in Alarming implementation of USM
 * 14-Feb-05    Babu B          CF001010	Raising/clearing of Alarms - administrator resets the bad password count
 * 14-Feb-05    Babu B          CF001016    Raising/clearing of alarms - user that raised the alarm is deleted!
 * 30-Mar-2005  Babu B          CF001864    Security alarm gets created after one attempt more than the number specified
 * 14-Apr-05    Babu B          CF002017    Clearing alarms -> case sensitive
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.alarming;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.securitymanagement.api.server.basic.notification.INotificationHandler;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import com.ossnms.bicnet.securitymanagement.server.IScsControllableImpl;
import com.ossnms.bicnet.securitymanagement.server.basic.ALAlarmRecordData;
import org.apache.log4j.Logger;

import java.util.Date;

/**
 * This class is the Handler for notification messages within USM-Alarming.
 * 
 * Since in the first step all the components of USM are within one machine, the
 * Authentication and Authorization part need not listen to notifications from the
 * topic. To prevent lag while listening, this class registers with the USMNotifier 
 * for the notifications to be sent as synchronous calls.
 * 
 * Listens to User Lock / Unlock / Delete & other related notifications (synchronous) 
 */

class ALAlarmingNotifHandler implements INotificationHandler {
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER =
        Logger.getLogger(ALAlarmingNotifHandler.class);

    /**
      * Data member for the sole instance of the class.
      */
    private static ALAlarmingNotifHandler self = null;

    /**
     * Static method to get the class instance
     * @return ALAlarmingNotifHandler - static reference for the same class
     */
    public static final synchronized ALAlarmingNotifHandler getInstance() {
        if (null == self) {
            self = new ALAlarmingNotifHandler();
        }
        return self;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.securitymanagement.api.server.basic.notification.INotificationHandler#handleNotification(com.ossnms.bicnet.securitymanagement.common.basic.USMMessage)
     */
    @Override
    public void handleNotification(USMMessage msg) {
        //If USMMessage contains notification for security data changes, security data cache is rebuilt in USMServerCache object on server side. 
        //And notification is sent to client side for rebuilding cache on client side 
        LOGGER.debug("handleNotification(USMMessage pMsg) Entry");

        USMBaseMsgType objMessageType = msg.getMessageType();
        String strMessageType = objMessageType.getMsgType();
        LOGGER.debug("Message type is " + strMessageType);

        if(objMessageType.equals(UAMessageType.S_UA_NOTIFICATION_USER_LOGIN_FAILED)) {
            handleUserLoginFailed(msg);
        } else if (objMessageType.equals(UAMessageType.S_UA_NOT_UNLOCK_USER)) {
            handleUserUnlocked(msg);
        } else if (objMessageType.equals(UAMessageType.S_UA_NOT_REMOVE_USER)) {
            handleUserDeleted(msg);
        }

        LOGGER.debug("handleNotification(USMMessage pMsg) Exit");
    }

    /**
     * Helper method for User Login Failed notification
     * 
     * @param msg
     *      The notification message
     */
    private void handleUserLoginFailed(USMMessage msg) {
        LOGGER.debug("handleUserLoginFailed - Entry");

        ALAlarmingImpl pojo = new ALAlarmingImpl();

        String strUserId = msg.popString().toLowerCase();
        msg.popInteger();
        boolean bAccountLocked = msg.popBoolean();

        if (bAccountLocked) {
            // locate alarm representation in DB
            ALAlarmRecordData objTransAlarm = pojo.locateAlarmRecord(getLocalCtx(), strUserId);

            // if alarm not already sent
            if (objTransAlarm == null) {
                objTransAlarm = new ALAlarmRecordData(strUserId, new Date());
//                // create alarm representation in LDAP
//                ALLWInterface.storeAlarmRecord(null, objTransAlarm);
//                LOGGER.debug("Alarm data successfully stored in LDAP");

                // send new alarm

                pojo.raiseAlarm(getLocalCtx(), objTransAlarm);
                LOGGER.debug("Alarm raise data successfully passed to FM " + objTransAlarm);
            }
        }

        LOGGER.debug("handleUserLoginFailed - Exit");
    }

    /**
     * Helper method for User Unlocked notification
     * 
     * @param msg
     *      The notification message
     */
    private void handleUserUnlocked(USMMessage msg) {
        LOGGER.debug("handleUserUnlocked - Entry");

        ALAlarmingImpl pojo = new ALAlarmingImpl();

        int nUnlockedUserCount = msg.popInteger();
        
        while (nUnlockedUserCount-- > 0) {
            String strUserId = msg.popString().toLowerCase();

            // locate alarm representation in FM
            ALAlarmRecordData objTransAlarm = pojo.locateAlarmRecord(getLocalCtx(), strUserId);

            // if alarm not sent
            if (objTransAlarm == null) {
                objTransAlarm = new ALAlarmRecordData(strUserId, new Date());
            }

            // send cleared alarm
            pojo.clearAlarm(getLocalCtx(), objTransAlarm);
            LOGGER.debug("Alarm clear data successfully passed to FM " + objTransAlarm);
        }

        LOGGER.debug("handleUserUnlocked - Exit");
    }

    /**
      * Helper method for User Deleted notification
      * 
      * @param msg The notification message
      */
    private void handleUserDeleted(USMMessage msg) {
        LOGGER.debug("handleUserDeleted - Entry");

        ALAlarmingImpl pojo = new ALAlarmingImpl();

        int userCount = msg.popInteger();

        while (userCount-- > 0) {
            String strUserId = msg.popString().toLowerCase();
            // locate alarm representation in LDAP
            ALAlarmRecordData objTransAlarm = pojo.locateAlarmRecord(getLocalCtx(), strUserId);

            // if alarm already sent
            if (objTransAlarm != null) {
                pojo.clearAlarm(getLocalCtx(), objTransAlarm);
                LOGGER.debug("Alarm clear data successfully passed to FM " + objTransAlarm);
                
            }
            LOGGER.debug("Alarm data removed from LDAP");
        }

        LOGGER.debug("handleUserDeleted - Exit");
    }

    /**
     * Helper function to get the Local Context of the Server.
     * @return ISessionContext Context of the Server.
     */
    private ISessionContext getLocalCtx() {
        return IScsControllableImpl
            .getLocalSecurityProviderFacade()
            .getSystemAccountContext();
    }

}
