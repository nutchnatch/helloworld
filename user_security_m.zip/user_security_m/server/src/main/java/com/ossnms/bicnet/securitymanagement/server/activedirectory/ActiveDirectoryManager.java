package com.ossnms.bicnet.securitymanagement.server.activedirectory;

import com.ossnms.bicnet.securitymanagement.common.general.sso.SSOConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.ldap.ADElement;
import com.ossnms.bicnet.securitymanagement.common.ldap.ADLDAPManager;
import com.ossnms.bicnet.securitymanagement.server.useradministration.UASubsystemSAP;
import org.apache.log4j.Logger;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.security.auth.Subject;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public final class ActiveDirectoryManager extends ADLDAPManager {

    private static final String SEARCH_FILTER_USER_GROUP = "(&(objectClass=user)(userPrincipalName=%s))";
    private static final String SEARCH_FILTER_GROUP = "(&(objectClass=group)(member=CN=%s,CN=ForeignSecurityPrincipals,%s))";

	private static final String GROUP_NAME_PATTERN = "(CN=(([^,])*))(.*)";

	private static final String LDAP_PROTOCOL = "ldap://";
	private static final String TCP_IP_PORT_PREFIX = ":";

	private static final String ATTR_GROUP_NAME = "distinguishedName";
	private static final String ATTR_USER_GROUP = "memberOf";

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(ActiveDirectoryManager.class);

    /**
     * @param subject
     * @param realm
     * @param kdc
     * @param port
     */
    public ActiveDirectoryManager(Subject subject, String realm, String kdc, String port) {
        super(subject, realm, kdc, port);
    }

	/**
	 * Retrieves user groups from Active Direction for accountName. All user groups are retrieved recursively.
	 */
	public List<String> getUserGroups(String principalName, String objectSID) {
		if(!connect()){
			return new ArrayList<>();
		}

		try {
			Set<String> allGroups = new HashSet<>();

			// Fetch all user groups per principal name
			List<String> userGroups = getGroupsPerPrincipalName(principalName);
	        allGroups.addAll(userGroups);
			// Fetch all user groups per member objectSID
			userGroups = getGroupsPerObjectSID(objectSID);
			allGroups.addAll(userGroups);

	        Deque<String> groupsToProcess = new ArrayDeque<>(allGroups);
	        for (String group = groupsToProcess.poll(); group != null; group = groupsToProcess.poll()) {
				List<String> groupsForGroup = getGroupsForGroup(group);
	        	groupsForGroup.removeAll(allGroups);
	        	allGroups.addAll(groupsForGroup);
	        	groupsToProcess.addAll(groupsForGroup);
	        }

	        // filter and return the returned names by matching them with the available groups
			return allGroups.stream()
					.map(toGroupName())
					.filter(UASubsystemSAP.nameBySupportedGroups())
					.collect(Collectors.toList());
		} catch (NamingException e) {
			LOGGER.error("Error getting groups for user " + objectSID + " from Active Directory", e);
			return new ArrayList<>();
		} finally {
			disconnect();
		}
	}

	/**
	 * Function to map a group cn (from an LDAP server) to a name
	 *
	 * @return
	 */
	private Function<String, String> toGroupName() {
		return group -> {
            Pattern pattern = Pattern.compile(GROUP_NAME_PATTERN, Pattern.CASE_INSENSITIVE);
            Matcher matcher = pattern.matcher(group);
			if(matcher.matches()) {
				return matcher.group(2).trim();
			}

			return null;
        };
	}

	/**
	 *
	 * @param objectSID
	 * @return
	 * @throws NamingException
	 */
	private List<String> getGroupsPerObjectSID(String objectSID) throws NamingException {
		String searchFilter = String.format(SEARCH_FILTER_GROUP, objectSID, getBaseDNSearch(realm));

		SearchControls searchControls = new SearchControls();
		searchControls.setReturningAttributes(new String[] {ATTR_GROUP_NAME});
		searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);

		List<ADElement> foundObjects = new ArrayList<>();

		if (getObjects(EMPTY, EMPTY, EMPTY, getBaseDNSearch(realm), foundObjects, searchFilter, searchControls)) {
			return getGroupsFromGroupLwElement(foundObjects);
		}

		return Collections.emptyList();
	}

    /**
     *
     * @param userPrincipalName the account name (userPrincipalName)
     * @return a list of groups to which the user belongs to
     * @throws NamingException
     */
    private List<String> getGroupsPerPrincipalName(String userPrincipalName) throws NamingException {
    	String searchFilter = String.format(SEARCH_FILTER_USER_GROUP, userPrincipalName);

    	SearchControls searchControls = new SearchControls();
    	searchControls.setReturningAttributes(new String[] {ATTR_USER_GROUP});
    	searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);

    	List<ADElement> foundObjects = new ArrayList<>();

    	if (getObjects(EMPTY, EMPTY, EMPTY, getBaseDNSearch(realm), foundObjects, searchFilter, searchControls)) {
    		return getGroupsFromUserLwElement(foundObjects);
    	}

    	return Collections.emptyList();
	}

    /**
     *
     * @param groupDn
     * @return
     * @throws NamingException
     */
    private List<String> getGroupsForGroup(String groupDn) throws NamingException {
		Attributes attributes = initialLdapContext.getAttributes(groupDn, new String[] { ATTR_USER_GROUP });
		Attribute attribute = attributes.get("memberOf");

		if (attribute == null) {
			return Collections.emptyList();
		}

        List<String> groups = new ArrayList<>();
		NamingEnumeration<?> allValues = attribute.getAll();
		while (allValues.hasMoreElements()) {
			groups.add((String) allValues.nextElement());
		}
		return groups;
    }

    private List<String> getGroupsFromUserLwElement(List<ADElement> foundObjects) throws NamingException {
    	List<String> groups = new ArrayList<>();
    	for (ADElement element : foundObjects) {
    		Attribute attribute = element.getLdapAttributes().get(ATTR_USER_GROUP);
    		if (attribute == null ) {
    			continue;
    		}
    		NamingEnumeration<?> values = attribute.getAll();
    		while (values.hasMoreElements()) {
    			groups.add((String) values.nextElement());
    		}
    	}
    	return groups;
    }

	private List<String> getGroupsFromGroupLwElement(List<ADElement> foundObjects) throws NamingException {
		List<String> groups = new ArrayList<>();
		for (ADElement element : foundObjects) {
			Attribute attribute = element.getLdapAttributes().get(ATTR_GROUP_NAME);
			if (attribute == null ) {
				continue;
			}
			NamingEnumeration<?> values = attribute.getAll();
			while (values.hasMoreElements()) {
				groups.add((String) values.nextElement());
			}
		}
		return groups;
	}

    /**
     * This method is used to validate if the information needed to create a
     * directory context with the Active Directory
     *
     * @return True if all information is available otherwise false.
     */
	private boolean areADPropertiesValid(SSOConfigurationData adConfigData) {
		String domainName = adConfigData.getDomainName();
		String domainServer = adConfigData.getDomainServer();
		return  domainName != null && !domainName.isEmpty() &&
				domainServer != null && !domainServer.isEmpty();
	}

    /**
     *
     * @param domainServer the server where the domain is configured
     * @return the fully formed provider url
     */
    private String getProviderUrl(String domainServer, String port){
        return LDAP_PROTOCOL + domainServer + TCP_IP_PORT_PREFIX + port;
    }

    /**
     *
     * @param domainServer the name of the domain server or the domain name
     * @return the hostname configured for the domain server or the domain name
     */
	public static String getLdapHostName(String domainServer) {
		try {
			return InetAddress.getByName(domainServer).getCanonicalHostName();
		} catch (UnknownHostException e) {
			return domainServer;
		}
	}

}