package com.ossnms.bicnet.securitymanagement.common.useradministration;

/**
 *
 */
public enum UAAuthenticationType {

    LOCAL,
    SSO,
    LDAP,
    RADIUS

}
