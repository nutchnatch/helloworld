package com.ossnms.bicnet.securitymanagement.common.general.radius.configuration;

import com.ossnms.bicnet.securitymanagement.common.general.ResponseMessage;
import com.ossnms.bicnet.securitymanagement.common.general.ResponseType;

/**
 *
 */
public class RadiusSettingsResponseMessage extends ResponseMessage {

    private static final long serialVersionUID = 909262256702381019L;

    public RadiusSettingsResponseMessage() {
    }

    public RadiusSettingsResponseMessage(ResponseType type, String message) {
        super(type, message);
    }

    public RadiusSettingsResponseMessage(ResponseType type, String messageFormat, String... params) {
        super(type, messageFormat, params);
    }

    public RadiusSettingsResponseMessage(ResponseType type, String message, ResponseMessage... messages) {
        super(type, message, messages);
    }
}
