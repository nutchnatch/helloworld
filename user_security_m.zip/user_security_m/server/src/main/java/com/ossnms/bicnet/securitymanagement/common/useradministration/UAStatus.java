/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	UAStatus
 * Author      	Vinay purohit
 * Substitute	Babu B
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER.VIEW
 *       : TNMS.DX2.SM.USER.CREATE
 * 	     : TNMS.DX2.SM.USER.ASSIGN
 *  	 : TNMS.DX2.SM.USER.STATUS
 *       : TNMS.DX2.SM.USER_GROUP.VIEW
 *       : TNMS.DX2.SM.USER_GROUP.CONFIGURE
 *       : TNMS.DX2.SM.USER_GROUP.CREATE
 *       : TNMS.DX2.SM.USER_GROUP.ASSIGN
 *       :
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Muyeen Munaver	CF000427 - Implementation of the XML import mechanism needed for the migration process
 * 18-Mar-2005  Asif khan R     CF001755 Error Messages when LDAP not available
 * 08-Aug-2005	Balasubramanya	CF002760 - 9320_MR_0291 Users, User Groups, Policies lose associations after import
 * 08-Aug-2005	Balasubramanya	CF002759 - 9320_MR_0289 Security information discarded for user after deletion and restore 
 * 17-Aug-2005	Babu			CF002854 - user migration does not work 
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.useradministration;

import java.util.Hashtable;
import java.util.Map;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;

/**
 * This is the class which represents the Status of the operation.
 */
public class UAStatus {
	/**
	 * This error code indicates that the initiated operation failed because of
	 * some internal NON_LOGICAL error.
	 */
	public static final int S_INTERNAL_ERROR = 1;

	/**
	 * This error code indicates that an Error has occurred during performing an
	 * LDAP Operation. The LDAP Operation could be Creation Modification
	 * Deletion of an LDAP Object.
	 */
	public static final int S_LDAP_ERROR = 2;

	/**
	 * Indicates that the Operation initiated has been successful.
	 */
	public static final int S_SUCCESS = 3;

	/**
	 * This error code indicates that there already exists a user with the
	 * same name. 2 users with the same name cannot be existing.
	 */
	public static final int S_USER_ALREADY_EXISTS = 4;

	/**
	 * This error code indicates that the user that has been selected to be
	 * deleted from LDAP has already been deleted.
	 */
	public static final int S_USER_DOES_NOT_EXIST = 5;

	/**
	 * This error code indicates that the user selected to be deleted cannot
	 * be deleted since it is currently logged on.
	 */
	public static final int S_USER_CANNOT_BE_DELETED_SINCE_CURRENTLY_LOGGED_IN =
		6;

	/**
	 * This error code indicates that the Maximum number of users allowed
	 * for creation is exceeded.
	 */
	public static final int S_USER_MAXIMUM_LIMIT_REACHED = 7;

	/**
	 * This error code indicates that the user name is empty or invalid
	 */
	public static final int S_USER_NAME_EMPTY_OR_INVALID = 9;
	/**
	 * This error code indicates that the user name is invalid
	 */
	public static final int S_USER_CANNOT_CREATED_PASSWORD_LENGTH_ERROR = 10;

	/**
	 * This error code indicates that the user name is invalid
	 */
	public static final int S_USER_CANNOT_CREATED_PASSWORD_COMP_ERROR = 11;
	/**
	 * This error code indicates that the user name is invalid
	 */
	public static final int S_USER_CANNOT_CREATED_PASSWORD_SAME_AS_USERID = 12;
	/**
	 * This error code indicates that the user name is invalid
	 */
	public static final int S_USER_CANNOT_CREATED_PASSWORD_CONTAINS_UID = 13;
	/**
	 * This error code indicates that the user name is invalid
	 */
	public static final int S_USER_CANNOT_CREATED_PASSWORD_CONTAIN_CIRCULARID =
		14;

	/**
	 * This error code indicates that the user name is invalid
	 */
	public static final int S_USER_CANNOT_CREATED_PASSWORD_CONTAIN_CONSECUTIVE_CHARS =
		15;

	/**
	 * This error code indicates that there already exists a user group with the
	 * same name. 2 user group with the same name cannot be existing.
	 */
	public static final int S_USERGROUP_ALREADY_EXISTS = 16;

	/**
	 * This error code indicates that the user that has been selected to be
	 * deleted from LDAP has already been deleted.
	 */
	public static final int S_USERGROUP_DOES_NOT_EXIST = 17;

	/**
	 * This error code indicates that the user group selected to be deleted cannot
	 * be deleted since it is a part of a Domain Mapping.
	 */
	public static final int S_USERGROUP_CANNOT_BE_DELETED_SINCE_MAPPED = 18;

	/**
		 * This error code indicates that the user group is not imported or created with all assigned users due to some users are not valid.
	 */
	public static final int S_USERGROUP_CAN_BE_CREATED_EVEN_USERS_NOT_VALID =
		19;

	/**
	 * This error code indicates that most likely the LDAP error is because of password history
	 */
	public static final int S_LDAP_PASSWORD_HISTORY = 20;

	/**
	 * This error code indicates that user was imported with warnings
	 */
	public static final int USER_IMPORTED_WITH_WARNINGS = 21;

	/**
	 * This error code indicates that user was imported with warnings
	 */
	public static final int USER_AND_PASSWORD_NOT_COMPLIANT_WITH_RULES = 22;
	

	/**
	 * Data member to hold the integer for the creation of this object. Which
	* represents the
	* status
	 */
	private int statusValue = S_SUCCESS;

	/**
	 * Data member to hold the look up for the status to the string that needs
	 * to be displayed.
	 */

	private static Map<Integer, String> s_stringLookupMap = new Hashtable<Integer, String>();


	/**
	 * Constructor
	 */
	public UAStatus() {

	}

	/**
	 * Constructor.
	 * 
	 * @param p_StatusValue
	 *            The integer which represents the status.
	 */
	public UAStatus(int p_StatusValue) {
		statusValue = p_StatusValue;
		}

	/*
	 * Static initializer for mapping error codes to error strings
	 */
	static {
		s_stringLookupMap.put(
			S_INTERNAL_ERROR,
			"An internal error has occured");
		s_stringLookupMap.put(
			S_LDAP_ERROR,
			"An LDAP error has occured");
		s_stringLookupMap.put(S_SUCCESS, " ");
		s_stringLookupMap.put(
			S_USER_ALREADY_EXISTS,
			"An user with the same name already exists");
		s_stringLookupMap.put(
			S_USER_DOES_NOT_EXIST,
			"This user has already been deleted from another Client");
		s_stringLookupMap.put(
			S_USER_CANNOT_BE_DELETED_SINCE_CURRENTLY_LOGGED_IN,
			"This user cannot be deleted since he/she is currently logged on");
		s_stringLookupMap.put(
			S_USER_MAXIMUM_LIMIT_REACHED,
			"Maximum number of users reached. Delete and then try to create an user");
		s_stringLookupMap.put(
			S_USER_NAME_EMPTY_OR_INVALID,
				"User name is invalid, possible reasons could be: \nUser name is empty  \nContains space(s) \nContains characters \\/?<>:*\"|# \nContains more than 64 characters");
		s_stringLookupMap.put(
			S_USER_CANNOT_CREATED_PASSWORD_COMP_ERROR,
				"User can not be created password complexity error: \n password should contain at least two alphabetic \n one numeric and one special character except #,$,*,/,@");
		s_stringLookupMap.put(
			S_USER_CANNOT_CREATED_PASSWORD_SAME_AS_USERID,
			"User can not be created  password error  \n password should not be same as userid");
		s_stringLookupMap.put(
			S_USER_CANNOT_CREATED_PASSWORD_CONTAINS_UID,
			"User can not be created password error  \n password should not contain userid either in reverse or in circular");
		s_stringLookupMap.put(
			S_USER_CANNOT_CREATED_PASSWORD_CONTAIN_CIRCULARID,
			"User can not be created password error  \n password should not contain userid either in reverse or in circular");
		s_stringLookupMap.put(
			S_USER_CANNOT_CREATED_PASSWORD_CONTAIN_CONSECUTIVE_CHARS,
				"User can not be created password error. \nPassword should not contain consecutive digits or consecutive letters from the alphabet.");
		s_stringLookupMap.put(
			S_USER_CANNOT_CREATED_PASSWORD_LENGTH_ERROR,
			"User  can not be created password error  \n password should be at least six character long");
		s_stringLookupMap.put(
			S_USERGROUP_ALREADY_EXISTS,
			"A User Group with the same name already exists");
		s_stringLookupMap.put(
			S_USERGROUP_DOES_NOT_EXIST,
			"User group with the passed ID does not exist.");
		s_stringLookupMap.put(
			S_USERGROUP_CANNOT_BE_DELETED_SINCE_MAPPED,
			"User Group cannot be deleted.\nIt is part of a mapping");
		s_stringLookupMap.put(
			S_USERGROUP_CAN_BE_CREATED_EVEN_USERS_NOT_VALID,
			"User Group created/modifed, invalid users removed");
		s_stringLookupMap.put(
			S_LDAP_PASSWORD_HISTORY,
			"Password could not be modified as It could be that it matches the last 12 previous password or some LDAP operation occured.");
		s_stringLookupMap.put(
			USER_IMPORTED_WITH_WARNINGS,
			"User was imported with some corrections. Please check the logs for further details.");
        s_stringLookupMap.put(USER_AND_PASSWORD_NOT_COMPLIANT_WITH_RULES, "User with invalid password");
	}

	/**
	 * Function to set the status.
	 * 
	 * @param p_StatusValue
	 *            The new status value.
	 */
	public void setStatus(int p_StatusValue) {
		statusValue = p_StatusValue;
		}

	/**
	 * Function to get the Status of this object
	 * 
	 * @return int
	 *   The integer equivalent of the Status object.
	 */
	public int getStatus() {
		return statusValue;
		}

	/**
	 * Function to push this object into the message. Will be used for
	 * transferring this object between the server and the client.
	 * 
	 * @param p_msg
	 *            The Message into which we have to push this object.
	 */
	public void pushMe(USMMessage p_msg) {
		p_msg.pushInteger(statusValue);
		}

	/**
	 * Function to pop this object from the message. Will be used while
	 * transferring this object between the server and the client.
	 * 
	 * @param p_msg
	 *            The Message from which we have to pop this object.
	 */
	public void popMe(USMMessage p_msg) {
		statusValue = p_msg.popInteger().intValue();
	}

	/**
	 * Function to return the Error String for this Status Object.
	 * 
	 * @return java.lang.String
	 *      The String which represents the error for this
	 *         status object.
	 */
	public String getErrorString() {
		String returnValue =
			s_stringLookupMap.get(statusValue);
		return returnValue;
		}
		

	/**
	 * Method to get the String equivalent given the code.
	 * 
	 * @param p_StatusValue
	 *            The integer which represents the status.
	 */
	public static String getErrorString(int p_StatusValue) {
		return s_stringLookupMap.get(p_StatusValue);
	}
}
