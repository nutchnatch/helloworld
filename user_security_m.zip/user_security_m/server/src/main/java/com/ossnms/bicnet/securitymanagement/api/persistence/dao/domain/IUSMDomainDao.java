package com.ossnms.bicnet.securitymanagement.api.persistence.dao.domain;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.IBaseDAO;
import com.ossnms.bicnet.securitymanagement.persistence.model.domain.USMDomain;

/**
 * created on 28/8/2014
 */
public interface IUSMDomainDao extends IBaseDAO<USMDomain, Integer> {
    USMDomain findByName(String name);
}
