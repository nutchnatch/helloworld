package com.ossnms.bicnet.securitymanagement.api.persistence.dao.policy;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.IBaseDAO;
import com.ossnms.bicnet.securitymanagement.persistence.model.policy.USMPermissionItem;

/**
 * created on 4/5/2015
 */
public interface IUSMPermissionItemDao extends IBaseDAO<USMPermissionItem, Integer> {
    USMPermissionItem findByName(String name);
}
