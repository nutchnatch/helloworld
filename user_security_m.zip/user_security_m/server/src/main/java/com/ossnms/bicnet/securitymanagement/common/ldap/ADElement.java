/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 05-May-2005  Babu B          CF001312   Master-Master Replication for Sun ONE DS
 * 26-May-2005  Muyeen Munaver  CF002374 - USM Erros/Exceptions during server start-up
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.ldap;

import org.apache.log4j.Logger;

import javax.naming.Binding;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.NameClassPair;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.OperationNotSupportedException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import java.util.Hashtable;

/**
 * This class is the base class for all data classes that need to be stored
 * into the LDAP DS. This can also be populated by user subsystems to store any
 * of their data into the LDAP DS.
 */
public class ADElement implements DirContext {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(ADElement.class);

	/**
	 * This contains the list of attributes that are to be part of the object
	 * stored in the ldap directory. The Attributes interface represents a
	 * collection of attributes.
	 */
	protected Attributes mLdapAttributes;

	/**
	 * This is the DN of the container under which the objects of this class
	 * will be stored in the LDAP directory. Example of this is
	 * "ou=DomainContainer, dc=aci-banagalore,dc=com"
	 */
	protected String mContainerDN;

	/**
	 * This is the name of the attribute which will prefix the DN to be used to
	 * bind the objects of this class. Example of this is "cn" if cn is the
	 * naming attribute for instances of this class.
	 */
	protected String mNamingAttribute;

	/**
	* This is the default constructor. The member attributes are constructed
	* and ready to be set in the derived class.
	*/
	public ADElement() {
		mLdapAttributes = new BasicAttributes(true);
		mContainerDN = "";
		mNamingAttribute = "";
		LOGGER.debug("LWElement() In the constructor");
	}

	/**
	 * This method is used to get the value of the relativeDNContainer member
	 * attribute. The method is to be invoked by the LWLDAPManager object to
	 * construct the complete DN of the object.
	 * 
	 * @return java.lang.String
	 */
	public String getRelativeDNContainer() {
		return mContainerDN;
	}

	/**
	 * This method is used to get the value of the mNamingAttribute member
	 * attribute. The method is to be invoked by the LWLDAPManager object to
	 * construct the complete DN of the object.
	 * 
	 * @return java.lang.String
	 */
	public String getNamingAttributeName() {
		return mNamingAttribute;
	}

	/**
	 * This method is called to set the member attribute mLdapAttributes.
	 * 
	 * @param pLdapAttributes
	 *            The attribute which has to be set.
	 */
	public void setLDAPAttributes(Attributes pLdapAttributes) {
		this.mLdapAttributes = pLdapAttributes;
	}

	/**
	 * This method is invoked to set the container DN path. The using subsystem
	 * code is to be perform the following to populate the container DN. The
	 * relative path of the container DN is obtained. A comma is added at the
	 * end of this string. The root DN path obtained from the LWGlobal
	 * interface is added to the end of the resultant string.
	 * 
	 * @param pContainerDN
	 *            The container DN path where the subsytem would like to
	 *            manipulate the LDAP object.
	 */
	public void setContainerDNPath(String pContainerDN) {
		this.mContainerDN = pContainerDN;
	}

	/**
	 * This method is used to retrieve the value associated with the passed
	 * attribute name. This will return null if attribute value could not be
	 * fetched.
	 * 
	 * @param pAttributeName
	 *            Specifies the name of the attributes.
	 * @return Object Returns the value of the attribute as an Object.
	 */
	public Object getAttributeValue(String pAttributeName) {
		LOGGER.debug("getAttributeValue() Entering the method");

		Object attributeValue = null;
		try {
			Attribute foundAttribute = mLdapAttributes.get(pAttributeName);
			if (null == foundAttribute) {
				LOGGER.info(
					"getAttributeValue() The attribute identified by the name "
						+ pAttributeName
						+ " does not exist");
				attributeValue = null;
			} else {
				attributeValue = foundAttribute.get();
			}
		} catch (NamingException ex) {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.error(
					"getAttributeValue() EXCEPTION: "
						+ ex.getClass()
						+ "Message : "
						+ ex.getMessage());
			}
			attributeValue = null;
		}

		LOGGER.debug("getAttributeValue() Returning from the method");
		return attributeValue;
	}

//	/**
//	 * This method is used to return the multiple values associated with the
//	 * passed attribute name. This will return null if attribute value could
//	 * not be fetched.
//	 *
//	 * @param p_attributeName
//	 *            The non-null id of the attribute to retrieve. If this
//	 *            attribute set ignores the character case of its attribute
//	 *            ids, the case of attrID is ignored.
//	 * @return List Returns a list of objects that satisfy the
//	 *         attributeName passed as a parameter.
//	 */
//	public List<String> getAttributeValues(String p_attributeName) {
//		LOGGER.debug("getAttributeValues() Entering the method");
//
//		String attributeValue = null;
//		List<String> attributeValueSet = null;
//		try {
//			Attribute foundAttribute = mLdapAttributes.get(p_attributeName);
//			if (null == foundAttribute) {
//				if (LOGGER.isDebugEnabled()) {
//					LOGGER.warn(
//						"getAttributeValues() : The attribute identified by the name "
//							+ p_attributeName
//							+ " does not exist");
//				}
//				attributeValueSet = null;
//			} else {
//				NamingEnumeration<? extends Object> enumeration = foundAttribute.getAll();
//				if (null != enumeration) {
//					attributeValueSet = new ArrayList<String>();
//					while (true == enumeration.hasMore()) {
//						attributeValue = (String) enumeration.next();
//						attributeValueSet.add(attributeValue);
//					}
//				}
//			}
//		} catch (NamingException ex) {
//			if (LOGGER.isDebugEnabled()) {
//				LOGGER.error(
//					"getAttributeValues()EXCEPTION: "
//						+ ex.getClass()
//						+ "Message : "
//						+ ex.getMessage());
//			}
//			attributeValueSet = null;
//		}
//
//		LOGGER.debug("getAttributeValues() Returning from the method");
//		return attributeValueSet;
//	}
//
//	/**
//	 * This method is used to set the value of the mNamingAttribute member
//	 * attribute.
//	 *
//	 * @param p_namingAttributeName
//	 *            Value of the namingAttritbute.
//	 */
//	public void setNamingAttributeName(String p_namingAttributeName) {
//		mNamingAttribute = p_namingAttributeName;
//	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup
	 * @param obj not sup
	 * @param attributes not sup
	 * @throws javax.naming.NamingException
	 */
	@Override
    public void bind(String s, Object obj, Attributes attributes)
		throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup
	 * @param obj not sup
	 * @param attributes not sup
	 * @throws javax.naming.NamingException
	 */
	@Override
    public void bind(Name name, Object obj, Attributes attributes)
		throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * @param s not sup
	 * @param attributes not sup
	 * @return javax.naming.directory.DirContext
	 * @throws javax.naming.NamingException
	 */
	@Override
    public DirContext createSubcontext(String s, Attributes attributes)
		throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup
	 * @param attributes not sup
	 * @return javax.naming.directory.DirContext
	 * @throws javax.naming.NamingException
	 */
	@Override
    public DirContext createSubcontext(Name name, Attributes attributes)
		throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param strAttribName not sup
	 * @return javax.naming.directory.Attributes
	 * @throws javax.naming.NamingException
	 */
	public Attribute getAttribute(String strAttribName)
		throws NamingException {

		Attribute attrToReturn = null;
		NamingEnumeration<? extends Attribute> enumAttributes = mLdapAttributes.getAll();
		while (enumAttributes.hasMore()) {
			Attribute attrCurrent = enumAttributes.next();
			String strAttributeName = attrCurrent.getID();
			if (strAttribName.equals(strAttributeName)) {
				attrToReturn = attrCurrent;
				break;
			}
		}

		return attrToReturn;
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup 
	 * @return javax.naming.directory.Attributes
	 * @throws javax.naming.NamingException
	 */
	@Override
    public Attributes getAttributes(String s) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup 
	 * @param as not sup
	 * @return javax.naming.directory.Attributes
	 * @throws javax.naming.NamingException
	 */
    @Override
    public Attributes getAttributes(String s, String as[]) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup 
	 * @return javax.naming.directory.Attributes
	 * @throws javax.naming.NamingException
	 */
	@Override
    public Attributes getAttributes(Name name) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup 
	 * @param as not sup
	 * @return javax.naming.directory.Attributes
	 * @throws javax.naming.NamingException
	 */
    @Override
    public Attributes getAttributes(Name name, String as[]) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup 
	 * @return javax.naming.directory.DirContext
	 * @throws javax.naming.NamingException
	 */
    @Override
    public DirContext getSchema(String s) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup
	 * @return javax.naming.directory.DirContext
	 * @throws javax.naming.NamingException
	 */
    @Override
    public DirContext getSchema(Name name) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup
	 * @return javax.naming.directory.DirContext
	 * @throws javax.naming.NamingException
	 */
    @Override
    public DirContext getSchemaClassDefinition(String s) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup
	 * @return javax.naming.directory.DirContext
	 * @throws javax.naming.NamingException
	 */
    @Override
    public DirContext getSchemaClassDefinition(Name name) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup
	 * @param i not sup
	 * @param attributes not sup
	 * @throws javax.naming.NamingException
	 */
    @Override
    public void modifyAttributes(String s, int i, Attributes attributes) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup 
	 * @param aModificationItem not sup
	 * @throws javax.naming.NamingException
	 */
    @Override
    public void modifyAttributes(String s, ModificationItem aModificationItem[]) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name name 
	 * @param integer not supported
	 * @param attributes not supported
	 * @throws javax.naming.NamingException
	 */
    @Override
    public void modifyAttributes(Name name, int integer, Attributes attributes) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup 
	 * @param aModificationItem not sup
	 * @throws javax.naming.NamingException
	 */
    @Override
    public void modifyAttributes(Name name, ModificationItem aModificationItem[]) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup 
	 * @param obj not sup
	 * @param attributes not sup 
	 * @throws javax.naming.NamingException
	 */
    @Override
    public void rebind(String s, Object obj, Attributes attributes) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup 
	 * @param obj  not sup 
	 * @param attributes not sup
	 * @throws javax.naming.NamingException
	 */
    @Override
    public void rebind(Name name, Object obj, Attributes attributes) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup
	 * @param s1 not sup 
	 * @param searchControls not sup
	 * @return javax.naming.NamingEnumeration
	 * @throws javax.naming.NamingException
	 */
    @Override
    public NamingEnumeration<SearchResult> search(String s, String s1, SearchControls searchControls) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup 
	 * @param s1 not sup 
	 * @param aobj not sup
	 * @param searchControls not sup
	 * @return javax.naming.NamingEnumeration
	 * @throws javax.naming.NamingException
	 */
    @Override
    public NamingEnumeration<SearchResult> search(String s, String s1, Object aobj[], SearchControls searchControls) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup 
	 * @param attributes not sup 
	 * @return javax.naming.NamingEnumeration not sup
	 * @throws javax.naming.NamingException
	 */
    @Override
    public NamingEnumeration<SearchResult> search(String s, Attributes attributes) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup
	 * @param attributes not sup 
	 * @param as not sup
	 * @return javax.naming.NamingEnumeration
	 * @throws javax.naming.NamingException
	 */
    @Override
    public NamingEnumeration<SearchResult> search(String s, Attributes attributes, String as[]) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup 
	 * @param s not sup
	 * @param searchControls not sup
	 * @return javax.naming.NamingEnumeration
	 * @throws javax.naming.NamingException
	 */
    @Override
    public NamingEnumeration<SearchResult> search(Name name, String s, SearchControls searchControls) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param pname name not sup
	 * @param s  not sup
	 * @param aobj not sup
	 * @param searchcontrols not sup
	 * @return javax.naming.NamingEnumeration
	 * @throws javax.naming.NamingException
	 */
    @Override
    public NamingEnumeration<SearchResult> search(Name pname, String s, Object aobj[], SearchControls searchcontrols) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 *  
	 * @param name not sup 
	 * @param attributes not sup 
	 * @return javax.naming.NamingEnumeration
	 * @throws javax.naming.NamingException
	 */
    @Override
    public NamingEnumeration<SearchResult> search(Name name, Attributes attributes) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup 
	 * @param attributes not sup 
	 * @param as not sup
	 * @return javax.naming.NamingEnumeration
	 * @throws javax.naming.NamingException
	 */
    @Override
    public NamingEnumeration<SearchResult> search(Name name, Attributes attributes, String as[]) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup 
	 * @param obj not sup 
	 * @return p_Object not sup 
	 * @throws javax.naming.NamingException
	 */
    @Override
    public Object addToEnvironment(String s, Object obj) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	* Refer to DirContext Throws OperationNotSupportedException.
	* 
	* @throws javax.naming.NamingException
	*/
	@Override
    public void close() throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup 
	 * @param s1 not sup 
	 * @return java.lang.String
	 * @throws javax.naming.NamingException
	 */
    @Override
    public String composeName(String s, String s1) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup 
	 * @param name1 not sup 
	 * @return javax.naming.Name
	 * @throws javax.naming.NamingException
	 */
    @Override
    public Name composeName(Name name, Name name1) throws NamingException {
        throw new OperationNotSupportedException();
    }
	/**
		 * Refer to DirContext Throws OperationNotSupportedException.
		 * 
		 * @param s not sup 
		 * @param obj not sup
		 * @throws javax.naming.NamingException
		 */
    @Override
    public void bind(String s, Object obj) throws NamingException {
        throw new OperationNotSupportedException();
    }

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup
	 * @param obj not sup
	 * @throws javax.naming.NamingException
	 */
	@Override
    public void bind(Name name, Object obj) throws NamingException {
		throw new OperationNotSupportedException();
	}
	/**
		 * @param s not sup
		 * @throws javax.naming.NamingException
		 */
	@Override
    public void unbind(String s) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * @param name not sup 
	 * @throws javax.naming.NamingException
	 */
	@Override
    public void unbind(Name name) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup
	 * @return javax.naming.Context
	 * @throws javax.naming.NamingException
	 */
	@Override
    public Context createSubcontext(String s) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup
	 * @return javax.naming.Context
	 * @throws javax.naming.NamingException
	 */
	@Override
    public Context createSubcontext(Name name) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup
	 * @throws javax.naming.NamingException
	 */
	@Override
    public void destroySubcontext(String s) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup 
	 * @throws javax.naming.NamingException
	 */
	@Override
    public void destroySubcontext(Name name) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @return Hashtable 
	 * @throws javax.naming.NamingException
	 */
	@Override
    public Hashtable getEnvironment() throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @return java.lang.String
	 * @throws javax.naming.NamingException
	 */
	@Override
    public String getNameInNamespace() throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup
	 * @return javax.naming.NameParser
	 * @throws javax.naming.NamingException
	 */
	@Override
    public NameParser getNameParser(String s) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup
	 * @return javax.naming.NameParser
	 * @throws javax.naming.NamingException
	 */
	@Override
    public NameParser getNameParser(Name name) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup
	 * @return javax.naming.NamingEnumeration
	 * @throws javax.naming.NamingException
	 */
	@Override
    public NamingEnumeration<NameClassPair> list(String s) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup
	 * @return javax.naming.NamingEnumeration
	 * @throws javax.naming.NamingException
	 */
	@Override
    public NamingEnumeration<NameClassPair> list(Name name) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup
	 * @return javax.naming.NamingEnumeration
	 * @throws javax.naming.NamingException
	 */
	@Override
    public NamingEnumeration<Binding> listBindings(String s) throws NamingException {
		throw new OperationNotSupportedException();
	}
	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup
	 * @return javax.naming.NamingEnumeration
	 * @throws javax.naming.NamingException
	 */
	@Override
    public NamingEnumeration<Binding> listBindings(Name name) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup
	 * @return Object
	 * @throws javax.naming.NamingException
	 */
	@Override
    public Object lookup(String s) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup
	 * @return Object
	 * @throws javax.naming.NamingException
	 */
	@Override
    public Object lookup(Name name) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup
	 * @return Object
	 * @throws javax.naming.NamingException
	 */
	@Override
    public Object lookupLink(String s) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup
	 * @return Object
	 * @throws javax.naming.NamingException
	 */
	@Override
    public Object lookupLink(Name name) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup
	 * @param obj not sup
	 * @throws javax.naming.NamingException
	 */
	@Override
    public void rebind(String s, Object obj) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param name not sup
	 * @param obj not sup
	 * @throws javax.naming.NamingException
	 */
	@Override
    public void rebind(Name name, Object obj) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param s not sup
	 * @return Object 
	 * @throws javax.naming.NamingException
	 */
	@Override
    public Object removeFromEnvironment(String s) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * Refer to DirContext Throws OperationNotSupportedException.
	 * 
	 * @param p_s not sup
	 * @param s1 not sup
	 * @throws javax.naming.NamingException
	 */
	@Override
    public void rename(String p_s, String s1) throws NamingException {
		throw new OperationNotSupportedException();
	}

	/**
	 * @param name not sup
	 * @param name1 not sup
	 * @throws javax.naming.NamingException
	 */
	@Override
    public void rename(Name name, Name name1) throws NamingException {
		throw new OperationNotSupportedException();
	}

    /**
     * returns the contained LDAP attributes
     */
    public Attributes getLdapAttributes() {
        return mLdapAttributes;
    }

}
