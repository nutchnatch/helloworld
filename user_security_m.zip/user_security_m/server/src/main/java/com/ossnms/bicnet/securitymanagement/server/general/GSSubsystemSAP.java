/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   GSSubsystemSAP
 * Author:      Jogender
 * Substitute	Babu 
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : 
 * 		 :
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 18-Mar-2005  Asif khan R     CF001755 Error Messages when LDAP not available
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.general;

import com.ossnms.bicnet.securitymanagement.api.server.general.GSProperty;
import com.ossnms.bicnet.securitymanagement.api.server.general.IGSWrapper;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.bicnet.securitymanagement.common.general.ldap.LDAPConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.radius.configuration.RadiusConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.sso.SSOConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.utils.InternalUSMBeanLocator;
import org.apache.log4j.Logger;

/**
 * This Interface Class encapsulates the calls that are made from outside of the GS
 */
public class GSSubsystemSAP {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(GSSubsystemSAP.class);


    /**
     *
     * @return
     */
    private static IGSWrapper getGSWrapper(){
        return InternalUSMBeanLocator.getEJB(IGSWrapper.class);
    }

    /**
	 * This method is called from UAsubsystemSAP::exportUsers method to get the default user for importing users
	 * @return String -
	 *      Returns the default user password for importing
	 */
	public static String getDefaultPassword() {
		LOGGER.debug("getDefaultPassword()		Enter");
		String strPassword = getGSWrapper().getDefaultPassword();
		LOGGER.debug("getDefaultPassword()		Exit");
		return strPassword;
	}

	/**
	 * This method returnd the bad password limit after which accounts will be locked.
	 * used by UA
	 * @return int
	 *      bad password limit after which accounts will be locked.
	 */
	public static int getBadPasswordLimit() {
		LOGGER.debug("getGeneralSettingData()        Enter");
		int nBadPasswordLimit =
                getGSWrapper()
				.getGeneralSettingData()
				.getDeactivationAfterLoginAttempts();
		LOGGER.debug("getGeneralSettingData()        Exit");
		return nBadPasswordLimit;
	}

    /**
     * This method returns the number of passwords to be stored in the password history
     * @return int number of passwords to be stored
     */
    public static int getNumberPasswordsInHistory() {
        LOGGER.debug("getNumberPasswordsInHistory()        Enter");
        int nPasswordsInHistory = 0;
        
        try {
        	nPasswordsInHistory = Integer.parseInt(getGSWrapper().getPropertyValue(GSProperty.PASSWORD_IN_HISTORY));
        } catch (NumberFormatException | NullPointerException e) {
        	LOGGER.warn("Number of Passwords in History is not defined: ", e);
        }
		LOGGER.debug("getNumberPasswordsInHistory()        Exit");
        return nPasswordsInHistory;
    }

    /**
	* Wraps ldap calls for retrieving general setting  data.
	 *
	* @return GSGeneralSettingData  Returns the general setting details wrapped.
	*/
	public static GSGeneralSettingData getGeneralSettingData() {
		// Calling LDAP wrapper for GS to retrieve the general setting data
		IGSWrapper gsWrapper = getGSWrapper();
		if(gsWrapper == null) {
			return null;
		}

		GSGeneralSettingData objData = gsWrapper.getGeneralSettingData();
		return objData;
	}

	/**
	 * Wraps calls for retrieving Single Sign On settings
	 *
	 * @return instance of SSOConfigurationData
	 */
	public static SSOConfigurationData getSSOConfigurationData(){
		SSOConfigurationData configurationData = getGSWrapper().getSingleSignOnConfiguration();

		if(configurationData == null){
			return new SSOConfigurationData();
		}

		return configurationData;
	}

	/**
	 * Wraps calls for LDAP Settings retrieval
	 *
	 * @return instance of LDAP Configuration Data
     */
	public static LDAPConfigurationData getLdapConfigurationData(){

		LDAPConfigurationData configurationData = getGSWrapper().getLdapConfigurationData();

		if(configurationData == null){
			return new LDAPConfigurationData();
		}

		return configurationData;
	}

	/**
	 * Wraps calls for RADIUS Settings retrieval
	 *
	 * @return instance of RADIUS Configuration Data
	 */
	public static RadiusConfigurationData getRadiusConfigurationData(){

		RadiusConfigurationData configurationData = getGSWrapper().getRadiusConfigurationData();

		if(configurationData == null){
			return new RadiusConfigurationData();
		}

		return configurationData;
	}
}
