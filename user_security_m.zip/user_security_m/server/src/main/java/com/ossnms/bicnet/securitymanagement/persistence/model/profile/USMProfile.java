package com.ossnms.bicnet.securitymanagement.persistence.model.profile;

import com.ossnms.bicnet.securitymanagement.persistence.model.BaseUSMEntity;

import javax.persistence.*;

@Entity
@Table(name = "USM_PROFILE",
    uniqueConstraints = { @UniqueConstraint(columnNames = {"USER_ID", "APP_UID"})}
)
@NamedQueries({
		@NamedQuery(name = "usmProfile.findByUser", query = "from USMProfile d where d.userId = :userId"),
		@NamedQuery(name = "usmProfile.findByUserAndAppUid", query = "from USMProfile d where d.userId = :userId AND d.appUid = :appUid")
})
public class USMProfile extends BaseUSMEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "USMProfileSequence")
	@SequenceGenerator(name = "USMProfileSequence", sequenceName = "USM_SEQ_PROFILE")
	@Column(name = "CONT")
	private Integer id;

	@Column(name = "USER_ID", nullable = false)
	private String userId;

	@Column(name = "APP_UID", nullable = false)
	private String appUid;

    @Lob
	@Column(name = "PROPERTIES")
	private String properties;

	public USMProfile() {
		super();
	}

	@Override
	public boolean isNew() {
		return id == null || id == 0;
	}

	/**
	 * Constructor
	 * 
	 * @param userId
	 *            the user id
	 * @param appUid
	 *            the CF application id
	 * @param properties
	 *            the properties of the profile
	 */
	public USMProfile(String userId, String appUid, String properties) {
		super();
		this.userId = userId;
		this.appUid = appUid;
		this.properties = properties;
	}

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getAppUid() {
		return appUid;
	}

	public void setAppUid(String appUid) {
		this.appUid = appUid;
	}

	public String getProperties() {
		return properties;
	}

	public void setProperties(String properties) {
		this.properties = properties;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj){
            return true;
        }
		if (obj == null){
            return false;
        }
		if (getClass() != obj.getClass()){
            return false;
        }

		USMProfile other = (USMProfile) obj;

		if (appUid == null) {
			if (other.appUid != null){
                return false;
            }
		} else if (!appUid.equals(other.appUid)){
            return false;
        }
		if (id == null) {
			if (other.id != null){
                return false;
            }
		} else if (!id.equals(other.id)){
            return false;
        }
		if (properties == null) {
			if (other.properties != null){
                return false;
            }
		} else if (!properties.equals(other.properties)){
            return false;
        }
		if (userId == null) {
			if (other.userId != null){
                return false;
            }
		} else if (!userId.equals(other.userId)){
            return false;
        }

		return true;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((appUid == null) ? 0 : appUid.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result
				+ ((properties == null) ? 0 : properties.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}

}
