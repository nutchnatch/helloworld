package com.ossnms.bicnet.securitymanagement.persistence.dao.profile;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.profile.IUSMProfileDao;
import com.ossnms.bicnet.securitymanagement.persistence.dao.AbstractBaseDao;
import com.ossnms.bicnet.securitymanagement.persistence.model.profile.USMProfile;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.Query;
import java.util.List;



/**
 * created on 28/8/2014
 */
@Stateless(name = "IUSMProfileDao")
@Local
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class USMProfileDao extends AbstractBaseDao<USMProfile, Integer> implements IUSMProfileDao {

	private static final String QUERY_FIND_BY_USER = "usmProfile.findByUser";
	private static final String QUERY_FIND_BY_USER_AND_APP_UID = "usmProfile.findByUserAndAppUid";

	private static final String PARAM_1 = "userId";
	private static final String PARAM_2 = "appUid";

	@Override
	public List<USMProfile> findByUser(String user) {
		Query query = getEntityManager().createNamedQuery(QUERY_FIND_BY_USER).setParameter(PARAM_1, user);

		return (List<USMProfile>) query.getResultList();
	}

	@Override
	public USMProfile findByUserAndAppUid(String user, String uid) {
		Query query = getEntityManager().createNamedQuery(QUERY_FIND_BY_USER_AND_APP_UID).setParameter(PARAM_1, user).setParameter(PARAM_2, uid);

		return getSingleResult(query);
	}

}
