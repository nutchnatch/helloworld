package com.ossnms.bicnet.securitymanagement.persistence.dao.user;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.user.IUSMUserDao;
import com.ossnms.bicnet.securitymanagement.persistence.dao.AbstractBaseDao;
import com.ossnms.bicnet.securitymanagement.persistence.model.user.USMPasswordHistory;
import com.ossnms.bicnet.securitymanagement.persistence.model.user.USMUser;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.Query;
import java.util.List;

/**
 * created on 8/10/2014
 */
@Stateless(name = "IUSMUserDao")
@Local
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class USMUserDao extends AbstractBaseDao<USMUser, Integer> implements IUSMUserDao {
	
	private static final String QUERY_FIND_PASSWORDS_BY_USER = "usmPasswordHistory.findByUserID";
	private static final String PARAM_1 = "user";

    @Override
    public USMUser findByUsername(String username) {
        Query query = getEntityManager()
                .createNamedQuery(USMUser.QUERY_FIND_BY_USERNAME)
                .setParameter(USMUser.PARAM_FIND_BY_USERNAME_1, username);
        return getSingleResult(query);
    }

    @Override
    public List<USMUser> findByInactivityTimeoutEnabled(boolean enabled){
        Query query = getEntityManager()
                .createNamedQuery(USMUser.QUERY_FIND_BY_INACTIVITY_TIMEOUT_ENABLED)
                .setParameter(USMUser.PARAM_FIND_BY_INACTIVITY_TIMEOUT_ENABLED_1, enabled);
        return query.getResultList();
    }
	
	@Override
	public List<USMPasswordHistory> findPasswordsByUser(USMUser user) {
		Query query = getEntityManager().createNamedQuery(QUERY_FIND_PASSWORDS_BY_USER).setParameter(PARAM_1, user);
		return (List<USMPasswordHistory>) query.getResultList();
	}

}
