/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	BSReturnType
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_OBJECTS
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_ACL 
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_SECURITY
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.INSERT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.bicnetserver;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;

/**
 * This class encapsulates the return type. Since Java does not provide an enum,
 * this class has been made to encapsulate the different return types for
 * operations within BS.
 */
public final class BSReturnType {
	/**
	 * This int is used to indicates the successful completion of the operation
	 */
	private static final int S_SUCCESS = 0;

	/**
	 * This int is used to indicates an error in the LDAP during the performing of the
	 * operation
	 */
	private static final int S_LDAP_ERROR = 1;

	/**
	 * This int is used indicates either CF down or some problem with LAN while
	 * trying to perform the operation on the Application Server
	 */
	private static final int S_SERVER_DOWN_NOT_REACHABLE = 2;

	/**
	 * This int is used to indicate that while performing the operation on the
	 * Application Server, the application server indicated that the data is
	 * inconsistent
	 */
	private static final int S_SERVER_DATA_INCONSISTENT = 3;

	/**
	 * This int is used to indicate that the Server is not a part of the Global
	 * Security.
	 */
	private static final int S_SERVER_NOT_CONFIGURED = 4;

	/**
	 * This int is used to indicate that the operation resulted in trying to connect
	 * to a server that is already connected to.
	 */
	private static final int S_SERVER_ALREADY_CONNECTED = 5;

	/**
	 * This int is used to indicates a failure while trying to retrieve the
	 * Managed Elements.
	 */
	private static final int S_FAIL_MANAGED_ELM = 6;

	/**
	 * This int is used to indicates a failure while trying to call the
	 * connect operation.
	 */
	private static final int S_FAIL_CONNECT = 7;

	/**
	 * This int is used to indicates a failure to set the name of the server
	 * to the new one. This could happen in case the name is already in use
	 */
	private static final int S_NAME_IN_USE = 8;

	/**
	 * This int is used to indicate a failure to connect to the Naming
	 * Service.
	 */
	private static final int S_NS_NOT_AVAILABLE = 9;

	/**
	 * This int is used to indicates a general failure while trying to perform the
	 * operation.
	 */
	private static final int S_FAILURE = 10;

	/**
	 * This is the actual value of the instance of the BSReturnType
	 */
	private int returnValue = -1;

	/**
	 * The strings that are used to display in the Client.
	 */
	private static String m_Reasons[] =
		{
			"Successful",
			"LDAP Error",
			"Server Down or Server not reachable",
			"Server Data Inconsistent",
			"Server not configured with Global Security",
			"Server Already Connected",
			"Error while retrieving the Managed Elements",
			"Failed to Connect to the Application Server",
			"The specified name already in Use",
			"The Naming Service is down or not reachable",
			"General Error" };

	/**
	 * This Object indicates the S_SUCCESSful completion of the operation
	 */
	public static final BSReturnType SUCCESS_T = new BSReturnType(S_SUCCESS);

	/**
	 * This Object indicates an error in the LDAP during the performing of the
	 * operation
	 */
	public static final BSReturnType LDAP_ERROR_T =
		new BSReturnType(S_LDAP_ERROR);

	/**
	 * This Object indicates either server down or some problem with LAN while trying
	 * to perform the operation on the Application Server.
	 */
	public static final BSReturnType SERVER_DOWN_NOT_REACHABLE_T =
		new BSReturnType(S_SERVER_DOWN_NOT_REACHABLE);

	/**
	 * This Object indicates that while performing the operation on the Application
	 * Server, the application server indicated that the data is inconsistent
	 */
	public static final BSReturnType SER_DATA_INCONSIST_T =
		new BSReturnType(S_SERVER_DATA_INCONSISTENT);

	/**
	 * This object indicates that the Server is not a part of the Global Security.
	 */
	public static final BSReturnType SERVER_NOT_CONFIGURED_T =
		new BSReturnType(S_SERVER_NOT_CONFIGURED);

	/**
	 * This object indicates that the operation resulted in trying to connect to a
	 * server which is already connected to.
	 */
	public static final BSReturnType SERVER_ALREADY_CONNECTED_T =
		new BSReturnType(S_SERVER_ALREADY_CONNECTED);

	/**
	 * This Object indicates a general failure while trying to perform the operation.
	 */
	public static final BSReturnType FAIL_MANAGED_ELM_T =
		new BSReturnType(S_FAIL_MANAGED_ELM);

	/**
	 * This Object indicates a general failure while trying to perform the operation.
	 */
	public static final BSReturnType FAIL_CONNECT_T =
		new BSReturnType(S_FAIL_CONNECT);

	/**
	 * This Object indicates a failure becuase the new name is already used.
	 */
	public static final BSReturnType NAME_IN_USE_T =
		new BSReturnType(BSReturnType.S_NAME_IN_USE);

	/**
	 * This Object indicates a failure because the Naming Service is not available.
	 */
	public static final BSReturnType NS_NOT_AVAILABLE_T =
		new BSReturnType(BSReturnType.S_NS_NOT_AVAILABLE);

	/**
	 * This Object indicates a general failure while trying to perform the operation.
	 */
	public static final BSReturnType FAILURE_T =
		new BSReturnType(BSReturnType.S_FAILURE);

	/**
	 * This is an array which contains all the Return Types.
	 */
	private static BSReturnType m_arrReturnType[] =
		{
			SUCCESS_T,
			LDAP_ERROR_T,
			SERVER_DOWN_NOT_REACHABLE_T,
			SER_DATA_INCONSIST_T,
			SERVER_NOT_CONFIGURED_T,
			SERVER_ALREADY_CONNECTED_T,
			FAIL_MANAGED_ELM_T,
			FAIL_CONNECT_T,
			NAME_IN_USE_T,
			NS_NOT_AVAILABLE_T,
			FAILURE_T };

	/**
	 * Constructor
	 * @param p_value  The int value which indicates the return type.
	 */
	private BSReturnType(int p_value) {
		returnValue = p_value;
	}

	/**
	 * This function is invoked when the BSReturnType needs to be passed
	 * from the Server to Client or vice versa. This function will push the
	 * BSReturnType into the message.
	 * @param pMsg  The message into which the object should be pushed.
	 */
	public void pushMe(USMMessage pMsg) {
		pMsg.pushInteger(returnValue);
	}

	/**
	 * This function is invoked when the BSReturnType needs to be populated
	 * after being passed from the Server to Client or vice versa. This function
	 * will pop the BSReturnType from the message.
	 * @param pMsg  The message from which the object should be poped.
	 * @return BSReturnType  The poped out Return type from
	 * the message.
	 */
	public static BSReturnType popMe(USMMessage pMsg) {
		int type = pMsg.popInteger().intValue();
		return m_arrReturnType[type];
	}

	/**
	 * Function to get the equivalent String for the Returntype
	 * @return java.lang.String  The equivalent string for this object.
	 */
	@Override
    public String toString() {
		return m_Reasons[returnValue];
	}
}
