package com.ossnms.bicnet.securitymanagement.common.policy;

import com.ossnms.bicnet.securitymanagement.api.common.USMSerializable;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;

/**
 * created on 6/5/2015
 */
public class PAPermissionItemData implements USMSerializable{
    private static final long serialVersionUID = 1L;

    /**
     *
     */
    private int id;

    /**
     *
     */
    private String name;

    /**
     *
     */
    private String description;

    public PAPermissionItemData() {
        this.id = -1;
        this.name = "";
        this.description = "";
    }

    /**
     *
     * @param id
     * @param name
     * @param description
     */
    public PAPermissionItemData(int id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    /**
     *
     * @return
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return
     */
    public String getDescription() {
        return description;
    }

    /**
     *
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() { return name; }

    /**
     *
     * @param o
     * @return
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        PAPermissionItemData that = (PAPermissionItemData) o;

        if (id != that.id) {
            return false;
        }

        if (name != null ? !name.equals(that.name) : that.name != null) {
            return false;
        }

        return !(description != null ? !description.equals(that.description) : that.description != null);
    }

    /**
     *
     * @return
     */
    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        return result;
    }


    @Override
    public void pushMe(USMMessage msg) {
        msg.pushInteger(id);
        msg.pushString(name);
        msg.pushString(description);
    }

    @Override
    public void popMe(USMMessage msg) {
        description = msg.popString();
        name = msg.popString();
        id = msg.popInteger();
    }
}
