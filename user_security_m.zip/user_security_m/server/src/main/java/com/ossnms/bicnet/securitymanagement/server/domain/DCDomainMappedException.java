/* --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 */

package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.securitymanagement.common.domain.DCException;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;

/**
 * This exception is thrown when there is a data base error due to an error while
 * reading or writing into LDAP
 */
class DCDomainMappedException extends DCException {

    private static final long serialVersionUID = 1L;

    /**
	 * Default constructor
	 */
	public DCDomainMappedException() {
		super(DCMessages.getInstance().getString(DCMessages.DC_DOMAIN_MAPPED_ERROR));
	}

	/**
	 * Constructor with a string parameter, which is descriptive
	 * @param reason  A user descriptive string which indicates this exception.
	 */
	public DCDomainMappedException(String reason) {
		super(reason);
	}

}
