package com.ossnms.bicnet.securitymanagement.common.policy;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * Helper class provided do some common operations that are needed by both the
 * client and the server. These include - 1. Pushing and Poping of
 * Lists of PolicyNameAndID objects
 *  
 */
public final class PACommonHelper {

	/**
	 * Hidden constructor
	 */
	private PACommonHelper(){}

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(PACommonHelper.class);

	/**
	 * This method pushes the policy details into a USMMessage
	 * 
	 * @param policies - List of policies that have to pushed into the message
	 * @param msg - Message that contains the policy objects
	 */
	public static void pushPolicyIntoMessage(List<? extends PAPolicyId> policies, USMMessage msg) {
		LOGGER.info("pushPolicyIntoMessage() entry");

		if ((null == policies) || (null == msg)) {
			LOGGER.error("Parameter passed is null.");
			return;
		}
		int nPushedPolicies = 0;
		for (PAPolicyId policyNameAndID : policies) {
			// Push All the PolicyNameAndID Pair Data onto the Message.
			policyNameAndID.pushMe(msg);
			nPushedPolicies++;
		}
		// Push Count.
		msg.pushInteger(nPushedPolicies);
		LOGGER.info("pushPolicyIntoMessage() number of policies pushed at server =" + policies.size());
		LOGGER.info("pushPolicyIntoMessage() exit");
	}

	public static void pushPolicyIntoMessage(PAPolicyData policy, USMMessage msg) {
		LOGGER.info("pushPolicyIntoMessage() entry");

		if ((null == policy) || (null == msg)) {
			LOGGER.error("Parameter passed is null.");
			return;
		}
		// Push the Policy Data onto the Message.
		policy.pushMe(msg);
		msg.pushInteger(1);
		LOGGER.info("pushPolicyIntoMessage() pushed one policy pushed at server");
		LOGGER.info("pushPolicyIntoMessage() exit");
	}

	/**
	 * This method pops the policy details from a USMMessage
	 * 
	 * @param msg Message that contains the policy objects
	 * @return List - A List that contains all the popped
	 *         policy objects
	 */
	public static List popPolicyNameIDListFromMsg(USMMessage msg) {
		LOGGER.debug("popPolicyNameIDListFromMsg  entering function ");
		int nPolicies;
		PAPolicyId pData = new PAPolicyId();
		List<PAPolicyId> lstPolicy = new ArrayList<>();
		nPolicies = msg.popInteger();
		LOGGER.info("popPolicyNameIDListFromMsg() number of policies poped are =" + nPolicies);
		for (int idx = 1; idx <= nPolicies; idx++) {
			pData.popMe(msg);
			lstPolicy.add(pData);
		}
		LOGGER.debug("popPolicyNameIDListFromMsg  exit function ");

		return lstPolicy;
	}

	/**
	 * Pushes a list of permissions to a {@link USMMessage} instance.
	 *
	 * @param permissions the list of permissions we wish to push into the message
	 * @param message the message to receive the data
	 */
	public static void pushPermissionIntoMessage(List<PAPermissionData> permissions, USMMessage message) {
		LOGGER.info("pushPermissionIntoMessage() entry");

		if ((null == permissions) || (null == message)) {
			LOGGER.error("Parameter passed is null.");
			return;
		}

		int nPushedPermissions = 0;
		for (PAPermissionData permissionData : permissions) {
			// Push All the PolicyNameAndID Pair Data onto the Message.
			permissionData.pushMe(message);
			nPushedPermissions++;
		}
		
		// Push Count.
		message.pushInteger(nPushedPermissions);
		LOGGER.info("pushPermissionIntoMessage() number of permissions pushed at server =" + permissions.size());
		LOGGER.info("pushPermissionIntoMessage() exit");
	}

	/**
	 * Pushes a list of permission items to a {@link USMMessage} instance.
	 *
	 * @param permissionItems the list of permission items we wish to push into the message
	 * @param message the message to receive the data
	 */
	public static void pushPermissionItemIntoMessage(List<PAPermissionItemData> permissionItems, USMMessage message) {
		LOGGER.info("pushPermissionItemIntoMessage() entry");

		if ((null == permissionItems) || (null == message)) {
			LOGGER.error("Parameter passed is null.");
			return;
		}

		int nPushedPermissionItems = 0;
		for (PAPermissionItemData permissionItemData : permissionItems) {
			// Push All the PolicyNameAndID Pair Data onto the Message.
			permissionItemData.pushMe(message);
			nPushedPermissionItems++;
		}

		// Push Count.
		message.pushInteger(nPushedPermissionItems);
		LOGGER.info("pushPermissionItemIntoMessage() number of permission items pushed at server =" + permissionItems.size());
		LOGGER.info("pushPermissionItemIntoMessage() exit");
	}
}
