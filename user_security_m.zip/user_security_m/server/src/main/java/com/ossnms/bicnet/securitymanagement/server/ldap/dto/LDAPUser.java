package com.ossnms.bicnet.securitymanagement.server.ldap.dto;

import java.util.List;

public class LDAPUser {
	
	private String userID;

	private List<LDAPGroup> userGroups;


	/**
	 * @return the userID
	 */
	public String getUserID() {
		return userID;
	}


	/**
	 * @param userID the userID to set
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}

	/**
	 *
	 * @return
     */
	public List<LDAPGroup> getUserGroups() {
		return userGroups;
	}


	/**
	 *
	 * @param userGroups
     */
	public void setUserGroups(List<LDAPGroup> userGroups) {
		this.userGroups = userGroups;
	}
}
