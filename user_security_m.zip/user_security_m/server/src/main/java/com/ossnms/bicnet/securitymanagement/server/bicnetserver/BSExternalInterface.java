package com.ossnms.bicnet.securitymanagement.server.bicnetserver;

import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.server.domain.DCSubsystemSAP;
import org.apache.log4j.Logger;

import java.util.List;

/**
 * This class is for encapsulating BS from the calls that are
 * made to DC and to PA
 */
class BSExternalInterface {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(BSExternalInterface.class);

	/**
	 * This function is invoked by the BSCentralController when a new CF
	 * is inserted into USM. PA needs this information since it
	 * should retrieve the menu options from the CF
	 * @param p_CF  The CF which has been inserted in to USM.
	 */
	static void informPAAboutCFInsertion(BSTransBicNetCFInfo p_CF) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering informPAAboutCFInsertion. CF : " + p_CF);
		}

//		PASubsystemSAP.onServerInserted(p_CF);

		LOGGER.debug("Exiting informPAAboutCFInsertion");
	}

	/**
	 * Function to retrieve all the Domains which are available within DC
	 * @return List List of Domains which are configured with DC.
	 */
	public static List<DCDomainData> getAllDomains() {
		LOGGER.debug("Entering getAllDomains");

		List<DCDomainData> lstDomains = DCSubsystemSAP.getAllDomains();

		LOGGER.debug("Exiting getAllDomains. List : " + lstDomains);
		return lstDomains;
	}
}
