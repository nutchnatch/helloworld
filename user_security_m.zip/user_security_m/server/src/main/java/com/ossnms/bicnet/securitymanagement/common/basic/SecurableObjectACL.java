package com.ossnms.bicnet.securitymanagement.common.basic;

import java.io.Serializable;
import java.util.BitSet;

/**
 * Object used during the login, to transfer the access control list bit set of a securable object 
 *
 */
public class SecurableObjectACL implements Serializable{

	private static final long serialVersionUID = 5107527189714264701L;
	
	private String uniqueName;
	private BitSet bitSetACL;
	
	/**
	 * Builds the Securable Object to ACL mapping
	 * @param uniqueName the unique name of the Securable Object
	 * @param bitSetACL the ACL bit set
	 */
	public SecurableObjectACL(String uniqueName, BitSet bitSetACL) {
		this.uniqueName = uniqueName;
		this.bitSetACL = bitSetACL;
	}


	/**
	 * Retrieves the Securable Object unique name
	 * @return the Securable Object unique name
	 */
	public String getUniqueName() {
		return uniqueName;
	}

	/**
	 * Sets the Securable Object unique name
	 * @param uniqueName the Securable Object unique name
	 */
	public void setUniqueName(String uniqueName) {
		this.uniqueName = uniqueName;
	}

	/**
	 * Retrieves the ACL bit set
	 * @return the ACL bit set
	 */
	public BitSet getBitSetACL() {
		return bitSetACL;
	}

	/**
	 * Sets the ACL bit set
	 * @param bitSetACL the ACL bit set
	 */
	public void setBitSetACL(BitSet bitSetACL) {
		this.bitSetACL = bitSetACL;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bitSetACL == null) ? 0 : bitSetACL.hashCode());
		result = prime * result + ((uniqueName == null) ? 0 : uniqueName.hashCode());
		return result;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		SecurableObjectACL other = (SecurableObjectACL) obj;
		if (bitSetACL == null) {
			if (other.bitSetACL != null) {
				return false;
			}
		} else if (!bitSetACL.equals(other.bitSetACL)) {
			return false;
		}
		if (uniqueName == null) {
			if (other.uniqueName != null) {
				return false;
			}
		} else if (!uniqueName.equals(other.uniqueName)) {
			return false;
		}
		return true;
	}
}
