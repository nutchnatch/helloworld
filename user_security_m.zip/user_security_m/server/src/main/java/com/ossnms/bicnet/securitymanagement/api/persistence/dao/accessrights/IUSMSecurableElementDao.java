package com.ossnms.bicnet.securitymanagement.api.persistence.dao.accessrights;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.IBaseDAO;
import com.ossnms.bicnet.securitymanagement.persistence.model.accessrights.USMSecurableElement;

import java.util.List;

/**
 * created on 24/9/2014
 */
public interface IUSMSecurableElementDao extends IBaseDAO<USMSecurableElement, String> {

    /**
     *
     * @param element
     */
    void loadAcl(USMSecurableElement element);

    /**
     *
     * @param element
     */
    void loadContainers(USMSecurableElement element);

    /**
     *
     * @param displayName
     * @return
     */
    USMSecurableElement findByDisplayName(String displayName , boolean withContainers, boolean withACL);

    /**
     *
     * @param functionId
     * @return
     */
    List<USMSecurableElement> findByFunction(String functionId, boolean withContainers, boolean withACL);

    /**
     *
     * @param functionId
     * @return
     */
    List<USMSecurableElement> findByFunctionAndDomain(String functionId, int domainId, boolean withContainers, boolean withACL);

    /**
     *
     * @return
     */
    List<USMSecurableElement> findAllWithACL();


    /**
     *
     * @return
     */
    List<USMSecurableElement> findAllWithContainers();

    /**
     *
     * @param uniqueName
     * @param withContainers
     * @param wihtACL
     * @return
     */
    USMSecurableElement findById(String uniqueName, boolean withContainers, boolean wihtACL);

    /**
     *
     * @param cFid
     * @return
     */
    int countByFunction(String cFid);

    /**
     *
     * @param cFid
     * @param domainID
     * @return
     */
    int countByFunctionAndDomain(String cFid, int domainID);
}
