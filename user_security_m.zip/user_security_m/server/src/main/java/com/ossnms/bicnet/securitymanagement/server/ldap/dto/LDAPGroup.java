package com.ossnms.bicnet.securitymanagement.server.ldap.dto;

public class LDAPGroup {

    private String groupID;

    public String getGroupID() {
        return groupID;
    }

    public void setGroupID(String groupID) {
        this.groupID = groupID;
    }

    @Override
    public String toString(){
        return groupID;
    }
}
