/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AAServerCache
 * Author      	Babu B
 * Substitute	Jogender Singh
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.SERVER.AUTHORIZATION
 * 		  TNMS.DX2.SM.CLIENT.AUTHORIZE
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 * 11-Mar-2005	Asif			CF000845 - System Event Log Entries
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.auth;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.paths.CommonContainerIdItem;
import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.facade.security.SecurableObjectContainerIdItem;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkableId;
import com.ossnms.bicnet.securitymanagement.api.server.auth.SessionType;
import com.ossnms.bicnet.securitymanagement.common.auth.AAClientCacheData;
import com.ossnms.bicnet.securitymanagement.common.auth.AAClientCacheData.ClientMapping;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.domain.DCGlobal;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessageType;
import com.ossnms.bicnet.securitymanagement.common.policy.PAMessageType;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionItemData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import com.ossnms.bicnet.securitymanagement.server.bicnetserver.BSSubsystemSAP;
import com.ossnms.bicnet.securitymanagement.server.domain.DCSubsystemSAP;
import com.ossnms.bicnet.securitymanagement.server.policy.PASubsystemSAP;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.ossnms.bicnet.bcb.model.ManagedObjectType.COMMON_CONTAINER;
import static com.ossnms.bicnet.bcb.model.ManagedObjectType.NE;
import static com.ossnms.bicnet.bcb.model.ManagedObjectType.SECURABLE_OBJECT;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.POLICY_NO_ACCESS;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.POLICY_NO_VISIBILITY;

/**
 *
 * This class maintains a cache based on the following structure
 *
 * Main Cache -> Map<UserGroup Vs ServerCacheMapping>
 *
 * ServerCacheMapping -> Map<DomainId Vs PolicyId>
 *
 * PolicyMap -> Map<PolicyId Vs MenuEntryList>
 *
 */
public final class AAServerCache {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(AAServerCache.class);

    /**
     * Data member for the sole instance of the class.
     */
    private static AAServerCache self = new AAServerCache();

    /**
     * Map<UserGroup Vs ServerCacheMapping>
     */
    private Map<String, AAServerCacheMapping> mapUG2ServerCacheMapping;

    /**
     * Map<PolicyId Vs MenuEntryList>
     */
    private Map<Integer, Set<String>> mapPolicyDetails;

    /**
     * Default Constructor
     *
     */
    private AAServerCache() {
        super();
        initMaps();
    }

    /**
     * Create the right map objects.
     *
     * Care has to be taken to ensure that these map objects are
     * 1. Thread Safe
     * 2. Cluster Aware
     *
     */
    private synchronized void initMaps() {
        LOGGER.debug("initMaps()		Enter");
        mapUG2ServerCacheMapping = Collections.synchronizedMap(new HashMap<>());

        mapPolicyDetails = Collections.synchronizedMap(new HashMap<>());
        LOGGER.debug("initMaps()		Exit");
    }

    /**
     * Update the maps with the given data.
     *
     * @param vecPolicies List of the policies
     */
    synchronized void updatePoliciesMap(List<PAPolicyData> vecPolicies) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("updatePoliciesMap(" + vecPolicies + ")		Enter");
        }
        // First - the Policy Map

        vecPolicies.forEach(this::updatePoliciesMap);

        LOGGER.debug("updatePoliciesMap Exit");
    }

    /**
     * Update the maps with the given policy.
     *
     * @param policy the policy
     */
    synchronized void updatePoliciesMap(PAPolicyData policy){
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("updatePoliciesMap(" + policy + ")		Enter");
        }

        int nPolicyId = policy.getPolicyID();

        Set<String> setMenuEntries = Collections.synchronizedSet(new HashSet<>());

        Set<PAPermissionItemData> permissionItemDataSet = new HashSet<>();
        permissionItemDataSet.addAll(PASubsystemSAP.getPermissionItems(policy));

        setMenuEntries.addAll(permissionItemDataSet.stream().map(PAPermissionItemData::getName).collect(Collectors.toList()));

        mapPolicyDetails.put(nPolicyId, setMenuEntries);

        LOGGER.debug("updatePoliciesMap Exit");
    }

    /**
     * Update the maps with the given data.
     *
     * @param vecDomainMappings
     *            - List of domain mappings
     */
    private synchronized void updateMainMap(List<DCDomainMapping> vecDomainMappings) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("updateMainMap(" + vecDomainMappings + ")	Enter");
        }
        // Next - the Main Map
        if(null != vecDomainMappings) {

            for (DCDomainMapping objDomainMapping : vecDomainMappings) {
                int nDomainId = objDomainMapping.getDomainID();
                int nPolicyId = objDomainMapping.getPolicyID();
                String sUserGroup = objDomainMapping.getUserGroup();
                AAServerCacheMapping cacheMapping = mapUG2ServerCacheMapping.get(sUserGroup);

                // If the UserGroup already exists in the map, then the map of
                // domain Id
                // Vs the permission class Id list must be updated. Otherwise, a
                // new entry
                // must be created in the map.
                if (null == cacheMapping) {
                    cacheMapping = new AAServerCacheMapping();
                    mapUG2ServerCacheMapping.put(sUserGroup, cacheMapping);
                }
                cacheMapping.updateMap(nDomainId, nPolicyId);
            }
        }
        LOGGER.debug("updateMainMap Exit");
    }

    /**
     * Function to return the singleton instance of the class
     *
     * This implementation uses Doug Schmidt's "double-checked locking" strategy
     * to improve performance.
     *
     * Reference :
     * http://www.javaworld.com/javaworld/jw-04-1999/jw-04-toolbox_p.html
     *
     * @return USMServerCache - The singleton instance of the class.
     *
     */
    public static AAServerCache getInstance() {
        return self;
    }

    /**
     * Assembles the security data to be returned to a specific client
     *
     * @param context Session token for the client
     * @return AAClientCacheData - client cache data
     *
     */
    synchronized AAClientCacheData retrieveClientSecurityData(ISessionContext context) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("retrieveClientSecurityData(" + context + ") Enter");
        }
        // Initialize return value
        AAClientCacheData objClientData = new AAClientCacheData();

        IEnhancedSessionContext sessionContext = (IEnhancedSessionContext) context;
        List<String> userGroups = sessionContext.getUserGroup();

        // To avoid duplicate sets of Client Mapping & policy data to be
        // returned
        Map<Integer, ClientMapping> mapDomId2ClientMapping = new HashMap<>();
        Set<Integer> setPolicyIds = new HashSet<>();

        // Get the AAServerCacheMapping for each user group associated with user
        for (String sUserGroup : userGroups) {

            AAServerCacheMapping objCacheMapping = mapUG2ServerCacheMapping.get(sUserGroup);

            // Copy corresponding Client Mapping into temp map
            if (null != objCacheMapping) {

                Map<Integer, Integer> mapDomain2PolicyIds = objCacheMapping.getMapDomainId2PolicyId();
                int [] allDomainIds = DCSubsystemSAP.getAllDomains().stream().mapToInt(DCDomainData::getDomainID).toArray();

                // Add NO_ACCESS Mappings
                for (int domainId : allDomainIds) {
                    if (!mapDomain2PolicyIds.containsKey(domainId)) {
                        mapDomain2PolicyIds.put(domainId, -1);
                    }
                }

                for (Entry<Integer, Integer> mapEntry : mapDomain2PolicyIds.entrySet()) {
                    Integer objDomainValue = mapEntry.getKey();
                    Integer objPolicyValue = mapEntry.getValue();

                    // Retrieve client mapping for given domain id
                    ClientMapping objClientMapping = mapDomId2ClientMapping.get(objDomainValue);

                    if (null == objClientMapping) {
                        objClientMapping = new ClientMapping();
                        objClientMapping.domainId = objDomainValue;

                        mapDomId2ClientMapping.put(objDomainValue, objClientMapping);
                    }

                    objClientMapping.policyIds.add(objPolicyValue);
                    setPolicyIds.add(objPolicyValue);
                }
            }
        } // Fault ID XX -

        // Construct the client mapping List from the map & add it to the return
        // value object
        List<ClientMapping> vecClientMappings = objClientData.getClientMappingVector();
        if(mapDomId2ClientMapping.size() != 0) {
            for (Entry<Integer, ClientMapping> mapEntry : mapDomId2ClientMapping.entrySet()) {
                ClientMapping objClientMapping = mapEntry.getValue();
                vecClientMappings.add(objClientMapping);
            }
        }

        // Construct the Policy List & add it to the return value object
        if(setPolicyIds.size() != 0) {
            // Iterate through all the permission class Ids &
            // add them to the return value.
            List<PAPolicyData> vecPolicies = objClientData.getPolicies();
            List<PAPolicyData> lstPolicies = PASubsystemSAP.getAllPolicies();

            for (PAPolicyData objPolicyData : lstPolicies) {
                Integer objPolicyId = objPolicyData.getPolicyID();

                if (setPolicyIds.contains(objPolicyId)) {
                    vecPolicies.add(objPolicyData);
                }
            }
        }
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("retrieveClientSecurityData Exit. Returning : " + objClientData);
        }
        return objClientData;
    }

    /**
     * Initializes the security data cache on server side, by reading the
     * necessary data from the corresponding components. If security data has
     * been changed after initialization, it will be re-built dynamically.
     *
     * Called from AAServerLifeCycleController.initialize
     *
     */
    synchronized void initializeServerCache() {
        LOGGER.debug("initializeServerCache()		Enter");
        // Clear all maps
        cleanup();

        // Reload all maps
        List<PAPolicyData> vecPolicies = PASubsystemSAP.getAllPolicies();

        List vecDomainMappings = DCSubsystemSAP.getAllDomainMappings();

        updatePoliciesMap(vecPolicies);
        updateMainMap(vecDomainMappings);

        dumpCache();
        LOGGER.debug("initializeServerCache()		Exit");
    }

    /**
     * Cleans the created cache on server side
     */
    public synchronized void cleanup() {
        LOGGER.debug("cleanup() 	Entry");

        mapUG2ServerCacheMapping.clear();
        mapPolicyDetails.clear();

        LOGGER.debug("cleanup() 	Exit");
    }

    /**
     * Checks whether the current user is allowed to use the given operation
     *
     * @param String
     *            The name of the operation to be analyzed
     * @return false, if the operation is not permitted true, otherwise
     */

    /**
     *
     * @param strOperation - he name of the operation to be analyzed
     * @param sessionContext - Client session token created at logged in
     * @return true if permission is granted
     */
    public boolean checkOperationPermission(java.lang.String strOperation, ISessionContext sessionContext) {
        LOGGER.debug("checkOperationPermission(" + strOperation + "," + sessionContext + ")		Enter");

        // a user which is of type system should be able to perform any action and see any element
        if(isSystemUser(sessionContext)) {
            return true;
        }

        synchronized (this) {
            // Assume that no permissions exist.
            boolean bResult = false;

            // Collate all accessible Policy Ids
            Set<Integer> setPolicyIds = getAccessiblePolicyIds(sessionContext);

            // Check whether the given operation is present in any of the policies
            if(setPolicyIds.size() != 0) {
                // Iterate through all the permission class Ids to check if the
                // the required command can be executed on at least one of them.
                for (Integer objPolicyId : setPolicyIds) {
                    // Determine the command Ids in the permission class
                    // identified by its Id.
                    Set<String> setMenuEntries = mapPolicyDetails.get(objPolicyId);
                    if (null != setMenuEntries) {
                        bResult = setMenuEntries.contains(strOperation);
                        // If the value returned is true, the operation can be
                        // executed.
                        if (bResult) {
                            break;
                        }
                    }
                }

                // Indicate that permissions were not sufficient.
                if(!bResult) {
                    // No policies containing the given menu entry
                    LOGGER.info("The operator has no permissions to execute the command, because there are NO! associated policies containing the given menu entry: " + strOperation);
                }

            } else { // No associated policies
                LOGGER.info("The operator has no permissions to execute the command, because there are NO! associated policies with the operator. " + strOperation);
            }
            LOGGER.debug("checkOperationPermission Exit. Returning : " + bResult);

            return bResult;
        }
    }

    /**
     * Checks whether the current user is allowed to manage the desired objects
     * by means that the objects are part of the user's security domain. This
     * method is called by plug-ins to decide whether a specific object may be
     * displayed on the GUI or not.
     *
     * @param arDesiredObjects - [] List of objects to be analzyed
     * @param sessionContext - Client session token created at logged in
     * @return p_arDesiredObjects IManagedObjectId[] the set of valid objects
     *         being a subset of arDesiredObjects
     */
    IManagedObjectId[] checkObjectPermission(IManagedObjectId[] arDesiredObjects, IEnhancedSessionContext sessionContext) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("checkObjectPermission(" + USMCommonHelper.getStringForArrayOfIManagedObjectId(arDesiredObjects) + "," + sessionContext + ")		Enter");
        }

        // a user which is of type system should be able to perform any action and see any element
        if(isSystemUser(sessionContext)) {
            return arDesiredObjects;
        }

        synchronized (this) {
            // Collate all accessible Domain Ids
            BitSet bitsetDomainIds = getAccessibleDomainIds(sessionContext);

            // List<ManagedObjectId>
            List<IManagedObjectId> allowedObjects = new ArrayList<>();

            // Check whether each of the given Managed Objects are present in any of
            // the domains
            if(bitsetDomainIds.size() != 0) {
                final int GLOBAL_DOMAIN_ID = 0;
                // Add a check to see if the User has the GLOBAL Domain Associated
                if(bitsetDomainIds.get(GLOBAL_DOMAIN_ID)) {
                    LOGGER.info("Security Check circumvented. User has access to GLOBAL Domain.");
                    return arDesiredObjects;
                } else {
                    for (IManagedObjectId idManagedObject : arDesiredObjects) {
                        BitSet bitsetACLCurrentNE = BSSubsystemSAP.getACLForSecurableObject(idManagedObject);

                        if ((bitsetACLCurrentNE != null) && (bitsetACLCurrentNE.intersects(bitsetDomainIds))) {
                            // At least one matching domain
                            LOGGER.debug("Object {} allowed access.", idManagedObject);
                            allowedObjects.add(idManagedObject);
                        }
                    }
                }
            } else {
                LOGGER.error("The operator has no permissions to access the object, because there are NO! associated domains with the operator.");
            }

            IManagedObjectId[] arr = makeArray(allowedObjects);

            if(LOGGER.isDebugEnabled()) {
                LOGGER.debug("checkObjectPermission Exit. Returning : " + USMCommonHelper.getStringForArrayOfIManagedObjectId(arr));
            }
            // Convert List to Array
            return arr;
        }
    }

    /**
     * Checks whether the current user is allowed to apply the given operation
     * to the desired objects
     *
     * @param strOperation - The name of the operation to be applied
     * @param arDesiredObjects - List of desired objects to be analzyed
     * @param sessionContext - Client session token created at logged in
     * @return ManagedObjectItem[] - the set of valid objects for the given operation being a subset of arDesiredObjects
     */
    public IManagedObjectId[] checkOperationPermission(String strOperation, IManagedObjectId[] arDesiredObjects, IEnhancedSessionContext sessionContext) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("checkOperationPermission(" + strOperation + "," + USMCommonHelper.getStringForArrayOfIManagedObjectId(arDesiredObjects) + "," + sessionContext + ")		Enter");
        }

        // a user which is of type system should be able to perform any action and see any element
        if(isSystemUser(sessionContext)) {
            return arDesiredObjects;
        }

        synchronized (this) {
            // List<ManagedObjectId>
            List<IManagedObjectId> vecAllowedObjects = new ArrayList<>();
            boolean bHasGlobalMappingAccess = hasAccessToGlobalMapping(sessionContext);

            if(bHasGlobalMappingAccess) {
                LOGGER.info("Security Check circumvented. Has access to GLOBAL Mapping.");
                return arDesiredObjects;
            } else {
                // Check whether each of the given Managed Objects are present in
                // any of the domains
                for (IManagedObjectId idManagedObject : arDesiredObjects) {
                    BitSet bitSetACLCurrentNE = BSSubsystemSAP.getACLForSecurableObject(idManagedObject);

                    if (bitSetACLCurrentNE != null) {
                        // Remove workaround later, when BS is fully implemented.
                        // For now, assume NE belongs only to GLOBAL domain.
                        // Fault ID 35 - Provide default handling for domaining
                        // BitSet bitsetACLCurrentNE = new BitSet();
                        // bitsetACLCurrentNE.set(0);

                        Set<Integer> setPolicyIds = new HashSet<>();

                        // Check each mapping
                        List<String> userGroups = sessionContext.getUserGroup();

                        for (String strUserGroup : userGroups) {
                            AAServerCacheMapping objCacheMapping = mapUG2ServerCacheMapping.get(strUserGroup);
                            if (null != objCacheMapping) {
                                Map<Integer, Integer> mapDomain2PolicyIds = objCacheMapping.getMapDomainId2PolicyId();
                                for (Entry<Integer, Integer> mapEntry : mapDomain2PolicyIds.entrySet()) {
                                    Integer objDomainValue = mapEntry.getKey();
                                    Integer objPolicyValue = mapEntry.getValue();

                                    boolean bDomainAllowed = bitSetACLCurrentNE.get(objDomainValue);

                                    if (bDomainAllowed) {
                                        setPolicyIds.add(objPolicyValue);
                                    }
                                }
                            }
                        }

                        boolean bResult = false;

                        // Check whether the given operation is present in any of
                        // the policies
                        if (setPolicyIds.size() != 0) {
                            // Iterate through all the permission class Ids to check
                            // if the
                            // the required command can be executed on at least one
                            // of them.
                            for (Integer objPolicyId : setPolicyIds) {
                                // Determine the command Ids in the permission class
                                // identified by its Id.

                                Set setMenuEntries = mapPolicyDetails.get(objPolicyId);
                                if (null != setMenuEntries) {
                                    bResult = setMenuEntries.contains(strOperation);

                                    // If the value returned is true, the operation
                                    // can be executed.
                                    if (bResult) {
                                        break;
                                    }
                                }
                            }

                            // Indicate that permissions were not sufficient.
                            if (!bResult) {
                                // No policies containing the given menu entry
                                LOGGER.error("The operator has no permissions to execute the command, because there are NO! associated policies containing the given menu entry." + strOperation);
                            }
                        } else { // No associated policies
                            LOGGER.debug("The operator has no permissions to execute the command, because there are NO! associated policies with the operator." + strOperation);
                        }
                        if (bResult) {
                            LOGGER.debug("Object " + idManagedObject + " allowed access.");
                            vecAllowedObjects.add(idManagedObject);
                        }
                    }
                }
            }
            IManagedObjectId[] arr = makeArray(vecAllowedObjects);

            if(LOGGER.isDebugEnabled()) {
                LOGGER.debug("checkOperationPermission Exit. Returning : " + USMCommonHelper.getStringForArrayOfIManagedObjectId(arr));
            }
            // Convert List to Array
            return arr;
        }
    }

    /**
     *
     * @param criteria
     * @param sessionContext
     * @return
     */
    IManagedObjectId[] filterVisibleObjects(IManagedObjectMarkableId[] criteria, IEnhancedSessionContext sessionContext) {
        LOGGER.debug("filterVisibleObjects Enter");
        return filterSecurableObjects(
                byMOType(criteria),
                byId(criteria),
                byVisibility(sessionContext));

    }

    /**
     *
     * @param criteria
     * @param sessionContext
     * @param operation
     * @return
     */
    IManagedObjectId[] filterAccessibleObjects(IManagedObjectMarkableId[] criteria,
                                                            IEnhancedSessionContext sessionContext,
                                                            String operation) {
        LOGGER.debug("filterAccessibleObjects Enter");
        return filterSecurableObjects(
                byMOType(criteria),
                byId(criteria),
                byAccess(sessionContext, operation));
    }

    /**
     *
     * @param byMOType
     * @param byId
     * @param byCustomPredicate
     * @return
     */
    private IManagedObjectId[] filterSecurableObjects(Predicate<? super BSSecurableObject> byMOType,
                                        Predicate<? super BSSecurableObject> byId,
                                        Predicate<? super BSSecurableObject> byCustomPredicate) {
        LOGGER.debug("filterSecurableObjects Enter");

        return BSSubsystemSAP.getAllSecurableObjectsWithACL().stream()
                .filter(byMOType)
                .filter(byId)
                .filter(byCustomPredicate)
                .map(toManagedObject())
                .toArray(IManagedObjectId[]::new);
    }

    /**
     *
     * @return
     */
    private Function<BSSecurableObject, IManagedObjectId> toManagedObject() {
        return secObject -> {
            IManagedObjectId id = null;

            if(secObject.getManagedObjectType().equals(NE)){
                id = new NEIdItem(Integer.parseInt(secObject.getObjectName()));
            } else if(secObject.getManagedObjectType().equals(SECURABLE_OBJECT)) {
                id = new SecurableObjectContainerIdItem(secObject.getObjectName());
            } else if(secObject.getManagedObjectType().equals(COMMON_CONTAINER)) {
                id = new CommonContainerIdItem(Long.parseLong(secObject.getObjectName().split("=")[1]));
            }

            return id;
        };
    }

    private Predicate<? super BSSecurableObject> byAccess(IEnhancedSessionContext sessionContext, String operation) {
        return bsSecurableObject -> {
            // if the user is a system user, return true without checking
            if(isSystemUser(sessionContext)) {
                return true;
            }

            synchronized (this) {
                BitSet bitsetACLCurrentNE = bsSecurableObject.getBitSetACL();

                if (bitsetACLCurrentNE != null) {
                    List<String> vecUserGroups = sessionContext.getUserGroup();

                    // User Groups
                    for (String vecUserGroup : vecUserGroups) {
                        // Map Domain-Policy
                        AAServerCacheMapping objCacheMapping = mapUG2ServerCacheMapping.get(vecUserGroup);

                        if (null != objCacheMapping) {
                            Map<Integer, Integer> mapDomain2PolicyIds = objCacheMapping.getMapDomainId2PolicyId();
                            List<Integer> accessibleDomainsIds = operation != null ? getAccessibleDomainsWithOperation(mapDomain2PolicyIds, operation)
                                            : getAccessibleDomains(mapDomain2PolicyIds);

                            for (Integer domainId : accessibleDomainsIds) {
                                if (bsSecurableObject.belongsToDomain(domainId)) {
                                    return true;
                                }
                            }
                        }
                    }
                }
                return false;
            }

        };
    }


    private Predicate<? super BSSecurableObject> byVisibility(IEnhancedSessionContext sessionContext) {
        return bsSecurableObject -> {
            // a user which is of type system should be able to perform any action and see any element
            if(isSystemUser(sessionContext)) {
                return true;
            }

            synchronized (this) {
                BitSet bitSetACLCurrentNE = bsSecurableObject.getBitSetACL();
                List<String> vecUserGroups = sessionContext.getUserGroup();

                if (bitSetACLCurrentNE != null) {
                    // User Groups
                    for (String vecUserGroup : vecUserGroups) {
                        // Map Domain-Policy
                        AAServerCacheMapping objCacheMapping = mapUG2ServerCacheMapping.get(vecUserGroup);

                        // Check if all mappings are NO_ACCESS
                        if(objCacheMapping == null) {
                            return true;
                        } else {
                            Map<Integer, Integer> mapDomain2PolicyIds = objCacheMapping.getMapDomainId2PolicyId();
                            // Check NO_ACCESS
                            for (int domainId : bsSecurableObject.getACL().getAclList()){
                                if(!mapDomain2PolicyIds.containsKey(domainId)){
                                    return true;
                                }
                            }
                            // Check NO_VISIBILITY
                            List<Integer> visibleDomainsIds = getVisibleDomains(mapDomain2PolicyIds);
                            for (Integer domainId : visibleDomainsIds) {
                                if (bsSecurableObject.belongsToDomain(domainId)) {
                                    return true;
                                }
                            }
                        }
                    }
                }
                return false;
            }
        };
    }

    /**
     * Checks the given session context to assert that the session is of type system, which will grant permission
     * to do any action
     *
     * @param sessionContext the session context to validate
     * @return true if the session is of type 'System'; false otherwise
     */
    private boolean isSystemUser(ISessionContext sessionContext) {
        return AASessionStore.getInstance().isSessionOfType(sessionContext, SessionType.SYSTEM);
    }

    /**
     *
     * @param mapDomainPolicyIds
     * @return
     */
    private List<Integer> getVisibleDomains(Map<Integer, Integer> mapDomainPolicyIds) {
        return mapDomainPolicyIds
                .entrySet().stream()
                .filter(mapPolicyDomain -> mapPolicyDomain.getValue() != POLICY_NO_VISIBILITY.getPolicyID())
                .map(Entry::getKey)
                .collect(Collectors.toList());
    }

    /**
     *
     * @param mapDomainPolicyIds
     * @return
     */
    private List<Integer> getAccessibleDomains(Map<Integer, Integer> mapDomainPolicyIds) {
        return mapDomainPolicyIds
                .entrySet().stream()
                .filter(mapDomainPolicies -> (!mapDomainPolicyIds.isEmpty()
                        && (mapDomainPolicies.getValue() != POLICY_NO_VISIBILITY.getPolicyID()) &&
                        (mapDomainPolicies.getValue() != POLICY_NO_ACCESS.getPolicyID())))
                .map(Entry::getKey)
                .collect(Collectors.toList());
    }

    private List<Integer> getAccessibleDomainsWithOperation(Map<Integer, Integer> mapDomainPolicyIds,String operation) {
        return getAccessibleDomains(mapDomainPolicyIds)
                .stream()
                .filter(domainId -> mapPolicyDetails.get(mapDomainPolicyIds.get(domainId)).contains(operation))
                .collect(Collectors.toList());
    }

    private Predicate<? super BSSecurableObject> byId(IManagedObjectMarkableId[] criteria) {
        return bsSecurableObject -> {
            if (criteria.length >= 1 && criteria[0].countMarks() != 0) {
                for(IManagedObjectMarkableId idMarkable : criteria){
                    if(bsSecurableObject.getUniqueName().equalsIgnoreCase(idMarkable.key())){
                        return true;
                    }
                }
            } else if (criteria.length == 1 && criteria[0].countMarks() == 0){
                return true;
            }

            return false;
        };
    }

    private Predicate<? super BSSecurableObject> byMOType(IManagedObjectMarkableId[] criteria) {
        return bsSecurableObject -> {
            if (criteria.length == 1 && criteria[0].countMarks() == 0) {
                return bsSecurableObject.getManagedObjectType().equals(criteria[0].moType());
            } else {
                return true;
            }
        };
    }

    /**
     * Helper function to check if the user has access to the GLOBAL Mapping
     *
     * @param ctx - The Context of the User
     * @return boolean Indicates whether the user has access to GLOBAL Mapping. True indicates has access.
     */
    private synchronized boolean hasAccessToGlobalMapping(IEnhancedSessionContext ctx) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("hasAccessToGlobalMapping(" + ctx + ") Entry");
        }
        final int GLOBAL_ID = 0;
        boolean bHasAccess = false;
        List<String> vecUGs = ctx.getUserGroup();
        for (String vecUG : vecUGs) {
            AAServerCacheMapping objCacheMapping = mapUG2ServerCacheMapping.get(vecUG);
            if (null != objCacheMapping) {
                int nPolID = objCacheMapping.getPolicyId(GLOBAL_ID);
                if (nPolID == GLOBAL_ID) {
                    bHasAccess = true;
                    break;
                }
            }
        }
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("hasAccessToGlobalMapping Exit. Returning : " + bHasAccess);
        }
        return bHasAccess;
    }

    /**
     * Retruns the Domain IDs
     *
     * @param sessionContext
     *            - Client session token created at logged in
     * @return - Bitset of Domain IDs
     */
    private synchronized BitSet getAccessibleDomainIds(IEnhancedSessionContext sessionContext) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("getAccessibleDomainIds(" + sessionContext + ") Entry");
        }

        BitSet bitsetDomainIds = new BitSet(DCGlobal.MAX_DOMAINS);
        List<String> vecUserGroups = sessionContext.getUserGroup();
        for (String vecUserGroup : vecUserGroups) {
            AAServerCacheMapping objCacheMapping = mapUG2ServerCacheMapping.get(vecUserGroup);
            if (null != objCacheMapping) {
                Map<Integer, Integer> mapDomain2PolicyIds = objCacheMapping.getMapDomainId2PolicyId();
                for (Entry<Integer, Integer> mapEntry : mapDomain2PolicyIds.entrySet()) {
                    Integer objDomainValue = mapEntry.getKey();
                    bitsetDomainIds.set(objDomainValue);
                }
            }
        }
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("getAccessibleDomainIds Exit. Returning : " + bitsetDomainIds);
        }
        return bitsetDomainIds;

    }

    /**
     * Retruns the policy IDs
     *
     * @param sessionContext
     *            - Client session token created at logged in
     * @return - Bitset of policy IDs
     */
    private synchronized Set<Integer> getAccessiblePolicyIds(ISessionContext sessionContext) {
        LOGGER.debug("getAccessiblePolicyIds({}) Entry", sessionContext);

        Set<Integer> setPolicyIds = new HashSet<>();
        List<String> vecUserGroups = sessionContext.getUserGroup();

        for (String vecUserGroup : vecUserGroups) {
            AAServerCacheMapping objCacheMapping = mapUG2ServerCacheMapping.get(vecUserGroup);
            if (null != objCacheMapping) {
                Map<Integer, Integer> mapDomain2PolicyIds = objCacheMapping.getMapDomainId2PolicyId();
                setPolicyIds.addAll(mapDomain2PolicyIds.values());
            }
        }

        LOGGER.debug("getAccessiblePolicyIds Exit. Returning : {}", setPolicyIds);
        return setPolicyIds;
    }

    /**
     * Helper method to create manageObject array for given list of managed
     * object
     *
     * @param vecManagedObjects
     *            - list of managed object as List
     * @return IManagedObject[] - Array of managed object
     */
    private IManagedObjectId[] makeArray(List<IManagedObjectId> vecManagedObjects) {
        LOGGER.debug("makeArray(" + vecManagedObjects + ")		Enter");
        IManagedObjectId[] arAllowedObjects = null;

        int nAllowedObjectsCount = vecManagedObjects.size();
        if(0 != nAllowedObjectsCount) {
            arAllowedObjects = new IManagedObjectId[nAllowedObjectsCount];

            for(int nAllowedObjectsIndex = 0; nAllowedObjectsIndex < nAllowedObjectsCount; ++nAllowedObjectsIndex) {
                arAllowedObjects[nAllowedObjectsIndex] = vecManagedObjects.get(nAllowedObjectsIndex);
            }
        }
        LOGGER.debug("makeArray(" + vecManagedObjects + ")		Exit");
        return arAllowedObjects;
    }

    /**
     * Notification handler for USM messages
     *
     * @param msg
     *            - Message recieved for updating the client cache
     */
    public void handleNotification(USMMessage msg) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleNotification({})		Enter", msg);
        }
        // Fault ID 4 - Improper handling of notification in Authentication
        // Client and Server
        boolean bDumpCache = false;
        USMBaseMsgType msgType = msg.getMessageType();

        LOGGER.debug("Received notification of type {}", msgType);

        if(msgType.equals(PAMessageType.S_PA_NOT_POLICY_CREATED)) {
            handlePolicyCreated(msg);
            bDumpCache = true;

        } else if(msgType.equals(PAMessageType.S_PA_NOT_POLICY_MODIFIED)) {
            handlePolicyModified(msg);
            bDumpCache = true;

        } else if(msgType.equals(PAMessageType.S_PA_NOT_POLICY_DELETED)) {
            handlePolicyDeleted(msg);
            bDumpCache = true;
        } else if(msgType.equals(DCMessageType.DC_NOT_DOMAIN_DELETED)) {
            handleDomainDeleted(msg);
            bDumpCache = true;

        } else if(msgType.equals(DCMessageType.DC_NOT_MAPPINGS_MODIFIED)) {
            handleDomainMappingsModified(msg);
            bDumpCache = true;
        }

        if((USMCommonHelper.isDetailedTracesEnabled()) && bDumpCache) {
            if(LOGGER.isDebugEnabled()) {
                LOGGER.debug("Cache data after notification handling - ");
                dumpCache();
            }
        }
        LOGGER.debug("handleNotification Exit");
    }

    /**
     * Helper method for domain mapping modification Notifications
     *
     * @param msg
     *            - The notification message
     */
    private synchronized void handleDomainMappingsModified(USMMessage msg) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleDomainMappingsModified({}) Enter", msg);
        }

        int nMappingsCount = msg.popInteger();

        if(USMCommonHelper.isDetailedTracesEnabled()) {
            if(LOGGER.isDebugEnabled()) {
                LOGGER.debug("Modified mapping Count - " + nMappingsCount);
            }
        }

        for(int nMappingsIndex = 0; nMappingsIndex < nMappingsCount; ++nMappingsIndex) {
            DCDomainMapping domMapping = new DCDomainMapping();
            domMapping.popMe(msg);

            if(USMCommonHelper.isDetailedTracesEnabled()) {
                if(LOGGER.isDebugEnabled()) {
                    LOGGER.debug("Modified mapping[" + nMappingsIndex + "] details - " + domMapping);
                }
            }

            String strUserGroup = domMapping.getUserGroup();
            int nDomainId = domMapping.getDomainID();
            int nPolicyId = domMapping.getPolicyID();
            Integer objDomainId = nDomainId;
            Integer objPolicyId = nPolicyId;

            AAServerCacheMapping objCacheMapping = mapUG2ServerCacheMapping.get(strUserGroup);

            // Check if it is a deleted mapping
            if(nPolicyId == -1) {
                if(null != objCacheMapping) {
                    Map<Integer, Integer> mapDom2PolicyIds = objCacheMapping.getMapDomainId2PolicyId();
                    mapDom2PolicyIds.remove(objDomainId);
                }
                // otherwise, it is a created or modified mappings
            } else {
                if(null == objCacheMapping) {
                    objCacheMapping = new AAServerCacheMapping();
                    mapUG2ServerCacheMapping.put(strUserGroup, objCacheMapping);
                }
                Map<Integer, Integer> mapDom2PolicyIds = objCacheMapping.getMapDomainId2PolicyId();
                mapDom2PolicyIds.put(objDomainId, objPolicyId);
            }
        }
        LOGGER.debug("handleDomainMappingsModified Exit");
    }

    /**
     * Helper method for domain deletion Notifications
     *
     * @param msg
     *            - The notification message
     */
    private synchronized void handleDomainDeleted(USMMessage msg) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleDomainDeleted(" + msg + ")		Enter");
        }
        DCDomainData objDomain = new DCDomainData();
        objDomain.popMe(msg);

        if(USMCommonHelper.isDetailedTracesEnabled()) {
            if(LOGGER.isDebugEnabled()) {
                LOGGER.debug("Deleted domain details - ");
                LOGGER.debug("    Id - {}", objDomain.getDomainID());
                LOGGER.debug("    Name - {}", objDomain.getDomainName());
            }
        }

        Integer objDomainId = objDomain.getDomainID();

        Iterator<AAServerCacheMapping> iterCacheMapping = mapUG2ServerCacheMapping.values().iterator();

        while(iterCacheMapping.hasNext()) {
            AAServerCacheMapping objCacheMapping = iterCacheMapping.next();
            Map<Integer, Integer> mapDom2PolicyIds = objCacheMapping.getMapDomainId2PolicyId();
            mapDom2PolicyIds.remove(objDomainId);

            if(mapDom2PolicyIds.isEmpty()) {
                iterCacheMapping.remove();
            }
        }
        LOGGER.debug("handleDomainDeleted Exit");
    }

    /**
     * Helper method for policy deletion Notifications
     *
     * @param msg
     *            - The notification message
     */
    private synchronized void handlePolicyDeleted(USMMessage msg) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("handlePolicyDeleted({})		Enter", msg);
        }
        // Fault ID 9 - Provide default handling for domaining

        int nDeletedPolicyCount = msg.popInteger();

        for(int nPolicyIndex = 0; nPolicyIndex < nDeletedPolicyCount; ++nPolicyIndex) {

            // Pop objects of type PAPolicyNameAndID
            PAPolicyId objPolicyNameAndId = new PAPolicyId();
            objPolicyNameAndId.popMe(msg);

            if(USMCommonHelper.isDetailedTracesEnabled()) {
                if(LOGGER.isDebugEnabled()) {
                    LOGGER.debug("Deleted policy details - ");
                    LOGGER.debug("    Id - " + objPolicyNameAndId.getPolicyID());
                    LOGGER.debug("    Name - " + objPolicyNameAndId.getPolicyName());
                }
            }

            Integer objPolicyId = objPolicyNameAndId.getPolicyID();

            // Fault ID 9 - NullPointerException in Authentication on Policy
            // Deleted (both server and client)
            mapPolicyDetails.remove(objPolicyId);
        }
        LOGGER.debug("handlePolicyDeleted Exit");
    }

    /**
     * Helper method for policy modification Notifications
     *
     * @param msg
     *            - The notification message
     */
    private synchronized void handlePolicyModified(USMMessage msg) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("handlePolicyModified(" + msg + ")		Enter");
        }
        PAPolicyData objPolicy = new PAPolicyData();
        objPolicy.popMe(msg);

        updatePoliciesMap(objPolicy);
        LOGGER.debug("handlePolicyModified Exit");
    }

    /**
     * Helper method for policy creation Notifications
     *
     * @param msg
     *            - The notification message
     */
    private synchronized void handlePolicyCreated(USMMessage msg) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("handlePolicyCreated(" + msg + ")		Enter");
        }
        PAPolicyData objPolicy = new PAPolicyData();
        objPolicy.popMe(msg);

        updatePoliciesMap(objPolicy);
        LOGGER.debug("handlePolicyCreated Exit");
    }

    /**
     * Helper method for Cache dumping
     */
    private synchronized void dumpCache() {
        if(USMCommonHelper.isDetailedTracesEnabled()) {
            if(LOGGER.isDebugEnabled()) {
                LOGGER.debug("Dumping the full cache contents : ");

                int nPolicyCount = mapPolicyDetails.size();
                LOGGER.debug("Policy Count - " + nPolicyCount);

                for (Entry<Integer, Set<String>> o : mapPolicyDetails.entrySet()) {
                    int nPolicyValue = o.getKey();
                    Set<String> setMenuEntries = o.getValue();

                    LOGGER.debug("    Policy Id = {}", nPolicyValue);
                    LOGGER.debug("    Menus - ");

                    int nMenuIndex = 0;
                    for (String setMenuEntry : setMenuEntries) {
                        LOGGER.debug("        " + nMenuIndex++ + " : " + setMenuEntry);
                    }
                }

                LOGGER.debug("Dumping the mappings : ");

                for (Entry<String, AAServerCacheMapping> objMapEntry : mapUG2ServerCacheMapping.entrySet()) {

                    String strUserGroup = objMapEntry.getKey();
                    AAServerCacheMapping objCacheMapping = objMapEntry.getValue();

                    LOGGER.debug("Mappings for user group " + strUserGroup + " : ");

                    Map<Integer, Integer> mapDom2PolicyIds = objCacheMapping.getMapDomainId2PolicyId();
                    for (Entry<Integer, Integer> objMapEntry2 : mapDom2PolicyIds.entrySet()) {
                        Integer objDomainId = objMapEntry2.getKey();
                        Integer objPolicyId = objMapEntry2.getValue();

                        LOGGER.debug("   Domain - " + objDomainId + ", Policy - " + objPolicyId);
                    }
                }
            }
        }
    }



}
