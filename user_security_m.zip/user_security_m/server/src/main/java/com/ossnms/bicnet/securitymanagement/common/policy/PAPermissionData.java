package com.ossnms.bicnet.securitymanagement.common.policy;

import com.ossnms.bicnet.securitymanagement.api.common.USMSerializable;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;

import java.util.ArrayList;
import java.util.List;

/**
 * created on 6/5/2015
 */
public class PAPermissionData implements USMSerializable {

    private static final long serialVersionUID = 1L;

    /**
     *
     */
    private int id;

    /**
     *
     */
    private String name;

    /**
     *
     */
    private String label;

    /**
     * Data member to hold the List of permission items assigned to the permission
     */
    private List<PAPermissionItemData> permissionItemDataList;

    public PAPermissionData() {
        this.id = -1;
        this.name = "";
        this.label = "";
        this.permissionItemDataList = new ArrayList<>();
    }

    /**
     *
     * @param id - The Unique Identifier for the PermissionItem
     * @param name  - Name of the Permission Item
     * @param label - Label of the Permission Item
     */
    public PAPermissionData(int id, String name, String label) {
        this.id = id;
        this.name = name;
        this.label = label;
        this.permissionItemDataList = new ArrayList<>();
    }


    public PAPermissionData(int id, String name, String label, List<PAPermissionItemData> permissionItemDataList) {
        this.id = id;
        this.name = name;
        this.label = label;
        this.permissionItemDataList = permissionItemDataList;
    }

    /**
     *
     */
    public int getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     */
    public String getName() {
        return name;
    }

    /**
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     */
    public String getLabel() {
        return label;
    }

    /**
     * @param label
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     *
     * @return
     */
    public List<PAPermissionItemData> getPermissionItems() {
        return permissionItemDataList;
    }

    /**
     *
     * @param permissionItems
     */
    public void setPermissionItems(List<PAPermissionItemData> permissionItems) {
        this.permissionItemDataList = permissionItems;
    }

    @Override
    public String toString() {
        return name;
    }

    /**
     *
     * @param o
     * @return
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if ((o == null) || (getClass() != o.getClass())) {
            return false;
        }

        PAPermissionData that = (PAPermissionData) o;

        if (id != that.id) {
            return false;
        }
        if (name != null ? !name.equals(that.name) : that.name != null) {
            return false;
        }
        return !(label != null ? !label.equals(that.label) : that.label != null);

    }

    /**
     *
     * @return
     */
    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (label != null ? label.hashCode() : 0);
        return result;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public void pushMe(USMMessage msg) {
        msg.pushInteger(id);
        msg.pushString(name);
        msg.pushString(label);
        //Push configured Permission Item List
        for(PAPermissionItemData permissionItemData : permissionItemDataList){
            permissionItemData.pushMe(msg);
        }
        //push Size of Permission Item List
        msg.pushInteger(permissionItemDataList.size());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void popMe(USMMessage msg) {
        //Pop size of Permission Items
        int permissionItemDataListSize = msg.popInteger();

        for (int idx = 0 ; idx<permissionItemDataListSize ; idx ++){
            PAPermissionItemData permissionItemData = new PAPermissionItemData();
            permissionItemData.popMe(msg);
            permissionItemDataList.add(permissionItemData);
        }

        label = msg.popString();
        name = msg.popString();
        id = msg.popInteger();
    }
}
