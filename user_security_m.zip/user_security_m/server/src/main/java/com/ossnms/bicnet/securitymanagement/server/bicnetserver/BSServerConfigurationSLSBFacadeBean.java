/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 09-02-2005	Muyeen Munaver  CF000060-01   CF USM GUI Requirements
 * 05-May-2005  Babu B  CF001312   Master-Master Replication for Sun ONE DS
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.bicnetserver;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityServerConfigurationPrivateFacadeLocal;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityServerConfigurationPrivateFacadeRemote;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import java.util.List;

/**
 * Bean class for the implementation for the server configuration related private
 * facade.
 **/
@Stateless(name = "BSServerConfigurationSLSBFacade")
@Local(ISecurityServerConfigurationPrivateFacadeLocal.class)
@Remote(ISecurityServerConfigurationPrivateFacadeRemote.class)
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class BSServerConfigurationSLSBFacadeBean implements ISecurityServerConfigurationPrivateFacadeLocal, ISecurityServerConfigurationPrivateFacadeRemote {

	/**
	 * Data member to hold the POJO class that will be used for retrieving
	 * results of the functions.
	 */
	private BSServerConfigurationPOJOImpl pojo= new BSServerConfigurationPOJOImpl();

	public USMMessage getConfiguredCFs(ISessionContext p_ctx) throws BcbSecurityException {
		return pojo.getConfiguredCFs(p_ctx);
	}

	public USMMessage removeCFsFromUSM(ISessionContext p_ctx, List pLstCFs) throws BcbSecurityException {
		return pojo.removeCFsFromUSM(p_ctx, pLstCFs);
	}

	public USMMessage getManagedSecurableElmsForCF(ISessionContext p_ctx, BSTransBicNetCFInfo p_CF)
			throws BcbSecurityException {
		return pojo.getManagedSecurableElmsForCF(p_ctx, p_CF);
	}

	public USMMessage synchSecObjsWithCFs(ISessionContext p_ctx, List p_LstCfs) throws BcbSecurityException {
		return pojo.synchSecObjsWithCFs(p_ctx, p_LstCfs);
	}

	public USMMessage updateACLForSecurableObjects(List pLstSecurableObj, List pLstDomains, List pLstFailedSecurableObjs, boolean p_Assign) {
		return pojo.updateACLForSecurableObjects(pLstSecurableObj, pLstDomains, pLstFailedSecurableObjs, p_Assign);
	}
}