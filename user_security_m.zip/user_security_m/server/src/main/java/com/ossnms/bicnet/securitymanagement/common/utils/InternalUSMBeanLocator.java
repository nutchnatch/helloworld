package com.ossnms.bicnet.securitymanagement.common.utils;

import org.apache.log4j.Logger;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 * created on 29/8/2014
 *
 * This class provides a simple interface to find beans configured under the specified
 * JNDI Domain, which in this case is 'securitymgmt'
 *
 */
public final class InternalUSMBeanLocator {

    private static final Logger logger = Logger.getLogger(InternalUSMBeanLocator.class);

    private static final String JNDI_PREFIX = "java:global/bicnet/securitymgmt/";

    private InternalUSMBeanLocator(){}

    /**
     * Using the JNDI prefix, will search for beans configured using the specified interface (or class)
     *
     * @param mappedInterface the type of the configured bean
     * @param <T> the type of the bean
     * @return the bean, if exists and is configured with such type, or null otherwise
     */
    public static <T> T getEJB(Class<T> mappedInterface){
        StringBuilder ejbName = new StringBuilder();
        ejbName.append(JNDI_PREFIX);
        ejbName.append(mappedInterface.getSimpleName());

        Context ctx;
        try {
            ctx = new InitialContext();
            return (T) ctx.lookup(ejbName.toString());
        }
        catch (NamingException e) {
            logger.debug("EJB for " + mappedInterface.getSimpleName() + " via JNDI not found");
        }

        try {
            ctx = new InitialContext();
            return (T) ctx.lookup(mappedInterface.getSimpleName());
        }
        catch (NamingException e) {
            logger.debug("EJB for " + mappedInterface.getSimpleName() + " not found");
        }

        try {
            ctx = new InitialContext();
            return (T) ctx.lookup(mappedInterface.getSimpleName() + "Local");
        }
        catch (NamingException e) {
            logger.debug("EJB for " + mappedInterface.getSimpleName() + " not found");
        }

        try {
            if(mappedInterface.getSimpleName().contains("Bean")){
                ctx = new InitialContext();
                return (T) ctx.lookup(mappedInterface.getSimpleName().replace("Bean", ""));
            }
        }
        catch (NamingException e) {
            logger.debug("EJB for " + mappedInterface.getSimpleName() + " not found");
        }

        try {
            if(mappedInterface.getSimpleName().contains("Bean")){
                ctx = new InitialContext();
                return (T) ctx.lookup(mappedInterface.getSimpleName().replace("Bean", "Local"));
            }
        }
        catch (NamingException e) {
            logger.debug("EJB for " + mappedInterface.getSimpleName() + " not found");
        }

        return null;
    }
}
