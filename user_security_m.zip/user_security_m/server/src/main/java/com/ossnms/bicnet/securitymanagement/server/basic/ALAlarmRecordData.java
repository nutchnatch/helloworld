/*
 * --------------------------------------------------------
 *
 * Project: TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   ALAlarmRecordData
 * Author:      Babu B
 * Substitute   Vinay Purohit
 * Created on   12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.LOGGING.ALARM
 *  
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.basic;

import java.io.Serializable;
import java.util.Date;
/**
* This class holds the data of the security log record.
*/
public class ALAlarmRecordData implements Serializable {

	/**
     * 
     */
    private static final long serialVersionUID = 1L;

    /* private data members */
	/**
	 * Data member to hold user id
	 */
	private String strUserId;
	/**
	 * Data member to hold alarm time
	 */
	private Date alarmTime;

	/* default constructor */
	public ALAlarmRecordData() {
	}
	/* constructor */
	public ALAlarmRecordData(String p_strUserId, Date p_AlarmTIme) {
		this.strUserId = p_strUserId;
		this.alarmTime = p_AlarmTIme;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
    public String toString() {
		return toString(this);
	}
	public static String toString(ALAlarmRecordData arg) {
		return "UserId="
			+ arg.getUserId()
			+ ",\n\t\t"
			+ "AlarmTime="
			+ arg.getAlarmTime();
	}

	/**
	 * Returns the user id associated with the alarm object
	 * @return String - User ID
	 */
	public String getUserId() {
		return strUserId;
	}

	/**
	 * Set the user id associated with the alarm object
	 * @param p_strUserId 
	 *      user id associated with the alarm object
	 */
	public void setUserId(String p_strUserId) {
		strUserId = p_strUserId;
	}

	/**
	 * Returns the alarm raise time associated with the alarm object
	 * @return Date - alarm raise time
	 */
	public Date getAlarmTime() {
		return alarmTime;
	}

	/**
	 * Set the alarm raise time associated with the alarm object
	 * @param p_Time 
	 *      alarm raise time associated with the alarm object
	 */
	public void setAlarmTime(Date p_Time) {
		alarmTime = p_Time;
	}

}