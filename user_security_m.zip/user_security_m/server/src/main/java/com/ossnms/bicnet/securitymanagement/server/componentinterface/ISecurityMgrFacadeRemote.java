package com.ossnms.bicnet.securitymanagement.server.componentinterface;

import com.ossnms.bicnet.bcb.facade.security.ISecurityMgrFacade;

public interface ISecurityMgrFacadeRemote extends ISecurityMgrFacade {}
