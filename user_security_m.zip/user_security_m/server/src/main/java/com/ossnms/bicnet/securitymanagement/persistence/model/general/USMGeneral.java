package com.ossnms.bicnet.securitymanagement.persistence.model.general;

import javax.persistence.*;

import com.ossnms.bicnet.securitymanagement.persistence.model.BaseUSMEntity;


@Entity
@Table(name = "USM_GENERAL")
@NamedQueries({
	@NamedQuery(name = "usmGeneral.findBySubDomain", query = "from USMGeneral d where d.subDomain = :subDomain")
})
public class USMGeneral extends BaseUSMEntity {

    public static final String QUERY_FIND_BY_SUBDOMAIN = "usmGeneral.findBySubDomain";
    public static final String PARAM_1_FIND_BY_SUBDOMAIN = "subDomain";

    private static final long serialVersionUID = -4832127531597068083L;

    @Id
    @Column(name = "PROPERTY", unique = true, nullable = false)
    private String property;

    @Column(name = "PROPERTY_VALUE", length = 2048)
    private String propValue;
    
    @Column(name = "SUB_DOMAIN", nullable = false)
    private String subDomain;

	@Override
	public boolean isNew() {
		return false;
	}

    public USMGeneral(){
        super();
    }

    /**
     * Constructor
     *
     * @param property the name of the general settings property
     * @param propValue the value of the general settings property
     * @param subDomain the sub-Domain to which the property belongs to
     */
    public USMGeneral(String property, String propValue, String subDomain) {
        super();
        this.property = property;
        this.propValue = propValue;
        this.subDomain = subDomain;
    }


    public String getProperty() {
        return property;
    }

    public void setProperty(String property) {
        this.property = property;
    }
    
    public String getValue() {
        return propValue;
    }

    public void setValue(String propValue) {
        this.propValue = propValue;
    }
    
    public String getSubDomain() {
        return subDomain;
    }

    public void setSubDomain(String subDomain) {
        this.subDomain = subDomain;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }

        USMGeneral that = (USMGeneral) o;

        if (propValue != null ? !propValue.equals(that.propValue) : that.propValue != null){
            return false;
        }
        if (!property.equals(that.property)){
            return false;
        }
        return subDomain.equals(that.subDomain);

    }

    @Override
    public int hashCode() {
        int result = property.hashCode();
        result = 31 * result + (propValue != null ? propValue.hashCode() : 0);
        result = 31 * result + subDomain.hashCode();
        return result;
    }
}
