/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 01/10/2004   Babu B          TCM Id 86 - LW does not support querying of virtual/operational attributes
 * 31-Jan-2005  Babu B          CF001236    periodic "Name Already Bound" warning issued by securitymanagement
 * 14-Apr-2005  Muyeen Munaver  CF001996 Optimization of GarbageCollection
 * 05-May-2005  Babu B          CF001312   Master-Master Replication for Sun ONE DS
 * 14-June-2005  Muyeen Munaver  CF002374 - USM Erros/Exceptions during server start-up
 * 17-Aug-2005	Babu			CF002854 - user migration does not work
 * 25-July-2006  Shrinidhi G V  CF004216 9320_MR_0602:LDAP reporting 3636 successful connections
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.ldap;

import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import org.apache.log4j.Logger;

import javax.naming.CommunicationException;
import javax.naming.Context;
import javax.naming.InvalidNameException;
import javax.naming.NameAlreadyBoundException;
import javax.naming.NameNotFoundException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.InvalidSearchControlsException;
import javax.naming.directory.InvalidSearchFilterException;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.security.auth.Subject;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

/**
 * This class is responsible for the implementations of the operations provided by the LWInterface object. 
 * This class is visible only within the LW subsystem.
 */
public abstract class ADLDAPManager {

    private static final Logger LOGGER = Logger.getLogger(ADLDAPManager.class);

    protected static final String EMPTY = "";

    private static final String DC = "DC=";
    private static final String COMMA = ",";
    private static final String DOT = "\\.";

    /**
     * This is the constant that holds the name of the environment property for
     * specifying the security level to use.
     */
    private static final String SECURITY_AUTHENTICATION_TYPE = "GSSAPI";

    /**
     * This is the constant that holds the name of the environment property for
     * specifying the initial context factory to use.
     */
    private static final String INITIAL_CONTEXT_FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";

    /**
     * Internal identification for ActiveDirectoryLWLDAPManager
     */
    private static final String ACTIVE_DIRECTORY_LDAP_MANAGER = "ACTIVE_DIRECTORY_LDAP_MANAGER";

    private static final String LDAP_TCP_PORT = "389";
    private static final String LDAP_PROTOCOL = "ldap://";
    private static final String TCP_IP_PORT_PREFIX = ":";

    private static final String LDAP_ATTRIBUTES_BINARY = "java.naming.ldap.attributes.binary";
    private static final String ATTRIBUTE_OBJECT_SID = "objectSID";

    protected static final String JAVA_PROP_REALM = "java.security.krb5.realm";
    protected static final String JAVA_PROP_KDC = "java.security.krb5.kdc";

    private Subject subject;

    protected String realm;
    protected String kdc;
    protected String port;

    protected InitialLdapContext initialLdapContext;

    /**
     * Constructor
     *
     * @param subject the security subject to use
     * @param realm the realm to which it'll connect
     * @param kdc the domain controller (or ldap server)
     */
    public ADLDAPManager(Subject subject, String realm, String kdc, String port){
        this.subject = subject;
        this.realm = realm;
        this.kdc = kdc;
        this.port = port;
    }

    /**
     * Connects to the ldap server as configured in this instance. Requires some kind of authentication, in order to
     * refresh the realm and kdc system properties. Otherwise, the assumed value will be the first when launching
     * the JVM. Further modifications require a Service restart.
     *
     * @return true if the connection was successful, false otherwise
     */
    protected boolean connect(){
        try {
            LOGGER.info("connectToDirectoryServer() Try to establish the connection to the Active Directory, through " + ACTIVE_DIRECTORY_LDAP_MANAGER);

            setRealm();

            Subject.doAsPrivileged(subject, new PrivilegedExceptionAction<InitialLdapContext>() {
                @Override
                public InitialLdapContext run() throws NamingException {
                    Hashtable<String, String> environment = new Hashtable<>();
                    environment.put(Context.INITIAL_CONTEXT_FACTORY, INITIAL_CONTEXT_FACTORY);
                    environment.put(Context.SECURITY_AUTHENTICATION, SECURITY_AUTHENTICATION_TYPE);
                    environment.put(Context.PROVIDER_URL, getProviderUrl(kdc, port));

                    //ensures that objectSID attribute values
                    //will be returned as a byte[] instead of a String
                    environment.put(LDAP_ATTRIBUTES_BINARY, ATTRIBUTE_OBJECT_SID);

                    initialLdapContext = new InitialLdapContext(environment, null);
                    return initialLdapContext;
                }
            }, null);

            if(initialLdapContext != null){
                if (LOGGER.isInfoEnabled()) {
                    String successMessage = MessageFormat.format(USMCommonStrings.IDS_LW_ACTIVE_DIRECTORY_CONNECTION_SUCCESS, kdc);
                    LOGGER.info(successMessage + " : " + initialLdapContext);
                }
                return true;
            }

            return false;
        } catch (PrivilegedActionException e) {
            LOGGER.error("connectToDirectoryServer() It's not possible to connect to the Active Directory", e);
            return false;
        }
    }

    /**
     * Checks the default realm and kdc configured. If none is configured, will assume the values configured in this
     * object instance.
     */
    private void setRealm() {
//        String sysRealm = System.getProperty(JAVA_PROP_REALM);
//        String sysKdc = System.getProperty(JAVA_PROP_KDC);

//        if(sysRealm == null || sysRealm.isEmpty() || sysKdc == null || sysKdc.isEmpty()){
        System.setProperty(JAVA_PROP_REALM,  realm);
        System.setProperty(JAVA_PROP_KDC,    kdc);
//        }
    }

    /**
     * This method is invoked by the LWLifecycleController as part of the finalization of the LW subsystem to disconnect or unbind from the
     * directory server. This method will in turn perform this operation on the DirContext member attribute. The member is assigned to null.
     *
     * @return boolean Returns true on successful disconnection from DS.
     */
    protected boolean disconnect() {
        LOGGER.debug("disconnectFromDirectoryServer() Entry");

        try {
            if(initialLdapContext != null){
                initialLdapContext.close();
                initialLdapContext = null;
            }
        } catch (NamingException e) {
            LOGGER.error("disconnectFromDirectoryServer() ", e);
        }

        LOGGER.debug("disconnectFromDirectoryServer() Exit");
        return true;
    }

    /**
     * This method is called by the LWInterface class's corresponding method.The return value is TRUE only if one or more elements are found, else if no
     * element or if any of the following exceptions occurs, FALSE is returned: NamingException is thrown.
     * 
     * @param objectClassType
     *            - This is the object class type of the objects to be searched in the LDAP directory. 
     *            Example of this is: "domaindata" is the type defined in the LDAP schema for the DomainData objects.
     * @param attributeName
     *            - This is the name of the attribute based on which the objects
     *            are to be found in the LDAP directory. Example is
     *            "ApplicationServerId" to search the NEData objects that map to
     *            a particular Application Server.
     * @param attributeValue
     *            - This is the value of the attribute based on which the objects are to be found in the LDAP directory. 
     *            Example of this is "25" is one of the values stored for the domainId attribute in the NEData objects. 
     *            This will be used to get all NEs assigned to this domain.
     * @param relativeDNContainer
     *            - This is the relative DN of the container under which the objects of this class will be stored in the LDAP directory.
     *            Example of this is "ou=DomainContainer, dc=aci-banagalore,dc=com"
     * @param listFoundObjects
     *            - This is the list of the objects found in the LDAP directory corresponding to the passed classType.
     * @return boolean Returns true if it was successful in retrieving the
     *         object from DS.
     */
    protected boolean getObjects(String objectClassType, String attributeName, String attributeValue, String relativeDNContainer, List<ADElement> listFoundObjects, String searchFilter, SearchControls searchCtls) {
        LOGGER.debug("getObjects()Entry");

        boolean foundObjects;
        // This is the case for the Microsoft Active Directory
        String objectClassAttributeName = "objectClass";
        try {
            BasicAttribute objectTypeAttribute = new BasicAttribute(objectClassAttributeName, objectClassType);
            BasicAttribute objectSearchAttribute = new BasicAttribute(attributeName, attributeValue);
            BasicAttributes attributesToSearch = new BasicAttributes(true);
            attributesToSearch.put(objectTypeAttribute);
            attributesToSearch.put(objectSearchAttribute);
            if(null == initialLdapContext) {
                LOGGER.error("getObjects() ERROR: The m_directoryContext is invalid");
                foundObjects = false;
                directoryContextError();
            } else {
                if(searchFilter != null && searchCtls != null) {
                    foundObjects = searchForAllElements(relativeDNContainer, attributesToSearch, listFoundObjects, searchFilter, searchCtls);
                } else {
                foundObjects = searchForAllElements(relativeDNContainer, attributesToSearch, listFoundObjects, null, null);
            }
            }
        } catch (Exception ex) {
            LOGGER.error("getObjects()", ex);
            foundObjects = false;
        }

        LOGGER.debug("getObjects() Exit");
        return foundObjects;
    }

    /**
     * This method is used internally to format the NamingEnumeration returned from a search. This method returns TRUE if the Attributes have been
     * retrieved from the NamingEnumeration successfully. It reurns false if there are no Attributes obtained or if any of the following exception are
     * thrown: NamingException
     * 
     * @param enumeration
     *            - This is the NamingEnumeration returned by the search.
     * @param attrs
     *            - This is the vector containing the list of attributes that are returned for each object found based on the search.
     * @return p_boolean Returns true if there was something to be processed from the enumeration.
     */
    private boolean formatResults(NamingEnumeration enumeration, List<Attributes> attrs) {
        LOGGER.debug("formatResults() Entry");

        boolean isProcessedAttributes = false;
        Attributes objectAttributes;
        try {
            if(null != enumeration) {
                while(enumeration.hasMoreElements()) {
                    SearchResult searchResult = (SearchResult) (enumeration.next());
                    objectAttributes = searchResult.getAttributes();
                    attrs.add(objectAttributes);
                    isProcessedAttributes = true;
                }
            }
        } catch (NamingException ex) {
            LOGGER.error("formatResults()", ex);
        }

        LOGGER.debug("formatResults() Exit");
        return isProcessedAttributes;
    }

    /**
     * This method is used to inform the LWLifecycleController of a possible
     * LDAP directory connection failure.
     */
    private void directoryContextError() {
        if(LOGGER.isDebugEnabled()){
            LOGGER.debug("directoryContextError() Entry");
        }

        if(LOGGER.isDebugEnabled()){
            LOGGER.debug("directoryContextError() Exit");
        }
    }

    /**
     * This method searches for all elements and returns a out parameter a list of LWElement. If the attributes is passed then the filter and
     * search controls are neglected. Otherwise it invokes the search as specified in the filter and the search controls. It returns all elements,
     * by invoking a paged search from the server.
     * 
     * @param relativeDNContainer
     *            - This is the relative DN of the container under which the objects of this class will be stored in the LDAP directory.
     *            Example of this is "ou=DomainContainer, dc=aci-banagalore,dc=com"
     * @param attributesToSearch
     *            Attributes which will be used to search.
     * @param listFoundObjects
     *            - This is the list of the objects found in the LDAP directory corresponding to the passed classType.
     * @param filter
     *            The filter expression to use for the search; may not be null
     * @param searchControls
     *            The search controls that control the search. If null, the default search controls are used (equivalent to (new SearchControls())).
     * @return boolean Returns true if there was no error from DS while
     *         searching.
     */
    protected boolean searchForAllElements(String relativeDNContainer, BasicAttributes attributesToSearch, List<ADElement> listFoundObjects, String filter, SearchControls searchControls) throws InvalidNameException, NameAlreadyBoundException {
        boolean foundObjects;
        try {
            NamingEnumeration<SearchResult> enumeration;
            if (null == searchControls) {
                enumeration = initialLdapContext.search(relativeDNContainer, attributesToSearch);
            } else {
                enumeration = initialLdapContext.search(relativeDNContainer, filter, searchControls);
            }

            List<Attributes> foundAttributes = new ArrayList<>();
            foundObjects = formatResults(enumeration, foundAttributes);
            if (foundObjects) {
                ADElement foundElement;
                for (Attributes foundAttribute : foundAttributes) {
                    foundElement = new ADElement();
                    foundElement.setLDAPAttributes(foundAttribute);
                    listFoundObjects.add(foundElement);
                }
            }
        } catch (InvalidSearchFilterException | InvalidSearchControlsException | NameNotFoundException
                | NameAlreadyBoundException | CommunicationException | InvalidNameException ex) {
            LOGGER.error("searchForAllElements()", ex);
            foundObjects = false;
        } catch (NamingException ex) {
            LOGGER.error("searchForAllElements()", ex);
            foundObjects = false;

            if (this.initialLdapContext == null) {
                directoryContextError();
            }
        }
        LOGGER.debug("searchForAllElements() Exit");
        return foundObjects;
    }

    /**
     *
     * @param domainServer the server where the domain is configured
     * @return the fully formed provider url
     */
    private String getProviderUrl(String domainServer, String port){
        return LDAP_PROTOCOL + domainServer + TCP_IP_PORT_PREFIX + port;
    }


    /**
     * This method is used to constructed the base DN search information based on domain name.
     *
     * @return Base DN search with a pattern similar as CN=Users,DC=oceans,DC=seven,DC=domain
     */
    protected String getBaseDNSearch(String domainName) {
        StringBuilder baseDNSearch = new StringBuilder();
        if (domainName != null && !domainName.isEmpty()) {
            String[] domainParts = domainName.split(DOT);
            if (domainParts.length > 0) {
                int i = 0;
                for (String domainPart : domainParts) {
                    baseDNSearch.append(DC);
                    baseDNSearch.append(domainPart);
                    if (i != domainParts.length - 1) {
                        baseDNSearch.append(COMMA);
                    }
                    ++i;
                }
            }
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Base DN search: " + baseDNSearch.toString());
        }
        return baseDNSearch.toString();
    }

}