package com.ossnms.bicnet.securitymanagement.persistence.model.policy;

import com.ossnms.bicnet.securitymanagement.persistence.model.BaseUSMEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 *
 */
@Entity
@Table(
        name = "USM_PERMISSION_ITEM",
        uniqueConstraints = {
                @UniqueConstraint( columnNames = { "NAME" })
        }
)
@NamedQueries({
        @NamedQuery(name = "usmPermissionItem.findByName", query = "from USMPermissionItem p where p.name = :name"),
})
public class USMPermissionItem extends BaseUSMEntity{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "USMPermissionSequence")
    @SequenceGenerator(name = "USMPermissionSequence", sequenceName = "USM_SEQ_PERMISSION")
    @Column(name = "ID")
    private Integer id;

    @Column(name = "NAME", nullable = false)
    private String name;

    @Column(name = "DESCRIPTION", nullable = false)
    private String description;

//    @ManyToOne
//    @JoinColumn(name="CF_ID", nullable=false, updatable=false)
//    private USMCF cf;

    /**
     * Implement this method to inform is the object is new or not.
     * e.g. when the id is a long, the object is new if the id == 0
     *
     * @return
     */
    @Override
    public boolean isNew() {
        return id == null || id == 0;
    }

    /**
     *
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

//    /**
//     *
//     */
//    public USMCF getCf() {
//        return cf;
//    }
//
//    /**
//     * @param cf
//     */
//    public void setCf(USMCF cf) {
//        this.cf = cf;
//    }

    /**
     *
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     *
     */
    public String getName() {
        return name;
    }

    /**
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj){
            return true;
        }
        if (obj == null){
            return false;
        }
        if (getClass() != obj.getClass()){
            return false;
        }
        USMPermissionItem other = (USMPermissionItem) obj;
        if (name == null) {
            if (other.name != null){
                return false;
            }
        } else if (!name.equals(other.name)){
            return false;
        }

        return true;
    }
}
