/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCDomainMappingData
 * Author      	Vinay Purohit
 * Substitute	Asifulla Khan
 * Created on	07-12-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.MAPPING.CREATE   
 * 	    :   TNMS.DX2.SM.MAPPING.VIEW
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.domain;

import java.io.Serializable;
import java.util.List;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;

/**
 * @author vpurohit
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class DCIEDomainMapping implements Serializable {
	private static final long serialVersionUID = 5906985247440585688L;
	
	public static final DCDomainMapping GLOBAL_MAPPING =
		new DCDomainMapping(
			0,
			DCMessages.getInstance().getString(DCMessages.DC_GLOBAL_GROUPS),
			0);
	/**
	 * Domain id for which this mapping is part of.
	 */
	private String domainName;

	/**
	 * Fully qualified user group of this mapping data
	 */
	private String userGroup;

	/**
	 * Domain id for which this mapping is part of.
	 */
	private String policyName;

	/**
	 * Constructor
	 * 
	 * @param p_ndomainName
	 *            The domain id of the mapping
	 * @param p_struserGroup
	 *            The user group of the mapping
	 * @param p_npolicyName
	 *            The policy id of the mapping
	 */
	public DCIEDomainMapping(
		String p_ndomainName,
		String p_struserGroup,
		String p_npolicyName) {

		domainName = p_ndomainName;
		userGroup = p_struserGroup;
		policyName = p_npolicyName;

	}

	/**
	 * Default constructor
	 */
	public DCIEDomainMapping() {

	}

	/**
	 * Function to push onto a domain mapping to a message. Used by the sender.
	 * After successful execution of this function. The message would contain
	 * information about the mapping
	 * 
	 * @param p_msg
	 *            The USMMessage to which the mapping has to be pushed
	 */
	public void pushMe(USMMessage p_msg) {

		//push dom id, ug, policyid, domUID in that order
		p_msg.pushString(domainName);
		p_msg.pushString(userGroup);
		p_msg.pushString(policyName);

	}

	/**
	 * Function to pop the mappings from a message. Used by the receiver
	 * 
	 * @param p_msg
	 *            The USMMessage from which the mappings need to be popped
	 */
	public void popMe(USMMessage p_msg) {
		policyName = p_msg.popString();
		userGroup = p_msg.popString();
		domainName = p_msg.popString();
	}

	/**
	 * Function to get the domain id associated with this mapping
	 * 
	 * @return int Returns the domain id of the mapping
	 */
	public String getDomainName() {
		return domainName;
	}

	/**
	 * Function to get the policy id associated with this mapping
	 * 
	 * @return int Returns the policy id of the mapping
	 */
	public String getPolicyName() {
		return policyName;
	}
	/**
		 * Function to set the domain id associated with this mapping
		 * 
		 */
	public void setDomainName(String p_domain) {
		domainName = p_domain;
	}

	/**
	 * Function to set the policy id associated with this mapping
	 * 
	
	 */
	public void setPolicyID(String p_policy) {
		policyName = p_policy;
	}

	/**
	 * Helper function to push the list of mappings onto a message
	 * 
	 * @param p_mappings
	 *            List of mappings which need to be pushed
	 * @param p_msg
	 *            The USMMessage onto which the mappings need to be pushed
	 */
	public static void pushMappingsToMessage(
		List p_mappings,
		USMMessage p_msg) {

		//Pushes the vector of p_mappings into the USM Message
		for (int i = 0; i < p_mappings.size(); ++i) {
			DCIEDomainMapping dom = (DCIEDomainMapping) p_mappings.get(i);
			dom.pushMe(p_msg);
		}
		p_msg.pushInteger(p_mappings.size());

	}

	/**
	 * Helper function to pop the list of mappings from a message. The list
	 * is cleared and then returned
	 * @param p_msg
	 *            The USMMessage from which the mappings need to be popped from
	 * @param domainMappings
	 *            List of mappings that would be populated from the Message
	 */
	public static void popMappingsFromMessage(
		USMMessage p_msg,
		List<DCDomainMapping> domainMappings) {

		domainMappings.clear();
		int nSize = p_msg.popInteger().intValue();
		for (int i = 0; i < nSize; ++i) {
			DCDomainMapping dom = new DCDomainMapping();
			dom.popMe(p_msg);
			domainMappings.add(dom);
		}

	}

	/**
	 * Function to get the user group associated with the mapping
	 * 
	 * @return String Returns the user group of the mapping
	 */
	public String getUserGroup() {
		return userGroup;
	}
	/**
		 * Function to set the user group associated with the mapping
		 * 
		  */
	public void setUserGroup(String p_ugrp) {
		userGroup = p_ugrp;
	}

	/**
	 * Checks whether the current mapping is a global mapping or not.
	 * 
	 * @return boolean Returns true to indicate that it is a global mapping
	 */
	public boolean isGlobalMapping() {
		String strAdminGroup =
			DCMessages.getInstance().getString(DCMessages.DC_GLOBAL_GROUPS);
		String strGlobalDomain =
			DCMessages.getInstance().getString(DCMessages.DC_GLOBAL_DOMAIN);
		String strGlobalPolicy = "GLOBAL";
		// PAMessages.getInstance().getString(PAMessages.PA_GLOBAL_GROUPS);

		return (
			(0 == domainName.compareToIgnoreCase(strGlobalDomain))
				&& (0 == policyName.compareToIgnoreCase(strGlobalPolicy))
				&& (0 == userGroup.compareToIgnoreCase(strAdminGroup)));
	}

	/**
	 * Overridden method equals to compare 2 mapping objects. 2 mapping objects
	 * are equal when the domain id and the user group are the same
	 * 
	 * @param domainMapping -
	 *            The mapping object against which the current object has to be
	 *            compared with
	 * @return boolean - Returns true if the object are equal
	 */
	@Override
    public boolean equals(Object domainMapping) {
		boolean bRet = false;
		if (null != domainMapping && domainMapping instanceof DCIEDomainMapping) {
			DCIEDomainMapping mapping = (DCIEDomainMapping) domainMapping;
			if (domainName.equals(mapping.getDomainName()) && (0 == mapping.getUserGroup().compareToIgnoreCase(userGroup))) {
				bRet = true;
			}
		}
		return bRet;
	}

	/**
	 * Overridden hashCode method. This is needed when the equals method is
	 * overridden This should return a uniq id
	 * 
	 * @return int Returns the hashCode of this object, which is uniq
	 */
	@Override
    public int hashCode() {
		return (domainName + "-" + userGroup.toLowerCase()).hashCode();
	}

	/**
	 * Overridden toString method for display purpose and debug info
	 * 
	 * @return String Returns a user group + domain id + policy id of the
	 *         mapping object
	 */
	@Override
    public String toString() {
		return "u-"
			+ userGroup
			+ "-d-"
			+ domainName
			+ "-p- "
			+ policyName;
	}

}
