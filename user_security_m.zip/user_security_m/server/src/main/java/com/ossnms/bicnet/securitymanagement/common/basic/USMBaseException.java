/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMBaseException
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.common.basic;

/**
 * This is the Base class for all the exceptions that are defined
 * within USM
 */
public class USMBaseException extends Exception {

	/**
	 * Constructor
	 */
	public USMBaseException() {
		super();
	}

	/**
	 * Constructor
	 * 
	 * @param p_ThrowableObj 
	 * 			The Throwable Object which was raised.
	 */
	public USMBaseException(Throwable p_ThrowableObj) {
		super(p_ThrowableObj);
	}

	/**
	 * Constructor
	 * 
	 * @param p_strMessage
	 * 			Additional Message
	 * @param p_ThrowableObj
	 * 			The Throwable Object which was raised.
	 */
	public USMBaseException(String p_strMessage, Throwable p_ThrowableObj) {
		super(p_strMessage, p_ThrowableObj);
	}

	/**
	 * Constructor
	 * 
	 * @param p_strMessage
	 * 			Additional Message
	 */
	public USMBaseException(String p_strMessage) {
		super(p_strMessage);
	}
}
