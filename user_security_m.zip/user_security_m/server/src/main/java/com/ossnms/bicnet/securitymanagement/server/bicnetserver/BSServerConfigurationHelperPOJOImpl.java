package com.ossnms.bicnet.securitymanagement.server.bicnetserver;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityServerConfigurationHelperPrivateFacade;

/**
 * POJO implementation for the interface provided for the call style change
 */
public class BSServerConfigurationHelperPOJOImpl implements ISecurityServerConfigurationHelperPrivateFacade {

	/**
	 * @see com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityServerConfigurationHelperPrivateFacade#checkForNewlyAvailableCFsWithServiceLocator(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
	public void checkForNewlyAvailableCFsWithServiceLocator(ISessionContext p_ctx)	throws BcbSecurityException {
		BSCentralController ctl = BSCentralController.getInstance();

		ctl.checkForNewlyAvailableCFsWithServiceLocator();
		ctl.performConsistencyCheck();
	}

}
