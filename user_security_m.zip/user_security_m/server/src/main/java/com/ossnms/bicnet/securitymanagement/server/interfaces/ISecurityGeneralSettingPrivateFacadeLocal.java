package com.ossnms.bicnet.securitymanagement.server.interfaces;

public interface ISecurityGeneralSettingPrivateFacadeLocal extends ISecurityGeneralSettingPrivateFacade { }

