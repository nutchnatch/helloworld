/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   UAIEUserGroup
 * Author:      Jogender
 * Substitute	Babu B
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : 
 * 		 :
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.useradministration;

import org.apache.log4j.Logger;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
/**
 * This Transient class contains all data of a User Group.
 */
public class UAIEUserGroup implements Serializable {

	/**
     * 
     */
    private static final long serialVersionUID = 1L;

    /**
     * Data member for the Logging of the class.
     */
	private static final Logger LOGGER = Logger.getLogger(UAUserGroup.class);
	/**
	 *  Name of the user group
	 */
	private String strName;

	/**
	 *  Description of the user group
	 */
	private String strDescription;

	/**
	 *  Assigned users for the user group 
	 */
	private List<String> assignedUsers;

	/**
	 * Default constructor
	 */
	public UAIEUserGroup() {
		this.strName = "";
		this.strDescription = "";
		this.assignedUsers = new ArrayList<>();
	}

	/**
	 * Constructor to form usergroup
	 * @param p_Name is a name of the usergroup
	 * @param p_Description holds the description of the user group
	 * @param p_assignedUsers holds the list of user assigned to the user group
	 */

	public UAIEUserGroup(
		String p_Name,
		String p_Description,
		List<String> p_assignedUsers) {
		this.strName = p_Name;
		this.strDescription = (p_Description != null) ? p_Description : "";
		this.assignedUsers = (p_assignedUsers != null) ? p_assignedUsers : new ArrayList<String>();

	}

	/**
	 * Returns the user group descriptiuon
	 *
	 * @return
	 *      String - User Group Description
	 */
	public String getDescription() {
		return strDescription;
	}

	/**
	 * Returns the list of the assigned users to the user group
	 *
	 * @return
	 *      String - List of the assigned users
	 */
	public List<String> getAssignedUsers() {
		return assignedUsers;
	}

	/**
	 * Returns the user group name
	 *
	 * @return String -User Group Name
	 */
	public String getName() {
		return strName;
	}

	/**
	 * Sets the description for user group
	 *
	 * @param  string - user group description
	 */
	public void setDescription(String string) {
		strDescription = string;
	}

	/**
	 * Sets the list of the assigned users to the user group
	 *
	 * @param  assignedUsers - List of the assigned users to the user group
	 */
	public void setAssignedUsers(List<String> assignedUsers) {
		this.assignedUsers = (assignedUsers != null) ? assignedUsers : new ArrayList<String>();
	}

	/**
	 * Sets the name for user group
	 *
	 * @param  strName - user group name
	 */
	public void setName(String strName) {
		this.strName = strName;
	}

	/**
		 * Function to retrieve the String equivalent of this object.
		 * 
		 * @return java.lang.String 
		 *      The String which is a representation of this object.
		 */
	@Override
    public String toString() {
		return strName;
	}

	/**
	 * Function to compare 2 objects for equality.
	 * 
	 * @param p_obj
	 *            The Object which has to be compared with this object.
	 * @return boolean Indicates whether the 2 objects are equal or not. True
	 *         indicates that the objects are equal.
	 */
	@Override
    public boolean equals(Object p_obj) {
		boolean bOp = false;
		if (p_obj instanceof UAUserGroup) {
			UAUserGroup userObj = (UAUserGroup) p_obj;
			String userGroupName = userObj.getName();

			if ((strName.equals(userGroupName))) {

				bOp = true;
			}
		} else {
			LOGGER.error("Equality check using a wrong type");
		}
		return bOp;
	}

	/**
	 * Returns the hash code value for this Field. 
	 * 
	 * @return
	 *      the integer hash code
	 */
	@Override
    public int hashCode() {
		return strName.hashCode();
	}

}
