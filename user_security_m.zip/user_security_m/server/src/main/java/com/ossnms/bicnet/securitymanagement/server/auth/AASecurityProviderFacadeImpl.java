/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AASecurityProviderFacadeImpl
 * Author      	Jogender Singh
 * Substitute	Babu B
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
  * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.SERVER.AUTHORIZATION
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 19-Jan-2005	Muyeen Munaver	CF001094 - Not possible do drag and drop NE's to the "Physical Root - View" window
 * 31-Jan-2005  Asif         	CF001093 - Computer name column - not empty when nobody is logged with that UserId 
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 * 09-Mar-2005	Muyeen Munaver	CF001666 - CrossNE Management 'Associated securable objects' are not correct
 * 11-Mar-2005	Asif			CF000845 - System Event Log Entries
 * 24-Mar-2005	Muyeen Munaver	CF001788 - PasswordChangeRequiredException missing during first Login with SysAdmin
 * 30-Mar-2005	Muyeen Munaver	CF001869 - Change password window to behave similarly as login window for empty password
 * 05-Mar-2005  Muyeen Munaver  CF001812    Import a xml file (from DX V2) users are deactivated, activate them- problem
 * 05-Mar-2005  Muyeen Munaver  CF001936    Change Password throws exception, but password has been changed
 * 12-Mar-2005  Muyeen Munaver  CF001932	Host Name is not shown for user logged in from 'Sys Admin' client
 * 10-May-2005	Muyeen Munaver	CF002170 - Resolve the Host name into the IP address fails
 * 11-Jan-2006  Balasubramanya  CF002773 - Missing correct computer name in window User Administration
 * 17-Nov-2006	Shrinidhi G V	CF004362-03 - 9320_MR_0775: Any user can bring down the application.
 * 31-Jan-2007  Shrinidhi G V   CF004362-  9320_MR_0775: Any user can bring down the application.
 * 26-Aug-2005  Babu B          CF002773 - Missing correct computer name in window User Administration
 * 10-Aug-2007	Shrinidhi G V			TD000504-03 - Extend USM public facade with method to get ldap credentials
 * 16-Sep-2009  Sayantan        TD5434
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.auth;

import com.ossnms.bicnet.bcb.facade.security.ILogonListener;
import com.ossnms.bicnet.bcb.facade.security.ISecureServerSession;
import com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.bcb.model.security.ISecurableObject;
import com.ossnms.bicnet.bcb.model.security.ISecurableObjectContainer;
import com.ossnms.bicnet.bcb.model.security.PasswordChangeRequiredException;
import com.ossnms.bicnet.securitymanagement.api.server.users.IAAWrapper;
import com.ossnms.bicnet.securitymanagement.common.auth.AAChangePasswordDetails;
import com.ossnms.bicnet.securitymanagement.common.auth.AAMessageType;
import com.ossnms.bicnet.securitymanagement.common.auth.AASessionContext;
import com.ossnms.bicnet.securitymanagement.common.auth.AAUserMessages;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import com.ossnms.bicnet.securitymanagement.common.utils.InternalUSMBeanLocator;
import com.ossnms.bicnet.securitymanagement.common.utils.ObjectCypher;
import com.ossnms.bicnet.securitymanagement.server.IScsControllableImpl;
import com.ossnms.bicnet.securitymanagement.server.basic.notification.USMNotifier;
import com.ossnms.bicnet.securitymanagement.server.bicnetserver.BSSubsystemSAP;
import com.ossnms.bicnet.securitymanagement.server.logging.LMInterFace;
import com.ossnms.bicnet.securitymanagement.server.logging.LMLogRecordData;
import com.ossnms.bicnet.securitymanagement.server.logging.LMLogRecordEnum;
import com.ossnms.bicnet.securitymanagement.server.useradministration.UASubsystemSAP;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.Handle;
import javax.security.auth.kerberos.KerberosTicket;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;


/**
 * It is the implementation of ISecurityProviderFacade interface for accessing
 * services provided by security management on the application server
 */
public final class AASecurityProviderFacadeImpl implements ISecurityProviderFacade {
    /**
     * Data member for tracing
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(AASecurityProviderFacadeImpl.class);

    private static final boolean NO_GUI_LOGON = true;

    /**
     * Holds singleton instance
     */
    private static final AASecurityProviderFacadeImpl INSTANCE = new AASecurityProviderFacadeImpl();
    
    /**
     * Via lookup, retrieves the bean for the IAAWrapper
     */
    private IAAWrapper  authenticationWrapper = InternalUSMBeanLocator.getEJB(IAAWrapper .class);

    /**
     * Holds singleton instance
     */
    private static List logonListener = new ArrayList();

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#getServerSession(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public ISecureServerSession getServerSession(ISessionContext sessionContext)
            throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "getServerSession(" + sessionContext + ")		Enter");
        }
        if (sessionContext == null) {
            throw new BcbSecurityException();
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "getServerSession(" + sessionContext + ")		Exit");
        }

        return new AASecureServerSessionImpl(sessionContext);
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#changePassword(java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public void changePassword(
            String userId,
            String currentPassword,
            String newPassword)
            throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "changePassword(" + userId + ",****,***** )		Enter");
        }
        AAAuthenticationPOJOImpl objAAPojo = new AAAuthenticationPOJOImpl();

        AAChangePasswordDetails objPwdDetails =
                new AAChangePasswordDetails(
                        userId,
                        null,
                        currentPassword,
                        newPassword);

        USMMessage msg = objAAPojo.changePassword(getLocalCtx(), objPwdDetails);
        Integer nResult = msg.popInteger();
        if (nResult.intValue() == AAUserMessages.AA_NO_ERROR.intValue()) {
            LOGGER.info(
                    "Password has been changed succussfully for user id :"
                            + userId);
        } else {
            String csMsg = AAUserMessages.getInstance().getString(nResult);
            LOGGER.error(
                    "Password change failed for user :"
                            + userId
                            + " Reason : "
                            + csMsg);
            Exception ex = new Exception(csMsg);
            BcbSecurityException bcbException = new BcbSecurityException();
            bcbException.initCause(ex);
            throw bcbException;
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "changePassword(" + userId + ",****,***** )		Exit");
        }
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#logon(java.lang.String, java.lang.String)
     */
    @Override
    public ISessionContext logon(String userId, String password, String clientComputerName)
            throws BcbSecurityException {
        return logon(userId, password, clientComputerName, !NO_GUI_LOGON);
    }

    private ISessionContext logon(String userId, String password,
                                  String clientComputerName, boolean isNbiLogon) throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("logon(" + userId + ",******)		Enter");
        }

        // Firstly check if the password has expired. Only then do the logon
        boolean bStatus = authenticationWrapper.isPasswordMustChanged(userId);

        if (bStatus) {

            try {
            	authenticationWrapper.logon(userId, password);
            } catch (BcbSecurityException ex) {

                LMLogRecordEnum activityName = LMLogRecordEnum.USER_LOGIN;
                String displayStr =
                        MessageFormat.format(
                                USMCommonStrings.IDS_AA_USER_LOGIN_FAILURE,
                                userId, clientComputerName);
                LMLogRecordData usmLogRecord =
                        new LMLogRecordData(
                                activityName,
                                userId,
                                LMLogRecordData._FAILURE,
                                null,
                                LogSeverity.ERROR.guiLabel(),
                                null,
                                displayStr);

                ISessionContext dummySessionContext = new AASessionContext(
                        "System Account",
                        "",
                        clientComputerName,
                        clientComputerName,
                        USMCommonHelper.getIpAddressForHost(clientComputerName),
                        null,
                        false);
                LMInterFace.getInstance().createSecurityLogRecord(
                        dummySessionContext,
                        usmLogRecord);

                //now send login failed info
                sendLoginFailedNotification(userId);

                //now rethrow the exception
                throw ex;

            }

            // Password has expired. So ensure user changes password by throwing
            // exception
            LOGGER.debug("User login denied. Reason password expired. "
                    + userId);
            throw new PasswordChangeRequiredException();
        }


        AAAuthenticationPOJOImpl objAAPojo = new AAAuthenticationPOJOImpl();
        String strHostAddress = USMCommonHelper.getIpAddressForHost(clientComputerName);

        ISessionContext sessionContext;

        if (isNbiLogon) {
            sessionContext = objAAPojo.nbiLogon(userId, password, clientComputerName, strHostAddress);
        } else {
            sessionContext = objAAPojo.logon(userId, ObjectCypher.cypherToken(password), clientComputerName, strHostAddress);
        }


        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("logon(" + userId + ",******)		Exit : Return :");
        }
        return sessionContext;
    }


    @Override
    public ISessionContext nbiLogon(String userId, String password,
                                    String computerName) throws BcbSecurityException {
        return logon(userId, password, computerName, NO_GUI_LOGON);
    }


    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#isLoggedOn(java.lang.String)
     */
    @Override
    public boolean isLoggedOn(String userId) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("isLoggedOn(" + userId + ") Enter");
        }
        AASessionStore objUserList =
                AASessionStore.getInstance();

        boolean bLogged = objUserList.isUserLoggedOn(userId);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("isLoggedOn Exiting. Returning : " + bLogged);
        }
        return bLogged;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#logoff(com.ossnms.bicnet.bcb.facade.security.ISecureServerSession)
     */
    @Override
    public void logoff(ISessionContext serverSession)
            throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("logoff(" + serverSession + ")		Enter");
        }
        AAAuthenticationPOJOImpl obj = new AAAuthenticationPOJOImpl();
        obj.logoff(serverSession);

        LOGGER.info("Status of logging off User : " + serverSession + " is : Successful");

        LOGGER.debug("logoff Exit");
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#addLogonListener(com.ossnms.bicnet.bcb.facade.security.ILogonListener)
     */
    @Override
    public void addLogonListener(ILogonListener listener) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("addLogonListener called. " + listener);
        }
        logonListener.add(listener);
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#removeLogonListener(com.ossnms.bicnet.bcb.facade.security.ILogonListener)
     */
    @Override
    public void removeLogonListener(ILogonListener listener) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("removeLogonListener called. " + listener);
        }
        logonListener.remove(listener);
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#registerObject(com.ossnms.bicnet.bcb.model.security.ISecurableObject)
     */
    @Override
    public void registerObject(BiCNetComponentType componentType, ISecurableObject securableObject) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("registerObject called. ComponentType: " + componentType.guiLabel() + " securableObject: " + securableObject);
        }

        BSSubsystemSAP.registerObject(componentType, securableObject);
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#unregisterObject(com.ossnms.bicnet.bcb.model.security.ISecurableObject)
     */
    @Override
    public boolean unregisterObject(BiCNetComponentType componentType, ISecurableObject securableObject) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("unregisterObject called.  ComponentType: " + componentType.guiLabel() + " securableObject: " + securableObject);
        }

        return BSSubsystemSAP.unregisterObject(componentType, securableObject);
    }

    /**
     * prevents instantiation
     */
    private AASecurityProviderFacadeImpl() {
        // prevent creation
    }

    /**
     * Returns the singleton instance.
     *
     * @return the singleton instance
     */
    public static AASecurityProviderFacadeImpl getInstance() {
        return INSTANCE;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#updateObject(com.ossnms.bicnet.bcb.model.security.ISecurableObject)
     */
    @Override
    public void updateObject(BiCNetComponentType componentType, ISecurableObject securableObject) {
        LOGGER.debug("updateObject called. ComponentType: {} securableObject: {}", componentType.guiLabel(), securableObject);
        BSSubsystemSAP.updateObject(componentType, securableObject);
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#logoff(com.ossnms.bicnet.bcb.facade.security.ISecureServerSession)
     */
    @Override
    public void logoff(ISecureServerSession serverSession) throws BcbSecurityException {
        logoff(serverSession.getSessionContext());
    }

    /**
     * @param ctx
     */
    public void userLoggedOn(ISessionContext ctx) {

        //CF001093, make it more robust, other people if throw exception, we should not be sufferers
        for (Object aLogonListener : logonListener) {
            ILogonListener logonListenr = (ILogonListener) aLogonListener;
            try {
                logonListenr.onUserLoggedOn(ctx);
            } catch (Exception ex) {
                LOGGER.error(
                        "Exception while calling onuser userLoggedOn ",
                        ex);
            }
        }

    }

    /**
     *
     * @param ctx
     */
    public void userLoggedOff(ISessionContext ctx) {
        for (Object aLogonListener : logonListener) {
            ILogonListener logonListenr = (ILogonListener) aLogonListener;
            try {
                logonListenr.onUserLoggedOff(ctx);
            } catch (Exception ex) {
                LOGGER.error(
                        "Exception while calling onuser onUserLoggedOff ",
                        ex);
            }

        }
    }

    /**
     * @param ctx
     */
    public void onUserLogginOff(ISessionContext ctx) {
        for (Object aLogonListener : logonListener) {
            ILogonListener logonListenr = (ILogonListener) aLogonListener;
            try {
                logonListenr.onUserLoggingOff(ctx);
            } catch (Exception ex) {
                LOGGER.error("Exception while calling onuser logging off ", ex);

            }
        }

    }

    /**
     * @param ctx
     */
    public void onUserPermissionsChanged(ISessionContext ctx) {
        for (Object aLogonListener : logonListener) {
            ILogonListener logonListenr = (ILogonListener) aLogonListener;
            try {
                logonListenr.onUserPermissionsChanged(ctx);
            } catch (Exception ex) {
                LOGGER.error("Exception in onUserPermissionsChanged ", ex);
            }
        }
    }

    /**
     * Helper function to get the Local Context of the Server.
     *
     * @return ISessionContext Context of the Server.
     */
    private ISessionContext getLocalCtx() {
        return IScsControllableImpl
                .getLocalSecurityProviderFacade()
                .getSystemAccountContext();
    }


    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#getLdapCredentials()
     *
     * @deprecated ldap is no longer supported
     */
    @Deprecated
    @Override
    public Properties getLdapCredentials() throws BcbSecurityException {
//        if (LOGGER.isDebugEnabled()) {
//            LOGGER.debug("getLdapCredentials() Enter");
//        }
//        return LWLifecycleController.getInstance().getLdapCredentials();
        return null;
    }

    /**
     * This method sends notification to all client for any user log-in failure.
     *
     * @param strUserId - user name who tried to log in
     */
    private void sendLoginFailedNotification(String strUserId) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "sendLoginFailedNotification(" + strUserId + ") Entry");
        }

        UAUser objUser = UASubsystemSAP.getUserData(strUserId);
        if (objUser != null) {

            USMNotifier notifier = USMNotifier.getInstance();

            USMMessage objUSMMessage =
                    new USMMessage(
                            AAMessageType.AA_NOTIFICATION_USER_LOGIN_FAILED,
                            USMMessage.USMMESSAGE_NOTIFICATION);

            objUSMMessage.pushBoolean(objUser.isAccountLocked());
            objUSMMessage.pushInteger(objUser.getBadPasswordCount());
            objUSMMessage.pushString(strUserId);

            notifier.sendNotification(objUSMMessage);
        } else {
            LOGGER.error(
                    "Trying to login with a user not available in cache/DS");
        }

        LOGGER.debug("sendLoginFailedNotification()      Exit");
    }

    @Override
    public ISessionContext logon(KerberosTicket kTicket, byte[] userName, byte[] host, byte[] clientIpAddress, byte[] encoded, Handle userSessionBean) throws BcbSecurityException {
        throw new UnsupportedOperationException("This method is unsupported due to migration to ejb3");
    }


    @Override
    public void updateObjectContainer(BiCNetComponentType componentType, ISecurableObjectContainer securableContainer) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("updateObjectContainer called. ComponentType: " + componentType.guiLabel() + " securableObjectContainer: " + securableContainer);
        }

        BSSubsystemSAP.updateObjectContainer(componentType, securableContainer);

    }

	@Override
	public ISessionContext authenticate(String userId, String password, String clientComputerName)
			throws BcbSecurityException {
        return logon(userId, password, clientComputerName, NO_GUI_LOGON);
	}
	
	@Override
	public byte[] getUserPasswordSalt(String userName) throws BcbSecurityException {
		return authenticationWrapper.getUserPasswordSalt(userName);
	}
}
