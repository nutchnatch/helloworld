package com.ossnms.bicnet.securitymanagement.api.persistence.dao.groups;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.IBaseDAO;
import com.ossnms.bicnet.securitymanagement.persistence.model.groups.USMGroups;

import java.util.List;

/**
 * created on 28/8/2014
 */
public interface IUSMGroupsDao extends IBaseDAO<USMGroups, String> {
	List<String> findGroupsOfUser(String userName);
}
