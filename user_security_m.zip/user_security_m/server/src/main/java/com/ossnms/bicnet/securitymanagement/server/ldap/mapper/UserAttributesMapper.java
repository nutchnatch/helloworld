package com.ossnms.bicnet.securitymanagement.server.ldap.mapper;

import com.ossnms.bicnet.securitymanagement.server.ldap.dto.LDAPUser;
import org.springframework.ldap.core.AttributesMapper;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.InvalidAttributeIdentifierException;
import java.text.MessageFormat;

/**
 *
 */
public class UserAttributesMapper implements AttributesMapper<LDAPUser> {

    private String userIdAttribute;

    public UserAttributesMapper(String userIdAttribute){
        this.userIdAttribute = userIdAttribute;
    }

    /**
     *
     * @param attributes
     * @return
     * @throws NamingException
     */
    public LDAPUser mapFromAttributes(Attributes attributes) throws NamingException {
        LDAPUser ldapUser = new LDAPUser();

        Attribute userIdAttr = attributes.get(userIdAttribute);
        if(userIdAttr == null) {
            throw new InvalidAttributeIdentifierException(
                    MessageFormat.format("User ID Attribute {0} does not exist.", userIdAttribute)
            );
        }
        ldapUser.setUserID(userIdAttr.get().toString());

        return ldapUser;
    }
}