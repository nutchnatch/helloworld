/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AASessionContext
 * Author      	Jogender Singh
 * Substitute	Babu B
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.AUTHENTHICATE.USER
 *        TNMS.DX2.SM.LOGIN.USERID
 *		  TNMS.DX2.SM.LOGOUT.USER
 *	      TNMS.DX2.SM.CLIENT.REGSITER_MENU
 *        TNMS.DX2.SM.CLIENT.AUTHORIZE
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Asif 			CF000673 - Need a Unique Client idenitifer for the logged in User
 * 19-Jan-2005	Muyeen Munaver	CF001094 - Not possible do drag and drop NE's to the "Physical Root - View" window
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 * 22-Mar-2005	Muyeen Munaver	CF0001791 - Problems with Login
 * 14-Apr-2005	Muyeen Munaver	CF001025	Stop the Server - message to the clients
 * 10-May-2005	Muyeen Munaver	CF002170 - Resolve the Host name into the IP address fails
 * 14-Jun-2005  Muyeen Munaver  CF002457 - Manual Export not working
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.auth;

import com.ossnms.bicnet.bcb.facade.security.EnhancedSessionContextItem;
import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import org.apache.log4j.Logger;

import java.io.Serializable;
import java.util.List;

/**
 * This class holds the data of the session context transiently.
 *
 * In case of a successful logon the security CF returns a client session object,
 * which contains all logon and authorization information.
 * This class is initialized by retrieving security data from LDAP after
 * successful login, for authorization on client side.
 * This object will be maintained till the user session ends
 */
public class AASessionContext implements IEnhancedSessionContext, Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER =
            Logger.getLogger(AASessionContext.class);

    /**
     * Counter which keeps track of the numbers assigned to the session context
     */
    private static long counter = 1;

    /**
     * To uniquely identify the session object
     */
    private long uniqId = -1;

    /**
     * This is the name of the user who are logged in
     */
    private String userName;

    /**
     * This is the password of the user
     */
    private String password;

    /**
     * This is the list of user groups that the user belongs to.
     */
    private List<String> userGroup;

    /**
     * Data member to hold the Name of the Client which is responsible for this session ctx being created
     */
    private String strClientName;

    /**
     * Data member to hold the ip-address of the client.
     * This has been extended since it might not be possible to get the ip-address of the
     * client in the server (Could be the case when the client uses dynamic ip-address
     */
    private String strClientIPAddress;

    /**
     * Data member to hold the Name of the Server (or cluster).
     */
    private String strServerName;

    /**
     * Constructor
     *
     * @param username
     * @param password
     * @param serverName
     * @param clientName
     * @param clientIpAddress
     * @param userGroups
     * @param isLoggedin
     */
    public AASessionContext(String username, String password, String serverName, String clientName,
                            String clientIpAddress, List<String> userGroups, boolean isLoggedin) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "AASessionContext( "
                            + username
                            + " , *****, (Server Name)="
                            + serverName
                            + ", (Client Name)="
                            + clientName
                            + ", "
                            + userGroups
                            + ", "
                            + isLoggedin
                            + ") Entry");

        }

        if (counter == 0) {
            LOGGER.error(
                    "The uniq id has been recycled, which is unlikely and could be dangerous");
        }
        //Only in case the user id is not blank or null, it is a actual creation, otherwise, it is not necessary to
        //increment the uniq id.
        if (null != username && !"".equals(username)) {
            this.uniqId = counter++;
        } else {
            LOGGER.error(
                    "Null or empty String passed for User Name. " + username);
        }

        this.userName = username;
        strServerName = serverName;
        strClientName = clientName;
        this.userGroup = userGroups;
        this.password = password;
        strClientIPAddress = clientIpAddress;
        LOGGER.debug("AASessionContext(...)	Exit");
    }

    /**
     * Constructor
     *
     * @param username
     * @param password
     * @param serverName
     * @param clientName
     * @param clientIpAddress
     * @param userGroups
     */
    public AASessionContext(long uniqId, String username, String password, String serverName, String clientName,
                            String clientIpAddress, List<String> userGroups) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "AASessionContext( " + username + " , *****, (Server Name)=" + serverName + ", (Client Name)=" + clientName + ", " + userGroups + ") Entry");
        }

        if (uniqId == 0) {
            LOGGER.error("The unique id cannot be 0. There is the risk that the session is being wrongly created.");
        }

        this.uniqId = uniqId;
        this.userName = username;
        strServerName = serverName;
        strClientName = clientName;
        this.userGroup = userGroups;
        this.password = password;
        strClientIPAddress = clientIpAddress;
        LOGGER.debug("AASessionContext(...)	Exit");
    }

    /**
     * Returns the user password
     *
     * @return String - Password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Returns the server name where user has been logged in
     *
     * @return String - Server Name
     */
    @Override
    public String getServerName() {
        return strServerName;
    }

    /**
     * Returns the the list of user groups to which user belongs to
     *
     * @return List - List of the user group
     */
    @Override
    public List<String> getUserGroup() {
        return userGroup;
    }

    /**
     * Returns the user name
     *
     * @return String - User name
     */
    @Override
    public String getUserName() {
        return userName;
    }

    /**
     * Function to return the Ip-address of the client machine
     *
     * @return String The Ipaddress of the client machine
     */
    @Override
    public String getClientIpAddress() {
        return strClientIPAddress;
    }

    /**
     * Sets the user password
     *
     * @param password
     * @return void
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Sets the Server Name
     *
     * @param serverName
     */
    @Override
    public void setServerName(String serverName) {
        strServerName = serverName;
    }

    /**
     * Sets the user groups to which user belongs to
     *
     * @param userGroup
     * @return void
     */
    @Override
    public void setUserGroup(List<String> userGroup) {
        this.userGroup = userGroup;
    }

    /**
     * Sets the user name
     *
     * @param username
     * @return void
     */
    @Override
    public void setUserName(String username) {
        this.userName = username;
    }

    /**
     * Sets the machine name where the client is running
     *
     * @param clientMcName
     */
    @Override
    public void setClientMachineName(String clientMcName) {
        strClientName = clientMcName;
    }

    @Override
    public String getClientMachineName() {
        return strClientName;
    }

    /**
     * Sets the IP address of the machine where the client is running
     *
     * @param address - IP address of the client machine
     */
    @Override
    public void setClientIpAddress(String address) {
        strClientIPAddress = address;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (uniqId ^ (uniqId >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        AASessionContext other = (AASessionContext) obj;
        if (uniqId != other.uniqId) {
            return false;
        }
        return true;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuffer strBuffer = new StringBuffer(200);

        // Add user id
        strBuffer.append("userid=");
        strBuffer.append(userName);
        strBuffer.append(" UniqId=");
        strBuffer.append(uniqId);
        strBuffer.append(" Client=");
        strBuffer.append(strClientName);

        return strBuffer.toString();
    }

    /**
     *
     * @return
     */
    public IEnhancedSessionContext toSessionContext(){
        EnhancedSessionContextItem enhancedSessionContextItem = new EnhancedSessionContextItem(strServerName, strClientName, strClientIPAddress, userGroup, userName, uniqId);

        // Workaround, BCB object should be fixed
        enhancedSessionContextItem.setUserName(userName);
        return enhancedSessionContextItem;
    }

    /**
     *
     * @param sessionContext
     * @return
     */
    public static AASessionContext fromSessionContext(IEnhancedSessionContext sessionContext){
        if(sessionContext instanceof AASessionContext){
            return (AASessionContext) sessionContext;
        }else {
            //it should be an EnhancedSessionContextItem instance
            EnhancedSessionContextItem enhancedSessionContextItem = (EnhancedSessionContextItem) sessionContext;
            AASessionContext aaSessionContext = new AASessionContext(
                    enhancedSessionContextItem.getUniqId(),
                    enhancedSessionContextItem.getUserName(),
                    "",
                    enhancedSessionContextItem.getServerName(),
                    enhancedSessionContextItem.getClientMachineName(),
                    enhancedSessionContextItem.getClientIpAddress(),
                    enhancedSessionContextItem.getUserGroup()
            );
            return aaSessionContext;
        }
    }

    /**
     * This gets the uniq id of the session context
     *
     * @return
     */
    @Override
    public long getUniqId() {
        LOGGER.info("The uniq id returned is " + uniqId);
        if (-1 == uniqId) {
            LOGGER.error(
                    "Uniq id requested where the data is invalid "
                            + uniqId
                            + " "
                            + this.toString());
        }
        return uniqId;
    }

    /**
     *
     * @param uniqId
     */
    public void setUniqId(long uniqId){
        this.uniqId = uniqId;
    }
}
