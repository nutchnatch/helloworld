/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 19-Jan-2005	Muyeen Munaver	CF000297 - Sync Step 1a)
 * 14-June-2005  Muyeen Munaver  CF000209 - Changes in the ISecurityProviderFacade / IManagedObject
 * 05-May-2005  Babu B  CF001312   Master-Master Replication for Sun ONE DS
 * 08-Aug-2005	Balasubramanya	CF002760 - 9320_MR_0291 Users, User Groups, Policies lose associations after import
 * 08-Aug-2005	Balasubramanya	CF002759 - 9320_MR_0289 Security information discarded for user after deletion and restore
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.bicnetserver;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.security.ISecurableObject;
import com.ossnms.bicnet.bcb.model.security.ISecurableObjectContainer;
import com.ossnms.bicnet.bcb.model.security.ISecurableObjectId;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSReturnType;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;

/**
 * This is the SAP that should be used by the other subsystems in the
 * CF USM if they have to retrieve some information from BS. This is
 * there since there is no message based communication within the same process.
 */
public class BSSubsystemSAP {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(BSSubsystemSAP.class);

	/**
	 * This interface is needed by DC to retrieve the list of all the configured
	 * CF's.
	 * @return List List of Configured CFs within CF USM
	 */
	public static List<BSTransBicNetCFInfo> getAllConfiguredCFs() {
		LOGGER.debug("Entering getAllFunctions");

		List<BSTransBicNetCFInfo> cfs = BSCentralController.getInstance().getAllConfiguredCFs();

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting getAllFunctions. Returning CFs : " + cfs);
		}
		return cfs;
	}

	/**
	 * This interface is needed by DC. When DC recieves a CF inserted notification, 
	 * it needs to not only display the cf info dynamically
	 * but also the Securable Object(s) that belong to the CF. This interface has been
	 * provided so that DC can achieve its objective. So after DC gets the
	 * notification, it queries for the Securable Object(s) of
	 * the CF. It will then update the GUI with this information.
	 * @param cfDetails CF for which we want to get the Securable Object(s).
	 * @param lstSecObjects Securable Objects which belong to the passed CF
	 * @return boolean Indicates whether it is possible to get the Securable Objects for the CF
	 */
    public static BSReturnType getSecurableObjects(BSTransBicNetCFInfo cfDetails, List<BSSecurableObject> lstSecObjects) {

        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering getSecurableObjects. CF : {} List : {}", cfDetails,lstSecObjects);
        }

        if((cfDetails == null) || (lstSecObjects == null)) {
            LOGGER.error("Parameters cannot be null. CF + {} List : {}", cfDetails, lstSecObjects);
            throw new InvalidParameterException();
        }
        lstSecObjects.clear();
        BSReturnType result = BSCentralController.getInstance().getSecurableObjects(cfDetails, lstSecObjects);

        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting getSecurableObjects. Result : {} CF + {} List : {}", result, cfDetails, lstSecObjects);
        }
		return result;
	}

	/**
	 * This interface is needed by DC. When DC recieves a CF inserted notification,
	 * it needs to not only display the cf info dynamically
	 * but also the Securable Object(s) that belong to the CF. This interface has been
	 * provided so that DC can achieve its objective. So after DC gets the
	 * notification, it queries for the Securable Object(s) of
	 * the CF. It will then update the GUI with this information.
	 * @param cfDetails CF for which we want to get the Securable Object(s).
	 * @param lstSecObjects Securable Objects which belong to the passed CF
	 * @return boolean Indicates whether it is possible to get the Securable Objects for the CF
	 */
	public static BSReturnType getSecurableObjects(BSTransBicNetCFInfo cfDetails, List<BSSecurableObject> lstSecObjects, int domainId) {

		if(LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering getSecurableObjects. CF : {} List : {}", cfDetails, lstSecObjects);
		}

		if((cfDetails == null) || (lstSecObjects == null)) {
			LOGGER.error("Parameters cannot be null. CF + {} List : {}", cfDetails, lstSecObjects);
			throw new InvalidParameterException();
		}

		lstSecObjects.clear();
		BSReturnType result = BSCentralController.getInstance().getSecurableObjects(cfDetails, lstSecObjects, domainId);

		if(LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting getSecurableObjects. Result : {} CF + {} List : {}", result, cfDetails, lstSecObjects);
		}
		return result;
	}

	/**
	 *
	 * @param server
	 * @return
	 */
	public static int getSecurableObjectsCount(BSTransBicNetCFInfo server) {
		return BSCentralController.getInstance().getSecurableObjectCount(server);
	}

	/**
	 *
	 * @param server
	 * @param domainID
     * @return
     */
	public static int getSecurableObjectsCount(BSTransBicNetCFInfo server, int domainID) {
		return BSCentralController.getInstance().getSecurableObjectCount(server, domainID);
	}

	/**
	 * When a new domain is being created, or new Securable Object(s) are being added to an existing
	 * domain, DC needs to inform BS about these changes, so that the Securable Object info can be
	 * updated. This interface is used by DC to inform BS about Securable Object(s) being added to a
	 * Domain.
	 * @param lstSecObjs The list of Securable Object(s) which needs to be added to the domain
	 * @param domain The domain where the Securable Object(s) should be added to.
	 * @param lstUnAssignedSecObjs The Securable Object(s) which could not be assigned to the
	 * Domain.
	 * @return boolean The return value indicates whether the operation succeded or 
	 * not. True indicates success.
	 */
    public static boolean setDomainForSecObjs(List<BSSecurableObject> lstSecObjs, DCDomainData domain, List<BSSecurableObject> lstUnAssignedSecObjs) {
		LOGGER.debug("Entering setDomainForSecObjs");

        boolean bResult = updateACLForSecObjs(lstSecObjs, domain, lstUnAssignedSecObjs, true);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting setDomainForSecObjs. Result is : " + bResult);
		}
		return bResult;
	}

	/**
	 * When Securable Object(s) assigned to an existing domain as unassigned, DC needs to inform BS
	 * about these changes, so that the Securable Object(s) info can be updated. This interface is used
	 * by DC to inform BS about Securable Object(s) being removed from a Domain.
	 * @param lstSecObjs The list of Securable Object(s) which needs to be removed from the domain
	 * @param domain The domain where the Securable Object(s) should be removed from.
	 * @param lstFailureSecObjs The Securable Object(s) which could not be un assigned
	 * @return boolean The return value indicates whether the operation succeded or 
	 * not. True indicates success.
	 */
    public static boolean unsetDomainForSecObjs(List<BSSecurableObject> lstSecObjs, DCDomainData domain, List<BSSecurableObject> lstFailureSecObjs) {
        LOGGER.debug("Entering unsetDomainForSecObjs");

        boolean bResult = updateACLForSecObjs(lstSecObjs, domain, lstFailureSecObjs, false);

        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting unsetDomainForSecObjs. Result is : " + bResult);
        }
		return bResult;
	}

	/**
	 * Function to update the ACL for the Securable Objects.
	 * @param lstSecObjs List of Securable Objects that should be updated
	 * @param domain The Domain to which the securable object should be added/removed
	 * @param lstFailureSecObjs The List of Securable Objects for which it was not possible to add/remove from domain
	 * @param assignDomains Indicates whether we want to assign or unassign from a domain
	 * @return boolean Returns true if it was possible to complete the operation.
	 */
    private static boolean updateACLForSecObjs(List<BSSecurableObject> lstSecObjs, DCDomainData domain, List<BSSecurableObject> lstFailureSecObjs, boolean assignDomains) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering updateACLForSecObjs. List Securable Objects : " + lstSecObjs + " Domain : " + domain + " Setting : " + assignDomains);
        }

        if((lstSecObjs == null) || (domain == null) || (lstFailureSecObjs == null)) {
            LOGGER.error("Parameter cannot be null. Security Object(s) : " + lstSecObjs + " Domain : " + domain + " Failed Sec object(s) : " + lstFailureSecObjs);
			throw new InvalidParameterException();
		}
		lstFailureSecObjs.clear();
		List<DCDomainData> lstDomains = new ArrayList<>();
		lstDomains.add(domain);

        BSReturnType bsResult = BSCentralController.getInstance().updateACLForSecurableObjects(lstSecObjs, lstDomains, lstFailureSecObjs, assignDomains);

        boolean bResult = bsResult.equals(BSReturnType.SUCCESS_T);
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting updateACLForSecObjs. List Failed Objects : " + lstFailureSecObjs + " Result : " + bResult);
        }
		return bResult;
	}

	/**
	 * This function returns all the Securable Object(s) that are currently managed by 
	 * CF USM
	 * @return List The list of Securable Objects within BS
	 */
	public static List<BSSecurableObject> getAllSecurableObjects() {
		LOGGER.debug("Entering getSecurableObjects");

		List<BSSecurableObject> lstSecObjs = BSCentralController.getInstance().getAllSecurableObjects();

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting getSecurableObjects. List : " + lstSecObjs);
		}
		return lstSecObjs;
	}


	public static List<BSSecurableObject> getAllSecurableObjectsWithACL() {
		LOGGER.debug("Entering getAllSecurableObjectsWithACL");

		List<BSSecurableObject> lstSecObjs = BSCentralController.getInstance().getAllSecurableObjectsWithACL();

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting getAllSecurableObjectsWithACL. List : " + lstSecObjs);
		}
		return lstSecObjs;
	}

	/**
	 * This method returns the SecurableObject, currently managed by USM, with the unique name as specified
	 * @return the SecurableObject if exists with the specified name, null otherwise
	 */
	public static BSSecurableObject getSecurableObject(ISecurableObjectId objectId){
		LOGGER.debug("Entering getSecurableObjectByDisplayName");

		BSSecurableObject secObj = BSCentralController.getInstance().getSecurableObject(objectId);

		LOGGER.debug("Exiting getSecurableObjectByDisplayName. Object : " + secObj);

		return secObj;
	}

	/**
	 * Function to return the ACL for a given Securable Object
	 * 
	 * @param object The Securable Object for which we have to retrieve the ACL.
	 * 
	 * @return BitSet The ACL of the Securable Object. It will be null if the Securable Object is not
	 * 			available within BS.
	 */
    public static BitSet getACLForSecurableObject(IManagedObjectId object) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering getACLForSecurableObject. Securable Object is : " + object);
		}

        if(object == null) {
            LOGGER.error("Securable Object for which you want an ACL cannot be null.");
            throw new InvalidParameterException();
        }
		BitSet btSet = BSCentralController.getInstance().getACLForSecurableObject(object);

        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting getACLForSecurableObject. Securable Object : " + object + " ACL : " + btSet);
        }
		return btSet;
	}

	/**
	 * Function to register a securable object 
	 * @param component The CF which owns the object
	 * @param securableObject The Securable Object that should be added.
	 */
    public static void registerObject(BiCNetComponentType component, ISecurableObject securableObject) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering registerObject. Securable Object : " + securableObject + " Component : " + component);
        }

        if((component == null) || (securableObject == null)) {
            LOGGER.error("Parameter cannot be null. Securable Object : " + securableObject + " Component : " + component);
			throw new InvalidParameterException();
		}

        BSCentralController.getInstance().registerObject(component, securableObject);

		LOGGER.debug("Exiting registerObject.");
	}

	/**
	 * Function to un-register a securable object
	 * @param component The CF which owns the object
	 * @param securableObject The Securable Object that should be removed
	 * @return Indicates whether it was possible to remove the securable object or not.
	 */
    public static boolean unregisterObject(BiCNetComponentType component, ISecurableObject securableObject) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering registerObject. Securable Object : " + securableObject + " Component : " + component);
        }

        if((component == null) || (securableObject == null)) {
            LOGGER.error("Parameter cannot be null. Securable Object : " + securableObject + " Component : " + component);
            throw new InvalidParameterException();
        }

        boolean bResult = BSCentralController.getInstance().unregisterObject(component, securableObject);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting unregisterObject. Result is : " + bResult);
		}
		return bResult;
	}

	/**
	 * @param component component type
	 * @param securableObject securable object
	 */
    public static void updateObject(BiCNetComponentType component, ISecurableObject securableObject) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering updateObject. Securable Object : " + securableObject + " Component : " + component);
        }

        if((component == null) || (securableObject == null)) {
            LOGGER.error("Parameter cannot be null. Securable Object : " + securableObject + " Component : " + component);
            throw new InvalidParameterException();
        }

        BSCentralController.getInstance().updateObject(component, securableObject);

		LOGGER.debug("Exiting updateObject.");
	}

	/**
	 * @param component component type
	 * @param securableObjectContainer securable object container
	 */
    public static void updateObjectContainer(BiCNetComponentType component, ISecurableObjectContainer securableObjectContainer) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering updateObjectContainer. Securable Object Container: " + securableObjectContainer + " Component : " + component);
        }

        if((component == null) || (securableObjectContainer == null)) {
            LOGGER.error("Parameter cannot be null. Securable Object Container: " + securableObjectContainer + " Component : " + component);
            throw new InvalidParameterException();
        }

        BSCentralController.getInstance().updateObjectContainer(component, securableObjectContainer);

		LOGGER.debug("Exiting updateObjectContainer.");
	}    
    
    
	/**
	 * Function to do the Synchronization of all securable Object related data.
	 * @param sessionContext The Session context of the operator driving the sync operation
	 * @throws BcbException Exception to be raised in case of problem
	 */
	public static void doFullSync(ISessionContext sessionContext)
		throws BcbException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering doFullSync. Ctx : " + sessionContext);
		}

		if (sessionContext == null) {
			LOGGER.error("Parameter cannot be null");
			throw new InvalidParameterException();
		}

		BSCentralController.getInstance().doFullSync(sessionContext);

		LOGGER.debug("Exiting registerObject.");
	}

}
