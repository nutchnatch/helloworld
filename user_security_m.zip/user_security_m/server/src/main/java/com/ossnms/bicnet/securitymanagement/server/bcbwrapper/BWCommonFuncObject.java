/*
 * Project      BiCNET Common Functions
 *
 * Component    CF:USM
 * Class Name   BWCommonFuncObject
 * Author       Muyeen M
 * Substitute   Asif Khan R
 * Created on   18-11-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 02-Feb-2005  Babu B          CF000199-11 Unification of GUI-Labels for Enums
 * 31-Mar-2005  Muyeen Munaver	CF001903 - Change null values given by CF's @ IBicNetService to defaults to continue
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.bcbwrapper;

import com.ossnms.bicnet.bcb.facade.IMgrFacade;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.ComponentVersionInformation;
import com.ossnms.bicnet.bcb.model.security.ISecurableObject;
import com.ossnms.bicnet.securitymanagement.server.auth.AALocalSecurityProviderFacadeImpl;
import com.ossnms.bicnet.util.versions.ServerComponentVersionInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.MessageFormat;

/**
 *
 * Class which encapsulates a single CF.
 */
public class BWCommonFuncObject {

	/**
	 * Data member to hold the Logger.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(BWCommonFuncObject.class);

	/**
	 * Data member to hold the BicNet Service for which this object
	 * was created
	 */
	private IMgrFacade cf = null;

	/**
	 * Data member to hold the type
	 */
	private BiCNetComponentType compType = null;

	/**
	 * Constructor. Has been made as package level intentionally.
	 *
	 * @param cf The CF for which this object is being created.
	 */
	BWCommonFuncObject(BiCNetComponentType compType, IMgrFacade cf) {
		LOGGER.debug("Entering Constructor. Type is : {}", compType);

		this.cf = cf;
		this.compType = compType;
	}

	/**
	 *
	 * get a displayable name for the component
	 * @return  name - returns the component's name
	 * @throws BcbException
	 */
	public String getName() throws BcbException {
		String strName = cf.getName(AALocalSecurityProviderFacadeImpl.getInstance().getSystemAccountContext());

		if (strName == null) {
			strName = compType.guiLabel();
			LOGGER.error("Name cannot be null. Using getGuiLabel() : {}", strName);
		}

		return strName;
	}

	/**
	 *
	 * get a short description for the component
	 * @return  version - returns a short description for the component
	 * @throws BcbException
	 */
	public String getDescription() throws BcbException {
		String strDesc = cf.getDescription(AALocalSecurityProviderFacadeImpl.getInstance().getSystemAccountContext());

		if (strDesc == null) {
			strDesc = "";
			LOGGER.error("Description cannot be null. Using blank for : {}", compType.guiLabel());
		}

		return strDesc;
	}

	/**
	 *
	 * get describing properties of the component
	 * @return  biCNetComponentType - an object containing a set of properties for the component
	 */
	public BiCNetComponentType getComponentType() {
		return compType;
	}

    /**
     * get the version of the component
     * 
     * @return version - returns the component's version
     * @throws BcbException
     */
    public ComponentVersionInformation getVersion() throws BcbException {
        // retrieves VersionInformation
		ComponentVersionInformation ver = cf.getVersion(AALocalSecurityProviderFacadeImpl.getInstance().getSystemAccountContext());

		if(ver == null) {
            ver = ServerComponentVersionInfo.getVersionInfo(getClass());
            LOGGER.error("VersionInformation cannot be null. Using default for : {}", compType.guiLabel());
        }

        return ver;
    }

	/**
	 * Provides a complete list of ojects the component owns and whishes of to be managed by User & SecurityMgmt
	 * Each single object is identical with those objects that can later on be tested by securityMgmt using the methods
	 * "checkObjectPermission" provided by ISecureServerSession and ISecureClientSession
	 *
	 * @return array of securable objects
	 */
	public ISecurableObject[] getSecurableObjects() {
		ISecurableObject[] arr = cf.getSecurableObjects();
		if (arr == null) {
			LOGGER.debug("Objects returned is null. Returning empty for : {}", compType.guiLabel());
			arr = new ISecurableObject[0];
		}
		return arr;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return MessageFormat.format("Object for type : {0}", compType.guiLabel());
	}

}
