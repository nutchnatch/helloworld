package com.ossnms.bicnet.securitymanagement.common.domain;

import java.io.Serializable;
import java.util.List;

import org.apache.log4j.Logger;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;

/**
 * This class holds the data of the created domains transiently. Domain does
 * not contain the data of the Securable Objects, but Securable Objects contain
 * the data to which domain it belongs to.
 */
public class DCDomainData implements Serializable {

	private static final long serialVersionUID = 1193295418223092151L;
	
	private static final Logger LOGGER = Logger.getLogger(DCDomainData.class);
	/**
	 * Global domain which is never stored in the directory server
	 */
	public static final DCDomainData GLOBAL_DOMAIN =
		new DCDomainData(
			DCMessages.getInstance().getString(DCMessages.DC_GLOBAL_DOMAIN),
			0,
			0,
			"Global domain containing all NEs");

	/**
	 * This is the name of the created domain. The name is unique.
	 */
	private String domainName;

	/**
	 * A user descriptive name of the domain which is created.
	 */
	private String domainDescription;

	/**
	 * This ensures the unique identification of created domain. This becomes
	 * necessary when the new and old (deleted) domains have same domain IDs.
	 * Since domain ids are recycled after 128. They may contain currently at
	 * most 128 domains
	 */
	private int domainUniqueID;

	/**
	 * This is an id for the created domain. Domain with id 0 is assumed to be
	 * global domain to which all NEs are assigned when they are created. The
	 * id range is from 0-127. Therefore, a maximum of 128 domains are possible
	 * at any given instant.
	 */
	private int domainID;

	/**
	 * Constructor which takes the name, id and creation id and description of
	 * the domain to be created
	 * 
	 * @param pStrDomainName -
	 *            The name of the domain. This should be unique
	 * @param pNID -
	 *            The unique id of the domain
	 * @param pNDomainCreationUID -
	 *            The creation time stamp of the domain
	 * @param pStrDomainDescription -
	 *            The user description of the domain
	 */
	public DCDomainData(
		String pStrDomainName,
		int pNID,
		int pNDomainCreationUID,
		String pStrDomainDescription) {
		domainUniqueID = pNDomainCreationUID;
		domainID = pNID;
		domainDescription = pStrDomainDescription;
		if (null != pStrDomainName) {
			domainName = pStrDomainName.trim();
		}
	}

	/**
	 * Default constructor This constructor should be followed by popMe method
	 * or set methods to populate the contents.
	 */
	public DCDomainData() {

	}

	/**
	 * Pushes on the domain details onto a USMMessage. Used by the sender of
	 * the message
	 * 
	 * @param p_msg -
	 *            The USMMessage onto which the domain details have to be
	 *            pushed into
	 */
    public void pushMe(USMMessage p_msg) {
        // push the name, id, descr, uid in that order
        p_msg.pushString(domainName);
        p_msg.pushInteger(domainID);
        p_msg.pushString(domainDescription);
        p_msg.pushInteger(domainUniqueID);
    }

	/**
	 * Pops the domain details from a USMMessage. Used typically by the
	 * Receiver of the message
	 * 
	 * @param pMsg -
	 *            The USMMessage onto which the domain details have to be
	 *            popped from
	 */
	public void popMe(USMMessage pMsg) {
		//pop the uid, descr, id, name in that order
		try {
			domainUniqueID = pMsg.popInteger();
			domainDescription = pMsg.popString();
			domainID = pMsg.popInteger();
			domainName = pMsg.popString();
		} catch (Exception ex) {
		    LOGGER.warn("Stack in inconsistent state, objects must be pushed/poped in the correct order", ex);
		}
	}

	/**
	 * Function to get the domain id of the domain
	 * 
	 * @return int Returns the domain id
	 */
	public int getDomainID() {
		return domainID;
	}

    /**
     * Function to set the id of the domain
     *
     * @param domainId the id of the domain
     */
    public void setDomainID(int domainId){
        domainID = domainId;
    }

	/**
	 * Function to get the unique domain id of the domain
	 * 
	 * @return int -  Returns the unique domain id of the domain
	 */
	public int getDomainUID() {
		return domainUniqueID;
	}

    /**
     * Function to set the unique domain id of the domain
     *
     * @param domainUniqueId int the unique domain of the domain
     */
    public void setDomainUID(int domainUniqueId){
        domainUniqueID = domainUniqueId;
    }

	/**
	 * Overridden hashCode method of Object if equals has to be overridden
	 * 
	 * @return int Returns a unique id for this domain object
	 */
	@Override
    public int hashCode() {
		return domainID;
	}

	/**
	 * Checks whether the current domain is a global domain or not.
	 * 
	 * @return boolean Returns true to indicate that it is a global domain
	 */
	public boolean isGlobalDomain() {
		return this.equals(GLOBAL_DOMAIN);
	}

	/**
	 * Helper function to push a list of domains onto the message
	 * 
	 * @param pDomains
	 *            List of DCDomainData that needs to be pushed onto the
	 *            message
	 * @param pMsg
	 *            The USMMessage onto which the list of domains need to be
	 *            pushed into
	 */
	public static void pushDomainsToMessage(List<DCDomainData> pDomains, USMMessage pMsg) {
		//Pushes the vector of domains into the USM Message
        for (DCDomainData pDomain : pDomains) {
            pDomain.pushMe(pMsg);
        }
		pMsg.pushInteger(pDomains.size());

	}

	/**
	 * Helper function to pop a list of domains from a message. This clears
	 * and return the list
	 * @param pMsg
	 *            The USMMessage from where the list of domain has to be popped
	 *            from
	 * @param pDomains
	 *            List of DCDomainData that will be filled up after
	 *            popping.
	 */
	public static void popDomainsFromMessage(
		USMMessage pMsg,
		List<DCDomainData> pDomains) {

		pDomains.clear();
		//Pops the the vector of domains from the USM Message
		int nSize = pMsg.popInteger();
		for (int i = 0; i < nSize; ++i) {
			DCDomainData dom = new DCDomainData();
			dom.popMe(pMsg);
			pDomains.add(dom);
		}
	}

	/**
	 * Function to get the domain name
	 * 
	 * @return String Returns the domain name of the domain
	 */
	public String getDomainName() {
		return domainName;
	}

    /**
     * Function to set the domain name
     *
     * @param name String name of the domain
     */
    public void setDomainName(String name){
        domainName = name;
    }

	/**
	 * Function to get the domain description
	 * 
	 * @return String Returns a domain description
	 */
	public String getDomainDescr() {
		return domainDescription;
	}

    /**
     * Function to set the domain description
     *
     * @param pDescr
     *            The user description string of the domain
     */
    public void setDomainDescr(String pDescr) {
        domainDescription = pDescr;
    }

	/**
	 * Overridden equals method for comparison purposes. The id of the domain
	 * is used for comparison
	 * 
	 * @param obj
	 *            The object agains which the current object has to be compared
	 *            with
	 * @return boolean Returns true if the object are equal
	 */
	@Override
    public boolean equals(Object obj) {
		boolean bRet = false;
		DCDomainData dom;
		if (obj instanceof DCDomainData) {
			dom = (DCDomainData) obj;
			bRet = (domainID == dom.domainID);
		}
		return bRet;
	}

	/**
	 * Function to set the domain description
	 * 
	 * @param pDescr
	 *            The user describle string of the domain
	 */
	public void setDomainDescription(String pDescr) {
		domainDescription = pDescr;
	}

	/**
	 * Overridden toString method for display purposes
	 * 
	 * @return java.lang.String Returns the string to be displayed
	 */
	@Override
    public String toString() {
		return domainName;
	}
}
