/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 20-02-2005	Asifulla Khan   CF000060-01   CF USM GUI Requirements
 * 30-Mar-2005	Babu B          CF001771      Security menu = two menu items with same shortcut
 * 27-Jun-2005  Muyeen Munaver  CF002719 Master-Master Replication Limitation; support only Global NE Domain
 * 05-Aug-2005  Shrinidhi G V   CF002751   9320_MR_0282 Why do we have the TMN Application Server Administration Window?
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.basic;

/**
 * This class contains all the menu label list and is used for authorization.
 */
public final class USMMenuNameList {

    public static final String DEACTIVATE = "Deactivate";
    public static final String ACTIVATE = "Activate";
    public static final String UNLOCK = "Unlock";
    public static final String FORCE_LOGOFF = "Force Logoff";
    public static final String SYNC_SEC_OBJS = "Sync Data";
    public static final String NEW = "New";
    public static final String MODIFY = "Modify";

    public static final String DELETE = "Delete";
    public static final String REMOVE = "Remove";

    public static final String APPLY = "Apply";
    public static final String ADD = "Add";
    public static final String DETAILS = "Details";
    public static final String IMPORT = "Import";
    public static final String EXPORT = "Export";
    public static final String ASSIGN_POLICY = "Assign Policy";

    public static final String LOGIN = "&Login";
    public static final String LOGOUT = "L&ogout";
    public static final String CONFIG_SSO = "Single Sign-on Configuration";

    public static final String LABEL_CHANGE_PASSWORD = "Change Password";
    public static final String LABEL_TMN_SERVER_ADMINISTRATION = "TMN Application Server Administration";
    public static final String LABEL_DOMAIN_ADMINISTRATION = "Security Domain Management";
    public static final String LABEL_POLICY_ADMINISTRATION = "Policy Management";
    public static final String LABEL_USER_ADMINISTRATION = "User Management";
    public static final String LABEL_USER_GROUP_ADMINISTRATION = "User Group Management";
    public static final String LABEL_ACCESS_RIGHTS = "Access Rights";
    public static final String LABEL_SECURITY_SETTINGS = "Security Settings";
    public static final String LABEL_SECURITY_SETTINGS_SSO = "Single Sign-on";
    public static final String LABEL_SECURITY_SETTINGS_LDAP_AUTHENTICATION = "LDAP Authentication";
    public static final String LABEL_SECURITY_SETTINGS_PASSWORD_VAIDATION_RULES = "Password Validation Rules";
    public static final String LABEL_SECURITY_SETTINGS_RADIUS_AUTHENTICATION = "RADIUS Authentication";
    public static final String LABEL_SECURITY_SETTINGS_GENERAL = "General";
    public static final String LABEL_SECURITY_SETTINGS_MESSAGE = "Advisory Message";
    public static final String LABEL_SECURITY_LOG = "Security Log";
    public static final String LABEL_LICENSE_KEY_ADMINISTRATION = "License Management";
    public static final String LABEL_LICENSE_LOG = "License Log";
    public static final String LABEL_LICENSE_LOG_SETTINGS = "License Log Settings";

    public static final String FILE_MENU = "File";
    public static final String LABEL_EXPORT_CONFIG = "Export Configuration";
    public static final String SETTINGS = "Settings";
    
    public static final String MENU_DOTS = "...";

    public static final String MENU_CHANGE_PASSWORD_LABEL = "&Change Password" + MENU_DOTS;
    public static final String MENU_CHANGE_PASSWORD_SHORT_DESC = "Change the password";
    public static final String MENU_CHANGE_PASSWORD_LONG_DESC = "Allows the user to change password";

    public static final String MENU_DOMAIN_ADMIN_LABEL = "Security &Domain Management" + MENU_DOTS;

    public static final String MENU_POLICY_ADMIN_LABEL = "&Policy Management" + MENU_DOTS;

    public static final String MENU_USER_ADMIN_LABEL = "&User Management" + MENU_DOTS;

    public static final String MENU_USER_GROUP_ADMIN_LABEL = "User &Group Management" + MENU_DOTS;

    public static final String MENU_ACCESS_RIGHTS_LABEL = "&Access Rights" + MENU_DOTS;

    private static final String MAIN_SECURITY_MENU = "Administration";
    private static final String MAIN_SYSTEM_PREFERENCES_MENU = "System Preferences";
    private static final String DELIMITER = "->";

    public static final String OPERATION_TMN_APP_SERVERS_ADMIN = MAIN_SECURITY_MENU + DELIMITER + LABEL_TMN_SERVER_ADMINISTRATION + MENU_DOTS;

    // This is button level security, hence no dots
    public static final String OPERATION_TMN_APP_SERVER_REMOVE = MAIN_SECURITY_MENU + DELIMITER + LABEL_TMN_SERVER_ADMINISTRATION + DELIMITER + REMOVE;

    public static final String OPERATION_TMN_APP_SERVER_SYNC_SEC_OBJS = MAIN_SECURITY_MENU + DELIMITER + LABEL_TMN_SERVER_ADMINISTRATION + DELIMITER + SYNC_SEC_OBJS;

    // Domain Administration...
    public static final String OPERATION_DOMAIN_ADMIN = MAIN_SECURITY_MENU + DELIMITER + LABEL_DOMAIN_ADMINISTRATION + MENU_DOTS;
    public static final String OPERATION_DOMAIN_NEW = MAIN_SECURITY_MENU + DELIMITER + LABEL_DOMAIN_ADMINISTRATION + DELIMITER + NEW;
    public static final String OPERATION_DOMAIN_MODIFY = MAIN_SECURITY_MENU + DELIMITER + LABEL_DOMAIN_ADMINISTRATION + DELIMITER + MODIFY;
    public static final String OPERATION_DOMAIN_DELETE = MAIN_SECURITY_MENU + DELIMITER + LABEL_DOMAIN_ADMINISTRATION + DELIMITER + DELETE;
    public static final String OPERATION_DOMAIN_ASSIGN_MAPPINGS = MAIN_SECURITY_MENU + DELIMITER + LABEL_DOMAIN_ADMINISTRATION + DELIMITER + ASSIGN_POLICY + MENU_DOTS;
    public static final String OPERATION_DOMAIN_ASSIGN_MAPPINGS_APPLY = MAIN_SECURITY_MENU + DELIMITER + LABEL_DOMAIN_ADMINISTRATION + DELIMITER + ASSIGN_POLICY + DELIMITER + APPLY;

    // Policy Administration...
    public static final String OPERATION_POLICY_ADMIN = MAIN_SECURITY_MENU + DELIMITER + LABEL_POLICY_ADMINISTRATION + MENU_DOTS;
    public static final String OPERATION_POLICY_NEW = MAIN_SECURITY_MENU + DELIMITER + LABEL_POLICY_ADMINISTRATION + DELIMITER + NEW;
    public static final String OPERATION_POLICY_MODIFY = MAIN_SECURITY_MENU + DELIMITER + LABEL_POLICY_ADMINISTRATION + DELIMITER + MODIFY;
    public static final String OPERATION_POLICY_DELETE = MAIN_SECURITY_MENU + DELIMITER + LABEL_POLICY_ADMINISTRATION + DELIMITER + DELETE;

    // User Administration
    public static final String OPERATION_USERS_ADMIN = MAIN_SECURITY_MENU + DELIMITER + LABEL_USER_ADMINISTRATION + MENU_DOTS;
    public static final String OPERATION_USER_NEW = MAIN_SECURITY_MENU + DELIMITER + LABEL_USER_ADMINISTRATION + DELIMITER + NEW;
    public static final String OPERATION_USER_MODIFY = MAIN_SECURITY_MENU + DELIMITER + LABEL_USER_ADMINISTRATION + DELIMITER + MODIFY;
    public static final String OPERATION_USER_DELETE = MAIN_SECURITY_MENU + DELIMITER + LABEL_USER_ADMINISTRATION + DELIMITER + DELETE;
    public static final String OPERATION_USER_FORCE_LOGOFF = MAIN_SECURITY_MENU + DELIMITER + LABEL_USER_ADMINISTRATION + DELIMITER + FORCE_LOGOFF;
    public static final String OPERATION_USER_UNLOCK = MAIN_SECURITY_MENU + DELIMITER + LABEL_USER_ADMINISTRATION + DELIMITER + UNLOCK;
    public static final String OPERATION_USER_ACTIVATE = MAIN_SECURITY_MENU + DELIMITER + LABEL_USER_ADMINISTRATION + DELIMITER + ACTIVATE;
    public static final String OPERATION_USER_DEACTIVATE = MAIN_SECURITY_MENU + DELIMITER + LABEL_USER_ADMINISTRATION + DELIMITER + DEACTIVATE;

    // User Group Administration
    public static final String OPERATION_USER_GROUP_ADMIN = MAIN_SECURITY_MENU + DELIMITER + LABEL_USER_GROUP_ADMINISTRATION + MENU_DOTS;
    public static final String OPERATION_USER_GROUP_NEW = MAIN_SECURITY_MENU + DELIMITER + LABEL_USER_GROUP_ADMINISTRATION + DELIMITER + NEW;
    public static final String OPERATION_USER_GROUP_MODIFY = MAIN_SECURITY_MENU + DELIMITER + LABEL_USER_GROUP_ADMINISTRATION + DELIMITER + MODIFY;
    public static final String OPERATION_USER_GROUP_DELETE = MAIN_SECURITY_MENU + DELIMITER + LABEL_USER_GROUP_ADMINISTRATION + DELIMITER + DELETE;

    // Access Rights
    public static final String OPERATION_ACCESS_RIGHTS = MAIN_SECURITY_MENU + DELIMITER + LABEL_ACCESS_RIGHTS + MENU_DOTS;

    // Security Settings
    public static final String OPERATION_SECURITY_SETTINGS = MAIN_SECURITY_MENU + DELIMITER + MAIN_SYSTEM_PREFERENCES_MENU + DELIMITER + LABEL_SECURITY_SETTINGS + MENU_DOTS;
    public static final String OPERATION_SECURITY_SETTINGS_GENERAL = MAIN_SECURITY_MENU + DELIMITER + MAIN_SYSTEM_PREFERENCES_MENU + DELIMITER + LABEL_SECURITY_SETTINGS_GENERAL + MENU_DOTS;
    public static final String OPERATION_SECURITY_SETTINGS_SSO = MAIN_SECURITY_MENU + DELIMITER + MAIN_SYSTEM_PREFERENCES_MENU + DELIMITER + LABEL_SECURITY_SETTINGS_SSO + MENU_DOTS;
    public static final String OPERATION_SECURITY_SETTINGS_MESSAGE = MAIN_SECURITY_MENU + DELIMITER + MAIN_SYSTEM_PREFERENCES_MENU + DELIMITER + LABEL_SECURITY_SETTINGS_MESSAGE + MENU_DOTS;
    public static final String OPERATION_SECURITY_SETTINGS_LDAP_AUTH = MAIN_SECURITY_MENU + DELIMITER + MAIN_SYSTEM_PREFERENCES_MENU + DELIMITER + LABEL_SECURITY_SETTINGS_LDAP_AUTHENTICATION + MENU_DOTS;
    public static final String OPERATION_SECURITY_SETTINGS_PASSWORD_VALIDATION_RULES = MAIN_SECURITY_MENU + DELIMITER + MAIN_SYSTEM_PREFERENCES_MENU + DELIMITER + LABEL_SECURITY_SETTINGS_PASSWORD_VAIDATION_RULES + MENU_DOTS;
    public static final String OPERATION_SECURITY_SETTINGS_RADIUS_AUTHENTICATION = MAIN_SECURITY_MENU + DELIMITER + MAIN_SYSTEM_PREFERENCES_MENU + DELIMITER + LABEL_SECURITY_SETTINGS_RADIUS_AUTHENTICATION + MENU_DOTS;

    // Security Log
    public static final String OPERATION_SECURITY_SECURITY_LOG = MAIN_SECURITY_MENU + DELIMITER + LABEL_SECURITY_LOG + MENU_DOTS;

    // License Administration
    public static final String OPERATION_SECURITY_LICENSE_KEY_ADMINISTRATION = MAIN_SECURITY_MENU + DELIMITER + LABEL_LICENSE_KEY_ADMINISTRATION + MENU_DOTS;
    public static final String OPERATION_SECURITY_LICENSE_KEY_ADMINISTRATION_ADD = MAIN_SECURITY_MENU + DELIMITER + LABEL_LICENSE_KEY_ADMINISTRATION + DELIMITER + ADD;
    public static final String OPERATION_SECURITY_LICENSE_KEY_ADMINISTRATION_DELETE = MAIN_SECURITY_MENU + DELIMITER + LABEL_LICENSE_KEY_ADMINISTRATION + DELIMITER + DELETE;
    public static final String OPERATION_SECURITY_LICENSE_KEY_ADMINISTRATION_DETAILS = MAIN_SECURITY_MENU + DELIMITER + LABEL_LICENSE_KEY_ADMINISTRATION + DELIMITER + DETAILS;
    public static final String OPERATION_SECURITY_LICENSE_KEY_ADMINISTRATION_IMPORT = MAIN_SECURITY_MENU + DELIMITER + LABEL_LICENSE_KEY_ADMINISTRATION + DELIMITER + IMPORT;
    public static final String OPERATION_SECURITY_LICENSE_KEY_ADMINISTRATION_EXPORT = MAIN_SECURITY_MENU + DELIMITER + LABEL_LICENSE_KEY_ADMINISTRATION + DELIMITER + EXPORT;
    public static final String OPERATION_SECURITY_LICENSE_LOG = MAIN_SECURITY_MENU + DELIMITER + LABEL_LICENSE_LOG + MENU_DOTS;
    public static final String OPERATION_SECURITY_LICENSE_LOG_SETTINGS = MAIN_SECURITY_MENU + DELIMITER + LABEL_LICENSE_LOG_SETTINGS + MENU_DOTS;    
    public static final String OPERATION_SECURITY__EXPORT_SETTINGS = FILE_MENU + DELIMITER + LABEL_EXPORT_CONFIG + DELIMITER + SETTINGS;

    public static final String OPERATION_WEB_AUTHENTICATION = "Web->Authentication";

	public static final String[] ARR_MENU_IN_CF_USM = {
            OPERATION_DOMAIN_ADMIN, OPERATION_DOMAIN_ASSIGN_MAPPINGS, OPERATION_DOMAIN_ASSIGN_MAPPINGS_APPLY, OPERATION_POLICY_ADMIN, OPERATION_POLICY_NEW,
			OPERATION_POLICY_MODIFY, OPERATION_POLICY_DELETE, OPERATION_USERS_ADMIN, OPERATION_USER_NEW, OPERATION_USER_MODIFY, OPERATION_USER_DELETE, OPERATION_USER_FORCE_LOGOFF,
			OPERATION_USER_UNLOCK, OPERATION_USER_ACTIVATE, OPERATION_USER_DEACTIVATE, OPERATION_USER_GROUP_ADMIN, OPERATION_USER_GROUP_NEW, OPERATION_USER_GROUP_MODIFY, OPERATION_USER_GROUP_DELETE,
			OPERATION_ACCESS_RIGHTS, OPERATION_SECURITY_SETTINGS, OPERATION_SECURITY_SECURITY_LOG, OPERATION_SECURITY_LICENSE_KEY_ADMINISTRATION, OPERATION_SECURITY_LICENSE_KEY_ADMINISTRATION_ADD,
			OPERATION_SECURITY_LICENSE_KEY_ADMINISTRATION_DELETE, OPERATION_SECURITY_LICENSE_KEY_ADMINISTRATION_DETAILS, OPERATION_SECURITY_LICENSE_KEY_ADMINISTRATION_IMPORT,
			OPERATION_SECURITY_LICENSE_KEY_ADMINISTRATION_EXPORT, OPERATION_SECURITY_LICENSE_LOG, OPERATION_SECURITY_LICENSE_LOG_SETTINGS, OPERATION_DOMAIN_NEW, OPERATION_DOMAIN_MODIFY,
			OPERATION_DOMAIN_DELETE, OPERATION_SECURITY__EXPORT_SETTINGS, OPERATION_WEB_AUTHENTICATION };

    /**
     * To prevent construction
     */
    private USMMenuNameList() {
    }
}