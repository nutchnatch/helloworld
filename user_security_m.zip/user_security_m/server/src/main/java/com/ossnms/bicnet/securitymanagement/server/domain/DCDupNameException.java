/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCDupNameException
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CREATE
 *    
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.securitymanagement.common.domain.DCException;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;

/**
 * This exception is thrown to indicate that a domain with the given name already
 * exists and hence the given domain cannot be created
 */
class DCDupNameException extends DCException {

	/**
	 * 
	 */
	public DCDupNameException() {
		super(DCMessages.getInstance().getString(DCMessages.DC_DUPLICATE_NAME));
		// 
	}

	/**
	 * @param reason  User descriptive reason for the exception raised
	 */
	public DCDupNameException(String reason) {
		super(reason);
	}
}
