package com.ossnms.bicnet.securitymanagement.server.auth;

import com.ossnms.bicnet.bcb.facade.security.EnhancedSessionContextItem;
import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;
import com.ossnms.bicnet.securitymanagement.api.server.auth.SessionType;
import com.ossnms.bicnet.securitymanagement.common.auth.AASessionContext;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.server.auth.monitor.AAServerSessionMonitor;
import com.ossnms.bicnet.securitymanagement.server.logging.LMInterFace;
import com.ossnms.bicnet.securitymanagement.server.logging.LMLogRecordData;
import com.ossnms.bicnet.securitymanagement.server.logging.LMLogRecordEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

import static com.ossnms.bicnet.securitymanagement.api.server.auth.SessionType.CLIENT;
import static com.ossnms.bicnet.securitymanagement.api.server.auth.SessionType.WEB;

/**
 * This class maintains the cache of logged in user. Whenever a user get logged in, will be added in cache.
 * Whenever a user get logged off, will be removed from the cache.
 *
 */
public final class AASessionStore {

	private static final Logger LOGGER = LoggerFactory.getLogger(AASessionStore.class);

	/**
	* List of user sessions logged in from GUI Client
	*/
	private final List<ISessionContext> clientSessions = new CopyOnWriteArrayList<>();


	/**
	 * List of user sessions logged in from web clients
	 */
	private final List<ISessionContext> webSessions = new CopyOnWriteArrayList<>();
	
	
	/**
	* List of user sessions logged in from other clients (NBI) or of special users (hidden users and system account)
	*/
	private final List<ISessionContext> systemSessions = new CopyOnWriteArrayList<>();
	
	
	/**
	 * Contains AAServerSessionMonitor instances used to timeout hanged client sessions
	 */
	private final Map<ISessionContext, AAServerSessionMonitor> clientMonitorMap = new HashMap<>();

	/**
	 * Contains AAServerSessionMonitor used to monitor web client sessions
	 */
	private final Map<ISessionContext, AAServerSessionMonitor> webMonitorMap = new HashMap<>();

	/**
	* reference of this class
	*/
	private static final AASessionStore AA_SESSION_STORE = new AASessionStore();

	/**
	 *
	 */
	private AASessionStore() {
	}

	/**
	 *
	 * @return
     */
	public static AASessionStore getInstance() {
		LOGGER.debug("getInstance() 	Called");
		return AA_SESSION_STORE;
	}

	/**
	 *
	 * @param sessionContext the session context to add
	 * @param sessionType the type of session
	 */
	public void addUserSession(IEnhancedSessionContext sessionContext, SessionType sessionType) {
		LOGGER.debug("addUserSession({}, {}) Entry", sessionContext, sessionType);

		switch (sessionType) {
			case CLIENT:
				// add the session to the list of client sessions and start monitoring
				this.clientSessions.add(sessionContext);
				this.clientMonitorMap.put(sessionContext, new AAServerSessionMonitor());
				break;
			case SYSTEM:
				// add the session to the list of system sessions. No monitoring.
				this.systemSessions.add(sessionContext);
				break;
			case WEB:
				this.webSessions.add(sessionContext);
				this.webMonitorMap.put(sessionContext, new AAServerSessionMonitor());
				break;
		}

		LOGGER.info("A new session was created in the store. Session: {}", sessionContext);
		LOGGER.debug("addUserSession 	Exit");
	}

	/**
	 *
	 * @param userSession the instance of session context
     */
	public void removeUserSession(ISessionContext userSession) {
		LOGGER.debug("removeUserSession({}) Entry", userSession);

		try{
			if(this.clientSessions.remove(userSession)) {
				LOGGER.debug("removeUserSession(" + userSession + ") Entry");
				this.clientMonitorMap.remove(userSession);
				return;
			}

			if(this.systemSessions.remove(userSession)) {
				return;
			}

			if(this.webSessions.remove(userSession)){
				this.webMonitorMap.remove(userSession);
			}
		} finally {
			LOGGER.info("The user is logged off or in the process {}", userSession);
			LOGGER.debug("removeUser(ISessionContext sessionContext) 	Exit");
		}
	}

	/**
	 *
	 * @return
     */
	public List<ISessionContext> getAllUserSessions() {
		List<ISessionContext> allSessions = new ArrayList<>();

		allSessions.addAll(this.clientSessions);
		allSessions.addAll(this.systemSessions);
		allSessions.addAll(this.webSessions);

		return allSessions;
	}

	/**
	 *
	 * @return
     */
	public List<ISessionContext> getClientSessions() {
		List<ISessionContext> guiUserSessions = new ArrayList<>();
		guiUserSessions.addAll(this.clientSessions);
		return guiUserSessions;
	}

	/**
	 *
	 * @return
	 */
	public List<ISessionContext> getAllWebUserSessions() {
		List<ISessionContext> userSessions = new ArrayList<>();
		userSessions.addAll(this.webSessions);
		return userSessions;
	}

	/**
	 *
	 * @param session
	 * @return
     */
	public boolean isNonGuiUserSession (ISessionContext session) {
		return systemSessions.contains(session);
	}
	
	
	public boolean isSessionOfType(ISessionContext sessionContext, SessionType sessionType) {

		switch (sessionType) {
		case CLIENT:
			return this.clientSessions.contains(sessionContext);
		case SYSTEM:
			return this.systemSessions.contains(sessionContext);
		case WEB:
			return this.webSessions.contains(sessionContext);
		default:
			return false;
		}
	}

	/**
	 *
	 * @param userName
	 * @return
     */
	public synchronized boolean isUserLoggedOn(String userName) {
		LOGGER.debug("isUserLoggedOn({}) Entry", userName);

		boolean userIsLoggedOn = isUserInList(userName, getAllUserSessions());

		LOGGER.debug("isUserLoggedOn Exit. Returing : {}", userIsLoggedOn);
		return userIsLoggedOn;
	}

	/**
	 *
	 * @param userCtx
	 * @return
     */
	public synchronized boolean isUserSessionActive(ISessionContext userCtx) {
		LOGGER.debug("isUserSessionActive({}) Entry", userCtx);

		ISessionContext tempCtx = null;

		if(userCtx instanceof AASessionContext){
			tempCtx = userCtx;
		}else if (userCtx instanceof IEnhancedSessionContext){
			tempCtx = AASessionContext.fromSessionContext((IEnhancedSessionContext) userCtx);
		}

		boolean userSessionIsActive = getAllUserSessions().contains(tempCtx);
		LOGGER.debug("isUserSessionActive Exit. Returning : {}", userSessionIsActive);
		return userSessionIsActive;
	}

	/**
	 *
	 * @param userName
	 * @return
     */
	public synchronized List<ISessionContext> getLoggedInUserSessions(String userName) {
		LOGGER.debug("getLoggedInUserSessions({}) Entry", userName);
		
		List<ISessionContext> userSessions = getUserSessionsInList(userName, getAllUserSessions());

		LOGGER.debug("getLoggedInUserSessions Exit. Returning : {}", userSessions);
		return userSessions;
	}

	/**
	 *
	 * @param ctx
	 * @return
	 */
	public AAServerSessionMonitor getMonitoringBean(ISessionContext ctx) {
		AAServerSessionMonitor monitoringBean = getMonitoringBean(ctx, CLIENT);

		if(monitoringBean == null) {
			monitoringBean = getMonitoringBean(ctx, WEB);
		}

		return monitoringBean;
	}

	/**
	 *
	 * @param sessionContext
	 * @return
	 */
	public AAServerSessionMonitor getMonitoringBean(ISessionContext sessionContext, SessionType sessionType) {
		ISessionContext context;

		if (sessionContext instanceof EnhancedSessionContextItem) {
			context = AASessionContext.fromSessionContext((EnhancedSessionContextItem) sessionContext);
		} else {
			context = sessionContext;
		}

		switch (sessionType) {
			case CLIENT:
				return clientMonitorMap.get(context);
			case WEB:
				return webMonitorMap.get(context);
			default:
				return null;
		}
	}

	/**
	 * Helper function to cleanup the cache 
	 */
	void cleanup() {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("cleanup Entry. Cleaning up : {} client sessions, {} system sessions, {} web sessions.",
					clientSessions.size(),
					systemSessions.size(),
					webSessions.size()
			);
		}
	
		// Write records to Sec log.
		createCleanupSecurityLog(clientSessions);
		createCleanUpLogEntries(clientSessions);
//		createCleanupSecurityLog(systemSessions);
		createCleanUpLogEntries(systemSessions);
	
		clientSessions.clear();
		systemSessions.clear();
		webSessions.clear();
		clientMonitorMap.clear();
	
		LOGGER.debug("cleanup Exit.");
	}

	/**
	 *
	 * @param userName
	 * @param userSessionList
	 * @return
	 */
	private boolean isUserInList(String userName, List<ISessionContext> userSessionList) {
		if(userName == null) {
			return false;
		}

		return userSessionList.stream()
				.anyMatch(session -> userName.equalsIgnoreCase(session.getUserName()));
	}

	/**
	 *
	 * @param userName
	 * @param userSessionList
	 * @return
	 */
	private List<ISessionContext> getUserSessionsInList(String userName, List<ISessionContext> userSessionList) {
		return userSessionList.stream()
				.filter(session -> userName.equalsIgnoreCase(session.getUserName()))
				.collect(Collectors.toList());
	}

	/**
	 *
	 * @param userSessionList
	 */
	private void createCleanupSecurityLog(List<ISessionContext> userSessionList) {
		ISessionContext systemAccountCtx = AALocalSecurityProviderFacadeImpl.getInstance().getSystemAccountContext();
		
		for (ISessionContext sessionCtx : userSessionList) {
			IEnhancedSessionContext usrCtx = (IEnhancedSessionContext) sessionCtx;
			String displayStr = MessageFormat.format(USMCommonStrings.IDS_AA_CLEANUP_USERS_SERVER_SHUTDOWN, usrCtx.getUserName(), usrCtx.getClientMachineName());
			LMLogRecordData usmLogRecord = new LMLogRecordData(
					LMLogRecordEnum.SERVER_SHUTDOWN,
					usrCtx.getUserName(),
					LMLogRecordData._SUCCESS,
					null,
					LogSeverity.MESSAGE.guiLabel(),
					null,
					displayStr
			);
			LMInterFace.getInstance().createSecurityLogRecord(systemAccountCtx, usmLogRecord);
		}
	}

	/**
	 *
	 * @param userSessionList
     */
	private void createCleanUpLogEntries(List<ISessionContext> userSessionList) {
		for (ISessionContext sessionCtx : userSessionList) {
			IEnhancedSessionContext usrCtx = (IEnhancedSessionContext) sessionCtx;
			String displayStr = MessageFormat.format(USMCommonStrings.IDS_AA_CLEANUP_USERS_SERVER_SHUTDOWN, usrCtx.getUserName(), usrCtx.getClientMachineName());
			// log this as info
			LOGGER.info(displayStr);
		}
	}
}
