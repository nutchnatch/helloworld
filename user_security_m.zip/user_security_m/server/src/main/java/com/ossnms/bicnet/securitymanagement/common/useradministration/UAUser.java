/*
 * ------------------------History-------------------------
 *
 * <date>       <author>              <reason(s) of change>
 * 21-Jan-2005	Muyeen Munaver	      CF000995 - Password Expiration Interval
 * 09-Feb-2005  Babu B                CF001104    Administrator accounts lockout duration is not working
 * 05-Mar-2005  Muyeen Munaver        CF001812    Import a xml file (from DX V2) users are deactivated, activate them- problem
 * 22-Jun-2005  Muyeen Munaver        CF002307   BST, GMT and CST -> wrong hours
 * 08-Aug-2005	Balasubramanya	      CF002760 - 9320_MR_0291 Users, User Groups, Policies lose associations after import
 * 08-Aug-2005	Balasubramanya	      CF002759 - 9320_MR_0289 Security information discarded for user after deletion and restore
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.useradministration;

import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * A Transient Serializable class containing all data for a User Account.
 */
/**
 * @author ricpires
 *
 */
public class UAUser implements Serializable {

    private static final long serialVersionUID = 1L;

    // Attributes
	private Integer id=0;
    private String firstName;
    private String lastName;
    private String userId;
    private String password;
    private String hostName;
    private String commonName;
    private String email;
    private String telephoneNumber;
    private String faxNumber;
    private String employeeNumber;

	// authentication type default is LOCAL
	private UAAuthenticationType authenticationType = UAAuthenticationType.LOCAL;
    private boolean userMustChangePassword;
    private boolean userCanNotChangePasswd;
    private boolean passwordExpires;
    private List<String> assignedUserGroups;
    private String lastLogOnTime;
    private String activationTime;
    private String lastLogOfTime;
    private String lastLogonAttemptTime;
    private String adminLockoutDuration;
    private int badPasswordCount;
    private int deactivateUserAccOnInactivity;
    private int passwordChangeInterval;
    private boolean accountLocked;
    private boolean accountActivated;
    private boolean currentLoginStatus;
    private boolean predefinedAccount;
    private String lastPasswordChangeTime;
    private boolean passwordHasExpired;
    private String encryptedPassword;

	private boolean inactivityTimeoutEnabled;
	private int inactivityTimeout;
	
	private boolean restrictUserSessions = true; 	//default value is active
	private int simultaneousUserSessions = 1; 		//number of simultaneous user sessions is default 1

	private boolean accountExpires = false;
	private Date expirationDate = new Date();

    public UAUser() {
	}

    /**
     * This method is responsible for extracting an UAUser from USMMessage
     * @param msg
     *            USMMessage which encapsulates a UAUser
     */
    public void popMe(USMMessage msg) {

        employeeNumber = msg.popString();
		expirationDate = msg.popDate();
		accountExpires = msg.popBoolean();
		simultaneousUserSessions = msg.popInteger();
		restrictUserSessions = msg.popBoolean();
		inactivityTimeoutEnabled = msg.popBoolean();
		inactivityTimeout = msg.popInteger();
        predefinedAccount = msg.popBoolean();
        currentLoginStatus = msg.popBoolean();
        accountActivated = msg.popBoolean();
        accountLocked = msg.popBoolean();
        passwordChangeInterval = msg.popInteger();
        deactivateUserAccOnInactivity = msg.popInteger();
        badPasswordCount = msg.popInteger();
        adminLockoutDuration = msg.popString();
        lastLogOfTime = msg.popString();
        lastLogOnTime = msg.popString();
        activationTime = msg.popString();
        userMustChangePassword = msg.popBoolean();
        userCanNotChangePasswd = msg.popBoolean();
        passwordExpires = msg.popBoolean();
        faxNumber = msg.popString();
        telephoneNumber = msg.popString();
        email = msg.popString();
		authenticationType = UAAuthenticationType.valueOf(msg.popString());

        commonName = msg.popString();
        hostName = msg.popString();
        password = msg.popString();
        userId = msg.popString();
        lastName = msg.popString();
        firstName = msg.popString();
        id = msg.popInteger();
    }
    
	/**
	 * This Method is responsible for encapsulating an UAUser into USMMessage
	 * @param msg
	 *               USMMessage which encapsulates a UAUser 
	 */
    public void pushMe(USMMessage msg) {

		msg.pushInteger(id);
        msg.pushString(firstName);
        msg.pushString(lastName);
        msg.pushString(userId);
        msg.pushString(password, true);
        msg.pushString(hostName);
        msg.pushString(commonName);

		msg.pushString(authenticationType.name());
        msg.pushString(email);
        msg.pushString(telephoneNumber);
        msg.pushString(faxNumber);
        msg.pushBoolean(passwordExpires);
        msg.pushBoolean(userCanNotChangePasswd);
        msg.pushBoolean(userMustChangePassword);
        msg.pushString(activationTime);
        msg.pushString(lastLogOnTime);
        msg.pushString(lastLogOfTime);
        msg.pushString(adminLockoutDuration);
        msg.pushInteger(badPasswordCount);
        msg.pushInteger(deactivateUserAccOnInactivity);
        msg.pushInteger(passwordChangeInterval);
        msg.pushBoolean(accountLocked);
        msg.pushBoolean(accountActivated);
        msg.pushBoolean(currentLoginStatus);
        msg.pushBoolean(predefinedAccount);
		msg.pushInteger(inactivityTimeout);
		msg.pushBoolean(inactivityTimeoutEnabled);
		msg.pushBoolean(restrictUserSessions);
		msg.pushInteger(simultaneousUserSessions);
		msg.pushBoolean(accountExpires);
		msg.pushDate(expirationDate);
		msg.pushString(employeeNumber);
    }

	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}

	/**
     * Returns the employee number associated with the current user
     * @return
     *      employee number associated with the current user
     */
    public String getEmployeeNumber() {
        return employeeNumber;
    }

    /**
	 * Returns the user groups associated with the current user
	 * @return
	 *      user groups associated with the current user
	 */
	public List<String> getAssignedUserGroups() {
		return assignedUserGroups;
	}

	/**
	 * returns the common name of user
	 * @return
	 *      common name of the user
	 */
	public String getCommonName() {
		return commonName;
	}

	/**
	 * returns the email of the user
	 * @return 
	 *      email of the user
	 */
	public String getEmail() {
		return email;
	}
	
	/**
	 * returns the fax number of user
	 * @return
	 *      fax number of the user
	 */
	public String getFaxNumber() {
		return faxNumber;
	}

	/**
	 * returns the first name of the user
	 * @return
	 *      first name of the user
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Method to get the last name of the user
	 * @return
	 *      last name of the user
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Method to get the password of the user
	 * @return
	 *      password of the user
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * method to get the telephone number of the user
	 * @return
	 *      telephone number of the user
	 */
	public String getTelephoneNumber() {
		return telephoneNumber;
	}

	/**
	 * Method to get the userid of the user
	 * @return
	 *      userid of the user            
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Method to get the usermustchangepassword attribute of the user
	 * @return true if user has to change his password at his next logon otherwise false
	 */
	public boolean isUserMustChangePassword() {
		return userMustChangePassword;
	}

    /**
     * To set the assigned employee number for a user
     * @param employeeNumber
     *      employee number representing the user in a corporation.
     */
    public void setEmployeeNumber(String employeeNumber) {
        this.employeeNumber = employeeNumber;
    }

    /**
	 * To set the assigned user groups for a user
	 * @param assignedUserGroupsList
	 *      vector of user groups to which user belongs.
	 */
	public void setAssignedUserGroups(List<String> assignedUserGroupsList) {
		assignedUserGroups = assignedUserGroupsList;
	}

	/**
	 * To set the common name of the user
	 * @param string
	 *      common name of the user
	 */
	public void setCommonName(String string) {
		commonName = string;
	}

	/**
	 * Gets the User's authentication type
	 * @return instance of {@link UAAuthenticationType}
     */
	public UAAuthenticationType getAuthenticationType() {
		return authenticationType;
	}

	/**
	 * Sets the authentication type
	 * @param authenticationType instance of {@link UAAuthenticationType}
     */
	public void setAuthenticationType(UAAuthenticationType authenticationType) {
		this.authenticationType = authenticationType;
	}

	/**
	 * To set the email of the user
	 * @param email
	 *      email of the user
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * to set the fax number of the user
	 * @param faxNumber
	 *      fax number of the user
	 */
	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	/**
	 * This Method sets the first name of the user
	 * @param string
	 *      first name of the user
	 */
	public void setFirstName(String string) {
		firstName = string;
	}

	/**
	 * This method sets the last name of the user
	 * @param string
	 *      last name of the user
	 */
	public void setLastName(String string) {
		lastName = string;
	}

	/**
	 * Sets the password of the user
	 * @param string
	 *      password of the user
	 */
	public void setPassword(String string) {
		password = string;
	}

	/**
	 * This Method sets the telephone number of the user
	 * @param telephoneNumber
	 *      telephone number of the user
	 */
	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	/**
	 * sets the userid of the user
	 * @param string
	 *      userid of the user
	 */
	public void setUserId(String string) {
		userId = string;
	}

	/**
	 * This Method is required to set whether user has to change his password at his next logon
	 * @param userMustChangePassword
	 *      true if user must change password at next logon; false otherwise
	 */
	public void setUserMustChangePassword(boolean userMustChangePassword) {
		this.userMustChangePassword = userMustChangePassword;
	}

	/**
	 * Method to get the Administration lockout time
	 * @return
	 *      time after which account will be locked if not used for login
	 */
	public String getAdminLockoutDuration() {
		return adminLockoutDuration;
	}

	/**
	 * Method is responsible for getting the bad password count
	 * @return
	 *      Number of invalid login attempts since last successful logon
	 */
	public int getBadPasswordCount() {
		return badPasswordCount;
	}

	/**
	 * Method to get number of days after that inactivity of user causes his account dactivation
	 * @return the number of days after which the account is rendered inactive
	 */
	public int getDeactivateUserAccOnInactivity() {
		return deactivateUserAccOnInactivity;
	}

	/**
	 * To get the last log on time
	 * @return
	 *      Sring containing the last logon time
	 */
	public String getLastLogOfTime() {
		return lastLogOfTime;
	}

	/**
	 * Method to get the last log off time
	 * @return
	 *      Sring containing the last logoff time
	 */
	public String getLastLogOnTime() {
		return lastLogOnTime;
	}

	/**
	 * Method to get the Activation time
	 * @return
	 *      Sring containing the Activationtime
	 */
	public String getActivationTime() {
		return activationTime;
	}

	/**
	* Method to get the last logon attempt time
	* @return
	*      Sring containing the last logon attempt time
	*/
	public String getLastLogonAttemptTime() {
		return lastLogonAttemptTime;
	}

	/**
	 * Methos to get the number of days in which user has to change his password
	 * @return
	 */
	public int getPasswordChangeInterval() {
		return passwordChangeInterval;
	}

	/**
	 * Method to set  the admin lock out duration
	 * @param string
	 *      Sring containing the new lockout duration in days
	 */
	public void setAdminLockoutDuration(String string) {
		adminLockoutDuration = string;
	}

	/**
	 * Method to set the bad password count
	 * @param badPasswordCount
	 *      New value for the bad password count
	 */
	public void setBadPasswordCount(int badPasswordCount) {
		this.badPasswordCount = badPasswordCount;
	}

	/**
	 * Method to set the deactivation period
	 * @param i
	 */
	public void setDeactivateUserAccOnInactivity(int i) {
		deactivateUserAccOnInactivity = i;
	}

	/**
	 * Method to set the last logoff time of the user
	 * @param string
	 */
	public void setLastLogOfTime(String string) {
		lastLogOfTime = string;
	}

	/**
	 * Method to set the last log on time of the user
	 * @param string
	 */
	public void setLastLogOnTime(String string) {
		lastLogOnTime = string;
	}

	/**
	 * Method to set the activation time of the user
	 */
	public void setActivationTimeToCurrentTime() {
		activationTime = USMCommonHelper.getGMTStringForCurrentDate();
	}

	/**
	 * Method to set the activation time of the user
	 * @param activationTime
	 */
	public void setActivationTime(String activationTime) {
		this.activationTime = activationTime;
	}

	/**
	 * Method to set the last logon attempt time of the user
	 * @param string
	 */
	public void setLastLogonAttemptTime(String string) {
		lastLogonAttemptTime = string;
	}

	/**
	 * Method to set the change password time interval in which user can change his password
	 * @param passwordChangeInterval
	 */
	public void setPasswordChangeInterval(int passwordChangeInterval) {
		this.passwordChangeInterval = passwordChangeInterval;
	}

	/**
	 * Method to get the hostname from the account last logged in
	 */
	public String getHostName() {
		return hostName;
	}

	/**
	 * Method to set the hostname from the account last logged in
	 * @param hostName
	 */
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	/**
	 * Method to get the current login state of the user account
	 */
	public boolean getCurrentLoginStatus() {
		return currentLoginStatus;
	}

	/**
	 * Method to set the current login state of the user account
	 */
	public void setCurrentLoginStatus(boolean b) {
		currentLoginStatus = b;
	}

	/**
	 * Method to get the account Activation state
	 */
	public boolean isAccountActivated() {
		return accountActivated;
	}

	/**
	 * Method to get the account Lock state
	 */
	public boolean isAccountLocked() {
		return accountLocked;
	}

	/**
	 * Method to set the account Activation state
	 * @param accountActivated
	 */
	public void setAccountActivated(boolean accountActivated) {
		this.accountActivated = accountActivated;
	}

	/**
	 * Method to set the account Lock state
	 * @param accountLocked
	 */
	public void setAccountLocked(boolean accountLocked) {
		this.accountLocked = accountLocked;
	}

	/**
	 * Method to get the Predefined flag
	 */
	public boolean isPredefinedAccount() {
		return predefinedAccount;
	}

	/**
	 * Method to set the Predefined flag
	 * @param predefinedAccount
	 */
	public void setPredefinedAccount(boolean predefinedAccount) {
		this.predefinedAccount = predefinedAccount;
	}

    /**
     * @return
     */
    public boolean getUserCanNotChangePasswd() {
        return userCanNotChangePasswd;
    }

    /**
     * @param b
     */
    public void setUserCanNotChangePasswd(boolean b) {
        userCanNotChangePasswd = b;
    }
    
    /**
     * @return
     */
    public boolean getPasswordExpires() {
        return passwordExpires;
    }

    /**
     * @param expires
     */
    public void setPasswordExpires(boolean expires) {
        passwordExpires = expires;
    }
	
    /**
     * Function to retrieve the String equivalent of this object.
     * @return java.lang.String The String which is a representation of this object.
     */
	@Override
    public String toString() {
		return userId;
	}

	/**
	 * @param strLastPasswordChgTime
	 */
	public void setLastPasswordChangeTime(String strLastPasswordChgTime) {
		lastPasswordChangeTime = strLastPasswordChgTime;
	}

	public void setPasswordHasExpired(boolean passwordHasExpired) {
		this.passwordHasExpired = passwordHasExpired;
	}

	public String getLastPasswordChangeTime() {
		return lastPasswordChangeTime;
	}

	public boolean getPasswordHasExpired() {
		return passwordHasExpired;
	}

	public String getEncryptedPassword() {
		return encryptedPassword;
	}

	public void setEncryptedPassword(String encryptedPassword) {
		this.encryptedPassword = encryptedPassword;
	}

	public int getInactivityTimeout() {
		return inactivityTimeout;
	}

	public void setInactivityTimeout(int inactivityTimeout) {
		this.inactivityTimeout = inactivityTimeout;
	}

	public boolean isInactivityTimeoutEnabled() {
		return inactivityTimeoutEnabled;
	}

	public void setInactivityTimeoutEnabled(boolean inactivityTimeoutEnabled) {
		this.inactivityTimeoutEnabled = inactivityTimeoutEnabled;
	}

	/**
	 *
	 */
	public boolean isRestrictUserSessions() {
		return restrictUserSessions;
	}

	/**
	 * @param restrictUserSessions
	 */
	public void setRestrictUserSessions(boolean restrictUserSessions) {
		this.restrictUserSessions = restrictUserSessions;
	}

	/**
	 *
	 */
	public int getSimultaneousUserSessions() {
		return simultaneousUserSessions;
	}

	/**
	 * @param simultaneousUserSessions
	 */
	public void setSimultaneousUserSessions(int simultaneousUserSessions) {
		this.simultaneousUserSessions = simultaneousUserSessions;
	}

	/**
	 *
	 */
	public boolean isAccountExpires() {
		return accountExpires;
	}

	/**
	 * @param accountExpires
	 */
	public void setAccountExpires(boolean accountExpires) {
		this.accountExpires = accountExpires;
	}

	/**
	 *
	 */
	public Date getExpirationDate() {
		return (Date) expirationDate.clone();
	}

	/**
	 * @param expirationDate
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = (Date) expirationDate.clone();
	}
	
	
	/**
	 *
	 */
	public boolean isAccountExternal() {
		return !authenticationType.equals(UAAuthenticationType.LOCAL);
	}

	public boolean isAdminUser(){
		return getId()==1 ? true:false;
	}
}