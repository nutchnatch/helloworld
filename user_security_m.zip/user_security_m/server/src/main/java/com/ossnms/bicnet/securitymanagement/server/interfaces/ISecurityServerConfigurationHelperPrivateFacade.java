/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	ISecurityServerConfigurationHelperPrivateFacade
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	23rd July 2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.interfaces;

import com.ossnms.bicnet.bcb.facade.IFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;

/**
 * This is the Private Interface Facade for the Bicnet Server Administration.
 */
public interface ISecurityServerConfigurationHelperPrivateFacade
	extends IFacade {

	/**
	 * This method is responsible for checking with the Service Locator for any newly configured CFs
	 * 
	 * CF USM on a Timer Thread used to check with the Service Locator, for newly available CFs. But method
	 * calls on the ISecurityManageable for LogM created a problem, as LogM was expecting that the CF making a
	 * call was within a Transaction. Therefore to help this being done, from the timer thread, we make a call
	 * to our bean method. And then a transaction can be used.
	 * 
	 * @param p_ctx 
	 * @return
	 */
	void checkForNewlyAvailableCFsWithServiceLocator(ISessionContext p_ctx)
		throws BcbSecurityException;
}
