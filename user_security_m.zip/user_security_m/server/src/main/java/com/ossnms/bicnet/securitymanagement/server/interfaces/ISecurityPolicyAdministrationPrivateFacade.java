/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	ISecurityPolicyAdministrationPrivateFacade
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	23rd July 2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.interfaces;

import com.ossnms.bicnet.bcb.facade.IFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;

import java.util.List;

/**
 * This is the Private Interface Facade for the Policy Administration
 */

public interface ISecurityPolicyAdministrationPrivateFacade extends IFacade {

	/**
	 * Function to create Policy
	 * @param p_Policy - Policy object ot be created
	 * @return USMMessage - Message that contains the result of the operation
	 */
	USMMessage createPolicy(ISessionContext p_Ctx, PAPolicyData p_Policy) throws BcbSecurityException;

	/**
	 * Function to modify a policy
	 * @param p_Policy - Policy object which has to be modified
	 * @return USMMessage - Message that contains the result of the operation
	 */
	USMMessage modifyPolicy(ISessionContext p_Ctx, PAPolicyData p_Policy) throws BcbSecurityException;

	/**
	 * Function to retrieve all configured policies
	 * @return USMMessage - Message that contains all the configured policies
	 */
	USMMessage getPolicies(ISessionContext p_Ctx) throws BcbSecurityException;

	/**
	 * Function to delete policies
	 * @param policyIds - Abstract list of policies to be deleted
	 * @return USMMessage - Message that contains all the configured policies
	 */
	USMMessage deletePolicy(ISessionContext sessionContext, List<PAPolicyId> policyIds) throws BcbSecurityException;

	/**
	 * Function to delete policies
	 * @param policy - Policy to fetch information
	 * @return USMMessage - Message that contains all the configured policies
	 */
	USMMessage getPolicyInformation(ISessionContext sessionContext, PAPolicyId policy) throws BcbSecurityException;

	/**
	 * Retrieves the full list of permissions to the system
	 *
	 * @param sessionContext the session context
	 * @return the message that contains the response
	 */
	USMMessage getPermissions(ISessionContext sessionContext) throws BcbSecurityException;

	/**
	 * Retrieves the full list of permissions to the system
	 *
	 * @param sessionContext the session's context
	 * @param policyId an object that contains the name and id of the policy
	 * @return the message that contains the response
	 */
	USMMessage getPermissions(ISessionContext sessionContext, PAPolicyId policyId) throws BcbSecurityException;

	/**
	 * Retrieves the full list of permission items to this system
	 *
	 * @param sessionContext the session's context
	 * @return the message that contains the response
	 */
	USMMessage getPermissionItems(ISessionContext sessionContext) throws BcbSecurityException;

	/**
	 * Retrieves the full list of permission items to this system
	 *
	 * @param sessionContext the session's context
	 * @param policyId the id and name of the policy
	 * @return the message containing the response
	 */
	USMMessage getPermissionItems(ISessionContext sessionContext, PAPolicyId policyId) throws BcbSecurityException;

	/**
	 * Retrieves the list of permission items that belong to the underlying permission
	 *
	 * @param sessionContext the session's context
	 * @param permissionData the permission to get the permission items from
	 * @return the message containing the response
	 */
	USMMessage getPermissionItems(ISessionContext sessionContext, PAPermissionData permissionData) throws BcbSecurityException;
}
