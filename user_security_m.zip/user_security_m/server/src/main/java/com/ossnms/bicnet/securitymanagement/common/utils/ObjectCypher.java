package com.ossnms.bicnet.securitymanagement.common.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

/**
 *
 */
public class ObjectCypher {

    private static final Logger LOGGER = LoggerFactory.getLogger(ObjectCypher.class);

    // temporary constants for decipher
    private static final String ALGORITHM_AES = "AES";
    private static final String CIPHER_KEY = "hfowq0132hf1fub0";

    /**
     * Ciphers the specified object
     *
     * @param token the object to cipher
     * @return a byte array with the cyphered password
     */
    public static byte[] cypherToken(Object token){
        try {
            // Length is 16 bytes
            SecretKeySpec sks = new SecretKeySpec(CIPHER_KEY.getBytes(), ALGORITHM_AES);

            // Create cipher
            Cipher cipher = Cipher.getInstance(ALGORITHM_AES);
            cipher.init(Cipher.ENCRYPT_MODE, sks);

            //
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            CipherOutputStream cipherOutputStream = new CipherOutputStream(outputStream, cipher);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(cipherOutputStream);

            objectOutputStream.writeObject(token);
            objectOutputStream.close();

            return outputStream.toByteArray();
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IOException e) {
            LOGGER.error("Error when ciphering the object.", e);
            return null;
        }
    }

    /**
     * Deciphers the specified object sent by the client application
     *
     * @param token the ciphered object as a byte array
     * @return the deciphered object or null if an error occurs
     */
    public static Object decypherToken(byte[] token) {
        try {
            // Length is 16 bytes
            SecretKeySpec sks = new SecretKeySpec(CIPHER_KEY.getBytes(), ALGORITHM_AES);

            // Create cipher
            Cipher cipher = Cipher.getInstance(ALGORITHM_AES);
            cipher.init(Cipher.DECRYPT_MODE, sks);

            ByteArrayInputStream inStream = new ByteArrayInputStream(token);
            CipherInputStream cipherInputStream = new CipherInputStream(inStream, cipher);
            ObjectInputStream objectInputStream = new ObjectInputStream(cipherInputStream);

            return objectInputStream.readObject();
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IOException | ClassNotFoundException e) {
            LOGGER.error("Error when deciphering the object.", e);
            return null;
        }
    }
}
