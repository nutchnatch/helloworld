package com.ossnms.bicnet.securitymanagement.server.componentinterface;

import com.ossnms.bicnet.bcb.facade.security.*;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.security.*;
import com.ossnms.bicnet.securitymanagement.server.bicnetserver.SecurableObjectFacade;
import com.ossnms.bicnet.securitymanagement.server.domain.NMSecurityMappingFacade;
import com.ossnms.bicnet.securitymanagement.server.domain.SecurityDomainFacade;
import com.ossnms.bicnet.securitymanagement.server.useradministration.SecurityUserFacade;
import com.ossnms.bicnet.securitymanagement.server.useradministration.SecurityUserGroupAssignmentFacade;
import com.ossnms.bicnet.securitymanagement.server.useradministration.SecurityUserGroupFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Pojo implementation specially created for Node Manager
 */
public class USMNMSecurityProviderPOJOImpl implements INMSecurityFacade{

    private static final Logger logger = LoggerFactory.getLogger(USMNMSecurityProviderPOJOImpl.class);

    /**
     * Constructor.
     *
     * It has to be a zero parameter constructor.
     */
    public USMNMSecurityProviderPOJOImpl() {
        logger.debug("Entering constructor for USMNMSecurityFacadeImpl");

        // other operations

        logger.debug("Exiting constructor for USMNMSecurityFacadeImpl");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ISecurityDomain getSingleSecurityDomain(ISessionContext sessionContext, ISecurityDomainId securityDomainId) throws BcbException {
        return new SecurityDomainFacade().getSingle(securityDomainId);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SecurityDomainReply getSecurityDomainList(ISessionContext sessionContext, ISecurityDomainId startAfter, ISecurityDomainMarkable[] filter, int howMany) throws BcbException {
        return new SecurityDomainFacade().getList(startAfter, filter, howMany);
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public ISecurableObject getSingleSecurableObject(ISessionContext sessionContext, ISecurableObjectId securableObjectId) throws BcbException {
        return new SecurableObjectFacade().getSingle(securableObjectId);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SecurableObjectReply getSecurableObjectList(ISessionContext sessionContext, ISecurableObjectId startAfter, ISecurableObjectMarkable[] filter, int howMany) throws BcbException {
        return new SecurableObjectFacade().getList(startAfter, filter, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SecurableObjectReply getSecurableObjectList(ISessionContext sessionContext, ISecurableObjectId startAfter, ISecurableObjectMarkable[] filter, int howMany, ISecurityDomainId securityDomain) throws BcbException {
        return SecurableObjectFacade.getFilteredFacade(securityDomain).getList(startAfter, filter, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SecurableObjectIdReply getSecurableObjectIdList(ISessionContext sessionContext, ISecurableObjectId startAfter, ISecurableObjectMarkable[] filter, int howMany) throws BcbException {
        return new SecurableObjectFacade().getIdList(startAfter, filter, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ISecurityUserGroup getSingleSecurityUserGroup(ISessionContext sessionContext, ISecurityUserGroupId securityUserGroupId) throws BcbException {
        return new SecurityUserGroupFacade().getSingle(securityUserGroupId);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SecurityUserGroupReply getSecurityUserGroupList(ISessionContext sessionContext, ISecurityUserGroupId startAfter, ISecurityUserGroupMarkable[] filter, int howMany) throws BcbException {
        return new SecurityUserGroupFacade().getList(startAfter, filter, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SecurityUserGroupIdReply getSecurityUserGroupIdList(ISessionContext sessionContext, ISecurityUserGroupId startAfter, ISecurityUserGroupMarkable[] filter, int howMany) throws BcbException {
        return new SecurityUserGroupFacade().getIdList(startAfter, filter, howMany);
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public NMSecurityMappingsReply getNMSecurityMappingsList(ISessionContext sessionContext, INMSecurityMappingsId startAfter, INMSecurityMappingsMarkable[] filter, int howMany) throws BcbException {
        return new NMSecurityMappingFacade().getList(startAfter, filter, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NMSecurityMappingsReply getNMSecurityMappingsList(ISessionContext sessionContext, INMSecurityMappingsId startAfter, INMSecurityMappingsMarkable[] filter, int howMany, ISecurityUserGroupId securityUserGroup) throws BcbException {
        return NMSecurityMappingFacade.getFilteredFacade(securityUserGroup).getList(startAfter, filter, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NMSecurityMappingsReply getNMSecurityMappingsList(ISessionContext sessionContext, INMSecurityMappingsId startAfter, INMSecurityMappingsMarkable[] filter, int howMany, ISecurityUserId securityUser) throws BcbException {
        return NMSecurityMappingFacade.getFilteredFacade(securityUser).getList(startAfter, filter, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ISecurityUser getSingleSecurityUser(ISessionContext sessionContext, ISecurityUserId securityUserId) throws BcbException {
        return new SecurityUserFacade().getSingle(securityUserId);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SecurityUserReply getSecurityUserList(ISessionContext sessionContext, ISecurityUserId startAfter, ISecurityUserMarkable[] filter, int howMany) throws BcbException {
        return new SecurityUserFacade().getList(startAfter, filter, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SecurityUserIdReply getSecurityUserIdList(ISessionContext sessionContext, ISecurityUserId startAfter, ISecurityUserMarkable[] filter, int howMany) throws BcbException {
        return new SecurityUserFacade().getIdList(startAfter, filter, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public SecurityUserGroupAssignmentReply getSecurityUserGroupAssignmentList(ISessionContext sessionContext, ISecurityUserGroupAssignmentId startAfter, ISecurityUserGroupAssignmentMarkable[] filter, int howMany) throws BcbException {
        return new SecurityUserGroupAssignmentFacade().getList(startAfter, filter, howMany);
    }
}
