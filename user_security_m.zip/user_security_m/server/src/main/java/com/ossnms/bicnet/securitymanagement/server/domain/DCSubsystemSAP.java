/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Asif		CF000427 - Implementation of the XML import mechanism needed for the migration process
 * 09-Feb-2005  Babu B          CF000459   Choose for a User Group the Assigned Policy "NONE" - not the correct behavior!
 * 11-Mar-2005	Asif		CF000845 - System Event Log Entries
 * 12-Apr-2005  Babu B          CF001958    invariable objects should not be exported
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.api.common.USMConstants;
import com.ossnms.bicnet.securitymanagement.api.server.domain.IDomainWrapper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMenuNameList;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.domain.DCIEDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;
import com.ossnms.bicnet.securitymanagement.common.importexport.IEDataObject;
import com.ossnms.bicnet.securitymanagement.common.importexport.IEDomainData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import com.ossnms.bicnet.securitymanagement.common.policy.PAStatus;
import com.ossnms.bicnet.securitymanagement.common.utils.InternalUSMBeanLocator;
import com.ossnms.bicnet.securitymanagement.server.basic.USMAuthorizationHelper;
import com.ossnms.bicnet.securitymanagement.server.policy.PASubsystemSAP;
import org.apache.log4j.Logger;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * This is the single point of access for all DC related services to other
 * subsystems. Other subsystem can ask for domain or mapping info from this class
 */
public class DCSubsystemSAP {
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(DCSubsystemSAP.class);

    /**
     *
     */
    private static IDomainWrapper domainWrapper = InternalUSMBeanLocator.getEJB(IDomainWrapper.class);

    /**
     * Checks if the passed policy id is part of any domain mappings. This
     * check is needed before any policies can be deleted.
     * @param policyId The policy which is to be checked if it is mapped
     * @return Returns true if the policy takes part in a mapping
     */
    public static boolean isPolicyMapped(int policyId) {

        LOGGER.debug("isPolicyMapped() - Entry");

        if (LOGGER.isInfoEnabled()) {
            LOGGER.info(
                "Policy with id "
                    + policyId
                    + " is to be checked whether it is to be mapped");
        }

        boolean bFound = false;
        ArrayList<DCDomainMapping> mappings = new ArrayList<DCDomainMapping>();
        DCServerDataManager.getInstance().getAllConfiguredMappings(
            mappings);
        for (int nDx = 0; nDx < mappings.size(); ++nDx) {
            DCDomainMapping domMap = mappings.get(nDx);
            if (policyId == domMap.getPolicyID()) {
                //Policy id is mapped, so mr. PA, u shud not be deleting the policy
                bFound = true;
                if (LOGGER.isInfoEnabled()) {
                    LOGGER.info("Policy with id " + policyId + " is mapped");
                }
                break;
            }
        }

        LOGGER.debug("isPolicyMapped() - Exit");
        return bFound;

    }
    /**
    * Checks if the passed user group is part of any domain mappings. This
    * check is needed before any user group can be deleted.
    * @param userGroup
    *            The policy which is to be checked if it is mapped
    * @return boolean Returns true if the user group takes part in a mapping
    */
    public static boolean isUserGroupMapped(String userGroup) {
        LOGGER.debug("isUserGroupMapped() - Entry");

        if (LOGGER.isInfoEnabled()) {
            LOGGER.info(
                "User group "
                    + userGroup
                    + " is to be checked if it is mapped");
        }

        boolean bFound = false;
        List mappings = new ArrayList();
        DCServerDataManager.getInstance().getAllConfiguredMappings(
            mappings);
        int mappingCount = mappings.size();
        for (int nDx = 0; nDx < mappingCount; ++nDx) {
            DCDomainMapping domMap = (DCDomainMapping) mappings.get(nDx);
            if (0 == userGroup.compareTo(domMap.getUserGroup())) {
                //user group is mapped, so mr. UA/UG, u shud not be deleting the group
                bFound = true;
                if (LOGGER.isInfoEnabled()) {
                    LOGGER.info(
                        "User group with id " + userGroup + " is mapped");
                }
                break;
            }
        }
        LOGGER.debug("isUserGroupMapped() - Exit");
        return bFound;
    }

    /**
     * Checks whether the domain is existing or has been deleted
     * @param domainData The domain which has to be checked for validity
     * @return Returns true if the domain is existing
     */
    public static boolean isDomainExisting(DCDomainData domainData) {

        LOGGER.debug("isDomainExisting() - Entry");
        boolean bFound = false;
        DCDomainData domain =
            DCServerDataManager.getInstance().getDomainData(
                    domainData.getDomainID());
        if (null != domain) {
            bFound = true;
        } else {
            if (LOGGER.isInfoEnabled()) {
                LOGGER.info(
                    "Domain with name and id is not existing " + domainData);
            }
        }
        LOGGER.debug("isDomainExisting() - Exit");
        return bFound;

    }

    /**
     * Gets a list of all configured domains that have been created. Global
     * domain never gets passed in this.
     * 
     * @return List Returns a ArrayList of DCDomainData created
     */
    public static List<DCDomainData> getAllDomains() {
        LOGGER.debug("getAllDomains() - Entry");
        List<DCDomainData> domains = new ArrayList<>();
        DCServerDataManager.getInstance().getAllConfiguredDomains(domains);
        LOGGER.debug("getAllDomains() - Exit");
        return domains;
    }

    /**
     * Returns the Domain Data object identified by the name specified.
     * @param name the name of the domain (unique)
     * @return instance of DCDomainData if exists, null otherwise.
     */
    public static DCDomainData getDomain(String name){
        LOGGER.debug("getDomain() - Entry");
        DCDomainData domainData = DCServerDataManager.getInstance().getDomainData(name);
        LOGGER.debug("getDomain() - Exit");
        return domainData;
    }

    public static DCDomainData getDomain(int domainID) {
        LOGGER.debug("getDomain() - Entry");
        DCDomainData domainData = DCServerDataManager.getInstance().getDomainData(domainID);
        LOGGER.debug("getDomain() - Exit");
        return domainData;
    }

    /**
     * Function to return all the mappings that are created within DC
     * 
     * @return List
     * 			List of the mappings that are available.
     */
    public static List<DCDomainMapping> getAllDomainMappings() {
        LOGGER.debug("getAllDomainMappings() - Entry");

        List<DCDomainMapping> mappings = new ArrayList<>();

        DCServerDataManager.getInstance().getAllConfiguredMappings(mappings);
        LOGGER.debug("getAllDomainMappings() - Exit");
        return mappings;

    }
    /**
     * @param domains
     */
    public static void exportDomains(ISessionContext sessionContext,List domains) {

        LOGGER.debug("exportDomains() - Entry");

        String strMenuId = USMMenuNameList.OPERATION_DOMAIN_ADMIN;
        boolean bExportAllowed = true;

        try {
            USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure( sessionContext, strMenuId);
        } catch (BcbSecurityException e) {
            bExportAllowed = false;
            LOGGER.debug(e);
        }

        if (bExportAllowed) {
        	List listToExporteDomains = getAllDomains();

        	Map<DCDomainData, List<BSSecurableObject>> resultDomain = new HashMap<DCDomainData, List<BSSecurableObject>>();

        	for(int i=0 ; i<listToExporteDomains.size() ; i++){
        		DCDomainData objDomain = (DCDomainData) listToExporteDomains.get(i);
        		
        		if(!objDomain.isGlobalDomain()){
        			List<BSSecurableObject> listToExportSecurableObject = new ArrayList<BSSecurableObject>();
            		DCExternalInterface.getAssignedObjectsOfDomain(objDomain.getDomainID(), listToExportSecurableObject);

            		resultDomain.put(objDomain, listToExportSecurableObject);
        		}
        	}

        	if(resultDomain.size()>0){
        		IEDataObject ieObject = new IEDataObject(resultDomain, "");
        		domains.add(ieObject);
        	}

        	if (LOGGER.isInfoEnabled()) {
        		LOGGER.info("Count of the domains which were imported were "+ domains.size());
        	}
        	if (LOGGER.isDebugEnabled()) {
        		LOGGER.info("The domains which were imported were " + domains);
        	}
        } else {
        	String strErrorMessage = MessageFormat.format(USMCommonStrings.IDS_IE_EXPORT_FAIL_SECURITY,	new Object[] { USMCommonStrings.IDS_IE_DOMAINS });
        	IEDataObject ieObject = new IEDataObject(null, strErrorMessage);
        	domains.add(ieObject);
        }
            

        LOGGER.debug("exportDomains() - Entry");

    }

    /**
     * Returns the domain id given its name. This is needed for importing only
     * 
     * @param domain
     *            The domain which has to be checked if existing and id to be returned
     * @return boolean Returns true if the domain name already exists
     */
    public static int getDomainIDForMigration(String domain) {

        LOGGER.debug("getDomainIDForMigration() Enter");

        int domId = -1;
        DCDomainData domainData = null;
        List domains = DCSubsystemSAP.getAllDomains();
        Iterator iter = domains.iterator();
        while (iter.hasNext()) {
            domainData = (DCDomainData) (iter.next());
            if (0 == domain.compareToIgnoreCase(domainData.getDomainName())) {
                domId = domainData.getDomainID();
                break;
            }
        }

        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Domain with name " + domain + " its id = " + domId);
        }
        LOGGER.debug("getDomainIDForMigration() Exit");

        return domId;
    }

    /**
     * @param ctx
     * @param domains
     * @param overWrite
     */
    public static void importDomains(
        ISessionContext ctx,
        List<IEDataObject> domains,
        boolean overWrite) {

        LOGGER.debug("importDomains() ENTER_FUNCTION" + overWrite);

        String strMenuId = USMMenuNameList.OPERATION_DOMAIN_NEW;
        boolean bImportAllowed = true;

        try {
            USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(
                ctx,
                strMenuId);
        } catch (BcbSecurityException e) {
            bImportAllowed = false;
            LOGGER.debug(e);
        }

        if (bImportAllowed) {
            for (IEDataObject ieObject : domains) {
                IEDomainData data = (IEDomainData) ieObject.getDataObject();
                USMMessage msg = null;

                DCDomainData domain = data.getDomain();
                List<String> cfSecurObjects = data.getSecurableObjectNames();

                if (!overWrite) { // Add Mode
                	msg = new DCDomainConfigurationPOJOImpl().createDomainData( ctx, domain);
                } else { // Overwrite Mode
                	int nIdOfExistingDomain = getDomainIDForMigration(domain.getDomainName());
                	if (0 == nIdOfExistingDomain) {
                		// GLOBAL Domain; Ignore & continue with other domains
                		ieObject.setErrorString(DCMessages.getInstance().getString( DCMessages.DC_ERR_GLOBAL_DOMAIN_NOT_MODIFIED));
                		LOGGER.warn("Tring to import global domain, warning");
                		continue;
                	} else if (-1 != nIdOfExistingDomain) {
                		//Creation id is not needed, for modify
                		// Object already exists, do a modify
                		msg = new DCDomainConfigurationPOJOImpl().modifyDomainData( ctx, new DCDomainData(domain.getDomainName(),getDomainIDForMigration(domain.getDomainName()),0,domain.getDomainDescr()));
                	} else {
                		// Object does not already exist, do an add
                		if (0 != nIdOfExistingDomain) {
                			msg = new DCDomainConfigurationPOJOImpl().createDomainData(ctx, domain);
                		}
                	}
                }
                if (msg != null) {
                	Integer errorId = msg.popInteger();
                	if (!errorId.equals(DCMessages.DC_NO_ERROR)) {
                		String errorString = DCMessages.getInstance().getString(errorId);
                		ieObject.setErrorString(errorString);
                	}else {
                		setDomainOfSecurableObjects(ieObject, ctx, domain, cfSecurObjects);
                	}
                } 
            }
            LOGGER.info(domains.size() + "domain need to be imported");

        } else {
            if (domains.size() > 0) {
                String strErrorMessage = MessageFormat.format( USMCommonStrings.IDS_IE_IMPORT_FAIL_SECURITY, USMCommonStrings.IDS_IE_DOMAINS);

                IEDataObject ieObject = new IEDataObject(null, strErrorMessage);

                domains.clear();
                domains.add(ieObject);
            }
        }
        LOGGER.debug("importDomain() EXIT_FUNCTION");

    }
    
    public static void setDomainOfSecurableObjects(IEDataObject ieObject, ISessionContext ctx, DCDomainData domain,List<String> cfSecurObjects){
    	
    	List<String> notRegistedSecurObj = new ArrayList<String>();
    	
    	List<DCDomainData> existingDomains = getAllDomains();

    	for(DCDomainData domainData : existingDomains){
    		if(domainData.getDomainName().equals(domain.getDomainName())){
    			domain = domainData;
    		}
    	}
    		
    	List<BSSecurableObject> registerSecurableObjectList = DCExternalInterface.getAllSecurableObjects();
		List<BSSecurableObject> toRegisterSecurableObject = new ArrayList<BSSecurableObject>();
		
    	for(String securObjectName : cfSecurObjects){
    		
    		boolean securObjFound = false;
    		for(BSSecurableObject registerSecurableObject : registerSecurableObjectList){
    			if(registerSecurableObject.getDisplayName().equals(securObjectName)){
    				toRegisterSecurableObject.add(registerSecurableObject);
    				securObjFound = true;
    				break;
    			}
    		}
    		
    		if(!securObjFound){
    			notRegistedSecurObj.add(securObjectName);
    		}
    	} 
    	
		try {
			USMMessage msg = new DCDomainConfigurationPOJOImpl().assignUnassignObjectsToDomain(ctx, toRegisterSecurableObject, new ArrayList<BSSecurableObject>(), domain, false);
			if(msg !=null) {
				Integer errorId = msg.popInteger();
				if(errorId == null ){
					LOGGER.error("Cannot popInteger from msg");
				}else if (!errorId.equals(DCMessages.DC_NO_ERROR)) {
	                String errorString = DCMessages.getInstance().getString(errorId);
	                ieObject.setErrorString(errorString);
	                ieObject.setErrorString("Not possible to register " + notRegistedSecurObj.toString());
	       	 	}
				
				if(notRegistedSecurObj.size() > 0) {
					LOGGER.warn("Not possible to register " + notRegistedSecurObj.toString());
					ieObject.setErrorIndex(PAStatus.S_DOMAIN_IMPORT_INVALID_NE.getStatus());
					ieObject.setErrorString(notRegistedSecurObj.toString());
				}
				
			}else {
				LOGGER.error("Cannot popInteger from USMMessage object msg is null");
			}
		} catch (BcbSecurityException e) {
			 LOGGER.debug("importDomain() failed with: ", e);
		}
   
    }
    

    /**
     * @param mappings
     */
    public static void exportMappings(
        ISessionContext context,
        List<IEDataObject> mappings) {

        LOGGER.debug("exportMappings() Enter");

        String strMenuId = USMMenuNameList.OPERATION_DOMAIN_ASSIGN_MAPPINGS;
        boolean bExportAllowed = true;

        try {
            USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(
                context,
                strMenuId);
        } catch (BcbSecurityException e) {
            bExportAllowed = false;
            LOGGER.debug(e);
        }

        if (bExportAllowed) {
            DCServerDataManager domainCache = DCServerDataManager.getInstance();
            List<DCDomainMapping> listOfExportedMappings = getAllDomainMappings();

            //Extract global mapping for brevity
            DCDomainMapping globalMapping = DCDomainMapping.GLOBAL_MAPPING;

            for (DCDomainMapping exportedMapping : listOfExportedMappings) {

                boolean isGlobalUserGroup = (exportedMapping.getUserGroup().compareToIgnoreCase(globalMapping.getUserGroup()) == 0);
                boolean isGlobalDomain = (exportedMapping.getDomainID() == globalMapping.getDomainID());
                boolean isGlobalPolicy = (exportedMapping.getPolicyID() == globalMapping.getPolicyID());

                boolean bCurrMappingIsGlobal = isGlobalUserGroup && isGlobalDomain && isGlobalPolicy;

                if (!bCurrMappingIsGlobal) {
                    //Get Domain Data
                    String domainName = domainCache.getDomainData(exportedMapping.getDomainID()).getDomainName();

                    //Get UserGroup
                    String userGroup = exportedMapping.getUserGroup();

                    //Get Policy
                    String policyName;
                    if(exportedMapping.getPolicyID() == USMConstants.POLICY_NO_VISIBILITY.getPolicyID()){
                        policyName = USMConstants.POLICY_NO_VISIBILITY.getPolicyName();
                    }else{
                        policyName = PASubsystemSAP.getPolicyData(exportedMapping.getPolicyID()).getPolicyName();
                    }

                    DCIEDomainMapping iemapping = new DCIEDomainMapping(domainName, userGroup, policyName);

                    IEDataObject ieObject = new IEDataObject(iemapping, "");
                    mappings.add(ieObject);
                }
            }
        } else {
            String strErrorMessage = MessageFormat.format(
                    USMCommonStrings.IDS_IE_EXPORT_FAIL_SECURITY,
                    USMCommonStrings.IDS_IE_DOMAIN_MAPPING
            );

            IEDataObject ieObject = new IEDataObject(null, strErrorMessage);
            mappings.add(ieObject);
        }

        LOGGER.debug("exportMappings() Exit");
    }

    /**
     * @param ctx
     * @param mappings
     * @param overWrite
     */
    public static void importMappings(
        ISessionContext ctx,
        List mappings,
        boolean overWrite) {

        LOGGER.debug("importMappings() ENTER_FUNCTION");

        String strMenuId =
            USMMenuNameList.OPERATION_DOMAIN_ASSIGN_MAPPINGS_APPLY;
        boolean bImportAllowed = true;

        try {
            USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(
                ctx,
                strMenuId);
        } catch (BcbSecurityException e) {
            bImportAllowed = false;
            LOGGER.debug(e);
        }

        if (bImportAllowed) {

            //Get the list of policy ids, so that it can be easily mapped in the domain mapping window
            List policies = DCExternalInterface.getPolicies();
            Map<String, Integer> policyMap = new HashMap<>();
            Iterator iter = policies.iterator();
            while (iter.hasNext()) {
                PAPolicyId pol = (PAPolicyId) iter.next();
                policyMap.put(pol.getPolicyName().toLowerCase(), pol.getPolicyID());
            }

            //Get the list of domain ids, so that it can be easily mapped in the domain mapping window
            List domains = DCSubsystemSAP.getAllDomains();
            Map<String, Integer> domainMap = new HashMap<>();
            iter = domains.iterator();
            while (iter.hasNext()) {
                DCDomainData dom = (DCDomainData) iter.next();
                domainMap.put( dom.getDomainName().toLowerCase(), dom.getDomainID() );
            }

            int size = mappings.size();

            for (int index = 0; index < size; index++) {
                String errorStr = "";

                IEDataObject ieObject = (IEDataObject) mappings.get(index);
                DCIEDomainMapping data =
                    (DCIEDomainMapping) ieObject.getDataObject();

                //Check if the domain is existing
                Object domObj = domainMap.get(data.getDomainName().toLowerCase());
                if (null == domObj) {
                    ieObject.setErrorString(DCMessages.getInstance().getString(DCMessages.DC_DOMAIN_INVALID));
                    LOGGER.error("Trying to import mappings, where the domain is not existing " + data.getDomainName());
                    continue;
                }

                //Check if policy exists
                String policyName = data.getPolicyName().toLowerCase();
                Object polObj = policyMap.get(policyName);

                if (null == polObj) {
                    ieObject.setErrorString(DCMessages.getInstance().getString(DCMessages.DC_ERROR_POLICY_INVALID));
                    LOGGER.error("Trying to import mappings, where the policy is not existing " + data.getPolicyName());
                    continue;
                }

                DCDomainMapping mapping = new DCDomainMapping(
                        ((Integer) domObj).intValue(),
                        data.getUserGroup(),
                        ((Integer) polObj).intValue()
                );

                if (!overWrite) {
                    int mapIndex = getAllDomainMappings().indexOf(mapping);
                    if (-1 != mapIndex) {
                        //There can be two cases, one which is that an exact mapping already exists,
                        //i.e the policy is also the same, in which case, i write
                        //an error message, saying that the exact policy is already mapped to the user group
                        //and domain
                        if (((DCDomainMapping) getAllDomainMappings()
                            .get(mapIndex))
                            .getPolicyID()
                            == mapping.getPolicyID()) {
                            errorStr =
                                DCMessages.getInstance().getString(
                                    DCMessages.DC_ERROR_DUPLICATE_MAPPING);
                        }
                        //Mapping already exists, but not with the same policy
                        else {
                            errorStr =
                                DCMessages.getInstance().getString(
                                    DCMessages.DC_ERROR_MAPPING_EXISTS);
                        }
                        ieObject.setErrorString(errorStr);
                        LOGGER.error(
                            "Trying to import mappings in add mode, duplicate "
                                + data);
                        continue;
                    }
                }

                List<DCDomainMapping> lst = new ArrayList<>();
                lst.add(mapping);
                USMMessage msg = new DCDomainConfigurationPOJOImpl().changeMappingData(ctx, lst);

                Integer errorId = msg.popInteger();
                if (!errorId.equals(DCMessages.DC_NO_ERROR)) {
                    List<DCDomainMapping> errMapps = new ArrayList<>();
                    DCDomainMapping.popMappingsFromMessage(msg, errMapps);
                    errorStr =
                        DCMessages.getInstance().getString((errMapps.get(0)).getErrorId());
                    ieObject.setErrorString(errorStr);
                }
            }

            LOGGER.info(size + "mappings to be imported");

        } else {
            if (mappings.size() > 0) {
                String strErrorMessage =
                    MessageFormat.format(
                        USMCommonStrings.IDS_IE_IMPORT_FAIL_SECURITY,
                            USMCommonStrings.IDS_IE_DOMAIN_MAPPING);
                IEDataObject ieObject = new IEDataObject(null, strErrorMessage);

                mappings.clear();
                mappings.add(ieObject);
            }
        }
        LOGGER.debug("importDomain() EXIT_FUNCTION");

    }
    
    /**
     * Creates a new mapping, Policy versus Group, in the LDAP DS with the details given
     * 
     * @param mapping
     *            The mapping object which needs to be created in LDAP DS.
     * @return boolean Returns true on successful creation of the mapping
     *         object in LDAP DS.
     */
    public static boolean createMapping(DCDomainMapping mapping){
        LOGGER.debug("createDomain() Entry");
        
        boolean isMappingCreated = domainWrapper.createMapping(mapping);
        
        LOGGER.debug("createDomain() Exit");
        
        return isMappingCreated;
    }
    
    /**
     * This method is used to validate if a certain DC domain mapping
     * (domainMapping) already exists within LDAP.
     * 
     * @return True if exists, otherwise false.
     */
    public static boolean isDCDomainMappingExist(DCDomainMapping mapping) {
        LOGGER.debug("isDCDomainMappingExist() Entry");
        
        boolean isDCDomainMappingExist = domainWrapper.isDCDomainMappingExist(mapping);
        
        LOGGER.debug("isDCDomainMappingExist() Exit");
        
        return isDCDomainMappingExist;
    }
    
    /**
     * This method is used to validate if a policy, identified by its ID, is
     * already mapped on domain mappings.
     * 
     * @param policyId
     *            Policy ID
     * @return True if it is already associated to any user group, otherwise
     *         false
     */
    public static boolean isPolicyMappedInDomain(int policyId){
        LOGGER.debug("isPolicyMappedInDomain() Entry");
        
        boolean isPolicyMapped = domainWrapper.isPolicyMapped(policyId);
        
        LOGGER.debug("isPolicyMappedInDomain() Exit");
        
        return isPolicyMapped;
    }
    
    /**
     * This method is used to validate if a group, identified by its name, is
     * already mapped on domain mappings.
     * 
     * @param userGroupName
     *            User group name to validate its existence
     * 
     * @return True if it is already associated to any user group, otherwise
     *         false
     */
    public static boolean isUserGroupMappedInDomain(String userGroupName){
        LOGGER.debug("isUserGroupMappedInDomain() Entry");
        
        boolean isUserGroupMapped = domainWrapper.isUserGroupMapped(userGroupName);
        
        LOGGER.debug("isUserGroupMappedInDomain() Exit");
        
        return isUserGroupMapped;
    }
    
    
    /**
	 * Function to get the domain mapping for a user group, including mappings concerning not assigned policies (no mapping)
	 * 
	 * @param userGroup The user group for which the mappings are requested
	 */
    public static List<DCDomainMapping> getMappingsForUserGroup(String userGroup) {
    	if (LOGGER.isDebugEnabled()) {
    		LOGGER.debug("getMappingsForUserGroup() Entry");
    	}
    
    	DCDomainMappingController ctrl = new DCDomainMappingController();
    	List<DCDomainMapping> mappings = ctrl.getMappingsForUserGroup(userGroup);
    	
    	if (LOGGER.isDebugEnabled()) {
    		LOGGER.debug("getMappingsForUserGroup() Exit");
    	}
    	
    	return mappings;
    }
    
    //TODO : Refactor duplicated code
	public static USMMessage changeMappingData(ISessionContext ctx, List mappings) {
		LOGGER.debug("changeMappingData - Enter");
		DCDomainMappingController ctl = new DCDomainMappingController();
		USMMessage msg = ctl.changeMappings(ctx, mappings);
		LOGGER.debug("changeMappingData - Exit");
		return msg;
	}
    
    // TODO: UA is getting the policies this way, but should get it directly from PA SAP
    public static List<PAPolicyId> getPolicies() {
    	return DCExternalInterface.getPolicies();
    }


}
