/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AALocalSecurityProviderFacadeImpl
 * Author      	Jogender Singh
 * Substitute	Babu B
 * Created on	08-10-2004
 *
 * --------------------------------------------------------
  * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.AUTHENTHICATE.USER
 *        TNMS.DX2.SM.LOGIN.USERID
 *		  TNMS.DX2.SM.LOGOUT.USER 
 *        TNMS.DX2.SM.SERVER.AUTHORIZATION
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 22-Mar-2005	Muyeen Munaver	CF0001791 - Problems with Login
 * 10-May-2005	Muyeen Munaver	CF002170 - Resolve the Host name into the IP address fails
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.auth;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ILocalSecurityProviderFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.securitymanagement.api.server.auth.SessionType;
import com.ossnms.bicnet.securitymanagement.common.auth.AASessionContext;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.server.useradministration.UASubsystemSAP;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 This class provides the functionality for creating and returning System context 
 to be used by in EJB server by Scheduler and NBI interfaces
 */
public final class AALocalSecurityProviderFacadeImpl
	implements ILocalSecurityProviderFacade {

	/**
	 * Data member to hold logger for the class
	 */
	private static final Logger LOGGER = Logger.getLogger(AALocalSecurityProviderFacadeImpl.class);

	/**
	 * Data member to to hold static user name for the system context
	 */
	private static final String s_systemUser = "System Account";

	/**
	 * 
	 */
	private volatile IEnhancedSessionContext sessionContext;

	/**
	* Holds singleton instance
	*/
	private static final AALocalSecurityProviderFacadeImpl m_instance = new AALocalSecurityProviderFacadeImpl();

	/**
	* prevents instantiation
	*/
	private AALocalSecurityProviderFacadeImpl() {
		// prevent creation
	}

	/**
	 * Returns the singleton instance.
	 * @return	the singleton instance
	 */
	public static AALocalSecurityProviderFacadeImpl getInstance() {
		return m_instance;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.server.auth.ILocalSecurityProviderFacade#getSystemAccountContext()
	 */
	@Override
    public ISessionContext getSystemAccountContext() {
		LOGGER.debug("getSystemAccountContext() Enter");

		ISessionContext localSessionContext = sessionContext;
		if (localSessionContext == null) {
			localSessionContext = createSessionContext();
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("getSystemAccountContext() Exit : Return (User Name):" + localSessionContext.getUserName());
		}
		return localSessionContext;
	}

	private synchronized ISessionContext createSessionContext() {
		IEnhancedSessionContext sessionContext = this.sessionContext;
		if (sessionContext == null) {
			// There is no need to get all the Groups.
			// Only the Admin Group should suffice
			List<String> lstUserGroupName = new ArrayList<>();
			lstUserGroupName.add(UASubsystemSAP.getAdministratorGroupName());

			String hostName = USMCommonHelper.getLocalHostName();
			String ipAddress = USMCommonHelper.getLocalHostAddress();

			sessionContext = new AASessionContext(s_systemUser, "", hostName, hostName, ipAddress, lstUserGroupName, true);
			AASessionStore objUserList = AASessionStore.getInstance();

			//If user logged in then user id is added in the cache.
			// else if user has logged off then user id is removed from the cache.
			objUserList.addUserSession(sessionContext, SessionType.SYSTEM);
			
			// publishes the reference with volatile write (must be the last statement)
            sessionContext = ((AASessionContext) sessionContext).toSessionContext();
            this.sessionContext = sessionContext;
        }
		return sessionContext;
	}
}
