package com.ossnms.bicnet.securitymanagement.persistence.dao;


import com.ossnms.bicnet.securitymanagement.api.persistence.dao.IBaseDAO;
import com.ossnms.bicnet.securitymanagement.persistence.model.BaseUSMEntity;
import org.apache.log4j.Logger;

import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import java.lang.reflect.ParameterizedType;
import java.util.List;

/**
 * created on 28/8/2014
 *
 * This class provides the DAOs inside the USM module with a common approach
 * for implementing data access methods
 *
 * @param <T> The entity extending BaseUSMEntity
 * @param <ID> The identifier type of the entity
 */
public abstract class AbstractBaseDao<T extends BaseUSMEntity, ID> implements IBaseDAO<T, ID> {

    private static final Logger logger = Logger.getLogger(AbstractBaseDao.class);

    private final Class<T> type;

    private static final String FORMAT_SELECT_ALL = "Select t from %s t";
    private static final String FORMAT_COUNT_ALL = "Select count(t) from %s t";

    @PersistenceContext(unitName = PERSISTENCE_UNIT_NAME)
    private EntityManager em;

    /**
     * Persists the item passed as parameter.
     *
     * @param item instance of the entity
     * @return the saved item
     */
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public T save(T item){
        try{
            if(item.isNew()){
                em.persist(item);
            }else{
                em.merge(item);
            }
        }catch(PersistenceException e){
            logger.error(e.getMessage());
            return null;
        }

        return item;

    }

    /**
     * Constructor for the abstract class <code>AbstractBaseDao</code>
     *
     * Uses reflection to retrieve the type of the entity passed as type
     */
    public AbstractBaseDao(){
        ParameterizedType pt = (ParameterizedType) getClass().getGenericSuperclass();
        type = (Class<T>) pt.getActualTypeArguments()[0];
    }

    /**
     * Removes the record from the database.
     *
     * @param item the instance of the entity to remove
     */
    @Override
    public void delete(T item) {
        em.remove(em.contains(item) ? item : em.merge(item));
    }

    /**
     * Deletes the instance which has the identifier as passed per parameter.
     *
     * @param id the identifier of the record to remove
     */
    @Override
    public void delete(ID id) {
        em.remove(em.getReference(type, id));
    }

    /**
     * Retrieves the list of all the records from this type
     *
     * @return a list with the instances for the configured entity, or null if empty.
     */
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public List<T> findAll() {
        return em.createQuery(
                String.format(FORMAT_SELECT_ALL, type.getSimpleName())
        ).getResultList();
    }

    /**
     * Retrieves the list of all the records from this type
     *
     * @return a list with the instances for the configured entity, or null if empty.
     */
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public List<T> findAllByQuery(Query query) {
        return query.getResultList();
    }

    /**
     * Retrieves the list of all the records if contained in the specified interval.
     *
     * @param firstResult the index of the first result
     * @param maxResults the maximum number of results
     * @return a list with the instances for the configured entity, or null if empty.
     */
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public List<T> findInRange(int firstResult, int maxResults) {
        return em.createQuery(
                String.format(FORMAT_SELECT_ALL, type.getSimpleName())
        ).setFirstResult(firstResult).setMaxResults(maxResults).getResultList();
    }

    /**
     * Retrieves the instance of the entity with the specified identifier.
     * @param id the identifier
     * @return the instance of the selected entity
     */
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public T findById(ID id) {
        return em.find(type, id);
    }

    /**
     * Retrieves the number of records in the database of the configured type.
     *
     * @return long with the number of records.
     */
    @Override
    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public long count() {
        return (Long) em.createQuery(
                String.format(FORMAT_COUNT_ALL, type.getSimpleName())
        ).getSingleResult();
    }

    /**
     * Detaches the entity from the session context.
     *
     * @param item the item to detach.
     */
    @Override
    public void detach(T item) {
        em.detach(item);
    }

    /**
     * Synchronizes the persistence context.
     */
    @Override
    public void flush() {
        em.flush();
    }

    /**
     *
     * @param query the query to retrieve the single result from
     * @return returns an instance of the type T, or null if nothing was found
     */
    protected T getSingleResult(Query query){
        try{
            return (T) query.getSingleResult();
        }catch(NoResultException e){
            return null;
        }
    }

    /**
     *
     * @return the configured entity manager
     */
    protected EntityManager getEntityManager(){
        return em;
    }
}
