package com.ossnms.bicnet.securitymanagement.api.persistence.dao.policy;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.IBaseDAO;
import com.ossnms.bicnet.securitymanagement.persistence.model.policy.USMPolicy;

/**
 * created on 24/9/2014
 */
public interface IUSMPolicyDao extends IBaseDAO<USMPolicy, Integer> {
    USMPolicy findByName(String name);
    void loadPermissions(USMPolicy policy);
}
