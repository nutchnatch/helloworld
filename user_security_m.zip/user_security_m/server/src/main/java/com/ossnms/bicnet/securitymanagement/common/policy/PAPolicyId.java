/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 05-May-2005  Babu B          CF001312   Master-Master Replication for Sun ONE DS
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.policy;

import com.ossnms.bicnet.securitymanagement.api.common.USMSerializable;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import org.apache.log4j.Logger;

/**
 * This data structure contains the Policy ID and Name of a configured policy.
 * This data structure will be sent along with the POLICY CREATED POLICY
 * DELETED Notifications. This class has been added so that we can reduce the
 * amount of info flow between the server and the client
 */
public class PAPolicyId implements USMSerializable {
	public static final long serialVersionUID = 11111111111L;
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(PAPolicyId.class);

	/**
	 * Internally Assignee Unique ID
	 */
	private int policyID;

	/**
	 * User Defined Name
	 */
	private String policyName;

	/**
	 * Overloaded Constructor
	 * 
	 * @param id
	 *            The Identifier for the Policy
	 * @param name
	 *            The Name as assigned by the operator
	 */
	public PAPolicyId(int id, String name) {
		LOGGER.debug("In The constructor()");
		policyID = id;
		policyName = name;
	}

	/**
	 * Default Constructor
	 */
	public PAPolicyId() {
		LOGGER.debug("In The constructor()");
		policyID = -1;
		policyName = "";
	}

	/**
	 * Function to push this object into the message. Will be used for
	 * transferring this object between the server and the client.
	 * 
	 * @param msg
	 *            The Message into which we have to push this object.
	 */
	public void pushMe(USMMessage msg) {
		msg.pushInteger(policyID);
		msg.pushString(policyName);
	}

	/**
	 * Function to pop this object from the message. Will be used while
	 * transferring this object between the server and the client.
	 * 
	 * @param msg
	 *            The Message from which we have to pop this object.
	 */
	public void popMe(USMMessage msg) {
		policyName = msg.popString();
		policyID = msg.popInteger();
	}

	/**
	 * Function to retrieve the Policy ID of this object
	 * 
	 * @return int The Identifier of the Policy Object
	 */
	public int getPolicyID() {
		return policyID;
	}
	/**
		 * Function to set the Policy ID of this object
		 * 
				 */
	public void setPolicyID(int pid) {
		policyID = pid;
	}

	/**
	 * Function to retrieve the Name of the Policy
	 * 
	 * @return java.lang.String The String which represents the Name of the
	 *         Policy
	 */
	public String getPolicyName() {
		return policyName;
	}

	/**
	 * Function to set the Name of the Policy
	 *
	 * @param policyName - Policy Name
	 */

	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	/**
	 * Function to retrieve the String equivalent of this object.
	 * 
	 * @return java.lang.String The String which is a representation of this
	 *         object.
	 */
	@Override
    public String toString() {
		return policyName;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object o) {
		if (this == o) { return true; }
		if (o == null || getClass() != o.getClass()) { return false; }

		PAPolicyId that = (PAPolicyId) o;

		return policyName.equals(that.policyName);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		return policyName.hashCode();
	}
}
