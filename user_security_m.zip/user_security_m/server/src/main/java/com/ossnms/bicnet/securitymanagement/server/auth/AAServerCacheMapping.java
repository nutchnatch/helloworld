/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AAServerCacheMapping
 * Author      	Babu B
 * Substitute	Jogender Singh
 * Created on	04-08-2004
 *
 * --------------------------------------------------------
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.SERVER.AUTHORIZATION
 * 		  TNMS.DX2.SM.CLIENT.AUTHORIZE
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.auth;

import org.apache.log4j.Logger;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Maintains a list of DomainId Policy Id pairs for a given user group 
 * Used as part of AAServerCache
 */
class AAServerCacheMapping {

	/**
	 * Data member to hold logger for the class
	 */
	private static final Logger LOGGER = Logger.getLogger(AAServerCacheMapping.class);

	/** 
	 * Data member to hold domain id and policy mapping
	 */
	private Map<Integer, Integer> mapDomainId2PolicyId;

	/**
	 * Default Constructor
	 */
	public AAServerCacheMapping() {
		super();
		mapDomainId2PolicyId = Collections.synchronizedMap(new HashMap<Integer, Integer>());
	}

	/**
	 * Updates the domain and policy map
	 * @param nDomainId - Domain id
	 * @param nPolicyId - Policy ID
	 */
	public void updateMap(int nDomainId, int nPolicyId) {
		mapDomainId2PolicyId.put(nDomainId,	nPolicyId);
	}

	/**
	 * Returns the policy id for passed domain id. It retrieves from the Domain and policy mapping
	 * @return int - policy id mapped to given domain id
	 */
	public int getPolicyId(int nDomainId) {
		LOGGER.debug("getPolicyId(" + nDomainId + ")		Enter");
		int nPolicyId = -1;
		Integer objPolicyId = mapDomainId2PolicyId.get(nDomainId);

		if (null != objPolicyId) {
			nPolicyId = objPolicyId;
		}
		LOGGER.debug("getPolicyId("	+ nDomainId	+ ")		Exit : Return :" + nPolicyId);
		return nPolicyId;
	}

	/**
	 *Returns the domain IDs and policy IDs mapping data structure
	 *@return Map - Domain IDs and Policy IDs mapping data 
	 */
	public Map<Integer, Integer> getMapDomainId2PolicyId() {
		return mapDomainId2PolicyId;
	}

}
