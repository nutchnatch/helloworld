/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AAAccountLockedException
 * Author      	Asifulla khan
 * Substitute	Babu B
 * Created on	10-12-2004
 *
 * --------------------------------------------------------
 * Project: TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.auth.exception;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;

/**
 * Exception for the case when the account is locked and the user is doing
 * authorization.
 */
public class AAKerberosAuthenticationException extends BcbSecurityException {
    private static final long serialVersionUID = 1L;
    
    public AAKerberosAuthenticationException(boolean rollbackRequested, String message){
        super(rollbackRequested, message);
    }
    
    public AAKerberosAuthenticationException(boolean rollbackRequested, String message, Throwable cause) {
        super(rollbackRequested, message, cause);
    }
}
