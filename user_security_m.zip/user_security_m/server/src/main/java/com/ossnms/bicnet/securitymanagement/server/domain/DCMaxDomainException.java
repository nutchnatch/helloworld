/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCMaxDomainException
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CREATE   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.securitymanagement.common.domain.DCException;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;

/**
 * This exception is thrown to indicate that the maximum number of domains have
 * already been created and it is not able to create a new domain
 */
class DCMaxDomainException extends DCException {

    private static final long serialVersionUID = 1L;

    /**
	 * Constructor 
	 */
	public DCMaxDomainException() {

		super(DCMessages.getInstance().getString(DCMessages.DC_MAX_DOMAIN));
	}

	/**
	 * Constructs an exception with the string giving the reason
	 * @param reason  The user descriptive string associated with the Exception
	 */
	public DCMaxDomainException(String reason) {
		super(reason);
	}

}
