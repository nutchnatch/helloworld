/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AADummySecurityProviderFacadeImpl
 * Author      	Muyeen Munaver
 * Substitute	
 * Created on	24-11-2004
 *
 * --------------------------------------------------------
  * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.SERVER.AUTHORIZATION
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Asif			CF000550 - Implement the new metod "getClientSessionId"
 * 19-Jan-2005	Muyeen Munaver	CF001094 - Not possible do drag and drop NE's to the "Physical Root - View" window
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 * 22-Mar-2005	Muyeen Munaver	CF0001791 - Problems with Login
 * 05-May-2005  Muyeen Munaver  CF001312   Master-Master Replication for Sun ONE DS
 * 14-June-2005 Muyeen Munaver  CF002457 - Manual Export not working
 * 11-Jan-2006  Balasubramanya  CF002773 - Missing correct computer name in window User Administration
 * 31-Jan-2007  Shrinidhi G V   CF004362-  9320_MR_0775: Any user can bring down the application.
 * 10-Aug-2007	Shrinidhi G V			TD000504-03 - Extend USM public facade with method to get ldap credentials
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.auth;

import com.ossnms.bicnet.bcb.facade.security.*;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkableId;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.bcb.model.security.ISecurableObject;
import com.ossnms.bicnet.bcb.model.security.ISecurableObjectContainer;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import org.apache.log4j.Logger;

import javax.ejb.Handle;
import javax.security.auth.kerberos.KerberosTicket;
import java.util.Properties;

/**
 * It is the implementation of ISecurityProviderFacade interface for accessing 
 * services provided by security management on the application server
 *
*/
public final class AADummySecurityProviderFacadeImpl
	implements ISecurityProviderFacade {
	/**
	 * Data member for tracing
	 */
	private static final Logger LOGGER =
		Logger.getLogger(AADummySecurityProviderFacadeImpl.class);

	/**
	* Holds singleton instance
	*/
	private static AADummySecurityProviderFacadeImpl instance;

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#getServerSession(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
	@Override
    public ISecureServerSession getServerSession(ISessionContext sessionContext)
		throws BcbSecurityException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"getServerSession(" + sessionContext + ")		Enter");
		}

		if (sessionContext == null) {
			LOGGER.error(
				"Passing a null. This is wrong. Will not work in case of Security Being Enabled.");
		}

		ISecureServerSession serverSession =
			new DummyAASecureServerSessionImpl(sessionContext);

		LOGGER.debug("getServerSession Exit");

		return serverSession;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#changePassword(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
    public void changePassword(
		String userId,
		String currentPassword,
		String newPassword)
		throws BcbSecurityException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"changePassword(" + userId + ",****,***** )		Enter");
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"changePassword(" + userId + ",****,***** )		Exit");
		}
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#logon(java.lang.String, java.lang.String)
	 */
	@Override
    public ISessionContext logon(String userId, String password, String computerName)
		throws BcbSecurityException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("logon(" + userId + ",******)		Enter");
		}

		if ((userId == null) || (userId.length() == 0)) {
			LOGGER.error("User ID is null or empty. " + userId);
			userId = "Server Context";
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("logon(" + userId + ",******)		Exit : Return :");
		}
		return USMCommonHelper.getDummySessionContext(userId);
	}

	
	@Override
	public ISessionContext nbiLogon(String userId, String password,
			String computerName) throws BcbSecurityException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("nbiLogon(" + userId + ",******)		Called");
		}
		return logon(userId, password, computerName);
	}
	
	
	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#isLoggedOn(java.lang.String)
	 */
	@Override
    public boolean isLoggedOn(String userId) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering isLoggedOn. ID is : " + userId);
			LOGGER.debug(
				"Exiting isLoggedOn. ID is : "
					+ userId
					+ ". Is returning true always");
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#logoff(com.ossnms.bicnet.bcb.facade.security.ISecureServerSession)
	 */
	@Override
    public void logoff(ISessionContext serverSession)
		throws BcbSecurityException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("logoff(" + serverSession + ")		Enter");
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("logoff(" + serverSession + ")		Exit");
		}
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#addLogonListener(com.ossnms.bicnet.bcb.facade.security.ILogonListener)
	 */
	@Override
    public void addLogonListener(ILogonListener listener) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering addLogonListener. Listener is : " + listener);
			LOGGER.debug("Exiting addLogonListener. Listener is : " + listener);
		}

	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#removeLogonListener(com.ossnms.bicnet.bcb.facade.security.ILogonListener)
	 */
	@Override
    public void removeLogonListener(ILogonListener listener) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering removeLogonListener. Listener is : " + listener);
			LOGGER.debug(
				"Exiting removeLogonListener. Listener is : " + listener);
		}
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#registerObject(com.ossnms.bicnet.bcb.model.security.ISecurableObject)
	 */
	@Override
    public void registerObject(BiCNetComponentType componentType, ISecurableObject securableObject) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering registerObject. Object is : " + securableObject);
			LOGGER.debug(
				"Exiting registerObject. Object is : " + securableObject);
		}
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#unregisterObject(com.ossnms.bicnet.bcb.model.security.ISecurableObject)
	 */
	@Override
    public boolean unregisterObject(BiCNetComponentType componentType, ISecurableObject securableObject) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering unregisterObject. Object is : " + securableObject);
			LOGGER.debug(
				"Exiting unregisterObject. Object is : " + securableObject);
		}
		return false;
	}
	/**
	* prevents instantiation
	*/
	private AADummySecurityProviderFacadeImpl() {
		// prevent creation
	}

	/**
	 * Returns the singleton instance.
	 * @return	the singleton instance
	 */
	public static synchronized AADummySecurityProviderFacadeImpl getInstance() {
		if (instance == null) {
			instance = new AADummySecurityProviderFacadeImpl();
		}
		return instance;
	}

	@Override
    public void updateObject(BiCNetComponentType componentType, ISecurableObject securableObject) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering updateObject. Object is : " + securableObject);
			LOGGER.debug(
				"Exiting updateObject. Object is : " + securableObject);
		}
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#logoff(com.ossnms.bicnet.bcb.facade.security.ISecureServerSession)
	 */
	@Override
    public void logoff(ISecureServerSession serverSession)
		throws BcbSecurityException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering logoff. Object is : " + serverSession);
			LOGGER.debug("Exiting logoff. Object is : " + serverSession);
		}
	}

	/**
	 * Dummy class added to help Joachim to do the testing. 
	 */
	protected class DummyAASecureServerSessionImpl implements ISecureServerSession {

		/**
		 * Data member to hold the context for which it was created.
		 */
		private IEnhancedSessionContext ctx;

		/**
		 * @param sessionContext
		 * @throws BcbSecurityException
		 */
		public DummyAASecureServerSessionImpl(ISessionContext sessionContext)
			throws BcbSecurityException {
			LOGGER.info(
				"Entering constructor of DummyAASecureServerSessionImpl");

			if ((sessionContext != null)
				&& (sessionContext instanceof IEnhancedSessionContext)) {
				ctx = (IEnhancedSessionContext) sessionContext;
			} else {
				LOGGER.error(
					"Context being passed is null. Or not of corrct type. Assuming default.");
				ctx = USMCommonHelper.getDummySessionContext("Server Context");
			}

		}

		/*
		 * (non-Javadoc)
		 * @see com.ossnms.bicnet.bcb.facade.security.ISecureServerSession#checkObjectPermission(com.ossnms.bicnet.bcb.model.IManagedObjectId[])
		 */
		@Override
        public IManagedObjectId[] checkObjectPermission(IManagedObjectId[] p_arDesiredObjects) {
			String strObjects =
				USMCommonHelper.getStringForArrayOfIManagedObjectId(
					p_arDesiredObjects);
			LOGGER.info(
				"DummySessionHandler : checkObjectPermission . : "
					+ strObjects);

			return p_arDesiredObjects;
		}

		/*
		 * (non-Javadoc)
		 * @see com.ossnms.bicnet.bcb.facade.security.ISecureServerSession#checkOperationPermission(java.lang.String)
		 */
		@Override
        public boolean checkOperationPermission(
			java.lang.String p_strOperation) {
			LOGGER.info(
				"DummySessionHandler : checkOperationPermission . strOperation : "
					+ p_strOperation);
			return true;
		}

		/*
		 * (non-Javadoc)
		 * @see com.ossnms.bicnet.bcb.facade.security.ISecureServerSession#checkOperationPermission(java.lang.String, com.ossnms.bicnet.bcb.model.IManagedObjectId[])
		 */
		@Override
        public IManagedObjectId[] checkOperationPermission(
			java.lang.String p_strOperation,
			IManagedObjectId[] p_arDesiredObjects) {
			String strObjects =
				USMCommonHelper.getStringForArrayOfIManagedObjectId(
					p_arDesiredObjects);
			LOGGER.info(
				"DummySessionHandler : checkOperationPermission . strOperation : "
					+ p_strOperation
					+ " Objects : "
					+ strObjects);
			return p_arDesiredObjects;
		}

		@Override
		public IManagedObjectId[] filterVisibleObjects(IManagedObjectMarkableId... criteria) {
			return new IManagedObjectId[0];
		}

		@Override
		public IManagedObjectId[] filterAccessibleObjects(IManagedObjectMarkableId... criteria) {
			return new IManagedObjectId[0];
		}

		@Override
		public IManagedObjectId[] filterAccessibleObjects(String operation, IManagedObjectMarkableId... criteria) {
			return new IManagedObjectId[0];
		}

		/* (non-Javadoc)
		 * @see com.ossnms.bicnet.bcb.facade.security.ISecureServerSession#getSessionContext()
		 */
		@Override
        public ISessionContext getSessionContext() {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("Entering getSessionContext. ");
				LOGGER.debug("Exiting getSessionContext. Object is : " + ctx);
			}
			return ctx;
		}

		/* (non-Javadoc)
		 * @see com.ossnms.bicnet.bcb.facade.security.ISecureServerSession#getClientId()
		 */
		@Override
        public String getClientId() {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("Entering getClientId. ");
				LOGGER.debug(
					"Exiting getClientId. Object is : "
						+ ctx.getClientMachineName());
			}
			return ctx.getClientMachineName();
		}

		/* (non-Javadoc)
		 * @see com.ossnms.bicnet.bcb.facade.security.ISecureServerSession#getUserName()
		 */
		@Override
        public String getUserName() {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("Entering getUserName. ");
				LOGGER.debug(
					"Exiting getUserName. Object is : " + ctx.getUserName());
			}
			return ctx.getUserName();
		}

		/* (non-Javadoc)
		 * @see com.ossnms.bicnet.bcb.facade.security.ISecureServerSession#getClientSessionId()
		 */
		@Override
        public String getClientSessionId() {
			// TODO Auto-generated method stub
		    return "" + ctx.getUniqId();
		}
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#getLdapCredentials()
	 */
	@Override
    public Properties getLdapCredentials() throws BcbSecurityException {
		return null;
	}

	@Override
	public ISessionContext logon(KerberosTicket kTicket, byte[] userName, byte[] host, byte[] clientIpAddress, byte[] encoded, Handle userSessionBean) throws BcbSecurityException {
		throw new UnsupportedOperationException("This method is unsupported due to migration to ejb3");
	}

    @Override
    public void updateObjectContainer(BiCNetComponentType componentType, ISecurableObjectContainer securableContainer) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                "Entering updateContainer. Object is : " + securableContainer);
            LOGGER.debug(
                "Exiting updateContainer. Object is : " + securableContainer);
        }
    }

	@Override
	public ISessionContext authenticate(String userId, String password, String computerName)
			throws BcbSecurityException {
		return logon(userId, password, computerName);
	}
	
	@Override
	public byte[] getUserPasswordSalt(String userName)
			throws BcbSecurityException {
		 return null;
	 }
}
