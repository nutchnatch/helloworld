/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	ISecurityServerConfigurationPrivateFacade
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	23rd July 2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 09-02-2005	Muyeen Munaver  CF000060-01   CF USM GUI Requirements
 * 05-May-2005  Babu B  CF001312   Master-Master Replication for Sun ONE DS
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.interfaces;

import com.ossnms.bicnet.bcb.facade.IFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;

import java.util.List;

/**
 * This is the Private Interface Facade for the CF Configuration
 */

public interface ISecurityServerConfigurationPrivateFacade extends IFacade {
	/**
	 * This method gets the list of CF configured with USM.
	 *  
	 * @param p_ctx 
	 * 		The Context which is associated with the client invoking this interface.
	 *  
	 * @return USMMessage 
	 * 		Message which contains all the CF's that are currently registered and a
	 * part of CF USM.
	 * 
	 * @throws BcbSecurityException
	 * 		Exception that will be raised if the calling client does not have the 
	 * permission to do this operation.
	 */
	USMMessage getConfiguredCFs(ISessionContext p_ctx)
		throws BcbSecurityException;

	/**
	 * This method is used when the user clicks on a component and wants to view a 
	 * list of objects that are managed by that component
	 * 
	 * @param p_ctx 
	 * 		The Context which is associated with the client invoking this interface.
	 * 
	 * @param p_CF
	 * 		The CF for which we are trying to get the managed elements.
	 * 
	 * @return USMMessage
	 * 		Message which will contain the result of retrieval of the Securable Objects
	 * 
	 * @throws BcbSecurityException
	 * 		Exception that will be raised if the calling client does not have the 
	 * permission to do this operation.
	 */
	USMMessage getManagedSecurableElmsForCF(
		ISessionContext p_ctx,
		BSTransBicNetCFInfo p_CF)
		throws BcbSecurityException;

	/**
	 * This method is used by the client when the user wants to forcefully remove a 
	 * server or component which is not working from the security management
	 * 
	 * @param p_ctx
	 * 		The Context which is associated with the client invoking this interface.
	 *  
	 * @param pLstCFs
	 * 		The List of CFs that are to be removed from CF USM
	 * 
	 * @return USMMessage
	 * 		Message which contains information about whether it was possible
	 * to remove the Cfs from USM.
	 * 		
	 * @throws BcbSecurityException
	 * 		Exception that will be raised if the calling client does not have the 
	 * permission to do this operation.
	 */
	USMMessage removeCFsFromUSM(ISessionContext p_ctx, List<BSTransBicNetCFInfo> pLstCFs)
		throws BcbSecurityException;

	/**
	 * This method gets called when the user selects a component and wants to update 
	 * the list of securable objects from the component.
	 * 
	 * @param p_ctx
	 * 		The Context which is associated with the client invoking this interface.
	 * 
	 * @param p_LstCfs
	 * 		List which contains the CFs which are to be synchronized with the Securable Object
	 * information
	 * 
	 * @return USMMessage
	 * 		Message which contains information about the the status of the synchronization of 
	 * the Cf.
	 * 
	 * @throws BcbSecurityException
	 * 		Exception that will be raised if the calling client does not have the 
	 * permission to do this operation.
	 */
	USMMessage synchSecObjsWithCFs(ISessionContext p_ctx, List p_LstCfs)
		throws BcbSecurityException;

    /**
    * This function is invoked update ACL information for Securable Objects
    * @param pLstSecurableObj  This contains all the Securable Objects that should be (un)assigned to the
    * domains
    * @param pLstDomains  The domains to which the Sec Objects should be (un)assigned .
    * @param pLstFailedSecurableObjs  The Sec Object(s) which could not be (un)assigned
    * @param p_Assign Indicates whether the function is called for Assignment or UnAssignment. True indicates Assignment.
    * @return BSReturnType  Indicates whether it was possible to complete the operation
    */
    USMMessage updateACLForSecurableObjects(
        List pLstSecurableObj,
        List pLstDomains,
        List pLstFailedSecurableObjs,
        boolean p_Assign);
}
