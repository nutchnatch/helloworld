/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	ISecurityAuthenticationPrivateFacade
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	23rd July 2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 10-May-2005	Muyeen Munaver	CF002170 - Resolve the Host name into the IP address fails
 *09-10-2007   Shrinidhi G V   CF004512-07  Improvement for server side filtering
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.interfaces;

import com.ossnms.bicnet.bcb.facade.IFacade;
import com.ossnms.bicnet.bcb.facade.annotation.AcceptServerState;
import com.ossnms.bicnet.bcb.facade.annotation.BypassAuthentication;
import com.ossnms.bicnet.bcb.facade.annotation.ServerState;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.api.common.OperationResult;
import com.ossnms.bicnet.securitymanagement.common.auth.AAChangePasswordDetails;
import com.ossnms.bicnet.securitymanagement.common.auth.AAClientCacheData;
import com.ossnms.bicnet.securitymanagement.common.basic.SecurableObjectACL;
import com.ossnms.bicnet.securitymanagement.common.basic.SessionEvent;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;

import java.util.Properties;
import java.util.Set;



/**
 * This is the Private Interface Facade for the Authentication
 */
public interface ISecurityAuthenticationPrivateFacade extends IFacade {

	/**
	 * Validates user credentials and return session token.
	 * @return ISessionContext
	 */
	@BypassAuthentication
	@AcceptServerState({ ServerState.running, ServerState.shutDown })
	ISessionContext logon(String userName, byte[] cypheredPassword, String host, String strClientIpAddress)
			throws BcbSecurityException;

	/**
	 * Validates user credentials through a Kerberos ticket and return session
	 * token.
	 * 
	 * @param token the ticket, encoded.
	 * @param userName User name associated with the kerberos ticket.
	 * @param host Host name from which the logon process was initialized.
	 * @param clientIpAddress Ip address of client.
	 * @return ISessionContext Session object related to a successful authentication.
	 */
	@BypassAuthentication
	@AcceptServerState({ ServerState.running, ServerState.shutDown })
	ISessionContext logon(byte[] token, String userName, String host, String clientIpAddress)
			throws BcbSecurityException;

	/**
	 * Logs off user for given session token.
	 * 
	 * @param sessionToLogoffContext Session token created at the time of login for the user.
	 */
	void logoff(ISessionContext sessionToLogoffContext) throws BcbSecurityException;

	
	/**
	 * Force the logoff of a user's session
	 * 
	 * @param sessionToLogoffContext Session token created at the time of login for the user.
	 * @param event The event affecting the session. 
	 */
	void forceLogoff(ISessionContext sessionToLogoffContext, SessionEvent event);
	
	/**
	 * Retrieves advisory message wrapped in UMSMEssage.
	 * 
	 * @param p_sessionContext
	 *            - Session token for the client
	 * @return USMMessage - Response to client wrapped in UMSMessage
	 */
	USMMessage getAdvisoryDetails(ISessionContext p_sessionContext) throws BcbSecurityException;

	/**
	 * Changes password for given user information.
	 * 
	 * @param p_sessionContext
	 *            - Session token for the client
	 * @param p_userDetails
	 *            - User credentials details.
	 * @return USMMessage - Response to client wrapped in UMSMessage
	 */
	USMMessage changePassword(ISessionContext p_sessionContext, AAChangePasswordDetails p_userDetails) throws BcbSecurityException;

	/**
	 * Returns client side security data cache.
	 * 
	 * @param p_sessionContext
	 *            - Session token created at the time of login for the user.
	 * @return USMClientCacheData - Represents security data cache
	 */
	AAClientCacheData getClientSecurityData(ISessionContext p_sessionContext) throws BcbSecurityException;

	/**
	 * returns the flag to password must change or not by the user.
	 * 
	 * @param p_sessionContext
	 *            - Session token created at the time of login for the user.
	 * @return USMMessage - Operation status with flag for change password
	 * 
	 **/
	USMMessage isPasswordMustChanged(ISessionContext p_sessionContext) throws BcbSecurityException;

	/**
	 * returns the password salt for the specified the user.
	 * 
	 * @param userName
	 *            - The user name.
	 * @return byte[] - A byte array containing the salt data
	 * @throws BcbSecurityException 
	 * 
	 **/
	@BypassAuthentication
	byte[] getUserPasswordSalt(String userName) throws BcbSecurityException;
	
	/**
	 * returns the flag to password must change or not by the user.
	 * 
	 * @param sessionContext - Session token created at the time of login for the user.
	 * @return Set - a set of securable object identifiers mapped with the respective ACL, as a bit set
	 * 
	 **/
	Set<SecurableObjectACL> getSecurableObjects(ISessionContext sessionContext) throws BcbSecurityException;

	/**
	 * returns the user profile data for user.
	 * 
	 * @param p_sessionContext
	 *            - Session token created at the time of login for the user.
	 * @return USMMessage - User profile data for CFs
	 * 
	 **/
	USMMessage getProfile(ISessionContext p_sessionContext) throws BcbSecurityException;

	/**
	 * Sets the client profile data for the user.
	 * 
	 * @param p_sessionContext
	 *            - Sesstion token created at the time of login for the user. * @param
	 *            p_AppUID - CF unique identifier. * @param p_profile - CF
	 *            profile data.
	 * @return USMMessage - Operation status with flag for change password
	 * 
	 **/
	@BypassAuthentication
	USMMessage setProfile(ISessionContext p_sessionContext, String p_AppUID, Properties p_profile) throws BcbSecurityException;

	/**
	 * Removes the client profile data for the user.
	 * 
	 * @param p_sessionContext
	 *            - Sesstion token created at the time of login for the user. * @param
	 *            p_AppUID - CF unique identifier.
	 * @return USMMessage - Operation status with flag for change password
	 * 
	 **/
	USMMessage removeUserProfile(ISessionContext p_sessionContext, String p_AppUID) throws BcbSecurityException;

	/**
	 * Retrieve server version and product type
	 * 
	 * @param p_sessionContext
	 *            - Sesstion token created at the time of login for the user.
	 * @return USMMessage - Operation status with flag for change password
	 * 
	 **/
	USMMessage getServerVersionAndProductType(ISessionContext p_sessionContext) throws BcbSecurityException;

	/**
	 * Ping the server so that the session remains active
	 * @param sessionContext Session token created at the time of login for the user
	 */
	OperationResult setActive(ISessionContext sessionContext);

	/**
	 *
	 * @param sessionContext
	 * @return
	 * @throws BcbSecurityException
	 */
	USMMessage getInactivityTimeout(ISessionContext sessionContext) throws BcbSecurityException;

    /**
     *
     * @return
     * @throws BcbSecurityException
     */
    USMMessage getInactivityTimeoutWarningTime(ISessionContext sessionContext) throws BcbSecurityException;
}
