package com.ossnms.bicnet.securitymanagement.server.ldap.mapper;

import com.ossnms.bicnet.securitymanagement.server.ldap.dto.LDAPGroup;
import org.springframework.ldap.core.AttributesMapper;

import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.InvalidAttributeIdentifierException;
import java.text.MessageFormat;

/**
 *
 */
public class UserGroupAttributesMapper implements AttributesMapper<LDAPGroup> {

    private String groupIdAttribute;

    public UserGroupAttributesMapper(String groupIdAttribute){
        this.groupIdAttribute = groupIdAttribute;
    }

    /**
     *
     * @param attributes
     * @return
     * @throws javax.naming.NamingException
     */
    public LDAPGroup mapFromAttributes(Attributes attributes) throws javax.naming.NamingException {
        LDAPGroup ldapGroup = new LDAPGroup();

        Attribute groupIdAttr = attributes.get(groupIdAttribute);

        if(groupIdAttr == null) {
            throw new InvalidAttributeIdentifierException(
                    MessageFormat.format("Group ID Attribute {0} does not exist.", groupIdAttribute)
            );
        }

        ldapGroup.setGroupID(groupIdAttr.get().toString());

        return ldapGroup;
    }
}