/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Author:      Jogender
 * Substitute	Babu B
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.auth;

import com.ossnms.bicnet.bcb.model.security.InvalidCredentialsException;
import com.ossnms.bicnet.securitymanagement.api.server.profile.IProfileWrapper;
import com.ossnms.bicnet.securitymanagement.api.server.users.IAAWrapper;
import com.ossnms.bicnet.securitymanagement.common.utils.InternalUSMBeanLocator;
import org.apache.log4j.Logger;

/**
 * @author vpurohit Interface to other subsystems in USM for user profile operations
 */
public class AASubsystemSAP {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(AASubsystemSAP.class);

    /**
     * Instance of the profileWrapper we will use
     */
    private IProfileWrapper profileWrapper = InternalUSMBeanLocator.getEJB(IProfileWrapper.class);

    /**
     * Instance of IAAWrapper
     */
    private IAAWrapper authenticationWrapper = InternalUSMBeanLocator.getEJB(IAAWrapper.class);

    /**
     * deletes user profile container for the specified user
     * 
     * @param strUserName
     *            User name to delete user profile container
     * @return boolean - Status of the operation. If container is deleted successfully then true else false.
     */
    public boolean deleteUserProfileContainer(String strUserName) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("deleteUserProfileContainer(" + strUserName + ") - entry");
        }
        return profileWrapper.deleteUserProfileContainer(strUserName);
    }

    /**
     *
     * @param username
     * @return
     * @throws InvalidCredentialsException
     */
    public byte[] getUserPasswordSalt(String username) throws InvalidCredentialsException {
        return authenticationWrapper.getUserPasswordSalt(username);
    }
}