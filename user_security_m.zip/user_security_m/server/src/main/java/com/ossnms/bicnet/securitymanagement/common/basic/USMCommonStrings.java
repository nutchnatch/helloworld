/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 18-Jan-2005	Asif		CF000834 - Command Log Entries	CF USM
 * 11-Feb-2005	Asif		CF000845 - System Event Log Entries
 * 18-Apr-2005  Asif khan R     CF001755 Error Messages when LDAP not available
 * 30-Apr-2005  Babu B          CF001864 Security alarm gets created after one attempt more than the number specified
 * 12-Mar-2005  Muyeen Munaver  CF001932	Host Name is not shown for user logged in from 'Sys Admin' client
 * 14-Apr-2005	Muyeen Munaver	CF001025	Stop the Server - message to the clients
 * 26-Apr-2005	Asif		CF000834 - Command Log Entries	CF USM
 * 05-May-2005  Muyeen M        CF001312   Master-Master Replication for Sun ONE DS
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 * 11-Jan-2006  Balasubramanya  CF002773 - Missing correct computer name in window User Administration
 * 05-Sep-2006  Shrinidhi G V   CF004305 - Client not responding => java message in Sys log
 * 26-Aug-2005  Babu B          CF002773 - Missing correct computer name in window User Administration
 * 27-June-2007	Shrinidhi G V 	CF004252 -13 - NE activated/resync => Source in Sys Log is not NE ID name (ex. EM/NE)
 * 27-June-2007	Shrinidhi G V 	CF004252 -20 - NE activated/resync => Source in Sys Log is not NE ID name (ex. EM/NE)
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.basic;

import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.RANGE_PORT_MAX;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.RANGE_PORT_MIN;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.RANGE_RETRIES_MAX;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.RANGE_RETRIES_MIN;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.RANGE_TIMEOUT_MAX;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.RANGE_TIMEOUT_MIN;

/**
 * This string defines some of the common strings that are used by subsytem It
 * could or could not be used by both clients and server. But all common strings
 * across the subsystem will be defined here
 */
public final class USMCommonStrings {

    private USMCommonStrings(){
        super();
    }

    //A
    public static final String AT = "@";
    public static final String ADMINISTRATORS_USER_GROUP = "Administrators";
    public static final String ADMINISTRATOR_USER_NAME = "Administrator";

    //D
    public static final String[] DEFAULT_POLICIES_NAMES = { "TNMSAdministration", "TNMSSupervision", "TNMSMaintenance", "TNMSOperation", "TNMSConfiguration" };
    public static final String[] DEFAULT_GROUPS_NAMES = { "TNMS UserClass Administration", "TNMS UserClass Supervision", "TNMS UserClass Maintenance", "TNMS UserClass Operation", "TNMS UserClass Configuration" };

    //E
    public static final String EMPTY = "";

    //G
    public static final int GLOBAL_POLICY_INTERNAL_ID = 0;
    public static final String GLOBAL_POLICY_NAME = "GLOBAL";
    
    //P
    public static final String PASSWORD_NOT_MODIFIED = "The Password could not be modified.";


    //IDS_A
    public static final String IDS_AA_LOGIN_EVENT = "User Login";
    public static final String IDS_AA_LOGOUT_EVENT = "User Logoff";
    public static final String IDS_AA_CHANGE_PASSWORD_EVENT = "Change Password";
    public static final String IDS_AA_AUTHORIZATION_ERROR_EVENT = "Authorization Error";
    public static final String IDS_AA_SERVER_SHUTDOWN = "Server Shutdown";
    public static final String IDS_AA_USER_LOGIN = "User ''{0}'' has successfully logged in from machine ''{1}''";
    public static final String IDS_AA_LDAP_USER_LOGIN = "User ''{0}'' has successfully logged in from machine ''{1}'' using LDAP Authentication";
    public static final String IDS_AA_RADIUS_USER_LOGIN = "User ''{0}'' has successfully logged in from machine ''{1}'' using RADIUS Authentication";
    public static final String IDS_AA_USER_LOGIN_KERBEROS = "User ''{0}'' has successfully logged in from machine ''{1}'' based on Single Sign-on (SSO)";
    public static final String IDS_AA_USER_LOGOFF = "User ''{0}'' has successfully logged off from machine ''{1}'' after being logged in for: {2}";
    public static final String IDS_AA_USER_LOGIN_FAILURE = "User ''{0}'' tried to login and login failed from machine ''{1}''";
    public static final String IDS_AA_USER_LOGIN_FAILURE_MAX_SESSION = "User ''{0}'' tried to login and login failed from machine ''{1}'' due to maximum sessions reached.";
    public static final String IDS_AA_USER_LOGIN_FAILURE_KERBEROS = "User ''{0}'' tried to login and login failed from machine ''{1}'' based on Single Sign-on (SSO)";
    public static final String IDS_AA_USER_LOGIN_NO_LICENSE = "No license is available to login user ''{0}''";
    public static final String IDS_AA_USER_LOGIN_TRIAL_LICENSE_EXPIRED = "Trial expired and no license is available for user ''{0}''";
    public static final String IDS_AA_USER_CHANGE_PASSWORD_SUCCESS = "User ''{0}'' has successfully changed password from machine ''{1}''";
    public static final String IDS_AA_USER_CHANGE_PASSWORD_FAILURE = "User ''{0}'' password change failed as user is ''{1}'' from machine ''{2}''";
    public static final String IDS_AA_USER_DOESNOT_HAVE_VIEW_SECURABLE_OBJECTS_PERMISSIONS = "User ''{0}'' doesnot have permissions on any of the securable objects from machine ''{1}''";
    public static final String IDS_AA_USER_DOESNOT_HAVE_OPERATION_PERMISSIONS = "User ''{0}'' does not have permissions for performing ''{1}'' from machine ''{2}''";
    public static final String IDS_AA_USER_DOESNOT_HAVE_OBJECT_OPERATION_PERMISSIONS = "User ''{0}'' does not have permissions on ''{1}'' of the securable objects of the selected ''{2}'' objects for doing the operation ''{3}'' from machine ''{4}''";
    public static final String IDS_AA_USER_CREATE_USER_NOT_PERFORMED = "It was not possible to create the user ''{0}'' on server cache, which tried to logon from machine ''{1}'', based on information existing on Active Directory (SSO).";
    public static final String IDS_AA_LDAP_USER_CREATE_USER_NOT_PERFORMED = "It was not possible to create the user ''{0}'', which tried to logon from machine ''{1}'', based on information existing on LDAP.";
    public static final String IDS_AA_RADIUS_USER_CREATE_USER_NOT_PERFORMED = "It was not possible to create the user ''{0}'', which tried to logon from machine ''{1}'', based on information existing on RADIUS.";
    public static final String IDS_AA_USER_CREATE_USER_PERFORMED = "The user ''{0}'' was created on server cache, which tried to logon from machine ''{1}'', based on information existing on Active Directory (SSO).";
    public static final String IDS_AA_LDAP_USER_CREATE_USER_PERFORMED = "The user ''{0}'' was created, which tried to logon from machine ''{1}'', based on information existing on LDAP.";
    public static final String IDS_AA_RADIUS_USER_CREATE_USER_PERFORMED = "The user ''{0}'' was created, which tried to logon from machine ''{1}'', based on information existing on RADIUS.";
    public static final String IDS_AA_USER_MODIFY_GROUPS_NOT_PERFORMED = "It was not possible to modify user groups for user ''{0}'', which tried to logon from machine ''{1}'', based on information existing on Active Directory (SSO).";
    public static final String IDS_AA_LDAP_USER_MODIFY_GROUPS_NOT_PERFORMED = "It was not possible to modify user groups for user ''{0}'', which tried to logon from machine ''{1}'', based on information existing on LDAP.";
    public static final String IDS_AA_RADIUS_USER_MODIFY_GROUPS_NOT_PERFORMED = "It was not possible to modify user groups for user ''{0}'', which tried to logon from machine ''{1}'', based on information existing on RADIUS.";
    public static final String IDS_AA_USER_MODIFY_GROUPS_PERFORMED = "The user groups for user ''{0}'', which tried to logon from machine ''{1}'', were changed based on information existing on Active Directory using the System Account context (SSO).";
    public static final String IDS_AA_LDAP_USER_MODIFY_GROUPS_PERFORMED = "The user groups for user ''{0}'', which tried to logon from machine ''{1}'', were changed based on information existing on LDAP.";
    public static final String IDS_AA_RADIUS_USER_MODIFY_GROUPS_PERFORMED = "The user groups for user ''{0}'', which tried to logon from machine ''{1}'', were changed based on information existing on RADIUS.";
    public static final String IDS_AA_NO_PERMISSION = "No securable objects permissions";
    public static final String IDS_AA_CLIENT_UNAVAILABLE = "System disconnected the client's session for the user id ";
    public static final String IDS_AA_CLIENT_NOTRESPONDING = " as client not responding. ";
    public static final String IDS_AA_WEB_TIMEOUT = " as the user reached the session timeout";
    public static final String IDS_AA_CLIENT_DELAYED_FORCELOGOFF = " as client delayed to logoff. ";
    public static final String IDS_AA_TRIAL_LICENSE_EXPIRED = " as trial mode has expired. ";
    public static final String IDS_AA_CLIENT_MACHINE = " from the client machine ";
    public static final String IDS_AA_WEB_ADDRESS = " from the address ";
    public static final String IDS_AA_CLEANUP_USERS_SERVER_SHUTDOWN = "User data for ''{0}'' connected from machine ''{1}'' has been cleared, due to server shutdown.";
    public static final String IDS_AA_USER_DOES_NOT_HAVE_TNMS_GROUPS_ON_ACTIVE_DIRECTORY = "User ''{0}'' tried to login and login failed from machine ''{1}'' because there are no TNMS user groups on Active Directory associated to the user (SSO).";
    public static final String IDS_APPLICATION_USERS = "Application User";
    public static final String IDS_APPLICATION_USERS_GROUPS = "Application User Group";
    public static final String IDS_APPLICATION_POLICY = "Security Policy";
    public static final String IDS_APPLICATION_SECURITYSETTINGS = "Security Settings";
    public static final String IDS_APPLICATION_LDAP_AUTHENTICATION_SETTINGS = "LDAP Authentication Settings";
    public static final String IDS_APPLICATION_RADIUS_AUTHENTICATION_SETTINGS = "RADIUS Authentication Settings";
    public static final String IDS_APPLICATION_DOMAIN = "Security Domain ";
    public static final String IDS_APPLICATION_ACCESS_RIGHTS = "Security Access Rights ";
    public static final String IDS_APPLICATION_SERVER_COMPONENTS = "Application Server Components";
    public static final String IDS_AA_DIALOG_MESSAGE_ERROR_SSO_CONFIG = "It's not possible to proceed with Single Sign-on configuration due to a server error.";

    public static final String IDS_AA_DIALOG_MESSAGE_CONFIG_SAVED = "Security Settings saved.";
    public static final String IDS_AA_DIALOG_MESSAGE_SSO_CONFIG_SAVED = "Your Single Sign-On settings have been saved. Please contact your Administrator to apply.";

    public static final String IDS_AA_DIALOG_MESSAGE_LDAP_CONFIG_SUCCESS_DETAILS = "LDAP Authentication Settings modified. TNMS has access to {0} users and {1} valid user groups.";
    public static final String IDS_AA_DIALOG_MESSAGE_LDAP_CONFIG_WARNING_DETAILS = "LDAP Authentication Settings are invalid. TNMS has access to {0} users and {1} valid user groups.";
    public static final String IDS_AA_DIALOG_MESSAGE_LDAP_CONFIG_ERROR_DETAILS = "LDAP Authentication Settings are invalid, search failed. Please check the hostname, Search Account credentials and/or SSL certificates (if applicable).";
    public static final String IDS_AA_DIALOG_MESSAGE_LDAP_CONFIG_TOOMANY_DETAILS = "LDAP Authentication Settings returned too many results. Please refine your Search bases and filters.";
    public static final String IDS_AA_DIALOG_MESSAGE_LDAP_CONFIG_FILTER_ERROR = "LDAP Authentication Settings are invalid. Search Filters are incorrect.";

    public static final String IDS_AA_DIALOG_MESSAGE_LDAP_CONFIG_SAVED = "The current LDAP settings have been saved.";
    public static final String IDS_AA_DIALOG_MESSAGE_LDAP_CONFIG_ERROR = "The current LDAP settings are invalid. Check Security Log for details.";
    public static final String IDS_AA_DIALOG_MESSAGE_LDAP_CONFIG_WARNING = "The current LDAP settings have been saved with warnings. Check Security Log for details.";

    public static final String IDS_AA_DIALOG_MESSAGE_RADIUS_CONFIG_SAVED = "The current RADIUS settings have been saved.";
    public static final String IDS_AA_DIALOG_MESSAGE_RADIUS_CONFIG_ERROR = "The current RADIUS settings are invalid. Check Security Log for details";

    //IDS_B
    public static final String IDS_BS_COMMON_FUNCTION_SELECTED = "''{0}'': ''{1}'' selected for viewing the securable objects";
    public static final String IDS_BS_COMMON_FUNCTION_CONTEXT_MENU_SELECTED = "''{0}'' for ''{1}'' common function(s) selected";
    public static final String IDS_BS_CF_SELF_REGISTRATION_EVENT = "CF server self registration";
    public static final String IDS_BS_CF_MODIFICATION_EVENT = "CF Server Modification";
    public static final String IDS_BS_CF_REMOVAL_EVENT = "CF Server Removal";
    public static final String IDS_BS_COMMON_FUNCTION_REMOVAL = "Common Function ''{0}'' has been removed by ''{1}'' from machine ''{2}''";
    public static final String IDS_BS_COMMON_FUNCTION_CONFIGURED = "Common Function ''{0}'' has been configured into security by ''{1}'' from machine ''{2}''";
    public static final String IDS_BS_CF_NEW_APPLICATION_SYSTEM_LOG = "New CF ''{0}'' found and configured in User and Security Management";
    public static final String IDS_BS_SYNCH_CF_SEC_OBJS = "Synchronization of CF ''{0}'' performed. ''{1}'' Securable objects fetched";

    //IDS_C

    //IDS_D - Domain administration
    public static final String IDS_DC_DOMAIN_CREATION_EVENT = "Domain Creation";
    public static final String IDS_DC_DOMAIN_MODIFICATION_EVENT = "Domain Modification";
    public static final String IDS_DC_DOMAIN_DELETION_EVENT = "Domain Deletion";
    public static final String IDS_DC_DOMAIN_SELECTED = "''{0}'': ''{1}'' selected for viewing securable objects";
    public static final String IDS_DC_DOMAIN_DETAIL = "''{0}'': ''{1}'' description is ''{2}''";
    public static final String IDS_DC_DOMAIN_DELETED = "''{0}'' for ''{1}'' domain(s) selected";
    public static final String IDS_DC_DOMAIN_MAPPING_CHANGED = "''{0}'': Change of ''{1}'' domain mappings";
    public static final String IDS_DC_ASSIGNED_SEC_OBJECTS = "''{0}'': ''{1}'' Assigned ''{2}'' securable objects";
    public static final String IDS_DC_UNASSIGNED_SEC_OBJECTS = "''{0}'': ''{1}'' Removed ''{2}'' securable objects";
    public static final String IDS_DC_MAPPINGS_CHANGED_EVENT = "Access Rights Changed";
    public static final String IDS_DC_DOMAIN_CREATION = "Domain ''{0}'' has been created by ''{1}'' from machine ''{2}''";
    public static final String IDS_DC_DOMAIN_MODIFICATION = "Domain ''{0}'' has been modified by ''{1}'' from machine ''{2}''";
    public static final String IDS_DC_DOMAIN_DELETION = "Domain ''{0}'' has been deleted by ''{1}'' from machine ''{2}''";
    public static final String IDS_DC_MAPPING_CHANGED = "Access rights for the user group ''{0}'' on domain ''{1}'' has been given ''{2}'' policy by ''{3}'' from machine ''{4}''";
    public static final String IDS_DC_MAPPING_DELETION = "Access rights for the user group ''{0}'' on domain ''{1}'' has been removed by ''{2}'' from machine ''{3}''";

    //IDS_E

    //IDS_F

    //IDS_G
    public static final String IDS_GS_PASSWORD_EXPIRATION_INTERVAL = "Password expiration interval is ''{0}'' days";
    public static final String IDS_GS_CLIENT_INACTIVITY = "Client inactivity period is ''{0}'' minutes";
    public static final String IDS_GS_CLIENT_INACTIVITY_TIMEOUT_WARNING = "Session timeout warning is ''{0}'' minutes before";
    public static final String IDS_GS_DEACTIVATE_ACCOUNT = "Deactivate account after ''{0}'' days of inactivity";
    public static final String IDS_GS_LOCK_ACCOUNT = "Lock account after ''{0}'' unsuccessful login attempts";
    public static final String IDS_GS_ADMIN_UNLOCK = "Unlock Admin account after ''{0}'' minutes";
    public static final String IDS_GS_ADVISORY_MESSAGE_TO_BE_DISPLAYED = "Advisory message to be displayed is ''{0}''";
    public static final String IDS_GS_ADVISORY_MESSAGE_CHANGED = "Advisory message changed";
    public static final String IDS_GS_SETTINGS_CHANGE_EVENT = "Security Settings Modification";
    public static final String IDS_GS_PASSWORD_CHANGE_NOT_ALLOWED = "Not allowed to change password";
    public static final String IDS_GS_SETTINGS_MODIFIED = "Security settings data has been modified by ''{0}'' from machine ''{1}''";
    public static final String IDS_GS_FETCH_LDAP_ERROR = "Failed to fetch security settings because of a LDAP error.\nWindow will be closed";
    public static final String IDS_GS_UPDATE_LDAP_ERROR = "Failed to update security settings because of a LDAP error.";

    public static final String IDS_GS_LDAP_SCOPE_ONELEVEL   = "One Level";
    public static final String IDS_GS_LDAP_SCOPE_SUBTREE    = "Subtree";

    public static final String IDS_GS_LDAP_ATTR_HOSTNAME = "Hostname has been changed to {0}";
    public static final String IDS_GS_LDAP_ATTR_PORT = "Port has been changed to {0}";
    public static final String IDS_GS_LDAP_ATTR_SSL = "SSL has been changed to {0}";
    public static final String IDS_GS_LDAP_ATTR_SEARCH_DN = "Search Account DN has been changed to {0}";
    public static final String IDS_GS_LDAP_ATTR_USER_SEARCH_BASE = "User Search Base has been changed to {0}";
    public static final String IDS_GS_LDAP_ATTR_USER_SEARCH_FILTER = "User Search Filter has been changed to {0}";
    public static final String IDS_GS_LDAP_ATTR_USER_SEARCH_SCOPE = "User Search Scope has been changed to {0}";
    public static final String IDS_GS_LDAP_ATTR_USER_ID_ATTR = "User Identifying Attribute has been changed to {0}";
    public static final String IDS_GS_LDAP_ATTR_GROUP_SEARCH_BASE = "Group Search Base has been changed to {0}";
    public static final String IDS_GS_LDAP_ATTR_GROUP_SEARCH_FILTER = "Group Search Filter has been changed to {0}";
    public static final String IDS_GS_LDAP_ATTR_GROUP_SEARCH_SCOPE = "Group Search Scope has been changed to {0}";
    public static final String IDS_GS_LDAP_ATTR_GROUP_ID_ATTR = "Group Identifying Attribute has been changed to {0}";
    public static final String IDS_GS_LDAP_ATTR_GROUP_MEMBER_ATTR = "Group Member Attribute has been changed to {0}";

    public static final String IDS_GS_SSO_DOMAIN_NAME = "Domain Name has been changed to {0}";
    public static final String IDS_GS_SSO_DOMAIN_SERVER = "Domain Server has been changed to {0}";
    public static final String IDS_GS_SSO_PORT = "AD Port has been changed to {0}";

    public static final String IDS_GS_RADIUS_ENABLED = "RADIUS Authentication is enabled";
    public static final String IDS_GS_RADIUS_DISABLED = "RADIUS Authentication is disabled";
    public static final String IDS_GS_RADIUS_TIMEOUT = "Timeout has been changed to {0}";
    public static final String IDS_GS_RADIUS_RETRIES = "Retries has been changed to {0}";
    public static final String IDS_GS_RADIUS_USER_GROUP_ATTRIBUTE = "User Group Attribute has been changed to {0}";
    public static final String IDS_GS_RADIUS_SERVER_HOSTNAME = "Server hostname has been changed to {0}";
    public static final String IDS_GS_RADIUS_SERVER_PORT = "Server port has been changed to {0}";
    public static final String IDS_GS_RADIUS_SERVER_SECRET = "Server shared secret has been changed.";
    public static final String IDS_GS_RADIUS_ALT_SERVER_HOSTNAME = "Alternative Server hostname has been changed to {0}";
    public static final String IDS_GS_RADIUS_ALT_SERVER_PORT = "Alternative Server port has been changed to {0}";
    public static final String IDS_GS_RADIUS_ALT_SERVER_SECRET = "Alternative Server shared secret has been changed.";
    public static final String IDS_GS_RADIUS_SERVER_TEST = "Server configurations for {0} were tested and the result was {1}";

    public static final String IDS_GS_RADIUS_TEST_AVAILABLE = "Server OK";
    public static final String IDS_GS_RADIUS_TEST_CONNECTION_FAILED = "RADIUS Server unreachable";
    public static final String IDS_GS_RADIUS_TEST_REJECTED = "Server not registered as a client";
    public static final String IDS_GS_RADIUS_TEST_FAILED = "";

    public static final String IDS_GS_PASSWORD_VALIDATION_RULES_DATE = "Password must be different from date is now {0}";
    public static final String IDS_GS_PASSWORD_VALIDATION_RULES_NAME = "Password must be different from first/last name is now {0}";
    public static final String IDS_GS_PASSWORD_VALIDATION_RULES_EMPLOYEE_NUMBER = "Password must be different from employee number is now {0}";
    public static final String IDS_GS_PASSWORD_VALIDATION_RULES_MUST_NOT_HAVE_SPACES = "Password must not have spaces is now {0}";

    //IDS_H

    //IDS_I
    public static final String IDS_IE_USERS = "Users";
    public static final String IDS_IE_USER_GROUPS = "User Groups";
    public static final String IDS_IE_POLICIES = "Policies";
    public static final String IDS_IE_DOMAINS = "Domains";
    public static final String IDS_IE_DOMAIN_MAPPING = "Domain Mappings";
    public static final String IDS_IE_EXPORT_FAIL_SECURITY = "Failed to export ''{0}''. You do not have enough permissions.";
    public static final String IDS_IE_IMPORT_FAIL_SECURITY = "None of the ''{0}'' could be imported. You do not have enough permissions.";

    //IDS_J

    //IDS_K

    //IDS_L
    public static final String IDS_LG_OPERATION_SELECTED = "''{0}'' selected";
    public static final String IDS_LG_OPERATION_SELECTED_FOR = "''{0}'' for ''{1}'' selected";
    public static final String IDS_LG_WINDOW_TAB_CONSOLIDATE_MSG = "''{0} {1}'': {2}";
    public static final String IDS_LG_WINDOW_TAB_OBJECT_CONSOLIDATE_MSG = "''{0}, {1}'': ''{2}'' - {3}";
    public static final String IDS_LW_ACTIVE_DIRECTORY_CONNECTION_SUCCESS = "Successfully established a connection to the Active Directory ''{0}''";

    //IDS_M

    //IDS_N

    //IDS_O

    //IDS_P
    public static final String IDS_PA_POLICY_DETAIL = "''{0}'': ''{1}'' description is ''{2}''";
    public static final String IDS_PA_POLICY_PERMISSION_COUNT = "''{0}'': ''{1}'' Contains ''{2}'' permissions configured";
    public static final String IDS_PA_POLICY_CONTEXT_MENU_SELECTED = "''{0}'' for ''{1}'' policy(s) selected";
    public static final String IDS_PA_POLICY_CREATION_EVENT = "Policy Creation";
    public static final String IDS_PA_POLICY_MODIFICATION_EVENT = "Policy Modification";
    public static final String IDS_PA_POLICY_DELETION_EVENT = "Policy Deletion";
    public static final String IDS_PA_POLICY_CREATION = "Policy ''{0}'' has been created by ''{1}'' from machine ''{2}''";
    public static final String IDS_PA_POLICY_MODIFICATION = "Policy ''{0}'' has been modified by ''{1}'' from machine ''{2}''";
    public static final String IDS_PA_POLICY_DELETION = "Policy ''{0}'' has been deleted by ''{1}'' from machine ''{2}''";
    public static final String IDS_PA_POLICY_IMPORT_INCOMPATIBLE = "Policy configuration from this version is incompatible with the current one. Policy import will be skipped.";

    //IDS_Q

    //IDS_R

    //IDS_S
    // This should never get printed. But just in case someone has done a
    // mistake in their message format and it throws an exception, then this string gets printed
    public static final String IDS_SECURITY = "Security";
    public static final String IDS_SECURITY_LOG = "Security Log";
    public static final String IDS_SETTINGS_TAB_GENERAL = "General";
    public static final String IDS_SETTINGS_TAB_SSO = "Single Sign-On";
    public static final String IDS_SETTINGS_TAB_PASSWORD_VALIDATIONS = "Password Validations";
    public static final String IDS_SETTINGS_TAB_LDAP = "LDAP Authentication";
    public static final String IDS_SETTINGS_TAB_RADIUS = "RADIUS Authentication";
    public static final String IDS_SETTINGS_TAB_ACCNT_LOCK = "Account Lockout";
    public static final String IDS_SETTINGS_TAB_ADVISORY = "Advisory Message";

    //IDS_T

    //IDS_U - User and Group Administration
    public static final String IDS_USER_TAB_PERSONAL = "Personal";
    public static final String IDS_USER_TAB_PASSWORD = "Password and Account Data";
    public static final String IDS_USER_TAB_MEMBER = "Member of";
    public static final String IDS_UG_GROUP_DETAIL = "''{0}'': ''{1}'' description is ''{2}''";
    public static final String IDS_UG_GROUP_CONTEXT_MENU_SELECTED = "''{0}'' for ''{1}'' User Group(s) selected";
    public static final String IDS_UG_USERS_ASSIGNED = "''{0}'': ''{1}'' Contains ''{2}'' user(s) in this user group";
    public static final String IDS_UA_USERS_CONTEXT_MENU_SELECTED = "''{0}'' for ''{1}'' User(s) selected";
    public static final String IDS_UA_USER_PERSONAL_INFO_FULLNAME = "Full Name changed to ''{0}''";
    public static final String IDS_UA_USER_PERSONAL_INFO_EMAIL = "Email changed to ''{0}''";
    public static final String IDS_UA_USER_PERSONAL_INFO_PHONE = "Phone changed to ''{0}''";
    public static final String IDS_UA_USER_PERSONAL_INFO_FAX = "Fax changed to ''{0}''";
    public static final String IDS_UA_USER_PERSONAL_INFO_EMPLOYEE = "Employee Number changed to ''{0}''";
    public static final String IDS_UA_USER_PERSONAL_INFO = "Full Name-''{0}'', Email-''{1}'', Phone-''{2}'', Fax-''{3}'', Employee Number-''{4}''";
    public static final String IDS_UA_USER_ACCOUNT_INFO = "Change password at next logon set to ''{0}''. Cannot change password set to ''{1}''. Account deactivate set to ''{2}''. Password expires after ''{3}'' days.";
    public static final String IDS_UA_USER_ACCOUNT_INFO_PWD_NEXT_CHANGE = "Change password at next logon set to ''{0}''.";
    public static final String IDS_UA_USER_ACCOUNT_INFO_PWD_NO_CHANGE = "Cannot change password set to ''{0}''.";
    public static final String IDS_UA_USER_ACCOUNT_INFO_ACCOUNT_DEACTIVATE = "Account deactivate set to ''{0}''.";
    public static final String IDS_UA_USER_ACCOUNT_INFO_PWD_EXPIRATION_DAYS = "Password expires after ''{0}'' days.";
    public static final String IDS_UA_USER_ACCOUNT_INFO_PWD_CHANGED = "Password was modified.";
    public static final String IDS_UA_USER_ACCOUNT_INFO_PWD_EXPIRATION = "Password expiration{0}.";
    public static final String IDS_UA_USER_ACCOUNT_INFO_ADDITIONAL = "User inactivity timeout{0}. Simultaneous user sessions restriction{1}. Account expiration{2}.";
    public static final String IDS_UA_USER_ACCOUNT_INFO_ADDITIONAL_INACTIVITY = "User inactivity timeout{0}.";
    public static final String IDS_UA_USER_ACCOUNT_INFO_ADDITIONAL_SESSIONS = "Simultaneous user sessions restriction{0}.";
    public static final String IDS_UA_USER_ACCOUNT_INFO_ADDITIONAL_ACCOUNT = "Account expiration{0}.";
    public static final String IDS_UA_USER_GROUP_INFO = "User belongs to ''{0}'' user group(s).";
    public static final String IDS_UA_USER_CREATION_EVENT = "User Creation";
    public static final String IDS_UA_USER_MODIFICATION_EVENT = "User Modification";
    public static final String IDS_UA_USER_DELETION_EVENT = "User Deletion";
    public static final String IDS_UA_USER_FORCE_LOGOFF_EVENT = "User Force Logoff";
    public static final String IDS_UA_USER_LOCKED_EVENT = "User Locked";
    public static final String IDS_UA_USER_UNLOCKED_EVENT = "User Unlocked";
    public static final String IDS_UA_USER_ACTIVATION_EVENT = "User Activation";
    public static final String IDS_UA_USER_DEACTIVATION_EVENT = "User Deactivation";
    public static final String IDS_UA_USERGROUP_CREATION_EVENT = "User Group Creation";
    public static final String IDS_UA_USERGROUP_MODIFICATION_EVENT = "User Group Modification";
    public static final String IDS_UA_USERGROUP_DELETION_EVENT = "User Group Deletion";
    public static final String IDS_UA_PASSWORD_EXPIRED = "Password expired";
    public static final String IDS_UA_USER_ACTIVATE = "User ''{0}'' has been activated by ''{1}'' from machine ''{2}''";
    public static final String IDS_UA_USER_DEACTIVATE = "User ''{0}'' has been deactivated by ''{1}'' from machine ''{2}''";
    public static final String IDS_UA_USER_UNLOCKED = "User ''{0}'' has been unlocked by ''{1}'' from machine ''{2}''";
    public static final String IDS_UA_USER_FORCE_LOGOFF = "User ''{0}'' has been forcefully logged off by ''{1}'' from machine ''{2}''";
    public static final String IDS_UA_USER_LOCKED = "User ''{0}'' has been locked for exceeding password retries by ''{1}'' from machine ''{2}''";
    public static final String IDS_UA_USER_PASSWORD_EXPIRED = "Password for user ''{0}'' marked as expired";
    public static final String IDS_UA_USER_PASSWORD_EXPIRED_FLAG_RESET = "Password expiry flag for user ''{0}'' has been reset";
    public static final String IDS_UA_USER_CREATION = "User ''{0}'' has been created by ''{1}'' from machine ''{2}''";
    public static final String IDS_UA_USER_MODIFICATION = "User ''{0}'' has been modified by ''{1}'' from machine ''{2}''";
    public static final String IDS_UA_USER_USERGROUP_ADD = "User ''{0}'' was added to usergroups: {1} by ''{2}'' from machine ''{3}''";
    public static final String IDS_UA_USER_USERGROUP_REMOVE = "User ''{0}'' was removed from usergroups: {1} by ''{2}'' from machine ''{3}''";
    public static final String IDS_UA_USER_DELETEION = "User ''{0}'' has been deleted by ''{1}'' from machine ''{2}''";
    public static final String IDS_UA_USERGROUP_CREATION = "User group ''{0}'' has been created by ''{1}'' from machine ''{2}''";
    public static final String IDS_UA_USERGROUP_MODIFICATION = "User group ''{0}'' has been modified by ''{1}'' from machine ''{2}''";
    public static final String IDS_UA_USERGROUP_DELETEION = "User group ''{0}'' has been deleted by ''{1}'' from machine ''{2}''";
    public static final String IDS_USM_START_USM_FULL_SYNCH = "Start of User and Security Management full synchronization";
    public static final String IDS_USM_END_USM_FULL_SYNCH = "End of User and Security Management full synchronization";
    public static final String IDS_USM_START_USM_FORCED_SYNCH = "Start of User and Security Management forced synchronization";
    public static final String IDS_USM_END_USM_FORCED_SYNCH = "End of User and Security Management forced synchronization";
    public static final String IDS_USM_START_USM_SYNCH = "Start of User and Security Management synchronization";
    public static final String IDS_USM_END_USM_SYNCH = "End of User and Security Management synchronization";
    public static final String IDS_USM_START_USM_INITIALIZED = "Start of User and Security Management initialization";
    public static final String IDS_USM_END_USM_INITIALIZED = "End of User and Security Management initialization";
    public static final String IDS_USM_ERROR_USM_INITIALIZED = "Error at User and Security Management initialization";
    public static final String IDS_USM_START_USM_FINALIZED = "Start of User and Security Management shut down";
    public static final String IDS_USM_END_USM_FINALIZED = "End of User and Security Management shut down";
    public static final String IDS_USM_START_USM_REINITIALIZE = "Start of User and Security Management re-initialization";
    public static final String IDS_USM_END_USM_REINITIALIZE = "End of User and Security Management re-initialization";
    public static final String IDS_USM_ERROR_USM_REINITIALIZE = "Error at User and Security Management re-initialization";
    public static final String IDS_USM_SECURITY_LOG_UNAVAILABLE = "Could not create a security log record";
    public static final String USERGROUP_ADDED_ACTIVITY     = "User Added to Usergroup";
    public static final String USERGROUP_REMOVED_ACTIVITY   = "User Removed from Usergroup";

    //IDS_V

    //IDS_X

    //IDS_Z

    //P
    public static final String POLICY_FILE_EXTENSION = ".policy";
    public static final String IDS_PA_PERMISSION_DESCRIPTION_HTML = "<html><strong>The permission {0} allows you to:</strong><br>{1}</html>";
    public static final String IDS_PA_PERMISSION_ITEM_DESCRIPTION_HTML = "- {0}; <br>";

    //S
    public static final String SYSTEM_ACCOUNT = "System Account";

    //U
    public static final String UNKNOWN_HOST = "<unknown>";

    public static final String RADIUS_FORMAT_RANGE = "[%d...%d]";

    public static final String RADIUS_TITLE_CLIENT_SETTINGS = "Client Settings";
    public static final String RADIUS_TITLE_SERVER_SETTINGS = "Server Settings";
    public static final String RADIUS_TITLE_ALT_SERVER_SETTINGS = "Alternative Server Settings";

    public static final String RADIUS_TEXT_HOSTNAME = "IP &Address/Hostname:";
    public static final String RADIUS_TEXT_SHARED_SECRET = "Shared &Secret:";
    public static final String RADIUS_TEXT_PORT = "&Port:";
    public static final String RADIUS_TEXT_ALT_PORT = "&Port:";
    public static final String RADIUS_TEXT_PORT_RANGE = String.format(RADIUS_FORMAT_RANGE, RANGE_PORT_MIN, RANGE_PORT_MAX);
    public static final String RADIUS_TEXT_USER_GROUP_ATTRIBUTE = "&User Group Attribute:";
    public static final String RADIUS_TEXT_TIMEOUT = "&Timeout:";
    public static final String RADIUS_TEXT_RETRIES = "&Retry:";

    public static final String RADIUS_TEXT_TIMEOUT_RANGE = String.format(RADIUS_FORMAT_RANGE, RANGE_TIMEOUT_MIN, RANGE_TIMEOUT_MAX);
    public static final String RADIUS_TEXT_TIMEOUT_UNIT = "seconds";
    public static final String RADIUS_TEXT_RETRIES_RANGE = String.format(RADIUS_FORMAT_RANGE, RANGE_RETRIES_MIN, RANGE_RETRIES_MAX);
    public static final String RADIUS_TEXT_RETRIES_UNIT = "retries";
    public static final String RADIUS_TEXT_TEST_CONNECTION = "Test Connection";
    public static final String RADIUS_TEXT_STATUS_TESTING = "Testing...";
    public static final String RADIUS_TEXT_STATUS_NOT_CONFIGURED = "Please fill the parameters";


}
