/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCModifyDomainController
 * Author      	Muyeen Munaver
 * Substitute	Asifullakhan
 * Created on	26-07-2004
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CONFIG
 * 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 10-Feb-2005	Asif 			CF000834 - Command Log Entries 
 * 11-Mar-2005	Asif			CF000845 - System Event Log Entries
 * 22-Mar-2005	Muyeen Munaver	CF0001791 - Problems with Login
 * 
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCHelper;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessageType;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;
import com.ossnms.bicnet.securitymanagement.server.basic.notification.USMNotifier;
import com.ossnms.bicnet.securitymanagement.server.logging.LMInterFace;
import com.ossnms.bicnet.securitymanagement.server.logging.LMLogRecordData;
import com.ossnms.bicnet.securitymanagement.server.logging.LMLogRecordEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Controller for creating, modifying a domain.
 */
class DCModifyDomainController {
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(DCModifyDomainController.class);

    /**
     * Constructor
     */
    DCModifyDomainController() {

    }

    /**
     * This method handles the request the creation of domain. The created domain is passed back
     * which contains the domain id and the domain unique id
     *
     * @param domain Domain object that is to be created
     * @return Message that contains the result of the operation, includes the created domain
     */

    public USMMessage createDomain(ISessionContext ctx, DCDomainData domain) {

        LOGGER.debug("createDomain() - Enter");
        boolean bSuccess = false;

        //Fill in the Message that has to be sent
        USMMessage msg = new USMMessage( DCMessageType.DC_RES_CREATE_DOMAIN, USMMessage.USMMESSAGE_RESPONSE);

        LOGGER.info("The domain which is to be modified is " + domain);

        DCDomainData createdDom = null;
        try {
			//Now ask cache manager to create a domain and get information about the created domain
			createdDom = DCServerDataManager.getInstance().createDomain(domain);
			createdDom.pushMe(msg);
			msg.pushInteger(DCMessages.DC_NO_ERROR);
			bSuccess = true;
		}
		//No need to trace it out here, as it would have been traced anyway in the
		//cache manager
		catch (DCDupNameException dupEx) {
			msg.pushInteger(DCMessages.DC_DUPLICATE_NAME);
		} catch (DCDataBaseException dupEx) {
			msg.pushInteger(DCMessages.DC_LDAP_ERROR);
		}
		//Tracing is required here, as this is a an exception thrown from outside DC
		catch (Exception ex) {
			msg.pushInteger(DCMessages.DC_INTERNAL_ERROR);
            LOGGER.error("createDomain() - Some unknown error has occurred while creating domain {} exception {}", domain, ex.getMessage());
        }

        if (bSuccess) {
            // Create security log for the event.
            String displayStr = MessageFormat.format(
                    USMCommonStrings.IDS_DC_DOMAIN_CREATION,
                    domain.getDomainName(),
                    ctx.getUserName(),
                    ((IEnhancedSessionContext) ctx).getClientMachineName()
            );

            LMLogRecordData usmLogRecord = new LMLogRecordData(
                    LMLogRecordEnum.DOMAIN_CREATION,
                    domain.getDomainName(),
                    LMLogRecordData._SUCCESS,
                    null,
                    LogSeverity.MESSAGE.guiLabel(),
                    null,
                    displayStr
            );

            LMInterFace.getInstance().createSecurityLogRecord(
                    ctx,
                    usmLogRecord
            );

            //Broadcast a notification to people listening that a new domain has been created
            USMMessage notifMsg = new USMMessage(
                            DCMessageType.DC_NOT_DOMAIN_CREATED,
                            USMMessage.USMMESSAGE_NOTIFICATION
            );

            createdDom.pushMe(notifMsg);
            USMNotifier.getInstance().sendNotification(notifMsg);

            // External Notification - Domains - Object Creation
            new SecurityDomainFacade().sendObjectCreation(createdDom);
        }
        LOGGER.debug("createDomain() - Exit");
        return msg;
    }



    /**
     * This method handles the request to modify the domain. Only domain description can
     * be modified. Securable objects assigned/unassigned to a domain is handled in a differnt way.
     *
     * @param domain Domain object that is to be modified
     * @return Message that contains the result of the operation
     */
    public USMMessage modifyDomain(ISessionContext context, DCDomainData domain) {
        LOGGER.debug("modifyDomain() - Entry");
        boolean bSuccess = false;
        //Fill in the USMMessage that has to be sent
        USMMessage msg = new USMMessage(DCMessageType.DC_RES_MODIFY_DOMAIN, USMMessage.USMMESSAGE_RESPONSE);

        LOGGER.info("The domain which is to be modified is " + domain);

        try {
            //Ask DC to modify the domain in LDAP
            DCServerDataManager.getInstance().modifyDomain(domain);
            msg.pushInteger(DCMessages.DC_NO_ERROR);
            bSuccess = true;
        } catch (DCDataBaseException dupEx) {
            msg.pushInteger(DCMessages.DC_LDAP_ERROR);
        } catch (DCInvalidDomainException dupEx) {
            msg.pushInteger(DCMessages.DC_DOMAIN_INVALID);
        } catch (Exception ex) {
            msg.pushInteger(DCMessages.DC_INTERNAL_ERROR);
            LOGGER.error("modifyDomain() - Some exception occured while modifying domain {} exception {}", domain, ex.getMessage());
        }
        //Send the message finally to the client.

        if (bSuccess) {
            // Create security log for the event.
            String displayStr = MessageFormat.format(
                            USMCommonStrings.IDS_DC_DOMAIN_MODIFICATION,
                            domain.getDomainName(),
                            context.getUserName(),
                            ((IEnhancedSessionContext) context).getClientMachineName()
            );

            LMLogRecordData usmLogRecord = new LMLogRecordData(
                            LMLogRecordEnum.DOMAIN_MODIFICATION,
                            domain.getDomainName(),
                            LMLogRecordData._SUCCESS,
                            null,
                            LogSeverity.MESSAGE.guiLabel(),
                            null,
                            displayStr
            );

            LMInterFace.getInstance().createSecurityLogRecord(
                    context,
                    usmLogRecord
            );

            //Broadcast a notification to components listening that a domain has been modified
            USMMessage notifMsg = new USMMessage(
                    DCMessageType.DC_NOT_DOMAIN_MODIFIED,
                    USMMessage.USMMESSAGE_NOTIFICATION
            );

            domain.pushMe(notifMsg);
            USMNotifier.getInstance().sendNotification(notifMsg);

            // External Notification - Domains - Attribute Value Change
            new SecurityDomainFacade().sendAttributeValueChanged(domain);
        }
        LOGGER.debug("modifyDomain() - Exit");
        return msg;
    }

    /**
     * This function assigns/unassigns securable objects to the selected domain.
     *
     * @param assignList   Securable objects which need to be assigned to domain
     * @param unassignList Securable objects which need to be un-assigned to domain
     * @param domain            The domain to which the objects need to be assigned/unassigned
     * @return Returns the status of the assign/unassign objects operation
     */
    USMMessage assignSecurableObjects(List<BSSecurableObject> assignList, List<BSSecurableObject> unassignList, DCDomainData domain) {
        LOGGER.debug("assignSecurableObjects() - Enter");

        //Assign domains of NE, ask BS to assigne domains of objects
        //BS should issue notification about assignment
        boolean bResult = DCExternalInterface.setDomainOfSecurableObjects(assignList, domain, true);

        if (bResult) {
            bResult = DCExternalInterface.setDomainOfSecurableObjects(unassignList, domain, false);
        }

        //Fill in the ICMessage that has to be sent
        USMMessage msg = new USMMessage( DCMessageType.DC_RES_ASSIGN_TO_DOMAIN, USMMessage.USMMESSAGE_RESPONSE);
        if (!bResult) {
            msg.pushInteger(DCMessages.DC_FAILED_TO_ASSIGN_NES);
        } else {
            msg.pushInteger(DCMessages.DC_NO_ERROR);
        }

        LOGGER.debug("assignSecurableObjects() - Exit");
        return msg;
    }

	/**
	 * Helper function to get all the network elements. This is called when the
	 * primitive "DC_Req_NetElemList" is received
	 * 
	 * @param domain USMMessage that contains the information from the client about the server and the domain.
	 */
	public USMMessage getSecurableObjects(DCDomainData domain, BSTransBicNetCFInfo server, boolean assign) {
        List<BSSecurableObject> securableObjects = new ArrayList<>();
        DCExternalInterface.getSecurableObjectsOfDomainForServer(domain, server, assign, securableObjects);

        USMMessage message = new USMMessage(DCMessageType.DC_RES_DOMAIN_DETAILS_OBJECT_LEVEL, USMMessage.USMMESSAGE_RESPONSE);
        DCHelper.pushSecurableObjects(securableObjects, message);
        server.pushTo(message);

        message.pushBoolean(assign);

        if (0 == securableObjects.size()) {
            //This should not typically happen, as this means that all NEs of this
            //server have been removed from the domain......wait wait
            //This case can very well happen, a notificataion would
            //have already gone to the client. But it could so happen that before the client
            //recieves the notification, the client has sent a request
            LOGGER.debug( "getSecurableObjects 0 NEs from server are assigned to this server {}", server);
        }
        message.pushInteger(DCMessages.DC_NO_ERROR);

        LOGGER.debug( "DCViewDomainConfigController - getNetElemsOfDomainForServer - The Nes of the server {} are : {}", server, domain);
        return message;

    }

	/**
	 * Helper function to get the first level server for the chosen domain. It
	 * does not send all the NEs associated with the domain. Only the first
	 * level to be displayed will be sent to the server.
	 * 
	 * @param domain USMMessage that contains the domain.
	 */
    USMMessage getFirstLevelSecurableObjects(DCDomainData domain) {
		LOGGER.debug("DCModifyDomainController - getFirstLevelSecurableObjects - Entry");

        //Get the list of server which have the NEs assigned to a domain.
        //This gives the list of assigned NEs.
        List<BSTransBicNetCFInfo> assignedServer = DCExternalInterface.getFirstLevelDetailsForDomain(domain, true);
        List<BSTransBicNetCFInfo> unAssignedServer = DCExternalInterface.getFirstLevelDetailsForDomain(domain, false);

        //Fill in the ICMessage that has to be sent
        USMMessage msg = new USMMessage(DCMessageType.DC_RES_DOMAIN_DETAILS_SERVER_LEVEL, USMMessage.USMMESSAGE_RESPONSE);
        //Now push this information into ICMessage
        //Push the assigned server list
        DCHelper.pushServersToMessage(assignedServer, msg);
        //Now push the un-assigned server list
        DCHelper.pushServersToMessage(unAssignedServer, msg);

        //Finally push the no error ID
        msg.pushInteger(DCMessages.DC_NO_ERROR);
        //Send the messag finally to the client.

		LOGGER.debug("DCModifyDomainController :: getFirstLevelSecurableObjects :: Exit");
		return msg;
	}
	
	/**
	 * Helper function to get all the securable objects from server.
	 *
	 */
    USMMessage getAllSecurableObject() {
        List<BSTransBicNetCFInfo> configuredCFsList = DCExternalInterface.getAllServers();
        Map<BSTransBicNetCFInfo, List<BSSecurableObject>> result = new HashMap<>();

        for (BSTransBicNetCFInfo cfInfo : configuredCFsList) {
            List<BSSecurableObject> securableObjectList = new ArrayList<>();
            DCExternalInterface.getSecurableObjects(cfInfo, securableObjectList, 0);
            if (securableObjectList.size() > 0) {
                result.put(cfInfo, securableObjectList);
            }
        }

        //Fill in the ICMessage that has to be sent
        USMMessage msg = new USMMessage(DCMessageType.DC_RES_ALL_SECURABLE_OBJECTS, USMMessage.USMMESSAGE_RESPONSE);
        //Now push this information into ICMessage
        //Push the assigned server list
        msg.pushObject(result);

        //Finally push the no error ID
        msg.pushInteger(DCMessages.DC_NO_ERROR);
        //return the message to be sent to Sto the client.
        return msg;
    }
}
