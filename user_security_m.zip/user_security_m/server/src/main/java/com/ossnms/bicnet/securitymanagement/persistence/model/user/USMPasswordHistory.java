package com.ossnms.bicnet.securitymanagement.persistence.model.user;

import com.ossnms.bicnet.securitymanagement.persistence.model.BaseUSMEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * created on 8/10/2014
 */
@Entity
@Table(name = "USM_PASSWORD_HISTORY",
        uniqueConstraints = { @UniqueConstraint(columnNames = {"USER_ID", "PASSWORD"})}
)
@NamedQueries({
    @NamedQuery(name="usmPasswordHistory.findByUserID", query = "from USMPasswordHistory u where u.user = :user order by u.dateChanged desc")
})
public class USMPasswordHistory extends BaseUSMEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "USMPasswordHistorySequence")
    @SequenceGenerator(name = "USMPasswordHistorySequence", sequenceName = "USM_SEQ_PASSWORD_HISTORY")
    @Column(name = "ID")
    private Integer id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "USER_ID", nullable = false)
    private USMUser user;

    @Column(name = "PASSWORD", nullable = false)
    private String password;

    @Column(name = "DATE_CHANGED", nullable = false)
    private String dateChanged;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public USMUser getUser() {
        return user;
    }

    public void setUser(USMUser user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDateChanged() {
        return dateChanged;
    }

    public void setDateChanged(String dateChanged) {
        this.dateChanged = dateChanged;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }

        USMPasswordHistory that = (USMPasswordHistory) o;

        if (dateChanged != null ? !dateChanged.equals(that.dateChanged) : that.dateChanged != null){
            return false;
        }
        if (password != null ? !password.equals(that.password) : that.password != null){
            return false;
        }
        if (user != null ? !user.equals(that.user) : that.user != null){
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = 0;
        result = 31 * result + (user != null ? user.hashCode() : 0);
        result = 31 * result + (password != null ? password.hashCode() : 0);
        result = 31 * result + (dateChanged != null ? dateChanged.hashCode() : 0);
        return result;
    }

    @Override
    public boolean isNew() {
        return id == null || id == 0;
    }
}
