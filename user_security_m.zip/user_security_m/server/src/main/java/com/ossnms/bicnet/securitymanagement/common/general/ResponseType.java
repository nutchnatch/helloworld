package com.ossnms.bicnet.securitymanagement.common.general;

public enum ResponseType {

    ERROR_MESSAGE (0),
    INFORMATION_MESSAGE (1),
    WARNING_MESSAGE (2),
    QUESTION_MESSAGE (3),

    PLAIN_MESSAGE (-1);
    
   private final int id;
   
   ResponseType(int id){
       this.id=id;
   }
   public int getValue(){
       return id;
   }
   
}
