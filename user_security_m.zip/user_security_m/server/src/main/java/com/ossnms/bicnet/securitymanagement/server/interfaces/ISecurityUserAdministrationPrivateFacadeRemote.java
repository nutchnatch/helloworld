package com.ossnms.bicnet.securitymanagement.server.interfaces;

public interface ISecurityUserAdministrationPrivateFacadeRemote extends ISecurityUserAdministrationPrivateFacade { }

