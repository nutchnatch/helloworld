package com.ossnms.bicnet.securitymanagement.common.general.radius.status;

import java.io.Serializable;

/**
 * DTO to include all the data necessary for the server test
 */
public class RadiusTestConfigurationData implements Serializable {

    private static final long serialVersionUID = -5293435065912457775L;

    private int timeout;
    private int retries;

    private String serverHostname;
    private int serverPort;
    private String serverSharedSecret;

    public int getTimeout() {
        return timeout;
    }

    public void setTimeout(int timeout) {
        this.timeout = timeout;
    }

    public int getRetries() {
        return retries;
    }

    public void setRetries(int retries) {
        this.retries = retries;
    }

    public String getServerHostname() {
        return serverHostname;
    }

    public void setServerHostname(String serverHostname) {
        this.serverHostname = serverHostname;
    }

    public int getServerPort() {
        return serverPort;
    }

    public void setServerPort(int serverPort) {
        this.serverPort = serverPort;
    }

    public String getServerSharedSecret() {
        return serverSharedSecret;
    }

    public void setServerSharedSecret(String serverSharedSecret) {
        this.serverSharedSecret = serverSharedSecret;
    }
}
