/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCGlobal
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CREATE
 * 		:	TNMS.DX2.SM.DOMAIN.CONFIG	   
 * 		:	TNMS.DX2.SM.DOMAIN.VIEW
 * 		:	TNMS.DX2.SM.MAPPING.CREATE
 * 		:	TNMS.DX2.SM.MAPPING.VIEW 
 * 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.common.domain;

/**
 * 
 */
public class DCGlobal {
	/*
	 * This was one place where, i could put the Trace strategy
	 * 
	 * The trace statements follow the strategy within the DC subsystem
	 * 1>All entry and exit statements have
	 * 				debug("Method name() - Enter/Exit");
	 * 
	 * 2>All preconditions and postconditions have
	 * 				debug("<Invalid inputs>");
	 * 
	 * 3>Information about change in state or write into LDAP are logged as
	 * 				info("<Update results>"); 
	 * 
	 * 4>Exceptions which are raised not necessarily as part of an error are logged as
	 * 				warning("<Reason for exception>");
	 * 
	 * 5>All errors and the exceptions which are clearly an error are logged
	 * 				error("<Reason for error>");
	 * 
	 */

	public static final int MAX_DOMAINS = 128;

}
