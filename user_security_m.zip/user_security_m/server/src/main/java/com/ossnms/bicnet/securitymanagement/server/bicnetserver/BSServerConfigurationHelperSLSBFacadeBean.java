/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	BSServerConfigurationHelperSLSBFacadeBean
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	12-10-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.bicnetserver;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityServerConfigurationHelperPrivateFacadeLocal;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityServerConfigurationHelperPrivateFacadeRemote;

/**
 *  Bean implementation for the interface provided for the call style change
 * 
 **/

@Stateless(name="BSServerConfigurationHelperSLSBFacade")
@Local(ISecurityServerConfigurationHelperPrivateFacadeLocal.class)
@Remote(ISecurityServerConfigurationHelperPrivateFacadeRemote.class)
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class BSServerConfigurationHelperSLSBFacadeBean implements ISecurityServerConfigurationHelperPrivateFacadeLocal, ISecurityServerConfigurationHelperPrivateFacadeRemote {

	private BSServerConfigurationHelperPOJOImpl pojo = new BSServerConfigurationHelperPOJOImpl();

	public void checkForNewlyAvailableCFsWithServiceLocator(ISessionContext p_ctx)
		throws BcbSecurityException {
		pojo.checkForNewlyAvailableCFsWithServiceLocator(p_ctx);
	}

}
