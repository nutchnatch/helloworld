/*
 * Project      BiCNET Common Functions
 *
 * Component    CF:USM
 * Class Name   BSTransBicNetCFInfo
 * Author       Muyeen M
 * Substitute   Asifulla Khan
 * Created on   12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_OBJECTS
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_ACL
 *       : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_SECURITY
 *       : TNMS.DX2.SM.APPLICATION_SERVER.INSERT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 02-Feb-2005  Babu B          CF000199-11 Unification of GUI-Labels for Enums
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.bicnetserver;

import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.ComponentVersionInformation;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import org.apache.log4j.Logger;

import java.io.Serializable;
import java.security.InvalidParameterException;

/**
 * Transient data to hold the BicNet Component Function details. This data is used to
 * transfer information about the CFs from the Server to the
 * Client, and vice-versa
 */
public class BSTransBicNetCFInfo implements Serializable {
    public static final long serialVersionUID = 111119999L;

    /**
     * Data member for the Logging of the class.
     */
    private transient static final Logger LOGGER =
            Logger.getLogger(BSTransBicNetCFInfo.class);

    /**
     * String that stores the editable display name.
     */
    private String name = null;

    /**
     * Data member that stores the description that has been sent by
     * the component.
     */
    private String description = null;

    /**
     * Data member to identify the type of the component.
     */
    private BiCNetComponentType componentType = null;

    /**
     * Data member to hold the Version Information of the component.
     */
    private ComponentVersionInformation version = null;

    /**
     * Data member to hold whether the CF is available or not.
     */
    private boolean isAvailable = true;

    /**
     * Default Constructor.
     */
    public BSTransBicNetCFInfo() {
        LOGGER.debug("Entering Default Constructor.");
        LOGGER.debug("Exiting Default Constructor.");
    }

    /**
     * Constructor
     *
     * @param p_Name          The Display name of the component
     * @param p_Desc          The Description for the component
     * @param p_ComponentType Type of the component
     * @param pVersion       Version of the CF
     */
    public BSTransBicNetCFInfo(
            String p_Name,
            String p_Desc,
            BiCNetComponentType p_ComponentType,
            ComponentVersionInformation pVersion) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "Entering constructor of BSTransBicNetCFInfo. Values passed are : "
                            + " Name : "
                            + p_Name
                            + " Description : "
                            + p_Desc
                            + " Type : "
                            + p_ComponentType
                            + " Version Info : "
                            + pVersion);
        }

        if ((null == p_Name)
                || (null == p_Desc)
                || (null == p_ComponentType)
                || (null == pVersion)) {
            LOGGER.error(
                    "Invalid parameter passed."
                            + " Name : "
                            + p_Name
                            + " Description : "
                            + p_Desc
                            + " Type : "
                            + p_ComponentType
                            + " Version Info : "
                            + pVersion);
            throw new InvalidParameterException();
        }
        name = p_Name;
        description = p_Desc;
        componentType = p_ComponentType;
        version = pVersion;

        LOGGER.debug("Exiting constructor of BSTransBicNetCFInfo");
    }

    /**
     * This function is invoked when the BSTransBicNetCFInfo needs to be passed
     * from the Server to Client or vice versa. This function will push the
     * BSTransBicNetCFInfo into the message.
     *
     * @param pMsg The message into which the object should be pushed.
     */
    public void pushTo(USMMessage pMsg) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Pushing : " + getTraceString() + " into the message");
        }

        if (null == pMsg) {
            LOGGER.error("Message passed is null.");
            throw new InvalidParameterException();
        }

        pMsg.pushString(name);
        pMsg.pushString(description);
        pMsg.pushString(componentType.toString());

        pMsg.pushString(version.getName());
        pMsg.pushString(version.getVersion());
        pMsg.pushString(version.getBcbVersion());
//        pMsg.pushShort(Short.valueOf(version.getMinor()));
//        pMsg.pushString(version.getBuild());
//        pMsg.pushString(version.getRelease());

        pMsg.pushBoolean(isAvailable);

        LOGGER.debug("Exiting pushTo");
    }

    /**
     * This function is invoked when the BSTransBicNetCFInfo needs to be created after
     * recieving a message from the Server to Client or vice versa. This function
     * will pop the BSTransBicNetCFInfo from the message.
     *
     * @param pMsg The message from which the object should be poped.
     * @return The newly poped BSTransBicNetCFInfo
     */
    public static BSTransBicNetCFInfo popMe(USMMessage pMsg) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Poping object from message : " + pMsg);
        }

        if (null == pMsg) {
            LOGGER.error("Message passed is null.");
            throw new InvalidParameterException();
        }

        boolean bAvailable = pMsg.popBoolean();

//        String strRelease = pMsg.popString();
//        String strBuild = pMsg.popString();
//        Short minor = pMsg.popShort();
//        Short major = pMsg.popShort();

        String bcbVersion = pMsg.popString();
        String version = pMsg.popString();
        String name = pMsg.popString();

        ComponentVersionInformation ver = new ComponentVersionInformation(name, version, bcbVersion);

        BiCNetComponentType componentType = BiCNetComponentType.fromName(pMsg.popString());
        String description = pMsg.popString();
        String nme = pMsg.popString();

        BSTransBicNetCFInfo obj = new BSTransBicNetCFInfo(nme, description, componentType, ver);

        if (bAvailable) {
            obj.setCFAsAvailable();
        } else {
            obj.setCFAsUnavailable();
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting popMe. Object being returned is : " + obj);
        }

        return obj;
    }

    /**
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        return componentType.hashCode();
    }

    /**
     * Function to return the Component Type of this CF Object
     *
     * @return BiCNetComponentType
     * The Component Type associated with this CF Object.
     */
    public BiCNetComponentType getComponentType() {
        return componentType;
    }

    /**
     * Function to return the Identifier which will be used for the identification purpouse of
     * this CF
     *
     * @return String
     * String which represents the Identifier for this CF.
     */
    public String getCFid() {
        return componentType.toString();
    }

    /**
     * Function to return the Description for this CF Object
     *
     * @return String
     * String which represents the Description for the CF.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Function to retrieve the Name of the CF
     *
     * @return String
     * String which represents the Name of the CF.
     */
    public String getName() {
        return name;
    }

    /**
     * Function to retrieve the Version of the CF
     *
     * @return VersionInformation
     * Version Information of the CF.
     */
    public ComponentVersionInformation getVersion() {
        return version;
    }

    /**
     * Function to set the Componenet Type for this CF
     *
     * @param p_compType The Componenet Type to which this CF has to be set.
     */
    public void setComponentType(BiCNetComponentType p_compType) {
        componentType = p_compType;
    }

    /**
     * Function to set the Description of the CF
     *
     * @param p_strDecs The String to which this CF's description should be set.
     */
    public void setDescription(String p_strDecs) {
        description = p_strDecs;
    }

    /**
     * Function to set the Name of the CF
     *
     * @param p_strName The String to which this CF's name should be set.
     */
    public void setName(String p_strName) {
        name = p_strName;
    }

    /**
     * Function to set the Version of the CF
     *
     * @param p_version The Version to which this CF's version should be set.
     */
    public void setVersion(ComponentVersionInformation p_version) {
        version = p_version;
    }

    /**
     * Function to trace out the complete Object/
     *
     * @return String
     * The String representation of the Object.
     */
    public String getTraceString() {

        return " Name : "
                + name
                + " Description : "
                + description
                + " Type : "
                + componentType
                + " Version Info : "
                + version;

    }

    /**
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return componentType.guiLabel();
    }

    /**
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        boolean bEquals = false;
        if (obj instanceof BSTransBicNetCFInfo) {
            BSTransBicNetCFInfo transObj = (BSTransBicNetCFInfo) obj;
            String strCFID = getCFid();
            String strOtherID = transObj.getCFid();
            bEquals = strCFID.equals(strOtherID);
        }
        return bEquals;
    }

    /**
     * Function to set the CF to Unavailable. The state of the CF will be changed to Unavailable
     */
    public void setCFAsUnavailable() {
        isAvailable = false;
    }

    /**
     * Function to set the CF to available. The state of the CF will be changed to available
     */
    public void setCFAsAvailable() {
        isAvailable = true;
    }

    /**
     * This function returns true if the state of this CF indicates that
     * it is available. A return of false indicates that the CF is unavailable
     *
     * @return boolean True indicates that the CF is available.
     */
    public boolean isCFAvailable() {
        return isAvailable;
    }

}
