package com.ossnms.bicnet.securitymanagement.api.persistence.dao.accessrights;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.IBaseDAO;
import com.ossnms.bicnet.securitymanagement.persistence.model.accessrights.USMSecurableElementContainer;

import java.util.List;

/**
 * created on 24/9/2014
 */
public interface IUSMSecurableElementContainerDao extends IBaseDAO<USMSecurableElementContainer, String> {
    void loadSecurableElements(USMSecurableElementContainer container);
    void loadChildContainers(USMSecurableElementContainer container);
    void loadParentContainers(USMSecurableElementContainer container);

    List<USMSecurableElementContainer> findByFunction(String functionId);
}
