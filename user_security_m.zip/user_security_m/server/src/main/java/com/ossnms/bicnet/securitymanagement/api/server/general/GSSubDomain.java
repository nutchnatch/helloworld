package com.ossnms.bicnet.securitymanagement.api.server.general;

/**
 * Defines the supported subdomains in General Settings
 */
public enum GSSubDomain {
    SECURITY_SETTINGS,
    PASSWORD_POLICY,
    SINGLE_SIGN_ON,
    LDAP_AUTHENTICATION,
    PASSWORD_VALIDATION_RULES,
    RADIUS_AUTHENTICATION
}
