/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AAClientCacheData
 * Author      	Babu B
 * Substitute	Jogender Singh
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.CLIENT.AUTHORIZE
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.auth;

import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
* This class holds the security data relevant for a specific user.
* 
* It holds the following data
* List of Domains accessible to the user
* List of policies associated with each domain that the user has been granted access to.
* 
*/
public class AAClientCacheData implements Serializable {

	/**
     * 
     */
    private static final long serialVersionUID = 1L;

	/**
	 * Domain ID and Policy List mapping collection
	 */
	public static class ClientMapping implements Serializable {
		/**
         * 
         */
        private static final long serialVersionUID = 1L;

        public int domainId;
		public List<Integer> policyIds;

		/**
		 * This class defines the mapping between domain and policy
		 */
		public ClientMapping() {
			super();

			domainId = -1;
			policyIds = new ArrayList<>();
		}

		/* (non-Javadoc)
		 * @see java.lang.Object#toString()
		 */
		@Override
        public String toString() {
			return "Domain ID : "	+ domainId + " PolicyID List : " + policyIds;
		}
	}
	/**
	 * List of ClientMapping
	 */
	private List<ClientMapping> vecClientMapping;
	/**
	 *  List of Policies
	 */
	private List<PAPolicyData> policies;

	/**
	 * Default Constructor
	 */
	public AAClientCacheData() {
		super();

		vecClientMapping = new ArrayList<>();
		policies = new ArrayList<>();
	}

	/**
	 * Returns the all policies which retrieved at client logged in time
	 * @return List - List of the policies
	 */
	public List<PAPolicyData> getPolicies() {
		return policies;
	}

	/**
	 * Sets the all policies which retrieved at client logged in time
	 * @param policyList - List of the policies
	 */
	public void setPolicies(List<PAPolicyData> policyList) {
		policies = policyList;
	}

	/**
	  * Returns the all client cache mapping which retrieved at client logged in time
	  * @return List - List of the mapping
	  */
	public List<ClientMapping> getClientMappingVector() {
		return vecClientMapping;
	}

	/**
	  * Sets the all client cache mapping which retrieved at client logged in time
	  * @param cliMappingList - List of the mapping
	  */
	public void setClientMappingVector(List<ClientMapping> cliMappingList) {
		vecClientMapping = cliMappingList;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
    public String toString() {
		return "Client Mapping : "+ vecClientMapping	+ " Policies : " + policies;
	}

}