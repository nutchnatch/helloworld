package com.ossnms.bicnet.securitymanagement.common.auth;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;

import java.io.Serializable;

/**
 * This class will be used as a DTO, between client and server,
 * regarding to the activation status of password verification rules.
 */
public class PasswordValidationRulesConfigurationData implements Serializable {

    private static final long serialVersionUID = -306108301293779078L;

    /**
     * Field where is configured if the password must be
     */
    private boolean passwordMustBeDifferentFromName;
    private boolean passwordMustBeDifferentFromEmployeeNumber;
    private boolean passwordMustBeDifferentFromDate;
    private boolean passwordMustNotHaveSpaces;

    public PasswordValidationRulesConfigurationData(){
    }

    public PasswordValidationRulesConfigurationData(boolean passwordMustBeDifferentFromName, boolean passwordMustBeDifferentFromEmployeeNumber,
                                                    boolean passwordMustBeDifferentFromDate, boolean passwordMustNotHaveSpaces){

        this.passwordMustBeDifferentFromDate = passwordMustBeDifferentFromDate;
        this.passwordMustBeDifferentFromName = passwordMustBeDifferentFromName;
        this.passwordMustBeDifferentFromEmployeeNumber = passwordMustBeDifferentFromEmployeeNumber;
        this.passwordMustNotHaveSpaces = passwordMustNotHaveSpaces;

    }

    public boolean isPasswordMustBeDifferentFromName() {
        return passwordMustBeDifferentFromName;
    }

    public void setPasswordMustBeDifferentFromName(boolean passwordMustBeDifferentFromName) {
        this.passwordMustBeDifferentFromName = passwordMustBeDifferentFromName;
    }

    public boolean isPasswordMustBeDifferentFromEmployeeNumber() {
        return passwordMustBeDifferentFromEmployeeNumber;
    }

    public void setPasswordMustBeDifferentFromEmployeeNumber(boolean passwordMustBeDifferentFromEmployeeNumber) {
        this.passwordMustBeDifferentFromEmployeeNumber = passwordMustBeDifferentFromEmployeeNumber;
    }

    public boolean isPasswordMustBeDifferentFromDate() {
        return passwordMustBeDifferentFromDate;
    }

    public void setPasswordMustBeDifferentFromDate(boolean passwordMustBeDifferentFromDate) {
        this.passwordMustBeDifferentFromDate = passwordMustBeDifferentFromDate;
    }

    public boolean isPasswordMustNotHaveSpaces() {
        return passwordMustNotHaveSpaces;
    }

    public void setPasswordMustNotHaveSpaces(boolean passwordMustNotHaveSpaces) {
        this.passwordMustNotHaveSpaces = passwordMustNotHaveSpaces;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){ return true; }
        if (o == null || getClass() != o.getClass()){ return false; }

        PasswordValidationRulesConfigurationData that = (PasswordValidationRulesConfigurationData) o;

        if (passwordMustBeDifferentFromName != that.passwordMustBeDifferentFromName){ return false; }
        if (passwordMustBeDifferentFromEmployeeNumber != that.passwordMustBeDifferentFromEmployeeNumber){ return false; }
        if (passwordMustNotHaveSpaces != that.passwordMustNotHaveSpaces){ return false; }
        return passwordMustBeDifferentFromDate == that.passwordMustBeDifferentFromDate;

    }

    @Override
    public int hashCode() {
        int result = (passwordMustBeDifferentFromName ? 1 : 0);
        result = 31 * result + (passwordMustBeDifferentFromEmployeeNumber ? 1 : 0);
        result = 31 * result + (passwordMustNotHaveSpaces ? 1 : 0);
        result = 31 * result + (passwordMustBeDifferentFromDate ? 1 : 0);
        return result;
    }

    /**
     * This method is responsible for extracting a PasswordValidationRulesConfigurationData from USMMessage
     * @param msg
     *            USMMessage which encapsulates a PasswordValidationRulesConfigurationData
     */
    public void popMe(USMMessage msg) {

        setPasswordMustNotHaveSpaces(msg.popBoolean());
        setPasswordMustBeDifferentFromName(msg.popBoolean());
        setPasswordMustBeDifferentFromEmployeeNumber(msg.popBoolean());
        setPasswordMustBeDifferentFromDate(msg.popBoolean());

    }

    /**
     * This Method is responsible for encapsulating a PasswordValidationRulesConfigurationData into USMMessage
     * @param msg
     *               USMMessage which encapsulates a PasswordValidationRulesConfigurationData
     */
    public void pushMe(USMMessage msg) {

        msg.pushBoolean(isPasswordMustBeDifferentFromDate());
        msg.pushBoolean(isPasswordMustBeDifferentFromEmployeeNumber());
        msg.pushBoolean(isPasswordMustBeDifferentFromName());
        msg.pushBoolean(isPasswordMustNotHaveSpaces());

    }

}
