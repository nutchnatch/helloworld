/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	IScsControllableImpl
 * Author      	Muyeen Munaver
 * Substitute	Asifullakhan
 * Created on	02-09-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Muyeen Munaver	CF000582 - InvalidAuthorizationInfoException in getSystemAccountContext()
 * 19-Jan-2005	Muyeen Munaver	CF000297 - Sync Step 1a)
 * 18-01-2005	Asif			CF001111 - Login Failure - Internal error occured Check the traces and try again.
 * 11-Feb-2005	Asif			CF000845 - System Event Log Entries 
 * 21-Feb-2005	Asif 			CF001042 - Connect to LDAP Service 
 * 14-Apr-2005	Muyeen Munaver	CF001025	Stop the Server - message to the clients
 * 05-May-2005  Babu B          CF001312   Master-Master Replication for Sun ONE DS
 * 27-June-2007	Shrinidhi G V 	CF004252 -13 - NE activated/resync => Source in Sys Log is not NE ID name (ex. EM/NE)
 * 27-June-2007	Shrinidhi G V 	CF004252 -20 - NE activated/resync => Source in Sys Log is not NE ID name (ex. EM/NE)
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server;

import com.ossnms.bicnet.bcb.facade.scs.IScsControllable;
import com.ossnms.bicnet.bcb.facade.security.ILocalSecurityProviderFacade;
import com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.messaging.BiCNetMessageLayer;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcherConfig;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.ManagedObjectType;
import com.ossnms.bicnet.bcb.model.common.AdministrativeState;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.IBiCNetComponentId;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.bcb.model.common.SyncCategory;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;
import com.ossnms.bicnet.bcb.model.platform.NotificationType;
import com.ossnms.bicnet.bcb.model.scs.ScsComponentState;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncMode;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.bicnet.messaging.BiCNetMessageDispatcherFactory;
import com.ossnms.bicnet.messaging.util.BiCNetNotificationTypeBuilder;
import com.ossnms.bicnet.securitymanagement.api.server.basic.notification.INotificationHandler;
import com.ossnms.bicnet.securitymanagement.common.auth.AAMessageType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.server.alarming.ALServerLifeCycleController;
import com.ossnms.bicnet.securitymanagement.server.auth.AADummyLocalSecurityProviderFacadeImpl;
import com.ossnms.bicnet.securitymanagement.server.auth.AADummySecurityProviderFacadeImpl;
import com.ossnms.bicnet.securitymanagement.server.auth.AALocalSecurityProviderFacadeImpl;
import com.ossnms.bicnet.securitymanagement.server.auth.AASecurityProviderFacadeImpl;
import com.ossnms.bicnet.securitymanagement.server.auth.AAServerLifeCycleController;
import com.ossnms.bicnet.securitymanagement.server.basic.USMServerLifeCycleController;
import com.ossnms.bicnet.securitymanagement.server.basic.USMServerLifeCycleControllerIfc;
import com.ossnms.bicnet.securitymanagement.server.basic.notification.USMMessageListener;
import com.ossnms.bicnet.securitymanagement.server.basic.notification.USMNotifier;
import com.ossnms.bicnet.securitymanagement.server.bicnetserver.BSServerLifeCycleController;
import com.ossnms.bicnet.securitymanagement.server.bicnetserver.BSSubsystemSAP;
import com.ossnms.bicnet.securitymanagement.server.domain.DCServerLifeCycleController;
import com.ossnms.bicnet.securitymanagement.server.general.GeneralServerLifeCycleController;
import com.ossnms.bicnet.securitymanagement.server.logging.LMInterFace;
import com.ossnms.bicnet.securitymanagement.server.policy.PAServerLifeCycleController;
import com.ossnms.bicnet.securitymanagement.server.useradministration.UAServerLifeCycleController;
import org.apache.log4j.Logger;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Represents a singleton.
 *
 * This class provides implementation for the IScsControllable 
 * interface. 
 */
public final class IScsControllableImpl implements IScsControllable {

	/**
	 * Data member to hold the Logger for tracing.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(IScsControllableImpl.class);

	/**
	 * Holds singleton instance
	 */
	private static IScsControllableImpl instance = new IScsControllableImpl();

	/**
	 * Data member to hold whether sync is supported or not.
	 */
	private static final boolean USM_SYNC_SUPPORTED = true;

	/**
	 * Data member to hold whether stopping is supported or not.
	 */
	private static final boolean USM_STOP_SUPPORTED = false;

	/**
	 * Data member to hold whether start is supported or not.
	 */
	private static final boolean USM_START_SUPPORTED = false;

	/**
	 * Data member to hold the Sync State of the USM component
	 */
	private static ScsSyncState usmSyncState = ScsSyncState.OUT_OF_SYNC;

	/**
	 * Data member to hold the Operational State of the USM component
	 */
	private static OperationalState usmOperationalState = OperationalState.DISABLED;

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#start(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
	@Override
    public void start(ISessionContext sessionContext) throws BcbException {
		LOGGER.debug("Entering start()");

		// There are no operations that are done in the start. Rather,
		// all initialization is done in the init.

		LOGGER.debug("Exiting start()");
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#init(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
	@Override
    public void init(ISessionContext sessionContext) throws BcbException {
		LOGGER.debug("Entering init()");
		final String strInitialize = "initialize";

		// We have a catch-22 situation here. SCS initializes CF USM.
		// CF USM should be given a valid context at the time of call, but SCS should ask CF USM for the ctx
		// So there is a problem. Therefore, it has been decided that SCS when it calls the init can do so with 
		// a null ctx. So we use a local ctx ignoring the one given by SCS.
		setOperationState(OperationalState.DISABLED);
		setSynchronizationState(ScsSyncState.SYNCHRONIZING);

		ISessionContext ctx =
			getLocalSecurityProviderFacade().getSystemAccountContext();
		LMInterFace.getInstance().createSecuritySystemEventRecord(
			ctx,
			USMCommonStrings.IDS_USM_START_USM_INITIALIZED,
			LogSeverity.MESSAGE,BiCNetComponentType.SECURITY_MANAGER.guiLabel());

		USMServerLifeCycleController.getInstance().setInitialized(
			false,
			"Start of initialization of USM");

		// The following is the order that should be followed for the initialization 
		// of the subsystems

		//Register for ldap reconnect
		CentralNotificationHandler handler = new CentralNotificationHandler();
		USMNotifier.getInstance().register(handler);

//		LDAPNotificationHandler ldapHandler = new LDAPNotificationHandler();
//		LWUpdateRegistrar.getInstance().register(ldapHandler);

		boolean bInitResult = initReInitInOrder(strInitialize);
		ctx = getLocalSecurityProviderFacade().getSystemAccountContext();
		if (bInitResult) {
			setOperationState(OperationalState.ENABLED);
			setSynchronizationState(ScsSyncState.SYNCHRONIZED);

			// SCS is responsible for initializing CF USM. But CF USM needs a context to log the
			// init. But SCS does not have it. Therefore as a work around, at this point, CF USM Shoudl
			// use the temp Context.
			LMInterFace.getInstance().createSecuritySystemEventRecord(
				ctx,
				USMCommonStrings.IDS_USM_END_USM_INITIALIZED,
				LogSeverity.MESSAGE,BiCNetComponentType.SECURITY_MANAGER.guiLabel());

			USMServerLifeCycleController.getInstance().setInitialized(
				true,
				"Completed initialization of USM");
		} else {
			setOperationState(OperationalState.DISABLED);
			setSynchronizationState(ScsSyncState.OUT_OF_SYNC);

			LMInterFace.getInstance().createSecuritySystemEventRecord(
				ctx,
				USMCommonStrings.IDS_USM_ERROR_USM_INITIALIZED,
				LogSeverity.ERROR,BiCNetComponentType.SECURITY_MANAGER.guiLabel());

		}

		initMessageListeners();

		LOGGER.debug("Exiting init()");
	}


	/**
	 * Function to inilialize / re-initialze in the set order
	 * @param p_strFuncName The name of the function to be called.
	 * @return boolean Indicates whether it was possible to do the operation
	 */
	private boolean initReInitInOrder(String p_strFuncName) {
			LOGGER.debug("initReInitInOrder(String p_strFuncName = " + p_strFuncName + ") - entry");

		boolean bInitResult = updateSubsystem(USMServerLifeCycleController.class, p_strFuncName);

		boolean bSecurityChkDisabled =
			USMCommonHelper.isSecurityCheckDisabled();

		if ((!bSecurityChkDisabled) && (bInitResult)) {
			// Only if the Security Check is enabled should we do all the
			// things. Else we simply say we are ready.
			bInitResult =
				updateSubsystem(
						GeneralServerLifeCycleController.class,
						p_strFuncName);
			if (bInitResult) {
				bInitResult =
					updateSubsystem(
						UAServerLifeCycleController.class,
						p_strFuncName);
			}

			if (bInitResult) {
				bInitResult =
					updateSubsystem(
						PAServerLifeCycleController.class,
						p_strFuncName);
			}

			if (bInitResult) {
				bInitResult =
					updateSubsystem(
						DCServerLifeCycleController.class,
						p_strFuncName);
			}

			if (bInitResult) {
				bInitResult =
					updateSubsystem(
						BSServerLifeCycleController.class,
						p_strFuncName);
			}

			if (bInitResult) {
				bInitResult =
					updateSubsystem(
						AAServerLifeCycleController.class,
						p_strFuncName);
			}

			if (bInitResult) {
				bInitResult =
					updateSubsystem(
						ALServerLifeCycleController.class,
						p_strFuncName);
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"initReInitInOrder(String) - exit - returning" + bInitResult);
		}
		return bInitResult;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#shutDown(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
	@Override
    public void shutDown(ISessionContext sessionContext) throws BcbException {
		LOGGER.debug("Entering shutDown()");
		final String strCleanup = "cleanup";

		removeMessageListeners();

		LMInterFace.getInstance().createSecuritySystemEventRecord(
			sessionContext,
			USMCommonStrings.IDS_USM_START_USM_FINALIZED,
			LogSeverity.MESSAGE,BiCNetComponentType.SECURITY_MANAGER.guiLabel());

		// The following is the order that should be followed for the initialization 
		// of the subsystems.

		// We do not do any specialized handling for shutdown. Even if one of the systems had a 
		// problem, we continue with the rest of them.
		boolean bSecurityChkDisabled =
			USMCommonHelper.isSecurityCheckDisabled();

		if (!bSecurityChkDisabled) {
			sendNotifToClientsOfShutDown();

			updateSubsystem(ALServerLifeCycleController.class, strCleanup);
			updateSubsystem(AAServerLifeCycleController.class, strCleanup);
			updateSubsystem(BSServerLifeCycleController.class, strCleanup);
			updateSubsystem(DCServerLifeCycleController.class, strCleanup);
			updateSubsystem(PAServerLifeCycleController.class, strCleanup);
			updateSubsystem(UAServerLifeCycleController.class, strCleanup);
			updateSubsystem(
					GeneralServerLifeCycleController.class,
					strCleanup);
//			updateSubsystem(LWLifecycleController.class, strCleanup);
		}

		updateSubsystem(USMServerLifeCycleController.class, strCleanup);

		USMServerLifeCycleController.getInstance().setInitialized(
			false,
			"Shutdown of USM called.");

		setOperationState(OperationalState.DISABLED);

		LMInterFace.getInstance().createSecuritySystemEventRecord(
			sessionContext,
			USMCommonStrings.IDS_USM_END_USM_FINALIZED,
			LogSeverity.MESSAGE,BiCNetComponentType.SECURITY_MANAGER.guiLabel());

		LOGGER.debug("Exiting shutDown()");
	}

	/**
	 * Function to re-initialize all the subsystems. The main work of the subsystems is
	 * to recache the data
	 * @param p_Ctx The Session Context of the user who has started the re-initialize 
	 * @throws BcbException Exception thrown if there is some problem.
	 */
	public void reinitialize(ISessionContext p_Ctx) throws BcbException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"reinitialize(ISessionContext p_Ctx = " + p_Ctx + ") - entry");
		}
		final String strReInitialize = "reinitialize";

		setOperationState(OperationalState.DISABLED);
		setSynchronizationState(ScsSyncState.SYNCHRONIZING);

		ISessionContext ctx =
			getLocalSecurityProviderFacade().getSystemAccountContext();
		LMInterFace.getInstance().createSecuritySystemEventRecord(
			ctx,
			USMCommonStrings.IDS_USM_START_USM_REINITIALIZE,
			LogSeverity.MESSAGE,BiCNetComponentType.SECURITY_MANAGER.guiLabel());

		USMServerLifeCycleController.getInstance().setInitialized(
			false,
			"Start of re-initialization of USM");

		// The following is the order that should be followed for the initialization 
		// of the subsystems

		boolean bInitResult = initReInitInOrder(strReInitialize);
		ctx = getLocalSecurityProviderFacade().getSystemAccountContext();
		if (bInitResult) {
			// SCS is responsible for initializing CF USM. But CF USM needs a context to log the
			// init. But SCS does not have it. Therefore as a work around, at this point, CF USM Shoudl
			// use the temp Context.
			LMInterFace.getInstance().createSecuritySystemEventRecord(
				ctx,
				USMCommonStrings.IDS_USM_END_USM_REINITIALIZE,
				LogSeverity.MESSAGE,BiCNetComponentType.SECURITY_MANAGER.guiLabel());

			USMServerLifeCycleController.getInstance().setInitialized(
				true,
				"Completed re-initialization of USM");

			USMMessage msg =
				new USMMessage(
					USMBaseMsgType.BASIC_SERVER_REINITIALIZED,
					USMMessage.USMMESSAGE_NOTIFICATION);
			USMNotifier.getInstance().sendNotification(msg);

		} else {
			setOperationState(OperationalState.DISABLED);
			setSynchronizationState(ScsSyncState.OUT_OF_SYNC);

			LMInterFace.getInstance().createSecuritySystemEventRecord(
				ctx,
				USMCommonStrings.IDS_USM_ERROR_USM_REINITIALIZE,
				LogSeverity.ERROR,BiCNetComponentType.SECURITY_MANAGER.guiLabel());

		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("reinitialize(ISessionContext) - exit");
		}
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#stop(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
	@Override
    public void stop(ISessionContext sessionContext) throws BcbException {
		// Nothing is done here. Rather all cleanup will happen in stop.
		LOGGER.debug("Entering stop()");

		UnsupportedOperationException unsupportedEx =
			new UnsupportedOperationException("This operation is not supported by USM.");

		LOGGER.debug("Exiting stop()");

		throw unsupportedEx;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#getState(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
	@Override
    public ScsComponentState getState(ISessionContext sessionContext)
		throws BcbException {
		LOGGER.debug("Entering getState");

		ScsComponentState usmState =
			new ScsComponentState(
				AdministrativeState.UNLOCKED,
				null,
				usmOperationalState,
				usmSyncState);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering getState. Returning : " + usmState);
		}

		return usmState;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#isStartSupported(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
	@Override
    public boolean isStartSupported(ISessionContext sessionContext)
		throws BcbException {
		LOGGER.debug("Entering isStartSupported");

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering isStartSupported. Returning : "
					+ USM_START_SUPPORTED);
		}

		return USM_START_SUPPORTED;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#isStopSupported(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
	@Override
    public boolean isStopSupported(ISessionContext sessionContext)
		throws BcbException {
		LOGGER.debug("Entering isStopSupported");

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering isStopSupported. Returning : " + USM_STOP_SUPPORTED);
		}

		return USM_STOP_SUPPORTED;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#isSyncSupported(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
	@Override
    public boolean isSyncSupported(ISessionContext sessionContext)
		throws BcbException {
		LOGGER.debug("Entering isSyncSupported");

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering isSyncSupported. Returning : " + USM_SYNC_SUPPORTED);
		}

		return USM_SYNC_SUPPORTED;
	}

	/**
	 * prevents instantiation
	 */
	private IScsControllableImpl() {
	}

	/**
	 * Returns the singleton instance.
	 * @return	the singleton instance
	 */
	public static IScsControllableImpl getInstance() {
		return instance;
	}

	/**
	 * Helper function to initialize the class that has been passed. Operations include -
	 * 1. Calling the static method getInstance()
	 * 2. Calling the method initialize on the returned class
	 * 
	 * This function assumes that the passed class has a static getInstance() method and
	 * a initialize method for the purpouse of initilalization
	 * 
	 * @param clazz 
	 * 			The Class that should be initilaized.
	 * 
	 * @return boolean 
	 * 			Indicates whether it was possible to initialize correctly. True indicates success
	 */
	private boolean updateSubsystem(Class<? extends USMServerLifeCycleControllerIfc> clazz, String functionName) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering the updateSubsystem for the class : "
					+ clazz.getName()
					+ " Function call : "
					+ functionName);
		}

		boolean bInitialized = false;
		try {
			Method mthGetInstance = clazz.getMethod("getInstance");
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(
					"Successfully got a handle to the getInstance method for the :"
						+ clazz.getName());
			}

			Object objLifeCycleCtl = mthGetInstance.invoke(null);
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(
					"Successfully invoked the getInstance method for the :"
						+ clazz.getName());
			}

			if (objLifeCycleCtl == null) {
				LOGGER.error("Object returned is null.");
				return bInitialized;
			}

			Method mthInitialize =
				objLifeCycleCtl.getClass().getMethod(functionName);
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(
					"Successfully got a handle to the initialize method for the :"
						+ clazz.getName());
			}
			Object objResult = mthInitialize.invoke(objLifeCycleCtl);
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(
					"Successfully invoked the initiliaze method for the :"
						+ clazz.getName());
			}

			bInitialized = (Boolean) objResult;

		} catch (SecurityException e) {
			LOGGER.error("Security Exception.", e);
		} catch (NoSuchMethodException e) {
			LOGGER.error("NoSuchMethodException Exception.", e);
		} catch (IllegalArgumentException e) {
			LOGGER.error("IllegalArgumentException Exception.", e);
		} catch (IllegalAccessException e) {
			LOGGER.error("IllegalAccessException Exception.", e);
		} catch (InvocationTargetException e) {
			LOGGER.error("InvocationTargetException Exception.", e);
		} catch (Exception e) {
			LOGGER.error("Some exception was thrown, who threw this???", e);
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering the updateSubsystem for the class : "
					+ clazz.getName());
		}

		if (!bInitialized) {
			LOGGER.error(
				"Could not perform : "
					+ functionName
					+ " successfully for : "
					+ clazz.getName());
		}

		//As a result of command log entries, we are making it more robust
		//This is an indirect consequece of command log entries
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering the updateSubsystem for the class : "
					+ clazz.getName()
					+ " Function call : "
					+ functionName
					+ " Result : "
					+ bInitialized);
		}
		return bInitialized;

	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#doSync(com.ossnms.bicnet.bcb.facade.security.ISessionContext, com.ossnms.bicnet.bcb.model.common.IBiCNetComponentId[], com.ossnms.bicnet.bcb.model.scs.ScsSyncMode)
	 */
	@Override
    public void doSync(ISessionContext sessionContext, IBiCNetComponentId[] with, ScsSyncMode syncMode, SyncCategory syncCategory)
            throws BcbException {
		LOGGER.debug("Entering doSync()");

		if(!SyncCategory.ALL.equals(syncCategory)) {
		    LOGGER.debug("doForcedSync() : Exit - skip synchronization: no need to sync this syncCategory");
            return;
        }
		
		LMInterFace.getInstance().createSecuritySystemEventRecord(
			sessionContext,
			USMCommonStrings.IDS_USM_START_USM_SYNCH,
			LogSeverity.MESSAGE,BiCNetComponentType.SECURITY_MANAGER.guiLabel());

		LMInterFace.getInstance().createSecuritySystemEventRecord(
			sessionContext,
			USMCommonStrings.IDS_USM_END_USM_SYNCH,
			LogSeverity.MESSAGE,BiCNetComponentType.SECURITY_MANAGER.guiLabel());

		LOGGER.debug("Exiting doSync()");
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#doForcedSync(com.ossnms.bicnet.bcb.facade.security.ISessionContext, com.ossnms.bicnet.bcb.model.common.IBiCNetComponentId[], com.ossnms.bicnet.bcb.model.scs.ScsSyncMode)
	 */
	@Override
    public void doForcedSync(ISessionContext sessionContext, IBiCNetComponentId[] with, ScsSyncMode syncMode, SyncCategory syncCategory)
            throws BcbException {
		LOGGER.debug("Entering doForcedSync()");

		if(!SyncCategory.ALL.equals(syncCategory)) {
		    LOGGER.debug("doForcedSync() : Exit - skip synchronization: no need to sync this syncCategory");
            return;
        }
		
		LMInterFace.getInstance().createSecuritySystemEventRecord(
			sessionContext,
			USMCommonStrings.IDS_USM_START_USM_FORCED_SYNCH,
			LogSeverity.MESSAGE,BiCNetComponentType.SECURITY_MANAGER.guiLabel());

		LMInterFace.getInstance().createSecuritySystemEventRecord(
			sessionContext,
			USMCommonStrings.IDS_USM_END_USM_FORCED_SYNCH,
			LogSeverity.MESSAGE,BiCNetComponentType.SECURITY_MANAGER.guiLabel());

		LOGGER.debug("Exiting doForcedSync()");
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#doFullSync(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
	@Override
    public void doFullSync(ISessionContext sessionContext)
		throws BcbException {

		boolean bSecurityChkDisabled =	USMCommonHelper.isSecurityCheckDisabled();

		LMInterFace.getInstance().createSecuritySystemEventRecord(
			sessionContext,
			USMCommonStrings.IDS_USM_START_USM_FULL_SYNCH,
			LogSeverity.MESSAGE,BiCNetComponentType.SECURITY_MANAGER.guiLabel());

		if (!bSecurityChkDisabled) {
			BSSubsystemSAP.doFullSync(sessionContext);
			reinitialize(sessionContext);
		}

		LMInterFace.getInstance().createSecuritySystemEventRecord(
			sessionContext,
			USMCommonStrings.IDS_USM_END_USM_FULL_SYNCH,
			LogSeverity.MESSAGE,BiCNetComponentType.SECURITY_MANAGER.guiLabel());

	}

	/**
	 * Helper function to get the Provider Facade for Security. Check would be donen
	 * to see whether security is to be disabled or not. And then the correct facade would
	 * be returned.
	 *  
	 * @return ISecurityProviderFacade - The Security provider facade which should be used for the
	 * checks.
	 */
	public static ISecurityProviderFacade getSecurityProviderFacade() {
		LOGGER.debug("Entering getSecurityProviderFacade");

		ISecurityProviderFacade facade;
		boolean bSecurityDisabled = USMCommonHelper.isSecurityCheckDisabled();
		if (bSecurityDisabled) {
			LOGGER.debug(
				"Security has been disabled. Returning a dummy object.");
			facade = AADummySecurityProviderFacadeImpl.getInstance();
		} else {
			LOGGER.debug(
				"Security has been enabled. Returning correct object.");
			facade = AASecurityProviderFacadeImpl.getInstance();
		}

		LOGGER.debug("Exiting getSecurityProviderFacade");
		return facade;
	}

	/**
	 * Helper function to get the Provider Facade for Security. Check would be donen
	 * to see whether security is to be disabled or not. And then the correct facade would
	 * be returned.
	 *  
	 * @return ISecurityProviderFacade - The Security provider facade which should be used for the
	 * checks.
	 */
	public static ILocalSecurityProviderFacade getLocalSecurityProviderFacade() {
		LOGGER.debug("Entering getLocalSecurityProviderFacade");

		ILocalSecurityProviderFacade facade;
		boolean bSecurityDisabled =
			USMCommonHelper.isSecurityCheckDisabled();
		if (bSecurityDisabled) {
			LOGGER.debug(
				"Security has been disabled. Returning a dummy object.");
			facade = AADummyLocalSecurityProviderFacadeImpl.getInstance();
		} else {
			LOGGER.debug(
				"Security has been enabled. Returning correct object.");
			facade = AALocalSecurityProviderFacadeImpl.getInstance();
		}

		LOGGER.debug("Exiting getLocalSecurityProviderFacade");
		return facade;
	}

	/**
	 * Function to set the Synchronization state of USM
	 * @param p_SyncState The new Sync State
	 */
	private void setSynchronizationState(ScsSyncState p_SyncState) {
		usmSyncState = p_SyncState;
	}

	/**
	 * Function to set the operation state of USM module
	 * @param p_OperState The operational state of CF USM
	 */
	private void setOperationState(OperationalState p_OperState) {
		usmOperationalState = p_OperState;
	}

	/**
	 * Helper function to send the notification to the clients that the server has 
	 * been shut down.
	 */
	private void sendNotifToClientsOfShutDown() {
		LOGGER.debug("sendNotifToClientsOfShutDown() 	Entry");

		USMMessage shutDownMsg =
			new USMMessage(
				AAMessageType.AA_NOTIFICATION_SERVER_SHUTDOWN,
				USMMessage.USMMESSAGE_NOTIFICATION);
		String strHostName = USMCommonHelper.getLocalHostName();
		if (strHostName != null) {
			strHostName = "";
		}
		shutDownMsg.pushString(strHostName);
		USMNotifier notifier = USMNotifier.getInstance();
		notifier.sendNotification(shutDownMsg);

		LOGGER.debug("sendNotifToClientsOfShutDown() 	Entry");
	}

	/**
	 * This is the central class which handles notificatin, when LDAP is reconnected and has gone down
	 * so that he can reinitialize his cache.
	 */
	private class CentralNotificationHandler implements INotificationHandler {
		/**
		 * Logger for this class
		 */
		private final Logger LOGGER =
			Logger.getLogger(CentralNotificationHandler.class);

		/* (non-Javadoc)
		 * @see com.ossnms.bicnet.securitymanagement.api.server.basic.notification.INotificationHandler#handleNotification(com.ossnms.bicnet.securitymanagement.common.basic.USMMessage)
		 */
		@Override
        public void handleNotification(USMMessage msg) {
			LOGGER.debug("handleNotification Entry " + msg.getMessageType());

			USMBaseMsgType objMessageType = msg.getMessageType();
			if (USMBaseMsgType.BASIC_LDAP_RECONNECT.equals(objMessageType)) {
				try {
					init(
						getLocalSecurityProviderFacade()
							.getSystemAccountContext());
				} catch (BcbException ex) {
					LOGGER.error("Exception occured while reinitializing ", ex);
				}
			}

			LOGGER.debug("handleNotification Exit");

		}
	}

	/**
	 *
	 */
	private void initMessageListeners() {
		USMMessageListener listener = USMMessageListener.getInstance();
		final IBiCNetMessageDispatcherConfig config = BiCNetMessageDispatcherFactory.getInstance().getDispatcherConfig(BiCNetComponentType.SECURITY_MANAGER);

		config.addListener(BiCNetMessageLayer.SOURCE, listener,
				BiCNetNotificationTypeBuilder.builder()
				.forObject(ManagedObjectType.LICENSE_KEY).notif(NotificationType.OBJECT_DELETION)
				.build());
	}

	/**
	 *
	 */
	private void removeMessageListeners() {
		final IBiCNetMessageDispatcherConfig config = BiCNetMessageDispatcherFactory.getInstance().getDispatcherConfig(BiCNetComponentType.SECURITY_MANAGER);
		config.removeListener(BiCNetMessageLayer.SOURCE, BiCNetNotificationTypeBuilder.builder().all());
	}
}
