/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCDomainConfigurationPOJOImpl
 * Author      	Muyeen Munaver
 * Substitute	Asifullakhan
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CREATE
 * 		:	TNMS.DX2.SM.DOMAIN.CONFIG	   
 * 		:	TNMS.DX2.SM.DOMAIN.VIEW
 * 		:	TNMS.DX2.SM.MAPPING.CREATE
 * 		:	TNMS.DX2.SM.MAPPING.VIEW    
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 10-Feb-2005	Asif 			CF000834 - Command Log Entries 
 * 11-Mar-2005	Asif			CF000845 - System Event Log Entries
 * 26-Apr-2005	Asif			CF000834 - Command Log Entries	CF USM
 * 27-June-2007	Shrinidhi G V 	CF004252 -13 - NE activated/resync => Source in Sys Log is not NE ID name (ex. EM/NE)
 * 27-June-2007	Shrinidhi G V 	CF004252 -20 - NE activated/resync => Source in Sys Log is not NE ID name (ex. EM/NE)
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMenuNameList;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.server.basic.USMAuthorizationHelper;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityDomainConfigurationPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.logging.LMInterFace;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * POJO Implementation class for the Domain Configuration Private Facade
 */
public class DCDomainConfigurationPOJOImpl
	implements ISecurityDomainConfigurationPrivateFacade {

	/**
	* Data member for the Logging of the class.
	*/
	private static final Logger LOGGER = LoggerFactory.getLogger(DCDomainConfigurationPOJOImpl.class);

	/**
	 * {@inheritDoc}
	 */
	@Override
    public USMMessage getAllDomains(ISessionContext ctx)
		throws BcbSecurityException {

		LOGGER.debug("getAllDomains - Enter");

		String strMessage =
			USMCommonHelper.createFormattedString(
				USMCommonStrings.IDS_LG_OPERATION_SELECTED,
					USMMenuNameList.OPERATION_DOMAIN_ADMIN);
		LMInterFace.getInstance().createSecurityCommandRecord(
			ctx,
			strMessage,USMCommonStrings.IDS_APPLICATION_DOMAIN);
		LOGGER.info(ctx + ":" + strMessage);

		USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(
			ctx,
			USMMenuNameList.OPERATION_DOMAIN_ADMIN);

		DCViewDomainConfigController ctl = new DCViewDomainConfigController();
		USMMessage msg = ctl.getDomains();

		LOGGER.debug("getAllDomains - Exit");
		return msg;
	}

	/**
     * {@inheritDoc}
     */
	@Override
    public USMMessage createDomain(ISessionContext ctx, DCDomainData domain) throws BcbSecurityException {
		LOGGER.debug("createDomain - Enter");

		String strMessage = USMCommonHelper.createFormattedString(
				USMCommonStrings.IDS_DC_DOMAIN_DETAIL,
				USMMenuNameList.OPERATION_DOMAIN_NEW,
				domain.getDomainName(),
				domain.getDomainDescr()
		);

		LMInterFace.getInstance().createSecurityCommandRecord(
			ctx,
			strMessage,domain.getDomainName()
		);
		LOGGER.info("{} : {}", ctx, strMessage);

		USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(
			ctx,
			USMMenuNameList.OPERATION_DOMAIN_NEW
		);

		USMMessage msg = createDomainData(ctx, domain);
		LOGGER.debug("createDomain - Exit");
		return msg;
	}

	/**
	 * @param ctx session's context
	 * @param domain domain data
	 * @return USMMessage response
	 */
	USMMessage createDomainData(ISessionContext ctx, DCDomainData domain) {

		LOGGER.debug("createDomainData - Enter");
		DCModifyDomainController ctl = new DCModifyDomainController();

		USMMessage msg = ctl.createDomain(ctx, domain);
		LOGGER.debug("createDomainData - Exit");
		return msg;
	}

	/**
     * {@inheritDoc}
     */
	@Override
    public USMMessage deleteDomain(ISessionContext ctx, List domain)
		throws BcbSecurityException {

		LOGGER.debug("deleteDomain - Enter");

		String strMessage =
			USMCommonHelper.createFormattedString(
				USMCommonStrings.IDS_DC_DOMAIN_DELETED,
					USMMenuNameList.OPERATION_DOMAIN_DELETE,
					Integer.toString(domain.size()));

		LMInterFace.getInstance().createSecurityCommandRecord(
			ctx,
			strMessage,USMCommonStrings.IDS_APPLICATION_DOMAIN);
		LOGGER.info(ctx + ":" + strMessage);

		USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(
			ctx,
			USMMenuNameList.OPERATION_DOMAIN_DELETE);

		DCViewDomainConfigController ctl = new DCViewDomainConfigController();
		USMMessage msg = ctl.deleteDomain(ctx, domain);
		LOGGER.debug("deleteDomain - Exit");
		return msg;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public USMMessage modifyDomain(ISessionContext ctx,	DCDomainData domain) throws BcbSecurityException {

		LOGGER.debug("modifyDomain - Enter");

		String strMessage = USMCommonHelper.createFormattedString(
				USMCommonStrings.IDS_DC_DOMAIN_DETAIL,
				USMMenuNameList.OPERATION_DOMAIN_MODIFY,
				domain.getDomainName(),
				domain.getDomainDescr()
		);

		LMInterFace.getInstance().createSecurityCommandRecord(
				ctx,
				strMessage, domain.getDomainName()
		);

		LOGGER.info(ctx + ":" + strMessage);

		USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(
				ctx,
				USMMenuNameList.OPERATION_DOMAIN_MODIFY
		);

		USMMessage msg = modifyDomainData(ctx, domain);
		LOGGER.debug("modifyDomain - Exit");

		return msg;
	}
	/**
	 * @param ctx session's context
	 * @param domain domain data
	 * @return USMMessage
	 */
	USMMessage modifyDomainData(ISessionContext ctx, DCDomainData domain) {

		LOGGER.debug("modifyDomainData - Enter");
		DCModifyDomainController ctl = new DCModifyDomainController();

		USMMessage msg = ctl.modifyDomain(ctx, domain);
		LOGGER.debug("modifyDomainData - Exit");
		return msg;
	}

	/**
     * {@inheritDoc}
     */
	@Override
    public USMMessage getServersForDomain(
		ISessionContext ctx,
		DCDomainData domain,
		boolean assigned,
		boolean domainConfigWdw)
		throws BcbSecurityException {

		LOGGER.debug("getServersForDomain - Enter");

		//The same method gets called for retrieving the securable objects from domain configuration window
		//as well as the create/modify domain window. 
		String securityString =
			getSecurityStringForDomainOperation(
				domain,
				assigned,
				domainConfigWdw);

		String commandString =
			getCommandStringToLogForDomainOperation(
				domain,
				assigned,
				domainConfigWdw);

		//It can be null in the case, the user has selected the domain modify window and the case
		//where the assigned objects are fetched. Since we log the entry when the unassigned objects are
		//fetched, it is sufficient
		if (null != commandString) {
			LMInterFace.getInstance().createSecurityCommandRecord(
				ctx,
				commandString,domain.getDomainName());
			LOGGER.info(ctx + ":" + commandString);
		}

		USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(
			ctx,
			securityString);

		DCModifyDomainController ctl = new DCModifyDomainController();
		USMMessage msg = ctl.getFirstLevelSecurableObjects(domain);
		LOGGER.debug("getServersForDomain - Exit");
		return msg;

	}
	/**
	* We need to get the command string to log 
	* @param domain domain data
	* @param assigned true if is assigned
	* @param domainConfigWdw
	* @return
	*/
	private String getCommandStringToLogForDomainOperation(
		DCDomainData domain,
		boolean assigned,
		boolean domainConfigWdw) {

		String commandString = null;
		if (domainConfigWdw) {
			commandString =
				USMCommonHelper.createFormattedString(
					USMCommonStrings.IDS_DC_DOMAIN_SELECTED,
						USMMenuNameList.OPERATION_DOMAIN_ADMIN,
						domain.getDomainName());

		} else {
			//If it is to get all the securable objects, it must be the create domain window
			if (domain.isGlobalDomain()) {
				commandString =
					USMCommonHelper.createFormattedString(
						USMCommonStrings.IDS_LG_OPERATION_SELECTED,
							USMMenuNameList.OPERATION_DOMAIN_NEW);

			}
			//The other option is, it is called for modify domain, but we might get two
			//requests for the same, currently we check it is the only one time we check
			else {
				if (assigned) {
					commandString =
						USMCommonHelper.createFormattedString(
							USMCommonStrings.IDS_LG_OPERATION_SELECTED_FOR,
								USMMenuNameList.OPERATION_DOMAIN_MODIFY,
								domain.getDomainName());
				}
			}
		}
		LOGGER.info("The command string to be logged " + commandString);
		return commandString;
	}

	/**
	 * We need to get the security string which has to be checked. The logic is explained in the function itself 
	 * @param domain
	 * @param assigned
	 * @param domainConfigWdw
	 * @return
	 */
	private String getSecurityStringForDomainOperation(
		DCDomainData domain,
		boolean assigned,
		boolean domainConfigWdw) {

		//Check if it was called from the domain configuration window.	
		String securityString = USMMenuNameList.OPERATION_DOMAIN_ADMIN;

		//If it was not called from domain configuration window, it could have been called from the create/modify		
		if (!domainConfigWdw) {
			//If it is to get all the securable objects, it must be the create domain window
			if (domain.isGlobalDomain()) {
				securityString = USMMenuNameList.OPERATION_DOMAIN_NEW;
			}
			//The other option is, it is called for modify domain, but we might get two
			//requests for the same, currently we check it is the only one time we check
			else {
				if (assigned) {
					securityString = USMMenuNameList.OPERATION_DOMAIN_MODIFY;
				}
			}
		}
		LOGGER.info("The security string to be logged " + securityString);
		return securityString;
	}

	/**
     * {@inheritDoc}
     */
	@Override
    public USMMessage getObjectsOfServerForDomain(
		ISessionContext ctx,
		DCDomainData domain,
		BSTransBicNetCFInfo server,
		boolean assigned)
		throws BcbSecurityException {

		LOGGER.debug("getObjectsOfServerForDomain - Enter");

		LOGGER.info(
			ctx
				+ ":"
				+ domain.getDomainName()
				+ ":"
				+ server.getName()
				+ ":"
				+ "is fetched\tThis info is not needed to be command logged :)");

		USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(
			ctx,
			USMMenuNameList.OPERATION_DOMAIN_ADMIN);

		DCModifyDomainController ctl = new DCModifyDomainController();
		USMMessage msg =
			ctl.getSecurableObjects(domain, server, assigned);
		LOGGER.debug("getObjectsOfServerForDomain - Exit");
		return msg;
	}

	/**
     * {@inheritDoc}
     */
	@Override
    public USMMessage getAllMappings(ISessionContext ctx)
		throws BcbSecurityException {

		LOGGER.debug("getObjectsOfServerForDomain - Enter");

		String strMessage =
			USMCommonHelper.createFormattedString(
				USMCommonStrings.IDS_LG_OPERATION_SELECTED,
					USMMenuNameList.OPERATION_ACCESS_RIGHTS);

		LMInterFace.getInstance().createSecurityCommandRecord(
			ctx,
			strMessage,USMCommonStrings.IDS_APPLICATION_ACCESS_RIGHTS);

		LOGGER.info(ctx + ":" + strMessage);

		USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(
			ctx,
			USMMenuNameList.OPERATION_ACCESS_RIGHTS);
		DCAccessRightsController ctl = new DCAccessRightsController();
		USMMessage msg = ctl.getAccessRights();
		LOGGER.debug("getObjectsOfServerForDomain - Exit");
		return msg;

	}

	/**
     * {@inheritDoc}
     */
	@Override
    public USMMessage changeMappings(ISessionContext ctx, List mappings)
		throws BcbSecurityException {

		LOGGER.debug("changeMappings - Enter");

		if (0 != mappings.size()) {
			//Since we know that now the change mappings are currently done for only one domain at a time, we can do this
			String strMessage =
				USMCommonHelper.createFormattedString(
					USMCommonStrings.IDS_DC_DOMAIN_MAPPING_CHANGED,
						USMMenuNameList.OPERATION_DOMAIN_ASSIGN_MAPPINGS,
						mappings.size());
			LMInterFace.getInstance().createSecurityCommandRecord(
				ctx,
				strMessage,USMCommonStrings.IDS_APPLICATION_DOMAIN);
			LOGGER.info(ctx + ":" + strMessage);
		}

		USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(
			ctx,
			USMMenuNameList.OPERATION_DOMAIN_ASSIGN_MAPPINGS_APPLY);
		USMMessage msg = changeMappingData(ctx, mappings);
		LOGGER.debug("changeMappings - Exit");
		return msg;

	}

	USMMessage changeMappingData(ISessionContext ctx, List mappings) {
		LOGGER.debug("changeMappingData - Enter");
		DCDomainMappingController ctl = new DCDomainMappingController();
		USMMessage msg = ctl.changeMappings(ctx, mappings);
		LOGGER.debug("changeMappingData - Exit");
		return msg;
	}


	/**
     * {@inheritDoc}
     */
	@Override
    public USMMessage assignUnassignObjectsToDomain(
		ISessionContext ctx,
		List<BSSecurableObject> objectsToAssign,
		List<BSSecurableObject> objectsToUnassign,
		DCDomainData domain,
		boolean createWindow)
		throws BcbSecurityException {

		LOGGER.debug("assignUnassignObjectsToDomain - Exit");

		String menuEntry = "";
		if (createWindow) {
			menuEntry = USMMenuNameList.OPERATION_DOMAIN_NEW;
		} else {
			menuEntry = USMMenuNameList.OPERATION_DOMAIN_MODIFY;
		}

		//Command log for assigning objects
		String strMessage =
			USMCommonHelper.createFormattedString(
				USMCommonStrings.IDS_DC_ASSIGNED_SEC_OBJECTS,
					menuEntry,
					domain.getDomainName(),
					objectsToAssign.size());
		LMInterFace.getInstance().createSecurityCommandRecord(
			ctx,
			strMessage,domain.getDomainName());
		LOGGER.info(ctx + ":" + strMessage);

		//Command log for un assigning objects....only in case of modify option and not in case of new
		if (menuEntry.equals(USMMenuNameList.OPERATION_DOMAIN_MODIFY)) {
		strMessage =
			USMCommonHelper.createFormattedString(
				USMCommonStrings.IDS_DC_UNASSIGNED_SEC_OBJECTS,
					menuEntry,
					domain.getDomainName(),
					objectsToUnassign.size());
		LMInterFace.getInstance().createSecurityCommandRecord(
			ctx,
			strMessage,domain.getDomainName());
		LOGGER.info(ctx + ":" + strMessage);
		}

		USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(
			ctx,
			menuEntry);

		DCModifyDomainController ctl = new DCModifyDomainController();
		USMMessage msg =
			ctl.assignSecurableObjects(
				objectsToAssign,
				objectsToUnassign,
				domain);
		LOGGER.debug("assignUnassignObjectsToDomain - Exit");
		return msg;
	}

	/**
     * {@inheritDoc}
     */
	@Override
	public USMMessage getAllSecurableObject(ISessionContext context)throws BcbSecurityException {
		
		USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(	context, USMMenuNameList.OPERATION_DOMAIN_ADMIN);
		
		DCModifyDomainController ctl = new DCModifyDomainController();

		return ctl.getAllSecurableObject();
	}
}
