package com.ossnms.bicnet.securitymanagement.server.interfaces;

import com.ossnms.bicnet.bcb.facade.IFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserGroup;

import java.util.List;

/**
 * This is the Private Interface Facade for the User Administration
 */
public interface ISecurityUserAdministrationPrivateFacade extends IFacade {
	/**
	 * Method Description It is responsible for getting all the assigned and unassigned users of a user group
	 * @param sessionContext The Context which identifies the User who has initiated this action.
	 * @param userGroup Contains the data about the usergroup in order to uniquely identify the usergroup
	 * @return USMMessage Contains all the assigned users and unassigned users
	 * @throws BcbSecurityException
	 */
	USMMessage getAllAssignedAndUnassignedUsers(
		ISessionContext sessionContext,
		UAUserGroup userGroup)
		throws BcbSecurityException;

	/**
	 * This Methods is responsible for modifying the attributes of the user group i.e its description or adding more users
	 * @param userGroup contains the data about the usergroup which is to be modified
	 * @param usersForUserGroup List Of UAUser which contains data about all the assigned users
	 * @param mappingsForUserGroup List of domain and policy mappings to assign to the user group. 
	 * @return the result of the operation i.e user is modified successfully or not
	 */
	USMMessage modifyUserGroup(
		ISessionContext sessionContext,
		UAUserGroup userGroup,
		List<String> usersForUserGroup, List<DCDomainMapping> mappingsForUserGroup)
		throws BcbSecurityException;

	/**
	 * This method is responsible for getting all the available user group
	 * @param sessionContext The security context of the user
	 * @param forUserGroupWindow This indicates, whether this method was called for 
	 * User Group window, in which case it has to be logged in command log, indicating the window was opened
	 * False value indicates, that the method was called from the create/modify user window
	 * @return All Available user group
	 * @throws BcbSecurityException
	 */
	USMMessage getAllUserGroup(
		ISessionContext sessionContext,
		boolean forUserGroupWindow)
		throws BcbSecurityException;

	/**
	 * This Method call is responsible for deleting the set of user groups
	 * @param userGroups is a set Of UAUserGroup to be deleted
	 * @return The result of the operation i.e how many user groups are deleted successfully
	 */
	USMMessage deleteUserGroup(ISessionContext sessionContext, List<UAUserGroup> userGroups)
		throws BcbSecurityException;

	/**
	 * This Method call is responsible for the creating the user
	 * @param userGroup contains the data about the user to be created
	 * @param usersForUserGroup contains the users to be assigned to this user group
	 * @param mappingsForUserGroup contains the domain and policy mappings to be assigned to this user group 
	 * @return the result of the operation encapsulated in the USMMessage i.e user is created successfully or the exception if any
	 */
	USMMessage createUserGroup(
		ISessionContext sessionContext,
		UAUserGroup userGroup,
		List<String> usersForUserGroup, List<DCDomainMapping> mappingsForUserGroup)
		throws BcbSecurityException;

	/**
	 * This Method call is responsible for the checking if  user group contains user
	 * @param sessionContext
	 * @param userGroup contain the data about the user to be created
	 * @param user contain the data about the user to be created
	 * @return the result of the operation encapsulated in the USMMessage i.e user is created successfully or the exception if any
	 */
	USMMessage checkUserGroupContainsUser(
		ISessionContext sessionContext,
		String userGroup,
		String user)
		throws BcbSecurityException;
	/**
	 * This Method is responsible Creating a User It throws an exception if any LDAP errors occur or User is already created
	 * @param user Contains the data about user including the Usergroups to which it belongs to.
	 * @return the result of the operation
	 */
	USMMessage createUser(
		ISessionContext sessionContext,
		UAUser user,
		List<String> assignedUserGroups)
		throws BcbSecurityException;

	/**
	 * This Method is responsible for activating the given user accounts. 
	 * @param lstUsers Contains the user ids
	 * @return the result of the operation
	 */
	USMMessage activateUsers(ISessionContext sessionContext, List<String> lstUsers)
		throws BcbSecurityException;

	/**
	 * This Method is responsible for deactivating the given user accounts. 
	 * @param lstUsers Contains the user ids
	 * @return the result of the operation
	 */
	USMMessage deactivateUsers(ISessionContext sessionContext, List<String> lstUsers)
		throws BcbSecurityException;

	/**
	 This Method is responsible for unlocking the given user accounts. 
	 * @param lstUsers Contains the user ids
	 * @return the result of the operation
	 */
	USMMessage unlockUsers(ISessionContext sessionContext, List<String> lstUsers)
		throws BcbSecurityException;

	/**
	 This Method is responsible for "forceful logoff' of the given user accounts. 
	 * @param lstUsers Contains the user ids
	 * @return the result of the operation
	 */
	USMMessage forcedLogoffUsers(ISessionContext sessionContext, List<String> lstUsers)
		throws BcbSecurityException;

	/**
	 * This Method is responsible for deleting a user and throws an exception if the user does not exist
	 * @param users is List of the UAUser
	 * @return result of the operation
	 */
	USMMessage deleteUsers(ISessionContext sessionContext, List<String> users)
		throws BcbSecurityException;

	/**
	 * This method call fetches all the available users
	 * @return All available user of a user
	 */
	USMMessage getAllUsers(ISessionContext sessionContext)
		throws BcbSecurityException;

	/**
	 * Method Description This Method Call is responsible for the getting all the assigned and unassigned usergroups for a user
	 * @param userData contains the data in order to uniquely identify the user
	 * @return USMMessage all the assigned and unassigned usergroups for a user
	 */
	USMMessage getAllAssignedAndUnassignedUsergroups(
		ISessionContext sessionContext,
		String userData)
		throws BcbSecurityException;

	/**
	 * This Method is called for assigning the users to usergroup.
	 * @param userGroupData contains the data about the usergroup in order to uniquely identify the usergroup
	 * @param users is list of UAUser which contains the Unique identity of users.
	 * @return the result of the operation
	 */
	USMMessage assignUsersToUserGroup(
		ISessionContext sessionContext,
		UAUserGroup userGroupData,
		List users)
		throws BcbSecurityException;

	/**
	 * This Method is called for modifying of a user.
	 * @param sessionContext
	 * @param user user information
	 * @param unassignedUgrp list of user groups to unassign
	 * @return the result of the operation
	 */
	USMMessage modifyUser(
		ISessionContext sessionContext,
		UAUser user,
		List<String> unassignedUgrp)
		throws BcbSecurityException;
	/**
	 * This method call fetches all the available users name and id
	 * @return All available user of a user
	 */
	USMMessage getAllUserNameAndID(ISessionContext sessionContext)
		throws BcbSecurityException;

	UAUser getUserByName(ISessionContext ctx, String username) throws BcbSecurityException;

	String getAdminName(ISessionContext ctx) throws BcbSecurityException;

}
