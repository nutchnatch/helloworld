/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCHelper
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CREATE
 * 		:	TNMS.DX2.SM.DOMAIN.CONFIG	   
 * 		:	TNMS.DX2.SM.DOMAIN.VIEW
 * 		:	TNMS.DX2.SM.MAPPING.CREATE
 * 		:	TNMS.DX2.SM.MAPPING.VIEW 
 * 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.common.domain;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;

import java.util.List;

/**
 * This class contains all helper methods or functions that are used within DC
 * Currently list of objects often pushed and popped are here
 */
public class DCHelper {

	/**
	 * This helper function pushes the list of network elements on to the USM
	 * message.
	 * 
	 * @param secObjects
	 *            The List of BSSecurableObject that needs to be pushed onto the
	 *            message
	 * @param message
	 *            The USMMessage onto which the list of network elements need to
	 *            be pushed
	 */
	public static void pushSecurableObjects(List<BSSecurableObject> secObjects, USMMessage message) {
		//Pushes the vector of network elements into the Message
		for (BSSecurableObject secObject : secObjects) {
			secObject.pushTo(message);
		}
		message.pushInteger(secObjects.size());
	}

	/**
	 * This helper function pops the list of network elements from the USM
	 * message on the vector
	 * 
	 * @param msg The USMMessage from which the list of network elements need to be popped from
	 * @param securableObjects Fills up the list of BSSecurableObject from the message
	 */
	public static void popSecurableObjects(USMMessage msg, List<BSSecurableObject> securableObjects) {
		//Pops the the vector of network elements from the Message
		int nSize = msg.popInteger();
		for (int i = 0; i < nSize; ++i) {
			BSSecurableObject neInfo = BSSecurableObject.popMe(msg);
			securableObjects.add(neInfo);
		}
	}

	/**
	 * This helper function pushes the list of servers on to the USM message.
	 * 
	 * @param servers The List of BSTransBicNetCFInfo that needs to be pushed onto the message
	 * @param message The USMMessage onto which the list of servers need to be pushed
	 */
	public static void pushServersToMessage(List<BSTransBicNetCFInfo> servers, USMMessage message) {
		//Pushes the vector of server elements into the  Message
		//Pushes the vector of server elements into the IC Message
		for (BSTransBicNetCFInfo ser : servers) {
			ser.pushTo(message);
		}
		message.pushInteger(servers.size());
	}

	/**
	 * This helper function pops the list of servers from the USM message on the
	 * vector
	 * 
	 * @param message The USMMessage from which the list of servers need to be popped from
	 * @param servers Fills up the list of BSTransBicNetCFInfo from the message
	 */
	public static void popServersFromMessage( USMMessage message, List<BSTransBicNetCFInfo> servers) {
		//Pops the the vector of network elements from the Message
		int nSize = message.popInteger();

		for (int i = 0; i < nSize; ++i) {
			BSTransBicNetCFInfo ser = BSTransBicNetCFInfo.popMe(message);
			servers.add(ser);
		}
	}

	/**
	 * Function to check whether the name passed is a valid domain
	 * name according to the LDAP DS constraints.
	 * @param p_domainName The domain name string which has to be checked
	 * @return	Returns true if the passed string is valid as per the LDAP DS
	 * constraints
	 */
	public static boolean isValidName(String p_domainName) {
		//Check if it begins with blank spaces
		String regExpInvalid = "+=\\;\"/<>,#";
		boolean valid = false;

		if (p_domainName.length() > 0 && p_domainName.length() <= 64) {
			valid = true;
			for (int i = 0; i < regExpInvalid.length(); i++) {
				if (-1 != p_domainName.indexOf((regExpInvalid.charAt(i)))) {
					valid = false;
					break;
				}
			}
		}
		return valid;
	}
}
