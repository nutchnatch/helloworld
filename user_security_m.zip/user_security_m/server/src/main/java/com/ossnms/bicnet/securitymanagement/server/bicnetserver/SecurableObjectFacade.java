package com.ossnms.bicnet.securitymanagement.server.bicnetserver;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.security.SecurableObjectIdReply;
import com.ossnms.bicnet.bcb.facade.security.SecurableObjectItem;
import com.ossnms.bicnet.bcb.facade.security.SecurableObjectReply;
import com.ossnms.bicnet.bcb.facade.security.SecurityDomainIdItem;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.security.ISecurableObject;
import com.ossnms.bicnet.bcb.model.security.ISecurableObjectId;
import com.ossnms.bicnet.bcb.model.security.ISecurableObjectMarkable;
import com.ossnms.bicnet.bcb.model.security.ISecurityDomainId;
import com.ossnms.bicnet.bcb.model.security.SecurableObjectsChanged;
import com.ossnms.bicnet.securitymanagement.api.common.utils.AbstractManagedObjectFacade;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.server.domain.DCSubsystemSAP;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.ossnms.bicnet.bcb.model.ManagedObjectType.NE;

/**
 *
 */
public class SecurableObjectFacade
        extends AbstractManagedObjectFacade<BSSecurableObject, ISecurableObjectId, ISecurableObject, ISecurableObjectMarkable, SecurableObjectReply, SecurableObjectIdReply> {

    @Override
    protected List<BSSecurableObject> getList() {
        return BSSubsystemSAP.getAllSecurableObjectsWithACL();
    }

    @Override
    protected BSSecurableObject getSingleItem(ISecurableObjectId id) {
        return BSSubsystemSAP.getSecurableObject(id);
    }

    @Override
    protected ISecurableObject toItem(BSSecurableObject data) {
        ISecurableObject securableObject = new SecurableObjectItem();
        securableObject.setObjectName(data.getDisplayName()); //currently the display name contains the id

        securableObject.setContainerList(null); //The container list can be null, since it is irrelevant in this interface

        //get all domains, and match them with the ACL settings
        ArrayList<ISecurityDomainId> securityDomainIds = new ArrayList<>();

        for(DCDomainData domainData : DCSubsystemSAP.getAllDomains()){
            if(data.belongsToDomain(domainData.getDomainID())){
                ISecurityDomainId securityDomainId = new SecurityDomainIdItem(domainData.getDomainName());
                securityDomainIds.add(securityDomainId);
            }
        }
        ISecurityDomainId[] securityDomainIdsArray = new ISecurityDomainId[securityDomainIds.size()];
        securityDomainIds.toArray(securityDomainIdsArray);
        securableObject.setSecurityDomainList(securityDomainIdsArray);

        //Return the securable Object
        return securableObject;
    }

    @Override
    protected ISecurableObjectId toIdItem(BSSecurableObject data) {
        return null;
    }

    @Override
    protected ISecurableObjectMarkable toMarkableItem(BSSecurableObject data) {
        return null;
    }

    @Override
    protected SecurableObjectReply toItemReply(boolean eof, ISecurableObject[] items) {
        return new SecurableObjectReply(
                items,
                eof,
                items.length > 0 ? items[items.length - 1].getSecurableObjectId() : null
        );
    }

    @Override
    protected SecurableObjectIdReply toIdReply(boolean eof, ISecurableObjectId[] ids) {
        return new SecurableObjectIdReply(
                ids,
                eof,
                ids.length > 0 ? ids[ids.length - 1] : null
        );
    }

    @Override
    protected boolean matchesFilter(ISecurableObjectMarkable filter, ISecurableObject data) {
        // not yet implemented
        return true;
    }

    /**
     * Returns a Facade which filters the securable objects by domain
     *
     * @param domainId instance of <ISecurityDomainId>
     * @return an instance of <code>SecurableObjectFacade</code> with an overridden getList method
     */
    public static SecurableObjectFacade getFilteredFacade(final ISecurityDomainId domainId){
        return new SecurableObjectFacade(){
            @Override
            protected List<BSSecurableObject> getList(){
                List<BSSecurableObject> securableObjInfos = super.getList();
                ArrayList<BSSecurableObject> securableObjects = new ArrayList<>(securableObjInfos.size());
                DCDomainData domainData = DCSubsystemSAP.getDomain(domainId.getName());

                for(BSSecurableObject securableObjInfo : securableObjInfos){
                    if (securableObjInfo.getACL().belongsToDomain(domainData.getDomainID())) {
                        securableObjects.add(securableObjInfo);
                    }
                }

                return securableObjects;
            }
        };
    }

    /**
     * Send External Notification of SecurableObjectsChanged.
     * @param data
     * @param userGroupName
     */
    public void sendSecurableObjectsChanged(List<BSSecurableObject> data, String userGroupName){
        // to managed object id
        List<IManagedObjectId> managedObjectIdList = data.stream().map(toManagedObjectId()).collect(Collectors.toList());
        // to array
        IManagedObjectId[] managedObjIdsArray = new IManagedObjectId[managedObjectIdList.size()];
        managedObjIdsArray = managedObjectIdList.toArray(managedObjIdsArray);

        // send external notification
        sendExternalNotification(new SecurableObjectsChanged(new Date(),userGroupName, managedObjIdsArray));
    }

    /**
     * Convert Securable Objects to Managed Objects Id.
     * @return
     */
    private Function<BSSecurableObject, IManagedObjectId> toManagedObjectId() {
        return secObject -> {
            if (NE.equals(secObject.getManagedObjectType())){
              return new NEIdItem(Integer.parseInt(secObject.getObjectName()));
            }

            return null;
        };
    }
}
