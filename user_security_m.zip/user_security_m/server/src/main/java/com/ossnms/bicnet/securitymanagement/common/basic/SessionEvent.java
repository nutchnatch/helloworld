package com.ossnms.bicnet.securitymanagement.common.basic;

import com.ossnms.bicnet.securitymanagement.common.auth.AAMessageType;

public enum SessionEvent {
	
	LOGIN (AAMessageType.AA_NOTIFICATION_USER_LOGGEDIN),
	LOGOFF(AAMessageType.AA_NOTIFICATION_USER_LOGGEDOUT),
	LOGOFF_TRIAL_EXPIRED (AAMessageType.AA_NOTIFICATION_USER_FORCE_LOGOUT_TRIAL_EXPIRED),
	FORCE_LOGOFF (AAMessageType.AA_NOTIFICATION_USER_FORCE_LOGOUT);
	
	private USMBaseMsgType associatedMessageType;
	
	SessionEvent(USMBaseMsgType associatedMessageType) {
		this.associatedMessageType = associatedMessageType;
	}
	
	public USMBaseMsgType getAssociatedMessageType() {
		return associatedMessageType;
	}
}
