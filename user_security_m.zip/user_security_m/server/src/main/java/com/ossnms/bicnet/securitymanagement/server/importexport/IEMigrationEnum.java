/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	IEMigrationEnum
 * Author      	Muyeen
 * Substitute	Asif
 * Created on	10-01-2005
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Asif			CF000427 - Implementation of the XML import mechanism needed for the migration process
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.importexport;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Helper class for the enums
 */
final class IEMigrationEnum {
	/**
	 * Data member for the enum Administration.
	 */
	private static final String ADMIN_USER_CLASS = "Administration";
	private static final String ADMIN_USER_GROUP = "TNMSAdministrators";
	private static final String ADMIN_POLICY = "TNMSAdministration";
	public static final IEMigrationEnum ADMINISTRATION =
		new IEMigrationEnum(ADMIN_USER_CLASS, ADMIN_USER_GROUP, ADMIN_POLICY);

	/**
	 * Data member for the enum Configuration.
	 */
	private static final String CONFIG_USER_CLASS = "Configuration";
	private static final String CONFIG_USER_GROUP = "TNMSConfigurators";
	private static final String CONFIG_POLICY = "TNMSConfiguration";
	public static final IEMigrationEnum CONFIGURATION =
		new IEMigrationEnum(
			CONFIG_USER_CLASS,
			CONFIG_USER_GROUP,
			CONFIG_POLICY);

	/**
	 * Data member for the enum Operation.
	 */
	private static final String OPER_USER_CLASS = "Operation";
	private static final String OPER_USER_GROUP = "TNMSOperators";
	private static final String OPER_POLICY = "TNMSOperation";
	public static final IEMigrationEnum OPERATION =
		new IEMigrationEnum(OPER_USER_CLASS, OPER_USER_GROUP, OPER_POLICY);

	/**
	 * Data member for the enum Maintenance.
	 */
	private static final String MAINT_USER_CLASS = "Maintenance";
	private static final String MAINT_USER_GROUP = "TNMSMaintainors";
	private static final String MAINT_POLICY = "TNMSMaintenance";
	public static final IEMigrationEnum MAINTENANCES =
		new IEMigrationEnum(MAINT_USER_CLASS, MAINT_USER_GROUP, MAINT_POLICY);

	/**
	 * Data member for the enum Supervision.
	 */
	private static final String SUPER_USER_CLASS = "Supervision";
	private static final String SUPER_USER_GROUP = "TNMSSupervisors";
	private static final String SUPER_POLICY = "TNMSSupervision";
	public static final IEMigrationEnum SUPERVISION =
		new IEMigrationEnum(SUPER_USER_CLASS, SUPER_USER_GROUP, SUPER_POLICY);

	private static Map<String, IEMigrationEnum> m_Map = new HashMap<String, IEMigrationEnum>();
	static {
		m_Map.put(ADMIN_USER_CLASS.toLowerCase(), ADMINISTRATION);
		m_Map.put(CONFIG_USER_CLASS.toLowerCase(), CONFIGURATION);
		m_Map.put(OPER_USER_CLASS.toLowerCase(), OPERATION);
		m_Map.put(MAINT_USER_CLASS.toLowerCase(), MAINTENANCES);
		m_Map.put(SUPER_USER_CLASS.toLowerCase(), SUPERVISION);
	}

	/**
	 * Data member to hold the name of the user class
	 */
	private String strUserClassName = null;

	/**
	 * Data member to hold the name of the user group
	 */
	private String strUserGroupName = null;

	/**
	 * Data member to hold the name of the policy
	 */
	private String strPolicyName = null;

	/**
	 * Constructor
	 * @param p_strUserClassName - Name of the User Class
	 * @param p_strUserGroupName - name of the User Group Name
	 * @param p_strPolicyName - Name of the Policy Name
	 */
	private IEMigrationEnum(
		String p_strUserClassName,
		String p_strUserGroupName,
		String p_strPolicyName) {

		strUserClassName = p_strUserClassName;
		strUserGroupName = p_strUserGroupName;
		strPolicyName = p_strPolicyName;
	}

	/**
	 * Function to return the Name of the Policy that should be created.
	 * @return String The Name of the Policy
	 */
	String getPolicyName() {
		return strPolicyName;
	}

	/**
	 * Function to return the Name of the user class.
	 * @return String The Name of the User Class
	 */
	String getUserClassName() {
		return strUserClassName;
	}

	/**
	 * Function to return the User Group Name
	 * @return String The Name of the user Group
	 */
	String getUserGroupName() {
		return strUserGroupName;
	}

	/**
	 * Function to return the IEMigrationEnum associated with the passed User Class name
	 * @param p_strUserClassName The Name of the User class
	 * @return IEMigrationEnum The Associated enum with the name.
	 */
	static IEMigrationEnum getEnumForUserClassName(String p_strUserClassName) {
		return m_Map.get(p_strUserClassName.toLowerCase());
	}

	/**
	 * Function to return a list of all the enums currently available
	 * @return List the List of all the enums.
	 */
	static List<IEMigrationEnum> getListOfAllEnums() {
		return new ArrayList<IEMigrationEnum>(m_Map.values());
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
    public String toString() {
		return strUserClassName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
    public boolean equals(Object obj) {
		boolean bEquals = false;
		if ((obj != null) && (obj instanceof IEMigrationEnum)) {
			IEMigrationEnum en = (IEMigrationEnum) obj;
			bEquals =
				(strUserClassName.compareToIgnoreCase(en.strUserClassName)
					== 0)
					? true
					: false;
		}
		return bEquals;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
    public int hashCode() {
		return strUserClassName.hashCode();
	}

}
