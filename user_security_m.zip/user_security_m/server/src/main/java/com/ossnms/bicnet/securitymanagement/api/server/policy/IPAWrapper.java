package com.ossnms.bicnet.securitymanagement.api.server.policy;

import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionItemData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;

import java.util.List;

/**
 * created on 6/5/2015
 */
public interface IPAWrapper {

    /**
     *
     *
     * @param policyData
     * @return
     */
    boolean createPolicy(PAPolicyData policyData);

    /**
     *
     * @param policyToBeDeleted
     * @return
     */
    boolean deletePolicy(PAPolicyId policyToBeDeleted);

    /**
     *
     * @param policyData
     * @return
     */
    boolean modifyPolicy(PAPolicyData policyData);

    /**
     *
     * @param policyID
     * @return
     */
    PAPolicyData getPolicy(int policyID);

    /**
     *
     * @param policyName
     * @return
     */
    PAPolicyData getPolicy(String policyName);

    /**
     *
     * @return
     */
    List<PAPolicyData> getPolicies();

    /**
     *
     * @return
     */
    List<PAPolicyId> getPolicyNameAndIdList();

    /**
     *
     * @param policyName
     * @return
     */
    boolean isPolicyAvailable(String policyName);

    /**
     *
     * @param id
     * @return
     */
    PAPermissionData getPermission(int id);

    /**
     *
     * @param permissionName
     * @return
     */
    PAPermissionData getPermission(String permissionName);

    /**
     *
     * @return
     */
    List<PAPermissionData> getPermissions();

    /**
     *
     * @return
     */
    List<PAPermissionData> getPermissions(PAPolicyData policyData);

    /**
     *
     * @return
     */
    List<PAPermissionData> getPermissions(PAPolicyId policyData);

    /**
     *
     * @param permissionItemId
     * @return
     */
    PAPermissionItemData getPermissionItem(int permissionItemId);

    /**
     *
     * @param permissionItemName
     * @return
     */
    PAPermissionItemData getPermissionItem(String permissionItemName);

    /**
     *
     * @return
     */
    List<PAPermissionItemData> getPermissionItems();

    /**
     *
     * @return
     */
    List<PAPermissionItemData> getPermissionItems(PAPolicyData policyData);

    /**
     *
     * @return
     */
    List<PAPermissionItemData> getPermissionItems(PAPolicyId policyId);


    /**
     *
     * @return
     */
    List<PAPermissionItemData> getPermissionItems(PAPermissionData permissionData);

}
