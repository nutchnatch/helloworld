/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	ALServerLifeCycleController
 * Author      	Babu B
 * Substitute	Vinay Purohit
 * Created on	12-10-2004
 *
 * --------------------------------------------------------
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.LOGGING.ALARM
 * 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 05-May-2005  Muyeen M        CF001312   Master-Master Replication for Sun ONE DS
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.alarming;

import com.ossnms.bicnet.securitymanagement.server.basic.USMServerLifeCycleControllerIfc;
import com.ossnms.bicnet.securitymanagement.server.basic.notification.USMNotifier;
import org.apache.log4j.Logger;

;

/**
 * This class which is responsible for the initialization of the
 * USM Alarming component.
 */
public final class ALServerLifeCycleController
	implements USMServerLifeCycleControllerIfc {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(ALServerLifeCycleController.class);

	/**
	 * Data member to hold the singleton instance of the class.
	 */
	private static ALServerLifeCycleController instance = new ALServerLifeCycleController();

	/**
	 * Private Constructor to prevent instantiation
	 */
	private ALServerLifeCycleController() {
	}

	/**
	 * Function to return the singleton instance of the class
	 *
	 * @return USMServerLifeCycleController -
	 * 			The singleton instance of the class.
	 *
	 */
	public static ALServerLifeCycleController getInstance() {
		LOGGER.debug("getInstance() 	Called");
		return instance;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.common.basic.USMLifeCycleController#initialize()
	 */
	public boolean initialize() {
		LOGGER.debug("initialize() 	Entry");

		// Register for User Lock / Unlock / Delete & other related notifications  (synchronous)
		ALAlarmingNotifHandler handler = new ALAlarmingNotifHandler();
		boolean bInitComplete = USMNotifier.getInstance().register(handler);

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info(
				"Notification Handler registration status - " + bInitComplete);
		}

		LOGGER.debug("initialize() 	Exit");
		return bInitComplete;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.common.basic.USMLifeCycleController#cleanup()
	 */
	public boolean cleanup() {
		LOGGER.debug("cleanup() 	Entry");

		LOGGER.debug("cleanup() 	Exit");
		return true;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.server.basic.USMServerLifeCycleControllerIfc#reinitialize()
	 */
	public boolean reinitialize() {
		LOGGER.debug("reinitialize() 	Entry");

		LOGGER.debug("reinitialize() 	Exit");
		return true;
	}

}
