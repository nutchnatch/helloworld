package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.securitymanagement.api.server.domain.IDomainWrapper;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.domain.DCException;
import com.ossnms.bicnet.securitymanagement.common.domain.DCGlobal;
import com.ossnms.bicnet.securitymanagement.common.domain.DCHelper;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;
import com.ossnms.bicnet.securitymanagement.common.utils.InternalUSMBeanLocator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Singleton class which holds all transient data cache for domain information.
 * Methods exist to access and modify the data. Responsible for getting data
 * from LDAP the first time the server starts up by delegating the request.
 */
public final class DCServerDataManager {

	/**
	 * Holds the singleton instance of this class
	 */
    private static final DCServerDataManager instance = new DCServerDataManager();

	/**
	 * Data member for the Logging of the class.
	 */
    private static final Logger LOGGER = LoggerFactory.getLogger(DCServerDataManager.class);
	private static final int INT_POSITIVE = 0x7fffffff;
	private static final int LSB_BITS = 7;

	/**
	 * Contains the list of domains that have been created. Map of domain id
	 * versus the DCDomainData
	 */
	private Map<Integer, DCDomainData> domains = new HashMap<>();

	/**
	 * Contains the list of domain Mappings that have been configured
	 */
	private List<DCDomainMapping> domainMappings = new ArrayList<>();

	/**
	 * Holds the byte stream object that identifies which id is free for the
	 * new domain which can be created. Maximum of 127 domains can be created.
	 * The first domain is not allocated and is the default global domain.
	 */
	private BitSet domainIds = new BitSet(DCGlobal.MAX_DOMAINS);

	/**
	 * Indicates what is the max domain id which has been allocated.
	 * This is done in the effort so that domain ids are not easily recycled.
	 * at least till 128th domain gets created
	 */
	private int maxDomainIdAllocated = 0;

	/**
	 * Single point of access to the class DCServerDataManager
	 * 
	 * @return DCServerDataManager Returns single
	 *         instance of the class
	 */
	public static DCServerDataManager getInstance() {
		//Did not want to do any tracing here, but may be i would get a comment for this, so added this line here 
		LOGGER.debug("getInstance() - Called");
		return instance;
	}

	/**
	 * Default constructor
	 */
	private DCServerDataManager() {
		//This is commented out because, it is a static variable and logger is not initialized
		//LOGGER.debug("DCServerDataManager() - Entry/Exit");
		//Better to initialize the variables in the location where they are declared it will at least prevent in missing out some initializations to some extent
	}

	private IDomainWrapper getDomainWrapper(){
		return InternalUSMBeanLocator.getEJB(IDomainWrapper.class);
	}

	/**
	 * Called the first time the server starts up to initialize the data cache
	 * manager by getting data from LDAP.
	 */
	synchronized void initialize() {
		LOGGER.debug("initialize() - Enter");
		//Get list of domains, global domain won't be created in the LDAP
		//even manually, it shall not be possible to create the global domain
		//the range is only from 1- 127
		List<DCDomainData> configuredDomainsList = getDomainWrapper().getAllDomains();

		domainIds.clear();
		maxDomainIdAllocated = 0;

		//Form a hashset for the number of domains, this will prevent any
		//extra domains in that case.
		domains.clear();
        for (DCDomainData configuredDomain : configuredDomainsList) {
            if (null == domains.get(configuredDomain.getDomainID())) {
                domains.put(configuredDomain.getDomainID(), configuredDomain);
            } else {
                LOGGER.error("initialize() - Some Extra domain was created, or duplicate domain was created " + configuredDomain);
                LOGGER.error("initialize() - DONOT create any extra data your self in LDAP unless you are VERY SURE");
            }
        }
		//Add the global domain also along with this information.
		DCDomainData globalDomain = DCDomainData.GLOBAL_DOMAIN;
		domains.put(globalDomain.getDomainID(), globalDomain);
		//Mark domain ids that are used
		markDomainIdsUsed();

		LOGGER.info("The domain ids used {} and max id {}", domainIds, maxDomainIdAllocated);

		domainMappings.clear();

		//Get list of mappings
		List<DCDomainMapping> retrievedMappingsList = getDomainWrapper().getAllMappings();
		retrievedMappingsList
				.stream()
				.filter(domainMapping -> !domainMappings.contains(domainMapping))
				.forEach(domainMapping -> domainMappings.add(domainMapping));

		//Make the global mappings with the security admin user group which will be created
		//while installing
		domainMappings.add(DCDomainMapping.GLOBAL_MAPPING);

		LOGGER.info("Number of domains existing are including global {}", domains.size());
		LOGGER.info("Number of Mappings existing are {}", domainMappings.size());

		LOGGER.debug("The domains existing are {}", domains);
		LOGGER.debug("The mappings existing are {}", domainMappings);
		LOGGER.debug("initialize() - Exit");

	}

	/**
	 * Gets the list of all domains that have been created
	 * 
	 * @param domains The List of DCDomainData which have been created
	 */
	public void getAllConfiguredDomains(List<DCDomainData> domains) {
		LOGGER.debug("getAllConfiguredDomains() - Enter");
		//Return the domain information to the caller.
		domains.addAll(this.domains.values());

		LOGGER.debug("The number of domains are {}", domains.size());
		LOGGER.debug("getAllConfiguredDomains() - Exit");
	}

	/**
	 * Gets the list of all configured mappings
	 * 
	 * @param mappings To holds the List of DCDomainMapping
	 */
	void getAllConfiguredMappings(List<DCDomainMapping> mappings) {
		LOGGER.debug("getAllConfiguredMappings() - Enter");

		mappings.addAll(domainMappings);

		LOGGER.debug("The number of mappings are {}", mappings.size());
		LOGGER.debug("getAllConfiguredMappings() - Exit");
	}

	/**
	 * This private function iterates thru the list and finds the domain ids
	 * which have been used and marks them in the member m_domainIds which is a
	 * bitset.
	 */
	private void markDomainIdsUsed() {
		LOGGER.debug("markDomainIdsUsed() - Enter");

		//set the global domain id as used, and not to be created.
		domainIds.set(0);
		int domainId;
        for(DCDomainData domainData : domains.values()) {
			domainId = domainData.getDomainID();

			//Mark this domain id as used
			domainIds.set(domainId);

			//Check for the max domain id allocated
			//This helps in reducing recreation of the domain
			//with same domain id upto some extent
			if (domainId > maxDomainIdAllocated) {
				maxDomainIdAllocated = domainId;
			}
		}

		LOGGER.debug("markDomainIdsUsed() - Exit");
	}

	/**
	 * Modifes a domain object that has been pased. Only domain descrition can
	 * be modified. When a NE is assigned to a domain or removed from the
	 * domain, this does not lead to domain modification, but leads to a NE
	 * attribute change
	 * 
	 * @param pDomain The domain which is to be modified
	 */
	public void modifyDomain(DCDomainData pDomain) throws DCException {

		LOGGER.debug("modifyDomain() - Enter");

		LOGGER.info("modifyDomain() - Trying to modify domain with these details {}", pDomain);

		//This should never happen, if it happens, it means that there was some critical error
		//that happened somewhere
		if (pDomain.isGlobalDomain()) {
			LOGGER.error("modifyDomain() Some one is trying to modify Global domain");
			throw new DCException("Some one is trying to modify Global domain");
		}

		if (!domains.containsValue(pDomain)) {
			LOGGER.warn("modifyDomain() Domain is not valid any longer, some other client could have deleted {}", pDomain);
			throw new DCInvalidDomainException();
		}

        if(!getDomainWrapper().modifyDomain(pDomain)) {
            LOGGER.error("modifyDomain() Domain could not be modified, as there was an error for domain {}", pDomain);
            throw new DCDataBaseException();
        }

		int domainId = pDomain.getDomainID();
		domains.put(domainId, pDomain);

		LOGGER.info("Domain has successfully modified {}", pDomain.getDomainName());

        LOGGER.debug("modifyDomain() - Exit");
	}

	/**
	 * Deletes the domain passed.
	 * 
	 * @param pDomain The id of the domain which is to be deleted
	 */
	public synchronized void deleteDomain(DCDomainData pDomain) throws DCException {
		LOGGER.debug("deleteDomain() :: Entry");

		//This should never happen, if it happens, it means that there was some critical error
		//that happened somewhere
		if (pDomain.isGlobalDomain()) {
			LOGGER.debug("deleteDomain() :: Trying to delete global domain");
			throw new DCException("Trying to delete global domain");
		}

		DCDomainData domain = getDomainData(pDomain.getDomainID());
		if (null == domain) {
			LOGGER.warn("deleteDomain() :: Some other client could have deleted this domain {}", pDomain);
			throw new DCInvalidDomainException();
		}
		
		if(isDomainMapped(domain.getDomainID())){
			LOGGER.debug("deleteDomain() :: Trying to delete mapped domain");
			throw new DCDomainMappedException();
		}

		//call AS for unassigning NEs for this domain
		DCExternalInterface.domainDeleted(domain);
		
		//Delete the mappings associated with the domain
		if (!deleteMappingsOfDomain(domain.getDomainID())) {
			LOGGER.error("deleteDomain() :: Mappings associated with the domain {} could not be deleted, database exception", domain);
			throw new DCDataBaseException();
		}

        if(!getDomainWrapper().deleteDomain(domain)) {
            LOGGER.error("deleteDomain() :: Domain could not be deleted, database exception {}", domain);
            throw new DCDataBaseException();
        }

		//Now update the cache, as LW update was successful.
		int domainId = domain.getDomainID();
		domains.remove(domainId);
		domainIds.clear(domain.getDomainID());

		LOGGER.info("Domain was successfully deleted {} domain id {}", domain, domainId);
		LOGGER.debug("deleteDomain() :: Exit");
	}

	/**
	 * Checks if a domain with this name is already exisiting in its data structure
	 * 
	 * @param pDomain The domain which has to be checked if already existing
	 * @return boolean Returns true if the domain name already exists
	 */
	private boolean isDomainNameExisting(DCDomainData pDomain) {
		LOGGER.debug("isDomainExisting() Enter");

		boolean bFound = false;
        for(DCDomainData domainData : domains.values()) {
            if(0 == pDomain.getDomainName().compareToIgnoreCase(domainData.getDomainName())) {
                bFound = true;
                break;
            }
        }

		LOGGER.info(bFound ? "Domain with the name {} is already existing" : "Domain with the name {} is not existing", pDomain);
		LOGGER.debug("isDomainExisting() Exit");

		return bFound;
	}

	/**
	 * This function gets all relevant mappings for a user group. It only gets the
	 * valid domain mappings that are part of the cache and data base. If a
	 * mapping is not created, then it DOESNOT return those mappings(with
	 * policy id -1 for NONE).
	 * 
	 * @param userGroup User Group for which mappings are requested
	 * @param mappings To holds the List of DCDomainMapping for the user group
	 */
	void getDomainMappings(String userGroup, List<DCDomainMapping> mappings) {
		LOGGER.debug("getDomainMappings() Entry");
		//Get the domain mappings for this passed domain
		mappings.addAll(
				domainMappings
						.stream()
						.filter(mapping -> mapping.getUserGroup() != null && mapping.getUserGroup().equals(userGroup))
						.collect(Collectors.toList())
		);

		LOGGER.info("Number of mappings retrieved for user group {} are {}", userGroup, mappings.size());

		LOGGER.debug("Mappings retrieved are " + mappings);

	}

	/**
	 * Passes the list of domain Mapping data to be modified. The domain id
	 * with the user group is unique. In this case, get the LWElement and if it
	 * exists then it is a change in the policy If mappings not contained,
	 * create a mapping, else change the mapping
	 * 
	 * @param pLstMappings List of mappings(DCDomainMapping) which have to be created/modified
	 * @param pSucceededMappings List of successfully modified mappings(DCDomainMapping)
	 * @param pErrorMappings List of error mappings(DCDomainMapping)
	 */
	void modifyMappings(List<DCDomainMapping> pLstMappings, List<DCDomainMapping> pSucceededMappings, List<DCDomainMapping> pErrorMappings) {
		LOGGER.debug("modifyMappings() Enter");

        for (DCDomainMapping domMap : pLstMappings) {
            // trying to map global mapping. not possible
            if (domMap.isGlobalMapping()) {
                LOGGER.warn("Trying to modify or change the global domain mapping {}", domMap);
                domMap.setErrorId(DCMessages.DC_ERROR_GLOBAL_MAPPING_MODIFIED);
                pErrorMappings.add(domMap);
                continue;
            }
            // if it doesnot already, contain, means that we have to create it
            // the domain id and the user group together make it unique
            if (!domainMappings.contains(domMap)) {
                if (getDomainWrapper().createMapping(domMap)) {
                    domainMappings.add(domMap);
                    pSucceededMappings.add(domMap);
                } else {
                    LOGGER.error("There was an error for creating this mapping {}", domMap);
                    domMap.setErrorId(DCMessages.DC_LDAP_ERROR);
                    pErrorMappings.add(domMap);
                }
            } else {
                completeDCDomainMapping(domMap);

                if (getDomainWrapper().modifyMapping(domMap)) {
                    domainMappings.set(domainMappings.indexOf(domMap), domMap);
                    pSucceededMappings.add(domMap);
                } else {
                    LOGGER.error("There was an error for modifying this mapping {}", domMap);
                    domMap.setErrorId(DCMessages.DC_LDAP_ERROR);
                    pErrorMappings.add(domMap);
                }
            }
        }

		LOGGER.info("Number of mappings which needed to be modified were {}", pLstMappings.size());
		LOGGER.info("Number of mappings which were successfully modified were {}", pSucceededMappings.size());
		LOGGER.info("Number of mappings which could not be modified were {}", pErrorMappings.size());

		LOGGER.debug("Mappings which needed to be modified were {}", pLstMappings);
		LOGGER.debug("modifyMappings() Exit");
	}

	/**
	 * Deletes the list of mappings passed. It first tries to find the list of
	 * mappings from LDAP and if it is possible to delete the mapping, it then
	 * proceeds to remove it from the cache.
	 * 
	 * @param pLstMappings List of mappings to be deleted(DCDomainMapping)
	 * @param pSucceededMappings List of mappings(DCDomainMapping) that were successfully deleted
	 * @param pErrorMappings List of mappings(DCDomainMapping) that could not be deleted.
	 */
	void deleteMappings(List<DCDomainMapping> pLstMappings, List<DCDomainMapping> pSucceededMappings, List<DCDomainMapping> pErrorMappings) {
		LOGGER.debug("deleteMappings() Enter");

        for (DCDomainMapping domMap : pLstMappings) {
            //Trying to map global mapping. not possible
            if (domMap.isGlobalMapping()) {
                LOGGER.warn("Trying to delete the global domain mapping {}", domMap);
                domMap.setErrorId(DCMessages.DC_ERROR_GLOBAL_MAPPING_MODIFIED);
                pErrorMappings.add(domMap);
                continue;
            }

            //fetch missing information from the cache
            completeDCDomainMapping(domMap);

            if (getDomainWrapper().deleteMapping(domMap)) {
                domainMappings.remove(domMap);
                pSucceededMappings.add(domMap);
            } else {
                LOGGER.error("There was an error for deleting this mapping {}", domMap);
                domMap.setErrorId(DCMessages.DC_LDAP_ERROR);
                pErrorMappings.add(domMap);
            }
        }

		LOGGER.info("Number of mappings which needed to be deleted were {}", pLstMappings.size());
		LOGGER.info("Number of mappings which were successfully deleted were {}", pSucceededMappings.size());
		LOGGER.info("Number of mappings which could not be deleted were {}", pErrorMappings.size());

		LOGGER.debug("Mappings which needed to be deleted were {}", pLstMappings);
		LOGGER.debug("deleteMappings() Exit");
	}

    /**
    * Checks if the passed domain is part of any mappings. This
    * check is needed before any domain can be deleted.
    * @param domainId The domain identifier
    * @return boolean Returns true if the domain takes part in a mapping
    */
	private boolean isDomainMapped(int domainId) {
        LOGGER.debug("isDomainMapped() - Entry");

		LOGGER.info("domain {} is to be checked if it is mapped", domainId);

        boolean found = false;
        for (DCDomainMapping domMap : domainMappings) {
            if (domMap.getDomainID() == domainId) {
                found = true;
				LOGGER.info("Domain with id {} is mapped", domainId);
                break;
            }
        }
    
        LOGGER.debug("isDomainMapped() - Exit");
        return found;
    }
	
	/**
	 * Deletes all mappings of the domain passed. Since domains form the basis
	 * of mappings, if the domain is deleted, all the mappings related to the
	 * domain also has to be deleted
	 * 
	 * @param pDomId The id of the domain, whose mappings have to be deleted
	 * @return boolean Returns true if it was successful in deleting all mappings
	 */
	boolean deleteMappingsOfDomain(int pDomId) {
		LOGGER.debug("deleteMappingsOfDomain() Enter");
		//Get the list of domain mappings for this id and start deleting from cache
		//only if it was successful
		boolean bOp = false;
		List<DCDomainMapping> mappingsToDelete = domainMappings
				.stream()
				.filter(domMap -> domMap.getDomainID() == pDomId)
				.collect(Collectors.toList());

		LOGGER.info("Deleted domain Id {} :: Number of mappings to delete {}", pDomId, mappingsToDelete.size());

		List<DCDomainMapping> successfullyDeletedMappings = new ArrayList<>();
		List<DCDomainMapping> errorMappings = new ArrayList<>();

		deleteMappings(mappingsToDelete, successfullyDeletedMappings, errorMappings);

		if (mappingsToDelete.size() == successfullyDeletedMappings.size()) {
			bOp = true;
		}

		LOGGER.debug("deleteMappingsOfDomain() Exit");
		return bOp;
	}

	/**
	 * Creates a new domain if the domain name is not already exisiting. Throws
	 * exception otherwise. Global domain cannot be created as it would throw a
	 * DCDupNameException The exception is throw only if the global domain has
	 * already been created in the cache If before creating in the cache and
	 * initializing, if this is called to create a domain, it is not guaranteed
	 * to throw the exception, This function creates a domain and throws
	 * exception if it was not possible to create.
	 *
	 * @param pDomain Domain details which has to be created. The id passed is not used
	 * @return DCDomainData Returns DCDomainData that was successfully created. The id of the domain is populated and filled
	 */
	public synchronized DCDomainData createDomain(DCDomainData pDomain) throws DCDataBaseException, DCInvalidNameException, DCDupNameException {
		LOGGER.debug("createDomain() - Entry");
		//Though the client also checks, better to check here, as it
		//may also be done while import/export
		//Check if the domain name is valid
		if (!DCHelper.isValidName(pDomain.getDomainName())) {
			//If exists, throw an exception.
			LOGGER.warn("createDomain() Domain name is invalid {}", pDomain);
			throw new DCInvalidNameException();
		}

		//Find if that name already exists in the cache.
		if (isDomainNameExisting(pDomain)) {
			LOGGER.warn("createDomain() Domain name is already existing {}", pDomain);
			throw new DCDupNameException();
		}

        //This storing of oldMax is needed, in case there is a failure in creating
		//the domain element in LDAP DS, the max allocated id should not change, so we revert back

        //since the Oracle DB will assign a new ID, this is unnecessary

//		int oldMax = maxDomainIdAllocated;
//		int domId = getDomainIdUnUsed();
//		if (-1 == domId) {
//			maxDomainIdAllocated = oldMax;
//			LOGGER.warn(
//				"createDomain() Maximum number of domain have been reached, not possible to create "
//					+ p_domain);
//			throw new DCMaxDomainException();
//		}
		//Domain id retrieval successfull...
		//Ask LW to create that domain and fill the LDAP domain info
		//Get the uniq id
		long longId = System.currentTimeMillis();
		//The uniq id stored will be the time in seconds,
		//since the function returns us long, we have to make it as int, so we are removing the msb
		//The ffff which u see in the below line for bitwise andis to make the lsb always positive.
		//We then remove the 3 lsb digital(this is 7 bits approx)  to remove the millisec count, now this number gives
		//us the seconds
		longId = longId >> LSB_BITS;

		int uniqId = (int) longId;
		//This is to make the int always positive so we donot have any probs in ldap
		uniqId = uniqId & INT_POSITIVE;

		DCDomainData domain = new DCDomainData(pDomain.getDomainName(), 0, uniqId, pDomain.getDomainDescr());

        if(!getDomainWrapper().createDomain(domain)) {
            // The max allocated should not change
            LOGGER.warn("createDomain() Database exception {}", pDomain);
            throw new DCDataBaseException();
        }
		//If success update the cache, and the domain id used
		domains.put(domain.getDomainID(), domain);
		domainIds.set(domain.getDomainID());

		LOGGER.info("Domain has successfully been created {}", domain);

		LOGGER.debug("createDomain() - Exit");
		//Return a valid domain data, whose id is valid
		return domain;
	}

	/**
	 * Gets the domain details given a domain id
	 *
	 * @param pDomId The id for which the domain details is requested
	 * @return xdm.security.dc.common.DCDomainData Returns the domain whose id is as specified in the parameter passed.
	 */
	public DCDomainData getDomainData(int pDomId) {
		LOGGER.debug("getDomainData() - Enter");
		DCDomainData dom = domains.get(pDomId);

		if (null != dom){
			LOGGER.info("Domain {} exists for the id {}", dom, pDomId);
		} else {
			LOGGER.warn("Domain is not existing for the id given {}", pDomId);
		}

		LOGGER.debug("getDomainData() - Exit");
		return dom;
	}

	/**
	 * Gets the domain details given a domain name
	 *
	 * @param domainName the name for which the domain details is requested
	 * @return Returns the domain whose name is as specified in the parameter passed.
	 */
	public DCDomainData getDomainData(String domainName) {
		LOGGER.debug("getDomainData() - Enter");
		DCDomainData dom = null;

		for(DCDomainData domainData : domains.values()){
			if(domainData.getDomainName() != null && domainData.getDomainName().equals(domainName)){
				dom = domainData;
				break;
			}
		}

		LOGGER.debug("getDomainData() - Exit");
		return dom;
	}

	/**
	 * This function performs consistency check with the mapping data
	 * available. The user could have created mappings, and from AD, he could
	 * have deleted policies or domains so that mappings have invalid domains
	 * or policies. This function removes all those invalid mappings from the
	 * cache 
	 * @param policyIdList The list of Policies as retrieved from PA to check whether
	 * the policy referred by the mapping is valid.
	 * @param userGroupList The list of user groups as retrieved from UA/UG to check whether
	 * the user group referred by the mapping is valid.
	 * @param deletedDomain The list of domain id which are not valid, but part of the
	 * mappings.
	 * @param deletedPolicy The list of policy ids which are not valid, but part of the
	 * mappings.
	 * @param deletedUserGroup The list of user groups which are not valid, but part of the
	 * mappings.
	 */
	void performConsistencyCheck(List<Integer> policyIdList, List<String> userGroupList, List<Integer> deletedDomain,
								 Set<Integer> deletedPolicy, List<String> deletedUserGroup) {
		LOGGER.debug("performConsistencyCheck() - Enter");
        for (DCDomainMapping domainMapping : domainMappings) {
            // Check for consistency with domain
            if (!domains.containsKey(domainMapping.getDomainID())) {
                deletedDomain.add(domainMapping.getDomainID());
                LOGGER.warn("Mapping found where a domain was deleted is {}", domainMapping);
            }

            // Check for consistency with policy
            if (!policyIdList.contains(domainMapping.getPolicyID())) {
                deletedPolicy.add(domainMapping.getPolicyID());
                LOGGER.warn("Mapping found where a policy was deleted is {}", domainMapping);
            }

            //Check for consistency with user group
            if (!userGroupList.contains(domainMapping.getUserGroup())) {
                deletedUserGroup.add(domainMapping.getUserGroup());
                LOGGER.warn("Mapping found where a user group was deleted is {}", domainMapping);
            }
        }

		LOGGER.debug("performConsistencyCheck() - Exit");
	}

	/**
	 * Completes the domain mapping with the information from the cache
	 *
	 * @param domainMapping the domain mapping to complete
     */
    private void completeDCDomainMapping(DCDomainMapping domainMapping){
        //get the complete mapping object from the cache and use that information to update the incoming
        //mapping object. Information might be missing (as is the id)
        DCDomainMapping cachedMapping = domainMappings.get(domainMappings.indexOf(domainMapping));
        domainMapping.setId(cachedMapping.getId());
        domainMapping.setName(cachedMapping.getName());
    }
}