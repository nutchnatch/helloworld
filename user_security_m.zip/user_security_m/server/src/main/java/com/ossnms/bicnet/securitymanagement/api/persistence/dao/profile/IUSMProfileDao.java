package com.ossnms.bicnet.securitymanagement.api.persistence.dao.profile;

import java.util.List;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.IBaseDAO;
import com.ossnms.bicnet.securitymanagement.persistence.model.profile.USMProfile;

/**
 * created on 28/8/2014
 */
public interface IUSMProfileDao extends IBaseDAO<USMProfile, Integer> {
    List<USMProfile> findByUser(String user);
    USMProfile findByUserAndAppUid(String user,String uid);
}
