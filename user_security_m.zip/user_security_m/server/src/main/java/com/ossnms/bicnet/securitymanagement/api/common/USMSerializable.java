package com.ossnms.bicnet.securitymanagement.api.common;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;

import java.io.Serializable;

/**
 * created on 6/5/2015
 */
public interface USMSerializable extends Serializable {

    /**
     * Function to push this object into the message. Will be used for
     * transfering this object between the server and the client.
     *
     * @param msg The Message into which we have to push this object.
     */
    void pushMe(USMMessage msg);

    /**
     * Function to pop this object from the message. Will be used while
     * transferring this object between the server and the client.
     *
     * @param msg The Message from which we have to pop this object.
     */
    void popMe(USMMessage msg);


}
