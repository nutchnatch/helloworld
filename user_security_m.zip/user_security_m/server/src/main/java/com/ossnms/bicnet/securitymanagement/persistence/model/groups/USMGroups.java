package com.ossnms.bicnet.securitymanagement.persistence.model.groups;

import com.ossnms.bicnet.securitymanagement.persistence.model.BaseUSMEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;


@Entity
@Table(name = "USM_USER_GROUPS")
public class USMGroups extends BaseUSMEntity {

    private static final long serialVersionUID = 3048589456141389893L;

    @Id
    @Column(name = "NAME", unique = true, nullable = false)
    private String name;

    @Column(name = "DESCRIPTION")
    private String description;
    
    @Lob
    @Column(name = "MEMBERS_OF_GROUP")
    private String membersOfGroup;

	@Override
	public boolean isNew() {
		return false;
	}

    public USMGroups(){
        super();
    }

    /**
     * Constructor
     *
     * @param name the name of the general settings property
     * @param description the value of the general settings property
     * @param memberOfGroup the sub-Domain to which the property belongs to
     */
    public USMGroups(String name, String description, String memberOfGroup) {
        super();
        this.name = name;
        this.description = description;
        this.membersOfGroup = memberOfGroup;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getMembersOfGroup() {
        return membersOfGroup;
    }

    public void setMembersOfGroup(String membersOfGroup) {
        this.membersOfGroup = membersOfGroup;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }

        USMGroups usmGeneral = (USMGroups) o;
        
        if (name != null ? !name.equals(usmGeneral.name) : usmGeneral.name != null){
            return false;
        }
        if (description != null ? !description.equals(usmGeneral.description) : usmGeneral.description != null){
            return false;
        }
        if (membersOfGroup != null ? !membersOfGroup.equals(usmGeneral.membersOfGroup) : usmGeneral.membersOfGroup != null){
            return false;
        }

        return true;
    }

    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((membersOfGroup == null) ? 0 : membersOfGroup.hashCode());
		return result;
	}
    
    

}
