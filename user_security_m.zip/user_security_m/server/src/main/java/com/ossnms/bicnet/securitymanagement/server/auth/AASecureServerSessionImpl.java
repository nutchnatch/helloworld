/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AASecureServerSessionImpl
 * Author      	Babu B
 * Substitute	Jogender Singh
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
  * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.SERVER.AUTHORIZATION
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 * 11-Mar-2005	Asif			CF000845 - System Event Log Entries
 * 22-Mar-2005	Muyeen Munaver	CF0001791 - Problems with Login
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.auth;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ISecureServerSession;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkableId;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.bcb.model.security.InvalidAuthorizationInfoException;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.server.logging.LMInterFace;
import com.ossnms.bicnet.securitymanagement.server.logging.LMLogRecordData;
import com.ossnms.bicnet.securitymanagement.server.logging.LMLogRecordEnum;
import org.apache.log4j.Logger;

import java.text.MessageFormat;
/**
 * This is a helper class on the server side that wraps the ISessionContext.
 * All Authorization checks from the security CF are routed through this class. 
 * 
 * This class also uses USMServerCache for implementing the authorization checks.
 */

class AASecureServerSessionImpl implements ISecureServerSession {

	/**
	 * Data member which will make sure that the code will be removed by the compiler.
	 * This is a stop - gap approach to check if the CF's have server side authorization.
	 */
	private static final boolean DEBUG = true;

	/**
	 * Logger 
	 */
	private static final Logger LOGGER = Logger.getLogger(AASecureServerSessionImpl.class);

	/**
	 *  The embedded session token for a given user session.  
	*/
	private IEnhancedSessionContext sessionContext = null;

	/**
	 * @param sessionContext session's context
	 */
	public AASecureServerSessionImpl(ISessionContext sessionContext)
		throws BcbSecurityException {

		LOGGER.info("Entering constructor of AASecureServerSessionImpl");
		LOGGER.debug("Entering AASecureServerSessionImpl. Session Context is : " + sessionContext);

		if (null == sessionContext) {
			throw new InvalidAuthorizationInfoException();
			// Null Session Context ??

		} else {
			AASessionStore lstAuthenticatedUsers =	AASessionStore.getInstance();
			boolean bUserAvailable = lstAuthenticatedUsers.isUserSessionActive(sessionContext);

			if (!bUserAvailable) {
				throw new InvalidAuthorizationInfoException();
				// User has logged out since session context was handed out ??
			}
		}
		this.sessionContext = (IEnhancedSessionContext) sessionContext;
		LOGGER.debug("Exiting AASecureServerSessionImpl. ");
	}

	/**
	 * Returns the session session context associated with the active logon.
	 * This context is to be passed as 1st parameter parameter in server calls
	 * to authorize the method on the server side.
	 * @return ISessionContext an implementation of the sessionContext
	*/
	@Override
    public ISessionContext getSessionContext() {
		if (DEBUG) {
			LOGGER.debug("Entering getSessionContext. Returning : " + sessionContext);
		}

		return sessionContext;
	}

	/**
	* Provides the host id of the client the server has a session with
	* @return String - Client id
	*/
	@Override
    public java.lang.String getClientId() {
		return sessionContext.getClientMachineName();
	}
	/**
	* Provides the BiCNet user name of the user currently logged in
	* @return String - The TNMS DX user name
	*/
	@Override
    public java.lang.String getUserName() {
		return sessionContext.getUserName();
	}

	/**
	 * Checks whether the current user is allowed to manage the desired objects
	 * by means that the objects are part of the user's security domain. This
	 * method is called by plug-ins to decide whether a specific object may be
	 * displayed on the GUI or not.
	 * @param p_arDesiredObjects	List of objects to be analzyed
	 * @return p_arDesiredObjects IManagedObjectId[]	the set of valid objects being a subset of arDesiredObjects
	 */
	@Override
    public IManagedObjectId[] checkObjectPermission(IManagedObjectId[] p_arDesiredObjects) {

		if (DEBUG) {
			String strMOs =
				USMCommonHelper.getStringForArrayOfIManagedObjectId(
					p_arDesiredObjects);
			LOGGER.debug(
				"Entering checkObjectPermission. IManagedObjectId passed is : "
					+ strMOs);
		}

		IManagedObjectId[] vecAllowedObjects = AAServerCache.getInstance().checkObjectPermission(p_arDesiredObjects, sessionContext);

		if (DEBUG) {
			String strMOs =
				USMCommonHelper.getStringForArrayOfIManagedObjectId(
					vecAllowedObjects);
			LOGGER.debug(
				"Exiting checkObjectPermission. User has permission for : "
					+ strMOs);
		}
		//Security log if the permissions are not available
		if (vecAllowedObjects == null || vecAllowedObjects.length == 0) {
			//Log that number of objects that were passed and number of objects that were actually
			//authorized for this permission to view is less, this case will always occur, so this is not necessary
			//a security breach, so i decided not to put this in the security log,
			//however if the operator doesnot have any permissions on any objects than log it
			String displayStr =
				MessageFormat.format(
						USMCommonStrings
								.IDS_AA_USER_DOESNOT_HAVE_VIEW_SECURABLE_OBJECTS_PERMISSIONS,
						sessionContext.getUserName(),
						sessionContext.getClientMachineName());

			LMLogRecordData usmLogRecord =
				new LMLogRecordData(
					LMLogRecordEnum.AUTHORIZATION_ERROR,
					USMCommonStrings.IDS_AA_NO_PERMISSION,
					LMLogRecordData._FAILURE,
					null,
					LogSeverity.WARNING.guiLabel(),
					null,
					displayStr);
			LMInterFace.getInstance().createSecurityLogRecord(
					sessionContext,
				usmLogRecord);
		}
		return vecAllowedObjects;
	}

	/**
	* Checks whether the current user is allowed to use the given operation
	* @param strOperation	The name of the operation to be analyzed
	* @return	false, if the operation is not permitted
	* 			true, otherwise
	*/
	@Override
    public boolean checkOperationPermission(String strOperation) {
		LOGGER.debug("Entering checkOperationPermission. String passed is : " + strOperation);



		boolean bResult = AAServerCache.getInstance().checkOperationPermission(strOperation, sessionContext);

		LOGGER.debug("Exiting checkOperationPermission. Result for String : " + strOperation + " is : " + bResult);

		//Log an event in the security log, informing that somehow this authorization came to the server,
		//whereas the event should have stopped in the client.
		if (!bResult) {
			String displayStr =	MessageFormat.format(
						USMCommonStrings.IDS_AA_USER_DOESNOT_HAVE_OPERATION_PERMISSIONS,
						sessionContext.getUserName(),
						strOperation,
						sessionContext.getClientMachineName());

			LMLogRecordData usmLogRecord =
				new LMLogRecordData(
					LMLogRecordEnum.AUTHORIZATION_ERROR,
					strOperation,
					LMLogRecordData._FAILURE,
					null,
					LogSeverity.ERROR.guiLabel(),
					null,
					displayStr);
			LMInterFace.getInstance().createSecurityLogRecord(
					sessionContext,
				usmLogRecord);
		}

		return bResult;

	}

	/**
	* Checks whether the current user is allowed to apply the given operation
	* to the desired objects
	* @param strOperation - The name of the operation to be applied
	* @param arDesiredObjects - List of desired objects to be analzyed
	* @return ManagedObjectItem[] - the set of valid objects
	*  for the given operation being a subset of arDesiredObjects
	*/
	@Override
    public IManagedObjectId[] checkOperationPermission(
		String strOperation,
		IManagedObjectId[] arDesiredObjects) {

		if (DEBUG) {
			String strMOs =
				USMCommonHelper.getStringForArrayOfIManagedObjectId(
					arDesiredObjects);
			LOGGER.debug(
				"Entering checkObjectPermission. IManagedObjectId passed is : "
					+ strMOs
					+ " Menu Entry is : "
					+ strOperation);
		}
		IManagedObjectId[] vecAllowedObjects =
			AAServerCache.getInstance().checkOperationPermission(
				strOperation,
				arDesiredObjects,
					sessionContext);

		if (DEBUG) {
			String strMOs =
				USMCommonHelper.getStringForArrayOfIManagedObjectId(
					vecAllowedObjects);
			LOGGER.debug(
				"Entering checkObjectPermission. Objects for which permission available is : "
					+ strMOs
					+ " Menu Entry is : "
					+ strOperation);
		}

		//Security log if the permissions are not available
		if (vecAllowedObjects == null
			|| arDesiredObjects == null
			|| (vecAllowedObjects.length < arDesiredObjects.length)) {
			//Log that number of objects that were passed and number of objects that were actually
			//authorized for this permission to view is less
			Integer allowedObjects = 0;
			Integer givenObjects = 0;
			if (vecAllowedObjects != null) {
				allowedObjects = vecAllowedObjects.length;
			}
			if (arDesiredObjects != null) {
				givenObjects = arDesiredObjects.length;
			}
            Integer notAllowedObjects = givenObjects - allowedObjects;

			String displayStr =
				MessageFormat.format(
						USMCommonStrings
								.IDS_AA_USER_DOESNOT_HAVE_OBJECT_OPERATION_PERMISSIONS,
						sessionContext.getUserName(),
						notAllowedObjects.toString(),
						givenObjects.toString(),
						strOperation,
						sessionContext.getClientMachineName());

			LMLogRecordData usmLogRecord =
				new LMLogRecordData(
					LMLogRecordEnum.AUTHORIZATION_ERROR,
					strOperation,
					LMLogRecordData._FAILURE,
					null,
					LogSeverity.ERROR.guiLabel(),
					null,
					displayStr);
			LMInterFace.getInstance().createSecurityLogRecord(
					sessionContext,
				usmLogRecord);
		}

		return vecAllowedObjects;
	}

	/**
	 * Provides a unique identifier for the current
	 * client /session/ that allows to distinguish this session
	 * from any other client session even on the same host
	 */
	@Override
	public String getClientSessionId() {
		return "" + sessionContext.getUniqId();
	}

	@Override
	public IManagedObjectId[] filterVisibleObjects(IManagedObjectMarkableId... criteria) {

		LOGGER.debug("Entering filterVisibleObjects.");

		IManagedObjectId[] vecAllowedObjects = AAServerCache.getInstance()
				.filterVisibleObjects(criteria, sessionContext);

		LOGGER.debug("Exiting filterVisibleObjects.");

		return vecAllowedObjects;
	}

	@Override
	public IManagedObjectId[] filterAccessibleObjects(IManagedObjectMarkableId... criteria) {
		LOGGER.debug("Entering filterAccessibleObjects.");

		IManagedObjectId[] vecAllowedObjects = AAServerCache.getInstance()
				.filterAccessibleObjects(criteria, sessionContext, null);

		LOGGER.debug("Exiting filterAccessibleObjects.");

		return vecAllowedObjects;
	}

	@Override
	public IManagedObjectId[] filterAccessibleObjects(String operation, IManagedObjectMarkableId... criteria) {
		LOGGER.debug("Entering filterAccessibleObjects.");

		IManagedObjectId[] vecAllowedObjects = AAServerCache.getInstance()
				.filterAccessibleObjects(criteria, sessionContext, operation);

		LOGGER.debug("Exiting filterAccessibleObjects.");

		return vecAllowedObjects;
	}
}
