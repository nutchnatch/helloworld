/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	LMLogRecordData
 * Author      	Vinay Purohit
 * Substitute	Jogendra Singh
 * Created on	26-07-2004
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.LOGGING.VIEW
 *          TNMS.DX2.SM.LOGGING.ALARM
 *          TNMS.DX2.SM.LOGGING.ALARM.DOMAIN
 *          TNMS.DX2.SM.LOGGING.POLICY
 *          TNMS.DX2.SM.LOGGING.MAPPING
 *          TNMS.DX2.SM.LOGGING.CREATE

 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.logging;

import com.ossnms.bicnet.bcb.model.logMgmt.Status;

import java.io.Serializable;
import java.security.InvalidParameterException;
/**
* This class holds the data of the security log record.
*/
public class LMLogRecordData implements Serializable {

	/**
     * 
     */
    private static final long serialVersionUID = 1L;

    /* private data members */
	/**
	 * Data member to hold activity name to be logged as
	 */
	private transient LMLogRecordEnum activityName;
	/**
	 * Data member to hold activity details
	 */
	private String activityDetails;
	/**
	 * Data member to hold activity status
	 */
	private String successStatus;
	/**
	 * Data member to hold 'private' or 'public' interfaces used for the activity
	 */
	private String interfaceType;
	/**
	 * Data member to hold command classification
	 */
	private String commandClassification;
	/**
	 * Data member to hold attempts for the activity
	 */
	private String accessAttemptCounter;
	/**
	 * Activity description for log record
	 */
	private String description;

	private static final int _FIRST = 0;
	public static final int _SUCCESS = 0;
	public static final int _FAILURE = 1;
	private static final int _LAST = 1;

	private static final String[] ARR_STATUS = { Status.fromOrdinal(0).guiLabel(), Status.fromOrdinal(1).guiLabel() };

	/**
	 * Default constructor 
	 */
	public LMLogRecordData() {
	}

	/* constructor */
	public LMLogRecordData(
		LMLogRecordEnum activityName,
		String activityDetails,
		int successStatus,
		String interfaceType,
		String commandClassification,
		String accessAtemptCounter,
		String description) {
		this.description = description;
		this.activityName = activityName;
		this.activityDetails = activityDetails;
		this.successStatus = getStatusString(successStatus);
		this.interfaceType = interfaceType;
		this.commandClassification = commandClassification;
		this.accessAttemptCounter = accessAtemptCounter;
	}

	private String getStatusString(int pValue) {
		if ((_FIRST <= pValue) && (pValue <= _LAST)) {
			return ARR_STATUS[pValue];
		}
		throw new InvalidParameterException();
	}

	/**
	 * Returns the activity for the security log records
	 * @return String - name of the activity to be recorded in security log record
	 */
	public LMLogRecordEnum getActivityName() {
		return activityName;
	}

	/** 
	 * Sets the activity Name attribute in this local object (does not invoke a remote call) 
	 */
	public void setActivityName(LMLogRecordEnum activityName) {
		this.activityName = activityName;
	}

	/**
	* Returns the activity details for the security log records
	* @return String - Activity name to be recorded
	*/
	public String getActivityDetails() {
		return activityDetails;
	}

	/** 
	 * Sets the activityDetails attribute in this local object (does not invoke a remote call) 
	 */
	public void setActivityDetails(String activityDetails) {
		this.activityDetails = activityDetails;
	}

	/**
	* Returns the status of the activity for the security log records
	* @return String - Status of the log to be records
	*/
	public String getSuccessStatus() {
		return successStatus;
	}

	/** 
	 * sets the successStatus attribute in this local object (does not invoke a remote call) 
	 */
	public void setSuccessStatus(String successStatus) {
		this.successStatus = successStatus;
	}
	/**
	* Returns the interfaces used to perform the activity for the security log records
	* @return String - interfaces used for activity
	*/
	public String getInterfaceType() {
		return interfaceType;
	}
	/** 
	 * sets the interfaceType attribute in this local object (does not invoke a remote call) 
	 */
	public void setInterfaceType(String interfaceType) {
		this.interfaceType = interfaceType;
	}
	/**
	* Returnsclassification of the activity for the security log records
	* @return String - activity classification
	*/
	public String getCommandClassification() {
		return commandClassification;
	}
	/** 
	 * sets the commandClassification attribute in this local object (does not invoke a remote call) 
	 */
	public void setCommandClassification(String commandClassification) {
		this.commandClassification = commandClassification;
	}
	/**
	 * Returns the number of attempts for the activity
	 * @return String - number of attempts
	 */
	public String getAccessAttemptCounter() {
		return accessAttemptCounter;
	}
	/** 
	 * sets the accessAtemptCounter attribute in this local object (does not invoke a remote call) 
	 */
	public void setAccessAttemptCounter(String accessAtemptCounter) {
		this.accessAttemptCounter = accessAtemptCounter;
	}
	/**
	 * 
	 * contains a human-readable description of the log record details
	 */
	public String getDescription() {
		return description;
	}
	/** 
	 * sets the description attribute in this local object (does not invoke a remote call) 
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
    public String toString() {
		return toString(this);
	}
	public static String toString(LMLogRecordData arg) {
		return "activityName="
			+ arg.getActivityName()
			+ ",\n\t\t"
			+ "activityDetails="
			+ arg.getActivityDetails()
			+ ",\n\t\t"
			+ "successStatus="
			+ arg.getSuccessStatus()
			+ ",\n\t\t"
			+ "interfaceType="
			+ arg.getInterfaceType()
			+ ",\n\t\t"
			+ "commandClassification="
			+ arg.getCommandClassification()
			+ ",\n\t\t"
			+ "accessAtemptCounter="
			+ arg.getAccessAttemptCounter()
			+ ",\n\t\t"
			+ "description="
			+ arg.getDescription();
	}
}