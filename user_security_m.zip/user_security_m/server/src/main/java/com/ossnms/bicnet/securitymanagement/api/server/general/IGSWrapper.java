package com.ossnms.bicnet.securitymanagement.api.server.general;

import com.ossnms.bicnet.securitymanagement.common.auth.PasswordValidationRulesConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.bicnet.securitymanagement.common.general.ldap.LDAPConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.radius.configuration.RadiusConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.sso.SSOConfigurationData;

import java.util.Map;

/**
 * created on 15/9/2014
 */
public interface IGSWrapper {

    void init();

    /**
     * Wraps DAO calls for retrieving general setting data.
     *
     * @return GSGeneralSettingData Returns the general setting details wrapped.
     */
    GSGeneralSettingData getGeneralSettingData();

    /**
     * Wraps DAO calls to retrieve Single Sign On data
     * @return SSOConfigurationData instance
     */
    SSOConfigurationData getSingleSignOnConfiguration();

    /**
     * Wraps DAO calls to retrieve Password Validation Rules Configuration Data.
     * @return PasswordValidationRulesConfigurationData instance
     */
    PasswordValidationRulesConfigurationData getPasswordValidationRulesConfiguration();

    /**
     * Wraps DAO calls to retrieve LDAP configuration data
     * @return LDAPConfigurationData instance
     */
    LDAPConfigurationData getLdapConfigurationData();

    /**
     * Wraps DAO calls to retrieve RADIUS configuration data
     * @return {@link RadiusConfigurationData} instance
     */
    RadiusConfigurationData getRadiusConfigurationData();

    /**
     * Wraps DAO calls for updating general setting data.
     *
     * @param generalSettingData - General Setting details.
     * @return boolean = Returns true or false for the security setting
     *         operation
     */
    boolean setGeneralSetting(GSGeneralSettingData generalSettingData);

    /**
     * Wraps DAO calls which update ldap configuration data
     *
     * @param configurationData ldap configuration settings
     * @return returns true if all the settings were saved successfully, false otherwise
     */
    boolean setLdapConfigurationData(LDAPConfigurationData configurationData);

    /**
     * Wraps DAO calls which update password validation rules configuration data
     * @param passwordValidationRulesConfigurationData password validation rules configuration data
     * @return returns true if all the settings were saved successfully, false otherwise
     */
    boolean setPasswordValidationRulesData(PasswordValidationRulesConfigurationData passwordValidationRulesConfigurationData);

    /**
     * Wraps DAO calls for retrieving password policy (general setting data.
     *
     * @return int - Returns the maximum unsuccessful login attempts allowed.
     */
    int getPasswordPolicyData();

    /**
     * Wraps DAO calls for retrieving default password
     *
     * @return String - Returns the default password for importing users.
     */
    String getDefaultPassword();
    
    /**
     * Wraps DAO calls for retrieving the value for the requested property
     */
    String getPropertyValue(GSProperty property);
    
    /**
     * Wraps DAO calls for setting value for a certain property
     */
    boolean setPropertyValue(GSProperty property, String value);

    boolean setPropertyValue(Map<GSProperty, String> properties);
}
