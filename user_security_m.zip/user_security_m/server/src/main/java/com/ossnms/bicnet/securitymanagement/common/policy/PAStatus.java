package com.ossnms.bicnet.securitymanagement.common.policy;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;

import java.util.Hashtable;
import java.util.Map;

/**
 * This is the class which represents the Status of the operation.
 */
public enum PAStatus {

	/**
	 * This error code indicates that the initiated operation failed because of
	 * some internal NON_LOGICAL error.
	 */
	S_INTERNAL_ERROR (1),

	/**
	 * This error code indicates that an Error has occurred during performing an
	 * DB Operation. The DB Operation could be Creation Modification
	 * Deletion of an DB Object.
	 */
	S_PERSISTENCE_ERROR(2),

	/**
	 * Indicates that the Operation initiated has been successful.
	 */
	S_SUCCESS (3),

	/**
	 * This error code indicates that there already exists a Policy with the
	 * same name. 2 policies with the same name cannot be existing.
	 */
	S_POLICY_ALREADY_EXISTS (4),

	/**
	 * This error code indicates that the policy that has been selected to be
	 * deleted from DB has already been deleted.
	 */
	S_POLICY_DOES_NOT_EXIST (5),

	/**
	 * This error code indicates that the policy selected to be deleted cannot
	 * be deleted since it is a part of a Domain Mapping.
	 */
	S_POLICY_CANNOT_BE_DELETED_SINCE_MAPPED (6),

	/**
	 * This error code indicates that the Maximum number of Policies allowed
	 * for creation is exceeded.
	 */
	S_POLICY_MAXIMUM_LIMIT_REACHED (7),

	/**
	 * This error code indicates that the Policy being created contains some
	 * menu entries which are not a part of the Global Security
	 */
	S_POLICY_CONTAINS_UNRECOG_MENUS (8),

	/**
	 * This error code indicates that the Policy name is invalid
	 */
	S_POLICY_NAME_INVALID (9),

	/**
	 * This error code indicates that the Policy name is invalid
	 */
	S_POLICY_IMPORT_GLOBAL (10),
	
	/**
	 * This error code indicates that the import for domain contains Ne no longer valid
	 */
	S_DOMAIN_IMPORT_INVALID_NE (11);

	private int id;

	/**
	 * Data member to hold the look up for the status to the string that needs
	 * to be displayed.
	 * 
	 */
	private static Map<PAStatus, String> stringLookupMap = new Hashtable<>();

	/**
	 * Constructor
	 *
	 * @param statusValue
	 */
	PAStatus(int statusValue) {
		this.id = statusValue;
	}
	static {
		stringLookupMap.put(S_INTERNAL_ERROR, "An internal error has occured");
		stringLookupMap.put(S_PERSISTENCE_ERROR, "A DB error has occurred");
		stringLookupMap.put(S_SUCCESS, " ");
		stringLookupMap.put(S_POLICY_ALREADY_EXISTS, "A policy with the same name already exists");
		stringLookupMap.put(S_POLICY_DOES_NOT_EXIST, "This policy has been deleted from another Client");
		stringLookupMap.put(S_POLICY_CANNOT_BE_DELETED_SINCE_MAPPED, "This policy cannot be deleted since it is part of one or more mappings");
		stringLookupMap.put(S_POLICY_MAXIMUM_LIMIT_REACHED, "Maximum number of policies reached. Delete and then try to create a policy");
		stringLookupMap.put(S_POLICY_CONTAINS_UNRECOG_MENUS, "The Policy contains Menu entries which are not recognized");
		stringLookupMap.put(S_POLICY_NAME_INVALID, "Policy name is invalid, possible reasons could be: \nBegins or ends with space \nContains characters \\/?<>:*\"|# \nContains more than 64 characters");
		stringLookupMap.put(S_POLICY_IMPORT_GLOBAL, "GLOBAL Policy  can not be created/modified");
		stringLookupMap.put(S_DOMAIN_IMPORT_INVALID_NE, "Invalid Nes to be included in domain");
	}

	/**
	 * Function to get the Status of this object
	 * 
	 * @return int The Integer equivalent of the Status object.
	 */
	public int getStatus() {
		return id;
	}

	/**
	 * Function to push this object into the message. Will be used for
	 * transferring this object between the server and the client.
	 * 
	 * @param msg
	 *            The Message into which we have to push this object.
	 */
	public void pushMe(USMMessage msg) {
		msg.pushInteger(id);
	}

	public static PAStatus pop(USMMessage msg){
		return PAStatus.valueOf(msg.popInteger());
	}

	/**
	 *
	 * @param value
	 * @return
	 */
	public static PAStatus valueOf(int value){
		for(PAStatus status : values()){
			if(status.getStatus() == value){
				return status;
			}
		}
		return null;
	}

	/**
	 * Function to return the Error String for this Status Object.
	 * 
	 * @return java.lang.String The String which represents the error for this
	 *         status object.
	 */
	public String getErrorString() {
		return stringLookupMap.get(this);
	}
}
