/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Asif			CF000427 - Implementation of the XML import mechanism needed for the migration process
 * 09-Feb-2005  Babu B          CF000459   Choose for a User Group the Assigned Policy "NONE" - not the correct behaviour!
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.importexport;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.importexport.IEDataObject;
import com.ossnms.bicnet.securitymanagement.common.importexport.IEMessageType;
import com.ossnms.bicnet.securitymanagement.server.domain.DCSubsystemSAP;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityImportExportPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.policy.PASubsystemSAP;
import com.ossnms.bicnet.securitymanagement.server.useradministration.UASubsystemSAP;

import java.util.ArrayList;
import java.util.List;

public class IEImportExportPOJOImpl implements ISecurityImportExportPrivateFacade {

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityImportExportPrivateFacade#importSecurityData
     * (com.ossnms.bicnet.bcb.facade.security.ISessionContext, java.util.List, java.lang.String, java.lang.Boolean)
     */
    @Override
    public USMMessage importSecurityData(ISessionContext ctx, List<IEDataObject> securityData, String type, Boolean overWrite) throws BcbSecurityException {

        USMMessage msg = new USMMessage(IEMessageType.IE_RES_IMPORT, USMMessage.USMMESSAGE_RESPONSE);
        boolean bVal = overWrite;
        if (0 == type.compareTo(IEDataObject.DOMAIN)) {
            DCSubsystemSAP.importDomains(ctx, securityData, bVal);
        } else if (0 == type.compareTo(IEDataObject.POLICY)) {
            PASubsystemSAP.importPolicies(ctx, securityData, bVal);
        } else if (0 == type.compareTo(IEDataObject.MAPPING)) {
            DCSubsystemSAP.importMappings(ctx, securityData, bVal);
        } else if (0 == type.compareTo(IEDataObject.USER)) {
            UASubsystemSAP.importUsers(ctx, securityData, bVal);
            IEMigrationHelper.migrateUsersIfNeeded(ctx, securityData, bVal);
        } else if (0 == type.compareTo(IEDataObject.USER_GROUP)) {
            UASubsystemSAP.importUserGroups(ctx, securityData, bVal);
        }

        removeSuccssfullyImportedData(securityData);
        pushIEObjectsIntoMessage(securityData, msg);
        return msg;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityImportExportPrivateFacade#exportSecurityData
     * (com.ossnms.bicnet.bcb.facade.security.ISessionContext, java.lang.String)
     */
    @Override
    public USMMessage exportSecurityData(ISessionContext ctx, String typeOfData) throws BcbSecurityException {

        USMMessage msg = new USMMessage(IEMessageType.IE_RES_EXPORT, USMMessage.USMMESSAGE_RESPONSE);
        List<IEDataObject> exportedData = new ArrayList<>();
        if (0 == typeOfData.compareTo(IEDataObject.DOMAIN)) {
            DCSubsystemSAP.exportDomains(ctx, exportedData);
        } else if (0 == typeOfData.compareTo(IEDataObject.POLICY)) {
            PASubsystemSAP.exportPolicies(ctx, exportedData);
        } else if (0 == typeOfData.compareTo(IEDataObject.MAPPING)) {
            DCSubsystemSAP.exportMappings(ctx, exportedData);
        } else if (0 == typeOfData.compareTo(IEDataObject.USER)) {
            UASubsystemSAP.exportUsers(ctx, exportedData);
        } else if (0 == typeOfData.compareTo(IEDataObject.USER_GROUP)) {
            UASubsystemSAP.exportUserGroups(ctx, exportedData);
        }

        // Sent it back finally
        pushIEObjectsIntoMessage(exportedData, msg);
        return msg;
    }

    /**
     * Helper function to remove all those data which were successfully imported.
     * 
     * @param lstData
     *            The List which has to be filtered.
     */
    private void removeSuccssfullyImportedData(List<IEDataObject> lstData) {
        int nNoOfElms = lstData.size();
        for (int idx = nNoOfElms - 1; idx >= 0; idx--) {
            IEDataObject data = lstData.get(idx);
            String str = data.getErrorString();
            if ((str == null) || (str.length() == 0)) {
                lstData.remove(idx);
            }
        }
    }

    private void pushIEObjectsIntoMessage(List<IEDataObject> lst, USMMessage msg) {
        int nNoOfObjs = lst.size();
        for (int i = 0; i < nNoOfObjs; ++i) {
            msg.pushObject(lst.get(i));
        }
        msg.pushInteger(nNoOfObjs);
    }
}