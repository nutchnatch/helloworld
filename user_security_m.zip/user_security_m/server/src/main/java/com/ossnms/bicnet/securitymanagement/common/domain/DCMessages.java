/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCMessages
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CREATE
 * 		:	TNMS.DX2.SM.DOMAIN.CONFIG
 * 		:	TNMS.DX2.SM.DOMAIN.VIEW
 * 		:	TNMS.DX2.SM.MAPPING.CREATE
 * 		:	TNMS.DX2.SM.MAPPING.VIEW
 *  
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005  Asif            CF000427 - Implementation of the XML import mechanism needed for the migration process
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.common.domain;

import com.ossnms.bicnet.securitymanagement.common.useradministration.UACommonHelper;

import java.util.Hashtable;
import java.util.Map;

/**
 * This class stores the messages that get displayed. It is also used to pass the id which from the server and needs to
 * be mapped to a string on the client side
 */
public final class DCMessages {
    public static final Integer DC_NO_ERROR = 0;
    public static final Integer DC_INTERNAL_ERROR = 1;
    public static final Integer DC_LDAP_ERROR = 2;
    public static final Integer DC_DUPLICATE_NAME = 3;
    public static final Integer DC_DOMAIN_INVALID = 4;
    public static final Integer DC_MAX_DOMAIN = 5;
    public static final Integer DC_DOMAIN_NAME_INVALID = 6;
    public static final Integer DC_FAILED_TO_ASSIGN_NES = 7;
    public static final Integer DC_DOMAIN_NAME_BLANK = 8;
    public static final Integer DC_VIEW_ACCESS_RIGHTS = 9;
    public static final Integer DC_NOT_ALL_MAPPINGS_ASSIGNED = 11;
    public static final Integer DC_ERR_GLOBAL_DOMAIN_NOT_MODIFIED = 12;
    public static final Integer DC_ERROR_COMMUNICATION = 13;
    public static final Integer DC_ERROR_SERVER_EXCEPTION = 14;
    public static final Integer DC_ERROR_POLICY_INVALID = 15;
    public static final Integer DC_ERROR_DOMAIN_INVALID = 16;
    public static final Integer DC_ERROR_DUPLICATE_MAPPING = 17;
    public static final Integer DC_ERROR_MAPPING_EXISTS = 18;
    public static final Integer DC_ERROR_GROUP_INVALID = 19;
    public static final Integer DC_ERROR_GLOBAL_MAPPING_MODIFIED = 20;
    public static final Integer DC_DOMAIN_MAPPED_ERROR = 21;

    public static final Integer DC_GLOBAL_DOMAIN = 1000;
    public static final Integer DC_GLOBAL_GROUPS = 1001;

    private Map<Integer, String> mapOfIdsVersusString = new Hashtable<>();
    private static DCMessages self = new DCMessages();

    /**
     * This is a protection mechanism offered, in case the id is not mapped to a string, in which case the caller may
     * fail when trying to print the string
     */
    public static final String SPACE = " ";

    public void init() {
        mapOfIdsVersusString = new Hashtable<>();
        mapOfIdsVersusString.put(DC_NO_ERROR, "");
        mapOfIdsVersusString.put(DC_INTERNAL_ERROR, "There was an internal error which has occured.");
        mapOfIdsVersusString.put(DC_LDAP_ERROR, "Operation failed because of a LDAP error.");
        mapOfIdsVersusString.put(DC_DUPLICATE_NAME, "Domain name is duplicated, Try another name for the domain.");
        mapOfIdsVersusString.put(DC_DOMAIN_INVALID, "Domain is not valid anymore, some other client could have deleted it.");
        mapOfIdsVersusString.put(DC_MAX_DOMAIN, "Maximum number of domains reached. Delete and then try to create a domain.");
        mapOfIdsVersusString.put(DC_DOMAIN_NAME_INVALID, "Domain name is invalid, possible reasons could be: \nContains only blanks \nContains characters +=\\;\"/<>,# \nContains more than 64 characters.");
        mapOfIdsVersusString.put(DC_FAILED_TO_ASSIGN_NES, "Failed to assign/unassign objects to a domain.");
        mapOfIdsVersusString.put(DC_DOMAIN_NAME_BLANK, "Domain name is blank.");
        mapOfIdsVersusString.put(DC_VIEW_ACCESS_RIGHTS, "Access Rights");
        mapOfIdsVersusString.put(DC_NOT_ALL_MAPPINGS_ASSIGNED, "Mappings could not be assigned.");
        mapOfIdsVersusString.put(DC_ERR_GLOBAL_DOMAIN_NOT_MODIFIED, "Global domain cannot be modified.");
        mapOfIdsVersusString.put(DC_ERROR_COMMUNICATION, "Server could not be contacted. Please check the server logs and try again.");
        mapOfIdsVersusString.put(DC_ERROR_SERVER_EXCEPTION, "Server threw an exception. Please check the server logs and try again.");

        mapOfIdsVersusString.put(DC_ERROR_POLICY_INVALID, "Policy part of the mapping is not available or has been deleted.");
        mapOfIdsVersusString.put(DC_ERROR_DOMAIN_INVALID, "Domain part of the mapping is not available or has been deleted.");
        mapOfIdsVersusString.put(DC_ERROR_GROUP_INVALID, "User Group part of the mapping is not available or has been deleted.");
        mapOfIdsVersusString.put(DC_ERROR_DUPLICATE_MAPPING, "An exact mapping already exists.");
        mapOfIdsVersusString.put(DC_ERROR_MAPPING_EXISTS, "Mapping for the user group and domain is already exists.");
        mapOfIdsVersusString.put(DC_ERROR_GLOBAL_MAPPING_MODIFIED, "Global Mapping cannot be modified.");
        mapOfIdsVersusString.put(DC_DOMAIN_MAPPED_ERROR, "The domain is mapped.");
        

        // These are the hardcoded strings to be displayed
        mapOfIdsVersusString.put(DC_GLOBAL_DOMAIN, "GLOBAL");
        mapOfIdsVersusString.put(DC_GLOBAL_GROUPS, UACommonHelper.ADMIN_GROUP_NAME);

    }

    /**
     * Access to the singleton class
     * 
     * @return DCErrorMessage singleton class
     */
    public static DCMessages getInstance() {
        return self;
    }

    /**
     * Default constructor
     */
    private DCMessages() {
        init();
    }

    /**
     * Function to retrieve the displayable error string given the error id
     * 
     * @param p_errId
     *            The id whose corresponding string has to be fetched
     * @return java.lang.String Returns a user displayable string corresponding to the id
     */
    public String getString(Integer p_errId) {
        String obj = mapOfIdsVersusString.get(p_errId);
        if (null == obj) {
            // It could so happen that the error code was defined, but no added, in which case the client should not crash
            return SPACE;
        }
        return obj;
    }
}