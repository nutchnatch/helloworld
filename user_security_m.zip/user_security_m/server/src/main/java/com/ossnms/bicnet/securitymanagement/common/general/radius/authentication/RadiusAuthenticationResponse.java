package com.ossnms.bicnet.securitymanagement.common.general.radius.authentication;

/**
 *
 */
public enum RadiusAuthenticationResponse {

    ACCEPTED (2),
    REJECTED (3),
    CONNECTION_ERROR(0);

    private int ordinal;

    RadiusAuthenticationResponse(int ordinal) {
        this.ordinal = ordinal;
    }

    /**
     *
     * @param ordinal
     * @return
     */
    public static RadiusAuthenticationResponse fromOrdinal(int ordinal) {
        for(RadiusAuthenticationResponse response : values()){
            if(response.ordinal == ordinal){
                return response;
            }
        }

        return null;
    }
}
