package com.ossnms.bicnet.securitymanagement.common.crypto;

import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.apache.log4j.Logger;

import com.ossnms.bicnet.bcb.model.BcbException;

/**
 * An encrypter and decrypter for DES encryption in CBC mode and using PKCS#5 padding.
 * 
 * @author João Pires and Joana Cruz
 */
public final class USMEncrypterDecrypter {
	private static final Logger LOGGER = Logger.getLogger(USMEncrypterDecrypter.class);
	private static final String DES = "DES";
    private static final String CIPHER_STRING = "DES/CBC/PKCS5Padding";
    
    private final byte[] iv =  { (byte) 0x8E, 0x12, 0x39, (byte) 0x9C, 0x07, 0x72, 0x6F, 0x5A };
    private final byte[] key = { (byte) 0x8E, 0x12, 0x39, (byte) 0x9C, 0x07, 0x72, 0x6F, 0x5A };
        
    private Cipher encryptingCipher;
    private Cipher decryptingCipher;
    private boolean isCryptoInitialized;
    
    private static USMEncrypterDecrypter instance;
    
    static {
    	USMEncrypterDecrypter myInstance = null;
    	try {
    		myInstance = new USMEncrypterDecrypter();
		} catch (GeneralSecurityException e) {
			LOGGER.error(e);
		}
    	instance = myInstance;
    }
    
    /**
     * Builds a DES encrypter and decrypter in CBC mode with the given key and initial value
     * 
     * @param key the shared key used for encryption and decryption
     * @param iv the initial value to be used (because of CBC mode)
     * @throws InvalidKeyException when an invalid key is given
     * @throws InvalidAlgorithmParameterException when an invalid initial value is given
     * @throws NoSuchPaddingException 
     * @throws NoSuchAlgorithmException 
     */
	private USMEncrypterDecrypter() throws InvalidKeyException, InvalidAlgorithmParameterException, NoSuchAlgorithmException, NoSuchPaddingException {
		LOGGER.debug("USMEncrypterDecrypter() Entry");
		
		IvParameterSpec parameterSpec = new IvParameterSpec(iv);
		SecretKey secretKey = new SecretKeySpec(key, DES);

		encryptingCipher = Cipher.getInstance(CIPHER_STRING);
		decryptingCipher = Cipher.getInstance(CIPHER_STRING);

		encryptingCipher.init(Cipher.ENCRYPT_MODE, secretKey, parameterSpec);
		decryptingCipher.init(Cipher.DECRYPT_MODE, secretKey, parameterSpec);
		
		isCryptoInitialized = true;
		
		LOGGER.debug("USMEncrypterDecrypter() Exit");
	}

	/**
	 * This method is used to retrieve the singleton instance for issues related
	 * with cipher.
	 * 
	 * @return Singleton instance of this class.
	 */
	public static USMEncrypterDecrypter getInstance() {
		LOGGER.debug("getInstance() Called");
		return instance;
	}
	
    /**
     * Decrypt a base64 encoded, DES encrypted data, as a string, and return the
     * unencrypted string.
     * 
     * @param encryptedData
     *            The base64 encoded data, as a string, to decrypt.
     * @return decryptedData The decrypted data, as a string.
     * @throws BcbException
     *             If an error occurs.
     */
    public String decryptDataBase64(String encryptedData) throws BcbException {
        try {
        	LOGGER.debug("decryptData() Entry");
        	
        	byte[] decodedBytes = DatatypeConverter.parseBase64Binary(encryptedData);
            byte[] unencryptedByteArray = decryptingCipher.doFinal(decodedBytes);
            
            return new String(unencryptedByteArray, "UTF8");
            
        } catch (UnsupportedEncodingException e) {
            throw new BcbException(e);
        } catch (IllegalBlockSizeException e) {
            throw new BcbException(e);
        } catch (BadPaddingException e) {
            throw new BcbException(e);
        } finally {
        	LOGGER.debug("decryptData() Exit");
        }
    }
	
    /**
     * Encrypt a string using DES algorithm, and return the encrypted string as
     * a base64 encoded string.
     * 
     * @param unencryptedData
     *            The data, as a string, to encrypt.
     * @return encryptedData The DES encrypted and base 64 encoded data, as a
     *         string.
     * @throws BcbException
     *             If an error occurs.
     */
    public String encryptDataBase64(String unencryptedData) throws BcbException {
        try {
        	LOGGER.debug("encryptData() Entry");
        	
        	byte[] unencryptedByteArray = unencryptedData.getBytes("UTF8");
            byte[] encryptedBytes = encryptingCipher.doFinal(unencryptedByteArray);
            
            return DatatypeConverter.printBase64Binary(encryptedBytes);
            
        } catch (UnsupportedEncodingException e) {
           throw new BcbException(e);
        } catch (IllegalBlockSizeException e) {
            throw new BcbException(e);
        } catch (BadPaddingException e) {
            throw new BcbException(e);
        } finally {
        	LOGGER.debug("encryptData() Exit");
        }
    }
	
    /**
     * This method is used to encrypt data using the defined IV and KEY.
     * @param original
     * 		Information in plain text that should be encrypted. 
     * @return
     * 		Byte array with encrypted data.
     */
	public byte[] encryptData(byte[] original) throws BcbException {
        LOGGER.debug("encryptData() Entry");
		
		try {
			return encryptingCipher.doFinal(original);
			
		} catch (IllegalBlockSizeException e) {
		    throw new BcbException(e);
		} catch (BadPaddingException e) {
		    throw new BcbException(e);
		} finally {
			LOGGER.debug("encryptData() Exit");
		}
	}

    /**
     * This method is used to decrypt that was encrypted by the encryptData method, in order to retrieve the original data.
     * @param encryptedString
     * 		Byte array with encrypted data
     * @return
     * 		Byte array with original plain text information
     */
    public byte[] decryptData(byte[] encryptedString) throws BcbException{
		LOGGER.debug("decryptData() Entry");
    	
    	try {
            return decryptingCipher.doFinal(encryptedString);
            
        } catch (IllegalBlockSizeException e) {
            throw new BcbException(e);
        } catch (BadPaddingException e) {
            throw new BcbException(e);
        } finally {
   			LOGGER.debug("decryptData() Exit");
        }
    }
    
    /**
	 * This method is used to perform decryption of data in the passed input
	 * stream. The method returns the input stream contains the decrypted data,
	 * if successful else null.
	 * 
	 * @param inputStream
	 *           The input stream object which needs to be decrypted.
	 * @return InputStream Returns the decrypted input stream. Return null if
	 *         some exception occured.
	 */
	public InputStream decryptData(InputStream inputStream) {
		LOGGER.debug("decryptData(InputStream inputStream) Entry");
		
		InputStream createdStream = new CipherInputStream(inputStream, decryptingCipher);

		LOGGER.debug("decryptData(InputStream inputStream) Exit");
		
		return createdStream;
	}
	
	/**
	 * This method is used to inform all the object that are using this class
	 * that is already to be used.
	 * 
	 * @return True if the objects associated to encrypt and decrypt are well
	 *         instantiate, otherwise false;
	 */
	public boolean isInitialized() {
		LOGGER.debug("initialize()");

		return isCryptoInitialized;
	}
}

