package com.ossnms.bicnet.securitymanagement.persistence.dao.domain;


import com.ossnms.bicnet.securitymanagement.api.persistence.dao.domain.IUSMDomainDao;
import com.ossnms.bicnet.securitymanagement.persistence.dao.AbstractBaseDao;
import com.ossnms.bicnet.securitymanagement.persistence.model.domain.USMDomain;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.Query;

/**
 * created on 28/8/2014
 */
@Stateless(name="IUSMDomainDao")
@Local
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class USMDomainDao extends AbstractBaseDao<USMDomain, Integer> implements IUSMDomainDao{

    @Override
    public USMDomain findByName(String name) {
        Query query = getEntityManager()
                .createNamedQuery(USMDomain.QUERY_FIND_BY_NAME)
                .setParameter(USMDomain.PARAM_1_FIND_BY_NAME, name);

        return getSingleResult(query);
    }

}
