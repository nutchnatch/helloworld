/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 *  Class Name 	UAUserNameAndID
 * Author:      Vinay Purohit
 * Substitute	Babu B
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER.VIEW
 *       : TNMS.DX2.SM.FORCE_LOGOFF
 *       : TNMS.DX2.SM.USER.CREATE
 *       : TNMS.DX2.SM.USER.CONFIGURE
 * 	     : TNMS.DX2.SM.USER.ASSIGN
 *       : TNMS.DX2.SM.USER.STATUS
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.useradministration;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import org.apache.log4j.Logger;

import java.io.Serializable;
/**
 * This Transient class contains identification data of a User. 
 */
public class UAUserNameAndID implements Serializable {
	/**
     * 
     */
    private static final long serialVersionUID = 1L;

    /**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(UAUserNameAndID.class);

	/**
	 * Data member to hold user id
	 */
	private String strUserId;

	/**
	 * Data member to hold user common name
	 */
	private String strCommonName;

	/**
	 * Default constructor
	 *
	 */
	public UAUserNameAndID() {
	}

	/**
	 * Construct UAUser 
	
	* @param userId stores the ID of  the user	
	* @param commonName  stores the common name  of the user	*
	*/
	public UAUserNameAndID(String userId, String commonName) {
		strCommonName = commonName;
		strUserId = userId;
	}

	/**
	 * This method is responsible for extracting the user identification data from USMMessage
	 * 
	 * @param msg 
	 *      USMMessage which encapsulates the given UAUser
	 */
	public void popMe(USMMessage msg) {
		strCommonName = msg.popString();
		strUserId = msg.popString();
	}

	/**
	 * This Method is responsible for encapsulating the users into USMMessage
	 * 
	 * @param msg 
	 *      USMMessage which encapsulates the given UAUser
	 */
	public void pushMe(USMMessage msg) {

		msg.pushString(strUserId);
		msg.pushString(strCommonName);
	}

	/**
	 * returns the common name of user
	 * @return
	 *      common name of the user
	 */
	public String getCommonName() {
		return strCommonName;
	}

	/**
	 * Method to get the userid of the user
	 * @return 
	 *      userid of the user
	 */
	public String getUserId() {
		return strUserId;
	}

	/**
	 * Sets the common name of the user
	 * @param p_strCommonName
	 *      The common name for the user 
	 */
	public void setCommonName(String p_strCommonName) {
		strCommonName = p_strCommonName;
	}

	/**
	 * Sets the userid of the user
	 * @param string
	 */
	public void setUserId(String p_strUserId) {
		strUserId = p_strUserId;
	}

	/**
	 * Function to retrieve the String equivalent of this object.
	 * 
	 * @return java.lang.String 
	 *      The String which is a representation of this object.
	 */
	@Override
    public String toString() {
		return strCommonName + " [" + strUserId + "]";
	}

	/**
	 * Function to compare 2 objects for equality.
	 * 
	 * @param p_obj
	 *            The Object which has to be compared with this object.
	 * @return boolean Indicates whether the 2 objects are equal or not. True
	 *         indicates that the objects are equal.
	 */
	@Override
    public boolean equals(Object p_obj) {
		boolean bOp = false;
		if (p_obj instanceof UAUserNameAndID) {
			UAUserNameAndID userObj = (UAUserNameAndID) p_obj;
			int nComp = strUserId.compareToIgnoreCase(userObj.getUserId());
			bOp = (nComp == 0) ? true : false;
		} else {
			LOGGER.error("Equality check using a wrong type");
		}
		return bOp;
	}

	/**
	 * Returns the hash code value for this Field. 
	 * 
	 * @return
	 *      the integer hash code
	 */
	@Override
    public int hashCode() {
		return strUserId.hashCode();
	}

}
