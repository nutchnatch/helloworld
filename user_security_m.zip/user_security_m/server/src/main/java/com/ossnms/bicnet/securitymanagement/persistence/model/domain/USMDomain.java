package com.ossnms.bicnet.securitymanagement.persistence.model.domain;

import com.ossnms.bicnet.securitymanagement.persistence.model.BaseUSMEntity;

import javax.persistence.*;

/**
 * created on 28/8/2014
 */
@Entity
@Table(name = "USM_DOMAIN")
@NamedQueries({
        @NamedQuery(name="usmDomain.findByName", query = "from USMDomain d where d.name = :domainName")
})
public class USMDomain extends BaseUSMEntity {

    private static final long serialVersionUID = 7093815872125924554L;

    public static final String QUERY_FIND_BY_NAME = "usmDomain.findByName";
    public static final String PARAM_1_FIND_BY_NAME = "domainName";

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO, generator="USMDomainSequence")
    @SequenceGenerator(name="USMDomainSequence", sequenceName="USM_SEQ_DOMAIN")
    @Column(name = "CONT")
    private Integer id;

    @Column(name = "NAME", unique = true, nullable = false)
    private String name;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "CREATION_ID", nullable = false)
    private int creationId;

    public USMDomain() {
        super();
    }

    @Override
    public boolean isNew() {
        return id == null || id == 0;
    }

    /**
     * Constructor
     *
     * @param name the name of the domain
     * @param description the description
     * @param creationId creation id (usually a timestamp) of the domain
     */
    public USMDomain(String name, String description, int creationId) {
        super();
        this.name = name;
        this.description = description;
        this.creationId = creationId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getCreationId() {
        return creationId;
    }

    public void setCreationId(int creationId) {
        this.creationId = creationId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }

        USMDomain usmDomain = (USMDomain) o;

        if (creationId != usmDomain.creationId){
            return false;
        }
        if (description != null ? !description.equals(usmDomain.description) : usmDomain.description != null){
            return false;
        }
        if (id != null ? !id.equals(usmDomain.id) : usmDomain.id != null){
            return false;
        }

        return !(name != null ? !name.equals(usmDomain.name) : usmDomain.name != null);

    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + creationId;
        return result;
    }
}
