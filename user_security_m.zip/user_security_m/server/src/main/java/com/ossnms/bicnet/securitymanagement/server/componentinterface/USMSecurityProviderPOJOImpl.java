/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Muyeen Munaver	CF000582 - InvalidAuthorizationInfoException in getSystemAccountContext()
 * 19-Jan-2005	Muyeen Munaver	CF000297 - Sync Step 1a)
 * 25-Jan-2005	Muyeen Munaver	CF001140 - Synchronize Network Alarms -> getAlarmObject -> calling failed
 * 05-Mar-2005  Muyeen Munaver  CF001936    Change Password throws exception, but password has been changed
 * 21-Apr-2005	Muyeen Munaver	CF002069 - login with invalid user => Probable reason is not coherent with the root cause
 * 05-May-2005  Babu B          CF001312   Master-Master Replication for Sun ONE DS
 * 05-Aug-2005  Shrinidhi G V   CF002751   9320_MR_0282 Why do we have the TMN Application Server Administration Window?
 * 08-Aug-2005	Balasubramanya	CF002760 - 9320_MR_0291 Users, User Groups, Policies lose associations after import
 * 08-Aug-2005	Balasubramanya	CF002759 - 9320_MR_0289 Security information discarded for user after deletion and restore
 * 11-Jan-2006  Balasubramanya  CF002773 - Missing correct computer name in window User Administration
 * 31-Jan-2007  Shrinidhi G V   CF004362-  9320_MR_0775: Any user can bring down the application.
 * 26-Aug-2005  Babu B          CF002773 - Missing correct computer name in window User Administration
 * 22-Sep-2005	Babu B			CF002960 - Security Menu items can not be enabled with self defined assign policy
 * 10-Aug-2007	Shrinidhi G V			TD000504-03 - Extend USM public facade with method to get ldap credentials
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.componentinterface;

import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmReply;
import com.ossnms.bicnet.bcb.facade.security.EnhancedSessionContextItem;
import com.ossnms.bicnet.bcb.facade.security.ILogonListener;
import com.ossnms.bicnet.bcb.facade.security.ISecureServerSession;
import com.ossnms.bicnet.bcb.facade.security.ISecurityMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.ComponentVersionInformation;
import com.ossnms.bicnet.bcb.model.common.File;
import com.ossnms.bicnet.bcb.model.common.IBiCNetComponentId;
import com.ossnms.bicnet.bcb.model.common.Log4jLevel;
import com.ossnms.bicnet.bcb.model.common.SyncCategory;
import com.ossnms.bicnet.bcb.model.common.TrafficDirection;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmMaskConfiguration;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmId;
import com.ossnms.bicnet.bcb.model.scs.ScsComponentState;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncMode;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.bcb.model.security.ISecurableObject;
import com.ossnms.bicnet.bcb.model.security.ISecurableObjectContainer;
import com.ossnms.bicnet.securitymanagement.common.auth.AASessionContext;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMenuNameList;
import com.ossnms.bicnet.securitymanagement.server.IBicNetServiceImpl;
import com.ossnms.bicnet.securitymanagement.server.IScsControllableImpl;
import com.ossnms.bicnet.securitymanagement.server.alarming.ALAlarmingImpl;
import com.ossnms.bicnet.util.versions.ServerComponentVersionInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.Handle;
import javax.security.auth.kerberos.KerberosTicket;
import java.util.Arrays;
import java.util.Properties;

/**
 * POJO implementation to the Public Facade
 */
public class USMSecurityProviderPOJOImpl extends USMNMSecurityProviderPOJOImpl implements ISecurityMgrFacade {

    private static final Logger LOGGER = LoggerFactory.getLogger(USMSecurityProviderPOJOImpl.class);

    private static final boolean NO_GUI_LOGON = true;

    /**
     * Constructor.
     *
     * It has to be a zero parameter constructor.
     */
    public USMSecurityProviderPOJOImpl() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering constructor for USMSecurityProviderPOJOImpl");
            LOGGER.debug("Exiting constructor for USMSecurityProviderPOJOImpl");
        }
    }

	/*
     * ******************************************************************
	 * The Following section is for the Methods defined in IBicNetService.
	 * ******************************************************************
	 */

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.common.IBicNetService#getDescription(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public String getDescription(ISessionContext sessionContext)
            throws BcbException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering getDescription.");
        }

        String strDesc = IBicNetServiceImpl.getInstance().getDescription(sessionContext);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting getDescription. Returning " + strDesc);
        }
        return strDesc;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.common.IBicNetService#getComponentType(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public BiCNetComponentType getComponentType(ISessionContext sessionContext)
            throws BcbException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering getComponentType.");
        }

        BiCNetComponentType type = IBicNetServiceImpl.getInstance().getComponentType(sessionContext);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting getComponentType. Returning " + type);
        }
        return type;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.common.IBicNetService#getName(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public String getName(ISessionContext sessionContext) throws BcbException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering getName.");
        }

        String strName = IBicNetServiceImpl.getInstance().getName(sessionContext);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting getName. Returning " + strName);
        }
        return strName;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.common.IBicNetService#getLog4JDefaultLevel(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public Log4jLevel getLog4JDefaultLevel(ISessionContext sessionContext)
            throws BcbException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering getLog4JDefaultLevel.");
        }

        Log4jLevel level = IBicNetServiceImpl.getInstance().getLog4JDefaultLevel(sessionContext);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting getLog4JDefaultLevel. Returning " + level);
        }
        return level;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.common.IBicNetService#getVersion(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public ComponentVersionInformation getVersion(ISessionContext sessionContext) throws UnsupportedOperationException {
        LOGGER.debug("Entering getVersion.");

        ComponentVersionInformation ver = ServerComponentVersionInfo.getVersionInfo(getClass());

        LOGGER.debug("Exiting getVersion. Returning " + ver);
        return ver;
    }

    /*
     * ******************************************************************
     * The Following section is for the Methods defined in IScsControllable.
     * ******************************************************************
     */
    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#start(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
    @Override
    public void start(ISessionContext sessionContext) throws BcbException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering start.");
        }

        IScsControllableImpl.getInstance().start(sessionContext);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting start");
        }
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#init(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public void init(ISessionContext sessionContext) throws BcbException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering init.");
        }

        IScsControllableImpl.getInstance().init(sessionContext);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting init");
        }
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#shutDown(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public void shutDown(ISessionContext sessionContext) throws BcbException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering shutDown.");
        }

        IScsControllableImpl.getInstance().shutDown(sessionContext);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting shutDown");
        }
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#stop(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public void stop(ISessionContext sessionContext) throws BcbException {
        LOGGER.debug("Entering stop.");

        IScsControllableImpl.getInstance().stop(sessionContext);

        LOGGER.debug("Exiting stop");
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#getState(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public ScsComponentState getState(ISessionContext sessionContext)
            throws BcbException {
        LOGGER.debug("Entering getState.");

        ScsComponentState state =
                IScsControllableImpl.getInstance().getState(sessionContext);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting getState. Returning " + state);
        }
        return state;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#isStartSupported(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public boolean isStartSupported(ISessionContext sessionContext)
            throws BcbException {
        LOGGER.debug("Entering isStartSupported.");

        boolean bStartSupported =
                IScsControllableImpl.getInstance().isStartSupported(sessionContext);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "Exiting isStartSupported. Returning " + bStartSupported);
        }
        return bStartSupported;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#isStopSupported(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public boolean isStopSupported(ISessionContext sessionContext)
            throws BcbException {
        LOGGER.debug("Entering isStopSupported.");

        boolean bStopSupported =
                IScsControllableImpl.getInstance().isStopSupported(sessionContext);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "Exiting isStopSupported. Returning " + bStopSupported);
        }
        return bStopSupported;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#isSyncSupported(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public boolean isSyncSupported(ISessionContext sessionContext)
            throws BcbException {
        LOGGER.debug("Entering isSyncSupported.");

        boolean bSyncSupported =
                IScsControllableImpl.getInstance().isSyncSupported(sessionContext);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "Exiting isSyncSupported. Returning " + bSyncSupported);
        }
        return bSyncSupported;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#doSync(com.ossnms.bicnet.bcb.facade.security.ISessionContext, com.ossnms.bicnet.bcb.model.common.IBiCNetComponentId[], com.ossnms.bicnet.bcb.model.scs.ScsSyncMode)
     */
    @Override
    public void doSync(ISessionContext sessionContext, IBiCNetComponentId[] with, ScsSyncMode syncMode, SyncCategory syncCategory)
            throws BcbException {
        LOGGER.debug("Entering doSync.");

        IScsControllableImpl.getInstance().doSync(sessionContext, with, syncMode, syncCategory);

        LOGGER.debug("Exiting doSync.");
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#doForcedSync(com.ossnms.bicnet.bcb.facade.security.ISessionContext, com.ossnms.bicnet.bcb.model.common.IBiCNetComponentId[], com.ossnms.bicnet.bcb.model.scs.ScsSyncMode)
     */
    @Override
    public void doForcedSync(ISessionContext sessionContext, IBiCNetComponentId[] with, ScsSyncMode syncMode, SyncCategory syncCategory)
            throws BcbException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering doForcedSync.");
        }

        IScsControllableImpl.getInstance().doForcedSync(sessionContext, with, syncMode, syncCategory);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting doForcedSync.");
        }

    }

    /*
     * ******************************************************************
     * The Following section is for the Methods defined in ISecurityProviderFacade.
     * ******************************************************************
     */
    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#getServerSession(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
    @Override
    public ISecureServerSession getServerSession(ISessionContext sessionContext)
            throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering getServerSession. SessionContext passed is : " + sessionContext);
        }

        ISessionContext objSessionContext;
        if(sessionContext instanceof EnhancedSessionContextItem){
            objSessionContext = AASessionContext.fromSessionContext((EnhancedSessionContextItem) sessionContext);
        }else{
            objSessionContext = sessionContext;
        }

        ISecureServerSession secServerSession = IScsControllableImpl.getSecurityProviderFacade().getServerSession(objSessionContext);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting getServerSession. Returning " + secServerSession);
        }
        return secServerSession;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#changePassword(java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public void changePassword(
            String userId,
            String currentPassword,
            String newPassword)
            throws BcbSecurityException {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering changePassword. User : " + userId);
        }
        try {
            IScsControllableImpl.getSecurityProviderFacade().changePassword(
                    userId,
                    currentPassword,
                    newPassword);
        } catch (BcbSecurityException ex) {
            checkAndRethrowException(ex);
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting changePassword");
        }

    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#logon(java.lang.String, java.lang.String)
     */
    @Override
    public ISessionContext logon(String userId, String password, String clientComputerName) throws BcbSecurityException {
        return logon(userId, password, clientComputerName, !NO_GUI_LOGON);
    }

    @Override
    public ISessionContext nbiLogon(String userId, String password, String computerName) throws BcbSecurityException {
        return logon(userId, password, computerName, NO_GUI_LOGON);
    }

    private ISessionContext logon(String userId, String password,
                                  String clientComputerName, boolean isNbiLogon) throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            String logIfNbi = isNbiLogon ? " (NBI)" : "";
            LOGGER.debug("Entering logon" + logIfNbi + ". User : " + userId);
        }

        ISessionContext ctx = null;
        try {
            if (isNbiLogon) {
                ctx = IScsControllableImpl.getSecurityProviderFacade().nbiLogon(
                        userId,
                        password,
                        clientComputerName);
            } else {
                ctx = IScsControllableImpl.getSecurityProviderFacade().logon(
                        userId,
                        password,
                        clientComputerName);
            }
        } catch (BcbSecurityException ex) {
            checkAndRethrowException(ex);
        } catch (Exception ex) {
            // Since we now have user being created directly in LDAP.
            // We have to throw an exception for this. But there is no
            // specific exception. So throwing a generic exception.
            throw new BcbSecurityException(false, "", ex);
        }

        if (LOGGER.isDebugEnabled()) {
            String logIfNbi = isNbiLogon ? " (NBI)" : "";
            LOGGER.debug("Exiting logon" + logIfNbi + ". Returning " + ctx);
        }
        return ctx;
    }

    /**
     * Helper function to take a BcbSecurityException and see if the exception
     * that is thrown is a BCB defined or USM defined. If it is USM defined, the
     * Exception will be converted to a BcbSecurityException
     *
     * @param ex Exception raised by the called.
     * @throws BcbSecurityException The new exception or old one itself if old one is a BCB defined one
     */
    private void checkAndRethrowException(BcbSecurityException ex)
            throws BcbSecurityException {

        String strExceptionName = ex.getClass().getName();
        if (!strExceptionName.startsWith("com.ossnms.bicnet.bcb.model.security")) {
            BcbSecurityException bcbEx = new BcbSecurityException();
            bcbEx.initCause(ex);
            throw bcbEx;
        }
        throw ex;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#isLoggedOn(java.lang.String)
     */
    @Override
    public boolean isLoggedOn(String userId) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering isLoggedOn. Parameter is : " + userId);
        }

        boolean bLoggedOn = IScsControllableImpl.getSecurityProviderFacade().isLoggedOn(userId);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting isLoggedOn. Returning " + bLoggedOn);
        }
        return bLoggedOn;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#logoff(com.ossnms.bicnet.bcb.facade.security.ISecureServerSession)
     */
    @Override
    public void logoff(ISecureServerSession serverSession)
            throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering logoff. Object being logged off is : " + serverSession);
        }
        try {
            IScsControllableImpl.getSecurityProviderFacade().logoff(serverSession);
        } catch (BcbSecurityException ex) {
            checkAndRethrowException(ex);
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting logoff");
        }
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#logoff(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public void logoff(ISessionContext sessionContext)
            throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering logoff. Context is : " + sessionContext);
        }

        try {
            IScsControllableImpl.getSecurityProviderFacade().logoff(sessionContext);
        } catch (BcbSecurityException ex) {
            checkAndRethrowException(ex);
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting logoff.");
        }
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#addLogonListener(com.ossnms.bicnet.bcb.facade.security.ILogonListener)
     */
    @Override
    public void addLogonListener(ILogonListener listener) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering addLogonListener. Object being registered is : " + listener);
        }

        LOGGER.warn("Avoid use of deprecated method!");

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting addLogonListener");
        }
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#removeLogonListener(com.ossnms.bicnet.bcb.facade.security.ILogonListener)
     */
    @Override
    public void removeLogonListener(ILogonListener listener) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering removeLogonListener. Object being un-registred is : " + listener);
        }

        LOGGER.warn("Avoid use of deprecated method!");

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting removeLogonListener");
        }
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#registerObject(com.ossnms.bicnet.bcb.model.security.ISecurableObject)
     */
    @Override
    public void registerObject(BiCNetComponentType componentType, ISecurableObject securableObject) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering registerObject. Securable Object is : " + securableObject);
        }
        IScsControllableImpl.getSecurityProviderFacade().registerObject(componentType, securableObject);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting registerObject.");
        }
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#unregisterObject(com.ossnms.bicnet.bcb.model.security.ISecurableObject)
     */
    @Override
    public boolean unregisterObject(BiCNetComponentType componentType, ISecurableObject securableObject) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering unregisterObject. Securable Object is : " + securableObject);
        }

        boolean bResult = IScsControllableImpl.getSecurityProviderFacade().unregisterObject(componentType, securableObject);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting unregisterObject.");
        }
        return bResult;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade#updateObject(com.ossnms.bicnet.bcb.model.security.ISecurableObject)
     */
    @Override
    public void updateObject(BiCNetComponentType componentType, ISecurableObject securableObject) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering updateObject. Securable Object is : " + securableObject);
        }

        IScsControllableImpl.getSecurityProviderFacade().updateObject(componentType, securableObject);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting unregisterObject.");
        }
    }

    /*
     * ******************************************************************
     * The Following section is for the Methods defined in ISecurityManageable.
     * ******************************************************************
     */
    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityManageable#getOperations()
	 */
    @Override
    public String[] getOperations() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering getOperations.");
        }

        String[] arrMenus = USMMenuNameList.ARR_MENU_IN_CF_USM;
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting getOperations. Returning : " + Arrays.toString(arrMenus));
        }
        return arrMenus;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ISecurityManageable#getSecurableObjects()
     */
    @Override
    public ISecurableObject[] getSecurableObjects() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Called getSecurableObjects.");
        }
        return null;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.security.ILocalSecurityProviderFacade#getSystemAccountContext()
     */
    @Override
    public ISessionContext getSystemAccountContext()
            throws UnsupportedOperationException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering getSystemAccountContext.");
        }

        ISessionContext ctx =
                IScsControllableImpl
                        .getLocalSecurityProviderFacade()
                        .getSystemAccountContext();

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting getSystemAccountContext");
        }

        return ctx;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.faultMgmt.IAlarmFacade#getAlarmList(com.ossnms.bicnet.bcb.facade.security.ISessionContext, com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmId, com.ossnms.bicnet.bcb.model.IManagedObjectId[], int)
     */
    @Override
    public AlarmReply getAlarmList(
            ISessionContext sessionContext,
            IAlarmId startAfter,
            IManagedObjectId[] filter,
            int howMany)
            throws BcbException {
        AlarmReply reply = null;
        boolean bSecurityChkDisabled = USMCommonHelper.isSecurityCheckDisabled();

        if (!bSecurityChkDisabled) {
            ALAlarmingImpl impl = new ALAlarmingImpl();
            reply = impl.getAlarmList(sessionContext, startAfter, filter, howMany);
        }
        return reply;
    }

    @Override
    public void enableAlarms(ISessionContext iSessionContext, IManagedObjectId[] iManagedObjectIds, AlarmMaskConfiguration alarmMaskConfiguration, TrafficDirection trafficDirection, boolean b) throws BcbException {
        //Do nothing
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.facade.scs.IScsControllable#doFullSync(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public void doFullSync(ISessionContext sessionContext)
            throws BcbException {
        IScsControllableImpl.getInstance().doFullSync(sessionContext);
    }


    @Override
    public Properties getLdapCredentials() throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering getLdapCredentials: ");
        }
        return IScsControllableImpl.getSecurityProviderFacade().getLdapCredentials();

    }


    @Override
    public boolean isTraceDataCollectionSupported(ISessionContext arg0) throws BcbException {
        // No Implementation
        return false;
    }


    @Override
    public void collectTraceData(ISessionContext arg0, File arg1) throws BcbException {
        // No Implementation

    }

    @Override
    public ISessionContext logon(KerberosTicket kTicket, byte[] userName, byte[] host, byte[] clientIpAddress, byte[] encoded, Handle userSessionBean) throws BcbSecurityException {
        throw new UnsupportedOperationException("This method is unsupported due to migration to ejb3");
    }

    @Override
    public void updateObjectContainer(BiCNetComponentType componentType, ISecurableObjectContainer securableContainer) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering updateObjectContainer. Securable container is : " + securableContainer);
        }
        IScsControllableImpl.getSecurityProviderFacade().updateObjectContainer(componentType, securableContainer);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting updateObjectContainer.");
        }

    }

    @Override
    public void disableAlarms(ISessionContext arg0, IManagedObjectId[] arg1, AlarmMaskConfiguration arg2, TrafficDirection direction) throws BcbException {
    }


	@Override
	public ISessionContext authenticate(String userId, String password, String computerName)
			throws BcbSecurityException {
		return logon(userId, password, computerName, NO_GUI_LOGON);
	}

	@Override
	public byte[] getUserPasswordSalt(String userName)
			throws BcbSecurityException {
		return IScsControllableImpl.getSecurityProviderFacade().getUserPasswordSalt(userName);
	}
}
