package com.ossnms.bicnet.securitymanagement.server.basic.notification;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.licensing.ILicenseKeyId;
import com.ossnms.bicnet.bcb.model.licensing.LicenseName;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;
import com.ossnms.bicnet.bcb.model.security.AccountLicenseException;
import com.ossnms.bicnet.securitymanagement.common.basic.SessionEvent;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.server.auth.AAAuthenticationPOJOImpl;
import com.ossnms.bicnet.securitymanagement.server.auth.AASessionStore;
import com.ossnms.bicnet.securitymanagement.server.logging.LMInterFace;
import com.ossnms.bicnet.securitymanagement.server.util.LicenseMgr;
import com.ossnms.bicnet.securitymanagement.server.util.USMUtils;
import org.apache.log4j.Logger;

import java.text.MessageFormat;
import java.util.List;



public final class ExternalUSMNotificationHandler {
	
    private static final Logger LOGGER = Logger.getLogger(ExternalUSMNotificationHandler.class);

    private static ExternalUSMNotificationHandler notifHandler = new ExternalUSMNotificationHandler();

    public static ExternalUSMNotificationHandler getInstance() {
        return notifHandler;
    }

	public void handleLicenseDeletion(ISessionContext sessionContext, ILicenseKeyId license) {
		
		if (!LicenseName.TRIAL_LICENSE.getLicenseName().equals(license.getLicenseName())) {
			return;
		}
		
		LOGGER.debug("Dealing with trial expired notification");
		List<ISessionContext> usersToReserve  = AASessionStore.getInstance().getClientSessions();
		
		//Attempt to reserve "loggedUser" license for all current user sessions.
		try {
			List<ISessionContext>reservedSessions = LicenseMgr.reserveLoginLicenseForUsersList(usersToReserve);
			LOGGER.debug(reservedSessions.size()+" sessions reserved.");
			usersToReserve.removeAll(reservedSessions);
		} catch (BcbException e) {
			LOGGER.error("Could not reserve license for user sessions", e);
		}
	
		LOGGER.debug("There are "+usersToReserve.size()+" unreserved.");
		
		//For the remaining unlicensed user sessions, filter the Administrators and for those reserve the "adminLoggedUser" license.
		for (ISessionContext session: usersToReserve) {
			if (USMUtils.isAdminUser(session)) {
				try {
					if (LicenseMgr.reserveAdminLoginLicense(session)) {
						usersToReserve.remove(session);//can remove session here because we are not going to iterate anymore
						LOGGER.debug("Reserved admin session");
						break;
					}
				} catch (AccountLicenseException e) {
					LOGGER.error("Could not reserve Admin License for admin user", e);
				}
			}
		}
		
		AAAuthenticationPOJOImpl privateSecurityAuthFacade = new AAAuthenticationPOJOImpl();
	
		//For all unlicensed user sessions (both Administrators and non Administrators), force the logoff.
		for (ISessionContext session: usersToReserve) {
			
			//write to SEL each of the logoff sessions
			LMInterFace.getInstance().createSecuritySystemEventRecord(
					session,
					USMCommonStrings.IDS_AA_CLIENT_UNAVAILABLE
					+ session.getUserName() + USMCommonStrings.IDS_AA_CLIENT_MACHINE
					+ ((IEnhancedSessionContext)session).getClientMachineName() + USMCommonStrings.IDS_AA_TRIAL_LICENSE_EXPIRED,
					LogSeverity.WARNING, ((IEnhancedSessionContext)session).getClientMachineName());
			
			//write to License log each of the forced logoff session
			String message = MessageFormat.format(USMCommonStrings.IDS_AA_USER_LOGIN_TRIAL_LICENSE_EXPIRED, session.getUserName());
			LMInterFace.getInstance().createLicenseLogRecord(message, LogSeverity.WARNING);
			
			privateSecurityAuthFacade.forceLogoff(session, SessionEvent.LOGOFF_TRIAL_EXPIRED);
		}
	}

}
