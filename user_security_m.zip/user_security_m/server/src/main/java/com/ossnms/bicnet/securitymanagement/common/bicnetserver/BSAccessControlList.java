/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	BSAccessControlList
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_OBJECTS
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_ACL 
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_SECURITY
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.INSERT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.bicnetserver;

import org.apache.log4j.Logger;

import java.io.Serializable;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * This class is an encapsulation for the BitSet class that is used
 * for holding data about which domains a Securable Object belongs to.
 */
public class BSAccessControlList implements Serializable {
    private static final long serialVersionUID = 1553781248054092889L;

    /**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(BSAccessControlList.class);

	/**
	 * Data member to hold the domains to which this Securable Object belongs to
	 */
	private java.util.BitSet acl = new java.util.BitSet();
	private List<Integer> aclList = new ArrayList<>();

    /**
     * Constructor.
     * @param ids This is the List that contains all the Domains to which this
     * Securable Object belongs.
     */
    public BSAccessControlList(List<Integer> ids){
        if(ids != null){
			ids.forEach(this::addToDomain);
        }
    }

	/**
	 * Constructor.
	 * @param str This is the String that contains all the Domains to which this
	 * Securable Object belongs.
	 */
    public BSAccessControlList(String str) {
		LOGGER.debug("Creating a BSAccessControlList for string - " + str);

        if(null == str) {
            LOGGER.error("The String cannot be null.");
            throw new InvalidParameterException();
        }

		String newStr = str.replace('{', ' ');
		newStr = newStr.replace('}', ' ');

		Stream.of(newStr.split(","))
				.map(String::trim)
				.forEach(s -> {
					if (!s.isEmpty()){
						Integer val = Integer.valueOf(s);
						addToDomain(val);
					}else{
						addToDomain(0);
					}
				});
    }

	/**
	 * Constructor
	 */
	public BSAccessControlList() {
		addToDomain(0);
	}

	/**
	 * This function is invoked to check if the Securable Object belongs to the 
	 * domain that is passed as a parameter.
	 * @param nDomID This is the Domain ID.
	 * @return boolean True indicates the Securable object belongs to the passed Domain.
	 */
	public boolean belongsToDomain(int nDomID) {
		return acl.get(nDomID);
	}

	/**
	 * This function is invoked to add the Securable object to the domainID that is passed as a
	 * parameter.
	 * @param nDomID This is the Domain ID to which the Securable object should be added.
	 */
	void addToDomain(int nDomID) {
		acl.set(nDomID);
		if(!aclList.contains(nDomID)){
			aclList.add(nDomID);
		}
	}

	/**
	 * This function is invoked to remove the Securable object from the domainID that is passed as a
	 * parameter.
	 * @param nDomID This is the Domain ID from which the Securable object should be removed.
	 */
	void removeFromDomain(int nDomID) {
		acl.set(nDomID, false);
		aclList.remove((Integer) nDomID);
	}

	/**
	* Function to return the encapsulated BitSet
	* @return java.util.BitSet Returns the encapsulated BitSet which holds the ACL.
	*/
	java.util.BitSet getACL() {
		return acl;
	}

	public List<Integer> getAclList() {
		return aclList;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return acl.toString();
	}

	/**
	 * Function to check if the ACL contains only the GLOBAL bit set.
	 * @return boolean True indicates that the ACL only contains the GLOBAL
	 * Domain ID.
	 */
	boolean onlyGLOBALBitSet() {
		// GLOBAL is set at the zeroth position.
		return ((acl.cardinality() == 1) && (acl.get(0)));
	}
}
