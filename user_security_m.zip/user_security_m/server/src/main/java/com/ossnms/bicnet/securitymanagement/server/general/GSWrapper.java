package com.ossnms.bicnet.securitymanagement.server.general;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.general.IUSMGeneralSettingsDao;
import com.ossnms.bicnet.securitymanagement.api.server.general.GSProperty;
import com.ossnms.bicnet.securitymanagement.api.server.general.GSSubDomain;
import com.ossnms.bicnet.securitymanagement.api.server.general.IGSWrapper;
import com.ossnms.bicnet.securitymanagement.common.auth.LDAPSearchScope;
import com.ossnms.bicnet.securitymanagement.common.auth.PasswordValidationRulesConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.auth.RadiusUserGroupAttribute;
import com.ossnms.bicnet.securitymanagement.common.general.GSConstants;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.bicnet.securitymanagement.common.general.ldap.LDAPConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.radius.configuration.RadiusConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.sso.SSOConfigurationData;
import com.ossnms.bicnet.securitymanagement.persistence.model.general.USMGeneral;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.EJB;
import javax.ejb.EJBTransactionRolledbackException;
import javax.ejb.Local;
import javax.ejb.Stateless;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ossnms.bicnet.securitymanagement.api.server.general.GSProperty.RADIUS_ALT_SERVER_HOSTNAME;
import static com.ossnms.bicnet.securitymanagement.api.server.general.GSProperty.RADIUS_ALT_SERVER_PORT;
import static com.ossnms.bicnet.securitymanagement.api.server.general.GSProperty.RADIUS_ALT_SERVER_SECRET;
import static com.ossnms.bicnet.securitymanagement.api.server.general.GSProperty.RADIUS_ENABLED;
import static com.ossnms.bicnet.securitymanagement.api.server.general.GSProperty.RADIUS_RETRIES;
import static com.ossnms.bicnet.securitymanagement.api.server.general.GSProperty.RADIUS_SERVER_HOSTNAME;
import static com.ossnms.bicnet.securitymanagement.api.server.general.GSProperty.RADIUS_SERVER_PORT;
import static com.ossnms.bicnet.securitymanagement.api.server.general.GSProperty.RADIUS_SERVER_SECRET;
import static com.ossnms.bicnet.securitymanagement.api.server.general.GSProperty.RADIUS_TIMEOUT;
import static com.ossnms.bicnet.securitymanagement.api.server.general.GSProperty.RADIUS_USER_GROUP_ATTRIBUTE;
import static com.ossnms.bicnet.securitymanagement.common.auth.RadiusUserGroupAttribute.VENDOR_SPECIFIC;

/**
 *
 */
@Stateless(name = "IGSWrapper")
@Local
public class GSWrapper implements IGSWrapper {

	private static final String MSG_DEBUG_ENTER_INIT	 	= "GSWrapper -- init() -- Enter";
	private static final String MSG_DEBUG_ENTER_DEFAULT_GS 	= "GSWrapper -- createDefaultGSData() -- Enter";
	private static final String MSG_DEBUG_ENTER_DEFAULT_PP 	= "GSWrapper -- createDefaultPasswordPolicy() -- Enter";
	private static final String MSG_DEBUG_EXIT_INIT 		= "GSWrapper -- init() -- Exit";
	private static final String MSG_DEBUG_EXIT_DEFAULT_GS 	= "GSWrapper -- createDefaultGSData() -- Exit";
	private static final String MSG_DEBUG_EXIT_DEFAULT_PP 	= "GSWrapper -- createDefaultPasswordPolicy() -- Exit";

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(GSWrapper.class);

	@EJB
	private IUSMGeneralSettingsDao generalSettingsDao;

	/**
     * Method to be called on server startup.
     * Looks for the default configurations. If they don't exist, create them.
     */
	@Override
	public void init() {
		LOGGER.debug(MSG_DEBUG_ENTER_INIT);

		// if the SECURITY_SETTINGS sub-domain does not exist (0 settings in
		// such sub-domain)
		// we need to create them
		if (generalSettingsDao.findBySubDomain(GSSubDomain.SECURITY_SETTINGS.name()).size() == 0) {
			createDefaultGSData();
		}
		// if the PASSWORD_POLICY sub-domain does not exist (0 settings in such
		// sub-domain)
		// we need to create it
		if (generalSettingsDao.findBySubDomain(GSSubDomain.PASSWORD_POLICY.name()).size() == 0) {
			createDefaultPasswordPolicyData();
		}

		LOGGER.debug(MSG_DEBUG_EXIT_INIT);
	}

	/**
	 * Retrieves the <code>GSGeneralSettingData</code> object from the database.
	 *
	 * @return the general settings data, as <code>GSGeneralSettingData</code>.
	 */
	@Override
	public GSGeneralSettingData getGeneralSettingData() {
		GSGeneralSettingData generalSetting = new GSGeneralSettingData();

		// get general settings values from database
		String objAdvisoryMessage = generalSettingsDao.getPropertyValue(GSProperty.ADVISORY_MESSAGE);
		String objDisplay = generalSettingsDao.getPropertyValue(GSProperty.IS_MESSAGE_DISPLAYED);
		String objTimeout = generalSettingsDao.getPropertyValue(GSProperty.INACTIVITY_TIMEOUT);
		String objAdminLockOut = generalSettingsDao.getPropertyValue(GSProperty.ADMIN_LOCKOUT_DURATION);
		String objInactivityPeriod = generalSettingsDao.getPropertyValue(GSProperty.INACTIVITY_PERIOD);
		String objInitPwdChangeInterval = generalSettingsDao.getPropertyValue(GSProperty.PASSWORD_CHANGE_INTERVAL);
		String objReloginTimeout = generalSettingsDao.getPropertyValue(GSProperty.RELOGIN_TIMEOUT);
		String objReloginDelayBetweenTries = generalSettingsDao.getPropertyValue(GSProperty.RELOGIN_DELAY_BETWEEN_TRIES);
		String objInactivityTimeoutWarningTime = generalSettingsDao.getPropertyValue(GSProperty.INACTIVITY_TIMEOUT_WARNING_TIME);
		String objExpirePasswordWarning = generalSettingsDao.getPropertyValue(GSProperty.EXPIRE_PASSWORD_WARNING);

		// set if advisory message should be shown
		generalSetting.setShowAdvisoryMessage(
				objDisplay == null ? GSConstants.S_DEFAULT_IS_ADVISORY_MESSAGE_DISPLAY : Boolean.parseBoolean(objDisplay)
		);
		// set initial password change interval
		generalSetting.setInitPasswordChangeInterval(
				objInitPwdChangeInterval == null ? GSConstants.S_INIT_PASSWORD_CHANGE_INTERVAL : Integer.parseInt(objInitPwdChangeInterval)
		);
		//set inactivity timeout value
		generalSetting.setInactivityTimeout(
				objTimeout == null ? GSConstants.S_INACTIVITY_TIMEOUT : Integer.parseInt(objTimeout)
		);
		// set deactivation timeout
		generalSetting.setDeactivationAfterInactivity(
				objInactivityPeriod == null ? GSConstants.S_USER_ACCOUNT_DEACTIVATE : Integer.parseInt(objInactivityPeriod)
		);
		// set administrator lockout period
		generalSetting.setAdminLockout(
				objAdminLockOut == null ? GSConstants.S_ADMIN_LOCKOUT_PERIOD : Integer.parseInt(objAdminLockOut)
		);
		// set advisory message
		generalSetting.setAdvisoryMessage(
				objAdvisoryMessage == null ? "" : objAdvisoryMessage
		);
		// set relogin timeout
		generalSetting.setReloginTimeout(
				objReloginTimeout == null ? GSConstants.S_RELOGIN_TIMEOUT : Integer.parseInt(objReloginTimeout)
		);
		// set delay between relogin retry
		generalSetting.setReloginDelayBetweenTries(
				objReloginDelayBetweenTries == null ? GSConstants.S_RELOGIN_DELAY_BETWEEN_TRIES : Integer.parseInt(objReloginDelayBetweenTries)
		);

		// set relogin timeout
		generalSetting.setExpirePasswordWarning(
				objExpirePasswordWarning == null ? GSConstants.S_EXPIRE_PASSWORD_WARNING : Integer.parseInt(objExpirePasswordWarning)
		);
		// set inactivity timeout warning time
		generalSetting.setInactivityTimeoutWarningTime(
				objInactivityTimeoutWarningTime == null ? GSConstants.S_INACTIVITY_TIMEOUT_WARNING : Integer.parseInt(objInactivityTimeoutWarningTime)
		);

		generalSetting.setDeactivationAfterLoginAttempts(getPasswordPolicyData());
		// set SSO settings
		generalSetting.setSSOConfigurationData(getSingleSignOnConfiguration());
		// set LDAP settings
		generalSetting.setLdapConfigurationData(getLdapConfigurationData());
		// set RADIUS Authentication settings
		generalSetting.setRadiusConfigurationData(getRadiusConfigurationData());
		// set Password Verification Rules settings
		generalSetting.setPasswordValidationRulesConfigurationData(getPasswordValidationRulesConfiguration());

		return generalSetting;
	}

	/**
	 * Wraps DAO calls to retrieve Single Sign On data
	 *
	 * @return SSOConfigurationData instance
	 */
	@Override
	public SSOConfigurationData getSingleSignOnConfiguration() {
		String enabled = generalSettingsDao.getPropertyValue(GSProperty.SSO_ENABLED);
		boolean isEnabled = Boolean.parseBoolean(enabled);

		String domainName = generalSettingsDao.getPropertyValue(GSProperty.SSO_DOMAIN_NAME);
		String domainServer = generalSettingsDao.getPropertyValue(GSProperty.SSO_DOMAIN_SERVER);
		String domainPort = generalSettingsDao.getPropertyValue(GSProperty.SSO_PORT);
		String principal = "unused/unused";

		return new SSOConfigurationData(
				domainName == null ? "" : domainName,
				domainServer == null ? "" : domainServer,
				domainPort == null ? "" : domainPort,
				principal,
				isEnabled
		);
	}

    /**
     * Wraps DAO calls to retrieve Password Validation Rules data
     *
     * @return SSOConfigurationData instance
     */
    @Override
    public PasswordValidationRulesConfigurationData getPasswordValidationRulesConfiguration() {

        String passwordMustBeDifferentFromName = generalSettingsDao.getPropertyValue(GSProperty.PASSWORD_VALIDATION_RULE_NAME);
        boolean isPasswordMustBeDifferentFromName = Boolean.parseBoolean(passwordMustBeDifferentFromName);

        String passwordMustBeDifferentFromEmployeeNumber = generalSettingsDao.getPropertyValue(GSProperty.PASSWORD_VALIDATION_RULE_EMPLOYEE_NUMBER);
        boolean isPasswordMustBeDifferentFromEmployeeNumber = Boolean.parseBoolean(passwordMustBeDifferentFromEmployeeNumber);

        String passwordMustBeDifferentFromDate = generalSettingsDao.getPropertyValue(GSProperty.PASSWORD_VALIDATION_RULE_DATE);
        boolean isPasswordMustBeDifferentFromDate = Boolean.parseBoolean(passwordMustBeDifferentFromDate);

        String passwordMustNotHaveSpaces = generalSettingsDao.getPropertyValue(GSProperty.PASSWORD_VALIDATION_RULE_SPACES);
        boolean isPasswordMustNotHaveSpaces = Boolean.parseBoolean(passwordMustNotHaveSpaces);

        return new PasswordValidationRulesConfigurationData(
                isPasswordMustBeDifferentFromName,
                isPasswordMustBeDifferentFromEmployeeNumber,
                isPasswordMustBeDifferentFromDate,
                isPasswordMustNotHaveSpaces
        );
    }

	@Override
	public LDAPConfigurationData getLdapConfigurationData() {
		String enabled = generalSettingsDao.getPropertyValue(GSProperty.LDAP_ENABLED);
		boolean isEnabled = Boolean.parseBoolean(enabled);

		String sslIndicator = generalSettingsDao.getPropertyValue(GSProperty.LDAP_SSL_INDICATOR);
		boolean isSSL = Boolean.parseBoolean(sslIndicator);

		String host = generalSettingsDao.getPropertyValue(GSProperty.LDAP_HOST);
		String port = generalSettingsDao.getPropertyValue(GSProperty.LDAP_PORT);
		String searchAccount = generalSettingsDao.getPropertyValue(GSProperty.LDAP_SEARCH_ACCOUNT);
		String searchPassword = generalSettingsDao.getPropertyValue(GSProperty.LDAP_SEARCH_PASSWORD);
		String userSearchBase = generalSettingsDao.getPropertyValue(GSProperty.LDAP_USER_SEARCH_BASE);
		String userSearchFilter = generalSettingsDao.getPropertyValue(GSProperty.LDAP_USER_SEARCH_FILTER);
		// set user search scope
		String userSearchScopeValue = generalSettingsDao.getPropertyValue(GSProperty.LDAP_USER_SEARCH_SCOPE);
		LDAPSearchScope userSearchScope =
				userSearchScopeValue == null ? LDAPSearchScope.ONELEVEL : LDAPSearchScope.valueOf(userSearchScopeValue);

		String userIdAttribute = generalSettingsDao.getPropertyValue(GSProperty.LDAP_USER_ID_ATTR);
		String groupSearchBase = generalSettingsDao.getPropertyValue(GSProperty.LDAP_GROUP_SEARCH_BASE);
		String groupSearchFilter = generalSettingsDao.getPropertyValue(GSProperty.LDAP_GROUP_SEARCH_FILTER);
		// set group search scope
		String groupSearchScopeValue = generalSettingsDao.getPropertyValue(GSProperty.LDAP_GROUP_SEARCH_SCOPE);
		LDAPSearchScope groupSearchScope =
				groupSearchScopeValue == null ? LDAPSearchScope.ONELEVEL : LDAPSearchScope.valueOf(groupSearchScopeValue);

		String groupIdAttribute = generalSettingsDao.getPropertyValue(GSProperty.LDAP_GROUP_ID_ATTR);
		String groupMemberAttribute = generalSettingsDao.getPropertyValue(GSProperty.LDAP_GROUP_MEMBER_ATTR);

		return new LDAPConfigurationData(
				isEnabled,
				isSSL,
				host == null ? "" : host,
				port == null ? "389" : port,
				searchAccount == null ? "" : searchAccount,
				searchPassword == null ? "" : searchPassword,
				userSearchBase == null ? "" : userSearchBase,
				userSearchFilter == null ? "" : userSearchFilter,
				userSearchScope == null ? LDAPSearchScope.ONELEVEL : userSearchScope,
				userIdAttribute == null ? "" : userIdAttribute,
				groupSearchBase == null ? "" : groupSearchBase,
				groupSearchFilter == null ? "" : groupSearchFilter,
				groupSearchScope == null ? LDAPSearchScope.ONELEVEL : groupSearchScope,
				groupIdAttribute == null ? "" : groupIdAttribute,
				groupMemberAttribute == null ? "" : groupMemberAttribute
		);
	}

	/**
	 * {@inheritDoc}
     */
	@Override
	public RadiusConfigurationData getRadiusConfigurationData() {
		RadiusConfigurationData configurationData = new RadiusConfigurationData();

		String enabled = generalSettingsDao.getPropertyValue(RADIUS_ENABLED);
		configurationData.setEnabled(enabled == null ? false : Boolean.valueOf(enabled));

		String timeout = generalSettingsDao.getPropertyValue(RADIUS_TIMEOUT);
		configurationData.setTimeout(timeout == null ?  GSConstants.S_RADIUS_TIMEOUT_DEFAULT : Integer.parseInt(timeout));

		String retries = generalSettingsDao.getPropertyValue(RADIUS_RETRIES);
		configurationData.setRetries(retries == null ? GSConstants.S_RADIUS_RETRY_DEFAULT : Integer.parseInt(retries));

		String attribute = generalSettingsDao.getPropertyValue(RADIUS_USER_GROUP_ATTRIBUTE);
		configurationData.setUserGroupAttribute(attribute == null ? VENDOR_SPECIFIC : RadiusUserGroupAttribute.valueOf(attribute));

		String serverHostname = generalSettingsDao.getPropertyValue(RADIUS_SERVER_HOSTNAME);
		configurationData.setServerHostname(serverHostname == null ? "" : serverHostname);

		String serverPort = generalSettingsDao.getPropertyValue(RADIUS_SERVER_PORT);
		configurationData.setServerPort(serverPort == null ? GSConstants.S_RADIUS_PORT_DEFAULT : Integer.parseInt(serverPort));

		String serverSecret = generalSettingsDao.getPropertyValue(RADIUS_SERVER_SECRET);
		configurationData.setServerSharedSecret(serverSecret == null ? "" : serverSecret);

		String altServerHostname = generalSettingsDao.getPropertyValue(RADIUS_ALT_SERVER_HOSTNAME);
		configurationData.setAltServerHostname(altServerHostname == null ? "" : altServerHostname);

		String altServerPort = generalSettingsDao.getPropertyValue(RADIUS_ALT_SERVER_PORT);
		configurationData.setAltServerPort(altServerPort == null ? GSConstants.S_RADIUS_PORT_DEFAULT : Integer.parseInt(altServerPort));

		String altServerSecret = generalSettingsDao.getPropertyValue(RADIUS_ALT_SERVER_SECRET);
		configurationData.setAltServerSharedSecret(altServerSecret == null ? "" : altServerSecret);

		return configurationData;
	}

	/**
     * Sets the configurations given by the instance of <code>GSGeneralSettingData</code>
     * passed as parameter
     * @param generalSettingData - General Setting details.
     * @return true if all the settings were saved successfully, false otherwise.
     */
	@Override
	public boolean setGeneralSetting(GSGeneralSettingData generalSettingData) {

		boolean retVal;

		LOGGER.debug("setGeneralSetting(" + generalSettingData + ")      Entry");

		SSOConfigurationData ssoConfiguration = generalSettingData.getSSOConfigurationData();
		LDAPConfigurationData ldapConfigurationData = generalSettingData.getLdapConfigurationData();
        PasswordValidationRulesConfigurationData passwordValidationRulesConfigurationData = generalSettingData.getPasswordValidationRulesConfigurationData();
		RadiusConfigurationData radiusConfigurationData = generalSettingData.getRadiusConfigurationData();

		retVal = setPropertyValue(GSProperty.PASSWORD_CHANGE_INTERVAL,
					Integer.toString(generalSettingData.getInitPasswordChangeInterval()))
				&& setPropertyValue(GSProperty.INACTIVITY_TIMEOUT,
					Integer.toString(generalSettingData.getInactivityTimeout()))
				&& setPropertyValue(GSProperty.INACTIVITY_PERIOD,
					Integer.toString(generalSettingData.getDeactivationAfterInativity()))
				&& setPropertyValue(GSProperty.ADMIN_LOCKOUT_DURATION,
					Integer.toString(generalSettingData.getAdminLockout()))
				&& setPropertyValue(GSProperty.IS_MESSAGE_DISPLAYED,
					Boolean.toString(generalSettingData.isShowAdvisoryMessage()))
				&& setPropertyValue(GSProperty.ADVISORY_MESSAGE,
					generalSettingData.getAdvisoryMessage())
				&& setPropertyValue(GSProperty.PASSWORD_MAX_FAILURE,
					Integer.toString(generalSettingData.getDeactivationAfterLoginAttempts()))
				&& setPropertyValue(GSProperty.RELOGIN_TIMEOUT,
					Integer.toString(generalSettingData.getReloginTimeout()))
				&& setPropertyValue(GSProperty.INACTIVITY_TIMEOUT_WARNING_TIME,
                    Integer.toString(generalSettingData.getInactivityTimeoutWarningTime()))
                && setPropertyValue(GSProperty.RELOGIN_DELAY_BETWEEN_TRIES,
					Integer.toString(generalSettingData.getReloginDelayBetweenTries()))
				&& setPropertyValue(GSProperty.EXPIRE_PASSWORD_WARNING,
						Integer.toString(generalSettingData.getExpirePasswordWarning()));

		if(ssoConfiguration != null){
			retVal &= setPropertyValue(GSProperty.SSO_ENABLED, Boolean.toString(ssoConfiguration.isEnabled()))
					&& setPropertyValue(GSProperty.SSO_DOMAIN_NAME, ssoConfiguration.getDomainName())
					&& setPropertyValue(GSProperty.SSO_DOMAIN_SERVER, ssoConfiguration.getDomainServer())
					&& setPropertyValue(GSProperty.SSO_PORT, ssoConfiguration.getLdapTcpPort());
		}

		if(ldapConfigurationData != null){
			retVal &= setLdapConfigurationData(ldapConfigurationData);
		}

		if(radiusConfigurationData != null){
			retVal &= setRadiusConfigurationData(radiusConfigurationData);
		}

        if(passwordValidationRulesConfigurationData != null){
            retVal &= setPasswordValidationRulesData(passwordValidationRulesConfigurationData);
        }

		LOGGER.debug("setGeneralSetting(" + generalSettingData + ")      Exit");

		return retVal;

	}

	private boolean setRadiusConfigurationData(RadiusConfigurationData radiusConfigurationData) {
		Map<GSProperty, String> properties = new EnumMap<>(GSProperty.class);

		properties.put(RADIUS_ENABLED, 				String.valueOf(radiusConfigurationData.isEnabled()));
		properties.put(RADIUS_TIMEOUT, 				String.valueOf(radiusConfigurationData.getTimeout()));
		properties.put(RADIUS_RETRIES, 				String.valueOf(radiusConfigurationData.getRetries()));
		properties.put(RADIUS_USER_GROUP_ATTRIBUTE,				   radiusConfigurationData.getUserGroupAttribute().name());
		properties.put(RADIUS_SERVER_HOSTNAME, 					   radiusConfigurationData.getServerHostname());
		properties.put(RADIUS_SERVER_PORT, 			String.valueOf(radiusConfigurationData.getServerPort()));
		properties.put(RADIUS_SERVER_SECRET, 					   radiusConfigurationData.getServerSharedSecret());
		properties.put(RADIUS_ALT_SERVER_HOSTNAME, 				   radiusConfigurationData.getAltServerHostname());
		properties.put(RADIUS_ALT_SERVER_PORT, 		String.valueOf(radiusConfigurationData.getAltServerPort()));
		properties.put(RADIUS_ALT_SERVER_SECRET, 				   radiusConfigurationData.getAltServerSharedSecret());

		return setPropertyValue(properties);
	}

	/**
	 * {@inheritDoc}
     */
	@Override
	public boolean setLdapConfigurationData(LDAPConfigurationData ldapConfigurationData) {
		Map<GSProperty, String> properties = new EnumMap<>(GSProperty.class);

		properties.put(GSProperty.LDAP_ENABLED, Boolean.toString(ldapConfigurationData.isEnabled()));
		properties.put(GSProperty.LDAP_SSL_INDICATOR, Boolean.toString(ldapConfigurationData.isSslIndicator()));
		properties.put(GSProperty.LDAP_HOST, ldapConfigurationData.getHost());
		properties.put(GSProperty.LDAP_PORT, ldapConfigurationData.getPort());
		properties.put(GSProperty.LDAP_SEARCH_ACCOUNT, ldapConfigurationData.getSearchAccount());
		properties.put(GSProperty.LDAP_SEARCH_PASSWORD, ldapConfigurationData.getSearchPassword());
		properties.put(GSProperty.LDAP_USER_SEARCH_BASE, ldapConfigurationData.getUserSearchBase());
		properties.put(GSProperty.LDAP_USER_SEARCH_FILTER, ldapConfigurationData.getUserSearchFilter());

		LDAPSearchScope userSearchScope = ldapConfigurationData.getUserSearchScope();
		properties.put(GSProperty.LDAP_USER_SEARCH_SCOPE, userSearchScope == null ? null : userSearchScope.name());
		properties.put(GSProperty.LDAP_USER_ID_ATTR, ldapConfigurationData.getUserIdAttribute());
		properties.put(GSProperty.LDAP_GROUP_SEARCH_BASE, ldapConfigurationData.getGroupSearchBase());
		properties.put(GSProperty.LDAP_GROUP_SEARCH_FILTER, ldapConfigurationData.getGroupSearchFilter());

		LDAPSearchScope groupSearchScope = ldapConfigurationData.getGroupSearchScope();
		properties.put(GSProperty.LDAP_GROUP_SEARCH_SCOPE, groupSearchScope == null ? null : groupSearchScope.name());
		properties.put(GSProperty.LDAP_GROUP_ID_ATTR, ldapConfigurationData.getGroupIdAttribute());
		properties.put(GSProperty.LDAP_GROUP_MEMBER_ATTR, ldapConfigurationData.getGroupMemberAttribute());

		return setPropertyValue(properties);
	}

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean setPasswordValidationRulesData(PasswordValidationRulesConfigurationData passwordValidationRulesConfigurationData) {
        Map<GSProperty, String> properties = new HashMap<>();

        properties.put(GSProperty.PASSWORD_VALIDATION_RULE_DATE, Boolean.toString(passwordValidationRulesConfigurationData.isPasswordMustBeDifferentFromDate()));
        properties.put(GSProperty.PASSWORD_VALIDATION_RULE_EMPLOYEE_NUMBER, Boolean.toString(passwordValidationRulesConfigurationData.isPasswordMustBeDifferentFromEmployeeNumber()));
        properties.put(GSProperty.PASSWORD_VALIDATION_RULE_NAME, Boolean.toString(passwordValidationRulesConfigurationData.isPasswordMustBeDifferentFromName()));
        properties.put(GSProperty.PASSWORD_VALIDATION_RULE_SPACES, Boolean.toString(passwordValidationRulesConfigurationData.isPasswordMustNotHaveSpaces()));

        return setPropertyValue(properties);
    }

	/**
     * Retrieves the property value specified by <code>GSProperty</code>.
     * @param property <code>GSProperty</code>, the name of the property.
     * @return a String value of the property.
     */
	@Override
	public String getPropertyValue(GSProperty property) {
		return generalSettingsDao.getPropertyValue(property.name());
	}

    /**
     * Sets the value of the property specified by the <code>GSProperty</code> parameter.
     * @param property <code>GSProperty</code>, the name of the property.
     * @param value the value to set.
     * @return true if the property's value was successfully set, false otherwise.
     */
	@Override
	public boolean setPropertyValue(GSProperty property, String value) {
		LOGGER.debug("setPropertyValue(" + property.name() + ")      Entry");

		boolean retVal = false;

		// Fill up the general settings property as required
		USMGeneral usmGeneral = populateNewUSMGeneral(property, value);

		try {
			generalSettingsDao.save(usmGeneral);
		} catch (EJBTransactionRolledbackException e) {
			LOGGER.error(e.getMessage());
		}

		if (usmGeneral != null && usmGeneral.getProperty() != null) {
			// General Setting was successfully added
			LOGGER.info("General Setting Property Added successfully {}", usmGeneral.getProperty());
			retVal = true;
		} else {
			LOGGER.error("General Setting Property could not be set, an error occurred.");
		}

		LOGGER.debug("setPropertyValue(" + property.name() + ")      Exit");

		return retVal;
	}

	@Override
	public boolean setPropertyValue(Map<GSProperty, String> properties) {
		LOGGER.debug("setPropertyValue(map)      Entry");

		final boolean[] retVal = { true };

		properties.forEach(
				(property, value) -> {
					// Fill up the general settings property as required
					USMGeneral usmGeneral = populateNewUSMGeneral(property, value);

					try {
						generalSettingsDao.save(usmGeneral);
					} catch (EJBTransactionRolledbackException e) {
						LOGGER.error(e.getMessage());
					}

					if (usmGeneral != null && usmGeneral.getProperty() != null) {
						// General Setting was successfully added
						LOGGER.info("General Setting Property Added successfully {}", usmGeneral.getProperty());
						retVal[0] &= true;
					} else {
						LOGGER.error("General Setting Property could not be set, an error occurred.");
					}
				}
		);

		LOGGER.debug("setPropertyValue(map)      Exit");

		return retVal[0];
	}


	/**
     * Private method, to set a new <code>USMGeneral</code> with the property name and value as specified.
     * @param property <code>GSProperty</code>, the name of the property.
     * @param value the value of the property.
     * @return the new instance of the USMGeneral object.
     */
	private USMGeneral populateNewUSMGeneral(GSProperty property, String value) {
		LOGGER.debug("populateNewUSMGeneral() - Enter");

		USMGeneral retElement = new USMGeneral();

		retElement.setProperty(property.name());
		retElement.setValue(value);
		retElement.setSubDomain(property.getSubDomain().name());

		LOGGER.debug("populateNewUSMGeneral() - Exit");

		return retElement;
	}

    /**
     * Retrieves the number of unsuccessful login attempts allowed.
     * @return int - the maximum number of unsuccessful login attempts.
     */
	@Override
	public int getPasswordPolicyData() {
		LOGGER.debug("getPasswordPolicyData()		Entry");
		int maxLoginAllowed;

		String objLoginAttempts = generalSettingsDao
				.getPropertyValue(GSProperty.PASSWORD_MAX_FAILURE.name());
		if (objLoginAttempts != null) {
			maxLoginAllowed = Integer.parseInt(objLoginAttempts);
		} else {
			maxLoginAllowed = GSConstants.S_MAX_LOGIN_ATTEMPTS;
		}

		LOGGER.debug("getPasswordData()		Exit : Return ::: {}", maxLoginAllowed);

		return maxLoginAllowed;
	}

    /**
     * Retrieves the default password.
     * @return a String with the default password.
     */
	@Override
	public String getDefaultPassword() {
		LOGGER.debug("getDefaultPassword()		Entry");
		return GSConstants.S_DEFAULT_PASSWORD;
	}

    /**
     * Private method, persists the default settings for the subDomain SECURITY_SETTINGS.
     * @return true if the data was successfully created, false otherwise.
     */
	private boolean createDefaultGSData() {
		LOGGER.debug(MSG_DEBUG_ENTER_DEFAULT_GS);

		List<USMGeneral> gsSettings = new ArrayList<>();

		gsSettings.add(populateNewUSMGeneral(
                GSProperty.ADVISORY_MESSAGE,
				GSConstants.DEFAULT_ADVISORY_MESSAGE));
		gsSettings.add(populateNewUSMGeneral(
                GSProperty.IS_MESSAGE_DISPLAYED,
				Boolean.toString(GSConstants.S_DEFAULT_IS_ADVISORY_MESSAGE_DISPLAY)));
		gsSettings.add(populateNewUSMGeneral(
                GSProperty.INACTIVITY_TIMEOUT,
				Integer.toString(GSConstants.S_INACTIVITY_TIMEOUT)));
		gsSettings.add(populateNewUSMGeneral(
				GSProperty.PASSWORD_CHANGE_INTERVAL,
				Integer.toString(GSConstants.S_INIT_PASSWORD_CHANGE_INTERVAL)));
		gsSettings.add(populateNewUSMGeneral(
                GSProperty.INACTIVITY_PERIOD,
				Integer.toString(GSConstants.S_USER_ACCOUNT_DEACTIVATE)));
		gsSettings.add(populateNewUSMGeneral(
                GSProperty.ADMIN_LOCKOUT_DURATION,
				Integer.toString(GSConstants.S_ADMIN_LOCKOUT_PERIOD)));
		gsSettings.add(populateNewUSMGeneral(
				GSProperty.RELOGIN_TIMEOUT,
				Integer.toString(GSConstants.S_RELOGIN_TIMEOUT)));
		gsSettings.add(populateNewUSMGeneral(
				GSProperty.RELOGIN_DELAY_BETWEEN_TRIES,
				Integer.toString(GSConstants.S_RELOGIN_DELAY_BETWEEN_TRIES)));
		gsSettings.add(populateNewUSMGeneral(
				GSProperty.EXPIRE_PASSWORD_WARNING,
				Integer.toString(GSConstants.S_EXPIRE_PASSWORD_WARNING)));
        gsSettings.add(populateNewUSMGeneral(
                GSProperty.INACTIVITY_TIMEOUT_WARNING_TIME,
                Integer.toString(GSConstants.S_INACTIVITY_TIMEOUT_WARNING)));
		gsSettings = generalSettingsDao.saveAll(gsSettings);

		LOGGER.debug(MSG_DEBUG_EXIT_DEFAULT_GS);
		return gsSettings != null;
	}

    /**
     * Private method, persists the default settings for the subDomain PASSWORD_POLICY.
     * @return true if the data was successfully created, false otherwise.
     */
	private boolean createDefaultPasswordPolicyData() {
		LOGGER.debug(MSG_DEBUG_ENTER_DEFAULT_PP);

		List<USMGeneral> gsSettings = new ArrayList<>();

		gsSettings.add(populateNewUSMGeneral(GSProperty.PASSWORD_MAX_FAILURE,
				Integer.toString(GSConstants.S_MAX_LOGIN_ATTEMPTS)));
		gsSettings.add(populateNewUSMGeneral(GSProperty.PASSWORD_IN_HISTORY,
				Integer.toString(GSConstants.S_PASSWORD_HISTORY)));

        gsSettings = generalSettingsDao.saveAll(gsSettings);

		LOGGER.debug(MSG_DEBUG_EXIT_DEFAULT_PP);
		return gsSettings != null;
	}
}
