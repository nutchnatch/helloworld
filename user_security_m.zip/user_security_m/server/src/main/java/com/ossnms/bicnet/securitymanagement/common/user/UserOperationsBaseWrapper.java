package com.ossnms.bicnet.securitymanagement.common.user;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.user.IUSMUserDao;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.utils.InternalUSMBeanLocator;
import com.ossnms.bicnet.securitymanagement.persistence.model.user.USMPasswordHistory;
import com.ossnms.bicnet.securitymanagement.persistence.model.user.USMUser;

import java.util.List;

/**
 * created on 13/10/2014
 */
public class UserOperationsBaseWrapper {

    protected IUSMUserDao getUserDao(){
        return InternalUSMBeanLocator.getEJB(IUSMUserDao.class);
    }

    /**
     * This method will be responsible for getting the valid list of passwords
     * in the password history
     *
     * @param user
     *            - the user name to change the password for
     * @param gsNumberPasswords
     *            - number of passwords defined in general settings for password
     *            history
     * @return a list populated with the allowed passwords history
     */
    protected List<USMPasswordHistory> getPasswordsHistoryList(USMUser user, int gsNumberPasswords) {

        List<USMPasswordHistory> passwords = getUserDao().findPasswordsByUser(user);

        if (gsNumberPasswords <= passwords.size()) {
            passwords = passwords.subList(0, gsNumberPasswords);
        }

        return passwords;
    }

    /**
     * This method will update the list of passwords with the new one according to the
     * number defined in general settings property
     *
     * @param user
     *            - the user name to change the password for
     * @param gsNumberPasswords
     *            - number of passwords defined in general settings for password
     *            history
     * @param newPassword
     *            - the new password to be associated with the user
     * @return a list populated with the allowed passwords history
     */
    protected List<USMPasswordHistory> updatedPasswordsHistoryList(USMUser user, int gsNumberPasswords, String newPassword) {

        // populate the password to be introduced in DB with all the data
        USMPasswordHistory password = new USMPasswordHistory();
        password.setDateChanged(USMCommonHelper.getGMTStringForCurrentDate());
        password.setPassword(newPassword);
        password.setUser(user);
        
        int lastIndex = (gsNumberPasswords - 1) < 0 ? 0 : (gsNumberPasswords - 1);

        //get all the existing passwords in password history for t
        List<USMPasswordHistory> passwords = getUserDao().findPasswordsByUser(user);

        // if password history is already full or
        // the allowed number of passwords in history is bigger then the defined in the general settings
        // then all the exceeding passwords will not be considered and the last one will be replaced
        // by the new one
        if (gsNumberPasswords <= passwords.size()) {
            passwords = passwords.subList(0, lastIndex);
        }

        // add password to the passwrods list
        passwords.add(password);

        return passwords;
    }

    /**
     * Compares the password to which we wish to change against the list of passwords in the password history
     *
     * @param historyList list of USMPasswordHistory items
     * @param encodedPassword the previously encoded password
     * @return true if the password is in history, false otherwise
     */
    protected boolean isPasswordInHistory(List<USMPasswordHistory> historyList, String encodedPassword){
        for(USMPasswordHistory passwordHistory : historyList){
        	if(passwordHistory.getPassword().equals(encodedPassword)){
                return true;
            }
        }
        return false;
    }

}
