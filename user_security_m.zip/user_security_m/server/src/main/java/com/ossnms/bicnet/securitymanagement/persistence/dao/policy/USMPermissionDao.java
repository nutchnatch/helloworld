package com.ossnms.bicnet.securitymanagement.persistence.dao.policy;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.policy.IUSMPermissionDao;
import com.ossnms.bicnet.securitymanagement.persistence.dao.AbstractBaseDao;
import com.ossnms.bicnet.securitymanagement.persistence.model.policy.USMPermission;
import org.hibernate.Hibernate;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.Query;

/**
 * created on 4/5/2015
 */
@Stateless(name = "IUSMPermissionDao")
@Local
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class USMPermissionDao extends AbstractBaseDao<USMPermission, Integer> implements IUSMPermissionDao {

    private static final String QUERY_FIND_BY_USER = "usmPermission.findByName";
    private static final String PARAM_1 = "name";

    @Override
    public USMPermission findByName(String name) {
        Query query = getEntityManager().createNamedQuery(QUERY_FIND_BY_USER).setParameter(PARAM_1, name);
        return getSingleResult(query);
    }

    @Override
    public void loadPermissionItems(USMPermission permission) {
        USMPermission temp = findById(permission.getId());

        //Call Hibernate.initialize to initialize the permission items lazy collection
        Hibernate.initialize(temp.getPermissionItems());

        //set permission items in the element
        permission.setPermissionItems(temp.getPermissionItems());
    }
}
