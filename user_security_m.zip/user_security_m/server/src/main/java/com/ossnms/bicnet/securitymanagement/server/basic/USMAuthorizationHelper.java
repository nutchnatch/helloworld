/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMServerLifeCycleControllerIfc
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.basic;

import com.ossnms.bicnet.bcb.facade.IMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISecureServerSession;
import com.ossnms.bicnet.bcb.facade.security.ISecurityProviderFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.security.AuthorizationFailedException;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.bcb.model.security.InvalidAuthorizationInfoException;
import com.ossnms.bicnet.servicelocator.BiCNetServiceLocator;
import com.ossnms.bicnet.util.UnexpectedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Helper class to check for the Authorization on the Server side
 */
public final class USMAuthorizationHelper {

	private static final BiCNetComponentType SECURITY_TYPE =
		BiCNetComponentType.SECURITY_MANAGER;
	/**
	 * Data member to cache and hold the Security Provider Facade.
	 */
	private static ISecurityProviderFacade secProvider = null;

	/**
	 * Data member for the tracing functionality
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(USMAuthorizationHelper.class);

	/**
	 * Private constructor to make sure that no object is created
	 */
	private USMAuthorizationHelper() {
	}

	/**
	 * Function to check if the Client which is represented by the context that is
	 * passed has access or not.
	 * 
	 * @param ctx Context which represents the Client
	 * @param menuEntries Menu Entry that is associated for the operations
	 */
	// Fault Id 36 - Provide authorization check on server - Begin
	public static void checkAccessForClientThrowExceptionOnFailure(ISessionContext ctx, String menuEntries) throws BcbSecurityException {
		LOGGER.debug("Entering checkAccessForClient. Context : {} Menu Entry : {}", ctx, menuEntries);

		if ((null == ctx) || (null == menuEntries)) {
			LOGGER.error("Parameter is null. Context : {} Menu Entry : {}", ctx, menuEntries);
			throw new InvalidAuthorizationInfoException();
		}

		ISecurityProviderFacade secP = getSecurityProviderFacadeDirectly();

		// There seems to be some problem getting the Security Provider directly.
		// Get it in-directly. This has to be removed. This is a bug in 
		// The BicNetServiceLocator
		if (secP == null) {
			secP = getSecurityProviderFacadeInDirectly();
		}

		if (null == secP) {
			LOGGER.error("Security Provider is null");
			throw new InvalidAuthorizationInfoException();
		}

		ISecureServerSession secServerSession = secP.getServerSession(ctx);
		if (null == secServerSession) {
			LOGGER.error("ISecureServerSession is null");
			throw new InvalidAuthorizationInfoException();
		}

		if (!secServerSession.checkOperationPermission(menuEntries)) {
			throw new AuthorizationFailedException();
		}

		LOGGER.debug("Finished Authorization");
		// Fault Id 36 - Provide authorization check on server - End
	}

	/**
	 * Function to help cache the Security Provider Facade.
	 *
	 * @return ISecurityProviderFacade
	 * 			Retrieves the Security Provider Facade.
	 */
	private static ISecurityProviderFacade getSecurityProviderFacadeDirectly() {
		LOGGER.debug("Entering getSecurityProviderFacade.");

		if (null == secProvider) {

			try {
				// Fault Id 36 - Provide authorization check on server
				secProvider = BiCNetServiceLocator.getInstance().getSecurityManager(SECURITY_TYPE);
			} catch (UnsupportedOperationException | UnexpectedException e) {
				LOGGER.error("Exception raised. ", e);
			}
		}

		LOGGER.debug("Exiting getSecurityProviderFacade. Object being returned is : {}", secProvider);
		return secProvider;
	}
	// Fault Id 36 - Provide authorization check on server - Begin

	/**
	 * Function to help cache the Security Provider Facade.
	 * 
	 * @return ISecurityProviderFacade
	 * 			Retrieves the Security Provider Facade.
	 */
	private static ISecurityProviderFacade getSecurityProviderFacadeInDirectly() {
		LOGGER.debug("Entering getSecurityProviderFacadeInDirectly.");
		if (null == secProvider) {
			BiCNetServiceLocator bclSL = BiCNetServiceLocator.getInstance();

			if (bclSL == null) {
				LOGGER.error("The returned BiCNetServiceLocator is null.");
				return null;
			}

			IMgrFacade objMgrFacade = null;
			try {
				objMgrFacade =
					bclSL.getPublicFacade(SECURITY_TYPE, SECURITY_TYPE);
			} catch (UnsupportedOperationException e) {
				LOGGER.error("Exception raised. Type is UnsupportedOperationException.");
				LOGGER.error("Exception raised. ", e);
			} catch (UnexpectedException e) {
				LOGGER.error("Exception raised. Type is UnexpectedException.");
				LOGGER.error("Exception raised", e);
			}

			if (objMgrFacade instanceof ISecurityProviderFacade) {
				secProvider = (ISecurityProviderFacade) objMgrFacade;
			}
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Exiting getSecurityProviderFacadeInDirectly. Returning "
					+ secProvider);
		}
		return secProvider;
	}

	// Fault Id 36 - Provide authorization check on server - Begin
}