package com.ossnms.bicnet.securitymanagement.api.common;

import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;

public final class USMConstants {
    private USMConstants() {
    }

    public static final String COMMA = ",";
    public static final String EMPTY_STRING = "";
    public static final String INTERNAL_USERS = "internal.users";
    public static final String MILLISECONDS_UNIT = "[ms]";
    public static final String RESOURCE_FILE_NAME = "com.ossnms.bicnet.securitymanagement.server.util.messages";
    public static final String SPACE = " ";
    public static final String SECONDS_UNIT = "[s]";
    public static final String TWO_POINTS = ":";
    public static final String NOTIFICATION = "notification";
    public static final String MESSAGE_TYPE = "securityManager";

    public static final String DUMMY_PASSWORD = "$$$$$$$$$";

    public static final PAPolicyId POLICY_GLOBAL          = new PAPolicyId( 0, "GLOBAL");
    public static final PAPolicyId POLICY_NO_ACCESS       = new PAPolicyId(-1, "NO ACCESS");
    public static final PAPolicyId POLICY_NO_VISIBILITY   = new PAPolicyId(-2, "NO VISIBILITY");

    public static final int RANGE_PORT_DEFAULT     = 1812;
    public static final int RANGE_PORT_MIN         = 1;
    public static final int RANGE_PORT_MAX         = 65535;
    public static final int RANGE_PORT_STEP_SIZE   = 1;

    public static final int RANGE_TIMEOUT_DEFAULT  = 10;
    public static final int RANGE_TIMEOUT_MIN      = 1;
    public static final int RANGE_TIMEOUT_MAX      = 15;
    public static final int RANGE_TIMEOUT_STEP     = 1;

    public static final int RANGE_RETRIES_DEFAULT  = 3;
    public static final int RANGE_RETRIES_MIN      = 1;
    public static final int RANGE_RETRIES_MAX      = 5;
    public static final int RANGE_RETRIES_STEP     = 1;
}