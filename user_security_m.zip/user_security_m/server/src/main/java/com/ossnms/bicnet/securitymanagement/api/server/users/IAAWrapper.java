package com.ossnms.bicnet.securitymanagement.api.server.users;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.security.AccountLockedException;
import com.ossnms.bicnet.bcb.model.security.AuthorizationFailedException;
import com.ossnms.bicnet.bcb.model.security.InvalidCredentialsException;
import com.ossnms.bicnet.bcb.model.security.UserAccountDisabledException;
import com.ossnms.bicnet.securitymanagement.api.exception.PasswordHistoryViolationException;
import com.ossnms.bicnet.securitymanagement.common.auth.AAAdvisoryDetails;
import com.ossnms.bicnet.securitymanagement.common.auth.AAChangePasswordDetails;

public interface IAAWrapper {

    /**
     * Changes the user password for given user details
     *
     * @param sessionContext - Session token
     * @param userDetails -User details data object.
     * @return boolean - operation status
     * @throws PasswordHistoryViolationException
     */
	boolean changePassword(ISessionContext sessionContext,
			AAChangePasswordDetails userDetails)
			throws PasswordHistoryViolationException, BcbException;

    /**
     * @param userId user id for which change password rights has to be checked.
     * @return true if user has rights to change his password false otherwise.
     */
	boolean checkPasswordPermission(String userId);

    /**
     * Wraps ldap calls for retrieving Advisory message details data.
     *
     * @return USMMessage Returns the Advisory message details wrapped in
     * USMMessage.
     */
	AAAdvisoryDetails getAdvisoryMessage(ISessionContext sessionContext);

    /**
     * Wraps ldap calls for checking the password must changed on user logged in
     * or not.
     *
     * @param sessionContext - Session token.
     * @return USMMessage Returns the Advisory message details wrapped in
     * USMMessage.
     */
	boolean isPasswordMustChanged(ISessionContext sessionContext);

    /**
     * Helper function to check if the user who's id is passed, has to change
     * password Could happen because of password expiration or, if admin decides
     * that the password should be changed
     *
     * @param userID The user id of the user
     * @return boolean True indicates, password must be changed.
     */
	boolean isPasswordMustChanged(String userID);

    /**
     * Updates the last logoff time for the user
     *
     * @param session
     * @return boolean - status of the updating last logoff time in the LDAP DS.
     */
	boolean logoff(ISessionContext session);

    /**
     * Validates user credentials.
     *
     * @param username - User name.
     * @param password - password.
     * @return boolean - validation status
	 * @throws AuthorizationFailedException
	 * @throws UserAccountDisabledException
	 * @throws InvalidCredentialsException
	 * @throws AccountLockedException
	 */
	boolean logon(java.lang.String username, java.lang.String password)
			throws AuthorizationFailedException, UserAccountDisabledException,
			InvalidCredentialsException, AccountLockedException;
	
    /**
     * Updates the user's last attempted login time into LDAP.
     *
     * @param username - User Name
     * @param currDate - Attempted Logon time
     */
	boolean updateLastLoginAttemptTime(String username, String currDate);


	/**
	 * Updates the user last login time into LDAP
	 * 
	 * @param ldapUserName
	 *            - User Name
	 * @param host
	 *            the host
	 * @param b
	 *            - flag for updating the Log on time or logoff time (true =
	 *            logon time & false = logoff time)
	 * @return lastLoginTimeBeforeLogin StringBuffer
	 */
	boolean updateLastLoginTimeAndHost(String ldapUserName, String host,
			boolean b, StringBuilder strLastLoginTimeBeforeLogin);

	/**
	 * Retrieves the password salt of the user 
	 * 
	 * @param userName - the username
	 * @return - the salt
	 * @throws InvalidCredentialsException
	 */
	byte[] getUserPasswordSalt(String userName) throws InvalidCredentialsException;
}
