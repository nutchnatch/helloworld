/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AALdapInterface
 * Author      	Jogender Singh
 * Substitute	Vinay Purohit
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
  * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.LOGGING.VIEW
 *          TNMS.DX2.SM.LOGGING.ALARM
 *          TNMS.DX2.SM.LOGGING.ALARM.DOMAIN
 *          TNMS.DX2.SM.LOGGING.POLICY
 *          TNMS.DX2.SM.LOGGING.MAPPING
 *          TNMS.DX2.SM.LOGGING.CREATE

 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 10-Feb-2005	Asif 		CF000834 - Command Log Entries
 * 11-Mar-2005	Asif		CF000845 - System Event Log Entries
 * 22-Mar-2005	Muyeen Munaver	CF001791 - Problems with Login
 * 05-May-2005  Babu B          CF001312   Master-Master Replication for Sun ONE DS
 * 10-May-2005	Muyeen Munaver	CF002170 - Resolve the Host name into the IP address fails
 * 27-June-2007	Shrinidhi G V 	CF004252 -13 - NE activated/resync => Source in Sys Log is not NE ID name (ex. EM/NE)
 * 27-June-2007	Shrinidhi G V 	CF004252 -20 - NE activated/resync => Source in Sys Log is not NE ID name (ex. EM/NE)
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.logging;

import com.ossnms.bicnet.bcb.facade.licensing.LicenseLogRecordItem;
import com.ossnms.bicnet.bcb.facade.logMgmt.CommandLogRecordItem;
import com.ossnms.bicnet.bcb.facade.logMgmt.ILogMgrFacade;
import com.ossnms.bicnet.bcb.facade.logMgmt.LogIdItem;
import com.ossnms.bicnet.bcb.facade.logMgmt.SecurityLogRecordItem;
import com.ossnms.bicnet.bcb.facade.logMgmt.SystemEventLogRecordItem;
import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.licensing.ILicenseLogRecord;
import com.ossnms.bicnet.bcb.model.logMgmt.ICommandLogRecord;
import com.ossnms.bicnet.bcb.model.logMgmt.ISecurityLogRecord;
import com.ossnms.bicnet.bcb.model.logMgmt.ISystemEventLogRecord;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.server.IScsControllableImpl;
import com.ossnms.bicnet.servicelocator.BiCNetServiceLocator;
import com.ossnms.bicnet.servicelocator.IBiCNetServiceLocator;
import com.ossnms.bicnet.util.UnexpectedException;
import org.apache.log4j.Logger;

import java.util.Date;

/**
 * Represents a singleton. This class is a wrapper for Log M interfaces
 */
public final class LMInterFace {

    /**
     * Data member to hold logger of the class
     */
    private static final Logger LOGGER = Logger.getLogger(LMInterFace.class);
    /**
     * Data member to hold log record type
     */
    private static final String BELONGING_NAME = "Security Log";
    /**
     * Data member to hold common function name
     */
    private static final String CF_NAME = "User and Security Management";
    /**
    * Holds singleton instance
    */
    private static LMInterFace instance = null;

    /**
     * Data member to hold the Log Manager
     */
    ILogMgrFacade logMgr = getLogManager();

    /**
    * prevents instantiation
    */
    private LMInterFace() {
    }
    /**
    	 * This method creates a record and logs to security log
    	 * using the description passed as an argument
    	 * @param context
    	 * @param usmlogRecordData - Security log record details
    	 */
    public void createSecurityLogRecord(ISessionContext context, LMLogRecordData usmlogRecordData) {

        LOGGER.debug("createSecurityLogRecord() Entry");

        //CF000834, making it more robust
        ISessionContext sessionContext = context;
        if(null == sessionContext) {
            sessionContext = IScsControllableImpl.getLocalSecurityProviderFacade().getSystemAccountContext();
        }

        // Check if the log record can be created by using the enum.

        //Retrieving LogM Facade
        try {
            // Populating Security log record item
            ISecurityLogRecord securityLogrecord = new SecurityLogRecordItem(null);
            securityLogrecord.setBelongingName(BELONGING_NAME);
            securityLogrecord.setTimeStamp(new Date());

            String ipaddress = ((IEnhancedSessionContext) sessionContext).getClientIpAddress();
            securityLogrecord.setDeviceOrServerId(USMCommonHelper.getLocalHostName());
            securityLogrecord.setIpAddress(ipaddress);

            // securityLogrecord.setPortNumber(host);
            securityLogrecord.setUserName(((IEnhancedSessionContext) sessionContext).getUserName());
            // Populating activity details into security log record
            if(null != usmlogRecordData) {
                securityLogrecord.setAccessAtemptCounter(usmlogRecordData.getAccessAttemptCounter());
                securityLogrecord.setDescription(usmlogRecordData.getDescription());
                securityLogrecord.setActivityName(usmlogRecordData.getActivityName().getEventName());
                securityLogrecord.setActivityDetails(usmlogRecordData.getActivityDetails());
                securityLogrecord.setCommandClassification(usmlogRecordData.getCommandClassification());
                securityLogrecord.setInterfaceType(usmlogRecordData.getInterfaceType());
                securityLogrecord.setSuccessStatus(usmlogRecordData.getSuccessStatus());

                // Creating security log record
                if(logMgr != null) {
                    logMgr.createSecurityLogRecord(sessionContext, securityLogrecord);
                } else {
                    LOGGER.error("Log Manager Object is null.");
                }
            }

        } catch (BcbException e) {
            LOGGER.error("Failed to create security log record record " + usmlogRecordData);
            String desc = "Failed to create security log record record " + usmlogRecordData;
            desc += e.getMessage();
            createSecuritySystemEventRecord(sessionContext, USMCommonStrings.IDS_USM_SECURITY_LOG_UNAVAILABLE, LogSeverity.ERROR, USMCommonStrings.IDS_SECURITY_LOG);
        } catch (Exception e) {
            LOGGER.error("Failed to create security log record record " + usmlogRecordData, e);

        }


        LOGGER.debug("createSecurityLogRecord() Exit");

    }
    /**
     * This method creates a record and logs to command log
     * using the description passed as an argument
     * @param context
     * @param description - description to be used for for logging the record
     */
    public void createSecurityCommandRecord(ISessionContext context, String description, String affectedObject) {
        LOGGER.debug("createSecurityCommandRecord() Entry");

        ISessionContext sessionContext = context;
        if(null == sessionContext) {
            sessionContext = IScsControllableImpl.getLocalSecurityProviderFacade().getSystemAccountContext();
        }

        try {
            ICommandLogRecord commandLogRecord = new CommandLogRecordItem(null);
            commandLogRecord.setDescription(description);

            if(affectedObject !=null && affectedObject.trim().length()>0) {
                commandLogRecord.setAffectedObject(affectedObject);
            } else {
                commandLogRecord.setAffectedObject(CF_NAME);
            }

            commandLogRecord.setComponent(BiCNetComponentType.SECURITY_MANAGER);
            commandLogRecord.setTimeStamp(new Date());
            commandLogRecord.setUserName((sessionContext).getUserName());

            if(logMgr != null) {
                logMgr.createCommandLogRecord(sessionContext, commandLogRecord);
            } else {
                LOGGER.error("Log Manager Object is null.");

            }

        } catch (BcbException e) {
            LOGGER.error("Failed to create command log record for " + description, e);
        } catch (Exception e) {
            LOGGER.error("Failed to create command log record for " + description, e);
        }

        LOGGER.debug("logCommandRecord() Exit");

    }

    /**
     * This method creates a record and logs to system event log
     * using the description passed as an argument
     * @param context
     * @param description - description to be used for for logging the record
     */
    public void createSecuritySystemEventRecord(ISessionContext context, String description, LogSeverity severity, String affectedObject) {
        LOGGER.debug("createSecuritySystemEventRecord() Entry");

        //Get the server machine
        String terminalId = USMCommonHelper.getLocalHostName();
        ISessionContext sessionContext = context;

        if(null == sessionContext) {
            sessionContext = IScsControllableImpl.getLocalSecurityProviderFacade().getSystemAccountContext();
        }

        try {
            ISystemEventLogRecord sysEventLogRecord = new SystemEventLogRecordItem(null);
            sysEventLogRecord.setSeverity(severity);
            sysEventLogRecord.setDescription(description);
            if(affectedObject != null && affectedObject.trim().length() > 0) {
                sysEventLogRecord.setAffectedObject(affectedObject);
            } else {
                sysEventLogRecord.setAffectedObject(CF_NAME);
            }
            
            sysEventLogRecord.setComponent(BiCNetComponentType.SECURITY_MANAGER);
            sysEventLogRecord.setTimeStamp(new Date());
            sysEventLogRecord.setTerminalId(terminalId);
            sysEventLogRecord.setUserName(sessionContext.getUserName());
            if(logMgr != null) {
                logMgr.createSystemEventLogRecord(sessionContext, sysEventLogRecord);
            } else {
                LOGGER.error("Log Manager Object is null.");
            }
        } catch (BcbException e) {
            LOGGER.error("Failed to create command log record for " + description, e);
        } catch (Exception e) {
            LOGGER.error("Failed to create command log record for " + description, e);
        }
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("logSystemEventRecord() Exit");
        }
    }
    
    
    public void createLicenseLogRecord(String message, LogSeverity severity) {
    	ILicenseLogRecord licenseLogRecord = new LicenseLogRecordItem();
        licenseLogRecord.setDescription(message);
        licenseLogRecord.setSourceType(BiCNetComponentType.SECURITY_MANAGER);
        licenseLogRecord.setSeverity(severity);
        licenseLogRecord.setTimeStamp(new Date());
        licenseLogRecord.setBelonging(new LogIdItem("License Log"));
        
        ISessionContext systemAccount = IScsControllableImpl.getLocalSecurityProviderFacade().getSystemAccountContext();
        
        try {
        	if (logMgr != null) {
        		logMgr.createLogRecord(systemAccount, licenseLogRecord);
        	} else {
        		LOGGER.error("Failed to create license log record for " + message);
        	}
        } catch (BcbException e) {
        	LOGGER.error("Failed to create license log record for " + message, e);
        }
    }
    
    

    /**
    * Returns the singleton instance.
     @return - the singleton instance
    */
    public static synchronized LMInterFace getInstance() {
        if (instance == null) {
            instance = new LMInterFace();
        }
        return instance;
    }

    /**
     * Returns an instance of logManager facade
     * @return - logManager facade
     */
    private static ILogMgrFacade getLogManager() {

        LOGGER.debug("getLogManager() Entry");
        IBiCNetServiceLocator serviceLocator =
            BiCNetServiceLocator.getInstance();
        ILogMgrFacade logMgrFacade = null;
        try {

            logMgrFacade =
                serviceLocator.getLogManager(
                    BiCNetComponentType.SECURITY_MANAGER);

        } catch (UnsupportedOperationException e) {
            LOGGER.error("No Service Locator has previously been registered for LogM ", e);
        } catch (UnexpectedException e) {
            LOGGER.error("Log Facade could not be retreived, check configuration files ", e);
        }

        LOGGER.debug("getLogManager() Exit");

        return logMgrFacade;
    }

}
