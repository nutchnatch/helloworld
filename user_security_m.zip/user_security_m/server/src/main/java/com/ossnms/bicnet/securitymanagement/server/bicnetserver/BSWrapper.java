package com.ossnms.bicnet.securitymanagement.server.bicnetserver;

import com.ossnms.bicnet.bcb.facade.common.IconPairIdItem;
import com.ossnms.bicnet.bcb.model.ManagedObjectType;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.ComponentVersionInformation;
import com.ossnms.bicnet.bcb.model.common.IIconPair;
import com.ossnms.bicnet.bcb.model.common.IIconPairId;
import com.ossnms.bicnet.securitymanagement.api.persistence.dao.accessrights.IUSMCFDao;
import com.ossnms.bicnet.securitymanagement.api.persistence.dao.accessrights.IUSMSecurableElementContainerDao;
import com.ossnms.bicnet.securitymanagement.api.persistence.dao.accessrights.IUSMSecurableElementDao;
import com.ossnms.bicnet.securitymanagement.api.server.bicnetserver.IBSWrapper;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSAccessControlList;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObjectContainer;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.persistence.model.accessrights.USMCF;
import com.ossnms.bicnet.securitymanagement.persistence.model.accessrights.USMSecurableElement;
import com.ossnms.bicnet.securitymanagement.persistence.model.accessrights.USMSecurableElementContainer;
import org.hibernate.Hibernate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.ejb.Local;
import javax.ejb.Stateless;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 *
 * Interface class for all interactions with this subsystem. This isolates the persistence
 * logic from the business layer
 *
 */
@Stateless(name = "IBSWrapper")
@Local
public class BSWrapper implements IBSWrapper {

    private static final Logger LOGGER = LoggerFactory.getLogger(BSWrapper.class);

    private static final String DEBUG_ENTER_CONFIGURED_CFS = "getFunctions :: ENTER";
    private static final String DEBUG_EXIT_CONFIGURED_CFS = "getFunctions :: EXIT";
    private static final String DEBUG_ENTER_ALL_SEC_OBJS = "getSecurableObjects :: ENTER";
    private static final String DEBUG_EXIT_ALL_SEC_OBJS = "getSecurableObjects :: EXIT";
    private static final String DEBUG_ENTER_ALL_SEC_OBJS_CONTAINERS =  "getSecurableObjectContainers() :: ENTER";
    private static final String DEBUG_EXIT_ALL_SEC_OBJS_CONTAINERS = "getSecurableObjectContainers() :: EXIT";
    private static final String DEBUG_ENTER_UPDATE_ACL =  "updateACL() :: ENTER";
    private static final String DEBUG_EXIT_UPDATE_ACL = "updateACL() :: EXIT";
    private static final String DEBUG_ENTER_CREATE_SEC_OBJS =  "saveSecurableObjects(List<BSSecurableObject) :: ENTER";
    private static final String DEBUG_EXIT_CREATE_SEC_OBJS = "saveSecurableObjects(List<BSSecurableObject) :: EXIT";
    private static final String DEBUG_ENTER_CREATE_SEC_OBJ_CONTAINER =  "saveSecurableObjectContainer() :: ENTER";
    private static final String DEBUG_EXIT_CREATE_SEC_OBJ_CONTAINER = "saveSecurableObjectContainer() :: EXIT";
    private static final String DEBUG_ENTER_DELETE_SEC_OBJ =  "deleteSecurableObject() :: ENTER";
    private static final String DEBUG_EXIT_DELETE_SEC_OBJ = "deleteSecurableObject() :: EXIT";
    private static final String DEBUG_ENTER_DELETE_SEC_OBJ_CONTAINER =  "deleteSecurableObjectContainer() :: ENTER";
    private static final String DEBUG_EXIT_DELETE_SEC_OBJ_CONTAINER = "deleteSecurableObjectContainer() :: EXIT";
    private static final String DEBUG_ENTER_MODIFY_SEC_OBJ =  "modifySecurableObject() :: ENTER";
    private static final String DEBUG_EXIT_MODIFY_SEC_OBJ = "modifySecurableObject() :: EXIT";
    private static final String DEBUG_ENTER_MODIFY_SEC_OBJ_CONTAINER =  "modifySecurableObjectContainer() :: ENTER";
    private static final String DEBUG_EXIT_MODIFY_SEC_OBJ_CONTAINER = "modifySecurableObjectContainer() :: EXIT";
    private static final String DEBUG_ENTER_INSERT_CF =  "insertFunction() :: ENTER";
    private static final String DEBUG_EXIT_INSERT_CF = "insertFunction() :: EXIT";
    private static final String DEBUG_ENTER_REMOVE_CF =  "removeFunction() :: ENTER";
    private static final String DEBUG_EXIT_REMOVE_CF = "removeFunction() :: EXIT";
    private static final String DEBUG_ENTER_CHANGE_CF_DISPLAY_NAME =  "changeFunctionDisplayName() :: ENTER";
    private static final String DEBUG_EXIT_CHANGE_CF_DISPLAY_NAME = "changeFunctionDisplayName() :: EXIT";

    private static final String FORMAT_ERROR_CF_NOT_FOUND = "%s :: CF with name %s was not found.";
    private static final String FORMAT_ERROR_ELEMENT_NOT_FOUND = "%s :: element with name %s was not found.";
    private static final String FORMAT_ERROR_CONTAINER_NOT_FOUND = "%s :: container with name %s was not found.";

    private static final String SEPARATOR = " :: ";

    private Map<String, BSSecurableObjectContainer> containerTempCache;

    @EJB
    private IUSMCFDao functionDAO;

    @EJB
    private IUSMSecurableElementDao securableElementDao;

    @EJB
    private IUSMSecurableElementContainerDao securableContainerDAO;

    @Override
    public BSTransBicNetCFInfo getFunction(String id) {
        USMCF function = functionDAO.findById(id);

        if(function == null){
            return null;
        }

        return fromEntity(function);
    }

    /**
     * This method will retrieve all the CFs from the DB
     *
     * @return list of CFs that have been configured within USM
     */
    @Override
    public List<BSTransBicNetCFInfo> getFunctions() {
        LOGGER.debug(DEBUG_ENTER_CONFIGURED_CFS);

        List<BSTransBicNetCFInfo> listTransCFs = new ArrayList<>();

        List<USMCF> cfList = functionDAO.findAll();

        for(USMCF cf : cfList){
            BSTransBicNetCFInfo cfInfo = fromEntity(cf);
            if (null != cfInfo) {
                listTransCFs.add(cfInfo);
            }
        }

        LOGGER.debug(DEBUG_EXIT_CONFIGURED_CFS);
        return listTransCFs;
    }

    @Override
    public BSSecurableObject getSecurableObject(String uniqueName) {
        USMSecurableElement securableObject = securableElementDao.findById(uniqueName, true, false);

        if(securableObject == null){
            return null;
        }

        securableElementDao.loadAcl(securableObject);

        return fromEntity(securableObject);
    }

    @Override
    public BSSecurableObject getSecurableObjectWithACL(String uniqueName) {
        USMSecurableElement securableObject = securableElementDao.findById(uniqueName, false, true);

        if(securableObject == null){
            return null;
        }

        return fromEntity(securableObject);
    }

    /**
     *
     * @return
     */
    @Override
    public List<BSSecurableObject> getSecurableObjects() {
        List<BSSecurableObject> securableObjects = new ArrayList<>();

        securableObjects.addAll(
                getFunctions()
                    .stream()
                    .map(this::getSecurableObjects)
                    .flatMap(Collection::stream)
                    .collect(Collectors.toList())
        );

        return securableObjects;
    }

    @Override
    public List<BSSecurableObject> getSecurableObjectsWithACL() {
        List<BSSecurableObject> securableObjects = new ArrayList<>();

        securableObjects.addAll(
                securableElementDao.findAllWithACL()
                        .stream()
                        .map(this::fromEntity)
                        .collect(Collectors.toList())
        );

        return securableObjects;
    }

    /**
     * Returns all the Securable Objects that are part of the passed
     * CF.
     * @param cf  The CF for which we are retrieving the Securable Object info.
     * @return List The List of Securable Objects which are available for the CF in the DB.
     */
    @Override
    public List<BSSecurableObject> getSecurableObjects(BSTransBicNetCFInfo cf) {
        LOGGER.debug(DEBUG_ENTER_ALL_SEC_OBJS);

        // init temporary cache
        containerTempCache = new ConcurrentHashMap<>();

        List<BSSecurableObject> listSecurableObjs = new ArrayList<>();
        String cfId = cf.getCFid();

        List<USMSecurableElement> elements = securableElementDao.findByFunction(cfId, true, false);

        for(USMSecurableElement element : elements){
            // load ACL
            securableElementDao.loadAcl(element);
            // to dto
            BSSecurableObject neInfo = fromEntity(element);
            if(null != neInfo) {
                listSecurableObjs.add(neInfo);
            }
        }

        containerTempCache.clear();
        containerTempCache = null;


        LOGGER.debug(DEBUG_EXIT_ALL_SEC_OBJS);

        return listSecurableObjs;
    }

    @Override
    public List<BSSecurableObject> getSecurableObjects(BSTransBicNetCFInfo cf, int domainId) {
        LOGGER.debug(DEBUG_ENTER_ALL_SEC_OBJS);

        // init temporary cache
        containerTempCache = new ConcurrentHashMap<>();

        List<BSSecurableObject> listSecurableObjs = new ArrayList<>();
        String cfId = cf.getCFid();

        List<USMSecurableElement> elements = securableElementDao.findByFunctionAndDomain(cfId, domainId, true, false);

        for(USMSecurableElement element : elements){
            // load ACL
            securableElementDao.loadAcl(element);
            // to dto
            BSSecurableObject neInfo = fromEntity(element);
            if(null != neInfo) {
                listSecurableObjs.add(neInfo);
            }
        }

        // clear temp cache
        containerTempCache.clear();
        containerTempCache = null;

        LOGGER.debug(DEBUG_EXIT_ALL_SEC_OBJS);

        return listSecurableObjs;
    }

    @Override
    public BSSecurableObjectContainer getSecurableObjectContainer(String uniqueName) {
        USMSecurableElementContainer container = securableContainerDAO.findById(uniqueName);

        if(container == null){
            return null;
        }

        return fromEntity(container, fromEntity(container.getCf()));
    }

    /**
     *
     * @return
     */
    public int getContainerChildCount(String uniqueName){
        USMSecurableElementContainer container = securableContainerDAO.findById(uniqueName);
        int count = 0;

        if(container == null){
            return count;
        }

        securableContainerDAO.loadSecurableElements(container);
        securableContainerDAO.loadChildContainers(container);

        count += container.getChildContainers().size();
        count += container.getSecurableElements().size();

        return count;
    }

    /**
     * This method returns all the Securable Object Containers that are part of the passed CF.
     * @param cf  The CF for which we are retrieving the Securable Object info.
     * @return List The List of Securable Object Containers which are available for the CF in the DB.
     */
    @Override
    public List<BSSecurableObjectContainer> getSecurableObjectContainers(BSTransBicNetCFInfo cf) {
        LOGGER.debug(DEBUG_ENTER_ALL_SEC_OBJS_CONTAINERS);
        List<BSSecurableObjectContainer> lstSecurableObjectContainers = new ArrayList<>();

        String cfId = cf.getCFid();

        //load the securable elements directly from the usmCf instance
        List<USMSecurableElementContainer> containers = securableContainerDAO.findByFunction(cfId);

        //For each container, search for the parents and set them before adding the instance to the list
        for (USMSecurableElementContainer container : containers) {
            BSSecurableObjectContainer securableObjectContainer = fromEntity(container, cf);
            if(securableObjectContainer != null) {
                List<BSSecurableObjectContainer> parents = new ArrayList<>();
                List<USMSecurableElementContainer> parentContainers = container.getParentContainers();

                for(USMSecurableElementContainer cntnr : parentContainers) {
                    BSSecurableObjectContainer parentContainer = fromEntity(cntnr, cf);
                    if (parentContainer != null) {
                        parents.add(parentContainer);
                    }
                }

                //Set parent containers
                securableObjectContainer.setObjectContainers(parents);

                //add the container to the list
                lstSecurableObjectContainers.add(securableObjectContainer);
            }
        }

        LOGGER.debug(DEBUG_EXIT_ALL_SEC_OBJS_CONTAINERS);
        return lstSecurableObjectContainers;
    }

    /**
     * This method is used to update the ACL for the Securable Object.
     * @param secObj  The Securable Object which should be modified
     * @return boolean  Indicates whether it was possible to update the ACL within
     * the DB. True indicates success.
     */
    @Override
    public boolean updateACL(BSSecurableObject secObj) {
        LOGGER.debug(DEBUG_ENTER_UPDATE_ACL);
        boolean result = false;

        USMSecurableElement neData = securableElementDao.findById(secObj.getUniqueName(), false, true);
        List<Integer> aclList = new ArrayList<>();

        String aclStr = secObj.getACL().toString();
        aclStr = aclStr.replace("{", "");
        aclStr = aclStr.replace("}", "");

        for(String domainId : aclStr.split(",")){
            if(!domainId.trim().isEmpty()){
                aclList.add(Integer.parseInt(domainId.trim()));
            }
        }

        neData.setAcl(aclList);
        try{
            securableElementDao.save(neData);
            result = true;
        }catch(EJBException e){
            LOGGER.debug("Error when saving ACL", e);
        }

        LOGGER.debug(DEBUG_EXIT_UPDATE_ACL);
        return result;
    }

    @Override
    public boolean saveSecurableObject(BSSecurableObject securableObject) {
        if(securableObject == null){
            return false;
        }

        USMSecurableElement element = fromDTO(securableObject);
        if(element == null){
            return false;
        }

        List<BSSecurableObjectContainer> containers = securableObject.getObjectContainers();
        // if the list of containers is bigger than 0, update
        if(containers != null && containers.size() > 0){
            containers.forEach(this::saveSecurableObjectContainer);
        }

        try{
            element = securableElementDao.save(element);
            if(element == null){
                LOGGER.debug("{} was not saved.", securableObject);
            }
        }catch(EJBException e){
            LOGGER.debug("Error when saving Securable object", e);
            return false;
        }


        return false;
    }

    /**
     * Create Securable Objects in the DB
     * @param listSecurableObjs List of Transient Securable Objects which should be persisted
     * in LDAP
     * @return boolean True indicates successful creation.
     */
    @Override
    public boolean saveSecurableObjects(List<BSSecurableObject> listSecurableObjs) {
        LOGGER.debug(DEBUG_ENTER_CREATE_SEC_OBJS);

        if (listSecurableObjs!= null) {
            listSecurableObjs.forEach(this::saveSecurableObject);
        }

        LOGGER.debug(DEBUG_EXIT_CREATE_SEC_OBJS);
        return true;
    }

    /**
     * Method to create Securable Object Containers
     * @param container the Transient Securable Object Container
     * @return boolean True indicates successful creation.
     */
    @Override
    public boolean saveSecurableObjectContainer(BSSecurableObjectContainer container) {
        LOGGER.debug(DEBUG_ENTER_CREATE_SEC_OBJ_CONTAINER);
        USMSecurableElementContainer elementContainer = fromDTO(container);
        boolean res = false;

        if(elementContainer != null) {
            try {
                List<BSSecurableObjectContainer> containers = container.getObjectContainers();
                // if the list of containers is bigger than 0, save all
                if(containers != null && containers.size() > 0){
                    containers.forEach(this::saveSecurableObjectContainer);
                }

                securableContainerDAO.save(elementContainer);
                res = true;
            } catch (EJBException e) {
                LOGGER.debug(e.getMessage());
                res = false;
            }
        }
        LOGGER.debug(DEBUG_EXIT_CREATE_SEC_OBJ_CONTAINER);
        return res;
    }

    @Override
    public boolean deleteSecurableObject(BSSecurableObject secObj) {
        LOGGER.debug(DEBUG_ENTER_DELETE_SEC_OBJ);

        try{
            securableElementDao.delete(secObj.getUniqueName());
            return true;
        }catch(EJBException e){
            LOGGER.debug(e.getMessage());
            return false;
        }finally{
            LOGGER.debug(DEBUG_EXIT_DELETE_SEC_OBJ);
        }
    }

    @Override
    public boolean deleteSecurableObjectContainer(BSSecurableObjectContainer container) {
        LOGGER.debug(DEBUG_ENTER_DELETE_SEC_OBJ_CONTAINER);

        try{
            securableContainerDAO.delete(container.getUniqueName());
            return true;
        }catch(EJBException e){
            LOGGER.debug(e.getMessage());
            return false;
        }finally {
            LOGGER.debug(DEBUG_EXIT_DELETE_SEC_OBJ_CONTAINER);
        }
    }

    @Override
    public boolean modifySecurableObject(BSSecurableObject secObj) {
        LOGGER.debug(DEBUG_ENTER_MODIFY_SEC_OBJ);

        boolean res = false;

        USMSecurableElement element = getSecurableElementForModification(secObj);
        if(element != null) {
            try {
                securableElementDao.save(element);
                res = true;
            } catch (EJBException e) {
                LOGGER.debug(e.getMessage());
            }
        }

        LOGGER.debug(DEBUG_EXIT_MODIFY_SEC_OBJ + SEPARATOR + res);
        return res;
    }

    @Override
    public boolean modifySecurableObjectContainer(BSSecurableObjectContainer secObjectContainer) {
        LOGGER.debug(DEBUG_ENTER_MODIFY_SEC_OBJ_CONTAINER);
        boolean res = false;

        USMSecurableElementContainer container = getSecurableElementContainerForModification(secObjectContainer);
        if(container != null) {
            try {
                securableContainerDAO.save(container);
                res = true;
            } catch (EJBException e) {
                LOGGER.debug(e.getMessage());
            }
        }

        LOGGER.debug(DEBUG_EXIT_MODIFY_SEC_OBJ_CONTAINER + SEPARATOR + res);
        return res;
    }

    @Override
    public boolean insertFunction(BSTransBicNetCFInfo transCF) {
        LOGGER.debug(DEBUG_ENTER_INSERT_CF);
        boolean res = false;

        USMCF cf = fromDTO(transCF);

        try{
            functionDAO.save(cf);
            res = true;
        }catch(EJBException e){
            LOGGER.debug(e.getMessage());
        }

        LOGGER.debug(DEBUG_EXIT_INSERT_CF + SEPARATOR + res);
        return res;
    }

    @Override
    public boolean removeFunction(BSTransBicNetCFInfo cf) {
        LOGGER.debug(DEBUG_ENTER_REMOVE_CF);
        boolean res = false;

        try{
            functionDAO.delete(cf.getCFid());
            res = true;
        }catch(EJBException e){
            LOGGER.debug(e.getMessage());
        }
        LOGGER.debug(DEBUG_EXIT_REMOVE_CF + SEPARATOR + res);
        return res;
    }

    @Override
    public boolean changeFunctionDisplayName(BSTransBicNetCFInfo cf) {
        LOGGER.debug(DEBUG_ENTER_CHANGE_CF_DISPLAY_NAME);

        boolean res = false;

        USMCF cfItem = functionDAO.findById(cf.getCFid());
        if(cfItem != null){
            //set the display name
            cfItem.setName(cf.getName());

            try{
                functionDAO.save(cfItem);
                res = true;
            }catch(EJBException e){
                LOGGER.debug(e.getMessage());
            }
        }

        LOGGER.debug(DEBUG_EXIT_CHANGE_CF_DISPLAY_NAME + SEPARATOR + res);
        return res;
    }

    /**
     * Retrieves the securable object by display name
     *
     * @param displayName the display name of the securable object
     * @return an optional instance of BSSecurableObject
     */
    @Override
    public Optional<BSSecurableObject> getSecurableObjectByDisplayName(String displayName) {
        USMSecurableElement element = securableElementDao.findByDisplayName(displayName, false, true);

        if(element == null){
            return Optional.empty();
        }

        BSSecurableObject securableObject = fromEntity(element);

        return Optional.ofNullable(securableObject);
    }

    @Override
    public int getSecurableObjectCount(BSTransBicNetCFInfo server) {
        return securableElementDao.countByFunction(server.getCFid());
    }

    @Override
    public int getSecurableObjectCount(BSTransBicNetCFInfo server, int domainID) {
        return securableElementDao.countByFunctionAndDomain(server.getCFid(), domainID);
    }

    /**
     *
     * @param cf common function
     * @return BSTransBicNetCFInfo instance with the USMCF instance info
     */
    private BSTransBicNetCFInfo fromEntity(USMCF cf){
        BSTransBicNetCFInfo transCf = null;

        String strName = cf.getName();
        String strType = cf.getCfId();
        String strBuild = cf.getBuild();
        String strMajor = cf.getMajor();
        String strMinor = cf.getMinor();
        String strRelease = cf.getRelease();
        String strDescription = cf.getDescription();

        if((null != strName) && (null != strType) && (null != strBuild) && (null != strMajor) && (null != strMinor) && (null != strRelease) && (null != strDescription)) {
            ComponentVersionInformation ver = new ComponentVersionInformation(strName, strMajor+"."+strMinor, "0");
            transCf = new BSTransBicNetCFInfo(strName, strDescription, BiCNetComponentType.fromName(strType), ver);
        } else {
            LOGGER.error("Null value detected while creating Pers CF Object." + " Name : " + strName + " Type : " + strType + " Build : " + strBuild + " Major : " + strMajor + " Minor : "
                    + strMinor + " Release : " + strRelease + " Description : " + strDescription);
        }

        return transCf;
    }

    /**
     *
     * @param element
     * @return
     */
    private BSSecurableObject fromEntity(USMSecurableElement element){

        BSSecurableObject secObj = null;

        String strName = element.getName();
        String strUniqueName = element.getUniqueName();
        String strCfId = element.getCf().getCfId();
        String iconId = element.getIconId();

        List<BSSecurableObjectContainer> containers = null;
        BSAccessControlList acl = null;

        BSTransBicNetCFInfo functionInfo = fromEntity(element.getCf());

        if(functionInfo == null){
            return null;
        }

        if(Hibernate.isInitialized(element.getContainers())){
            containers = new ArrayList<>();
            containers.addAll(
                    element.getContainers()
                            .stream()
                            .map(container -> fromEntity(container, functionInfo))
                            .collect(Collectors.toList())
            );
        }

        if(Hibernate.isInitialized(element.getAcl())){
            List<Integer> acls = element.getAcl();
            acl = new BSAccessControlList(acls);
        }

        int nType = element.getType() == 0 ? ManagedObjectType.NE.getOrdinal() : element.getType();
        ManagedObjectType type = ManagedObjectType.fromOrdinal(nType);

        if(strName != null && strUniqueName != null) {
            IIconPairId iconPair = new IconPairIdItem(functionInfo.getComponentType(), iconId);
            IIconPair icon = BSServerHelper.getIconFromComponent(iconPair);

            secObj = new BSSecurableObject(strName, strUniqueName, strCfId, functionInfo.getName(), acl, icon, containers, type);
        } else {
            LOGGER.error("One of the attribute retrieved is null. " + " Display Name : " + strName + " Unique Name : " + strUniqueName + " ACL(n) : " + (acl == null ? 0 : acl.toString()) + " CF id" + strCfId);
        }

        return secObj;
    }

    /**
     *
     * @param container
     * @param cf
     * @return
     */
    private BSSecurableObjectContainer fromEntity(USMSecurableElementContainer container, BSTransBicNetCFInfo cf){
        // loading from the database

        if(containerTempCache != null && containerTempCache.containsKey(container.getUniqueName())){
            return containerTempCache.get(container.getUniqueName());
        }

        String strName = container.getName();
        String strUniqueName = container.getUniqueName();
        String strCfId = container.getCf().getCfId();

        //iconId might be null (securableObjectContainers can have a null icon), so read the null value directly from DB without logging an error message
        String iconId = container.getIconId();

        int nType = container.getType() == 0 ? ManagedObjectType.NE.getOrdinal() : container.getType();
        ManagedObjectType type = ManagedObjectType.fromOrdinal(nType);

        BSSecurableObjectContainer secObjContainer = null;
        if(strName != null && strUniqueName != null && strCfId != null) {
            IIconPairId iconPair = new IconPairIdItem(cf.getComponentType(), iconId);
            IIconPair icon = BSServerHelper.getIconFromComponent(iconPair);
            secObjContainer = new BSSecurableObjectContainer(strName, strUniqueName, strCfId, cf.getName(), icon, container.isCompound(), new ArrayList<>(), type);

            for(USMSecurableElementContainer elementContainer : container.getParentContainers()){
                secObjContainer.getObjectContainers().add(fromEntity(elementContainer, cf));
            }

//            if(Hibernate.isInitialized(container.getChildContainers())){
//                List<USMSecurableElementContainer> childContainers = container.getChildContainers();
//                // copy into effectively final
//                BSSecurableObjectContainer finalSecObjContainer = secObjContainer;
//                childContainers.forEach(childContainer -> {
//                    BSSecurableObjectContainer bsContainer = fromEntity(childContainer, cf);
//                    if(bsContainer != null){
//                        finalSecObjContainer.getChildObjects().add(bsContainer);
//                    }
//                });
//            }

//            if(Hibernate.isInitialized(container.getSecurableElements())){
//                List<USMSecurableElement> childElements = container.getSecurableElements();
//                // copy into effectively final
//                BSSecurableObjectContainer finalSecObjContainer = secObjContainer;
//                childElements.forEach(childElement -> {
//                    BSSecurableObject bsObject = fromEntity(childElement);
//                    if(bsObject != null){
//                        finalSecObjContainer.getChildObjects().add(bsObject);
//                    }
//                });
//            }
        } else {
            LOGGER.error("One of the attribute retrieved is null. " + " Display Name : " + strName + " Unique Name : " + strUniqueName + " CF id" + strCfId);
        }

        if(containerTempCache != null){
            containerTempCache.put(secObjContainer.getUniqueName(), secObjContainer);
        }
        return secObjContainer;
    }

    /**
     *
     * @param transSecObj
     * @return
     */
    private USMSecurableElement fromDTO(BSSecurableObject transSecObj){
        USMSecurableElement element = new USMSecurableElement();

        element.setName(transSecObj.getDisplayName());
        element.setUniqueName(transSecObj.getUniqueName());

        element.setIconId(transSecObj.getIcon() != null ? transSecObj.getIcon().getId() : null);
        element.setType(transSecObj.getManagedObjectType().getOrdinal());

        //Parse the ACL and set it
        if(transSecObj.getACL() != null){
            element.setAcl(new ArrayList<>());
            for(Integer domainId : transSecObj.getACL().getAclList()){
                element.getAcl().add(domainId);
            }
        }

        if(transSecObj.getObjectContainers() != null){
            element.setContainers(new ArrayList<>());
            for(BSSecurableObjectContainer parent : transSecObj.getObjectContainers()){
                USMSecurableElementContainer parentContainer = fromDTO(parent);
                element.getContainers().add(parentContainer);
            }
        }

        USMCF cf = functionDAO.findById(transSecObj.getOwnerCfId());
        if(cf == null){
            LOGGER.error(String.format(FORMAT_ERROR_CF_NOT_FOUND, "fromDTO", transSecObj.getOwnerCfId()));
            return null;
        }
        element.setCf(cf);

        return element;
    }

    /**
     *
     * @param objContainer
     * @return
     */
    private USMSecurableElementContainer fromDTO(BSSecurableObjectContainer objContainer){
        USMSecurableElementContainer container = securableContainerDAO.findById(objContainer.getUniqueName());

        if (container == null) {
            container = new USMSecurableElementContainer();
        }
//        else {
////            securableContainerDAO.loadChildContainers(container);
////            securableContainerDAO.loadParentContainers(container);
//        }

        container.setName       (objContainer.getDisplayName());
        container.setUniqueName (objContainer.getUniqueName());
        container.setIconId     (objContainer.getIcon() != null ? objContainer.getIcon().getId() : null);
        container.setType       (objContainer.getManagedObjectType().getOrdinal());
        container.setCompound   (objContainer.isCompound());

        container.setParentContainers(new ArrayList<>());

        if(objContainer.getObjectContainers() != null){
            for(BSSecurableObjectContainer parent : objContainer.getObjectContainers()){
                USMSecurableElementContainer parentContainer = fromDTO(parent);

                if(parentContainer != null){
                    container.getParentContainers().add(parentContainer);
                }
            }
        }

        USMCF cf = functionDAO.findById(objContainer.getOwnerCfId());
        if(cf == null){
            LOGGER.error(String.format(FORMAT_ERROR_CF_NOT_FOUND, "fromDTO", objContainer.getOwnerCfId()));
            return null;
        }
        container.setCf(cf);

        return container;
    }

    /**
     *
     * @param cfInfo
     * @return
     */
    private USMCF fromDTO(BSTransBicNetCFInfo cfInfo){
        USMCF cf = new USMCF();

        cf.setCfId(cfInfo.getCFid());
        cf.setName(cfInfo.getName());
        cf.setDescription(cfInfo.getDescription());
        ComponentVersionInformation ver = cfInfo.getVersion();
        cf.setMajor("0");
        cf.setMinor("0");
        cf.setBuild(ver.getVersion());
        cf.setRelease(ver.getBcbVersion());

        return cf;
    }

    /**
     *
     * @param secObject
     * @return
     */
    private USMSecurableElement getSecurableElementForModification(BSSecurableObject secObject){
        USMSecurableElement element = securableElementDao.findById(secObject.getUniqueName());

        if(element == null){
            LOGGER.error(String.format(FORMAT_ERROR_ELEMENT_NOT_FOUND, "getSecurableElementForModification", secObject.getOwnerCfId()));
            return null;
        }

        securableElementDao.loadContainers(element);
        securableElementDao.loadAcl(element);

        element.setName(secObject.getDisplayName());
        element.setIconId(secObject.getIcon() != null ? secObject.getIcon().getId() : null);

        //Parse the ACL and set it
        element.setAcl(new ArrayList<>());
        for(Integer domainId : getDomainIdFromAccessControlList(secObject.getACL())){
            element.getAcl().add(domainId);
        }

        if(secObject.getObjectContainers() != null){
            element.setContainers(new ArrayList<>());
            for(BSSecurableObjectContainer containerInfo : secObject.getObjectContainers()){
                USMSecurableElementContainer container = securableContainerDAO.findById(containerInfo.getUniqueName());
                if(container == null){
                    //In case the container does not exist yet, we should provide a way to insert it anyway.
                    //This can be done by retrieving the information from the BSTransSecurableContainer object
                    //and setting that information inside the container
                    container = fromDTO(containerInfo);
                    //This container will be added to the list of containers of the element
                    //and persisted when calling save on the element
                }
                element.getContainers().add(container);
            }
        }

        return element;
    }

    /**
     *
     * @param secContainer
     * @return
     */
    private USMSecurableElementContainer getSecurableElementContainerForModification(BSSecurableObjectContainer secContainer){
        USMSecurableElementContainer container = securableContainerDAO.findById(secContainer.getUniqueName());
        if(container == null){
            LOGGER.error(String.format(FORMAT_ERROR_CONTAINER_NOT_FOUND, "getSecurableElementContainerForModification", secContainer.getUniqueName()));
            return null;
        }

        container.setName(secContainer.getDisplayName());
        container.setIconId(secContainer.getIcon() != null ? secContainer.getIcon().getId() : null);
        container.setCompound(secContainer.isCompound());
        return container;
    }

    /**
     *
     * @param accessControlList
     * @return
     */
    private Integer[] getDomainIdFromAccessControlList(BSAccessControlList accessControlList) {
        if(accessControlList == null){
            return null;
        }

        List<Integer> aclList = accessControlList.getAclList();
        return aclList.toArray(new Integer[aclList.size()]);
    }
}


