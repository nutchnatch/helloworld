package com.ossnms.bicnet.securitymanagement.server.interfaces;

public interface ISecurityServerConfigurationPrivateFacadeRemote extends ISecurityServerConfigurationPrivateFacade { }

