package com.ossnms.bicnet.securitymanagement.api.server.users;

import com.ossnms.bicnet.securitymanagement.api.exception.PasswordHistoryViolationException;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;

import java.util.List;
import java.util.Map;

public interface IUAWrapper {

    /**
     * Method to create an User in the DB.
     * It throws an exception if any errors occur or User details are incorrect
     *
     * @param userData Contains the data about user including the user group to which it belongs to.
     * @return the result of the operation: true if successful; false otherwise
     */
    boolean createUser(UAUser userData);

    /**
     * Modify the user attributes in DB
     *
     * @param userData a user data class containing information about the user including the user groups to which it belongs to
     * @return The result of the operation
     * true if successful; false otherwise
     * @throws PasswordHistoryViolationException
     */
    boolean modifyUser(UAUser userData, boolean modifyPassword) 
    		throws PasswordHistoryViolationException;

    /**
     * This method is responsible for deleting the given user
     *
     * @param strUserID is the usrid of user to be deleted
     * @return The result of the operation  true if user was deleted successfully
     */
    boolean deleteUser(String strUserID);

    /**
     * Activate the specified users
     *
     * @param lstUsers           Users to be activated
     * @param lstSuccessfulUsers Users successfully activated
     * @return Users that could not be successfully activated
     */
    List<String> activateUsers(List<String> lstUsers, List<String> lstSuccessfulUsers);

    /**
     * Deactivate the specified users
     *
     * @param lstUsers           Users to be deactivated
     * @param lstSuccessfulUsers Users successfully deactivated
     * @return Users that could not be successfully deactivated
     */
    List<String> deactivateUsers(List<String> lstUsers, List<String> lstSuccessfulUsers);

    /**
     * Unlock the specified users
     *
     * @param lstUsers           Users to be unlocked
     * @param lstSuccessfulUsers Users successfully unlocked
     * @return Users that could not be successfully unlocked
     */
    List<String> unlockUsers(List<String> lstUsers, List<String> lstSuccessfulUsers);

    /**
     * Unlock the specified users
     *
     * @param lstUsers           Users to be unlocked
     * @param lstSuccessfulUsers Users successfully unlocked
     * @return Users that could not be successfully unlocked
     */
    List<String> passwordExpiredForUsers(List<String> lstUsers, List<String> lstSuccessfulUsers, boolean expired);

    /**
     * Function to retrieve the complete information about the User.
     *
     * @return
     */
    List<UAUser> retrieveAllUsers();

    /**
     * Method to return the total number of users in the database
     *
     * @return the number of users in the database
     */
    int getUserCount();

    /**
     * Updates the user last login time into LDAP. We should not be updating the Cache.
     * But rather wait for the Notification that comes later to do the same.
     *
     * @param userName - User Name
     * @param isLogon  - flag for updating the Log on time or logoff time (true = logon time & false = logoff time)
     * @return boolean - operation status
     */
    boolean updateLastLoginLogoutTimeAndHost(String userName, String host, String strTime, boolean isLogon);

    /**
     * Updates the user's last attempted login time into LDAP.
     *
     * @param userName - User Name
     * @param strTime  - Attempted Logon time
     */
    boolean updateLastLoginAttemptTime(String userName, String strTime);

    /**
     * Function to return the Bad password count for the user passed
     *
     * @param strUID The User ID for which we have to get the Bad Password count.
     * @return int Represent the Bad Password count.
     */
    int getBadPasswordCountByUser(String strUID);

    boolean updateBadPasswordCountByUser(String strUID, int nBadPasswordCount);

    /**
     * Function to retrieve the complete information about the User.
     *
     * @return
     */
    List<UAUser> retrieveUsersForPasswordExpiry();

    /**
     * This method creates a Map of all the users and the passwords in LDAP directory and returns it.<br>
     * This method is called when the security configuration for the users is to be exported.<br>
     *
     * @return - Map of user Ids v/s the encrypted password in stringified format.
     */
    Map<String, String> loadPasswords();

    /**
     * Given the username, retrieves the user with the matching username.
     *
     * @param username the username
     * @return an instance of UAUser if the user exists, null otherwise.
     */
    UAUser retrieveUser(String username);



    /**
     * Given the username Admin
     *
     * @return an instance of UAUser
     */
    UAUser getAdminUser();


    /**
     * Given the username and input password, validates the password against the db information
     * @param username
     * @param password
     * @return
     */
    boolean validatePassword(String username, String password);
}

