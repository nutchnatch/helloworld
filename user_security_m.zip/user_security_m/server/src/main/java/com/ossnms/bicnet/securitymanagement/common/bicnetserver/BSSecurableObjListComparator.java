/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	BSSecurableObjListComparator
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_OBJECTS
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_ACL 
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_SECURITY
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.INSERT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.bicnetserver;

import org.apache.log4j.Logger;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * This class is mainly used in the case when we want to Snchronize the Securable Object(s). This
 * could happen in the case when the Sync Securable Object(s) button is pressed. Therefore now
 * we have 2 List of Securable Object(s). The first List contains the Securable Object(s) that are available
 * with CF USM. In the second List there are the Securable Object(s) that have come from
 * the CF. There could be the following or a combination of the following
 * that could occur
 * 1. New Securable Object(s) could have got created.
 * 2. Securable Object(s) could have been deleted.
 * 3. Securable Object(s) could have been modified. (Only the display Name)
 * 4. Securable Object(s) could have been un-modified.
 * It makes no sense to do a dump of these Securable Object(s). But to do selective Handling. This
 * class is responsible for the separation into the 4 Lists.
 */
public class BSSecurableObjListComparator {

    /**
     * List to hold the Securable Object(s) that have been newly created since the last sync point
     */
    private List<BSSecurableObject> lstNewlyCreatedSecObjs = new ArrayList<BSSecurableObject>();

	/**
	 * List to hold the Securable Object(s) that have been deleted since the last sync point
	 */
	private List<BSSecurableObject> lstRemovedSecObjs = new ArrayList<BSSecurableObject>();

	/**
	 * List to hold the Securable Object(s) that have been modified since the last sync point
	 */
	private List<BSSecurableObject> lstModifedSecObjs = new ArrayList<BSSecurableObject>();

	/**
	 * Data member for the tracing.
	 */
	private static final Logger LOGGER = Logger.getLogger(BSSecurableObjListComparator.class);

	/**
	 * Creates a new instance of BSSecurableObjListComparator
	 * @param lstOldSecObjs The List of Old Securable Object(s) that are currently available within CF USM
	 * @param lstNewSecObjs The List of New Securable Object(s) that have been retrieved from the CF
	 */
	public BSSecurableObjListComparator(List<BSSecurableObject> lstOldSecObjs, List<BSSecurableObject> lstNewSecObjs) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering BSSecurableObjListComparator. Old List : " + lstOldSecObjs + " New List : " + lstNewSecObjs);
        }

        if((lstOldSecObjs == null) || (lstNewSecObjs == null)) {
            LOGGER.error("Parameter is null. Old List : " + lstOldSecObjs + " New List : " + lstNewSecObjs);
            throw new InvalidParameterException();
        }

        // Firstly we shall sort the Securable Object(s).
        Collections.sort(lstOldSecObjs);
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Sorted List of Old Objects : " + lstOldSecObjs);
        }

        Collections.sort(lstNewSecObjs);
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Sorted List of New Objects : " + lstNewSecObjs);
        }

		check(lstOldSecObjs, lstNewSecObjs);
	}

	/**
	 * The function which will do the checking and segregation into the necessary
	 * Lists.
	 * @param lstOldSecObjs List which contains the sorted Securable Object(s) within CF USM (old)
	 * @param lstNewSecObjs List which contains the sorted Securable Object(s) from the CF (new)
	 */
	private void check(List<BSSecurableObject> lstOldSecObjs, List<BSSecurableObject> lstNewSecObjs) {
        int indexOld = 0;
        int indexNew = 0;
        boolean bContinue = true;

        while(bContinue) {
            BSSecurableObject neOld = null;
            // First we shall get the NE at the oldIndex only if it is not zero already
            if(lstOldSecObjs.size() > 0) {
                neOld = lstOldSecObjs.get(indexOld);
            }

            BSSecurableObject neNew = null;
            // Then we shall get the NE at the newIndex only if it is not zero already
            if(lstNewSecObjs.size() > 0) {
                neNew = lstNewSecObjs.get(indexNew);
            }

            // Compare the 2 Securable Object(s) and use the value to figure out what to do.
            // Beginning we shall assume the Securable Object(s) to be equal.
            int value = 0;

            if(neOld == null) {
                // If the Old NE is null, we say that the new NE is greater.
                // This is done by making the value to 1 (Or any value greater then 1)
                value = 1;
            } else {
                // Here it means that the neOld is not null. Therefore it means
                // that we can use the neOld for the comparison purpose.
                value = neOld.compareTo(neNew);
            }

			if (value < 0) {
				// This is the case when the neOld is less then the neNew. This means that a NE has been deleted.
				if (null != neOld) {
					lstRemovedSecObjs.add(neOld);
				}
				indexOld++;
            } else if(value == 0) {
                // This is the case when the neOld is equal to the neNew
                if(null != neNew) {
                    lstModifedSecObjs.add(neNew);
                }
				indexOld++;
				indexNew++;
			} else {
				// This is the case when the neOld is greater then the neNew. This means a New NE has been created.
				if (null != neNew) {
					lstNewlyCreatedSecObjs.add(neNew);
				}
				indexNew++;
			}

			if (indexOld == lstOldSecObjs.size()) {
				// Means there are no more Securable Object(s) in the old. Hence add all the Securable Object(s)
				// that are there in newSet are newly created
				int nSize = lstNewSecObjs.size();
				while (indexNew < nSize) {
					BSSecurableObject obj = lstNewSecObjs.get(indexNew);
					if (null != obj) {
						lstNewlyCreatedSecObjs.add(obj);
					}
					indexNew++;
				}
				bContinue = false;
			}

			if (indexNew == lstNewSecObjs.size()) {
				// This means that there are no more Securable Object(s) in the New. Meaning that
				// the remaining Securable Object(s) in the old are to be deleted.
				int nSize = lstOldSecObjs.size();
				while (indexOld < nSize) {
					BSSecurableObject obj = lstOldSecObjs.get(indexOld);
					if (null != obj) {
						lstRemovedSecObjs.add(obj);
					}
					indexOld++;
				}
				bContinue = false;
			}

		}
	}

	/**
	 * Function to retrieve the Newly Created Securable Object(s)
	 * @return java.util.List The List of Newly created Securable Object(s) which have to be added
	 * within CF USM.
	 */
	public List<BSSecurableObject> getNewlyCreatedSecurableObjs() {
		return lstNewlyCreatedSecObjs;
	}

	/**
	 * Function to retrieve the Deleted Securable Object(s)
	 * @return java.util.List The List of Deleted Securable Object(s) which have to be removed
	 * from CF USM
	 */
	public List<BSSecurableObject> getDeletedSecurableObjs() {
		return lstRemovedSecObjs;
	}

	/**
	 * Function to retrieve the Modified Securable Object(s)
	 * @return java.util.List The List of Securable Object(s) that have been changed. (Only
	 * display name)
	 */
	public List<BSSecurableObject> getModifiedSecurableObjs() {
		return lstModifedSecObjs;
	}

}
