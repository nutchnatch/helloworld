/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AAServerSessionTimer
 * Author      	Jogender Singh
 * Substitute	Babu B
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.USER.VIEW
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 31-Jan-2005  Babu B          CF001093    Computer name column - not empty when nobody is logged with that UserId 
 * 11-Feb-2005	Asif			CF000845 - System Event Log Entries  
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 * 22-Mar-2005	Muyeen Munaver	CF0001791 - Problems with Login
 * 05-Apr-2005  Babu B          CF001897    GCT cleanup doesnot happen in case of client crash
 * 01-Sep-2005  Muyeen Munaver  CF002611 - 9320_MR_0217:EMS Client logged out despite inactivity setting of "0".
 * 05-Sep-2006  Shrinidhi G V   CF004305 - Client not responding => java message in Sys log
 * 08-Sep-2005  Muyeen Munaver  CF002611 - 9320_MR_0217:EMS Client logged out despite inactivity setting of "0".
 * 27-June-2007	Shrinidhi G V 	CF004252 -13 - NE activated/resync => Source in Sys Log is not NE ID name (ex. EM/NE)
 * 27-June-2007	Shrinidhi G V 	CF004252 -20 - NE activated/resync => Source in Sys Log is not NE ID name (ex. EM/NE)
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.auth.monitor;

import org.apache.log4j.Logger;

import java.util.Timer;

/**
 * Simple demo that uses java.util.Timer to schedule a task to execute
 * once configured period have passed.
 */

public final class AAServerSessionTimer {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(AAServerSessionTimer.class);

	/**
	 * Data Member for self reference of the object
	 */
	private static AAServerSessionTimer instance = new AAServerSessionTimer();

	/**
	 * Creats the single instance of the class and return for every calls
	 * @return AAServerSessionTimer - Self instance of the class
	 */
	public static AAServerSessionTimer getInstance() {
		return instance;
	}
	/**
	 * Defualt constructor for singleton class
	 *
	 */
	private AAServerSessionTimer() {
	}

	public void initializeTimer() {
		LOGGER.debug("initializeTimer() - entry");

		Timer timer = new Timer();
		timer.schedule(new ClientActivityMonitorTask(), ClientActivityMonitorTask.S_PERIOD, ClientActivityMonitorTask.S_PERIOD);
		timer.schedule(new WebSessionMonitorTask(), 	WebSessionMonitorTask.S_PERIOD, 	WebSessionMonitorTask.S_PERIOD);

		LOGGER.debug("initializeTimer() - exit");
	}
}
