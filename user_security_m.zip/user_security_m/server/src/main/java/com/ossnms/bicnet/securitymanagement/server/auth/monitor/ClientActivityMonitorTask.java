package com.ossnms.bicnet.securitymanagement.server.auth.monitor;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.server.auth.AASessionStore;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityAuthenticationPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.logging.LMInterFace;
import com.ossnms.bicnet.securitymanagement.server.servicelocator.USMServiceLocator;
import com.ossnms.bicnet.util.UnexpectedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.TimerTask;

import static com.ossnms.bicnet.securitymanagement.api.server.auth.SessionType.CLIENT;

/**
 *
 */
final class ClientActivityMonitorTask extends TimerTask {
    /**
     * Logger for this class
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ClientActivityMonitorTask.class);

    /**
     * Holds the interval period for the timer (in seconds)
     */
    private static final int S_INTERVAL = 5*60;
    static final int S_PERIOD = S_INTERVAL * 1000;

    @Override
    public void run() {
        LOGGER.debug("Entering run");
        AASessionStore sessionStore = AASessionStore.getInstance();
        List<ISessionContext> userList = sessionStore.getClientSessions();

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("List of Authenticated users : " + userList);
        }

        for (ISessionContext userContext : userList) {
            if (!(userContext instanceof IEnhancedSessionContext)) {
                LOGGER.debug("Skipping for ctx " + userContext + " since its not instance of IEnhancedSessionContext.");
                continue;
            }

            IEnhancedSessionContext objSessionContext = (IEnhancedSessionContext) userContext;
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Processing : " + toSessionDescriptor(objSessionContext));
            }

            //Checking the client status. if client is not active for the configured
            //period then it will be logged off from the server.
            AAServerSessionMonitor objBean = sessionStore.getMonitoringBean(objSessionContext, CLIENT);
            if (objBean == null) {
                // objBean is null for System account
                continue;
            }

            long currentTime = System.currentTimeMillis();
            int elapsedTime = (int) (currentTime - objBean.getLastRequestTime());

            if (elapsedTime > S_PERIOD) {
                // removing user session
                LOGGER.debug("Removing user session {}", objSessionContext.getUserName());
                logoffUser(objSessionContext);
            }
        }
    }

    /**
     *
     * @param objSessionContext the session context to describe
     * @return the resulting string, describing the session context
     */
    private String toSessionDescriptor(IEnhancedSessionContext objSessionContext) {
        return objSessionContext.toString() +
                            "Server : " +
                            objSessionContext.getServerName() +
                            "Client : " +
                            objSessionContext.getClientMachineName() +
                            "VECTOR : " +
                            objSessionContext.getUserGroup();
    }

    /**
     *
     * @param usrCtx the session, identifying the user which we should logoff
     */
    private void logoffUser(IEnhancedSessionContext usrCtx) {
        LOGGER.debug("Entering logoffUser.");

        // creating security system event record
        String format = USMCommonStrings.IDS_AA_CLIENT_UNAVAILABLE + "%s" + USMCommonStrings.IDS_AA_CLIENT_MACHINE  + "%s" + USMCommonStrings.IDS_AA_CLIENT_NOTRESPONDING;

        LMInterFace.getInstance().createSecuritySystemEventRecord(
                usrCtx,
                String.format(format, usrCtx.getUserName(), usrCtx.getClientMachineName()),
                LogSeverity.WARNING,usrCtx.getClientMachineName());

        USMServiceLocator servLoc = USMServiceLocator.getInstance();
        try {
            ISecurityAuthenticationPrivateFacade fcd = servLoc.getSecurityAuthenticationPrivateFacade();
            if (fcd != null) {
                fcd.logoff(usrCtx);
            } else {
                LOGGER.error("The Private interface returned is null.");
            }
        } catch (UnexpectedException | BcbSecurityException e) {
            LOGGER.error("An exception was thrown", e);
        }

        LOGGER.debug("Exiting logoffUser.");
    }
}
