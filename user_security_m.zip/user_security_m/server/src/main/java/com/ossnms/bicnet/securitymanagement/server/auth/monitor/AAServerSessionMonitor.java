/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AAUserMonitoringSLSBFacadeBean
 * Author      	Muyeen Munaver
 * Substitute	Asifullakhan
 * Created on	22-07-2004
 *
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.USER.VIEW
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 * 30-Mar-2005	Babu B          CF001770 - "Last Login" from "Advisory Message" window shows my current login time
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.auth.monitor;

import org.apache.log4j.Logger;

import java.util.Date;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Bean class for implementing the User Monitoring related private facade.
 * 
 **/

public class AAServerSessionMonitor {

	/**
	 * Data member to hold the last ping request time
	 */
	private AtomicLong lastRequestTime = new AtomicLong(System.currentTimeMillis());

	/**
	 * Data member to hold the first login time
	 */
	private Long firstLoginTime = new Date().getTime();

	/**
	 * Data member to hold the last login time
	 */
	private String strLastLoginTime;
	
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(AAServerSessionMonitor.class);

    public long getLastRequestTime() {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("getLastRequestTime called. Returning : " + lastRequestTime);
		}
		return lastRequestTime.get();
	}

	/**
	 *
	 */
    public void setActive() {
		LOGGER.debug("setActive() called");
		lastRequestTime.set(System.currentTimeMillis());
	}

	/**
	 *
	 */
	public Long getFirstLoginTime() {
		return firstLoginTime;
	}

	/**
	 * Returns the last login time
	 * 
	 */
    public String getLastLoginTime() {
		return strLastLoginTime;
	}

	/**
	 * Updates the last login time
	 * 
	 */
    public void setLastLoginTime(String string) {
		strLastLoginTime = string;
	}
}