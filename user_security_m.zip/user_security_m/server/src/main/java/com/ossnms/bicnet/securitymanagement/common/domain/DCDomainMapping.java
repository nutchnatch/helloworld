/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCDomainMapping
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.MAPPING.CREATE   
 * 	    :   TNMS.DX2.SM.MAPPING.VIEW
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 05-May-2005  Babu B          CF001312   Master-Master Replication for Sun ONE DS
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.common.domain;

import com.ossnms.bicnet.securitymanagement.api.common.USMConstants;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;

import java.io.Serializable;
import java.util.List;

/**
 * This class holds the domain Mappings. Domains are assigned to user groups
 * and a set of permissions are given to that particular user group for a
 * particular domain.
 */
public class DCDomainMapping implements Serializable {

	private static final long serialVersionUID = -7585678011469950669L;

    //Global Domain Mapping
	public static final DCDomainMapping GLOBAL_MAPPING = new DCDomainMapping(
            0,
            DCMessages.getInstance().getString(DCMessages.DC_GLOBAL_GROUPS),
            USMConstants.POLICY_GLOBAL.getPolicyID()
    );

    private int id;

    private String name;

    /**
     * Domain id for which this mapping is part of.
     */
    private int domainId;

    /**
     * Fully qualified user group of this mapping data
     */
    private String userGroup;

    /**
     * The id of the user group taking part in this mapping.
     */
    private int userGroupId;

    /**
     * Domain id for which this mapping is part of.
     */
    private int policyId;

    /**
     * This is the error string, when a mapping could not be created 
     */
    private Integer error = DCMessages.DC_NO_ERROR;

    /**
     * Constructor
     * 
     * @param pDomainID
     *            The domain id of the mapping
     * @param pStrUserGroup
     *            The user group of the mapping
     * @param pPolicyID
     *            The policy id of the mapping
     */
    public DCDomainMapping(
        int pDomainID,
        String pStrUserGroup,
        int pPolicyID) {

        domainId = pDomainID;
        userGroup = pStrUserGroup;
        policyId = pPolicyID;

    }

    /**
     * Default constructor
     */
    public DCDomainMapping() {

    }

    /**
     * Function to push onto a domain mapping to a message. Used by the sender.
     * After successful execution of this function. The message would contain
     * information about the mapping
     * 
     * @param pMsg
     *            The USMMessage to which the mapping has to be pushed
     */
    public void pushMe(USMMessage pMsg) {

        //push dom id, ug, policyid, domUID in that order
        pMsg.pushInteger(domainId);
        pMsg.pushString(userGroup);
        pMsg.pushInteger(policyId);
        pMsg.pushInteger(error);

    }

    /**
     * Function to pop the mappings from a message. Used by the receiver
     * 
     * @param pMsg
     *            The USMMessage from which the mappings need to be popped
     */
    public void popMe(USMMessage pMsg) {
        error = pMsg.popInteger();
        policyId = pMsg.popInteger().intValue();
        userGroup = pMsg.popString();
        domainId = pMsg.popInteger().intValue();
    }

    /**
     * Function to get the domain id associated with this mapping
     * 
     * @return int Returns the domain id of the mapping
     */
    public int getDomainID() {
        return domainId;
    }

    public void setDomainID(int domainId) {
        this.domainId = domainId;
    }

    /**
     * Function to get the policy id associated with this mapping
     * 
     * @return int Returns the policy id of the mapping
     */
    public int getPolicyID() {
        return policyId;
    }

    /**
     * Function to set the policy id associated with this mapping
     * @param pPolicyId - Policy id to be set to
     */
    public void setPolicyID(int pPolicyId) {
        policyId = pPolicyId;
    }

    /**
     * Helper function to push the list of mappings onto a message
     * 
     * @param pMappings
     *            List of mappings which need to be pushed
     * @param p_msg
     *            The USMMessage onto which the mappings need to be pushed
     */
    public static void pushMappingsToMessage(
        List pMappings,
        USMMessage p_msg) {

        //Pushes the vector of p_mappings into the USM Message
        for (int i = 0; i < pMappings.size(); ++i) {
            DCDomainMapping dom = (DCDomainMapping) pMappings.get(i);
            dom.pushMe(p_msg);
        }
        p_msg.pushInteger(pMappings.size());

    }

    /**
     * Helper function to pop the list of mappings from a message. The list
     * is cleared and then returned
     * @param pMsg
     *            The USMMessage from which the mappings need to be popped from
     * @param pMappings
     *            List of mappings that would be populated from the Message
     */
    public static void popMappingsFromMessage(
        USMMessage pMsg,
        List<DCDomainMapping> pMappings) {

        pMappings.clear();
        int nSize = pMsg.popInteger().intValue();
        for (int i = 0; i < nSize; ++i) {
            DCDomainMapping dom = new DCDomainMapping();
            dom.popMe(pMsg);
            pMappings.add(dom);
        }

    }

    /**
     * Function to get the user group associated with the mapping
     * 
     * @return String Returns the user group of the mapping
     */
    public String getUserGroup() {
        return userGroup;
    }

    /**
     * Function to set the User Group
     *
     * @param userGroup
     */
    public void setUserGroup(String userGroup) {
        this.userGroup = userGroup;
    }

    /**
     * Function to get the user group id associated with the mapping
     *
     * @return integer with user group id
     */
    public int getUserGroupId() {
        return userGroupId;
    }


    /**
     * Function to set the User Group ID
     *
     * @param userGroupId
     */
    public void setUserGroupId(int userGroupId) {
        this.userGroupId = userGroupId;
    }

    /**
     *
     * @return
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Checks whether the current mapping is a global mapping or not.
     * 
     * @return boolean Returns true to indicate that it is a global mapping
     */
    public boolean isGlobalMapping() {
        return this.equals(GLOBAL_MAPPING);
    }

    /**
     * Overridden method equals to compare 2 mapping objects. 2 mapping objects
     * are equal when the domain id and the user group are the same
     * 
     * @param pMapping -
     *            The mapping object against which the current object has to be
     *            compared with
     * @return boolean - Returns true if the object are equal
     */
	@Override
    public boolean equals(Object pMapping) {
		boolean bRet = false;
		DCDomainMapping mapping;
		if (pMapping instanceof DCDomainMapping) {
			mapping = (DCDomainMapping) pMapping;
			if (domainId == mapping.getDomainID() && (0 == mapping.getUserGroup().compareToIgnoreCase(userGroup))) {
				bRet = true;
			}
		}
		return bRet;
	}

    /**
     * Overridden hashCode method. This is needed when the equals method is
     * overridden This should return a uniq id
     * 
     * @return int Returns the hashCode of this object, which is uniq
     */
    @Override
    public int hashCode() {
        return (domainId + "-" + userGroup.toLowerCase()).hashCode();
    }

    /**
     * Overridden toString method for display purpose and debug info
     * 
     * @return String Returns a user group + domain id + policy id of the
     *         mapping object
     */
    @Override
    public String toString() {
        return "u-" + userGroup + "-d-" + domainId + "-p- " + policyId;
    }

    /**
     * Gets the error id associated with this mapping
     */
    public Integer getErrorId() {
        return error;
    }

    /**
     * Gets the error id associated with this mapping
     */
    public void setErrorId(Integer pError) {
        error = pError;
    }

}
