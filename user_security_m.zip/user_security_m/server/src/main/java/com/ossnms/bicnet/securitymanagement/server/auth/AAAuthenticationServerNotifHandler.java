/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AAAuthenticationServerNotifHandler
 * Author      	Babu B
 * Substitute	Jogender Singh
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.SERVER.AUTHORIZATION
 * 		  TNMS.DX2.SM.CLIENT.AUTHORIZE
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.auth;

import com.ossnms.bicnet.securitymanagement.api.server.basic.notification.INotificationHandler;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import org.apache.log4j.Logger;

/**
 * This class is the Handler for the messages that are sent as a notification
 * within USM from the server to the client.
 * 
 * Since in the first step all the components of USM are within one machine, the
 * Authentication and Authorization part need not listen to notifications from the
 * topic for rebuilding of the cache. To prevent lag while listening, this class
 * registers with the USMNotifier for the notifications to be sent as synchronous
 * calls.
 * Listens to Policy / Mapping - Create/ Delete / Modify Notifications (synchronous) 
 * Used by AAServerCache
 
*/

class AAAuthenticationServerNotifHandler implements INotificationHandler {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(AAAuthenticationServerNotifHandler.class);

	/**
	  * Data member for the sole instance of the class.
	  */
	private static AAAuthenticationServerNotifHandler self = null;

	/**
	 * Static method to get the class instance
	 * @return AAAuthenticationServerNotifHandler - static reference for the same class
	 */
	public static final synchronized AAAuthenticationServerNotifHandler getInstance() {
		if (null == self) {
			self = new AAAuthenticationServerNotifHandler();
		}
		return self;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.api.server.basic.notification.INotificationHandler#handleNotification(com.ossnms.bicnet.securitymanagement.common.basic.USMMessage)
	 */
	public void handleNotification(USMMessage msg) {
		//If USMMessage contains notification for security data changes, security data cache is rebuilt in USMServerCache object on server side. 
		//And notification is sent to client side for rebuilding cache on client side 

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handleNotification(" + msg + ") Entry");
		}

		USMBaseMsgType objMessageType = msg.getMessageType();
		String strMessageType = objMessageType.getMsgType();
		LOGGER.debug("Message type is " + strMessageType);

		AAServerCache.getInstance().handleNotification(msg);

		LOGGER.debug("handleNotification Exit");
	}

}
