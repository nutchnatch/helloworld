/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   GSMessageType
 * Author:      Jogender
 * Substitute	Babu B
 * Created on	13-10-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.ADVISORY_CONFIGURE
 *        : TNMS.DX2.SM.PASSWORD.COMPLEXITY
 * 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.general;

import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;

/**
 * This class stores all the primitives used by GS internally across the client
 * and the server for its messages
 */
public final class GSMessageType {

	/**
	 * Message primitives for general setting data retrieval
	 */
	public static final USMBaseMsgType GS_GENERAL_SETTING_DATA_REQUEST =
		new USMBaseMsgType("GS_GENERAL_SETTING_DATA_REQUEST");

	/**
	 * Message primitives for general setting data retrieval
	 */
	public static final USMBaseMsgType GS_GENERAL_SETTING_DATA_RESPONSE =
		new USMBaseMsgType("GS_GENERAL_SETTING_DATA_RESPONSE");

	/**
	 *  Message primitives for general setting data update request
	 */
	public static final USMBaseMsgType GS_GENERAL_SETTING_DATA_UPDATE_REQUEST =
		new USMBaseMsgType("GS_GENERAL_SETTING_DATA_UPDATE_REQUEST");

	/**
	 * Message primitives for general setting data update response
	 */
	public static final USMBaseMsgType GS_GENERAL_SETTING_DATA_UPDATE_RESPONSE =
		new USMBaseMsgType("GS_GENERAL_SETTING_DATA__UPDATE_RESPONSE");

	/**
	 * Message primitives for general setting data update response
	 */
	public static final USMBaseMsgType GS_NOT_GENERAL_SETTING_DATA_UPDATE =
		new USMBaseMsgType("GS_NOT_GENERAL_SETTING_DATA_UPDATE");

	/**
	 * Creates a new instance of GSMessageType
	 */
	private GSMessageType() {
	}
}