package com.ossnms.bicnet.securitymanagement.api.exception;

/**
 * Exception which indicates that the user is trying to set the password to one which was previously used
 * and is still stored in LDAP's password history.
 * 
 */
public class PasswordHistoryViolationException extends Exception {

    private static final long serialVersionUID = 1L;

    public PasswordHistoryViolationException() {
        super();
    }

    public PasswordHistoryViolationException(Throwable cause) {
        super(cause);
    }
}
