/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	IEMessageType
 * Author      	Jogender Singh
 * Substitute	Babu B
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 * Project: TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : 	TNMS.DX2.SM.MIGRATION
 * 			TNMS.DX2.SM.EXPORT
 * 			TNMS.DX2.SM.IMPORT
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.importexport;

import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;

/**
 * @author ccc1102
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class IEMessageType {

	/**
	 * Message primitives
	 */
	public static final USMBaseMsgType IE_REQ_EXPORT =
		new USMBaseMsgType("IE_Req_Export");
	public static final USMBaseMsgType IE_RES_EXPORT =
		new USMBaseMsgType("IE_Res_Export");

	public static final USMBaseMsgType IE_REQ_IMPORT =
		new USMBaseMsgType("IE_Req_Import");
	public static final USMBaseMsgType IE_RES_IMPORT =
		new USMBaseMsgType("IE_Res_Import");

}
