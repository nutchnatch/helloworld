/*
 * Project      BiCNET Common Functions
 *
 * Component    CF:USM
 * Class Name   IBicNetServiceImpl
 * Author       Muyeen Munaver
 * Substitute   Asifullakhan
 * Created on   02-09-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 02-Feb-2005  Babu B          CF000199-11 Unification of GUI-Labels for Enums
 * 06-Apr-2005  Babu B          CF000006 - Implement the getVersionInfoItems() for the client plugin
 * 21-Apr-2005  Muyeen Munaver	CF001879 - Component version information for Server side components
 * 01-Jun-2006  Shrinidhi G V   Version Information Naming Type Changed : 2.02.001 APM E FM V2.2 1st build
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server;

import com.ossnms.bicnet.bcb.facade.common.IBicNetService;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.ComponentVersionInformation;
import com.ossnms.bicnet.bcb.model.common.File;
import com.ossnms.bicnet.bcb.model.common.Log4jLevel;
import com.ossnms.bicnet.util.versions.ServerComponentVersionInfo;

/**
 * Represents a singleton.
 *
 * This class provides an implementation for the IBicNetService.
 * Even though it is an implementation, it has been decided not to
 * implement the interface. Reason for the decision -
 * 1. Authorization checks can be performed in the USMSecurityProviderPOJOImpl. Therefore no
 * nned of ISessionContext and throwing of exception.
 *
 */
public final class IBicNetServiceImpl implements IBicNetService {

	/**
	 * Date member for the Component Type
	 */
	private static final BiCNetComponentType COMPONENT_TYPE = BiCNetComponentType.SECURITY_MANAGER;

	/**
	 * Data member to hold the Level of Logging
	 */
	private static final Log4jLevel DEFAULT_LEVEL = Log4jLevel.WARN;;

	/**
	 * Data member to hold the Description
	 */
	private static final String DESCRIPTION =
		"Common Function User and Security Management.";

	/**
	* Holds singleton instance
	*/
	private static IBicNetServiceImpl instance = new IBicNetServiceImpl();

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.common.IBicNetService#getName(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
	@Override
    public String getName(ISessionContext ctx) {
		return COMPONENT_TYPE.guiLabel(); // m_CompType.toString();
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.common.IBicNetService#getDescription(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
	@Override
    public String getDescription(ISessionContext ctx) {
		return DESCRIPTION;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.common.IBicNetService#getComponentType(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
	@Override
    public BiCNetComponentType getComponentType(ISessionContext ctx) {
		return COMPONENT_TYPE;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.common.IBicNetService#getLog4JDefaultLevel(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
	@Override
    public Log4jLevel getLog4JDefaultLevel(ISessionContext ctx) {
		return DEFAULT_LEVEL;
	}

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.bcb.facade.common.IBicNetService#getVersion(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public ComponentVersionInformation getVersion(ISessionContext ctx) {
//        Package pack = getClass().getPackage();
//        String dotQuote = Pattern.quote(".");
//        String[] bcbVersion = null;
//
//        if (pack.getSpecificationVersion() != null) {
//            bcbVersion = pack.getSpecificationVersion().split(dotQuote);
//        }

//        String majorVersion = USMCommonStrings.EMPTY;
//        String minorVersion = USMCommonStrings.EMPTY;
//
//        if (bcbVersion != null) {
//            if (bcbVersion.length > 1) {
//                majorVersion = bcbVersion[0];
//                minorVersion = bcbVersion[1];
//            } else if (bcbVersion.length == 1) {
//                majorVersion = bcbVersion[0];
//            }
//        }

        return ServerComponentVersionInfo.getVersionInfo(getClass());
    }

	/**
	* prevents instantiation
	*/
	private IBicNetServiceImpl() {
	}

	/**
	 * Returns the singleton instance.
	 * @return  the singleton instance
	 */
	public static IBicNetServiceImpl getInstance() {
		return instance;
	}

	@Override
    public boolean isTraceDataCollectionSupported(ISessionContext arg0) throws BcbException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
    public void collectTraceData(ISessionContext arg0, File arg1) throws BcbException {
		// TODO Auto-generated method stub
		
	}

}
