/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 10-Feb-2005	Asif 			CF000834 - Command Log Entries
 * 11-Mar-2005	Asif			CF000845 - System Event Log Entries
 * 18-Mar-2005  Asif khan R     CF001755 Error Messages when LDAP not available
 * 22-Mar-2005	Muyeen Munaver	CF0001791 - Problems with Login
 * 26-Apr-2005	Asif			CF000834 - Command Log Entries	CF USM
 * 05-May-2005  Babu B          CF001312   Master-Master Replication for Sun ONE DS
 * 27-June-2007	Shrinidhi G V 	CF004252 -13 - NE activated/resync => Source in Sys Log is not NE ID name (ex. EM/NE)
 * 27-June-2007	Shrinidhi G V 	CF004252 -20 - NE activated/resync => Source in Sys Log is not NE ID name (ex. EM/NE)
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.general;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.api.server.general.IGSWrapper;
import com.ossnms.bicnet.securitymanagement.common.auth.PasswordValidationRulesConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMenuNameList;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.bicnet.securitymanagement.common.general.GSMessageType;
import com.ossnms.bicnet.securitymanagement.common.general.ResponseMessage;
import com.ossnms.bicnet.securitymanagement.common.general.ldap.LDAPConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.ldap.LDAPSettingsResponseMessage;
import com.ossnms.bicnet.securitymanagement.common.general.radius.configuration.RadiusConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.radius.configuration.RadiusSettingsResponseMessage;
import com.ossnms.bicnet.securitymanagement.common.general.radius.status.RadiusServerStatus;
import com.ossnms.bicnet.securitymanagement.common.general.radius.status.RadiusTestConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.sso.SSOConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.sso.SSOSettingsResponseMessage;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAStatus;
import com.ossnms.bicnet.securitymanagement.common.utils.InternalUSMBeanLocator;
import com.ossnms.bicnet.securitymanagement.server.basic.USMAuthorizationHelper;
import com.ossnms.bicnet.securitymanagement.server.basic.notification.USMNotifier;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityGeneralSettingPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.ldap.LDAPAuthenticationManager;
import com.ossnms.bicnet.securitymanagement.server.logging.LMCommandClassificationEnum;
import com.ossnms.bicnet.securitymanagement.server.logging.LMInterFace;
import com.ossnms.bicnet.securitymanagement.server.logging.LMLogRecordData;
import com.ossnms.bicnet.securitymanagement.server.logging.LMLogRecordEnum;
import com.ossnms.bicnet.securitymanagement.server.radius.RadiusAuthenticationManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.NestedRuntimeException;
import org.springframework.ldap.InvalidAttributeIdentifierException;
import org.springframework.ldap.InvalidNameException;
import org.springframework.ldap.InvalidSearchFilterException;
import org.springframework.ldap.NameNotFoundException;
import org.springframework.ldap.NamingException;
import org.springframework.ldap.PartialResultException;
import org.springframework.ldap.UncategorizedLdapException;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper.createFormattedString;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.IDS_GS_RADIUS_SERVER_TEST;
import static com.ossnms.bicnet.securitymanagement.common.general.ResponseType.ERROR_MESSAGE;
import static com.ossnms.bicnet.securitymanagement.common.general.ResponseType.INFORMATION_MESSAGE;
import static com.ossnms.bicnet.securitymanagement.common.general.ResponseType.WARNING_MESSAGE;

/**
 * Implementation class for the General Settings Private Facade
 */
public class GSGeneralSettingPOJOImpl implements ISecurityGeneralSettingPrivateFacade {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(GSGeneralSettingPOJOImpl.class);

    // maintains a list of error strings for each exception type
    private static final Map<Class<? extends Exception>, String> ldapValidationErrors;
    private static final String ACTIVE = "active";
    private static final String INACTIVE = "inactive";

    static {
        ldapValidationErrors = new HashMap<>(4);
        ldapValidationErrors.put(UncategorizedLdapException.class, USMCommonStrings.IDS_AA_DIALOG_MESSAGE_LDAP_CONFIG_ERROR_DETAILS);
        ldapValidationErrors.put(InvalidNameException.class, USMCommonStrings.IDS_AA_DIALOG_MESSAGE_LDAP_CONFIG_ERROR_DETAILS);
        ldapValidationErrors.put(PartialResultException.class, USMCommonStrings.IDS_AA_DIALOG_MESSAGE_LDAP_CONFIG_TOOMANY_DETAILS);
        ldapValidationErrors.put(InvalidSearchFilterException.class, USMCommonStrings.IDS_AA_DIALOG_MESSAGE_LDAP_CONFIG_FILTER_ERROR);
    }

    /**
     *
     */
    private final IGSWrapper gsWrapper = InternalUSMBeanLocator.getEJB(IGSWrapper.class);

    /**
     * Default constructor
     * 
     */
    GSGeneralSettingPOJOImpl() {
    }

    /**
     * Loads the General Settings Data from the database and logs the action to the Command Log
     */
    @Override
    public GSGeneralSettingData getGeneralSettingData(ISessionContext sessionContext) throws BcbSecurityException {
        LOGGER.debug("getGeneralSettingData() Entry");

        assert gsWrapper != null;
        GSGeneralSettingData objData = gsWrapper.getGeneralSettingData();

        LOGGER.debug("getGeneralSettingData() Exit");

        return objData;
    }

    /**
     * 
     */
    @Override
    public ResponseMessage setGeneralSettingData(ISessionContext sessionContext, GSGeneralSettingData generalSettingData) throws BcbException {
        LOGGER.debug("setGeneralSettingData() Entry");

        GSGeneralSettingData oldGeneralSettingsData = getGeneralSettingData(sessionContext);
        USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(sessionContext, USMMenuNameList.OPERATION_SECURITY_SETTINGS);

        boolean bStatus;

        // Calling LDAP wrapper for updating the general setting data
        // GSLdapInterface objLdapWrapper = new GSLdapInterface();
        assert gsWrapper != null;
        bStatus = gsWrapper.setGeneralSetting(generalSettingData);

        LOGGER.info("General Setting data update status :" + bStatus);

        // Sending notification for client who has kept open general setting
        // window.
        if(bStatus) {
            this.createCommandRecord(sessionContext, oldGeneralSettingsData, generalSettingData);

            USMNotifier notificationSender = USMNotifier.getInstance();
            USMMessage notifMsg = new USMMessage(GSMessageType.GS_NOT_GENERAL_SETTING_DATA_UPDATE, USMMessage.USMMESSAGE_NOTIFICATION);
            notifMsg.pushObject(generalSettingData);
            notificationSender.sendNotification(notifMsg);

            // Create security log for the event.
            String displayStr = createFormattedString(
                    USMCommonStrings.IDS_GS_SETTINGS_MODIFIED,
                    sessionContext.getUserName(),
                    ((IEnhancedSessionContext) sessionContext).getClientMachineName()
            );
            LMLogRecordData usmLogRecord = new LMLogRecordData(LMLogRecordEnum.GENERAL_SETTING, "", LMLogRecordData._SUCCESS, null, LogSeverity.MESSAGE.guiLabel(), null, displayStr);
            LMInterFace.getInstance().createSecurityLogRecord(sessionContext, usmLogRecord);

            /**
             * Your Single Sign-On settings have been saved. Please contact your Administrator to apply.
             */
			ResponseMessage message = new ResponseMessage(
                    INFORMATION_MESSAGE,
                    USMCommonStrings.IDS_AA_DIALOG_MESSAGE_CONFIG_SAVED
            );

            // if sso is enabled and the settings are different
            SSOConfigurationData oldData = oldGeneralSettingsData.getSSOConfigurationData();
            SSOConfigurationData data = generalSettingData.getSSOConfigurationData();
            validate(sessionContext, message, oldData, data);

            // if ldap is enabled and the settings are different
            LDAPConfigurationData ldap = generalSettingData.getLdapConfigurationData();
            LDAPConfigurationData oldLdap = oldGeneralSettingsData.getLdapConfigurationData();
            validate(sessionContext, message, oldLdap, ldap);

            // if password validation rules are different
            PasswordValidationRulesConfigurationData oldPasswordRulesData = oldGeneralSettingsData.getPasswordValidationRulesConfigurationData();
            PasswordValidationRulesConfigurationData passwordRulesData = generalSettingData.getPasswordValidationRulesConfigurationData();
            validate(sessionContext, oldPasswordRulesData, passwordRulesData);

            // if radius is enabled and the settings are different
            RadiusConfigurationData radius = generalSettingData.getRadiusConfigurationData();
            RadiusConfigurationData oldRadius = oldGeneralSettingsData.getRadiusConfigurationData();
            validate(sessionContext, message, oldRadius, radius);

            return message;
        }
        LOGGER.debug("setGeneralSettingData() Exit");

        return new ResponseMessage(ERROR_MESSAGE, USMCommonStrings.IDS_AA_DIALOG_MESSAGE_ERROR_SSO_CONFIG);
    }

    @Override
    public RadiusServerStatus testRadiusServer(ISessionContext sessionContext, RadiusTestConfigurationData configurationData) throws BcbSecurityException {
        USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(sessionContext, USMMenuNameList.OPERATION_SECURITY_SETTINGS);

        RadiusServerStatus status =  new RadiusAuthenticationManager()
                .setServerHostname(configurationData.getServerHostname())
                .setServerSharedSecret(configurationData.getServerSharedSecret())
                .setServerPort(configurationData.getServerPort())
                .isServerAvailable();

        String changesStr = createFormattedString(IDS_GS_RADIUS_SERVER_TEST, configurationData.getServerHostname(), status);
        LMLogRecordData record = new LMLogRecordData(
                LMLogRecordEnum.GENERAL_SETTING,
                "RADIUS Authentication - Test Connection",
                LMLogRecordData._SUCCESS,
                null,
                LogSeverity.MESSAGE.guiLabel(),
                null,
                changesStr);

        LMInterFace.getInstance().createSecurityLogRecord(sessionContext, record);
        LOGGER.info("{}:{}", sessionContext, record);

        return status;
    }

    @Override
    public SSOConfigurationData getSingleSignOnData() throws BcbSecurityException {
        LOGGER.debug("getSingleSignOnData() Entry");

        assert gsWrapper != null;
        SSOConfigurationData objData = gsWrapper.getSingleSignOnConfiguration();

        LOGGER.debug("getSingleSignOnData() Exit");
        return objData;
    }

    @Override
    public LDAPConfigurationData getLdapConfigurationData() throws BcbSecurityException {
        LOGGER.debug("getLdapConfigurationData() Entry");

        assert gsWrapper != null;
        LDAPConfigurationData objData = gsWrapper.getLdapConfigurationData();

        LOGGER.debug("getLdapConfigurationData() Exit");
        return objData;
    }

    @Override
    public RadiusConfigurationData getRadiusConfigurationData() throws BcbSecurityException {
        LOGGER.debug("getRadiusConfigurationData() Entry");

        assert gsWrapper != null;
        RadiusConfigurationData objData = gsWrapper.getRadiusConfigurationData();

        LOGGER.debug("getRadiusConfigurationData() Exit");
        return objData;
    }

    @Override
    public USMMessage getPasswordVerificationRulesConfigurationData() throws BcbSecurityException {
        LOGGER.debug("getPasswordVerificationRulesConfigurationData()     Entering");

        assert gsWrapper != null;

        USMMessage pMsg = new USMMessage(UAMessageType.S_UA_RES_GET_ALL_PASSWORD_VALIDATION_RULES, USMMessage.USMMESSAGE_RESPONSE);
        PasswordValidationRulesConfigurationData data = gsWrapper.getPasswordValidationRulesConfiguration();

        data.pushMe(pMsg);

        UAStatus operationStatus = new UAStatus(UAStatus.S_SUCCESS);
        operationStatus.pushMe(pMsg);

        LOGGER.debug("getPasswordVerificationRulesConfigurationData()     Exiting : Return :" + pMsg);
        return pMsg;
    }

    /**
     * retrieves the user count from the LDAPConfigurationData
     *
     * @param ldap the instance of the LDAPConfigurationData
     * @return the number of users found
     */
    private int getUserCount(LDAPConfigurationData ldap) {
        try{
            return new LDAPAuthenticationManager(ldap).getUserCount();
        }catch(NameNotFoundException | InvalidAttributeIdentifierException e){
            logException(e, "An error occurred when retrieving User Count.");
        }
        return 0;
    }

    /**
     *
     * @param ldap LDAPConfigurationData
     * @return the user group count
     */
    private int getUserGroupCount(LDAPConfigurationData ldap) {
        try{
            return new LDAPAuthenticationManager(ldap).getUserGroupCount();
        }catch(NameNotFoundException | InvalidAttributeIdentifierException e){
            logException(e, "An error occurred when retrieving User Group Count.");
        }
        return 0;
    }

    /**
     * Validates the LDAP Settings and sets a new LDAPSettingsResponseMessage in the response message with the
     * validation result
     *
     * @param sessionContext the session context
     * @param message the response message to set
     * @param ldap the ldap configuration data
     */
    private void validate(ISessionContext sessionContext, ResponseMessage message, LDAPConfigurationData oldLdap, LDAPConfigurationData ldap) {
        // if the parameters are not null, if ldap is still enabled and if the old settings does not equal the new ldap settings
        if(ldap != null && oldLdap != null && ldap.isEnabled() && !oldLdap.equals(ldap)) {
            ResponseMessage ldapMessage;
            try{
                // ...get user count with the current settings
                int userCount = getUserCount(ldap);
                int userGroupCount = getUserGroupCount(ldap);

                // if the user group found or the number of users found are 0, then the settings might not be correctly configured
                if(userCount == 0 || userGroupCount == 0){
                    // set response message
                    ldapMessage = new LDAPSettingsResponseMessage(WARNING_MESSAGE, USMCommonStrings.IDS_AA_DIALOG_MESSAGE_LDAP_CONFIG_WARNING);
                    // add security log entry
                    createSecurityLogRecord(
                            sessionContext,
                            USMCommonStrings.IDS_APPLICATION_LDAP_AUTHENTICATION_SETTINGS,
                            LMCommandClassificationEnum.WARNING,
                            LMLogRecordData._FAILURE,
                            USMCommonStrings.IDS_AA_DIALOG_MESSAGE_LDAP_CONFIG_WARNING_DETAILS, Integer.toString(userCount), Integer.toString(userGroupCount)
                    );
                }else{
                    ldapMessage = new LDAPSettingsResponseMessage(INFORMATION_MESSAGE, USMCommonStrings.IDS_AA_DIALOG_MESSAGE_LDAP_CONFIG_SAVED);
                    // add security log entry
                    createSecurityLogRecord(
                            sessionContext,
                            USMCommonStrings.IDS_APPLICATION_LDAP_AUTHENTICATION_SETTINGS,
                            LMCommandClassificationEnum.MESSAGE,
                            LMLogRecordData._SUCCESS,
                            USMCommonStrings.IDS_AA_DIALOG_MESSAGE_LDAP_CONFIG_SUCCESS_DETAILS, Integer.toString(userCount), Integer.toString(userGroupCount)
                    );
                }
            }catch(NamingException e){
                ldapMessage = handleLDAPValidationException(e, sessionContext);
            }
            message.addResponseMessage(ldapMessage);
            // create the command record with the changes
            createCommandRecord(sessionContext, oldLdap, ldap);
        }
    }

    /**
     * Validates the SSO configuration
     *
     * @param sessionContext the session context
     * @param message the message object to add parts to
     * @param oldSSO the old settings
     * @param sso the new settings
     */
    private void validate(ISessionContext sessionContext, ResponseMessage message, SSOConfigurationData oldSSO, SSOConfigurationData sso){
        if(sso != null && oldSSO != null && sso.isEnabled() && !oldSSO.equals(sso)){
            ResponseMessage ssoMessage = new SSOSettingsResponseMessage(INFORMATION_MESSAGE, USMCommonStrings.IDS_AA_DIALOG_MESSAGE_SSO_CONFIG_SAVED);
            // add a single sign-on message
            message.addResponseMessage(ssoMessage);
            // create the CommandRecord
            createCommandRecord(sessionContext, oldSSO, sso);
        }
    }

    /**
     * Validates the Password Validation Rules configuration
     *
     * @param sessionContext the session context
     * @param oldPasswordRulesData the old settings
     * @param passwordRulesData the new settings
     */
    private void validate(ISessionContext sessionContext, PasswordValidationRulesConfigurationData oldPasswordRulesData, PasswordValidationRulesConfigurationData passwordRulesData){
        if(passwordRulesData != null && oldPasswordRulesData != null && !oldPasswordRulesData.equals(passwordRulesData)){
            createCommandRecord(sessionContext, oldPasswordRulesData, passwordRulesData);
        }
    }

    /**
     *
     *
     * @param sessionContext
     * @param message
     * @param oldData
     * @param newData
     */
    private void validate(ISessionContext sessionContext, ResponseMessage message, RadiusConfigurationData oldData, RadiusConfigurationData newData) {
        if(newData != null && oldData != null && !oldData.equals(newData)){
            ResponseMessage radiusMessage = new RadiusSettingsResponseMessage(INFORMATION_MESSAGE, USMCommonStrings.IDS_AA_DIALOG_MESSAGE_RADIUS_CONFIG_SAVED);
            // add a single sign-on message
            message.addResponseMessage(radiusMessage);
            // create the CommandRecord
            createCommandRecord(sessionContext, oldData, newData);

            return;
        }

        if(newData == null || oldData == null){
            handleRadiusValidationException(null, sessionContext);
        }
    }

    /**
     * Handles LDAP Validation exception
     * @param e the exception to handle
     * @param sessionContext the session context
     * @return an LDAPSettingsResponseMessage with a user friendly explanation
     */
    private LDAPSettingsResponseMessage handleLDAPValidationException(Exception e, ISessionContext sessionContext){
        LOGGER.error("LDAP Exception occurred", e);
        String message = ldapValidationErrors.get(e.getClass());

        createSecurityLogRecord(
                sessionContext,
                USMCommonStrings.IDS_APPLICATION_LDAP_AUTHENTICATION_SETTINGS,
                LMCommandClassificationEnum.ERROR,
                LMLogRecordData._FAILURE,
                message == null ? "" : message
        );

        return new LDAPSettingsResponseMessage(ERROR_MESSAGE, USMCommonStrings.IDS_AA_DIALOG_MESSAGE_LDAP_CONFIG_ERROR);
    }

    private RadiusSettingsResponseMessage handleRadiusValidationException(Exception e, ISessionContext sessionContext) {
        LOGGER.error("RADIUS Exception occurred", e);
        String message = USMCommonStrings.IDS_AA_DIALOG_MESSAGE_RADIUS_CONFIG_ERROR;

        createSecurityLogRecord(
                sessionContext,
                USMCommonStrings.IDS_APPLICATION_RADIUS_AUTHENTICATION_SETTINGS,
                LMCommandClassificationEnum.ERROR,
                LMLogRecordData._FAILURE,
                message
        );

        return new RadiusSettingsResponseMessage(ERROR_MESSAGE, message);
    }

    /**
     * Creates a security Log Record
     * @param sessionContext the Session Context
     * @param activity the activity description
     * @param commandClassification the command classification
     * @param status the status code
     * @param logStrFormat the format of the log string
     * @param objects the objects for the log
     */
    private void createSecurityLogRecord(ISessionContext sessionContext, String activity, LMCommandClassificationEnum commandClassification, int status, String logStrFormat, String... objects) {
        String logStr = objects == null ? logStrFormat : createFormattedString(logStrFormat, objects);

        LMInterFace.getInstance().createSecurityLogRecord(sessionContext, new LMLogRecordData(
                LMLogRecordEnum.GENERAL_SETTING,
                activity,
                status,
                null,
                commandClassification.getLabel(),
                null,
                logStr
        ));
    }


	/**
     * This method creates a command record for the GS window
     * 
     * @param p_sessionContext The session context of the user
     * @param newGeneralSettingData The general settings data
     */
    private void createCommandRecord(ISessionContext p_sessionContext, GSGeneralSettingData oldGeneralSettingsData, GSGeneralSettingData newGeneralSettingData) {
        // Log in the reverse order, so that it is easier for the operator to
        // find in this order. At least it was easy for me :)
        // Log the advisory message display, don't log the complete message, as
        // it is a problem as it exceeds
        // the length and not much info there
        if(oldGeneralSettingsData.isShowAdvisoryMessage() != newGeneralSettingData.isShowAdvisoryMessage()){
            String firstLogStr = createFormattedString(USMCommonStrings.IDS_GS_ADVISORY_MESSAGE_TO_BE_DISPLAYED, newGeneralSettingData.isShowAdvisoryMessage());

            String logStr = createFormattedString(USMCommonStrings.IDS_LG_WINDOW_TAB_CONSOLIDATE_MSG, USMMenuNameList.OPERATION_SECURITY_SETTINGS,
                    USMCommonStrings.IDS_SETTINGS_TAB_ADVISORY, firstLogStr);
            LMInterFace.getInstance().createSecurityCommandRecord(p_sessionContext, logStr, USMCommonStrings.IDS_APPLICATION_SECURITYSETTINGS);
            LOGGER.info(p_sessionContext + ":" + logStr);
        }

        if(oldGeneralSettingsData.getAdvisoryMessage()!=null && !oldGeneralSettingsData.getAdvisoryMessage().equals(newGeneralSettingData.getAdvisoryMessage())){
            String firstLogStr = USMCommonStrings.IDS_GS_ADVISORY_MESSAGE_CHANGED;
            String logStr = createFormattedString(USMCommonStrings.IDS_LG_WINDOW_TAB_CONSOLIDATE_MSG, USMMenuNameList.OPERATION_SECURITY_SETTINGS,
                    USMCommonStrings.IDS_SETTINGS_TAB_ADVISORY, firstLogStr);
            LMInterFace.getInstance().createSecurityCommandRecord(p_sessionContext, logStr, USMCommonStrings.IDS_APPLICATION_SECURITYSETTINGS);
            LOGGER.info(p_sessionContext + ":" + logStr);
        }

        StringBuilder result = new StringBuilder("");
        // Second tab log info
        // account lockout of n attempts
        if(oldGeneralSettingsData.getDeactivationAfterLoginAttempts() != newGeneralSettingData.getDeactivationAfterLoginAttempts()) {
            result.append(createFormattedString(USMCommonStrings.IDS_GS_LOCK_ACCOUNT, newGeneralSettingData.getDeactivationAfterLoginAttempts() ));
        }

        // deactivation of account after n days
        if(oldGeneralSettingsData.getDeactivationAfterInativity() != newGeneralSettingData.getDeactivationAfterInativity()){
            if(!result.toString().isEmpty()){
                result.append(", ");
            }
            result.append(createFormattedString(USMCommonStrings.IDS_GS_DEACTIVATE_ACCOUNT, newGeneralSettingData.getDeactivationAfterInativity() ));
        }
        // admin unlock duration in minutes
        if(oldGeneralSettingsData.getAdminLockout() != newGeneralSettingData.getAdminLockout()){
            if(!result.toString().isEmpty()){
                result.append(", ");
            }
            result.append(createFormattedString(USMCommonStrings.IDS_GS_ADMIN_UNLOCK, newGeneralSettingData.getAdminLockout() ));
        }

        if(!result.toString().isEmpty()){
            String logStr = createFormattedString(USMCommonStrings.IDS_LG_WINDOW_TAB_CONSOLIDATE_MSG, USMMenuNameList.OPERATION_SECURITY_SETTINGS,
                    USMCommonStrings.IDS_SETTINGS_TAB_ACCNT_LOCK, result);
            LMInterFace.getInstance().createSecurityCommandRecord(p_sessionContext, logStr, USMCommonStrings.IDS_APPLICATION_SECURITYSETTINGS);
            LOGGER.info(p_sessionContext + ":" + logStr);
        }

        //reset stringbuilder, so that it can be reused.
        result.delete(0, result.length());

        // First tab log info
        // initial password change interval time
        if(oldGeneralSettingsData.getInitPasswordChangeInterval() != newGeneralSettingData.getInitPasswordChangeInterval()){
            result.append(createFormattedString(USMCommonStrings.IDS_GS_PASSWORD_EXPIRATION_INTERVAL, newGeneralSettingData.getInitPasswordChangeInterval() ));
        }
        // client inactivity time out interval
        if(oldGeneralSettingsData.getInactivityTimeout() != newGeneralSettingData.getInactivityTimeout()){
            if(!result.toString().isEmpty()){
                result.append(", ");
            }
            result.append(createFormattedString(USMCommonStrings.IDS_GS_CLIENT_INACTIVITY, newGeneralSettingData.getInactivityTimeout() ));
        }
        // client inactivity timeout warning time
        if(oldGeneralSettingsData.getInactivityTimeoutWarningTime() != newGeneralSettingData.getInactivityTimeoutWarningTime()){
            if(!result.toString().isEmpty()){
                result.append(", ");
            }
            result.append(createFormattedString(USMCommonStrings.IDS_GS_CLIENT_INACTIVITY_TIMEOUT_WARNING, newGeneralSettingData.getInactivityTimeoutWarningTime() ));
        }

        if(!result.toString().isEmpty()){
            String logStr = createFormattedString(USMCommonStrings.IDS_LG_WINDOW_TAB_CONSOLIDATE_MSG, USMMenuNameList.OPERATION_SECURITY_SETTINGS,
                    USMCommonStrings.IDS_SETTINGS_TAB_GENERAL, result);
            LMInterFace.getInstance().createSecurityCommandRecord(p_sessionContext, logStr, USMCommonStrings.IDS_APPLICATION_SECURITYSETTINGS);
            LOGGER.info(p_sessionContext + ":" + logStr);
        }
    }

    /**
     * Creates a command record for every value changed in the LDAP configuration data
     *
     * @param sessionContext the session context
     * @param oldLdapData the old LDAP configuration data
     * @param ldapData the new LDAP configuration data
     */
    private void createCommandRecord(ISessionContext sessionContext, LDAPConfigurationData oldLdapData, LDAPConfigurationData ldapData) {
        doOnChange(oldLdapData.getGroupMemberAttribute(), ldapData.getGroupMemberAttribute(),
                () -> createLDAPCommandRecord(sessionContext, USMCommonStrings.IDS_GS_LDAP_ATTR_GROUP_MEMBER_ATTR, ldapData.getGroupMemberAttribute()));

        doOnChange(oldLdapData.getGroupMemberAttribute(), ldapData.getGroupMemberAttribute(),
                () -> createLDAPCommandRecord(sessionContext, USMCommonStrings.IDS_GS_LDAP_ATTR_GROUP_MEMBER_ATTR, ldapData.getGroupMemberAttribute()));

        doOnChange(oldLdapData.getGroupIdAttribute(), ldapData.getGroupIdAttribute(),
                () -> createLDAPCommandRecord(sessionContext, USMCommonStrings.IDS_GS_LDAP_ATTR_GROUP_ID_ATTR, ldapData.getGroupIdAttribute()));

        doOnChange(oldLdapData.getGroupSearchScope(), ldapData.getGroupSearchScope(),
                () -> createLDAPCommandRecord(sessionContext, USMCommonStrings.IDS_GS_LDAP_ATTR_GROUP_SEARCH_SCOPE, ldapData.getGroupSearchScope().toString()));

        doOnChange(oldLdapData.getGroupSearchFilter(), ldapData.getGroupSearchFilter(),
                () -> createLDAPCommandRecord(sessionContext, USMCommonStrings.IDS_GS_LDAP_ATTR_GROUP_SEARCH_FILTER, ldapData.getGroupSearchFilter()));

        doOnChange(oldLdapData.getGroupSearchBase(), ldapData.getGroupSearchBase(),
                () -> createLDAPCommandRecord(sessionContext, USMCommonStrings.IDS_GS_LDAP_ATTR_GROUP_SEARCH_BASE, ldapData.getGroupSearchBase()));

        doOnChange(oldLdapData.getUserIdAttribute(), ldapData.getUserIdAttribute(),
                () -> createLDAPCommandRecord(sessionContext, USMCommonStrings.IDS_GS_LDAP_ATTR_USER_ID_ATTR, ldapData.getUserIdAttribute()));

        doOnChange(oldLdapData.getUserSearchScope(), ldapData.getUserSearchScope(),
                () -> createLDAPCommandRecord(sessionContext, USMCommonStrings.IDS_GS_LDAP_ATTR_USER_SEARCH_SCOPE, ldapData.getUserSearchScope().toString()));

        doOnChange(oldLdapData.getUserSearchFilter(), ldapData.getUserSearchFilter(),
                () -> createLDAPCommandRecord(sessionContext, USMCommonStrings.IDS_GS_LDAP_ATTR_USER_SEARCH_FILTER, ldapData.getUserSearchFilter()));

        doOnChange(oldLdapData.getUserSearchBase(), ldapData.getUserSearchBase(),
                () -> createLDAPCommandRecord(sessionContext, USMCommonStrings.IDS_GS_LDAP_ATTR_USER_SEARCH_BASE, ldapData.getUserSearchBase()));

        doOnChange(oldLdapData.getSearchAccount(), ldapData.getSearchAccount(),
                () -> createLDAPCommandRecord(sessionContext, USMCommonStrings.IDS_GS_LDAP_ATTR_SEARCH_DN, ldapData.getSearchAccount()));

        doOnChange(oldLdapData.isSslIndicator() , ldapData.isSslIndicator(),
                () -> createLDAPCommandRecord(sessionContext, USMCommonStrings.IDS_GS_LDAP_ATTR_SSL, Boolean.toString(ldapData.isSslIndicator())));

        doOnChange(oldLdapData.getHost(), ldapData.getHost(),
                () -> createLDAPCommandRecord(sessionContext, USMCommonStrings.IDS_GS_LDAP_ATTR_HOSTNAME, ldapData.getHost()));
    }

    /**
     * Creates a command record for every value changed in the SSO configuration data
     * @param sessionContext the new session context
     * @param oldData the old Single Sign-On configuration data
     * @param data the new Single Sign-On configuration data
     */
    private void createCommandRecord(ISessionContext sessionContext, SSOConfigurationData oldData, SSOConfigurationData data) {
        doOnChange(oldData.getLdapTcpPort(),data.getLdapTcpPort(), () ->
            createSSOCommandRecord(sessionContext, USMCommonStrings.IDS_GS_SSO_PORT, data.getLdapTcpPort()));

        doOnChange(oldData.getDomainServer(),data.getDomainServer(), () ->
            createSSOCommandRecord(sessionContext, USMCommonStrings.IDS_GS_SSO_DOMAIN_SERVER, data.getDomainServer()));

        doOnChange(oldData.getDomainName(),data.getDomainName(), () ->
            createSSOCommandRecord(sessionContext, USMCommonStrings.IDS_GS_SSO_DOMAIN_NAME, data.getDomainName()));
    }

    /**
     * Creates a command record for every value changed in the RADIUS configuration Data
     * @param sessionContext the new session context
     * @param oldData the old RADIUS configuration data
     * @param newData the new RADIUS configuration data
     */
    private void createCommandRecord(ISessionContext sessionContext, RadiusConfigurationData oldData, RadiusConfigurationData newData) {
        doOnChange(oldData.isEnabled(),                 newData.isEnabled(),
                () -> createRadiusCommandRecord(sessionContext, newData.isEnabled() ? USMCommonStrings.IDS_GS_RADIUS_ENABLED : USMCommonStrings.IDS_GS_RADIUS_DISABLED));

        doOnChange(oldData.getTimeout(),                newData.getTimeout(),
                () -> createRadiusCommandRecord(sessionContext, USMCommonStrings.IDS_GS_RADIUS_TIMEOUT,             String.valueOf(newData.getTimeout())));

        doOnChange(oldData.getRetries(),                newData.getRetries(),
                () -> createRadiusCommandRecord(sessionContext, USMCommonStrings.IDS_GS_RADIUS_RETRIES,             String.valueOf(newData.getRetries())));

        doOnChange(oldData.getUserGroupAttribute(),     newData.getUserGroupAttribute(),
                () -> createRadiusCommandRecord(sessionContext, USMCommonStrings.IDS_GS_RADIUS_USER_GROUP_ATTRIBUTE,String.valueOf(newData.getUserGroupAttribute())));

        doOnChange(oldData.getServerHostname(),         newData.getServerHostname(),
                () -> createRadiusCommandRecord(sessionContext, USMCommonStrings.IDS_GS_RADIUS_SERVER_HOSTNAME,     newData.getServerHostname()));

        doOnChange(oldData.getServerPort(),             newData.getServerPort(),
                () -> createRadiusCommandRecord(sessionContext, USMCommonStrings.IDS_GS_RADIUS_SERVER_PORT,         String.valueOf(newData.getServerPort())));

        doOnChange(oldData.getServerSharedSecret(),     newData.getServerSharedSecret(),
                () -> createRadiusCommandRecord(sessionContext, USMCommonStrings.IDS_GS_RADIUS_SERVER_SECRET));

        doOnChange(oldData.getAltServerHostname(),      newData.getAltServerHostname(),
                () -> createRadiusCommandRecord(sessionContext, USMCommonStrings.IDS_GS_RADIUS_ALT_SERVER_HOSTNAME, newData.getAltServerHostname()));

        doOnChange(oldData.getAltServerPort(),          newData.getAltServerPort(),
                () -> createRadiusCommandRecord(sessionContext, USMCommonStrings.IDS_GS_RADIUS_ALT_SERVER_PORT,     String.valueOf(newData.getAltServerPort())));

        doOnChange(oldData.getAltServerSharedSecret(),  newData.getAltServerSharedSecret(),
                () -> createRadiusCommandRecord(sessionContext, USMCommonStrings.IDS_GS_RADIUS_ALT_SERVER_SECRET));

    }

    /**
     * Creates a command record for every value changed in the Password Validation Rules configuration data
     * @param sessionContext the new session context
     * @param oldData the old Password Validation Rules configuration data
     * @param data the new Password Validation Rules configuration data
     */
    private void createCommandRecord(ISessionContext sessionContext, PasswordValidationRulesConfigurationData oldData, PasswordValidationRulesConfigurationData data) {
        if(oldData.isPasswordMustBeDifferentFromEmployeeNumber()!=data.isPasswordMustBeDifferentFromEmployeeNumber()){
            createPasswordValidationRulesCommandRecord(
                    sessionContext,
                    USMCommonStrings.IDS_GS_PASSWORD_VALIDATION_RULES_EMPLOYEE_NUMBER,
                    data.isPasswordMustBeDifferentFromEmployeeNumber()? ACTIVE : INACTIVE);
        }

        if(oldData.isPasswordMustBeDifferentFromName()!=data.isPasswordMustBeDifferentFromName()){
            createPasswordValidationRulesCommandRecord(sessionContext, USMCommonStrings.IDS_GS_PASSWORD_VALIDATION_RULES_NAME, data.isPasswordMustBeDifferentFromName()? ACTIVE : INACTIVE);
        }

        if(oldData.isPasswordMustBeDifferentFromDate()!=data.isPasswordMustBeDifferentFromDate()){
            createPasswordValidationRulesCommandRecord(sessionContext, USMCommonStrings.IDS_GS_PASSWORD_VALIDATION_RULES_DATE, data.isPasswordMustBeDifferentFromDate()? ACTIVE : INACTIVE);
        }

        if(oldData.isPasswordMustNotHaveSpaces()!=data.isPasswordMustNotHaveSpaces()){
            createPasswordValidationRulesCommandRecord(sessionContext, USMCommonStrings.IDS_GS_PASSWORD_VALIDATION_RULES_MUST_NOT_HAVE_SPACES, data.isPasswordMustNotHaveSpaces()? ACTIVE : INACTIVE);
        }
    }

    /**
     * Creates a Command Record identifying an LDAP event
     *
     * @param context session context
     * @param format String format
     * @param values values to replace
     */
    private void createLDAPCommandRecord(ISessionContext context, String format, String... values){
        String changesStr = createFormattedString(format, (Object[]) values);
        String logStr = createFormattedString(
                USMCommonStrings.IDS_LG_WINDOW_TAB_CONSOLIDATE_MSG,
                USMMenuNameList.OPERATION_SECURITY_SETTINGS,
                USMCommonStrings.IDS_SETTINGS_TAB_LDAP,
                changesStr);
        LMInterFace.getInstance().createSecurityCommandRecord(context, logStr, USMCommonStrings.IDS_APPLICATION_SECURITYSETTINGS);
        LOGGER.info("{}:{}", context, logStr);
    }

    /**
     * Creates a Command Record identifying a SSO event
     *
     * @param context session context
     * @param format String format
     * @param values values to replace
     */
    private void createSSOCommandRecord(ISessionContext context, String format, String... values){
        String changesStr = createFormattedString(format, (Object[]) values);
        String logStr = createFormattedString(
                USMCommonStrings.IDS_LG_WINDOW_TAB_CONSOLIDATE_MSG,
                USMMenuNameList.OPERATION_SECURITY_SETTINGS,
                USMCommonStrings.IDS_SETTINGS_TAB_SSO,
                changesStr);
        LMInterFace.getInstance().createSecurityCommandRecord(context, logStr, USMCommonStrings.IDS_APPLICATION_SECURITYSETTINGS);
        LOGGER.info("{}:{}", context, logStr);
    }

    /**
     *
     * @param context
     * @param format
     * @param values
     */
    private void createPasswordValidationRulesCommandRecord(ISessionContext context, String format, String values){
        String changesStr = createFormattedString(format, values);
        String logStr = createFormattedString(
                USMCommonStrings.IDS_LG_WINDOW_TAB_CONSOLIDATE_MSG,
                USMMenuNameList.OPERATION_SECURITY_SETTINGS,
                USMCommonStrings.IDS_SETTINGS_TAB_PASSWORD_VALIDATIONS,
                changesStr);
        LMInterFace.getInstance().createSecurityCommandRecord(context, logStr, USMCommonStrings.IDS_APPLICATION_SECURITYSETTINGS);
        LOGGER.info("{}:{}", context, logStr);
    }

    /**
     * Creates a Command Record identifying a RADIUS event
     *
     * @param context session context
     * @param format String format
     * @param values values to replace
     */
    private void createRadiusCommandRecord(ISessionContext context, String format, String... values){
        String changesStr = createFormattedString(format, (Object[]) values);
        String logStr = createFormattedString(
                USMCommonStrings.IDS_LG_WINDOW_TAB_CONSOLIDATE_MSG,
                USMMenuNameList.OPERATION_SECURITY_SETTINGS,
                USMCommonStrings.IDS_SETTINGS_TAB_RADIUS,
                changesStr);
        LMInterFace.getInstance().createSecurityCommandRecord(context, logStr, USMCommonStrings.IDS_APPLICATION_SECURITYSETTINGS);
        LOGGER.info("{}:{}", context, logStr);
    }

    /**
     * Logs a new exception
     * @param e the exception to log
     * @param message the format
     */
    private void logException(NestedRuntimeException e, String message) {
        String msg = MessageFormat.format("{0}. Reason: {1}", message, e.getMessage());
        LOGGER.error(msg);
        LOGGER.debug(message, e);
    }

    /**
     *
     * @param oldValue
     * @param newValue
     * @param runnable
     */
    private void doOnChange(Object oldValue, Object newValue, Runnable runnable) {
        if(oldValue != null && !oldValue.equals(newValue)){
            runnable.run();
        }
    }
}