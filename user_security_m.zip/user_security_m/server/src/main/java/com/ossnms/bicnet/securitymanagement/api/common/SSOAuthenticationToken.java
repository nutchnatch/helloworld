package com.ossnms.bicnet.securitymanagement.api.common;

import com.ossnms.bicnet.securitymanagement.common.utils.ObjectCypher;

import javax.security.auth.kerberos.KerberosTicket;
import java.io.Serializable;

/**
 *
 */
public final class SSOAuthenticationToken implements Serializable {

    private static final long serialVersionUID = -8750554408687175987L;

    private String clientRealm;
    private String ldapServer;
    private String objectSID;
    private KerberosTicket kerberosTicket;

    /**
     *
     * @param realm the realm of the client to set
     */
    public void setClientRealm(String realm){
        clientRealm = realm;
    }

    /**
     *
     * @return the client realm
     */
    public String getClientRealm(){
        return clientRealm;
    }

    /**
     *
     * @return the ldap server
     */
    public String getLdapServer() {
        return ldapServer;
    }

    /**
     *
     * @param ldapServer the ldap server to set
     */
    public void setLdapServer(String ldapServer) {
        this.ldapServer = ldapServer;
    }

    /**
     *
     */
    public String getObjectSID() {
        return objectSID;
    }

    /**
     * @param objectSID the Object's SID to set
     */
    public void setObjectSID(String objectSID) {
        this.objectSID = objectSID;
    }

    /**
     *
     */
    public KerberosTicket getKerberosTicket() {
        return kerberosTicket;
    }

    /**
     * @param kerberosTicket the Kerberos Credentials ticket to set
     */
    public void setKerberosTicket(KerberosTicket kerberosTicket) {
        this.kerberosTicket = kerberosTicket;
    }

    /**
     *
     * @param token
     * @return
     */
    public static byte[] cypherToken(SSOAuthenticationToken token) {
        return ObjectCypher.cypherToken(token);
    }

    /**
     * Deciphers the KerberosTicket sent by the client application
     *
     * @param token the ciphered ticket as a byte array
     * @return the deciphered KerberosTicket
     */
    public static SSOAuthenticationToken decipherTicket(byte[] token) {
        return (SSOAuthenticationToken) ObjectCypher.decypherToken(token);
    }
}
