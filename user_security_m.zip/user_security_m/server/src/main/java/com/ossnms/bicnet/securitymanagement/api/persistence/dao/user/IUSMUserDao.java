package com.ossnms.bicnet.securitymanagement.api.persistence.dao.user;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.IBaseDAO;
import com.ossnms.bicnet.securitymanagement.persistence.model.user.USMPasswordHistory;
import com.ossnms.bicnet.securitymanagement.persistence.model.user.USMUser;

import java.util.List;

/**
 * created on 8/10/2014
 */
public interface IUSMUserDao extends IBaseDAO<USMUser, Integer> {
    USMUser findByUsername(String username);

    /**
     *
     * @param enabled
     * @return
     */
    List<USMUser> findByInactivityTimeoutEnabled(boolean enabled);
    
    /**
     * Returns an ordered by date list of all the passwords in password history for a certain user
     */
    List<USMPasswordHistory> findPasswordsByUser(USMUser user);
}
