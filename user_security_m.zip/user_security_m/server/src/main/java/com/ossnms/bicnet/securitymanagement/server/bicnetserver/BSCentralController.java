/*
 * Project      BiCNET Common Functions
 *
 * Component    CF:USM
 * Class Name   BSCentralController
 * Author       Muyeen M
 * Substitute   Asifulla Khan
 * Created on   12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_OBJECTS
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_ACL
 *       : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_SECURITY
 *       : TNMS.DX2.SM.APPLICATION_SERVER.INSERT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005  Asif            CF000845 - System Event Log Entries
 * 19-Jan-2005  Muyeen Munaver  CF000297 - Sync Step 1a)
 * 02-Feb-2005  Babu B          CF000199-11 Unification of GUI-Labels for Enums
 * 18-Mar-2005  Asif khan R     CF001755 Error Messages when LDAP not available 
 * 22-Mar-2005	Muyeen Munaver	CF0001791 - Problems with Login
 * 14-Apr-2005	Muyeen Munaver	CF001025	Stop the Server - message to the clients
 * 25-Apr-2005	Muyeen Munaver	CF001917 - Policy with FM menu associated - not possible to do ACK or Add Note
 * 26-Apr-2005	Asif		    CF000834 - Command Log Entries	CF USM
 * 14-Jun-2005  Muyeen Munaver  CF000209 - Changes in the ISecurityProviderFacade / IManagedObject
 * 27-Jun-2005  Muyeen Munaver  CF002719 - Master-Master Replication Limitation; support only Global NE Domain
 * 27-June-2007	Shrinidhi G V 	CF004252 -13 - NE activated/resync => Source in Sys Log is not NE ID name (ex. EM/NE)
 * 27-June-2007	Shrinidhi G V 	CF004252 -20 - NE activated/resync => Source in Sys Log is not NE ID name (ex. EM/NE)
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.bicnetserver;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.ComponentVersionInformation;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.bcb.model.security.ISecurableObject;
import com.ossnms.bicnet.bcb.model.security.ISecurableObjectContainer;
import com.ossnms.bicnet.bcb.model.security.ISecurableObjectId;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSMessageType;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSReturnType;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObjectContainer;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.server.auth.AALocalSecurityProviderFacadeImpl;
import com.ossnms.bicnet.securitymanagement.server.basic.notification.USMNotifier;
import com.ossnms.bicnet.securitymanagement.server.bcbwrapper.BWCommonFuncObject;
import com.ossnms.bicnet.securitymanagement.server.bcbwrapper.BWCommonFuncRetrievalManager;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityServerConfigurationHelperPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.logging.LMInterFace;
import com.ossnms.bicnet.securitymanagement.server.logging.LMLogRecordData;
import com.ossnms.bicnet.securitymanagement.server.logging.LMLogRecordEnum;
import com.ossnms.bicnet.securitymanagement.server.servicelocator.USMServiceLocator;
import com.ossnms.bicnet.util.UnexpectedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.InvalidParameterException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;
import java.util.TimerTask;

/**
 * This is the Central Controller for the BS Subsystem. The POJO speaks to this class.
 * This Controller then depending on the work that needs to be done, delegates to one
 * of the helper Controllers.
 */
final class BSCentralController {
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER =  LoggerFactory.getLogger(BSCentralController.class);

    /**
     * This is the TimerTask which is associated with the periodic pinging
     * to check for newly available CF's
     */
    private TimerTask periodicPingChkNewlyAvailCFTask = null;

    /**
     * This is the time delay for checks of the newly available CFs
     */
    private static final int PING_INTERVAL_CHK_NEWLY_AVAIL_CF = 120000;

    /**
     * Static data member to hold the static data object
     */
    private static BSCentralController instance = new BSCentralController();

    /**
     * The Transient Cache Manager which holds all the Transient Data. Since
     * all new insertions of CF can only happen through the Central
     * Controller, the Central Controller maintains a Transisent Cache Manager
     * to maintain a list of the configured CFs.
     */
    private BSDataManager bsDataManager = null;

    /**
     * Data member to hold whether the consistency check has been performed already or not.
     * Initially it should be set to true to indicate that the consistency check is required
     */
    private boolean consistencyChkRequired = true;

    /**
     * Constructor
     */
    private BSCentralController() {
        LOGGER.debug("Entering the constructor");
        LOGGER.debug("Exiting the constructor");
    }

    /**
     * This function will do all the initialization that is needed for startup.
     *
     * @return boolean  Indicates whether the initialization succeeded or not. True indicates success
     */
    boolean initialize() {
        LOGGER.debug("Entering the initialize.");

        bsDataManager = new BSDataManager();
        bsDataManager.initialize();

        // Now we set up the timer jobs
        // Set up the Timer Job for the checking if new CFs have become
        // available.
        periodicPingChkNewlyAvailCFTask = new java.util.TimerTask() {
            @Override
            public void run() {
                try {
                    checkAvailableCFs();
                } catch (Exception ex) {
                    LOGGER.error("An exception was thrown, new CFs will be undiscovered.", ex);
                }
            }
        };
        // Create a timer object to run the task. But make sure that it runs as a
        // daemon and does not block the shutdown of the application
        java.util.Timer timer = new java.util.Timer(true);
        timer.schedule(
                periodicPingChkNewlyAvailCFTask,
                PING_INTERVAL_CHK_NEWLY_AVAIL_CF,
                PING_INTERVAL_CHK_NEWLY_AVAIL_CF
        );

        LOGGER.debug("Exiting initialize. Returning with success.");
        return true;
    }

    /**
     * Helper function which will make a call to the Bean for the checking of the
     * Newly available CFs with the Service Locator.
     */
    private void checkAvailableCFs() {
        LOGGER.debug("Entering checkAvailableCFs.");

        USMServiceLocator servLoc = USMServiceLocator.getInstance();
        ISecurityServerConfigurationHelperPrivateFacade fcd;
        try {
            fcd = servLoc.getSecurityServerConfigurationHelperPrivateFacade();
            if (fcd != null) {
                fcd.checkForNewlyAvailableCFsWithServiceLocator(null);
            } else {
                LOGGER.error("The Private interface returned is null.");
            }
        } catch (UnexpectedException | BcbSecurityException e) {
            LOGGER.error("Exception occurred", e);
        }

        LOGGER.debug("Exiting checkAvailableCFs.");
    }

    /**
     * Helper function which will perform the consistency check
     */
    void performConsistencyCheck() {
        LOGGER.debug("performConsistencyCheck() - entry");

        // Only if the flag is set that we have to do the consistency check
        if (consistencyChkRequired) {
            // perform the consistency check for each cf
            bsDataManager.getAllFunctions().forEach(cf -> {
                String strID = cf.getCFid();
                BWCommonFuncObject bwObj = BWCommonFuncRetrievalManager.getInstance().getCommonFunctionObject(strID);
                if (bwObj != null) {
                    // retrieve securable objects
                    ISecurableObject[] arrObjects = bwObj.getSecurableObjects();
                    if (arrObjects != null) {
                        // convert array of SecurableObjects
                        List<BSSecurableObject> lstElms = BSServerHelper.convertToSecurableObjectList(arrObjects, cf);
                        bsDataManager.updateSecurableObjsForCF(cf, lstElms);
                        if (lstElms.size() > 0) {
                            // We are setting it true only when we have at least 1 elem. This guarantees that EM-NE Obj has been initialized.
                            // In case where there are no NE's this check will be repeated after 2 mins. So over head is very low.
                            consistencyChkRequired = false;
                        }
                    }
                } else {
                    LOGGER.error("performConsistencyCheck() CF is currently not available. " + cf.getComponentType());
                }
            });
        }
        LOGGER.debug("performConsistencyCheck() - exit");
    }

    /**
     * Helper function which will check with the Service
     * Locator for any newly available CFs.
     */
    void checkForNewlyAvailableCFsWithServiceLocator() {

        LOGGER.debug("Entering checkForNewlyAvailableCFsWithServiceLocator");
        BWCommonFuncRetrievalManager mgr =
                BWCommonFuncRetrievalManager.getInstance();
        Object[] arrCFs = mgr.getAllRegisteredCFs();

        if (arrCFs != null) {
            for (Object arrCF : arrCFs) {
                String strCompType = (String) arrCF;
                if (!bsDataManager.isFunctionConfigured(strCompType)) {
                    BWCommonFuncObject obj = mgr.getCommonFunctionObject(strCompType);
                    if (obj != null) {
                        insertCFIntoUSM(obj);
                    } else {
                        LOGGER.error("Returned CF Object is null");
                    }
                } else {
                    if (LOGGER.isDebugEnabled()) {
                        LOGGER.debug("Already configured Object : " + strCompType);
                    }
                }
            }
        } else {
            LOGGER.error("BWCommonFuncRetrievalManager returned null for CFs");
        }

        LOGGER.debug("Exiting checkForNewlyAvailableCFsWithServiceLocator");
    }

    /**
     * Function to insert a CF Object which is encapsulated into CF USM
     *
     * @param cfObject The Object which represents a CF.
     */
    private void insertCFIntoUSM(BWCommonFuncObject cfObject) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering insertFunction. Object : " + cfObject);
        }

        try {
            String name = cfObject.getName();
            String desc = cfObject.getDescription();
            BiCNetComponentType compType = cfObject.getComponentType();
            ComponentVersionInformation verInfo = cfObject.getVersion();

            BSTransBicNetCFInfo transCF = new BSTransBicNetCFInfo(name, desc, compType, verInfo);

            BSReturnType result = bsDataManager.insertFunction(transCF);
            if (result == BSReturnType.SUCCESS_T) {
                BSExternalInterface.informPAAboutCFInsertion(transCF);

                retrieveAndStoreSecurableObjectsForCF(AALocalSecurityProviderFacadeImpl.getInstance().getSystemAccountContext(), cfObject, transCF);
                sendNotificationCFInserted(transCF);
            } else {
                LOGGER.error("Error while inserting CF into USM. CF : " + transCF + ", Result is : " + result);
            }

        } catch (BcbException e) {
            LOGGER.error("Exception thrown." + e);
        } catch (InvalidParameterException e) {
            LOGGER.error("InvalidParameterException thrown." + e);
        }

        LOGGER.debug("Exiting insertFunction.");
    }

    /**
     * Function to send a Notification that a CF was successfully inserted into CF USM
     *
     * @param transCF The CF which was inserted into CF USM.
     */
    private void sendNotificationCFInserted(BSTransBicNetCFInfo transCF) {
        // Now send the notification.
        USMMessage insertCFNotifMsg = new USMMessage(BSMessageType.BS_NOT_CF_INSERTED, USMMessage.USMMESSAGE_NOTIFICATION);
        transCF.pushTo(insertCFNotifMsg);
        USMNotifier notifier = USMNotifier.getInstance();
        notifier.sendNotification(insertCFNotifMsg);

        ISessionContext ctx = AALocalSecurityProviderFacadeImpl.getInstance().getSystemAccountContext();
        //CF has self subscribed
        String displayStr = MessageFormat.format(USMCommonStrings.IDS_BS_COMMON_FUNCTION_CONFIGURED,
                transCF.getComponentType().guiLabel(), ctx.getUserName(), ((IEnhancedSessionContext) ctx).getClientMachineName());
        LMLogRecordData usmLogRecord = new LMLogRecordData(LMLogRecordEnum.CF_SELF_REGISTERED, transCF.getName(), LMLogRecordData._SUCCESS, null, LogSeverity.MESSAGE.guiLabel(), null, displayStr);
        LMInterFace.getInstance().createSecurityLogRecord(ctx, usmLogRecord);

        displayStr = MessageFormat.format(USMCommonStrings.IDS_BS_CF_NEW_APPLICATION_SYSTEM_LOG, transCF.getComponentType().guiLabel(), transCF.getVersion().toString());

        LMInterFace.getInstance().createSecuritySystemEventRecord(ctx, displayStr, LogSeverity.MESSAGE, transCF.getComponentType().guiLabel());
    }

    /**
     * Function called to cleanup the resources that are acquired by this
     * Object. It should also set all its Objects to null to facilitate finalization
     */
    boolean cleanup() {
        if (bsDataManager != null) {
            bsDataManager = null;
        }

        if (periodicPingChkNewlyAvailCFTask != null) {
            periodicPingChkNewlyAvailCFTask.cancel();
            periodicPingChkNewlyAvailCFTask = null;
        }

        return true;
    }

    /**
     * Static function to get the singelton Object
     *
     * @return BSCentralController  Returns the singleton instance of this class.
     */
    static BSCentralController getInstance() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering getInstance");
            LOGGER.debug("Exiting getInstance. Returning : {}", instance);
        }

        return instance;
    }

    /**
     * Function to retrieve all the Configured CF's that are available with CF USM
     * in a Message
     *
     * @return USMMessage Message which contains the configured CF's within USM
     */
     USMMessage getAllConfiguredCFsInMsg() {
        LOGGER.debug("Entering getAllConfiguredCFsInMsg");

        List<BSTransBicNetCFInfo> lstCFs = getAllConfiguredCFs();

        USMMessage msg = new USMMessage(BSMessageType.BS_RES_GET_CONF_CFS, USMMessage.USMMESSAGE_RESPONSE);
        BSCommonHelper.pushCFsListIntoMessage(msg, lstCFs);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting getAllConfiguredCFsInMsg. Msg : " + msg);
        }
        return msg;
    }

    /**
     * Function to return all configured CFs within USM in a List.
     *
     * @return List List of configured CFs within USM
     */
    List<BSTransBicNetCFInfo> getAllConfiguredCFs() {
        LOGGER.debug("Entering getAllFunctions");
        List<BSTransBicNetCFInfo> lst = bsDataManager.getAllFunctions();

        LOGGER.debug("Exiting getAllFunctions. List : " + lst);
        return lst;
    }

    /**
     * Function to retrieve and store the Securable Objects for a particular CF
     *
     * @param cfObject THe encapsulated CF Object retrieved from the Service Locator.
     * @param transCf  The CF as represented in USM
     * @return BSReturnType Result of the retrieval and update.
     */
    private BSReturnType retrieveAndStoreSecurableObjectsForCF(ISessionContext sessionContext, BWCommonFuncObject cfObject, BSTransBicNetCFInfo transCf) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering retrieveAndStoreSecurableObjectsForCF. CF is : " + transCf);
        }
        BSReturnType result = BSReturnType.SUCCESS_T;
        ISecurableObject[] arrObjects = cfObject.getSecurableObjects();
        if (arrObjects != null) {
            List<BSSecurableObject> lstElms = BSServerHelper.convertToSecurableObjectList(arrObjects, transCf);
            result = bsDataManager.updateSecurableObjsForCF(transCf, lstElms);

        } else {
            LOGGER.warn("Securable Objects retrieved are null.");
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting retrieveAndStoreSecurableObjectsForCF. Result is : " + result);
        }

        int nNoOfElms = (arrObjects != null) ? arrObjects.length : 0;
        String displayStr = MessageFormat.format(USMCommonStrings.IDS_BS_SYNCH_CF_SEC_OBJS, transCf.getComponentType().guiLabel(), Integer.toString(nNoOfElms));

        LMInterFace.getInstance().createSecuritySystemEventRecord(sessionContext, displayStr, LogSeverity.MESSAGE, transCf.getComponentType().guiLabel());

        return result;
    }

    /**
     * This function is called to retrieve a list of all the Sec Objects
     * that belong to a particular CF.
     *
     * @param cf The CF for which the Managed Elements should be retrieved.
     * @return USMMessage Message which contains the Securable Object information.
     */
     USMMessage getSecurableObjsForCFFromCacheInMsg(BSTransBicNetCFInfo cf) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering getSecurableObjsForCFFromCacheInMsg. CF is : " + cf);
        }
        BSReturnType result = BSReturnType.SERVER_NOT_CONFIGURED_T;
        USMMessage msg = new USMMessage(BSMessageType.BS_RES_GET_SEC_OBJS_FOR_CF, USMMessage.USMMESSAGE_RESPONSE);

        if (bsDataManager.isFunctionConfigured(cf.getCFid())) {
            List<BSSecurableObject> lstSecObjs = bsDataManager.getSecurableObjects(cf);
            BSCommonHelper.pushSecurableObjectsListIntoMessage(msg, lstSecObjs);
            result = BSReturnType.SUCCESS_T;
        }

        cf.pushTo(msg);
        result.pushMe(msg);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting getSecurableObjsForCFFromCacheInMsg. Server is : " + cf + " Message is : " + msg);
        }

        return msg;
    }

    /**
     * Function to retrieve the Securable Objects for a CF from the Cache.
     *
     * @param cf           The CF for which we have to retrieve the information
     * @param lstSecObjs The Securable Objects that are available in USM for the CF
     * @return BSReturnType Indicates whether the data was retrieved or not.
     */
    BSReturnType getSecurableObjects(BSTransBicNetCFInfo cf, List<BSSecurableObject> lstSecObjs) {
        LOGGER.debug("Entering getSecurableObjects. CF : " + cf);

        BSReturnType result = BSReturnType.SERVER_NOT_CONFIGURED_T;

        if (bsDataManager.isFunctionConfigured(cf.getCFid())) {
            lstSecObjs.addAll(bsDataManager.getSecurableObjects(cf));
            result = BSReturnType.SUCCESS_T;
        }

        LOGGER.debug("Exiting getSecurableObjects. List : " + lstSecObjs + " Result : " + result);

        return result;
    }


    /**
     * Function to retrieve the Securable Objects for a CF from the Cache.
     *
     * @param cf           The CF for which we have to retrieve the information
     * @param lstSecObjs The Securable Objects that are available in USM for the CF
     * @return BSReturnType Indicates whether the data was retrieved or not.
     */
    BSReturnType getSecurableObjects(BSTransBicNetCFInfo cf, List<BSSecurableObject> lstSecObjs, int domainId) {
        LOGGER.debug("Entering getSecurableObjects. CF : " + cf);

        BSReturnType result = BSReturnType.SERVER_NOT_CONFIGURED_T;

        if (bsDataManager.isFunctionConfigured(cf.getCFid())) {
            lstSecObjs.addAll(bsDataManager.getSecurableObjects(cf, domainId));
            result = BSReturnType.SUCCESS_T;
        }

        LOGGER.debug("Exiting getSecurableObjects. List : " + lstSecObjs + " Result : " + result);

        return result;
    }

    /**
     * Function to remove CF's from USM
     *
     * @param lctCFs List of CF which should be removed.
     * @return USMMessage Message which has information about the result of the
     * operation.
     */
    USMMessage removeCFsFromUSM(ISessionContext ctx, List<BSTransBicNetCFInfo> lctCFs) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering removeCFsFromUSM. List being passed is : " + lctCFs);
        }

        USMMessage responseMsg = new USMMessage(BSMessageType.BS_RES_REMOVE_CFS, USMMessage.USMMESSAGE_RESPONSE);

        USMMessage notifMsg = new USMMessage(BSMessageType.BS_NOT_CF_REMOVED, USMMessage.USMMESSAGE_NOTIFICATION);

        int nNoOfCFsRemovedSucc = 0;

        for (BSTransBicNetCFInfo cf : lctCFs) {
            BSReturnType result = removeCFFromUSM(cf);

            result.pushMe(responseMsg);
            cf.pushTo(responseMsg);

            // If the server was removed successfully, we should also send a notification. So add all of them together and send.
            if (result.equals(BSReturnType.SUCCESS_T)) {
                cf.pushTo(notifMsg);
                nNoOfCFsRemovedSucc++;
                // Create security log for the event.
                String displayStr = MessageFormat.format(USMCommonStrings.IDS_BS_COMMON_FUNCTION_REMOVAL,
                        cf.getComponentType().guiLabel(), ctx.getUserName(), ((IEnhancedSessionContext) ctx).getClientMachineName());
                LMLogRecordData usmLogRecord = new LMLogRecordData(LMLogRecordEnum.CF_REMOVED, cf.getName(), LMLogRecordData._SUCCESS, null, LogSeverity.WARNING.toString(), null, displayStr);

                LMInterFace.getInstance().createSecurityLogRecord(ctx, usmLogRecord);
            }
        }
        responseMsg.pushInteger(lctCFs.size());

        if (nNoOfCFsRemovedSucc != 0) {
            notifMsg.pushInteger(nNoOfCFsRemovedSucc);
            USMNotifier.getInstance().sendNotification(notifMsg);
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Message that was sent for the removal of the CFs : " + notifMsg);
            LOGGER.debug("Exiting removeCFsFromUSM. Returing Message : " + responseMsg);
        }

        return responseMsg;
    }

    /**
     * This function is invoked to remove a CF from the USM Scenario. On invoking of this function,
     * the following actions need to be performed -
     * Remove the Data about the CF from LDAP.
     *
     * @param cf The CF that needs to be removed from USM.
     * @return BSReturnType  The result of the removal of the CF.
     */
    private BSReturnType removeCFFromUSM(BSTransBicNetCFInfo cf) {
        LOGGER.debug("Entering removeCFFromUSM. CF passed is : " + cf);

        BSReturnType bStatus = bsDataManager.removeCFFromUSM(cf);

        LOGGER.debug("Exiting removeCFFromUSM. Result of removal is : " + bStatus);

        return bStatus;
    }

    /**
     * Function to retrieve all the Securable Objects
     *
     * @return List List which contains the Securable Objects within CF USM
     */
     List<BSSecurableObject> getAllSecurableObjects() {
         LOGGER.debug("Entering getSecurableObjects.");

         List<BSSecurableObject> lstAllSecObjs = bsDataManager.getSecurableObjects();

         LOGGER.debug("Exiting getSecurableObjects. List : {}", lstAllSecObjs);
         return lstAllSecObjs;
    }


    public List<BSSecurableObject> getAllSecurableObjectsWithACL() {
        LOGGER.debug("Entering getSecurableObjects.");

        List<BSSecurableObject> lstAllSecObjs = bsDataManager.getSecurableObjectsWithACL();

        LOGGER.debug("Exiting getSecurableObjects. List : {}", lstAllSecObjs);
        return lstAllSecObjs;
    }



    /**
     * This function is invoked update ACL information for Securable Objects
     *
     * @param lstSecurableObj        This contains all the Securable Objects that should be (un)assigned to the
     *                               domains
     * @param lstDomains             The domains to which the Sec Objects should be (un)assigned .
     * @param lstFailedSecurableObjs The Sec Object(s) which could not be (un)assigned
     * @param assign                 Indicates whether the function is called for Assignment or UnAssignment. True indicates Assignment.
     * @return BSReturnType  Indicates whether it was possible to complete the operation
     */
     BSReturnType updateACLForSecurableObjects(List<BSSecurableObject> lstSecurableObj, List<DCDomainData> lstDomains, List<BSSecurableObject> lstFailedSecurableObjs, boolean assign) {
        return bsDataManager.updateACL(lstSecurableObj, lstDomains, lstFailedSecurableObjs, assign);
    }

    /**
     * Function to Synchronize the passed CFs with the latest Securable information
     *
     * @param lstCFs List of CFs which have to be Synchronized.
     * @return USMMessage Message which contains information about the Synchronization.
     */
     USMMessage syncSecObjsWithCFs(ISessionContext ctx, List<BSTransBicNetCFInfo> lstCFs) {
        LOGGER.debug("Entering syncSecObjsWithCFs. List passed is : {}", lstCFs);

        USMMessage responseMsg = new USMMessage(BSMessageType.BS_RES_SYNC_CFS_WITH_SEC_OBJS, USMMessage.USMMESSAGE_RESPONSE);

        lstCFs.forEach(cf -> {
            BSReturnType result = syncSecurableObjectsForCF(ctx, cf);
            result.pushMe(responseMsg);
            cf.pushTo(responseMsg);
        });

        responseMsg.pushInteger(lstCFs.size());

        LOGGER.debug("Exiting syncSecObjsWithCFs. Message being returned is : " + responseMsg);
        return responseMsg;
    }

    /**
     * Function to synchronize a specific CF with Securable Objects
     *
     * @param cf The CF which has to be synchronized.
     * @return BSReturnType Result of the Synchronization operation.
     */
    private BSReturnType syncSecurableObjectsForCF(ISessionContext ctx, BSTransBicNetCFInfo cf) {
        BWCommonFuncRetrievalManager mgr = BWCommonFuncRetrievalManager.getInstance();
        BSReturnType result = BSReturnType.SERVER_DOWN_NOT_REACHABLE_T;

        String strType = cf.getComponentType().toString();
        BWCommonFuncObject obj = mgr.getCommonFunctionObject(strType);
        if (obj != null) {
            result = retrieveAndStoreSecurableObjectsForCF(ctx, obj, cf);
            if (result.equals(BSReturnType.SUCCESS_T)) {
                // Since we have  the data we should send a notification.
                USMMessage cfSynchedNotifMsg = new USMMessage(BSMessageType.BS_NOT_CF_SYNCED_WITH_SEC_OBJS, USMMessage.USMMESSAGE_NOTIFICATION);
                cf.pushTo(cfSynchedNotifMsg);
                USMNotifier notifier = USMNotifier.getInstance();
                notifier.sendNotification(cfSynchedNotifMsg);
            }
        } else {
            LOGGER.error("CF is currently no available." + cf);
        }

        return result;
    }

    /**
     * Function to add a securable object to a particular Component.
     *
     * @param component       The Component which is the owner of the Securable Objects
     * @param securableObject The Securable Object that should be added.
     */
    void registerObject(BiCNetComponentType component, ISecurableObject securableObject) {
        LOGGER.debug("registerObject(BiCNetComponentType p_Component = {}, ISecurableObject p_SecurableObject = {}) - entry", component, securableObject);

        String strCompType = component.toString();
        if (bsDataManager.isFunctionConfigured(strCompType)) {
            BSTransBicNetCFInfo cf = bsDataManager.getFunction(strCompType);
            BSSecurableObject transSecObj = BSServerHelper.convertToSecurableObject(securableObject, cf);
            List<BSSecurableObject> lstElms = new ArrayList<>();
            lstElms.add(transSecObj);
            bsDataManager.insertSecurableObjects(cf, lstElms);
        } else {
            LOGGER.error("CF calling registerObject without itself being registered. " + component);
        }

        LOGGER.debug("registerObject(BiCNetComponentType, ISecurableObject) - exit");
    }

    /**
     * Function to update a securable object to a particular Component.
     *
     * @param component       The Component which is the owner of the Securable Objects
     * @param securableObject The Securable Object that should be updated.
     */
    void updateObject(BiCNetComponentType component, ISecurableObject securableObject) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("updateObject(BiCNetComponentType p_Component = " + component + ", ISecurableObject p_SecurableObject = " + securableObject + ") - entry");
        }

        String strCompType = component.toString();
        if (bsDataManager.isFunctionConfigured(strCompType)) {
            BSTransBicNetCFInfo cf = bsDataManager.getFunction(strCompType);
            BSSecurableObject transSecObj = BSServerHelper.convertToSecurableObject(securableObject, cf);
            List<BSSecurableObject> lstElms = new ArrayList<>();
            lstElms.add(transSecObj);
            bsDataManager.modifySecurableObjects(cf, lstElms);
        } else {
            LOGGER.error("CF calling registerObject without itself being registered. " + component);
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("updateObject(BiCNetComponentType, ISecurableObject) - exit");
        }
    }

    /**
     * Function to update a securable object container to a particular Component.
     *
     * @param component                The Component which is the owner of the Securable Objects
     * @param securableObjectContainer The Securable Object Container that should be updated.
     */
    void updateObjectContainer(BiCNetComponentType component, ISecurableObjectContainer securableObjectContainer) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("updateObjectContainer(BiCNetComponentType p_Component = " + component + ", ISecurableObjectContainer p_SecurableObject = " + securableObjectContainer + ") - entry");
        }

        String strCompType = component.toString();
        if (bsDataManager.isFunctionConfigured(strCompType)) {
            BSTransBicNetCFInfo cf = bsDataManager.getFunction(strCompType);
            List<BSSecurableObjectContainer> transSecObjContainers = BSServerHelper.convertToSecurableObjectContainerList(new ISecurableObjectContainer[]{securableObjectContainer}, cf);
            bsDataManager.modifySecurableObjContainersForCF(cf, transSecObjContainers);
        } else {
            LOGGER.error("CF calling registerObject without itself being registered. " + component);
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("updateObjectContainer(BiCNetComponentType, ISecurableObjectContainer) - exit");
        }
    }


    /**
     * Function to remove a securable object from a particular Component.
     *
     * @param component       The Component which is the owner of the Securable Objects
     * @param securableObject The Securable Object that should be removed.
     */
    boolean unregisterObject(BiCNetComponentType component, ISecurableObject securableObject) {
        String strCompType = component.toString();
        if (bsDataManager.isFunctionConfigured(strCompType)) {
            BSTransBicNetCFInfo cf = bsDataManager.getFunction(strCompType);
            BSSecurableObject transSecObj = BSServerHelper.convertToSecurableObject(securableObject, cf);
            List<BSSecurableObject> lstElms = new ArrayList<>();
            lstElms.add(transSecObj);
            bsDataManager.removeSecurableObjsForCF(cf, lstElms);
        } else {
            LOGGER.error("CF calling unregisterObject without itself being registered. " + component);
        }
        return true;
    }

    /**
     * Function to retrieve the ACL for a particular Securable object
     *
     * @param object The Securable object for which we have to get the ACL.
     * @return BitSet BitSet which represents the ACL.
     */
    BitSet getACLForSecurableObject(IManagedObjectId object) {
        String strKey = object.key();
        return bsDataManager.getACLForSecurableObjWithID(
                USMCommonHelper.getUSMizedStringForKey(strKey));
    }

    /**
     * Function to do the Synchronization of all securable Object related data.
     *
     * @param sessionContext The Session context of the operator driving the sync operation
     * @throws BcbException Exception to be raised in case of problem
     */
    void doFullSync(ISessionContext sessionContext) throws BcbException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering doFullSync. Ctx : " + sessionContext);
        }

        List<BSTransBicNetCFInfo> lst = getAllConfiguredCFs();
        syncSecObjsWithCFs(sessionContext, lst);

        LOGGER.debug("Exiting registerObject.");
    }

    /**
     * Function to retrieve a particular SecurableObject
     *
     * @param objectId the id of the object
     * @return an instance of BSSecurableObject
     */
    BSSecurableObject getSecurableObject(ISecurableObjectId objectId) {
    	//String strKey = objectId.key();
    	// return bsDataManager.getSecurableObjectByDisplayName(USMCommonHelper.getUSMizedStringForKey(strKey));
    	String strKey = objectId.getObjectName();
    	return bsDataManager.getSecurableObjectByDisplayName(strKey);
    }


    int getSecurableObjectCount(BSTransBicNetCFInfo server) {
        LOGGER.debug("Entering getSecurableObjectCount. CF : " + server);

        int result = 0;

        if (bsDataManager.isFunctionConfigured(server.getCFid())) {
            result = bsDataManager.getSecurableObjectCount(server);
        }

        LOGGER.debug("Exiting getSecurableObjects.");

        return result;
    }

    int getSecurableObjectCount(BSTransBicNetCFInfo server, int domainID) {
        LOGGER.debug("Entering getSecurableObjectCount. CF : " + server);

        int result = 0;

        if (bsDataManager.isFunctionConfigured(server.getCFid())) {
            result = bsDataManager.getSecurableObjectCount(server, domainID);
        }

        LOGGER.debug("Exiting getSecurableObjects.");

        return result;
    }
}
