package com.ossnms.bicnet.securitymanagement.server.ldap.callback;

import com.ossnms.bicnet.securitymanagement.server.ldap.dto.LDAPUserContext;
import org.springframework.ldap.core.LdapEntryIdentification;

import javax.naming.directory.DirContext;

/**
 *
 */
public class LDAPContextCallback implements org.springframework.ldap.core.AuthenticatedLdapEntryContextMapper<LDAPUserContext> {
    public LDAPUserContext mapWithContext(DirContext ctx, LdapEntryIdentification ldapEntryIdentification) {
        LDAPUserContext userContext = new LDAPUserContext();
        userContext.setLdapEntryIdentification(ldapEntryIdentification);
        return userContext;
    }
}
