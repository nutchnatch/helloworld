package com.ossnms.bicnet.securitymanagement.api.common;

import java.io.Serializable;

/**
 *
 */
public final class OperationResult implements Serializable {

    private static final long serialVersionUID = 1028667913035718610L;
    
    /**
     *
     */
    private OperationResultStatus status;

    public OperationResult(){}

    /**
     *
     * @return
     */
    public OperationResultStatus getStatus() {
        return status;
    }

    /**
     *
     * @param status
     */
    public void setStatus(OperationResultStatus status) {
        this.status = status;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }

        OperationResult that = (OperationResult) o;

        return getStatus() == that.getStatus();

    }

    @Override
    public int hashCode() {
        return getStatus() != null ? getStatus().hashCode() : 0;
    }

    @Override
    public String toString(){
        return "OperationResult == " + getStatus();
    }
}
