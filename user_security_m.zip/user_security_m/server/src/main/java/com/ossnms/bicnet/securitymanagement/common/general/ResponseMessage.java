package com.ossnms.bicnet.securitymanagement.common.general;

import java.io.Serializable;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ResponseMessage implements Serializable{

    private static final long serialVersionUID = 724676862238904822L;

    private String message;

    private List<ResponseMessage> responseMessages = new ArrayList<>();
    
    private ResponseType type = ResponseType.PLAIN_MESSAGE;

    /**
     *
     */
    public ResponseMessage(){
        super();
    }

    /**
     *
     * @param message
     * @param type
     */
    public ResponseMessage(ResponseType type, String message){
        this();

        this.message = message;
        this.type = type;
    }

    /**
     *
     * @param type
     * @param messageFormat
     * @param params
     */
    public ResponseMessage(ResponseType type, String messageFormat, String... params){
        this();

        this.message = MessageFormat.format(messageFormat, params);
        this.type = type;
    }

    /**
     *
     * @param message
     * @param type
     */
    public ResponseMessage(ResponseType type, String message, ResponseMessage... messages) {
        this(type, message);
        this.responseMessages.addAll(Arrays.asList(messages));
    }

    /**
     *
     * @return
     */
    public String getMessage() {
        return message;
    }

    /**
     *
     * @param message
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     *
     * @return
     */
    public ResponseType getType() {
        return type;
    }

    /**
     *
     * @param type
     */
    public void type(ResponseType type) {
        this.type = type;
    }

    /**
     *
     * @param messages
     */
    public void addResponseMessage(ResponseMessage... messages){
        responseMessages.addAll(Arrays.asList(messages));
    }

    /**
     *
     * @return
     */
    public List<ResponseMessage> getResponseMessages(){
        return responseMessages;
    }

    /**
     *
     * @param type
     * @return
     */
    public List<ResponseMessage> getResponseMessages(ResponseType type){
        return responseMessages
                .stream()
                .filter(message -> message.getType().equals(type))
                .collect(Collectors.toList());
    }

    public List<ResponseMessage> getResponseMessages(Class<?> clss){
        return responseMessages
                .stream()
                .filter(message -> message.getClass().equals(clss))
                .collect(Collectors.toList());
    }
}
