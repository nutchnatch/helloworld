/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	BSServerConfigurationPOJOImpl
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_OBJECTS
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_ACL 
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_SECURITY
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.INSERT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Asif			CF000845 - System Event Log Entries
 * 09-02-2005	Muyeen Munaver  CF000060-01   CF USM GUI Requirements
 * 26-Apr-2005	Asif			CF000834 - Command Log Entries	CF USM
 * 05-May-2005  Babu B  CF001312   Master-Master Replication for Sun ONE DS
 * 27-June-2007	Shrinidhi G V 	CF004252 -13 - NE activated/resync => Source in Sys Log is not NE ID name (ex. EM/NE)
 * 27-June-2007	Shrinidhi G V 	CF004252 -20 - NE activated/resync => Source in Sys Log is not NE ID name (ex. EM/NE)
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.bicnetserver;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMenuNameList;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.server.basic.USMAuthorizationHelper;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityServerConfigurationPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.logging.LMInterFace;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.InvalidParameterException;
import java.util.List;

/**
 * POJO related class for the implementation of the server configuration related private facade
 */
public class BSServerConfigurationPOJOImpl implements ISecurityServerConfigurationPrivateFacade {

	/**
	 * Data member to store the Logger for Tracing purposes.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(BSServerConfigurationPOJOImpl.class);

	/**
	 *
	 * @param ctx
	 * @return
	 * @throws BcbSecurityException
     */
	@Override
    public USMMessage getConfiguredCFs(ISessionContext ctx) throws BcbSecurityException {
		LOGGER.debug("Entering getConfiguredServers");

		final String strMenuName =	USMMenuNameList.OPERATION_TMN_APP_SERVERS_ADMIN;

		String strMessage =	USMCommonHelper.createFormattedString(	USMCommonStrings.IDS_LG_OPERATION_SELECTED, strMenuName);
		LMInterFace.getInstance().createSecurityCommandRecord(ctx, strMessage,USMCommonStrings.IDS_APPLICATION_SERVER_COMPONENTS);
		LOGGER.info(ctx + ":" + strMessage);

		USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(ctx,	strMenuName);
		USMMessage msg = BSCentralController.getInstance().getAllConfiguredCFsInMsg();

		LOGGER.debug("Exiting getConfiguredServers. Returing Message : " + msg);
		return msg;
	}

	/**
	 *
	 * @param ctx
	 * @param lctCFs
	 * @return
	 * @throws BcbSecurityException
     */
	@Override
    public USMMessage removeCFsFromUSM(ISessionContext ctx, List<BSTransBicNetCFInfo> lctCFs) throws BcbSecurityException {

		LOGGER.debug("Entering removeCFsFromUSM. List being passed is : {}", lctCFs);

		if (lctCFs == null) {
			LOGGER.error("List of CFs to be removed passed is null.");
			throw new InvalidParameterException();
		}

		final String strMenuName = USMMenuNameList.OPERATION_TMN_APP_SERVER_REMOVE;

		String strMessage = USMCommonHelper.createFormattedString(
				USMCommonStrings.IDS_BS_COMMON_FUNCTION_CONTEXT_MENU_SELECTED,
				USMMenuNameList.OPERATION_TMN_APP_SERVER_REMOVE,
				Integer.toString(lctCFs.size())
		);

		LMInterFace.getInstance().createSecurityCommandRecord(
				ctx,
				strMessage,
				USMCommonStrings.IDS_APPLICATION_SERVER_COMPONENTS
		);

		LOGGER.info(ctx + ":" + strMessage);

		USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(ctx,	strMenuName);
		USMMessage responseMsg = BSCentralController.getInstance().removeCFsFromUSM(ctx, lctCFs);

		LOGGER.debug("Exiting removeCFsFromUSM. Returing Message : " + responseMsg);

		return responseMsg;
	}

	/**
	 *
	 * @param ctx
	 * @param cf
	 * @return
	 * @throws BcbSecurityException
     */
	@Override
    public USMMessage getManagedSecurableElmsForCF(ISessionContext ctx, BSTransBicNetCFInfo cf)	throws BcbSecurityException {
		LOGGER.debug("Entering getManagedSecurableElmsForCF. CF : " + cf);

		if (cf == null) {
			LOGGER.error("The CF passed is null.");
			throw new InvalidParameterException();
		}

		String strMessage =	USMCommonHelper.createFormattedString(
				USMCommonStrings.IDS_BS_COMMON_FUNCTION_SELECTED,
				USMMenuNameList.OPERATION_TMN_APP_SERVERS_ADMIN,
				cf.getName()
		);

		LMInterFace.getInstance().createSecurityCommandRecord(
			ctx,
			strMessage,cf.getName()
		);

		LOGGER.info("{}:{}", ctx, strMessage);

		final String strMenuName = USMMenuNameList.OPERATION_TMN_APP_SERVERS_ADMIN;
		USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(ctx, strMenuName);

		USMMessage responseMsg = BSCentralController.getInstance().getSecurableObjsForCFFromCacheInMsg(cf);

		LOGGER.debug("Exiting getManagedSecurableElmsForCF. Returing Message : {}", responseMsg);
		return responseMsg;
	}

	/**
	 *
	 * @param ctx
	 * @param lctCFs
	 * @return
	 * @throws BcbSecurityException
     */
	@Override
    public USMMessage synchSecObjsWithCFs(ISessionContext ctx, List lctCFs) throws BcbSecurityException {
		LOGGER.debug("Entering syncSecObjsWithCFs. List being passed is : {}", lctCFs);

		if (lctCFs == null) {
			LOGGER.error("List of CFs to be synced is null.");
			throw new InvalidParameterException();
		}

		final String strMenuName = USMMenuNameList.OPERATION_TMN_APP_SERVER_SYNC_SEC_OBJS;

		String strMessage = USMCommonHelper.createFormattedString(
				USMCommonStrings.IDS_BS_COMMON_FUNCTION_CONTEXT_MENU_SELECTED,
				strMenuName,
				Integer.toString(lctCFs.size())
		);

		LMInterFace.getInstance().createSecurityCommandRecord(
			ctx,
			strMessage,USMCommonStrings.IDS_APPLICATION_SERVER_COMPONENTS
		);
		LOGGER.info("{}:{}", ctx, strMessage);

		USMAuthorizationHelper.checkAccessForClientThrowExceptionOnFailure(ctx, strMenuName);

		USMMessage responseMsg = BSCentralController.getInstance().syncSecObjsWithCFs(ctx, lctCFs);

		LOGGER.debug("Exiting syncSecObjsWithCFs. Returing Message : {}", responseMsg);

		return responseMsg;
	}

    /**
     * @see com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityServerConfigurationPrivateFacade#synchSecObjsWithServers(com.ossnms.bicnet.bcb.facade.security.ISessionContext, java.util.List)
     */
    @Override
    public USMMessage updateACLForSecurableObjects(
        List securableObjs,
        List domains,
        List failedSecurableObjs,
        boolean assign) {

        
        BSCentralController.getInstance().updateACLForSecurableObjects(
            securableObjs,
            domains,
            failedSecurableObjs,
            assign);
        return null;
    }
}
