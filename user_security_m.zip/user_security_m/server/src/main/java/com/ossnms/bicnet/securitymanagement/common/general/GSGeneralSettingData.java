/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   GSGeneralSettingData
 * Author:      Jogender
 * Substitute	Babu B
 * Created on	13-10-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.ADVISORY_CONFIGURE
 *        : TNMS.DX2.SM.PASSWORD.COMPLEXITY
 * 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.common.general;

import com.ossnms.bicnet.securitymanagement.common.auth.PasswordValidationRulesConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.ldap.LDAPConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.radius.configuration.RadiusConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.sso.SSOConfigurationData;

import java.io.Serializable;
import java.util.Objects;

/**
 * This class holds the data of the general setting transiently.
 */
public class GSGeneralSettingData implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    /**
     * This is the number of days for password change to be happened..
     */
    private int initPasswordChangeInterval;

    /**
     * this is for login expiration time if user is inactive for defined time .
     */
    private int inactivityTimeout;

    /**
     * This time will define the number of minutes before user session timeout that a pop up warning should be shown.
     */
    private int inactivityTimeoutWarningTime;

    /**
     * Advisory message dialog has to be shown or not after login
     */
    private boolean isShowAdvisoryMessage;

    /**
     * Advisory message contents
     */
    private String advisoryMessage;

    /**
     * This is the number of Unsuccessful login attempts after that user account
     * will get deactivated..
     */
    private int deactivationAfterLoginAttempts;

    /**
     * This is inactivity duration after that user account will get
     * deactivated..
     */
    private int deactivationAfterInativity;

    /**
     * Lock out for administrator
     */
    private int adminLockout;

    /**
     * Time period during which automatic re-login is attempted.
     */
    private int reloginTimeout;

    /**
     * Delay between automatic re-login tries.
     */
    private int reloginDelayBetweenTries;
    
    private int expirePasswordWarning;

    private SSOConfigurationData ssoConfigData;

    /**
     *
     */
    private LDAPConfigurationData ldapConfigurationData;

    /**
     *
     */
    private RadiusConfigurationData radiusConfigurationData;

    /**
     * Data structure containing the activation status of all password validation rules.
     */
    private PasswordValidationRulesConfigurationData passwordValidationRulesConfigurationData;

    /**
     * this constructor Sets initial values for the member variables.
     * 
     * @param initPasswordChangeInterval
     *            -number of days for password change to be happened
     * @param inactivityTimeout
     *            -login expiration time if user is inactive for defined time
     * @param isShowAdvisoryMessage
     *            -Advisory message has to be shown or not after login
     * @param advisoryMessage
     *            - Advisory message contents
     * @param deactivationAfterLoginAttempts
     *            -number of Unsuccessful login attempts after that user account
     *            will get deactivated.
     * @param deactivationAfterInativity
     *            -inactivity duration after that user account will get
     *            deactivated.
     * @param adminLockout
     *            -Lock out period for predefined accounts
     * 
     * @param ssoConfigData
     *            - Single Sign-on configuration data
     *
     * @param passwordValidationRulesConfigurationData
     *            - Data structure containing the activation status of all password validation rules
     */
    public GSGeneralSettingData(int initPasswordChangeInterval, int inactivityTimeout, boolean isShowAdvisoryMessage,
                                String advisoryMessage, int deactivationAfterLoginAttempts, int inactivityTimeoutWarningTime,
                                int deactivationAfterInativity, int adminLockout, SSOConfigurationData ssoConfigData,
                                PasswordValidationRulesConfigurationData passwordValidationRulesConfigurationData) {
        this.initPasswordChangeInterval = initPasswordChangeInterval;
        this.inactivityTimeout = inactivityTimeout;
        this.isShowAdvisoryMessage = isShowAdvisoryMessage;
        this.advisoryMessage = advisoryMessage;
        this.deactivationAfterLoginAttempts = deactivationAfterLoginAttempts;
        this.inactivityTimeoutWarningTime = inactivityTimeoutWarningTime;
        this.deactivationAfterInativity = deactivationAfterInativity;
        this.adminLockout = adminLockout;
        this.ssoConfigData = ssoConfigData;
        this.passwordValidationRulesConfigurationData = passwordValidationRulesConfigurationData;
    }

    /**
     * Default constructor
     */
    public GSGeneralSettingData() {
    }

    /**
     * Function to retrieve the String equivalent of this object.
     * 
     * @return java.lang.String The String which is a representation of this
     *         object.
     */
    @Override
    public String toString() {
        StringBuffer objToStr = new StringBuffer();
        objToStr.append("Initial Password Change Interval ").append(this.initPasswordChangeInterval);
        objToStr.append("/n Client Inactivity Time Out ").append(this.inactivityTimeout);
        objToStr.append("/n Max Login Attempts Allowed ").append(this.deactivationAfterLoginAttempts);
        objToStr.append("/n Account Deactivation on inactivities for ").append(this.deactivationAfterInativity);
        objToStr.append("/n User session timeout warning time ").append(this.inactivityTimeoutWarningTime);
        objToStr.append("/n Admin Lock out Period ").append(this.adminLockout);
        objToStr.append("/n Is Advisory Message to be displayed").append(this.isShowAdvisoryMessage);
        objToStr.append("/n Advisory Message ").append(this.advisoryMessage);
        objToStr.append("/n Relogin Timeout ").append(this.reloginTimeout);
        objToStr.append("/n Relogin Delay Between Tries ").append(this.reloginDelayBetweenTries);
        objToStr.append("/n Expire Password Warning ").append(this.expirePasswordWarning);
        
        objToStr.append("/n Single Sign-on ").append(this.ssoConfigData);
        objToStr.append("/n Password Validation Rules ").append(this.passwordValidationRulesConfigurationData);
        return objToStr.toString();
    }

    /**
     * Returns the Lock out period for administrator
     *
     * @return int - Lock out period for administrator
     */
    public int getAdminLockout() {
        return this.adminLockout;
    }

    /**
     * Returns the advisory message for general setting
     *
     * @return String - advisory message contents
     */
    public String getAdvisoryMessage() {
        return this.advisoryMessage;
    }

    /**
     * Returns the inactivity duration after that user account will get
     * deactivated..
     *
     * @return int - inactivity duration after that user account will get
     *         deactivated..
     * 
     */
    public int getDeactivationAfterInativity() {
        return this.deactivationAfterInativity;
    }

    /**
     * Returns the number of Unsuccessful login attempts after that user account
     * will get deactivated.
     *
     * @return int - Number of Unsuccessful login attempts after that user
     *         account will get deactivated.
     * 
     */
    public int getDeactivationAfterLoginAttempts() {
        return this.deactivationAfterLoginAttempts;
    }

    /**
     * retruns the login expiration time if user is inactive for defined time
     *
     * @return int - login expiration time if user is inactive for defined time
     * 
     */
    public int getInactivityTimeout() {
        return this.inactivityTimeout;
    }

    /**
     *
     * @return int - the time before login expiration in which the warning should be shown.
     */
    public int getInactivityTimeoutWarningTime() {
        return inactivityTimeoutWarningTime;
    }

    /**
     * returns the number of days for password change to be happened.
     *
     * @return int - number of days for password change to be happened
     * 
     */
    public int getInitPasswordChangeInterval() {
        return this.initPasswordChangeInterval;
    }

    /**
     * returns the status for displaying advisory message at login time or not.
     *
     * @return boolean - Advisory message has to be displayed if true otherwise
     *         not
     * 
     */
    public boolean isShowAdvisoryMessage() {
        return this.isShowAdvisoryMessage;
    }

    /**
     * Returns the automatic re-login timeout.
     * @return automatic re-login timeout (in minutes)
     */
    public int getReloginTimeout() {
        return reloginTimeout;
    }

    /**
     * Returns the automatic re-login delay between tries.
     * @return automatic re-login delay between tries (in seconds)
     */
    public int getReloginDelayBetweenTries() {
        return reloginDelayBetweenTries;
    }

    /**
     * Set the lock out time for administrator
     * 
     * @param adminLockout - lock out time for administrator
     * @return void
     * 
     */
    public void setAdminLockout(int adminLockout) {
        this.adminLockout = adminLockout;
    }

    /**
     * Set the advisory message contents
     * 
     * @param advisoryMessage
     *            - advisory message contents
     * @return void
     * 
     */
    public void setAdvisoryMessage(String advisoryMessage) {
        this.advisoryMessage = advisoryMessage;
    }

    /**
     * Set the inactivity duration after that user account will get deactivated.
     * 
     * @param deactivationAfterInativity - number of Unsuccessful login attempts after that user
     *        account will get deactivated
     * @return void
     * 
     */
    public void setDeactivationAfterInactivity(int deactivationAfterInativity) {
        this.deactivationAfterInativity = deactivationAfterInativity;
    }

    /**
     * Set the number of Unsuccessful login attempts after that user account
     * will get deactivated.
     * 
     * @param deactivationAfterLoginAttempts - number of Unsuccessful login attempts after that user
     *        account will get deactivated
     * @return void
     * 
     */
    public void setDeactivationAfterLoginAttempts(int deactivationAfterLoginAttempts) {
        this.deactivationAfterLoginAttempts = deactivationAfterLoginAttempts;
    }

    /**
     * Set the expiration time.
     * 
     * @param inactivityTimeout - expiration time
     * @return void
     * 
     */
    public void setInactivityTimeout(int inactivityTimeout) {
        this.inactivityTimeout = inactivityTimeout;
    }

    /**
     * Sets the minutes before user session timeout in which the pop up should be shown.
     *
     * @param inactivityTimeoutWarningTime the time before user session timeout in which the pop up should be shown.
     * @return void
     */
    public void setInactivityTimeoutWarningTime(int inactivityTimeoutWarningTime) {
        this.inactivityTimeoutWarningTime = inactivityTimeoutWarningTime;
    }

    /**
     * Set the number of days for password change to be happened.
     * 
     * @param initPasswordChangeInterval - number of days for password change to be happened
     * @return void
     * 
     */
    public void setInitPasswordChangeInterval(int initPasswordChangeInterval) {
        this.initPasswordChangeInterval = initPasswordChangeInterval;
    }

    /**
     * Set the advisory message status te be displayed or not.
     * 
     * @param showAdvisoryMessage - true if advisory message has to be displayed at the
     *        login time otherwise false.
     * @return void
     * 
     */
    public void setShowAdvisoryMessage(boolean showAdvisoryMessage) {
        this.isShowAdvisoryMessage = showAdvisoryMessage;
    }

    /**
     * Sets the automatic re-login timeout
     * @param reloginTimeout timeout in minutes
     */
    public void setReloginTimeout(int reloginTimeout) {
        this.reloginTimeout = reloginTimeout;
    }

    /**
     * Sets the automatic re-login delay between tries
     * @param reloginDelayBetweenTries delay between tries in seconds
     */
    public void setReloginDelayBetweenTries(int reloginDelayBetweenTries) {
        this.reloginDelayBetweenTries = reloginDelayBetweenTries;
    }
    
    /**
	 * @return the expirePasswordWarning
	 */
	public int getExpirePasswordWarning() {
		return expirePasswordWarning;
	}

	/**
	 * @param expirePasswordWarning the expirePasswordWarning to set
	 */
	public void setExpirePasswordWarning(int expirePasswordWarning) {
		this.expirePasswordWarning = expirePasswordWarning;
	}

	/**
     *
     * @return
     */
    public SSOConfigurationData getSSOConfigurationData() {
        if(this.ssoConfigData == null) {
            this.ssoConfigData = new SSOConfigurationData();
        }
        return this.ssoConfigData;
    }

    /**
     *
     * @param ssoConfigData
     */
    public void setSSOConfigurationData(SSOConfigurationData ssoConfigData) {
        this.ssoConfigData = ssoConfigData;
    }

    /**
     *
     * @return
     */
    public LDAPConfigurationData getLdapConfigurationData() {
        if(this.ldapConfigurationData == null){
            this.ldapConfigurationData = new LDAPConfigurationData();
        }
        return ldapConfigurationData;
    }

    /**
     *
     * @param ldapConfigurationData
     */
    public void setLdapConfigurationData(LDAPConfigurationData ldapConfigurationData) {
        this.ldapConfigurationData = ldapConfigurationData;
    }

    /**
     * Returns a data structure containing the activation status of all password validation rules.
     *
     * @return a data structure containing the activation status of all password validation rules.
     */
    public PasswordValidationRulesConfigurationData getPasswordValidationRulesConfigurationData() {
        if(this.passwordValidationRulesConfigurationData == null){
            this.passwordValidationRulesConfigurationData = new PasswordValidationRulesConfigurationData();
        }
        return passwordValidationRulesConfigurationData;
    }

    /**
     * Sets a new data structure containing the activation status of all password validation rules.
     *
     * @param passwordValidationRulesConfigurationData the new data structure containing the activation status of all
     *                                                 password validation rules.
     */
    public void setPasswordValidationRulesConfigurationData(PasswordValidationRulesConfigurationData passwordValidationRulesConfigurationData) {
        this.passwordValidationRulesConfigurationData = passwordValidationRulesConfigurationData;
    }

    /**
     *
     * @return
     */
    public RadiusConfigurationData getRadiusConfigurationData() {
        return radiusConfigurationData;
    }

    /**
     *
     * @param radiusConfigurationData
     */
    public void setRadiusConfigurationData(RadiusConfigurationData radiusConfigurationData) {
        this.radiusConfigurationData = radiusConfigurationData;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GSGeneralSettingData that = (GSGeneralSettingData) o;
        return getInitPasswordChangeInterval() == that.getInitPasswordChangeInterval() &&
                getInactivityTimeout() == that.getInactivityTimeout() &&
                getInactivityTimeoutWarningTime() == that.getInactivityTimeoutWarningTime() &&
                isShowAdvisoryMessage() == that.isShowAdvisoryMessage() &&
                getDeactivationAfterLoginAttempts() == that.getDeactivationAfterLoginAttempts() &&
                getDeactivationAfterInativity() == that.getDeactivationAfterInativity() &&
                getAdminLockout() == that.getAdminLockout() &&
                getReloginTimeout() == that.getReloginTimeout() &&
                getReloginDelayBetweenTries() == that.getReloginDelayBetweenTries() &&
                getExpirePasswordWarning() == that.getExpirePasswordWarning() &&
                Objects.equals(getAdvisoryMessage(), that.getAdvisoryMessage()) &&
                Objects.equals(ssoConfigData, that.ssoConfigData) &&
                Objects.equals(getLdapConfigurationData(), that.getLdapConfigurationData()) &&
                Objects.equals(getRadiusConfigurationData(), that.getRadiusConfigurationData()) &&
                Objects.equals(getPasswordValidationRulesConfigurationData(), that.getPasswordValidationRulesConfigurationData());
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                getInitPasswordChangeInterval(),
                getInactivityTimeout(),
                getInactivityTimeoutWarningTime(),
                isShowAdvisoryMessage(),
                getAdvisoryMessage(),
                getDeactivationAfterLoginAttempts(),
                getDeactivationAfterInativity(),
                getAdminLockout(),
                getReloginTimeout(),
                getReloginDelayBetweenTries(),
                getExpirePasswordWarning(),
                ssoConfigData,
                getLdapConfigurationData(),
                getRadiusConfigurationData(),
                getPasswordValidationRulesConfigurationData()
        );
    }
}