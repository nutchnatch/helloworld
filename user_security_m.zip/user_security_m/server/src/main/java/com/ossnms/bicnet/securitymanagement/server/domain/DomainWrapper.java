package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.domain.IUSMDomainDao;
import com.ossnms.bicnet.securitymanagement.api.persistence.dao.domain.IUSMDomainMappingDao;
import com.ossnms.bicnet.securitymanagement.api.server.domain.IDomainWrapper;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.persistence.model.domain.USMDomain;
import com.ossnms.bicnet.securitymanagement.persistence.model.domain.USMDomainMapping;
import org.apache.log4j.Logger;

import javax.ejb.EJB;
import javax.ejb.EJBTransactionRolledbackException;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.naming.event.NamingEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * created on 2/9/2014
 *
 * Responsible for handling USM calls and retrieving and storing data using
 * USM DAOs. This class abstracts all database operations for subsystem DC.
 */
@Stateless(name = "IDomainWrapper")
@Local
public class DomainWrapper implements IDomainWrapper {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger logger = Logger.getLogger(DomainWrapper.class);

    /**
     * Constants
     */
    private static final String DEBUG_ENTER_CREATE_DOMAIN = "CreateDomain() - Enter";
    private static final String DEBUG_EXIT_CREATE_DOMAIN = "CreateDomain() - Exit";
    private static final String DEBUG_ENTER_CREATE_MAPPING = "CreateMapping() - Enter";
    private static final String DEBUG_EXIT_CREATE_MAPPING = "CreateMapping() - Exit";
    private static final String DEBUG_ENTER_DELETE_DOMAIN = "DeleteDomain() - Enter";
    private static final String DEBUG_EXIT_DELETE_DOMAIN = "DeleteDomain() - Exit";
    private static final String DEBUG_ENTER_DELETE_MAPPING = "DeleteMapping() - Enter";
    private static final String DEBUG_EXIT_DELETE_MAPPING = "DeleteMapping() - Exit";
    private static final String DEBUG_ENTER_MODIFY_DOMAIN = "modifyDomain() - Enter";
    private static final String DEBUG_EXIT_MODIFY_DOMAIN = "modifyDomain() - Exit";
    private static final String DEBUG_ENTER_MODIFY_MAPPING = "modifyMapping() - Enter";
    private static final String DEBUG_EXIT_MODIFY_MAPPING = "modifyMapping() - Exit";
    private static final String DEBUG_ENTER_POPULATE_DOMAIN = "populateDomainElement() - Enter";
    private static final String DEBUG_EXIT_POPULATE_DOMAIN = "populateDomainElement() - Exit";
    private static final String DEBUG_ENTER_ALL_DOMAINS = "getAllDomains() - Enter";
    private static final String DEBUG_EXIT_ALL_DOMAINS = "getAllDomains() - Exit";
    private static final String DEBUG_ENTER_ALL_DOMAIN_MAPPINGS = "getAllMappings() - Enter";
    private static final String DEBUG_EXIT_ALL_DOMAIN_MAPPINGS = "getAllMappings() - Exit";
    private static final String DEBUG_ENTER_MAPPING_EXISTS = "isDCDomainMappingExist() - Enter";
    private static final String DEBUG_EXIT_MAPPING_EXISTS = "isDCDomainMappingExist() - Exit";

    private static final String WARN_NULL_DOMAIN = "Invalid null domain passed, junk caller";
    private static final String WARN_NULL_MAPPING = "Invalid null mapping passed, junk caller";

    private static final String INFO_FORMAT_DOMAIN_CREATED = "Domain %s created successfully.";
    private static final String INFO_FORMAT_DOMAIN_DELETED = "Domain %s deleted successfully.";
    private static final String INFO_FORMAT_DOMAIN_MODIFIED = "Domain %s modified successfully.";
    private static final String INFO_FORMAT_DOMAIN_MAPPING_CREATED = "Mapping %s created successfully.";
    private static final String INFO_FORMAT_DOMAIN_MAPPING_DELETED = "Mapping %s deleted successfully.";
    private static final String INFO_FORMAT_DOMAIN_MAPPING_MODIFIED = "Mapping %s modified successfully.";

    private static final String ERROR_FORMAT_DOMAIN_CREATION = "Domain %s could not be created, an error occurred.";
    private static final String ERROR_FORMAT_DOMAIN_DELETION = "Domain %s could not be deleted, an error occurred.";
    private static final String ERROR_FORMAT_DOMAIN_MODIFICATION = "Domain %s could not be modified, an error occurred.";
    private static final String ERROR_FORMAT_DOMAIN_MAPPING_CREATION = "Mapping %s could not be created, an error occurred.";
    private static final String ERROR_FORMAT_DOMAIN_MAPPING_MODIFICATION = "Mapping %s could not be modified, an error occurred.";
    private static final String ERROR_FORMAT_DOMAIN_MAPPING_DELETION = "Mapping %s could not be deleted, an error occurred.";

    @EJB
    @SuppressWarnings("unassigned")
    private IUSMDomainDao usmDomainDao;

    @EJB
    @SuppressWarnings("unassigned")
    private IUSMDomainMappingDao usmDomainMappingDao;

    @Override
    public boolean createDomain(DCDomainData domain) {
        logger.debug(DEBUG_ENTER_CREATE_DOMAIN);

        //Check the precondition, since this is a precondition check it is
        //not necessarily traced as an error
        if (null == domain) {
            logger.warn(WARN_NULL_DOMAIN);
            return false;
        }

        //Fill up the domain data as required
        USMDomain usmDomain = populateNewUSMDomain(domain);

        try{
            usmDomainDao.save(usmDomain);
        }catch(EJBTransactionRolledbackException e){
            logger.error(e.getMessage());
        }

        boolean retVal = false;

        if(usmDomain != null && usmDomain.getId() != null) {
            // Domain was successfully created
            logger.info(String.format(INFO_FORMAT_DOMAIN_CREATED, domain));

            //set the id generated by the database
            domain.setDomainID(usmDomain.getId());
            retVal = true;
        } else {
            logger.error(String.format(ERROR_FORMAT_DOMAIN_CREATION, domain));
        }

        logger.debug(DEBUG_EXIT_CREATE_DOMAIN);
        return retVal;
    }

    @Override
    public boolean deleteDomain(DCDomainData domain) {
        logger.debug(DEBUG_ENTER_DELETE_DOMAIN);

        if (null == domain) {
            logger.warn(WARN_NULL_DOMAIN);
            return false;
        }

        boolean retVal = false;

        try{
            usmDomainDao.delete(domain.getDomainID());
            retVal = true;
        }catch(EJBTransactionRolledbackException e){
            logger.error(e.getMessage());
        }

        if(retVal) {
            // Domain was successfully deleted
            logger.info(String.format(INFO_FORMAT_DOMAIN_DELETED, domain));
        } else {
            logger.error(String.format(ERROR_FORMAT_DOMAIN_DELETION, domain));
        }
        logger.debug(DEBUG_EXIT_DELETE_DOMAIN);
        return retVal;
    }

    @Override
    public boolean modifyDomain(DCDomainData domain) {
        logger.debug(DEBUG_ENTER_MODIFY_DOMAIN);

        if(null == domain) {
            logger.warn(WARN_NULL_DOMAIN);
            return false;
        }

        boolean retVal = false;
        //We can only modify the description of this domain, nothing else is allowed
        USMDomain usmDomain;

        try {
            usmDomain = usmDomainDao.findById(domain.getDomainID());
            if(usmDomain != null){
                usmDomain.setDescription(domain.getDomainDescr());
                usmDomainDao.save(usmDomain);
                retVal = true;
            }
        }catch(EJBTransactionRolledbackException e){
            logger.error(e.getMessage());
        }

        if(retVal) {
            // Domain was successfully modified
            logger.info(String.format(INFO_FORMAT_DOMAIN_MODIFIED, domain));
        } else {
            logger.error(String.format(ERROR_FORMAT_DOMAIN_MODIFICATION, domain));
        }

        logger.debug(DEBUG_EXIT_MODIFY_DOMAIN);
        return retVal;
    }

    @Override
    public boolean createMapping(DCDomainMapping mapping) {
        logger.debug(DEBUG_ENTER_CREATE_MAPPING);

        if (null == mapping) {
            logger.debug(WARN_NULL_DOMAIN);
            return false;
        }

        boolean retVal = false;
        //Fill the mapping data
        USMDomainMapping domainMapping = populateNewUSMDomainMapping(mapping);

        try{
            usmDomainMappingDao.save(domainMapping);
        }catch(EJBTransactionRolledbackException e){
            logger.error(e.getMessage());
        }

        if(domainMapping != null && domainMapping.getId() != null) {
            logger.info(String.format(INFO_FORMAT_DOMAIN_MAPPING_CREATED, mapping));

            //set the id generated by the database
            mapping.setId(domainMapping.getId());
            mapping.setName(domainMapping.getName());
            retVal = true;
        } else {
            logger.error(String.format(ERROR_FORMAT_DOMAIN_MAPPING_CREATION, mapping));
        }

        logger.debug(DEBUG_EXIT_CREATE_MAPPING);
        return retVal;
    }

    @Override
    public boolean modifyMapping(DCDomainMapping mapping) {
        logger.debug(DEBUG_ENTER_MODIFY_MAPPING);

        if (null == mapping) {
            logger.debug(WARN_NULL_DOMAIN);
            return false;
        }

        boolean retVal = false;
        USMDomainMapping usmDomainMapping;
        try {
            usmDomainMapping = usmDomainMappingDao.findById(mapping.getId());
            usmDomainMapping.setPolicyId(mapping.getPolicyID());

            usmDomainMappingDao.save(usmDomainMapping);
            retVal = true;
        }catch(EJBTransactionRolledbackException | NullPointerException e){
            logger.error(e.getMessage());
        }

        if(retVal) {
            // Domain was successfully deleted
            logger.info(String.format(INFO_FORMAT_DOMAIN_MAPPING_MODIFIED, mapping));
        } else {
            logger.error(String.format(ERROR_FORMAT_DOMAIN_MAPPING_MODIFICATION, mapping));
        }
        logger.debug(DEBUG_EXIT_MODIFY_MAPPING);
        return retVal;
    }

    @Override
    public boolean deleteMapping(DCDomainMapping mapping) {
        logger.debug(DEBUG_ENTER_DELETE_MAPPING);

        if (mapping == null) {
            logger.warn(WARN_NULL_MAPPING);
            return false;
        }

        boolean retVal = false;

        try{
            usmDomainMappingDao.delete(mapping.getId());
            retVal = true;
        }catch(EJBTransactionRolledbackException e){
            logger.error(e.getMessage());
        }

        if(retVal) {
            // Domain was successfully deleted
            logger.info(String.format(INFO_FORMAT_DOMAIN_MAPPING_DELETED, mapping));
        } else {
            logger.error(String.format(ERROR_FORMAT_DOMAIN_MAPPING_DELETION, mapping));
        }
        logger.debug(DEBUG_EXIT_DELETE_MAPPING);
        return retVal;
    }

    @Override
    public List<DCDomainData> getAllDomains() {
        logger.debug(DEBUG_ENTER_ALL_DOMAINS);

        List<DCDomainData> dcDomains = new ArrayList<>();
        List<USMDomain> usmDomains = usmDomainDao.findAll();

        for(USMDomain domain : usmDomains){
            DCDomainData domainData = new DCDomainData();
            domainData.setDomainID(domain.getId());
            domainData.setDomainDescr(domain.getDescription());
            domainData.setDomainName(domain.getName());
            domainData.setDomainUID(domain.getCreationId());

            dcDomains.add(domainData);
        }

        logger.debug(DEBUG_EXIT_ALL_DOMAINS);
        return dcDomains;
    }

    @Override
    public List<DCDomainMapping> getAllMappings() {
        logger.debug(DEBUG_ENTER_ALL_DOMAIN_MAPPINGS);

        List<DCDomainMapping> dcMappings = new ArrayList<>();
        List<USMDomainMapping> usmDomainMappings = usmDomainMappingDao.findAll();

        for(USMDomainMapping mapping : usmDomainMappings){
            DCDomainMapping  domainMapping = new DCDomainMapping();
            domainMapping.setId(mapping.getId());
            domainMapping.setDomainID(mapping.getDomainId());
            domainMapping.setName(mapping.getName());
            domainMapping.setPolicyID(mapping.getPolicyId());
            domainMapping.setUserGroup(mapping.getUserGroup());

            dcMappings.add(domainMapping);
        }

        logger.debug(DEBUG_EXIT_ALL_DOMAIN_MAPPINGS);
        return dcMappings;
    }

    @Override
    public DCDomainData loadDomain(NamingEvent namingEvent) {
        //since we'll stop working with LDAP, these events will no longer be received.
        return null;
    }

    @Override
    public DCDomainMapping loadDomainMapping(NamingEvent namingEvent) {
        //since we'll stop working with LDAP, these events will no longer be received.
        return null;
    }

    @Override
    public boolean isDCDomainMappingExist(DCDomainMapping domainMapping) {
        logger.debug(DEBUG_ENTER_MAPPING_EXISTS);
        List<DCDomainMapping> domainMappings = getAllMappings();

        //The 'contains' method will check for equality, taking advantage of the 'equals' method
        //implementation within DCDomainMapping
        boolean returnVal = domainMappings.contains(domainMapping);

        logger.debug(DEBUG_EXIT_MAPPING_EXISTS);
        return returnVal;
    }

    @Override
    public boolean isPolicyMapped(int policyId) {
        //check if policy is mapped
        return usmDomainMappingDao.findByPolicy(policyId).size() > 0;
    }

    @Override
    public boolean isUserGroupMapped(String userGroupName) {
        //check if group is mapped
        return usmDomainMappingDao.findByUserGroup(userGroupName).size() > 0;
    }

    private USMDomain populateNewUSMDomain(DCDomainData domain){
        logger.debug(DEBUG_ENTER_POPULATE_DOMAIN);

        USMDomain retElement = new USMDomain();
        retElement.setName(domain.getDomainName());
        retElement.setDescription(domain.getDomainDescr());
        retElement.setCreationId(domain.getDomainUID());

        logger.debug(DEBUG_EXIT_POPULATE_DOMAIN);

        return retElement;
    }

    private USMDomainMapping populateNewUSMDomainMapping(DCDomainMapping mapping){
        //Fill the mapping data
        USMDomainMapping domainMapping = new USMDomainMapping();
        domainMapping.setUserGroup(mapping.getUserGroup());
        domainMapping.setDomainId(mapping.getDomainID());
        domainMapping.setPolicyId(mapping.getPolicyID());
        domainMapping.setName(mapping.getUserGroup() + "-" + mapping.getDomainID());

        return domainMapping;
    }
}
