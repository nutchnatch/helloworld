package com.ossnms.bicnet.securitymanagement.common.general.ldap;

import com.ossnms.bicnet.securitymanagement.common.general.ResponseMessage;
import com.ossnms.bicnet.securitymanagement.common.general.ResponseType;

/**
 *
 */
public final class LDAPSettingsResponseMessage extends ResponseMessage {

    private static final long serialVersionUID = -2875572263458533974L;

    public LDAPSettingsResponseMessage() {
    }

    public LDAPSettingsResponseMessage(ResponseType type, String message, ResponseMessage... messages) {
        super(type, message, messages);
    }

    public LDAPSettingsResponseMessage(ResponseType type, String messageFormat, String... params) {
        super(type, messageFormat, params);
    }

    public LDAPSettingsResponseMessage(ResponseType type, String message) {
        super(type, message);
    }
}
