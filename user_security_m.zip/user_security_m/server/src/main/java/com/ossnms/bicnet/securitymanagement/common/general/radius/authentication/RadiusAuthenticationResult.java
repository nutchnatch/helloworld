package com.ossnms.bicnet.securitymanagement.common.general.radius.authentication;

import com.axlradius.radclient4.attributes.AttributeList;

/**
 *
 */
public class RadiusAuthenticationResult {

    private RadiusAuthenticationResponse response;
    private AttributeList attributeList;

    public RadiusAuthenticationResult(){}

    /**
     *
     * @return
     */
    public RadiusAuthenticationResponse getResponse() {
        return response;
    }

    /**
     *
     * @param response
     * @return
     */
    public RadiusAuthenticationResult setResponse(RadiusAuthenticationResponse response) {
        this.response = response;
        return this;
    }

    /**
     *
     * @return
     */
    public AttributeList getAttributeList() {
        return attributeList;
    }

    /**
     *
     * @param attributeList
     * @return
     */
    public RadiusAuthenticationResult setAttributeList(AttributeList attributeList) {
        this.attributeList = attributeList;
        return this;
    }

    /**
     *
     * @return
     */
    public String toString(){
        return String.format(
                "Response %s, with %d on the Attributes List.",
                response == null ? "" : response,
                attributeList == null ? 0 : attributeList.size()
        );
    }
}
