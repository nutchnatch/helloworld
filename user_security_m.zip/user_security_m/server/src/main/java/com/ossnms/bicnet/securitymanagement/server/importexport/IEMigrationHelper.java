/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	IEImportExportPOJOImpl
 * Author      	Muyeen
 * Substitute	Asif
 * Created on	10-01-2005
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Asif			CF000427 - Implementation of the XML import mechanism needed for the migration process
 * 17-Aug-2005	Babu			CF002854 - user migration does not work
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.importexport;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.common.domain.DCIEDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;
import com.ossnms.bicnet.securitymanagement.common.importexport.IEDataObject;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAStatus;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAIEUser;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAIEUserGroup;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAStatus;
import com.ossnms.bicnet.securitymanagement.server.domain.DCSubsystemSAP;
import com.ossnms.bicnet.securitymanagement.server.policy.PASubsystemSAP;
import com.ossnms.bicnet.securitymanagement.server.useradministration.UASubsystemSAP;
import com.ossnms.bicnet.securitymanagement.server.util.USMUtils;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * Helper class to perform the Migration of users.
 */
final class IEMigrationHelper {
    private static final int POLICY = 1;
    private static final int USER_GROUPS = 2;
    private static final int MAPPINGS = 3;
    private final static String GLOBAL = "GLOBAL";
    /**
     * Data member to hold the Logger that should be used.
     */
    private static final Logger LOGGER = Logger.getLogger(IEMigrationHelper.class);

    private IEMigrationHelper(){
    }

    /**
     * Function that should be called for the migration of users.
     * 
     * @param ctx
     *            The Context of the Operator who has started the migration
     * @param securityData
     *            List of Users
     * @param bReplace
     *            Indicates whether it is replace mode or not.
     */
    static void migrateUsersIfNeeded(ISessionContext ctx, List<IEDataObject> securityData, boolean bReplace) {
        LOGGER.debug("migrateUsersIfNeeded() Entry");

        List lst = getListOfUsersToBeMigrated(securityData, bReplace);
        Set st = getSetOfUserClassEnums(lst);
        createPoliciesUGsMappingsAsNeededForMigration(ctx, st, lst);

        for (Iterator itEnums = st.iterator(); itEnums.hasNext();) {
            IEMigrationEnum en = (IEMigrationEnum) itEnums.next();
            List lstUsers = getListOfUsersOfPassedEnumType(lst, en);
            assignUsersToUserGroupEnum(ctx, en, lstUsers);
        }

        LOGGER.debug("migrateUsersIfNeeded() Exit");

    }

    /**
     * Function to assign a list of users to a particular UG
     * 
     * @param ctx
     *            The Context of the user who has started the migration.
     * @param en
     *            The enum which has to be used for UG
     * @param lstUsers
     *            The List of Users to be assigned.
     */
    private static void assignUsersToUserGroupEnum(ISessionContext ctx, IEMigrationEnum en, List<IEDataObject> lstUsers) {
        LOGGER.debug("assignUsersToUserGroupEnum() Entry");

        String strDesc = UASubsystemSAP.getDescriptionForUserGroupID(en.getUserGroupName());

        List<String> lstUsrs = UASubsystemSAP.getListOfUsersForGroup(en.getUserGroupName());
        for (Iterator<IEDataObject> itObjs = lstUsers.iterator(); itObjs.hasNext();) {
            IEDataObject ieObj = itObjs.next();
            UAIEUser usr = (UAIEUser) ieObj.getDataObject();
            String strUsrID = usr.getUserId().toLowerCase();
            // Exclude from the list of users those that are classified as USMConstants.INTERNAL_USERS (e.g. PTC)
            if (!lstUsrs.contains(strUsrID) && !USMUtils.getUsersToBeHidden().contains(strUsrID)) {
                lstUsrs.add(usr.getUserId());
            }
        }

        UAIEUserGroup ug = new UAIEUserGroup(en.getUserGroupName(), strDesc, lstUsrs);
        IEDataObject ieObj = new IEDataObject();
        ieObj.setDataObject(ug);
        ieObj.setErrorString("");
        List<IEDataObject> lst = new ArrayList<IEDataObject>();
        lst.add(ieObj);

        UASubsystemSAP.importUserGroups(ctx, lst, true);
        String strError = ieObj.getErrorString();
        if ((strError != null) && (strError.length() > 0)) {
            LOGGER.error("Error while creating the User Group. " + strError);
        }

        for (Iterator itObjs = lstUsers.iterator(); itObjs.hasNext();) {
            IEDataObject obj = (IEDataObject) itObjs.next();
            obj.setErrorString(strError);
        }
        
        LOGGER.debug("assignUsersToUserGroupEnum() Exit");
    }

    /**
     * Function to get a List of Users who belong to the same User Class which is passed.
     * 
     * @param lst
     *            List of all the Users
     * @param en
     *            The Enum which denotes which the User Class is
     * @return List List containing all the Users of a particular type.
     */
    private static List getListOfUsersOfPassedEnumType(List lst, IEMigrationEnum en) {
        LOGGER.debug("getListOfUsersOfPassedEnumType() Entry");

        List lstPassedUsers = new ArrayList();
        for (Iterator itUsrs = lst.iterator(); itUsrs.hasNext();) {
            IEDataObject ieObj = (IEDataObject) itUsrs.next();
            UAIEUser usr = (UAIEUser) ieObj.getDataObject();
            String strUC = usr.getUserClass();
            IEMigrationEnum enUsr = IEMigrationEnum.getEnumForUserClassName(strUC);
            if (enUsr.equals(en)) {
                lstPassedUsers.add(ieObj);
            }
        }
        LOGGER.debug("getListOfUsersOfPassedEnumType() Exit");

        return lstPassedUsers;
    }

    /**
     * Helper function that will look through the list that is passed and find out the user for which we can continue
     * with the Migration.
     * 
     * @param lst
     * @return
     */
    private static List getListOfUsersToBeMigrated(List<IEDataObject> lst, boolean bReplace) {
        LOGGER.debug("getListOfUsersToBeMigrated() Entry");

        List<IEDataObject> lstToBeMigratedUsers = new ArrayList<IEDataObject>();
        for (Iterator<IEDataObject> itUsrs = lst.iterator(); itUsrs.hasNext();) {
            IEDataObject ieObject = itUsrs.next();
            UAIEUser usr = (UAIEUser) ieObject.getDataObject();
            String strError = ieObject.getErrorString();
            if ((strError != null) && ((strError.length() == 0) || strError.equals(UAStatus.getErrorString(UAStatus.USER_IMPORTED_WITH_WARNINGS)))) {
                String strUC = usr.getUserClass();
                if ((strUC != null) && (strUC.length() != 0)) {
                    IEMigrationEnum en = IEMigrationEnum.getEnumForUserClassName(strUC);
                    if (en != null) {
                        lstToBeMigratedUsers.add(ieObject);
                    } else {
                        String strReturnError = "Passed value for User Class is not recognized : " + strUC;
                        LOGGER.error(strReturnError);
                        ieObject.setErrorString(strReturnError);
                    }
                } else {
                    if (LOGGER.isDebugEnabled()) {
                        LOGGER.debug("Migration not selected by operator for user : " + usr + " reason : "+ strError);
                    }
                }
            } else {
                if (LOGGER.isDebugEnabled()) {
                    LOGGER.debug("Migration not done due to error for user : " + usr + " reason : "+ strError);
                }
            }
        }
        LOGGER.debug("getListOfUsersToBeMigrated() Exit");

        return lstToBeMigratedUsers;
    }

    /**
     * Helper function to create all the Policies as needed only once. This is to avoid the multiple calls that would
     * have to be made if we create Policies per user basis.
     * 
     * @param ctx
     *            Context of the operator who has started the Migration
     * @param st
     *            The Set of Enums
     * @param lst
     *            The List of Users who are being migrated.
     */
    private static void createPoliciesUGsMappingsAsNeededForMigration(ISessionContext ctx, Set st, List lst) {
        LOGGER.debug("createPoliciesUGsMappingsAsNeededForMigration() Entry");

        createPoliciesAsNeeded(ctx, st, lst);
        createUserGroupsAsNeeded(ctx, st, lst);
        createMappingsAsNeeded(ctx, st, lst);

        LOGGER.debug("createPoliciesUGsMappingsAsNeededForMigration() Exit");
    }

    /**
     * Helper function to get a Set of the Enums for the Users
     * 
     * @param lst
     *            The List of Users
     * @return Set Set containing the Enums
     */
    private static Set getSetOfUserClassEnums(List lst) {
        LOGGER.debug("getSetOfUserClassEnums() Entry");

        // First of all get a Set of all the Policies Enums which need to be created
        Set st = new HashSet();
        for (Iterator itUsrs = lst.iterator(); itUsrs.hasNext();) {
            IEDataObject ieObject = (IEDataObject) itUsrs.next();
            UAIEUser usr = (UAIEUser) ieObject.getDataObject();
            String strUC = usr.getUserClass();
            IEMigrationEnum en = IEMigrationEnum.getEnumForUserClassName(strUC);
            st.add(en);
        }
        LOGGER.debug("getSetOfUserClassEnums() Exit");

        return st;
    }

    /**
     * Helper function to create all the policies that are needed for the migration
     * 
     * @param ctx
     *            Context of the operator who has started the migration
     * @param setEnums
     *            The Set containing the enums of User Classes to be migrated
     * @param lst
     *            The List of Users who are being migrated.
     */
    private static void createPoliciesAsNeeded(ISessionContext ctx, Set setEnums, List lst) {
        LOGGER.debug("createPoliciesAsNeeded() Entry");

        List vecMenus = new ArrayList();
        List<IEDataObject> lstPolicies = new ArrayList<IEDataObject>();
        for (Iterator itEnums = setEnums.iterator(); itEnums.hasNext();) {
            IEMigrationEnum obj = (IEMigrationEnum) itEnums.next();
            IEDataObject ieObj = new IEDataObject();
            PAPolicyData pol = new PAPolicyData(-1, obj.getPolicyName(), "", -1, -1);
//            PAPolicyData pol = new PAPolicyData(-1, obj.getPolicyName(), "", vecMenus, -1, -1);
            ieObj.setDataObject(pol);
            ieObj.setErrorString("");
            lstPolicies.add(ieObj);
        }
        try {
            PASubsystemSAP.importPolicies(ctx, lstPolicies, false);
            final String strExists = PAStatus.S_POLICY_ALREADY_EXISTS.getErrorString();
            final String strNotRecoMenus = PAStatus.S_POLICY_CONTAINS_UNRECOG_MENUS.getErrorString();
            String[] arrAllowed = { strExists, strNotRecoMenus };
            removeUsersDueToFailedDependencyCreation(lstPolicies, lst, arrAllowed, POLICY);
        } catch (BcbSecurityException e) {
            LOGGER.error(e);
        }

        LOGGER.debug("createPoliciesAsNeeded() Exit");
    }

    /**
     * Helper function to remove all those users which could not be migrated due to failed dependency
     * 
     * @param lstDepenObjs
     *            List of Dependecy Objects
     * @param lstUsrs
     *            List of Users
     * @param allowedErr
     *            Array of Allowed Error messages
     * @param type
     *            Type of migration
     */
    private static void removeUsersDueToFailedDependencyCreation(List lstDepenObjs, List lstUsrs, String[] allowedErr, int type) {
        LOGGER.debug("removeUsersDueToFailedDependencyCreation() Entry");

        for (Iterator itDepObj = lstDepenObjs.iterator(); itDepObj.hasNext();) {
            IEDataObject depObj = (IEDataObject) itDepObj.next();
            String strDepError = depObj.getErrorString();
            boolean bAllowedError = false;
            for (int idx = 0; idx < allowedErr.length; idx++) {
                String strErr = allowedErr[idx];
                if ((strErr.compareToIgnoreCase(strDepError) == 0) || (strDepError.length() == 0)) {
                    bAllowedError = true;
                    break;
                }
            }

            if (bAllowedError != true) {
                IEMigrationEnum en = null;
                switch (type) {
                case POLICY: {
                    PAPolicyData pol = (PAPolicyData) depObj.getDataObject();
                    String strName = pol.getPolicyName();
                    en = getEnumGivenPolicyName(strName);
                    break;
                }
                case USER_GROUPS: {
                    UAIEUserGroup ug = (UAIEUserGroup) depObj.getDataObject();
                    String strName = ug.getName();
                    en = getEnumGivenUGName(strName);
                    break;
                }
                case MAPPINGS: {
                    DCIEDomainMapping maping = (DCIEDomainMapping) depObj.getDataObject();
                    String strName = maping.getPolicyName();
                    en = getEnumGivenPolicyName(strName);
                    break;
                }
                }
                List lst = getListOfUsersOfPassedEnumType(lstUsrs, en);
                for (Iterator itUsrs = lst.iterator(); itUsrs.hasNext();) {
                    IEDataObject obj = (IEDataObject) itUsrs.next();
                    obj.setErrorString(strDepError);
                    lstUsrs.remove(obj);
                }
            }
        }
        LOGGER.debug("removeUsersDueToFailedDependencyCreation() Exit");
    }

    /**
     * Helper function to create all the UGs that are needed for the migration
     * 
     * @param ctx
     *            Context of the operator who has started the migration
     * @param setEnums
     *            The Set containing the enums of User Classes to be migrated
     * @param lst
     *            The List of Users who are being migrated.
     */
    private static void createUserGroupsAsNeeded(ISessionContext ctx, Set setEnums, List lst) {
        LOGGER.debug("createUserGroupsAsNeeded() Entry");

        List lstUGs = new ArrayList();
        List lstUsers = new ArrayList();
        for (Iterator itEnums = setEnums.iterator(); itEnums.hasNext();) {
            IEMigrationEnum obj = (IEMigrationEnum) itEnums.next();
            IEDataObject ieObj = new IEDataObject();
            UAIEUserGroup ug = new UAIEUserGroup(obj.getUserGroupName(), "", lstUsers);
            ieObj.setDataObject(ug);
            ieObj.setErrorString("");
            lstUGs.add(ieObj);
        }
        UASubsystemSAP.importUserGroups(ctx, lstUGs, false);
        final String strExists = new UAStatus(UAStatus.S_USERGROUP_ALREADY_EXISTS).getErrorString();
        final String strNotReco = new UAStatus(UAStatus.S_USERGROUP_CAN_BE_CREATED_EVEN_USERS_NOT_VALID).getErrorString();
        String[] arrAllowed = { strExists, strNotReco };
        removeUsersDueToFailedDependencyCreation(lstUGs, lst, arrAllowed, USER_GROUPS);
        LOGGER.debug("createUserGroupsAsNeeded() Exit");
    }

    /**
     * Helper function to create all the Mappings that are needed for the migration
     * 
     * @param ctx
     *            Context of the operator who has started the migration
     * @param setEnums
     *            The Set containing the enums of User Classes to be migrated
     * @param list
     *            The List of Users who are being migrated.
     */
    private static void createMappingsAsNeeded(ISessionContext ctx, Set setEnums, List list) {
        LOGGER.debug("createMappingsAsNeeded() Entry");

        
        List lst = new ArrayList();
        for (Iterator itEnums = setEnums.iterator(); itEnums.hasNext();) {
            IEMigrationEnum obj = (IEMigrationEnum) itEnums.next();
            IEDataObject ieObj = new IEDataObject();
            DCIEDomainMapping mapping = new DCIEDomainMapping(GLOBAL, obj.getUserGroupName(), obj.getPolicyName());
            ieObj.setDataObject(mapping);
            ieObj.setErrorString("");
            lst.add(ieObj);
        }

        DCSubsystemSAP.importMappings(ctx, lst, false);
        String strExact = DCMessages.getInstance().getString(DCMessages.DC_ERROR_DUPLICATE_MAPPING);
        String[] arrAllowed = { strExact };
        removeUsersDueToFailedDependencyCreation(lst, list, arrAllowed, MAPPINGS);
        LOGGER.debug("createMappingsAsNeeded() Exit");
    }

    /**
     * Helper function to get the Enum that is associated with a Policy Name
     * 
     * @param strPolName
     *            The Name of the Policy
     * @return IEMigrationEnum Enum associated with Policy
     */
    private static IEMigrationEnum getEnumGivenPolicyName(String strPolName) {
        LOGGER.debug("getEnumGivenPolicyName() Entry");
        
        List lst = IEMigrationEnum.getListOfAllEnums();
        IEMigrationEnum retEnum = null;
        for (Iterator itEnums = lst.iterator(); itEnums.hasNext();) {
            IEMigrationEnum en = (IEMigrationEnum) itEnums.next();
            if (en.getPolicyName().compareToIgnoreCase(strPolName) == 0) {
                retEnum = en;
                break;
            }
        }
        LOGGER.debug("getEnumGivenPolicyName() Exit");
        
        return retEnum;
    }

    /**
     * Helper function to get the Enum that is associated with a UG Name
     * 
     * @param strUGName
     *            The Name of the Policy
     * @return IEMigrationEnum Enum associated with Policy
     */
    private static IEMigrationEnum getEnumGivenUGName(String strUGName) {
        LOGGER.debug("getEnumGivenUGName() Entry");
        
        List lst = IEMigrationEnum.getListOfAllEnums();
        IEMigrationEnum retEnum = null;
        for (Iterator itEnums = lst.iterator(); itEnums.hasNext();) {
            IEMigrationEnum en = (IEMigrationEnum) itEnums.next();
            if (en.getUserGroupName().compareToIgnoreCase(strUGName) == 0) {
                retEnum = en;
                break;
            }
        }
        LOGGER.debug("getEnumGivenUGName() Exit");
        
        return retEnum;
    }
}
