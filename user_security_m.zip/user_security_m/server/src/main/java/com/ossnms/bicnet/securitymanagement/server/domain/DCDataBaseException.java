/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCDataBaseException
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CREATE
 * 		:	TNMS.DX2.SM.MAPPING.CREATE
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.securitymanagement.common.domain.DCException;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;

/**
 * This exception is thrown when there is a data base error due to an error while
 * reading or writing into LDAP
 */
class DCDataBaseException extends DCException {

    private static final long serialVersionUID = 1L;

    /**
	 * Default constructor
	 */
	public DCDataBaseException() {
		super(DCMessages.getInstance().getString(DCMessages.DC_LDAP_ERROR));
	}

	/**
	 * Constructor with a string parameter, which is descriptive
	 * @param reason  A user descriptive string which indicates this excpetion.
	 */
	public DCDataBaseException(String reason) {
		super(reason);
	}

}
