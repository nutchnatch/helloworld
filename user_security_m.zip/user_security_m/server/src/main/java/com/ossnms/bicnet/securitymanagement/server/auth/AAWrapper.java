package com.ossnms.bicnet.securitymanagement.server.auth;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.security.AccountLockedException;
import com.ossnms.bicnet.bcb.model.security.AuthorizationFailedException;
import com.ossnms.bicnet.bcb.model.security.InvalidCredentialsException;
import com.ossnms.bicnet.bcb.model.security.UserAccountDisabledException;
import com.ossnms.bicnet.securitymanagement.api.exception.PasswordHistoryViolationException;
import com.ossnms.bicnet.securitymanagement.api.server.users.IAAWrapper;
import com.ossnms.bicnet.securitymanagement.common.auth.AAAdvisoryDetails;
import com.ossnms.bicnet.securitymanagement.common.auth.AAChangePasswordDetails;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.bicnet.securitymanagement.common.user.UserOperationsBaseWrapper;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAStatus;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import com.ossnms.bicnet.securitymanagement.persistence.model.user.USMUser;
import com.ossnms.bicnet.securitymanagement.server.auth.monitor.AAServerSessionMonitor;
import com.ossnms.bicnet.securitymanagement.server.general.GSSubsystemSAP;
import com.ossnms.bicnet.securitymanagement.server.useradministration.UASubsystemSAP;
import com.ossnms.bicnet.util.encode.HashEncode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.Local;
import javax.ejb.Stateless;

@Stateless(name = "IAAWrapper")
@Local
public class AAWrapper extends UserOperationsBaseWrapper implements IAAWrapper  {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(UASubsystemSAP.class);

	@Override
	public boolean changePassword(ISessionContext sessionContext,
			AAChangePasswordDetails userDetails)
			throws PasswordHistoryViolationException, BcbException {
		
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("changePassword(" + sessionContext + ", " + userDetails + ") Entry");
		}

		boolean isChanged = false;

        UAUser user = UASubsystemSAP.getUserData(userDetails.getUserName());

		String newPassword = userDetails.getNewPassword();
		int numAllowedPasswords = GSSubsystemSAP.getNumberPasswordsInHistory();

		// populates user the user to be changed
		user.setPassword(newPassword);
		user.setUserMustChangePassword(Boolean.FALSE);
		user.setLastPasswordChangeTime(USMCommonHelper.getGMTStringForCurrentDate());
		user.setPasswordHasExpired(Boolean.FALSE);

        UAStatus status = UASubsystemSAP.modifyUser(user);

        if(status.getStatus() == UAStatus.S_LDAP_PASSWORD_HISTORY){
            String cause = USMCommonStrings.PASSWORD_NOT_MODIFIED + "\n"
                    + "It matches one of the previous " + numAllowedPasswords
                    + " passwords.";
            LOGGER.warn("changePassword(): " + cause);
            throw new PasswordHistoryViolationException();
        }else{
            isChanged = true;
            LOGGER.info(String.format("Password for user %s changed successfully",user.getUserId()));
        }
		
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("changePassword Exit. Returning : " + isChanged);
		}
		
		return isChanged;
	}


	@Override
	public boolean checkPasswordPermission(String userId) {
		return !(UASubsystemSAP.getUserData(userId).getUserCanNotChangePasswd());
	}

	@Override
	public AAAdvisoryDetails getAdvisoryMessage(ISessionContext sessionContext) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("getAdvisoryMessage(" + sessionContext + ") Entry");
		}
		AAAdvisoryDetails advisoryMessage = new AAAdvisoryDetails();
		GSGeneralSettingData generalSettings = GSSubsystemSAP.getGeneralSettingData();
		IEnhancedSessionContext objSessionContext = (IEnhancedSessionContext) sessionContext;

		advisoryMessage.setAdvisoryMessage(generalSettings.getAdvisoryMessage());
		advisoryMessage.setDisplay(generalSettings.isShowAdvisoryMessage());
		advisoryMessage.setInactivitTimeout(generalSettings.getInactivityTimeout());
		advisoryMessage.setUserId(objSessionContext.getUserName());

		AAServerSessionMonitor serverSessionMonitor = AASessionStore
				.getInstance().getMonitoringBean(objSessionContext);
		if (serverSessionMonitor != null) {
			advisoryMessage.setLastLogin(serverSessionMonitor.getLastLoginTime());
		}


		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("getAdvisoryMessage Exit. Returning : "
					+ advisoryMessage);
		}
		return advisoryMessage;
	}

	@Override
	public boolean isPasswordMustChanged(ISessionContext sessionContext) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("isPasswordMustChanged(" + sessionContext + ") 	Entry");
		}

		boolean bStatus = isPasswordMustChanged(sessionContext.getUserName());

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("isPasswordMustChanged(ISessionContext sessionContext) 	Exit : Return :"
					+ bStatus);
		}
		return bStatus;
	}

	@Override
	public boolean isPasswordMustChanged(String userName) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("isPasswordMustChanged(" + userName + ") 	Entry");
		}

		boolean bStatus = false;

		UAUser user = UASubsystemSAP.getUserData(userName);

		boolean bMustChange = user.isUserMustChangePassword();
		boolean bExpired = user.getPasswordHasExpired();
		boolean bCanChange = !user.getUserCanNotChangePasswd();

		bStatus = (bCanChange && (bMustChange || bExpired));

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("isPasswordMustChanged(String) Exit. Returning : {}", bStatus);
		}
		return bStatus;
	}
	
	@Override
	public byte[] getUserPasswordSalt(String userName) throws InvalidCredentialsException {
		LOGGER.debug("getUserPasswordSalt(" + userName + ") 	Entry");

		byte[] salt;
		
		// validate that user is not empty
		if (isNullOrEmpty(userName)) {
			LOGGER.error("logon error - empty username");
			throw new InvalidCredentialsException("Username is empty");
		}

		//After checking for valid username parameter, get the UAUser instance
		UAUser user = UASubsystemSAP.getUserData(userName);
		if (user != null) {
			USMUser usmUser = getUserDao().findByUsername(user.getUserId());
			String password = usmUser.getPassword();

			salt = HashEncode.extractSalt(password);
		} else {
			LOGGER.warn("The user " + userName + " does not exist.");
			throw new InvalidCredentialsException("User does not exist");
		}

		LOGGER.debug("getUserPasswordSalt(String) Exit. Returning :" + salt);

		return salt;
	}

	@Override
	public boolean logoff(ISessionContext session) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("logoff(" + session + " )Entry");
		}
		// Updating user last logoff time into directory server
		String strUserName = session.getUserName();
		String strHost = ((IEnhancedSessionContext) session).getClientMachineName();
		// Fault ID- 25 - Login throws a null pointer exception on the server
		// side - Begin
		boolean bStatus = false;
		try {
			bStatus = updateLastLoginTimeAndHost(strUserName, strHost, false, null);
		} catch (Exception ex) {
			LOGGER.error("Exception :", ex);
		} // Fault ID- 25 - Login throws a null pointer exception on the server
			// side - End
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("logoff Exit. Returning : " + bStatus);
		}

		return bStatus;
	}

	@Override
	public boolean logon(String username, String password)
			throws AuthorizationFailedException, UserAccountDisabledException,
			InvalidCredentialsException, AccountLockedException	{

		boolean bStatus;
		LOGGER.debug("logon(%s) Entry", username);

		// validate that user is not empty
		if (isNullOrEmpty(username) || isNullOrEmpty(password)) {
			LOGGER.error("logon error - empty username or password");
			throw new InvalidCredentialsException();
		}
		
        //After checking for valid username parameter, get the UAUser instance
        UAUser user = UASubsystemSAP.getUserData(username);

		if(user == null){
			LOGGER.warn("The user %s does not exist.", username);
			throw new InvalidCredentialsException();
		}

		// verify if user account is activated
		if (!user.isAccountActivated()) {
			LOGGER.warn("logon(): Operation is not supported. User Account {} is deactivated.", user.getUserId());
			throw new UserAccountDisabledException();
		// verify if account is not locked
		} else if (user.isAccountLocked()) {
			LOGGER.warn("logon(): User account {} is locked because of max password tries. Contact the administrator.", user.getUserId());
			throw new AccountLockedException();
		// verify if password equals the password stored for this user
		}else if (!UASubsystemSAP.validatePassword(user.getUserId(),password)) {
			LOGGER.warn("logon(): An authentication error has occured. Either the User ID or the Password or both supplied at installation are incorrect.");
			throw new AuthorizationFailedException();
		} else {
			bStatus = true;
		}

		LOGGER.debug("logon Exit. Returning : %b", bStatus);

		return bStatus;
	}

	private boolean isNullOrEmpty(String str) {
		return null == str || "".equals(str) || str.trim().length() < 1;
	}

	@Override
	public boolean updateLastLoginAttemptTime(String username, String currDate) {
		return UASubsystemSAP.updateLastLoginAttemptTime(username, currDate);
	}

	@Override
	public boolean updateLastLoginTimeAndHost(String userName, String host,
			boolean flag, StringBuilder lastLoginTimeBeforeLogin) {
		return UASubsystemSAP.updateLastLoginLogoutTimeAndHost(userName, host, flag, lastLoginTimeBeforeLogin);
	}
	
	
}
