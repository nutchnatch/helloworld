package com.ossnms.bicnet.securitymanagement.server.auth;

import com.ossnms.bicnet.bcb.facade.scs.ISystemControlEjbFacade;
import com.ossnms.bicnet.bcb.facade.security.EnhancedSessionContextItem;
import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.BiCNetProductType;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;
import com.ossnms.bicnet.bcb.model.scs.ScsServerErrorCondition;
import com.ossnms.bicnet.bcb.model.security.AccountExpiredException;
import com.ossnms.bicnet.bcb.model.security.AccountLicenseException;
import com.ossnms.bicnet.bcb.model.security.AccountLockedException;
import com.ossnms.bicnet.bcb.model.security.ActiveDirectoryUserGroupModificationException;
import com.ossnms.bicnet.bcb.model.security.ActiveDirectoryUserGroupsNotAvailableException;
import com.ossnms.bicnet.bcb.model.security.AuthorizationFailedException;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.bcb.model.security.InvalidCredentialsException;
import com.ossnms.bicnet.bcb.model.security.InvalidInitializationStateException;
import com.ossnms.bicnet.bcb.model.security.MaxSessionsReachedException;
import com.ossnms.bicnet.bcb.model.security.PasswordChangeRequiredException;
import com.ossnms.bicnet.bcb.model.security.UserAccountDisabledException;
import com.ossnms.bicnet.bcb.model.security.UserNotLoggedOnException;
import com.ossnms.bicnet.securitymanagement.api.common.OperationResult;
import com.ossnms.bicnet.securitymanagement.api.common.OperationResultStatus;
import com.ossnms.bicnet.securitymanagement.api.common.SSOAuthenticationToken;
import com.ossnms.bicnet.securitymanagement.api.exception.PasswordHistoryViolationException;
import com.ossnms.bicnet.securitymanagement.api.server.auth.SessionType;
import com.ossnms.bicnet.securitymanagement.api.server.profile.IProfileWrapper;
import com.ossnms.bicnet.securitymanagement.api.server.users.IAAWrapper;
import com.ossnms.bicnet.securitymanagement.api.server.users.IUAWrapper;
import com.ossnms.bicnet.securitymanagement.common.auth.AAAdvisoryDetails;
import com.ossnms.bicnet.securitymanagement.common.auth.AAChangePasswordDetails;
import com.ossnms.bicnet.securitymanagement.common.auth.AAClientCacheData;
import com.ossnms.bicnet.securitymanagement.common.auth.AAMessageType;
import com.ossnms.bicnet.securitymanagement.common.auth.AASessionContext;
import com.ossnms.bicnet.securitymanagement.common.auth.AAUserMessages;
import com.ossnms.bicnet.securitymanagement.common.auth.LDAPSearchScope;
import com.ossnms.bicnet.securitymanagement.common.auth.exception.AAKerberosAuthenticationException;
import com.ossnms.bicnet.securitymanagement.common.basic.SecurableObjectACL;
import com.ossnms.bicnet.securitymanagement.common.basic.SessionEvent;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.general.GSMessageType;
import com.ossnms.bicnet.securitymanagement.common.general.ldap.LDAPConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.radius.configuration.RadiusConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.sso.SSOConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAStatus;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserAccountType;
import com.ossnms.bicnet.securitymanagement.common.utils.InternalUSMBeanLocator;
import com.ossnms.bicnet.securitymanagement.common.utils.ObjectCypher;
import com.ossnms.bicnet.securitymanagement.server.IScsControllableImpl;
import com.ossnms.bicnet.securitymanagement.server.activedirectory.ActiveDirectoryManager;
import com.ossnms.bicnet.securitymanagement.server.auth.monitor.AAServerSessionMonitor;
import com.ossnms.bicnet.securitymanagement.server.basic.USMServerLifeCycleController;
import com.ossnms.bicnet.securitymanagement.server.basic.notification.USMNotifier;
import com.ossnms.bicnet.securitymanagement.server.bicnetserver.BSSubsystemSAP;
import com.ossnms.bicnet.securitymanagement.server.general.GSSubsystemSAP;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityAuthenticationPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.ldap.LDAPAuthenticationManager;
import com.ossnms.bicnet.securitymanagement.server.ldap.dto.LDAPGroup;
import com.ossnms.bicnet.securitymanagement.server.ldap.dto.LDAPUser;
import com.ossnms.bicnet.securitymanagement.server.logging.LMInterFace;
import com.ossnms.bicnet.securitymanagement.server.logging.LMLogRecordData;
import com.ossnms.bicnet.securitymanagement.server.logging.LMLogRecordEnum;
import com.ossnms.bicnet.securitymanagement.server.radius.RadiusAuthenticationManager;
import com.ossnms.bicnet.securitymanagement.server.radius.dto.RadiusUser;
import com.ossnms.bicnet.securitymanagement.server.servicelocator.USMServiceLocator;
import com.ossnms.bicnet.securitymanagement.server.useradministration.UASubsystemSAP;
import com.ossnms.bicnet.securitymanagement.server.useradministration.notification.UANotifier;
import com.ossnms.bicnet.securitymanagement.server.util.LicenseMgr;
import com.ossnms.bicnet.securitymanagement.server.util.USMUtils;
import com.ossnms.bicnet.util.UnexpectedException;
import com.ossnms.bicnet.util.encode.HashEncode;
import com.ossnms.bicnet.util.generator.password.PasswordGenerator;
import org.apache.commons.lang.time.DurationFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.ldap.NameNotFoundException;
import org.springframework.ldap.NamingException;

import javax.ejb.EJBTransactionRolledbackException;
import javax.security.auth.Subject;
import java.text.MessageFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.Collectors;

import static com.ossnms.bicnet.securitymanagement.api.server.auth.SessionType.CLIENT;
import static com.ossnms.bicnet.securitymanagement.api.server.auth.SessionType.SYSTEM;
import static com.ossnms.bicnet.securitymanagement.api.server.auth.SessionType.WEB;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.EMPTY;
import static com.ossnms.bicnet.securitymanagement.common.useradministration.UAAuthenticationType.LDAP;
import static com.ossnms.bicnet.securitymanagement.common.useradministration.UAAuthenticationType.RADIUS;
import static com.ossnms.bicnet.securitymanagement.common.useradministration.UAAuthenticationType.SSO;
import static com.ossnms.bicnet.securitymanagement.server.useradministration.UASubsystemSAP.getAllUserGroupNameForUser;

/**
 * POJO class for implementing the Authentication related Private Facade
 */

public class AAAuthenticationPOJOImpl implements ISecurityAuthenticationPrivateFacade {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(AAAuthenticationPOJOImpl.class);

    // Format strings
    private static final String FORMAT_TIME = "HH'h' mm'min' ss's'";

    private IProfileWrapper profileWrapper = InternalUSMBeanLocator.getEJB(IProfileWrapper.class);

    /**
     * Via lookup, retrieves the bean for the IAAWrapper
     */
    private IAAWrapper authenticationWrapper = InternalUSMBeanLocator.getEJB(IAAWrapper.class);

    private IUAWrapper uaWrapper = InternalUSMBeanLocator.getEJB(IUAWrapper.class);

    /**
     * Changes password for given user information.
     *
     * @param sessionContext - Session Token for the client
     * @param userDetails    - User credentials details.
     * @return USMMessage - Response to client wrapped in UMSMessage
     */
    @Override
    public USMMessage changePassword(ISessionContext sessionContext, AAChangePasswordDetails userDetails)
            throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("changePassword(" + sessionContext + ", " + userDetails + ") Entry");
        }
        boolean bStatus;
        Integer aaStatus = AAUserMessages.AA_NO_ERROR;
        // Creating USMMessage object to send back to client
        USMMessage objUSMMessage = new USMMessage(AAMessageType.AA_RESPONSE_USER_CHANGEPASSWORD,
                USMMessage.USMMESSAGE_RESPONSE);

        String userId = userDetails.getUserName();
        String oldPassword = userDetails.getOldPassword();

        boolean pPermission = checkPasswordChangePermission(userId);
        if (pPermission) {
            bStatus = false;
            try {
                authenticationWrapper.logon(userId, oldPassword);
                bStatus = true;
            } catch (AuthorizationFailedException ex) {
                aaStatus = AAUserMessages.AA_ERR_AUTHENTICATION;
            } catch (UserAccountDisabledException ex) {
                aaStatus = AAUserMessages.AA_ERR_ACCOUNT_DISABLED;
            } catch (AccountLockedException ex) {
                aaStatus = AAUserMessages.AA_ERR_ACCOUNT_LOCKED;
            } catch (BcbSecurityException ex) {
                aaStatus = AAUserMessages.AA_LOGIN_INVALID;
            }

            if (!bStatus) {
                LOGGER.error("changePassword() Authentication with previous credentials failed for user " + userId
                        + " due " + AAUserMessages.getInstance().getString(aaStatus));
                LOGGER.error("changePassword() Thus, the change password operation was not performed for user "
                        + userId);

                sendLoginFailedNotification(userId, AAMessageType.AA_NOTIFICATION_USER_LOGIN_FAILED);
                String displayStr = MessageFormat.format(USMCommonStrings.IDS_AA_USER_LOGIN_FAILURE,
                        userId, ((IEnhancedSessionContext) sessionContext).getClientMachineName());
                LMLogRecordData usmLogRecord = new LMLogRecordData(LMLogRecordEnum.USER_LOGIN, userId,
                        LMLogRecordData._FAILURE, null, LogSeverity.ERROR.guiLabel(), null, displayStr);
                LMInterFace.getInstance().createSecurityLogRecord(sessionContext, usmLogRecord);
            } else {
                try {
                    bStatus = authenticationWrapper.changePassword(sessionContext, userDetails);
                } catch (PasswordHistoryViolationException e) {
                    aaStatus = AAUserMessages.AA_ERR_PASSWORD_LDAP;
                } catch (BcbException e) {
                    aaStatus = AAUserMessages.AA_INTERNAL_ERROR;
                }
                if (bStatus) {
                    USMMessage notifMsg = new USMMessage(AAMessageType.AA_NOTIFICATION_USER_PASSWORD_CHANGED,
                            USMMessage.USMMESSAGE_NOTIFICATION);
                    notifMsg.pushString(userId);
                    USMNotifier.getInstance().sendNotification(notifMsg);

                    String displayStr = MessageFormat.format(USMCommonStrings.IDS_AA_USER_CHANGE_PASSWORD_SUCCESS,
                            userId, ((IEnhancedSessionContext) sessionContext).getClientMachineName());
                    LMLogRecordData usmLogRecord = new LMLogRecordData(LMLogRecordEnum.CHANGE_PASSWORD, userId,
                            LMLogRecordData._SUCCESS, null, LogSeverity.MESSAGE.guiLabel(), null, displayStr);
                    LMInterFace.getInstance().createSecurityLogRecord(sessionContext, usmLogRecord);
                    LMInterFace.getInstance().createSecurityCommandRecord(sessionContext,
                            LMLogRecordEnum.CHANGE_PASSWORD.getEventName(), userId);
                } else {
                    aaStatus = AAUserMessages.AA_ERR_PASSWORD_LDAP;
                }
            }
        } else {
            aaStatus = AAUserMessages.AA_ERR_USER_CANNOT_CHANGED;
            String displayStr = MessageFormat.format(USMCommonStrings.IDS_AA_USER_CHANGE_PASSWORD_FAILURE,
                    userId, USMCommonStrings.IDS_GS_PASSWORD_CHANGE_NOT_ALLOWED,
                    ((IEnhancedSessionContext) sessionContext).getClientMachineName());
            LMLogRecordData usmLogRecord = new LMLogRecordData(LMLogRecordEnum.CHANGE_PASSWORD,
                    USMCommonStrings.IDS_GS_PASSWORD_CHANGE_NOT_ALLOWED, LMLogRecordData._FAILURE, null,
                    LogSeverity.WARNING.guiLabel(), null, displayStr);
            LMInterFace.getInstance().createSecurityLogRecord(sessionContext, usmLogRecord);
        }

        objUSMMessage.pushInteger(aaStatus);

        LOGGER.debug("changePassword() Exit");

        return objUSMMessage;
    }

    /**
     * Retrieves advisory message wrapped in UMSMEssage.
     *
     * @param sessionContext - Session Token for the client
     * @return USMMessage - Response to client wrapped in UMSMessage
     */
    @Override
    public USMMessage getAdvisoryDetails(ISessionContext sessionContext) {
        LOGGER.debug("getAdvisoryDetails() Entry");

        AAAdvisoryDetails objAdvisoryData = authenticationWrapper.getAdvisoryMessage(sessionContext);

        // Creating USMMessage object to send back to client
        USMMessage objUSMMessage = new USMMessage(AAMessageType.AA_NOTIFICATION_USER_LOGGEDIN,
                USMMessage.USMMESSAGE_RESPONSE);
        // Populating USMMessage object according to following condition
        // 1. If advisory message is allowed to displayed on the client side, it
        // will be populated with
        // message, user, user last login tim and flag to be displayed or not.
        // 2. If advisory message is not allowed to displayed on the client side
        // then only display flag only will be populated
        if (objAdvisoryData != null) {
            if (objAdvisoryData.isDisplay()) {
                if ((null == objAdvisoryData.getLastLogin()) || (objAdvisoryData.getLastLogin().length() < 1)) {
                    objUSMMessage.pushString(EMPTY);
                } else {
                    objUSMMessage.pushString(objAdvisoryData.getLastLogin());
                }
                objUSMMessage.pushString(objAdvisoryData.getUserId());
                objUSMMessage.pushString(objAdvisoryData.getAdvisoryMessage());
            }
            objUSMMessage.pushInteger(objAdvisoryData.getInactivitTimeout());
            objUSMMessage.pushBoolean(objAdvisoryData.isDisplay());
        }
        LOGGER.debug("getAdvisoryDetails() Exit");

        return objUSMMessage;
    }

    /**
     * Retruns client side security data cache.
     *
     * @param sessionContext - Sesstion token created at the time of login for the user.
     * @return USMClientCacheData - Represents security data cache
     */
    @Override
    public AAClientCacheData getClientSecurityData(ISessionContext sessionContext) throws BcbSecurityException {
        return new AAClientCacheData();
    }

    /**
     * Retrieves all user profile data.
     *
     * @param sessionContext - Session token created at the time of login for the user.
     * @return USMMessage - Operation status with profile data
     * @see com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityAuthenticationPrivateFacade#getSecurableObjects(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public USMMessage getProfile(ISessionContext sessionContext) throws BcbSecurityException {
        LOGGER.debug("getProfile() Entry");

        Map<String, Properties> profile = profileWrapper.getProfile(sessionContext);

        // Creating USMMessage object to send back to client
        USMMessage msgResponse = new USMMessage(AAMessageType.AA_USER_PROFILE_GET_RESPONSE, USMMessage.USMMESSAGE_RESPONSE);
        msgResponse.pushObject(profile);
        LOGGER.debug("getProfile() Exit. Returning");

        return msgResponse;
    }

    /**
     * Retrieve all security objects.
     *
     * @param sessionContext - Session token created at the time of login for the user.
     * @return USMMessage - Operation status with flag for change password
     * @see com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityAuthenticationPrivateFacade#getSecurableObjects(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public Set<SecurableObjectACL> getSecurableObjects(ISessionContext sessionContext) throws BcbSecurityException {
        LOGGER.debug("getSecurableObjects() Entry");

        List<BSSecurableObject> lstSecurableObjects = BSSubsystemSAP.getAllSecurableObjectsWithACL();

        // Creating object to send back to client
        Set<SecurableObjectACL> response = new HashSet<>();

        for (BSSecurableObject objSecurable : lstSecurableObjects) {
            SecurableObjectACL securableObjectACL = new SecurableObjectACL(objSecurable.getUniqueName(), objSecurable.getBitSetACL());
            response.add(securableObjectACL);
        }

        LOGGER.debug("getSecurableObjects() Exit");

        return response;
    }

    /**
     *
     */
    @Override
    public USMMessage getServerVersionAndProductType(ISessionContext sessionContext) throws BcbSecurityException {
        LOGGER.debug("getServerVersionAndProductType()    Entry");

        USMServiceLocator serviceLocator = USMServiceLocator.getInstance();
        USMMessage msgResponse = new USMMessage(AAMessageType.AA_GET_SERVER_VERSION_PRODUCT_RESPONSE,
                USMMessage.USMMESSAGE_RESPONSE);
        try {

            ISystemControlEjbFacade scs = serviceLocator.getSCSControlFacade();
            BiCNetProductType type = scs.getProductType(sessionContext);
            String version = scs.getServerVersion(sessionContext).getBuild();

            LOGGER.info("Server Version:" + version);
            LOGGER.info("Server Product Type:" + type);

            msgResponse.pushObject(type);
            msgResponse.pushString(version);
        } catch (UnexpectedException ue) {
            LOGGER.error("Error while getting public facade Atp SCS:" + ue);
            throw new BcbSecurityException(false, "Error while getting public facade Atp SCS", ue);
        } catch (BcbException bcbe) {
            LOGGER.error("Error while getting the server version and product type from Atp SCS:" + bcbe);
            throw new BcbSecurityException(false,
                    "Error while getting the server version and product type from Atp SCS", bcbe);
        }

        LOGGER.debug("getServerVersionAndProductType Exit");

        return msgResponse;
    }

    @Override
    public OperationResult setActive(ISessionContext sessionContext) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setActive(" + sessionContext + ") Entry");
        }

        OperationResult result = new OperationResult();

        ISessionContext context;
        if (sessionContext instanceof EnhancedSessionContextItem) {
            context = AASessionContext.fromSessionContext((EnhancedSessionContextItem) sessionContext);
        } else {
            context = sessionContext;
        }

        AAServerSessionMonitor monitoringBean = AASessionStore.getInstance().getMonitoringBean(context);
        if(monitoringBean != null){
            monitoringBean.setActive();
            result.setStatus(OperationResultStatus.OK);
        }else{
            result.setStatus(OperationResultStatus.INTERNAL_ERROR);
        }

        LOGGER.debug("setActive() Exit");
        return result;
    }

    /**
     * Asserts if the User has the inactivity timeout enabled. If true, sends the value. Else, sends the general
     * setting for the application.
     *
     * @param sessionContext session's context
     * @return USMMessage response
     * @throws BcbSecurityException
     */
    @Override
    public USMMessage getInactivityTimeout(ISessionContext sessionContext) throws BcbSecurityException {
        USMMessage message;
        UAUser user = UASubsystemSAP.getUserData(sessionContext.getUserName());

        if (user == null) {
            return null;
        }

        message = new USMMessage(GSMessageType.GS_GENERAL_SETTING_DATA_RESPONSE, USMMessage.USMMESSAGE_RESPONSE);

        if (user.isInactivityTimeoutEnabled()) {
            message.pushInteger(user.getInactivityTimeout());
        } else {
            int inactivityTimeout = GSSubsystemSAP.getGeneralSettingData().getInactivityTimeout();
            message.pushInteger(inactivityTimeout);
        }

        return message;
    }

    /**
     * Sends the general setting value for the inactivity timeout warning time
     *
     * @return USMMessage response
     * @throws BcbSecurityException
     */
    @Override
    public USMMessage getInactivityTimeoutWarningTime(ISessionContext sessionContext) throws BcbSecurityException {
        USMMessage message;

        message = new USMMessage(GSMessageType.GS_GENERAL_SETTING_DATA_RESPONSE, USMMessage.USMMESSAGE_RESPONSE);
        int inactivityTimeout = GSSubsystemSAP.getGeneralSettingData().getInactivityTimeoutWarningTime();
        message.pushInteger(inactivityTimeout);

        return message;
    }

    /**
     * returns the flag to password must change or not by the user.
     *
     * @param sessionContext - Sesstion token created at the time of login for the user.
     * @return USMMessage - Operation status with flag for change password
     */
    @Override
    public USMMessage isPasswordMustChanged(ISessionContext sessionContext) {
        LOGGER.debug("isPasswordMustChanged() Entry");

        boolean bStatus = authenticationWrapper.isPasswordMustChanged(sessionContext);

        // Creating USMMessage object to send back to client
        USMMessage objUSMMessage = new USMMessage(AAMessageType.AA_RESPONSE_USER_CHANGEPASSWORD,
                USMMessage.USMMESSAGE_RESPONSE);

        objUSMMessage.pushBoolean(bStatus);
        LOGGER.debug("isPasswordMustChanged() Exit");

        return objUSMMessage;
    }

    /**
     * returns the password salt of the user.
     *
     * @param userName - the user.
     * @return byte[] - a byte array with the salt data
     */
    @Override
    public byte[] getUserPasswordSalt(String userName) throws InvalidCredentialsException {
        LOGGER.debug("getUserPasswordSalt() Entry");

        byte[] salt;

        try {
            salt = authenticationWrapper.getUserPasswordSalt(userName);
        } catch (EJBTransactionRolledbackException e) {
            LOGGER.debug("Could not retrieve password salt for user " + userName, e);
            salt = null;
        }

        LOGGER.debug("getUserPasswordSalt() Exit");

        return salt;
    }

    /**
     * Logs off user for given session token.
     *
     * @param session - Session token created at the time of login for the user.
     */
    @Override
    public void logoff(ISessionContext session) throws BcbSecurityException {
        LOGGER.debug("logoff() Entry");

        IEnhancedSessionContext objSessionContext;

        // Check if somebody has passed a invalid Session context.
        if (session == null) {
            LOGGER.error("logoff() :: The 'session' object received is null, therefore an exception should be thrown.");
            throw new BcbSecurityException();
        } else {
            //Keep this fork until we are sure there are no impacts
            if (session instanceof EnhancedSessionContextItem) {
                objSessionContext = AASessionContext.fromSessionContext((EnhancedSessionContextItem) session);
            } else if (session instanceof AASessionContext) {
                objSessionContext = (AASessionContext) session;
            } else {
                LOGGER.error("logoff() :: The 'session' object received does not have a relation 'IS-A' with EnhancedSessionContextItem or AASessionContext object, therefore an exception should be thrown.");
                throw new BcbSecurityException();
            }
        }

        boolean bStatus = AASessionStore.getInstance().isUserSessionActive(objSessionContext);
        if (bStatus) {
            // stop 1 min timer / remove timer
            AASecurityProviderFacadeImpl.getInstance().onUserLogginOff(objSessionContext);

            // remove user from server cache
            AASessionStore.getInstance().removeUserSession(objSessionContext);

            // Updating user status into the directory server
            authenticationWrapper.logoff(objSessionContext);

            LicenseMgr.releaseLoginLicense(objSessionContext);

            sendUserLoggedInNotification(objSessionContext, SessionEvent.LOGOFF);
            AASecurityProviderFacadeImpl.getInstance().userLoggedOff(objSessionContext);

            // create display string for the log
            long sessionDurationMilliseconds = UASubsystemSAP.getUserLastSessionDuration(objSessionContext.getUserName());
            String sessionDuration = DurationFormatUtils.formatDuration(sessionDurationMilliseconds, FORMAT_TIME);
            String displayStr = MessageFormat.format(USMCommonStrings.IDS_AA_USER_LOGOFF, objSessionContext.getUserName(), objSessionContext.getClientMachineName(), sessionDuration);

            // if the session is a GUI user session, then log this on the security log record
            if(!AASessionStore.getInstance().isNonGuiUserSession(objSessionContext)){
                LMLogRecordData usmLogRecord = new LMLogRecordData(LMLogRecordEnum.USER_LOGOFF, EMPTY, LMLogRecordData._SUCCESS, null, LogSeverity.MESSAGE.guiLabel(), null, displayStr);
                LMInterFace.getInstance().createSecurityLogRecord(objSessionContext, usmLogRecord);
            }

            // independently of the user type, log this event in the server log
            LOGGER.warn(displayStr);
        } else {
            LOGGER.error("logoff " + objSessionContext.getUserName() + " is already logged off.");
            throw new UserNotLoggedOnException();
        }

        LOGGER.debug("logoff() Exit");
    }


    @Override
    public void forceLogoff(final ISessionContext sessionToLogoffContext, SessionEvent event) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("forceLogoff() Entry");
        }
        
        //delay force logoff so that other components do not throw Invalid argument excpetion and deal with nbilogon 
        long timeWait = 1000 * 60;

        sendUserLoggedInNotification(sessionToLogoffContext, event);
        
		if (AASessionStore.getInstance().isSessionOfType(sessionToLogoffContext, SessionType.WEB)) {
			timeWait = 0;
		}

        ForceLogoffTimerTask forceLogoffTimerTask = new ForceLogoffTimerTask(sessionToLogoffContext);
        Timer forceLogoffTimer = new Timer();
        forceLogoffTimer.schedule(forceLogoffTimerTask, timeWait);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("forceLogoff() Exit");
        }
    }


    /**
     * Validates user credentials through a Kerberos Ticket and return session token.
     * If the user that is trying to authenticated does not exist on TNMS, it will
     * be created on the fly based on information existing on the Active Directory,
     * including the membership information (user groups).
     *
     * @param token Kerberos ticket, ciphered, obtained at client side which will be
     *              used to authenticate the client in TNMS.
     * @return Session context object created after a Kerberos
     * ticket validation.
     * @throws BcbSecurityException Three exceptions could be raised within the execution flow of
     *                              this method:
     *                              <p>
     *                              AAActiveDirectoryContextNotInitializedException - If the
     *                              directory context associated to Active Directory is not
     *                              available to be used due a configuration error or
     *                              communication failure.
     *                              <p>
     *                              AAActiveDirectoryUserGroupsNotAvailableException - If the
     *                              user is not associated to one or more TNMS default user
     *                              groups.
     *                              <p>
     *                              AAKerberosAuthenticationException - If the Kerberos ticket
     *                              validation is not well performed.
     */
    @Override
    public ISessionContext logon(byte[] token, String username, String host, String clientIpAddress) throws BcbSecurityException {
        long start = 0;
        long end;

        if (LOGGER.isDebugEnabled()) {
            start = System.currentTimeMillis();
            LOGGER.debug("logon() - with Kerberos Entry");
        }

        checkServerRunning();

        SSOAuthenticationToken authenticationToken = SSOAuthenticationToken.decipherTicket(token);

        if(authenticationToken == null) {
            LOGGER.error("logon() - the Kerberos Ticket was undecipherable.");
            createSecurityLogRecord(null, username, host, clientIpAddress, USMCommonStrings.IDS_AA_USER_LOGIN_FAILURE_KERBEROS, LMLogRecordData._FAILURE, LogSeverity.ERROR.guiLabel());
            sendLoginFailedNotification(username, AAMessageType.AA_NOTIFICATION_USER_LOGIN_FAILED);
            throw new AAKerberosAuthenticationException(false, MessageFormat.format(USMCommonStrings.IDS_AA_USER_LOGIN_FAILURE_KERBEROS, username, host));
        }

        // Prepare the subject
        Subject subject = new Subject();
        subject.getPrivateCredentials().add(authenticationToken.getKerberosTicket());
        // get SSO configured parameters
        SSOConfigurationData configurationData = GSSubsystemSAP.getSSOConfigurationData();

        //Fetch the groups for this user
        List<String> groupsList = new ActiveDirectoryManager(
                subject,
                configurationData.getKrbDomainName(),
                authenticationToken.getLdapServer(),
                configurationData.getLdapTcpPort()
        ).getUserGroups(username, authenticationToken.getObjectSID());

        LOGGER.info("User " + username + " belongs to groups: " + groupsList);

        if (groupsList == null || groupsList.isEmpty()) {
            LOGGER.error("logon() The user {} does not have any TNMS user group associated on Active Directory or LDAP configuration is not correct.", username);

            createSecurityLogRecord(null, username, host, clientIpAddress,
                    USMCommonStrings.IDS_AA_USER_DOES_NOT_HAVE_TNMS_GROUPS_ON_ACTIVE_DIRECTORY,
                    LMLogRecordData._FAILURE, LogSeverity.ERROR.guiLabel());

//            throw new ActiveDirectoryUserGroupsNotAvailableException(false, MessageFormat.format(USMCommonStrings.IDS_AA_USER_DOES_NOT_HAVE_TNMS_GROUPS_ON_ACTIVE_DIRECTORY, userName, host));
            throw new ActiveDirectoryUserGroupsNotAvailableException();
        }

        // Check if user exists. If not, get groups from Active Directory and
        // create user in LDAP
        if (!UASubsystemSAP.isUserExist(username, SSO)) {
            LOGGER.info("logon() The sso user {} does not exist within LDAP system. Creating new user.", username);
            createExternalUserAccount(username, host, clientIpAddress, groupsList, UAUserAccountType.SSO);
        } else {
            UAUser user = UASubsystemSAP.getUserData(username);
            modifyExternalUserAccount(username, host, clientIpAddress, groupsList, user, UAUserAccountType.SSO);
        }

        IEnhancedSessionContext objSessionContext = assignUserSession(host, clientIpAddress, username, CLIENT, USMCommonStrings.IDS_AA_USER_LOGIN_KERBEROS);

        if (LOGGER.isDebugEnabled()) {
            end = System.currentTimeMillis();
            LOGGER.debug("logon() Elapsed time : " + (end - start) + " [ms]");
            LOGGER.debug("logon() with Kerberos Exit");
        }

        return objSessionContext != null ? ((AASessionContext) objSessionContext).toSessionContext() : null;
    }

    /**
     * Creates a user account from an external data source (SSO, LDAP, etc)
     *
     * @param userName the username
     * @param host the hostname
     * @param clientIpAddress the client ip address
     * @param groupsList the list of groups the user belongs to
     * @throws InvalidCredentialsException
     */
    private void createExternalUserAccount(String userName, String host, String clientIpAddress, List<String> groupsList, UAUserAccountType accountType) throws InvalidCredentialsException {
        String generatedPassword = PasswordGenerator.generatePassword();
        generatedPassword = HashEncode.encodePassword(generatedPassword);

        UAUser uaUser = new UAUser();
		uaUser.setId(0);
        uaUser.setUserId(userName);
        uaUser.setAuthenticationType(accountType.getAuthenticationType()); // set the authentication type
        uaUser.setPassword(generatedPassword);
        uaUser.setUserCanNotChangePasswd(true);
        uaUser.setFirstName(userName);
        uaUser.setLastName(userName);
        uaUser.setEmail(EMPTY);
        uaUser.setCommonName(userName);
        uaUser.setAccountActivated(true);
        uaUser.setActivationTimeToCurrentTime();
        uaUser.setAssignedUserGroups(groupsList);

        UAStatus createUserStatus = UASubsystemSAP.createUser(uaUser);

        if ((createUserStatus == null) || (createUserStatus.getStatus() != UAStatus.S_SUCCESS)) {
            createSecurityLogRecord(
                    null,
                    userName,
                    host,
                    clientIpAddress,
                    accountType.getCreationFailureMessage(),
                    LMLogRecordData._FAILURE,
                    LogSeverity.ERROR.guiLabel()
            );

            sendLoginFailedNotification(userName, AAMessageType.AA_NOTIFICATION_USER_LOGIN_FAILED);
            throw new InvalidCredentialsException("User not recognized");
        } else {
            createSecurityLogRecord(
                    null,
                    userName,
                    host,
                    clientIpAddress,
                    accountType.getCreationSuccessMessage(),
                    LMLogRecordData._SUCCESS,
                    LogSeverity.MESSAGE.guiLabel()
            );

            UANotifier.getInstance().notifyCreation(uaUser);
        }
    }

    /**
     * @param userName the username
     * @param host the host from the request was originated
     * @param clientIpAddress the ip address of the client machine
     * @param groupsList the list of groups to associate the user to
     * @param user the user information
     * @throws ActiveDirectoryUserGroupModificationException if the user was not modified
     */
    private void modifyExternalUserAccount(String userName, String host, String clientIpAddress, List<String> groupsList, UAUser user, UAUserAccountType accountType) throws ActiveDirectoryUserGroupModificationException {
        // get the unassigned groups
        List<String> oldUserGroups = UASubsystemSAP.getAllUserGroupNameForUser(userName);
        oldUserGroups.removeAll(groupsList);

        // The user already exists on the DB, therefore we need to
        // modify user groups based on information existing on Active
        // Directory.
        user.setAssignedUserGroups(groupsList);
        UAStatus modifyUserStatus = UASubsystemSAP.modifyUser(user);

        if ((modifyUserStatus == null) || (modifyUserStatus.getStatus() != UAStatus.S_SUCCESS)) {
            createSecurityLogRecord(
                    null,
                    userName,
                    host,
                    clientIpAddress,
                    accountType.getModificationFailureMessage(),
                    LMLogRecordData._FAILURE,
                    LogSeverity.ERROR.guiLabel()
            );
            sendLoginFailedNotification(userName, AAMessageType.AA_NOTIFICATION_USER_LOGIN_FAILED);
            throw new ActiveDirectoryUserGroupModificationException();
        } else {
            createSecurityLogRecord(
                    null,
                    userName,
                    host,
                    clientIpAddress,
                    accountType.getModificationSuccessMessage(),
                    LMLogRecordData._SUCCESS,
                    LogSeverity.MESSAGE.guiLabel()
            );

            UANotifier.getInstance().notifyModification(user, oldUserGroups);
        }
    }

    @Override
    public ISessionContext logon(String userName, byte[] cypheredPassword, String host, String clientIpAddress) throws BcbSecurityException {
        return logon(userName, (String) ObjectCypher.decypherToken(cypheredPassword), host, clientIpAddress, CLIENT);
    }

    /**
     *
     * @param userName
     * @param password
     * @param host
     * @param clientIpAddress
     * @return
     * @throws BcbSecurityException
     */
    public ISessionContext nbiLogon(String userName, String password, String host, String clientIpAddress) throws BcbSecurityException {
        return logon(userName, password, host, clientIpAddress, SYSTEM);
    }

    /**
     *
     * @param userName
     * @param password
     * @param host
     * @param clientIpAddress
     * @return
     * @throws BcbSecurityException
     */
    public ISessionContext webLogin(String userName, String password, String host, String clientIpAddress) throws BcbSecurityException {
        return logon(userName, password, host, clientIpAddress, WEB);
    }

    /**
     * Removes the profile data for given CF unique identifier
     *
     * @param sessionContext - Session token created at the time of login for the user.
     * @param appUID         - CF unique identifier
     * @return USMMessage - Operation status for updating profile date
     * @see com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityAuthenticationPrivateFacade#removeUserProfile(com.ossnms.bicnet.bcb.facade.security.ISessionContext, String p_AppUID)
     */
    @Override
    public USMMessage removeUserProfile(ISessionContext sessionContext, String appUID) throws BcbSecurityException {
        LOGGER.debug("removeUserProfile() Entry");

        boolean bStatus = profileWrapper.removeUserProfile(sessionContext, appUID);

        // / Creating USMMessage object to send back to client
        USMMessage msgResponse = new USMMessage(AAMessageType.AA_USER_PROFILE_REMOVE_RESPONSE, USMMessage.USMMESSAGE_RESPONSE);
        msgResponse.pushBoolean(bStatus);

        if (bStatus) {
            // Sending notification
            IEnhancedSessionContext context = (IEnhancedSessionContext) sessionContext;

            USMMessage objUSMMessage = new USMMessage(AAMessageType.AA_NOT_PROFILE_DELETED, USMMessage.USMMESSAGE_NOTIFICATION);

            objUSMMessage.pushString(appUID);
            objUSMMessage.pushString(context.getUserName());

            USMNotifier.getInstance().sendNotification(objUSMMessage);
        }

        LOGGER.debug("removeUserProfile() Exit");

        return msgResponse;
    }

    /**
     * Sets the profile data for given CF unique identifier
     *
     * @param sessionContext - Session token created at the time of login for the user.
     * @param appUID         - CF unique identifier
     * @param profile        - profile data for the given CF.
     * @return USMMessage - Operation status for updating profile data
     * @see com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityAuthenticationPrivateFacade#getSecurableObjects(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public USMMessage setProfile(ISessionContext sessionContext, String appUID, Properties profile)
            throws BcbSecurityException {
        LOGGER.debug("setProfile() Entry");

        boolean bStatus = profileWrapper.setProfile(sessionContext, appUID, profile);

        // Creating USMMessage object to send back to client
        USMMessage msgResponse = new USMMessage(AAMessageType.AA_USER_PROFILE_SET_RESPONSE, USMMessage.USMMESSAGE_RESPONSE);
        msgResponse.pushBoolean(bStatus);

        if (bStatus) {
            // Sending notification
            IEnhancedSessionContext context = (IEnhancedSessionContext) sessionContext;

            USMMessage objUSMMessage = new USMMessage(AAMessageType.AA_NOT_PROFILE_UPDATED, USMMessage.USMMESSAGE_NOTIFICATION);
            objUSMMessage.pushObject(profile);
            objUSMMessage.pushString(appUID);
            objUSMMessage.pushString(context.getUserName());

            USMNotifier.getInstance().sendNotification(objUSMMessage);
        }

        LOGGER.debug("setProfile() Exit");

        return msgResponse;
    }

    /**
     * @param userId user id of the user for which change password permission has
     *               to be checked.
     * @return true if he has rights to change his password false otherwise.
     */
    private boolean checkPasswordChangePermission(String userId) {
        LOGGER.debug("checkPasswordChangePermission() Entry");
        LOGGER.debug("checkPasswordChangePermission() Exit");

        return authenticationWrapper.checkPasswordPermission(userId);
    }

    /**
     * This method is used to create a session context object and related
     * security and command log information.
     *
     * @param username    username
     * @param password        When a kerberos authentication is performed there is not password.
     * @param host            host
     * @param clientIpAddress client's IP address
     * @return Session context object
     */
    private IEnhancedSessionContext createSessionContext(String username, String password, String host, String clientIpAddress) {
        LOGGER.debug("createSessionContext() Entry");

        UAUser user = UASubsystemSAP.getUserData(username);
        List<String> objUserGroup = getAllUserGroupNameForUser(user.getUserId());

        IEnhancedSessionContext objSessionContext = new AASessionContext(user.getUserId(), password,
                USMCommonHelper.getLocalHostName(), host, clientIpAddress, objUserGroup, true);

        LOGGER.debug("createSessionContext() Exit");

        return objSessionContext;
    }

    private void updateLastLoginTimeAndHost(IEnhancedSessionContext userSession) {
        StringBuilder strLastLoginTimeBeforeLogin = new StringBuilder();
        authenticationWrapper.updateLastLoginTimeAndHost(userSession.getUserName(), userSession.getClientMachineName(), true, strLastLoginTimeBeforeLogin);

        AAServerSessionMonitor monitoringBean = AASessionStore.getInstance().getMonitoringBean(userSession);
        if (monitoringBean != null) {
            monitoringBean.setLastLoginTime(strLastLoginTimeBeforeLogin.toString());
        }
    }

    /**
     * @param userName
     * @param password
     * @param host
     * @param clientIpAddress
     * @param sessionType
     * @return
     * @throws BcbSecurityException
     */
    private ISessionContext logon(String userName, String password, String host, String clientIpAddress, SessionType sessionType) throws BcbSecurityException {
        LOGGER.debug("logon() - locally");

        IEnhancedSessionContext objSessionContext;
        String logRecordMessage = USMCommonStrings.IDS_AA_USER_LOGIN;

        checkServerRunning();

        try {
            validatePassword(userName, password, clientIpAddress);
                        
            LDAPConfigurationData ldapConfigurationData = GSSubsystemSAP.getLdapConfigurationData();
            RadiusConfigurationData radiusConfigurationData = GSSubsystemSAP.getRadiusConfigurationData();

            // check if the user exists locally. If so, perform local authentication
            if (UASubsystemSAP.isUserExist(userName)) {
                // first check if the password must be changed
                checkPasswordMustBeChanged(userName, sessionType);

                authenticationWrapper.logon(userName, password);
            } else if (ldapConfigurationData.isEnabled()) {
                // if the user does not exist locally, and ldap authentication is enabled, then perform ldap
                // authentication
                logonLDAP(userName, password, host, clientIpAddress, ldapConfigurationData);
                logRecordMessage = USMCommonStrings.IDS_AA_LDAP_USER_LOGIN;
            } else if(radiusConfigurationData.isEnabled()) {
                // if the user does not exist locally, and radius authentication is enabled, then perform radius
                // authentication
                logonRadius(userName, password, host, clientIpAddress, radiusConfigurationData);
                logRecordMessage = USMCommonStrings.IDS_AA_RADIUS_USER_LOGIN;
            } else {
    			LOGGER.warn("The user %s does not exist.", userName);
    			throw new InvalidCredentialsException("User not recognized.");
            }
            
        	
			// check if user Required Permission
			checkAccess(userName, sessionType);

            // If user credentials are validated successfully then session token
            // is created for the user otherwise no.
            SessionType type = (!SYSTEM.equals(sessionType) && !USMUtils.isHiddenUser(userName)) ? sessionType : SYSTEM;
            // create user session for the specified user
            objSessionContext = assignUserSession(host, clientIpAddress, userName, type, logRecordMessage);

            LOGGER.info("Authentication was performed successfully for user " + userName);
        } catch (AccountLicenseException e) {
            LOGGER.debug("AccountLicenseException caught. Message: {}", e.getMessage());
            throw e;
        } catch (AuthorizationFailedException | InvalidCredentialsException ex) {
            handleLoginFailure(userName, host, clientIpAddress, getUserNumPasswordFailureAttempts(userName));
            throw ex;
        } catch (MaxSessionsReachedException ex) {
            handleLoginFailureMaxSession(userName, host, clientIpAddress, null);
            throw ex;
        } catch (BcbSecurityException ex) {
            handleLoginFailure(userName, host, clientIpAddress, null);
            throw ex;
        }
        LOGGER.debug("logon() - with LDAP Exit");

        return ((AASessionContext) objSessionContext).toSessionContext();
    }

    /**
     *
     * @param userName the username of the user trying to log in
     * @param sessionType the type of the session requested
     * @throws PasswordChangeRequiredException signaling that the password should be changed
     */
    private void checkPasswordMustBeChanged(String userName, SessionType sessionType) throws PasswordChangeRequiredException {
        // this will only be checked if the session type is WEB
        if(WEB.equals(sessionType) && authenticationWrapper.isPasswordMustChanged(userName)){
            // Password has expired. So ensure user changes password by throwing
            // exception
            LOGGER.debug("User login denied. Reason password expired. " + userName);
            throw new PasswordChangeRequiredException();
        }
    }

    /**
     *
     * @param userName
     * @param password
     * @param clientIpAddress
     * @throws InvalidCredentialsException
     */
    private void validatePassword(String userName, String password, String clientIpAddress) throws InvalidCredentialsException {
        // validate that user and the password are not empty
        if (isNullOrEmpty(userName) || isNullOrEmpty(password)) {
            LOGGER.error("Logon error on {}. Empty username and/or password", clientIpAddress);
            throw new InvalidCredentialsException("Empty username or password");
        }
    }

    /**
     * @param userName the username of the user we which to authenticate
     * @param password the password
     * @param host hostname of the machine
     * @param clientIpAddress ip address of the client machine
     * @param ldapConfigurationData configuration data for ldap access
     * @throws AuthorizationFailedException if authentication is not possible
     */
    private void logonLDAP(String userName, String password, String host, String clientIpAddress, LDAPConfigurationData ldapConfigurationData) throws BcbSecurityException {
        LOGGER.debug("logon() - with LDAP Entry");

        String LDAPHost = ldapConfigurationData.getHost();
        int port = Integer.valueOf(ldapConfigurationData.getPort());
        boolean sslIndicator = ldapConfigurationData.isSslIndicator();
        String userDn = ldapConfigurationData.getSearchAccount();
        String pwd = ldapConfigurationData.getSearchPassword();

        String userSearchBase = ldapConfigurationData.getUserSearchBase();
        String userSearchFilter = ldapConfigurationData.getUserSearchFilter();
        LDAPSearchScope userSearchScope = ldapConfigurationData.getUserSearchScope();
        String userIdAttribute = ldapConfigurationData.getUserIdAttribute();

        String groupSearchBase = ldapConfigurationData.getGroupSearchBase();
        String groupSearchFilter = ldapConfigurationData.getGroupSearchFilter();
        LDAPSearchScope groupSearchScope = ldapConfigurationData.getGroupSearchScope();
        String groupIdAttribute = ldapConfigurationData.getGroupIdAttribute();
        String groupMemberAttribute = ldapConfigurationData.getGroupMemberAttribute();

        LDAPUser ldapUser;

        try {

            ldapUser = new LDAPAuthenticationManager(
                    LDAPHost, port, sslIndicator, userDn, pwd
            ).setUserSearchParameters(
                    userSearchBase,
                    userSearchFilter,
                    userSearchScope,
                    userIdAttribute
            ).setGroupSearchParameters(
                    groupSearchBase,
                    groupSearchFilter,
                    groupSearchScope,
                    groupIdAttribute,
                    groupMemberAttribute
            ).authenticate(
                    userName,
                    password
            );

        } catch(NameNotFoundException e){
            String message = MessageFormat.format("LDAP Authentication failed for user {0}. Search failed.", userName);
            LOGGER.error(message);
            LOGGER.debug(message, e);
            throw new AuthorizationFailedException(message);
        } catch (NamingException e) {
            String message = MessageFormat.format("LDAP Authentication failed for user {0}", userName);
            LOGGER.error(message);
            LOGGER.debug(message, e);
            throw new AuthorizationFailedException(message);
        } catch (EmptyResultDataAccessException e) {
            String message = MessageFormat.format("LDAP Authentication error; Incorrect result size: expected 1, actual 0 for {0}", userName);
            LOGGER.error(message);
            LOGGER.debug(message, e);
            throw new AuthorizationFailedException(message);
        }

        // if the authentication object came back null, the list of groups is null or empty, authentication fails
        if (ldapUser == null || ldapUser.getUserGroups() == null || ldapUser.getUserGroups().size() == 0) {
            String message = "An LDAP authentication error has occurred. Either the Username or the Password or both supplied at installation are incorrect.";
            LOGGER.error(message);
            throw new AuthorizationFailedException(message);
        }

        // collect the user group ids from the ldap authentication
        List<String> groupsList = ldapUser.getUserGroups()
                .stream()
                .map(LDAPGroup::getGroupID)
                .collect(Collectors.toList());

        if (groupsList.isEmpty()) {
            String message = MessageFormat.format("The ldap user {0} does not belong to any TNMS Groups.", userName);
            LOGGER.error(message);
            throw new AuthorizationFailedException(message);
        }

        // Check if user exists. If not, get groups from Active Directory and
        // create user in LDAP
        if (!UASubsystemSAP.isUserExist(userName, LDAP)) {
            LOGGER.debug("The user {} does not exist within the LDAP Server. Creating new user.", userName);
            createExternalUserAccount(userName, host, clientIpAddress, groupsList, UAUserAccountType.LDAP);
        } else {
            UAUser user = UASubsystemSAP.getUserData(userName);
            modifyExternalUserAccount(userName, host, clientIpAddress, groupsList, user, UAUserAccountType.LDAP);
        }
    }

    /**
     *
     * @param userName
     * @param password
     * @param host
     * @param clientIpAddress
     * @param configurationData
     */
    private void logonRadius(String userName, String password, String host, String clientIpAddress, RadiusConfigurationData configurationData) throws BcbSecurityException {
        RadiusUser user = new RadiusAuthenticationManager()
                .setTimeout(configurationData.getTimeout())
                .setRetries(configurationData.getRetries())
                .setRadiusUserGroupAttribute(configurationData.getUserGroupAttribute())
                .setServerHostname(configurationData.getServerHostname())
                .setServerPort(configurationData.getServerPort())
                .setServerSharedSecret(configurationData.getServerSharedSecret())
                .setAltServerHostname(configurationData.getAltServerHostname())
                .setAltServerPort(configurationData.getAltServerPort())
                .setAltServerSharedSecret(configurationData.getAltServerSharedSecret())
                .setDebug(LOGGER.isDebugEnabled()) // turn debug on if LOGGER debug is also on
                .authenticate(userName, password);

        // if the authentication object came back null, the list of groups is null or empty, authentication fails
        if (user == null || user.getUserGroups() == null || user.getUserGroups().size() == 0) {
            String message = "A RADIUS authentication error has occurred. Either the Username or the Password or both supplied at installation are incorrect.";
            LOGGER.error(message);
            throw new AuthorizationFailedException(message);
        }

        // check if the groups are all valid.
        List<String> userGroups = user.getUserGroups().stream().filter(UASubsystemSAP::isUserGroupExist).collect(Collectors.toList());

        if(userGroups.isEmpty()){
            String message = MessageFormat.format("The RADIUS user {0} does not belong to any TNMS Groups.", userName);
            LOGGER.error(message);
            throw new AuthorizationFailedException(message);
        }

        // Check if user exists. If not, create the user locally with type RADIUS
        // In every case, replace the groups
        if (!UASubsystemSAP.isUserExist(userName, RADIUS)) {
            LOGGER.debug("The user {} does not exist within the LDAP Server. Creating a new user.", userName);
            createExternalUserAccount(userName, host, clientIpAddress, userGroups, UAUserAccountType.RADIUS);
        } else {
            UAUser persistedUser = UASubsystemSAP.getUserData(userName);
            modifyExternalUserAccount(userName, host, clientIpAddress, userGroups, persistedUser, UAUserAccountType.RADIUS);
        }
    }

    /**
     * Assigns a new user session token to this user only if certain validation parameters are met.
     *
     * @param host             the hostname
     * @param clientIpAddress  the client's IP Address
     * @param username         the username
     * @param sessionType     true if it is a GUI Session, false otherwise
     * @param logRecordMessage the message to be included in the log record
     * @return a new session token if the user was assigned one
     * @throws AccountLicenseException if the user had no license available for login
     */
    private IEnhancedSessionContext assignUserSession(String host, String clientIpAddress, String username, SessionType sessionType, String logRecordMessage) throws BcbSecurityException {
        UAUser user = uaWrapper.retrieveUser(username);

        if(user == null) {
            throw new InvalidCredentialsException("User not recognized");
        }

        // nevertheless, reset bad password count
        uaWrapper.updateBadPasswordCountByUser(username, 0);
        // send notification regarding login attempt, but only if it is a GUI Session
        if (isClientSession(sessionType)) {
            String strCurrDate = USMCommonHelper.getGMTStringForCurrentDate();
            UASubsystemSAP.updateLastLoginAttemptTime(username, strCurrDate);
            UASubsystemSAP.sendUserLoginAttemptNotification(username, strCurrDate);
        }

        // validate number of allowed simultaneous user sessions by retrieving the number of active sessions
        int loggedInSessions = AASessionStore.getInstance().getLoggedInUserSessions(username).size();
        LOGGER.info("User {} has {} active sessions.", username, loggedInSessions);

        if (user.isRestrictUserSessions() && user.getSimultaneousUserSessions() <= loggedInSessions) {
            throw new MaxSessionsReachedException();
        }

        // validate account expiration date
        if (user.isAccountExpires() && user.getExpirationDate().compareTo(new Date()) < 0) {
            throw new AccountExpiredException();
        }

        IEnhancedSessionContext objSessionContext = issueSessionContext(username, EMPTY, host, clientIpAddress, sessionType);
        AASessionStore.getInstance().addUserSession(objSessionContext, sessionType);

        if(isClientSession(sessionType)){
            updateLastLoginTimeAndHost(objSessionContext);
            createSecurityLogRecord(objSessionContext, username, host, clientIpAddress, logRecordMessage, LMLogRecordData._SUCCESS, LogSeverity.MESSAGE.guiLabel());
            sendUserLoggedInNotification(objSessionContext, SessionEvent.LOGIN);
            AASecurityProviderFacadeImpl.getInstance().userLoggedOn(objSessionContext);
        }

        return objSessionContext;
    }

    /**
     * Checks if the session type is of the type client
     * @param sessionType the session type to check
     * @return true if it is a client session; false otherwise
     */
    private boolean isClientSession(SessionType sessionType) {
        return sessionType != null && sessionType.isClientSession();
    }

    /**
     * This method is used to record information on Security Log through LogM
     * component.
     */
    private void createSecurityLogRecord(ISessionContext objSessionContext, String userName, String host,
                                         String clientIpAddress, String message, int logRecordDataType, String messageLabel, Integer attemptCounter) {
        LOGGER.debug("createSecurityLogRecord() Entry");

        ISessionContext sessionContext = objSessionContext;
        if (sessionContext == null) {
            sessionContext = new AASessionContext(USMCommonStrings.SYSTEM_ACCOUNT, EMPTY, host,
                    host, clientIpAddress, null, false);
        }

        LMLogRecordData usmLogRecord = new LMLogRecordData(LMLogRecordEnum.USER_LOGIN, userName, logRecordDataType,
                null, messageLabel, attemptCounter != null ? attemptCounter.toString() : null, MessageFormat.format(message, userName, host));
        LMInterFace.getInstance().createSecurityLogRecord(sessionContext, usmLogRecord);

        LOGGER.debug("createSecurityLogRecord() Exit");
    }

    /**
     *
     * @param objSessionContext
     * @param userName
     * @param host
     * @param clientIpAddress
     * @param message
     * @param logRecordDataType
     * @param messageLabel
     */
    private void createSecurityLogRecord(ISessionContext objSessionContext, String userName, String host, String clientIpAddress, String message, int logRecordDataType,
                                         String messageLabel) {
        createSecurityLogRecord(objSessionContext, userName, host, clientIpAddress, message, logRecordDataType, messageLabel, null);
    }

    /**
     *
     * @param userName
     * @param host
     * @param clientIpAddress
     * @param numFailedAttempts
     */
    private void handleLoginFailure(String userName, String host, String clientIpAddress, Integer numFailedAttempts) {
        createSecurityLogRecord(null, userName, host, clientIpAddress, USMCommonStrings.IDS_AA_USER_LOGIN_FAILURE, LMLogRecordData._FAILURE, LogSeverity.ERROR.guiLabel(), numFailedAttempts);
        sendLoginFailedNotification(userName, AAMessageType.AA_NOTIFICATION_USER_LOGIN_FAILED);
    }

    /**
     *
     * @param userName
     * @param host
     * @param clientIpAddress
     * @param numFailedAttempts
     */
    private void handleLoginFailureMaxSession(String userName, String host, String clientIpAddress, Integer numFailedAttempts) {
        createSecurityLogRecord(null, userName, host, clientIpAddress, USMCommonStrings.IDS_AA_USER_LOGIN_FAILURE_MAX_SESSION,
                LMLogRecordData._FAILURE, LogSeverity.ERROR.guiLabel(), numFailedAttempts);
    }

    /**
     *
     * @param userName
     * @param password
     * @param host
     * @param clientIpAddress
     * @param sessionType
     * @return
     * @throws AccountLicenseException
     */
    private IEnhancedSessionContext issueSessionContext(String userName, String password, String host, String clientIpAddress, SessionType sessionType) throws AccountLicenseException {
        IEnhancedSessionContext objSessionContext = createSessionContext(userName, password, host, clientIpAddress);

        if ((isClientSession(sessionType)) && !LicenseMgr.reserveLoginLicense(objSessionContext) && (!USMUtils.isAdminUser(objSessionContext) || !LicenseMgr.reserveAdminLoginLicense(objSessionContext))) {
            String message = MessageFormat.format(USMCommonStrings.IDS_AA_USER_LOGIN_NO_LICENSE, objSessionContext.getUserName());
            LMInterFace.getInstance().createLicenseLogRecord(message, LogSeverity.ERROR);
            createSecurityLogRecord(objSessionContext, userName, host, clientIpAddress, USMCommonStrings.IDS_AA_USER_LOGIN_NO_LICENSE, LMLogRecordData._FAILURE, LogSeverity.ERROR.guiLabel());
            throw new AccountLicenseException();
        }

        return objSessionContext;
    }

    /**
     * Checks if server is running without problems
     *
     * @throws InvalidInitializationStateException
     * @throws SecurityException
     * @throws IllegalArgumentException
     */
    private void checkServerRunning() throws InvalidInitializationStateException {
        if (!USMServerLifeCycleController.getInstance().isInitialized()) {
            try {
                LOGGER.error("USM component has not been initialized successfully or completely");
                ISessionContext ctx = IScsControllableImpl.getLocalSecurityProviderFacade().getSystemAccountContext();
                ISystemControlEjbFacade scsControlFacade = USMServiceLocator.getInstance().getSCSControlFacade();
                ScsServerErrorCondition errorCondition = scsControlFacade.getServerErrorCondition(ctx);
                throw new InvalidInitializationStateException(errorCondition);
            } catch (UnexpectedException | BcbException e) {
                LOGGER.error("Can't get errorCondition", e);
                throw new InvalidInitializationStateException(null, e);
            }
        }
    }

    /**
     * This method sends notification to all client for any user log-in failure.
     *
     * @param userId  - User name who tried to log in
     * @param message - Message to be sent to the client
     */
    private void sendLoginFailedNotification(String userId, USMBaseMsgType message) {
        LOGGER.debug("sendLoginFailedNotification () Entry");

        UAUser objUser = UASubsystemSAP.getUserData(userId);
        if (objUser != null) {
            USMMessage objUSMMessage = new USMMessage(message, USMMessage.USMMESSAGE_NOTIFICATION);

            objUSMMessage.pushBoolean(objUser.isAccountLocked());
            objUSMMessage.pushInteger(objUser.getBadPasswordCount());
            objUSMMessage.pushString(userId);

            USMNotifier.getInstance().sendNotification(objUSMMessage);
        }

        LOGGER.debug("sendLoginFailedNotification() Exit");
    }

    /**
     * This method sends notification to all client for any user logged in /
     * logged out.
     *
     * @param objSessionContext - session context
     * @param event             the event
     */
    private void sendUserLoggedInNotification(ISessionContext objSessionContext, SessionEvent event) {
        LOGGER.debug("sendUserLoggedInNotification() Entry");

        String userName = objSessionContext.getUserName();
        UAUser objUser = UASubsystemSAP.getUserData(userName);

        USMMessage objUSMMessage = new USMMessage(event.getAssociatedMessageType(), USMMessage.USMMESSAGE_NOTIFICATION);

        String strLastLoginTime = objUser.getLastLogOnTime();
        objUSMMessage.pushString(strLastLoginTime);
//        ((AASessionContext) objSessionContext).pushTo(objUSMMessage);

        //Every USM output related to SessionContext must be made in the form of an EnhancedSessionContextItem
        objUSMMessage.pushObject(((AASessionContext) objSessionContext).toSessionContext());
        USMNotifier.getInstance().sendNotification(objUSMMessage);

        LOGGER.debug("sendUserLoggedInNotification() Exit");
    }

    /**
     * Retrieve a user's number of failure login attempts.
     *
     * @param userId the id of the user
     * @return User's number of failure login attempts or the limit of failed attempts.
     */
    private Integer getUserNumPasswordFailureAttempts(String userId) {
        UAUser objUser = UASubsystemSAP.getUserData(userId);
        int maxBadPasswordCount = GSSubsystemSAP.getBadPasswordLimit();
        if (objUser != null) {
            int userBadPasswordCount = objUser.getBadPasswordCount();
            //user's bad password count is incremented since this method is called before the failed login is saved in ldap
            return userBadPasswordCount >= maxBadPasswordCount ? maxBadPasswordCount : userBadPasswordCount + 1;
        }
        return null;
    }

    /**
     *
     * @param str
     * @return
     */
    private boolean isNullOrEmpty(String str) {
        return null == str || "".equals(str) || str.trim().length() < 1;
    }

    /**
     *
     */
    private static class ForceLogoffTimerTask extends TimerTask {
        /**
         * Logger for this class
         */
        private static final Logger LOGGER = LoggerFactory.getLogger(ForceLogoffTimerTask.class);
        private ISessionContext sessionToLogoffContext;

        ForceLogoffTimerTask(ISessionContext sessionToLogoffContext) {
            this.sessionToLogoffContext = sessionToLogoffContext;
        }

        @Override
        public void run() {
            LOGGER.debug("Force Logoff Timer Task Entered.");

            if (AASessionStore.getInstance().isUserSessionActive(sessionToLogoffContext)) {
                LOGGER.warn("Cleaning up unresponsive client session after a forced logoff: " + sessionToLogoffContext);

                IEnhancedSessionContext sessionToLogoff = (IEnhancedSessionContext) sessionToLogoffContext;
                LMInterFace.getInstance().createSecuritySystemEventRecord(
                        sessionToLogoff,
                        USMCommonStrings.IDS_AA_CLIENT_UNAVAILABLE
                                + sessionToLogoff.getUserName() + USMCommonStrings.IDS_AA_CLIENT_MACHINE
                                + sessionToLogoff.getClientMachineName() + USMCommonStrings.IDS_AA_CLIENT_DELAYED_FORCELOGOFF,
                        LogSeverity.WARNING, sessionToLogoff.getClientMachineName());

                USMServiceLocator servLoc = USMServiceLocator.getInstance();
                try {
                    ISecurityAuthenticationPrivateFacade fcd = servLoc.getSecurityAuthenticationPrivateFacade();
                    if (fcd != null) {
                        fcd.logoff(sessionToLogoffContext);
                    } else {
                        LOGGER.error("The Private interface returned is null.");
                    }
                } catch (UnexpectedException | BcbSecurityException e) {
                    LOGGER.error("Error cleaning up unresponsive client session after a forced logoff", e);
                }
            } else {
                LOGGER.debug("Session already logged off. Exiting Timer task.");
            }
        }
    }
    
    /**
     * Checks the access to a specified action (or set of actions) for a specific user
     *
     * @param username the username
     * @param sessionType the type of session
     * @return true if the user has access to at least one of the specified permission items; false otherwise.
     * @throws BcbSecurityException 
     */
    private boolean checkAccess(String username, SessionType sessionType) throws BcbSecurityException{
    	
		if (!sessionType.equals(SessionType.WEB)) {
			return true;
		}
    	
        if(username == null || username.isEmpty() || sessionType.getRequiredPermission() == null || sessionType.getRequiredPermission().isEmpty()){
            LOGGER.debug("checkAccess call with invalid parameters. Username or list of permission items are null.");
            throw new BcbSecurityException("User Authorization Failed.");
        }

        List<String> userGroups = UASubsystemSAP.getAllUserGroupNameForUser(username);

        if(userGroups.isEmpty()){
        	LOGGER.warn("The user {} does not has access {}.", username,sessionType.getRequiredPermission());
        	throw new BcbSecurityException("User Authorization Failed.");
        }

        IEnhancedSessionContext objSessionContext = new AASessionContext(username, "", USMCommonHelper.getLocalHostName(), "", "", userGroups, false);

		if (AAServerCache.getInstance().checkOperationPermission(sessionType.getRequiredPermission(), objSessionContext)) {
			return true;
		}

    	LOGGER.warn("The user {} does not has access {}.", username,sessionType.getRequiredPermission());
        throw new BcbSecurityException("User Authorization Failed.");
    }
}

