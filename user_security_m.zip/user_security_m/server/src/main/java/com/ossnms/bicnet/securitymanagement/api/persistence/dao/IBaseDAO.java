package com.ossnms.bicnet.securitymanagement.api.persistence.dao;

import com.ossnms.bicnet.securitymanagement.persistence.model.BaseUSMEntity;

import javax.persistence.Query;
import java.util.List;

/**
 *
 * @param <T> the type to be persisted
 * @param <ID> the identifier type
 */
public interface IBaseDAO<T extends BaseUSMEntity, ID> {

    /** Persistence Unit name. */
    String PERSISTENCE_UNIT_NAME = "USM_PU";

    T save(T item);
    void delete(T item);
    void delete(ID id);
    List<T> findAll();
    List<T> findAllByQuery(Query query);
    List<T> findInRange(int firstResult, int maxResults);
    T findById(ID id);
    long count();

    void detach(T item);
    void flush();
}
