package com.ossnms.bicnet.securitymanagement.server.ldap.dto;

import org.springframework.ldap.core.LdapEntryIdentification;

/**
 *
 */
public class LDAPUserContext {

    private LdapEntryIdentification ldapEntryIdentification;

    /**
     *
     * @return
     */
    public LdapEntryIdentification getLdapEntryIdentification() {
        return ldapEntryIdentification;
    }

    /**
     *
     * @param ldapEntryIdentification
     */
    public void setLdapEntryIdentification(LdapEntryIdentification ldapEntryIdentification) {
        this.ldapEntryIdentification = ldapEntryIdentification;
    }

    /**
     *
     * @return
     */
    public String getAbsoluteDN(){
        return this.ldapEntryIdentification.getAbsoluteName().toString();
    }
}
