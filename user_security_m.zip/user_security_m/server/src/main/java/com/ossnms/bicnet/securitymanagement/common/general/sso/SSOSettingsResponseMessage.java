package com.ossnms.bicnet.securitymanagement.common.general.sso;

import com.ossnms.bicnet.securitymanagement.common.general.ResponseMessage;
import com.ossnms.bicnet.securitymanagement.common.general.ResponseType;

/**
 *
 */
public final class SSOSettingsResponseMessage extends ResponseMessage {
    public SSOSettingsResponseMessage() {
    }

    public SSOSettingsResponseMessage(ResponseType type, String message) {
        super(type, message);
    }

    public SSOSettingsResponseMessage(ResponseType type, String messageFormat, String... params) {
        super(type, messageFormat, params);
    }

    public SSOSettingsResponseMessage(ResponseType type, String message, ResponseMessage... messages) {
        super(type, message, messages);
    }
}
