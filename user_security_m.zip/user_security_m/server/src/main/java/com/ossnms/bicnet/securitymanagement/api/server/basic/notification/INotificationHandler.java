package com.ossnms.bicnet.securitymanagement.api.server.basic.notification;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;

/**
* Interface that should be implemented by the Server side components
* which want to be informed about notifications. 
*/
public interface INotificationHandler {
	/**
	 * Function that will be invoked when a notification is being sent
	 * by any component.
	 * 
	 * @param msg The Message which contains information about the
	 * notificaiton.
	 */
	void handleNotification(USMMessage msg);
}
