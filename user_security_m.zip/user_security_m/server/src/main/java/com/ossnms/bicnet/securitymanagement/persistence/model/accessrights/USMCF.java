package com.ossnms.bicnet.securitymanagement.persistence.model.accessrights;

import com.ossnms.bicnet.securitymanagement.persistence.model.BaseUSMEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;

/**
 * created on 24/9/2014
 */
@Entity
@Table(name="USM_CF")
public class USMCF extends BaseUSMEntity {

    private static final long serialVersionUID = -2295552159303646434L;

    @Id
    @Column(name = "CF_ID", nullable = false)
    private String cfId;

    @Column(name = "NAME", nullable = false)
    private String name;

    @Column(name = "BUILD", nullable = false)
    private String build;

    @Column(name = "MAJOR", nullable = false)
    private String major;

    @Column(name = "MINOR", nullable = false)
    private String minor;

    @Column(name = "RELEASE", nullable = false)
    private String release;

    @Column(name = "DESCRIPTION", nullable = false)
    private String description;

    @OneToMany(mappedBy = "cf")
    private List<USMSecurableElement> securableElements;

    @OneToMany(mappedBy = "cf")
    private List<USMSecurableElementContainer> securableElementContainers;

    public USMCF(){}

    public USMCF(String cfId, String name, String build, String major, String minor, String release, String description) {
        this.cfId = cfId;
        this.name = name;
        this.build = build;
        this.major = major;
        this.minor = minor;
        this.release = release;
        this.description = description;
    }

    @Override
    public boolean isNew() {
        return false;
    }

    public String getCfId() {
        return cfId;
    }

    public void setCfId(String cfId) {
        this.cfId = cfId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBuild() {
        return build;
    }

    public void setBuild(String build) {
        this.build = build;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getMinor() {
        return minor;
    }

    public void setMinor(String minor) {
        this.minor = minor;
    }

    public String getRelease() {
        return release;
    }

    public void setRelease(String release) {
        this.release = release;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<USMSecurableElement> getSecurableElements() {
        return securableElements;
    }

    public void setSecurableElements(List<USMSecurableElement> securableElements) {
        this.securableElements = securableElements;
    }

    public List<USMSecurableElementContainer> getSecurableElementContainers() {
        return securableElementContainers;
    }

    public void setSecurableElementContainers(List<USMSecurableElementContainer> securableElementContainers) {
        this.securableElementContainers = securableElementContainers;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }

        USMCF usmcf = (USMCF) o;

        if (build != null ? !build.equals(usmcf.build) : usmcf.build != null){
            return false;
        }
        if (cfId != null ? !cfId.equals(usmcf.cfId) : usmcf.cfId != null){
            return false;
        }
        if (description != null ? !description.equals(usmcf.description) : usmcf.description != null){
            return false;
        }
        if (major != null ? !major.equals(usmcf.major) : usmcf.major != null){
            return false;
        }
        if (minor != null ? !minor.equals(usmcf.minor) : usmcf.minor != null){
            return false;
        }
        if (name != null ? !name.equals(usmcf.name) : usmcf.name != null){
            return false;
        }
        if (release != null ? !release.equals(usmcf.release) : usmcf.release != null){
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = cfId != null ? cfId.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (build != null ? build.hashCode() : 0);
        result = 31 * result + (major != null ? major.hashCode() : 0);
        result = 31 * result + (minor != null ? minor.hashCode() : 0);
        result = 31 * result + (release != null ? release.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        return result;
    }
}
