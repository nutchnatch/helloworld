/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCInvalidDomainException
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CONFIG   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.securitymanagement.common.domain.DCException;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;

/**
 * This exception is thrown to indicate that the given domain is invalid.
 * It could be  that some other client has already deleted that domain.
 */
class DCInvalidDomainException extends DCException {

	/**
	 * Constructor
	 */
	public DCInvalidDomainException() {

		super(DCMessages.getInstance().getString(DCMessages.DC_DOMAIN_INVALID));
	}

	/**
	 * Constructs an instance of DCInvalidDomainException with the
	 * specified detail message.
	 * @param reason  The user descriptive string associated with the Exception
	 */
	public DCInvalidDomainException(String reason) {
		super(reason);
	}
}
