package com.ossnms.bicnet.securitymanagement.api.server.domain;

import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;

import javax.naming.event.NamingEvent;
import java.util.List;

/**
 * created on 2/9/2014
 */
public interface IDomainWrapper {
    /**
     * Wraps ldap calls for creating a domain, DCDomainData equivalent in LDAP DS
     * will be created.
     *
     * @param domain
     *            The domain which has to be created.
     * @return boolean Returns true on successful creation of the domain in LDAP DS.
     */
    boolean createDomain(DCDomainData domain);

    /**
     * Deletes the domain whose domain data is the one specified.
     *
     * @param domain
     *            The domain object which has to be removed from LDAP DS.
     * @return boolean Returns true on successful deletion of the domain.
     */
    boolean deleteDomain(DCDomainData domain);

    /**
     * Modifies the object in the domain whose domain id and name(DCDomainData)
     * is given.
     *
     * @param domain
     *            Domain which has to be modified. Only the user description is
     *            modifiable.
     * @return boolean Returns true on successful modification of the domain.
     */
    boolean modifyDomain(DCDomainData domain);

    /**
     * Deletes the given mapping element from the LDAP DS. User group and domain id
     * are uniq to a mapping.
     *
     * @param mapping
     *            The mapping object which needs to be deleted from LDAP DS.
     * @return boolean Returns true on successful deletion of the mapping.
     */
    boolean deleteMapping(DCDomainMapping mapping);

    /**
     * Modifies the domain mapping that is stored in the db. User
     * group along with domain id is uniq to a mapping. Modification means only
     * changing the policy id for the user.
     *
     * @param mapping
     *            The mapping object which needs to be modified.
     * @return boolean Returns true on successful modification of the mapping.
     */
    boolean modifyMapping(DCDomainMapping mapping);

    /**
     * Creates a new mapping in the domain db with the details given.
     * User group and domain id make the mapping uniq.
     *
     * @param mapping
     *            The mapping object which needs to be created in LDAP DS.
     * @return boolean Returns true on successful creation of the mapping
     *         object in the db.
     */
    boolean createMapping(DCDomainMapping mapping);

    /**
     * Gets the list of all configured domains from the db.
     *
     * @return List<DCDomainData> Returns a vector of DCDomainData that have been retrieved
     *         from the db.
     */
    List<DCDomainData> getAllDomains();

    /**
     * Gets the list of all configured mappings from the db.
     *
     * @return List<DCDomainMapping> Returns a vector of DCDomainMapping.
     */
    List<DCDomainMapping> getAllMappings();

    /**
     * This method constructs a transient DCDomainData instance out of the given event.
     *
     * @param namingEvent LDAP V3 event
     * @return DCDomainData
     *      A DCDomainData instance initialized from the event.
     */
    DCDomainData loadDomain(NamingEvent namingEvent);

    /**
     * This method constructs a transient DCDomainMapping instance out of the given event.
     *
     * @param namingEvent
     *      LDAP V3 event
     * @return DCDomainMapping
     *      A DCDomainMapping instance initialized from the LDAP event.
     */
    DCDomainMapping loadDomainMapping(NamingEvent namingEvent) ;

    /**
     * This method is used to validate if a certain DC domain mapping
     * (domainMapping) already exists within LDAP.
     *
     * @return True if exists, otherwise false.
     */
    boolean isDCDomainMappingExist(DCDomainMapping domainMapping);

    /**
     * This method is used to validate if a policy, identified by its ID, is
     * already mapped on domain mappings.
     *
     * @param policyId
     *            Policy ID
     * @return True if it is already associated to any user group, otherwise
     *         false
     */
    boolean isPolicyMapped(int policyId);

    /**
     * This method is used to validate if a group, identified by its name, is
     * already mapped on domain mappings.
     *
     * @param userGroupName
     *            User group name to validate its existence
     *
     * @return True if it is already associated to any user group, otherwise
     *         false
     */
    boolean isUserGroupMapped(String userGroupName);


}
