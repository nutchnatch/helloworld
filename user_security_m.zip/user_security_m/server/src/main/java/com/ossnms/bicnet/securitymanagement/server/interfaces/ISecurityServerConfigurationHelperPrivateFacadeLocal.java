package com.ossnms.bicnet.securitymanagement.server.interfaces;

public interface ISecurityServerConfigurationHelperPrivateFacadeLocal extends ISecurityServerConfigurationHelperPrivateFacade { }

