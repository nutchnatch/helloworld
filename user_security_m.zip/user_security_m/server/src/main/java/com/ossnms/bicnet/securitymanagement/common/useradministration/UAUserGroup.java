/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   UAUserGroup
 * Author:      Jogender
 * Substitute	Babu B
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER_GROUP.VIEW
 *       : TNMS.DX2.SM.USER_GROUP.CONFIGURE
 *       : TNMS.DX2.SM.USER_GROUP.CREATE
 *       : TNMS.DX2.SM.USER_GROUP.ASSIGN

 * 		 :
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.useradministration;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import org.apache.log4j.Logger;

import java.io.Serializable;
/**
 * This Transient class contains all data of a User Group.
 */
public class UAUserGroup implements Serializable {

	/**
     * 
     */
    private static final long serialVersionUID = 1L;

    /**
		 * Data member for the Logging of the class.
		 */
	private static final Logger LOGGER = Logger.getLogger(UAUserGroup.class);
	/**
	 *  Name of the user group
	 */
	private String strName;

	/**
	 *  Description of the user group
	 */
	private String strDescription;

	/** Unique identifier for the user group */
	private String strDistinguishedName;

	/**
	 * Default constructor
	 */
	public UAUserGroup() {
		this.strName = "";
		this.strDescription = "";
		this.strDistinguishedName = "";
	}

	/**
	 * Constructor to form usergroup
	 * @param p_Name is a name of the usergroup
	 * @param p_Description holds the description of the user group
	 * @param p_DN holds the distinguished name of the user group
	 */

	public UAUserGroup(String p_Name, String p_Description, String p_DN) {
		this.strName = p_Name;
		strDescription = (p_Description != null) ? p_Description : "";
		this.strDistinguishedName = (p_DN != null) ? p_DN : "";

	}

	/**
	 * pushes the user common name and id into usmmessage
	 * @param pMsg
	 */
	public void pushMe(USMMessage pMsg) {
		pMsg.pushString(strName);
		pMsg.pushString(strDescription);
		pMsg.pushString(strDistinguishedName);
	}
	/**
	 * pops the user common name and id from the usmmessage
	 * @param p_Ugrp
	 */
	public void popMe(USMMessage p_Ugrp) {
		strDistinguishedName = p_Ugrp.popString();
		strDescription = p_Ugrp.popString();
		strName = p_Ugrp.popString();
	}

	/**
	 * Returns the user group descriptiuon
	 *
	 * @return
	 *      String - User Group Description
	 */
	public String getDescription() {
		return strDescription;
	}

	/**
	 * Returns the distinguished name for user group
	 *
	 * @return
	 *      String - Distinguished name
	 */
	public String getDistinguishedName() {
		return strDistinguishedName;
	}

	/**
	 * Returns the user group name
	 *
	 * @return String -User Group Name
	 */
	public String getName() {
		return strName;
	}

	/**
	 * Sets the description for user group
	 *
	 * @param string - user group description
	 * @return void
	 */
	public void setDescription(String string) {
		strDescription = string;
	}

	/**
	 * Sets the distinguish name for user group
	 *
	 * @param p_strDN - distinguish name
	 * @return void
	 */
	public void setDistinguishedName(String p_strDN) {
		strDistinguishedName = p_strDN;
	}

	/**
	 * Sets the name for user group
	 *
	 * @param p_strName - user group name
	 * @return void
	 */
	public void setName(String p_strName) {
		strName = p_strName;
	}

	/**
		 * Function to retrieve the String equivalent of this object.
		 * 
		 * @return java.lang.String 
		 *      The String which is a representation of this object.
		 */
	@Override
    public String toString() {
		return strName;
	}

	/**
	 * Function to compare 2 objects for equality.
	 * 
	 * @param p_obj
	 *            The Object which has to be compared with this object.
	 * @return boolean Indicates whether the 2 objects are equal or not. True
	 *         indicates that the objects are equal.
	 */
	@Override
    public boolean equals(Object p_obj) {
		boolean bOp = false;
		if (p_obj instanceof UAUserGroup) {
			UAUserGroup userObj = (UAUserGroup) p_obj;
			String userGroupName = userObj.getName();

			if ((strName.equals(userGroupName))) {

				bOp = true;
			}
		} else {
			LOGGER.error("Equality check using a wrong type");
		}
		return bOp;
	}

	/**
	 * Returns the hash code value for this Field. 
	 * 
	 * @return
	 *      the integer hash code
	 */
	@Override
    public int hashCode() {
		return strName.hashCode();
	}

}
