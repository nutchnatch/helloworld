package com.ossnms.bicnet.securitymanagement.persistence.model.user;

import com.ossnms.bicnet.securitymanagement.persistence.model.BaseUSMEntity;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;
import org.hibernate.annotations.Type;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import java.util.List;

/**
 *
 */
@Entity
@Table(name = "USM_USER",
        uniqueConstraints = {
                @UniqueConstraint(columnNames = {"USERNAME"})
        }
)
@NamedQueries({
        @NamedQuery(name="usmUser.findByUsername", query = "from USMUser u where LOWER(u.username) = LOWER(:username)"),
        @NamedQuery(name = "usmUser.findByInactivityTimeoutEnabled", query = "from USMUser u where u.inactivityTimeoutEnabled = :enabled")
})
public class USMUser extends BaseUSMEntity {

    public static final String QUERY_FIND_BY_USERNAME = "usmUser.findByUsername";
    public static final String PARAM_FIND_BY_USERNAME_1 = "username";

    public static final String QUERY_FIND_BY_INACTIVITY_TIMEOUT_ENABLED = "usmUser.findByInactivityTimeoutEnabled";
    public static final String PARAM_FIND_BY_INACTIVITY_TIMEOUT_ENABLED_1 = "enabled";

    private static final String TYPE_BOOLEAN = "yes_no";

    @Id
    @GeneratedValue(strategy= GenerationType.AUTO, generator = "USMUserSequence")
    @SequenceGenerator(name="USMUserSequence", sequenceName = "USM_SEQ_USER")
    @Column(name = "ID")
    private Integer id;

    @Column(name = "USERNAME", nullable = false, unique = true)
    private String username;

    @Enumerated(EnumType.STRING)
    @Column(name = "TYPE", nullable = false)
    private AuthenticationType authenticationType;

    @Column(name = "FIRST_NAME", nullable = false)
    private String firstName;

    @Column(name = "LAST_NAME", nullable = false)
    private String lastName;
    
    @Column(name = "FULL_NAME", nullable = false)
    private String fullName;

    @Column(name = "PASSWORD", nullable = false)
    private String password;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "PHONE")
    private String phone;

    @Column(name = "FAX")
    private String fax;

    @Column(name = "EMPLOYEE_NUMBER")
    private String employeeNumber;

    @Column(name = "ACTIVATION_TIME")
    private String activationTime;

    @Column(name = "LAST_LOGOFF")
    private String lastLogoff;

    @Column(name = "LAST_LOGON")
    private String lastLogon;

    @Column(name = "LAST_LOGON_ATTEMPT")
    private String lastLogonAttempt;

    @Column(name = "HOST_NAME")
    private String hostName;

    @Column(name = "LAST_PASSWORD_CHANGE")
    private String lastPasswordChange;

    @Column(name = "PASSWORD_CHANGE_INTERVAL")
    private int passwordChangeInterval;

    @Column(name = "PASSWORD_RETRY_COUNT")
    private int passwordRetryCount;

    @Column(name = "SIMULTANEOUS_USER_SESSIONS")
    private int simultaneousUserSessions;

    @Column(name = "EXPIRATION_DATE")
    private long expirationDate;

    @Type(type = TYPE_BOOLEAN)
    @Column(name = "ACCOUNT_LOCKED")
    private boolean accountLocked;

    @Type(type = TYPE_BOOLEAN)
    @Column(name = "ACCOUNT_EXPIRES")
    private boolean accountExpires;

    @Type(type = TYPE_BOOLEAN)
    @Column(name = "ACCOUNT_ACTIVATED")
    private boolean accountActivated;

    @Type(type = TYPE_BOOLEAN)
    @Column(name = "PASSWORD_MUST_CHANGE")
    private boolean passwordMustChange;
    
    @Type(type = TYPE_BOOLEAN)
    @Column(name = "PASSWORD_CAN_CHANGE")
    private boolean passwordCanChange;

    @Type(type = TYPE_BOOLEAN)
    @Column(name = "PASSWORD_EXPIRES")
    private boolean passwordExpires;

    @Type(type = TYPE_BOOLEAN)
    @Column(name = "PASSWORD_EXPIRED")
    private boolean passwordExpired;

    @Type(type = TYPE_BOOLEAN)
    @Column(name = "RESTRICT_USER_SESSIONS")
    private boolean restrictUserSessions;

    @Type(type = TYPE_BOOLEAN)
    @Column(name = "INACTIVITY_TIMEOUT_ENABLED", nullable = false)
    private boolean inactivityTimeoutEnabled;

    @Column(name = "INACTIVITY_TIMEOUT")
    private int inactivityTimeout;

    @OneToMany(mappedBy = "user", fetch = FetchType.EAGER, orphanRemoval = true, cascade = CascadeType.ALL)
    private List<USMPasswordHistory> passwords;

    @Override
    public boolean isNew() {
        return id == null || id == 0;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public AuthenticationType getAuthenticationType() {
        return authenticationType;
    }

    public void setAuthenticationType(AuthenticationType authenticationType) {
        this.authenticationType = authenticationType;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getActivationTime() {
        return activationTime;
    }

    public void setActivationTime(String activationTime) {
        this.activationTime = activationTime;
    }

    public String getLastLogoff() {
        return lastLogoff;
    }

    public void setLastLogoff(String lastLogoff) {
        this.lastLogoff = lastLogoff;
    }

    public String getLastLogon() {
        return lastLogon;
    }

    public void setLastLogon(String lastLogon) {
        this.lastLogon = lastLogon;
    }

    public String getLastLogonAttempt() {
        return lastLogonAttempt;
    }

    public void setLastLogonAttempt(String lastLogonAttempt) {
        this.lastLogonAttempt = lastLogonAttempt;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public String getLastPasswordChange() {
        return lastPasswordChange;
    }

    public void setLastPasswordChange(String lastPasswordChange) {
        this.lastPasswordChange = lastPasswordChange;
    }

    public int getPasswordChangeInterval() {
        return passwordChangeInterval;
    }

    public void setPasswordChangeInterval(int passwordChangeInterval) {
        this.passwordChangeInterval = passwordChangeInterval;
    }

    public int getPasswordRetryCount() {
        return passwordRetryCount;
    }

    public void setPasswordRetryCount(int passwordRetryCount) {
        this.passwordRetryCount = passwordRetryCount;
    }

    public boolean isAccountLocked() {
        return accountLocked;
    }

    public void setAccountLocked(boolean accountLocked) {
        this.accountLocked = accountLocked;
    }

    public boolean isAccountActivated() {
        return accountActivated;
    }

    public void setAccountActivated(boolean accountActivated) {
        this.accountActivated = accountActivated;
    }

    public boolean isPasswordMustChange() {
        return passwordMustChange;
    }

    public void setPasswordMustChange(boolean passwordMustChange) {
        this.passwordMustChange = passwordMustChange;
    }
    
    public boolean isPasswordCanChange() {
        return passwordCanChange;
    }
    
    public void setPasswordCanChange(boolean passwordCanChange) {
        this.passwordCanChange = passwordCanChange;
    }

    public boolean isPasswordExpires() {
        return passwordExpires;
    }

    public void setPasswordExpires(boolean passwordExpires) {
        this.passwordExpires = passwordExpires;
    }

    public boolean isPasswordExpired() {
        return passwordExpired;
    }

    public void setPasswordExpired(boolean passwordExpired) {
        this.passwordExpired = passwordExpired;
    }

    public boolean isInactivityTimeoutEnabled() {
        return inactivityTimeoutEnabled;
    }

    public void setInactivityTimeoutEnabled(boolean inactivityTimeoutEnabled) {
        this.inactivityTimeoutEnabled = inactivityTimeoutEnabled;
    }

    public int getInactivityTimeout() {
        return inactivityTimeout;
    }

    public void setInactivityTimeout(int inactivityTimeout) {
        this.inactivityTimeout = inactivityTimeout;
    }

    public List<USMPasswordHistory> getPasswords() {
        return passwords;
    }

    public void setPasswords(List<USMPasswordHistory> passwords) {
        this.passwords = passwords;
    }

    public int getSimultaneousUserSessions() {
        return simultaneousUserSessions;
    }

    public void setSimultaneousUserSessions(int simultaneousUserSessions) {
        this.simultaneousUserSessions = simultaneousUserSessions;
    }

    public boolean isAccountExpires() {
        return accountExpires;
    }

    public void setAccountExpires(boolean accountExpires) {
        this.accountExpires = accountExpires;
    }

    public long getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(long expirationDate) {
        this.expirationDate = expirationDate;
    }

    public boolean isRestrictUserSessions() {
        return restrictUserSessions;
    }

    public void setRestrictUserSessions(boolean restrictUserSessions) {
        this.restrictUserSessions = restrictUserSessions;
    }

    public String getEmployeeNumber() {
        return employeeNumber;
    }

    public void setEmployeeNumber(String employeeNumber) {
        this.employeeNumber = employeeNumber;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }

        USMUser usmUser = (USMUser) o;

        return new EqualsBuilder()
            .append(accountActivated, usmUser.accountActivated)
            .append(accountLocked, usmUser.accountLocked)
            .append(passwordChangeInterval, usmUser.passwordChangeInterval)
            .append(passwordExpired, usmUser.passwordExpired)
            .append(passwordExpires, usmUser.passwordExpires)
            .append(passwordMustChange, usmUser.passwordMustChange)
            .append(passwordRetryCount, usmUser.passwordRetryCount)
            .append(activationTime, usmUser.activationTime)
            .append(email, usmUser.email)
            .append(fax, usmUser.fax)
            .append(employeeNumber, usmUser.employeeNumber)
            .append(firstName, usmUser.firstName)
            .append(fullName, usmUser.fullName)
            .append(id, usmUser.id)
            .append(lastLogoff, usmUser.lastLogoff)
            .append(lastLogon, usmUser.lastLogon)
            .append(lastLogonAttempt, usmUser.lastLogonAttempt)
            .append(hostName, usmUser.hostName)
            .append(lastName, usmUser.lastName)
            .append(lastPasswordChange, usmUser.lastPasswordChange)
            .append(password, usmUser.password)
            .append(phone, usmUser.phone)
            .append(username, usmUser.username)
            .append(authenticationType, usmUser.authenticationType)
            .append(simultaneousUserSessions, usmUser.simultaneousUserSessions)
            .append(expirationDate, usmUser.expirationDate)
            .append(restrictUserSessions, usmUser.restrictUserSessions)
            .append(accountExpires, usmUser.accountExpires)
            .isEquals();

    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(id)
            .append(username)
            .append(authenticationType)
            .append(firstName)
            .append(lastName)
            .append(fullName)
            .append(password)
            .append(email)
            .append(phone)
            .append(fax)
            .append(employeeNumber)
            .append(activationTime)
            .append(lastLogoff)
            .append(lastLogon)
            .append(lastLogonAttempt)
            .append(hostName)
            .append(lastPasswordChange)
            .append(passwordChangeInterval)
            .append(passwordRetryCount)
            .append(accountLocked)
            .append(accountActivated)
            .append(passwordMustChange)
            .append(passwordExpires)
            .append(passwordExpired)
            .append(simultaneousUserSessions)
            .append(expirationDate)
            .append(restrictUserSessions)
            .append(accountExpires)
            .toHashCode();
    }
}
