/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AAAdvisoryDetails
 * Author      	Jogender Singh
 * Substitute	Babu B
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 * Project: TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.ADVISORY_CONFIGURE
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.auth;

import org.apache.log4j.Logger;

import java.io.Serializable;

/**
* This class holds the data of the Advisory message transiently.
*/
public class AAAdvisoryDetails implements Serializable {

	/**
     * 
     */
    private static final long serialVersionUID = 1L;

    /**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(AAAdvisoryDetails.class);

	/**  Advisory message contents */
	private String advisoryMessage;

	/**  User Id  */
	private String userID;

	/**  Last login time for user */
	private String lastLogin;

	/**  Data member to hold flag for advisory message has to be displayed or not on client side */
	private boolean isDisplay;

	/**  Data member to hold period for client inactivity time out */
	private int inactivityTimeout;

	/**
	 * Default Constructor
	 *
	 */
	public AAAdvisoryDetails() {
	}

	/** Default constructor
	* @param p_advisoryMessage - Advisory message content
	* @param p_userId          - Logged in user id
	* @param pLastLogin       - Last login time for the same user
	*/
	public AAAdvisoryDetails(
		String p_advisoryMessage,
		String p_userId,
		String pLastLogin,
		boolean pIsDisplay,
		int pInactivityTimeout) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"AAAdvisoryDetails("
					+ p_advisoryMessage
					+ ", "
					+ p_userId
					+ ", "
					+ pLastLogin
					+ ", "
					+ pIsDisplay
					+ ") Entry");
		}
		this.advisoryMessage = p_advisoryMessage;
		this.userID = p_userId;
		this.lastLogin = pLastLogin;
		this.isDisplay = pIsDisplay;
		this.inactivityTimeout = pInactivityTimeout;
		LOGGER.debug("AAAdvisoryDetails(...)	Exit");
	}
	/**
	 * Gets advisory message contents to be displayed in Advisory message window
	 *  Extracted and Used on client side to set field in advisory message window	
	 * @return String - Advisory message contents 
	 *
	 */
	public String getAdvisoryMessage() {
		return advisoryMessage;
	}

	/**
	 * Gets last login time to be displayed in Advisory message window
	 * Extracted and Used on client side to set field in advisory message window
	 * @return String - Last login time
	 *
	 */
	public String getLastLogin() {
		return lastLogin;
	}

	/**
	 * Gets user id to be displayed in Advisory message window
	 * Extracted and Used on client side to set field in advisory message window
	 * @return String - User id 
	 *
	 */
	public String getUserId() {
		return userID;
	}

	/**
	 * Sets advisory message contents to be displayed in Advisory message window
	 * Sets on server side to set field in advisory message window on client side
	 * @param  p_message - Advisory Message contents	
	 *
	 */
	public void setAdvisoryMessage(String p_message) {
		advisoryMessage = p_message;
	}

	/**
	 * Sets user last login time to be displayed in Advisory message window
	 * Sets on server side to set field in advisory message window on client side
	 * @param  pLastLogin - Last Login Time
	 *
	 */
	public void setLastLogin(String pLastLogin) {
		lastLogin = pLastLogin;
	}

	/**
	 * Sets user id to be displayed in Advisory message window
	 * Sets on server side to set field in advisory message window on client side
	 * @param   p_userID - User id to be set	
	 *
	 */
	public void setUserId(String p_userID) {
		userID = p_userID;
	}
	/**
	 * Returns the flag for advisory message to be displayed or not on client side
	 *@return boolean - true/false according to data populated
	 *
	 */
	public boolean isDisplay() {
		return this.isDisplay;
	}

	/**
	 * Sets display flag to be displayed the Advisory message window or not	 *
	 * @param   pIsDisplay - User id to be set
	 */
	public void setDisplay(boolean pIsDisplay) {
		this.isDisplay = pIsDisplay;
	}

	/**
	 * gets inactivity time out for the client *	
	 * @return int - inactivity period for the client expiration
	 *
	 */
	public int getInactivitTimeout() {
		return this.inactivityTimeout;
	}
	/**
	 * Sets inactivity time out for the client *
	 * @param   p_time - inactivity period for the client expiration
	 *
	 */
	public void setInactivitTimeout(int p_time) {
		this.inactivityTimeout = p_time;
	}
}
