/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AAServerLifeCycleController
 * Author      	Jogender Singh
 * Substitute	Babu B
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.SERVER.AUTHORIZATION
 * 		  TNMS.DX2.SM.CLIENT.AUTHORIZE
 *        TNMS.DX2.SM.SERVER.J2EE
 * 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 14-Apr-2005	Muyeen Munaver	CF001025	Stop the Server - message to the clients
 * 05-May-2005  Muyeen Munaver  CF001312   Master-Master Replication for Sun ONE DS
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.auth;

import com.ossnms.bicnet.securitymanagement.common.auth.AAMessageType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.server.auth.monitor.AAServerSessionTimer;
import com.ossnms.bicnet.securitymanagement.server.basic.USMServerLifeCycleControllerIfc;
import com.ossnms.bicnet.securitymanagement.server.basic.notification.USMNotifier;
import org.apache.log4j.Logger;

;

/**
 * This class which is responsible for the initialization of the
 * USM Server component.
 */
public final class AAServerLifeCycleController
    implements USMServerLifeCycleControllerIfc {
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER =
        Logger.getLogger(AAServerLifeCycleController.class);

    /**
     * Data member to hold the singleton instance of the class.
     */
    private static AAServerLifeCycleController instance = new AAServerLifeCycleController();

    /**
     * Private Constructor to prevent instantiation
     */
    private AAServerLifeCycleController() {
    }

    /**
     * Function to return the singleton instance of the class
     *
     * @return USMServerLifeCycleController -
     * 			The singleton instance of the class.
     *
     */
    public static AAServerLifeCycleController getInstance() {
        LOGGER.debug("getInstance() called");
        return instance;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.securitymanagement.common.basic.USMLifeCycleController#initialize()
     */
    @Override
    public boolean initialize() {
        LOGGER.debug("initialize() 	Entry");

        // Register for Policy / Mapping - Create/ Delete / Modify Notifications (synchronous)
        AAAuthenticationServerNotifHandler handler =
            new AAAuthenticationServerNotifHandler();
        USMNotifier.getInstance().register(handler);

        //At start up server, Security data is cached in USMServerCache object
        AAServerCache.getInstance().initializeServerCache();
//        AALdapInterface.getInstance().createProfileContainer();
		AAServerSessionTimer.getInstance().initializeTimer();
        LOGGER.debug("initialize() 	Exit");
        return true;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.securitymanagement.common.basic.USMLifeCycleController#cleanup()
     */
    @Override
    public boolean cleanup() {
        LOGGER.debug("cleanup() 	Entry");

        // At this point it should send a notification to the clients 
        // that the server has been shut down.
        sendNotifToClientsOfShutDown();
        AASessionStore.getInstance().cleanup();

        AAServerCache.getInstance().cleanup();
        LOGGER.debug("cleanup() 	Exit");

        return true;
    }

    /**
     * Helper function to send the notification to the clients that the server has 
     * been shut down.
     */
    private void sendNotifToClientsOfShutDown() {
        LOGGER.debug("sendNotifToClientsOfShutDown() 	Entry");

        USMMessage shutDownMsg =
            new USMMessage(
                AAMessageType.AA_NOTIFICATION_SERVER_SHUTDOWN,
                USMMessage.USMMESSAGE_NOTIFICATION);
        String strHostName = USMCommonHelper.getLocalHostName();
        if (strHostName != null) {
            strHostName = "";
        }
        shutDownMsg.pushString(strHostName);
        USMNotifier notifier = USMNotifier.getInstance();
        notifier.sendNotification(shutDownMsg);

        LOGGER.debug("sendNotifToClientsOfShutDown() 	Entry");
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.securitymanagement.server.basic.USMServerLifeCycleControllerIfc#reinitialize()
     */
    @Override
    public boolean reinitialize() {
        LOGGER.debug("reinitialize() 	Entry");

        //At start up server, Security data is cached in USMServerCache object
        AAServerCache.getInstance().initializeServerCache();
//        AALdapInterface.getInstance().createProfileContainer();
        LOGGER.debug("reinitialize() 	Exit");
        return true;
    }
}
