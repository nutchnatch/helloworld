/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	BSServerHelper
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_OBJECTS
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_ACL 
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_SECURITY
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.INSERT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 19-Jan-2005	Muyeen Munaver	CF000137 - #678: Add a method getType or so to the ISecurableObject
 * 25-Apr-2005	Muyeen Munaver	CF001917 - Policy with FM menu associated - not possible to do ACK or Add Note
 * 14-June-2005  Muyeen Munaver  CF000209 - Changes in the ISecurityProviderFacade / IManagedObject
 * 05-May-2005  Babu B  CF001312   Master-Master Replication for Sun ONE DS
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.bicnetserver;

import com.ossnms.bicnet.bcb.facade.common.IIconPairFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.ManagedObjectType;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.IIconPair;
import com.ossnms.bicnet.bcb.model.common.IIconPairId;
import com.ossnms.bicnet.bcb.model.security.ISecurableObject;
import com.ossnms.bicnet.bcb.model.security.ISecurableObjectContainer;
import com.ossnms.bicnet.bcb.model.security.ISecurableObjectContainerId;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSAccessControlList;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSMessageType;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableBase;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObjectContainer;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.server.auth.AALocalSecurityProviderFacadeImpl;
import com.ossnms.bicnet.securitymanagement.server.basic.notification.USMNotifier;
import com.ossnms.bicnet.servicelocator.BiCNetServiceLocator;
import com.ossnms.bicnet.util.UnexpectedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Helper class to BS Server part.
 */
public class BSServerHelper {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(BSServerHelper.class);

	/**
	 * Helper function to convert and retrieve Trans Securable Object List from
	 * ISecurableObject Array
	 * 
	 * @param secObjects Array of Securable Objects.
	 * @param cf CF which owns the Securable Objects
	 * @return List of newly created Trans Securable object.
	 */
	static List<BSSecurableObject> convertToSecurableObjectList(ISecurableObject[] secObjects, BSTransBicNetCFInfo cf) {
		LOGGER.debug("Entering convertToSecurableObjectList. CF : " + cf);

		if ((secObjects == null) || cf == null) {
			LOGGER.error("Parameter null. CF : {} Array : {}", cf, Arrays.toString(secObjects));
			throw new InvalidParameterException();
		}

		List<BSSecurableObject> lstObjs = new ArrayList<>();

		for (ISecurableObject secObj : secObjects) {
			BSSecurableObject transSecObj = convertToSecurableObject(secObj, cf);
			lstObjs.add(transSecObj);
		}

		LOGGER.debug("Exiting convertToSecurableObject. Server is : " + cf + " Securable Objects are : " + lstObjs);

		return lstObjs;
	}

	/**
	 * Helper function to convert and retrieve Trans Securable Object from
	 * ISecurableObject
	 * 
	 * @param secObjs ISecurableObject which has to be converted.
	 * @param cf CF which owns the Securable Objects
	 * @return The newly created Transient Securable object.
	 */
	static BSSecurableObject convertToSecurableObject(ISecurableObject secObjs, BSTransBicNetCFInfo cf) {
		LOGGER.debug("Entering convertToSecurableObject. CF : " + cf + " SecurableObject : " + secObjs);

		if (null == cf || null == secObjs) {
			LOGGER.error("Parameter cannot be null. CF : " + cf + " SecurableObject : " + secObjs);
			throw new InvalidParameterException();
		}
		
		String strCFName = cf.getName();
		String strID = cf.getCFid();
		BSAccessControlList acl = new BSAccessControlList();

		String strSecObjName = secObjs.getNativeName();
		String strUniqueName = USMCommonHelper.getUSMizedStringForKey(secObjs.key());
		IIconPairId iconId = secObjs.getIconId();
		ManagedObjectType type = secObjs.moType();
		
		List<BSSecurableObjectContainer> containers = convertToSecurableObjectContainerList(secObjs.getContainerList(), cf);
		
		IIconPair icon = getIconFromComponent(iconId);

		BSSecurableObject secObj = new BSSecurableObject(strSecObjName, strUniqueName, strID, strCFName, acl, icon, containers, type);

		LOGGER.debug("Exiting convertToSecurableObject. Trans Object : {}", secObj);

		return secObj;
		}

	/**
	 *
	 * @param containers
	 * @param cf
     * @return
     */
	static List<BSSecurableObjectContainer> convertToSecurableObjectContainerList(ISecurableObjectContainerId[] containers, BSTransBicNetCFInfo cf) {
		List<BSSecurableObjectContainer> containerList = new ArrayList<>();
		if (containers == null) {
			return containerList;
		}
		
		for (ISecurableObjectContainerId container : containers) {
			if(container instanceof ISecurableObjectContainer){
				ISecurableObjectContainer containerItem = (ISecurableObjectContainer) container;

				String name = containerItem.getNativeName();
				String uniqueName = USMCommonHelper.getUSMizedStringForKey(containerItem.key());
				String cfId = cf.getCFid();
				String cfName = cf.getName();
				IIconPairId iconId = containerItem.getIconId();
				ManagedObjectType type = containerItem.moType();
				// get the compound flag
				boolean compound = containerItem.getCompound();

				List<BSSecurableObjectContainer> childContainers = convertToSecurableObjectContainerList(containerItem.getContainerList(), cf);
				IIconPair icon = getIconFromComponent(iconId);
				BSSecurableObjectContainer transContainer = new BSSecurableObjectContainer(name, uniqueName, cfId, cfName, icon, compound, childContainers, type);

				containerList.add(transContainer);
			}
		}
		return containerList;
	}

	/**
	 * Helper function to send Register / UnRegister Notification.
	 * 
	 * @param cf CF for which the Object has been added/removed
	 * @param lstObjs List of Objects that have been added/deleted
	 * @param register Whether the Object are added or removed. True indicates objects added
	 */
	static void sendRegistrationObjectNotification(BSTransBicNetCFInfo cf, List<BSSecurableObject> lstObjs, boolean register) {
		LOGGER.debug("Entering sendRegistrationObjectNotification. CF : {} List : {} Register : {}", cf, lstObjs, register);

		if ((cf == null) || (lstObjs == null)) {
			LOGGER.error( "Parameter cannot be null. CF : {} Objects : {}", cf, lstObjs);
			throw new InvalidParameterException();
		}

		USMBaseMsgType type = (register) 	? BSMessageType.BS_NOT_NEW_SEC_OBJ_REGISTERED : BSMessageType.BS_NOT_SEC_OBJ_UNREGISTERED;
		USMMessage msg = new USMMessage(type, USMMessage.USMMESSAGE_NOTIFICATION);

		// Only if there are some elements in the List does it make
		// sense to send the notification.
		if (lstObjs.size() > 0) {

			BSCommonHelper.pushSecurableObjectsListIntoMessage(msg, lstObjs);
			cf.pushTo(msg);

			USMNotifier.getInstance().sendNotification(msg);

		}

		LOGGER.debug("Exiting sendRegistrationObjectNotification. Message sent is : {}", msg);
	}

	/**
	 * Notify ACL Modified (Sec. Object <-> Domain changes).
	 * @param securableObjects
     */
	static void notifyACLModified(List<BSSecurableObject> securableObjects){
		new SecurableObjectFacade().sendSecurableObjectsChanged(securableObjects, "");
	}

	/**
	 * Notify Mapping Modified (Sec. Objects <-> Domain/Policy changes).
	 * @param securableObjects
	 * @param userGroupName
     */
	public static void notifyMappingModified(List<BSSecurableObject> securableObjects, String userGroupName){
		new SecurableObjectFacade().sendSecurableObjectsChanged(securableObjects, userGroupName);
	}

	/**
	 * Helper function to send Register / UnRegister Notification.
	 * 
	 * @param cf CF for which the Object has been added/removed
	 * @param lstObjs List of Objects that have been added/deleted
	 */
	static void sendSecObjectModifiedNotification(BSTransBicNetCFInfo cf, List<? extends BSSecurableBase> lstObjs) {
		USMMessage msg;
		LOGGER.debug("sendSecObjectModifiedNotification(BSTransBicNetCFInfo p_CF = {}, List p_lstObjs = {}) - entry", cf, lstObjs);

		if ((cf == null) || (lstObjs == null)) {
			LOGGER.error("Parameter cannot be null. CF : {} Objects : {}", cf, lstObjs);
			throw new InvalidParameterException();
		}

		if(lstObjs.isEmpty()){
			LOGGER.debug("sendSecObjectModifiedNotification(BSTransBicNetCFInfo, List) - exit due to empty parameter list");
			return;
		}

		if(lstObjs.get(0) instanceof BSSecurableObjectContainer){
			msg = new USMMessage(BSMessageType.BS_NOT_SEC_OBJ_CONTAINER_CHANGE, USMMessage.USMMESSAGE_NOTIFICATION);
			BSCommonHelper.pushSecurableObjectContainersListIntoMessage(msg, (List<BSSecurableObjectContainer>) lstObjs);
		}
		else if(lstObjs.get(0) instanceof BSSecurableObject){
			msg = new USMMessage(BSMessageType.BS_NOT_SEC_OBJ_CHANGED, USMMessage.USMMESSAGE_NOTIFICATION);
			BSCommonHelper.pushSecurableObjectsListIntoMessage(msg, (List<BSSecurableObject>) lstObjs);
		}
		else {
				LOGGER.debug("sendSecObjectModifiedNotification(BSTransBicNetCFInfo, List) - exit due to unexpected parameter object type");
			return;
		}

		cf.pushTo(msg);
		USMNotifier.getInstance().sendNotification(msg);
	}
	
	/**
	 *
	 * @param iconId
	 * @return
     */
	static IIconPair getIconFromComponent( IIconPairId iconId) {

		if (iconId == null || iconId.getId() == null) {
			return null;
		}
        if(iconId.getContext().equals(BiCNetComponentType.DCN_MANAGER)){
            return null;
        }

		try {
			ISessionContext sessionContext = AALocalSecurityProviderFacadeImpl.getInstance().getSystemAccountContext();
			IIconPairFacade cfFacade = (IIconPairFacade) BiCNetServiceLocator.getInstance().getServiceLocator(iconId.getContext()).getPublicFacade(BiCNetComponentType.SECURITY_MANAGER);
			return cfFacade.getSingleIconPair(sessionContext, iconId);
		} catch (UnsupportedOperationException e) {
			LOGGER.warn("Problem getting icon from component. Unable to get service locator. Icon Id: " + iconId.getId() + " Component: " + iconId.getContext(), e);
		} catch (UnexpectedException e) {
			LOGGER.warn("Problem getting icon from component. Unable to get component facade. Icon Id: " + iconId.getId() + " Component: " + iconId.getContext(), e);
		} catch (ClassCastException e) {
			LOGGER.warn("Problem getting icon from component. Component does not implement icon facade. Icon Id: " + iconId.getId() + " Component: " + iconId.getContext(), e);
		} catch (BcbException | IllegalArgumentException e) {
			LOGGER.warn("Problem getting icon from component. Icon Id: " + iconId.getId() + " Component: " + iconId.getContext(), e);
		}

		return null;
	}

}
