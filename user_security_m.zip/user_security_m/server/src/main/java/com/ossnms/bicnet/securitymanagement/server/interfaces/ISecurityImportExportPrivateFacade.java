/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	ISecurityImportExportPrivateFacade
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	23rd July 2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.interfaces;

import java.util.List;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.importexport.IEDataObject;

/**
 * This is the Private Interface Facade for the Import/Export functionality
 */
public interface ISecurityImportExportPrivateFacade {

	/**
	 * This method starts the import of security data
	 * @return USMMessage - Message containing the result of the security data
	 * imported
	 */
	USMMessage importSecurityData(
		ISessionContext p_ctx,
		List<IEDataObject> p_securityData,
		String p_type,
		Boolean p_overWrite)
		throws BcbSecurityException;

	/**
	 * This method starts the exporting of security data.
	 * @return USMMessage - Message containing the exported data
	 */
	USMMessage exportSecurityData(
		ISessionContext p_ctx,
		String p_typeOfData)
		throws BcbSecurityException;

}
