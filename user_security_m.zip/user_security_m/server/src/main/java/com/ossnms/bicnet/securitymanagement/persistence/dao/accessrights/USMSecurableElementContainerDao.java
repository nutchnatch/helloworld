package com.ossnms.bicnet.securitymanagement.persistence.dao.accessrights;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.accessrights.IUSMSecurableElementContainerDao;
import com.ossnms.bicnet.securitymanagement.persistence.dao.AbstractBaseDao;
import com.ossnms.bicnet.securitymanagement.persistence.model.accessrights.USMSecurableElementContainer;
import org.hibernate.Hibernate;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.Query;
import java.util.List;

/**
 * created on 24/9/2014
 */
@Stateless(name="IUSMSecurableElementContainerDao")
@Local
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class USMSecurableElementContainerDao
        extends AbstractBaseDao<USMSecurableElementContainer, String>
        implements IUSMSecurableElementContainerDao {

    private static final String QUERY_FIND_BY_FUNCTION = "usmSecurableElementContainer.findByFunction";
    private static final String PARAM_FUNCTION = "functionId";

    @Override
    public void loadSecurableElements(USMSecurableElementContainer container) {
        USMSecurableElementContainer temp = findById(container.getUniqueName());

        //Call Hibernate.initialize to initialize the ACL lazy collection
        Hibernate.initialize(temp.getSecurableElements());

        //set ACL in the element
        container.setSecurableElements(temp.getSecurableElements());
    }

    @Override
    public void loadChildContainers(USMSecurableElementContainer container) {
        USMSecurableElementContainer temp = findById(container.getUniqueName());

        //Call Hibernate.initialize to initialize the ACL lazy collection
        Hibernate.initialize(temp.getChildContainers());

        //set ACL in the element
        container.setChildContainers(temp.getChildContainers());
    }

    @Override
    public void loadParentContainers(USMSecurableElementContainer container) {
        USMSecurableElementContainer temp = findById(container.getUniqueName());

        //Call Hibernate.initialize to initialize the ACL lazy collection
        Hibernate.initialize(temp.getParentContainers());

        //set ACL in the element
        container.setParentContainers(temp.getParentContainers());
    }


    @Override
    public List<USMSecurableElementContainer> findByFunction(String functionId){
        Query query = getEntityManager().createNamedQuery(QUERY_FIND_BY_FUNCTION).setParameter(PARAM_FUNCTION, functionId);
        return query.getResultList();
    }
}
