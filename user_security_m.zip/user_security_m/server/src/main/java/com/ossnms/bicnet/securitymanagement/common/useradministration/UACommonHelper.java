/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 *  Class Name 	UACommonHelper
 * Author:      Vinay Purohit
 * Substitute	Babu B
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
  * ReqID : TNMS.DX2.SM.USER.VIEW
 *       : TNMS.DX2.SM.FORCE_LOGOFF
 *       : TNMS.DX2.SM.USER.CREATE
 *       : TNMS.DX2.SM.USER.CONFIGURE
 *       : TNMS.DX2.SM.USER.ASSIGN
 *       : TNMS.DX2.SM.USER.STATUS
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 12-Apr-2005  Babu B          CF001958    invariable objects should not be exportet
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.useradministration;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;
/**
 * Helper class provided do some common operations that are needed by both the
 * client and the server. These include - 1. Pushing and Poping of information 
 * related to User and User Group
 *   
 */
public class UACommonHelper {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(UACommonHelper.class);

	/**
	 * Method used for pushing the user groups detail into the USMMessage.
	 *
	 * @param p_Ugrp
	 *      Usergroups to be pushed
	 * @param pMsg
	 *      Message encapsulating the user groups 
	 * @return USMMessage
	 *      The Message encapsulating the user groups (same as param pMsg)
	 */
	public static USMMessage pushUserGroupsToMessage(
		List p_Ugrp,
		USMMessage pMsg) {
		LOGGER.debug(
			"pushUserGroupsToMesage(" + p_Ugrp + "," + pMsg + ") entering");

		if ((null == p_Ugrp) || (null == pMsg)) {
			LOGGER.error("Parameter passed is null.");
		}
		int nCountUserGroupEntity = p_Ugrp.size();
		int nPushedUserEntity = 0;
		for (int idx = 0; idx < nCountUserGroupEntity; idx++) {
			// Push All the user group Data into the Message.
			UAUserGroup dataUserEntity = (UAUserGroup) p_Ugrp.get(idx);
			try {
				dataUserEntity.pushMe(pMsg);
				nPushedUserEntity++;
			} catch (Exception ex) {
			    LOGGER.debug(ex);
			}
		}
		// Push Count.
		pMsg.pushInteger(nPushedUserEntity);
		LOGGER.debug(
			"pushUserGroupsToMesage(" + p_Ugrp + "," + pMsg + ") Exiting");
		return pMsg;
	}
	/**
		 * Method used for poping the user groups detail from the USMMessage.
		 *		
		 * @param pMsg
		 *      Message encapsulating the user groups 
		 * @return List
		 *      User group list encapsulated in passed USMMessage
		 */
	public static List popUserGroupsFromMessage(USMMessage pMsg) {
		LOGGER.debug("popUserGroupsFromMesage(" + pMsg + ") entering");
		List userGroupList = new ArrayList();
		if (null == pMsg) {
			LOGGER.error("Parameter passed is null.");
			return userGroupList;
		}
		int countUsergroup = pMsg.popInteger().intValue();
		for (int idx = 0; idx < countUsergroup; idx++) {
			// poping All the user group Data from the Message.
			UAUserGroup dataUserEntity = new UAUserGroup();
			try {
				dataUserEntity.popMe(pMsg);
				userGroupList.add(dataUserEntity);
			} catch (Exception ex) {
			    LOGGER.debug(ex);
			}
		}
		LOGGER.debug(
			"popUserGroupsFromMesage("
				+ pMsg
				+ ") Exit : Return : "
				+ userGroupList);
		return userGroupList;
	}

	/**
	 * Method used for pushing the users to the USMMessage.
	 *
	 * @param p_Ugrp
	 *      Usergroups to be pushed
	 * @param pMsg
	 *      Message encapsulating the users 
	 * @return USMMessage
	 *      The Message encapsulating the users (same as param pMsg)
	 */

	public static USMMessage pushUsersToMessage(
		List p_Ugrp,
		USMMessage pMsg) {
		LOGGER.debug(
			"pushUsersToMesage(" + p_Ugrp + "," + pMsg + ")  Entering");

		if ((null == p_Ugrp) || (null == pMsg)) {
			LOGGER.error("Parameter passed is null.");

		}

		int nCountUserEntity = p_Ugrp.size();
		int nPushedUserEntity = 0;
		for (int idx = 0; idx < nCountUserEntity; idx++) {
			// Push All the Users onto the Message.
			UAUserNameAndID objUser = (UAUserNameAndID) p_Ugrp.get(idx);
			objUser.pushMe(pMsg);
			nPushedUserEntity++;
		}
		// Push Count.
		pMsg.pushInteger(nPushedUserEntity);
		LOGGER.info(
			"pushUsersToMesage() number of entry pushed at server ="
				+ p_Ugrp.size());
		LOGGER.debug(
			"pushUsersToMesage(" + p_Ugrp + "," + pMsg + ")  Exiting");
		return pMsg;

	}
	/**
		 * Method used for poping the users from the USMMessage.
		 *
		 * @param pMsg
		 *      Message encapsulating the users 
		 * @return List
		 *      Users list encapsulated in passed USMMessage
		 */

	public static List popUsersFromMessage(USMMessage pMsg) {
		LOGGER.debug("popUsersFromMessage(" + pMsg + ")  Entering");
		List usersList = new ArrayList();
		if (null == pMsg) {
			LOGGER.error("Parameter passed is null.");
			return usersList;
		}

		int nCountUsers = pMsg.popInteger().intValue();
		for (int idx = 0; idx < nCountUsers; idx++) {
			// Push All the Users onto the Message.
			UAUserNameAndID objUser = new UAUserNameAndID();
			objUser.pushMe(pMsg);
			usersList.add(objUser);
		}
		LOGGER.debug(
			"popUsersFromMessage(" + pMsg + ")  Exit : Return" + usersList);
		return usersList;

	}

    /**
     * Data member to hold the name of the Group which is the Administrator
     * Group.
     */
    public static final String ADMIN_GROUP_NAME = "Administrators";
}
