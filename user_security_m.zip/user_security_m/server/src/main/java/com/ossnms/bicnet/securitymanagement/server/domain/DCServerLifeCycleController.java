/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCServerLifeCycleController
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CREATE
 * 		:	TNMS.DX2.SM.DOMAIN.CONFIG	   
 * 		:	TNMS.DX2.SM.DOMAIN.VIEW
 * 		:	TNMS.DX2.SM.MAPPING.CREATE
 * 		:	TNMS.DX2.SM.MAPPING.VIEW    
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 05-May-2005  Babu B          CF001312   Master-Master Replication for Sun ONE DS
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import com.ossnms.bicnet.securitymanagement.server.basic.USMServerLifeCycleControllerIfc;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Life cycle controller on the server. Single point of entry for the
 * subsystems DC Responsible for initializing the subsystem and cleaning it up.
 */
public final class DCServerLifeCycleController
    implements USMServerLifeCycleControllerIfc {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER =
        Logger.getLogger(DCServerLifeCycleController.class);

    /**
     * Holds the single instance of this controller
     */
    private static DCServerLifeCycleController self =
        new DCServerLifeCycleController();

    /**
     * Default constructor of the DCServerLifeCycleController
     */
    private DCServerLifeCycleController() {
    }

    /**
     * This function initializes subsystem DC. It registers with SI for
     * receiving the calls from Application Servers for getting the domain and
     * mappings. It initializes the cache manager and initiates to get the
     * domains and mappings from the Active Directory It also initiates
     * consistency check on the domains and mappings. It is also responsible
     * for registering with Migration
     * 
     * @return boolean Returns true on successful initialization of the
     *         subsystem
     */
    @Override
    public boolean initialize() {

        LOGGER.debug("initialize() - Enter");
        boolean bRetVal = true;
        try {
            //initialize DCServerDataManager
            DCServerDataManager dcDataCacheMgr = DCServerDataManager.getInstance();
            dcDataCacheMgr.initialize();

            initiateConsistencyCheckForMappings();
        } catch (Exception ex) {
            bRetVal = false;
            LOGGER.error("Exception has occured in initializind subsystem DC");
        }
        LOGGER.debug("initialize() - Exit");
        return bRetVal;
    }

    /**
     * This helper function does a consistency check on the mappings. It checks
     * if the mappings contain an invalid domain. Domain which has been deleted
     * manually by the operator from the ADS. It also checks for an invalid
     * policy. Policy which has been delted from ADS. In which case, it deltes
     * all the mappings whereever the invalid policy takes part. Apart from
     * this to delete the mapping, where the domain is invalid. It registers a
     * callback so that when AS is finally initialized, it can tell AS that the
     * domain has been deleted and it also deletes the mapping in that case.
     */
    void initiateConsistencyCheckForMappings() {

        LOGGER.debug("initiateConsistencyCheckForMappings() - Enter");

        List policyIdList = new ArrayList();
        List policyList = DCExternalInterface.getPolicies();
        for (Object policy : policyList) {
            policyIdList.add(((PAPolicyId)policy).getPolicyID());
        }

        String[] userGroupsFetched = DCExternalInterface.getGlobalUserGroups();
        
        List<String> userGroups = Arrays.asList(userGroupsFetched);
        List deletedDomains = new ArrayList();
        Set deletedPolicies = new HashSet();
        List deletedUserGroups = new ArrayList();

        DCServerDataManager cacheMgr =
            DCServerDataManager.getInstance();
        cacheMgr.performConsistencyCheck(
            policyIdList,
            userGroups,
            deletedDomains,
            deletedPolicies,
            deletedUserGroups);

        //You could have a question, why all this is done here and why not within the DCServerDataManager
        //The reasons is simple. I may need to do more than just deleting mappings. I may have
        //to delete the reference of the NEs whereever the NEs point to this domain and it is
        //not right to put it into the cachemanager. Other reason is..tomorrow someone could
        //tell that it is better to create a dummy domain instead, and a dummy policy instead..
        //so i have to be a little foolproof...for the future...though this may not happen...
        //nevertheless, this was also an alternative.

        //Delete the mappings containing the invalid or delted domains
        if (0 != deletedDomains.size()) {
            LOGGER.error(
                "initiateConsistencyCheckForMappings() - Mappings exist where a domain is invalid, doing consistency check...");
            //Now start deleting the mappings... wait wait...before i delete the mappings..
            //I need to inform BS that the domain has been deleted and he has to unassign
            //NEs to that domain. Now BS is initialized after DC, so I need to invoke the
            //domainDeleted functionality after BS is initialized....
            //But there is another problem, this is only for those domains which i know have
            //been deleted by looking at the mapping..Now as part of the
            //consistency check, even BS has to find which domains are actually valid, so let BS only decide that

            //It could so happen that the domain got deleted. does not take part in mapping
            //but NE contains reference to this domain thru the ACL. Now the reference has
            //to be removed. So that part BS, itself would be doing it.
            for (int i = 0; i < deletedDomains.size(); ++i) {
                int domainId = (Integer) (deletedDomains.get(i));
                DCServerDataManager.getInstance().deleteMappingsOfDomain(
                    domainId);
                LOGGER.warn(
                    "initiateConsistencyCheckForMappings() - DO NOT, I repeat, DO NOT delete data as u did for domain with domain id = "
                        + domainId);
                LOGGER.warn(
                    "initiateConsistencyCheckForMappings() - All mappings with respect to this domain are lost now...No use cribbing now");
            }
        }

        //Delete the mappings containging the invalid or delted policies
        if (0 != deletedPolicies.size()) {
            LOGGER.error(
                "initiateConsistencyCheckForMappings() - Mappings exist where a policy is invalid,doing consistency check...");
            //There are mappings which are to be deleted. because the policy id is invalid
            //or the policy has been deleted
            List mappings = new ArrayList();
            List mappingsTobeDeleted = new ArrayList();
            cacheMgr.getAllConfiguredMappings(mappings);
            //Delete the mappings wherever this policy is part of
            for (int i = 0; i < mappings.size(); ++i) {
                DCDomainMapping map = (DCDomainMapping) mappings.get(i);
                if (deletedPolicies.contains(map.getPolicyID())) {
                    mappingsTobeDeleted.add(map);
                    LOGGER.warn(
                        "initiateConsistencyCheckForMappings() - DO NOT, I repeat, DO NOT delete data from LDAP DS, as u did for policy id = "
                            + map.getPolicyID());
                    LOGGER.warn(
                        "initiateConsistencyCheckForMappings() - All mappings with respect to this policy are lost now...No use cribbing now");
                }
            }
            cacheMgr.deleteMappings(
                mappingsTobeDeleted,
                new ArrayList(),
                new ArrayList());
        }

        //Delete the mappings containging the invalid or deleted user groups
        if (0 != deletedUserGroups.size()) {
            LOGGER.error(
                "initiateConsistencyCheckForMappings() - Mappings exist where a user group is invalid,doing consistency check...");
            //There are mappings which are to be deleted. because the user group is invalid
            //or the user group has been deleted
            List mappings = new ArrayList();
            List mappingsTobeDeleted = new ArrayList();
            cacheMgr.getAllConfiguredMappings(mappings);
            //Delete the mappings whereever this policy is part of that
            for (int i = 0; i < mappings.size(); ++i) {
                DCDomainMapping map = (DCDomainMapping) mappings.get(i);
                if (deletedUserGroups.contains(map.getUserGroup())) {
                    mappingsTobeDeleted.add(map);
                    LOGGER.warn(
                        "initiateConsistencyCheckForMappings() - DO NOT, I repeat, DO NOT delete data from LDAP DS, as u did for user group = "
                            + map.getUserGroup());
                    LOGGER.warn(
                        "initiateConsistencyCheckForMappings() - All mappings with respect to this user group are lost now...No use cribbing now");
                }
            }
            cacheMgr.deleteMappings(
                mappingsTobeDeleted,
                new ArrayList(),
                new ArrayList());
        }

        LOGGER.debug("initiateConsistencyCheckForMappings() - Exit");
    }

    /**
     * Responsible for successfull cleaning up of the subsytem DC
     * 
     * @return boolean Returns true always
     */
    @Override
    public boolean cleanup() {
        return true;
    }

    /**
     * Provides the single instance of this object
     * 
     * @return xdm.security.dc.server.DCServerLifeCycleController Returns the
     *         singleton instance of this class.
     */
    public static DCServerLifeCycleController getInstance() {
        return self;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.securitymanagement.server.basic.USMServerLifeCycleControllerIfc#reinitialize()
     */
    @Override
    public boolean reinitialize() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("reinitialize() - entry");
        }
        //initialize DCServerDataManager
        DCServerDataManager dcDataCacheMgr =
            DCServerDataManager.getInstance();
        dcDataCacheMgr.initialize();

        initiateConsistencyCheckForMappings();

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("reinitialize() - exit - returning" + true);
        }
        return true;
    }
}
