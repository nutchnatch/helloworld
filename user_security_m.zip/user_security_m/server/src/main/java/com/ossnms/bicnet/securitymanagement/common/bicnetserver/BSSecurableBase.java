package com.ossnms.bicnet.securitymanagement.common.bicnetserver;

import com.ossnms.bicnet.bcb.model.ManagedObjectType;
import com.ossnms.bicnet.bcb.model.common.IIconPair;
import org.apache.log4j.Logger;

import java.io.Serializable;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * This Class represents the common attributes for the Container and SecurableObjects DTO's (data transfer objects)
 *
 */
public class BSSecurableBase implements Comparable<BSSecurableBase>, Serializable {
    
    private static final long serialVersionUID = 5802345874518101976L;
    
	private static final Logger LOGGER = Logger.getLogger(BSSecurableBase.class);

    /**
     * Data member to store the Display name of the Securable Object as seen
     * in the Owner CF.
     */
	protected String displayName;
    /**
     * Data member to store the unique name for the Securable Object.
     */
    protected String uniqueName;
    /**
     * The CF ID to which this Securable Object belongs to
     */
    protected String ownerCfId;
    /**
     * The Display Name of the CF which owns this Securable Object.
     */
    protected String ownerCfDisplayName;
    /**
     * The Icon of this Securable Object.
     */
    protected IIconPair icon;
    /**
     * Data member to hold the type of the Object. (Is an Enum)
     */
    protected ManagedObjectType managedObjectType;

	/**
	 * The parent containers of the object
	 */
	protected List<BSSecurableObjectContainer> objectContainers;

    /**
     * Constructor for the BSSecurableBase
     * @param displayName
     * @param uniqueName
     * @param ownerCfId
     * @param ownerCfDisplayName
     * @param icon
     * @param managedObjectType
     * @param objectContainers 
     */
    public BSSecurableBase(String displayName, String uniqueName, String ownerCfId, String ownerCfDisplayName, IIconPair icon, ManagedObjectType managedObjectType, List<BSSecurableObjectContainer> objectContainers) {
		if (displayName == null || uniqueName == null || ownerCfId == null || ownerCfDisplayName == null || managedObjectType == null) {
			LOGGER.error("One of the Value is null." + " Display Name : " + displayName + " Unique Name : " + uniqueName + " CF ID : " + ownerCfId
					+ " CF Name : " + ownerCfDisplayName + " Type : " + managedObjectType);
			throw new InvalidParameterException();
		}
		
        this.displayName = displayName;
        this.uniqueName = uniqueName;
        this.ownerCfId = ownerCfId;
        this.ownerCfDisplayName = ownerCfDisplayName;
        this.icon = icon;
        this.managedObjectType = managedObjectType;
        this.objectContainers = objectContainers;
    }
    
    /**
     * Access method for the displayName property.
     * @return java.lang.String   The current value of the displayName property
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Sets the value of the displayName property.
     * @param displayName  The new value of the displayName property
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Access method for the uniqueName property.
     * @return java.lang.String  The current value of the uniqueName property
     */
    public String getUniqueName() {
        return uniqueName;
    }

    /**
     * Sets the value of the uniqueName property.
     * @param uniqueName  The new value of the uniqueName property
     */
    public void setUniqueName(String uniqueName) {
        this.uniqueName = uniqueName;
    }

    /**
     * Access method for the ownerCfId property.
     * @return java.lang.Integer  The current value of the ownerCFid property
     */
    public String getOwnerCfId() {
        return ownerCfId;
    }

    /**
     * Sets the value of the ownerCfId property.
     * @param ownerCfId  The new value of the ownerCfId property
     */
    public void setOwnerCfId(String ownerCfId) {
        this.ownerCfId = ownerCfId;
    }

    /**
     * Access method for the ownerCfDisplayName property.
     * @return java.lang.String  The current value of the ownerCfDisplayName
     * property
     */
    public String getOwnerCfDisplayName() {
        return ownerCfDisplayName;
    }

    /**
     * Sets the value of the ownerCfDisplayName property.
     * @param ownerCfDisplayName  The new value of the ownerCfDisplayName
     * property
     */
    public void setOwnerCfDisplayName(String ownerCfDisplayName) {
        this.ownerCfDisplayName = ownerCfDisplayName;
    }

    /**
     * Retrieves the IconPair object associated with this object
     */
    public IIconPair getIcon() {
        return icon;
    }

    /**
     * Sets the IconPair object to be associated with this object
     * @param icon The icon to be associated
     */
    public void setIcon(IIconPair icon) {
        this.icon = icon;
    }

    /**
     * Function to return the Type of the Object
     * @return ManagedObjectType  Enum which denotes the type
     */
    public ManagedObjectType getManagedObjectType() {
        return managedObjectType;
    }

    /**
     * Function to set the type of the Object
     * @param type The New Type of the Object
     */
    public void setManagedObjectType(ManagedObjectType type) {
        managedObjectType = type;
    }

	/**
	 * @see java.lang.Object#toString()
	 */
	@Override
    public String toString() {
		return displayName;
	}
	
	/**
	 * Retrieves the list of Object Containers where this securable object belongs to.
	 * @return the list of Object Containers
	 */
	public List<BSSecurableObjectContainer> getObjectContainers() {
		return objectContainers;
	}

	/**
	 * Retrieves the list of object container names, where this securable object belongs to.
	 * @return the list of object container names
	 */
	public List<String> getObjectContainersUniqueName() {
		if (objectContainers == null) {
			return Collections.emptyList();
		}

		List<String> uniqueNames = new ArrayList<>(objectContainers.size());
		for (BSSecurableObjectContainer container : objectContainers) {
			uniqueNames.add(container.getUniqueName());
		}
		return uniqueNames;
	}
	
	/**
	 * Sets the list of Object Containers where this securable object belongs to.
	 * @param containers object containers list
	 */
	public void setObjectContainers(List<BSSecurableObjectContainer> containers) {
		objectContainers = containers;
	}

    @Override
    public int compareTo(BSSecurableBase o) {
        final int EQUAL = 0;
        int comparison = EQUAL;

        // same pointer, therefore, same object
        if(this == o){
            return EQUAL;
        }

        comparison = this.getUniqueName().compareTo(o.getUniqueName());
        if(comparison != EQUAL){
            return comparison;
        }

        comparison = this.getDisplayName().compareTo(o.getDisplayName());
        if(comparison != EQUAL){
            return comparison;
        }

        comparison = this.getManagedObjectType().compareTo(o.getManagedObjectType());
        if(comparison != EQUAL){
            return comparison;
        }


        return comparison;
    }
}