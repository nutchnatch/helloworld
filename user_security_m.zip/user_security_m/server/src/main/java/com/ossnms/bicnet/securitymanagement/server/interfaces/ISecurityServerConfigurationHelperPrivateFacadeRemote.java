package com.ossnms.bicnet.securitymanagement.server.interfaces;

public interface ISecurityServerConfigurationHelperPrivateFacadeRemote extends ISecurityServerConfigurationHelperPrivateFacade { }

