package com.ossnms.bicnet.securitymanagement.api.common.utils;

import com.ossnms.bicnet.bcb.facade.IManagedObjectFacade;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IManagedObjectIdReply;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.model.IManagedObjectReply;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.Notification;
import com.ossnms.bicnet.bcb.model.platform.ObjectCreation;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.server.basic.notification.USMNotifier;

import java.lang.reflect.Array;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Abstract class which intends to extract information from the server while parsing said information into the
 * BCB Model. Provides methods for list retrieval, supporting filtering, record count and pagination.
 */
public abstract class AbstractManagedObjectFacade<
        T,
        MOID extends IManagedObjectId,
        MO extends IManagedObject,
        MOM extends IManagedObjectMarkable,
        MOR extends IManagedObjectReply,
        MOIDR extends IManagedObjectIdReply> implements IManagedObjectFacade{

    private static final int MOID_INDEX  = 1;
    private static final int MO_INDEX    = 2;

    /**
     * Returns the list of DTOs (from <T>) from the server
     *
     * @return List of {@code <T>}
     */
    protected abstract List<T> getList();

    /**
     * Hook method. Returns a single item, given an id of type <MOID>
     *
     * @param id instance of type <MOID>
     * @return instance of type <T>, or null if the object is not found
     */
    protected abstract T getSingleItem(MOID id);

    /**
     * Parses the object of type <T> into an item type object of type <MO>
     *
     * @param data instance of <T>
     * @return instance of <MO>
     */
    protected abstract MO toItem(T data);

    /**
     * Parses the object of type <T> into an item type object of type <MOID>
     *
     * @param data instance of <T>
     * @return instance of <MOID>
     */
    protected abstract MOID toIdItem(T data);

    /**
     * Parses the object of type <T> into an item type object of type <MOM>
     *
     * @param data instance of <T>
     * @return instance of <MOM>
     */
    protected abstract MOM toMarkableItem(T data);

    /**
     * Extract the list of <MO> items and the eof flag into a BCB reply instance of type <MOR>
     *
     * @param items List of instances of <MO>
     * @return BCB Reply type instance of <MOR>
     */
    protected abstract MOR toItemReply(boolean eof, MO[] items);

    /**
     * Extract the list of <MOID> items and the eof flag into a BCB reply instance of type <MOIDR>
     *
     * @param ids List of instances of <MOID>
     * @return BCB Reply type instance of <MOIDR>
     */
    protected abstract MOIDR toIdReply(boolean eof, MOID[] ids);

    /**
     * Checks if a determined instance of type <MO> matches the filter specified by the array of Markables, of type
     * <MOM>
     *
     * @param filter instance of type <MOM>
     * @param data the <MO> instance to validate
     * @return true if the object matches the filter, false otherwise
     */
    protected abstract boolean matchesFilter(MOM filter, MO data);

    /**
     * Checks if a determined instance of type <MO> matches the filter specified by the array of Markables, of type
     * <MOM>
     *
     * @param filter array of type <MOM>
     * @param data the <MO> instance to validate
     * @return true if the object matches the filter, false otherwise
     */
    private boolean matchesFilter(MOM[] filter, MO data){
        for(MOM fltr : filter){
           if (!matchesFilter(fltr, data)){
               return false;
           }
        }

        return true;
    }

    /**
     * Retrieves a single item (instance of type <MO>, identified by the instance of <MOID>
     *
     * @param id instance of <MOID> that identifies the object
     * @return instance of type <MO> if the object is found, null otherwise
     * @throws BcbSecurityException if the parameter id is null
     */
    public MO getSingle(MOID id) throws BcbSecurityException {
        // if the id is null, then throw exception (as mandated by Facade implementations)
        if(id == null){
            throw new BcbSecurityException("ID cannot be null");
        }
        // call the hook method to retrieve the DTO item from the Managed Object ID
        T item = getSingleItem(id);
        // if nothing was found, return null
        if(item == null) {
            return null;
        }

        return toItem(item);
    }

    /**
     * Fetches a list of instances of <MO>, which match the parameters passed. This is encapsulated in an object of type
     * <MOR>.
     *
     * @param startAfter start the list after the object identified by this <MOID> instance
     * @param filter array of <MOM> objects to filter the results
     * @param howMany the number of records to return
     * @return instance of <MOR>
     */
    public MOR getList(MOID startAfter, MOM[] filter, int howMany) {
        ListParser<MO> parser = new ListParser<MO>(){
            @Override
            protected MO parseObject(MO item) {
                return item;
            }
        }.invoke(startAfter, filter, howMany);

        // get <MO> type
        Class type = getParameterizedType(MO_INDEX);
        // get list of items
        List<MO> items = parser.getElements();
        // instantiate array
        MO[] array = (MO[]) Array.newInstance(type, items.size());
        items.toArray(array);

        return toItemReply(parser.isEof(), array);
    }

    /**
     * Fetches a list of instances of <MOID>, which match the parameters passed. This is encapsulated in an object of type
     * <MOIDR>.
     *
     * @param startAfter start the list after the object identified by this <MOID> instance
     * @param filter array of <MOM> objects to filter the results
     * @param howMany the number of records to return
     * @return instance of <MOIDR>
     */
    public MOIDR getIdList(MOID startAfter, MOM[] filter, int howMany) {
        ListParser<MOID> parser = new ListParser<MOID>(){
            @Override
            protected MOID parseObject(MO item) {
                return (MOID) item.getGenericId();
            }
        }.invoke(startAfter, filter, howMany);

        // get <MOID> type
        Class type = getParameterizedType(MOID_INDEX);
        // get list of items
        List<MOID> items = parser.getElements();
        // instantiate array
        MOID[] array = (MOID[]) Array.newInstance(type, items.size());
        items.toArray(array);

        return toIdReply(parser.isEof(), array);
    }

    /**
     * Sends an external notification to inform of an object creation
     *
     * @param data DTO with the newly created object
     */
    public void sendObjectCreation(T data){
        sendExternalNotification(new ObjectCreation(new Date(), toItem(data)));
    }

    /**
     * Sends an external notification to inform of an object modification
     *
     * @param data DTO with the modified object
     */
    public void sendAttributeValueChanged(T data){
        sendExternalNotification(new AttributeValueChange(new Date(), toMarkableItem(data)));
    }

    /**
     * Sends an external notification to inform of an object deletion
     *
     * @param data DTO with the deleted object
     */
    public void sendObjectDeletion(T data){
        sendExternalNotification(new ObjectDeletion(new Date(), toIdItem(data)));
    }


    /**
     *
     * @param notification
     */
    protected void sendExternalNotification(Notification notification){
        USMNotifier.getInstance().sendExternalNotification(notification);
    }

    /**
     * Private class to encapsulate common behavior
     * - Fetch list
     * - Apply filter
     * - restrict number of records of type <MOType> returned
     * - return after the id specified
     */
    private abstract class ListParser<MOType> {
        private List<MOType> elements;
        private boolean eof;

        /**
         * Constructor
         */
        ListParser() {}

        /**
         * Getter method to return the list of elements returned after the call to the invoke method
         *
         * @return the list of instances of type <MOType>
         */
        public List<MOType> getElements() {
            return elements;
        }

        /**
         * Return if the search has reached the end of the records
         *
         * @return true if there are more records, false otherwise.
         */
        boolean isEof() {
            return eof;
        }

        /**
         * Hook method. Provides a connection so that usages of this may specify the way to extract objects of the
         * type <MOType>.
         *
         * @param item instance of type <MO>
         * @return parsed instance of <MOType>
         */
        protected abstract MOType parseObject(MO item);

        /**
         * Fetches the list of instances of <MOType> and populates the object, together with the flag EOF.
         *
         * @return the instance of this
         */
        ListParser<MOType> invoke(MOID startAfter, MOM[] filter, int howMany) {
            // retrieve the list
            List<T> dataList = getList();
            elements = new ArrayList<>();

            boolean afterId = false;
            int idx = 0;
            eof = false;

            // iterate through the objects on the retrieved data source
            for(T data : dataList){
                try{
                    // parse from DTO object
                    MO item = toItem(data);
                    // if we are instructed to start after a specified ID
                    if(startAfter != null && !afterId){
                        if(startAfter.equals(item)){
                            afterId = true;
                        }
                        continue;
                    }
                    // if the number of objects has been met
                    if(howMany != 0 && elements.size() == howMany){
                        break;
                    }
                    // if the object did not match the filter
                    if(filter != null && !matchesFilter(filter, item)){
                        continue;
                    }
                    elements.add(parseObject(item));
                } finally {
                    idx++;
                }
            }
            // if the index equals the size of the datalist, then all the items were processed, EOF
            if(idx == dataList.size()){
                eof = true;
            }
            return this;
        }
    }

    /**
     * In runtime we need to know the type of some parameters, so this is a class to discover that.
     *
     * @return the concrete type as configured in the specified index
     */
    private Class getParameterizedType(int parameterIndex){
        // get IManagedObject type
        Type superClass = getClass().getGenericSuperclass();
        // if this type is a parameterized type, then we have access to this Abstract Class declaration
        if(!(superClass instanceof ParameterizedType)){
            superClass = ((Class)superClass).getGenericSuperclass();
        }
        return (Class) ((ParameterizedType) superClass).getActualTypeArguments()[parameterIndex];
    }
}
