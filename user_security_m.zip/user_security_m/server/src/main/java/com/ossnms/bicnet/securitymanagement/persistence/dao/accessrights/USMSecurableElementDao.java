package com.ossnms.bicnet.securitymanagement.persistence.dao.accessrights;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.accessrights.IUSMSecurableElementDao;
import com.ossnms.bicnet.securitymanagement.persistence.dao.AbstractBaseDao;
import com.ossnms.bicnet.securitymanagement.persistence.model.accessrights.USMSecurableElement;
import org.hibernate.Hibernate;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.Query;
import java.util.List;

/**
 * created on 24/9/2014
 */
@Stateless(name="IUSMSecurableElementDao")
@Local
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class USMSecurableElementDao
        extends AbstractBaseDao<USMSecurableElement, String>
        implements IUSMSecurableElementDao {

    private static final String QUERY_FIND_BY_UNIQUENAME_CONTAINERS = "usmSecurableElement.findByUniqueNameWithContainers";
    private static final String QUERY_FIND_BY_UNIQUENAME_ACL = "usmSecurableElement.findByUniqueNameWithACL";

    private static final String QUERY_FIND_BY_DISPLAY_NAME = "usmSecurableElement.findByDisplayName";
    private static final String QUERY_FIND_BY_DISPLAY_NAME_CONTAINERS = "usmSecurableElement.findByDisplayNameWithContainers";
    private static final String QUERY_FIND_BY_DISPLAY_NAME_ACL = "usmSecurableElement.findByDisplayNameWithACL";
    private static final String PARAM_NAME = "name";

    private static final String QUERY_COUNT_BY_FUNCTION = "usmSecurableElement.countByFunction";
    private static final String QUERY_COUNT_BY_FUNCTION_AND_DOMAIN = "usmSecurableElement.countByFunctionAndDomain";
    private static final String QUERY_FIND_BY_FUNCTION_AND_DOMAIN = "usmSecurableElement.findByFunctionAndDomain";
    private static final String QUERY_FIND_BY_FUNCTION = "usmSecurableElement.findByFunction";
    private static final String QUERY_FIND_BY_FUNCTION_AND_DOMAIN_CONTAINERS = "usmSecurableElement.findByFunctionAndDomainWithContainers";
    private static final String QUERY_FIND_BY_FUNCTION_CONTAINERS = "usmSecurableElement.findByFunctionWithContainers";
    private static final String QUERY_FIND_BY_FUNCTION_AND_DOMAIN_ACL = "usmSecurableElement.findByFunctionAndDomainWithAcl";
    private static final String QUERY_FIND_BY_FUNCTION_ACL = "usmSecurableElement.findByFunctionWithAcl";
    private static final String PARAM_FUNCTION = "functionId";
    private static final String PARAM_DOMAIN = "domainId";

    private static final String QUERY_FIND_ALL_ACL = "usmSecurableElement.findAllWithACL";
    private static final String QUERY_FIND_ALL_CONTAINERS = "usmSecurableElement.findAllWithContainers";
    private static final String PARAM_UNIQUE_NAME = "uniqueName";


    /**
     *
     * @param element
     */
    @Override
    public void loadAcl(USMSecurableElement element) {
        USMSecurableElement temp = findById(element.getUniqueName());
        // call Hibernate.initialize to initialize the ACL lazy collection
        Hibernate.initialize(temp.getAcl());
        // set ACL in the element
        element.setAcl(temp.getAcl());
    }

    /**
     *
     * @param element
     */
    @Override
    public void loadContainers(USMSecurableElement element) {
        USMSecurableElement temp = findById(element.getUniqueName());
        // call Hibernate.initialize to initialize the ACL lazy collection
        Hibernate.initialize(temp.getContainers());
        // set ACL in the element
        element.setContainers(temp.getContainers());
    }

    @Override
    public USMSecurableElement findByDisplayName(String displayName, boolean withContainers, boolean withACL) {
        Query query;

        if(withContainers){
            query = getEntityManager().createNamedQuery(QUERY_FIND_BY_DISPLAY_NAME_CONTAINERS).setParameter(PARAM_NAME, displayName);
        }else if(withACL){
            query = getEntityManager().createNamedQuery(QUERY_FIND_BY_DISPLAY_NAME_ACL).setParameter(PARAM_NAME, displayName);
        }else {
            query = getEntityManager().createNamedQuery(QUERY_FIND_BY_DISPLAY_NAME).setParameter(PARAM_NAME, displayName);
        }

        return getSingleResult(query);
    }

    @Override
    public List<USMSecurableElement> findByFunction(String functionId, boolean withContainers, boolean withACL){
        Query query;

        if(withContainers){
            query = getEntityManager().createNamedQuery(QUERY_FIND_BY_FUNCTION_CONTAINERS).setParameter(PARAM_FUNCTION, functionId);
        }else if(withACL){
            query = getEntityManager().createNamedQuery(QUERY_FIND_BY_FUNCTION_ACL).setParameter(PARAM_FUNCTION, functionId);
        }else {
            query = getEntityManager().createNamedQuery(QUERY_FIND_BY_FUNCTION).setParameter(PARAM_FUNCTION, functionId);
        }

        return findAllByQuery(query);
    }


    @Override
    public List<USMSecurableElement> findByFunctionAndDomain(String functionId, int domainId, boolean withContainers, boolean withACL){
        Query query;

        if(withContainers){
            query = getEntityManager().createNamedQuery(QUERY_FIND_BY_FUNCTION_AND_DOMAIN_CONTAINERS)
                    .setParameter(PARAM_FUNCTION, functionId)
                    .setParameter(PARAM_DOMAIN, domainId);
        }else if(withACL){
            query = getEntityManager().createNamedQuery(QUERY_FIND_BY_FUNCTION_AND_DOMAIN_ACL)
                    .setParameter(PARAM_FUNCTION, functionId)
                    .setParameter(PARAM_DOMAIN, domainId);
        }else {
            query = getEntityManager().createNamedQuery(QUERY_FIND_BY_FUNCTION_AND_DOMAIN)
                    .setParameter(PARAM_FUNCTION, functionId)
                    .setParameter(PARAM_DOMAIN, domainId);
        }

        return findAllByQuery(query);
    }

    @Override
    public List<USMSecurableElement> findAllWithACL() {
        Query query = getEntityManager().createNamedQuery(QUERY_FIND_ALL_ACL);
        return findAllByQuery(query);
    }

    @Override
    public List<USMSecurableElement> findAllWithContainers() {
        Query query = getEntityManager().createNamedQuery(QUERY_FIND_ALL_CONTAINERS);
        return findAllByQuery(query);
    }

    @Override
    public USMSecurableElement findById(String uniqueName, boolean withContainers, boolean withACL){
        Query query;

        if(withContainers){
            query = getEntityManager().createNamedQuery(QUERY_FIND_BY_UNIQUENAME_CONTAINERS).setParameter(PARAM_UNIQUE_NAME, uniqueName);
        }else if(withACL){
            query = getEntityManager().createNamedQuery(QUERY_FIND_BY_UNIQUENAME_ACL).setParameter(PARAM_UNIQUE_NAME, uniqueName);
        }else {
            return findById(uniqueName);
        }

        return getSingleResult(query);
    }

    @Override
    public int countByFunction(String functionId) {
        Query query = getEntityManager().createNamedQuery(QUERY_COUNT_BY_FUNCTION)
                .setParameter(PARAM_FUNCTION, functionId);

        return ((Long) query.getSingleResult()).intValue();
    }

    @Override
    public int countByFunctionAndDomain(String functionId, int domainId) {
        Query query = getEntityManager().createNamedQuery(QUERY_COUNT_BY_FUNCTION_AND_DOMAIN)
                .setParameter(PARAM_FUNCTION, functionId)
                .setParameter(PARAM_DOMAIN, domainId);

        return ((Long) query.getSingleResult()).intValue();
    }
}
