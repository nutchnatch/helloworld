package com.ossnms.bicnet.securitymanagement.common.bicnetserver;

import com.ossnms.bicnet.bcb.model.ManagedObjectType;
import com.ossnms.bicnet.bcb.model.common.IIconPair;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import org.apache.log4j.Logger;

import java.io.Serializable;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;

/**
 * Transient data to hold the Securable Object Container details. This data is used to
 * transfer information about the Securable Object Container from the Server to the
 * Client. This class is equivalent to the BSPersSecurableObjectContainerInfo. The only
 * difference is that it does not derive from the LWElement
 */
public class BSSecurableObjectContainer extends BSSecurableBase implements Serializable {

    private static final long serialVersionUID = -2741651334006705834L;

    /**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(BSSecurableObjectContainer.class);

	/**
	 * Holds the list of securable objects contained.
	 */
	private List<BSSecurableBase> childObjects = new ArrayList<>();

	private boolean compound;

	/**
	 * Constructor
	 * @param dispName Display Name of the Securable Object
	 * @param uniqueName Unique Name of the Securable Object
	 * @param cfId Identifier for the CF which owns the Securable Object
	 * @param cfDisplayName Display Name for the CF which owns the Securable Object
	 * @param compound indicates if this object is compounded and should be treated as a single unit
	 * @param objectContainers  Parents of the container
	 */
	public BSSecurableObjectContainer(String dispName, String uniqueName, String cfId, String cfDisplayName, IIconPair icon, boolean compound, List<BSSecurableObjectContainer> objectContainers, ManagedObjectType moType) {

	    super(dispName, uniqueName, cfId, cfDisplayName, icon, moType, objectContainers);
		this.compound = compound;
	    
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Creating BSSecurableObjectContainer. Display Name : " + dispName + " Unique Name : " + uniqueName + " CF ID : " + cfId
					+ " CF Name : " + cfDisplayName + " Type : " + moType);
		}

		LOGGER.debug("Exiting Constructor.");
	}

	/**
	 * This function is invoked when the BSSecurableObject needs to be passed
	 * from the Server to Client or vice versa. This function will push the
	 * BSSecurableObject into the message.
	 * @param msg  The message into which the object should be pushed.
	 */
	public void pushMe(USMMessage msg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering pushTo. Message : " + msg);
		}

		if (msg == null) {
			LOGGER.error("Message to push the object cannot be null.");
			throw new InvalidParameterException();
		}

		msg.pushString(displayName);
		msg.pushString(uniqueName);
		msg.pushString(ownerCfId);
		msg.pushString(ownerCfDisplayName);
		msg.pushBoolean(compound);
		msg.pushObject(getIcon());

		if(objectContainers != null){
			for (BSSecurableObjectContainer container : objectContainers) {
				container.pushMe(msg);
			}
		}
		msg.pushInteger(objectContainers == null ? -1 : objectContainers.size());
		
		Integer nType = managedObjectType.getOrdinal();
		msg.pushInteger(nType);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting pushTo. Message : " + msg);
		}
	}

	/**
	 * This function is invoked when the BSSecurableObject needs to be created
	 * after recieving a message from the Server to Client or vice versa. This
	 * function will pop the BSSecurableObject from the message.
	 * @param msg  The message from which the object should be poped.
	 * @return BSSecurableObject Newly Poped out BSSecurableObject
	 */
	public static BSSecurableObjectContainer popMe(USMMessage msg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering popMe. Message : " + msg);
		}

		if (msg == null) {
			LOGGER.error("Message to pop the object cannot be null.");
			throw new InvalidParameterException();
		}
		int nType = msg.popInteger();
		ManagedObjectType type = ManagedObjectType.fromOrdinal(nType);

		int containerSize = msg.popInteger();
		List<BSSecurableObjectContainer> containers = null;
		if(containerSize != -1){
			containers = new ArrayList<>(containerSize);
			for (int i = 0; i < containerSize; i++) {
				BSSecurableObjectContainer container = BSSecurableObjectContainer.popMe(msg);
				containers.add(container);
			}
		}
		
		IIconPair icon = (IIconPair) msg.popObject();

		boolean compound = msg.popBoolean();
		String strOwnerCFName = msg.popString();
		String strCFID = msg.popString();
		String strUniqueName = msg.popString();
		String strDisplayName = msg.popString();

		BSSecurableObjectContainer transCF = new BSSecurableObjectContainer(strDisplayName, strUniqueName, strCFID, strOwnerCFName, icon, compound, containers, type);
		
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting popMe. Object created is : " + transCF);
		}

		return transCF;
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
    public boolean equals(Object obj) {
		boolean bEquals = false;
		if (obj instanceof BSSecurableObjectContainer) {
			BSSecurableObjectContainer transObj = (BSSecurableObjectContainer) obj;
			if (uniqueName.compareTo(transObj.uniqueName) == 0) {
				bEquals = true;
			}
		}
		return bEquals;
	}

	/**
	 * @see java.lang.Object#hashCode()
	 */
	@Override
    public int hashCode() {
		return uniqueName.hashCode();
	}

	public boolean isCompound() {
		return compound;
	}

	public void setCompound(boolean compound) {
		this.compound = compound;
	}

	public void addChildObject(BSSecurableBase object) {
		childObjects.add(object);
	}
	
	public boolean removeChildObject(BSSecurableBase object) {
		return childObjects.remove(object);
	}

	public List<BSSecurableBase> getChildObjects(){
		return childObjects;
	}
	
	public boolean isEmpty() {
		return childObjects.isEmpty();
	}
}
