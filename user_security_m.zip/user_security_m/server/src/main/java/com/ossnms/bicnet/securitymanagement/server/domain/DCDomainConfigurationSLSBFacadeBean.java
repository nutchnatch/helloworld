/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCDomainConfigurationSLSBFacadeBean
 * Author      	Muyeen Munaver
 * Substitute	Asifullakhan
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CREATE
 * 		:	TNMS.DX2.SM.DOMAIN.CONFIG	   
 * 		:	TNMS.DX2.SM.DOMAIN.VIEW
 * 		:	TNMS.DX2.SM.MAPPING.CREATE
 * 		:	TNMS.DX2.SM.MAPPING.VIEW    
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 10-Feb-2005	Asif 			CF000834 - Command Log Entries 
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityDomainConfigurationPrivateFacadeLocal;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityDomainConfigurationPrivateFacadeRemote;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import java.util.List;

/**
 * Bean class implementation for the Domain configuration related private
 * facade.
 * 
 */
@Stateless(name = "DCDomainConfigurationSLSBFacade")
@Local(ISecurityDomainConfigurationPrivateFacadeLocal.class)
@Remote(ISecurityDomainConfigurationPrivateFacadeRemote.class)
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class DCDomainConfigurationSLSBFacadeBean implements ISecurityDomainConfigurationPrivateFacadeLocal, ISecurityDomainConfigurationPrivateFacadeRemote {

	/**
	 * One to one mapping b/w bean and the pojo class
	 */
	protected DCDomainConfigurationPOJOImpl m_pojo = new DCDomainConfigurationPOJOImpl();

	public USMMessage getAllDomains(ISessionContext p_ctx) throws BcbSecurityException {

		return m_pojo.getAllDomains(p_ctx);
	}

	public USMMessage createDomain(ISessionContext p_ctx, DCDomainData p_domain) throws BcbSecurityException {

		return m_pojo.createDomain(p_ctx, p_domain);
	}

	public USMMessage deleteDomain(ISessionContext p_Ctx, List p_Domain) throws BcbSecurityException {

		return m_pojo.deleteDomain(p_Ctx, p_Domain);

	}

	public USMMessage modifyDomain(ISessionContext p_Ctx, DCDomainData p_Domain) throws BcbSecurityException {

		return m_pojo.modifyDomain(p_Ctx, p_Domain);
	}

	public USMMessage getServersForDomain(ISessionContext p_ctx, DCDomainData p_domain, boolean p_assigned,
			boolean p_domainConfigWdw) throws BcbSecurityException {

		DCDomainConfigurationPOJOImpl pojo = new DCDomainConfigurationPOJOImpl();
		return pojo.getServersForDomain(p_ctx, p_domain, p_assigned, p_domainConfigWdw);

	}

	public USMMessage getObjectsOfServerForDomain(ISessionContext p_ctx, DCDomainData p_domain,
			BSTransBicNetCFInfo p_server, boolean p_assigned) throws BcbSecurityException {

		return m_pojo.getObjectsOfServerForDomain(p_ctx, p_domain, p_server, p_assigned);
	}

	public USMMessage getAllMappings(ISessionContext p_Ctx) throws BcbSecurityException {

		return m_pojo.getAllMappings(p_Ctx);
	}

	public USMMessage changeMappings(ISessionContext p_ctx, List p_mappings) throws BcbSecurityException {

		return m_pojo.changeMappings(p_ctx, p_mappings);

	}


	public USMMessage assignUnassignObjectsToDomain(ISessionContext ctx, List objectsToAssign,
													List objectsToUnassign, DCDomainData domain, boolean createWindow) throws BcbSecurityException {

		return m_pojo.assignUnassignObjectsToDomain(ctx, objectsToAssign, objectsToUnassign, domain,
				createWindow);
	}

	@Override
	public USMMessage getAllSecurableObject(ISessionContext context)throws BcbSecurityException{
		return m_pojo.getAllSecurableObject(context);
	}
}
