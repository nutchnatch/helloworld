package com.ossnms.bicnet.securitymanagement.common.bicnetserver;

import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;

/**
 * This class encapsulates all the types of messages of AS.
 */
public class BSMessageType {
	/**
	 * String representation for notification of Insert CF
	 */
	public static final USMBaseMsgType BS_NOT_CF_INSERTED =
		new USMBaseMsgType("BS_Not_CF_Inserted");

	/**
	 * USMBaseMsgType representation for notification of Modify CF with name
	 */
	public static final USMBaseMsgType BS_NOT_CF_NAME_CHANGED =
		new USMBaseMsgType("BS_Not_CF_Name_Change");

	/**
	 * USMBaseMsgType representation for notification of Synchronize CF with Sec. Objs
	 */
	public static final USMBaseMsgType BS_NOT_CF_SYNCED_WITH_SEC_OBJS =
		new USMBaseMsgType("BS_Not_Synced_CF_With_SecurableObjects");

	/**
	 * USMBaseMsgType representation for notification of Remove CF
	 */
	public static final USMBaseMsgType BS_NOT_CF_REMOVED =
		new USMBaseMsgType("BS_Not_CF_Removed");

	/**
	 * USMBaseMsgType representation for notification of Server State Changed
	 */
	public static final USMBaseMsgType BS_NOT_CF_STATE_CHANGED =
		new USMBaseMsgType("BS_Not_CF_StateChanged");

	/**
	 * USMBaseMsgType representation for notification of Assign Sec Obj(s) to Domain(s)
	 */
	public static final USMBaseMsgType BS_NOT_SEC_OBJS_ASSIGNED_TO_DOMAINS =
		new USMBaseMsgType("BS_Not_SecObjs_Assigned_To_Domains");

	/**
	 * USMBaseMsgType representation for notification of Assign Sec Obj(s) to Domain(s)
	 */
	public static final USMBaseMsgType BS_NOT_NEW_SEC_OBJ_REGISTERED =
		new USMBaseMsgType("BS_Not_New_SecObj_Registered");

	/**
	 * USMBaseMsgType representation for notification of Assign Sec Obj(s) to Domain(s)
	 */
	public static final USMBaseMsgType BS_NOT_SEC_OBJ_UNREGISTERED =
		new USMBaseMsgType("BS_Not_SecObj_UnRegistered");

	/**
	 * USMBaseMsgType representation for notification of Securable object Name Change
	 */
	public static final USMBaseMsgType BS_NOT_SEC_OBJ_CHANGED =
		new USMBaseMsgType("BS_Not_SecObj_Changed");

	/**
	 * USMBaseMsgType representation for notification of Un-Assign Sec Obj(s) from Domain(s)
	 */
	public static final USMBaseMsgType BS_NOT_SEC_OBJS_UNASSIGNED_FROM_DOMAINS =
		new USMBaseMsgType("BS_Not_SecObjs_UnAssigned_From_Domains");

	/**
	 * USMBaseMsgType representation for request to Get Configured CFs
	 */
	public static final USMBaseMsgType BS_REQ_GET_CONF_CFS =
		new USMBaseMsgType("BS_Req_GetConfCFs");

	/**
	 * USMBaseMsgType representation for request to Get Managed Elements for a CF
	 */
	public static final USMBaseMsgType BS_REQ_GET_SEC_OBJS_FOR_CF =
		new USMBaseMsgType("BS_Req_GetSecObjs_For_CF");

	/**
	 * USMBaseMsgType representation for request to Remove a Configured CF
	 */
	public static final USMBaseMsgType BS_REQ_REMOVE_CFS =
		new USMBaseMsgType("BS_Req_RemoveCF");

	/**
	 * USMBaseMsgType representation for request to Synchronize Configured cf with Sec Obj data
	 */
	public static final USMBaseMsgType BS_REQ_SYNC_CFS_WITH_SEC_OBJS =
		new USMBaseMsgType("BS_Req_SyncCFs_With_SecObjs");

	/**
	 * USMBaseMsgType representation for request to Get the complete cf detail
	 */
	public static final USMBaseMsgType BS_REQ_GET_COMP_CF_DETAIL =
		new USMBaseMsgType("BS_Req_GetCompleteCFInfo");

	/**
	 * USMBaseMsgType representation for request to update the Server info
	 */
	public static final USMBaseMsgType BS_REQ_UPDATE_CF_DISPLAY_NAME =
		new USMBaseMsgType("BS_Req_UpdateCF_DisplayName");

	/**
	 * USMBaseMsgType representation for response to Get Configured Cfs
	 */
	public static final USMBaseMsgType BS_RES_GET_CONF_CFS =
		new USMBaseMsgType("BS_Res_GetConfCFs");

	/**
	 * USMBaseMsgType representation for response to Get Securable Object(s) for Cf
	 */
	public static final USMBaseMsgType BS_RES_GET_SEC_OBJS_FOR_CF =
		new USMBaseMsgType("BS_Res_GetSecObjs_For_CF");

	/**
	 * USMBaseMsgType representation for response to Remove Configured cfs
	 */
	public static final USMBaseMsgType BS_RES_REMOVE_CFS =
		new USMBaseMsgType("BS_Res_RemoveCF");

	/**
	 * USMBaseMsgType representation for response to Synch App Server with sec Objs data
	 */
	public static final USMBaseMsgType BS_RES_SYNC_CFS_WITH_SEC_OBJS =
		new USMBaseMsgType("BS_Res_SyncCFs_With_SecObjs");

	/**
	 * USMBaseMsgType representation for response to Get the complete cf detail
	 */
	public static final USMBaseMsgType BS_RES_GET_COMP_CF_DETAIL =
		new USMBaseMsgType("BS_Res_GetCompleteCFInfo");

	/**
	 * USMBaseMsgType representation for response to update the Server display name
	 */
	public static final USMBaseMsgType BS_RES_UPDATE_CF_DISPLAY_NAME =
		new USMBaseMsgType("BS_Res_UpdateCF_DisplayName");

	/**
	 * USMBaseMsgType representation for response to update the Server display name
	 */
	public static final USMBaseMsgType BS_NOT_SEC_OBJ_CONTAINER_CHANGE =
		new USMBaseMsgType("BS_Not_Sec_Obj_Container_Change");

}
