/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCViewDomainConfigController
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CONFIG	   
 * 		:	TNMS.DX2.SM.DOMAIN.VIEW    
 *    
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 10-Feb-2005	Asif 			CF000834 - Command Log Entries 
 * 11-Mar-2005	Asif			CF000845 - System Event Log Entries
 * 22-Mar-2005	Muyeen Munaver	CF0001791 - Problems with Login
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessageType;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;
import com.ossnms.bicnet.securitymanagement.server.basic.notification.USMNotifier;
import com.ossnms.bicnet.securitymanagement.server.logging.LMInterFace;
import com.ossnms.bicnet.securitymanagement.server.logging.LMLogRecordData;
import com.ossnms.bicnet.securitymanagement.server.logging.LMLogRecordEnum;
import org.apache.log4j.Logger;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Controller for retrieving the domain configuration details. The details
 * involving the domains created and the NEs assigned to that domain, and also supports domain deletion
 */
class DCViewDomainConfigController {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(DCViewDomainConfigController.class);

	/**
	 * Constructor
	 */
	public DCViewDomainConfigController() {

	}

	/**
	 * This method is called when the domain admin view is opened. The user wants to see
	 * all the domains now. This would include the global domain, since the global domain 
	 * also has to be shown to the user.
	 * @return USMMessage Message that contains all the domain information
	 */
	public USMMessage getDomains() {

		LOGGER.debug("getDomains() - Enter");
		DCServerDataManager cache = DCServerDataManager.getInstance();
		ArrayList<DCDomainData> domains = new ArrayList<>();
		cache.getAllConfiguredDomains(domains);

		USMMessage message =
			new USMMessage(
				DCMessageType.DC_RES_DOMAINS,
				USMMessage.USMMESSAGE_RESPONSE);

		DCDomainData.pushDomainsToMessage(domains, message);

		message.pushInteger(DCMessages.DC_NO_ERROR);

		LOGGER.debug("getDomains() - Exit");
		return message;
	}

	/**
	 * This method deletes the list of domains passed. It will also send
	 * notification about the list of domains deleted
	 * @param p_domains ArrayList of domains that are to be deleted
	 * @return Message that contains the result of the operation
	 *  
	 */
	public USMMessage deleteDomain(ISessionContext p_ctx, List p_domains) {

		LOGGER.debug("deleteDomain() - Enter");

		List<DCDomainData> succDeleted = new ArrayList<>();
		USMMessage respMsg =
			new USMMessage(
				DCMessageType.DC_RES_DELETE_DOMAIN,
				USMMessage.USMMESSAGE_RESPONSE);

		if (null == p_domains) {

			LOGGER.error("Null domain was passed for deletion");
			respMsg.pushInteger(DCMessages.DC_INTERNAL_ERROR);
			return respMsg;
		}

		int nDomain = p_domains.size();
		for (int nDx = 0; nDx < nDomain; ++nDx) {
			DCDomainData domData = (DCDomainData) p_domains.get(nDx);

			try {

				DCServerDataManager.getInstance().deleteDomain(domData);
				domData.pushMe(respMsg);
				respMsg.pushInteger(DCMessages.DC_NO_ERROR);
				succDeleted.add(domData);
				// Create security log for the event.
				String displayStr =
					MessageFormat.format(
						USMCommonStrings.IDS_DC_DOMAIN_DELETION,
							domData.getDomainName(),
							p_ctx.getUserName(),
							((IEnhancedSessionContext) p_ctx).getClientMachineName());

				LMLogRecordData usmLogRecord =
					new LMLogRecordData(
						LMLogRecordEnum.DOMAIN_DELETION,
						domData.getDomainName(),
						LMLogRecordData._SUCCESS,
						null,
						LogSeverity.MESSAGE.guiLabel(),
						null,
						displayStr);
				LMInterFace.getInstance().createSecurityLogRecord(
					p_ctx,
					usmLogRecord);
			}
			//No need to trace this, as this would have already been traced, when the exception would have
			//been thrown.
			catch (DCDataBaseException dbex) {
				domData.pushMe(respMsg);
				respMsg.pushInteger(DCMessages.DC_LDAP_ERROR);
			} catch (DCInvalidDomainException invex) {
				domData.pushMe(respMsg);
				respMsg.pushInteger(DCMessages.DC_DOMAIN_INVALID);
			}
			catch(DCDomainMappedException ex){
				domData.pushMe(respMsg);
				respMsg.pushInteger(DCMessages.DC_DOMAIN_MAPPED_ERROR);
			}
			//Tracing is needed here, as it is an exception outside DC
			catch (Exception ex) {
				//internal error
				domData.pushMe(respMsg);
				respMsg.pushInteger(DCMessages.DC_INTERNAL_ERROR);
				LOGGER.error(
					"deleteDomain() - Some unknown error has occured"
						+ ex.getMessage());
			}
		}

		//Finally push in the size of the domains which were to be deleted
		respMsg.pushInteger(nDomain);

		for (int nDx = 0; nDx < succDeleted.size(); ++nDx) {
			//send notification saying Domain Deleted
			USMMessage domDelNotMsg =
				new USMMessage(
					DCMessageType.DC_NOT_DOMAIN_DELETED,
					USMMessage.USMMESSAGE_NOTIFICATION);
			DCDomainData delDom = succDeleted.get(nDx);
			delDom.pushMe(domDelNotMsg);
			//Notification for the list of deleted domains
			USMNotifier.getInstance().sendNotification(domDelNotMsg);

			//External Notification - Domains - Object Deletion
			new SecurityDomainFacade().sendObjectDeletion(delDom);

			LOGGER.debug(
				"deleteDomain() - Notification was sent for domain deletion ");

		}

		LOGGER.debug("deleteDomain() - Exit");
		return respMsg;
	}
}
