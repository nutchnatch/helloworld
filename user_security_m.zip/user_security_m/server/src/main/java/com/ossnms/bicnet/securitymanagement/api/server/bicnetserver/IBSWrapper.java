package com.ossnms.bicnet.securitymanagement.api.server.bicnetserver;

import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObjectContainer;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;

import java.util.List;
import java.util.Optional;

/**
 * created on 24/9/2014
 */
public interface IBSWrapper {
    /**
     *
     * @param id
     * @return
     */
    BSTransBicNetCFInfo getFunction(String id);

    /**
     *
     * @return
     */
    List<BSTransBicNetCFInfo> getFunctions();

    /**
     *
     * @param uniqueName
     * @return
     */
    BSSecurableObject getSecurableObject(String uniqueName);

    /**
     *
     * @param uniqueName
     * @return
     */
    BSSecurableObject getSecurableObjectWithACL(String uniqueName);


    /**
     *
     * @return
     */
    List<BSSecurableObject> getSecurableObjects();

    /**
     *
     * @return
     */
    List<BSSecurableObject> getSecurableObjectsWithACL();

    /**
     *
     * @param cf
     * @return
     */
    List<BSSecurableObject> getSecurableObjects(BSTransBicNetCFInfo cf);


    /**
     *
     * @param cf
     * @return
     */
    List<BSSecurableObject> getSecurableObjects(BSTransBicNetCFInfo cf, int domainId);


    /**
     *
     * @param uniqueName
     * @return
     */
    BSSecurableObjectContainer getSecurableObjectContainer(String uniqueName);

    /**
     *
     * @param uniqueName
     * @return
     */
    int getContainerChildCount(String uniqueName);

    /**
     *
     * @param cf
     * @return
     */
    List<BSSecurableObjectContainer> getSecurableObjectContainers(BSTransBicNetCFInfo cf);

    /**
     *
     * @param secObj
     * @return
     */
    boolean updateACL(BSSecurableObject secObj);

    /**
     *
     * @param securableObject
     * @return
     */
    boolean saveSecurableObject(BSSecurableObject securableObject);

    /**
     *
     * @param listSecurableObjs
     * @return
     */
    boolean saveSecurableObjects(List<BSSecurableObject> listSecurableObjs);

    /**
     * @param container
     * @return
     */
    boolean saveSecurableObjectContainer(BSSecurableObjectContainer container);

    /**
     *
     * @param secObj
     * @return
     */
    boolean deleteSecurableObject(BSSecurableObject secObj);

    /**
     *
     * @param container
     * @return
     */
    boolean deleteSecurableObjectContainer(BSSecurableObjectContainer container);

    /**
     *
     * @param secObj
     * @return
     */
    boolean modifySecurableObject(BSSecurableObject secObj);

    /**
     *
     * @param secObjectContainer
     * @return
     */
    boolean modifySecurableObjectContainer(BSSecurableObjectContainer secObjectContainer);

    /**
     *
     * @param transCF
     * @return
     */
    boolean insertFunction(BSTransBicNetCFInfo transCF);

    /**
     *
     * @param cf
     * @return
     */
    boolean removeFunction(BSTransBicNetCFInfo cf);

    /**
     *
     * @param cf
     * @return
     */
    boolean changeFunctionDisplayName(BSTransBicNetCFInfo cf);

    /**
     * Retrieves a Securable Object By Display Name
     *
     * @param displayName the display name of the securable object
     * @return an {@link Optional} instance parameterized with {@link BSSecurableObject}
     */
    Optional<BSSecurableObject> getSecurableObjectByDisplayName(String displayName);

    int getSecurableObjectCount(BSTransBicNetCFInfo server);

    int getSecurableObjectCount(BSTransBicNetCFInfo server, int domainID);
}

