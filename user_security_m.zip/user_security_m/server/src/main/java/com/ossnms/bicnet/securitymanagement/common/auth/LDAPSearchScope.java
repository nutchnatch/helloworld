package com.ossnms.bicnet.securitymanagement.common.auth;

import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;

/**
 *
 */
public enum LDAPSearchScope {
    ONELEVEL    (USMCommonStrings.IDS_GS_LDAP_SCOPE_ONELEVEL),
    SUBTREE     (USMCommonStrings.IDS_GS_LDAP_SCOPE_SUBTREE);

    private String name;

    /**
     * Constructor
     *
     * @param name the name used to identify this search scope
     */
    LDAPSearchScope(String name){
        this.name = name;
    }

    /**
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    public static LDAPSearchScope fromName(String name){
        for (LDAPSearchScope ldapSearchScope : LDAPSearchScope.values()) {
            if(ldapSearchScope.getName().equals(name)){
                return ldapSearchScope;
            }
        }

        return null;
    }

    /**
     *
     * @return
     */
    public String toString(){
        return name;
    }
}
