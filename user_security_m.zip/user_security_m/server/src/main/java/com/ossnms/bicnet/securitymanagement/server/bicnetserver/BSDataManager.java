package com.ossnms.bicnet.securitymanagement.server.bicnetserver;

import com.ossnms.bicnet.securitymanagement.api.server.bicnetserver.IBSWrapper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSAccessControlList;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSMessageType;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSReturnType;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableBase;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObjListComparator;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObjectContainer;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.utils.InternalUSMBeanLocator;
import com.ossnms.bicnet.securitymanagement.server.basic.notification.USMNotifier;
import com.ossnms.bicnet.securitymanagement.server.domain.DCSubsystemSAP;
import com.ossnms.bicnet.securitymanagement.server.domain.SecurityDomainFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;


/**
 * This is a helper class to the Central Controller.
 * <p>
 * Outside this class only the TransData info is maintained. This class isolates the other classes of BS from the DB
 * Wrapper. This class also maintains a Cache of information.
 */
public final class BSDataManager {
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(BSDataManager.class);

    /**
     * This is the Interface class that is used for the purpose of LDAP
     * operations. Since this class needs to do operations in LDAP, an object
     * is created and stored for this purpose.
     */
    private IBSWrapper bsWrapper = null;

    /**
     * Constructor
     */
    public BSDataManager() {
        LOGGER.debug("Entering constructor");

        LOGGER.debug("Exiting constructor");
    }

    /**
     * This function is responsible to initialize the Data Cache Manager with the
     * LDAP data. This includes both the CF information and the Sec Object information.
     */
    public void initialize() {
        LOGGER.debug("Entering initialize");

        bsWrapper = InternalUSMBeanLocator.getEJB(IBSWrapper.class);
        // initialize the cache
//		 BSCacheManager.initializeCache(getSecurableObjects());

        LOGGER.debug("Exiting initialize");
    }

    /**
     * This function is responsible to check the mapCFIDToMapOfSecObjs if a
     * Map for the SecurableObjects with the Naming Context already exists. If it does exist,
     * the Map is returned back. Else a new Map is created and added to the
     * mapCFIDToMapOfSecObjs for the CF ID passed
     *
     * @param functionId The CF ID of the CF for which we require the Sec Objects
     * @return Map  Map which contains all the Securable Object for a particular CF
     */
    private Map<String, BSSecurableObject> getSecurableObjectsMap(String functionId) {
        LOGGER.debug("Entering getSecurableObjectsMap. CF : " + functionId);

        Map<String, BSSecurableObject> objectMap = new HashMap<>();

        BSTransBicNetCFInfo functionInfo = getFunction(functionId);

        getSecurableObjects(functionInfo).forEach(securableObject -> objectMap.put(securableObject.getUniqueName(), securableObject));

        LOGGER.debug("Exiting getSecurableObjectsMap for Component Type : " + functionId + " Returing : " + objectMap);
        return objectMap;
    }

    /**
     * This function is responsible to check the mapCfIdToMapOfSecObjsContainer
     * if a Map for the SecurableObjectContainers with the Naming Context already exists.
     * If it does exist, the Map is returned back. Else a new Map is created and
     * added to the mapCFIDToMapOfSecObjs for the CF ID passed
     */
    private Map<String, BSSecurableObjectContainer> getSecurableObjectContainersMap(String functionId) {
        LOGGER.debug("Entering getSecurableObjectsMap. CF : " + functionId);

        Map<String, BSSecurableObjectContainer> containerMap = new HashMap<>();

        BSTransBicNetCFInfo functionInfo = getFunction(functionId);


        getSecurableObjectContainers(functionInfo).forEach(
                securableContainer -> containerMap.put(securableContainer.getUniqueName(), securableContainer)
        );

        LOGGER.debug("Exiting getSecurableObjectsMap for Component Type : " + functionId + " Returing : " + containerMap);
        return containerMap;
    }

    /**
     * Function to return the list of CFs that have been configured to
     * work in USM scenario.
     *
     * @return List List which contain all the CFs configured within USM
     */
    List<BSTransBicNetCFInfo> getAllFunctions() {
        LOGGER.debug("Entering getAllFunctions.");

        List<BSTransBicNetCFInfo> lstConfiguredCFs = bsWrapper.getFunctions();

        LOGGER.debug("Exiting getAllFunctions. Returning : " + lstConfiguredCFs);
        return lstConfiguredCFs;
    }

    /**
     * Function to retrieve the Securable Object information for the CF.
     *
     * @param appServer The CF for which we have to get the Sec Objects.
     * @return List List of Securable Objects for the CF
     */
    List<BSSecurableObject> getSecurableObjects(BSTransBicNetCFInfo appServer) {
        LOGGER.debug("Entering getSecurableObjects for CF : " + appServer);

        List<BSSecurableObject> objectList = bsWrapper.getSecurableObjects(appServer);

        LOGGER.debug("Exiting getSecurableObjects for CF : " + appServer + " Returning Sec Obj(s)" + objectList);
        return objectList;
    }

    /**
     * Function to retrieve the Securable Object information for the CF.
     *
     * @param appServer The CF for which we have to get the Sec Objects.
     * @return List List of Securable Objects for the CF
     */
    List<BSSecurableObject> getSecurableObjects(BSTransBicNetCFInfo appServer, int domainId) {
        LOGGER.debug("Entering getSecurableObjects for CF : " + appServer);

        List<BSSecurableObject> objectList = bsWrapper.getSecurableObjects(appServer, domainId);

        LOGGER.debug("Exiting getSecurableObjects for CF : " + appServer + " Returning Sec Obj(s)" + objectList);
        return objectList;
    }


    /**
     * @param server
     * @return
     */
    public int getSecurableObjectCount(BSTransBicNetCFInfo server) {
        LOGGER.debug("Entering getSecurableObjectCount for CF : " + server);

        int result = bsWrapper.getSecurableObjectCount(server);

        LOGGER.debug("Exiting getSecurableObjectCount for CF : " + server);
        return result;
    }

    /**
     * @param server
     * @param domainID
     * @return
     */
    public int getSecurableObjectCount(BSTransBicNetCFInfo server, int domainID) {
        LOGGER.debug("Entering getSecurableObjectCount for CF : " + server);

        int result = bsWrapper.getSecurableObjectCount(server, domainID);

        LOGGER.debug("Exiting getSecurableObjectCount for CF : " + server);
        return result;
    }

    /**
     * Function to retrieve the Securable Object information for the CF.
     *
     * @param appServer The CF for which we have to get the Sec Objects.
     * @return List List of Securable Objects for the CF
     */
    List<BSSecurableObjectContainer> getSecurableObjectContainers(BSTransBicNetCFInfo appServer) {
        LOGGER.debug("Entering getSecurableObjects for CF : " + appServer);

        List<BSSecurableObjectContainer> containers = bsWrapper.getSecurableObjectContainers(appServer);

        LOGGER.debug("Exiting getSecurableObjects for CF : " + appServer + " Returning Sec Obj(s)" + containers);
        return containers;
    }

    /**
     * Function to retrieve all the NEs that are managed by USM
     *
     * @return List The List which will contain all the Sec Objects within USM.
     */
    List<BSSecurableObject> getSecurableObjects() {
        LOGGER.debug("Entering getSecurableObjects");

        List<BSSecurableObject> vecAllSecObjs = bsWrapper.getSecurableObjects();

        LOGGER.debug("Exiting getSecurableObjects");
        return vecAllSecObjs;
    }


    public List<BSSecurableObject> getSecurableObjectsWithACL() {
        LOGGER.debug("Entering getSecurableObjects");

        List<BSSecurableObject> vecAllSecObjs = bsWrapper.getSecurableObjectsWithACL();

        LOGGER.debug("Exiting getSecurableObjects");
        return vecAllSecObjs;
    }

    /**
     * Function to retrieve the NE, managed by USM, with the specified id
     *
     * @return the instance of BSSecurableObject
     */
    public BSSecurableObject getSecurableObject(String uniqueName) {
        BSSecurableObject securableObject = bsWrapper.getSecurableObject(uniqueName);
        return securableObject;
    }

    /**
     * Function to retrieve the NE, managed by USM, with the specified id
     *
     * @return the instance of BSSecurableObject
     */
    BSSecurableObject getSecurableObjectByDisplayName(String displayName) {
        Optional<BSSecurableObject> optionalSecurableObject = bsWrapper.getSecurableObjectByDisplayName(displayName);

        if (optionalSecurableObject.isPresent()) {
            return optionalSecurableObject.get();
        }

        return null;
    }

    /**
     * @param uniqueName
     * @return
     */
    BSSecurableObjectContainer getSecurableObjectContainer(String uniqueName) {
        BSSecurableObjectContainer container = bsWrapper.getSecurableObjectContainer(uniqueName);
        return container;
    }

    /**
     * This function is invoked when we are inserting a CF
     * into USM. This function is responsible to create a
     * persistent object of the CF and to store it in the LDAP.
     * It will then update the cache to now also hold the CF
     * that has been inserted.
     *
     * @param cf The CF that has to be inserted into USM
     * @return BSReturnType  Indicates whether it was possible
     * to insert the CF into USM
     */
    BSReturnType insertFunction(BSTransBicNetCFInfo cf) {
        LOGGER.debug("Entering insertFunction. Inserting : " + cf);

        BSReturnType result = BSReturnType.FAILURE_T;
        try {
            boolean bAddedToLDAP = bsWrapper.insertFunction(cf);

            if (bAddedToLDAP) {
                result = BSReturnType.SUCCESS_T;
//				putCFInfoIntoCFIdToCFInfoMap(cf.getCFid(), cf);
            } else {
                result = BSReturnType.LDAP_ERROR_T;
            }
        } catch (Exception ex) {
            LOGGER.error("Exception raised : " + ex);
        }

        LOGGER.debug("Exiting insertFunction. Result of inserting : " + cf + " is : " + result);
        return result;
    }

    /**
     * Function that will check whether a CF is already configured
     * within USM
     *
     * @param type The Type of the CF which has to be checked.
     * @return boolean
     * Indicates whether a certain CF is available with USM or not.
     */
    boolean isFunctionConfigured(String type) {
        return bsWrapper.getFunction(type) != null;

    }

    /**
     * This function is responsible to update the Sec objects for a particular CF.
     *
     * @param cf                     The CF under which we have to update the Sec Objects
     * @param listOfNewSecurableObjs The Sec Objects that have to be updated
     * @return BSReturnType Result of the updation operation.
     */
    BSReturnType updateSecurableObjsForCF(BSTransBicNetCFInfo cf, List<BSSecurableObject> listOfNewSecurableObjs) {
        Map<String, BSSecurableObject> mapSecObjs = getSecurableObjectsMap(cf.getCFid());
        List<BSSecurableObject> vecOldSecObjs = new ArrayList<>(mapSecObjs.values());

        BSSecurableObjListComparator comparator = new BSSecurableObjListComparator(vecOldSecObjs, listOfNewSecurableObjs);

        List<BSSecurableObject> lstCreatedNEs = comparator.getNewlyCreatedSecurableObjs();
        insertSecurableObjects(cf, lstCreatedNEs);

        List<BSSecurableObject> vecRemovedNEs = comparator.getDeletedSecurableObjs();
        removeSecurableObjsForCF(cf, vecRemovedNEs);

        List<BSSecurableObject> vecModifiedNEs = comparator.getModifiedSecurableObjs();
        modifySecurableObjects(cf, vecModifiedNEs);

        return BSReturnType.SUCCESS_T;
    }

    /**
     * This function is used to remove created Sec Objects, from the Cache.
     *
     * @param cf                  The CF under which we have to remove the Securable Object
     * @param listOfSecurableObjs The Securable Objects that have to be removed.
     * @return BSReturnType Result of the Removal of the Securable Objects.
     */
    BSReturnType removeSecurableObjsForCF(BSTransBicNetCFInfo cf, List<BSSecurableObject> listOfSecurableObjs) {
        BSReturnType result = BSReturnType.SUCCESS_T;
        List<BSSecurableObject> lstOfRemovedNEs = new ArrayList<>();

        for (BSSecurableObject removedNE : listOfSecurableObjs) {
            BSSecurableObject objInCache = getSecurableObject(removedNE.getUniqueName());

            if (objInCache != null) {
                boolean bRemoved = bsWrapper.deleteSecurableObject(objInCache);
                if (bRemoved) {
                    removeSecurableObjectBaseFromContainers(cf, objInCache, objInCache.getObjectContainers());
                    lstOfRemovedNEs.add(objInCache);
                } else {
                    result = BSReturnType.LDAP_ERROR_T;
                    LOGGER.error("Error deleting NE : " + removedNE);
                }
            }
        }

        // Send the notification for AA, since they will not listen to the CF Synched Notification.
        BSServerHelper.sendRegistrationObjectNotification(cf, lstOfRemovedNEs, false);
        return result;
    }

    /**
     * This function is used to modify created Sec Objects, in the Cache.
     *
     * @param cf              The CF under which we have to modify the Sec Objects
     * @param modifiedSecObjs The modified Sec Objects.
     * @return BSReturnType Result of the Modification.
     */
    BSReturnType modifySecurableObjects(BSTransBicNetCFInfo cf, List<BSSecurableObject> modifiedSecObjs) {
        BSReturnType result = BSReturnType.SUCCESS_T;

        //
        modifiedSecObjs.forEach(securableObject -> {
            BSSecurableObject persisted = bsWrapper.getSecurableObject(securableObject.getUniqueName());

            if (persisted != null) {
                securableObject.setACL(persisted.getACL());
                // we should update the domains
                updateSecurableObjectDomainAssignment(securableObject);
                bsWrapper.saveSecurableObject(securableObject);
            }
        });

        BSServerHelper.sendSecObjectModifiedNotification(cf, modifiedSecObjs);


        return result;
    }

    /**
     * This function is used to modify created Sec Object Containers, in the Cache.
     *
     * @param cf                       The CF under which we have to modify the Sec Object Containers
     * @param modifiedSecObjContainers The modified Sec Object Containers
     * @return BSReturnType Result of the Modification.
     */
    BSReturnType modifySecurableObjContainersForCF(BSTransBicNetCFInfo cf, List<BSSecurableObjectContainer> modifiedSecObjContainers) {
        BSReturnType[] result = {BSReturnType.SUCCESS_T};

        List<BSSecurableObjectContainer> modifiedContainers = modifiedSecObjContainers
                .stream()
                .filter(container -> {
                    if (!bsWrapper.saveSecurableObjectContainer(container)) {
                        result[0] = BSReturnType.LDAP_ERROR_T;
                        LOGGER.error("Error Modifying Name of Sec Object Container: {}", container);
                        return false;
                    }

                    return true;
                }).collect(Collectors.toList());

        BSServerHelper.sendSecObjectModifiedNotification(cf, modifiedContainers);
        return result[0];
    }


    /**
     * This function is responsible to add the Sec Objects that have been passed to the
     * Cache as well as the LDAP
     *
     * @param cf                  The CF for which we have to add the Sec objects.
     * @param listOfSecurableObjs The List of Sec Objects that are to be added to the CF
     * @return BSReturnType  Indicates the result of the insertion of the Sec Objects for the passed CF.
     */
    BSReturnType insertSecurableObjects(BSTransBicNetCFInfo cf, List<BSSecurableObject> listOfSecurableObjs) {
        LOGGER.debug("Entering insertSecurableObjects. CF is : " + cf + " Securable Objects are : " + listOfSecurableObjs);
        BSReturnType result = BSReturnType.SUCCESS_T;

        // the securable object might be assigned to a compound securable object container
        // in such a case, we need the inserted NE to match his sibling's assignments
        if (listOfSecurableObjs.size() > 0) {
            updateSecurableObjectDomainAssignment(listOfSecurableObjs);
        }

        bsWrapper.saveSecurableObjects(listOfSecurableObjs);

        // Send the notification for AA, since they will not listen to the CF
        // Synced Notification.
        BSServerHelper.sendRegistrationObjectNotification(cf, listOfSecurableObjs, true);

        // notify ACL modified
        BSServerHelper.notifyACLModified(listOfSecurableObjs);

        LOGGER.debug("Exiting insertSecurableObjects. Result is : " + result);
        return result;
    }

    /**
     * @param securableObject
     * @return
     */
    private BSReturnType updateSecurableObjectDomainAssignment(BSSecurableObject securableObject) {
        // if the securable object belongs to any compound container (which is not empty),
        // we should unassign any other domains
        List<BSSecurableObjectContainer> containers = getRelevantCompoundContainers(securableObject);
        if(containers.size() == 0){
            // nothing to update
            return BSReturnType.SUCCESS_T;
        }

        // get the list of domains we should add the object to
        List<DCDomainData> domains = containers.stream()
                .map(this::getCompoundAssignedDomains)
                .flatMap(Collection::stream)
                .collect(Collectors.toList());

        // get the list of domains to unassign the object from
        List<DCDomainData> toUnassign = DCSubsystemSAP.getAllDomains()
                .stream()
                .filter(domain -> domain.getDomainID() != 0
                        && securableObject.belongsToDomain(domain.getDomainID())
                        && !domains.contains(domain)
                )
                .collect(Collectors.toList());

        if (toUnassign.size() > 0) {
            // issue the update command to unassign (silently)
            updateACL(securableObject, toUnassign, false);
        }

        if (domains.size() > 0) {
            // issue the update command to assign (silently)
            updateACL(securableObject, domains, true);
        }

        return BSReturnType.SUCCESS_T;
    }

    /**
     *
     * @param securableObject
     * @return
     */
    private List<BSSecurableObjectContainer> getRelevantCompoundContainers(BSSecurableObject securableObject) {
        if (securableObject.getObjectContainers() != null) {
            return securableObject.getObjectContainers()
                    .stream()
                    .filter(BSSecurableObjectContainer::isCompound)
                    .filter(container -> !isEmpty(container))
                    .collect(Collectors.toList());
        }

        return new ArrayList<>();
    }

    private boolean isEmpty(BSSecurableObjectContainer objectContainer) {
        return getSecurableObjects()
                        .stream()
                        .filter(base -> base.getObjectContainers().contains(objectContainer)).count() == 0;
    }

    /**
     * @param object
     * @param domains
     * @param toAssign
     */
    private void updateACL(BSSecurableObject object, List<DCDomainData> domains, boolean toAssign) {
        domains.forEach(domain -> {
            if (toAssign) {
                object.addToDomainID(domain.getDomainID());
            } else {
                object.removeFromDomainID(domain.getDomainID());
            }
        });
    }

    /**
     * @param securableObjects
     * @return
     */
    private BSReturnType updateSecurableObjectDomainAssignment(List<BSSecurableObject> securableObjects) {
        BSReturnType returnType = BSReturnType.SUCCESS_T;

        if (securableObjects == null || securableObjects.size() == 0) {
            return returnType;
        }

        securableObjects.forEach(this::updateSecurableObjectDomainAssignment);

        return returnType;
    }


    /**
     * @param container
     * @return
     */
    private List<DCDomainData> getCompoundAssignedDomains(BSSecurableObjectContainer container) {
        List<DCDomainData> domainData = new ArrayList<>();

        if (!container.isCompound()) {
            return domainData;
        }

        // we need to retrieve the complete securable object container information (including children)
        BSSecurableObjectContainer securableObjectContainer = getSecurableObjectContainer(container.getUniqueName());

        if (securableObjectContainer == null) {
            return domainData;
        }

        // fetch the container children
        List<BSSecurableBase> securableObjects = getSecurableObjects()
                .stream()
                .filter(base -> base.getObjectContainers().contains(securableObjectContainer))
                .collect(Collectors.toList());

        for (BSSecurableBase child : securableObjects) {
            if (child instanceof BSSecurableObject) {
                // assuming that all the children have the save domains assigned
                BSSecurableObject securableObject = (BSSecurableObject) child;
                return DCSubsystemSAP.getAllDomains()
                        .stream()
                        .filter(domain -> securableObject.belongsToDomain(domain.getDomainID()))
                        .collect(Collectors.toList());
            }
        }


        return domainData;
    }

    /**
     * Function to retrieve the Transient CF Object given an ID for the Object
     *
     * @param strId The ID by which the CF is identified
     * @return BSTransBicNetCFInfo The Trans CF object associated with the ID.
     */
    BSTransBicNetCFInfo getFunction(String strId) {
        return bsWrapper.getFunction(strId);
    }

    /**
     * Helper function to assign and unassign NEs
     *
     * @param lstSecurableObj        This contains all the Sec Objects that should be assigned
     *                               to the domains
     * @param lstDomains             The domains to which the Sec Objects should be (un)assigned .
     * @param lstFailedSecurableObjs The Sec Objects for which it was not possible to (un)assign
     *                               Domains
     * @param assign                 Boolean to indicate whether it is a assign or unassign
     *                               operation
     * @return BSReturnType  The result of the assign or
     * unassign operation.
     */
    BSReturnType updateACL(List<BSSecurableObject> lstSecurableObj, List<DCDomainData> lstDomains, List<BSSecurableObject> lstFailedSecurableObjs, boolean assign) {

        BSReturnType status;
        List<BSSecurableObject> vecSuccessfulNEs = new ArrayList<>();

        Set<BSTransBicNetCFInfo> setServerChanged = new HashSet<>();

        for (BSSecurableObject clientNE : lstSecurableObj) {
            // Get each NE, from the NE get the Server it belongs ot.
            // Then get the NEs that are there for the server in the cache.
            // The reason for not using the NE sent is that this NE info could
            // be old and outdated.
            BSSecurableObject retrievedSecObj = bsWrapper.getSecurableObjectWithACL(clientNE.getUniqueName());

            if (retrievedSecObj != null) {
                // To be able to do a roll back in case of an LDAP problem, we shall
                // follow the following method. There are 2 NEs
                // a Sent from Client called as clientNE
                // b retrieved from the cache called the retrievedNE
                // 1. Copy the ACL of the retrievedNE into clientNE
                // 2. Update the clientNE ACL with the new Info
                // 3. Use this to update the LDAP
                // 4. If successfully then Update the retrievedNE ACL with the clientNE ACL
                // 5. If failure send the retrievedNE to the clients.

                BSAccessControlList retrievedACL = retrievedSecObj.getACL();
                clientNE.setACL(retrievedACL);

                // Now we have the NE which is the same as the one that is sent.
                for (DCDomainData dom : lstDomains) {
                    // If the function was called for assign domain, then add the domain else remove the domain from the ACL.
                    int nDomID = dom.getDomainID();
                    if (0 == nDomID) {
                        String str = assign ? "Assignment." : "UnAssignment.";
                        LOGGER.error("DC has given us the Global Domain for " + str);
                        // This makes sure we don't do the operation for the Global Domain
                        continue;
                    }

                    if (assign) {
                        clientNE.addToDomainID(nDomID);
                    } else {
                        clientNE.removeFromDomainID(nDomID);
                    }
                }
                boolean result = true;


                result = bsWrapper.updateACL(clientNE);

                if (result) {
                    // 4.
                    BSAccessControlList acl = clientNE.getACL();
                    retrievedSecObj.setACL(acl);
                    vecSuccessfulNEs.add(retrievedSecObj);
                    String nServerID = retrievedSecObj.getOwnerCfId();
                    setServerChanged.add(getFunction(nServerID));
                } else {
                    // 5.
                    lstFailedSecurableObjs.add(retrievedSecObj);
                }
                // end of if ( check for same NE)
            } else {
                // Add this NE to the failed list
                lstFailedSecurableObjs.add(clientNE);
                LOGGER.error("(Un)Assigning a Securable Object which is no more available." + clientNE);
            }
        } // end of for loop sent NE

        // Now we have to send a notification to the DC fellows to update their windows
        // The message will have the following in the pop order
        // 1. No of NEs.
        // 2. NEs
        // 3. No. of Domains
        // 4. Domains

        if (vecSuccessfulNEs.size() > 0) {
            // Only if there has been a successful assign of domains should we do this.
            USMBaseMsgType msgType = assign ? BSMessageType.BS_NOT_SEC_OBJS_ASSIGNED_TO_DOMAINS : BSMessageType.BS_NOT_SEC_OBJS_UNASSIGNED_FROM_DOMAINS;
            USMMessage notificationMsg = new USMMessage(msgType, USMMessage.USMMESSAGE_NOTIFICATION);
            BSCommonHelper.pushDomainListIntoMessage(notificationMsg, lstDomains);
            BSCommonHelper.pushSecurableObjectsListIntoMessage(notificationMsg, vecSuccessfulNEs);
            USMNotifier.getInstance().sendNotification(notificationMsg);

            for (DCDomainData dom : lstDomains) {
                new SecurityDomainFacade().sendAttributeValueChanged(dom);
            }

            // notify ACL modified
            BSServerHelper.notifyACLModified(vecSuccessfulNEs);
        }

        status = (lstFailedSecurableObjs.size() > 0) ? BSReturnType.FAILURE_T : BSReturnType.SUCCESS_T;

        return status;
    }

    /**
     * This function is invoked when we are removing a CF from USM. This function is responsible to remove the persistent
     * object of the CF from LDAP. It will then update the cache to remove the CF that has been removed.
     *
     * @param cf The CF that has to be removed from USM
     * @return BSReturnType Indicates the result of removal of the CF from USM.
     */
    BSReturnType removeCFFromUSM(BSTransBicNetCFInfo cf) {
        BSReturnType status = BSReturnType.FAILURE_T;
        // We have to do the following in the order
        // 1. Remove the NE information from LDAP
        // 2. Remove the NE information from the Cache.
        // 3. Remove the Server info from LDAP.
        // 4. Remove the Server info from the Cache
        String strCFID = cf.getCFid();
        Map<String, BSSecurableObject> mapSecurableObjs = getSecurableObjectsMap(strCFID);
        boolean bErrorOccured = false;

        if (null != mapSecurableObjs) {
            List<BSSecurableObject> lstSecurableObjects = new ArrayList<>(mapSecurableObjs.values());

            for (BSSecurableObject ne : lstSecurableObjects) {
                boolean bLDAPStatus = bsWrapper.deleteSecurableObject(ne);
                if (!bLDAPStatus) {
                    // We can break here, but its better to continue with the
                    // delete of the other objects.
                    bErrorOccured = true;
                    status = BSReturnType.LDAP_ERROR_T;
                    LOGGER.error("Error deleing NE : " + ne);
                } else {
                    mapSecurableObjs.remove(ne.getUniqueName());
                }
            }
        }

        if (!bErrorOccured) {
            status = bsWrapper.removeFunction(cf) ? BSReturnType.SUCCESS_T : BSReturnType.LDAP_ERROR_T;
        }
        return status;
    }

    /**
     * Function to return the BitSet (ACL) for the Passed Object
     *
     * @param id The Identifier for the Securable Object
     * @return BitSet The ACL for the Object passed.
     */
    BitSet getACLForSecurableObjWithID(String id) {
        BSSecurableObject securableObject = bsWrapper.getSecurableObjectWithACL(id);

        if(securableObject == null){
            return null;
        }

        return securableObject.getBitSetACL();
    }

    /**
     * Associates the securable object with container objects that exist in the cache. The containers that don't exist in cache will be created.
     */
    private void addSecurableObjectContainers(BSTransBicNetCFInfo cf, BSSecurableBase object) {
        List<BSSecurableObjectContainer> objectContainers = object.getObjectContainers();
        // create a new list to hold the container objects that are already in cache
//        object.setObjectContainers(new ArrayList<>());
        addSecurableObjectBaseToContainers(cf, object, objectContainers);
    }

    /**
     * Adds a securable object to the list of containers passed. If these containers don't exist in the cache, they will be created both in cache and LDAP.
     */
    private void addSecurableObjectBaseToContainers(BSTransBicNetCFInfo cf, BSSecurableBase securableObject, Collection<BSSecurableObjectContainer> objectContainers) {
        if (objectContainers == null) {
            return;
        }

        Map<String, BSSecurableObjectContainer> containerMap = getSecurableObjectContainersMap(cf.getCFid());
        for (BSSecurableObjectContainer container : objectContainers) {
            // search for the object container in the cache
            boolean result;
            if (containerMap.get(container.getUniqueName()) == null) {
                result = bsWrapper.saveSecurableObjectContainer(container);
            } else {
                result = bsWrapper.modifySecurableObjectContainer(container);
            }

            if (result) {
                addSecurableObjectContainers(cf, container);
            }
        }
    }

    /**
     * Removes a securable object from the list of containers passed. If any container is empty after removing the object, the container will be removed from cache and LDAP.
     */
    private void removeSecurableObjectBaseFromContainers(BSTransBicNetCFInfo cf, BSSecurableBase securableObject, Collection<BSSecurableObjectContainer> objectContainers) {
        if (objectContainers == null) {
            return;
        }

        for (BSSecurableObjectContainer container : objectContainers) {
            BSSecurableObjectContainer persistedContainer = getSecurableObjectContainer(container.getUniqueName());
            int childCount = bsWrapper.getContainerChildCount(container.getUniqueName());

            if (persistedContainer == null) {
                continue;
            }

            if (childCount == 0) {
                bsWrapper.deleteSecurableObjectContainer(persistedContainer);
                removeSecurableObjectBaseFromContainers(cf, persistedContainer, persistedContainer.getObjectContainers());
            }
        }

        securableObject.getObjectContainers().removeAll(objectContainers);
    }

    /**
     * Updates containers in securable object objectInCache. New containers will be created in cache and LDAP and empty containers will be removed.
     *
     * @param cf              BSTransBicNetCFInfo object
     * @param securableObject Securable object currently in cache that will be updated
     * @param containers      Securable object containers to set
     */
    private void updateContainersOfSecurableObject(BSTransBicNetCFInfo cf, BSSecurableObject securableObject, List<BSSecurableObjectContainer> containers) {
        Set<BSSecurableObjectContainer> containersToRemove = new HashSet<>(securableObject.getObjectContainers());
        containersToRemove.removeAll(containers);
        removeSecurableObjectBaseFromContainers(cf, securableObject, containersToRemove);

        Set<BSSecurableObjectContainer> containersToAdd = new HashSet<>(containers);
        containersToAdd.removeAll(securableObject.getObjectContainers());
        addSecurableObjectBaseToContainers(cf, securableObject, containersToAdd);
    }

}
