/* --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.basic.notification;

import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcherFactory;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.platform.Notification;
import com.ossnms.bicnet.messaging.BiCNetMessage;
import com.ossnms.bicnet.messaging.BiCNetMessageDispatcherFactory;
import com.ossnms.bicnet.securitymanagement.api.server.basic.notification.INotificationHandler;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import org.apache.log4j.Logger;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.*;

/**
 * This class is responsible for sending of Notifications using the
 * Topic that has been created.
 * 
 * Also, since CM:SM Server would require to be informed about the
 * 
 */
public class USMNotifier {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(USMNotifier.class);

	/**
	 * Data member to hold the USM string defined in BiCNetComponentType
	 */
	private static final String STR_USM = BiCNetComponentType.SECURITY_MANAGER.toString();

	/**
	 * Data member to hold the singleton instance of the class
	 */
	private static final USMNotifier instance = new USMNotifier();

	/**
	 * Data member to hold a list of the handlers who are interested 
	 * in the notifications that are being published.
	 */
	private Set<INotificationHandler> interestedNotifHandlers;

	/**
	 * Static method to return the singleton instance of the class
	 * 
	 * @return The singleton instance of the class
	 */
	public static USMNotifier getInstance() {
		LOGGER.debug("Called getInstance. Returning : " + instance);
		return instance;
	}

	/**
	 * Private constructor to avoid instantiation.
	 */
	private USMNotifier() {
		LOGGER.debug("Entering the Constructor");
		interestedNotifHandlers = Collections.synchronizedSet(new HashSet<>());
		LOGGER.debug("Exiting Constructor.");
	}

	/**
	 * Function that is invoked by the calling subsystems to send a notification
	 * using the topic.
	 * 
	 * During the sending of the notification, the JMS type is set as CF_USM.
	 * 
	 * @param msg The Message which has to be sent.
	 */
	public void sendNotification(USMMessage msg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering the sendNotification. Msg : " + msg);
		}

		sendNotificationToLocalListeners(msg);

		try {
			//
			// Get the dispatcher factory and the dispatcher for the current common function.
			//
			IBiCNetMessageDispatcherFactory dispatcherFactory = BiCNetMessageDispatcherFactory.getInstance();
			IBiCNetMessageDispatcher dispatcher = dispatcherFactory.getDispatcher(BiCNetComponentType.SECURITY_MANAGER);
			//
			// Construct and populate a message.
			//
			IBiCNetMessage message = new BiCNetMessage();
			message.setStringProperty(IBiCNetMessage.PROP_SENDER_ID, STR_USM);
			message.setStringProperty(IBiCNetMessage.PROP_CLIENT_SCOPE, IBiCNetMessage.PROP_CLIENT_SCOPE_VAL_PRIVATE);
			// 0 has to be set for a message not involving NE's
			message.setNeId(0);
			message.setObject(msg.copy());

			dispatcher.sendToClient(message, getMessageType(msg));
		} catch (Exception e) {
			LOGGER.error("Exception while using Dispatcher : ", e);
		}

		LOGGER.debug("Exiting sendNotification");
	}

	/**
	 * Get message type
	 * @param msg
     * @return
     */
	private String getMessageType(USMMessage msg) {
		return NOTIFICATION + "@" + msg.getMessageType().toString().toUpperCase() + "@" + MESSAGE_TYPE;
	}

	/**
	 *
	 * @param notif notification to send externally
     */
	public void sendExternalNotification(Notification notif) {
		LOGGER.debug("Entering the sendExternalNotification");

		try {
			//
			// Get the dispatcher factory and the dispatcher for the current common function.
			//
			IBiCNetMessageDispatcherFactory dispatcherFactory = BiCNetMessageDispatcherFactory.getInstance();
			IBiCNetMessageDispatcher dispatcher = dispatcherFactory.getDispatcher(BiCNetComponentType.SECURITY_MANAGER);
			//
			// Construct and populate a message.
			//
			IBiCNetMessage message = new BiCNetMessage();
			message.setStringProperty(IBiCNetMessage.PROP_SENDER_ID, STR_USM);
			message.setStringProperty(IBiCNetMessage.PROP_CLIENT_SCOPE, IBiCNetMessage.PROP_CLIENT_SCOPE_VAL_PUBLIC);
			// 0 has to be set for a message not involving NE's
			message.setNeId(0);
			message.setObject(notif);

			dispatcher.send(message, true, EMPTY_STRING);
		} catch (Exception e) {
			LOGGER.error("Exception while using Dispatcher : ", e);
		}

		LOGGER.debug("Exiting sendExternalNotification");
	}


	/**
	 * Helper function to send the notification message to all the recievers 
	 * in the server.
	 * @param msg Message that has to be broadcast to all the local listeners.
	 */
	private void sendNotificationToLocalListeners(USMMessage msg) {
		LOGGER.debug("Entering sendNotificationToLocalListeners.");

		interestedNotifHandlers.forEach(handler -> {
			LOGGER.debug("Calling handleNotification for the Object: " + handler);
			try {
				handler.handleNotification(msg.copy());
			} catch (Exception e1) {
				LOGGER.error("Exception in sendNotificationToLocalListeners.", e1);
			}
		});

		LOGGER.debug("Exiting sendNotificationToLocalListeners.");
	}

	/**
	 * Function to register a Notification Handler Object with the 
	 * Notifier
	 * 
	 * @param handler The Notification Handler object which should be registered.
	 * @return Indicates whether it was possible to register successfully.
	 */
	public boolean register(INotificationHandler handler) {
		LOGGER.debug("Register called. Object being registered is : " + handler);
		return interestedNotifHandlers.add(handler);
	}

	/**
	 * Function to un-register a Notification Handler Object from the  Notifier
	 * 
	 * @param handler The Notification Handler object which should be un-registered.
	 * @return Indicates whether it was possible to unregister successfully.
	 */
	public boolean unregister(INotificationHandler handler) {
		LOGGER.debug("unregister called. Object being un-registered is : "+ handler);
		return interestedNotifHandlers.remove(handler);
	}
}