/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Muyeen Munaver	CF000427 - Implementation of the XML import mechanism needed for the migration process
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.policy;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * This Transient class contains all data of a policy like 1. ID : Uniquely
 * Assigned Internally 2. Name : Entered by the NGPM Administrator in the
 * Create Policy Window 3. Description : Entered by the NGPM Administrator in
 * the Create Policy Window 4. Configured Menu items : Selected Menu Options of
 * various Configured Application Servers by the NGPM Administrator.
 */
public class PAPolicyData extends PAPolicyId {
    /**
	 * Data member for the Logging of the class.
	 */
	private static final Logger logger = Logger.getLogger(PAPolicyData.class);

	/**
	 * Data member to hold the Description (assigned by operator) to the Policy
	 */
	private String policyDescription;

	/**
	 * Data member to hold when the Policy Object was created
	 */
	private int creationTimeStamp;

	/**
	 * Data member to hold when the Policy Object was last Modified
	 */
	private int modificationTimeStamp;

	/**
	 * Data member to hold the list of permissions (assigned by the operator) to
	 * the policy
	 */
	private List<PAPermissionData> permissionDataList;

	/**
	 * Constructor
	 * 
	 * @param nPolicyID The Unique Identifier for the Policy
	 * @param csPolicyName The Name of the Policy
	 * @param csPolicyDescription The Description of the Policy
	 * @param creationTimeStamp The Time of Creation of the Policy
	 * @param modificationTimeStamp The Time of Modification of the Policy
	 */
	public PAPolicyData(
			int nPolicyID,
			String csPolicyName,
			String csPolicyDescription,
			int creationTimeStamp,
			int modificationTimeStamp
	) {
		logger.debug("in the constructor");
		this.setPolicyID(nPolicyID);
		this.setPolicyName(csPolicyName);
		this.policyDescription = csPolicyDescription;
		this.creationTimeStamp = creationTimeStamp;
		this.modificationTimeStamp = modificationTimeStamp;
		this.permissionDataList = new ArrayList<>();
		logger.debug("PAPolicyData() exit");
	}

	/**
	 * Constructor
	 *
	 * @param nPolicyID The Unique Identifier for the Policy
	 * @param csPolicyName The Name of the Policy
	 * @param csPolicyDescription The Description of the Policy
	 * @param permissionDataList The list of configured permissions
	 * @param creationTimeStamp The Time of Creation of the Policy
	 * @param modificationTimeStamp The Time of Modification of the Policy
	 */
	public PAPolicyData(
			int nPolicyID,
			String csPolicyName,
			String csPolicyDescription,
			List<PAPermissionData> permissionDataList,
			int creationTimeStamp,
			int modificationTimeStamp) {
		logger.debug("in the constructor");
		this.setPolicyID(nPolicyID);
		this.setPolicyName(csPolicyName);
		this.policyDescription = csPolicyDescription;
		this.creationTimeStamp = creationTimeStamp;
		this.modificationTimeStamp = modificationTimeStamp;
		this.permissionDataList = new ArrayList<>(permissionDataList);
		logger.debug("PAPolicyData() exit");
	}

	/**
	 * Default Constructor
	 */
	public PAPolicyData() {
		logger.debug("in the default constructor");
		permissionDataList = new ArrayList<>();
		this.setPolicyID(-1);
		creationTimeStamp = 0;
		modificationTimeStamp = 0;
		this.setPolicyName("");
		policyDescription = "";
	}

	/**
	 * Function to push this object into the message. Will be used for
	 * transfering this object between the server and the client.
	 * 
	 * @param msg
	 *            The Message into which we have to push this object.
	 */
	@Override
	public void pushMe(USMMessage msg) {
		logger.debug("pushTo() In the method");

		//Push name and id
		super.pushMe(msg);

		// PUSH DESCRIPTION
		msg.pushString(policyDescription);

		// PUSH CREATION TIME STAMP
		msg.pushInteger(creationTimeStamp);

		// PUSH MODIFICATION TIME STAMP
		msg.pushInteger(modificationTimeStamp);

		// PUSH CONFIGURED PERMISSION List.
		for (PAPermissionData permissionData : permissionDataList) {
			permissionData.pushMe(msg);
		}

		msg.pushInteger(permissionDataList.size());
		logger.debug("pushTo() exit from the method");
	}

	/**
	 * Function to pop this object from the message. Will be used while
	 * transferring this object between the server and the client.
	 * 
	 * @param msg
	 *            The Message from which we have to pop this object.
	 */
	@Override
	public void popMe(USMMessage msg) {
		logger.debug("popMe() IN THE METHOD");
		// POP CONFIGURED MENU List.
		int nCountConfiguredMenus = msg.popInteger();


		for (int idx = 0; idx < nCountConfiguredMenus; ++idx) {
			PAPermissionData configuredPermission = new PAPermissionData();
			configuredPermission.popMe(msg);
			permissionDataList.add(configuredPermission);
		}

		// POP Modification Time Stamp.
		modificationTimeStamp = msg.popInteger();

		// POP Creation Time Stamp.
		creationTimeStamp = msg.popInteger();

		// POP DESCRIPTION.
		policyDescription = msg.popString();

		// POP name and ID
		super.popMe(msg);
		logger.debug("popMe() EXIT FROM THE METHOD");
	}

	/**
	 * Helper function to retrieve the Creation Time Stamp
	 * 
	 * @return int The Time stamp when the Policy was created
	 */
	public int getCreationTimeStamp() {
		return creationTimeStamp;
	}
	/**
		 * Helper function to set the Creation Time Stamp
		 * 
		 */
	public void setCreationTimeStamp(int tStamp) {
		creationTimeStamp = tStamp;
	}

	/**
	 * Helper function to retrieve the Modification Time Stamp
	 * 
	 * @return int The Time stamp when the Policy was modified.
	 */
	public int getModificationTimeStamp() {
		return modificationTimeStamp;
	}
	/**
	 * Helper function to set the Modification Time Stamp
	 * 
	 */
	public void setModificationTimeStamp(int tStamp) {
		modificationTimeStamp = tStamp;
	}

	/**
	 * Helper function to return the Description of the Policy
	 * 
	 * @return java.lang.String The String which represents the description of
	 *         the policy
	 */
	public String getPolicyDescription() {
		return policyDescription;
	}

	/**
	 * Helper function to set the new Description for the Policy
	 * 
	 * @param policyDescription
	 *            The new description of the Policy
	 */
	public void setPolicyDescription(String policyDescription) {
		this.policyDescription = policyDescription;
	}

	/**
	 * Retrieves the list of configured Permissions
	 */
	public List<PAPermissionData> getPermissionDataList() {
		return permissionDataList;
	}

	/**
	 * Sets the list of configured permissions
	 * @param permissionDataList the list of permissions
	 */
	public void setPermissionDataList(List<PAPermissionData> permissionDataList) {
		this.permissionDataList = new ArrayList<>(permissionDataList);
	}

	/**
	 * Function top return an equivalent string of this Object.
	 * 
	 * @return java.lang.String The String equivalent of this Object.
	 */
	@Override
    public String toString() {
		return this.getPolicyName();
	}

	/**
	 *
	 * @param o
	 * @return
	 */
	@Override
	public boolean equals(Object o) {
		if (this == o) {return true;}
		if (o == null || getClass() != o.getClass()) {return false;}
		if (!super.equals(o)) {return false;}

		PAPolicyData that = (PAPolicyData) o;

		if (creationTimeStamp != that.creationTimeStamp) { return false;}
		if (modificationTimeStamp != that.modificationTimeStamp) {return false;}
		return !(policyDescription != null ? !policyDescription.equals(that.policyDescription) : that.policyDescription != null);

	}

	/**
	 *
	 * @return
	 */
	@Override
	public int hashCode() {
		int result = super.hashCode();
		result = 31 * result + (policyDescription != null ? policyDescription.hashCode() : 0);
		result = 31 * result + creationTimeStamp;
		result = 31 * result + modificationTimeStamp;
		return result;
	}
}
