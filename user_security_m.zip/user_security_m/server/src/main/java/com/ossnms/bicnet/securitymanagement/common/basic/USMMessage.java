/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMMessage
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 22-Mar-2005	Muyeen Munaver	CF0001791 - Problems with Login
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.basic;

import com.ossnms.bicnet.bcb.model.platform.Notification;
import org.apache.log4j.Logger;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * This class is the modeling of the generic structure for transfer of messages
 * between Client and Server processes. It provides interfaces to
 * store and retrieve variety of data types. The mechanism of operation of this
 * class is similar to a stack, i.e, when reading from an USMMessage, the order
 * must be reverse that of the writing.
 */
public final class USMMessage extends Notification implements Serializable {

    private static final long serialVersionUID = 8512437459321230354L;

    /**
	 * This corresponds to request messages.
	 */
	public static final int USMMESSAGE_REQUEST = 1;

	/**
	 * This corresponds to response messages.
	 */
	public static final int USMMESSAGE_RESPONSE = 2;

	/**
	 * This corresponds to notification messages.
	 */
	public static final int USMMESSAGE_NOTIFICATION = 3;

	/**
	 * This is the minimum value for message category.
	 */
	private static final int MESSAGE_CATEGORY_MINIMUM = 1;

	/**
	 * This is the maximum value for message category.
	 */
	private static final int MESSAGE_CATEGORY_MAXIMUM = 3;

	/**
	 * Data member to make sure numerical literals are not in the code.
	 */
	private static final int FOUR_ZERO_FOUR_FS = 0x0000ffff;

	/**
	 * Data member to make sure numerical literals are not in the code.
	 */
	private static final int TWO_ZERO_TWO_FS = 0x00ff;

	private static final long EIGHT_ZERO_EIGHT_FS = 0x00000000ffffffffL;

	/**
	 * Data member to hold the logger for tracing
	 */
    private static final transient Logger LOGGER = Logger.getLogger(USMMessage.class);

	/**
	 * This is the category of the USMMessage. The possible values are enumerated
	 * within this class as static values.
	 */
	private int messageCategory;

	/**
	 * This container attribute stores the contents of the message. The contents
	 * are stored in terms of the type Byte.
	 */
	private List<Byte> vecPayload;

	/**
	 * This is the identifier of the role or function of the message.
	 */
	private USMBaseMsgType baseMsgType;

	/**
	 * Data member to hold the Error Message to be passed if the response is null
	 */
	public static final USMBaseMsgType ERROR_MSG_TYPE =
		new USMBaseMsgType("USM_Error");

	/**
	 * Constructs a new message.
	 * 
	 * @param msgType
	 *            String to identify the message type.
	 * @param msgCategory
	 *            The category, whether it is a request or a response.
	 */
	public USMMessage(USMBaseMsgType msgType, int msgCategory) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering constructor : Message Type " + msgType + " Category : " + msgCategory);
        }

        if(!isValidMessageCategory(msgCategory)) {
            LOGGER.error("Constructing a message with wrong category : Message Type " + msgType + " Category : " + msgCategory);
            throw new InvalidParameterException();
        }

		vecPayload = new ArrayList<>();
		baseMsgType = msgType;
		messageCategory = msgCategory;

		LOGGER.debug("Exiting constructor");
	}

	/**
	 * This method returns the category of the message.
	 * 
	 * @return int Returns the category of the message, whether it was a request
	 *         or a response.
	 */
	public int getMessageCategory() {
		return messageCategory;
	}

	/**
	 * This method will empty the payload contents of the USMMessage.
	 */
	public void clear() {
		LOGGER.debug("Entering clear");
		vecPayload.clear();
		LOGGER.debug("Exiting clear");
	}

	/**
	 * This method returns the payload as a byte array.
	 * 
	 * @return byte[] Returns the payload of the message as a byte array.
	 */
	private byte[] getPayload() {
		LOGGER.debug("Entering getPayload");

		Object[] objectPayloadArray = vecPayload.toArray();
		int numberOfBytes = objectPayloadArray.length;
		byte[] returnedArray = new byte[numberOfBytes];
		for (int i = 0; i < numberOfBytes; ++i) {
			returnedArray[i] = (Byte) (objectPayloadArray[i]);
		}

		LOGGER.debug("Exiting getPayload");
		return returnedArray;
	}

	/**
	 * This method validates the constructed message's category.
	 * 
	 * @param msgCategory
	 *            Checks if the category specified by the user is a valid
	 *            category or not.
	 * @return boolean returns true if the category is valid.
	 */
	private boolean isValidMessageCategory(int msgCategory) {
        boolean returnValue = false;
        if((msgCategory >= MESSAGE_CATEGORY_MINIMUM) && (msgCategory <= MESSAGE_CATEGORY_MAXIMUM)) {
            returnValue = true;
        }
		return returnValue;
	}

	/**
	 * This method returns the number of bytes in the payload of the message.
	 * 
	 * @return int Returns the size of the message in number of bytes.
	 */
	public int size() {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering size(). Returning : " + vecPayload.size());
		}
		return vecPayload.size();
	}

	/**
	 * This method is used to set the message category.
	 * 
	 * @param msgCategory
	 *            The category of the message.
	 */
	public void setMessageCategory(int msgCategory) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering setMessageCategory. Value being sent is : " + msgCategory);
        }

		if (!isValidMessageCategory(msgCategory)) {
			LOGGER.error("Setting wrong category. Category : " + msgCategory);
			throw new InvalidParameterException();
		}

		messageCategory = msgCategory;
	}

	/**
	 * This method pushes a Byte to the message.
	 * 
	 * @param data
	 *            Byte data that needs to be pushed onto the message.
	 */
	public void pushByte(Byte data) {
		pushRawByte(data);
	}

	/**
	 * This method pops a Byte from a message.
	 * 
	 * @return java.lang.Byte Returns a Byte that got pushed into the message
	 *         and will now be popped out.
	 */
	public Byte popByte() {
		return popRawByte();
	}

    /**
     * This method pushes a String onto the message.
     * 
     * @param data
     *            String which needs to be pushed onto the message without sensitive data.
     */
    public void pushString(String data) {
        if (LOGGER.isDebugEnabled() ) {
            if(data != null && data.length() > 0){
                LOGGER.debug("Entering pushString. Trying to push : " + data);
            }else{
                LOGGER.debug("Entering pushString. Trying to push : -");
            }
        }
        
        pushData(data);

        LOGGER.debug("Exiting pushString");
    }

    /**
     * This method pushes a String onto the message, but is used for sensitive data, for instance, 
     * passwords and other related, in order to hide such information within the log files, when the log level
     * is defined as DEBUG mode.
     * 
     * The difference between this method and the existing one is based only on the way that log information is 
     * recorded within the log files,thus the behavior stills the same, therefore the statements related to 
     * behavior is available for both methods 'pushString' through the private method 'pushData'.  
     * 
     * @param data
     *            String which needs to be pushed onto the message with sensitive data.
     * @param isSensitiveData
     *            true - The data is classified as sensitive (e.g. passwords).
     *            false - The data is not classified as sensitive (e.g. passwords).           
     */
    public void pushString(String data, boolean isSensitiveData) {
        if (!isSensitiveData) {
            pushString(data);
        }else {
            LOGGER.debug("Entering pushString. Trying to push : -");
            pushData(data);
        }

        LOGGER.debug("Exiting pushString");
    }
    
    /**
     * This is common method used by both "pushString" methods, which pushes a String onto the message.
     * 
     * @param data
     *            String which needs to be pushed onto the message.
     */
    private void pushData(String data){
        if (null != data) {
            byte[] arr = data.getBytes();

            int len = arr.length;
            Integer lenVal = len;
            Byte by = null;
            for (int i = len - 1; i >= 0; --i) {
                by = arr[i];
                pushRawByte(by);
            }
            pushInteger(lenVal);
        } else {
            pushInteger(0);
        }
    }

	/**
	 * This method pops a String from a message.
	 * 
	 * @return String Returns a String that was pushed onto the message and will
	 *         now be popped out.
	 */
	public String popString() {
		LOGGER.debug("Entering popString");

		Integer len = popInteger();
		String str = null;
		if (null != len) {
			int nLength = len;
			byte[] arr = new byte[nLength];
			int i = 0;
			Byte by = null;
			for (; i < nLength; ++i) {
				by = popRawByte();
				if (null == by) {
					break;
				}
				arr[i] = by;
			}
			if (i == nLength) {
				str = new String(arr);
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting popString(). Returning : " + str);
		}
		return str;
	}

	/**
	 * This method pushes an Integer onto the message.
	 * 
	 * @param data
	 *            Integer that needs to be pushed into the message.
	 */
	public void pushInteger(Integer data) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering pushInteger(). Trying to push : " + data);
        }

		int temp = data;
		int i1 = temp & FOUR_ZERO_FOUR_FS;
		int i2 = temp >> 16;
		Integer lsbInt = i1;
		Short lsbShort = lsbInt.shortValue();
		pushShort(lsbShort);
		Integer msbInt = i2;
		Short msbShort = msbInt.shortValue();
		pushShort(msbShort);

		LOGGER.debug("Exiting pushInteger");
	}

	/**
	 * This function pops out an Integer from the message.
	 * 
	 * @return Integer Returns an Integer that was pushed onto a message and
	 *         will now be popped out.
	 */
	public Integer popInteger() {
		LOGGER.debug("Entering popInteger");

		Integer val = null;
		try {
			Short msbShort = popShort();
			Short lsbShort = popShort();
			int lsbInt = (lsbShort.intValue()) & FOUR_ZERO_FOUR_FS;
			int msbInt = (msbShort.intValue()) << 16;
			msbInt |= lsbInt;
			val = msbInt;
		} catch (NullPointerException ex) {
		    LOGGER.debug(ex);
			val = null;
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting popInteger(). Returning : " + val);
		}
		return val;
	}

	/**
	 * Pushes a byte array finally into raw format. 
	 * 
	 * @param rawData
	 *            Data which has to be pushed onto the payload.
	 */
	private void pushRawBytes(byte[] rawData) {
		for (byte aRawData : rawData) {
			pushRawByte(aRawData);
		}
		pushInteger(rawData.length);
	}

	/**
	 * Pushes an object in raw format. 
	 * 
	 * @param object
	 *            Object which has to be pushed onto the payload.
	 */
	public void pushObject(Object object) {
		ByteArrayOutputStream objByteStream = new ByteArrayOutputStream(200);
		ObjectOutputStream objObjectStream;
		try {
			objObjectStream = new ObjectOutputStream(objByteStream);
			objObjectStream.writeObject(object);
		} catch (IOException e1) {
		    LOGGER.debug(e1);
		}
		pushRawBytes(objByteStream.toByteArray());
	}

	/**
	 * Pushes all data finally into raw format. All push finally end up pushing
	 * the raw data.
	 * 
	 * @param rawData
	 *            Data which has to be pushed onto the payload.
	 */
	private void pushRawByte(Byte rawData) {
		vecPayload.add(rawData);
	}

	/**
	 * This method pops out a byte from the payload.
	 * 
	 * @return java.lang.Byte The byte which was popped from the message.
	 */
	private Byte popRawByte() {
		Byte by = null;
		try {
			Object data = vecPayload.get(vecPayload.size() - 1);
			by = (Byte) data;
			vecPayload.remove((vecPayload.size() - 1));
		} catch (NoSuchElementException ex) {
			by = null;
			LOGGER.debug(ex);
		}
		return by;
	}

	/**
	 * Pops a byte array from raw format.
	 */
	private byte[] popRawBytes() {
		int nByteCount = popInteger();

		byte[] arrBytes = new byte[nByteCount];
		for (int i = nByteCount - 1; i >= 0; --i) {
			arrBytes[i] = popRawByte();
		}

		return arrBytes;
	}

	/**
	 * Pops an object from raw format. 
	 * 
	 * @return java.lang.Object The object which was popped from the message.
	 */
	public Object popObject() {
		Object retVal = null;
		byte[] arrBytes = popRawBytes();

		ByteArrayInputStream objByteStream = new ByteArrayInputStream(arrBytes);
		ObjectInputStream objObjectStream;

		try {
			objObjectStream = new ObjectInputStream(objByteStream);
			retVal = objObjectStream.readObject();
		} catch (ClassNotFoundException | IOException cnfe) {
		    LOGGER.debug(cnfe);
		}
		return retVal;
	}

	/**
	 * This method returns the type of the message received.
	 * 
	 * @return USMBaseMsgType Returns the user defined type of the message.
	 */
	public USMBaseMsgType getMessageType() {
		return baseMsgType;
	}

	/**
	 * This method is used to push a Boolean onto the message.
	 * 
	 * @param data
	 *            Boolean data which needs to be pushed onto the message.
	 */
	public void pushBoolean(Boolean data) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering pushBoolean(). Trying to Push : " + data);
		}
		Byte by = null;
		if (data) {
			by = ((byte) 1);
		} else {
			by = ((byte) 0);
		}
		pushRawByte(by);

		LOGGER.debug("Exiting pushBoolean");
	}

	/**
	 * This method is used to pop a Boolean from the message.
	 * 
	 * @return Boolean Returns the popped out Boolean data.
	 */
	public Boolean popBoolean() {
		LOGGER.debug("Entering popBoolean");

		Byte by = popRawByte();
		Boolean boolData = null;
		if (null != by) {
			if (by == 0) {
				boolData = false;
			} else {
				boolData = true;
			}
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting popBoolean(). Returning : " + boolData);
		}
		return boolData;
	}

	/**
	 * This method is used to get another instance with the same contents as
	 * this object.
	 * 
	 * @return USMMessage Returns a copy of the message.
	 */
	public USMMessage copy() {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering copy for the message : " + this);
		}

		USMMessage newMessage = new USMMessage(baseMsgType, messageCategory);
		byte[] messagePayloadBytes = getPayload();
		for (int i = 0; i < messagePayloadBytes.length; ++i) {
			newMessage.pushByte(messagePayloadBytes[i]);
		}

		LOGGER.debug("Exiting copy");
		return newMessage;
	}

	/**
	 * This method pushes a Short data onto a message.
	 * 
	 * @param data
	 *            Short data which needs to be pushed onto a message.
	 */
	public void pushShort(Short data) {
        short temp = data;
        int i1 = temp & TWO_ZERO_TWO_FS;
        int i2 = temp >> 8;
        Integer lsbInt = i1;
        Byte lsb = lsbInt.byteValue();
        pushRawByte(lsb);
        Integer msbInt = i2;
        Byte msb = msbInt.byteValue();
        pushRawByte(msb);
	}

	/**
	 * This method is used to pop out a Short from the message.
	 * 
	 * @return Short Returns s Short popped out data from the message.
	 */
	public Short popShort() {
		Short val = null;
		try {
			byte msb = popRawByte();
			byte lsb = popRawByte();
			int lsbInt = lsb & 0xff;
			int temp = msb;
			int msbInt = temp << 8;
			msbInt |= lsbInt;
			Integer valInt = msbInt;
			val = valInt.shortValue();
		} catch (NullPointerException npe) {
			LOGGER.debug(npe);
			val = null;
		}
		return val;
	}

	/**
	 * This method pushes a Long data onto a message.
	 * 
	 * @param data The data which has to be pushed onto a message.
	 */
	public void pushLong(Long data) {

		long temp = data;
		int i1 = (int) temp;
		// int i1 = data.intValue();
		int i2 = (int) (temp >> 32);
		Integer lsbInt = i1;
		pushInteger(lsbInt);
		Integer msbInt = i2;
		pushInteger(msbInt);
	}

	/**
	 * This pops out a Long data from a message.
	 * 
	 * @return Long Returns the popped out Long value of the message.
	 */
	public Long popLong() {

		Long val = null;
		try {
			Integer msbInt = popInteger();
			Integer lsbInt = popInteger();
			long lsb = lsbInt.longValue();
			long msb = (msbInt.longValue()) << 16;
			msb = msb << 16;
			msb |= (lsb & EIGHT_ZERO_EIGHT_FS);
			val = msb;
		} catch (NullPointerException ex) {
			LOGGER.debug(ex);
			val = null;
		}

		return val;
	}

	/**
	 * This method pushes a Date onto a message.
	 *
	 * @param date the date which has to be pushed
	 */
	public void pushDate(Date date){
		long temp = date.getTime();
		pushLong(temp);
	}

	public Date popDate() {
		Date temp = null;

		long time = popLong();
		temp = new Date(time);

		return temp;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
    public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(" USMBaseMsgType : ");
		sb.append(baseMsgType);
		sb.append(" Message Category is : ");
		sb.append(messageCategory);
		sb.append(" Size : ");
		sb.append(size());
		return sb.toString();
	}
}