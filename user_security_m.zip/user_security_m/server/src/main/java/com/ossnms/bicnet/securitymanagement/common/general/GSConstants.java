/*
 * --------------------------------------------------------
 *
 * Project: TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   GSConstants
 * Author:      Jogender
 * Substitute   Babu B
 * Created on   13-10-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.ADVISORY_CONFIGURE
 *        : TNMS.DX2.SM.PASSWORD.COMPLEXITY
 * 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 21-Jan-2005  Muyeen Munaver  CF000995 - Password Expiration Interval
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.general;

/**
 * This class stores all the primitives used by GS internally across the client
 * and the server for its default values
 */
public final class GSConstants {
    /**
     * Constant for the inactivity time out period (in minutes)
     */
    public static final int S_INACTIVITY_TIMEOUT = 60;

    /**
     * Constant for the inactivity time out period (in minutes)
     */
    public static final int S_INACTIVITY_TIMEOUT_WARNING = 0;

    /**
     * Constant for the inactivity time out period (in minutes)
     */
    public static final int S_INACTIVITY_TIMEOUT_MIN = 0;

    /**
     * Constant for the Inactivity time out period (in minutes)
     */
    public static final int S_INACTIVITY_TIMEOUT_MAX = 999;

    /**
     * Constant for the initial password change interval (in days)
     */
    public static final int S_INIT_PASSWORD_CHANGE_INTERVAL = 30;

    /**
     * Constant for the initial password change interval (in days)
     */
    public static final int S_INIT_PASSWORD_CHANGE_INTERVAL_MIN = 3;

    /**
     * Constant for the initial password change interval (in days)
     */
    public static final int S_INIT_PASSWORD_CHANGE_INTERVAL_MAX = 90;

    /**
     * Constant for the unsuccessful login attempts allowed (in minutes)
     */
    public static final int S_MAX_LOGIN_ATTEMPTS = 5;

    /**
     * Constant for the unsuccessful login attempts allowed (in minutes)
     */
    public static final int S_MAX_LOGIN_ATTEMPTS_MIN = 3;

    /**
     * Constant for the unsuccessful login attempts allowed (in minutes)
     */
    public static final int S_MAX_LOGIN_ATTEMPTS_MAX = 9;

    /**
     * Constant for the user account deactivation on inactivity for the certain
     * period (in days)
     */
    public static final int S_USER_ACCOUNT_DEACTIVATE = 15;

    /**
     * Constant for the user account deactivation on inactivity for the certain
     * period (in days)
     */
    public static final int S_USER_ACCOUNT_DEACTIVATE_MIN = 3;

    /**
     * Constant for the user account deactivation on inactivity for the certain
     * period (in days)
     */
    public static final int S_USER_ACCOUNT_DEACTIVATE_MAX = 90;

    /**
     * Constant for the Administrator account lock out period (in minutes)
     */
    public static final int S_ADMIN_LOCKOUT_PERIOD = 15;

    /**
     * Constant for the Administrator account lock out period (in minutes)
     */
    public static final int S_ADMIN_LOCKOUT_PERIOD_MIN = 5;

    /**
     * Constant for the Administrator account lock out period (in minutes)
     */
    public static final int S_ADMIN_LOCKOUT_PERIOD_MAX = 60;

    /**
     * Constant for the default Advisory Message Display
     */
    public static final boolean S_DEFAULT_IS_ADVISORY_MESSAGE_DISPLAY = false;

    /**
     * Constant for the Password history
     */
    public static final int S_PASSWORD_HISTORY = 12;

    /**
     * constant to hold the default advisory message
     */
    public static final String DEFAULT_ADVISORY_MESSAGE = "";

    /**
     * Default password for user (used in importing users)
     */
    public static final String S_DEFAULT_PASSWORD = "bicnet12!@";

    /**
     * Default LDAP tcp port for active directory
     */
    public static final int S_AD_LDAP_PORT = 389;

    /**
     * Default LDAP tcp port for active directory minimum
     */
    public static final int S_AD_LDAP_PORT_MIN = 1024;
    /**
     * Default LDAP tcp port for active directory maximum
     */
    public static final int S_AD_LDAP_PORT_MAX = 65535;
    
    
    /**
     * Constant for the inactivity time out period (in minutes)
     */
    public static final int S_SIMULTANEOUS_USER_SESSIONS  = 1;

    /**
     * Constant for the inactivity time out period (in minutes)
     */
    public static final int S_SIMULTANEOUS_USER_SESSIONS_MIN = 1;

    /**
     * Constant for the Inactivity time out period (in minutes)
     */
    public static final int S_SIMULTANEOUS_USER_SESSIONS_MAX = 99;

    /**
     * Constant for the time during which automatic re-login is tried (in minutes)
     */
    public static final int S_RELOGIN_TIMEOUT = 20;

    /**
     * Constant for the minimum timeout value allowed for re-login (in minutes)
     */
    public static final int S_RELOGIN_TIMEOUT_MIN = 3;

    /**
     * Constant for the maximum timeout value allowed for re-login (in minutes)
     */
    public static final int S_RELOGIN_TIMEOUT_MAX = 30;

    /**
     * Constant for the delay between re-login attempts (in seconds)
     */
    public static final int S_RELOGIN_DELAY_BETWEEN_TRIES = 30;

    /**
     * Constant for the minimum delay between re-login attempts
     */
    public static final int S_RELOGIN_DELAY_BETWEEN_TRIES_MIN = 1;

    /**
     * Constant for the maximum delay between re-login attempts
     */
    public static final int S_RELOGIN_DELAY_BETWEEN_TRIES_MAX = 60;
    
    
    /**
     * Constant for expire password notice (in days)
     */
    public static final int S_EXPIRE_PASSWORD_WARNING = 0;

    /**
     * Constant for the minimum expire password notice (in days)
     */
    public static final int S_EXPIRE_PASSWORD_WARNING_MIN = 0;

    /**
     * Constant for the maximum expire password notice (in days)
     */
    public static final int S_EXPIRE_PASSWORD_WARNING_MAX = 30;

    /**
     *
     */
    public static final int S_RADIUS_TIMEOUT_DEFAULT = 10;

    /**
     *
     */
    public static final int S_RADIUS_RETRY_DEFAULT = 3;

    /**
     *
     */
    public static final int S_RADIUS_PORT_DEFAULT = 1812;



    /**
     * Default constructors
     */
    private GSConstants() {
    }
}