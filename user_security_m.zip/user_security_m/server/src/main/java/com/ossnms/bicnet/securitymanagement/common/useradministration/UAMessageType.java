package com.ossnms.bicnet.securitymanagement.common.useradministration;

import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;

/**
 * This class holds String representation for notification of User/Group related operation.
 * Each message type uniquely identifies one single operation that can be performed in UA.
 */
public class UAMessageType {
	/**
	 * String representation for request for create user
	 */
	public static final USMBaseMsgType S_UA_REQ_GET_ALL_USERS =
		new USMBaseMsgType("UA_REQ_GET_ALL_USERS");
    /**
     * String representation for request to get one user
     */
    public static final USMBaseMsgType S_UA_REQ_GET_USER_BY_NAME =
            new USMBaseMsgType("UA_REQ_GET_USER_BY_NAME");
    /**
     * String representation for response to get one user
     */
    public static final USMBaseMsgType S_UA_RES_GET_USER_BY_NAME =
            new USMBaseMsgType("UA_RES_GET_USER_BY_NAME");
    /**
     * String representation for request for create user
     */
    public static final USMBaseMsgType S_UA_REQ_GET_ALL_PASSWORD_VALIDATION_RULES =
            new USMBaseMsgType("UA_REQ_GET_ALL_PASSWORD_VALIDATION_RULES");
    /**
     * String representation for response for check usergroup contains user
     */
    public static final USMBaseMsgType S_UA_RES_GET_ALL_PASSWORD_VALIDATION_RULES =
            new USMBaseMsgType("S_UA_RES_GET_ALL_PASSWORD_VALIDATION_RULES");
	/**
     * String representation for response for create user
	 */
	public static final USMBaseMsgType S_UA_RES_GET_ALL_USERS =
		new USMBaseMsgType("S_UA_RES_GET_ALL_USERS");
	/**
		 * String representation for request for create user
		 */
	public static final USMBaseMsgType S_UG_RES_GET_ALL_USERGROUPS =
		new USMBaseMsgType("UG_RES_GET_ALL_USERSGROUPS");
	/**
			 * String representation for request for create user
			 */
	public static final USMBaseMsgType S_UG_REQ_GET_ALL_USERGROUPS =
		new USMBaseMsgType("UG_REQ_GET_ALL_USERSGROUPS");

	/**
	 * String representation for request for force logoff of user
	 */
	public static final USMBaseMsgType S_UA_REQ_FORCE_LOGOFF_USER =
		new USMBaseMsgType("S_UA_REQ_FORCE_LOGOFF_USER");
	/**
	 * String representation for request for activate user
	 */
	public static final USMBaseMsgType S_UA_REQ_UNLOCK_USER =
		new USMBaseMsgType("S_UA_REQ_UNLOCK_USER");
	/**
	 * String representation for request for activate user
	 */
	public static final USMBaseMsgType S_UA_REQ_ACTIVATE_USER =
		new USMBaseMsgType("S_UA_REQ_ACTIVATE_USER");
	/**
	 * String representation for request for deactivate user
	 */
	public static final USMBaseMsgType S_UA_REQ_DEACTIVATE_USER =
		new USMBaseMsgType("S_UA_REQ_DEACTIVATE_USER");
	/**
	 * String representation for notification for create user
	 */
	public static final USMBaseMsgType S_UA_NOT_CREATE_USER =
		new USMBaseMsgType("UA_NOT_CREATE_USER");
	/**
	 * String representation for notification for modify user
	 */
	public static final USMBaseMsgType S_UA_NOT_MODIFY_USER =
		new USMBaseMsgType("UA_NOT_MODIFY_USER");
	/**
	 * String representation for notification for create user
	 */
	public static final USMBaseMsgType S_UA_NOT_CREATE_USERGROUP =
		new USMBaseMsgType("S_UA_NOT_CREATE_USERGROUP");
	/**
	 * String representation for notification for create user
	 */
	public static final USMBaseMsgType S_UA_NOT_REMOVE_USERGROUP =
		new USMBaseMsgType("S_UA_NOT_REMOVE_USERGROUP");
	/**
	* String representation for notification for remove user
	*/
	public static final USMBaseMsgType S_UA_NOT_REMOVE_USER =
		new USMBaseMsgType("UA_NOT_REMOVE_USER");
	/**
	 * String representation for notification for activate user
	 */
	public static final USMBaseMsgType S_UA_NOT_ACTIVATE_USER =
		new USMBaseMsgType("UA_NOT_ACTIVATE_USER");
	/**
	 * String representation for notification for deactivate user
	 */
	public static final USMBaseMsgType S_UA_NOT_DEACTIVATE_USER =
		new USMBaseMsgType("UA_NOT_DEACTIVATE_USER");
	/**
	 * String representation for notification for unlock user
	 */
	public static final USMBaseMsgType S_UA_NOT_UNLOCK_USER =
		new USMBaseMsgType("UA_NOT_UNLOCK_USER");
	/**
	 * String representation for notification for forced logoff user
	 */
	public static final USMBaseMsgType S_UA_NOT_FORCED_LOGOFF_USER =
		new USMBaseMsgType("UA_NOT_FORCED_LOGOFF_USER");
	/**
	 * String representation for request for create user
	 */
	public static final USMBaseMsgType S_UA_REQ_CREATE_USER =
		new USMBaseMsgType("UA_REQ_CREATE_USER");
	/**
	 * String representation for response for create user
	 */
	public static final USMBaseMsgType S_UA_RES_CREATE_USER =
		new USMBaseMsgType("UA_RES_CREATE_USER");

	/**
	 * String representation for response for create user
	 */
	public static final USMBaseMsgType S_UA_RES_GET_ASSIGNED_AND_UNASSIGNED_USERGROUP =
		new USMBaseMsgType("UA_RES_GETASSIGNED_AND_UNASSIGNED_USERGROUP");
	/**
	 * String representation for request for delete user
	 */
	public static final USMBaseMsgType S_UA_REQ_DELETE_USER =
		new USMBaseMsgType("UA_REQ_DELETE_USER");
	/**
	 * String representation for response for delete user
	 */
	public static final USMBaseMsgType S_UA_RES_DELETE_USER =
		new USMBaseMsgType("UA_RES_DELETE_USER");
	/**
	 * String representation for request for check usergroup contains user
	 */
	public static final USMBaseMsgType S_UA_REQ_CHRCK_USERGROUP_CONTAINS_USER =
		new USMBaseMsgType("S_UA_REQ_CHRCK_USERGROUP_CONTAINS_USER");
	/**
	 * String representation for response for check usergroup contains user
	 */
	public static final USMBaseMsgType S_UA_RES_CHECK_USERGROUP_CONTAINS_USER =
		new USMBaseMsgType("S_UA_RES_CHECK_USERGROUP_CONTAINS_USER");
	/**
	 * String representation for notification for create user group
	 */
	public static final USMBaseMsgType S_UA_MODIFY_CREATE_USER =
		new USMBaseMsgType("UA_NOT_CREATE_USER_GROUP");
	/**
	 * String representation for request for remove user group
	 */
	public static final USMBaseMsgType S_UG_REQ_REMOVE_USER_GROUP =
		new USMBaseMsgType("S_UG_REQ_REMOVE_USER_GROUP");
	/**
		 * String representation for Response for remove user group
		 */
	public static final USMBaseMsgType S_UG_RES_REMOVE_USER_GROUP =
		new USMBaseMsgType("S_UG_RES_REMOVE_USER_GROUP");
	/**
	 * String representation for request for modify user group
	 */
	public static final USMBaseMsgType S_UG_REQ_MODIFY_USER_GROUP =
		new USMBaseMsgType("S_UG_REQ_MODIFY_USER_GROUP");
	/**
		 * String representation for response for modify user group
		 */
	public static final USMBaseMsgType S_UG_RES_MODIFY_USER_GROUP =
		new USMBaseMsgType("S_UG_RES_MODIFY_USER_GROUP");
	/**
	 * String representation for request for create user group
	 */
	public static final USMBaseMsgType S_UG_REQ_CREATE_USER_GROUP =
		new USMBaseMsgType("S_UG_REQ_CREATE_USER_GROUP");
	/**
		 * String representation for response for create user group
		 */
	public static final USMBaseMsgType S_UG_RES_CREATE_USER_GROUP =
		new USMBaseMsgType("S_UG_RES_CREATE_USER_GROUP");
	/**
	 * String representation for notification for create user group
	 */
	public static final USMBaseMsgType S_UG_NOT_CREATE_USER_GROUP =
		new USMBaseMsgType("UG_NOT_CREATE_USER_GROUP");

	/**
	 * String representation for notification for remove user group
	 */
	public static final USMBaseMsgType S_UG_NOT_REMOVE_USER_GROUP =
		new USMBaseMsgType("UG_NOT_REMOVE_USER_GROUP");
	/**
	 * String representation for notification for modify user group
	 */
	public static final USMBaseMsgType S_UG_NOT_MODIFY_USER_GROUP =
		new USMBaseMsgType("UG_NOT_MODIFY_USER_GROUP");

	public static final USMBaseMsgType S_UA_RES_MODIFY_USER =
		new USMBaseMsgType("S_UA_RES_MODIFY_USER");

	public static final USMBaseMsgType S_UA_NOTIFICATION_USER_LOGIN_FAILED =
		new USMBaseMsgType("S_UA_NOTIFICATION_USER_LOGIN_FAILED");

}
