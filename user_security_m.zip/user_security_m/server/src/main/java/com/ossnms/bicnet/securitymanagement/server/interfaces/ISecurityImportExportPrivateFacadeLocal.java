package com.ossnms.bicnet.securitymanagement.server.interfaces;

public interface ISecurityImportExportPrivateFacadeLocal extends ISecurityImportExportPrivateFacade { }

