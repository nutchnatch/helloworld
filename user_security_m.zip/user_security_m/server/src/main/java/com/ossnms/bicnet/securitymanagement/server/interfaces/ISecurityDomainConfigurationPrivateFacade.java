/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	ISecurityDomainConfigurationPrivateFacade
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	23rd July 2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 18-Jan-2005	Asif			CF000834 - Command Log Entries	CF USM
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.interfaces;

import com.ossnms.bicnet.bcb.facade.IFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;

import java.util.List;

/**
 * This is the Private Interface Facade for the Domain Configuration
 */

public interface ISecurityDomainConfigurationPrivateFacade extends IFacade {
	/**
	 * This method gets all the domains from the server
	 * @return USMMessage - Message containing all the domains information
	 */
	USMMessage getAllDomains(ISessionContext p_Ctx)
		throws BcbSecurityException;

	/**
	 * This method handles the create domain operation
	 * @param p_Domain - Domain object that is to be created
	 * @return USMMessage - Message that contains the result of the operation
	 */
	USMMessage createDomain(
		ISessionContext p_Ctx,
		DCDomainData p_Domain)
		throws BcbSecurityException;

	/**
	 * This method handles the deletion of domains
	 * @param p_Domain - List of domain to be deleted
	 * @return USMMessage - Message containing the result of the operation
	 */
	USMMessage deleteDomain(ISessionContext p_Ctx, List p_Domain)
		throws BcbSecurityException;

	/**
	 * This method handles the modification of domains
	 * @param p_Domain - List of domain to be modified
	 * @return USMMessage - Message containing the result of the operation
	 */
	USMMessage modifyDomain(
		ISessionContext p_Ctx,
		DCDomainData p_Domain)
		throws BcbSecurityException;

	/**
	 * This method handles the modification of domains
	 * @param p_Domain - Domain object for which the servers have to be retrieved
	 * @param p_Assigned - True to indicate that the securable objects of the server belong to the domain
	 * @param p_domainConfigWdw - True to indicate that this method is called from domain config main window
	 * @return USMMessage - Message containing the result of the operation
	 */
	//Added the new parameter p_domainConfigWdw as i now need to differentiate whether this was called for domain
	//config window or for the create/modify window. Was it a bad design decision that i reuse the job and the
	//facade method for getting the objects assigned to the domain for domain config window as well as for the 
	//create/modify domain window is still a discussion. 
	USMMessage getServersForDomain(
		ISessionContext p_Ctx,
		DCDomainData p_Domain,
		boolean p_Assigned,
		boolean p_domainConfigWdw)
		throws BcbSecurityException;

	/**
	 * This method handles the modification of domains
	 * @param p_Domain - Domain object for which the servers have to be retrieved
	 * @param p_Server - Server object of which the securable objects have to be retrieved
	 * @param p_Assigned - True to indicate that the securable objects of the server belong to the domain
	 * @return USMMessage - Message containing the result of the operation
	 */
	USMMessage getObjectsOfServerForDomain(
		ISessionContext p_Ctx,
		DCDomainData p_Domain,
		BSTransBicNetCFInfo p_Server,
		boolean p_Assigned)
		throws BcbSecurityException;

	/**
	 * This method retrieves all the mappings present
	 * @return USMMessage - Message containing the mapping information
	 */
	USMMessage getAllMappings(ISessionContext p_Ctx)
		throws BcbSecurityException;

	/**
	 * This method gets called when the mappings are changed.
	 * @param p_mappings - List of mappings that are to be changed
	 * @return USMMessage - Message containing the result of the operation
	 */
	USMMessage changeMappings(ISessionContext p_Ctx, List p_mappings)
		throws BcbSecurityException;


	/**
	 * This method assigns securable objects to domain
	 * @return USMMessage - Message informing the result
	 */
	USMMessage assignUnassignObjectsToDomain(
		ISessionContext ctx,
		List<BSSecurableObject> objectsToAssign,
		List<BSSecurableObject> objectsToUnassign,
		DCDomainData domain,
		boolean createWindow)
		throws BcbSecurityException;
	
	/**
	 * This method returns all the securable object
	 * 
	 * @return USMMessage - Message informing the result
	 */
	USMMessage getAllSecurableObject(ISessionContext context) throws BcbSecurityException;

}
