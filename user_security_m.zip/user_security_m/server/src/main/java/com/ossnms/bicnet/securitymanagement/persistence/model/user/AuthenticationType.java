package com.ossnms.bicnet.securitymanagement.persistence.model.user;

/**
 *
 */
public enum AuthenticationType {
    LOCAL,
    SSO,
    LDAP,
    RADIUS
}
