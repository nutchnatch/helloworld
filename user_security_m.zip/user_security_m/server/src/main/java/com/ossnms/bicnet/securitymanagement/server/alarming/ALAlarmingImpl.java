/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 13-Jan-05    Babu B          TCM Id 309 Trace statements insufficient in Alarming implementation of USM
 * 02-Feb-05    Babu B          CF000199-11   Unification of GUI-Labels for Enums
 * 10-Mar-05    Babu B          CF001295-01 - "Alarm list" window - (Equipment Type column - Unknown)
 * 
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.server.alarming;

import com.ossnms.bicnet.bcb.facade.common.BiCNetComponentIdItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmReply;
import com.ossnms.bicnet.bcb.facade.faultMgmt.IFaultMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.IBiCNetComponentId;
import com.ossnms.bicnet.bcb.model.common.TimeOrigin;
import com.ossnms.bicnet.bcb.model.common.TrafficDirection;
import com.ossnms.bicnet.bcb.model.elementMgmt.ObjectTemplate;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.bcb.model.faultMgmt.FaultCondition;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarm;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmId;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmLogRecord;
import com.ossnms.bicnet.bcb.model.faultMgmt.ProbableCause;
import com.ossnms.bicnet.bcb.model.logMgmt.LogRecordFields;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import com.ossnms.bicnet.securitymanagement.server.basic.ALAlarmRecordData;
import com.ossnms.bicnet.securitymanagement.server.useradministration.UASubsystemSAP;
import com.ossnms.bicnet.servicelocator.BiCNetServiceLocator;
import com.ossnms.bicnet.servicelocator.IBiCNetServiceLocator;
import com.ossnms.bicnet.util.UnexpectedException;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * Helper POJO class for the USM Alarming tasks
 */
public class ALAlarmingImpl {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(ALAlarmingImpl.class);

	/**
	 * Cached reference to the Fault Manager Facade
	 */
	static IFaultMgrFacade faultMgrFacade = null;

	/**
	* Returns a cached instance of FaultManager facade
	* @return - FaultManager facade
	*/
	private static IFaultMgrFacade getFaultManager() {

		LOGGER.debug("getFaultManager() Entry");

		if (null == faultMgrFacade) {
			IBiCNetServiceLocator serviceLocator =
				BiCNetServiceLocator.getInstance();

			try {
				faultMgrFacade =
					serviceLocator.getFaultManager(
						BiCNetComponentType.SECURITY_MANAGER);

				LOGGER.info("Service Locator for FM successfully retrieved");
            } catch (UnsupportedOperationException e) {
                LOGGER.error("No Service Locator has previously been registered for FM ", e);

            } catch (UnexpectedException e) {
                LOGGER.error("FaultMgr Facade could not be retreived, check configuration files ", e);
			}
		}
		LOGGER.debug("getFaultManager() Exit");

		return faultMgrFacade;
	}

	/**
	 * This method raises an alarm to FM 
	 * using the ALAlarmRecordData passed as an argument
	 * @param sessionContext
	 * @param usmAlarmRecordData - Alarm record details
	 */
    public void raiseAlarm(ISessionContext sessionContext, ALAlarmRecordData usmAlarmRecordData) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("raiseAlarm() Entry");
        }
		//Retrieving FM Facade
		IFaultMgrFacade faultMgr = getFaultManager();
		try {

			//Populating Alarm Record item
			IAlarm alarmRecord = createTransAlarmRecord(usmAlarmRecordData);

            // Raise the alarm
            if(null != faultMgr) {
                faultMgr.raiseAlarm(sessionContext, null, alarmRecord, TimeOrigin.SENDER);
            }
            LOGGER.debug("Alarm data successfully passed to FM");

		} catch (BcbException e) {
			LOGGER.error("Failed to raise alarm " + usmAlarmRecordData, e);

		} catch (Exception e) {
			LOGGER.error("Failed to raise alarm " + usmAlarmRecordData, e);
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("raiseAlarm() Exit");
		}
	}

	/**
	 * This method raises a cleared alarm to FM 
	 * using the ALAlarmRecordData passed as an argument
	 * @param sessionContext
	 * @param usmAlarmRecordData - Alarm record details
	 */
    public void clearAlarm(ISessionContext sessionContext, ALAlarmRecordData usmAlarmRecordData) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("clearAlarm() Entry");
        }
        // Retrieving FM Facade
        IFaultMgrFacade faultMgr = getFaultManager();
        try {
            // Populating Alarm Record item
            IAlarm alarmRecord = createTransAlarmRecord(usmAlarmRecordData);
            LOGGER.debug("Alarm clear data successfully passed to FM");

            // clear the alarm
            if(null != faultMgr) {
                faultMgr.clearAlarm(sessionContext, null, alarmRecord, alarmRecord.getRaiseTime(), TimeOrigin.SENDER);
            }

		} catch (BcbException e) {
			LOGGER.error("Failed to clear alarm " + usmAlarmRecordData, e);

		} catch (Exception e) {
			LOGGER.error("Failed to clear alarm " + usmAlarmRecordData, e);

		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("clearAlarm() Exit");
		}
	}

	/**
	 * Helper method for creating a dummy IAlarm object with default values
	 * using the ALAlarmRecordData object passed as an argument
	 * @param usmAlarmRecordData - Alarm record details
	 */
	private IAlarm createTransAlarmRecord(ALAlarmRecordData usmAlarmRecordData) {

        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("createTransAlarmRecord() Entry " + usmAlarmRecordData);
        }

		//Populating Alarm Record item
		IAlarm alarmRecord = new AlarmItem(null);

        alarmRecord.setSourceComponentName(BiCNetComponentType.SECURITY_MANAGER.guiLabel());

		IBiCNetComponentId affectedObject = new BiCNetComponentIdItem();
		affectedObject.setType(BiCNetComponentType.SECURITY_MANAGER);

        alarmRecord.setSourceComponentType(BiCNetComponentType.SECURITY_MANAGER);
        alarmRecord.setAffectedObject(affectedObject);
        alarmRecord.setAffectedObjectLocation(usmAlarmRecordData.getUserId());
        alarmRecord.setAffectedObjectType(ObjectTemplate.fromName("software"));
        alarmRecord.setEquipmentType(null);
        alarmRecord.setFaultCondition(FaultCondition.NEUTRAL);
        alarmRecord.setMoVersion(1L);
        alarmRecord.setProbableCause(ProbableCause.fromName("unsuccessfulLoginsExceeded"));
        alarmRecord.setRaiseTime(new Date());
        alarmRecord.setSeverity(AlarmSeverity.CRITICAL);
        alarmRecord.setTrafficDirection(TrafficDirection.NONE);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("createTransAlarmRecord() Exit");
		}

		return alarmRecord;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.facade.faultMgmt.IAlarmFacade#getAlarmList(com.ossnms.bicnet.bcb.facade.security.ISessionContext, com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmId, com.ossnms.bicnet.bcb.model.IManagedObjectId[], int)
	 */
    public AlarmReply getAlarmList(ISessionContext sessionContext, IAlarmId startAfter, IManagedObjectId[] filter, int howMany) throws BcbException {

		/*
		 * NOTE: The filter is not implemented. The filter parameter is ignored. 
		 */

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("getAlarmList() Entry");
		}

		List<IAlarm> lstAlarms = new ArrayList<IAlarm>();

		// retrieve all users
		List<UAUser> lstUsers = UASubsystemSAP.getAllUsers();

		Iterator<UAUser> iterUsers = lstUsers.iterator();
		while (iterUsers.hasNext()) {
			UAUser objUser = iterUsers.next();

			// identify locked users
			if (objUser.isAccountLocked()) {

				// locate alarm representation in LDAP
				ALAlarmRecordData usmAlarmRecordData = locateAlarmRecord(
                        sessionContext,
                        objUser.getUserId());

//				// ensure alarm representation exists in LDAP
//				if (usmAlarmRecordData == null) {
//					usmAlarmRecordData = new ALAlarmRecordData();
//					usmAlarmRecordData.setUserId(objUser.getUserId());
//
//					ALLWInterface.storeAlarmRecord(
//						sessionContext,
//						usmAlarmRecordData);
//				}

				// create IAlarm representation to be sent to FM
				IAlarm objAlarm = createTransAlarmRecord(usmAlarmRecordData);
				lstAlarms.add(objAlarm);
			}
		}

		// skip alarms till (& including) startAfter
		Iterator<IAlarm> iterAlarms = lstAlarms.iterator();
		while (iterAlarms.hasNext()) {
			IAlarm objAlarm = iterAlarms.next();
			if (startAfter.equals(objAlarm.getAlarmId())) {
				break;
			}
		}

		IAlarm objAlarm = null;
		// get the next 'howMany' alarms
		List<IAlarm> vecAlarms = new ArrayList<IAlarm>();
		while ((iterAlarms.hasNext()) && (howMany-- > 0)) {
			objAlarm = iterAlarms.next();
			vecAlarms.add(objAlarm);
		}

		// convert to plain vanilla array
		IAlarm[] arrAlarms =
			vecAlarms.toArray(new IAlarm[vecAlarms.size()]);

		AlarmReply objAlarmReply =
			new AlarmReply(arrAlarms, !iterAlarms.hasNext(), objAlarm);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("getAlarmList() Exit");
			LOGGER.debug("getAlarmList() return value - " + Arrays.toString(arrAlarms));
		}

		return objAlarmReply;
	}


    public ALAlarmRecordData locateAlarmRecord(ISessionContext sessionContext, String userId){

        // Retrieving FM Facade
        IFaultMgrFacade faultMgr = getFaultManager();
        ALAlarmRecordData recordData = new ALAlarmRecordData(userId, new Date());

        IAlarm alarmRecord = createTransAlarmRecord(recordData);

        try {
            //Because LogRecordFields array is empty, no values will be returned, but no value is required, since we are only trying to find
            //if such records exist
            IAlarmLogRecord[] records = faultMgr.getRaisedAlarmsById(sessionContext, new IAlarmId[]{alarmRecord}, new LogRecordFields[0]);
            if(records != null && records.length != 0){
                return recordData;
            }
        } catch (BcbException e) {
            LOGGER.warn("locateAlarmRecord() - " + e.getMessage());
        }

        return null;
    }

}
