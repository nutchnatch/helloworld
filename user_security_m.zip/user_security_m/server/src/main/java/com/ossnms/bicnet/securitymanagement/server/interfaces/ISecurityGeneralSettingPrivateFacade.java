package com.ossnms.bicnet.securitymanagement.server.interfaces;


import com.ossnms.bicnet.bcb.facade.IFacade;
import com.ossnms.bicnet.bcb.facade.annotation.AcceptServerState;
import com.ossnms.bicnet.bcb.facade.annotation.BypassAuthentication;
import com.ossnms.bicnet.bcb.facade.annotation.ServerState;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.bicnet.securitymanagement.common.general.ResponseMessage;
import com.ossnms.bicnet.securitymanagement.common.general.ldap.LDAPConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.radius.configuration.RadiusConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.radius.status.RadiusServerStatus;
import com.ossnms.bicnet.securitymanagement.common.general.radius.status.RadiusTestConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.sso.SSOConfigurationData;

/**
 * This is the Private Interface Facade for the General Settings
 */

public interface ISecurityGeneralSettingPrivateFacade extends IFacade {
    /**
     * Gets the general setting data. Whenever request comes from the client to
     * general setting bean, bean delegates the request to this class to process
     * the request
     *
     * @param sessionContext - Session token for the client
     * @return GSGeneralSettingData - Response goes to client wrapped in
     * GSGeneralSettingData
     */
    GSGeneralSettingData getGeneralSettingData(ISessionContext sessionContext) throws BcbSecurityException;

    /**
     * Updates the general setting data. Whenever request comes from the client
     * to general setting bean, bean delegates the request to this class to
     * process the request
     *
     * @param sessionContext     - Session token for the client
     * @param generalSettingData - General Setting details
     * @return boolean - Response goes to client wrapped in USMMessage
     */
    ResponseMessage setGeneralSettingData(ISessionContext sessionContext, GSGeneralSettingData generalSettingData) throws BcbException;

    /**
     * Tests the RADIUS server, identified with the {@link RadiusTestConfigurationData} parameters
     *
     * @param sessionContext the session context
     * @param configurationData the test configuration data
     * @return the server status
     */
    RadiusServerStatus testRadiusServer(ISessionContext sessionContext, RadiusTestConfigurationData configurationData) throws BcbSecurityException;

    /**
     * Retrieves the settings regarding Single Sign On
     * @return an instance of {@link SSOConfigurationData}
     * @throws BcbSecurityException if the data could not be obtained
     */
    @BypassAuthentication
    @AcceptServerState({ServerState.running, ServerState.shutDown})
    SSOConfigurationData getSingleSignOnData() throws BcbSecurityException;

    /**
     * Retrieves the settings regarding LDAP Authentication
     * @return an instance of {@link LDAPConfigurationData}
     * @throws BcbSecurityException if the data could not be obtained
     */
    @BypassAuthentication
    @AcceptServerState({ServerState.running, ServerState.shutDown})
    LDAPConfigurationData getLdapConfigurationData() throws BcbSecurityException;

    /**
     *
     * @return
     * @throws BcbSecurityException
     */
    @BypassAuthentication
    @AcceptServerState({ ServerState.running, ServerState.shutDown })
    USMMessage getPasswordVerificationRulesConfigurationData() throws BcbSecurityException;

    /**
     * Retrieves the settings regarding RADIUS Authentication
     * @return an instance of {@link RadiusConfigurationData}
     * @throws BcbSecurityException if the data could not be obtained
     */
    @BypassAuthentication
    @AcceptServerState({ServerState.running, ServerState.shutDown})
    RadiusConfigurationData getRadiusConfigurationData() throws BcbSecurityException;

}
