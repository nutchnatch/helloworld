package com.ossnms.bicnet.securitymanagement.server.logging;

/**
 *
 */
public enum LMCommandClassificationEnum {
    MESSAGE("Message"),
    ERROR("Error"),
    WARNING("Warning");

    /**
     *
     */
    private String label;

    /**
     *
     * @param label
     */
    private LMCommandClassificationEnum(String label){
        this.label = label;
    }

    /**
     *
     * @return
     */
    public String getLabel() {
        return label;
    }

    /**
     *
     * @param label
     */
    public void setLabel(String label) {
        this.label = label;
    }
}
