/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCMessageType
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CREATE
 * 		:	TNMS.DX2.SM.DOMAIN.CONFIG	   
 * 		:	TNMS.DX2.SM.DOMAIN.VIEW
 * 		:	TNMS.DX2.SM.MAPPING.CREATE
 * 		:	TNMS.DX2.SM.MAPPING.VIEW 
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.common.domain;

import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;

/**
 * This class stores all the primitives used by DC internally across the client
 * and the server for its messages
 */
public final class DCMessageType {

	/**
	 * Message primitives
	 */
	public static final USMBaseMsgType DC_REQ_DOMAINS =
		new USMBaseMsgType("DC_Req_Domains");
	public static final USMBaseMsgType DC_RES_DOMAINS =
		new USMBaseMsgType("DC_Res_Domains");

	public static final USMBaseMsgType DC_REQ_ACCESS_RIGHTS =
		new USMBaseMsgType("DC_Req_AccessRights");
	public static final USMBaseMsgType DC_RES_ACCESS_RIGHTS =
		new USMBaseMsgType("DC_Res_AccessRights");

	public static final USMBaseMsgType DC_REQ_MAPPING_FOR_DOMAIN =
		new USMBaseMsgType("DC_Req_MappingForDomain");
	public static final USMBaseMsgType DC_RES_MAPPING_FOR_DOMAIN =
		new USMBaseMsgType("DC_Res_MappingForDomain");

	public static final USMBaseMsgType DC_REQ_ASSIGN_MAPPING =
		new USMBaseMsgType("DC_Req_AssignMapping");
	public static final USMBaseMsgType DC_RES_ASSIGN_MAPPING =
		new USMBaseMsgType("DC_Res_AssignMapping");

	public static final USMBaseMsgType DC_REQ_CREATE_DOMAIN =
		new USMBaseMsgType("DC_Req_CreateDomain");
	public static final USMBaseMsgType DC_RES_CREATE_DOMAIN =
		new USMBaseMsgType("DC_Res_CreateDomain");

	public static final USMBaseMsgType DC_REQ_DELETE_DOMAIN =
		new USMBaseMsgType("DC_Req_DeleteDomain");
	public static final USMBaseMsgType DC_RES_DELETE_DOMAIN =
		new USMBaseMsgType("DC_Res_DeleteDomain");

	public static final USMBaseMsgType DC_REQ_DOMAIN_DETAILS_SERVER_LEVEL =
		new USMBaseMsgType("DC_Req_DomainDetailsServerLevel");
	public static final USMBaseMsgType DC_RES_DOMAIN_DETAILS_SERVER_LEVEL =
		new USMBaseMsgType("DC_Res_DomainDetailsServerLevel");
	
	public static final USMBaseMsgType DC_REQ_ALL_SECURABLE_OBJECTS =	new USMBaseMsgType("DC_Req_AllSecurableObjects");
	public static final USMBaseMsgType DC_RES_ALL_SECURABLE_OBJECTS =	new USMBaseMsgType("DC_Res_AllSecurableObjects");

	public static final USMBaseMsgType DC_REQ_DOMAIN_DETAILS_OBJECT_LEVEL =
		new USMBaseMsgType("DC_Req_DomainDetailsObjectLevel");
	public static final USMBaseMsgType DC_RES_DOMAIN_DETAILS_OBJECT_LEVEL =
		new USMBaseMsgType("DC_Res_DomainDetailsObjectLevel");

	public static final USMBaseMsgType DC_REQ_ASSIGN_TO_DOMAIN =
		new USMBaseMsgType("DC_Req_AssignObjectsToDomain");
	public static final USMBaseMsgType DC_RES_ASSIGN_TO_DOMAIN =
		new USMBaseMsgType("DC_Res_AssignObjectsToDomain");

	public static final USMBaseMsgType DC_REQ_MODIFY_DOMAIN =
		new USMBaseMsgType("DC_Req_ModifyDomain");
	public static final USMBaseMsgType DC_RES_MODIFY_DOMAIN =
		new USMBaseMsgType("DC_Res_ModifyDomain");

	/**
	 * Notifications
	 */
	public static final USMBaseMsgType DC_NOT_MAPPINGS_MODIFIED =
		new USMBaseMsgType("DC_Not_MappingsModified");
	public static final USMBaseMsgType DC_NOT_DOMAIN_CREATED =
		new USMBaseMsgType("DC_Not_DomainCreated");
	public static final USMBaseMsgType DC_NOT_DOMAIN_DELETED =
		new USMBaseMsgType("DC_Not_DomainDeleted");
	public static final USMBaseMsgType DC_NOT_DOMAIN_MODIFIED =
		new USMBaseMsgType("DC_Not_DomainModified");

	/**
	 * To prevent creation a new instance of DCMessages
	 */
	private DCMessageType() {

	}
}
