package com.ossnms.bicnet.securitymanagement.server.importexport;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityImportExportPrivateFacadeLocal;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityImportExportPrivateFacadeRemote;

@Stateless(name = "IEImportExportSLSBFacade")
@Local(ISecurityImportExportPrivateFacadeLocal.class)
@Remote(ISecurityImportExportPrivateFacadeRemote.class)
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class IEImportExportSLSBFacadeBean implements ISecurityImportExportPrivateFacadeLocal, ISecurityImportExportPrivateFacadeRemote {

	IEImportExportPOJOImpl m_pojo = new IEImportExportPOJOImpl();

	public USMMessage importSecurityData(ISessionContext p_ctx, List p_securityData, String p_type, Boolean p_overWrite)
			throws BcbSecurityException {
		return m_pojo.importSecurityData(p_ctx, p_securityData, p_type, p_overWrite);
	}

	public USMMessage exportSecurityData(ISessionContext p_ctx, String p_typeOfData) throws BcbSecurityException {
		return m_pojo.exportSecurityData(p_ctx, p_typeOfData);
	}
}
