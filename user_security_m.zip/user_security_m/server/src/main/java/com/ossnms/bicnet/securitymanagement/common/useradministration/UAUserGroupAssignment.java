package com.ossnms.bicnet.securitymanagement.common.useradministration;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;

import java.io.Serializable;
import java.util.Objects;

/**
 *
 */
public class UAUserGroupAssignment implements Serializable {

    private static final long serialVersionUID = 6722687920097305494L;

    private String username;
    private String userGroupName;

    /**
     *
     */
    public UAUserGroupAssignment() {
        username = "";
        userGroupName = "";
    }

    /**
     *
     * @param username
     * @param userGroupName
     */
    public UAUserGroupAssignment(String username, String userGroupName){
        this.username = username != null ? username : "";
        this.userGroupName = userGroupName != null ? userGroupName : "";
    }

    /**
     *
     * @param msg
     */
    public void pushMe(USMMessage msg){
        msg.pushString(username);
        msg.pushString(userGroupName);
    }

    /**
     *
     * @param msg
     */
    public void popMe(USMMessage msg){
        userGroupName = msg.popString();
        username = msg.popString();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserGroupName() {
        return userGroupName;
    }

    public void setUserGroupName(String userGroupName) {
        this.userGroupName = userGroupName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UAUserGroupAssignment that = (UAUserGroupAssignment) o;
        return Objects.equals(username, that.username) &&
                Objects.equals(userGroupName, that.userGroupName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(username, userGroupName);
    }
}
