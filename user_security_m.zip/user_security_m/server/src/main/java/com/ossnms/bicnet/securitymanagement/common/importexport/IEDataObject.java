/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	IEDataObject
 * Author      	Jogender Singh
 * Substitute	Babu B
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 * Project: TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : 	TNMS.DX2.SM.MIGRATION
 * 			TNMS.DX2.SM.EXPORT
 * 			TNMS.DX2.SM.IMPORT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Muyeen Munaver	CF000427 - Implementation of the XML import mechanism needed for the migration process
 * 04-Apr-2006	Shrinidhi G V 	CF003795-03 - Wrong info with import of Security Management
 * 23-Mar-2006	Shrinidhi		CF003795-01	Wrong info with import of Security Management
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.importexport;

import java.io.Serializable;

/**
 * Data object class used in data import/export functionality
 */
public class IEDataObject implements Serializable {

	/**
     * 
     */
    private static final long serialVersionUID = 1L;

    /**
	 * String to denote to import/export domains
	 */
	public static final String DOMAIN = "Domain";
	/**
	 * String to denote to import/export Policy
	 */
	public static final String POLICY = "Policy";
	/**
	 * String to denote to import/export User
	 */
	public static final String USER = "User";
	/**
	 * String to denote to import/export User Group
	 */
	public static final String USER_GROUP = "User Group";
	/**
	 * String to denote to import/export Mapping
	 */
	public static final String MAPPING = "Mapping";

	/**
	 * Variable used to store the index of the message obtained while importing security data
	 */
	public int m_index = 0;

	/**
	 * Data member to hold actual object
	 */
	private Object ieData = new Object();
	/**
	 * Data member to hold import/export operation status
	 */
	private String errorString = "";

	/**
	 * Default constructor
	 *
	 */
	public IEDataObject() {
	}
	/**
	 * This constructor initialize the member variables.
	 *@param pIeData - Import/Export data to be imported or exported
	 *@param p_errorString - Status of the import or export operation
	 */
	public IEDataObject(Object pIeData, String p_errorString) {
		errorString = p_errorString;
		ieData = pIeData;
	}
	/**
	 * Returns the import/export operation status
	 * @return String - Message string which tells the operation status
	 */
	public String getErrorString() {
		return errorString;
	}

	/**
	 * Returns the import/export data object
	 * @return Object - Data object to be imported/exported
	 */
	public Object getDataObject() {
		return ieData;
	}

	/**
	 * Sets the import/export operation status
	 * @param p_errorString - Message string which tells the operation status
	 */
	public void setErrorString(String p_errorString) {
		errorString = p_errorString;
	}

	/**
	 * Returns the import/export data object
	 * @param p_object - Data object to be imported/exported
	 */
	public void setDataObject(Object p_object) {
		ieData = p_object;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
    public String toString() {
		String str = "";
		if (ieData != null) {
			str = ieData.toString();
		}
		return str;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
    public boolean equals(Object obj) {
		boolean bEquals = false;
		if ((obj != null) && (obj instanceof IEDataObject)) {
			IEDataObject ieObj = (IEDataObject) obj;
			bEquals = ieData.equals(ieObj.ieData);
		}
		return bEquals;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
    public int hashCode() {
		return ieData.hashCode();
	}
	/**
	 * @return
	 */
	public int geterrorIndex() {
		return m_index;
	}

	/**
	 * @param i
	 */
	public void setErrorIndex(int i) {
		m_index = i;
	}

}
