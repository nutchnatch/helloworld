/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCAccessRightsController
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID	    :   TNMS.DX2.SM.MAPPING.VIEW   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.server.domain;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessageType;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Controller for handling feature request for access rights details.
 * Responsible for sending all the access rights configured.
 */
class DCAccessRightsController {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(DCAccessRightsController.class);

    /**
     * Constructor
     */
    public DCAccessRightsController() {
        //Do nothing
    }

    /**
     * Function which gets called when a get access rights request is
     * received from the client.
     *
     * @return Message which contains all the mappings with info about domains and policies
     */
    public USMMessage getAccessRights() {

        LOGGER.debug("getAccessRights() - Entry");
        List<DCDomainMapping> allMappings = new ArrayList<>();
        //Fetch all mappings from data cache manager
        DCServerDataManager.getInstance().getAllConfiguredMappings(allMappings);

        //Fetch the list of domain data as the name and domain id is mapped from here
        //The mappings contains only the domain id
        List<DCDomainData> allDomains = new ArrayList<DCDomainData>();
        DCServerDataManager.getInstance().getAllConfiguredDomains(
                allDomains);

        //Create a map of domain id, so that searching is easier
        //I am creating a map of domain id and domain data even though
        //i could have retrieved the same from DCServerDataCacheMangager by calling	getDomainData
        //passing the domain id. But since this method is synchrnonized, i donot want to do it.
        Map mapDomainIds = new HashMap();
        for (DCDomainData dom : allDomains) {
            mapDomainIds.put(dom.getDomainID(), dom);
        }

        //Fetch all policies, to send in the policies which are of interest to the caller,
        //i.e which take part in the mapping
        List allPolicies;
        allPolicies = DCExternalInterface.getPolicies();
        //Create a map of policy id, so that searching is easier
        Map mapPolicyIds = new HashMap();
        for (Object allPolicy : allPolicies) {
            PAPolicyId pol = (PAPolicyId) allPolicy;
            mapPolicyIds.put(pol.getPolicyID(), pol);
        }

        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("getAccessRights() - " + "Total number of domain mappings retrieved are " + allMappings.size());
            LOGGER.info("getAccessRights() - " + "Total number of domain retrieved are " + allDomains.size());
            LOGGER.info("getAccessRights() - " + "Total number of policies retrieved are " + allPolicies.size());
        }

        //Now is the part of sending the filtered list of domain data and the policy
        //data that is of interest to the caller
        List<PAPolicyId> policiesPartOfMappings = new ArrayList<PAPolicyId>();
        List<DCDomainData> domainsPartOfMappings = new ArrayList<DCDomainData>();
        List<DCDomainMapping> mappingsToBeSent = new ArrayList<DCDomainMapping>();

        for (DCDomainMapping allMapping : allMappings) {
            int policyId = allMapping.getPolicyID();

            Object obj = mapPolicyIds.get(policyId);
            //The policy should be found, if not found, log it as an error
            if (null != obj) {
                PAPolicyId polData = (PAPolicyId) obj;
                policiesPartOfMappings.add(polData);
            } else {
                LOGGER.error(
                        "getAccessRights() - "
                                + "There exists a mapping, where the policy id is invalid, mapping being "
                                + allMapping);
                continue;
            }

            int domainId = allMapping.getDomainID();
            obj = mapDomainIds.get(domainId);
            //The policy should be found, if not found, log it as an error
            if (null != obj) {
                DCDomainData domData = (DCDomainData) obj;
                domainsPartOfMappings.add(domData);
            } else {
                LOGGER.error(
                        "getAccessRights() - "
                                + "There exists a mapping, where the domain id is invalid, mapping being "
                                + allMapping);
                continue;
            }
            mappingsToBeSent.add(allMapping);
        }

        //Fill in the USMMessage that has to be sent
        USMMessage msg =
                new USMMessage(
                        DCMessageType.DC_RES_ACCESS_RIGHTS,
                        USMMessage.USMMESSAGE_RESPONSE);
        for (PAPolicyId pol : policiesPartOfMappings) {
            pol.pushMe(msg);
        }
        msg.pushInteger(policiesPartOfMappings.size());
        DCDomainData.pushDomainsToMessage(domainsPartOfMappings, msg);
        DCDomainMapping.pushMappingsToMessage(mappingsToBeSent, msg);

        //Finally, I have found one method, which always returns always success
        //What error can occur in this function. is what i currently donot know.
        //One error could be is that the mappins exist, but domain or policy donot exist for
        //that mapping, but i have also neatly handled that condition, hopefully.
        msg.pushInteger(DCMessages.DC_NO_ERROR);

        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("getAccessRights() - " + "Total number of proper domain mappings retrieved to be sent to client are " + mappingsToBeSent.size());
            LOGGER.info("getAccessRights() - " + "Domain that are sent as part of mappings info are " + domainsPartOfMappings.size());
            LOGGER.info("getAccessRights() - " + "Policy that are sent as part of mappings info are " + policiesPartOfMappings.size());
        }

        LOGGER.debug("getAccessRights() - Exit");
        return msg;
    }
}
