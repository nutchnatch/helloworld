package com.ossnms.bicnet.securitymanagement.common.auth;

/**
 * Supported values for the User Group Attribute in RADIUS Authentication methods
 */
public enum RadiusUserGroupAttribute {

    VENDOR_SPECIFIC ("Vendor Specific"),
    FILTER_ID       ("Filter-id");

    private String label;

    /**
     * Constructor which supports a label
     * @param label the label of the user group attribute type
     */
    RadiusUserGroupAttribute(String label){
        this.label = label;
    }

    /**
     *
     * @return
     */
    public String toString() {
        return this.label;
    }
}
