package com.ossnms.bicnet.securitymanagement.server.interfaces;

public interface ISecurityAuthenticationPrivateFacadeRemote extends ISecurityAuthenticationPrivateFacade { }

