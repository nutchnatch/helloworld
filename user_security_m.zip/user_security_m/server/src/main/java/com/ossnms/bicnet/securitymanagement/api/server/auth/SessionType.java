package com.ossnms.bicnet.securitymanagement.api.server.auth;

/**
 *
 */
public enum SessionType {

    //      isClient
    CLIENT  (true,null),
    SYSTEM  (false,null),
    WEB     (true,"Web->Authentication");

    private boolean isClientSession;
	private String requiredPermission;
	

    SessionType(boolean isClientSession, String requiredPermission) {
        this.isClientSession = isClientSession;
        this.requiredPermission = requiredPermission;
    }

    /**
     *
     */
    public boolean isClientSession() {
        return isClientSession;
    }

	public String getRequiredPermission() {
		return requiredPermission;
	}    
}
