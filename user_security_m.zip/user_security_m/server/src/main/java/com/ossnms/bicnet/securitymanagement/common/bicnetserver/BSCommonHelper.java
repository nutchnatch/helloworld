/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	BSCommonHelper
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_OBJECTS
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_ACL 
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_SECURITY
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.INSERT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.bicnetserver;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;

/**
 * Helper class to BS for both the server and the client
 */
public class BSCommonHelper {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(BSCommonHelper.class);

	/**
	 * Helper function to push the List of Securable Objects into the message
	 * @param pMsg The Message into which the objects are to be pushed
	 * @param pListSecObjs The List which contains the Securable Objects that have to be
	 * pushed into the message.
	 */
	public static void pushSecurableObjectsListIntoMessage(USMMessage pMsg, List<BSSecurableObject> pListSecObjs) {
		LOGGER.debug("Entering into pushSecurableObjectsListIntoMessage. List : {} Msg : {}", pListSecObjs, pMsg);

		if ((null == pMsg) || (null == pListSecObjs)) {
			LOGGER.error("Parameters cannot be null. Message : {} List : {}", pMsg, pListSecObjs);
			throw new InvalidParameterException();
		}

		pListSecObjs.forEach(secObj -> secObj.pushTo(pMsg));

		// After pushing in the Securable Objects into the message, we push in the number of Securable Objects.
		pMsg.pushInteger(pListSecObjs.size());

		LOGGER.debug("Exiting from pushSecurableObjectsListIntoMessage");
	}

	/**
	 * Helper function to push the List of Securable Objects Container into the message
	 * @param pMsg The Message into which the objects are to be pushed
	 * @param pListSecObjs The List which contains the Securable Object Containers that have to be
	 * pushed into the message.
	 */
	public static void pushSecurableObjectContainersListIntoMessage(USMMessage pMsg, List<BSSecurableObjectContainer> pListSecObjs) {
		LOGGER.debug("Entering into pushSecurableObjectContainersListIntoMessage. List : {} Msg : {}", pListSecObjs, pMsg);

		if ((null == pMsg) || (null == pListSecObjs)) {
			LOGGER.error("Parameters cannot be null. Message : {} List : {}", pMsg, pListSecObjs);
			throw new InvalidParameterException();
		}

		pListSecObjs.forEach(secObjContainer -> secObjContainer.pushMe(pMsg));

		// After pushing in the Securable Objects Container into the message, we push in the number of Securable Objects Containers.
		pMsg.pushInteger(pListSecObjs.size());

		LOGGER.debug("Exiting from pushSecurableObjectContainersListIntoMessage");
	}

	/**
	 * Helper function to pop out the Securable Objects from the message and put it in a List
	 * @param pMsg  The Message from which the objects are to be poped
	 * @return List The List of Securable Objects that has been poped from the message.
	 */
	public static List<BSSecurableObject> popSecurableObjectsListFromMessage(USMMessage pMsg) {
		LOGGER.debug("Entering into popSecurableObjectsListFromMessage. Message : {}", pMsg);

		if (null == pMsg) {
			LOGGER.error("Message passed cannot be null.");
			throw new InvalidParameterException();
		}

		List<BSSecurableObject> lstSecurableObjs = new ArrayList<>();

		int nCount = pMsg.popInteger();
		for (int index = 0; index < nCount; index++) {
			BSSecurableObject securableObj = BSSecurableObject.popMe(pMsg);
			lstSecurableObjs.add(securableObj);
		}

		LOGGER.debug("Exiting from popSecurableObjectsListFromMessage. Returning : " + lstSecurableObjs);

		return lstSecurableObjs;
	}

	/**
	 *
	 * @param msg message to retrieve the list of containers from
	 * @return the list of securable object container
     */
	public static List<BSSecurableObjectContainer> popSecurableObjectContainersListFromMessage(USMMessage msg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering into popSecurableObjectsListFromMessage. Message : {}", msg);
		}

		if (msg == null) {
			LOGGER.error("Message passed cannot be null.");
			throw new InvalidParameterException();
		}

		List<BSSecurableObjectContainer> securableObjectContainers = new ArrayList<>();

		int nCount = msg.popInteger();
		for (int index = 0; index < nCount; index++) {
			BSSecurableObjectContainer container = BSSecurableObjectContainer.popMe(msg);
			securableObjectContainers.add(container);
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting from popSecurableObjectsListFromMessage. Returning : {}", securableObjectContainers);
		}

		return securableObjectContainers;
	}

	/**
	 * Helper function to push the List of CFs into the message
	 * @param pMsg  The Message into which the objects are to be pushed
	 * @param pListCFs  The List of CFs that have to be pushed into the message.
	 */
	public static void pushCFsListIntoMessage(USMMessage pMsg, List<BSTransBicNetCFInfo> pListCFs) {
		LOGGER.debug("Entering into pushCFsListIntoMessage. List being pushed is : {} Msg : {}", pListCFs, pMsg);

		if ((null == pMsg) || (null == pListCFs)) {
			LOGGER.error("Parameters cannot be null. Message : {} List : {}", pMsg, pListCFs);
			throw new InvalidParameterException();
		}

		pListCFs.forEach(cf -> cf.pushTo(pMsg));

		// After pushing in the Objects into the message, we push in the number of Objects.
		pMsg.pushInteger(pListCFs.size());

		LOGGER.debug("Exiting from pushCFsListIntoMessage. Msg : " + pMsg);
	}

	/**
	 * Helper function to pop out the CFs from the message and put it in a
	 * List
	 * @param pMsg The Message from which the objects are to be poped
	 * @return List The List that has been poped from the message.
	 */
	public static List<BSTransBicNetCFInfo> popCFsListFromMessage(USMMessage pMsg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering into popCFsListFromMessage. Msg : {}", pMsg);
		}

		if (null == pMsg) {
			LOGGER.error("Message passed cannot be null.");
			throw new InvalidParameterException();
		}

		int nCount = pMsg.popInteger();
		List<BSTransBicNetCFInfo> listCFs = new ArrayList<>(nCount);

		for (int index = 0; index < nCount; index++) {
			BSTransBicNetCFInfo bicnetComponent = BSTransBicNetCFInfo.popMe(pMsg);
			listCFs.add(bicnetComponent);
		}
		LOGGER.debug("Exiting from popCFsListFromMessage. Returning : {}", listCFs);

		return listCFs;
	}

	/**
	 * Helper function to push the List of Domains into the message
	 * @param pMsg  The Message into which the objects are to be pushed
	 * @param pLstDomains  The List of Domains that have to be pushed into the message.
	 */
	public static void pushDomainListIntoMessage(USMMessage pMsg, List<DCDomainData> pLstDomains) {
		LOGGER.debug("Entering into pushDomainListIntoMessage. List being pushed is : {} Msg : {}", pLstDomains, pMsg);

		if ((null == pMsg) || (null == pLstDomains)) {
			LOGGER.error("Parameters cannot be null. Message : {} List : {}", pMsg, pLstDomains);
			throw new InvalidParameterException();
		}

		pLstDomains.forEach(domain -> domain.pushMe(pMsg));
		// After pushing in the Objects into the message, we push in the number of Objects.
		pMsg.pushInteger(pLstDomains.size());

		LOGGER.debug("Exiting from pushDomainListIntoMessage. Msg : {}", pMsg);
	}

	/**
	 * Helper function to pop out the Domains from the message and put it in a List
	 * @param pMsg The Message from which the objects are to be poped
	 * @return List The List that has been poped from the message.
	 */
	public static List<DCDomainData> popDomainsListFromMessage(USMMessage pMsg) {
		LOGGER.debug("Entering into popDomainsListFromMessage. Msg : {}", pMsg);

		if (null == pMsg) {
			LOGGER.error("Message passed cannot be null.");
			throw new InvalidParameterException();
		}

		int nCount = pMsg.popInteger();
		List<DCDomainData> listDomains = new ArrayList<>(nCount);

		for (int index = 0; index < nCount; index++) {
			DCDomainData domain = new DCDomainData();
			domain.popMe(pMsg);
			listDomains.add(domain);
		}

		LOGGER.debug("Exiting from popDomainsListFromMessage. Returning : {}", listDomains);

		return listDomains;
	}
}
