package com.ossnms.bicnet.securitymanagement.persistence.model.accessrights;

import javax.persistence.*;
import java.util.List;

/**
 * Securable Element (e.g.: NE)
 */
@Entity
@Table(name = "USM_SEC_ELEMENT")
@NamedQueries({
        @NamedQuery(
                name = "usmSecurableElement.findByUniqueNameWithContainers",
                query = "select distinct e from USMSecurableElement e left join fetch e.containers where e.uniqueName = :uniqueName"
        ),
        @NamedQuery(
                name = "usmSecurableElement.findByUniqueNameWithACL",
                query = "select distinct e from USMSecurableElement e left join fetch e.acl where e.uniqueName = :uniqueName"
        ),
        @NamedQuery(
                name = "usmSecurableElement.findByDisplayName",
                query = "select distinct e from USMSecurableElement e where e.name = :name"
        ),
        @NamedQuery(
                name = "usmSecurableElement.findByDisplayNameWithContainers",
                query = "select distinct e from USMSecurableElement e left join fetch e.containers where e.name = :name"
        ),
        @NamedQuery(
                name = "usmSecurableElement.findByDisplayNameWithACL",
                query = "select distinct e from USMSecurableElement e left join fetch e.acl where e.name = :name"
        ),
        @NamedQuery(
                name = "usmSecurableElement.findByFunction",
                query = "select distinct e from USMSecurableElement e where e.cf.cfId = :functionId"
        ),
        @NamedQuery(
                name = "usmSecurableElement.countByFunction",
                query = "select count(e) from USMSecurableElement e where e.cf.cfId = :functionId"
        ),
        @NamedQuery(
                name = "usmSecurableElement.findByFunctionWithContainers",
                query = "select distinct e from USMSecurableElement e left join fetch e.containers where e.cf.cfId = :functionId"
        ),
        @NamedQuery(
                name = "usmSecurableElement.findByFunctionWithAcl",
                query = "select distinct e from USMSecurableElement e left join fetch e.acl where e.cf.cfId = :functionId"
        ),
        @NamedQuery(
                name = "usmSecurableElement.findByFunctionAndDomain",
                query = "select distinct e from USMSecurableElement e where e.cf.cfId = :functionId AND :domainId MEMBER OF e.acl"
        ),
        @NamedQuery(
                name = "usmSecurableElement.countByFunctionAndDomain",
                query = "select count(e) from USMSecurableElement e where e.cf.cfId = :functionId AND :domainId MEMBER OF e.acl"
        ),
        @NamedQuery(
                name = "usmSecurableElement.findByFunctionAndDomainWithContainers",
                query = "select distinct e from USMSecurableElement e left join fetch e.containers where e.cf.cfId = :functionId AND :domainId MEMBER OF e.acl"
        ),
        @NamedQuery(
                name = "usmSecurableElement.findByFunctionAndDomainWithAcl",
                query = "select distinct e from USMSecurableElement e left join fetch e.acl where e.cf.cfId = :functionId AND :domainId MEMBER OF e.acl"
        ),
        @NamedQuery(
                name = "usmSecurableElement.findAllWithACL",
                query = "select distinct e from USMSecurableElement e left join fetch e.acl"
        ),
        @NamedQuery(
                name = "usmSecurableElement.findAllWithContainers",
                query = "select distinct e from USMSecurableElement e left join fetch e.containers"
        )
})
public class USMSecurableElement extends USMSecurableBase {

    private static final long serialVersionUID = 1148860638715335804L;

    @ElementCollection
    @CollectionTable(name = "USM_ACL", joinColumns = @JoinColumn(name = "ELEMENT_NAME"))
    @Column(name = "DOMAIN_ID")
    private List<Integer> acl;

    @ManyToMany
    @JoinTable(
            name="USM_SEC_CONTAINER_SEC_ELEMENT",
            joinColumns = @JoinColumn(name="ELEMENT_NAME", referencedColumnName = "UNIQUE_NAME"),
            inverseJoinColumns = @JoinColumn(name="CONTAINER_NAME", referencedColumnName = "UNIQUE_NAME")
    )
    private List<USMSecurableElementContainer> containers;

    public USMSecurableElement(){
        super();
    }

    public USMSecurableElement(String uniqueName, String name, int type, String iconId) {
        super(uniqueName, name, type, iconId);
    }

    public List<Integer> getAcl() {
        return acl;
    }

    public void setAcl(List<Integer> acl) {
        this.acl = acl;
    }

    public List<USMSecurableElementContainer> getContainers() {
        return containers;
    }

    public void setContainers(List<USMSecurableElementContainer> containers) {
        this.containers = containers;
    }

    @Override
    public boolean equals(Object o) {
        return super.equals(o);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }
}
