package com.ossnms.bicnet.securitymanagement.server.ldap.api;

import com.ossnms.bicnet.securitymanagement.common.auth.LDAPSearchScope;
import com.ossnms.bicnet.securitymanagement.server.ldap.dto.LDAPUser;

/**
 *
 */
public interface ILDAPAuthenticationManager {

    /**
     *
     * @param searchBase
     * @param searchFilter
     * @param searchScope
     * @param idAttribute
     * @return
     */
    ILDAPAuthenticationManager setUserSearchParameters(String searchBase, String searchFilter, LDAPSearchScope searchScope, String idAttribute);

    /**
     *
     * @param searchBase
     * @param searchFilter
     * @param searchScope
     * @param idAttribute
     * @param memberAttribute
     * @return
     */
    ILDAPAuthenticationManager setGroupSearchParameters(String searchBase, String searchFilter, LDAPSearchScope searchScope, String idAttribute, String memberAttribute);

    /**
     *
     * @return
     */
    int getUserCount();

    /**
     *
     * @return
     */
    int getUserGroupCount();

    /**
     *
     * @param username
     * @param password
     * @return
     */
    LDAPUser authenticate(String username, String password);
}
