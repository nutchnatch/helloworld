package com.ossnms.bicnet.securitymanagement.persistence.model.policy;

import com.ossnms.bicnet.securitymanagement.persistence.model.BaseUSMEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import java.util.List;

/**
 * Permission is a set of Permission Items
 */
@Entity
@Table(
        name = "USM_PERMISSION",
        uniqueConstraints = {
                @UniqueConstraint( columnNames = { "NAME" })
        }
)
@NamedQueries({
        @NamedQuery(name = "usmPermission.findByName", query = "from USMPermission p where p.name = :name"),
})
public class USMPermission extends BaseUSMEntity{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "USMPermissionSequence")
    @SequenceGenerator(name = "USMPermissionSequence", sequenceName = "USM_SEQ_PERMISSION")
    @Column(name = "ID")
    private Integer id;

    @Column(name = "NAME", nullable = false, unique = true)
    private String name;

    @Column(name = "LABEL", nullable = false)
    private String label;

    /**
     * Defaults to <code>FetchType.LAZY</code>
     * Requires a call to Hibernate.initialize(...)
     */
    @ManyToMany
    @JoinTable(
            name = "USM_PERMISSION_PERMISSION_ITEM",
            joinColumns = @JoinColumn(name="PERMISSION_ID", referencedColumnName="ID"),
            inverseJoinColumns = @JoinColumn(name="PERMISSION_ITEM_ID", referencedColumnName="ID")
    )
    private List<USMPermissionItem> permissionItems;

    /**
     * Implement this method to inform is the object is new or not.
     * e.g. when the id is a long, the object is new if the id == 0
     *
     * @return
     */
    @Override
    public boolean isNew() {
        return id == null || id == 0;
    }

    /**
     *
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     *
     */
    public String getName() {
        return name;
    }

    /**
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     */
    public String getLabel() {
        return label;
    }

    /**
     * @param label
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     *
     */
    public List<USMPermissionItem> getPermissionItems() {
        return permissionItems;
    }

    /**
     * @param permissionItems
     */
    public void setPermissionItems(List<USMPermissionItem> permissionItems) {
        this.permissionItems = permissionItems;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj){
            return true;
        }
        if (obj == null){
            return false;
        }
        if (getClass() != obj.getClass()){
            return false;
        }
        USMPermission other = (USMPermission) obj;
        if (name == null) {
            if (other.name != null){
                return false;
            }
        } else if (!name.equals(other.name)){
            return false;
        }

        return true;
    }
}
