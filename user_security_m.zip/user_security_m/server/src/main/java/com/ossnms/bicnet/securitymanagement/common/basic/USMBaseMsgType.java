/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMBaseMsgType
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 10-Feb-2005	Asif 			CF001042 - Connect to LDAP Service
 * 05-May-2005  Muyeen M        CF001312   Master-Master Replication for Sun ONE DS
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.basic;

import java.io.Serializable;

import org.apache.log4j.Logger;

/**
*
* The Client Interactor need to register with the Notification Handler and
* tell what is the type of the notification that they are intereseted in.
* 
* It could be possible to send a string which can be used for comparision
* but this is error prone. Therefore the Notification Handler will always 
* take an object which is of USMBaseMsgType.
*  
*/
public class USMBaseMsgType implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    /**
     * Data member to hold the string which decides the message type 
     */
    private String strMsgType;

    private static final Logger LOGGER = Logger.getLogger(USMBaseMsgType.class);

    /**
     * Constructor. 
     * @param p_strMsgType
     * 			The String which indicates the type of the message
     */
    public USMBaseMsgType(String p_strMsgType) {
        strMsgType = p_strMsgType;
    }

    /**
     * Function to return the String equivalent of the type. This is
     * used by the notification handler to filter out notifications and
     * give it to the interested listeners
     * 
     * @return String equivalent of the type.
     */
    public final String getMsgType() {
        return strMsgType;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        return strMsgType.hashCode();
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        boolean bEquals = false;
        if (obj instanceof USMBaseMsgType) {
            USMBaseMsgType msgType = (USMBaseMsgType) obj;
            if (strMsgType.compareTo(msgType.strMsgType) == 0) {
                LOGGER.debug("Comparision succeded.");
                bEquals = true;
            }
        }
        return bEquals;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return strMsgType;
    }

    /**
     * Message primitives
     */
    public static final USMBaseMsgType BASIC_LDAP_RECONNECT =
        new USMBaseMsgType("LDAP_Reconnect");

    public static final USMBaseMsgType BASIC_SERVER_SHUTDOWN =
        new USMBaseMsgType("SERVER_SHUTDOWN");

    public static final USMBaseMsgType BASIC_SERVER_REINITIALIZED =
        new USMBaseMsgType("SERVER_REINITIALIZED");

    public static final USMBaseMsgType CLOSE_WINDOWS_AFTER_LDAP_SYNC =
        new USMBaseMsgType("CLOSE_WINDOWS_AFTER_LDAP_SYNC");

}
