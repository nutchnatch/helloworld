package com.ossnms.bicnet.securitymanagement.common.auth;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

/**
 * This class stores the messages that get displayed. It is also used to pass the id which from the server and needs to
 * be mapped to a string on the client side
 */
public final class AAUserMessages {
    private static final Logger LOGGER = Logger.getLogger(AAUserMessages.class);

    /**
     * This is used in order to allocate for HashMap the necessary memory space to hold the error messages.
     */
    private static final int NUMBER_OF_MESSAGES = 19;
    
    /**
     * Ids for error messages.
     */
    public static final Integer AA_NO_ERROR = 0;
    public static final Integer AA_INTERNAL_ERROR = 1;
    public static final Integer AA_LOGIN_INVALID = 2;
    public static final Integer AA_ERR_PASSWORD_LDAP = 3;
    public static final Integer AA_ERR_USER_NOT_LOGGED = 4;
    public static final Integer AA_ERR_USER_CANNOT_CHANGED = 5;
    public static final Integer AA_ERR_PASSWORD_COMPLEXITY = 6;
    public static final Integer AA_ERR_PASSWORD_COMPLEXITY_ERROR = 6;
    public static final Integer AA_ERR_PASSWORD_SAME_AS_USERID = 7;
    public static final Integer AA_ERR_PASSWORD_LENGTH = 8;
    public static final Integer AA_ERR_PASSWORD_CONSECUTIVE_CHARACTERS = 9;
    public static final Integer AA_ERR_PASSWORD_CONTAINS_UID = 10;
    public static final Integer AA_ERR_PASSWORD_CIRCULAR_UID = 11;
    public static final Integer AA_ERR_PASSWORD_SAME_N_CHARS = 12;

    public static final Integer AA_ERR_AUTHENTICATION = 13;
    public static final Integer AA_ERR_NAMING_SERVICE_UNAVAILABLE = 14;
    public static final Integer AA_ERR_ACCOUNT_DISABLED = 16;
    public static final Integer AA_ERR_ACCOUNT_LOCKED = 17;
    public static final Integer AA_ERR_PASSWORD_NOT_COMPLIANT_WITH_RULES = 18;
    
    private final Map<Integer, String> mapOfIdsVersusString;
    private static AAUserMessages instance= new AAUserMessages();

    /**
     * This is a protection mechanism offered, in case the id is not mapped to a string, in which case the caller may
     * fail when trying to print the string
     */
    public static final String BLANK = " ";

    /**
     * Default constructor
     */
    private AAUserMessages() {
        LOGGER.debug("AAUserMessages() Entry");

        mapOfIdsVersusString = new HashMap<Integer, String>(NUMBER_OF_MESSAGES);
        init();

        LOGGER.debug("AAUserMessages() Exit");
    }
    
    /**
     * Access to the singleton class
     * 
     * @return DCErrorMessage singleton class
     */
    public static synchronized AAUserMessages getInstance() {
        LOGGER.debug("getInstance() Entry & Exit");

        return instance;
    }

    public void init() {
        LOGGER.debug("init() Entry");

        mapOfIdsVersusString.put(AA_NO_ERROR, "No Error.");
        mapOfIdsVersusString.put(AA_INTERNAL_ERROR, "There was an internal error which has occured." + "Check the traces and report the error.");
        mapOfIdsVersusString.put(AA_LOGIN_INVALID, "The old password that you have entered is incorrect or your account is invalid.");

        mapOfIdsVersusString.put(AA_ERR_PASSWORD_LDAP, "The password could not be modified.\nIt matches one of the previous 5 passwords, or an error occured.");
        mapOfIdsVersusString.put(AA_ERR_USER_NOT_LOGGED, "Error.\nUser has not logged in.");
        mapOfIdsVersusString.put(AA_ERR_USER_CANNOT_CHANGED, "You can not change your password :\nContact the Administrator");
        mapOfIdsVersusString.put(AA_ERR_PASSWORD_COMPLEXITY, "Error.\nPassword doesnot match the complexity rules.Check the password complexity rules.");
        mapOfIdsVersusString.put(AA_ERR_PASSWORD_COMPLEXITY_ERROR, "Password should contain at least two alphabets, one numeric\n" + " and one special character other than #,$,*,/,@");
        mapOfIdsVersusString.put(AA_ERR_PASSWORD_SAME_AS_USERID, "Password should not be the same as your user id.");
        mapOfIdsVersusString.put(AA_ERR_PASSWORD_LENGTH, "Password should be at least 8 characters long.");
        mapOfIdsVersusString.put(AA_ERR_PASSWORD_CONSECUTIVE_CHARACTERS, "Password should not contain more than 3 consecutive digits or alphabets.");
        mapOfIdsVersusString.put(AA_ERR_PASSWORD_CONTAINS_UID, "Password should not contain userid either in reverse or in circular.");
        mapOfIdsVersusString.put(AA_ERR_PASSWORD_CIRCULAR_UID, "Password should not contain userid either in reverse or in circular.");
        mapOfIdsVersusString.put(AA_ERR_PASSWORD_SAME_N_CHARS, "The new password should differ by your old password by at least 3 characters.");
        
        mapOfIdsVersusString.put(AA_ERR_AUTHENTICATION, "The old password entered is invalid. Password could not be changed.");
        mapOfIdsVersusString.put(AA_ERR_NAMING_SERVICE_UNAVAILABLE, "Directory server is not available. Password could not be changed.");
        mapOfIdsVersusString.put(AA_ERR_ACCOUNT_DISABLED, "You account is disabled. Password could not be changed.");
        mapOfIdsVersusString.put(AA_ERR_ACCOUNT_LOCKED, "You account is locked for exceeding wrong password retries. Password could not be changed.");
        mapOfIdsVersusString.put(AA_ERR_PASSWORD_NOT_COMPLIANT_WITH_RULES, "Password is not compliant with the defined rules.\nPlease check the available documentation.");

        LOGGER.debug("init() Exit");
    }

    /**
     * Function to retrieve the displayable error string given the error id
     * 
     * @param id
     *            The id whose corresponding string has to be fetched
     * @return java.lang.String Returns a user displayable string corresponding to the id
     */
    public String getString(Integer id) {
        LOGGER.debug("getString() Entry");

        String message = BLANK;

        if (mapOfIdsVersusString != null) {
            message = mapOfIdsVersusString.get(id);
        }

        if (message == null) {
            message = BLANK;
        }

        LOGGER.debug("getString() Exit");

        return message;
    }
}