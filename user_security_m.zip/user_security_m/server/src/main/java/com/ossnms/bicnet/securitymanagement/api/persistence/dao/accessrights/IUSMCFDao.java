package com.ossnms.bicnet.securitymanagement.api.persistence.dao.accessrights;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.IBaseDAO;
import com.ossnms.bicnet.securitymanagement.persistence.model.accessrights.USMCF;

/**
 * created on 24/9/2014
 */
public interface IUSMCFDao extends IBaseDAO<USMCF, String> {
    void loadSecurableElements(USMCF cf);
    void loadSecurableElementContainers(USMCF cf);
}
