/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	PAMessageType
 * Author      	Vinay purohit
 * Substitute	muyeen
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID	:	TNMS.DX2.SM.POLICY.VIEW
 * 			:	TNMS.DX2.SM.POLICY.ADMIN
 * 			:	TNMS.DX2.SM.POLICY.CREATE
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.common.policy;

import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;

/**
 * This class holds String representation for notification of policy related operation.
 * Whenever notification recieved from the server, 
 * depending on message type, appropraite action takes place.
 */
public final class PAMessageType {

	/**
	 * Private hidden constructor
	 */
	private PAMessageType(){

	}
	/**
	 * String representation for policy not created message
	 */
	public static final USMBaseMsgType S_PA_REQ_POLICY_DELETED =
		new USMBaseMsgType("PA_REQ_POLICY_DELETE");

	/**
	 * String representation for policy not created message
	 */
	public static final USMBaseMsgType S_PA_REQ_GET_CONFIGURED_POLICIES =
		new USMBaseMsgType("PA_REQ_GET_CONFIGURED_POLICIES");

	/**
	 * String representation for policy not created message
	 *
	 * @deprecated referring to Menu Options, which do not exist
	 */
	@Deprecated
	public static final USMBaseMsgType S_PA_REQ_GET_ALL_MENU_OPTIONS =
		new USMBaseMsgType("PA_REQ_GET_ALL_MENU_OPTIONS");

	/**
	 * String representation for policy not created message
	 * @deprecated referring to Menu Options, which do not exist
	 */
	@Deprecated
	public static final USMBaseMsgType S_PA_REQ_GET_CONFIG_NON_CONFIG_MENUS =
		new USMBaseMsgType("PA_REQ_GET_CONFIG_NON_CONFIG_MENUS");

	/**
	 * String representation for policy retrieve used and non-used permissions
	 */
	public static final	USMBaseMsgType S_PA_REQ_GET_POLICY_INFORMATION =
			new USMBaseMsgType("PA_REQ_GET_POLICY_INFORMATION");

	/**
	 * String representation for policy not created message
	 * @deprecated referring to Menu Options, which do not exist
	 */
	@Deprecated
	public static final USMBaseMsgType S_PA_REQ_MENU_OPTIONS_FOR_POLICY =
		new USMBaseMsgType("PA_REQ_MENU_OPTIONS_FOR_POLICY");

	/**
	 * String representation for policy not created message
	 */
	public static final	USMBaseMsgType S_PA_REQ_GET_ALL_PERMISSIONS =
		new USMBaseMsgType("PA_REQ_GET_ALL_PERMISSIONS");

	public static final USMBaseMsgType S_PA_REQ_GET_ALL_PERMISSIONS_FOR_POLICY =
		new USMBaseMsgType("PA_REQ_GET_ALL_PERMISSIONS_FOR_POLICY");

	/**
	 * String representation for policy not created message
	 */
	public static final USMBaseMsgType S_PA_REQ_MODIFY_POLICY =
		new USMBaseMsgType("PA_REQ_MODIFY_POLICY");

	/**
	 * String representation for policy not created message
	 */
	public static final USMBaseMsgType S_PA_NOT_POLICY_CREATED =
		new USMBaseMsgType("PA_NOT_POLICY_CREATED");
	/**
	 * String representation for notification for non deletion of policy
	 */
	public static final USMBaseMsgType S_PA_NOT_POLICY_DELETED =
		new USMBaseMsgType("PA_NOT_POLICY_DELETED");
	/**
	 * String representation for notification for non modification of policy
	 */
	public static final USMBaseMsgType S_PA_NOT_POLICY_MODIFIED =
		new USMBaseMsgType("PA_NOT_POLICY_MODIFIED");
	/**
	 * String representation for notification for modification of server insertion
	 */
	public static final USMBaseMsgType S_PA_NOT_SERVER_INSERTED =
		new USMBaseMsgType("PA_NOT_SERVER_INSERTED");

	/**
	 * String representation for notification for modification of removal of server
	 */
	public static final USMBaseMsgType S_PA_NOT_SERVER_REMOVED =
		new USMBaseMsgType("PA_NOT_SERVER_REMOVED");

	/**
		 * String representation for notification for create policy
		 */
	public static final USMBaseMsgType S_PA_RES_POLICY_CREATED =
		new USMBaseMsgType("PA_RES_POLICY_CREATED");
	/**
	 * String representation for notification for deletion of policy
	 */
	public static final USMBaseMsgType S_PA_RES_POLICY_DELETED =
		new USMBaseMsgType("PA_RES_POLICY_DELETED");

	/**
	 *
	 */
	public static final USMBaseMsgType S_PA_RES_GET_POLICY_INFORMATION =
			new USMBaseMsgType("PA_RES_GET_POLICY_INFORMATION");

	/**
	 * String representation for notification for modification of policy
	 */
	public static final USMBaseMsgType S_PA_RES_POLICY_MODIFIED =
		new USMBaseMsgType("PA_RES_POLICY_MODIFIED");

	/**
	 * String representation for notification for modification of server insertion
	 */
	public static final USMBaseMsgType S_PA_POLICY_ERROR =
		new USMBaseMsgType("PA_POLICY_ERROR");

	/**
	 * String representation for notification for modification of removal of server
	 */
	public static final USMBaseMsgType S_PA_RES_POLICY_RECEIVED =
		new USMBaseMsgType("PA_RES_POLICY_RECEIVED");

	public static final USMBaseMsgType S_PA_RES_ALL_PERMISSION_RECEIVED =
			new USMBaseMsgType("PA_RES_ALL_PERMISSION_RECEIVED");

	public static final USMBaseMsgType S_PA_RES_ALL_PERMISSION_ITEM_RECEIVED =
			new USMBaseMsgType("PA_RES_ALL_PERMISSION_ITEM_RECEIVED");

	public static final USMBaseMsgType S_PA_RES_ALL_PERMISSION_POLICY_RECEIVED =
			new USMBaseMsgType("PA_RES_ALL_PERMISSION_POLICY_RECEIVED");

	public static final USMBaseMsgType S_PA_RES_ALL_PERMISSION_ITEM_POLICY_RECEIVED =
			new USMBaseMsgType("PA_RES_ALL_PERMISSION_ITEM_POLICY_RECEIVED");

	public static final USMBaseMsgType S_PA_RES_ALL_PERMISSION_ITEM_PERMISSION_RECEIVED =
			new USMBaseMsgType("PA_RES_ALL_PERMISSION_ITEM_PERMISSION_RECEIVED");

	/**
	 * String representation for notification for modification of removal of server
	 * @deprecated referring to Menu Options, which do not exist
	 */
	@Deprecated
	public static final USMBaseMsgType S_PA_RES_ALL_MENU_POLICY_RECEIVED =
		new USMBaseMsgType("PA_RES_ALL_MENU_POLICY_RECEIVED");
	/**
	 * String representation for notification for modification of removal of server
	 * @deprecated referring to Menu Options, which do not exist
	 */
	@Deprecated
	public static final USMBaseMsgType S_PA_RES_MENU_FOR_POLICY_RECEIVED =
		new USMBaseMsgType("PA_RES_MENU_FOR_POLICY_RECEIVED");
	/**
	 * String representation for notification for modification of removal of server
	 */
	public static final USMBaseMsgType S_PA_RES_POLICY_CONFIGNONCONFIG_MENU_RECEIVED =
		new USMBaseMsgType("PA_RES_CONFIGNONCONFIG_MENU_RECEIVED");
}
