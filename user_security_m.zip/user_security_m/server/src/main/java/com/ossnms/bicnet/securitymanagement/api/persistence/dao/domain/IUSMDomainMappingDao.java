package com.ossnms.bicnet.securitymanagement.api.persistence.dao.domain;

import com.ossnms.bicnet.securitymanagement.api.persistence.dao.IBaseDAO;
import com.ossnms.bicnet.securitymanagement.persistence.model.domain.USMDomainMapping;

import java.util.List;

/**
 * created on 28/8/2014
 */
public interface IUSMDomainMappingDao extends IBaseDAO<USMDomainMapping, Integer> {
    USMDomainMapping findByName(String name);
    List<USMDomainMapping> findByDomain(int domainId);
    List<USMDomainMapping> findByPolicy(int policyId);
    List<USMDomainMapping> findByUserGroup(String userGroup);
}
