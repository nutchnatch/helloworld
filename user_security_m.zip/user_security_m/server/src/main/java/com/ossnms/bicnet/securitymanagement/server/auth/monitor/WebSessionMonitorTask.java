package com.ossnms.bicnet.securitymanagement.server.auth.monitor;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.server.auth.AASessionStore;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityAuthenticationPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.logging.LMInterFace;
import com.ossnms.bicnet.securitymanagement.server.servicelocator.USMServiceLocator;
import com.ossnms.bicnet.securitymanagement.server.useradministration.UASubsystemSAP;
import com.ossnms.bicnet.util.UnexpectedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.TimerTask;
import java.util.function.Consumer;
import java.util.function.Predicate;

import static com.ossnms.bicnet.securitymanagement.api.server.auth.SessionType.WEB;

/**
 *
 */
public final class WebSessionMonitorTask extends TimerTask {
    /**
     * Logger for this class
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(WebSessionMonitorTask.class);

    private static final long MINUTE = 60 * 1000;
    private static final long HOUR = 60 * MINUTE;

    static final long S_PERIOD = 5 * MINUTE;                    // timer will run every 5 minutes
    public static final long TIMEOUT_ABSOLUTE = 4 * HOUR;      // absolute timeout is 4 hours

    @Override
    public void run() {
        LOGGER.info(">>> Running Web Session Monitorization Task...");

        List<ISessionContext> sessions = AASessionStore.getInstance().getAllWebUserSessions();

        LOGGER.info("Found {} valid user sessions.", sessions.size());

        sessions.stream()
                .filter (invalidUserSessions())
                .map(sessionContext -> (IEnhancedSessionContext) sessionContext)
                .forEach(logoutConsumer());

        LOGGER.info(">>> Finished.");
    }

    /**
     * Predicate to retrieve only user sessions
     * @return a predicate which returns true if the user session is invalid; false otherwise;
     */
    private Predicate<ISessionContext> invalidUserSessions() {
        return sessionContext -> {
            AASessionStore instance = AASessionStore.getInstance();
            AAServerSessionMonitor monitoringBean = instance.getMonitoringBean(sessionContext, WEB);

            if(monitoringBean == null) {
                // the session was already terminated. Remove from the store
                instance.removeUserSession(sessionContext);
                return false;
            }

            long currentTime = System.currentTimeMillis();

            // check for absolute timeout
            long elapsedTimeSinceLogin = currentTime - monitoringBean.getFirstLoginTime();
            if(elapsedTimeSinceLogin > TIMEOUT_ABSOLUTE) {
                LOGGER.warn("Session {} from user {} will be terminated due to absolute timeout.",
                        sessionContext.getUniqId(),
                        sessionContext.getUserName()
                );
                return true;
            }

            long elapsedTimeSinceRequest = currentTime - monitoringBean.getLastRequestTime();
            long timeoutRelative = UASubsystemSAP.getInactivityTimeout(sessionContext.getUserName());
            if(timeoutRelative != 0 && elapsedTimeSinceRequest > timeoutRelative) {
                LOGGER.warn("Session {} from user {} will be terminated due to relative timeout (inactivity).",
                        sessionContext.getUniqId(),
                        sessionContext.getUserName()
                );
                return true;
            }

            return false;
        };
    }

    /**
     *
     * @return
     */
    private Consumer<IEnhancedSessionContext> logoutConsumer() {
        return sessionContext -> {
            LOGGER.debug("Logging off user {} due to inactivity.", sessionContext.getUserName());

            // creating security system event record
            String format = USMCommonStrings.IDS_AA_CLIENT_UNAVAILABLE + "%s" + USMCommonStrings.IDS_AA_WEB_ADDRESS + "%s" + USMCommonStrings.IDS_AA_WEB_TIMEOUT;

            // security system event record
            LMInterFace.getInstance().createSecuritySystemEventRecord(
                    sessionContext,
                    String.format(format, sessionContext.getUserName(), sessionContext.getClientMachineName()),
                    LogSeverity.WARNING, sessionContext.getClientMachineName());

            // log off the user
            USMServiceLocator servLoc = USMServiceLocator.getInstance();
            try {
                ISecurityAuthenticationPrivateFacade fcd = servLoc.getSecurityAuthenticationPrivateFacade();
                if (fcd != null) {
                    fcd.logoff(sessionContext);
                } else {
                    LOGGER.error("Returned private facade is null");
                }
            } catch (UnexpectedException | BcbSecurityException e) {
                LOGGER.error("An exception was thrown", e);
            }
        };
    }
}
