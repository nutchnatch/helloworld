package com.ossnms.bicnet.securitymanagement.client.importexport.migration;

import org.junit.Before;
import org.junit.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;

import static com.ossnms.bicnet.securitymanagement.client.importexport.IETagNames.POLICY;
import static com.ossnms.bicnet.securitymanagement.client.importexport.IETagNames.POLICY_NAME;
import static com.ossnms.bicnet.securitymanagement.client.importexport.IETagNames.POLICY_PERMISSION;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.DEFAULT_POLICIES_NAMES;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class PolicyMigrationTest {

    PolicyMigration policyMigration;
    
    @Before
    public void init() throws ParserConfigurationException, SAXException, IOException{
        InputStream importExportFileStream = this.getClass().getResourceAsStream("/import_export.xml");
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        
        Document dom = db.parse(importExportFileStream);
        policyMigration = new PolicyMigration(dom.getDocumentElement());
    }
    
    @Test
    public void testRemoveMenuOptions() {
        policyMigration.removeMenuOptions();
        String documentText = xmlToString(policyMigration.getElement());
        assertTrue(documentText.contains("<Permission>Leeks</Permission>"));
        assertTrue(documentText.contains("<Permission>Celery</Permission>"));
        assertFalse(documentText.contains("<Permission>Cabbages</Permission>"));
        assertFalse(documentText.contains("<Permission>Turnips</Permission>"));
        assertTrue(policyContainsMenu("TNMSAdministration", "Ferrari"));
        assertFalse(policyContainsMenu("TNMSConfiguration", "Ferrari"));

    }

    @Test
    public void testUpdateMenuOptions() {
        policyMigration.updateMenuOptions();
        String documentText = xmlToString(policyMigration.getElement());
        assertTrue(documentText.contains("<Permission>Onions</Permission>"));
        assertTrue(documentText.contains("<Permission>Brussel-&gt;Sprouts</Permission>"));
        assertFalse(documentText.contains("<Permission>Leeks</Permission>"));
        assertFalse(documentText.contains("<Permission>Runner-&gt;Beans</Permission>"));
    }
    
    @Test
    public void testAddMenuOptions() {
        for (String policy: DEFAULT_POLICIES_NAMES) {
            policyMigration.addMenuOptions(policy);
        }
        assertTrue(policyContainsMenu("TNMSAdministration", "Butternut->Squash")); // Don't escape the chevrons as we are not converting the XML to text.
        assertTrue(policyContainsMenu("TNMSAdministration", "Network->DCN->Deactivate EMs"));
        assertTrue(policyContainsMenu("TNMSMaintenance", "Beetroot"));
    }
    
    @Test
    public void testMigrate() {
        policyMigration.migrate();
        String documentText = xmlToString(policyMigration.getElement());
        assertFalse(documentText.contains("<Permission>Cabbages</Permission>"));
        assertFalse(documentText.contains("<Permission>Turnips</Permission>"));
        assertTrue(documentText.contains("<Permission>Onions</Permission>"));
        assertTrue(documentText.contains("<Permission>Brussel-&gt;Sprouts</Permission>"));
        assertFalse(documentText.contains("<Permission>Leeks</Permission>"));
        assertFalse(documentText.contains("<Permission>Runner-&gt;Beans</Permission>"));
        assertTrue(policyContainsMenu("TNMSAdministration", "Butternut->Squash")); // Don't escape the chevrons as we are not converting the XML to text.
        assertTrue(policyContainsMenu("TNMSAdministration", "Network->DCN->Deactivate EMs"));
        assertTrue(policyContainsMenu("TNMSMaintenance", "Beetroot"));
    }
    
    
    /**
     * Check to see if a given policy contains the given menu option.
     * 
     * @param policy
     * @param menu
     * @return
     */
    private boolean policyContainsMenu(String policy, String menu) {
        
        Element element = policyMigration.getElement();
        NodeList policyNodes = element.getElementsByTagName(POLICY);

        // Loop through all the policy tags
        for (int i=0; i < policyNodes.getLength(); i++) {
            Node policyNode = policyNodes.item(i);
            
            // Get the <name> tag
            if (((Element)policyNode).getElementsByTagName(POLICY_NAME).item(0).getFirstChild().getNodeValue().equals(policy)) {
                // Loop through the menu entries
                NodeList policyChildNodes = policyNode.getChildNodes();
                for (int j=0; j < policyChildNodes.getLength(); j++) {
                    if (policyChildNodes.item(j).getNodeName().equals(POLICY_PERMISSION) && policyChildNodes.item(j).getFirstChild().getNodeValue().equals(menu)) {
                        return true;
                    }
                }
                return false;
            }
        }
        return false;
    }
    
    /**
     * Utility method for converting a node object to an XML String.
     * @param node DOM node to be converted.
     * @return XML String representation of the Node
     */
    private static String xmlToString(Node node) {
        try {
            Source source = new DOMSource(node);
            StringWriter stringWriter = new StringWriter();
            Result result = new StreamResult(stringWriter);
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            transformer.transform(source, result);
            return stringWriter.getBuffer().toString();
        } catch (TransformerConfigurationException e) {
            e.printStackTrace();
        } catch (TransformerException e) {
            e.printStackTrace();
        }
        return null;
    }
}
