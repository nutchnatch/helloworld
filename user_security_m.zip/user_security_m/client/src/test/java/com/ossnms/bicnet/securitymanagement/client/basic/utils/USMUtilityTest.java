package com.ossnms.bicnet.securitymanagement.client.basic.utils;

import static org.junit.Assert.*;

import org.junit.Test;

public class USMUtilityTest {

    @Test
    public void testIsEMailValidInvalid() {
        assertFalse(USMUtility.isEMailValid("Hello"));
        assertFalse(USMUtility.isEMailValid("Goodbye@"));
        assertFalse(USMUtility.isEMailValid("@Goodbye"));
        assertFalse(USMUtility.isEMailValid("\"goodbye@hello.com"));
    }

    @Test
    public void testIsEMailValidValid() {
        assertTrue(USMUtility.isEMailValid("a@a.com"));
        assertTrue(USMUtility.isEMailValid("tom.jones@xyz.com"));
        assertTrue(USMUtility.isEMailValid("barack_obama@president.com"));
        assertTrue(USMUtility.isEMailValid("goodbye@hello.co.uk"));
    }

    @Test
    public void testIsTelephoneValidEmpty() {
        assertTrue(USMUtility.isTelephoneValid(""));
    }
    
    @Test
    public void testIsTelephoneValidStartNumber() {
        assertTrue(USMUtility.isTelephoneValid("3test"));
    }
    
    @Test
    public void testIsTelephoneValidStartLetterNumber() {
        assertTrue(USMUtility.isTelephoneValid("letter3"));
    }
    
    @Test
    public void testIsTelephoneValidInvalid() {
        assertFalse(USMUtility.isTelephoneValid("Hello"));
    }
    
    @Test
    public void testIsFaxValidEmpty() {
        assertTrue(USMUtility.isFaxValid(""));
    }
    
    @Test
    public void testIsFaxValidStartNumber() {
        assertTrue(USMUtility.isFaxValid("3_João"));
    }
    
    @Test
    public void testIsFaxValidStartLetterUC() {
        assertTrue(USMUtility.isFaxValid("Sérgio-8"));
    }
    
    @Test
    public void testIsFaxValidStartLetterLC() {
        assertTrue(USMUtility.isFaxValid("catarina-8"));
    }
    
    @Test
    public void testIsFaxValidStartSymbol() {
        assertTrue(USMUtility.isFaxValid("'123"));
        assertTrue(USMUtility.isFaxValid("(123"));
        assertTrue(USMUtility.isFaxValid(")123"));
        assertTrue(USMUtility.isFaxValid("+123"));
        assertTrue(USMUtility.isFaxValid(",123"));
        assertTrue(USMUtility.isFaxValid("-123"));
        assertTrue(USMUtility.isFaxValid(".123"));
        assertTrue(USMUtility.isFaxValid("=123"));
    }

    @Test
    public void testIsFaxValidInvalid() {
        assertFalse(USMUtility.isFaxValid("Ã problem"));
        assertFalse(USMUtility.isFaxValid("» problem"));
        assertFalse(USMUtility.isFaxValid("! problem"));
        assertFalse(USMUtility.isFaxValid("# problem"));
    }
}
