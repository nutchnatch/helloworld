package com.ossnms.bicnet.securitymanagement.client.importexport.migration;

import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.DEFAULT_POLICIES_NAMES;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.InputStream;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class PolicyMigrationDocumentTest {

    private PolicyMigrationDocument migrateDoc;

    @Before
    public void init() {
        InputStream migrationFileStream = this.getClass().getResourceAsStream("/policy_migration.xml");
        migrateDoc = new PolicyMigrationDocument();
        migrateDoc.loadValues(migrationFileStream);
    }

    @Test
    public void getMenusToAddTest() {
        List<String> administratorsMenusToAdd = migrateDoc.getMenusToAdd(DEFAULT_POLICIES_NAMES[0]);
        assertTrue(administratorsMenusToAdd.contains("Butternut->Squash"));
        assertFalse(administratorsMenusToAdd.contains("Potatoes"));

        List<String> maintenanceMenusToAdd = migrateDoc.getMenusToAdd(DEFAULT_POLICIES_NAMES[2]);
        assertTrue(maintenanceMenusToAdd.contains("Beetroot"));
    }

    @Test
    public void getMenusToRemoveTest() {
        assertTrue(migrateDoc.isMenuToBeRemoved("Policy", "Cabbages"));
        assertFalse(migrateDoc.isMenuToBeRemoved("Policy", "Carrots"));
        assertTrue(migrateDoc.isMenuToBeRemoved("Policy", "Turnips"));
    }

    @Test
    public void getNewNameForMenuTest() {
        assertTrue(migrateDoc.getNewNameForMenu("Leeks").equals("Onions"));
        assertNull(migrateDoc.getNewNameForMenu("Brocolli"));
    }
}
