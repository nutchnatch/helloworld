package com.ossnms.bicnet.securitymanagement.client.domain.common;

import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;

/**
 * Created by rcaldeir on 15-07-2016.
 */
public enum ServerTypeFilterEnum {

    COMMON_SERVICE_LIST	  (BiCNetComponentType.COMMON_SERVICE_LIST, SecurableObjectFilterEnum.NE),
    DCN_MANAGER           (BiCNetComponentType.DCN_MANAGER, SecurableObjectFilterEnum.SUBSCRIBERS);

    private BiCNetComponentType serverType;
    private SecurableObjectFilterEnum[] securableObjectTypes;

    /**
     *
     * @param serverType
     * @param securableObjectFilters
     */
    ServerTypeFilterEnum(BiCNetComponentType serverType, SecurableObjectFilterEnum... securableObjectFilters){
        this.securableObjectTypes = securableObjectTypes;
        this.serverType = serverType;
    }

    public SecurableObjectFilterEnum[] getSecurableObjectFilters(){
        return securableObjectTypes;
    }

    public BiCNetComponentType getServerType(){
        return serverType;
    }
}
