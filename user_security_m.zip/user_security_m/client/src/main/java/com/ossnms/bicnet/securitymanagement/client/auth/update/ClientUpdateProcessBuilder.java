package com.ossnms.bicnet.securitymanagement.client.auth.update;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.text.MessageFormat;

import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;

/**
 *
 */
public class ClientUpdateProcessBuilder {

    private static final Logger LOGGER = LoggerFactory.getLogger(ClientUpdateProcessBuilder.class);

    private static final String FILE_PATH_CLIENT_UPDATE = "upgrade" + File.separator + "client-update.jar";
    private static final String FILE_PATH_CLIENT_UPDATE_TEMP = "upgrade" + File.separator + "client-update-temp.jar";

    private static final String FORMAT_CLIENT_UPDATE_CMD = "java -Djavax.net.ssl.trustStore={4} -Djavax.net.ssl.trustStorePassword={5} -jar "+ FILE_PATH_CLIENT_UPDATE_TEMP +" --server_hostname={0} --client_version=\"{1}\" --server_version=\"{2}\" --ssl={3}";

    private static final String SYS_PROP_USE_SSL = "com.ossnms.bicnet.frontend.useSSL";
    private static final String SYS_PROP_TRUST_STORE = "javax.net.ssl.trustStore";
    private static final String SYS_PROP_TRUST_STORE_PASSWORD = "javax.net.ssl.trustStorePassword";

    private final String hostname;
    private final String clientVersion;
    private final String serverVersion;

    private boolean isSSL = false;
    private String trustStore = "";
    private String trustStorePassword = "";

    private String currentDirectory = ".";

    /**
     *
     * @param hostname
     * @param clientVersion
     * @param serverVersion
     */
    public ClientUpdateProcessBuilder(String hostname, String clientVersion, String serverVersion){
        this.hostname = hostname;
        this.clientVersion = clientVersion;
        this.serverVersion = serverVersion;

        this.isSSL = Boolean.getBoolean(SYS_PROP_USE_SSL);
        this.trustStore = System.getProperty(SYS_PROP_TRUST_STORE);
        this.trustStorePassword = System.getProperty(SYS_PROP_TRUST_STORE_PASSWORD);
    }

    /**
     *
     * @param currentDirectory
     * @return
     */
    public ClientUpdateProcessBuilder currentDirectory(String currentDirectory){
        this.currentDirectory = currentDirectory;
        return this;
    }

    /**
     *
     * @throws IOException
     */
    public void launch() throws IOException {
        ProcessBuilder pb;
        String cmdString = toString();
        String[] cmdLineArray = cmdString.split(" ");

        LOGGER.info("Launching Client Update {}", toString());

        // copy the file
        Files.copy(
                new File(FILE_PATH_CLIENT_UPDATE).toPath(),
                new File(FILE_PATH_CLIENT_UPDATE_TEMP).toPath(),
                REPLACE_EXISTING
        );

        // Lets now try splitting the string in spaces
        pb = new ProcessBuilder(cmdLineArray).directory(new File(currentDirectory));
        pb.start();
    }

    public String toString(){
        return MessageFormat.format(
                FORMAT_CLIENT_UPDATE_CMD,
                hostname,
                clientVersion,
                serverVersion,
                isSSL,
                trustStore,
                trustStorePassword
        );
    }
}
