package com.ossnms.tnms.securitymanagement.client.jobs;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.framework.client.helpers.FrameworkFetchJob;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDocument;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityGeneralSettingPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.servicelocator.USMServiceLocator;
import com.ossnms.bicnet.util.UnexpectedException;
import org.apache.log4j.Logger;

public class SecuritySettingsFetchJob extends FrameworkFetchJob {

    private static final Logger LOGGER = Logger.getLogger(SecuritySettingsFetchJob.class);

    private static final String ADDITIONAL_INFO = "Job to fetch data from server";
    private static final String ID = "com.ossnms.tnms.securitymanagement.client.jobs.SecuritySettingsFetchJob";
    private static final String NAME = "SecuritySettingsFetchJob";

    public SecuritySettingsFetchJob(IFrameworkDocument jobOwner) {
        super(ID, NAME, ADDITIONAL_INFO, jobOwner);
    }

    @Override
    public Object execute(Object arg0) throws FrameworkException {
        GSGeneralSettingData gs = null;

        try {
            ISecurityGeneralSettingPrivateFacade fcd = USMServiceLocator.getInstance().getSecurityGeneralSettingsPrivateFacade();
            gs = fcd.getGeneralSettingData(USMUtility.getInstance().getSessionContext());
        } catch (BcbSecurityException | UnexpectedException e) {
            LOGGER.error("Error retrieving data from server", e);
        }

        return gs;
    }

}
