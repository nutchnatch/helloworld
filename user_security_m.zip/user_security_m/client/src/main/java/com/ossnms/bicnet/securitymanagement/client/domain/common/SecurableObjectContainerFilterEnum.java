package com.ossnms.bicnet.securitymanagement.client.domain.common;

import com.ossnms.bicnet.bcb.model.ManagedObjectType;

public enum SecurableObjectContainerFilterEnum {

	NETWORK_DOMAIN	(ManagedObjectType.NETWORK_DOMAIN),
	MEDIATOR        (ManagedObjectType.EM),
	CONTAINER	    (ManagedObjectType.GENERIC_CONTAINER, ManagedObjectType.SYSTEM_CONTAINER);

	private ManagedObjectType[] managedObjectTypes;

	/**
	 *
	 * @param managedObjectTypes
     */
	SecurableObjectContainerFilterEnum(ManagedObjectType... managedObjectTypes){
		this.managedObjectTypes = managedObjectTypes;
	}

	/**
	 *
	 * @param objectType
	 * @return
     */
	public boolean isTypeValid(ManagedObjectType objectType){
		for(ManagedObjectType type : managedObjectTypes){
			if(type.equals(objectType)){
				return true;
			}
		}

		return false;
	}

}
