package com.ossnms.bicnet.securitymanagement.client.useradministration.usergroup.common;

import com.coriant.widgets.table.PComboBoxRenderer;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UACommonHelper;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.table.JfxTable;
import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class UAUserGroupDomainsAndPoliciesPane extends JPanel {
    private static final long serialVersionUID = 6793222867464132692L;

    private static final Logger LOGGER = Logger.getLogger(UAUserGroupDomainsAndPoliciesPane.class);

    // Stores the list of policy id name
    private List lstPolicyIDToName = null;

    // Hash map of policy id to policy name
    private Map mapPolicyIdToPolicyName;

    // Stored the available domains
    private List<DCDomainData> domains;

    // Hash map of domain id to domain name
    private Map<Integer, String> mapDomainIdToDomainName;

    // To make the second column a combo box
    private JComboBox policyComboBox;

    // Model which holds the mapping for the current mappings
    private UAUserGroupDomainMappingModel modelRights;

    // Table to hold the mappings. Jfx helps in sorting and filtering
    private JfxTable tblRights;

    // String for displaying NONE, otherwise, i have to keep calling this function
    public static final String NOACCESS = JfxStringTable.getString(USMStringTable.IDS_DC_NOACCESS);
    public static final String NOVISIBILITY = JfxStringTable.getString(USMStringTable.IDS_DC_NOVISIBILITY);

    private boolean isAdminGroup = false;

    public UAUserGroupDomainsAndPoliciesPane() {
        // domain = p_domain; TODO: handle user group
        mapPolicyIdToPolicyName = new HashMap();

        initComponents();
        setNamesForTesting();
    }

    /**
     * Helper function that is used to set the Names of all the editable components within the Tab. Strings in this function are not to be Internationalized.
     */
    private void setNamesForTesting() {
        tblRights.setName("AssignPolicyForDomain");
    }

    private void initComponents() {
        LOGGER.debug("initComponents() - Enter");

        this.setLayout(new GridBagLayout());
        setPreferredSize(new Dimension(350, 320));
        setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);
        
        modelRights = new UAUserGroupDomainMappingModel();
        tblRights = new JfxTable(modelRights);
        tblRights.setSortable(true);
        tblRights.setFilterable(false);
        tblRights.setHeaderToolTipsEnabled(true);
        tblRights.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        // Allow horizontal scrollbar
        tblRights.setAutoResizeMode(JfxTable.AUTO_RESIZE_ALL_COLUMNS);

        JScrollPane scrPaneRights = new JScrollPane(tblRights);
        scrPaneRights.setPreferredSize(new Dimension(250, 200));

        this.add(scrPaneRights, new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0, GridBagConstraints.WEST, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));

        LOGGER.debug("initComponents() - Exit");
    }

    /**
     * This is a helper method to set up the entries of the combo.
     * 
     * @param policyColumn
     *            The column where in the combo is to be displayed.
     * @param mapPolicies
     *            Map of policy id versus the policy name.
     */
    private void setUpPolicyColumnCombo(TableColumn policyColumn, Map mapPolicies) {
        LOGGER.debug("setUpPolicyColumnCombo() - Entry");

        // Set up the editor for the Policy cells.
        policyComboBox = new JComboBox();
        
        Iterator itKeys = mapPolicies.keySet().iterator();
        while (itKeys.hasNext()) {
            String strPolicy = (String) mapPolicies.get(itKeys.next());
            // This is to make sure that None is the Last entry in the Combo Box The user can create a policy named as none.
            // If he is not supposed to then, this will add an additional check if uncommented
            if (strPolicy.compareTo(NOACCESS) != 0 && strPolicy.compareTo(NOVISIBILITY) != 0 ) {
                policyComboBox.addItem(strPolicy);
            }
        }
        policyComboBox.addItem(NOVISIBILITY);
        policyComboBox.addItem(NOACCESS);
        policyColumn.setCellEditor(new DefaultCellEditor(policyComboBox));
        policyColumn.setCellRenderer(new PComboBoxRenderer());
        LOGGER.debug("setUpPolicyColumnCombo() - Exit");
    }

    /**
     * Initializes the tab with the domain mappings fetched initially.
     * 
     * @param p_mappings
     *            The list of domain mappings.
     * @param policyIDToName
     *            The list of policy id versus the policy name.
     * @param domains
     *            The list of available domains
     */
    public void populateMappings(List<DCDomainMapping> mappings, List<PAPolicyId> policyIDToName, List<DCDomainData> domainsList) {
        LOGGER.debug("populateMappings() - Enter");

        lstPolicyIDToName = policyIDToName;
        mapPolicyIdToPolicyName = createMapOfPolicyIDToPolicyName(lstPolicyIDToName);

        domains = domainsList;
        mapDomainIdToDomainName = createMapOfDomainIdToDomainName(domainsList);
        
        List arrDisplay = getDisplayableArrayList(mappings);
        modelRights.data.addAll(arrDisplay);
        
		if (isAdminGroup) {
			modelRights.setCellEditToDisable();
		} else {
			setUpPolicyColumnCombo(tblRights.getColumnModel().getColumn(1),mapPolicyIdToPolicyName);
		}

        modelRights.fireTableDataChanged();

        LOGGER.debug("populateMappings() - Exit");
    }

    /**
     * This function is responsible to convert the data that has been passed into the Displayable Data.
     * 
     * @param p_mappings
     *            The mappings which has to be displayed.
     * @return Returns a list of DCDomainMappingTableData for display.
     */
    private List getDisplayableArrayList(List<DCDomainMapping> mappings) {
        LOGGER.debug("getDisplayableArrayList() - Enter");

        List arrTableData = new ArrayList();
        for (DCDomainMapping mapping : mappings) {
        	if(mapping.getUserGroup().equalsIgnoreCase(UACommonHelper.ADMIN_GROUP_NAME)){
        		isAdminGroup = true;
        	}
            Integer nDomainId = mapping.getDomainID();
            String strDomain = mapDomainIdToDomainName.get(nDomainId);
            Integer nPolicyID = mapping.getPolicyID();
            String strPolicy = (String) mapPolicyIdToPolicyName.get(nPolicyID);
            if (null != strPolicy) {
                UAUserGroupDomainMappingTableData tableData = new UAUserGroupDomainMappingTableData(strDomain, strPolicy);
                arrTableData.add(tableData);
            }
        }

        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("The number of displayable entities are " + arrTableData);
        }
        LOGGER.debug("getDisplayableArrayList() - Exit");
        return arrTableData;
    }

    /**
     * This function will create a HashMap. The Key to the Map is the ID of the policy and the Value is the Name of the policy
     * 
     * @param pLstPolicyIDToName
     *            List of PAPolicyNameAndID.
     * @return Returns the hashmap created of policy id versus the name.
     */
    private Map createMapOfPolicyIDToPolicyName(List lstPolicyIDToName) {
        LOGGER.debug("createMapOfPolicyIDToPolicyName() - Entry");

        Map map = new HashMap();
        for (int index = 0; index < lstPolicyIDToName.size(); index++) {
            PAPolicyId policy = (PAPolicyId) lstPolicyIDToName.get(index);
            Integer key = policy.getPolicyID();
            String value = policy.getPolicyName();
            map.put(key, value);
        }
        // Now after having done this. We shall add a new entry -1 -> None into the
        // Map this will help us in isolating the code that we write for No mapping
        map.put(-2, NOVISIBILITY);
        map.put(-1, NOACCESS);

        LOGGER.debug("createMapOfPolicyIDToPolicyName() - Exit");

        return map;
    }

    /**
     * Create a map of IDs to domain names for easy access when filling in assigned mappings.
     * 
     * @param domains
     *            List of available domains
     * @return the map
     */
    private Map<Integer, String> createMapOfDomainIdToDomainName(List<DCDomainData> domains) {
        Map<Integer, String> map = new HashMap<Integer, String>();

        for (DCDomainData dom : domains) {
            map.put(dom.getDomainID(), dom.getDomainName());
        }

        return map;
    }

    /**
     * This handles policy creation. A new policy key gets added in the Vector and should be displayed in the combo
     * 
     * @param policy
     *            The newly created policy.
     */
    public void policyCreated(PAPolicyId policy) {
        Integer nPolicyID = policy.getPolicyID();
        boolean bAlreadyAvailable = mapPolicyIdToPolicyName.containsKey(nPolicyID);

        if (bAlreadyAvailable) {
            // Trace out an error. Since we are getting a Policy creation for an already existing Policy ID
            LOGGER.warn("policyCreated() - Policy creation coming twice for  " + policy);
        } else {
            String strName = policy.getPolicyName();
            // Put it in the Map, array and JCombo
            mapPolicyIdToPolicyName.put(nPolicyID, strName);
            lstPolicyIDToName.add(policy);
            int nNoOfElms = policyComboBox.getItemCount();
            // We want to make sure that the Last is None. Therefore add to one above that.
            policyComboBox.insertItemAt(strName, (nNoOfElms - 1));
        }
    }

    /**
     * This handles the notification of a policy being deleted, in which case the policy has to be removed from the combo.
     * @param p_policy The policy which got deleted.
     */
    public void policyDeleted(PAPolicyId policy) {
        Integer nPolicyID = policy.getPolicyID();
        boolean bAvailable = mapPolicyIdToPolicyName.containsKey(nPolicyID);

        if (bAvailable) {
            // Remove it from the Map, array and JCombo
            String strName = (String) mapPolicyIdToPolicyName.remove(nPolicyID);
            lstPolicyIDToName.remove(policy);
            policyComboBox.removeItem(strName);
            modelRights.policyDeleted(strName);
        }
    }

    /**
     * This handles the notification of mappings being created. It adds the created mappings in the tab.
     * 
     * @param mappings
     *            - List of mappings that were created.
     * 
     */
    public void mappingsChanged(List mappings) {
        List arrDisplay = getDisplayableArrayList(mappings);
        modelRights.mappingsChanged(arrDisplay);
    }

    /**
     * This method gets called when the OK button is clicked. It returns the lists of mapping to be created, deleted and modified.
     */
    public void getMappingsForAssignment(String userGroup, List<DCDomainMapping> mappingsForUserGroup) {
        LOGGER.debug("getMappingsForAssignment() - Entry");

        List<UAUserGroupDomainMappingTableData> arrTableData = modelRights.data;
        Map mapPolNameToID = createMapOfPolicyNameToPolicyID(lstPolicyIDToName);
        Map<String, Integer> mapDomNameToID = createMapOfDomainNameToDomainId(domains);


        for (UAUserGroupDomainMappingTableData tableData : arrTableData) {
            Integer nDomainID = mapDomNameToID.get(tableData.domain);
            String strInitialString = tableData.initiallyAssigned;
            String strFinalString = tableData.finalAssignment;
            Integer nPolicyID = (Integer) mapPolNameToID.get(strFinalString);
            DCDomainMapping data = new DCDomainMapping(nDomainID, userGroup, nPolicyID.intValue());

            // only need to process mappings for which the assigned policy was changed
            if (strInitialString.compareTo(strFinalString) != 0) {
                mappingsForUserGroup.add(data);
            }
        }
        LOGGER.debug("getMappingsForAssignment() - Exit");
    }


    /**
     * This function will create a HashMap. The Key to the Map is the Policy Name and the Value is the ID of the policy.
     * 
     * @param lstPolicyIDToName
     *            List of PAPolicyNameAndID.
     * @return Map Returns the map of policy name versus the policy id.
     */
    private Map createMapOfPolicyNameToPolicyID(List lstPolicyIDToName) {
        LOGGER.debug("createMapOfPolicyNameToPolicyID() - Entry");

        Map map = new HashMap();
        for (int index = 0; index < lstPolicyIDToName.size(); index++) {
            PAPolicyId policy = (PAPolicyId) lstPolicyIDToName.get(index);
            Integer value = policy.getPolicyID();
            String key = policy.getPolicyName();
            map.put(key, value);
        }
        // Now add the one for the None.
        map.put(NOVISIBILITY, -2);
        map.put(NOACCESS, -1);

        LOGGER.debug("createMapOfPolicyNameToPolicyID() - Exit");

        return map;
    }

    /**
     * Create a map of domain names to domain Id for easy access when reading from table to create the mappings
     * 
     * @param domains
     * @return
     */
    private Map<String, Integer> createMapOfDomainNameToDomainId(List<DCDomainData> domains) {
        Map<String, Integer> map = new HashMap<String, Integer>();

        for (DCDomainData dom : domains) {
            map.put(dom.getDomainName(), dom.getDomainID());
        }

        return map;
    }

    /**
     * Data model class for mappings
     */
    static class UAUserGroupDomainMappingModel extends AbstractTableModel {
        private static final long serialVersionUID = 3597725089824963768L;

        // The title of the columns, two columns
        private String columns[] = { JfxStringTable.getString(USMStringTable.IDS_DC_DOMAIN), JfxStringTable.getString(USMStringTable.IDS_DC_ASSIGNED_POLICY) };

        // Holds the data for this tab
        private List<UAUserGroupDomainMappingTableData> data = new ArrayList<UAUserGroupDomainsAndPoliciesPane.UAUserGroupDomainMappingTableData>();
        
        private boolean tableEditable = true;

        /**
         * This method is used to find if a particular cell is editable or not.
         * 
         * @param row
         *            The row index of the cell.
         * @param col
         *            The column index of the cell.
         * @return Returns true if the cell is editable.
         */
        @Override
        public boolean isCellEditable(int row, int col) {
            boolean bEditable = false;
            if (1 == col && tableEditable) { 
                bEditable = true;  	
            }
            return bEditable;
        }

        /**
         * Get the column header name to be displayed.
         * 
         * @param column
         *            The column index of the cell.
         */
        @Override
        public String getColumnName(int column) {
            return columns[column];
        }

        @Override
        public int getColumnCount() {
            return columns.length;
        }

        @Override
        public int getRowCount() {
            return data.size();
        }

        /**
         * This method handles the changes in the mappings data.
         * @param changedMappings
         *            The changed mapping data.
         */
        public void mappingsChanged(List changedMappings) {
            for (int nOuterIndex = 0; nOuterIndex < data.size(); nOuterIndex++) {
                // We shall iterate over the whole of the data that we have
                UAUserGroupDomainMappingTableData savedData = data.get(nOuterIndex);
                
                for (int nInnerIndex = 0; nInnerIndex < changedMappings.size(); nInnerIndex++) {
                    UAUserGroupDomainMappingTableData changedData = (UAUserGroupDomainMappingTableData) changedMappings.get(nInnerIndex);
                    if (changedData.equals(savedData)) {
                        savedData.initiallyAssigned = changedData.finalAssignment;
                        savedData.finalAssignment = changedData.finalAssignment;
                        break;
                    }
                }
            }
            fireTableDataChanged();
        }
        
        public void setCellEditToDisable(){
        	tableEditable = false;
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            Object returnValue = null;
            UAUserGroupDomainMappingTableData objData = data.get(rowIndex);
            switch (columnIndex) {
            case 0: {
                returnValue = objData.domain;
                break;
            }
            case 1: {
                returnValue = objData.finalAssignment;
                break;
            }
            default: {
                LOGGER.debug("We reached a point we should never have got to using value columnIndex=" + columnIndex);
                break;
            }
            }
            return returnValue;

        }

        /**
         * Sets the value of the object
         * @param p_value
         *            The value, which has to be set.
         * @param p_row
         *            The row index, where value has to be set.
         * @param p_col
         *            The column index, where value has to be set.
         */
        @Override
        public void setValueAt(Object value, int row, int col) {
            UAUserGroupDomainMappingTableData objData = data.get(row);
            objData.finalAssignment = (String) value;
            fireTableCellUpdated(row, col);
        }

        /**
         * This method handles policy deleted. It removes that policy from the combo.
         * 
         * @param p_PolicyName
         *            The policy name which has been deleted.
         */
        public void policyDeleted(String policyName) {
            for (int index = 0; index < data.size(); index++) {
                UAUserGroupDomainMappingTableData objData = data.get(index);
                if (objData.finalAssignment.compareTo(policyName) == 0) {
                    // This means that for this mapping, the policy selected has been deleted.
                    // Therefore we shall revert this to the Initial one that was set when the tab was open. If even this is None
                    objData.finalAssignment = objData.initiallyAssigned;
                }
            }
            fireTableDataChanged();
        }
    }

    /**
     * This class holds the mapping data in a readable format.
     */
    class UAUserGroupDomainMappingTableData {

        // For Domain
        String domain;

        // For Initial Assigned Policy
        String initiallyAssigned;

        // For Assignment by operator
        String finalAssignment;

        /**
         * Constructor which takes a domain and assigned policy.
         * @param domain
         *            The domain of the mapping.
         * @param policyAssigned
         *            The policy assigned to this mapping.
         */
        UAUserGroupDomainMappingTableData(String domain, String policyAssigned) {
            this.domain = domain;
            this.initiallyAssigned = policyAssigned;
            this.finalAssignment = policyAssigned;
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + getOuterType().hashCode();
            result = prime * result + ((domain == null) ? 0 : domain.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            UAUserGroupDomainMappingTableData other = (UAUserGroupDomainMappingTableData) obj;
            if (!getOuterType().equals(other.getOuterType())) {
                return false;
            }
            if (domain == null) {
                if (other.domain != null) {
                    return false;
                }
            } else if (!domain.equals(other.domain)) {
                return false;
            }
            return true;
        }

        /**
         * Overridden toString method
         * @return java.lang.String Returns the domain + policy initially assigned + policy assigned
         */
        @Override
        public String toString() {
            return (domain + " : " + initiallyAssigned + " : " + finalAssignment);
        }

        private UAUserGroupDomainsAndPoliciesPane getOuterType() {
            return UAUserGroupDomainsAndPoliciesPane.this;
        }
    }

}