/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 *  Class Name 	UAModifyUserCommand 
 * Author:      Vinay Purohit
 * Substitute	Babu B
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER.VIEW
 *       : TNMS.DX2.SM.USER.CREATE
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.useradministration.usermodify;

import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;
import org.apache.log4j.Logger;

/**
 * Concrete class for the Command of the Modify User View. This Command is
 * registered with the UI and is responsible to display the Modify User View.
 *  
 */
public class UAModifyUserCommand extends USMCommand {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(UAModifyUserCommand.class);

	/**
	 * String contains user id of the user to be modified.
	 */
	private String userID = null;

	/**
	 * Default constructor
	 */
	public UAModifyUserCommand() {

		super(USMCommandID.S_UI_ID_MODIFY_USER);
	}

	/**
	 * Constructor with command id as parameter
	 * 
	 * @param cmdID - Command ID of the modify user command
	 */
	public UAModifyUserCommand(USMCommandID cmdID) {
		super(cmdID);
		LOGGER.debug(" in the constructor");
	}

	/**
	 * Overriden method to create and return a view object.
	 * 
	 * @return USMBaseView 
	 *      The View object that has been created.
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#createAndReturnView()
	 */
	@Override
	protected USMBaseView createAndReturnView() {
		return new UAModifyUserView(userID);
	}

	/**
	 * Returns a cloned instance of command handler object on which the
	 * method is invoked.
	 * 
	 * @param selList 
	 *      The selection list containing selection item
	 * 
	 * @return USMCommand - Returns the USMCommand that newly got created. 
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#cloneCmd(java.lang.Object)
	 */
	@Override
	public USMCommand cloneCmd(Object selList) {
		LOGGER.debug("cloneCmd() in the method");
		UAModifyUserCommand modCommand = new UAModifyUserCommand();
		modCommand.userID = (String) selList;

		return modCommand;
	}

	/**
	 * Function to compare a Command handler with this Object. The passed object
	 * also is a Command Handler.
	 * 
	 * @param cmd
	 *            The Command handler which should be compared to this object.
	 * 
	 * @return boolean The result of the comparison. Return true, if the 2
	 *         commands are the same, else return false
	 */

	@Override
	public boolean compare(USMCommand cmd) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering compare. Command being passed is : " + cmd);
		}

		boolean bOp = false;

		UAModifyUserCommand pCmdModifyUG = (UAModifyUserCommand) cmd;
		if (userID.compareToIgnoreCase(pCmdModifyUG.userID) == 0) {
			bOp = true;
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting compare. Result of compare is : " + bOp);
		}
		return bOp;
	}
    
    /**
     * {@inheritDoc}
     */
    @Override
	public Object getKey() { 
        return userID;
    }
}
