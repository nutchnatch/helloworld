/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   UAJobUnlockUsers
 * Author:      Babu B
 * Substitute	Vinay Purohit
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER.VIEW
 *       : TNMS.DX2.SM.FORCE_LOGOFF
 *       : TNMS.DX2.SM.USER.CREATE
 *       : TNMS.DX2.SM.USER.CONFIGURE
 *       : TNMS.DX2.SM.USER.STATUS
 * 		 :
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration.job;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.useradministration.UADelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;

import java.util.List;
/**
 * This class represents the job responsible for unlocking a given set of users
 */
public class UAJobUnlockUsers extends USMJob {

	/**
	 * Data member for the users for which this command is to be executed.
	 */
	private List lstSelectedUsers;

	/**
	 * This is the constructor
	 *
	 * @param jobOwner The controller associated with the job
	 */
	public UAJobUnlockUsers(USMControllerIfc jobOwner) {
		super(
			UAMessageType.S_UA_REQ_UNLOCK_USER,
			USMCommonStrings.EMPTY,
			USMCommonStrings.EMPTY,
			jobOwner);
	}

	/**
	 * Executes the given job
	 *
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob#executeJob()
	 */
	@Override
    public USMMessage executeJob() throws BcbSecurityException {
		USMMessage msgRetVal;
		UADelegate delegate = new UADelegate();

		msgRetVal = delegate.unlockUsers(lstSelectedUsers);

		return msgRetVal;
	}

	/**
	 * Store the users for which the job has to be executed 
	 *  
	 * @param selectedUsers
	 */
	public void setUsers(List selectedUsers) {
		lstSelectedUsers = selectedUsers;
		String str;
		if(selectedUsers.size() == 1) {
			Object[] arr = {selectedUsers.get(0)};
			str = USMStringTable.IDS_UA_JOB_UNLOCKING_USER_SINGLE.getFormatedMessage(arr);
		} else {
			Object[] arr = {selectedUsers.size()};
			str = USMStringTable.IDS_UA_JOB_UNLOCKING_USER_MULTI.getFormatedMessage(arr);
		}
		setName(str);
	}

}
