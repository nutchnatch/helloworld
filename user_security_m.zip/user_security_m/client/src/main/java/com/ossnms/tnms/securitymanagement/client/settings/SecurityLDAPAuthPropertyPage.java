/*
 * Copyright Coriant 2013
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 *
 */
package com.ossnms.tnms.securitymanagement.client.settings;

import com.coriant.widgets.spinner.SpinnerIntegerModel;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientLogEntry;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientLogSeverity;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPageSite;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSettingsPropertyPage;
import com.ossnms.bicnet.bcb.plugin.DefaultPluginClientLogEntry;
import com.ossnms.bicnet.framework.client.notificationpopup.NotificationPopupDetails;
import com.ossnms.bicnet.framework.client.notificationpopup.NotificationPopupDetails.OpStatus;
import com.ossnms.bicnet.framework.client.notificationpopup.NotificationPopupManager;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.client.common.USMTextField;
import com.ossnms.bicnet.securitymanagement.common.auth.LDAPSearchScope;
import com.ossnms.bicnet.securitymanagement.common.general.GSConstants;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.bicnet.securitymanagement.common.general.ResponseMessage;
import com.ossnms.bicnet.securitymanagement.common.general.ldap.LDAPConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.ldap.LDAPSettingsResponseMessage;
import com.ossnms.tnms.securitymanagement.client.util.USMMessages;
import com.ossnms.tnms.securitymanagement.client.util.USMResourceBundleConstants;
import com.ossnms.tools.jfx.JfxCheckBoxTitlePanel;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxCheckBox;
import com.ossnms.tools.jfx.components.JfxComboBox;
import com.ossnms.tools.jfx.components.JfxComboBox.ItemData;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxPasswordField;
import com.ossnms.tools.jfx.components.JfxSpinner;
import org.apache.commons.validator.routines.IntegerValidator;
import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static com.ossnms.bicnet.securitymanagement.common.auth.LDAPSearchScope.ONELEVEL;
import static com.ossnms.bicnet.securitymanagement.common.auth.LDAPSearchScope.SUBTREE;

/**
 * The LDAP Authentication Property page
 */
final class SecurityLDAPAuthPropertyPage extends JPanel implements ISecurityPropertyPage {

	private static final long serialVersionUID = -2161787957134798085L;

	private static final Logger LOGGER = Logger.getLogger(SecurityLDAPAuthPropertyPage.class);
	private static final int LDAP_MIN_PORT = 1;

	private final JfxLabel ldapHostnameLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_LDAP_HOSTNAME);

	private final JfxLabel sslIndicatorLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_LDAP_SSL_INDICATOR);

	private final JfxLabel passwordAccountLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_LDAP_PASSWORD);

	private final JfxLabel userSearchBaseLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_LDAP_USER_SEARCH_BASE);

	private final JfxLabel userSearchFilterLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_LDAP_USER_SEARCH_FILTER);

	private final JfxLabel userSearchScopeLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_LDAP_USER_SEARCH_SCOPE);

	private final JfxLabel groupSearchBaseLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_LDAP_GROUP_SEARCH_BASE);

	private final JfxLabel groupSearchFilterLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_LDAP_GROUP_SEARCH_FILTER);

	private final JfxLabel groupSearchScopeLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_LDAP_GROUP_SEARCH_SCOPE);

	private final JfxLabel searchAcountLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_LDAP_SEARCH_ACCOUNT);

	private final JfxLabel userIdentifyingAttributeLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_LDAP_USER_IDENTIFYING_ATTRIBUTE);

	private final JfxLabel groupIdentifyingAttributeLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_LDAP_GROUP_IDENTIFYING_ATTRIBUTE);
	
	private final JfxLabel groupAttributeIdentifyingUserLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_LDAP_GROUP_ATTRIBUTE_IDENTIFYING_USER);
	
	private final JfxLabel activeDirectoryLDAPAuthPortLabel = new JfxLabel(USMStringTable.IDS_SS_AD_LDAP_PORT_LABEL);

	private final transient SecuritySettingsDocument doc;

	private transient BiCNetPluginPropertyPageSite propertyPageSite;

	private JfxCheckBoxTitlePanel enableLdapAuthCheckbox;

	private USMTextField ldapHostNameField;

	private USMTextField userSearchBaseField;

	private USMTextField userSearchFilterField;

	private JfxComboBox userSearchScopeField;

	private USMTextField searchAcountField;

	private USMTextField groupSearchBaseField;

	private USMTextField groupSearchFilterField;

	private JfxComboBox groupSearchScopeField;

	private USMTextField userIdentifyingAttributeField;

	private USMTextField groupIdentifyingAttributeField;
	
	private USMTextField groupAttributeIdentifyingUserField;

	private JfxPasswordField passwordAccountField;

	private JfxCheckBox sslIndicatorCheckbox;

	private JfxCheckBox ldapAuthPortCheckbox;

	private final JfxLabel ldapAuthPortRange = new JfxLabel();

	private JfxSpinner ldapAuthPortSpinner;

	private JPanel ldapAuthPanel;

	private SpinnerIntegerModel ldapAuthPortSpinnerModel;

	private JfxButton defaultButton = new JfxButton(JfxStringTable.IDS_Default);

	private final transient List<ChangeListener> changeListeners = new ArrayList<>();

	private transient List<ItemData> itemsList = new ArrayList<>();

	/**
	 * Flag to inform us the page required an update (was dirty)
	 */
	private boolean requiredUpdate;

	/**
	 * Creates the new LDAP Authentication Property Page, with the SecuritySettingsDocument as basis
	 * @param doc an instance of {@link SecuritySettingsDocument}
     */
	public SecurityLDAPAuthPropertyPage(SecuritySettingsDocument doc) {
		this.doc = doc;
		this.itemsList.add(new ItemData(ONELEVEL, ONELEVEL));
		this.itemsList.add(new ItemData(SUBTREE, SUBTREE));

		initLayout();
		initListeners();
		
		enableLDAPAuth(ldapAuthPanel, enableLdapAuthCheckbox.isSelected());

		setGuiNames();
	}

	private void initListeners() {
		enableLdapAuthCheckbox.addActionListener(e -> this.stateChanged(new ChangeEvent(enableLdapAuthCheckbox)));
		ldapAuthPortCheckbox.addActionListener(e -> this.stateChanged(new ChangeEvent(ldapAuthPortCheckbox)));
		userSearchScopeField.addActionListener(e -> this.stateChanged(new ChangeEvent(userSearchScopeField)));
		groupSearchScopeField.addActionListener(e -> this.stateChanged(new ChangeEvent(groupSearchScopeField)));

		ldapAuthPortSpinner.addChangeListener(this);
		DocumentListener documentListener = new LDAPDocumentListener();

		ldapHostNameField.addDocumentListener(documentListener);
		userSearchBaseField.addDocumentListener(documentListener);
		userSearchFilterField.addDocumentListener(documentListener);
		searchAcountField.addDocumentListener(documentListener);
		groupSearchBaseField.addDocumentListener(documentListener);
		groupSearchFilterField.addDocumentListener(documentListener);
		userIdentifyingAttributeField.addDocumentListener(documentListener);
		groupIdentifyingAttributeField.addDocumentListener(documentListener);
		groupAttributeIdentifyingUserField.addDocumentListener(documentListener);
		sslIndicatorCheckbox.addChangeListener(this);
		passwordAccountField.addDocumentListener(documentListener);
		
		defaultButton.addActionListener(e -> {
            enableLdapAuthCheckbox.setSelected(false);

            ldapAuthPortCheckbox.setSelected(true);
            ldapAuthPortSpinner.setValue(GSConstants.S_AD_LDAP_PORT);

            ldapHostNameField.setText("");
            userSearchBaseField.setText("");
            userSearchFilterField.setText("");
            userSearchScopeField.setSelectedItem(ONELEVEL);
            searchAcountField.setText("");
            groupSearchBaseField.setText("");
            groupSearchFilterField.setText("");
            groupSearchScopeField.setSelectedItem(ONELEVEL);
            userIdentifyingAttributeField.setText("");
            groupIdentifyingAttributeField.setText("");
            groupAttributeIdentifyingUserField.setText("");
            sslIndicatorCheckbox.setSelected(false);
            passwordAccountField.setText("");

            enableLDAPAuth(ldapAuthPanel, enableLdapAuthCheckbox.isSelected());

            if (propertyPageSite != null) {
                propertyPageSite.eventPageStatusChanged(SecurityLDAPAuthPropertyPage.this);
            }
        });
	}

	private void initLayout() {
		setLayout(new GridBagLayout());
		setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);
		
		createLdapAuthPanel();

		enableLdapAuthCheckbox = new JfxCheckBoxTitlePanel(USMStringTable.IDS_SS_AD_LDAP_AUTHENTICATION_CHECKBOX, ldapAuthPanel);

		add(enableLdapAuthCheckbox, new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
		add(defaultButton, new GridBagConstraints(0, 1, 1, 1, 0.0, 1.0, GridBagConstraints.SOUTHWEST, GridBagConstraints.NONE, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0), 0, 0));
	}


	private JPanel createLdapAuthPanel() {
		ldapAuthPanel = new JPanel(new GridBagLayout());

		int row = 0;
		initAndAddLdapHost(ldapAuthPanel, row++);
		initAndAddLDAPAuthPort(ldapAuthPanel, row++);
		ldapAuthPanel.add(createLdapPortAuthPanel(),
				new GridBagConstraints(0, row++, GridBagConstraints.REMAINDER, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, JfxUtils.FIELD_INDENTATION, 0, 0), 0, 0));
		initAndAddSslIndicator(ldapAuthPanel, row++);

		createLdapAuthSearchAccount(ldapAuthPanel, row++);
		initAndAddPasswordAccount(ldapAuthPanel, row++);

		initAndAddUserSearchBase(ldapAuthPanel, row++);
		initAndAddUserSearchFilter(ldapAuthPanel, row++);
		initAndAddUserSearchScope(ldapAuthPanel, row++);
		initAndAddUserIdentifyingAttribute(ldapAuthPanel, row++);
		
		initAndAddGroupSearchBase(ldapAuthPanel, row++);
		initAndAddGroupSearchFilter(ldapAuthPanel, row++);
		initAndAddGroupSearchScope(ldapAuthPanel, row++);
		initAndAddGroupIdentifyingAttribute(ldapAuthPanel, row++);
		initAndAddGroupAttributeIdentifyingUser(ldapAuthPanel, row);
		
		return ldapAuthPanel;
	}

	protected void enableLDAPAuth(Object object, boolean enableLdapAuth) {
		if (object instanceof Container) {
			Container c = (Container) object;
			Component[] components = c.getComponents();
			for (Component component : components) {
				enableLDAPAuth(component, enableLdapAuth);
				component.setEnabled(enableLdapAuth);
			}
		} else {
			if (object instanceof Component) {
				Component component = (Component) object;
				component.setEnabled(enableLdapAuth);
			}
		}
		if (enableLdapAuth) {
			validateLDAPAuthPort(this.ldapAuthPortCheckbox.isSelected());
		}
	}

	private void validateLDAPAuthPort(boolean checked) {
		ldapAuthPortSpinnerModel.setMinimum(checked ? GSConstants.S_AD_LDAP_PORT : LDAP_MIN_PORT);
		ldapAuthPortSpinner.setEnabled(!checked);
		ldapAuthPortSpinner.setValue(checked ? GSConstants.S_AD_LDAP_PORT : LDAP_MIN_PORT);
	}

	private void initAndAddLDAPAuthPort(JPanel panel, int row) {
		ldapAuthPortCheckbox = new JfxCheckBox(USMStringTable.IDS_SS_AD_LDAP_PORT_CHECKBOX);
		ldapAuthPortCheckbox.setSelected(true);
		ldapAuthPortCheckbox.setMnemonic(USMStringTable.IDS_SS_AD_LDAP_PORT_CHECKBOX.getMnemonic());
		panel.add(ldapAuthPortCheckbox, new GridBagConstraints(0, row, GridBagConstraints.REMAINDER, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
	}

	private void initAndAddLdapHost(JPanel panel, int row) {
		ldapHostNameField = new USMTextField();
		ldapHostnameLabel.setLabelAndMnemonicFor(ldapHostNameField);
		ldapHostNameField.setToolTipText(USMStringTable.IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_HOSTNAME);
		ldapHostNameField.setMandatoryEntry(true);
		panel.add(ldapHostnameLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.DEFAULT_MARGIN), 0, 0));
		panel.add(ldapHostNameField, new GridBagConstraints(1, row, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
	}

	private void initAndAddSslIndicator(JPanel panel, int row) {
		sslIndicatorCheckbox = new JfxCheckBox();
		sslIndicatorCheckbox.setMnemonic(USMStringTable.IDS_SS_AD_LDAP_SSLINDICATOR_CHECKBOX.getMnemonic());
		sslIndicatorLabel.setLabelAndMnemonicFor(sslIndicatorCheckbox);
		panel.add(sslIndicatorLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.DEFAULT_MARGIN), 0, 0));
		panel.add(sslIndicatorCheckbox, new GridBagConstraints(1, row, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
	}

	private void initAndAddPasswordAccount(JPanel panel, int row) {
		passwordAccountField = new JfxPasswordField();
		passwordAccountLabel.setLabelAndMnemonicFor(passwordAccountField);
		passwordAccountField.setToolTipText(USMStringTable.IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_PASSWORD);
		passwordAccountField.setMandatoryEntry(true);
		panel.add(passwordAccountLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.DEFAULT_MARGIN), 0, 0));
		panel.add(passwordAccountField, new GridBagConstraints(1, row, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
	}

	private void initAndAddUserSearchBase(JPanel panel, int row) {
		userSearchBaseField = new USMTextField();
		userSearchBaseLabel.setLabelAndMnemonicFor(userSearchBaseField);
		userSearchBaseField.setToolTipText(USMStringTable.IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_USER_SEARCH_BASE);
		userSearchBaseField.setMandatoryEntry(true);
		panel.add(userSearchBaseLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.DEFAULT_MARGIN), 0, 0));
		panel.add(userSearchBaseField, new GridBagConstraints(1, row, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
	}

	private void initAndAddUserSearchFilter(JPanel panel, int row) {
		userSearchFilterField = new USMTextField();
		userSearchFilterLabel.setLabelAndMnemonicFor(userSearchFilterField);
		userSearchFilterField.setToolTipText(USMStringTable.IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_USER_SEARCH_FILTER);
		userSearchFilterField.setMandatoryEntry(true);
		panel.add(userSearchFilterLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.DEFAULT_MARGIN), 0, 0));
		panel.add(userSearchFilterField, new GridBagConstraints(1, row, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
	}

	private void initAndAddUserSearchScope(JPanel panel, int row) {
		userSearchScopeField = new JfxComboBox(itemsList);
		userSearchScopeLabel.setLabelAndMnemonicFor(userSearchScopeField);
		userSearchScopeField.setToolTipText(USMStringTable.IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_USER_SEARCH_SCOPE);
		userSearchScopeField.setMandatoryEntry(true);
		panel.add(userSearchScopeLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.DEFAULT_MARGIN), 0, 0));
		panel.add(userSearchScopeField, new GridBagConstraints(1, row, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
	}

	private void initAndAddGroupSearchBase(JPanel panel, int row) {
		groupSearchBaseField = new USMTextField();
		groupSearchBaseLabel.setLabelAndMnemonicFor(groupSearchBaseField);
		groupSearchBaseField.setToolTipText(USMStringTable.IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_GROUP_SEARCH_BASE);
		groupSearchBaseField.setMandatoryEntry(true);
		panel.add(groupSearchBaseLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.DEFAULT_MARGIN), 0, 0));
		panel.add(groupSearchBaseField, new GridBagConstraints(1, row, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
	}

	private void initAndAddGroupSearchFilter(JPanel panel, int row) {
		groupSearchFilterField = new USMTextField();
		groupSearchFilterLabel.setLabelAndMnemonicFor(groupSearchFilterField);
		groupSearchFilterField.setToolTipText(USMStringTable.IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_GROUP_SEARCH_FILTER);
		groupSearchFilterField.setMandatoryEntry(true);
		panel.add(groupSearchFilterLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.DEFAULT_MARGIN), 0, 0));
		panel.add(groupSearchFilterField, new GridBagConstraints(1, row, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
	}

	private void initAndAddGroupSearchScope(JPanel panel, int row) {
		groupSearchScopeField = new JfxComboBox(itemsList);
		groupSearchScopeLabel.setLabelAndMnemonicFor(groupSearchScopeField);
		groupSearchScopeField.setToolTipText(USMStringTable.IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_GROUP_SEARCH_SCOPE);
		groupSearchScopeField.setMandatoryEntry(true);
		panel.add(groupSearchScopeLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.DEFAULT_MARGIN), 0, 0));
		panel.add(groupSearchScopeField, new GridBagConstraints(1, row, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
	}

	private void createLdapAuthSearchAccount(JPanel panel, int row) {
		searchAcountField = new USMTextField();
		searchAcountLabel.setLabelAndMnemonicFor(searchAcountField);
		searchAcountField.setToolTipText(USMStringTable.IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_SEARCH_ACCOUNT);
		searchAcountField.setMandatoryEntry(true);
		panel.add(searchAcountLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.DEFAULT_MARGIN), 0, 0));
		panel.add(searchAcountField, new GridBagConstraints(1, row, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
	}

	private void initAndAddUserIdentifyingAttribute(JPanel panel, int row) {
		userIdentifyingAttributeField = new USMTextField();
		userIdentifyingAttributeLabel.setLabelAndMnemonicFor(userIdentifyingAttributeField);
		userIdentifyingAttributeField.setToolTipText(USMStringTable.IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_ATTRIBUTE_IDENTIFYING_ROLE);
		userIdentifyingAttributeField.setMandatoryEntry(true);
		panel.add(userIdentifyingAttributeLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.DEFAULT_MARGIN), 0, 0));
		panel.add(userIdentifyingAttributeField, new GridBagConstraints(1, row, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
	}

	private void initAndAddGroupIdentifyingAttribute(JPanel panel, int row) {
		groupIdentifyingAttributeField = new USMTextField();
		groupIdentifyingAttributeLabel.setLabelAndMnemonicFor(groupIdentifyingAttributeField);
		groupIdentifyingAttributeField.setToolTipText(USMStringTable.IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_ATTRIBUTE_IDENTIFYING_USER);
		groupIdentifyingAttributeField.setMandatoryEntry(true);
		panel.add(groupIdentifyingAttributeLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.DEFAULT_MARGIN), 0, 0));
		panel.add(groupIdentifyingAttributeField, new GridBagConstraints(1, row, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
	}

	
	private void initAndAddGroupAttributeIdentifyingUser(JPanel panel, int row) {
		groupAttributeIdentifyingUserField = new USMTextField();
		groupAttributeIdentifyingUserLabel.setLabelAndMnemonicFor(groupAttributeIdentifyingUserField);
		groupAttributeIdentifyingUserField.setToolTipText(USMStringTable.IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_ATTRIBUTE_IDENTIFYING_USER);
		groupAttributeIdentifyingUserField.setMandatoryEntry(true);
		panel.add(groupAttributeIdentifyingUserLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.DEFAULT_MARGIN), 0, 0));
		panel.add(groupAttributeIdentifyingUserField, new GridBagConstraints(1, row, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
	}
	
	
	private JPanel createLdapPortAuthPanel() {
		JPanel ldapPortPanel = new JPanel(new GridBagLayout());

		ldapAuthPortSpinnerModel = new SpinnerIntegerModel(GSConstants.S_AD_LDAP_PORT, LDAP_MIN_PORT, GSConstants.S_AD_LDAP_PORT_MAX, 1);
		ldapAuthPortSpinner = new JfxSpinner(ldapAuthPortSpinnerModel);
		activeDirectoryLDAPAuthPortLabel.setLabelAndMnemonicFor(ldapAuthPortSpinner);
		ldapAuthPortSpinner.setToolTipText(USMStringTable.IDS_AA_WINDOW_CONTROL_TOOLTIP_AD_LDAP_PORT);
		ldapAuthPortRange.setText(USMMessages.getInstance().getFormatedString(USMResourceBundleConstants.SECURITY_SETTINGS_RANGE, new Object[] { String.valueOf(LDAP_MIN_PORT), String.valueOf(GSConstants.S_AD_LDAP_PORT_MAX) }));

		ldapPortPanel.add(activeDirectoryLDAPAuthPortLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
		ldapPortPanel.add(ldapAuthPortSpinner, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
		ldapPortPanel.add(ldapAuthPortRange, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, 0, 0), 0, 0));
		return ldapPortPanel;
	}

	/**
	 * Helper function that is used to set the Names of all the editable
	 * components within the Window.
	 * 
	 * Strings in this function are not to be Internationalized.
	 */
	private void setGuiNames() {
		LOGGER.debug("setGuiNames() Entry");

		enableLdapAuthCheckbox.setName("EnableLdapAuthCheckbox");
		enableLdapAuthCheckbox.getCheckBox().setName("EnableLdapAuthCheckbox");
		ldapAuthPortCheckbox.setName("LdapAuthPortCheckbox");
		ldapAuthPortSpinner.setName("LdapAuthPortSpinner");
		
		ldapHostNameField.setName("LdapHostNameField");
		userSearchBaseField.setName("UserSearchBaseField");
		userSearchFilterField.setName("UserSearchFilterField");
		userSearchScopeField.setName("UserSearchScopeField");
		searchAcountField.setName("SearchAcountField");
		groupSearchBaseField.setName("GroupSearchBaseField");
		groupSearchFilterField.setName("GroupSearchFilterField");
		groupSearchScopeField.setName("GroupSearchScopeField");
		userIdentifyingAttributeField.setName("UserIdentifyingAttributeField");
		groupIdentifyingAttributeField.setName("GroupIdentifyingAttributeField");
		groupAttributeIdentifyingUserField.setName("GroupAttributeIdentifyingUserField");
		sslIndicatorCheckbox.setName("SslIndicatorCheckbox");
		passwordAccountField.setName("PasswordAccountField");

		LOGGER.debug("setGuiNames() Exit");
	}

	@Override
	public void actionApply() {
		// Do nothing
	}

	@Override
	public void actionCancel() {
		// Do nothing
	}

	@Override
	public void eventClosing() {
		// Do nothing
	}

	@Override
	public void eventOpened() {
		// Do nothing
	}

	@Override
	public JComponent getComponent() {
		return this;
	}

	@Override
	public String getID() {
		return USMCommandID.S_UI_ID_SECURITY_SETTINGS_LDAP_AUTH.getMenuString();
	}

	@Override
	public String getTitle() {
		return USMStringTable.IDS_AA_LDAP_AUTHENTICATION_CONFIGURATION_GROUP_LABEL.toString();
	}

	@Override
	public boolean isPageDirty() {
		GSGeneralSettingData savedSettings = doc.getGeneralSettingsData();

		boolean retValue = savedSettings == null;
		retValue = retValue || (savedSettings.getLdapConfigurationData() == null);
		retValue = retValue || (savedSettings.getLdapConfigurationData().isEnabled() != enableLdapAuthCheckbox.isSelected());
		retValue = retValue || areLdapAuthSettingDirty(savedSettings.getLdapConfigurationData());

		return retValue;
	}

	/**
	 *
	 * @param ldapConfigurationData
	 * @return
     */
	private boolean areLdapAuthSettingDirty(LDAPConfigurationData ldapConfigurationData) {

		if (!ldapConfigurationData.getHost().equals(ldapHostNameField.getText())) {
			return true;
		}

		if (!ldapConfigurationData.getSearchAccount().equals(searchAcountField.getText())) {
			return true;
		}

		if (!ldapConfigurationData.getUserSearchBase().equals(userSearchBaseField.getText())) {
			return true;
		}

		if (!ldapConfigurationData.getUserSearchFilter().equals(userSearchFilterField.getText())) {
			return true;
		}

		if (!userSearchScopeField.getSelectedObjectValue().equals(ldapConfigurationData.getUserSearchScope())) {
			return true;
		}

		if (!ldapConfigurationData.getGroupSearchBase().equals(groupSearchBaseField.getText())) {
			return true;
		}

		if (!ldapConfigurationData.getGroupSearchFilter().equals(groupSearchFilterField.getText())) {
			return true;
		}

		if (!groupSearchScopeField.getSelectedObjectValue().equals(ldapConfigurationData.getGroupSearchScope())) {
			return true;
		}

		if (!ldapConfigurationData.getUserIdAttribute().equals(userIdentifyingAttributeField.getText())) {
			return true;
		}

		if (!ldapConfigurationData.getGroupIdAttribute().equals(groupIdentifyingAttributeField.getText())) {
			return true;
		}

		if (!ldapConfigurationData.getGroupMemberAttribute().equals(groupAttributeIdentifyingUserField.getText())) {
			return true;
		}
		
		if (!ldapConfigurationData.getSearchPassword().equals(String.valueOf(passwordAccountField.getPassword()))) {
			return true;
		}

		if (ldapConfigurationData.isSslIndicator() != sslIndicatorCheckbox.isSelected()) {
			return true;
		}
		
		if (!ldapConfigurationData.getPort().equals(String.valueOf(ldapAuthPortSpinner.getValue()))) {
			return true;
		}

		return false;
	}

	@Override
	public void setObjects(IManagedObjectMarkable[] objects) {
		// Do nothing
	}

	@Override
	public void setPageSite(BiCNetPluginPropertyPageSite site) {
		this.propertyPageSite = site;
	}

	@Override
	public void setReadOnly(boolean arg0) {
		// Do nothing
	}

	@Override
	public void update() {
		//
	}

	@Override
	public void validateInput() throws BiCNetPluginException {
		boolean enabledLdapAuth = enableLdapAuthCheckbox.isSelected();
		String host = ldapHostNameField.getText();
		String port = String.valueOf(ldapAuthPortSpinner.getValue());
		String searchAccount = searchAcountField.getText();
		String searchPassword = String.valueOf(passwordAccountField.getPassword());
		String userSearchBase = userSearchBaseField.getText();
		String userSearchFilter = userSearchFilterField.getText();
		String userSearchScope = userSearchScopeField.getSelectedKey().toString();
		String groupSearchBase = groupSearchBaseField.getText();
		String groupSearchFilter = groupSearchFilterField.getText();
		String groupSearchScope = groupSearchScopeField.getSelectedKey().toString();
		String groupAttributeRole = userIdentifyingAttributeField.getText();
		String groupAttributeUser = groupIdentifyingAttributeField.getText();
		String groupAttributeIdentifyingUser = groupAttributeIdentifyingUserField.getText();
		
		
		if (enabledLdapAuth && (host.isEmpty() || port.isEmpty() || searchAccount.isEmpty() || searchPassword.isEmpty() || userSearchBase.isEmpty() || userSearchFilter.isEmpty() || userSearchScope.isEmpty() || groupSearchBase.isEmpty() || groupSearchFilter.isEmpty()
				|| groupSearchScope.isEmpty() || groupAttributeRole.isEmpty() || groupAttributeUser.isEmpty() || groupAttributeIdentifyingUser.isEmpty())) {
			throw new BiCNetPluginException(USMStringTable.IDS_AA_DIALOG_MESSAGE_EMPTY_LDAP_AUTH_CONFIG.getText());
		}
	}

	@Override
	public BiCNetPluginSettingsPropertyPage[] getChildPages() {
		return new BiCNetPluginSettingsPropertyPage[0];
	}

	@Override
	public boolean isEnabled(IManagedObject[] arg0) {
		return USMUtility.getInstance().checkIfOperatorHasPermission(USMCommandID.S_UI_ID_GENERAL_SECURITY_SETTINGS.getMenuString());
	}

	/**
	 * ***********************************************************************
	 * Sets the interface of the enclosing frame provided by the application.
	 * This method is called before the view is displayed. The view should store
	 * the given reference for later use.
	 *
	 * @param frame
	 *            Reference to plug-in frame. *
	 * ***********************************************************************
	 */
	@Override
	public void setFrame(BiCNetPluginFrame frame) {
		// no implementation necessary
	}

	@Override
	public void updateData(Object key) {
		if (key instanceof GSGeneralSettingData) {
			GSGeneralSettingData data = (GSGeneralSettingData) key;

			LDAPConfigurationData authLdapData = data.getLdapConfigurationData();


			// LDAP Configuration
			enableLdapAuthCheckbox.setSelected(authLdapData.isEnabled());
			enableLDAP();
			enableLdapAuthCheckbox.setUnmodifiedValue(authLdapData.isEnabled());

			ldapHostNameField.setText(authLdapData.getHost());
			ldapHostNameField.setUnmodifiedValue(authLdapData.getHost());

			searchAcountField.setText(authLdapData.getSearchAccount());
			searchAcountField.setUnmodifiedValue(authLdapData.getSearchAccount());

			userSearchBaseField.setText(authLdapData.getUserSearchBase());
			userSearchBaseField.setUnmodifiedValue(authLdapData.getUserSearchBase());

			userSearchFilterField.setText(authLdapData.getUserSearchFilter());
			userSearchFilterField.setUnmodifiedValue(authLdapData.getUserSearchFilter());

			userSearchScopeField.setSelectedItemByKey(authLdapData.getUserSearchScope());
			userSearchScopeField.setUnmodifiedValue(new ItemData(authLdapData.getUserSearchScope(), authLdapData.getUserSearchScope()));

			groupSearchBaseField.setText(authLdapData.getGroupSearchBase());
			groupSearchBaseField.setUnmodifiedValue(authLdapData.getGroupSearchBase());

			groupSearchFilterField.setText(authLdapData.getGroupSearchFilter());
			groupSearchFilterField.setUnmodifiedValue(authLdapData.getGroupSearchFilter());

			groupSearchScopeField.setSelectedItemByKey(authLdapData.getGroupSearchScope());
			groupSearchScopeField.setUnmodifiedValue(new ItemData(authLdapData.getGroupSearchScope(), authLdapData.getGroupSearchScope()));

			userIdentifyingAttributeField.setText(authLdapData.getUserIdAttribute());
			userIdentifyingAttributeField.setUnmodifiedValue(authLdapData.getUserIdAttribute());

			groupIdentifyingAttributeField.setText(authLdapData.getGroupIdAttribute());
			groupIdentifyingAttributeField.setUnmodifiedValue(authLdapData.getGroupIdAttribute());
			
			groupAttributeIdentifyingUserField.setText(authLdapData.getGroupMemberAttribute());
			groupAttributeIdentifyingUserField.setUnmodifiedValue(authLdapData.getGroupMemberAttribute());

			passwordAccountField.setText(authLdapData.getSearchPassword());
			passwordAccountField.setUnmodifiedValue(authLdapData.getSearchPassword());

			sslIndicatorCheckbox.setSelected(authLdapData.isSslIndicator());
			sslIndicatorCheckbox.setUnmodifiedValue(authLdapData.isSslIndicator());

			Integer authLdapPort = IntegerValidator.getInstance().validate(authLdapData.getPort());
			if (authLdapPort == null) {
				authLdapPort = GSConstants.S_AD_LDAP_PORT;
			}

			boolean flag = authLdapPort == GSConstants.S_AD_LDAP_PORT;

			ldapAuthPortCheckbox.setSelected(flag);
			ldapAuthPortCheckbox.setUnmodifiedValue(flag);

			ldapAuthPortSpinner.setEnabled(!flag);
			ldapAuthPortSpinner.setUnmodifiedValue(!flag);

			ldapAuthPortSpinner.setValue(authLdapPort);
			ldapAuthPortSpinner.setUnmodifiedValue(authLdapPort);

		} else if (key instanceof ResponseMessage) {
			handleResponseMessage((ResponseMessage) key);
		} else {
			enableLDAP();
		}
	}

	/**
	 *
	 */
	private void enableLDAP() {
		enableLdapAuthCheckbox.setEnabled(!doc.isRadiusEnabled());
		if(doc.isRadiusEnabled()){
            enableLdapAuthCheckbox.getCheckBox().setToolTipText("LDAP Authentication is disabled since RADIUS is enabled.");
        }
	}

	/**
	 *
	 * @param msg the message to handle
	 */
	private void handleResponseMessage(ResponseMessage msg) {
		if (this.enableLdapAuthCheckbox.isSelected() && requiredUpdate) {
			for (ResponseMessage message : msg.getResponseMessages(LDAPSettingsResponseMessage.class)) {
				String msgText = message.getMessage();

				OpStatus status;
				BiCNetPluginClientLogSeverity severity;

				switch (message.getType()) {
					case ERROR_MESSAGE:
						status = OpStatus.FAILED;
						severity = BiCNetPluginClientLogSeverity.ERROR;
						break;
					case WARNING_MESSAGE:
						status = OpStatus.WITH_WARNINGS;
						severity = BiCNetPluginClientLogSeverity.WARNING;
						break;
					default:
						status = OpStatus.SUCCESSFUL;
						severity = BiCNetPluginClientLogSeverity.INFORMATION;
						break;
				}

				// create the popup details
				NotificationPopupDetails popupDetails = new NotificationPopupDetails(status, msgText, BiCNetComponentType.SECURITY_MANAGER, "");
				popupDetails.setTitle(USMStringTable.IDS_AA_WINDOW_LDAP_AUTH_SETTINGS.toString());
				// show popup
				NotificationPopupManager.getInstance().showPopup(popupDetails);

				BiCNetPluginClientLogEntry entry = new DefaultPluginClientLogEntry(severity, getTitle(), msgText);
				try {
					USMUtility.getInstance().getCfPluginSite().addClientLogEntry(entry);
				} catch (BiCNetPluginException e) {
					LOGGER.error("Unable to write to Client Log", e);
				}
			}
		}
	}

	@Override
	public void saveData(SecuritySettingsData data) {

		boolean enabledLdapAuth = enableLdapAuthCheckbox.isSelected();
		boolean isSslIndicator = sslIndicatorCheckbox.isSelected();
		String host = ldapHostNameField.getText();
		String port = String.valueOf(ldapAuthPortSpinner.getValue());
		String searchAccount = searchAcountField.getText();
		String searchPassword = String.valueOf(passwordAccountField.getPassword());
		String userSearchBase = userSearchBaseField.getText();
		String userSearchFilter = userSearchFilterField.getText();
		String userSearchScope = userSearchScopeField.getSelectedStringValue();
		String groupSearchBase = groupSearchBaseField.getText();
		String groupSearchFilter = groupSearchFilterField.getText();
		String groupSearchScope = groupSearchScopeField.getSelectedStringValue();
		String userIdentifyingAttribute = userIdentifyingAttributeField.getText();
		String groupIdentifyingAttribute = groupIdentifyingAttributeField.getText();
		String groupMemberAttribute = groupAttributeIdentifyingUserField.getText();
		
		LDAPConfigurationData ldapConfigurationData = new LDAPConfigurationData(
				enabledLdapAuth,
				isSslIndicator,
				host,
				port,
				searchAccount,
				searchPassword,
				userSearchBase,
				userSearchFilter,
				LDAPSearchScope.fromName(userSearchScope),
				userIdentifyingAttribute,
				groupSearchBase,
				groupSearchFilter,
				LDAPSearchScope.fromName(groupSearchScope),
				groupIdentifyingAttribute,
				groupMemberAttribute
		);

		data.getData().setLdapConfigurationData(ldapConfigurationData);
	}

	/**
	 * Add listener to listener list.
	 * 
	 * @param listener
	 *            listener
	 */
	@Override
	public void addChangeListener(ChangeListener listener) {
		changeListeners.add(listener);
	}

	@Override
	public void stateChanged(ChangeEvent e) {
		if (e != null) {
			if (e.getSource().equals(enableLdapAuthCheckbox)) {
				enableLDAPAuth(ldapAuthPanel, enableLdapAuthCheckbox.isSelected());
				doc.setLDAPEnabled(enableLdapAuthCheckbox.isSelected());
			} else if (e.getSource().equals(ldapAuthPortCheckbox)) {
				validateLDAPAuthPort(ldapAuthPortCheckbox.isSelected());
			}
		}

		requiredUpdate = isPageDirty();

		if (propertyPageSite != null) {
			propertyPageSite.eventPageStatusChanged(this);
		}

		for (ChangeListener listener : changeListeners) {
			listener.stateChanged(null);
		}
	}

	private final class LDAPDocumentListener implements DocumentListener {
		@Override
		public void removeUpdate(DocumentEvent e) {
			stateChanged(null);
		}
		@Override
		public void insertUpdate(DocumentEvent e) {
			stateChanged(null);
		}
		@Override
		public void changedUpdate(DocumentEvent e) {
			stateChanged(null);
		}
	}
}