package com.ossnms.bicnet.securitymanagement.client.useradministration.useradmin;

import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.tools.jfx.components.JfxMenuItem;
import com.ossnms.tools.jfx.table.JfxTable;
import com.ossnms.tools.jfx.table.JfxTablePosAction;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;

/**
 *
 */
public final class UAUserAdministrationTable extends JfxTable {
    private static final long serialVersionUID = 7648579360972696228L;

    private UAUserAdministrationView parentView;

    private TableCellRenderer iconRenderer = new UAUserAdministrationIconRenderer();
    private TableCellRenderer defaultRenderer = new DefaultTableCellRenderer();

    public UAUserAdministrationTable(TableModel model) {
        super(model);

        setAutoResizeMode(JfxTable.AUTO_RESIZE_ALL_COLUMNS);
        setHeaderToolTipsEnabled(true);
        setDefaultToolTipBehaviour(true);

        // Setup context menus
        setupMenu();
    }

    private void setupMenu() {
        // Modify...
        JfxTablePosAction actionUserModify = new JfxTablePosAction(ResourcesIconFactory.ICON_TOOL_MOD_16, USMStringTable.IDS_UA_BUTTON_MODIFY, null, null);
        actionUserModify.setIfConditionHandler(action -> {
            boolean bEnabled = true;
            bEnabled = parentView.getButtonState(USMButtonTypeEnum.BTN_TYPE_MODIFY);
            return bEnabled;
        });

        actionUserModify.setIfPerformedHandler(action -> parentView.handleButtonClick(USMButtonTypeEnum.BTN_TYPE_MODIFY));
        addTablePopupItem(new JfxMenuItem(actionUserModify), false);

        // Delete...
        JfxTablePosAction actionUserDelete = new JfxTablePosAction(ResourcesIconFactory.ICON_TOOL_DELETE_16, USMStringTable.IDS_UA_BUTTON_DELETE, null, null);
        actionUserDelete.setIfConditionHandler(action -> {
            boolean bEnabled = true;
            bEnabled = parentView.getButtonState(USMButtonTypeEnum.BTN_TYPE_DELETE);
            return bEnabled;
        });

        actionUserDelete.setIfPerformedHandler(action -> parentView.handleButtonClick(USMButtonTypeEnum.BTN_TYPE_DELETE));
        addTablePopupItem(new JfxMenuItem(actionUserDelete), false);
        addTablePopupSeparator(false);

        // Force Logoff...
        JfxTablePosAction actionUserForceLogoff = new JfxTablePosAction(ResourcesIconFactory.ICON_TOOL_FORCELOGOFF_16, USMStringTable.IDS_UA_BUTTON_FORCE_LOGOFF, null, null);
        actionUserForceLogoff.setIfConditionHandler(action -> {
            boolean bEnabled = true;
            bEnabled = parentView.getButtonState(USMButtonTypeEnum.BTN_TYPE_FORCE_LOGOFF);
            return bEnabled;
        });

        actionUserForceLogoff.setIfPerformedHandler(action -> parentView.handleButtonClick(USMButtonTypeEnum.BTN_TYPE_FORCE_LOGOFF));
        addTablePopupItem(new JfxMenuItem(actionUserForceLogoff), false);
        addTablePopupSeparator(false);

        // Unlock...
        JfxTablePosAction actionUserUnlock = new JfxTablePosAction(ResourcesIconFactory.ICON_TOOL_UNLOCK_USER_16, USMStringTable.IDS_UA_BUTTON_UNLOCK, null, null);
        actionUserUnlock.setIfConditionHandler(action -> {
            boolean bEnabled = true;
            bEnabled = parentView.getButtonState(USMButtonTypeEnum.BTN_TYPE_UNLOCK);
            return bEnabled;
        });

        actionUserUnlock.setIfPerformedHandler(action -> parentView.handleButtonClick(USMButtonTypeEnum.BTN_TYPE_UNLOCK));
        addTablePopupItem(new JfxMenuItem(actionUserUnlock), false);

        // Activate...
        JfxTablePosAction actionUserActivate = new JfxTablePosAction(ResourcesIconFactory.ICON_TOOL_ACTIVATE_USER_16, USMStringTable.IDS_UA_BUTTON_ACTIVATE, null, null);
        actionUserActivate.setIfConditionHandler(action -> {
            boolean bEnabled = true;
            bEnabled = parentView.getButtonState(USMButtonTypeEnum.BTN_TYPE_ACTIVATE);
            return bEnabled;
        });

        actionUserActivate.setIfPerformedHandler(action -> parentView.handleButtonClick(USMButtonTypeEnum.BTN_TYPE_ACTIVATE));
        addTablePopupItem(new JfxMenuItem(actionUserActivate), false);

        // Deactivate...
        JfxTablePosAction actionUserDeactivate = new JfxTablePosAction(ResourcesIconFactory.ICON_TOOL_DEACTIVATE_USER_16, USMStringTable.IDS_UA_BUTTON_DEACTIVATE, null, null);
        actionUserDeactivate.setIfConditionHandler(action -> {
            boolean bEnabled = true;
            bEnabled = parentView.getButtonState(USMButtonTypeEnum.BTN_TYPE_DEACTIVATE);
            return bEnabled;
        });

        actionUserDeactivate.setIfPerformedHandler(action -> parentView.handleButtonClick(USMButtonTypeEnum.BTN_TYPE_DEACTIVATE));
        addTablePopupItem(new JfxMenuItem(actionUserDeactivate), false);
    }

    /**
     * @param view instance of UAUserAdministrationView
     */
    public void setParentView(UAUserAdministrationView view) {
        parentView = view;
    }

    /**
     * retrieve the renderer associated with a cell
     *
     * @param row    the cell's row
     * @param column the cell's column
     * @return the cell's renderer
     */
    @Override
    public TableCellRenderer getCellRenderer(int row, int column) {
        int nModelIndex = convertColumnIndexToModel(column);
        switch (nModelIndex) {
            case 0:
            case 1:
                return iconRenderer;
            case 7:
                return new DefaultTableCellRenderer() {

                    private static final long serialVersionUID = 1L;

                    @Override
                    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                        if (value != null) {
                            setHorizontalAlignment(JLabel.RIGHT);
                        }
                        return this;
                    }
                };
            default:
                return defaultRenderer;
        }
    }
}