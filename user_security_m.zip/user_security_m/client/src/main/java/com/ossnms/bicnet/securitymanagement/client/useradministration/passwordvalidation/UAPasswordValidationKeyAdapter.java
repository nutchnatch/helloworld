package com.ossnms.bicnet.securitymanagement.client.useradministration.passwordvalidation;

import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.auth.PasswordValidationRulesConfigurationData;
import com.ossnms.tools.jfx.JfxValidatorUtils;
import com.ossnms.tools.jfx.components.JfxCheckBox;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxTextField;

import javax.swing.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 *
 */
public class UAPasswordValidationKeyAdapter extends KeyAdapter{

    private JPasswordField editPassword;
    private JfxTextField username;
    private JfxLabel editPasswordIcon;
    private JPasswordField editConfirmPassword;
    private JLabel editConfirmPasswordIcon;
    private boolean isModifyUserView;
    private JfxCheckBox mustChangePasswordCheckbox;
    private JfxTextField employeeNumber;
    private JfxTextField lastName;
    private JfxTextField firstName;
    private PasswordValidationRulesConfigurationData passwordValidationRules;

    public UAPasswordValidationKeyAdapter(JPasswordField editPassword, JfxTextField username, JfxLabel editPasswordIcon,
                                          JPasswordField editConfirmPassword, JLabel editConfirmPasswordIcon,
                                          boolean isModifyUserView, JfxCheckBox mustChangePasswordCheckbox,
                                          JfxTextField employeeNumber, JfxTextField lastName, JfxTextField firstName,
                                          PasswordValidationRulesConfigurationData passwordValidationRules) {

        this.editPassword = editPassword;
        this.username = username;
        this.editPasswordIcon = editPasswordIcon;
        this.editConfirmPassword = editConfirmPassword;
        this.editConfirmPasswordIcon = editConfirmPasswordIcon;
        this.isModifyUserView = isModifyUserView;
        this.mustChangePasswordCheckbox = mustChangePasswordCheckbox;
        this.employeeNumber = employeeNumber;
        this.lastName = lastName;
        this.firstName = firstName;
        this.passwordValidationRules = passwordValidationRules;
    }

    @Override
    public void keyReleased(KeyEvent e) {

        String currentDate = USMUtility.getInstance().convertDateToClientTimeZone(null);

        UAPasswordValidationParams params = new UAPasswordValidationParams(String.valueOf(editPassword.getPassword()),
                employeeNumber.getText(), lastName.getText(), firstName.getText(), null,
                String.valueOf(editConfirmPassword.getPassword()), username.getText(), currentDate);

        String validationResult = UAPasswordValidationUtility.validateNewPasswordFieldAndShowWarning(params, passwordValidationRules);
        USMUtility.getInstance().updateWarningMessage(validationResult, editPasswordIcon);
        JfxValidatorUtils.validateConfirmPasswordFieldAndShowWarning(editPassword, editConfirmPassword, editConfirmPasswordIcon);

        if (isModifyUserView && mustChangePasswordCheckbox.isEnabled()) {
            mustChangePasswordCheckbox.setSelected(editPassword.getPassword().length != 0);
        }
    }

}
