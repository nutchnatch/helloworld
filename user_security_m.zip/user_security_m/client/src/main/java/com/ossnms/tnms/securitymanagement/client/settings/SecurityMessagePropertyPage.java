/*
 * Copyright Coriant 2013
 * The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
 *
 */
package com.ossnms.tnms.securitymanagement.client.settings;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPageSite;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSettingsPropertyPage;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxCheckBox;
import com.ossnms.tools.jfx.components.JfxTextArea;
import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;



public final class SecurityMessagePropertyPage extends JPanel implements ISecurityPropertyPage {

    private static final long serialVersionUID = -656311816101096636L;

    private static final Logger LOGGER = Logger.getLogger(SecurityMessagePropertyPage.class);

    private BiCNetPluginPropertyPageSite propertyPageSite;

    private SecuritySettingsDocument doc;

    private JfxCheckBox advisoryMsgDisplayedCheckbox;

    private JfxTextArea txtAreaAdvisoryMessage;

    private JfxButton defaultButton = new JfxButton(JfxStringTable.IDS_Default);

    private final List<ChangeListener> changeListeners = new ArrayList<ChangeListener>();

    public SecurityMessagePropertyPage(SecuritySettingsDocument doc) {
        this.doc = doc;
        initLayout();
        initListeners();
        setGuiNames();
    }

    private void initListeners() {
        advisoryMsgDisplayedCheckbox.addItemListener(e -> SecurityMessagePropertyPage.this.stateChanged(new ChangeEvent(advisoryMsgDisplayedCheckbox)));

        txtAreaAdvisoryMessage.addDocumentListener(new DocumentListener() {

            @Override
            public void removeUpdate(DocumentEvent e) {
                SecurityMessagePropertyPage.this.stateChanged(new ChangeEvent(txtAreaAdvisoryMessage));
            }

            @Override
            public void insertUpdate(DocumentEvent e) {
                SecurityMessagePropertyPage.this.stateChanged(new ChangeEvent(txtAreaAdvisoryMessage));
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                SecurityMessagePropertyPage.this.stateChanged(new ChangeEvent(txtAreaAdvisoryMessage));
            }
        });

        defaultButton.addActionListener(e -> {
            advisoryMsgDisplayedCheckbox.setSelected(false);
            txtAreaAdvisoryMessage.setUndefinedToken(USMStringTable.IDS_GS_ADVISORY_MESSAGE_MSG.toString());
            txtAreaAdvisoryMessage.setUndefined(true);

            if (propertyPageSite != null) {
                propertyPageSite.eventPageStatusChanged(SecurityMessagePropertyPage.this);
            }
        });
    }

    private void initLayout() {
        this.advisoryMsgDisplayedCheckbox =
                new JfxCheckBox(USMStringTable.IDS_SS_ADVISORY_MESSAGE_CHECKBOX_LABEL.toString());
        this.advisoryMsgDisplayedCheckbox.setMnemonic(USMStringTable.IDS_SS_ADVISORY_MESSAGE_CHECKBOX_LABEL
                .getMnemonic());
        this.txtAreaAdvisoryMessage = new JfxTextArea();
        this.txtAreaAdvisoryMessage.setWrapStyleWord(true);
        this.txtAreaAdvisoryMessage.setLineWrap(true);

        JScrollPane advisoryMsgScrollPane = new JScrollPane(this.txtAreaAdvisoryMessage);

        setLayout(new GridBagLayout());
        setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);

        add(this.advisoryMsgDisplayedCheckbox, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0,
                        JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS,
                        JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        add(advisoryMsgScrollPane, new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0, GridBagConstraints.BASELINE_LEADING,
                GridBagConstraints.BOTH, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        add(defaultButton, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0, GridBagConstraints.SOUTHWEST,
                GridBagConstraints.NONE, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0), 0, 0));
    }

    /**
     * Helper function that is used to set the Names of all the editable components within the Window.
     * 
     * Strings in this function are not to be Internationalized.
     */
    private void setGuiNames() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setGuiNames() Entry");
        }

        advisoryMsgDisplayedCheckbox.setName("DisplayAdvisoryMessage");
        txtAreaAdvisoryMessage.setName("AdvisoryMessage");

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setGuiNames() Exit");
        }
    }

    @Override
    public void actionApply() {
        // do nothing
    }

    @Override
    public void actionCancel() {
    }

    @Override
    public void eventClosing() {
    }

    @Override
    public void eventOpened() {
    }

    @Override
    public JComponent getComponent() {
        return this;
    }

    @Override
    public String getID() {
        return USMCommandID.S_UI_ID_SECURITY_SETTINGS_MESSAGE.getMenuString();
    }

    @Override
    public String getTitle() {
        return USMStringTable.IDS_SS_ADVISORY_MESSAGE_TAB_TITLE.toString();
    }

    @Override
    public boolean isPageDirty() {
        GSGeneralSettingData savedSettings = doc.getGeneralSettingsData();

        if (savedSettings == null) {
            return true;
        }

        if (advisoryMsgDisplayedCheckbox.isSelected() != savedSettings.isShowAdvisoryMessage()) {
            return true;
        }

        if (!txtAreaAdvisoryMessage.getText().equals(savedSettings.getAdvisoryMessage())) {
            return true;
        }

        return false;
    }

    @Override
    public void setObjects(IManagedObjectMarkable[] objects) {
        // Do nothing
    }

    @Override
    public void setPageSite(BiCNetPluginPropertyPageSite site) {
        this.propertyPageSite = site;
    }

    @Override
    public void setReadOnly(boolean arg0) {
        // Do nothing
    }

    @Override
    public void update() {
        // Do nothing
    }

    @Override
    public void validateInput() throws BiCNetPluginException {
        String advisoryMessage = txtAreaAdvisoryMessage.getText();

        if (advisoryMsgDisplayedCheckbox.isSelected() && (advisoryMessage == null || advisoryMessage.trim().isEmpty())) {
            throw new BiCNetPluginException(USMStringTable.IDS_SS_DIALOG_MESSAGE_EMPTY_ADVISORY_CONFIG.getText());
        }
    }

    @Override
    public BiCNetPluginSettingsPropertyPage[] getChildPages() {
        return null;
    }

    @Override
    public boolean isEnabled(IManagedObject[] arg0) {
        return USMUtility.getInstance().checkIfOperatorHasPermission(
                USMCommandID.S_UI_ID_GENERAL_SECURITY_SETTINGS.getMenuString());
    }

    /**
     * ***********************************************************************
     * Sets the interface of the enclosing frame provided by the application.
     * This method is called before the view is displayed. The view should
     * store the given reference for later use.
     *
     * @param frame Reference to plug-in frame.
     *              ************************************************************************
     */
    @Override
    public void setFrame(BiCNetPluginFrame frame) {

    }

    @Override
    public void updateData(Object key) {
        if (key instanceof GSGeneralSettingData) {
            GSGeneralSettingData data = (GSGeneralSettingData) key;

            advisoryMsgDisplayedCheckbox.setSelected(data.isShowAdvisoryMessage());
            advisoryMsgDisplayedCheckbox.setUnmodifiedValue(data.isShowAdvisoryMessage());

            if (USMStringTable.IDS_GS_ADVISORY_MESSAGE_MSG.toString().equals(data.getAdvisoryMessage())) {
                txtAreaAdvisoryMessage.setUndefinedToken(USMStringTable.IDS_GS_ADVISORY_MESSAGE_MSG.toString());
                txtAreaAdvisoryMessage.setUndefined(true);
            }
            else {
                txtAreaAdvisoryMessage.setText(data.getAdvisoryMessage());
            }
            txtAreaAdvisoryMessage.setUnmodifiedValue(data.getAdvisoryMessage());
        }
    }

    @Override
    public void saveData(SecuritySettingsData data) {
        GSGeneralSettingData settingsData = data.getData();
        settingsData.setShowAdvisoryMessage(advisoryMsgDisplayedCheckbox.isSelected());
        settingsData.setAdvisoryMessage(txtAreaAdvisoryMessage.getText());
    }

    /**
     * Add listener to listener list.
     * 
     * @param listener
     *            listener
     */
    public void addChangeListener(ChangeListener listener) {
        changeListeners.add(listener);
    }

    /**
     * Remove listener form listener list.
     * 
     * @param listener
     *            listener
     */
    public void removeChangeListener(ChangeListener listener) {
        changeListeners.remove(listener);
    }

    @Override
    public void stateChanged(ChangeEvent e) {
        if (propertyPageSite != null) {
            propertyPageSite.eventPageStatusChanged(this);
            for (ChangeListener listener : changeListeners) {
                listener.stateChanged(null);
            }
        }
    }
}
