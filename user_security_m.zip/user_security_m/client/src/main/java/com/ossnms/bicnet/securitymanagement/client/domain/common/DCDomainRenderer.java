/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Mar-2005	Muyeen Munaver	CF000137 - #678: Add a method getType or so to the ISecurableObject
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.domain.common;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.model.ManagedObjectType;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableBase;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import java.awt.*;

/**
 * 
 * This is the renderer class for DC trees which informs the tree to display the colour of NEs which have not been
 * assigned to any of the creatd domains to be displayed in a different colour.
 */
public final class DCDomainRenderer extends DefaultTreeCellRenderer {
    /**
     * This is the overridden method of the DefaultTreeCellRenderer class which is used to display the tree class
     * elements
     * 
     * @param tree JTree the receiver is being configured for.
     * @param value The object of the tree which needs to be rendered.
     * @param sel If selected is true, the cell will be drawn as if selected.
     * @param expanded If expanded is true the node is currently expanded.
     * @param leaf If leaf is true the node represets a leaf
     * @param row Identifies the row
     * @param hasFocus If hasFocus is true the node currently has focus.
     * @return Component The Component that the renderer uses to draw the value.
     */
    @Override
    public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus) {
        super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);

        if (leaf && isGlobalDomainOnly(value)) {
            setForeground(java.awt.Color.BLUE);
        }

        setIcon(getIconToDisplay(value));
        return this;
    }

    /**
     * Helper function to validate that the selected object is a NE and belongs to global domain only
     * 
     * @param value The object which is to be rendered by the JTree using this renderer
     * @return boolean Returns true if the object value is a NE and is assigned to global domain only.
     */
    private boolean isGlobalDomainOnly(Object value) {
        Object node = ((DefaultMutableTreeNode) value).getUserObject();
        if (node instanceof BSSecurableObject) {
            if (((BSSecurableObject) node).belongOnlyToGlobalDomain()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Helper function to return the Icon that should be used for the object.
     * 
     * @param value The object which is to be rendered by the JTree using this renderer
     * @return Icon The Icon that should be used for the display purpose.
     */
    private Icon getIconToDisplay(Object value) {
        Icon img = ResourcesIconFactory.ICON_LIST_SERVER_16;
        Object node = ((DefaultMutableTreeNode) value).getUserObject();
        
        //this might be BSSecurableObject or BSSecurableObjectContainer, but we don't care because we can take advantage of polymorphism
        if (node != null && node instanceof BSSecurableBase) {
            BSSecurableBase secObj = (BSSecurableBase) node;

            try {
				if (isEM(secObj)) {
					return USMUtility.getInstance().getSecuritySite().getNEObjectProvider().getEmIcon(new EMIdItem(extractId(secObj)));
				} else if(isMediator(secObj)){
                    return USMResourcesIconFactory.getIconForManagedObjectType(secObj.getManagedObjectType());
                } else if (isNE(secObj)) {
					return USMUtility.getInstance().getSecuritySite().getNEObjectProvider().getNeIcon(new NEIdItem(extractId(secObj)));
				} else if (isSubscriber(secObj)) {
                    return ResourcesIconFactory.ICON_TOOL_SUBSCRIBERS_16;
                }  else {
                    return USMResourcesIconFactory.getIconForManagedObjectType(secObj.getManagedObjectType());
                }
            } catch (Exception e) {
                return USMResourcesIconFactory.getIcon(null, secObj.getManagedObjectType());
            }
        }
        return img;
    }

    /**
     *
     * @param secObj
     * @return
     */
    private boolean isNE(BSSecurableBase secObj) {
        return ManagedObjectType.NE.equals(secObj.getManagedObjectType());
    }

    /**
    *
    * @param secObj
    * @return
    */
    private boolean isEM(BSSecurableBase secObj) {
       return ManagedObjectType.EM.equals(secObj.getManagedObjectType());
    }

    /**
     *
     * @param secObject
     * @return
     */
    private boolean isMediator(BSSecurableBase secObject){
        return ManagedObjectType.MEDIATOR.equals(secObject.getManagedObjectType());
    }

    /**
     *
     * @param secObject
     * @return
     */
    private boolean isSubscriber(BSSecurableBase secObject){
        return ManagedObjectType.COMMON_CONTAINER.equals(secObject.getManagedObjectType());
    }

    /**
     *
     * @param secObj
     * @return
     */
    private int extractId(BSSecurableBase secObj) {
        if((secObj.getUniqueName() != null) && (secObj.getUniqueName().indexOf("=") > 0) && (!secObj.getUniqueName().substring(secObj.getUniqueName().indexOf("=") + 1).trim().isEmpty()) ){
            return Integer.parseInt(secObj.getUniqueName().substring(secObj.getUniqueName().indexOf("=") + 1));
        }
        return 0;
    }

}
