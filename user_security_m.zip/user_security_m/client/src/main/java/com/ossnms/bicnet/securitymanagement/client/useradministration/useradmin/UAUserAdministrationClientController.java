/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   UAUserAdministrationClientController
 * Author:      Babu B
 * Substitute	Vinay Purohit
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER.VIEW
 *       : TNMS.DX2.SM.FORCE_LOGOFF
 *       : TNMS.DX2.SM.USER.CREATE
 *       : TNMS.DX2.SM.USER.CONFIGURE
 * 	     : TNMS.DX2.SM.USER.ASSIGN
 *       : TNMS.DX2.SM.USER.STATUS
 * 		 :
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 31-Jan-2005  Babu B          CF001454 Wrong behavior in "Force logoff" for different scenarios (TCMId-313)
 * 18-Mar-2005  Asif khan R     CF001755 Error Messages when LDAP not available
 * 
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration.useradmin;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMBaseController;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobActivateUsers;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobDeactivateUsers;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobDeleteUsers;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobForcedLogoffUsers;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobGetAllUsers;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobUnlockUsers;
import com.ossnms.bicnet.securitymanagement.common.auth.AAMessageType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAStatus;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * This class implements the controller for the User administration View.This
 * listens to the notifications and updates the view
 */
class UAUserAdministrationClientController extends USMBaseController {
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(UAUserAdministrationClientController.class);

    /**
     * This is the constructor
     *
     * @param pView -
     *               The associated with the controller
     */
    UAUserAdministrationClientController(USMBaseView pView) {
        super(pView);

        registerInterestedNotificationIds(getInterestedNotifications());
    }

    /**
     * Function to return a Vector which contains the list of types that this
     * controller is interested in.
     *
     * @return List -
     * The List which contains the notification the controller is
     * interested in.
     */
    private List<USMBaseMsgType> getInterestedNotifications() {
        LOGGER.debug("getInterestedNotifications() in the method");

        List<USMBaseMsgType> vectorForNotification = new ArrayList<>();
        vectorForNotification.add(UAMessageType.S_UA_NOT_CREATE_USER);
        vectorForNotification.add(UAMessageType.S_UA_NOT_MODIFY_USER);
        vectorForNotification.add(UAMessageType.S_UA_NOT_REMOVE_USER);

        vectorForNotification.add(UAMessageType.S_UA_NOT_ACTIVATE_USER);
        vectorForNotification.add(UAMessageType.S_UA_NOT_DEACTIVATE_USER);
        vectorForNotification.add(UAMessageType.S_UA_NOT_UNLOCK_USER);
        vectorForNotification.add(UAMessageType.S_UA_NOT_FORCED_LOGOFF_USER);

        vectorForNotification.add(AAMessageType.AA_NOTIFICATION_USER_LOGGEDIN);
        vectorForNotification.add(AAMessageType.AA_NOTIFICATION_USER_LOGGEDOUT);
        vectorForNotification.add(UAMessageType.S_UA_NOTIFICATION_USER_LOGIN_FAILED);

        LOGGER.debug("getInterestedNotifications() exit");

        return vectorForNotification;
    }

    /**
     * This method initiates the fetching of all the User's to be displayed in the User Administartion Window. Forwards
     * the request to the UA delegate
     *
     * @return boolean - Indicates whether it was possible to send the request or not.
     */
    boolean sendReqToGetAllUsers() {
        LOGGER.debug("sendReqToGetAllUsers() Entry");

        UAJobGetAllUsers objJobgetAllUser = new UAJobGetAllUsers(this);

        LOGGER.debug("sendReqToGetAllUsers() Exit");
        return queueJob(objJobgetAllUser);
    }

    /**
     * This method initiates the deletion of a given set of user acounts.
     * Forwards the request to the UA delegate
     *
     * @param lstSelectedUsers Users selected in the window
     * @return boolean -
     * Indicates whether it was possible to send the request or not.
     */
    boolean sendReqToDeleteSelectedUsers(List<String> lstSelectedUsers) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "Sending request to delete the following users : "
                            + lstSelectedUsers);
        }

        UAJobDeleteUsers objJobDeleteUsers = new UAJobDeleteUsers(this);
        objJobDeleteUsers.setUsers(lstSelectedUsers);
        return queueJob(objJobDeleteUsers);
    }

    /**
     * This method initiates the activation of a given set of user acounts.
     * Forwards the request to the UA delegate
     *
     * @param pLstSelectedUsers Users selected in the window
     * @return boolean -
     * Indicates whether it was possible to send the request or not.
     */
    boolean sendReqToActivateSelectedUsers(List pLstSelectedUsers) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Sending request to activate the following users : " + pLstSelectedUsers);
        }

        UAJobActivateUsers objJobActivateUsers = new UAJobActivateUsers(this);
        objJobActivateUsers.setUsers(pLstSelectedUsers);
        return queueJob(objJobActivateUsers);
    }

    /**
     * This method initiates the deactivation of a given set of user accounts.
     * Forwards the request to the UA delegate
     *
     * @param pLstSelectedUsers Users selected in the window
     * @return boolean -
     * Indicates whether it was possible to send the request or not.
     */
    boolean sendReqToDeactivateSelectedUsers(List pLstSelectedUsers) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "Sending request to deactivate the following users : "
                            + pLstSelectedUsers);
        }
        UAJobDeactivateUsers objJobDeactivateUsers =
                new UAJobDeactivateUsers(this);
        objJobDeactivateUsers.setUsers(pLstSelectedUsers);
        return queueJob(objJobDeactivateUsers);
    }

    /**
     * This method initiates the unlocking of a given set of user acounts.
     * Forwards the request to the UA delegate
     *
     * @param pLstSelectedUsers Users selected in the window
     * @return boolean -
     * Indicates whether it was possible to send the request or not.
     */
    boolean sendReqToUnlockSelectedUsers(List pLstSelectedUsers) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "Sending request to unlock the following users : "
                            + pLstSelectedUsers);
        }

        UAJobUnlockUsers objJobUnlockUsers = new UAJobUnlockUsers(this);
        objJobUnlockUsers.setUsers(pLstSelectedUsers);
        return queueJob(objJobUnlockUsers);
    }

    /**
     * This method initiates the Forced Logoff of a given set of user accounts.
     * Forwards the request to the UA delegate
     *
     * @param lstSelectedUsers Users selected in the window
     * @return boolean -
     * Indicates whether it was possible to send the request or not.
     */
    boolean sendReqToForcedLogoffSelectedUsers(List<String> lstSelectedUsers) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "Sending request to logoff the following users : "
                            + lstSelectedUsers);
        }

        UAJobForcedLogoffUsers objJobForcedLogoffUsers =
                new UAJobForcedLogoffUsers(this);
        objJobForcedLogoffUsers.setUsers(lstSelectedUsers);
        return queueJob(objJobForcedLogoffUsers);
    }

    /**
     * Helper method called by the framework when a notification is received.
     * Forwards to the appropriate method
     */
    @Override
    public void handleNotification(USMMessage msg) {
        USMBaseMsgType type = msg.getMessageType();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleNotification - Entry " + msg);
        }

        if (type.equals(UAMessageType.S_UA_NOT_CREATE_USER)) {
            handleNotifCreatedUsers(msg);

        } else if (type.equals(UAMessageType.S_UA_NOT_MODIFY_USER)) {
            handleNotifModifiedUsers(msg);

        } else if (type.equals(UAMessageType.S_UA_NOT_REMOVE_USER)) {
            handleNotifRemoveUsers(msg);

        } else if (type.equals(UAMessageType.S_UA_NOT_ACTIVATE_USER)) {
            handleNotifActivatedUsers(msg);

        } else if (type.equals(UAMessageType.S_UA_NOT_DEACTIVATE_USER)) {
            handleNotifDeactivatedUsers(msg);

        } else if (type.equals(UAMessageType.S_UA_NOT_UNLOCK_USER)) {
            handleNotifUnlockedUsers(msg);

        } else if (type.equals(AAMessageType.AA_NOTIFICATION_USER_LOGGEDIN)) {
            handleNotifUserLoggedIn(msg);

        } else if (type.equals(AAMessageType.AA_NOTIFICATION_USER_LOGGEDOUT)) {
            handleNotifUserLoggedOut(msg);

        } else if (type.equals(UAMessageType.S_UA_NOTIFICATION_USER_LOGIN_FAILED)) {
            handleNotifUserLoginFailure(msg);

        }
    }

    /**
     * Forward user modified notification to window for further handling
     *
     * @param pMsg USMMessage encapsulating the modified user
     */
    private void handleNotifModifiedUsers(USMMessage pMsg) {

        LOGGER.debug("handleModifiedUsers - Entry");

        UAUser objUser = new UAUser();
        objUser.popMe(pMsg);

        getWindow().handleModifiedUsers(objUser);

        LOGGER.debug("handleModifiedUsers - Exit ");
    }

    /**
     * Forward user unlocked notification to window for further handling
     *
     * @param pMsg USMMessage encapsulating the unlocked users
     */
    private void handleNotifUnlockedUsers(USMMessage pMsg) {

        LOGGER.debug("handleUnlockedUsers - Exit");

        int nUnlockedUserCount = pMsg.popInteger();

        List<String> lstUnlockedUsers = new ArrayList<>();
        while (nUnlockedUserCount-- > 0) {
            String strUserId = pMsg.popString();
            lstUnlockedUsers.add(strUserId);
        }
        getWindow().handleUnlockedUsers(lstUnlockedUsers);

        LOGGER.debug("handleUnlockedUsers - Exit");
    }

    /**
     * Forward user logged out notification to window for further handling
     *
     * @param pMsg USMMessage encapsulating the logged out user
     */
    private void handleNotifUserLoggedOut(USMMessage pMsg) {
        LOGGER.debug("handleUserLoggedOut - Entry");

        IEnhancedSessionContext objSessionContext =
                (IEnhancedSessionContext) pMsg.popObject();

        UAUserAdministrationView wndAssociatedView = getWindow();
        if (null != wndAssociatedView) {
            wndAssociatedView.handleUserLoggedOut(objSessionContext);
        }

        LOGGER.debug("handleUserLoggedOut - Exit");
    }

    /**
     * Forward user login failure notification to window for further handling
     *
     * @param pMsg USMMessage encapsulating the user id of user
     */
    private void handleNotifUserLoginFailure(USMMessage pMsg) {

        LOGGER.debug("handleUserLoginFailure - Entry");

        String strUserId = pMsg.popString();
        int nBadPasswordCount = pMsg.popInteger();
        boolean bAccountLocked = pMsg.popBoolean();

        getWindow().handleUserLoginFailure(
                strUserId,
                nBadPasswordCount,
                bAccountLocked);

        LOGGER.debug("handleUserLoginFailure - Exit");
    }

    /**
     * Forward user logged in notification to window for further handling
     *
     * @param pMsg USMMessage encapsulating the logged in user
     */
    private void handleNotifUserLoggedIn(USMMessage pMsg) {

        LOGGER.debug("handleUserLoggedIn - Entry");

        IEnhancedSessionContext objSessionContext =
                (IEnhancedSessionContext) pMsg.popObject();

        String strLastLogonTime = pMsg.popString();

        getWindow().handleUserLoggedIn(objSessionContext, strLastLogonTime);

        LOGGER.debug("handleUserLoggedIn - Exit");
    }

    /**
     * Forward user created notification to window for further handling
     *
     * @param msg USMMessage encapsulating the created users
     */
    private void handleNotifCreatedUsers(USMMessage msg) {

        LOGGER.debug("handleCreatedUsers - Entry");

        UAUser objUser = new UAUser();
        objUser.popMe(msg);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("User created : " + objUser.getUserId());
        }

        getWindow().handleCreatedUsers(objUser);

        LOGGER.debug("handleCreatedUsers - Exit ");
    }

    /**
     * Forward user deleted notification to window for further handling
     *
     * @param msg USMMessage encapsulating the deleted users
     */
    private void handleNotifRemoveUsers(USMMessage msg) {

        LOGGER.debug("handleRemoveUsers - Entry");

        int nDeletedUserCount = msg.popInteger();

        List<String> lstDeletedUsers = new ArrayList<>();
        while (nDeletedUserCount-- > 0) {
            String strUserId = msg.popString();
            lstDeletedUsers.add(strUserId);
        }
        getWindow().handleDeletedUsers(lstDeletedUsers);

        LOGGER.debug("handleRemoveUsers - Exit ");
    }

    /**
     * Forward user deactivated notification to window for further handling
     *
     * @param msg USMMessage encapsulating the deactivated users
     */
    private void handleNotifDeactivatedUsers(USMMessage msg) {

        LOGGER.debug("handleDeactivatedUsers - Entry");

        int nDeactivatedUserCount = msg.popInteger();

        List<String> lstDeactivatedUsers = new ArrayList<>();
        while (nDeactivatedUserCount-- > 0) {
            String strUserId = msg.popString();
            lstDeactivatedUsers.add(strUserId);
        }
        getWindow().handleDeactivatedUsers(lstDeactivatedUsers);

        LOGGER.debug("handleDeactivatedUsers - Exit ");
    }

    /**
     * Forward user activated notification to window for further handling
     *
     * @param msg USMMessage encapsulating the activated users
     */
    private void handleNotifActivatedUsers(USMMessage msg) {

        LOGGER.debug("handleActivatedUsers - Entry");

        int nActivatedUserCount = msg.popInteger();

        List<String> lstActivatedUsers = new ArrayList<>();
        while (nActivatedUserCount-- > 0) {
            String strUserId = msg.popString();
            lstActivatedUsers.add(strUserId);
        }
        getWindow().handleActivatedUsers(lstActivatedUsers);

        LOGGER.debug("handleActivatedUsers - Exit");
    }

    /**
     * Helper method called by the framework when a response is received.
     * Forwards to the appropriate method
     *
     * @param job    reference to the job which resulted in the original request
     * @param result result of executing the given job
     */
    @Override
    public void resultAvailable(USMJob job, USMMessage result) {

        LOGGER.debug("resultAvailable() - Enter");

        USMBaseMsgType msgType = result.getMessageType();

        if (msgType.equals(UAMessageType.S_UA_REQ_GET_ALL_USERS)) {
            handleGetAllUsersResponse(result);
        } else if (msgType.equals(UAMessageType.S_UA_REQ_DELETE_USER)) {
            handleDeleteUsersResponse(result);
//        } else if (msgType.equals(UAMessageType.S_UA_REQ_FORCE_LOGOFF_USER)) {
////            handleForceLogoffUsersResponse(result);
        } else if (msgType.equals(UAMessageType.S_UA_REQ_UNLOCK_USER)) {
            handleUnlockUsersResponse(result);
        } else if (msgType.equals(UAMessageType.S_UA_REQ_ACTIVATE_USER)) {
            handleActivateUsersResponse(result);
        } else if (msgType.equals(UAMessageType.S_UA_REQ_DEACTIVATE_USER)) {
            handleDeactivateUsersResponse(result);
        } else {
            LOGGER.warn("Unknown message type received - " + msgType);
        }

        LOGGER.debug("resultAvailable() - Exit");

    }

    /**
     * @param result
     */
    private void handleDeactivateUsersResponse(USMMessage result) {
        String errStr =
                popListOfStringsAndConcat(
                        result,
                        USMStringTable.getString(USMStringTable.IDS_UA_REASONS_LDAP));
        //Some error has occured for one or more users while deactivating
        if (null != errStr) {
            String completeMessage =
                    USMStringTable.getString(
                            USMStringTable.IDS_UA_DEACTIVATE_USER_ERROR);
            completeMessage += "\n" + errStr;
            getWindow().showErrorMessage(completeMessage);
            LOGGER.error(completeMessage);

        }

    }

    /**
     * @param result
     */
    private void handleActivateUsersResponse(USMMessage result) {
        String errStr =
                popListOfStringsAndConcat(
                        result,
                        USMStringTable.getString(USMStringTable.IDS_UA_REASONS_LDAP));

        //Some error has occured for one or more users while activating
        if (null != errStr) {
            String completeMessage =
                    USMStringTable.getString(
                            USMStringTable.IDS_UA_ACTIVATE_USER_ERROR);
            completeMessage += "\n" + errStr;
            getWindow().showErrorMessage(completeMessage);
            LOGGER.error(completeMessage);

        }

    }

    /**
     * @param result
     */
    private String popListOfStringsAndConcat(USMMessage result, String reason) {
        int n = result.popInteger();
        if (n != 0) {
            StringBuilder str = new StringBuilder();
            for (int i = 0; i < n; ++i) {
                str.append(", ").append(result.popString());
            }
            // This is to remove the first ", " of the list of users which it concatenates
            str.delete(0, 2);
            str.append(":\n").append(reason);
            return str.toString();
        }
        return null;
    }

    /**
     * @param result
     */
    private void handleUnlockUsersResponse(USMMessage result) {
        String errStr =
                popListOfStringsAndConcat(
                        result,
                        USMStringTable.getString(USMStringTable.IDS_UA_REASONS_LDAP));
        //Some error has occurred for one or more users while unlocking
        if (null != errStr) {
            String completeMessage = USMStringTable.getString(USMStringTable.IDS_UA_UNLOCK_USER_ERROR);
            completeMessage += "\n" + errStr;
            getWindow().showErrorMessage(completeMessage);
            LOGGER.error(completeMessage);
        }

    }

//    /**
//     * @param result
//     */
//    private void handleForceLogoffUsersResponse(USMMessage result) {
//
//    }

    /**
     * @param result
     */
    private void handleDeleteUsersResponse(USMMessage result) {
        // Pop the Result of the Operation.
        UAStatus statusObject = new UAStatus();
        statusObject.popMe(result);
        int nUAResult = statusObject.getStatus();

        //If the global error id is failure, then display the error one by one
        if (nUAResult != UAStatus.S_SUCCESS) {
            LOGGER.warn("Error in deleting users");
            String errStr = retrieveErrorMessage(result);
            LOGGER.error(errStr);
            String completeMessage =
                    USMStringTable.getString(
                            USMStringTable.IDS_UA_DELETE_USER_ERROR);
            completeMessage += errStr;
            getWindow().showErrorMessage(completeMessage);
        }
    }

    /**
     * @param result
     * @return
     */
    private String retrieveErrorMessage(USMMessage result) {

        int count = result.popInteger();
        Map mapErr = new HashMap();

        for (int i = 0; i < count; ++i) {
            UAStatus statusObject = new UAStatus();
            statusObject.popMe(result);
            int nUAResult = statusObject.getStatus();

            String userId = result.popString();

            Object strMap = mapErr.get(nUAResult);
            if (null == strMap) {
                mapErr.put(nUAResult, userId);
                LOGGER.error(
                        "Error for the user, adding first time "
                                + userId
                                + " Error Id :"
                                + nUAResult);
            } else {
                mapErr.put(
                        nUAResult,
                        strMap.toString() + ", " + userId);
                LOGGER.error(
                        "Error for the user, adding second time as error Id is same "
                                + userId
                                + " Error Id :"
                                + nUAResult);
            }
        }

        StringBuilder errStr = new StringBuilder();

        Set setError = mapErr.keySet();
        Iterator iter = setError.iterator();
        UAStatus errorStatus = new UAStatus();
        while (iter.hasNext()) {
            Integer errId = (Integer) iter.next();
            errorStatus.setStatus(errId);
            errStr.append("\n").append(mapErr.get(errId)).append(":");
            errStr.append("\n").append(errorStatus.getErrorString());
        }
        LOGGER.debug("retrieveErrorMessage - Exit");
        return errStr.toString();
    }

    /**
     * This method handles the response when the message to retrieve all
     * users is retreived.
     *
     * @param message -
     *                The message contains the return code and the list of users.
     */
    private void handleGetAllUsersResponse(USMMessage message) {

        LOGGER.debug("handleGetAllUsersResponse - Exit");

        int nUserCount = message.popInteger();
        List<UAUser> lstUsers = new ArrayList<>();

        for (int nUserIndex = 0; nUserIndex < nUserCount; ++nUserIndex) {
            UAUser objUser = new UAUser();
            objUser.popMe(message);

            lstUsers.add(objUser);
        }

        getWindow().updateUsers(lstUsers);

        LOGGER.debug("handleGetAllUsersResponse - Exit");
    }

    /**
     * Method to typecast the base view pointer and get the derived window.
     * Helps prevent littering of ugly typecasts in code
     *
     * @return Typecasted user admin window
     */
    private UAUserAdministrationView getWindow() {
        return (UAUserAdministrationView) associatedView;
    }

}
