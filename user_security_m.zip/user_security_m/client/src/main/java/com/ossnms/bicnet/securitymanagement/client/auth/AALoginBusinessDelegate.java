/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AALoginBusinessDelegate
 * Author      	Jogender Singh
 * Substitute	Babu B
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.AUTHENTHICATE.USER
 *        TNMS.DX2.SM.LOGIN.USERID
 *        TNMS.DX2.SM.LOGIN.PASSWORD
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 * 14-Apr-2005	Muyeen Munaver	CF001025	Stop the Server - message to the clients
 * 21-Apr-2005	Muyeen Munaver	CF002069 - login with invalid user => Probable reason is not coherent with the root cause
 * 10-May-2005	Muyeen Munaver	CF002170 - Resolve the Host name into the IP address fails
 * 10-May-2005	Muyeen Munaver	CF002128 - 1st Client login attempt fails with java.lang.NullPointerException
 * 09-10-2007   Shrinidhi G V   CF004512-07  Improvement for server side filtering
 * 06-May-2009  Nagaraddi S S    TD004578 - RQT-STDERR errors instead log4j's
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.auth;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginServerAccessController;
import com.ossnms.bicnet.securitymanagement.api.common.OperationResult;
import com.ossnms.bicnet.securitymanagement.api.common.SSOAuthenticationToken;
import com.ossnms.bicnet.securitymanagement.client.SecurityPlugin;
import com.ossnms.bicnet.securitymanagement.client.auth.sso.SSOClientManager;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.auth.AAClientCacheData;
import com.ossnms.bicnet.securitymanagement.common.basic.SecurableObjectACL;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.general.sso.SSOConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.utils.ObjectCypher;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityAuthenticationPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityGeneralSettingPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.servicelocator.USMServiceLocator;
import com.ossnms.bicnet.util.UnexpectedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.security.auth.Subject;
import javax.security.auth.kerberos.KerberosPrincipal;
import javax.security.auth.login.LoginException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.Principal;
import java.security.PrivilegedActionException;
import java.util.Collections;
import java.util.Properties;
import java.util.Set;

import static com.ossnms.bicnet.bcb.plugin.BiCNetPluginServerAccessController.doPrivileged;

/**
 * Authentication components uses a Business Delegate to perform an operation on
 * the bean. This class is the Business Delegate for the authentication
 * components.
 */
public class AALoginBusinessDelegate {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(AALoginBusinessDelegate.class);
	public static final int TEST_TIMEOUT = 1000;

	//	Fault ID- 34 - Throwing exception on pressing ok in change password view - Begin
	/**
	 * Class member for holding authentication private facade
	 */
	private static ISecurityAuthenticationPrivateFacade usmAuthentication = null;

	/**
	 * Returns the authentication private facade
	 */
	public static ISecurityAuthenticationPrivateFacade getPrivateFacade() {
		return usmAuthentication;
	}
	//	Fault ID- 34 - Throwing exception on pressing ok in change password view - End

	/**
	 * Constructor
	 */
	public AALoginBusinessDelegate() {
		LOGGER.debug("AALoginBusinessDelegate() Entry");
		LOGGER.debug("AALoginBusinessDelegate() Exit");
	}

	/**
	 * Validates user credentials and return session token.
	 * 
     * @param userName             - User name.
     * @param password             - password.
     * @param host                 - host.
     * @param strClientIpAddress   - Session full handle which monitoring client status .
	 * @return ISessionContext
	 */
    public ISessionContext logon(final String server, final String userName, final String password, final String host, final String strClientIpAddress) throws Exception {
		LOGGER.debug("logon({}, ******, {} Entry", userName, host);

        try {
            return (ISessionContext) doPrivileged(this, () -> {
                ISecurityAuthenticationPrivateFacade authentication = getAuthenticationBean();
                if (authentication != null) {
					ISessionContext ctx = authentication.logon(
							userName, ObjectCypher.cypherToken(password), host, strClientIpAddress
					);

					USMUtility.getInstance().getSecurityPlugin().setLoggedInWithSSO(false);

					updateReloginController(server, userName, password, false, ctx);
                    return ctx;
                }
                return null;
            });
        } catch (PrivilegedActionException e) {
            LOGGER.debug("Exception at logon : ", e);
            throw e.getException();
        }
	}

	/**
	 * Updates the relogin controller with the
	 *
	 * @param server the server
	 * @param userName the username
	 * @param password the password
	 * @param sso true if it is SSO
     * @param ctx the session context
     */
    private void updateReloginController(final String server, final String userName, String password, boolean sso, ISessionContext ctx) {
        if (ctx != null) {
            ReloginController.getInstance().loggedOn(server, userName, password, sso);
        }
    }

	/**
	 * @return session context
	 */
    public ISessionContext logon(String server, final Subject ssoSubject, final String username, final String host, final String clientIpAddress) throws Exception {
		LOGGER.debug("logon() with  Entry");

		try {
			return (ISessionContext) doPrivileged(this, () -> {
                ISecurityAuthenticationPrivateFacade usmAuthentication1 = getAuthenticationBean();
                ISecurityGeneralSettingPrivateFacade usmGeneralSettings = USMServiceLocator.getInstance().getSecurityGeneralSettingsPrivateFacade();

                if (usmAuthentication1 != null && usmGeneralSettings != null) {
                    SSOConfigurationData ssoData = usmGeneralSettings.getSingleSignOnData();

                    //if the SSO is not retrievable or it is not enabled, we should not continue
					if (ssoData == null || !ssoData.isEnabled()) {
                        throw new LoginException("SSO not configured on the server.");
                    }

                    String clientObjectSID = null;
					String sAMAccountName = username.split("@")[0];
					String userPrincipalName = null;

                    // The client application should now request authentication and the ldap service ticket
                    // to the server configured for single sign-on
                    LOGGER.warn("[SSO] Attempting Authentication against configured Single Sign-on Server");
					String domainServer = getLdapHostName(ssoData.getDomainServer());
					// print the status of the reachable servers for the configured domain
					if(LOGGER.isDebugEnabled()){
						printNetworkTest(ssoData.getDomainName(), domainServer);
					}

                    SSOClientManager.authenticate(ssoSubject, ssoData.getKrbDomainName());
                    SSOClientManager.requestServiceTicket(ssoSubject, domainServer);

                    // Go over the Subject's principals, find the first KerberosPrincipal, authenticate and
                    // request the LDAP ticket
                    // With said authorization, fetch the user's object SID
					for (Principal principal : ssoSubject.getPrincipals()) {
						if (principal instanceof KerberosPrincipal) {
							String realm = ((KerberosPrincipal) principal).getRealm();
							String domainServer2 = domainServer;

							if(!realm.equalsIgnoreCase(ssoData.getDomainName())){
								// get the hostname of the realm
								domainServer2 = getLdapHostName(realm);
								// we'll use this method to repeat authentication to the SSO configured server.
								SSOClientManager.authenticate(ssoSubject, realm);
								// After the authentication is possible, the user will ask for a kerberos ticket which
								// allows himself to access the LDAP server on the configured domain
								SSOClientManager.requestServiceTicket(ssoSubject, domainServer2);
							}

                            // retrieve the objectSID and set the authentication token with it
                            clientObjectSID = SSOClientManager.getObjectSID(ssoSubject, sAMAccountName, realm, domainServer2, ssoData.getLdapTcpPort());
							userPrincipalName = SSOClientManager.getUserPrincipalName(ssoSubject, sAMAccountName, realm, domainServer2, ssoData.getLdapTcpPort());
                            break;
                        }
                    }

                    //Prepare the authentication token by retrieving the relevant ticket
                    SSOAuthenticationToken authToken = SSOClientManager.prepareToken(ssoSubject, domainServer, clientObjectSID);

					if(userPrincipalName == null) {
						userPrincipalName = SSOClientManager.getUserPrincipalName(ssoSubject, sAMAccountName, ssoData.getKrbDomainName(), domainServer, ssoData.getLdapTcpPort());
					}

					if (authToken != null) {
                        // Cipher sensitive data before send it through network to server
                        // cipher the ticket, retrieve byte array and send that to server
                        byte[] token = SSOAuthenticationToken.cypherToken(authToken);

                        ISessionContext ctx = usmAuthentication1.logon(
                        		token,
								userPrincipalName == null ? username : userPrincipalName,
								host,
								clientIpAddress
						);

                        USMUtility.getInstance().getSecurityPlugin().setLoggedInWithSSO(true);

						updateReloginController(server, username, null, true, ctx);

                        return ctx;
                    }
                }

                return null;
            });
		} catch (PrivilegedActionException e) {
			LOGGER.debug("Exception at logon : ", e);
			throw e.getException();
		} finally {
			LOGGER.debug("logon() Exit");
		}
	}

	/**
	 * @param domainName the domain name
	 * @param domainServer the domain server
     */
	private void printNetworkTest(String domainName, String domainServer) {
		try {
			LOGGER.warn("");
			LOGGER.warn("SSO STATUS");
			LOGGER.warn("	Domain Name		:		{}", domainName);
			LOGGER.warn("	Domain Server	:		{}", domainServer);
			LOGGER.warn("");

			InetAddress[] addresses = InetAddress.getAllByName(domainName);
			LOGGER.warn("	Found {} addresses for domain name {}", addresses.length, domainName);
			LOGGER.warn("");

			LOGGER.warn(" Connect | LDAP | KERBEROS | Address");
			for(InetAddress address : addresses){
				LOGGER.warn(
						"{}|{}|{}|{}@{}",
						address.getCanonicalHostName().equalsIgnoreCase(domainServer) 	? "    X    " 	: "         ",
						isPortReachable(address.getHostName(), 389, TEST_TIMEOUT) 		? "  OK  " 		: "      ",
						isPortReachable(address.getHostName(), 88, TEST_TIMEOUT) 		? "    OK    " 	: "          ",
						" " + address.getCanonicalHostName(),
						" " + address.getHostAddress()
				);
            }
			LOGGER.warn("END");
		} catch (IOException e) {
			LOGGER.error("Could not print network status. exception thrown", e);
		}
	}

	/**
	 *
	 * @param hostName the host name
	 * @param i port number
     * @return true if the port is reachable
     */
	private boolean isPortReachable(String hostName, int i, int timeout) {
		try {
			Socket socket = new Socket();
			socket.connect(new InetSocketAddress(hostName, i), timeout);
			socket.close();
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	/**
	 * Retrieves the Active Directory Machine for this Domain
     *
	 * @param domainServer the domain server fully qualified name
	 * @return the Ldap Host Name
	 */
	private String getLdapHostName(String domainServer) {
		try {
			return InetAddress.getByName(domainServer).getCanonicalHostName();
		} catch (UnknownHostException e) {
			LOGGER.error("Could not resolve domain server : " + e.getMessage());
			return domainServer;
		}
	}

	/**
	 * Validates user credentials and return session token.
	 * 
     * @param sessionContext - User name.
	 */
	public void logoff(final ISessionContext sessionContext) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("logoff(" + sessionContext + ") Entry");
		}

		// For all cases we assume that Logoff has worked. This could come in handy if the Server was shut down and the client has to be logged off.
		boolean bContactServer = USMUtility.getInstance().isServerContactedAtLogOff();

		if (bContactServer) {
			if (null != sessionContext) {
				try {
					doPrivileged(this, () -> {
                        ISecurityAuthenticationPrivateFacade usmAuthentication1 = getAuthenticationBean();
						try {
							if (usmAuthentication1 != null) {
								usmAuthentication1.logoff(sessionContext);
							} else {
								LOGGER.error("ISecurityAuthenticationPrivateFacade returned for logoff is null. Could happen if Server is not reachable.");
							}
						} catch (IllegalStateException ex) {
							LOGGER.error("Exception in logoff for : " + sessionContext, ex);
						}
                        return null;
                    });
				} catch (PrivilegedActionException e) {
					LOGGER.error("Exception in logoff for : " + sessionContext, e);
				}

			}
		} else {
			LOGGER.info("Not contacting server.");
		}

		LOGGER.debug("logoff Exit");
	}

	/**
	 * After successful logon, it is called to display advisory message.
	 * 
     * @param sessionContext - Session Token.
	 * @return USMMessage - Advisory message wrapped in USMMessage object
	 */
	public USMMessage getAdvisoryDetails(final ISessionContext sessionContext) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("getAdvisoryDetails(" + sessionContext + ") Entry");
		}

		try {
			return (USMMessage) doPrivileged(this, () -> {
                ISecurityAuthenticationPrivateFacade usmAuthentication1 = getAuthenticationBean();
                if (usmAuthentication1 != null) {
                    return usmAuthentication1.getAdvisoryDetails(sessionContext);
                }
                return null;
            });
		} catch (PrivilegedActionException e) {
			LOGGER.error("Exception raised for ctx : " + sessionContext, e);
		}

		LOGGER.debug("getAdvisoryDeatils(ISessionContext p_sessionContext) 		Exit");
		return null;
	}

	/**
	 * Sends the request to retrieve client cache 
     *
	 * @param sessionContext - Session token retrieved at logged in
	 * @return AAClientCacheData - Client cache data structure
	 */
	public AAClientCacheData getClientCacheData(final ISessionContext sessionContext) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"getClientCacheData(" + sessionContext + ") Entry");
		}

		try {
			return (AAClientCacheData) doPrivileged(this, () -> {
                ISecurityAuthenticationPrivateFacade usmAuthentication1 = getAuthenticationBean();
                if (usmAuthentication1 != null) {
                    return usmAuthentication1.getClientSecurityData(sessionContext);
                }
                return null;
            });
		} catch (PrivilegedActionException e) {
			LOGGER.error("Exception raised for ctx : " + sessionContext, e);
		}

		LOGGER.debug("getClientCacheData(ISessionContext p_sessionContext)       Exit");
		return null;
	}

	/**
	 * Helper function to retrieve the Bean object
	 *
	 * @return ISecurityAuthenticationPrivateFacade - The Bean object that will do the operations.
	 */
	public static ISecurityAuthenticationPrivateFacade getAuthenticationBean() {
		LOGGER.debug("getAuthenticationBean() Enter");
		USMServiceLocator servLoc = USMServiceLocator.getInstance();
		ISecurityAuthenticationPrivateFacade fcd = null;
		try {
			fcd = servLoc.getSecurityAuthenticationPrivateFacade();
			//Fault ID- 34 - Throwing exception on pressing ok in change password view
			usmAuthentication = fcd;
		} catch (UnexpectedException e) {
			LOGGER.error("Exception :", e);
		}
		LOGGER.debug("getAuthenticationBean()		Exit");
		return fcd;
	}

	/**
	 * Ping the server so that the session remains active
	 */
	public OperationResult setActive() throws PrivilegedActionException, BiCNetPluginException {
		LOGGER.debug("Calling setActive()...");

		return (OperationResult) BiCNetPluginServerAccessController.doPrivileged(this, () -> {
            ISecurityAuthenticationPrivateFacade authenticationFacade = getAuthenticationBean();
            if (authenticationFacade != null) {
				// get the security plugin and the session context
                SecurityPlugin securityPlugin = USMUtility.getInstance().getSecurityPlugin();
                ISessionContext sessionContext = securityPlugin.getContext();
				// issue a call to the server
                OperationResult result = authenticationFacade.setActive(sessionContext);
				LOGGER.debug("setActive call returned with status {}", result);
				return result;
            }
            return null;
        });
	}

	/**
	 * This method initiates the fetching of all the Securable objects and their ACL(s). Sends the Request Message with Primitive AA_REQ_GET_SECURABLE_OBJECTS
	 * 
	 * @return boolean - Indicates whether it was possible to send the request
	 *         or not.
	 */
	@SuppressWarnings("unchecked")
	public Set<SecurableObjectACL> getSecurableObjects() throws BcbSecurityException {
		try {
			return (Set<SecurableObjectACL>) doPrivileged(this, () -> {
                ISecurityAuthenticationPrivateFacade usmAuthentication1 = getAuthenticationBean();
                if (usmAuthentication1 != null) {
                    SecurityPlugin securityPlugin = USMUtility.getInstance().getSecurityPlugin();
                    ISessionContext objSessionContext = securityPlugin.getContext();

                    return usmAuthentication1.getSecurableObjects(objSessionContext);
                }
                return Collections.emptySet();
            });
		} catch (PrivilegedActionException e) {
			LOGGER.error("Exception raised at getSecurableObjects. : ", e);
		}

		return null;
	}

	//[TO REMOVE] Unused
//	/**
//	 * @param p_session session context
//	 * @return true if the password should change, false otherwise
//	 */
//	public boolean isPasswordMustChanged(ISessionContext p_session) {
//		final ISessionContext session = p_session;
//		boolean bPasswordMustChange = false;
//
//		try {
//			USMMessage msgResult = (USMMessage) BiCNetPluginServerAccessController.doPrivileged(this, new PrivilegedExceptionAction() {
//				@Override
//                public Object run() throws BcbSecurityException  {
//					ISecurityAuthenticationPrivateFacade usmAuthentication = getAuthenticationBean();
//					if (usmAuthentication != null) {
//						ISessionContext objSessionContext = USMUtility.getInstance().getSessionContext();
//						return usmAuthentication.isPasswordMustChanged(session);
//					}
//					return null;
//				}
//			});
//
//			bPasswordMustChange = msgResult.popBoolean().booleanValue();
//		} catch (PrivilegedActionException e) {
//			LOGGER.error("Exceptin raised for ctx : " + p_session, e);
//		}
//
//		return bPasswordMustChange;
//	}

	/**
	 * Sends the request to retrieve user profile client cache
	 * 
     * @param ctx The Context of the Logged in User
	 * @return USMMessage - User Profile Client cache data structure
	 */
	public USMMessage getUserProfileCache(final ISessionContext ctx) throws BcbSecurityException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("setUserProfileCache(" + ctx + ") Entry");
		}
		try {
			return (USMMessage) doPrivileged(this, () -> {
                ISecurityAuthenticationPrivateFacade usmAuthentication1 = getAuthenticationBean();
                if (usmAuthentication1 != null) {
                    return usmAuthentication1.getProfile(ctx);
                }
                return null;
            });
		} catch (PrivilegedActionException e) {
			LOGGER.error("Exception in getUserProfileCache() for ctx : " + ctx, e);
		}
		LOGGER.debug("getUserProfileCache() Exit");
		return null;
	}

    /**
     * Sends the request to update user profile for some particular CF
     * 
     * @param appUID  - Unique Identifier for the CF
     * @param profile - Profile for CF to be stored
     */
    public USMMessage setUserProfileCache(final String appUID, final Properties profile) throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setUserProfileCache(" + appUID + ", " + profile + ") Entry");
        }

        boolean bContactServer = USMUtility.getInstance().isServerContactedAtLogOff();
        final ISessionContext sessionContext = USMUtility.getInstance().getSessionContext();

        if (bContactServer && sessionContext != null) {
            try {
                return (USMMessage) doPrivileged(this, () -> {
                    ISecurityAuthenticationPrivateFacade usmAuthentication1 = getAuthenticationBean();
                    if (usmAuthentication1 != null) {
                        return usmAuthentication1.setProfile(sessionContext, appUID, profile);
                    }
                    return null;
                });
            } catch (PrivilegedActionException e) {
                LOGGER.error("setUserProfileCache() Exception :", e);
            }
        } else {
            LOGGER.info("Not contacting server.");
        }
        LOGGER.debug("setUserProfileCache() Exit");
        return null;
    }

	/**
	 * Sends the request to remove user profile for some particular CF
	 * 
     * @param appUID - Unique Identifier for the CF *
	 */
	public USMMessage removeUserProfile(final String appUID) throws BcbSecurityException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("removeUserProfile(" + appUID + ") Entry");
		}

		final SecurityPlugin securityPlugin = USMUtility.getInstance().getSecurityPlugin();

		try {
			return (USMMessage) doPrivileged(this, () -> {
                ISecurityAuthenticationPrivateFacade usmAuthentication1 = getAuthenticationBean();
                if (usmAuthentication1 != null) {
                    return usmAuthentication1.removeUserProfile(securityPlugin.getContext(), appUID);
                }
                return null;
            });
		} catch (PrivilegedActionException e) {
			LOGGER.error("removeUserProfile() Exception :", e);
		}

		LOGGER.debug("removeUserProfile() Exit");
		return null;

	}
}