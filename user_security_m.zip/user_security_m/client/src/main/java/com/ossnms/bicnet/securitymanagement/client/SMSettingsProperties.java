package com.ossnms.bicnet.securitymanagement.client;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

/**
 * Wrapper class for the sm-settings.properties file.
 * 
 */
public final class SMSettingsProperties {

    private static final String RESOURCE_NAME = "sm-settings.properties";

    private static final String SERVER_DEFAULT_PORT = "SERVER_DEFAULT_PORT";
	private static final String TNMS_PRINCIPAL_NAME = "TNMS_PRINCIPAL_NAME";
	private static final Logger LOGGER = Logger.getLogger(SMSettingsProperties.class);

	private static Properties props = null;
    
    static {
        try {
            init();
        } catch (IOException ioe) {
            LOGGER.error("Error reading " + RESOURCE_NAME, ioe);
        }
    }

    private SMSettingsProperties() {
    }
    
    private static void init() throws IOException {
        InputStream propertiesIS = SMSettingsProperties.class.getClassLoader().getResourceAsStream(RESOURCE_NAME);
        if (propertiesIS == null) {
            throw new FileNotFoundException();
        }
        props = new Properties();
        props.load(propertiesIS);
        propertiesIS.close();
    }

    /**
     * Returns the value of the default port.
     * The default port value is set by the installer during installation.  It is
     * normally only used on the first login. 
     * 
     * @return default port as specified by the installer.
     */
    public static String getServerDefaultPort() {
        return props.getProperty(SERVER_DEFAULT_PORT);
    }

	public static String getTnmsPrincipalName() {
		return props.getProperty(TNMS_PRINCIPAL_NAME);
	}

	public static String getKrbTnmsServiceName() {
		String tnmsPrincipalName = getTnmsPrincipalName();
		if (tnmsPrincipalName != null) {
			return tnmsPrincipalName.replace('/', '@');
		}
		return null;
	}
}
