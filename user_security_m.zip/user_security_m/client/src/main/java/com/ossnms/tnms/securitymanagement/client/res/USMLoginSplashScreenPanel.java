package com.ossnms.tnms.securitymanagement.client.res;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class USMLoginSplashScreenPanel extends JPanel {

    private static final long serialVersionUID = 4478102539640478914L;

    /**
     * Name of the product.
     */
    private String appName;

    /**
     * Product family the product belongs to.
     */
    private String appProdFamily;

    /**
     * The Left Position of the Product information.
     */
    private static final int PRODUCTINFO_LEFT_OFFSET = 104;

    /**
     * The Top(Y) position of the Product family.
     */
    private static final int PRODUCTFAMILY_TOP_OFFSET = 78;

    /**
     * The Top(Y) position of the Product family.
     */
    private static final int PRODUCTFAMILY_TOP_OFFSET_WITH_TWO_LINE_PRODUCTNAME = 65;
    
    /**
     * The Position of the Product Name for the First Line.
     */
    private static final int PRODUCTNAME_FIRST_TOP_OFFSET = 79;

    /**
     * The Position of the Product Name for the First Line.
     */
    private static final int PRODUCTNAME_SECOND_TOP_OFFSET = 92;

    /**
     * The maximum size for the First Line of the Product Name.
     */
    private static final int PRODUCTNAME_MAX_LINE_SIZE = 164; // 280 - PRODUCTINFO_LEFT_OFFSET - 12

    private static final String SPACE = " ";

    /**
     * Text color of the product information(Product family, Product name and version.)
     */
    private static final Color PRODUCT_INFO_COLOR = new Color(102, 102, 102);

    private Font fontApp;
    private Font fontFamilyName;
    private transient ImageHandler image;

    public USMLoginSplashScreenPanel(String strAppFamily, String strAppName, ImageIcon imageIcon) {

        appProdFamily = strAppFamily;
        appName = strAppName;

        fontApp = new Font("Arial", Font.BOLD, 14);
        fontFamilyName = new Font("Arial", Font.PLAIN, 10);

        /* Load image */
        image = new ImageHandler(imageIcon);

        /* Build components */
        setLayout(new BorderLayout());
        setSize(image.getWidth() + 2, image.getHeight() + 2);
        centerOnScreen();
    }

    /***************************************************************************
     * Centers the splash window on the screen. This method is called from the constructor.
     **************************************************************************/

    public void centerOnScreen() {
        Dimension screenSize = getToolkit().getScreenSize();
        Rectangle rectScreen, rectBounds;

        rectScreen = new Rectangle(0, 0, screenSize.width, screenSize.height);
        rectBounds = getBounds();

        int dx = rectScreen.x + (rectScreen.width - rectBounds.width) / 2;
        int dy = rectScreen.y + (rectScreen.height - rectBounds.height) / 2;

        setLocation(dx, dy);
    }

    /***************************************************************************
     * Paints the splash window contents.
     * 
     * @param g
     *            Graphics context.
     **************************************************************************/

    @Override
    public void paint(Graphics graphics) {
        // Draw image
        image.paint(graphics, 1, 1);

        // Draw Product family name
        Graphics2D g2d = (Graphics2D) graphics;

        if (appProdFamily != null && !appProdFamily.equals(appName)) {
        	addProductFamily(g2d);
        }
        // Adds the product name informations.
        addProductName(g2d);
    }

    /**
     * Draws the product Family according to the guidelines.
     * 
     * @param g2d
     *            Graphic object.
     */
    private void addProductFamily(Graphics2D g2d) {
        Color orginalColor = g2d.getColor();
        Font orginalFont = g2d.getFont();

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(PRODUCT_INFO_COLOR);
        g2d.setFont(fontFamilyName);
        // Positioning of Product Family depends on the number of lines of Product Name.
        // Product Name might have multilines maximum up to 2. If Product Name has 2 lines, then Product Family will go up.
		if (isTwoLineProductName(g2d, appName)) {
			g2d.drawString(appProdFamily, PRODUCTINFO_LEFT_OFFSET, PRODUCTFAMILY_TOP_OFFSET_WITH_TWO_LINE_PRODUCTNAME);
		} else {
			g2d.drawString(appProdFamily, PRODUCTINFO_LEFT_OFFSET, PRODUCTFAMILY_TOP_OFFSET);
		}
        g2d.setColor(orginalColor);
        g2d.setFont(orginalFont);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
    }

    /**
     * Draws the product name according to the guidelines.
     * 
     * @param g2d
     *            graphic object.
     */
    private void addProductName(Graphics2D g2d) {
        Color c = g2d.getColor();
        Font f = g2d.getFont();

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setColor(PRODUCT_INFO_COLOR);
        g2d.setFont(fontApp);

        if (isTwoLineProductName(g2d, appName)) {
            List<String> lines = splitProductNameInTwo(appName, g2d.getFontMetrics());

            g2d.drawString(lines.get(0), PRODUCTINFO_LEFT_OFFSET, PRODUCTNAME_FIRST_TOP_OFFSET);
            g2d.drawString(lines.get(1), PRODUCTINFO_LEFT_OFFSET, PRODUCTNAME_SECOND_TOP_OFFSET);
        } else {
            // Single line
            g2d.drawString(appName, PRODUCTINFO_LEFT_OFFSET, PRODUCTNAME_SECOND_TOP_OFFSET);
        }

        // restore graphics settings
        g2d.setColor(c);
        g2d.setFont(f);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
    }

    /**
     * Helper class to split product name in two lines due to image size limitation.
     * 
     * @param productName
     *            The product name to be split.
     * @param fontMetrics
     *            Font metrics being used to draw the product name.
     * 
     * @return List with two strings (resulting product name split in two lines)
     */
    private List<String> splitProductNameInTwo(String productName, FontMetrics fontMetrics) {
    	String[] productNameSplit = productName.split("\n");
		if (productNameSplit.length > 1) {
			return Arrays.asList(productNameSplit);
    	}
		
        List<String> lines = new ArrayList<String>();
        StringBuilder builderLine1 = new StringBuilder();
        StringBuilder builderLine2 = new StringBuilder();

        String[] words = productName.split(SPACE);

        boolean flagFirstLineComplete = false;
        for (String word : words) {
            int wordSize = fontMetrics.stringWidth(word);
            int builder1Size = fontMetrics.stringWidth(builderLine1.toString()) + wordSize;

            if (!flagFirstLineComplete && builder1Size <= PRODUCTNAME_MAX_LINE_SIZE) {
                builderLine1.append(word);
                builderLine1.append(SPACE);
            } else {
                builderLine2.append(word);
                builderLine2.append(SPACE);
                flagFirstLineComplete = true;
            }
        }

        lines.add(builderLine1.toString());
        lines.add(builderLine2.toString());

        return lines;
    }
    
    /**
     * Helper method to check if product name takes two lines or just one.
     */
    private boolean isTwoLineProductName(Graphics2D g2d, String productName) {
    	if (productName.split("\n").length > 1) {
    		return true;
    	}
    	int strWidth = g2d.getFontMetrics(fontApp).stringWidth(appName);
        return strWidth > PRODUCTNAME_MAX_LINE_SIZE;
    }

    /***************************************************************************
     * Helper class for loading and rendering an image (remember that we can't use Swing because of speed).
     * 
     * @author Joern Haferstroh
     **************************************************************************/

    private class ImageHandler {
        ImageIcon imageIcon = null;

        /***********************************************************************
         * Constructs the image handler.
         **********************************************************************/

        public ImageHandler(ImageIcon pImageIcon) {
            this.imageIcon = pImageIcon;
        }

        /***********************************************************************
         * Queries the width of the image.
         * 
         * @return Image width in pixels.
         **********************************************************************/

        public int getWidth() {
            return (imageIcon != null) ? imageIcon.getIconWidth() : 400;
        }

        /***********************************************************************
         * Queries the heigth of the image.
         * 
         * @return Image height in pixels.
         **********************************************************************/

        public int getHeight() {
            return (imageIcon != null) ? imageIcon.getIconHeight() : 250;
        }

        /***********************************************************************
         * Renders the image.
         * 
         * @param g
         *            Graphics context.
         * @param nXPos
         *            X position of top-left corner.
         * @param nYPos
         *            Y position of top-left corner.
         **********************************************************************/

        public void paint(Graphics p_g, int p_nXPos, int p_nYPos) {
            if (imageIcon != null) {
                p_g.drawImage(imageIcon.getImage(), p_nXPos, p_nYPos, USMLoginSplashScreenPanel.this);
            }
        }
    }
}