package com.ossnms.bicnet.securitymanagement.client.domain.common;

import com.coriant.widgets.togglebuttontree.ToggleButtonTree;

import static com.ossnms.bicnet.securitymanagement.client.domain.common.SecurableObjectContainerFilterEnum.MEDIATOR;
import static com.ossnms.bicnet.securitymanagement.client.domain.common.SecurableObjectFilterEnum.*;
import static com.ossnms.bicnet.securitymanagement.client.domain.common.ServerTypeFilterEnum.DCN_MANAGER;


public class SecurableObjectToggleButtonTree extends ToggleButtonTree<SecurableObjectTreeNode> implements ISecurableObjectTree {

    private static final long serialVersionUID = -2427710942527701746L;

    private ServerTypeFilterEnum serverType = DCN_MANAGER;
    private SecurableObjectContainerFilterEnum filter = MEDIATOR;
    private SecurableObjectFilterEnum objectFilter = NE;

    public SecurableObjectToggleButtonTree() {
        super();
        setTreeModel(new SecurableObjectTreeModel());
    }

    @Override
    public void setTreeModel(SecurableObjectTreeModel treeModel) {
        super.setModel(treeModel);
    }

    @Override
    public SecurableObjectTreeModel getTreeModel() {
        return (SecurableObjectTreeModel) super.getModel();
    }

    @Override
    public SecurableObjectContainerFilterEnum getFilter() {
        return filter;
    }

    @Override
    public void setFilter(SecurableObjectContainerFilterEnum filter) {
        this.filter = filter;
    }

    @Override
    public SecurableObjectFilterEnum getObjectFilter() {
        return objectFilter;
    }

    @Override
    public void setObjectFilter(SecurableObjectFilterEnum objectFilter) {
        this.objectFilter = objectFilter;
    }

    @Override
    public ServerTypeFilterEnum getServerTypeFilter() {
        return serverType;
    }

    @Override
    public void setServerTypeFilter(ServerTypeFilterEnum serverType) {
        this.serverType = serverType;
    }
}
