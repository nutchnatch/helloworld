/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	IEClientController
 * Author      	Muyeen Munaver
 * Substitute	Asifullah Khan
 * Created on	07-12-2004
 *
 * --------------------------------------------------------
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : 	TNMS.DX2.SM.MIGRATION
 * 			TNMS.DX2.SM.EXPORT
 * 			TNMS.DX2.SM.IMPORT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 09-Feb-2005  Babu B          CF000459   Choose for a User Group the Assigned Policy "NONE" - not the correct behaviour!
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.importexport;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMBaseController;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.basic.USMTimeTracer;
import com.ossnms.bicnet.securitymanagement.common.importexport.IEDataObject;
import com.ossnms.bicnet.securitymanagement.common.importexport.IEMessageType;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * Controller class which is responsible for interacting with the Deleegate and doing 
 * the following operations - 
 * 1. Retrieving of the data for export purpouse.
 * 2. Requesting the server to import data.
 */
public class IEClientController extends USMBaseController {

	/**
	 * Data member to hold the logger.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(IEClientController.class);

	/**
	 * Data member to hold the Time Tracker
	 */
	//CF000459  Time to do performance test for this
	private USMTimeTracer timeTracker = new USMTimeTracer();

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc#resultAvailable(com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob, com.ossnms.bicnet.securitymanagement.common.basic.USMMessage)
	 */
	public void resultAvailable(USMJob pJob, USMMessage result) {
		// Function has to be implemented since otherwise class will become abstract.
		// Want to keep it as close as possible to the design of the other classes so that
		// if ClientFrame changes, it is easy to adapt
		LOGGER.error(
			"resultAvailable should never get called. Since we do not queue the job.");
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc#handleNotification(com.ossnms.bicnet.securitymanagement.common.basic.USMMessage)
	 */
	public void handleNotification(USMMessage pMsg) {
		// Function has to be implemented since otherwise class will become abstract.
		// Want to keep it as close as possible to the design of the other classes so that
		// if ClientFrame changes, it is easy to adapt
		LOGGER.error(
			"handleNotification should never get called. Since we do not queue the job.");
	}

	/**
	 * Function called to get the Data which has to be exported. 
	 * @param p_strName The Name of the Object which should be exported 
	 * @return List List containing all the data which is to be exported. List can be null.
	 */
	List exportData(String p_strName) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering exportData. Tag is : " + p_strName);
		}

		timeTracker.registerExecuteJobStarted();

		List lstObjs = null;
		IEExportJob expJob =
			new IEExportJob(IEMessageType.IE_REQ_EXPORT, this, p_strName);
		try {
			USMMessage msg = expJob.executeJob();
			lstObjs = getListFromMessage(msg);
		} catch (Exception e) {
			LOGGER.error("Exception in exportData : ", e);
		}
		if (LOGGER.isInfoEnabled()) {
			String strMsg =
				(lstObjs != null)
					? "List Size : " + lstObjs.size()
					: "List is null";
			LOGGER.debug("Exiting exportData. " + strMsg);
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting exportData. List : " + lstObjs);
		}
		timeTracker.registerExecuteJobComplete();
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info(
				"Time taken to do export of "
					+ p_strName
					+ " for size of "
					+ lstObjs.size()
					+ " is "
					+ timeTracker.getTimeForServerProcessing());
		}
		return lstObjs;
	}

	/**
	 * Function called to import data.
	 * @param p_strName The Name of the Object which is to be imported
	 * @param pLstDataToImport The Actual objects which are to be imported
	 * @param p_Overwrite Indicates whether overwrite is to be performed. True indicates overwrite
	 * @return List The List of Data which could not be exported.
	 */
	List importData(String p_strName, List pLstDataToImport, boolean p_Overwrite) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering importData. Tag is : " + p_strName +
					" List : " + pLstDataToImport + " Overwrite Mode : " + p_Overwrite);
		}

		timeTracker.registerExecuteJobStarted();

		List lstFailedObjs = null;
		IEImportJob job =
			new IEImportJob(
				IEMessageType.IE_REQ_EXPORT,
				this,
				pLstDataToImport,
				p_strName,
				p_Overwrite);
		try {
			USMMessage msg = job.executeJob();
			lstFailedObjs = getListFromMessage(msg);
		} catch (Exception e) {
			LOGGER.error("Exception in exportData : ", e);
		}
		if (LOGGER.isInfoEnabled()) {
			String strMsg =
				(lstFailedObjs != null)
					? "List Size : " + lstFailedObjs.size()
					: "List is null";
			LOGGER.debug("Exiting importData. " + strMsg);
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting importData. List : " + lstFailedObjs);
		}
		timeTracker.registerExecuteJobComplete();
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info(
				"Time taken to do import of "
					+ p_strName
					+ " for size of "
					+ pLstDataToImport.size()
					+ " is "
					+ timeTracker.getTimeForServerProcessing());
		}

		return lstFailedObjs;
	}

	/**
	 * Helper function to return the List of Objects which are contained within
	 * the message.
	 * @param pMsg The message that has been retrieved from the Server
	 * @return List List containing the Obejcts which are to be exported. The List is null in
	 * case the message is null.
	 */
	private List getListFromMessage(USMMessage pMsg) {
		List lst = null;
		if (pMsg != null) {
			lst = new ArrayList();
			int nNoOfElms = pMsg.popInteger();
			for (int idx = 0; idx < nNoOfElms; idx++) {
				IEDataObject data = (IEDataObject) pMsg.popObject();
				lst.add(data);
			}
		}
		return lst;
	}
}
