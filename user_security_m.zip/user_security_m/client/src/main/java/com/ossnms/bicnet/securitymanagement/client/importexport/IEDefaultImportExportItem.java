/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 09-Feb-2005  Babu B          CF000459   Choose for a User Group the Assigned Policy "NONE" - not the correct behaviour!
 * 05-Apr-2005  Muyeen Munaver	CF001885   XML file without any domain -import all the securtyManagement (includes domains)
 * 23-Mar-2006	Shrinidhi		CF003795-01	Wrong info with import of Security Management
 * 04-Apr-2006	Shrinidhi G V 	CF003795-03 - Wrong info with import of Security Management
 * 09-Oct-2006	Shrinidhi G V 	CF004333 - 9320_MR_0731:Need the ability to import/export Topology Management
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.importexport;

import com.ossnms.bicnet.bcb.plugin.BiCNetConfirmation;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginImportExportItem;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginImportExportListener;
import com.ossnms.bicnet.securitymanagement.client.auth.AAClientCache;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.client.importexport.migration.PolicyMigration;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMenuNameList;
import com.ossnms.bicnet.securitymanagement.common.domain.DCIEDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.importexport.IEDataObject;
import com.ossnms.bicnet.securitymanagement.common.importexport.IEDomainData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAStatus;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAIEUser;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAIEUserGroup;
import com.ossnms.tools.jfx.JfxText;
import org.apache.log4j.Logger;
import org.w3c.dom.Element;

import java.io.FileNotFoundException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import static com.ossnms.bicnet.securitymanagement.client.importexport.IETagNames.BICNETDATA_VERSION;

/**
 * This class represents the data to be imported or exported from USM
 */
public class IEDefaultImportExportItem implements BiCNetPluginImportExportItem {

	private static final String VERSION_PERMISSION_INTRODUCTION = "15.1 0.131.0";

	private static final Logger LOGGER = Logger.getLogger(IEDefaultImportExportItem.class);

	private static final boolean REPLACE = false;
	public static final String VERSION_SPLIT = "\\s|\\.";

	/**
	 * Data member to hold the Controller that should be used to retrieve the
	 * information.
	 */
	private IEClientController ctl = new IEClientController();

	/**
	 * Data member to hold name of the data to be exported or imported
	 */
	private JfxText name = null;

	private BiCNetPluginImportExportItem[] children = new BiCNetPluginImportExportItem[0];

	/**
	 * Post import data list, used after all import process.
	 */
	private List<PostImportData> postImportData = null;

	/**
	 * Constructor
	 */
	public IEDefaultImportExportItem(
			JfxText name,
			boolean isImported,
			boolean isExported) {
		this.name = name;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginImportExportItem#getName()
	 */
	@Override
	public String getName() {
		return name.toString();
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginImportExportItem#importData(org.w3c.dom.Element, boolean, com.ossnms.bicnet.bcb.plugin.BiCNetPluginImportExportListener)
	 */
	@Override
	public void importData(Element root, BiCNetPluginImportExportListener listener) throws BiCNetPluginException {

		// Get the XML version, if it is version 1.0 then it must be from before
		// release 14.0 10.
		String currentBuild = USMUtility.getInstance().getSecuritySite().getScsProvider().getServerVersion().getBuild();
		if (root.getAttribute(BICNETDATA_VERSION).equals("1.0") || (currentBuild.compareTo(root.getAttribute(BICNETDATA_VERSION)) > 0)) {
			LOGGER.debug("Migrating Policies");
			PolicyMigration migration;
			try {
				migration = new PolicyMigration(root);
				migration.migrate();
				root = migration.getElement();
			} catch (FileNotFoundException e) {
				LOGGER.warn("Unable to perform policy migration, import will continue without policies being migrated");
			}
		}

		IEXmlReader reader = IEXmlReader.getInstance();
		if (name.equals(USMStringTable.IDS_IE_DOMAINS)) {
			List<IEDomainData> lst = reader.getDomains(root, listener);
			//this should be performed after all the import operation. The DCN data must be present first.
			PostImportData data = new PostImportData(IEDataObject.DOMAIN, lst, REPLACE);
			addPostImportData(data);
		} else if (name.equals(USMStringTable.IDS_IE_POLICIES)) {
			//The version of the export is earlier than the introduction of the permission/permission item model
			//Inform the user, perform actions and proceed.
			if(isVersionInvalid(root)){
				//Inform the user that the version is incompatible, and the import will be skipped.
				listener.eventPluginImportExportMessage(USMCommonStrings.IDS_PA_POLICY_IMPORT_INCOMPATIBLE);
			}else{
				List<PAPolicyData> lst = reader.getPolicies(root, listener);
				importDataAndLogError(IEDataObject.POLICY, lst, REPLACE, listener);
			}
		} else if (name.equals(USMStringTable.IDS_IE_DOMAIN_MAPPING)) {
			List<DCIEDomainMapping> lst = reader.getMappings(root, listener);
			PostImportData data = new PostImportData(IEDataObject.MAPPING, lst, REPLACE);
			addPostImportData(data);
		} else if (name.equals(USMStringTable.IDS_IE_USERS)) {
			List<UAIEUser> lst = reader.getUsers(root, listener);
			importDataAndLogError(IEDataObject.USER, lst, REPLACE, listener);
		} else if (name.equals(USMStringTable.IDS_IE_USER_GROUPS)) {
			List<UAIEUserGroup> lst = reader.getUserGroups(root, listener);
			importDataAndLogError(	IEDataObject.USER_GROUP, lst, REPLACE,	listener);
		}
		listener.eventPluginImportExportProgress(1, 1);
	}

	/**
	 * Compares both versions (the one where the new permission model was introduced and the one
	 * from the import) and returns the result of such comparison.
	 *
	 * @param root the element which contains the xml file contents.
	 * @return true if the version is invalid and the import should be bypassed. False otherwise.
     */
	private boolean isVersionInvalid(Element root) {
		String[] permissionVersionParts = VERSION_PERMISSION_INTRODUCTION.split(VERSION_SPLIT);
		String[] importVersionParts = root.getAttribute(BICNETDATA_VERSION).split(VERSION_SPLIT);

		int nParts = permissionVersionParts.length >= importVersionParts.length ? importVersionParts.length : permissionVersionParts.length;

		for(int i = 0; i < nParts; i++){
			int permissionVersion = Integer.parseInt(permissionVersionParts[i]);
			int importVersion = Integer.parseInt(importVersionParts[i]);

			if(permissionVersion != importVersion){
				return permissionVersion > importVersion;
			}
		}

		return false;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginImportExportItem#exportData(org.w3c.dom.Element, com.ossnms.bicnet.bcb.plugin.BiCNetPluginImportExportListener)
	 */
	@Override
	public void exportData(
			Element root,
			BiCNetPluginImportExportListener listener)
					throws BiCNetPluginException {
		IEXmlWriter writer = IEXmlWriter.getInstance();
		if (name.equals(USMStringTable.IDS_IE_DOMAINS)) {
			String id = IEDataObject.DOMAIN;
			List lst = getListOfDataAndLogError(id, listener);
			if (lst != null && lst.size()>0) {
				writer.writeDomains(root, lst);
			}
		} else if (name.equals(USMStringTable.IDS_IE_POLICIES)) {
			String id = IEDataObject.POLICY;
			List lst = getListOfDataAndLogError(id, listener);
			if (lst != null && lst.size()>0) {
				writer.writePolicies(root, lst);
			}
		} else if (name.equals(USMStringTable.IDS_IE_DOMAIN_MAPPING)) {
			String id = IEDataObject.MAPPING;
			List lst = getListOfDataAndLogError(id, listener);
			if (lst != null && lst.size()>0) {
				writer.writeMappings(root, lst);
			}
		} else if (name.equals(USMStringTable.IDS_IE_USERS)) {
			String id = IEDataObject.USER;
			List lst = getListOfDataAndLogError(id, listener);
			if (lst != null && lst.size()>0) {
				writer.writeUsers(root, lst);
			}
		} else if (name.equals(USMStringTable.IDS_IE_USER_GROUPS)) {
			String id = IEDataObject.USER_GROUP;
			List lst = getListOfDataAndLogError(id, listener);
			if (lst != null && lst.size()>0) {
				writer.writeUserGroups(root, lst);
			}
		}
		listener.eventPluginImportExportProgress(1, 1);
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginImportExportItem#abortExport()
	 */
	@Override
	public void abortExport() {

	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginImportExportItem#abortImport()
	 */
	@Override
	public void abortImport() {

	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginImportExportItem#isImportAllowed()
	 */
	@Override
	public boolean isImportAllowed() {
		String strMenuId = null;
		if (name.equals(USMStringTable.IDS_IE_DOMAINS)) {
			strMenuId = USMMenuNameList.OPERATION_DOMAIN_NEW;

		} else if (name.equals(USMStringTable.IDS_IE_POLICIES)) {
			strMenuId = USMMenuNameList.OPERATION_POLICY_NEW;

		} else if (name.equals(USMStringTable.IDS_IE_DOMAIN_MAPPING)) {
			strMenuId = USMMenuNameList.OPERATION_DOMAIN_ASSIGN_MAPPINGS_APPLY;

		} else if (name.equals(USMStringTable.IDS_IE_USERS)) {
			strMenuId = USMMenuNameList.OPERATION_USER_NEW;

		} else if (name.equals(USMStringTable.IDS_IE_USER_GROUPS)) {
			strMenuId = USMMenuNameList.OPERATION_USER_GROUP_NEW;

		}

		boolean bImportAllowed = false;
		if (strMenuId != null) {
			bImportAllowed =
					AAClientCache.getInstance().checkOperationPermission(strMenuId);
		}

		return bImportAllowed;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginImportExportItem#isExportAllowed()
	 */
	@Override
	public boolean isExportAllowed() {

		String strMenuId = null;
		if (name.equals(USMStringTable.IDS_IE_DOMAINS)) {
			strMenuId = USMMenuNameList.OPERATION_DOMAIN_ADMIN;

		} else if (name.equals(USMStringTable.IDS_IE_POLICIES)) {
			strMenuId = USMMenuNameList.OPERATION_POLICY_ADMIN;

		} else if (name.equals(USMStringTable.IDS_IE_DOMAIN_MAPPING)) {
			strMenuId = USMMenuNameList.OPERATION_DOMAIN_ASSIGN_MAPPINGS;

		} else if (name.equals(USMStringTable.IDS_IE_USERS)) {
			strMenuId = USMMenuNameList.OPERATION_USERS_ADMIN;

		} else if (name.equals(USMStringTable.IDS_IE_USER_GROUPS)) {
			strMenuId = USMMenuNameList.OPERATION_USER_GROUP_ADMIN;

		}

		boolean bExportAllowed = false;
		if (strMenuId != null) {
			bExportAllowed =
					AAClientCache.getInstance().checkOperationPermission(strMenuId);
		}

		return bExportAllowed;
	}

	/**
	 * Helper function that is responsible to get the data to be exported and logs an error if any.
	 * @param p_strData The Name of the Data to be exported.
	 * @param pListener The Listener where the error is to be logged.
	 * @return List List which contains the data to be exported.
	 */
	private List getListOfDataAndLogError(
			String p_strData,
			BiCNetPluginImportExportListener pListener) {
		List lst = ctl.exportData(p_strData);
		if (lst == null) {
			String strError =
					USMStringTable
					.IDS_IE_JOB_EXPORT_ERROR_WHILE_RETRIEVING
					.toString();
			pListener.eventPluginImportExportMessage(strError + p_strData);
		} else if (lst.size() == 0) {
			pListener.eventPluginImportExportMessage(
					USMStringTable.IDS_IE_JOB_EXPORT_THERE_ARE_NO.toString()
					+ (p_strData.equalsIgnoreCase(USMStringTable.IDS_IE_JOB_EXPORT_POLICY.toString())?
							(USMStringTable.IDS_IE_JOB_EXPORT_POLICIES.toString()):
								(p_strData.concat(USMStringTable.IDS_IE_JOB_EXPORT_LETTER_S.toString())))
								+ USMStringTable.IDS_IE_JOB_EXPORT_TO_BE_EXPORTED.toString());
		} else if (lst.size() == 1) {
			IEDataObject ieObject = (IEDataObject) lst.get(0);
			if (ieObject.getDataObject() == null) {
				lst.clear();
				lst = null;
				pListener.eventPluginImportExportMessage(
						ieObject.getErrorString());
			}
		}
		return lst;
	}

	/**
	 * Function called to import the data and to log any errors
	 * @param p_strData The Data that should be imported.
	 * @param p_LstData The List which contains the actual objects to be imported
	 * @param p_overwrite Indicates whether it is overwrite mode. True means overwrite
	 * @param listener The Listener to be used in case of errors.
	 */
	private void importDataAndLogError(
			String p_strData,
			List p_LstData,
			boolean p_overwrite,
			BiCNetPluginImportExportListener listener) {

		int nNoOfElms = p_LstData.size();

		if (nNoOfElms == 0) {
			// It means the file contains no objects of the type which is being imported
			// So flag a warning
			String strInfo =
					MessageFormat.format(
							USMStringTable.IDS_IE_NO_DATA_TO_IMPORT.toString(),
							p_strData);
			LOGGER.info(strInfo);
			listener.eventPluginImportExportMessage(strInfo);
		} else
			//		The above code should be un-commented if the customer would want
			//		to be informed, if the oeprator is trying to import some objects, but these objects
			//		don't exist in the xml file.
		{
			List lstOfConvertedData = new ArrayList(nNoOfElms);
			for (int idx = 0; idx < nNoOfElms; idx++) {
				Object obj = p_LstData.get(idx);
				IEDataObject data = new IEDataObject(obj, "");
				lstOfConvertedData.add(data);
			}

			List lstFailedObjs = ctl.importData(p_strData, lstOfConvertedData, p_overwrite);
			if (lstFailedObjs == null) {
				listener.eventPluginImportExportMessage(
						USMStringTable.IDS_IE_JOB_IMPORT_FAIL_ALL.toString()
						+ p_strData);
			} else if (lstFailedObjs.size() > 0) {
				int nNoOfFailedData = lstFailedObjs.size();
				for (int idx = 0; idx < nNoOfFailedData; idx++) {
					IEDataObject obj = (IEDataObject) lstFailedObjs.get(idx);
					String strTraceMsg = null;
					if (obj.geterrorIndex()	== PAStatus.S_POLICY_CONTAINS_UNRECOG_MENUS.getStatus()) {
						strTraceMsg =
								p_strData
								+ " "
								+ obj.toString()
								+ USMStringTable
								.IDS_IE_JOB_IMPORT_SUCCESS_WITHUNRECOGNIZED
								.toString()
								+ obj.getErrorString();

					} else if(obj.geterrorIndex()
							== PAStatus.S_DOMAIN_IMPORT_INVALID_NE.getStatus()){
						strTraceMsg =
								p_strData
								+ " "
								+ obj.toString()
								+ USMStringTable
								.IDS_IE_JOB_IMPORT_SUCCESS_PARCIAL
								.toString()
								+ obj.getErrorString();
					}else {
						strTraceMsg =
								p_strData
								+ " "
								+ obj.toString()
								+ USMStringTable
								.IDS_IE_JOB_IMPORT_FAIL_REASON
								.toString()
								+ obj.getErrorString();
					}
					LOGGER.debug(strTraceMsg);
					listener.eventPluginImportExportMessage(strTraceMsg);
				}
			}
		}

	}

	@Override
	public BiCNetPluginImportExportItem[] getChildImportExportItems() {
		return children;
	}

	@Override
	public List<BiCNetConfirmation> getConfirmations() {
		return null;
	}

	public void addChildImportExportItems(BiCNetPluginImportExportItem[] newChild) {

		children = newChild.clone();

	}

	@Override
	public void setConfirmations(List<BiCNetConfirmation> confirmations) {return;}

	@Override
	public void postImport(BiCNetPluginImportExportListener importListener) throws BiCNetPluginException {
		if(postImportData == null || postImportData.isEmpty()){
			LOGGER.debug("No post operation to be performed after import");

			//setting progress bar to 100%
			importListener.eventPluginImportExportProgress(1, 1);
			return;
		}

		int progress=0;
		for(PostImportData data :postImportData){
			importListener.eventPluginImportExportProgress(progress++, postImportData.size());
			importDataAndLogError(data.getItemName(), data.getList(), data.isToBeReplaced(), importListener);
		}
		postImportData = null;
		//must set the progress bar to 100%
		importListener.eventPluginImportExportProgress(1, 1);
	}

	/**
	 * Add post import data.
	 * 
	 * @param data
	 */
	private void addPostImportData(PostImportData data){
		if(postImportData == null){
			postImportData = new ArrayList<>();
		}
		postImportData.add(data);
	}

	/**
	 * 
	 * Data object to retain some post import operation.
	 *
	 */
	private static class PostImportData{

		private String itemName;
		private List<?> list;
		private boolean toBeReplaced;

		/**
		 * Content set for the post import data
		 * 
		 * @param itemName - The item name String in IEDataObject
		 * @param list - The data list to perform the post import operation
		 * @param toBeReplaced - Whether if it is to replace the previous content. 
		 */
		public PostImportData(String itemName, List<?> list, boolean toBeReplaced){
			this.itemName = itemName;
			this.list = list;
			this.toBeReplaced = toBeReplaced;
		}

		/**
		 * The string identifier for this data object. Reference present in IEDataObject.
		 * 
		 * @return String
		 */
		public String getItemName() {
			return itemName;
		}

		/**
		 * The content list.
		 * 
		 * @return List
		 */
		public List<?> getList() {
			return list;
		}

		/**
		 * Whether it is to replace the previous content.
		 * 
		 * @return boolean
		 */
		public boolean isToBeReplaced() {
			return toBeReplaced;
		}
	}
}

