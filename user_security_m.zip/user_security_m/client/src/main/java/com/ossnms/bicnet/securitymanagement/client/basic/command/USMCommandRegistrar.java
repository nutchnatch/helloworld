/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMCommandRegistrar
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.MMR
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 05-May-2005  Babu B          CF001312   Master-Master Replication for Sun ONE DS
 * 01-Sep-2005  Muyeen Munaver  CF002862 - 9320_MR_0335  Clients hang up after EMS Server LAN Failure
 * 06-May-2009  Nagaraddi S S    TD004578 - RQT-STDERR errors instead log4j's
 * 
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.basic.command;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.securitymanagement.client.auth.AALoginBusinessDelegate;
import com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEventIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.auth.AAClientCacheData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionItemData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
/**
 * This class holds the mapping of "commandID to command". It as a repository
 * to hold the command object for the correpsonding command ID. When the
 * command is invoked by the user, the USMCommandManager (who treats the user
 * request through GUI or from another window when the user clicks GUI to
 * invoke the command, for instance) will query for the command object by
 * providing command ID.
 */
final class USMCommandRegistrar implements USMLogonLogoffEventIfc {
	
	private static final String USM_PROFILE_NAME = "SecurityPlugin_OpenViews";

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(USMCommandRegistrar.class);

	/**
	 * The command ID to the command map maintained by UICmdRegister object.
	 */
	private Map<USMCommandID, USMCommand> cmdIdToCmdHndlrTable = null;

	/**
	 * This is the active command list which holds the list of active commands
	 */
	private Hashtable<USMCommandID, List<USMCommand>> activeCmdIdToCmdHndlrTable = new Hashtable<>();

	/**
	* OU to Id Set Map
	*/
	private Map<String, Set<USMCommandID>> ou2Idmap = new Hashtable<>(13);

	/**
	 * Singleton instance
	 */
	static private USMCommandRegistrar mSelf = new USMCommandRegistrar();

	/**
	 * Singleton access method
	 */
	static USMCommandRegistrar getInstance() {
		return mSelf;
	}

	/**
	 * This is the default constructor of the class USMCommandRegistrar which
	 * instantiates its register (HashMap).
	 */
	private USMCommandRegistrar() {
		LOGGER.debug("Entering constructor");

		cmdIdToCmdHndlrTable = new Hashtable<>();

		populateOu2IdMap();

		LOGGER.debug("Exiting constructor");
	}

	/**
	 * populate the map of ou names vs command id's.
	 * will be used for closing all windows related to a given ou.
	 */
	private void populateOu2IdMap() {

		// Add Domain related stuff
		Set<USMCommandID> setDomainIds = new HashSet<>();
		setDomainIds.add(USMCommandID.S_UI_ID_VIEW_DOMAINS);
		setDomainIds.add(USMCommandID.S_UI_ID_NEW_DOMAIN);
		setDomainIds.add(USMCommandID.S_UI_ID_MODIFY_DOMAIN);
		ou2Idmap.put("Domains", setDomainIds);

		// Add Domain Mapping related stuff
		Set<USMCommandID> setDomainMappingIds = new HashSet<>();
		setDomainMappingIds.add(USMCommandID.S_UI_ID_VIEW_ACCESS_RIGHTS);
		setDomainMappingIds.add(USMCommandID.S_UI_ID_ASSIGN_MAPPINGS);
		ou2Idmap.put("DomainMappings", setDomainMappingIds);

		// Add Policy related stuff
		Set<USMCommandID> setPolicyIds = new HashSet<>();
		setPolicyIds.add(USMCommandID.S_UI_ID_VIEW_POLICIES);
		setPolicyIds.add(USMCommandID.S_UI_ID_NEW_POLICIES);
		setPolicyIds.add(USMCommandID.S_UI_ID_MODIFY_POLICY);
		ou2Idmap.put("PolicyList", setPolicyIds);

		// Add User related stuff
		Set<USMCommandID> setUserIds = new HashSet<>();
		setUserIds.add(USMCommandID.S_UI_ID_USER_MGMT_VIEW_USER);
		setUserIds.add(USMCommandID.S_UI_ID_USER_MGMT_CREATE_USER);
		setUserIds.add(USMCommandID.S_UI_ID_MODIFY_USER);
		ou2Idmap.put("Users", setUserIds);

		// Add User Group related stuff
		Set<USMCommandID> setUserGroupIds = new HashSet<>();
		setUserGroupIds.add(USMCommandID.S_UI_ID_USER_MGMT_VIEW_USER_GROUP);
		setUserGroupIds.add(USMCommandID.S_UI_ID_USER_MGMT_CREATE_USER_GROUP);
		setUserGroupIds.add(USMCommandID.S_UI_ID_MODIFY_USERGROUP);
		ou2Idmap.put("UserGroups", setUserGroupIds);

		// Add General Settings stuff
		Set<USMCommandID> setGenSecIds = new HashSet<>();
		setGenSecIds.add(USMCommandID.S_UI_ID_GENERAL_SECURITY_SETTINGS);
		ou2Idmap.put("GeneralSettings", setGenSecIds);

		// Add CFs stuff
		Set<USMCommandID> setCFIds = new HashSet<>();
		setCFIds.add(USMCommandID.S_UI_ID_VIEW_TMN_APPLICATION_SERVER);
		ou2Idmap.put("USMCFContainer", setCFIds);

	}

	/**
	 * This method registers the command associated with a specific command ID.
	 * If there is a command handler already registered for the commanb ID,
	 * this method call will fail.
	 * 
	 * @param uiCmdHdlr - This is the command handler object to be registered.
	 * @return boolean - Returns true if the command was successfully registered.
	 */
	boolean registerCmd(final USMCommand uiCmdHdlr) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering registerCmd for Command : " + uiCmdHdlr);
		}

		boolean bIsRegistered = false;

		try {
			USMCommandID cmdID = uiCmdHdlr.getCommandID();
			boolean bIsAlreadyAvailable = cmdIdToCmdHndlrTable.containsValue(cmdID);
			if (!bIsAlreadyAvailable) {

				if (null == cmdIdToCmdHndlrTable.put(cmdID, uiCmdHdlr)) {
					bIsRegistered = true;
				} else {
					LOGGER.debug(
						"A Null was not returned for the addition of the Object.");
				}

			} else {
				LOGGER.debug(
					"Registring a command which is already available.");
			}
		} catch (NullPointerException nullPtrExcp) {
			LOGGER.error(
				"Nullpointer exception for Command : "
					+ uiCmdHdlr
					+ " for the CommandID : "
					+ uiCmdHdlr.getCommandID());
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Exiting registerCmd for Command : "
					+ uiCmdHdlr
					+ "with result as : "
					+ bIsRegistered);
		}
		return bIsRegistered;
	}

	/**
	 * This method retrieves the command handler object associated with a
	 * command ID. This function has been provided so that the calling class
	 * can then make a clone of the Command.
	 * 
	 * @param uiCmdId - This is the command ID for which the associated command
	 *            handler object should be fetched
	 * @return USMCommand - The USMCommand of the given ID.
	 */
	USMCommand getCmdHndlr(final USMCommandID uiCmdId) {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering getCmdHndlr for Command ID : " + uiCmdId);
		}

		USMCommand cmdHndlr = null;

		try {
			cmdHndlr = cmdIdToCmdHndlrTable.get(uiCmdId);
		} catch (NullPointerException nullPtExcp) {
			LOGGER.error("Null Pointer exception raised for : " + uiCmdId);
		} catch (ClassCastException castExcp) {
			LOGGER.error("ClassCaseException raised for : " + uiCmdId);
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Exiting getCmdHndlr for Command ID : "
					+ uiCmdId
					+ " returning : "
					+ cmdHndlr);
		}
		return cmdHndlr;
	}

	/**
	 * This method returns the list of active command objects for the passed
	 * command ID
	 * 
	 * @param uiCmdID - The command ID for which the list of associated active
	 *            command handlers will be fetched
	 * @return java.util.Vector - Returns the current Vector of active commands.
	 */
	List<USMCommand> getListOfActiveCmds(final USMCommandID uiCmdID) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
					"Entering getListOfActiveCmds for CommandID : " + uiCmdID);
		}

		List<USMCommand> listOfActiveCmds = null;

		try {
			listOfActiveCmds = activeCmdIdToCmdHndlrTable.get(uiCmdID);
		} catch (NullPointerException nullPtrExcp) {
			LOGGER.error("Null Pointer error, for CommandID : " + uiCmdID);
		} catch (ClassCastException castExcp) {
			LOGGER.error("Class Cast error, for CommandID : " + uiCmdID);
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Exiting getListOfActiveCmds for CommandID : "
					+ uiCmdID
					+ " returning the Objects : "
					+ listOfActiveCmds);
		}

		return listOfActiveCmds;
	}

	/**
	 * This method adds the command handler object to the list of active
	 * commands. This method is generally invoked after the execute is called
	 * on the command hanlder object by UIMainFrame
	 * 
	 * @param cmdHndlrObj - Command Handler object to be added to the active command list
	 * @return boolean - Returns true if the method was successful in adding the
	 *         command to the list.
	 */
	boolean addToListOfActiveCmds(final USMCommand cmdHndlrObj) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering the addToListOfActiveCmds for the Command : "
					+ cmdHndlrObj);
		}

		USMCommandID cmdID = cmdHndlrObj.getCommandID();

		List<USMCommand> listOfActiveCmd =
			 activeCmdIdToCmdHndlrTable.get(cmdID);

		if (null == listOfActiveCmd) {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(
					"Creating a new Vector for the active commands for Command : "
						+ cmdHndlrObj);
			}
			listOfActiveCmd = new ArrayList<>();
			activeCmdIdToCmdHndlrTable.put(
					cmdHndlrObj.getCommandID(),
					listOfActiveCmd);
		}

		boolean bIsAdded = listOfActiveCmd.add(cmdHndlrObj);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Exiting the addToListOfActiveCmds for the Command : "
					+ cmdHndlrObj
					+ " status of addition is : "
					+ bIsAdded);
		}
		return bIsAdded;
	}

	/**
	 * This method removes the active command object from the acitve command
	 * list associated with a command ID. This method is called by
	 * UICmdHndlrInfce when one of its derived object is about to be shut down.
	 * 
	 * @param cmdHndlrObj - The command handler object which should be removed
	 */
	void removeFromActiveCmdList(final USMCommand cmdHndlrObj) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering the removeFromActiveCmdList for the Command : "
					+ cmdHndlrObj);
		}
		try {
			USMCommandID cmdID = cmdHndlrObj.getCommandID();
			List<USMCommand> listOfActiveCmd = activeCmdIdToCmdHndlrTable.get(cmdID);

			if (null != listOfActiveCmd) {
				boolean bRemoved = listOfActiveCmd.remove(cmdHndlrObj);

				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug(
						"Result of removeFromActiveCmdList is : " + bRemoved);
				}

			} else {
				LOGGER.error("Trying to remove a command from a null list.");
			}

		} catch (NullPointerException nullPtrExcp) {
			LOGGER.error("Null Pointer exception for : " + cmdHndlrObj);
		} catch (ClassCastException castExcp) {
			LOGGER.error("Class Cast exception for : " + cmdHndlrObj);
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Exiting the removeFromActiveCmdList for the Command : "
					+ cmdHndlrObj);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEventInfc#operatorLoggedOn()
	 */
	@Override
    public void operatorLoggedOn(ISessionContext sessionContext) {
		LOGGER.debug("Entering the operatorLoggedOn");

		// Activate views opened at time of last logoff
		restoreViews();

		LOGGER.debug("Exiting the operatorLoggedOn");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEventInfc#operatorLoggedOff()
	 */
	@Override
    public void operatorLoggedOff(ISessionContext sessionContext) {
		LOGGER.debug("Entering the operatorLoggedOff");

		closeAllWindows();
		activeCmdIdToCmdHndlrTable.clear();

		LOGGER.debug("Exiting the operatorLoggedOff");
	}

	/**
	 * Methods added to unit test the code. These methods will return the
	 * necessary map, but only after making them as read-only
	 * 
	 * @return Map
	 * 			Readonly version of the Active Command List map. 
	 */
	Map<USMCommandID, List<USMCommand>> getMapOfActiveCmd() {
		// This function has been added for the sole purpouse of Unit Testing.
		// It therefore has no trace statements.
		return Collections.unmodifiableMap(activeCmdIdToCmdHndlrTable);
	}

	/**
	 * Methods added to unit test the code. These methods will return the
	 * necessary map, but only after making them as read-only
	 * 
	 * @return Map
	 * 			Readonly version of the Map of registered commands
	 */
	Map<USMCommandID, USMCommand> getMapOfCommandIdToCommandHndlr() {
		// This function has been added for the sole purpouse of Unit Testing.
		// It therefore has no trace statements.
		Map<USMCommandID, USMCommand> mp = null;
		if (null != cmdIdToCmdHndlrTable) {
			mp = Collections.unmodifiableMap(cmdIdToCmdHndlrTable);
		}
		return mp;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEventIfc#operatorLoggingOff()
	 */
	@Override
    public void operatorLoggingOff(ISessionContext sessionContext) {

		// List of active commands
		Map<Object, String> mapCommandsToBeSaved = new Hashtable<>(17);

		updateOpenViews(mapCommandsToBeSaved);

		// Save the profiles, now!
		try {
			saveOpenViews(mapCommandsToBeSaved);
		} catch (BiCNetPluginException e) {
			LOGGER.error("Exception :", e);
		}
	}

	private void saveOpenViews(Map<Object, String> mapCommandsToBeSaved) throws BiCNetPluginException {
		Properties ldapProfile = new Properties();

		Iterator viewsIt = mapCommandsToBeSaved.entrySet().iterator();
		Map.Entry key;
		while (viewsIt.hasNext()) {
			key = (Map.Entry) viewsIt.next();
			ldapProfile.put(key.getKey(), key.getValue());
		}

		USMUtility.getInstance().getSecureClientSession().setUserProfile(USM_PROFILE_NAME, ldapProfile);
	}

	private void updateOpenViews(Map<Object, String> mapCommandsToBeSaved) {

		mapCommandsToBeSaved.clear();

		for (Enumeration<USMCommandID> enActiveCmds = activeCmdIdToCmdHndlrTable.keys();
			enActiveCmds.hasMoreElements();
			) {
			USMCommandID cmdID = enActiveCmds.nextElement();

			List<USMCommand> listOfActiveCmd = activeCmdIdToCmdHndlrTable.get(cmdID);

			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(
					"Saving the active objects for command : "
						+ cmdID
						+ " Object(s) being : "
						+ listOfActiveCmd);
			}

			if (listOfActiveCmd != null) {
				for (USMCommand cmd : listOfActiveCmd) {
					Object strCommandKey = cmd.getKey();
					String strCommandClass =
							String.valueOf(cmd.getCommandID().getIntegerId());

					if (null != strCommandKey) {
						mapCommandsToBeSaved.put(
								strCommandKey,
								strCommandClass);
					}
					if (LOGGER.isDebugEnabled()) {
						LOGGER.debug(
								"Saving details for the command : "
										+ strCommandKey
										+ "->"
										+ strCommandClass);
					}
				}
			}
		}
	}

	private void restoreViews() {

		Properties ldapProfile = USMUtility.getInstance().getSecureClientSession().getUserProfile(USM_PROFILE_NAME);

		if (ldapProfile == null) {
			return;
		}

		for (Object o : ldapProfile.entrySet()) {
			try {

				Map.Entry mapEntry = (Map.Entry) o;

				Object objCommandKey = mapEntry.getKey();
				String strCommandId = (String) mapEntry.getValue();
				int nCommandId = Integer.parseInt(strCommandId);
				USMCommandID objCommandId = USMCommandID.getCommandID(nCommandId);

				boolean bPermission = false;
				ISessionContext ctx = USMUtility.getInstance().getSessionContext();
				AALoginBusinessDelegate objDelegate = new AALoginBusinessDelegate();
				AAClientCacheData objClientCachedata = objDelegate.getClientCacheData(ctx);
				List<PAPolicyData> vecPolicies = objClientCachedata.getPolicies();

				int nPolicyCount = vecPolicies.size();

				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("nPolicyCount =" + nPolicyCount);
				}

				// Loop among the policies and check whether the menu is available in the policy.
				for (int nPolicyIndex = 0; nPolicyIndex < nPolicyCount; ++nPolicyIndex) {
					PAPolicyData objPolicy = vecPolicies.get(nPolicyIndex);

					// query each policy for the menu items
					List<String> permissionItems = getPermissionItems(objPolicy);

					// log debug information
					LOGGER.debug("Policy [" + nPolicyIndex + "] - " + objPolicy);
					LOGGER.debug("Menu Entries count - " + permissionItems.size());

					// if the retrieved list contains the permission item, break
					if(permissionItems.contains(objCommandId.getMenuString())){
						bPermission = true;
						break;
					}
				}

				if (bPermission) {
					USMCommandManager.getInstance().executeCmd(objCommandId, objCommandKey);
				}
				LOGGER.debug("getMenuString = " + objCommandId.getMenuString());

			} catch (Exception ex) {
				LOGGER.warn("restoreViews " + ex);
			}
		}
	}

	/**
	 * Retrieves a list of permission item names for a given policy
	 *
	 * @param objPolicy the policy to analyze.
	 * @return a List of Strings, containing the names of the permission items. The size will be zero if none
	 * is found or if the policy is null.
	 */
	private List<String> getPermissionItems(PAPolicyData objPolicy) {
		// instantiate list of String
		List<String> permissionItems = new ArrayList<>();

		if(objPolicy == null || objPolicy.getPermissionDataList() == null) {
			return permissionItems;
		}

		// iterate over the permissions inside the policy
		for(PAPermissionData permissionData : objPolicy.getPermissionDataList()){
			// for each permission, iterate over the permission items
			for(PAPermissionItemData permissionItemData : permissionData.getPermissionItems()){
				// add each permission item into the previously created list
				permissionItems.add(permissionItemData.getName());
			}
		}

		return permissionItems;
	}

	/**
	 * Function to perform cleanup actions
	 * @return boolean Indicates the status of the clean up.
	 */
	public boolean cleanup() {
		ISessionContext ctx = USMUtility.getInstance().getSessionContext();

		operatorLoggingOff(ctx);
		operatorLoggedOff(ctx);

		return false;
	}

	/**
	 * Function to return the number of active commands.
	 * @return int The number of active commands.
	 */
	public int getNumberOfActiveCmds() {
		return activeCmdIdToCmdHndlrTable.size();
	}

	/**
	 * Close all windows associated with the specified OU.
	 * 
	 * @param strOUName OU which has been reloaded
	 */
	void closeWindows(String strOUName) {

		Set<USMCommandID> setCmdIds = ou2Idmap.get(strOUName);
		for (USMCommandID objCmdId : setCmdIds) {
			List<USMCommand> listOfActiveCmd = activeCmdIdToCmdHndlrTable.get(objCmdId);
			if (listOfActiveCmd != null) {
				for (USMCommand cmd : listOfActiveCmd) {
					if (LOGGER.isDebugEnabled()) {
						LOGGER.debug(
								"Calling cleanup for the command : " + cmd);
					}
					cmd.cleanup();
				}
			}
		}

	}

	/**
	 * Close all USM windows.
	 */
	public void closeAllWindows() {
		// Terminate all active commands
		Enumeration<USMCommandID> enActiveCmds = activeCmdIdToCmdHndlrTable.keys();

		for (; enActiveCmds.hasMoreElements();) {
			USMCommandID cmdID = enActiveCmds.nextElement();

			List<USMCommand> listOfActiveCmd = activeCmdIdToCmdHndlrTable.get(cmdID);

			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(
					"Removing the active objects for command :"
						+ cmdID
						+ " Object(s) being : "
						+ listOfActiveCmd);
			}

			if (listOfActiveCmd != null) {
				for (USMCommand cmd : listOfActiveCmd) {
					if (LOGGER.isDebugEnabled()) {
						LOGGER.debug(
								"Calling cleanup for the command : " + cmd);
					}
					cmd.cleanup();
				}
				listOfActiveCmd.clear();
			}
		}

		activeCmdIdToCmdHndlrTable.clear();
	}
}