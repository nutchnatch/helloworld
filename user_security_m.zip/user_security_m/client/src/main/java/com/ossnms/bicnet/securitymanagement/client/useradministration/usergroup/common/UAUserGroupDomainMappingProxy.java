/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCDomainMappingProxy
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.MAPPING.CREATE 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.useradministration.usergroup.common;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMBaseController;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.domain.job.DCAssignMappingsJob;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessageType;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;
import com.ossnms.bicnet.securitymanagement.common.policy.PAMessageType;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UACommonHelper;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserGroup;
import com.ossnms.tools.jfx.JfxStringTable;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * This is the client interactor class which is responsible for regulating
 * user group mappings of domain and policy assignment
 */
public abstract class UAUserGroupDomainMappingProxy extends USMBaseController {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(UAUserGroupDomainMappingProxy.class);

    /**
     * This is the constructor
     *
     * @param view -
     *             This is the view associated with the controller
     */
    public UAUserGroupDomainMappingProxy(UAUserGroupCreateModifyBaseView view) {

        super(view);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("UAUserGroupDomainMappingProxy(" + view + ") - Enter");
        }

        //Fault ID 64, 24
        List vectorForNotification = new ArrayList();
        vectorForNotification.add(DCMessageType.DC_NOT_MAPPINGS_MODIFIED);
        vectorForNotification.add(DCMessageType.DC_NOT_DOMAIN_DELETED);

        vectorForNotification.add(PAMessageType.S_PA_NOT_POLICY_CREATED);
        vectorForNotification.add(PAMessageType.S_PA_NOT_POLICY_DELETED);

        vectorForNotification.add(UAMessageType.S_UG_NOT_REMOVE_USER_GROUP);
        vectorForNotification.add(UAMessageType.S_UG_NOT_CREATE_USER_GROUP);

        registerInterestedNotificationIds(vectorForNotification);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("UAUserGroupDomainMappingProxy(" + view + ") - Exit");
        }
    }


    @Override
    public void handleNotification(USMMessage msg) {

        LOGGER.debug("handleNotification() - Enter");
        if (null != associatedView) {
            USMBaseMsgType msgType = msg.getMessageType();

            if (msgType.equals(DCMessageType.DC_NOT_MAPPINGS_MODIFIED)) {
                handleNotifMappingsModified(msg);

            } else if (msgType.equals(DCMessageType.DC_NOT_DOMAIN_DELETED)) {
                handleNotifDomainDeleted(msg);

            } else if (msgType.equals(PAMessageType.S_PA_NOT_POLICY_CREATED)) {
                handleNotifPolicyCreated(msg);

            } else if (msgType.equals(PAMessageType.S_PA_NOT_POLICY_DELETED)) {
                handleNotifPolicyDeleted(msg);

            } else if (
                    msgType.equals(UAMessageType.S_UG_NOT_REMOVE_USER_GROUP)) {
                handleNotifUserGroupDeleted(msg);
            } else if (
                    msgType.equals(UAMessageType.S_UG_NOT_CREATE_USER_GROUP)) {
                handleNotifUserGroupCreated(msg);
            } else {
                LOGGER.warn("Unknown notification has been sent " + msgType);
            }
        }

        LOGGER.debug("handleNotification() - Exit");
    }

    private void handleNotifUserGroupCreated(USMMessage msg) {
        UAUserGroup userGrp = new UAUserGroup();
        userGrp.popMe(msg);
        //getWindow().getDomainsPoliciesPane().userGroupCreated(userGrp); TODO: handle differently (change to handle domain created)

    }


    private void handleNotifUserGroupDeleted(USMMessage msg) {
        List grps = UACommonHelper.popUserGroupsFromMessage(msg);
        for (int i = 0; i < grps.size(); ++i) {
            //getWindow().getDomainsPoliciesPane().userGroupsDeleted((UAUserGroup) grps.get(i)); TODO: handle differently
        }

    }

//	/**
//	 * This method gets invoked when the mappings for a domain have to be
//	 * retrieved
//	 * 
//	 * @param domain -
//	 *            Domain object for ehich the mappings have to be retrieved
//	 */
//	public void getMappingsForDomain(DCDomainData domain) {
//
//		if (LOGGER.isDebugEnabled()) {
//			LOGGER.debug("getMappingsForDomain(" + domain + ") - Enter");
//		}
//
//		if (LOGGER.isInfoEnabled()) {
//			LOGGER.info("Getting mappings for the domain " + domain);
//		}
//
//		DCGetMappingsOfDomainJob job =
//			new DCGetMappingsOfDomainJob(
//				DCMessageType.DC_REQ_MAPPING_FOR_DOMAIN,
//				this,
//				domain);
//		queueJob(job);
//
//		if (LOGGER.isDebugEnabled()) {
//			LOGGER.debug("getMappingsForDomain(" + domain + ") - Exit");
//		}
//	}

    /**
     * This method handles the notifications whenever mappings are modified.
     * When mappings are modified then the window has to refresh itself with
     * the changed mapping.
     *
     * @param msg -
     *            The message which contains the list of changed mappings.
     */
    protected void handleNotifMappingsModified(USMMessage msg) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleMappingsModifiedNotif(" + msg + ") - Enter");
        }
        List modifiedMappings = new ArrayList();
        DCDomainMapping.popMappingsFromMessage(msg, modifiedMappings);

        //The other information passed in the notif are not relevant to this
        //window, since this handles information for only one user group and
        //all policy information are alredy got in the beginning.
        getWindow().getDomainsPoliciesPane().mappingsChanged(modifiedMappings);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleMappingsModifiedNotif(" + msg + ") - Exit");
        }

    }


    /**
     * This method handles the response when the message to retrieve the
     * mappings associated with the user group is retrieved.
     *
     * @param msg -
     *            The message contains the error id and the list of mappings
     *            and the policy name and id pair, and the domains.
     */
    protected void handleResponseGetMappingsForUserGroup(USMMessage msg) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "handleMappingsForDomainResponse(" + msg + ") - Enter");
        }

        Integer errId = msg.popInteger();
        List<DCDomainMapping> mappings = new ArrayList<DCDomainMapping>();
        List<PAPolicyId> policies = new ArrayList<PAPolicyId>();
        List<DCDomainData> domains = new ArrayList<DCDomainData>();

        if (errId.equals(DCMessages.DC_NO_ERROR)) {
            DCDomainMapping.popMappingsFromMessage(msg, mappings);

            DCDomainData.popDomainsFromMessage(msg, domains);

            int nPolicyId = msg.popInteger().intValue();
            for (int nDx = 0; nDx < nPolicyId; ++nDx) {
                PAPolicyId polId = new PAPolicyId();
                polId.popMe(msg);
                policies.add(polId);
            }

            if (LOGGER.isInfoEnabled()) {
                LOGGER.info("Mapping fetched with details " + mappings);
            }
            getWindow().getDomainsPoliciesPane().populateMappings(mappings, policies, domains);
        } else {
            getWindow().showMessage(DCMessages.getInstance().getString(errId));
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "handleMappingsForDomainResponse(" + msg + ") - Exit");
        }
    }

    /**
     * This method gets called as a response to the mappings getting
     * assigned/unassigned. On success this method should initiate the window
     * to shut down itself.
     *
     * @param msg The message which contains the response.
     */
    protected void handleResponseAssignMappings(USMMessage msg) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleAssignMappingsResponse(" + msg + ") - Enter");
        }

        Integer globalErrId = msg.popInteger();
        if (globalErrId.equals(DCMessages.DC_NO_ERROR)) {
            getWindow().closeWindow();
        } else {
            LOGGER.warn("Error in assigning the policy to the mappings");
            List errMapps = new ArrayList();
            DCDomainMapping.popMappingsFromMessage(msg, errMapps);
            String errStr = retreiveErrorMessage(errMapps);
            LOGGER.error(errStr);
            getWindow().showMessage(errStr);
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleAssignMappingsResponse(" + msg + ") - Exit");
        }

    }

    /**
     * Retrieves the error message given the list of errored mappings passed
     *
     * @param errMapps The list of errored mappings
     * @return Returns the concatenated error string to be displayed
     */
    private String retreiveErrorMessage(List errMapps) {

        LOGGER.debug("retreiveErrorMessage - Enter");
        Map<Integer, String> mapErr = new HashMap();

        for (int i = 0; i < errMapps.size(); ++i) {
            DCDomainMapping mapp = (DCDomainMapping) errMapps.get(i);
            Object strMap = mapErr.get(mapp.getErrorId());
            if (null == strMap) {
                mapErr.put(mapp.getErrorId(), mapp.getUserGroup());
                LOGGER.error(
                        "Error for the mapping, adding first time "
                                + mapp
                                + " Error Id :"
                                + mapp.getErrorId());
            } else {
                mapErr.put(
                        mapp.getErrorId(),
                        strMap.toString() + "," + mapp.getUserGroup());
                LOGGER.error(
                        "Error for the mapping, adding second time as error Id is same "
                                + mapp
                                + " Error Id :"
                                + mapp.getErrorId());
            }
        }

        StringBuilder errStr = new StringBuilder(
                JfxStringTable.getString(USMStringTable.IDS_DC_MSG_MAPPING_NOT_ASSIGNED));

        for (Entry<Integer, String> entry : mapErr.entrySet()) {
            errStr.append("\n");
            errStr.append(entry.getValue());
            errStr.append(":\n");
            errStr.append(DCMessages.getInstance().getString(entry.getKey()));
        }
        LOGGER.debug("retreiveErrorMessage - Exit");
        return errStr.toString();
    }

    /**
     * This method handles the notification of a policy being created. When a
     * new policy is created, the policy should get added in the list of
     * available policies to be assigned.
     *
     * @param msg -
     *            The PolicyData pair is part of this message.
     */
    void handleNotifPolicyCreated(USMMessage msg) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handlePolicyCreatedNotif(" + msg + ") - Enter");
        }
        PAPolicyData policy = new PAPolicyData();
        policy.popMe(msg);
        PAPolicyId policyNameId =
                new PAPolicyId(policy.getPolicyID(), policy.getPolicyName());
        getWindow().getDomainsPoliciesPane().policyCreated(policyNameId);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handlePolicyCreatedNotif(" + msg + ") - Exit");
        }
    }

    /**
     * This method handles the policy deletion notification. Policy could be
     * deleted and as a result, the assign policy window should remove this
     * policy from the available policies.
     *
     * @param msg -
     *            The list of policies which were deleted.
     */
    void handleNotifPolicyDeleted(USMMessage msg) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handlePolicyDeletedNotif(" + msg + ") - Enter");
        }
        int nPolicy = msg.popInteger().intValue();
        for (int nDx = 0; nDx < nPolicy; ++nDx) {
            PAPolicyId policy = new PAPolicyId();
            policy.popMe(msg);
            getWindow().getDomainsPoliciesPane().policyDeleted(policy);
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handlePolicyDeletedNotif(" + msg + ") - Exit");
        }
    }

    /**
     * This methid handles the notification of a a domain being deleted. When
     * the domain gets deleted and if the assign policy window is open for that
     * domain, the window should be closed.
     *
     * @param msg -
     *            Message contains the domain which got deleted.
     */
    void handleNotifDomainDeleted(USMMessage msg) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleDomainDeletedNotif(" + msg + ") - Enter");
        }
        DCDomainData dom = new DCDomainData();
        dom.popMe(msg);
        //getWindow().getDomainsPoliciesPane().domainDeleted(dom); TODO: handle domain delete differently
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleDomainDeletedNotif(" + msg + ") - Exit");
        }

    }

    /**
     * @param changedMappings
     * @param domain
     */
    public void assignMappings(DCDomainData domain, List changedMappings) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("assignMappings(" + changedMappings + ") - Enter");
        }

        if (LOGGER.isInfoEnabled()) {
            LOGGER.info(
                    "Mappings which need to be assigned " + changedMappings);
        }

        DCAssignMappingsJob job =
                new DCAssignMappingsJob(
                        DCMessageType.DC_REQ_ASSIGN_MAPPING,
                        this,
                        changedMappings,
                        domain);

        queueJob(job);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("assignMappings(" + changedMappings + ") - Exit");
        }
    }

    /**
     * Method to typecast the base view pointer and get the derived window.
     *
     * @return Typecasted domain mapping window
     */
    private UAUserGroupCreateModifyBaseView getWindow() {
        return (UAUserGroupCreateModifyBaseView) associatedView;
    }
}
