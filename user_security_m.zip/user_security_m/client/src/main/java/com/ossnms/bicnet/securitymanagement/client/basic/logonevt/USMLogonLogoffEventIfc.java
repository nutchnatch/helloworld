/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMLogonLogoffEventIfc
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.logonevt;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;

/**
 * A lot of classes within USM client require to be notified when the oeprator
 * logs in or logs out of the system.
 * 
 * Rather then keep track of such classes in the logon() and logoff() method, a
 * interface is being provided that these classes have to implement.
 * 
 * This class defines the interfaces for these events.
 */

public interface USMLogonLogoffEventIfc {
	/**
	 * This is the function that will be called by the USM Framework when the
	 * operator successfully logs on to the Server
	 * 
	 * All initialization like caching of the context, connecting to topics
	 * should be done here
	 */
	void operatorLoggedOn(ISessionContext sessionContext);

	/**
	 * This is the function that will be called by the USM Framework when the
	 * operator logs out.
	 * 
	 * All cleanup like removing the context from the cache and disconnecting
	 * from the topics should be done here
	 */
	void operatorLoggedOff(ISessionContext sessionContext);

	/**
	 * This is the function that will be called by the USM Frameword when the
	 * operator is about to Log off.
	 *
	 * All functions to write the profile of the operator should be done here.
	 */
	void operatorLoggingOff(ISessionContext sessionContext);
}
