package com.ossnms.bicnet.securitymanagement.client.auth.sso;

import com.ossnms.bicnet.securitymanagement.api.common.SSOAuthenticationToken;
import com.ossnms.bicnet.securitymanagement.client.SecurityLogonView;
import org.ietf.jgss.GSSContext;
import org.ietf.jgss.GSSCredential;
import org.ietf.jgss.GSSException;
import org.ietf.jgss.GSSManager;
import org.ietf.jgss.GSSName;
import org.ietf.jgss.Oid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.naming.NamingException;
import javax.security.auth.Subject;
import javax.security.auth.kerberos.KerberosTicket;
import javax.security.auth.login.AppConfigurationEntry;
import javax.security.auth.login.Configuration;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * created on 5/8/2015
 */
public final class SSOClientManager {

    private static final Logger LOGGER = LoggerFactory.getLogger(SSOClientManager.class);

    private static final String GSS_API_KRB_OID = "1.2.840.113554.1.2.2";
    private static final String JAVA_SYS_PROPERTY_KRB5_REALM = "java.security.krb5.realm";
    private static final String JAVA_SYS_PROPERTY_KRB5_KDC = "java.security.krb5.kdc";

    private static final String NAME_KERBEROS_CONF_CLASS = SecurityLogonView.class.getName();

    private static final String LOGIN_MODULE_NAME = "com.sun.security.auth.module.Krb5LoginModule";
    private static final String LOGIN_PROP_TICKET_CACHE = "useTicketCache";
    private static final String LOGIN_REFRESH_KRB5_CONFIG = "refreshKrb5Config";

    private static final String FORMAT_SERVICE_TICKET = "%s@%s";
    private static final String SERVICE_LDAP = "ldap";

    /**
     * Private constructor
     */
    private SSOClientManager(){}

    /**
     * Authenticates the user against the specified kdc
     *
     * @param subject the security subject
     * @param realm the realm against which we wish to authenticate
     * @throws LoginException
     */
    public static void authenticate(Subject subject, String realm) throws LoginException {
        //Store current real and kdc properties for later restoration
        String systemRealm = System.getProperty(JAVA_SYS_PROPERTY_KRB5_REALM);
        String systemKDC = System.getProperty(JAVA_SYS_PROPERTY_KRB5_KDC);

        try {
            LOGGER.warn("[SSO] Requesting Kerberos Authentication for realm {}", realm);

            LoginContext context = new LoginContext(
                    NAME_KERBEROS_CONF_CLASS,
                    subject,
                    callbacks -> {
                        //Do nothing
                    },
                    getKerberosConfiguration()
            );

            System.setProperty(JAVA_SYS_PROPERTY_KRB5_REALM, realm.toUpperCase());
            System.setProperty(JAVA_SYS_PROPERTY_KRB5_KDC, realm.toUpperCase());

            context.login();
            LOGGER.warn("[SSO] Successfully established login context for realm {}.", realm);
        } finally {
            //restore realm and kdc
            System.setProperty(JAVA_SYS_PROPERTY_KRB5_REALM, systemRealm);
            System.setProperty(JAVA_SYS_PROPERTY_KRB5_KDC, systemKDC);
        }
    }

    /**
     * Retrieves a new ldap service ticket for the specified hostname, adding said ticket to the Subject's private
     * credentials
     *
     * @param subject the security subject
     * @param hostname the hostname for which we which to retrieve the service ticket
     * @throws PrivilegedActionException
     */
    public static void requestServiceTicket(Subject subject, String hostname) throws PrivilegedActionException {
        LOGGER.warn("[SSO] Requesting LDAP Service ticket for server {}...", hostname);
        // instantiate a new service ticket request action
        TicketRequestAction ticketAction = new TicketRequestAction(hostname, SERVICE_LDAP);
        // perform action as the specified security Subject
        Subject.doAs(subject, ticketAction);
        LOGGER.warn("[SSO] Successfully obtained LDAP Service ticket for {}", hostname);
    }

    /**
     * Issues calls to the specified LDAP server to retrieve the subject's objectSID
     *
     * @param ssoSubject the subject for which we require the objectSID
     * @param hostName the ldap server to reach
     * @return the ObjectSID, if it exists, null otherwise
     */
    public static String getObjectSID(Subject ssoSubject, String sAMAccountName, String realm, String hostName, String port) {
        byte[] objectSid;
        try {
            objectSid = new LDAPManager(ssoSubject, realm, hostName, port).getObjectSID(sAMAccountName);
            return decodeSID(objectSid);
        } catch (NamingException e) {
            LOGGER.error("Failed to retrieve objectSID for " + sAMAccountName, e);
        }

        return null;
    }

    /**
     * Issues calls to the specified LDAP server to retrieve the subject's userPrincipalName
     *
     * @param ssoSubject the Security Subject
     * @param sAMAccountName the account name
     * @param realm the realm to look the user from
     * @param hostName the location of the server (hostname)
     * @param port the location of the server (port)
     *
     * @return the attribute's value (userPrincipalName) or null if none was found
     */
    public static String getUserPrincipalName(Subject ssoSubject, String sAMAccountName, String realm, String hostName, String port) {
        try {
            return new LDAPManager(ssoSubject, realm, hostName, port).getUserPrincipalName(sAMAccountName);
        } catch (NamingException e) {
            LOGGER.error("Failed to retrieve objectSID for " + sAMAccountName, e);
        }

        return null;
    }

    /**
     * Given the service hostname, will search the private credentials of the specified subject for an ldap service
     * ticket. If it succeeds, sets the objectSID on the authentication token and returns.
     *
     * @param subject the subject which contains all the private credentials
     * @param confServiceHostname the hostname for which we require the service ticket
     * @param objectSID the object SID of the security principal
     * @return an instance of SSOAuthenticationToken, filled with the objectSID and KerberosTicket (ldap), or null if
     * any of these elements was missing.
     */
    public static SSOAuthenticationToken prepareToken(Subject subject,  String confServiceHostname, String objectSID){
        if(subject == null || confServiceHostname == null){
            LOGGER.debug(
                    String.format("Invalid method invocation: hostname %s / objectSID %s / subject %s", confServiceHostname, objectSID, subject)
            );
            return null;
        }

        KerberosTicket ldapServiceTicket = null;

        // The next step is to iterate over the private credentials and retrieve the
        // important KerberosTicket (which grants access to the configured ldap server)
        Set<KerberosTicket> kerberosTickets = subject.getPrivateCredentials(KerberosTicket.class);

        for (KerberosTicket ticket : kerberosTickets) {
            LOGGER.debug("################### service principal: " + ticket.getServer().getName());
            LOGGER.debug("################### ticket: " + ticket.toString());

            String ticketServer = ticket.getServer().toString().toLowerCase();

            // if the ticket corresponds to an ldap service ticket and it contains the specified
            // realm, then it is the required ticket
            if(ticketServer.contains(SERVICE_LDAP) && ticketServer.contains(confServiceHostname)){
                LOGGER.debug("############################ Found ticket for ldap at " + confServiceHostname);
                ldapServiceTicket = ticket;
                //continue
                break;
            }
        }

        if(ldapServiceTicket == null){
            LOGGER.warn("Could not find a service ticket for " + confServiceHostname);
            return null;
        }

        SSOAuthenticationToken authenticationToken = new SSOAuthenticationToken();

        authenticationToken.setKerberosTicket(ldapServiceTicket);
        authenticationToken.setObjectSID(objectSID);
        authenticationToken.setLdapServer(confServiceHostname);

        return authenticationToken;
    }

    /**
     * Returns the Configuration instance that configures the Kerberos calls
     * @return a new instance of Configuration
     */
    private static Configuration getKerberosConfiguration(){
        return new Configuration() {
            @Override
            public AppConfigurationEntry[] getAppConfigurationEntry(String name) {
                Map<String, Object> options = new HashMap<>(1);

                options.put(LOGIN_PROP_TICKET_CACHE, "true");
                options.put(LOGIN_REFRESH_KRB5_CONFIG, "true");

                return new AppConfigurationEntry[]{
                        new AppConfigurationEntry(
                                LOGIN_MODULE_NAME,
                                AppConfigurationEntry.LoginModuleControlFlag.REQUIRED,
                                options)
                };
            }
        };
    }

    /**
     * Priviled Action to request an ldap Service Ticket.
     *
     * To use with Subject.doAs or Subject.doAsPrivileged
     */
    private static class TicketRequestAction implements PrivilegedExceptionAction<byte[]> {

        private String hostname;
        private String service;

        /**
         * Constructor
         *
         * @param hostname the hostname where the ldap server is located
         * @param service the name of the service we which to request
         */
        public TicketRequestAction(String hostname, String service){
            this.hostname = hostname;
            this.service = service;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public byte[] run() throws GSSException {
            GSSManager manager = GSSManager.getInstance();
            GSSCredential clientCredential = manager.createCredential(GSSCredential.INITIATE_ONLY);

            //request the server ticket for the specified realm
            GSSName serverName = manager.createName(
                    String.format(FORMAT_SERVICE_TICKET, service, hostname),
                    GSSName.NT_HOSTBASED_SERVICE
            );

            Oid krb5Oid = new Oid(GSS_API_KRB_OID);
            GSSContext context = manager.createContext(serverName, krb5Oid, clientCredential, GSSContext.DEFAULT_LIFETIME);
            return context.initSecContext(new byte[0], 0, 0);
        }
    }

    /**
     * The binary data is in the form:
     * byte[0] - revision level
     * byte[1] - count of sub-authorities
     * byte[2-7] - 48 bit authority (big-endian)
     * and then count x 32 bit sub authorities (little-endian)
     *
     * The String value is: S-Revision-Authority-SubAuthority[n]...
     *
     * Based on code from here - http://forums.oracle.com/forums/thread.jspa?threadID=1155740&tstart=0
     */
    public static String decodeSID(byte[] sid) {
        if(sid == null){
            return null;
        }
        final StringBuilder strSid = new StringBuilder("S-");

        // get version
        final int revision = sid[0];
        strSid.append(Integer.toString(revision));

        //next byte is the count of sub-authorities
        final int countSubAuths = sid[1] & 0xFF;

        //get the authority
        long authority = 0;
        //String rid = "";
        for(int i = 2; i <= 7; i++) {
            authority |= ((long)sid[i]) << (8 * (5 - (i - 2)));
        }
        strSid.append("-");
        strSid.append(Long.toHexString(authority));

        //iterate all the sub-auths
        int offset = 8;
        int size = 4; //4 bytes for each sub auth
        for(int j = 0; j < countSubAuths; j++) {
            long subAuthority = 0;
            for(int k = 0; k < size; k++) {
                subAuthority |= (long)(sid[offset + k] & 0xFF) << (8 * k);
            }

            strSid.append("-");
            strSid.append(subAuthority);

            offset += size;
        }

        return strSid.toString();
    }
}
