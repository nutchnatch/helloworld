/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-Apr-2005	Asif			CF000834 - Command Log Entries	CF USM
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.useradministration.usercreate;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMBaseController;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobCreateUser;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobGetAllPasswordValidationRules;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobGetAllUserGroup;
import com.ossnms.bicnet.securitymanagement.common.auth.PasswordValidationRulesConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.general.GSStatus;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAStatus;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserGroup;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * This class implements the controller for the Create User View.This listens
 * to the notifications and updates the view
 */
public class UACreateUserClientController extends USMBaseController {

	/**
	 * Data member for the Logging of the class.
	 */
    private static final Logger LOGGER = Logger.getLogger(UACreateUserClientController.class);

	/**
	 * This is the constructor
	 * 
	 * @param pView -
	 *            The view associated with the controller
	 */
	public UACreateUserClientController(UACreateUserView pView) {
		super(pView);
		LOGGER.debug("UACreateUserClientController() in the constructor");
		associatedView = pView;
		registerInterestedNotificationIds(getInterestedNotifcations());
	}

	/**
	 * Function to return the Notification IDs that the controller is
	 * interested in.
	 * 
	 * @return The List of Notification IDs that the controller is interested
	 * in
	 */
	private List getInterestedNotifcations() {
		LOGGER.debug("getInterestedNotifcations() entry");

		List vectorForNotification = new ArrayList();
		vectorForNotification.add(UAMessageType.S_UG_NOT_CREATE_USER_GROUP);
		vectorForNotification.add(UAMessageType.S_UG_NOT_REMOVE_USER_GROUP);
		LOGGER.debug("getInterestedNotifcations() exit");

		return vectorForNotification;
	}
	/**
	 * This method handles creation of users
	 * 
	 * @param p_UserData -
	 *         The user object to be created
	 * @param p_AssignedUserGroups -
	 *         Vector of user groups to which the user is assigned to
	 * @return boolean - True indicates the successful creation of the user
	 */
	public boolean sendRequestToCreateUser(
		UAUser p_UserData,
		List p_AssignedUserGroups) {
		LOGGER.debug("createUser() entry");

        UAJobCreateUser objCreateUser = new UAJobCreateUser(p_UserData, this, p_AssignedUserGroups);
		boolean bStatus = queueJob(objCreateUser);
		LOGGER.debug("createUser() exit");
		return bStatus;
	}

	/**
	 * This method sends a request to get all user groups
	 */
	public boolean sendRequestToGetAllUsergroups() {
		LOGGER.debug("sendRequestToGetAllUsergroups() in the job");
		UAJobGetAllUserGroup objJob = new UAJobGetAllUserGroup(this, false);
		boolean bStatus = queueJob(objJob);
		LOGGER.debug("sendRequestToGetAllUsergroups() exit");

		return bStatus;
	}

	/**
	 * Helper method called by the framework when a notification is received.
	 * Forwards to the appropriate method
	 * 
	 * @param pMsg Message encapsulating the notification
	 *
	 */
	@Override
    public void handleNotification(USMMessage pMsg) {
		LOGGER.debug("handleNotification() in the job");

		USMBaseMsgType type = pMsg.getMessageType();
		if (type.equals(UAMessageType.S_UG_NOT_CREATE_USER_GROUP)) {
			handleNotificationUserGroupCreated(pMsg);
		} else if (type.equals(UAMessageType.S_UG_NOT_REMOVE_USER_GROUP)) {
			handleNotificationUsergroupRemoved(pMsg);
		}
		LOGGER.debug("handleNotification() in the job");
	}

	/**
	 * Handles the notification for the user group removed operation
	 * 
	 * @param pMessage
	 *      the notification message
	 */
	private void handleNotificationUsergroupRemoved(USMMessage pMessage) {
		final String FUNC_NAME = "handleNotificationUsergroupRemoved() ";
		LOGGER.debug(FUNC_NAME + " ENTER_FUNCTION");

		if (pMessage == null) {
			LOGGER.warn(FUNC_NAME + "notification message is null");
		} else {
			UAUserGroup ugrp = new UAUserGroup();
			ugrp.popMe(pMessage);
            ((UACreateUserView) associatedView).onUserGroupRemoved(ugrp.getName());
		}
		LOGGER.debug(FUNC_NAME + " EXIT_FUNCTION");
	}

	/**
	 * Handles the notification for the user group created operation
	 * @param pMessage
	 *      the notification message
	 */
	private void handleNotificationUserGroupCreated(USMMessage pMessage) {
		final String FUNC_NAME = "handleNotificationUserGroupCreated( )";
		LOGGER.debug(FUNC_NAME + " ENTER_FUNCTION");

		if (pMessage == null) {
			LOGGER.warn(FUNC_NAME + "notification message is null");
		} else {
			UAUserGroup ugrp = new UAUserGroup();
			ugrp.popMe(pMessage);

            ((UACreateUserView) associatedView).onUserGroupCreated(ugrp.getName());

		}

		LOGGER.debug(FUNC_NAME + " EXIT_FUNCTION");

	}

	/**
	 * Helper method called by the framework when a response is received.
	 * Forwards to the appropriate method
	 * 
	 * @param pJob reference to the job which resulted in the original request
	 * @param result result of executing the given job
	 */
	@Override
    public void resultAvailable(USMJob pJob, USMMessage result) {
		LOGGER.debug(" resultAvailable() entry");

		USMBaseMsgType msgType = result.getMessageType();
		if (msgType.equals(UAMessageType.S_UA_RES_CREATE_USER)) {
			handleResponseForCreateUser(result);
		} else if (msgType.equals(UAMessageType.S_UG_RES_GET_ALL_USERGROUPS)) {
			handleResponseForGetAllAvailableUserGroups(result);
		} else if (msgType.equals(UAMessageType.S_UA_RES_GET_ALL_PASSWORD_VALIDATION_RULES)) {
            handleResponseForGetAllPasswordValidationRules(result);
        } else {
			LOGGER.error("Got a message which could not be handled");
		}
	}

    /**
     * Handles the response for the get all user groups operation
     * 
     * @param result contains the result of the operation
     */
    private void handleResponseForGetAllAvailableUserGroups(USMMessage result) {
        LOGGER.info("handleResponseForGetAllAvailableUserGroups() MESSAGE SIZE ");

        // Pop the Result of the Operation.
        UAStatus statusObject = new UAStatus();
        statusObject.popMe(result);

        if (statusObject.getStatus() == UAStatus.S_SUCCESS) {
            LOGGER.info("user groups fetched successfully ");
            List<String> availableUserGroups = new ArrayList<>();

            // Pop the Count of Available Menu options ( STRINGS )
            int nCount = result.popInteger();

            LOGGER.info("handleResponseForGetAllAvailableUserGroups()Number of Available user groups retreived from the Server : " + nCount);

            UAUserGroup userGroups = null;
            for (int idx = 0; idx < nCount; ++idx) {
                userGroups = new UAUserGroup();
                userGroups.popMe(result);
                String userGroupName = userGroups.getName();
                availableUserGroups.add(userGroupName);
            }

            getView().updateViewWithCreateUserResult(availableUserGroups);
        } else if (statusObject.getStatus() == UAStatus.S_INTERNAL_ERROR) {
            getView().showMessage(USMStringTable.getString(USMStringTable.IDS_UA_USER_CREATE_MODIFY_ERROR_FETCH_USERGROYPS));
            LOGGER.info(" handleResponseForGetAllAvailableUserGroups() Failed to Fetch All Available user groups from Server");
        }

        LOGGER.debug(" handleResponseForGetAllAvailableUserGroups() EXIT_FUNCTION");
	}

    /**
     * Handles the response for the get all user groups operation
     *
     * @param result
     *            contains the result of the operation
     */
    private void handleResponseForGetAllPasswordValidationRules(USMMessage result) {
        LOGGER.info("handleResponseForGetAllPasswordValidationRules() MESSAGE SIZE ");

        PasswordValidationRulesConfigurationData data = new PasswordValidationRulesConfigurationData();

        // Pop the Result of the Operation.
        UAStatus statusObject = new UAStatus();
        statusObject.popMe(result);

        if (statusObject.getStatus() == UAStatus.S_SUCCESS) {
            LOGGER.info("rules fetched successfully ");

            data.popMe(result);

            getView().updateViewWithPasswordValidationRulesResult(data.isPasswordMustNotHaveSpaces(), data.isPasswordMustBeDifferentFromName(),
                    data.isPasswordMustBeDifferentFromEmployeeNumber(), data.isPasswordMustBeDifferentFromDate());
        } else if (statusObject.getStatus() == UAStatus.S_INTERNAL_ERROR) {
            getView().showMessage(
                    USMStringTable.getString(USMStringTable.IDS_UA_USER_CREATE_MODIFY_ERROR_FETCH_PASSWORD_VALIDATION_RULES));
            LOGGER.info(" handleResponseForGetAllAvailableUserGroups() Failed to Fetch All Available rules from Server");
        }

        LOGGER.debug(" handleResponseForGetAllAvailableUserGroups() EXIT_FUNCTION");
    }
    
	private UACreateUserView getView() {
		return (UACreateUserView) associatedView;
	}

    /**
     * Sends a request to get all password validation rules. The objective is to enforce these rules
     * when creating/modifying a users password.
     *
     * @return boolean - True indicates the operation was completed
     *         successfully
     */
    public boolean sendReqToGetAllPasswordValidationRules() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("sendReqToGetAllPasswordValidationRules()	  Enter");
        }
        UAJobGetAllPasswordValidationRules objJobgetAllPasswordValidationRules =
                new UAJobGetAllPasswordValidationRules(this);
        boolean bStatus = queueJob(objJobgetAllPasswordValidationRules);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "sendReqToGetAllPasswordValidationRules()	  Exit - Return :" + bStatus);
        }
        return bStatus;

    }

	/**
	 * Handles the response for the create user operation
	 *
	 * @param pMessage contains the result of the operation
	 */
	private void handleResponseForCreateUser(USMMessage pMessage) {
		final String FUNC_NAME = "handleResponseForCreateUser()";
		LOGGER.debug("handleResponseForCreateUser() ENTER_FUNCTION");

        try {
            // Pop the Result of the Operation.
            UAStatus statusObject = new UAStatus();
            statusObject.popMe(pMessage);
            int nUAResult = statusObject.getStatus();

            GSStatus gsStatusObject = new GSStatus();
            int nGSResult = gsStatusObject.getStatus();

            if ((nUAResult == UAStatus.S_SUCCESS) && (nGSResult == GSStatus.S_SUCCESS)) {
                LOGGER.debug("handleResponseForCreateUser()  close create user window");
                associatedView.getFrame().closeFrame();
			} else {
				String csUserMessage = null;

                if (nUAResult == UAStatus.S_LDAP_ERROR) {
                    LOGGER.error(FUNC_NAME + "Server returned LDAP Error");
                    csUserMessage = USMStringTable.getString(USMStringTable.IDS_UA_LDAP_ERROR);

                } else if (nUAResult == UAStatus.S_USER_ALREADY_EXISTS) {
                    LOGGER.error(FUNC_NAME + "User with the same id already exist");
                    csUserMessage = USMStringTable.getString(USMStringTable.IDS_UA_USER_ALREADY_EXIST_MESSAGE);
                    
                } else if (nUAResult == UAStatus.S_USER_NAME_EMPTY_OR_INVALID) {
                    LOGGER.error(FUNC_NAME + "Usr name empty / invalid");
                    csUserMessage = USMStringTable.getString(USMStringTable.IDS_UA_USERID_MESSAGE);
                    
                } else if (nUAResult == UAStatus.USER_AND_PASSWORD_NOT_COMPLIANT_WITH_RULES) {
                    csUserMessage = USMStringTable.getString(USMStringTable.IDS_UA_USER_AND_PASSWORD_NOT_COMPLIANT_WITH_RULES);
                    LOGGER.error(FUNC_NAME + "User and Password not compliant with rules");
                    
                } else if (nUAResult == UAStatus.S_INTERNAL_ERROR) {
                    LOGGER.error(FUNC_NAME + "Server returned Internal Error");
                    csUserMessage = USMStringTable.getString(USMStringTable.IDS_UA_SERVER_RETURNED_ERROR);

                }

                if (csUserMessage != null) {
                    getView().showMessage(csUserMessage);
                }
            }

        } catch (Exception ex) {
            LOGGER.error("handleResponseForCreateUser()EXCEPTION: " + ex.getClass() + "Message : " + ex.getMessage());
        }

		LOGGER.debug("handleResponseForCreateUser() EXIT_FUNCTION");
	}
    /**
     * overriding the addjob method for showing the loading image
     */
    @Override
    public void addJob(USMJob job) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering the addJob. Adding Job : " + job);
        }

        if (null == job) {
            LOGGER.error("Job passed cannot be null.");
            return;
        }

        synchronized (jobs) {
            job.registerJobAddedToQueue();
            jobs.put(job.getID(), job);
        }

        // Since there is a Job it means that we have to wait for some response.
		if (associatedView != null) {
			associatedView.setWaitCursor();
		}
    }
    
    /**
     * Overriding the method endjob to remove the Loading screen
     */ 
    @Override
    public void endJob(USMJob job) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering the endJob. Adding Job : " + job);
        }

        if (null == job) {
            LOGGER.error("Job passed cannot be null.");
            return;
        }
        boolean bFlagSetNormalCursor = false;
        synchronized (jobs) {
            jobs.remove(job.getID());
            bFlagSetNormalCursor = (jobs.size() == 0);
        }

        if (bFlagSetNormalCursor) {
            // Now we have received all the responses for the requests. So we can remove the cursor.
            if (associatedView != null) {
                associatedView.setNormalCursor();
            }
        }
    }
}