package com.ossnms.bicnet.securitymanagement.client.domain.common;

import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableBase;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObjectContainer;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import javax.swing.tree.TreePath;

/**
 * Functional interface which centers functionality of a securable object tree
 */
interface ISecurableObjectTree {

    /**
     * Sets the tree model for this Tree
     * @param treeModel the {@link SecurableObjectTreeModel} instance
     */
    void setTreeModel(SecurableObjectTreeModel treeModel);

    /**
     * Fetches the underlying {@link SecurableObjectTreeModel}
     *
     * @return instance of {@link SecurableObjectTreeModel}
     */
    SecurableObjectTreeModel getTreeModel();

    /**
     * Fetches the currently applied filter to the this tree instance
     *
     * @return an instance of {@link SecurableObjectContainerFilterEnum}
     */
    SecurableObjectContainerFilterEnum getFilter();

    /**
     * Sets the {@link SecurableObjectContainerFilterEnum} filter to apply
     *
     * @param filter the filter to set
     */
    void setFilter(SecurableObjectContainerFilterEnum filter);

    /**
     *
     * @return
     */
    SecurableObjectFilterEnum getObjectFilter();

    /**
     *
     * @param objectFilter
     */
    void setObjectFilter(SecurableObjectFilterEnum objectFilter);

    /**
     * Returns the root node for this tree
     *
     * @return an instance of {@link SecurableObjectTreeNode} if the root node exists; null otherwise
     */
    default SecurableObjectTreeNode getRootNode(){
        if(getTreeModel() != null && getTreeModel().getRootNode() != null){
            return getTreeModel().getRootNode();
        }

        return null;
    }

    /**
     * Fetches the root node matching the specified common function type
     *
     * @param bicNetFunction the common function type
     *
     * @return an instance of {@link SecurableObjectTreeNode} if it exists, false otherwise
     */
    default SecurableObjectTreeNode getRootNode(BSTransBicNetCFInfo bicNetFunction){
        if (bicNetFunction == null || getRootNode() == null) {
            return null;
        }

        for(Enumeration children = getRootNode().children(); children.hasMoreElements();) {
            Object element = children.nextElement();
            if(!(element instanceof SecurableObjectTreeNode)){
                continue;
            }
            SecurableObjectTreeNode treeNode = (SecurableObjectTreeNode) element;
            if(bicNetFunction.equals(treeNode.getUserObject())){
                return treeNode;
            }
        }

        return null;
    }

    /**
     * Inserts (if it does not exist) the root node matching the specified Common Function info
     *
     * @param function the instance of {@link BSTransBicNetCFInfo} to create the root node
     *
     * @return the created {@link SecurableObjectTreeNode}
     */
    default SecurableObjectTreeNode insertRootNode(BSTransBicNetCFInfo function){
        // get the root node for the common function
        SecurableObjectTreeNode functionTreeNode = getRootNode(function);
        //The common function do not exist, create it
        if(functionTreeNode == null){
            functionTreeNode = new SecurableObjectTreeNode(function);
            insertNode(functionTreeNode, getRootNode());
        }
        // return the tree node
        return functionTreeNode;
    }

    /**
     * Deletes the root node matching the {@link BSTransBicNetCFInfo} instance specified
     *
     * @param function the common function data which identifies the root node
     */
    default void deleteRootNode(BSTransBicNetCFInfo function){
        SecurableObjectTreeNode serverNode = getRootNode(function);
        if (serverNode != null) {
            deleteNode(serverNode);
        }
    }

    /**
     * Inserts a generic node with the specified object (e.g. String)
     *
     * @param object the object to set into the generic tree node
     *
     * @param treeNode the parent tree node
     */
    default void insertGeneric(Object object, SecurableObjectTreeNode treeNode){
        insertNode(new SecurableObjectTreeNode(object), treeNode);
    }

    /**
     * Inserts the specified {@link BSSecurableObject} instance into the root node identified by the specified
     * {@link BSTransBicNetCFInfo} instance
     *
     * @param securableObject the Securable Object to insert
     * @param function the common function root node under which to insert the securable object
     */
    default List<SecurableObjectTreeNode> insertSecurableObject(BSSecurableObject securableObject, BSTransBicNetCFInfo function){
        List<SecurableObjectTreeNode> addedNodes = new ArrayList<>();
        List<BSSecurableObjectContainer> objContainers;

        if(!getObjectFilter().getObjectType().equals(securableObject.getManagedObjectType())){
            return addedNodes;
        }

        if(securableObject.getObjectContainers()==null || securableObject.getObjectContainers().isEmpty()){
            insertNodeIntoTree(securableObject, addedNodes, getRootNode(function));
        } else {
            // filter the containers
            objContainers = SecurableObjectContainerFilter.filterSecurableObjectContainer(
                    securableObject.getObjectContainers(),
                    getFilter()
            );

            if (objContainers != null && objContainers.size() > 0) {
                List<SecurableObjectTreeNode> parentTreeNodes = insertSecurableObjectContainers(objContainers, function);
                parentTreeNodes.forEach(parentNode -> insertNodeIntoTree(securableObject, addedNodes, parentNode));
            }
        }

        return addedNodes;
    }

    default void insertNodeIntoTree(BSSecurableObject securableObject, List<SecurableObjectTreeNode> addedNodes, SecurableObjectTreeNode cfTreeNode) {
        SecurableObjectTreeNode childTreeNode = new SecurableObjectTreeNode(securableObject);
        insertNode(childTreeNode, cfTreeNode);
        addedNodes.add(childTreeNode);
        reload(childTreeNode);
    }

    /**
     * Insert all the securable objects on the specified list under the specified common function
     *
     * @param securableObjects the list of {@link BSSecurableObject} to insert
     * @param cfInfo the {@link BSTransBicNetCFInfo} instance which identifies the root node under which the securable
     *               objects will be inserted
     * @return the list of the inserted {@link SecurableObjectTreeNode}
     */
    default List<SecurableObjectTreeNode> insertSecurableObjects(List<BSSecurableObject> securableObjects, BSTransBicNetCFInfo cfInfo){
        List<SecurableObjectTreeNode> addedNodes = new ArrayList<>();

        for (BSSecurableObject securableObject : securableObjects) {
            addedNodes.addAll(insertSecurableObject(securableObject, cfInfo));
        }

        return addedNodes;
    }

    /**
     * Inserts the {@link BSSecurableObjectContainer} instance under the specified {@link BSTransBicNetCFInfo}
     * instance
     *
     * @param securableObjectContainer the securable object container to insert
     * @param function the common function to identify the parent node
     */
    default List<SecurableObjectTreeNode> insertSecurableObjectContainer(BSSecurableObjectContainer securableObjectContainer, BSTransBicNetCFInfo function){
        List<SecurableObjectTreeNode> addedNodes = new ArrayList<>();
        // filter the containers
        List<BSSecurableObjectContainer> objContainers = securableObjectContainer.getObjectContainers();

        if(getRootNode(function) == null){
            insertRootNode(function);
        }

        if (objContainers != null && objContainers.size() > 0) {
            List<SecurableObjectTreeNode> parentTreeNodes = insertSecurableObjectContainers(objContainers, function);
            for (SecurableObjectTreeNode parentNode : parentTreeNodes) {
                SecurableObjectTreeNode treeNode = insertSecurableObjectContainer(securableObjectContainer, parentNode);
                addedNodes.add(treeNode);
            }
        } else {
            SecurableObjectTreeNode parentNode = getRootNode(function);
            SecurableObjectTreeNode treeNode = insertSecurableObjectContainer(securableObjectContainer, parentNode);
            addedNodes.add(treeNode);
        }

        return addedNodes;
    }

    /**
     * Inserts the {@link BSSecurableObjectContainer} instance under the specified {@link SecurableObjectTreeNode}
     * parent node
     *
     * @param securableObjectContainer the securable object container to insert
     * @param parentNode the parent node
     *
     * @return the securable object container node
     */
    default SecurableObjectTreeNode insertSecurableObjectContainer(BSSecurableObjectContainer securableObjectContainer, SecurableObjectTreeNode parentNode) {
        SecurableObjectTreeNode treeNode = getTreeNode(securableObjectContainer, parentNode);
        if(treeNode == null){
            treeNode = new SecurableObjectTreeNode(securableObjectContainer);
            insertNode(treeNode, parentNode);
        }
        return treeNode;
    }

    /**
     * Inserts the list of {@link BSSecurableObjectContainer} instances under the specified {@link BSTransBicNetCFInfo}
     * instance
     *
     * @param securableObjectContainers the securable object container to insert
     * @param function the common function to identify the parent node
     *
     * @return the list of added nodes
     */
    default List<SecurableObjectTreeNode> insertSecurableObjectContainers(List<BSSecurableObjectContainer> securableObjectContainers, BSTransBicNetCFInfo function){
        List<SecurableObjectTreeNode> addedNodes = new ArrayList<>();

        for (BSSecurableObjectContainer container : securableObjectContainers) {
            addedNodes.addAll(insertSecurableObjectContainer(container, function));
        }

        return addedNodes;
    }

    /**
     * Modifies the specified securable objects under the specified common function root node
     *
     * @param securableObjects the list of modified securable objects
     * @param function the common function under which the modification will be performed
     */
    default void modifySecurableObjects(List<BSSecurableObject> securableObjects, BSTransBicNetCFInfo function){
        if(securableObjects != null && securableObjects.size() > 0){
            deleteSecurableObjects(securableObjects, function);
            insertSecurableObjects(securableObjects, function);
        }
    }

    /**
     * Modifies the specified securable object container'a node, under the parent root node identified by the common
     * function.
     *
     * @param securableObjectContainer the securable object container
     * @param function the common function which identifies the root node
     */
    default void modifySecurableObjectContainer(BSSecurableObjectContainer securableObjectContainer, BSTransBicNetCFInfo function){
        SecurableObjectTreeNode containerTreeNode = getTreeNode(securableObjectContainer, getRootNode(function));

        if (containerTreeNode == null) {
            return;
        }

        // delete the node
        containerTreeNode.setUserObject(securableObjectContainer);
        deleteNode(containerTreeNode);

        // get securable object containers
        for(BSSecurableObjectContainer parentContainer : securableObjectContainer.getObjectContainers()){
            SecurableObjectTreeNode parentNode = getTreeNode(parentContainer, getRootNode(function));
            if(parentNode == null) {
                insertSecurableObjectContainer(parentContainer, function);
                parentNode = getTreeNode(parentContainer, getRootNode(function));
            }

            insertNode(containerTreeNode, parentNode);
        }
    }

    /**
     * Modifies the nodes identified by the list of securable object containers
     *
     * @param securableObjectContainers the list of modified securable object containers
     * @param function the securable object to identify the root node
     */
    default void modifySecurableObjectContainers(List<BSSecurableObjectContainer> securableObjectContainers, BSTransBicNetCFInfo function){
        SecurableObjectContainerFilter.filterSecurableObjectContainer(securableObjectContainers,getFilter())
                .stream()
                .forEach(container -> modifySecurableObjectContainer(container, function));
    }

    /**
     * Deletes the node identified by the securable obejct, under the specified {@link BSTransBicNetCFInfo}
     * root node
     *
     * @param securableObject the {@link BSSecurableObject} instance which identifies the node to delete
     * @param function the {@link BSTransBicNetCFInfo} instance which
     *
     * @return true if the node was successfully deleted, false otherwise.
     */
    default boolean deleteSecurableObject(BSSecurableObject securableObject, BSTransBicNetCFInfo function){
        List<SecurableObjectTreeNode> nodesToDelete = getTreeNodes(securableObject, getRootNode(function));

        nodesToDelete.forEach(this::deleteNode);

        return !nodesToDelete.isEmpty();
    }

    /**
     * Deletes the tree nodes identified by the specified securable objects
     *
     * @param securableObjects the list of securable object nodes to delete
     * @param function the common function identification of the root node
     */
    default void deleteSecurableObjects(List<BSSecurableObject> securableObjects, BSTransBicNetCFInfo function){
        for (BSSecurableObject securableObject : securableObjects) {
            deleteSecurableObject(securableObject, function);
        }
    }

    /**
     * Renames the node identified by the common function
     *
     * @param function the common function details
     */
    default void renameFunction(BSTransBicNetCFInfo function) {
        SecurableObjectTreeNode serverNode = getRootNode(function);
        if (serverNode != null) {
            serverNode.setUserObject(function);
            deleteNode(serverNode);
            insertNode(serverNode, serverNode);
        }
    }

    /**
     * Inserts the specified tree node under the specified parent node
     *
     * @param treeNode the tree node to insert
     * @param parentNode the parent tree node
     */
    default void insertNode(SecurableObjectTreeNode treeNode, SecurableObjectTreeNode parentNode){
        getTreeModel().insertNodeInto(treeNode, parentNode);
    }

    /**
     * Deletes the specified node
     *
     * @param childTreeNode the {@link SecurableObjectTreeNode} to delete
     */
    default void deleteNode(SecurableObjectTreeNode childTreeNode){
        SecurableObjectTreeNode parentNode = (SecurableObjectTreeNode) childTreeNode.getParent();

        // remove the node from the parent (which already notifies of the change)
        getTreeModel().removeNodeFromParent(childTreeNode);

        if (parentNode != null && parentNode.getChildCount() == 0 && !(parentNode.getUserObject() instanceof BSTransBicNetCFInfo)) {
            deleteNode(parentNode);
        }
    }

    /**
     * Fetches the tree node matching the specified object
     *
     * @param object the {@link SecurableObjectTreeNode} which identifies the nodes
     * @param rootNode the root node to look under
     *
     * @return the first matching tree node
     */
    default SecurableObjectTreeNode getTreeNode(Object object, SecurableObjectTreeNode rootNode){
        if (object == null || rootNode == null) {
            return null;
        }

        for (Enumeration enumeration = rootNode.breadthFirstEnumeration(); enumeration != null && enumeration.hasMoreElements();) {
            SecurableObjectTreeNode currNode = (SecurableObjectTreeNode) enumeration.nextElement();

            if (object.equals(currNode.getUserObject())) {
                return currNode;
            }
        }

        return null;
    }

    /**
     * Fetches the tree nodes matching the specified object
     *
     * @param object the object to find
     *
     * @return the list of matching {@link SecurableObjectTreeNode}
     */
    default List<SecurableObjectTreeNode> getTreeNodes(Object object, SecurableObjectTreeNode rootNode){
        if (object == null) {
            return new ArrayList<>();
        }

        List<SecurableObjectTreeNode> nodesToReturn = new ArrayList<>();
        for (Enumeration enumeration = rootNode.depthFirstEnumeration(); enumeration.hasMoreElements();) {
            SecurableObjectTreeNode treeNode = (SecurableObjectTreeNode) enumeration.nextElement();
            if (object.equals(treeNode.getUserObject())) {
                nodesToReturn.add(treeNode);
            }
        }
        return nodesToReturn;
    }

    /**
     * Reloads the tree under the root node
     */
    default void reload(){
        reload(getRootNode());
    }

    /**
     * Reloads the tree from the model.
     */
    default void reload(BSTransBicNetCFInfo serverInfo) {
        reload(getRootNode(serverInfo));
    }

    /**
     * Reloads the children of the specified root node
     *
     * @param treeNode the tree node which structure the tree is to reload
     */
    default void reload(SecurableObjectTreeNode treeNode){
        if(treeNode != null){
            getTreeModel().reload(treeNode);
        }
    }

    /**
     * Clears the tree under the root node
     */
    default void clear(){
        clear(getRootNode());
    }

    /**
     * Clears the root node identified by the {@link BSTransBicNetCFInfo} instance
     * @param function the common function node identifier
     */
    default void clear(BSTransBicNetCFInfo function){
        clear(getRootNode(function));
    }

    /**
     * Clears the children of the specified tree node
     *
     * @param treeNode the tree node to clear
     */
    default void clear(SecurableObjectTreeNode treeNode){
        if(treeNode != null){
            treeNode.removeAllChildren();
        }
    }

    /**
     * Fetches the tree paths under the root node
     *
     * @return the list of matching {@link TreePath}
     */
    default List<TreePath> getTreePaths() {
        List<TreePath> paths = new ArrayList<>();
        paths.addAll(getTreePath(getRootNode()));
        return paths;
    }

    /**
     * Returns the tree path given the node
     *
     * @param treeNode the tree node to search
     *
     * @return the list of matching {@link TreePath}
     */
    default List<TreePath> getTreePath(SecurableObjectTreeNode treeNode){
        List<TreePath> paths = new ArrayList<>();

        paths.add(new TreePath(treeNode.getPath()));
        for (int i = 0; i < treeNode.getChildCount(); i++) {
            paths.addAll(getTreePath((SecurableObjectTreeNode) treeNode.getChildAt(i)));
        }

        return paths;
    }

    /**
     * Finds the node paths that match the BSSecurableBase object (Object or ObjectContainer), under the specified tree
     * node
     *
     * @param securableObject the securable base to look for
     * @param treeNode the tree node to look under
     *
     * @return the list of found tree paths
     */
    default List<TreePath> findNodePath(BSSecurableBase securableObject, SecurableObjectTreeNode treeNode){
        List<TreePath> results = new ArrayList<>();

        if (treeNode.getUserObject() instanceof BSSecurableObject && treeNode.getUserObject().equals(securableObject)) {
            results.add(new TreePath(treeNode.getPath()));
        } else if(treeNode.getUserObject() instanceof BSSecurableObjectContainer && treeNode.getUserObject().equals(securableObject)){
            results.add(new TreePath(treeNode.getPath()));
        }else {
            for (int i = 0; i < treeNode.getChildCount(); i++) {
                results.addAll(findNodePath(securableObject,(SecurableObjectTreeNode) treeNode.getChildAt(i)));
            }
        }

        return results;
    }

    /**
     *
     * @param neList the list of BSSecurableObjects to update
     */
    @SuppressWarnings("unchecked")
    default void updateNeUserObjects(List<?> neList) {
        List<SecurableObjectTreeNode> nodesChanged = new ArrayList<>();
        for (Enumeration<SecurableObjectTreeNode> enumeration = getRootNode().breadthFirstEnumeration(); enumeration.hasMoreElements(); ) {
            SecurableObjectTreeNode treeNode = enumeration.nextElement();
            for (Object ne : neList) {
                if (ne != null && ne.equals(treeNode.getUserObject())) {
                    nodesChanged.add(treeNode);
                    break;
                }
            }
        }

        for (SecurableObjectTreeNode treeNode : nodesChanged) {
            getTreeModel().nodeChanged(treeNode);
        }
    }

    ServerTypeFilterEnum getServerTypeFilter();

    void setServerTypeFilter(ServerTypeFilterEnum serverType);
}
