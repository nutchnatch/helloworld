/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name 	UAUsergroupDataHolder
 * Author:      Vinay Purohit
 * Substitute	Babu B
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER.VIEW
 *       : TNMS.DX2.SM.USER.CREATE
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.useradministration.usercreate;

import javax.swing.*;

public class UAUserGroupDataHolder {

	/*
	 * Model for Users Available to be assigned to the user group 
	 */
	private DefaultListModel<String> mdlAvailableUsergroups = null;

	/*
	 * Model for Users Assigned to the user group 
	 */
	private DefaultListModel<String> mdlAssignedUsergroups = null;

	/**
	 * constructor 
	 */
	public UAUserGroupDataHolder() {
		mdlAvailableUsergroups = new DefaultListModel<>();
		mdlAssignedUsergroups = new DefaultListModel<>();
	}

	/**
	 * Retrieve the model for the Assigned Users List
	 * 
	 * @return DefaultListModel
	 */
	public DefaultListModel<String> getAssignedUsersList() {
		return mdlAssignedUsergroups;
	}

	/**
	 * Retrieve the model for the Available Users List
	 * 
	 * @return DefaultListModel
	 */
	public DefaultListModel<String> getAvailableUsersList() {
		return mdlAvailableUsergroups;
	}

}
