package com.ossnms.bicnet.securitymanagement.client.common;

import com.ossnms.tools.jfx.components.JfxTextField;

/**
 * An JfxTextField which trims the resulting strings when getting text
 */
public class USMTextField extends JfxTextField {

    @Override
    public String getText(){
        return super.getText().trim();
    }
}
