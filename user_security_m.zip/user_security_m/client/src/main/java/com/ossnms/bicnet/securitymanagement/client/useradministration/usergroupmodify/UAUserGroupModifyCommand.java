/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   UAUserGroupModifyCommand
 * Author:      Jogender
 * Substitute	Babu B
 * Created on	12-09-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER_GROUP.CONFIGURE 
 *       : TNMS.DX2.SM.USER_GROUP.ASSIGN 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration.usergroupmodify;

import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserGroup;
import org.apache.log4j.Logger;

/**
 * Concrete class for the Command of the User Group Modification View. This
 * Command is registered with the UI and is responsible to display the User
 * Group Modification view
 */
public class UAUserGroupModifyCommand extends USMCommand {
	private UAUserGroup userGroup;
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(UAUserGroupModifyCommand.class);

	/**
	 * Default constructor 
	 */
	public UAUserGroupModifyCommand() {
		super(USMCommandID.S_UI_ID_MODIFY_USERGROUP);
	}

	/**
	 * THis class returns the view associated with the controller
	 * 
	 * @return USMBaseView - The User Group Modification View
	 */
	@Override
    protected USMBaseView createAndReturnView() {
		return new UAUserGroupModifyView(userGroup);
	}

	/**
	 * Function to compare a Command handler with this Object. The passed object
	 * also is a Command Handler.
	 * 
	 * @param cmd
	 *            The Command handler which should be compared to this object.
	 * 
	 * @return boolean The result of the comparision. Return true, if the 2
	 *         commands are the same, else return false
	 */
	@Override
    public boolean compare(USMCommand cmd) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering compare. Command being passed is : " + cmd);
		}

		boolean bOp = false;

		UAUserGroupModifyCommand pCmdModifyUG =
			(UAUserGroupModifyCommand) cmd;
		UAUserGroup retrievedUG = pCmdModifyUG.userGroup;
		if (retrievedUG.equals(userGroup)) {
			bOp = true;
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting compare. Result of compare is : " + bOp);
		}
		return bOp;
	}

	/**
	 * Returns a cloned instance of command handler object on which the
	 * method is invoked.
	 * 
	 * @param selList
	 *      Selection on which the command is executed
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#cloneCmd(java.lang.Object)
	 */
	@Override
    public USMCommand cloneCmd(Object selList) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("cloneCmd(" + selList + ")	Entered");
		}
		UAUserGroupModifyCommand ugCmdForView = new UAUserGroupModifyCommand();
		ugCmdForView.userGroup = (UAUserGroup) selList;
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"cloneCmd("
					+ selList
					+ ")		Exit : Return"
					+ ugCmdForView);
		}
		return ugCmdForView;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#getKey()
	 */
	@Override
    public Object getKey() {
		return userGroup;
	}
}