package com.ossnms.bicnet.securitymanagement.client.settings.radius.job;

import com.ossnms.bicnet.framework.client.helpers.FrameworkFetchJob;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDocument;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.general.radius.status.RadiusServerStatus;
import com.ossnms.bicnet.securitymanagement.common.general.radius.status.RadiusTestConfigurationData;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityGeneralSettingPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.servicelocator.USMServiceLocator;
import org.apache.log4j.Logger;

/**
 * Job which handles the execution of the test with asserts the status of the RADIUS Server
 */
public class RadiusServerStatusJob extends FrameworkFetchJob {

    private static final Logger LOGGER = Logger.getLogger(RadiusServerStatusJob.class);

    private static final String ID = "securitymanagement.client.settings.radius.job.RadiusServerStatusJob";
    private static final String NAME = "RadiusServerStatusJob";
    private static final String ADDITIONAL_INFO = "Job to send data to server";

    private RadiusTestConfigurationData configurationData;

    /**
     * Constructor to initialize the member variables
     *
     * @param document the document to control
     * @param configurationData
     */
    public RadiusServerStatusJob(IFrameworkDocument document, RadiusTestConfigurationData configurationData) {
        super(ID, NAME, ADDITIONAL_INFO, document);
        this.configurationData = configurationData;
    }

    @Override
    public Object execute(Object data) throws FrameworkException {
        RadiusServerStatus result = null;
        try {
            ISecurityGeneralSettingPrivateFacade fcd = USMServiceLocator.getInstance().getSecurityGeneralSettingsPrivateFacade();
            result = fcd.testRadiusServer(USMUtility.getInstance().getSessionContext(), configurationData);
        } catch (Exception e) {
            LOGGER.error("Error testing RADIUS Server", e);
        }

        return result;
    }
}
