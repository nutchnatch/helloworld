/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCDeleteDomainJob
 * Author      	Muyeen Munaver
 * Substitute	Asifullakhan
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CREATE
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain.job;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.domain.DCBusinessDelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import org.apache.log4j.Logger;

/**
 * This class represents a job that is responsible for the domain creation
 * operation
 */
public class DCCreateDomainJob extends USMJob {
	/**
	 * This represents the domain data
	 */
	DCDomainData mDomain = null;

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(DCCreateDomainJob.class);

	/**
	 * This is the constructor
	 * 
	 * @param pId The type of message
	 * @param pJobOwner The controller associated with the job
	 * @param pDomain Domain data
	 */
	public DCCreateDomainJob(
			USMBaseMsgType pId,
			USMControllerIfc pJobOwner,
			DCDomainData pDomain) {
		super(pId, USMCommonStrings.EMPTY, USMCommonStrings.EMPTY, pJobOwner);

		Object[] arr = { pDomain };
		String str = USMStringTable.IDS_DC_JOB_CREATE_DOMAIN.getFormatedMessage(arr);
		setName(str);

		LOGGER.debug("DCCreateDomainJob() - Entry");
		mDomain = pDomain;
		LOGGER.debug("DCCreateDomainJob() - Exit");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob#executeJob()
	 */
	@Override
    public USMMessage executeJob() throws BcbSecurityException {

		LOGGER.debug("executeJob() - Entry");

		DCBusinessDelegate delegate = new DCBusinessDelegate();
		USMMessage msg = delegate.createDomain(mDomain);
		LOGGER.debug("executeJob() - Exit");
		return msg;

	}

}
