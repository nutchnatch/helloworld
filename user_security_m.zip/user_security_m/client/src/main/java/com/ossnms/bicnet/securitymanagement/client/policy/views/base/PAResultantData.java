package com.ossnms.bicnet.securitymanagement.client.policy.views.base;


/**
 * This class holds the resultant data for the UICreatWdw. User subsystems get the selection of the
 * available and the assigned data in this data structure.
 */
public class PAResultantData {

	/**
	 * The name associated with this data structure
	 */
	private String name;
	/**
	 * The associated description.
	 */
	private String description;

	/**
	 * Constructor
	 * @param name  The name of the data.
	 * @param description  The user description.
	 */
	public PAResultantData(
		String name,
		String description) {
		this.name = name;
		this.description = description;
	}

	/**
	 * This method is used to get the name associated with the resultant data.
	 * @return java.lang.String  Returns the name associated with the resultant data.
	 */
	public final String getName() {
		return name;
	}

	/**
	 * This method gets the user description of the resultant data.
	 * @return java.lang.String  Returns the user description of the resultant data.
	 */
	public final String getDescr() {
		return description;
	}

}
