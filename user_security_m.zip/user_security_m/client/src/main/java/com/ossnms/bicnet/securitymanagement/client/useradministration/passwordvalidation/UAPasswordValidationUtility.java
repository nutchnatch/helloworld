package com.ossnms.bicnet.securitymanagement.client.useradministration.passwordvalidation;

import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.common.auth.PasswordValidationRulesConfigurationData;
import com.ossnms.bicnet.util.validator.PasswordValidator;
import com.ossnms.bicnet.util.validator.ValidatorResult;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable.ENUM_LABEL_PASSWORD_MUST_BE_DIFFERENT_FROM_DATE;
import static com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable.ENUM_LABEL_PASSWORD_MUST_BE_DIFFERENT_FROM_EMPLOYEE_NUMBER;
import static com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable.ENUM_LABEL_PASSWORD_MUST_BE_DIFFERENT_FROM_FIRST_NAME;
import static com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable.ENUM_LABEL_PASSWORD_MUST_BE_DIFFERENT_FROM_LAST_NAME;
import static com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable.ENUM_LABEL_PASSWORD_MUST_NOT_HAVE_SPACES;
import static com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable.ENUM_LABEL_SUCCESS;

/**
 *
 */
public final class UAPasswordValidationUtility {


    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(UAPasswordValidationUtility.class);
    private static final String SPACE_CHAR = " ";
    private static final String EMPTY_STRING = "";
    private static final int DATE_DAY_BEGIN_INDEX = 0;
    private static final int DATE_DAY_END_INDEX = 2;
    private static final int DATE_MONTH_BEGIN_INDEX = 3;
    private static final int DATE_MONTH_END_INDEX = 5;
    private static final int DATE_YEAR_BEGIN_INDEX = 6;
    private static final int DATE_YEAR_END_INDEX = 10;
    private static final int DATE_MONTH_FIRST_DIGIT_BEGIN_INDEX = 0;
    private static final int DATE_MONTH_FIRST_DIGIT_END_INDEX = 1;
    private static final int DATE_MONTH_SECOND_DIGIT_BEGIN_INDEX = 1;
    private static final int DATE_MONTH_SECOND_DIGIT_END_INDEX = 2;
    private static final int DATE_YEAR_FIRST_TWO_DIGITS_BEGIN_INDEX = 0;
    private static final int DATE_YEAR_LAST_TWO_DIGITS_BEGIN_INDEX = 2;
    private static final int DATE_YEAR_FIRST_TWO_DIGITS_END_INDEX = 2;
    private static final int DATE_YEAR_LAST_TWO_DIGITS_END_INDEX = 4;
    private static final String PASSWORD_VALIDATION_RESULT = "Password validation result: ";

    /**
     * Utility class constructor
     */
    private UAPasswordValidationUtility(){
    }

    /**
     * This method will validate the parameters against both the configurable and the mandatory rules.
     *
     * @param params All relevant parameters for validation.
     * @param rules Set of active and inactive rules.
     * @return String indicating the status of the validation.
     */
    public static String validateNewPasswordFieldAndShowWarning(UAPasswordValidationParams params, PasswordValidationRulesConfigurationData rules){

        PasswordValidationResult res = validatePassword(params, rules);
        boolean selectedValidations = res.equals(PasswordValidationResult.SUCCESS);

        if(selectedValidations){
            String oldPassword = params.getOldPassword() != null && params.getOldPassword().length() > 0?params.getOldPassword():null;
            ValidatorResult result = PasswordValidator.validate(params.getUserName().trim(), oldPassword, params.getNewPassword());
            if(!params.getNewPassword().isEmpty() && !result.isValid()){
                LOGGER.debug(PASSWORD_VALIDATION_RESULT + result.getLocalizedErrorMessage());
                return result.getLocalizedErrorMessage();
            }
        }

        LOGGER.debug(PASSWORD_VALIDATION_RESULT + res.getLabel());
        return res.getLabel();
    }

    /**
     * This method will validate the parameters against both the configurable and the mandatory rules when the user must
     * change his password.
     *
     * @param params All relevant parameters for validation.
     * @param rules Set of active and inactive rules.
     * @return String indicating success or the detail of the error.
     */
    public static String validateWithOldPassword(UAPasswordValidationParams params, PasswordValidationRulesConfigurationData rules){

        PasswordValidationResult res = validatePassword(params, rules);
        boolean selectedValidations = res.equals(PasswordValidationResult.SUCCESS);

        if(selectedValidations){
            ValidatorResult passwordValidator = PasswordValidator.validate(params.getUserName(), params.getOldPassword(), params.getNewPassword(), params.getConfirmNewPassword());
            if (!passwordValidator.isValid()) {
                LOGGER.debug(PASSWORD_VALIDATION_RESULT + passwordValidator.getLocalizedErrorMessage());
                return passwordValidator.getLocalizedErrorMessage();
            }
        }
        LOGGER.debug(PASSWORD_VALIDATION_RESULT + res.getLabel());
        return res.getLabel();

    }

    /**
     * This method will validate the parameters against both the configurable and the mandatory rules when user is
     * created of modified by the administrator.
     *
     * @param params All relevant parameters for validation.
     * @param rules Set of active and inactive rules.
     * @return String indicating success or the detail of the error.
     */
    public static String validateWithNoOldPassword(UAPasswordValidationParams params, PasswordValidationRulesConfigurationData rules){
        PasswordValidationResult res = validatePassword(params, rules);
        boolean selectedValidations = res.equals(PasswordValidationResult.SUCCESS);


        if(selectedValidations){
            ValidatorResult passwordValidator = PasswordValidator.validate(params.getUserName(), null, params.getNewPassword(), params.getConfirmNewPassword());
            if (!passwordValidator.isValid()) {
                LOGGER.debug(PASSWORD_VALIDATION_RESULT + passwordValidator.getLocalizedErrorMessage());
                return passwordValidator.getLocalizedErrorMessage();
            }
        }
        LOGGER.debug(PASSWORD_VALIDATION_RESULT + res.getLabel());
        return res.getLabel();
    }

    /**
     * This method will validate the parameters against both the configurable rules.
     *
     * @param params All relevant parameters for validation.
     * @param rules Set of active and inactive rules.
     * @return PasswordValidationResult object indicating the status of the validation.
     */
    private static PasswordValidationResult validatePassword(UAPasswordValidationParams params, PasswordValidationRulesConfigurationData rules){
        String newPassword = params.getNewPassword();

        if(rules.isPasswordMustNotHaveSpaces() && !validateSpacesRule(newPassword)){
            return PasswordValidationResult.SPACES_RULE_VIOLATED;
        }

        if(rules.isPasswordMustBeDifferentFromDate() && !validateDateRule(params.getCurrentDate(), newPassword)){
            return PasswordValidationResult.DATE_RULE_VIOLATED;
        }

        PasswordValidationResult result = validatePasswordAgainstUserParameters(params, rules, newPassword);

        return result != null ? result : PasswordValidationResult.SUCCESS;

    }

    /**
     *
     * @param params
     * @param rules
     * @param newPassword
     * @return
     */
    private static PasswordValidationResult validatePasswordAgainstUserParameters(UAPasswordValidationParams params, PasswordValidationRulesConfigurationData rules, String newPassword) {
        if(rules.isPasswordMustBeDifferentFromEmployeeNumber() && !validateEmployeeNumberRule(newPassword, params.getEmployeeId())){
            return PasswordValidationResult.EMPLOYEE_NUMBER_RULE_VIOLATED;
        }

        if(rules.isPasswordMustBeDifferentFromName() && !validateNameRule(newPassword, params.getLastName())){
            return PasswordValidationResult.LAST_NAME_RULE_VIOLATED;
        }

        if(rules.isPasswordMustBeDifferentFromName() && !validateNameRule(newPassword, params.getFirstName())){
            return PasswordValidationResult.FIRST_NAME_RULE_VIOLATED;
        }
        return null;
    }

    /**
     * This method will validate the password against the rule "Passwords must not contain spaces".
     *
     * @param password password to be validated.
     * @return Boolean indicating the status of the validation.
     */
    private static boolean validateSpacesRule(String password){

        return !password.contains(SPACE_CHAR);

    }

    /**
     * This method will validate the password against the rule "Passwords must not contain the current date".
     *
     * @param password password to be validated.
     * @return Boolean indicating the status of the validation.
     */
    private static boolean validateDateRule(String dateString, String password){

        SimpleDateFormat startFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        SimpleDateFormat finalFormat = new SimpleDateFormat("MMM");
        Date parsedDate = null;
        String monthExt = EMPTY_STRING;

        try {
            parsedDate = startFormat.parse(dateString);
        } catch (ParseException e) {
            LOGGER.error("(validateDateRule) Error parsing date string");
        }

        if(parsedDate != null) {
            monthExt = finalFormat.format(parsedDate);
        }

        String day = dateString.substring(DATE_DAY_BEGIN_INDEX, DATE_DAY_END_INDEX);
        String month = dateString.substring(DATE_MONTH_BEGIN_INDEX, DATE_MONTH_END_INDEX);
        String year = dateString.substring(DATE_YEAR_BEGIN_INDEX, DATE_YEAR_END_INDEX);
        String firstNumberOfMonth = month.substring(DATE_MONTH_FIRST_DIGIT_BEGIN_INDEX, DATE_MONTH_FIRST_DIGIT_END_INDEX);
        String secondNumberOfMonth = month.substring(DATE_MONTH_SECOND_DIGIT_BEGIN_INDEX, DATE_MONTH_SECOND_DIGIT_END_INDEX);
        String firstTwoDigitsOfTheYear = year.substring(DATE_YEAR_FIRST_TWO_DIGITS_BEGIN_INDEX, DATE_YEAR_FIRST_TWO_DIGITS_END_INDEX);
        String lastTwoDigitsOfTheYear = year.substring(DATE_YEAR_LAST_TWO_DIGITS_BEGIN_INDEX, DATE_YEAR_LAST_TWO_DIGITS_END_INDEX);

        List<String> patternList = new ArrayList<>();

        patternList.add(MessageFormat.format(".*({0}[/-_]?{1}?{2}[/-_]?({3})?{4}).*", day, firstNumberOfMonth, secondNumberOfMonth, firstTwoDigitsOfTheYear, lastTwoDigitsOfTheYear));
        patternList.add(MessageFormat.format(".*({0}?{1}[/-_]?{2}[/-_]?({3})?{4}).*", firstNumberOfMonth, secondNumberOfMonth, day, firstTwoDigitsOfTheYear, lastTwoDigitsOfTheYear));
        patternList.add(MessageFormat.format(".*(({0})?{1}[/-_]?{2}?{3}[/-_]?{4}).*", firstTwoDigitsOfTheYear, lastTwoDigitsOfTheYear, firstNumberOfMonth, secondNumberOfMonth, day));
        patternList.add(MessageFormat.format(".*({0}[/-_]?{1}[/-_]?({2})?{3}).*", day, monthExt, firstTwoDigitsOfTheYear, lastTwoDigitsOfTheYear));
        patternList.add(MessageFormat.format(".*({0}[/-_]?{1}[/-_]?({2})?{3}).*", monthExt, day, firstTwoDigitsOfTheYear, lastTwoDigitsOfTheYear));
        patternList.add(MessageFormat.format(".*(({0})?{1}[/-_]?{2}[/-_]?{3}).*", firstTwoDigitsOfTheYear, lastTwoDigitsOfTheYear, monthExt, day));

        for (String patternString : patternList){
            Pattern pattern = Pattern.compile(patternString);
            Matcher matcher = pattern.matcher(password.toLowerCase());

            if(matcher.matches()){
                return false;
            }
        }

        return true;
    }

    /**
     * This method will validate the password against the rule "Passwords must not contain the Employee Number".
     *
     * @param password password to be validated.
     * @return Boolean indicating the status of the validation.
     */
    private static boolean validateEmployeeNumberRule(String password, String employeeId){

        return !(!employeeId.equals(EMPTY_STRING) && password.toUpperCase().contains(employeeId.toUpperCase()));

    }

    /**
     * This method will validate the password against the rule "Passwords must not contain the name".
     *
     * @param password password to be validated.
     * @return Boolean indicating the status of the validation.
     */
    private static boolean validateNameRule(String password, String name){

        return !(!name.equals(EMPTY_STRING) && password.toUpperCase().contains(name.toUpperCase()));

    }

    /**
     * Enumerate to indicate the status of the validation of the rules.
     */
    public enum PasswordValidationResult {

        SUCCESS(USMStringTable.getString(ENUM_LABEL_SUCCESS)),
        SPACES_RULE_VIOLATED(USMStringTable.getString(ENUM_LABEL_PASSWORD_MUST_NOT_HAVE_SPACES)),
        DATE_RULE_VIOLATED(USMStringTable.getString(ENUM_LABEL_PASSWORD_MUST_BE_DIFFERENT_FROM_DATE)),
        EMPLOYEE_NUMBER_RULE_VIOLATED(USMStringTable.getString(ENUM_LABEL_PASSWORD_MUST_BE_DIFFERENT_FROM_EMPLOYEE_NUMBER)),
        LAST_NAME_RULE_VIOLATED(USMStringTable.getString(ENUM_LABEL_PASSWORD_MUST_BE_DIFFERENT_FROM_LAST_NAME)),
        FIRST_NAME_RULE_VIOLATED(USMStringTable.getString(ENUM_LABEL_PASSWORD_MUST_BE_DIFFERENT_FROM_FIRST_NAME));

        private String label;

        PasswordValidationResult(String label) {
            this.label = label;
        }

        public String getLabel() {
            return this.label;
        }
    }

}
