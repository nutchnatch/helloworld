package com.ossnms.bicnet.securitymanagement.client.auth;

public class ReloginData {
	private String activeServer;
	private String user;
	private String password;
	private String standbyServer;
	private final boolean sso;

	public String getActiveServer() {
		return activeServer;
	}

	public void setActiveServer(String activeServer) {
		this.activeServer = activeServer;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isSso() {
		return sso;
	}

	public String getStandbyServer() {
		return standbyServer;
	}

	public void setStandbyServer(String standbyServer) {
		this.standbyServer = standbyServer;
	}

	public ReloginData(String activeServer, String user, String password, boolean sso, String standbyServer) {
		super();
		this.activeServer = activeServer;
		this.user = user;
		this.password = password;
		this.sso = sso;
		this.standbyServer = standbyServer;
	}

}
