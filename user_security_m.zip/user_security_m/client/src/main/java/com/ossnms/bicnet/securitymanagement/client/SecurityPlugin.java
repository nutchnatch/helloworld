package com.ossnms.bicnet.securitymanagement.client;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ILogonListener;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkableId;
import com.ossnms.bicnet.bcb.model.ManagedObjectType;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.ComponentVersionInformation;
import com.ossnms.bicnet.bcb.model.licensing.LicenseStatus;
import com.ossnms.bicnet.bcb.model.topoMgmt.INetworkViewId;
import com.ossnms.bicnet.bcb.plugin.BiCNetPlugin;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginAction;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginActionType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginImportExportItem;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginMainContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginMapEventType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPage;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSettings;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginStatusIndicator;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginWizardStep;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.bicnet.securitymanagement.client.auth.AAClientCache;
import com.ossnms.bicnet.securitymanagement.client.auth.AALoginBusinessDelegate;
import com.ossnms.bicnet.securitymanagement.client.auth.AAServerSessionTimer;
import com.ossnms.bicnet.securitymanagement.client.auth.AAUserProfileCache;
import com.ossnms.bicnet.securitymanagement.client.auth.AuthClientLifeCycleController;
import com.ossnms.bicnet.securitymanagement.client.auth.ReloginController;
import com.ossnms.bicnet.securitymanagement.client.basic.USMBasicClientLifeCycleController;
import com.ossnms.bicnet.securitymanagement.client.basic.USMBasicSAP;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEvtRegistrar;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.client.bicnetserver.BSClientLifeCycleController;
import com.ossnms.bicnet.securitymanagement.client.domain.DCClientLifeCycleController;
import com.ossnms.bicnet.securitymanagement.client.importexport.IEDefaultImportExportItem;
import com.ossnms.bicnet.securitymanagement.client.policy.PAClientLifeCycleController;
import com.ossnms.bicnet.securitymanagement.client.useradministration.UAClientLifeCycleController;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMenuNameList;
import com.ossnms.bicnet.securitymanagement.common.basic.USMTimeTracer;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.bicnet.securitymanagement.common.general.radius.configuration.RadiusConfigurationData;
import com.ossnms.bicnet.securitymanagement.server.servicelocator.USMCallStyleProperties;
import com.ossnms.bicnet.securitymanagement.server.servicelocator.USMServiceLocator;
import com.ossnms.bicnet.servicelocator.BiCNetServiceLocator;
import com.ossnms.bicnet.util.ApplicationProperties;
import com.ossnms.bicnet.util.versions.ClientComponentVersionInfo;
import com.ossnms.tnms.securitymanagement.client.settings.SecuritySettingsMainPropertyPage;
import com.ossnms.tnms.securitymanagement.client.settings.SecuritySettingsManager;
import com.ossnms.tools.jfx.JfxText;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * BiCNet compliant security management plugin class.
 */
public class SecurityPlugin implements BiCNetPlugin, IPluginSecurityProvider {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(SecurityPlugin.class);

    /**
     * This object will be initialized on successful logon for authorization
     * checks on client.
     */
    private ISecureClientSession clientSession = null;

    /**
     * Session to token for specific client
     */
    private IEnhancedSessionContext context = null;

    /**
     * List of listener registered for successful logon
     */
    private List<ILogonListener> logonListeners = new ArrayList<>();

    private boolean loggedInWithSSO = false;

    /* Export Settings */
    private static final String IDS_DEFAULT_PASSWORD_EXPIRATION = "sm.set.sso.default.password.expiration";
    private static final String IDS_SESSION_TIMEOUT = "sm.set.sso.session.timeout";
    private static final String IDS_EXPIRE_PASSWORD_WARNING = "sm.set.sso.expire.password.warning";
    private static final String IDS_INACTIVITY_TIMEOUT_WARNING = "sm.set.sso.inactivity.timeout.warning";
    private static final String IDS_MAX_LOGIN_ATTEMPTS = "sm.set.sso.maximum.login.attempts";
    private static final String IDS_USER_ACCOUNT_DEACTIVATION = "sm.set.sso.user.account.deactivation";
    private static final String IDS_ADMIN_REACTIVATION_TIME = "sm.set.sso.administrator.reactivation.time";
    private static final String IDS_GENERAL_SETTINGS = "sm.set.sso.general.settings";
    private static final String IDS_SSO_ENABLE = "sm.set.sso.enable";
    private static final String IDS_DOMAIN_NAME = "sm.set.sso.domain.name";
    private static final String IDS_DOMAIN_NAME_SERVER = "sm.set.sso.domain.name.server";
    private static final String IDS_LDAP_PORT = "sm.set.sso.ldap.port";
    private static final String IDS_SSO = "sm.set.sso";
    private static final String IDS_DISPLAY_ADVISORY_MSG = "sm.set.sso.display.advisory.message";
    private static final String IDS_ADVISORY_MSG_TEXT = "sm.set.sso.advisory.message.text";
    private static final String IDS_ADVISORY_MSG = "sm.set.sso.advisory.message";

    private static final String IDS_LDAP_AUTH = "sm.set.ldap.auth";
    private static final String IDS_LDAP_AUTH_ENABLE = "sm.set.ldap.auth.enable";
    private static final String IDS_LDAP_AUTH_HOSTNAME = "sm.set.ldap.auth.hostname";
    private static final String IDS_LDAP_AUTH_PORT = "sm.set.ldap.auth.port";
    private static final String IDS_LDAP_AUTH_SSL_INDICATOR = "sm.set.ldap.auth.ssl.indicator";    
    private static final String IDS_LDAP_AUTH_SEARCH_ACCOUNT = "sm.set.ldap.auth.search.account";

    private static final String IDS_LDAP_AUTH_USER_SEARCH_BASE = "sm.set.ldap.auth.user.search.base";
    private static final String IDS_LDAP_AUTH_USER_SEARCH_FILTER = "sm.set.ldap.auth.user.search.filter";
    private static final String IDS_LDAP_AUTH_USER_SEARCH_SCOPE = "sm.set.ldap.auth.user.search.scope";    
    private static final String IDS_LDAP_AUTH_USER_ID_ATTRIBUTE = "sm.set.ldap.auth.user.id.attribute";
    private static final String IDS_LDAP_AUTH_GROUP_SEARCH_BASE = "sm.set.ldap.auth.group.search.base";
    private static final String IDS_LDAP_AUTH_GROUP_SEARCH_FILTER = "sm.set.ldap.auth.group.search.filter";
    private static final String IDS_LDAP_AUTH_GROUP_SEARCH_SCOPE = "sm.set.ldap.auth.group.search.scope";
    private static final String IDS_LDAP_AUTH_GROUP_ID_ATTRIBUTE = "sm.set.ldap.auth.group.id.attribute";    
    private static final String IDS_LDAP_AUTH_GROUP_ATTRIBUTE_ID_USER = "sm.set.ldap.auth.group.attribute.id.user";

    private static final String IDS_PASSWORD_VALIDATION = "sm.set.password.validation";
    private static final String IDS_PASSWORD_VALIDATION_NAME = "sm.set.password.validation.name";
    private static final String IDS_PASSWORD_VALIDATION_DATE = "sm.set.password.validation.date";
    private static final String IDS_PASSWORD_VALIDATION_EMPLOYEE_NUMBER = "sm.set.password.validation.employee_number";
    private static final String IDS_PASSWORD_VALIDATION_SPACES = "sm.set.password.validation.spaces";

    private static final String IDS_RADIUS_AUTHENTICATION = "sm.set.radius";
    private static final String IDS_RADIUS_AUTHENTICATION_TIMEOUT = IDS_RADIUS_AUTHENTICATION + ".timeout";
    private static final String IDS_RADIUS_AUTHENTICATION_RETRIES = IDS_RADIUS_AUTHENTICATION + ".retries";
    private static final String IDS_RADIUS_AUTHENTICATION_USER_GROUP = IDS_RADIUS_AUTHENTICATION + ".user.group.attribute";
    private static final String IDS_RADIUS_AUTHENTICATION_SERVER_HOSTNAME = IDS_RADIUS_AUTHENTICATION + ".server.hostname";
    private static final String IDS_RADIUS_AUTHENTICATION_SERVER_PORT = IDS_RADIUS_AUTHENTICATION + ".server.port";
    private static final String IDS_RADIUS_AUTHENTICATION_SERVER_SECRET = IDS_RADIUS_AUTHENTICATION + ".server.secret";
    private static final String IDS_RADIUS_AUTHENTICATION_ALT_SERVER_HOSTNAME = IDS_RADIUS_AUTHENTICATION + ".alt.server.hostname";
    private static final String IDS_RADIUS_AUTHENTICATION_ALT_SERVER_PORT = IDS_RADIUS_AUTHENTICATION + ".alt.server.port";
    private static final String IDS_RADIUS_AUTHENTICATION_ALT_SERVER_SECRET = IDS_RADIUS_AUTHENTICATION + ".alt.server.secret";


    /**
     * Constructs the plugin.
     */
    public SecurityPlugin() {
        LOGGER.debug("SecurityPlugin()Constructor Entry & Exit");
    }

    /**
     * Returns the plug-in's ID. The ID should be unique and stable for longer
     * time. It is recommended to use the base package name of the plug-in.
     * Other plug-ins may detect this plug-in using the ID.
     *
     * @return ID string (e.g. "com.ossnms.bicnet.securitymanagement").
     */
    @Override
    public String getID() {
        LOGGER.debug("getID() Entry & Exit");

        return "com.ossnms.bicnet.securitymanagement";
    }

    /**
     * Returns the plugin's name. The name should give a short statement about
     * the plug-in's task.
     *
     * @return Name string (e.g. "Fault Management").
     */
    @Override
    public String getName() {
        LOGGER.debug("getName() Entry & Exit");
        return "Security Management";
    }

    /**
     * Returns the plugin's description. The description should give a longer
     * statement about the plug-in's task.
     *
     * @return Description string (e.g. "Provides alarm list and log, filtering,
     * sorting").
     */
    @Override
    public String getDescription() {
        LOGGER.debug("getDescription() Entry & Exit");
        return "Provides logon and user administration";
    }

    /**
     * Sets the site interface of the application loading the plug-in. This is
     * the first method called after the plug-in class instance has been
     * created. The plug-in should store the given site reference for later use.
     *
     * @param site Reference to plug-in site.
     */
    @Override
    public void setSite(BiCNetPluginSite site) {
        LOGGER.debug("setSite(BiCNetPluginSite site) Entry & Exit");
        USMUtility.getInstance().setSecuritySite(site);
    }

    /**
     * Initializes the plug-in. This method is called after the plug-in class
     * instance has been created and the setSite() and setParameters() methods
     * have been called.
     *
     * @throws BiCNetPluginException If the plug-in can not initialize properly. The calling
     *                               application should release all references to the plug-in and
     *                               display an error.
     */
    @Override
    public void init() throws BiCNetPluginException {
        LOGGER.debug("init() Entry ");

        // Register the Service Locator
        BiCNetServiceLocator bcbsl = BiCNetServiceLocator.getInstance();
        USMServiceLocator secMgmtServiceLocator = USMServiceLocator.getInstance();
        bcbsl.registerServiceLocator(BiCNetComponentType.SECURITY_MANAGER, secMgmtServiceLocator);

        ApplicationProperties appProp = USMCallStyleProperties.getInstance();
        String strSwitch = appProp.getProperty("securityManager.SecurityCheckDisabled");
        LOGGER.info("Value of securityManager.SecurityCheckDisabled is : " + strSwitch);

        Boolean bVal = Boolean.FALSE;
        try {
            bVal = Boolean.valueOf(strSwitch);
        } catch (Exception ex) {
            LOGGER.error("Value for securityManager.SecurityCheckDisabled is junk. Setting it to false");
        }

        boolean bSecurityChkDisabled = bVal;
        USMCommonHelper.setSecurityDisabledState(bSecurityChkDisabled);

        if (!bSecurityChkDisabled) {
            USMBasicClientLifeCycleController.getInstance().initialize();
            BSClientLifeCycleController.getInstance().initialize();
            DCClientLifeCycleController.getInstance().initialize();
            PAClientLifeCycleController.getInstance().initialize();
            AuthClientLifeCycleController.getInstance().initialize();
            UAClientLifeCycleController.getInstance().initialize();

            SecurityInactivityClientCtl.getInstance().initialize();
            SecuritySettingsManager.getInstance().initialize();
        }
        
        ReloginController.getInstance().init();

        LOGGER.debug("init()			Exit ");
    }

    /**
     * Destroys the plug-in. This method is called before the application shuts
     * down. The plug-in should release all outgoing references and shutdown.
     */
    @Override
    public void destroy() {
        LOGGER.debug("destroy()		Entry ");
        ReloginController.getInstance().destroy();
        this.logonListeners.clear();
        LOGGER.debug("destroy()			Exit ");
    }

    /**
     * Queries the plug-in for available actions for the main menu or toolbar.
     *
     * @param eContext Context for which actions are queried.
     * @return Array of actions for context.
     */
    @Override
    public BiCNetPluginAction[] getMainActions(BiCNetPluginMainContext eContext) {
        LOGGER.debug("getMainActions(BiCNetPluginMainContext eContext) Entry ");
        boolean bSecurityDisabled = USMCommonHelper.isSecurityCheckDisabled();

        if ((eContext == BiCNetPluginMainContext.FILE) && (!bSecurityDisabled)) {
            return USMBasicSAP.getFileMainActions();
        }
        if ((eContext == BiCNetPluginMainContext.ADMINISTRATION) && (!bSecurityDisabled)) {
            return USMBasicSAP.getMainActions();
        }
        LOGGER.debug("getMainActions(BiCNetPluginMainContext eContext) Exit ");
        return null;
    }

    //[TO REMOVE]
//    /**
//     * Queries the plug-in for available actions for the context menu of managed
//     * objects.
//     *
//     * @param arObjects   Array of objects for which actions are queried.
//     * @param environment Environment of objects (Example: Network View in case of NE
//     *                    objects), may be null.
//     * @return Array of actions for context.
//     */
//    public BiCNetPluginAction[] getObjectActions(ManagedObjectIdItem[] arObjects, ManagedObjectIdItem environment) {
//        LOGGER.debug("getObjectActions(ManagedObjectIdItem[] arObjects, ManagedObjectIdItem environment) Entry & ExitEntry ");
//        return null;
//    }

    /**
     * Queries the plug-in for available property pages to be displayed in the
     * context of the Client Frame (e.g. "General Settings").
     *
     * @param eContext Context for which property pages are queried.
     * @return Array of property pages for context.
     */
    @Override
    public BiCNetPluginPropertyPage[] getMainPropertyPages(BiCNetPluginMainContext eContext) {
        LOGGER.debug("getMainPropertyPages(BiCNetPluginMainContext eContext) Entry");
        BiCNetPluginPropertyPage[] pages = null;

        boolean hasPermission =
                USMUtility.getInstance().checkIfOperatorHasPermission(
                        USMCommandID.S_UI_ID_GENERAL_SECURITY_SETTINGS.getMenuString());

        // User Preferences application window
        if (BiCNetPluginMainContext.ADMINISTRATION.equals(eContext) && hasPermission) {
            pages = new BiCNetPluginPropertyPage[1];
            pages[0] = new SecuritySettingsMainPropertyPage();
        }
        LOGGER.debug("getMainPropertyPages(BiCNetPluginMainContext eContext) Exit");
        return pages;
    }

    //[TO REMOVE]
//    /**
//     * Queries the plug-in for available property pages to be displayed in the
//     * context of managed objects (e.g. "Log Properties").
//     *
//     * @param arObjects   Array of objects for which actions are queried.
//     * @param environment Environment of objects (Example: Network View in case of NE
//     *                    objects), may be null.
//     * @return Array of property pages for context.
//     */
//    public BiCNetPluginPropertyPage[] getObjectPropertyPages(ManagedObjectIdItem[] arObjects, ManagedObjectIdItem environment) {
//        LOGGER.debug("getObjectPropertyPages(ManagedObjectIdItem[] arObjects, ManagedObjectIdItem environment) Entry & Exit");
//
//        return null;
//    }

    /**
     * Queries the plug-in for available wizard steps to be displayed in another
     * component's wizard
     *
     * @return Array of wizard steps
     */
    @Override
    public BiCNetPluginWizardStep[] getObjectWizardSteps(ManagedObjectType managedObjectType) {
        return null;
    }

    /**
     * Queries the plug-in for available status indicators. Indicators are tiny
     * components that are integrated in the status bar of the client frame.
     *
     * @return Array of status indicators.
     */
    @Override
    public BiCNetPluginStatusIndicator[] getStatusIndicators() {
        LOGGER.debug("getStatusIndicators() Entry & Exit ");

        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BiCNetPluginImportExportItem getImportExportItems(Element arg0) {
        LOGGER.debug("getImportExportItems(Element arg0) Entry ");

        boolean bSecurityDisabled = USMCommonHelper.isSecurityCheckDisabled();

        if (!bSecurityDisabled) {

            IEDefaultImportExportItem parent = new IEDefaultImportExportItem(new JfxText(this.getName()), true, true);
            parent.addChildImportExportItems(USMBasicSAP.getImportExportItems(arg0));
            return parent;
        }
        LOGGER.debug("getImportExportItems(Element arg0) Exit ");
        return null;
    }

    /**
     * Queries the plug-in for available version info items. The plug-in should
     * provide a complete list of all its Client and Server components and their
     * exact versions.
     *
     * @return Array of version info items.
     */
    @Override
    public ComponentVersionInformation[] getVersionInfoItems() {
        LOGGER.debug("getVersionInfoItems() Entry & Exit");
        return ClientComponentVersionInfo.getVersionInfo(getClass());
    }

    /**
     * Returns an object implementing the interface ISecureClientSession. The
     * object is used to perform security related tasks as -authorization -user
     * profile management -security logging -querving log-in information
     *
     * @param sessionContext The context of the session
     * @return Implementation of the ISecureClientSession interface
     * @throws BiCNetPluginException if user is not logged on.
     */
    @Override
    public ISecureClientSession getClientSession(ISessionContext sessionContext) throws BiCNetPluginException {
        LOGGER.debug("getClientSession(ISessionContext sessionContext) Entry ");

        if (this.context != null && this.context != sessionContext) {
            throw new BiCNetPluginException("Failed to get Client Session!");
        }
        LOGGER.debug("getClientSession(ISessionContext sessionContext) Exit ");
        return this.clientSession;
    }

    /**
     * Returns the IsessionContext .
     *
     * @return ISessionContext - Session token for the user.
     */
    public ISessionContext getSessionContext() {
        return this.context;
    }

    /**
     * Authenticates the user and returns an object implementing the interface
     * ISessionContext. The security plug-in may show a logon dialog. After
     * successful log-in, all registered logon listeners are notified.
     *
     * @return object implementing the interface ISecureClientSession or null if
     * user decided to cancel the login dialog.
     * @throws BiCNetPluginException if login fails.
     */
    @Override
    public ISecureClientSession logon() throws BiCNetPluginException {
        LOGGER.debug("logon()		Entry ");

        // Opening logon window
        SecurityLogonView view = new SecurityLogonView(this);
        BiCNetPluginFrame frame = USMUtility.getInstance().getSecuritySite().createFrame(view, BiCNetPluginFrameType.MODAL);
        view.setFocus();
        frame.showFrame();

        LOGGER.debug("logon()		Exit");
        return this.clientSession;
    }

    /**
     * Returns whether the user is currently logged on to a server.
     *
     * @param clientSession The client session object to be tested
     * @return boolean True if logged in.
     */
    @Override
    public boolean isLoggedOn(ISecureClientSession clientSession) {
        LOGGER.debug("isLoggedOn(ISecureClientSession clientSession) Entry & Exit");
        return (this.clientSession != null && this.clientSession == clientSession);
    }

    /**
     * Logs the user out of the server. This method may be called either on
     * request of the user (the caller should already have shown a logoff
     * dialog) or on connection loss on any RMI or JMS connection. After
     * successful log-off all registered logon listeners are notified.
     *
     * @throws BiCNetPluginException if logoff fails.
     */
    private void logoff() throws BiCNetPluginException {
        LOGGER.debug("logoff()		Entry ");

        boolean bSecurityDisabled = USMCommonHelper.isSecurityCheckDisabled();

        this.fireUserLogginOff(this.context);
        SwingUtilities.invokeLater(() -> {

            String oldServerId = this.clientSession.getServerId();

            if (!bSecurityDisabled) {

                AALoginBusinessDelegate logonDelegate = new AALoginBusinessDelegate();
                logonDelegate.logoff(this.context);

                // Fault ID- 9 -NullPointerException in Authentication on Policy Deleted (both server and client)
                AAServerSessionTimer objServerSessionTimer = AAServerSessionTimer.getInstance();
                objServerSessionTimer.cancelTimer();
                this.fireUserLoggedOff(this.context);
                this.clientSession = null;
                this.context = null;

                // Clear the client authorization cache
                AAClientCache objClientCache = AAClientCache.getInstance();
                objClientCache.clearCache();

                USMServiceLocator serviceLocator = USMServiceLocator.getInstance();
                serviceLocator.invalidateRemoteHomeCache();

            } else {
                this.fireUserLoggedOff(this.context);
                this.clientSession = null;
                this.context = null;
            }

            invalidateServiceLocator();

            ReloginController.getInstance().loggedOff(oldServerId);
        });
        LOGGER.debug("logoff()		Exit ");
    }

    @Override
    public void logoff(ISecureClientSession clientSession, LogoffReason logoffReason) throws BiCNetPluginException {
        USMUtility.getInstance().setLogoffReason(logoffReason != null ? logoffReason : LogoffReason.NORMAL_LOGOFF);
        logoff();
    }

	private void invalidateServiceLocator() {
		try {
        	BiCNetServiceLocator.getInstance().invalidateConfig();
        } catch (BcbException e) {
        	LOGGER.error("Unable to invalidate Service Locator.", e);
        }
	}

    /**
     * Adds a logon listener to the list. Using this method the Client Frame as
     * well as other plug-ins can be informed when the user logs on or off. The
     * Client Frame will always be the first listener.
     *
     * @param listener Logon listener.
     */
    @Override
    public void addLogonListener(ILogonListener listener) {
        LOGGER.debug("addLogonListener(ILogonListener listener) Entry ");
        this.logonListeners.add(listener);
        LOGGER.debug("addLogonListener(ILogonListener listener) Exit ");
    }

    /**
     * Removes a logon listener from the list. When the plug-in is destroyed,
     * all remaining listeners are automatically removed.
     *
     * @param listener Logon listener.
     */
    @Override
    public void removeLogonListener(ILogonListener listener) {
        LOGGER.debug("removeLogonListener(ILogonListener listener) Entry ");
        this.logonListeners.remove(listener);
        LOGGER.debug("removeLogonListener(ILogonListener listener) Exit ");
    }

    @Override
    public void reportActivity(ISessionContext sessionContext, long timestamp) {
        LOGGER.info("Report activity was called. Timestamp: {}", timestamp);
        SecurityInactivityClientCtl.getInstance().reportActivity(timestamp);
    }

    /**
     * Notifies all plugins about a logon event.
     *
     * @param context Logon context.
     */
    public void fireUserLoggedOn(ISessionContext context) {
        LOGGER.debug("fireUserLoggedOn(ISessionContext context) Entry ");

        USMUtility.getInstance().operatorLoggedOn(context);
        for (ILogonListener listener : logonListeners) {
            try {
                listener.onUserLoggedOn(context);
            } catch (Exception e) {
                LOGGER.error("Error calling logon listener", e);
            }
        }
        USMLogonLogoffEvtRegistrar.getInstance().onUserLoggedOn(context);
        LOGGER.debug("fireUserLoggedOn(ISessionContext context)		Exit ");
    }

    /**
     * Notifies all plugins that a logoff is about to happen, so that if they
     * need, they can save their profiles.
     *
     * @param context Logon context.
     */
    protected void fireUserLogginOff(ISessionContext context) {
        LOGGER.debug("fireUserLogginOff(ISessionContext context,String strAdditionalInfo)     Entry ");

        for (ILogonListener listener : logonListeners) {
            try {
                listener.onUserLoggingOff(context);
            } catch (Exception e) {
                LOGGER.error("Error calling logging off listener", e);
            }
        }

        USMLogonLogoffEvtRegistrar.getInstance().onUserLoggingOff(context);
        LOGGER.debug("fireUserLogginOff(ISessionContext context,String strAdditionalInfo)     Exit ");
    }

    /**
     * Notifies all plugins about a logoff event.
     *
     * @param context Logon context.
     */
    protected void fireUserLoggedOff(ISessionContext context) {
        LOGGER.debug("fireUserLoggedOff(ISessionContext context)      Entry ");
        this.logonListeners.stream().filter(listener -> listener != null).forEach(listener -> {
            try {
                listener.onUserLoggedOff(context);
            } catch (Exception e) {
                LOGGER.error("Error calling logoff listener", e);
            }
        });
        USMLogonLogoffEvtRegistrar.getInstance().onUserLoggedOff(context);
        LOGGER.debug("fireUserLoggedOff(ISessionContext context,String strAdditionalInfo)     Exit ");
    }

    /**
     * Notifies all plugins about a Permissions changed event.
     */
    public void fireUserPermissionsChanged() {
        LOGGER.debug("fireUserLoggedOn(ISessionContext context)      Entry ");
        for (ILogonListener listener : this.logonListeners) {
            try {
                listener.onUserPermissionsChanged(this.context);
            } catch (Exception ex) {
                LOGGER.error("Exception raised : " + listener, ex);
            }
        }

        LOGGER.debug("fireUserLoggedOn(ISessionContext context)      Exit ");
    }

    /**
     * Client session implementation.
     */
    public class SessionHandler implements ISecureClientSession {

        public SessionHandler() {
            LOGGER.info("Inside the constructor of SessionHandler");
        }

        /**
         * Returns the session context associated with the active logon. This
         * context is to be passed as first parameter in server calls to
         * authorize the method on the server side.
         *
         * @return Session context implementation.
         */
        @Override
        public ISessionContext getSessionContext() {
            return SecurityPlugin.this.context;
        }

        /**
         * Provides the ID of the server or cluster the client has a session
         * with.
         *
         * @return ID string (Name or address).
         */
        @Override
        public String getServerId() {
            return SecurityPlugin.this.context.getServerName().split(":")[0];
        }

        /**
         * Provides the host and port of the server or cluster the client has a
         * session with.
         *
         * @return Server with Port string (<host>:<port>).
         */
        @Override
        public String getServerAndPort() {
            return SecurityPlugin.this.context.getServerName();
        }

        /**
         * Provides the user name of the user currently logged in.
         *
         * @return User name string.
         */
        @Override
        public String getUserName() {
            return SecurityPlugin.this.context.getUserName();

        }

        /**
         * Checks whether the current user is allowed to use the given
         * operation.
         *
         * @param strOperation The name of the operation to be analyzed
         * @return false, if the operation is not permitted true, otherwise
         */
        @Override
        public boolean checkOperationPermission(String strOperation) {
            if (LOGGER.isInfoEnabled()) {
                LOGGER.info("SessionHandler : checkOperationPermission . : " + strOperation);
            }

            USMTimeTracer timeTracker = new USMTimeTracer();
            timeTracker.registerExecuteJobStarted();

            AAClientCache objClientCache = AAClientCache.getInstance();
            boolean result = objClientCache.checkOperationPermission(strOperation);

            timeTracker.registerExecuteJobComplete();
            if (LOGGER.isInfoEnabled()) {
                LOGGER.info("Time taken to checkOperationPermission taking a string as parameter is " + timeTracker.getTimeForServerProcessing());
                LOGGER.info("SessionHandler : checkOperationPermission . : " + strOperation + " Result : " + result);

            }

            return result;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public IManagedObjectId[] checkObjectPermission(IManagedObjectId[] arDesiredObjects) {
            if (LOGGER.isInfoEnabled()) {
                String strObjects = USMCommonHelper.getStringForArrayOfIManagedObjectId(arDesiredObjects);
                LOGGER.info("SessionHandler : checkObjectPermission . : " + strObjects);
            }

            AAClientCache objClientCache = AAClientCache.getInstance();
            IManagedObjectId[] arrPassedObjects = objClientCache.checkObjectPermission(arDesiredObjects);

            if (LOGGER.isInfoEnabled()) {
                String strPassedObjects = USMCommonHelper.getStringForArrayOfIManagedObjectId(arrPassedObjects);
                LOGGER.info("SessionHandler : checkObjectPermission . Passed Objects : " + strPassedObjects);
            }
            return arrPassedObjects;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public IManagedObjectId[] checkOperationPermission(String strOperation, IManagedObjectId[] arDesiredObjects) {
            if (LOGGER.isInfoEnabled()) {
                String strObjects = USMCommonHelper.getStringForArrayOfIManagedObjectId(arDesiredObjects);
                LOGGER.info("SessionHandler : checkOperationPermission . strOperation : " + strOperation + " Objects : " + strObjects);
            }

            AAClientCache objClientCache = AAClientCache.getInstance();

            IManagedObjectId[] arrPassedObjects = objClientCache.checkObjectPermission(strOperation, arDesiredObjects);
            if (LOGGER.isInfoEnabled()) {
                String strPassedObjects = USMCommonHelper.getStringForArrayOfIManagedObjectId(arrPassedObjects);
                LOGGER.info("SessionHandler : checkOperationPermission . strOperation : " + strOperation + " Passed Objects : " + strPassedObjects);
            }
            return arrPassedObjects;
        }

        @Override
        public IManagedObjectId[] filterVisibleObjects(IManagedObjectMarkableId... criteria) {
            LOGGER.info("SessionHandler : (Entering) filterVisibleObjects.");

            IManagedObjectId[] visibleObjects = AAClientCache.getInstance().filterVisibleObjects(criteria);

            LOGGER.info("SessionHandler : (Exiting) filterVisibleObjects.");
            return visibleObjects;
        }

        @Override
        public IManagedObjectId[] filterAccessibleObjects(IManagedObjectMarkableId... criteria) {
            LOGGER.info("SessionHandler : (Entering) filterAccessibleObjects.");

            IManagedObjectId[] arrPassedObjects = AAClientCache.getInstance().filterAccessibleObjects(criteria, null);

            LOGGER.info("SessionHandler : (Exiting) filterAccessibleObjects.");

            return arrPassedObjects;
        }

        @Override
        public IManagedObjectId[] filterAccessibleObjects(String operation, IManagedObjectMarkableId... criteria) {
            LOGGER.info("SessionHandler : (Entering) filterAccessibleObjects.");

            IManagedObjectId[] arrPassedObjects = AAClientCache.getInstance().filterAccessibleObjects(criteria, operation);

            LOGGER.info("SessionHandler : (Exiting) filterAccessibleObjects.");
            return arrPassedObjects;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public void setUserProfile(String applicationUUId, Properties profile) {
            AAUserProfileCache.getInstance().setProfile(applicationUUId, profile);
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public Properties getUserProfile(String applicationUUId) {
            return AAUserProfileCache.getInstance().getProfile(applicationUUId);
        }

        /**
         * Provides a unique identifier for the current client /session/ that
         * allows to distinguish this session from any other client session even
         * on the same host
         */
        @Override
        public String getClientSessionId() {
            return "" + SecurityPlugin.this.context.getUniqId();
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public void removeUserProfile(String arg0) {
            AAUserProfileCache.getInstance().removeUserProfile(arg0);
        }
    }

    /**
     * Dummy class which will always return true for all checks
     */
    public class DummySessionHandler implements ISecureClientSession {

        public DummySessionHandler() {
            LOGGER.info("Inside the constructor of DummySessionHandler");
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public boolean checkOperationPermission(String strOperation) {
            LOGGER.info("DummySessionHandler : checkOperationPermission . strOperation : " + strOperation);
            return true;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public IManagedObjectId[] checkObjectPermission(IManagedObjectId[] arDesiredObjects) {
            String strObjects = USMCommonHelper.getStringForArrayOfIManagedObjectId(arDesiredObjects);
            LOGGER.info("DummySessionHandler : checkObjectPermission . : " + strObjects);

            return arDesiredObjects;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public IManagedObjectId[] checkOperationPermission(String strOperation, IManagedObjectId[] arDesiredObjects) {
            String strObjects = USMCommonHelper.getStringForArrayOfIManagedObjectId(arDesiredObjects);
            LOGGER.info("DummySessionHandler : checkOperationPermission . strOperation : " + strOperation + " Objects : " + strObjects);
            return arDesiredObjects;
        }

        @Override
        public IManagedObjectId[] filterVisibleObjects(IManagedObjectMarkableId... criteria) {
            return new IManagedObjectId[0];
        }

        @Override
        public IManagedObjectId[] filterAccessibleObjects(IManagedObjectMarkableId... criteria) {
            return new IManagedObjectId[0];
        }

        @Override
        public IManagedObjectId[] filterAccessibleObjects(String operation, IManagedObjectMarkableId... criteria) {
            return new IManagedObjectId[0];
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public void setUserProfile(String applicationUUId, Properties profile) {
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public Properties getUserProfile(String applicationUUId) {
            return new Properties();
        }

        /**
         * Provides a unique identifier for the current client /session/ that
         * allows to distinguish this session from any other client session even on the same host
         */
        @Override
        public String getClientSessionId() {
            return "" + SecurityPlugin.this.context.getUniqId();
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public ISessionContext getSessionContext() {
            return SecurityPlugin.this.context;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public String getServerId() {
            return SecurityPlugin.this.context.getServerName().split(":")[0];
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public String getServerAndPort() {
            return SecurityPlugin.this.context.getServerName();
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public String getUserName() {
            return SecurityPlugin.this.context.getUserName();
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public void removeUserProfile(String arg0) {
        }
    }

    //[TO REMOVE] UNUSED
//    /**
//     * User profile implementation.
//     */
//    private static class ProfileHandler {
//        private final String uUId;
//
//        public ProfileHandler(String strUUId) {
//            this.uUId = strUUId;
//        }
//
//        public final String getUUId() {
//            return this.uUId;
//        }
//    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BiCNetPluginAction[] getObjectActions(IManagedObject[] arObjects, IManagedObject environment, String strEnvironment) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BiCNetPluginPropertyPage[] getObjectPropertyPages(IManagedObject[] arObjects, IManagedObject environment, String strEnvironment) {
        return null;
    }

    /**
     * Method Description
     *
     * @return ISessionContext
     */
    public ISessionContext getContext() {
        return this.context;
    }

    /**
     * @param session secure client session
     */
    public void setSession(ISecureClientSession session) {
        this.clientSession = session;
    }

    /**
     * @param context session context implementation
     */
    public void setContext(IEnhancedSessionContext context) {
        this.context = context;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BiCNetPluginAction[] getHighlightActions(IManagedObject[] arg0, IManagedObject arg1, String arg2) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyUnhighlight(INetworkViewId arg0) {

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyMapEvent(INetworkViewId arg0, BiCNetPluginMapEventType arg1) {
    }

    public void setLoggedInWithSSO(boolean flag) {
        loggedInWithSSO = flag;
    }

    /**
     * Indicates whether the current user is logged in using SSO.
     *
     * @return true when user logged in with SSO, otherwise false.
     */
    public boolean isLoggedInWithSSO() {
        return loggedInWithSSO;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public BiCNetPluginAction[] getObjectTypeActions(ManagedObjectType arg0, BiCNetPluginActionType arg1) {
        return null;
    }

    /**
     *
     * @return
     */
    @Override
    public BiCNetPluginSettings getPluginSettings() {
        if (!USMUtility.getInstance().checkIfOperatorHasPermission(USMMenuNameList.OPERATION_SECURITY__EXPORT_SETTINGS)) {
            LOGGER.debug("Export USM plugin settings::Permission denied.");
            return null;
        }

        GSGeneralSettingData savedSettings = SecuritySettingsManager.getInstance().getGeneralSettingsData();
        BiCNetPluginSettings settings = new BiCNetPluginSettings(this.getName());

        settings.addChild(getBiCNetPluginSettings(savedSettings));

        if (savedSettings.getSSOConfigurationData() != null) {
            settings.addChild(getSSOSettings(savedSettings));
        }

        if (savedSettings.getLdapConfigurationData() != null) {
        	settings.addChild(getLDAPSettings(savedSettings));
        }

        if (savedSettings.getPasswordValidationRulesConfigurationData() != null) {
            settings.addChild(getPasswordValidationSettings(savedSettings));
        }

        if (savedSettings.getRadiusConfigurationData() != null) {
            settings.addChild(getRadiusAuthenticationSettings(savedSettings));
        }

        settings.addChild(getAdvisorySettings(savedSettings));

        return settings;
    }

    /**
     *
     * @param savedSettings
     * @return
     */
    private BiCNetPluginSettings getAdvisorySettings(GSGeneralSettingData savedSettings) {
        BiCNetPluginSettings childSettings = new BiCNetPluginSettings(IDS_ADVISORY_MSG);

        childSettings.addProperty(IDS_DISPLAY_ADVISORY_MSG, Boolean.toString(savedSettings.isShowAdvisoryMessage()));
        childSettings.addProperty(IDS_ADVISORY_MSG_TEXT, savedSettings.getAdvisoryMessage());

        return childSettings;
    }

    /**
     *
     * @param savedSettings
     * @return
     */
    private BiCNetPluginSettings getRadiusAuthenticationSettings(GSGeneralSettingData savedSettings) {
        BiCNetPluginSettings childSettings = new BiCNetPluginSettings(IDS_RADIUS_AUTHENTICATION);

        RadiusConfigurationData radiusData = savedSettings.getRadiusConfigurationData();

        childSettings.addProperty(IDS_RADIUS_AUTHENTICATION_TIMEOUT,            String.valueOf(radiusData.getTimeout()));
        childSettings.addProperty(IDS_RADIUS_AUTHENTICATION_RETRIES,            String.valueOf(radiusData.getRetries()));
        childSettings.addProperty(IDS_RADIUS_AUTHENTICATION_USER_GROUP,         radiusData.getUserGroupAttribute().name());
        childSettings.addProperty(IDS_RADIUS_AUTHENTICATION_SERVER_HOSTNAME,    radiusData.getServerHostname());
        childSettings.addProperty(IDS_RADIUS_AUTHENTICATION_SERVER_PORT,        String.valueOf(radiusData.getServerPort()));
        childSettings.addProperty(IDS_RADIUS_AUTHENTICATION_SERVER_SECRET,      radiusData.getServerSharedSecret());
        childSettings.addProperty(IDS_RADIUS_AUTHENTICATION_ALT_SERVER_HOSTNAME,radiusData.getAltServerHostname());
        childSettings.addProperty(IDS_RADIUS_AUTHENTICATION_ALT_SERVER_PORT,    String.valueOf(radiusData.getAltServerPort()));
        childSettings.addProperty(IDS_RADIUS_AUTHENTICATION_ALT_SERVER_SECRET,  radiusData.getAltServerSharedSecret());

        return childSettings;
    }

    /**
     *
     * @param savedSettings
     * @return
     */
    private BiCNetPluginSettings getPasswordValidationSettings(GSGeneralSettingData savedSettings) {
        BiCNetPluginSettings childSettings = new BiCNetPluginSettings(IDS_PASSWORD_VALIDATION);

        childSettings.addProperty(IDS_PASSWORD_VALIDATION_DATE, String.valueOf(savedSettings.getPasswordValidationRulesConfigurationData().isPasswordMustBeDifferentFromDate()));
        childSettings.addProperty(IDS_PASSWORD_VALIDATION_EMPLOYEE_NUMBER, String.valueOf(savedSettings.getPasswordValidationRulesConfigurationData().isPasswordMustBeDifferentFromEmployeeNumber()));
        childSettings.addProperty(IDS_PASSWORD_VALIDATION_SPACES, String.valueOf(savedSettings.getPasswordValidationRulesConfigurationData().isPasswordMustNotHaveSpaces()));
        childSettings.addProperty(IDS_PASSWORD_VALIDATION_NAME, String.valueOf(savedSettings.getPasswordValidationRulesConfigurationData().isPasswordMustBeDifferentFromName()));

        return childSettings;
    }

    /**
     *
     * @param savedSettings
     * @return
     */
    private BiCNetPluginSettings getLDAPSettings(GSGeneralSettingData savedSettings) {
        BiCNetPluginSettings childSettings = new BiCNetPluginSettings(IDS_LDAP_AUTH);

        childSettings.addProperty(IDS_LDAP_AUTH_ENABLE, String.valueOf(savedSettings.getLdapConfigurationData().isEnabled()));
        childSettings.addProperty(IDS_LDAP_AUTH_HOSTNAME, String.valueOf(savedSettings.getLdapConfigurationData().getHost()));
        childSettings.addProperty(IDS_LDAP_AUTH_PORT, String.valueOf(savedSettings.getLdapConfigurationData().getPort()));
        childSettings.addProperty(IDS_LDAP_AUTH_SSL_INDICATOR, String.valueOf(savedSettings.getLdapConfigurationData().isSslIndicator()));
        childSettings.addProperty(IDS_LDAP_AUTH_SEARCH_ACCOUNT, String.valueOf(savedSettings.getLdapConfigurationData().getSearchAccount()));
        childSettings.addProperty(IDS_LDAP_AUTH_USER_SEARCH_BASE, String.valueOf(savedSettings.getLdapConfigurationData().getUserSearchBase()));
        childSettings.addProperty(IDS_LDAP_AUTH_USER_SEARCH_FILTER, String.valueOf(savedSettings.getLdapConfigurationData().getUserSearchFilter()));
        childSettings.addProperty(IDS_LDAP_AUTH_USER_SEARCH_SCOPE, String.valueOf(savedSettings.getLdapConfigurationData().getUserSearchScope()));
        childSettings.addProperty(IDS_LDAP_AUTH_USER_ID_ATTRIBUTE, String.valueOf(savedSettings.getLdapConfigurationData().getUserIdAttribute()));
        childSettings.addProperty(IDS_LDAP_AUTH_GROUP_SEARCH_BASE, String.valueOf(savedSettings.getLdapConfigurationData().getGroupSearchBase()));
        childSettings.addProperty(IDS_LDAP_AUTH_GROUP_SEARCH_FILTER, String.valueOf(savedSettings.getLdapConfigurationData().getGroupSearchFilter()));
        childSettings.addProperty(IDS_LDAP_AUTH_GROUP_SEARCH_SCOPE, String.valueOf(savedSettings.getLdapConfigurationData().getGroupSearchScope()));
        childSettings.addProperty(IDS_LDAP_AUTH_GROUP_ID_ATTRIBUTE, String.valueOf(savedSettings.getLdapConfigurationData().getGroupIdAttribute()));
        childSettings.addProperty(IDS_LDAP_AUTH_GROUP_ATTRIBUTE_ID_USER, String.valueOf(savedSettings.getLdapConfigurationData().getGroupMemberAttribute()));

        return childSettings;
    }

    /**
     *
     * @param savedSettings
     * @return
     */
    private BiCNetPluginSettings getSSOSettings(GSGeneralSettingData savedSettings) {
        BiCNetPluginSettings childSettings = new BiCNetPluginSettings(IDS_SSO);

        childSettings.addProperty(IDS_SSO_ENABLE, String.valueOf(savedSettings.getSSOConfigurationData().isEnabled()));
        childSettings.addProperty(IDS_DOMAIN_NAME, String.valueOf(savedSettings.getSSOConfigurationData().getDomainName()));
        childSettings.addProperty(IDS_DOMAIN_NAME_SERVER, String.valueOf(savedSettings.getSSOConfigurationData().getDomainServer()));
        childSettings.addProperty(IDS_LDAP_PORT, String.valueOf(savedSettings.getSSOConfigurationData().getLdapTcpPort()));

        return childSettings;
    }

    /**
     *
     * @param savedSettings
     * @return
     */
    private BiCNetPluginSettings getBiCNetPluginSettings(GSGeneralSettingData savedSettings) {
        BiCNetPluginSettings childSettings = new BiCNetPluginSettings(IDS_GENERAL_SETTINGS);

        childSettings.addProperty(IDS_DEFAULT_PASSWORD_EXPIRATION, String.valueOf(savedSettings.getInitPasswordChangeInterval()));
        childSettings.addProperty(IDS_SESSION_TIMEOUT, String.valueOf(savedSettings.getInactivityTimeout()));
        childSettings.addProperty(IDS_EXPIRE_PASSWORD_WARNING, String.valueOf(savedSettings.getExpirePasswordWarning()));
        childSettings.addProperty(IDS_MAX_LOGIN_ATTEMPTS, String.valueOf(savedSettings.getDeactivationAfterLoginAttempts()));
        childSettings.addProperty(IDS_USER_ACCOUNT_DEACTIVATION, String.valueOf(savedSettings.getDeactivationAfterInativity()));
        childSettings.addProperty(IDS_ADMIN_REACTIVATION_TIME, String.valueOf(savedSettings.getAdminLockout()));
        childSettings.addProperty(IDS_INACTIVITY_TIMEOUT_WARNING, String.valueOf(savedSettings.getInactivityTimeoutWarningTime()));

        return childSettings;
    }

    /**
     * Check if Component or Manager contains License and if it is valid
     *
     * @return LicenseStatus containing License status. For components without license, always return AVAILABLE.
     */
    @Override
    public LicenseStatus getLicenseStatus() {
        return LicenseStatus.AVAILABLE;
    }

}
