/*
 * --------------------------------------------------------
 * History
 * <date>       <author>        <reason(s) of change>
 * 18-Jan-2005	Muyeen Munaver	CF00702 - The "OK" could became Grey in the "New User" window
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 06-May-2009  Nagaraddi S S    TD004578 - RQT-STDERR errors instead log4j's
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.view;

import com.ossnms.bicnet.bcb.model.security.AuthorizationFailedException;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPrintData;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginView;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMHelp;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.tools.jfx.JfxFormPanel;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxProperties;
import com.ossnms.tools.jfx.components.JfxPersistentProperties;
import com.ossnms.tools.jfx.table.JfxTable;
import com.ossnms.tools.jfx.table.JfxTableProperties;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Frame;
import java.security.InvalidParameterException;
import java.util.Properties;
import javax.swing.Icon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import org.apache.log4j.Logger;

/**
 * Since all the windows of User and Security Management have the same look and feel. Where there is a button panel, it makes more sense to have this in a base class.
 * 
 * This class provides the possibility of placing the buttons in the button panel. It also provides the basic functionality
 */

public abstract class USMBaseView extends JfxFormPanel implements BiCNetPluginView {
    // Fault ID 68 - Remove un-necessary data attrib from USMBaseView.

    private static final long serialVersionUID = 6333196465107266291L;

    // Data member to hold the Client Controller for the view.
    protected USMControllerIfc associatedClientController;

    // Data member for the Logging of the class.
    private static final Logger LOGGER = Logger.getLogger(USMBaseView.class);

    // This is the data member to hold the frame that will be used to embed the Panel
    private BiCNetPluginFrame frame = null;

    // Data member to hold the Command that is responsible for creating this Interactor.
    private USMCommand command;

    // Data member to hold whether the View can be resized or not.
    private boolean resizable;

    // Data member to hold the Title of the View
    private String strTitle;

    // Data member to hold the fully qualified class name. Needed by the BicNet Frameword
    private String strId;

    // Data member to hold the ID of the Help Screen to be opened
    private int hlpId;

    // This method keeps track whether the wait cursor is currently set or not.
    private boolean waitCursorState = false;

    /**
     * Constructor
     * @param strID
     *            - This hold the fully qualified class name
     * @param title
     *            - This hold the Title of the View
     * @param isResizable
     *            - This indicates if the view is resizable or not
     * @param helpid
     *            - The Help ID which should be used to open the help files
     */
    protected USMBaseView(String strID, String title, boolean isResizable, int helpid) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering constructor. Parameters passed are : ID : " + strID + " Title : " + title + "Resizable : " + isResizable + " Help ID : " + helpid);
        }

        if ((null == strID) || (null == title)) {
            LOGGER.error("Values sent as parameter are incorrect. ID : " + strID + " Title : " + title + "Resizable : " + isResizable + " Help ID : " + helpid);
            throw new InvalidParameterException();
        }

        strId = strID;
        strTitle = title;
        resizable = isResizable;
        hlpId = helpid;

        LOGGER.debug("Exiting constructor.");
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#setFrame(com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame)
     */
    @Override
    public void setFrame(BiCNetPluginFrame newframe) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering setFrame. Value being set is : " + newframe);
        }

        if (newframe == null) {
            LOGGER.error("Null value being set for Frame.");
            throw new InvalidParameterException();
        }
        frame = newframe;

        LOGGER.debug("Exiting setFrame");
    }

    /**
     * Function to re turn the Frame which is associated with the View
     * 
     * @return BiCNetPluginFrame Frame associated with the View.
     */
    @Override
    public BiCNetPluginFrame getFrame() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering getFrame.");
            LOGGER.debug("Exiting getFrame. Returning " + frame);
        }
        return frame;
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#isClosable()
     */
    @Override
    public boolean isClosable() {
        return true;
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#canClose()
     */
    @Override
    public boolean canClose() {
        return true;
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#isPrintable()
     */
    @Override
    public boolean isPrintable() {
        return false;
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getPrintData()
     */
    @Override
    public BiCNetPluginPrintData getPrintData() {
        return null;
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#eventOpened()
     */
    @Override
    public void eventOpened() {
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#eventClosing()
     */
    @Override
    public void eventClosing() {
        onClose();
    }

    /**
     * Function that should be called by the Derived classes to handle the closing of the window.
     * 
     */
    public void onClose() {
        LOGGER.debug("Entering onClose");
        if (null != command) {
            command.cleanup();
        }
        LOGGER.debug("Exiting onClose");
    }

    /**
     * Method to close the window
     * 
     */
    public void close() {
        if (this.getFrame() != null) {
            this.getFrame().closeFrame();
        }
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getHelpID()
     */
    @Override
    public int getHelpID() {
        return hlpId;
    }

    /**
     * Function to get the Command that is associated with this View
     * 
     * @return USMCommand - Returns the m_Cmd.
     */
    public USMCommand getCommand() {
        return command;
    }

    /**
     * Function to set the Command that is associated with this View
     * 
     * @param cmd
     *            -The m_Cmd to set.
     */
    public void setCommand(USMCommand cmd) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering setCommand. Value being set is : " + cmd);
        }
        command = cmd;

        LOGGER.debug("Exiting setCommand.");
    }

    /**
     * Function to display the view
     * @return boolean - Return true if the view was correctly displayed.
     */
    public boolean showWindow() {
        boolean bCorrectlyDisplayed = false;
        try {
            USMFrameType frmType = getFrameTypeToBeUsed();
            BiCNetPluginFrame frame = USMUtility.getInstance().getSecuritySite().createFrame(this, frmType.getFrameType());
            frame.showFrame();
            bCorrectlyDisplayed = true;
        } catch (BiCNetPluginException e) {
            LOGGER.error("Exception :", e);
        }
        return bCorrectlyDisplayed;
    }

    /**
     * Function to bring the View back to the Front
     */
    public void bringToFront() {
        frame.activateFrame();
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getTitle()
     */
    @Override
    public String getTitle() {
        return strTitle;
    }

    /**
     * Helper function to set the Title of the Window.
     * @param title
     *            The new Title of the Window
     */
    protected void setTitle(String title) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Setting new title of the Window to : " + title);
        }

        if (null == title) {
            LOGGER.error("Setting null title.");
            throw new InvalidParameterException();
        }
        strTitle = title;
        setName("Title - " + strTitle);
        frame.updateFrameTitle();
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#isResizable()
     */
    @Override
    public boolean isResizable() {
        return resizable;
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getID()
     */
    @Override
    public String getID() {
        return strId;
    }

    /**
     * Function to decide what is the Frame that should be used.
     * 
     * @return USMFrameType The Frame type that should be used.
     */
    protected USMFrameType getFrameTypeToBeUsed() {
        return USMFrameType.S_INTERNAL;
    }

    /**
     * Function that will be called by the USMControllerIfc derived object when it recieves an exception from the Server
     * 
     * @param excp
     *            The Exception that has been raised.
     */
    public final void handleBcbSecurityException(BcbSecurityException excp) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering handleBcbSecurityException. Exception raised is : " + excp);
        }

        String str = "AuthorizationFailedException raised in the server.\n" + "Possible reason could be you no longer have authorization to perform the said operation.";
        JfxOptionPane.showMessageBox(this, str);
        eventClosing();

        /*
         * if (p_Excp instanceof AuthorizationFailedException) { LOGGER.debug("AuthorizationFailedException has been raised"); AuthorizationFailedException ex =
         * (AuthorizationFailedException) p_Excp; handleAuthorizationFailedException(ex); }
         */

        LOGGER.debug("Exiting handleBcbSecurityException.");
    }

    /**
     * Function to handle a AuthorizationFailedException if raised by the server
     * 
     * @param ex
     *            The Exception that has been raised.
     */
    protected void handleAuthorizationFailedException(AuthorizationFailedException ex) {
        LOGGER.debug("Entering handleAuthorizationFailedException");
        String str = "AuthorizationFailedException raised in the server.\n" + "Possible reason could be you no longer have authorization to perform the said operation.";
        JfxOptionPane.showMessageBox(this, str);

        LOGGER.debug("Exiting handleAuthorizationFailedException");
    }

    public static void showNotImplementedFeatureWindow() {
        String str = "The requested feature is not supported \n in the current release.";
        Frame frm = JOptionPane.getRootFrame();
        JfxOptionPane.showMessageBox(frm, str);
    }
    // Fault ID 48 - Show a message informing not released feature - End

    // Fault ID 61 - Wrong "Policy has been Deleted" message
    /**
     * Function to do the cleanup actions for the View.
     */
    public void cleanup() {
        LOGGER.debug("Entering cleanup.");
        command = null;

        frame = null;

        if (associatedClientController != null) {
            associatedClientController.cleanup();
        }
        associatedClientController = null;
        LOGGER.debug("Exiting cleanup.");
    }

    /**
     * Helper function to display the Help Page that is associated with this View.
     */
    public void showAssociatedHelp() {
        LOGGER.debug("Entering showAssociatedHelp");

        frame.showHelp(hlpId);

        if (LOGGER.isDebugEnabled()) {
            String strHelp = USMHelp.getStringForID(hlpId);
            LOGGER.debug("Exiting showAssociatedHelp. Help ID : " + hlpId + " Window : " + strHelp);
        }
    }

    /**
     * Setting the final modifier will help the function to become a candidate for inlining. This method sets the cursor to a wait cursor for this window.
     */
    public void setWaitCursor() {
        waitCursorState = true;
        setCursorToAllComponents(this, new Cursor(Cursor.WAIT_CURSOR));
    }

    /**
     * Setting the final modifier will help the function to become a candidate for inlining This method sets the cursor to a normal cursor for this window.
     */
    public void setNormalCursor() {
        waitCursorState = false;
        setCursorToAllComponents(this, new Cursor(Cursor.DEFAULT_CURSOR));
    }

    /**
     * This method returns the current state of the wait cursor.
     * @return boolean Returns true if the wait cursor is set.
     */
    public final boolean isWaitCursorSet() {
        return waitCursorState;
    }

    /**
     * Setting the final modifier will help the function to become a candidate for inlining. This helper method will set the cursor over all of its components.
     * 
     * @param cursor
     */
    private void setCursorToAllComponents(Container com, Cursor cursor) {
        Component[] cmps = com.getComponents();
        for (Component cmp : cmps) {
            cmp.setCursor(cursor);
            if (cmp instanceof JPanel) {
                setCursorToAllComponents((Container) cmp, cursor);
            }
        }
        setCursor(cursor);
    }

    /**
     * Helper function that should be called by the Derived classes when the Window is to be closed, on account of object for which this window is opened is deleted or removed from
     * CF USM.
     */
    public void closeWindowOnObjectDeletion() {
        String strMsg = USMStringTable.IDS_WINDOW_CLOSE_OBJ_DELETED_OR_REMOVED.toString();
        bringToFront();
        JfxOptionPane.showMessageBox(this, strMsg);
        this.getFrame().closeFrame();
    }

    /**
     * Helper function to save table properties as a Profile
     */
    protected final void saveProperties(JfxTable table, int nIndex, String strProfileName) {
        // Persistent properties
        JfxPersistentProperties persistentProps = table.getPersistentProperties(strProfileName, 0);

        JfxProperties ldapProfile = new JfxProperties();

        ldapProfile.setProperty("Properties." + nIndex + ".Class", persistentProps.getClass().getName());
        ldapProfile.setProperty("Properties." + nIndex + ".ViewID", persistentProps.getViewID().toString());
        ldapProfile.setProperty("Properties." + nIndex + ".ControlID", String.valueOf(persistentProps.getControlID()));
        persistentProps.saveProperties(ldapProfile, "Properties." + nIndex);

        java.util.Properties prop = new java.util.Properties();
        prop.putAll(ldapProfile);

        USMUtility.getInstance().getSecureClientSession().setUserProfile(strProfileName, prop);
    }

    /**
     * Helper function to load table properties from an LDAP Profile
     */
    protected final void loadProperties(JfxTable table, int nIndex, String strProfileName) {

        Properties ldapProfile = USMUtility.getInstance().getSecureClientSession().getUserProfile(strProfileName);

        // Load user profile
        JfxProperties props = new JfxProperties();
        if (ldapProfile != null) {
            props.putAll(ldapProfile);
        }

        // Load persistent properties
        String strClass = props.getProperty("Properties." + nIndex + ".Class");
        String strViewId = props.getProperty("Properties." + nIndex + ".ViewID");

        if (strClass != null && strViewId != null) {
            int nControlId = props.getPropertyAsInt("Properties." + nIndex + ".ControlID", 0);

            JfxPersistentProperties persistent = createPersistentProperties(strClass, strViewId, nControlId);
            if (persistent != null) {
                persistent.loadProperties(props, "Properties." + nIndex);
                table.setPersistentProperties(persistent);
            } else {
                LOGGER.error("Unknown persistent properties class read from property file:" + strClass);
            }
        }
    }

    protected static JfxPersistentProperties createPersistentProperties(String strClass, String strViewId, int controlId) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("createPersistentProperties(" + strClass + ", " + strViewId + ", " + controlId + ") Entry ");
        }
        JfxPersistentProperties persistent = null;

        if (strClass.equals(JfxTableProperties.class.getName())) {
            persistent = new JfxTableProperties(strViewId, controlId);
        }

        LOGGER.debug("createPersistentProperties(String strClass, String strViewId, int controlId) Exit");
        return persistent;
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getIcon()
     */
    @Override
    public Icon getIcon() {
        return null;
    }
    
    
	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#eventActivated()
	 */
    @Override
	public void eventActivated() {
	}

	
	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#eventDeactivated()
	 */
    @Override
	public void eventDeactivated() {
	}
}