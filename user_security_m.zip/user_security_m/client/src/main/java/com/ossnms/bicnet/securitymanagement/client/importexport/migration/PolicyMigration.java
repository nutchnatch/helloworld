package com.ossnms.bicnet.securitymanagement.client.importexport.migration;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;

import static com.ossnms.bicnet.securitymanagement.client.importexport.IETagNames.POLICY_PERMISSION;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.DEFAULT_POLICIES_NAMES;

/**
 * Migrates policies in the import/export XML document.
 * 
 * This class migrates USM menu item policies stored in the import/export file.
 * Changes (add/remove/replace) are defined in the policy_migration.xml file and are applied by the class.
 * 
 */
public final class PolicyMigration {
    
    private Element importExportElement;
    private PolicyMigrationDocument migrateDoc;

    public PolicyMigration(Element importExportDocument) throws FileNotFoundException {
        importExportElement = importExportDocument;
        InputStream migrationFileStream = this.getClass().getResourceAsStream("/policy_migration.xml");
        if (migrationFileStream == null) {
            throw new FileNotFoundException("policy_migration.xml cannot be found in the classpath");
        }
        migrateDoc = new PolicyMigrationDocument();
        migrateDoc.loadValues(migrationFileStream);
    }

    void removeMenuOptions() {
        NodeList menuNodes = importExportElement.getElementsByTagName(POLICY_PERMISSION);

        for (int i = 0; i < menuNodes.getLength(); i++) {
            Node node = menuNodes.item(i);
            Node parentNode = node.getParentNode();
            String policyName = getPolicyName(parentNode);
            if (node.getFirstChild()!=null && migrateDoc.isMenuToBeRemoved(policyName, node.getFirstChild().getNodeValue())) {
                parentNode.removeChild(node);
                // We need to change "i" due to the removed node.
                i--;
            }
        }
    }

    void updateMenuOptions() {
        NodeList menuNodes = importExportElement.getElementsByTagName(POLICY_PERMISSION);

        for (int i = 0; i < menuNodes.getLength(); i++) {
            Node node = menuNodes.item(i);
            if (node.getFirstChild()!=null && migrateDoc.getNewNameForMenu(node.getFirstChild().getNodeValue()) != null) {
                node.getFirstChild().setNodeValue(migrateDoc.getNewNameForMenu(node.getFirstChild().getNodeValue()));
            }
        }
    }

    void addMenuOptions(String policy) {
        NodeList policyNodes = importExportElement.getElementsByTagName("Policy");

        // Loop through all the policy tags
        for (int i = 0; i < policyNodes.getLength(); i++) {
            Node policyNode = policyNodes.item(i);

            // Get the <name> tag
            if (getPolicyName(policyNode).equals(policy)) {
                List<String> newMenusList = migrateDoc.getMenusToAdd(policy);
                if (newMenusList != null) {
                    for (String newMenuOption : newMenusList) {
                        Element menuElement = importExportElement.getOwnerDocument().createElement(POLICY_PERMISSION);
                        menuElement.appendChild(importExportElement.getOwnerDocument().createTextNode(newMenuOption));
                        policyNode.appendChild(menuElement);
                    }
                }
            }
        }
    }

    private String getPolicyName(Node policyNode) {
        return ((Element) policyNode).getElementsByTagName("Name").item(0).getFirstChild().getNodeValue();
    }

    /**
     * Entry method for the class.
     */
    public void migrate() {
        updateMenuOptions();
        removeMenuOptions();

        for (String policy : DEFAULT_POLICIES_NAMES) {
            addMenuOptions(policy);
        }
    }

    /**
     * Returns the XML Document.  If called after running migrate(), the translated document is returned.
     * @return
     */
    public Element getElement() {
        return importExportElement;
    }
}