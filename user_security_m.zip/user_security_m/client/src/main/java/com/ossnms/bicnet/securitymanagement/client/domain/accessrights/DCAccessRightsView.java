/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Jogi			CF000060 - CF USM GUI Requirements
 * 18-Jan-2005	Muyeen Munaver	CF00702 - The "OK" could became Grey in the "New User" window
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 14-Feb-2005  Babu B          CF001293   Columns in security windows 
 * 20-02-2005	Babu B          CF000060-01   CF USM GUI Requirements
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.domain.accessrights;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.framework.client.jfx.FrameworkDialogApp;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.api.common.USMConstants;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMHelp;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import com.ossnms.tools.jfx.JfxFormPanel;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.table.JfxTable;
import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This is the window class to display the mapping between user groups, domain and policy informations.
 */
public class DCAccessRightsView extends USMBaseViewWithButtons {
    private static final long serialVersionUID = 2144162620102069849L;
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(DCAccessRightsView.class);
    /**
     * Holds the map of the domain id with the domain name.
     */
    private Map<Integer, String> mapDomIDToName;

    /**
     * Holds the map of the policy id with the policy name.
     */
    private Map<Integer, String> mapPolIDToName;
    /**
     * A AbstractTableModel derived class for the access rights.
     */
    private DCAccessRightsWdwTableModel tblModelRights;

    /**
     * A JTable class for holding the access rights.
     */
    private JfxTable accessRightsTable;

    private static final String strProfileName = "Access Rights Window Settings";

    /**
     * This is the constructor which initializes the associated controller of this view
     */
    public DCAccessRightsView() {
        super(null, getButtons(), null, "com.ossnms.bicnet.securitymanagement.client.domain.DCAccessRights", USMStringTable.getString(USMStringTable.IDS_DC_ACCESS_RIGHT_WINDOW_TITLE), true, false,
                USMHelp.HID_ACCESS_RIGHTS);
        LOGGER.debug("DCAccessRightsWdw() - Enter");
        associatedClientController = new DCAccessRightsProxy(this);

        // Error ID 23

        initComponents();
        setNamesForTesting();
        ((DCAccessRightsProxy) associatedClientController).getAllMappings();
        LOGGER.debug("DCAccessRightsWdw() - Exit");
    }

    /**
     * Helper function that is used to set the Names of all the editable components within the Window.
     * 
     * Strings in this function are not to be Internationalized.
     */
    private void setNamesForTesting() {
        accessRightsTable.setName("AccessRights");
    }

    /**
     * The method returns the Vector of buttons that have to be displayed in the window
     * 
     * @return Vector - Vector of buttons that have to be displayed in the window
     */
    public static List<USMButtonType> getButtons() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getButtons()	Enter");
        }
        List<USMButtonType> icons = new ArrayList<USMButtonType>();
        icons.add(USMButtonType.BTN_TYPE_CLOSE);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getButtons()	Exit");
        }
        return icons;
    }

    /**
     * This method initializes the window
     */
    private void initComponents() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("initComponents() 	Enter");
        }
        JfxFormPanel contentPanel = getPanelForPlacingDerviedControls();

        tblModelRights = new DCAccessRightsWdwTableModel();
        accessRightsTable = new JfxTable(tblModelRights);
        accessRightsTable.setSortable(true);
        accessRightsTable.setFilterable(true);
        accessRightsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        contentPanel.setLayout(new GridBagLayout());
        JScrollPane accessRightsPane = new javax.swing.JScrollPane(accessRightsTable);
        contentPanel.add(accessRightsPane, new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0, GridBagConstraints.WEST, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));

        accessRightsPane.setPreferredSize(new Dimension(250, 200));
        setPreferredSize(new Dimension(350, 320));

        // Allow horizontal scrollbar
        accessRightsTable.setAutoResizeMode(JfxTable.AUTO_RESIZE_OFF);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("initComponents() 	Exit");
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getComponent()
     */
    @Override
    public JComponent getComponent() {
        return this;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView_BtnPnl_StatusBar#handleButtonClick(com.ossnms
     * .bicnet.securitymanagement.client.basic.view.USMButtonType)
     */
    @Override
    public void handleButtonClick(USMButtonTypeEnum type) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleButtonClick(" + type + ") 	Enter");
        }
        if ((USMButtonTypeEnum.BTN_TYPE_CLOSE).equals(type)) {
            close();
        } else {
            LOGGER.debug("handleButtonClick() handleButtonClick() EXIT_FUNCTION");
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleButtonClick(" + type + ") 	Exit");
        }
    }

    /**
     * This method initializes the window with the mappings. Mappings contains domain id and policy id The domain and
     * policy id are resolved to a domain name and a policy name by creating a hashtable.
     * 
     * @param LstMappings List of DCDomainMapping objects which this window needs to be initialized with.
     * @param LstDomains List of DCDomainData. Data is retrieved to form a hastable of id v/s name.
     * @param LstPolicies List of PAPolicyNameAndId. Data is retrieved to form a hashtable of id v/s name.
     */
    public void initWindow(List LstMappings, List LstDomains, List LstPolicies) {
        LOGGER.debug("initWindow() - Entry");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("initWindow(" + LstMappings + "," + LstDomains + "," + LstPolicies + ") 	Enter");
        }

        if (LOGGER.isInfoEnabled()) {
            LOGGER.info(" no of mappings=" + LstMappings.size() + " no of domain =" + LstDomains.size() + "no of policies=" + LstPolicies.size());
        }
        mapDomIDToName = createMapOfDomIDToDomName(LstDomains);
        mapPolIDToName = createMapOfPolicyIDToPolicyName(LstPolicies);

        List lstDisplayableData = convertDomMappingToTableData(LstMappings);
        tblModelRights.addData(lstDisplayableData);

        // Fault 97
        tblModelRights.fireTableDataChanged();
        LOGGER.debug("initWindow() - Exit");
    }

    /**
     * Helper function to create a hash table of domain id v/s domain name.
     * 
     * @param LstDomains List of DCDomainData
     * @return java.util.HashMap Returns a hashtable of domain id v/s name.
     */
    private Map<Integer, String> createMapOfDomIDToDomName(List LstDomains) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("createMapOfDomIDToDomName(" + LstDomains + ") 	Enter");
        }
        Map<Integer, String> map = new HashMap<Integer, String>();

        for (int index = 0; index < LstDomains.size(); index++) {
            DCDomainData domData = (DCDomainData) LstDomains.get(index);
            String strValueName = domData.getDomainName();
            Integer nKeyID = Integer.valueOf(domData.getDomainID());
            map.put(nKeyID, strValueName);
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("createMapOfDomIDToDomName(" + LstDomains + ") 	Exit : Return : " + map);
        }

        return map;
    }

    /**
     * Function to return the Icon that is associated with this View.
     * 
     * @return Icon The Icon that should be used
     */
    @Override
    public Icon getIcon() {
        return ResourcesIconFactory.ICON_TOOL_ASSIGN_16;
    }

    /**
     * This is a helper function to convert the list of mappings data
     * 
     * @param LstMappings List of DCDomainMapping that are to be represeneted in the displayable form.
     * @return java.util.ArrayList List of DCAccessRightsTableData that is required for displaying the table.
     */
    private List convertDomMappingToTableData(List LstMappings) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("convertDomMappingToTableData(" + LstMappings + ") 	Enter");
        }

        List lstDisplayableData = new ArrayList();
        for (int index = 0; index < LstMappings.size(); index++) {
            DCDomainMapping mapping = (DCDomainMapping) LstMappings.get(index);
            // User group
            String strUserGroup = mapping.getUserGroup();

            // Domain
            Integer nDomID = Integer.valueOf(mapping.getDomainID());
            String strDomName = mapDomIDToName.get(nDomID);

            // Policy
            Integer nPolID = Integer.valueOf(mapping.getPolicyID());
            String strPolicyName = mapPolIDToName.get(nPolID);
            if ((strUserGroup != null) && (strDomName != null) && (strPolicyName != null)) {
                DCAccessRightsTableData data = new DCAccessRightsTableData(strUserGroup, strDomName, strPolicyName);
                lstDisplayableData.add(data);
            } else {
                LOGGER.debug("DCAccessRightsWdw" + "convertDomMappingToTableData()" + "Internal error has occured");
            }
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("convertDomMappingToTableData(" + LstMappings + ") 	Exit : Return : " + lstDisplayableData);
        }
        return lstDisplayableData;
    }

    /**
     * Helper function to create a hash table of policy id v/s policy name.
     * 
     * @param lstPolicies List of PAPolicyNameAndID
     * @return java.util.HashMap Returns a hashtable of policy id v/s policy name.
     */
    private Map<Integer, String> createMapOfPolicyIDToPolicyName(List<PAPolicyId> lstPolicies) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("createMapOfPolicyIDToPolicyName(" + lstPolicies + ") 	Enter");
        }
        Map<Integer, String> map = new HashMap<>();

        for (PAPolicyId lstPolicy : lstPolicies) {
            PAPolicyId polData = lstPolicy;
            String strValueName = polData.getPolicyName();
            Integer nKeyDomID = polData.getPolicyID();
            map.put(nKeyDomID, strValueName);
        }

        // Add the policy named as NONE
        map.put(USMConstants.POLICY_NO_ACCESS.getPolicyID(), USMConstants.POLICY_NO_ACCESS.getPolicyName());
        map.put(USMConstants.POLICY_NO_VISIBILITY.getPolicyID(), USMConstants.POLICY_NO_VISIBILITY.getPolicyName());

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("createMapOfPolicyIDToPolicyName(" + lstPolicies + ") 	Exit : Return : " + map);
        }
        return map;
    }

    // Fault 108
    /**
     * This method should be called to indicate the creation of a new policy. The policy created will be added to the
     * hashtable.
     * 
     * @param createdPolicy The policy which has been created.
     */
    public void policyCreated(PAPolicyId createdPolicy) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("policyCreated(" + createdPolicy + ")		Enter");
        }
        Integer nKeyID = createdPolicy.getPolicyID();
        String strValueName = createdPolicy.getPolicyName();
        mapPolIDToName.put(nKeyID, strValueName);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("policyCreated(" + createdPolicy + ")		Exit");
        }
    }

    /**
     * This method should be called to indicate the creation of a new domain. The domain created will be added to the
     * hashtable of domain id v/s domain name.
     * 
     * @param domain The domain which was created.
     */
    public void domainCreated(DCDomainData domain) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("domainCreated(" + domain + ")		Enter");
        }
        Integer nKeyID = Integer.valueOf(domain.getDomainID());
        String strValueName = domain.getDomainName();
        mapDomIDToName.put(nKeyID, strValueName);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("domainCreated(" + domain + ")		Exit");
        }
    }

    /**
     * This method deletes the domain data displayed in the window. This is done in response to the DOMAIN_DELETE
     * notification. When a domain gets deleted, all associated mappings with regard to this domain should also be
     * deleted.
     * 
     * @param domain The domain which was deleted.
     */
    public void domainDeleted(DCDomainData domain) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("domainDeleted(" + domain + ")		Enter");
        }
        tblModelRights.deleteDomain(domain.getDomainName());
        tblModelRights.fireTableDataChanged();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("domainDeleted(" + domain + ")		Exit");
        }
    }

    /**
     * This method updates the access rights window when new mappings are created. The domain id and policy id
     * associated with this mapping are assumed to be already available in the hashtable.
     * 
     * @param mappingLst List of DCDomainMappings which are created.
     */
    public void mappingsCreated(List mappingLst) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("mappingsCreated(" + mappingLst + ")		Enter");
        }
        List lstDisplayableData = convertDomMappingToTableData(mappingLst);
        tblModelRights.mappingsCreated(lstDisplayableData);
        tblModelRights.fireTableDataChanged();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("mappingsCreated(" + mappingLst + ")		Exit");
        }
    }

    /**
     * This method deletes the mappings that are passed. A deleted mapping has the the policy id as -1.
     * 
     * @param mappingLst The list of DCDomainMappings which are to be deleted.
     */
    public void mappingsDeleted(List mappingLst) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("mappingsDeleted(" + mappingLst + ")		Enter");
        }
        List lstDisplayableData = convertDomMappingToTableData(mappingLst);
        tblModelRights.mappingsDeleted(lstDisplayableData);
        tblModelRights.fireTableDataChanged();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("mappingsDeleted(" + mappingLst + ")		Exit");
        }
    }

    /**
     * @param stringMsg
     */
    public void showMessage(String stringMsg) {
        bringToFront();
        JfxOptionPane.showMessageBox(this, stringMsg, JOptionPane.CLOSED_OPTION, JOptionPane.ERROR_MESSAGE);

    }

    /**
     * AbstractTableModel derived class for displaying the access rights
     */
    class DCAccessRightsWdwTableModel extends AbstractTableModel {

        private static final long serialVersionUID = 3688118662133150863L;

        /**
         * Holds the table header strings
         */
        private final String columns[] = { JfxStringTable.getString(USMStringTable.IDS_DC_USER_GROUP), JfxStringTable.getString(USMStringTable.IDS_DC_DOMAIN), JfxStringTable.getString(USMStringTable.IDS_DC_POLICY) };

        /**
         * Holds the data for displaying the access rights
         */
        private final List data = new ArrayList();

        /**
         * Default constructor.
         */
        DCAccessRightsWdwTableModel() {
        }

        /**
         * Function to get the current count of the columns.
         * 
         * @return int Returns the number of columns.
         */
        @Override
        public int getColumnCount() {
            return columns.length;
        }

        /**
         * Function to retrieve the number of rows in the window.
         * 
         * @return int Returns the current number of the rows.
         */
        @Override
        public int getRowCount() {
            return data.size();
        }

        /**
         * Function to check whether a particular cell given a column and row number is editable or not. Currently all
         * the cells are read only and will remain so.
         * 
         * @param row The row of the cell which needs to be checked for being editable.
         * @param col The column of the cell which needs to be checked for being editable.
         * @return boolean Returns true to indicate that the cell is editable. Returns false always.
         */
        @Override
        public boolean isCellEditable(int row, int col) {
            return false;
        }

        /**
         * Adds a new row to the existing table. The row should be added in the correct location, keeping the sort in
         * order.
         * 
         * @param dataRcv The new displayable mapping data that needs to be added.
         */
        public void addData(List dataRcv) {
            this.data.addAll(dataRcv);
        }

        /**
         * Deletes a domain given the domain name. Domain names are uniq. Deleteion of domains also leads to deletion of
         * all mappings that this domain takes part in.
         * 
         * @param nDomainName The domain which has to be deleted.
         */
        public void deleteDomain(String nDomainName) {
            // Start from the end and traverse down. Removing all entries which has the same Domain Name
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("deleteDomain(" + nDomainName + ")		Enter");
            }
            int index = data.size() - 1;
            for (; index >= 0; index--) {
                DCAccessRightsTableData objData = (DCAccessRightsTableData) data.get(index);
                if (nDomainName.compareTo(objData.strDomainName) == 0) {
                    // Since the Domain name passed is the same as the domain name here we can remove this entry
                    data.remove(index);
                }
            }
            // We don't need to sort here since it is already sorted and we have removed some entries. But we need to
            // update the Table
            fireTableDataChanged();
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("deleteDomain(" + nDomainName + ")		Exit");
            }
        }

        /**
         * Adds the new set of mappings which are created. Mapping could have been modified in which case, the entry has
         * to change to reflect the new policy.
         * 
         * @param sentMappingLst List of mappings which are to be modified/created.
         */
        public void mappingsCreated(List sentMappingLst) {
            // For the Mapping Created, we shall traverse through the list
            // and check if there already exists a Mapping with the same
            // Domain and the User Group. If we find this, we shall remove
            // it and add the one that has been passed instead. If we don't
            // find it we shall add the one that has been sent.
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("mappingsCreated(" + sentMappingLst + ")		Enter");
            }

            // For the window, it is always modify, since the window would have added all mappings with policy none. We
            // reuse the code, and delete and add the data.
            mappingsDeleted(sentMappingLst);
            addData(sentMappingLst);
            // The addData will take care of the sorting for us and also firing the event
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("mappingsCreated(" + sentMappingLst + ")		Exit");
            }
        }

        /**
         * Deletes the mappings and updates the window.
         * 
         * @param sentMappingLst List of mappings which need to be deleted.
         */
        public void mappingsDeleted(List sentMappingLst) {
            // For the Mapping Deleted, we shall traverse through the list and check for the Mapping that has been sent.
            // We shall then remove the mapping from the data
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("mappingsDeleted(" + sentMappingLst + ")		Enter");
            }
            for (int nSentIndex = 0; nSentIndex < sentMappingLst.size(); nSentIndex++) {
                Object sentData = sentMappingLst.get(nSentIndex);
                if (!removeMapping(sentData)) {
                    LOGGER.debug("DCAccessRightsWdwTableModel" + "mappingsDeleted" + "Failed to remove mappings");
                }
            }
            // We don't need to sort since already sorted but fire the event
            fireTableDataChanged();
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("mappingsDeleted(" + sentMappingLst + ") Exit");
            }
        }

        /**
         * Function to remove a mapping which is existing from the table
         * 
         * @param mappingObj The mapping object which has to be deleted.
         * @return boolean Returns true on successful deletion of the mapping. Returns false if the mapping doesnot
         *         exist.
         */
        private boolean removeMapping(Object mappingObj) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("removeMapping(" + mappingObj + ")		Enter");
            }
            boolean bFound = false;
            for (int nAvailIndex = 0; nAvailIndex < data.size(); nAvailIndex++) {
                Object availData = data.get(nAvailIndex);
                if (availData.equals(mappingObj)) {
                    data.remove(nAvailIndex);
                    bFound = true;
                    break;
                }
            }
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("removeMapping(" + mappingObj + ")		Exit : Return :" + bFound);
            }
            return bFound;
        }

        /**
         * Function to get the displayable column name.
         * 
         * @param col Indicates which column the caller is interested in.
         * @return java.lang.String Returns a user displayable column header.
         */
        @Override
        public String getColumnName(int col) {
            return columns[col];
        }

        /**
         * This function retrieves for a given cell, the object that needs to be displayed.
         * 
         * @param row The row of the cell which needs to be displayed.
         * @param col The column of the cell which needs to be displayed.
         * @return java.lang.Object Returns the object for the given cell.
         */
        @Override
        public Object getValueAt(int row, int col) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("getValueAt(" + row + "," + col + ")		Enter");
            }
            Object returnValue = null;
            DCAccessRightsTableData objData = (DCAccessRightsTableData) data.get(row);
            switch (col) {
            case 0: {
                returnValue = objData.strUserGroup;
                break;
            }
            case 1: {
                returnValue = objData.strDomainName;
                break;
            }
            case 2: {
                returnValue = objData.strAssignedPolicy;
                break;
            }
            default: {
                LOGGER.debug("We reached a point we should never have got to using value col=" + col);
                break;
            }

            }
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("getValueAt(" + row + "," + col + ")		Exit : Return :" + returnValue);
            }
            return returnValue;
        }

        /**
         * There is no-where else to put this. Add a mouse listener to the Table to trigger a table sort when a column
         * heading is clicked in the JTable.
         * 
         * @param table Table which needs to add the listener for the header.
         */
    }

    /**
     * Class to hold the access rights data. This is needed only for display prupose
     */
    class DCAccessRightsTableData {

        /**
         * The User Group associated with the Mapping
         */
        private final String strUserGroup;

        /**
         * The Domain Name
         */
        private final String strDomainName;

        /**
         * Assigned Policy
         */
        private final String strAssignedPolicy;

        /**
         * Creates a new instance of DCDomainMappingTableData
         * 
         * @param strUserGroup The user group of the domain mapping object.
         * @param strDomainName The domain name of the mapping object.
         * @param strAssignedPolicy The policy name of the mapping object.
         */
        public DCAccessRightsTableData(String strUserGroup, String strDomainName, String strAssignedPolicy) {
            this.strUserGroup = strUserGroup;
            this.strDomainName = strDomainName;
            this.strAssignedPolicy = strAssignedPolicy;
        }

        /**
         * This has to be overridden when ever the equals is overwritten.
         * 
         * @return int Returns a uniq hash code key for this data.
         */
        @Override
        public int hashCode() {
            return (strDomainName + strUserGroup).toLowerCase().hashCode();
        }

        /**
         * Over written equals method of the Object class. User group and domain are what makes the mapping object
         * unique.
         * 
         * @param obj The object which has to be compared with.
         * @return boolean Returns true if the objects are equal.
         */
        @Override
        public boolean equals(Object obj) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("equals(" + obj + ")		Enter");
            }
            boolean bEqual = false;
            if ((null != obj) && (obj instanceof DCAccessRightsTableData)) {
                // Do this only if the second object is not null and is of type DCAccessRightsTableData
                DCAccessRightsTableData otherData = (DCAccessRightsTableData) obj;
                if ((strDomainName.equalsIgnoreCase(otherData.strDomainName)) && (strUserGroup.equalsIgnoreCase(otherData.strUserGroup))) {
                    bEqual = true;
                }
            }
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("equals(" + obj + ")		Exit : Return :" + bEqual);
            }
            return bEqual;
        }

        /**
         * Over ridden toString method which is used for tracing purpose.
         * 
         * @return java.lang.String Returns the string using the user group + domain + policy.
         */
        @Override
        public String toString() {
            return (strUserGroup + " : " + strDomainName + " : " + strAssignedPolicy);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView_BtnPnl_StatusBar#
     * enableBtnsAfterLongOperationCompleted()
     */
    @Override
    protected void enableDisableControls() {
        enableAllButtons();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#eventClosing()
     */
    @Override
    public void eventClosing() {
        // Save table's properties
        saveProperties(accessRightsTable, 0, strProfileName);

        super.eventClosing();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#eventOpened()
     */
    @Override
    public void eventOpened() {
        // Load table's properties
        loadProperties(accessRightsTable, 0, strProfileName);

        super.eventOpened();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#setFrame(com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame)
     */
    @Override
    public void setFrame(BiCNetPluginFrame frame) {
        super.setFrame(frame);

        accessRightsTable.setDialogApp(new FrameworkDialogApp(getFrame()));
    }

    @Override
    public boolean isDockable() {
        return true;
    }
}