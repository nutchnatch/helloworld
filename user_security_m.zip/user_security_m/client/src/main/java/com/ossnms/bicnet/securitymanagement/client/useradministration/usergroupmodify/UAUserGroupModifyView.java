/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 18-Jan-2005	Muyeen Munaver	CF00702 - The "OK" could became Grey in the "New User" window
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 09-02-2005	Babu B          CF000060-01   CF USM GUI Requirements
 * 12-Apr-2006	Shrinidhi G V	CF003939-01	Deactivation of administrator
 * 02-Feb-2006	Balasubramanya	CF003463-01	Deactivation of administrator
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration.usergroupmodify;

import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMHelp;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.bicnet.securitymanagement.client.useradministration.UADelegate;
import com.ossnms.bicnet.securitymanagement.client.useradministration.usergroup.common.UAUserGroupCreateModifyBaseView;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UACommonHelper;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserGroup;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserNameAndID;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxStringTable;
import org.apache.log4j.Logger;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

/**
 * This is a user interface class which displays the user group modify view
 */
public class UAUserGroupModifyView extends UAUserGroupCreateModifyBaseView {
    private static final long serialVersionUID = -64071959157946840L;
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(UAUserGroupModifyView.class);

    /**
     * Data member to hold title for the window
     */
    private static final String UG_TITLE_USER_GROUP_MODIFY_WINDOW = JfxStringTable.getString(USMStringTable.IDS_UG_TITLE_USER_GROUP_MODIFY_WINDOW);
    private static final String UG_MSG_USER_GROUP_DESC_NOT_VALID = JfxStringTable.getString(USMStringTable.IDS_UG_MSG_MODIFY_USER_GROUP_DESC_NOT_VALID);

    /**
     * Constructor
     * 
     * @param userGroup user group to be modified
     */
    public UAUserGroupModifyView(UAUserGroup userGroup) {
        super(null, getButtons(), null, "com.ossnms.bicnet.securitymanagement.client.UAUserGroupModifyView" + "-" +
                userGroup.getName(), UG_TITLE_USER_GROUP_MODIFY_WINDOW, true, USMHelp.HID_MODIFY_USERGROUP);

        LOGGER.debug("UAUserGroupModifyView(" + userGroup + ") Enter");
        setValueofComponents(userGroup.getName(), userGroup.getDescription());
        associatedClientController = new UAUserGroupModifyClientController(userGroup, this);
        ((UAUserGroupModifyClientController) associatedClientController).sendRequestToFetchAssignedNonAvailableUsers();
        LOGGER.debug("UAUserGroupModifyView(" + userGroup + ") Exit");
    }

    /**
     * Overridden method to return the buttons to be embedded in the button bar
     * 
     * @return vector of USMButtonType(s) to be added to the View
     */
    private static List<USMButtonType> getButtons() {
        LOGGER.debug("getButtons() Enter");
        List<USMButtonType> vecBtns = new ArrayList<USMButtonType>();
        USMButtonType ok = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_OK, null, USMStringTable.IDS_UG_TOOL_TIP_MODIFY_USER_GROUPS, true);
        vecBtns.add(ok);
        vecBtns.add(USMButtonType.BTN_TYPE_CANCEL);
        LOGGER.debug("getButtons() Exit");
        return vecBtns;
    }

    /**
     * Returns the user group name
     * 
     * @return String user group name
     */
    public String getUserGroupName() {
        return tabGroup.getGeneralPane().getNameTextField().getText();
    }

    /**
     * Overriden method to return the component to be embedded in the view
     * 
     * @return the view itself
     * 
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getComponent()
     */
    @Override
    public JComponent getComponent() {
        return this;
    }

    /**
     * Sets the name and description information for the user group to be modified
     * 
     * @param strName
     *            user group name
     * @param strDesc
     *            user group description
     */
    void setValueofComponents(String strName, String strDesc) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setValueofComponemts(" + strName + "," + strDesc + ") Exit");
        }
        tabGroup.getGeneralPane().getNameTextField().setText(strName);
        tabGroup.getGeneralPane().getDescriptionTextField().setText(strDesc);
        tabGroup.getGeneralPane().getNameTextField().setEnabled(false);
        
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setValueofComponemts(" + strName + "," + strDesc + ") Exit");
        }
    }

    /**
     * Handler for buttons in button bar. Called by USM framework, when a button is clicked
     * 
     * Delegates to appropriate helper method
     * 
     * @param buttonType
     *            Identifier for the button that was clicked
     * 
     * @see com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons#handleButtonClick(com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum)
     */
    @Override
    public void handleButtonClick(USMButtonTypeEnum buttonType) {
        if ((USMButtonTypeEnum.BTN_TYPE_OK).equals(buttonType)) {
            modifyUserGroup();
        } else if ((USMButtonTypeEnum.BTN_TYPE_CANCEL).equals(buttonType)) {
            close();
        } else {
            LOGGER.debug("handleButtonClick() handleButtonClick() EXIT_FUNCTION");
        }
    }

    /**
     * Function that is called by this class when the window is opened for the modify user group and operator has
     * pressed Modify.
     */
    private void modifyUserGroup() {
        LOGGER.debug("modifyUserGroup() Enter");
        UAUserGroup dataUserGroup = new UAUserGroup();

        // Creating UAUserGroup object
        String groupDesc = tabGroup.getGeneralPane().getDescriptionTextField().getText();
        dataUserGroup.setName(tabGroup.getGeneralPane().getNameTextField().getText());
        dataUserGroup.setDescription(groupDesc);
        int assignedUserLen = tabGroup.getGeneralPane().getAssignedUserListModel().size();
        List<String> userList = new ArrayList<String>(assignedUserLen);

        if ("".equals(groupDesc)) {
            JfxOptionPane.showMessageBox(this, UG_MSG_USER_GROUP_DESC_NOT_VALID, JOptionPane.CLOSED_OPTION, JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Creating list of the assigned users
        for (int index = 0; index < assignedUserLen; index++) {
            UAUserNameAndID dataUser = (UAUserNameAndID) tabGroup.getGeneralPane().getAssignedUserListModel().elementAt(index);
            LOGGER.debug(dataUser.getCommonName());
            LOGGER.debug(dataUser.getUserId());
            userList.add(dataUser.getUserId());
        }

        // CF003939-01
        // If "Administrators" group, do not allow the removal of the "Administrator" user
        if (dataUserGroup.getName().equalsIgnoreCase(UACommonHelper.ADMIN_GROUP_NAME)) {
            boolean bAssignedHasAdmin = false;
            for (int i = 0; i < userList.size(); i++) {
                if (userList.get(i) instanceof String) {
                    String userName = userList.get(i);
                    if (userName.equalsIgnoreCase(new UADelegate().getAdminUserName())) {
                        bAssignedHasAdmin = true;
                    }
                }
            }
            // If the UG is "Administrators" and assigned users do not contain "Administrator", show an error message and return
            if (!bAssignedHasAdmin) {
                JfxOptionPane.showMessageBox(this, USMStringTable.IDS_UG_ADMINISTRATOR_USER_MODIFY_ERROR.toString(), JOptionPane.CLOSED_OPTION, JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Getting List of mappings to create, delete and modify
        List<DCDomainMapping> mappingsForUserGroup = new ArrayList<DCDomainMapping>();
        tabGroup.getDomainsPoliciesPane().getMappingsForAssignment(dataUserGroup.getName(), mappingsForUserGroup);
        
        ((UAUserGroupModifyClientController) associatedClientController).sendRequestToModifyUserGroup(dataUserGroup, userList, mappingsForUserGroup);
        
        setGuiNames();
        
        LOGGER.debug("modifyUserGroup() Exit");
    }
    
    private void setGuiNames() {
        tabGroup.getGeneralPane().getNameTextField().setText("Name");
        tabGroup.getGeneralPane().getDescriptionTextField().setText("Description");
    }

    /**
     * Displays the error message box
     * 
     * @param strMessage
     *            p_message to be displayed
     */
    public void showMessageWindow(String strMessage) {
        bringToFront();
        JfxOptionPane.showMessageBox(this, strMessage, JOptionPane.CLOSED_OPTION, JOptionPane.ERROR_MESSAGE);
    }

    /**
     * @param grp
     */
    public void groupModified(UAUserGroup grp) {
        tabGroup.getGeneralPane().getDescriptionTextField().setText(grp.getDescription());
    }

    @Override
    protected void enableDisableControls() {
        enableAllButtons();
    }
    
    @Override
    public boolean isDockable() {    
        return false;
    }
    
    @Override
    public Icon getIcon() {
        return ResourcesIconFactory.ICON_LIST_USER_GROUP_16;
    }

}