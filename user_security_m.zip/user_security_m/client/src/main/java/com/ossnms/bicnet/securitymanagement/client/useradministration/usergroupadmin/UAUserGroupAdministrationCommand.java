/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   UAUserGroupAdministrationCommand
 * Author:      Jogender
 * Substitute	Babu B
 * Created on	12-09-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER_GROUP.CONFIGURE 
 *       : TNMS.DX2.SM.USER_GROUP.VIEW
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration.usergroupadmin;

import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;

/**
 * Concrete class for the Command of the User Group Administration View. This
 * Command is registered with the UI and is responsible to display the User
 * Group Administration view
 */
public class UAUserGroupAdministrationCommand extends USMCommand {

	/**
	 * Default constructor
	 */
	public UAUserGroupAdministrationCommand() {
		super(USMCommandID.S_UI_ID_USER_MGMT_VIEW_USER_GROUP);
	}

	/**
	 * THis class returns the view associated with the controller
	 * 
	 * @return USMBaseView - The User Group Administration View
	 */
	@Override
    protected USMBaseView createAndReturnView() {
		return new UAUserGroupAdministrationView();
	}

}
