package com.ossnms.bicnet.securitymanagement.client.auth;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientProperties;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.SecurityPlugin;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.LogoffReason;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMHelp;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMFrameType;
import com.ossnms.bicnet.securitymanagement.client.useradministration.passwordvalidation.UAPasswordValidationParams;
import com.ossnms.bicnet.securitymanagement.client.useradministration.passwordvalidation.UAPasswordValidationUtility;
import com.ossnms.bicnet.securitymanagement.client.useradministration.passwordvalidation.UAPasswordValidationUtility.PasswordValidationResult;
import com.ossnms.bicnet.securitymanagement.common.auth.AAChangePasswordDetails;
import com.ossnms.bicnet.securitymanagement.common.auth.AAUserMessages;
import com.ossnms.bicnet.securitymanagement.common.auth.PasswordValidationRulesConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import com.ossnms.tnms.securitymanagement.client.res.USMLoginSplashScreenPanel;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.JfxValidatorUtils;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxPasswordField;
import com.ossnms.tools.jfx.components.JfxTextField;
import org.apache.log4j.Logger;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * This class will set properties and display the change password window. Whenever operator presses change password menu
 * entry, this will create Change password window by Instantiating this class.
 */
public class AAChangePasswordView extends USMBaseViewWithButtons {
    private static final long serialVersionUID = 969362343147980522L;
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(AAChangePasswordView.class);

    /**
     * Data member for holding security plugin
     */
    protected transient SecurityPlugin plugin = null;

    /**
     * Data member for the class ID.
     */
    private static final String CLASS_ID = "com.ossnms.bicnet.securitymanagement.client.auth.AAChangePasswordView";

    /**
     * Data member for the Window title.
     */
    private static final String WINDOW_TITLE = USMStringTable.IDS_AA_WINDOW_CHANGE_PASSWORD.toString();
    /**
     * Windows messages constants
     */
    private static final String DIALOG_MESSAGE_CHANGE_PASSWORD_SUCCESSFUL = USMStringTable.IDS_AA_DIALOG_MESSAGE_CHANGE_PASSWORD_SECCUSSFUL.toString();

    // Data member to hold the Password Validation Rules.
    private transient PasswordValidationRulesConfigurationData passwordValidationRules = new PasswordValidationRulesConfigurationData();

    // Data member to hold the User Details.
    private transient UAUser userDetails = null;

    /**
     * GUI elements
     */
    private ImageIcon iconSplash = ResourcesIconFactory.getInstance().getAppLoginImage();

    private final JfxTextField serverField = new JfxTextField();
    private final JfxTextField usernameField = new JfxTextField();
    private final JfxPasswordField oldPasswordField = new JfxPasswordField();
    private final JfxPasswordField newPasswordField = new JfxPasswordField();
    private final JfxPasswordField confirmPasswordField = new JfxPasswordField();
    private final JfxLabel newPasswordIcon = new JfxLabel();
    private final JfxLabel confirmPasswordIcon = new JfxLabel();
    /**
     * Data member to flag that the OK was pressed. So log off should not happen
     */
    private boolean okPressed = false;

    /**
     * Default constructor
     */
    public AAChangePasswordView() {

        super(null, getCommitButtons(), null, CLASS_ID, WINDOW_TITLE, true, false, USMHelp.HID_CHANGE_PASSWORD);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("AAChangePasswordView() Entry");
        }
        associatedClientController = new AAChangePasswordClientController(this);
        initComponents();
        setNamesForTesting();
        getAssociatedController().sendReqToGetAllPasswordValidationRules();
        getAssociatedController().sendReqToGetUserByName();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("AAChangePasswordView() Exit");
        }
    }

    private AAChangePasswordClientController getAssociatedController() {
        return (AAChangePasswordClientController) associatedClientController;
    }

    private static List<USMButtonType> getCommitButtons() {
        List<USMButtonType> buttons = new ArrayList<USMButtonType>();

        buttons.add(new USMButtonType(USMButtonTypeEnum.BTN_TYPE_OK, null, null, true));
        buttons.add(new USMButtonType(USMButtonTypeEnum.BTN_TYPE_CANCEL, null, null, true));
        return buttons;
    }

    /**
     * Helper function that is used to set the Names of all the editable components within the Window.
     *
     * Strings in this function are not to be Internationalized.
     */
    private void setNamesForTesting() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setNames() Entry");
        }

        serverField.setName("ServerName");
        usernameField.setName("Username");
        oldPasswordField.setName("OldPassword");
        newPasswordField.setName("NewPassword");
        confirmPasswordField.setName("ConfirmNewPassword");

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setNames() Exit");
        }

    }

    /**
     * Displays the message box
     *
     * @param message - message to be displayed
     */
    private void showMessageBox(String message) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("showMessageBox() Entry");
        }

        JfxOptionPane.showMessageBox(this, message, JOptionPane.CLOSED_OPTION, JOptionPane.INFORMATION_MESSAGE);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("showMessageBox() Exit");
        }
    }

    /**
     * Function called to update the window with the new information.
     *
     * @param isPasswordMustNotHaveSpaces If the PasswordMustNotHaveSpaces rule is active;
     * @param isPasswordMustBeDifferentFromName If the PasswordMustBeDifferentFromName rule is active;
     * @param isPasswordMustBeDifferentFromEmployeeNumber If the PasswordMustBeDifferentFromEmployeeNumber rule is active;
     * @param isPasswordMustBeDifferentFromDate If the PasswordMustBeDifferentFromDate rule is active;
     */
    public void updateViewWithPasswordValidationRulesResult(boolean isPasswordMustNotHaveSpaces, boolean isPasswordMustBeDifferentFromName,
                                                            boolean isPasswordMustBeDifferentFromEmployeeNumber, boolean isPasswordMustBeDifferentFromDate) {
        LOGGER.debug("updateViewWithPasswordValidationRulesResult() entry");

        passwordValidationRules.setPasswordMustBeDifferentFromEmployeeNumber(isPasswordMustBeDifferentFromEmployeeNumber);
        passwordValidationRules.setPasswordMustBeDifferentFromName(isPasswordMustBeDifferentFromName);
        passwordValidationRules.setPasswordMustNotHaveSpaces(isPasswordMustNotHaveSpaces);
        passwordValidationRules.setPasswordMustBeDifferentFromDate(isPasswordMustBeDifferentFromDate);

    }

    /**
     * Function called to update the window with the new information.
     *
     * @param data
     *            The password validation rule set;
     */
    public void updateViewWithUserDetailsResult(UAUser data) {
        LOGGER.debug("updateViewWithPasswordValidationRulesResult() entry");

        if (data != null) {
            LOGGER.debug("updateViewWithPasswordValidationRulesResult - Exists");
            userDetails = data;

            setUpKeyAdapter();

        } else {
            LOGGER.info("updateViewWithPasswordValidationRulesResult() - Null");
        }
    }

    private void setUpKeyAdapter() {
        KeyAdapter passwordHandler = new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                validateAndManageOKButton();
            }
        };
        oldPasswordField.addKeyListener(passwordHandler);
        newPasswordField.addKeyListener(passwordHandler);
        confirmPasswordField.addKeyListener(passwordHandler);
    }


    public void showMessage(String message) {
        JfxOptionPane.showMessageBox(this, message);
    }

    /**
     * This method will be called by AAChangePasswordClientController whenever some response notification comes to it
     *
     * @param message - message received in change password response
     */
    public void updateView(USMMessage message) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("updateView() Entry");
        }

        Integer status = message.popInteger();
        if (status.equals(AAUserMessages.AA_NO_ERROR)) {
            showMessageBox(DIALOG_MESSAGE_CHANGE_PASSWORD_SUCCESSFUL);
            this.okPressed = true;
            this.getFrame().closeFrame();
        } else {
            String csUserMessage = AAUserMessages.getInstance().getString(status);
            JfxOptionPane.showMessageBox(this, USMStringTable.IDS_AA_DIALOG_MESSAGE_PASSWORD_CHANGE_FAILURE_TITLE.toString(), csUserMessage, JOptionPane.CLOSED_OPTION, JOptionPane.ERROR_MESSAGE);
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("updateView() Exit");
        }
    }

    /**
     * Sets the component's frame.
     *
     * @param frame -Component frame.
     */
    @Override
    public void setFrame(BiCNetPluginFrame frame) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setFrame() Entry");
        }

        super.setFrame(frame);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setFrame() Exit");
        }
    }

    /**
     * This method initiates all the components except toolbar and status bar and add to change password window
     */
    private void initComponents() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("initComponents() Entry");
        }

        ISecureClientSession clientSession = getClientSession();
        BiCNetPluginSite site = USMUtility.getInstance().getSecuritySite();
        String operationAppFamilyName = site.getClientProperty(BiCNetPluginClientProperties.PRODUCT_FAMILY_NAME, null);
        String operationAppName = site.getClientProperty(BiCNetPluginClientProperties.CLIENT_NAME_FOR_IMAGE, null);

        USMLoginSplashScreenPanel splashScreen = new USMLoginSplashScreenPanel(operationAppFamilyName, operationAppName, iconSplash);

        splashScreen.setPreferredSize(new Dimension(280, 106));
        add(splashScreen, BorderLayout.NORTH);

        JfxLabel serverLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_SERVER);
        serverLabel.setLabelAndMnemonicFor(serverField);
        serverField.setText(clientSession.getServerId());
        serverField.setEditable(false);

        JfxLabel userNameLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_USERID);
        userNameLabel.setLabelAndMnemonicFor(usernameField);
        usernameField.setEditable(false);
        usernameField.setText(clientSession.getUserName());

        JfxLabel oldPasswordLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_OLD_PASSWORD);
        oldPasswordLabel.setLabelAndMnemonicFor(oldPasswordField);
        oldPasswordField.setMandatoryEntry(true);

        JfxLabel newPasswordLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_NEW_PASSWORD);
        newPasswordLabel.setLabelAndMnemonicFor(newPasswordField);
        newPasswordField.setMandatoryEntry(true);
        newPasswordIcon.setMinimumSize(new Dimension(16, 16));
        newPasswordIcon.setPreferredSize(new Dimension(16, 16));

        JfxLabel confirmPasswordLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_CONFIRM_PASSWORD);
        confirmPasswordLabel.setLabelAndMnemonicFor(confirmPasswordField);
        confirmPasswordField.setMandatoryEntry(true);
        confirmPasswordIcon.setMinimumSize(new Dimension(16, 16));
        confirmPasswordIcon.setPreferredSize(new Dimension(16, 16));

        JPanel mainPanel = getPanelForPlacingDerviedControls();
        mainPanel.setLayout(new GridBagLayout());

        mainPanel.setBorder(JfxUtils.DIALOG_OUTSIDE_BORDER);
        mainPanel.add(serverLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.MARGIN_BETWEEN_CAPTION_AND_MANDATORY_FIELD), 0, 0));
        mainPanel.add(serverField, new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        mainPanel.add(userNameLabel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.MARGIN_BETWEEN_CAPTION_AND_MANDATORY_FIELD), 0, 0));
        mainPanel.add(usernameField, new GridBagConstraints(1, 1, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0), 0, 0));
        mainPanel.add(oldPasswordLabel, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.MARGIN_BETWEEN_CAPTION_AND_MANDATORY_FIELD), 0, 0));
        mainPanel.add(oldPasswordField, new GridBagConstraints(1, 2, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0), 0, 0));
        mainPanel.add(newPasswordLabel, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.MARGIN_BETWEEN_CAPTION_AND_MANDATORY_FIELD), 0, 0));
        mainPanel.add(newPasswordField, new GridBagConstraints(1, 3, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0), 0, 0));
        mainPanel.add(newPasswordIcon, new GridBagConstraints(2, 3, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, JfxUtils.UNIT_LEFT_MARGIN, 0, 0), 0, 0));
        mainPanel.add(confirmPasswordLabel, new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.DEFAULT_MARGIN), 0, 0));
        mainPanel.add(confirmPasswordField, new GridBagConstraints(1, 4, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        mainPanel.add(confirmPasswordIcon, new GridBagConstraints(2, 4, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, JfxUtils.UNIT_LEFT_MARGIN, 0, 0), 0, 0));

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("initComponents() Exit");
        }
    }

    /**
     * Helper method to check and disable to OK button.
     */
    private void validateAndManageOKButton() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("validateAndManageOKButton() Entry");
        }
        boolean confirmPasswordFieldOk;
        boolean oldPasswordFieldOk = !String.valueOf(oldPasswordField.getPassword()).isEmpty();
        String currentDate = USMUtility.getInstance().convertDateToClientTimeZone(null);

        UAPasswordValidationParams params = new UAPasswordValidationParams(String.valueOf(newPasswordField.getPassword()),
                userDetails.getEmployeeNumber(), userDetails.getLastName(), userDetails.getFirstName(),
                String.valueOf(oldPasswordField.getPassword()), String.valueOf(confirmPasswordField.getPassword()),
                userDetails.getUserId(), currentDate);

        String validationResult = UAPasswordValidationUtility.validateNewPasswordFieldAndShowWarning(params, passwordValidationRules);
        boolean newPasswordOk = validationResult.equals(PasswordValidationResult.SUCCESS.getLabel());
        USMUtility.getInstance().updateWarningMessage(validationResult, newPasswordIcon);

        confirmPasswordFieldOk = JfxValidatorUtils.validateConfirmPasswordFieldAndShowWarning(newPasswordField, confirmPasswordField, confirmPasswordIcon);

        if (oldPasswordFieldOk && newPasswordOk && confirmPasswordFieldOk) {
            enableSelectiveButtons(Collections.singletonList(USMButtonTypeEnum.BTN_TYPE_OK));
        } else {
            disableSelectiveButtons(Collections.singletonList(USMButtonTypeEnum.BTN_TYPE_OK));
        }


        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("validateAndManageOKButton() Exit");
        }
    }

    /**
     * Sets the default cursor on the old password field
     */
    public void setFocus() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setFocus() Entry");
        }

        oldPasswordField.setFocusable(true);
        oldPasswordField.requestFocus();

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setFocus() Exit");
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getComponent()
     */
    @Override
    public JComponent getComponent() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getComponent()");
        }
        return this;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#isResizable()
     */
    @Override
    public boolean isResizable() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("isResizable()");
        }

        return false;
    }

    /**
     * Called when user pressed "OK" button. *
     */
    protected void actionOK() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("actionOK() Entry");
        }
        String currentDate = USMUtility.getInstance().convertDateToClientTimeZone(null);
        String strServerID = serverField.getText();
        String strUserID = usernameField.getText().trim();

        String strOldPassword = String.valueOf(oldPasswordField.getPassword());
        String strNewPassword = String.valueOf(newPasswordField.getPassword());

        UAPasswordValidationParams params = new UAPasswordValidationParams(String.valueOf(newPasswordField.getPassword()),
                userDetails.getEmployeeNumber(), userDetails.getLastName(), userDetails.getFirstName(),
                String.valueOf(oldPasswordField.getPassword()), String.valueOf(confirmPasswordField.getPassword()),
                userDetails.getUserId(), currentDate);

        String result = UAPasswordValidationUtility.validateWithOldPassword(params, passwordValidationRules);

        if (result.equals(PasswordValidationResult.SUCCESS.getLabel())) {

        	//Encode Password and generate random salt
        	//Should be done in AAChangePasswordDelegate
        	//strNewPassword = EncodePassword.encodePassword(strNewPassword, null);
        	
            AAChangePasswordDetails userDetails = new AAChangePasswordDetails(strUserID, strServerID, strOldPassword, strNewPassword);
            AAChangePasswordClientController objChgPwdController = new AAChangePasswordClientController(this);
            objChgPwdController.sendRequestToChangePassword(userDetails);

        } else {

            showAndLogMessage(result);

        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("actionOK() Exit");
        }
    }

    private void showAndLogMessage(String message){
        JfxOptionPane.showMessageBox(this, message, JOptionPane.CLOSED_OPTION, JOptionPane.ERROR_MESSAGE);
        LOGGER.warn("actionOK() The new password provided is not compliant with the defined rules.");
    }

    /**
     * Called when user pressed "Cancel" button.
     */
    protected void actionCancel() {
        LOGGER.debug("actionCancel() Entry");

        this.getFrame().closeFrame();

        LOGGER.debug("actionCancel() Exit");
    }

    @Override
    public void eventOpened() {
        super.eventOpened();
        setDefaultButton(USMButtonTypeEnum.BTN_TYPE_OK);
        disableSelectiveButtons(Collections.singletonList(USMButtonTypeEnum.BTN_TYPE_OK));
        this.setFocus();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView#eventClosing()
     */
    @Override
    public void onClose() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("onClose() Entry");
        }

        AAChangePasswordCommand objCommand = (AAChangePasswordCommand) getCommand();
        USMUtility util = USMUtility.getInstance();

        // This is needed for the following cases when the Change password view due to change password at next logon is open and the following occurs
        // 1. Force Loggedoff
        // 2. Inactivity timeout
        boolean bForceOrTimeoutLogoff = false;

        LogoffReason logoffReason = util.getLogoffReason();
        if (logoffReason == LogoffReason.ADMIN_FORCED_LOGOFF || logoffReason == LogoffReason.INACTIVITY_TIMEOUT) {
            bForceOrTimeoutLogoff = true;
        }

        if ((objCommand != null) && (objCommand.isInvokedAtStartup()) && (!okPressed) && (!bForceOrTimeoutLogoff)) {
            try {
                ISecureClientSession clientSession = util.getSecureClientSession();
                IPluginSecurityProvider provider = util.getSecuritySite().getSecurityProvider();
                super.onClose();
                provider.logoff(clientSession, IPluginSecurityProvider.LogoffReason.MUST_CHANGE_PASSWORD);
            } catch (BiCNetPluginException e) {
                LOGGER.error("Exception :", e);
            }
        } else {
            super.onClose();
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("onClose() Exit");
        }
    }

    /**
     * Return the frame type to display for change password window
     *
     * @return USMFrameType - frame type ( model, internal frame etc)
     */
    @Override
    protected USMFrameType getFrameTypeToBeUsed() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getFrameTypeToBeUsed()");
        }

        return USMFrameType.S_MODAL;
    }

    private ISecureClientSession getClientSession() {
        try {
            IPluginSecurityProvider securityProvider = USMUtility.getInstance().getSecuritySite().getSecurityProvider();
            ISessionContext ctx = USMUtility.getInstance().getSessionContext();
            return securityProvider.getClientSession(ctx);
        } catch (BiCNetPluginException e) {
            LOGGER.error("Failed to get client session.", e);
            return null;
        }
    }

    @Override
    public boolean isDockable() {
        return false;
    }

    @Override
    public void handleButtonClick(USMButtonTypeEnum type) {
        if (type == USMButtonTypeEnum.BTN_TYPE_OK) {
            actionOK();
        } else {
            actionCancel();
        }
    }

    @Override
    protected void enableDisableControls() {

        if(userDetails!=null && passwordValidationRules!=null) {
            validateAndManageOKButton();
        }

    }

}