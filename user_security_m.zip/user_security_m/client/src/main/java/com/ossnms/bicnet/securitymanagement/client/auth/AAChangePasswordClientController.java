/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.auth;

import com.ossnms.bicnet.securitymanagement.client.auth.job.AAJobChangePassword;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMBaseController;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobGetAllPasswordValidationRules;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobGetUserByName;
import com.ossnms.bicnet.securitymanagement.common.auth.AAChangePasswordDetails;
import com.ossnms.bicnet.securitymanagement.common.auth.PasswordValidationRulesConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAStatus;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * This is the main client interactor component which controls the session operation in the client side for the change
 * password operations.
 */
public class AAChangePasswordClientController extends USMBaseController {
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(AAChangePasswordClientController.class);

    /**
     * Data member for holding the User details
     */
    AAChangePasswordDetails userDetails = new AAChangePasswordDetails();

    /**
     * It is Default constructor to register notification for change password window
     * 
     * @param view
     */
    AAChangePasswordClientController(USMBaseView view) {
        super(view);
        LOGGER.debug("AAChangePasswordClientController(USMBaseView view) 	Entry");
        registerInterestedNotificationIds(getInterestedNotifcations());
        LOGGER.debug("AAChangePasswordClientController(USMBaseView view) 	Exit");
    }

    /**
     * Handles notification received from the server.
     * 
     * @param ugrpNotif - Data received from the server
     */
    @Override
    public void handleNotification(USMMessage ugrpNotif) {
    }

    /**
     * Updates the change password window on response received from the server.
     * 
     * @param changePasswordNotif - response received from the server for change password request
     */
    private void updateChangePasswordView(USMMessage changePasswordNotif) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("updateChangePasswordView(" + changePasswordNotif + ") Entry");

        }
        ((AAChangePasswordView) associatedView).updateView(changePasswordNotif);
        LOGGER.debug("updateChangePasswordView Exit");
    }

    /**
     * it sends a request to server for changing password using change password business delegation.
     * 
     * @param usrgrpData - User details for changing the password
     * 
     */
    public void sendRequestToChangePassword(AAChangePasswordDetails usrgrpData) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("sendRequestToChangePassword(" + usrgrpData + ") Entry");

        }

        AAJobChangePassword objJobChangePassword = new AAJobChangePassword(this, usrgrpData);
        queueJob(objJobChangePassword);
        LOGGER.debug("sendRequestToChangePassword Exit");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void resultAvailable(USMJob job, USMMessage result) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("resultAvailable(" + result + ") Entry");

        }

        USMBaseMsgType msgType = result.getMessageType();
        if (msgType.equals(UAMessageType.S_UA_RES_GET_ALL_PASSWORD_VALIDATION_RULES)) {
            handleResponseForGetAllPasswordValidationRules(result);
        } else if (msgType.equals(UAMessageType.S_UA_RES_GET_USER_BY_NAME)) {
            handleResponseForGetUserByName(result);
        } else {
            updateChangePasswordView(result);
        }

        LOGGER.debug("resultAvailable Exit");
    }

    /**
     * Handles the response for the get all user groups operation
     *
     * @param result
     *            contains the result of the operation
     */
    private void handleResponseForGetAllPasswordValidationRules(USMMessage result) {
        LOGGER.info("handleResponseForGetAllPasswordValidationRules() MESSAGE SIZE ");

        PasswordValidationRulesConfigurationData data = new PasswordValidationRulesConfigurationData();

        // Pop the Result of the Operation.
        UAStatus statusObject = new UAStatus();
        statusObject.popMe(result);

        if (statusObject.getStatus() == UAStatus.S_SUCCESS) {
            LOGGER.info("rules fetched successfully ");

            data.popMe(result);

            getView().updateViewWithPasswordValidationRulesResult(data.isPasswordMustNotHaveSpaces(), data.isPasswordMustBeDifferentFromName(),
                    data.isPasswordMustBeDifferentFromEmployeeNumber(), data.isPasswordMustBeDifferentFromDate());
        } else if (statusObject.getStatus() == UAStatus.S_INTERNAL_ERROR) {
            getView().showMessage(
                    USMStringTable.getString(USMStringTable.IDS_UA_USER_CHANGE_PASSWORD_ERROR_FETCH_ERROR_FETCH_PASSWORD_VALIDATION_RULES));
            LOGGER.info(" handleResponseForGetAllAvailableUserGroups() Failed to Fetch All Available rules from Server");
        }

        LOGGER.debug(" handleResponseForGetAllAvailableUserGroups() EXIT_FUNCTION");
    }

    /**
     * Handles the response for the get a user by name operation
     *
     * @param result
     *            contains the result of the operation
     */
    private void handleResponseForGetUserByName(USMMessage result) {
        LOGGER.info("handleResponseForGetAllPasswordValidationRules() MESSAGE SIZE ");

        UAUser data = new UAUser();

        // Pop the Result of the Operation.
        UAStatus statusObject = new UAStatus();
        statusObject.popMe(result);

        if (statusObject.getStatus() == UAStatus.S_SUCCESS) {
            LOGGER.info("rules fetched successfully ");

            data.popMe(result);

            getView().updateViewWithUserDetailsResult(data);
        } else if (statusObject.getStatus() == UAStatus.S_INTERNAL_ERROR) {
            getView().showMessage(
                    USMStringTable.getString(USMStringTable.IDS_UA_USER_CHANGE_PASSWORD_ERROR_FETCH_USER_BY_NAME));
            LOGGER.info(" handleResponseForGetAllAvailableUserGroups() Failed to Fetch All Available rules from Server");
        }

        LOGGER.debug(" handleResponseForGetAllAvailableUserGroups() EXIT_FUNCTION");
    }

    /**
     * Function to return the Notification IDs that the controller is interested in.
     * 
     * @return The List of Notification IDs that the controller is interested in
     */
    private List getInterestedNotifcations() {
        LOGGER.debug("getInterestedNotifcations() 	Entry");
        List objNotificationList = new ArrayList();
        LOGGER.debug("getInterestedNotifcations() 	Exit");
        return objNotificationList;
    }

    private AAChangePasswordView getView() {
        return (AAChangePasswordView) associatedView;
    }

    /**
     * Sends a request to get all password validation rules. The objective is to enforce these rules
     * when creating/modifying a users password.
     *
     * @return boolean - True indicates the operation was completed
     *         successfully
     */
    public boolean sendReqToGetAllPasswordValidationRules() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("sendReqToGetAllPasswordValidationRules()	  Enter");
        }
        UAJobGetAllPasswordValidationRules objJobgetAllPasswordValidationRules =
                new UAJobGetAllPasswordValidationRules(this);
        boolean bStatus = queueJob(objJobgetAllPasswordValidationRules);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "sendReqToGetAllPasswordValidationRules()	  Exit - Return :" + bStatus);
        }
        return bStatus;

    }

    /**
     * Sends a request to get all password validation rules. The objective is to enforce these rules
     * when creating/modifying a users password.
     *
     * @return boolean - True indicates the operation was completed
     *         successfully
     */
    public boolean sendReqToGetUserByName() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("sendReqToGetUserByName()	  Enter");
        }
        UAJobGetUserByName objJobGetUserByName =
                new UAJobGetUserByName(this);
        boolean bStatus = queueJob(objJobGetUserByName);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "sendReqToGetUserByName()	  Exit - Return :" + bStatus);
        }
        return bStatus;

    }

}
