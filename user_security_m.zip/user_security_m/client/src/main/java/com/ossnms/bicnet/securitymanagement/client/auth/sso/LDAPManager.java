package com.ossnms.bicnet.securitymanagement.client.auth.sso;

import com.ossnms.bicnet.securitymanagement.common.ldap.ADElement;
import com.ossnms.bicnet.securitymanagement.common.ldap.ADLDAPManager;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.SearchControls;
import javax.security.auth.Subject;
import java.util.ArrayList;
import java.util.List;

/**
 * created on 5/8/2015
 */
public class LDAPManager extends ADLDAPManager {


    private static final String ATTRIBUTE_OBJECT_SID = "objectSid";
    private static final String ATTRIBUTE_USER_PRINCIPAL_NAME = "userPrincipalName";
    private static final String SEARCH_FILTER = "(&(objectClass=user)(sAMAccountName=%s))";

    /**
     * Constructor
     *
     * @param subject the security subject
     * @param realm the realm
     * @param kdc the domain controller
     * @param port
     */
    public LDAPManager(Subject subject, String realm, String kdc, String port) {
        super(subject, realm, kdc, port);
    }

    /**
     *
     * @param sAMAccountName the principal's name
     * @return User account's objectSID, null if any error occurred or the user does not exist
     */
    public byte[] getObjectSID(String sAMAccountName) throws NamingException {
        if(!connect()){
            return null;
        }

        try{
            String searchFilter = String.format(SEARCH_FILTER, sAMAccountName);

            SearchControls searchControls = new SearchControls();
            searchControls.setReturningAttributes(new String[] { ATTRIBUTE_OBJECT_SID });
            searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);

            List<ADElement> foundObjects = new ArrayList<>();

            if (getObjects(EMPTY, EMPTY, EMPTY, getBaseDNSearch(realm), foundObjects, searchFilter, searchControls)) {
                return getObjectSIDFromLWElement(foundObjects);
            }

            return null;
        } finally {
            disconnect();
        }
    }

    /**
     *
     * @param sAMAccountName
     * @return
     */
    public String getUserPrincipalName(String sAMAccountName) throws NamingException {
        if(!connect()){
            return null;
        }

        try{
            String searchFilter = String.format(SEARCH_FILTER, sAMAccountName);

            SearchControls searchControls = new SearchControls();
            searchControls.setReturningAttributes(new String[] { ATTRIBUTE_USER_PRINCIPAL_NAME });
            searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);

            List<ADElement> foundObjects = new ArrayList<>();

            if (getObjects(EMPTY, EMPTY, EMPTY, getBaseDNSearch(realm), foundObjects, searchFilter, searchControls)) {
                return getUserPrincipalNameFromLWElement(foundObjects);
            }
            return null;
        } finally {
            disconnect();
        }
    }

    /**
     *
     * @param foundObjects list of ADElements found in a LDAP Query
     * @return the found ObjectSID
     */
    private byte[] getObjectSIDFromLWElement(List<ADElement> foundObjects) throws NamingException {
        if(foundObjects == null || foundObjects.size() == 0){
            return null;
        }

        //only one should be there
        ADElement element = foundObjects.get(0);
        Attribute attribute = element.getLdapAttributes().get(ATTRIBUTE_OBJECT_SID);
        if (attribute == null ) {
            return null;
        }

        return (byte[]) attribute.get(0);
    }

    /**
     *
     * @param foundObjects
     * @return
     * @throws NamingException
     */
    private String getUserPrincipalNameFromLWElement(List<ADElement> foundObjects) throws NamingException {
        if(foundObjects == null || foundObjects.size() == 0){
            return null;
        }

        //only one should be there
        ADElement element = foundObjects.get(0);
        Attribute attribute = element.getLdapAttributes().get(ATTRIBUTE_USER_PRINCIPAL_NAME);
        if (attribute == null ) {
            return null;
        }

        return (String) attribute.get(0);
    }
}
