/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	PAMenuNode
 * Author      	Vinay Purohit
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID	:	TNMS.DX2.SM.POLICY.VIEW
 * 			:	TNMS.DX2.SM.POLICY.ADMIN
 * 			:	TNMS.DX2.SM.POLICY.CREATE
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.policy.views.base;


import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionData;

/**
 * This class represnts a Node in the tree
 */
public class PAPermissionNode {

	/**
	 * Data member to hold the Name that is displayed to the user
	 */
	String label;

	/**
	 * Data member to hold the Fully Qualified Name of the Menu Entry.
	 */
	String fqn;

	/**
	 * Data member to hold the concrete permission data
	 */
	PAPermissionData permissionData;

	/**
	 * Constructor.
	 * 
	 * @param label
	 *            The Name of the Menu as displayed in the tree
	 * @param fqn
	 *            The fully qualified Name of the Menu
	 */
	public PAPermissionNode(String label, String fqn, PAPermissionData permissionData) {
		this.label = label;
		this.fqn = fqn;
		this.permissionData = permissionData;
	}

	/**
	 * Function to return the equivalent string for the object.
	 * 
	 * @return java.lang.String The equivalent string for the object.
	 */
	@Override
	public String toString() {
		return label;
	}

	/**
	 * Function to retrieve the fully qualified Name
	 * 
	 * @return java.lang.String The fully qualified name
	 */
	public String getFQN() {
		return fqn;
	}

	/**
	 *
	 * @return
	 */
	public String getPermissionName(){
		return permissionData == null ? null : permissionData.getName();
	}

	public PAPermissionData getPermissionData() {
		return permissionData;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		PAPermissionNode that = (PAPermissionNode) o;

		if (label != null ? !label.equals(that.label) : that.label != null) return false;
		if (fqn != null ? !fqn.equals(that.fqn) : that.fqn != null) return false;
		return !(permissionData != null ? !permissionData.equals(that.permissionData) : that.permissionData != null);

	}

	@Override
	public int hashCode() {
		int result = label != null ? label.hashCode() : 0;
		result = 31 * result + (fqn != null ? fqn.hashCode() : 0);
		result = 31 * result + (permissionData != null ? permissionData.hashCode() : 0);
		return result;
	}
}
