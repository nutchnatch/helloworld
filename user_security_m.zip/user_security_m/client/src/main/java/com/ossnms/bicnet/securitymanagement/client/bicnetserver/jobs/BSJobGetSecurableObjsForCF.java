/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	BSJobGetSecurableObjsForCF
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_OBJECTS
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_ACL 
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_SECURITY
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.INSERT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.bicnetserver.jobs;


import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.bicnetserver.BSAppServerBusinessDelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSMessageType;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * This class represents a Job which is responsible for getting all the securable
 * Object(s) that are managed by a CF.
 */
public class BSJobGetSecurableObjsForCF extends USMJob {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(BSJobGetSecurableObjsForCF.class);

	/**
	 * Data member to hold the server for which the Securable Object(s) are to be
	 * retrieved.
	 */
	private BSTransBicNetCFInfo cf;

	/**
	 * Constructor
	 * 
	 * @param jobOwner The Owner of the Job.
	 * @param pCF The CF for which the securable object(s) are to be retrieved.
	 */
	public BSJobGetSecurableObjsForCF(USMControllerIfc jobOwner, BSTransBicNetCFInfo pCF) {
		super(BSMessageType.BS_REQ_GET_SEC_OBJS_FOR_CF, USMCommonStrings.EMPTY, USMCommonStrings.EMPTY, jobOwner);

		Object[] arr = { pCF };
		String str = USMStringTable.IDS_BS_JOB_RETRIEVE_SEC_OBJS_SINGLE.getFormatedMessage(arr);
		setName(str);

		cf = pCF;
		LOGGER.debug("Constructing BSJobGetSecurableObjsForCF. CF : {}", cf);
	}

	/**
	 *
	 * @return
	 * @throws BcbSecurityException
     */
	public USMMessage executeJob() throws BcbSecurityException {
		LOGGER.debug("Entering executeJob");
		USMMessage msg = new BSAppServerBusinessDelegate().getSecurableObjsForCF(cf);
		LOGGER.debug("Exiting executeJob");
		return msg;
	}
}