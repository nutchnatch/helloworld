/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Jogi			CF000060 - CF USM GUI Requirements
 * 18-Jan-2005	Muyeen Munaver	CF00702 - The "OK" could became Grey in the "New User" window
 * 09-02-2005	Babu B          CF000060-01   CF USM GUI Requirements
 * 14-June-2005  Muyeen Munaver  CF000209 - Changes in the ISecurityProviderFacade / IManagedObject
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.bicnetserver.configuration;

import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMHelp;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.bicnet.securitymanagement.client.bicnetserver.BSClientHelper;
import com.ossnms.bicnet.securitymanagement.client.bicnetserver.BSSecurableObjectListCellRenderer;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMenuNameList;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.tools.jfx.JfxFormPanel;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * This is the class which is responsible for the CF View
 */
class BSCFView extends USMBaseViewWithButtons implements ListSelectionListener {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(BSCFView.class);

	/**
	 * In swing, for displaying of data, the data should be stored in a Model,
	 * which is associated with the GUI object. This data member stores the data that
	 * is associated with displaying of the Managed Elements
	 */
	private DefaultListModel<BSSecurableObject> modelSecurableObjects = null;

	/**
	 * This is the GUI object which will display the Securable Objects
	 */
	private JfxList<BSSecurableObject> lstSecurableObjects = null;

	/**
	 * In swing, for displaying of data, the data should be stored in a Model,
	 * which is associated with the GUI object. This data member stores the data that
	 * is associated with displaying of the Configured CFs
	 */
	private DefaultListModel<BSTransBicNetCFInfo> modelConfiguredCFs = null;

	/**
	 * This is the GUI object which will display the Configured CFs
	 */
	private JfxList<BSTransBicNetCFInfo> lstCFs = null;

	/**
	 * On a notification, for CFs removal, function valueChanged gets called from within
	 * cfsRemoved. Hence, a request is sent which is suprious. This needs to be prevented.
	 * So this data attribute is used for controlling the problem.
	 */
	private boolean deleteInProgress = false;

	/**
	 * GUI control for popup menu in the domain list
	 */
	private JPopupMenu contextMenu;

	/**
	 * Constructor
	 */
	BSCFView() {
		super(getButtons(), BSCFView.class.getName(), USMStringTable.IDS_BS_ADMIN_WND_TITLE.toString(), true, USMHelp.HID_TMN_APPSERVER);
		initViewComponents();
		setNamesForTesting();
		associatedClientController = new BSCFClientController(this);
		getAssociatedController().sendReqToGetConfCFs();

		LOGGER.debug("Creating an object of BSAppServerView.");
	}

	/**
	 * Helper function that is used to set the Names of all the editable
	 * components within the Window.
	 * 
	 * Strings in this function are not to be Internationalized.
	 */
	private void setNamesForTesting() {
		lstCFs.setName("Servers");
		lstSecurableObjects.setName("AssociatedSecurableObjects");
	}

	/**
	 * Helper function to set up the Pop up menu.
	 */
	private void setupPopUpMenu() {
		JMenuItem remove = new JMenuItem(USMStringTable.IDS_REMOVE.toString());
		JMenuItem syncData = new JMenuItem(USMStringTable.IDS_SYNC_NE.toString());

		contextMenu = new JPopupMenu();
		contextMenu.add(remove);
		contextMenu.add(syncData);

		remove.addActionListener(e -> handleButtonClick(USMButtonTypeEnum.BTN_TYPE_REMOVE));
		remove.setMnemonic(KeyEvent.VK_V);
		remove.registerKeyboardAction(
			this,
			KeyStroke.getKeyStroke(KeyEvent.VK_V, KeyEvent.ALT_MASK),
			JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT
		);

		syncData.addActionListener(e -> handleButtonClick(USMButtonTypeEnum.BTN_TYPE_SYNC_NE));
		syncData.setMnemonic(KeyEvent.VK_S);
		syncData.registerKeyboardAction(
			this,
			KeyStroke.getKeyStroke(KeyEvent.VK_S, KeyEvent.ALT_MASK),
			JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT
		);
	}

	/**
	 * Display the context sensitive menus on right mouse click in the domain list
	 * @param event - Mouse event for pop up trigger
	 */
	private void showPopup(MouseEvent event) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("showPopup(" + event + ") 	Enter");
		}
		// is this event a popup trigger?
		if (contextMenu.isPopupTrigger(event)) {
			Point p = event.getPoint();
			contextMenu.show(lstCFs, p.x, p.y);
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("showPopup(" + event + ") 	Exit");
		}
	}

	/**
	 * Helper function to return the List of Buttons that are to be displayed
	 * 
	 * @return List -
	 * 			The List which contains the Buttons
	 */
	private static List<USMButtonType> getButtons() {
		LOGGER.debug("Entering getButtons");

		List<USMButtonType> lstButtons = new ArrayList<>();
		// The Buttons are to be the following - 
		// Remove | Sync SE | Close |

		USMButtonType remove = new USMButtonType(
				USMButtonTypeEnum.BTN_TYPE_REMOVE,
				USMMenuNameList.OPERATION_TMN_APP_SERVER_REMOVE,
				USMStringTable.IDS_BS_ADMIN_WND_TOOL_TIP_REMOVE,
				true
			);
		lstButtons.add(remove);
		lstButtons.add(USMButtonType.BTN_SEPARATOR);

		USMButtonType syncSe = new USMButtonType(
				USMButtonTypeEnum.BTN_TYPE_SYNC_NE,
				USMMenuNameList.OPERATION_TMN_APP_SERVER_SYNC_SEC_OBJS,
				USMStringTable.IDS_BS_ADMIN_WND_TOOL_TIP_SYNC_NE,
				true
		);
		lstButtons.add(syncSe);
		lstButtons.add(USMButtonType.BTN_SEPARATOR);

		LOGGER.debug("Exiting getButtons");
		return lstButtons;
	}

	/**
	 * Helper function to place the GUI Components on the Panel.
	 */
	private void initViewComponents() {
		LOGGER.debug("Entering initViewComponents");
		JfxFormPanel panelForDerivedObjs = getPanelForPlacingDerviedControls();

		// Set up the List and the Model for the CFs
		modelConfiguredCFs = new DefaultListModel<>();
		lstCFs = new JfxList<>(modelConfiguredCFs);
		lstCFs.setSelectionMode(
			ListSelectionModel.MULTIPLE_INTERVAL_SELECTION
		);
		lstCFs.setCellRenderer(new BSCFListCellRenderer());
		lstCFs.addListSelectionListener(this);

		setupPopUpMenu();

		//Adding action on domain list to dsiplay the context sensitive menus
		lstCFs.addMouseListener(new MouseAdapter() {
			@Override
            public void mousePressed(MouseEvent me) {
				showPopup(me);
			}

			@Override
            public void mouseReleased(MouseEvent me) {
				showPopup(me);
			}
		});

		// Set up the List and the Model for the Securable Objects
		modelSecurableObjects = new DefaultListModel<>();
		lstSecurableObjects = new JfxList<>(modelSecurableObjects);
		lstSecurableObjects.setCellRenderer(new BSSecurableObjectListCellRenderer());

		// Set up the Title and the Scroll Pane for CFs
		JPanel panelForCFs = new JPanel();
		panelForCFs.setLayout(new BoxLayout(panelForCFs, BoxLayout.Y_AXIS));

		// Set up the Title for CFs
		JLabel captionForCFs = new JfxLabel(USMStringTable.IDS_BS_ADMIN_WND_COMMON_FUNC.toString());
		captionForCFs.setDisplayedMnemonic(USMStringTable.IDS_BS_ADMIN_WND_COMMON_FUNC_MNEMONIC.toString().charAt(0));
		captionForCFs.setLabelFor(lstCFs);
		captionForCFs.setAlignmentX(LEFT_ALIGNMENT);
		panelForCFs.add(captionForCFs);

		// Set up the Scroll Pane for CFs
		JScrollPane scrollPaneCFs = new JScrollPane(lstCFs);
		Border bevelBorder = new BevelBorder(BevelBorder.LOWERED);
		Border marginBorder = new EmptyBorder(2, 0, 2, 2);
		Border borderForCFs = new CompoundBorder(marginBorder, bevelBorder);
		scrollPaneCFs.setBorder(borderForCFs);
		scrollPaneCFs.setAlignmentX(LEFT_ALIGNMENT);

		panelForCFs.add(scrollPaneCFs);

		// Set up the Title and the Scroll Pane for Securable objects
		JPanel panelForSecurableObjects = new JPanel();
		panelForSecurableObjects.setLayout(new BoxLayout(panelForSecurableObjects, BoxLayout.Y_AXIS));

		JLabel captionForSecurableObjects =	new JfxLabel(USMStringTable.IDS_BS_ADMIN_WND_ASSOCIATED_SEC_OBJS.toString());
		captionForSecurableObjects.setDisplayedMnemonic(USMStringTable.IDS_BS_ADMIN_WND_ASSOCIATED_SEC_OBJS_MNEMONIC.toString().charAt(0));
		captionForSecurableObjects.setDisplayedMnemonicIndex(Integer.parseInt(USMStringTable.IDS_BS_ADMIN_WND_ASSOCIATED_SEC_OBJS_MNEMONIC_INDEX.toString()));
		captionForSecurableObjects.setLabelFor(lstSecurableObjects);
		captionForSecurableObjects.setAlignmentX(LEFT_ALIGNMENT);
		panelForSecurableObjects.add(captionForSecurableObjects);

		// Set up the Scroll Pane for CFs
		JScrollPane scrollPaneForSecurableObjects =	new JScrollPane(lstSecurableObjects);
		Border borderForSecurableObjects = new CompoundBorder(marginBorder, bevelBorder);

		scrollPaneForSecurableObjects.setBorder(borderForSecurableObjects);
		scrollPaneForSecurableObjects.setAlignmentX(LEFT_ALIGNMENT);

		panelForSecurableObjects.add(scrollPaneForSecurableObjects);

		// Add both the Scroll Panes into the Split Pane 
		JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelForCFs,	panelForSecurableObjects);
		splitPane.setBorder(BorderFactory.createEmptyBorder());
		splitPane.setDividerLocation(125);
		splitPane.setDividerSize(1);
		splitPane.setOneTouchExpandable(false);
		panelForDerivedObjs.add(splitPane);
		setPreferredSize(new Dimension(600, 350));

		enableDisableControls();

		LOGGER.debug("Exiting initViewComponents");
	}

	@Override
    public void handleButtonClick(USMButtonTypeEnum type) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering handleButtonClick. Button Clicked is : " + type);
		}

		if (type.equals(USMButtonTypeEnum.BTN_TYPE_CLOSE)) {
			close();
		} else if (type.equals(USMButtonTypeEnum.BTN_TYPE_REMOVE)) {
			onRemoveBtnClicked();
		} else if (type.equals(USMButtonTypeEnum.BTN_TYPE_SYNC_NE)) {
			onSyncSecObjsBtnClicked();
		} else {
			LOGGER.error("Do not know how I got this button click. " + type);
		}

		LOGGER.debug("Exiting handleButtonClick.");
	}

	/**
	 * Helper function which is responsible for calling the interfaces on the Controller
	 * to remove particular CF(s) from USM 
	 */
	private void onRemoveBtnClicked() {
		LOGGER.debug("Entering onRemoveBtnClicked.");
		List<BSTransBicNetCFInfo> lstSelectedObjs = getSelectedCFs();
		if (lstSelectedObjs != null) {
			if (confirmCFsRemoval(lstSelectedObjs)) {
				getAssociatedController().sendReqToRemoveCFsFromUSM(lstSelectedObjs);
			}
		} else {
			LOGGER.error("Null returned from getSelectedCFs");
		}
		LOGGER.debug("Exiting onRemoveBtnClicked.");
	}

	/**
	 * Helper function that is responsible for synchronizing the Securable Object
	 * between the CF and the USM
	 */
	private void onSyncSecObjsBtnClicked() {
		LOGGER.debug("Entering onSyncSecObjsBtnClicked.");
		List<BSTransBicNetCFInfo> lstSelectedObjs = getSelectedCFs();
		if (lstSelectedObjs != null) {
			getAssociatedController().sendReqToSyncSecurableObjs(lstSelectedObjs);
		} else {
			LOGGER.error("Null returned from getSelectedCFs");
		}
		LOGGER.debug("Exiting onSyncSecObjsBtnClicked.");
	}

	/**
	 * Function which will be called by the Client Controller when it recieves information
	 * about the Securable Object(s) that are managed by a particular CF
	 * 
	 * @param cf - 
	 * 			The CF for which the securable object(s) have been retrieved
	 * 
	 * @param lstSecObjs -
	 * 			The List of Securable Object(s) that are managed by the Server.
	 */
	void updateSecurableObjectList(BSTransBicNetCFInfo cf, List<BSSecurableObject> lstSecObjs) {
		LOGGER.debug("Entering updateSecurableObjectList. CF : {} Securable Objects : {}", cf, lstSecObjs);

		modelSecurableObjects.clear();
		lstSecObjs.forEach(secObj -> modelSecurableObjects.addElement(secObj));

		LOGGER.debug("Exiting updateSecurableObjectList");
	}

	/**
	 * Helper function to retrieve the CF(s) that are currently selected in the
	 * List and returning them
	 * 
	 * @return The List which contains the CF(s) that are selected in the JfxList
	 */
	private List<BSTransBicNetCFInfo> getSelectedCFs() {
        List<BSTransBicNetCFInfo> lstObjs = null;
        List<BSTransBicNetCFInfo> selectedObj = lstCFs.getSelectedValuesList();

        if (selectedObj != null) {
            lstObjs = new ArrayList<>();
			lstObjs.addAll(selectedObj);
        }
        return lstObjs;
    }

	/**
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getComponent()
	 */
	@Override
    public JComponent getComponent() {
		return this;
	}


	/**
	 * Function called by the Client Controller when it has the result
	 * of retrieving the CF(s) that are configured within USM
	 * 
	 * @param lstConfCFs  The List of CF(s) that are configured within USM
	 */
	void updateConfigCFsList(List<BSTransBicNetCFInfo> lstConfCFs) {
		LOGGER.debug("Entering updateConfigCFsList. Adding elements : {}", lstConfCFs);

		modelConfiguredCFs.clear();
		lstCFs.setModel(modelConfiguredCFs);

		lstConfCFs.forEach(cf -> modelConfiguredCFs.addElement(cf));

		//enableDisableControls();
		LOGGER.debug("Exiting updateConfigCFsList.");
	}

	/**
	 * @see javax.swing.event.ListSelectionListener#valueChanged(javax.swing.event.ListSelectionEvent)
	 */
	@Override
    public void valueChanged(ListSelectionEvent evt) {
		LOGGER.debug("Entering valueChanged.");
		// Multiple events are sent when an object is selected in the list.
		// Rather then react to all the events, we shall react only to the one 
		// which is the last. 
		if (!evt.getValueIsAdjusting() && !deleteInProgress ) {
            enableDisableControls();

			if (null != lstCFs) {
                List<BSTransBicNetCFInfo> listOfSel = lstCFs.getSelectedValuesList();
                if (listOfSel.size() == 1) {
                    BSTransBicNetCFInfo cfInfo = listOfSel.get(0);
                    onSelectionChangeInListOfCFs(cfInfo);
                } else {
                    modelSecurableObjects.clear();
                }
            }
        }
		LOGGER.debug("Exiting valueChanged.");
	}

	/**
	 * This function is invoked, when the operator selects an CF from
	 * the Main view. This function is also invoked when the an existing selected
	 * CF is unselected and a  new selection of CF is done.
	 * @param selectedCF The newly selected CF
	 */
	private void onSelectionChangeInListOfCFs(BSTransBicNetCFInfo selectedCF) {
		LOGGER.debug("Entering onSelectionChangeInListOfCFs. CF selected is : {}", selectedCF);

		getAssociatedController().sendReqToGetSecObjsForCF(selectedCF);

		LOGGER.debug("Exiting onSelectionChangeInListOfCFs");
	}

	/**
	 * Helper function to return the Associated Controller. This is correctly type casted 
	 * to the correct type so that it can be used.
	 * 
	 * @return BSCFClientController 
	 * 			The Client Controller associated with the View.
	 */
	private BSCFClientController getAssociatedController() {
		return (BSCFClientController) associatedClientController;
	}

	/**
	 * Helper function to help enable and disable of the controls depending
	 * on the selection that has been made in the list
	 */
	@Override
    protected void enableDisableControls() {
        List<USMButtonTypeEnum> vecEnabledBtns = new ArrayList<>();
        List<USMButtonTypeEnum> vecDisabledBtns = new ArrayList<>();
        int nSelectedElms = lstCFs.getSelectedValuesList().size();

        switch (nSelectedElms) {
            case 0: {
                // No elems selected. Disable all.
                vecDisabledBtns.add(USMButtonTypeEnum.BTN_TYPE_REMOVE);
                vecDisabledBtns.add(USMButtonTypeEnum.BTN_TYPE_SYNC_NE);
                break;
            }
            case 1: {
                // 1 elem selected. Enable all.
                vecEnabledBtns.add(USMButtonTypeEnum.BTN_TYPE_REMOVE);
                vecEnabledBtns.add(USMButtonTypeEnum.BTN_TYPE_SYNC_NE);
                break;
            }
            default: {
                // Multiple elemts selected. Disable Enable Rest.
                vecEnabledBtns.add(USMButtonTypeEnum.BTN_TYPE_REMOVE);
                vecEnabledBtns.add(USMButtonTypeEnum.BTN_TYPE_SYNC_NE);
                break;
            }
        }

        enableSelectiveButtons(vecEnabledBtns);
        disableSelectiveButtons(vecDisabledBtns);
        //Call the base class for disabling buttons now for authorization
        //This will only disable the buttons based on authorization, nothing else
        performPermissionCheckForButtons();

	}

	/**
	 * This function is invoked by the client controller when it recieves a
	 * CF Inserted notification
	 * @param cf The CF which has been inserted.
	 */
	void cfInserted(BSTransBicNetCFInfo cf) {
		LOGGER.debug("Entering cfInserted. Inserting CF into View : {}", cf);
		modelConfiguredCFs.addElement(cf);
		LOGGER.debug("Exiting cfInserted.");
	}

	/**
	 * This function is invoked by the client controller when it recieves a
	 * CFs Removed notification
	 * @param lstCfs List of CFs that have been removed from USM control.
	 */
	void cfsRemoved(List<BSTransBicNetCFInfo> lstCfs) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering cfsRemoved. List is : " + lstCfs);
		}
		deleteInProgress = true;
		for (BSTransBicNetCFInfo obj : lstCfs) {
			modelConfiguredCFs.removeElement(obj);
		}
		deleteInProgress = false;

		modelSecurableObjects.clear();

		LOGGER.debug("Exiting cfsRemoved.");

	}

	/**
	 * This function is invoked by the client controller when it recieves a
	 * CF Name Change notification
	 * @param cf CF that have been renamed
	 */
	void cfNameChanged(BSTransBicNetCFInfo cf) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering cfNameChanged. List is : " + cf);
		}

		int nSize = modelConfiguredCFs.size();
		for (int nIndex = 0; nIndex < nSize; nIndex++) {
			BSTransBicNetCFInfo obj = modelConfiguredCFs.get(nIndex);
			if (obj.equals(cf)) {
				obj.setName(cf.getName());
			}
		}
		lstCFs.repaint();
		LOGGER.debug("Exiting cfNameChanged.");
	}

	/**
	 * This function is called when NEs are assigned to some domains.
	 * @param lstSecObjects The Securable Objects which have been assigned
	 */
	void sesAssignedToDomains(List<BSSecurableObject> lstSecObjects) {
		BSClientHelper.domainInfoChangedForSecObjects(lstSecurableObjects, lstSecObjects);
	}

	/**
	 * This function is called when NEs are assigned to some domains.
	 * @param lstSecObjects The Securable Objects which have been unassigned
	 */
	void sesUnAssignedToDomains(List<BSSecurableObject> lstSecObjects) {
		BSClientHelper.domainInfoChangedForSecObjects(lstSecurableObjects, lstSecObjects);
	}

	/**
	 * This function is invoked by the client controller when it recieves a
	 * CF Synchronized notification
	 * @param receivedCF The CF which has been synchronized
	 */
	void cfSynchronized(BSTransBicNetCFInfo receivedCF) {
		List<BSTransBicNetCFInfo> lstCFs = getSelectedCFs();
		// Only if the CF list is not null and only if a single
		// CF is selected, we go back and get the data. Otherwise,
		// if multiple CFs are selected, then the SecurableObject(s) list
		// is blank
		if ((lstCFs != null) && (lstCFs.size() == 1)) {
			BSTransBicNetCFInfo cf = lstCFs.get(0);
			if (cf.equals(receivedCF)) {
				onSelectionChangeInListOfCFs(cf);
			}
		}
	}

	/**
	 * This class is used for the display of the CFs in the List Box.
	 * This is needed since we have special Icons that will be associated with
	 * the CFs.
	 */
	private class BSCFListCellRenderer extends JfxLabel implements ListCellRenderer<BSTransBicNetCFInfo> {

		private static final long serialVersionUID = -1348248953180752709L;

		/**
		 * @see javax.swing.ListCellRenderer#getListCellRendererComponent(javax.swing.JList, java.lang.Object, int, boolean, boolean)
		 */
		@Override
        public Component getListCellRendererComponent(JList list, BSTransBicNetCFInfo value, int index, boolean isSelected, boolean cellHasFocus) {
			// Since this method would be called many times, the tracing
			// has not been added
			setText(value.toString());
			Icon img = ResourcesIconFactory.ICON_LIST_SERVER_16;
			// Set the icon here.
			setIcon(img);

			if (isSelected) {
				setBackground(list.getSelectionBackground());
				setForeground(list.getSelectionForeground());
			} else {
				setBackground(list.getBackground());
				setForeground(list.getForeground());
			}
			setEnabled(list.isEnabled());
			setFont(list.getFont());
			setOpaque(true);

			return this;
		}
	}

	/**
	 * Function to display an error message to the operator
	 * @param strError Erros message that should be displayed.
	 */
	void displayErrorMessage(String strError) {
		JfxOptionPane.showMessageBox(this, strError);
	}

	/**
	 * Helper function to confirm whether a CF should be removed or not.
	 * @param lstCFs List of CFs that are to be removed.
	 * @return Indicates the choice of the operator. True indicates Remove.
	 */
	private boolean confirmCFsRemoval(List<BSTransBicNetCFInfo> lstCFs) {
		boolean bOp = false;
		String strMessage;

		if (1 == lstCFs.size()) {
			strMessage = USMStringTable.IDS_BS_ADMIN_WND_CONFIRM_SINGLE_CFS_REMOVAL.toString()	+ "'" + lstCFs.get(0).toString() + "'?";
		} else {
			strMessage = USMStringTable.IDS_BS_ADMIN_WND_CONFIRM_CFS_REMOVAL.toString() + lstCFs.size() + JfxStringTable.getString(USMStringTable.IDS_BS_CFS);
		}

		String strTitle = USMStringTable.IDS_BS_ADMIN_WND_CONFIRM_CFS_REMOVAL_TITLE.toString();

		int nRetVal = JfxOptionPane.showConfirmDialog(
				this,
				strMessage,
				strTitle,
				JfxOptionPane.YES_NO_OPTION
		);

		if (JfxOptionPane.YES_OPTION == nRetVal) {
			bOp = true;
		}

		return bOp;
	}

	/**
	 * Function called by the Controller when new Objects are registered for a CF
	 * @param receivedCF The CF for which objects have been registered
	 * @param lstSecObjs The newly available Objects
	 */
	void secObjsRegisteredForCF(BSTransBicNetCFInfo receivedCF, List<BSSecurableObject> lstSecObjs) {
		List<BSTransBicNetCFInfo> lstObjs = getSelectedCFs();
		// We only have to worry if there is a single selection. This is so coz
		// Only then Securable Objects are displayed in the Right Pane.
		if (lstObjs.size() == 1) {
			BSTransBicNetCFInfo cfSelected = lstObjs.get(0);
			if (receivedCF.equals(cfSelected)) {
				// Check then if the selected CF is the same as the CF for which Sec Obj has been added.
				// If it is then add the Sec Obj blindly.
				lstSecObjs.forEach(secObj -> modelSecurableObjects.addElement(secObj));
			}
		}
	}

	/**
	 * Function called by the Controller when Objects are unregistered from a CF
	 * @param receivedCF The CF for which objects have been unregistered
	 * @param lstSecObjs The removed Objects
	 */
	void secObjsUnRegisteredForCF(BSTransBicNetCFInfo receivedCF, List<BSSecurableObject> lstSecObjs) {
		List<BSTransBicNetCFInfo> lstObjs = getSelectedCFs();
		// We only have to worry if there is a single selection. This is so coz
		// Only then Securable Objects are displayed in the Right Pane.
		if (lstObjs.size() == 1) {
			BSTransBicNetCFInfo cfSelected = lstObjs.get(0);
			if (receivedCF.equals(cfSelected)) {
				// Check then if the selected CF is the same as the CF for which Sec Obj has been added.
				// If it is then add the Sec Obj blindly.
				lstSecObjs.forEach(secObj -> modelSecurableObjects.removeElement(secObj));
			}
		}
	}

	/**
	 * Function to return the Icon that is associated with this View.
	 * @return Icon The Icon that should be used
	 */
	@Override
    public Icon getIcon() {
		return ResourcesIconFactory.ICON_LIST_SERVER_16;
	}

	/**
	 * Function called by the Client Interactor when it receives a notification
	 * that the names of some securable objects have changed
	 * @param receivedCF The CF which owns the objects who's name has changed
	 * @param lstSecObjs The List of securable objects who's name has changed
	 */
	void secObjsNameChangedForCF(BSTransBicNetCFInfo receivedCF, List<BSSecurableObject> lstSecObjs) {
		List<BSTransBicNetCFInfo> lstObjs = getSelectedCFs();
		// We only have to worry if there is a single selection. This is so coz
		// Only then Securable Objects are displayed in the Right Pane.
		if ((lstObjs != null) && (lstObjs.size() == 1)) {
			BSTransBicNetCFInfo cfSelected = lstObjs.get(0);
			if (receivedCF.equals(cfSelected)) {
				int noOfElms = modelSecurableObjects.size();

				for (int idx = 0; idx < noOfElms; idx++) {
					BSSecurableObject secObj = modelSecurableObjects.getElementAt(idx);

					for (BSSecurableObject elmChanged : lstSecObjs) {
						if (secObj.equals(elmChanged)) {
							secObj.setDisplayName(elmChanged.getDisplayName());
							break;
						}
					}
				}
			}
			lstSecurableObjects.repaint();
		}
	}

    @Override
    public boolean isDockable() {    
        return false;
    }
}
