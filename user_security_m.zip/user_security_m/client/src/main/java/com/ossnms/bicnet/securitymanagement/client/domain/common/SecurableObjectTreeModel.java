package com.ossnms.bicnet.securitymanagement.client.domain.common;

import javax.swing.tree.DefaultTreeModel;

/**
 * Securable objects are sorted alphabetically. Securable containers are grouped before securable objects, also sorted.
 * For this mechanism to work, nodes have to be inserted through the model.
 */
class SecurableObjectTreeModel extends DefaultTreeModel {

	private static final long serialVersionUID = 3312377728661350108L;

	SecurableObjectTreeModel() {
		super(new SecurableObjectTreeNode());
	}

	SecurableObjectTreeNode getRootNode(){
		return (SecurableObjectTreeNode) super.getRoot();
	}

	void insertNodeInto(SecurableObjectTreeNode newChild, SecurableObjectTreeNode parent) {
		super.insertNodeInto(newChild, parent, parent.getChildCount());
	}
}
