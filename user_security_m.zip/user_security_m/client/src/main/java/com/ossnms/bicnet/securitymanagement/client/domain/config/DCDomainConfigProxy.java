/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCDomainConfigProxy
 * Author      	Asif Khan R, Jogender
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CONFIG   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 10-Feb-2005	Asif 			CF000834 - Command Log Entries 
 * 14-June-2005  Asif  CF000209 - Changes in the ISecurityProviderFacade / IManagedObject
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain.config;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMBaseController;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.domain.job.DCDeleteDomainJob;
import com.ossnms.bicnet.securitymanagement.client.domain.job.DCGetAllDomainsJob;
import com.ossnms.bicnet.securitymanagement.client.domain.job.DCGetObjectsOfDomainForServerJob;
import com.ossnms.bicnet.securitymanagement.client.domain.job.DCGetObjectsOfDomainJob;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSMessageType;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObjectContainer;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCHelper;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessageType;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;
import org.apache.log4j.Logger;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

/**
 * This is the main client interactor component which controls the domain configuration operation in the client side.
 */
class DCDomainConfigProxy extends USMBaseController {
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(DCDomainConfigProxy.class);

    /**
     * This is the constructor
     * 
     * @param view - This is the view associated with the interactor
     */
    DCDomainConfigProxy(DCDomainConfigView view) {
        super(view);
        registerInterestedNotificationIds(getInterestedNotifications());
    }

    /**
     * Function to return a Vector which contains the list of types that this controller is interested in.
     * 
     * @return List - The List which contains the notification the controller is interested in.
     */
    private List<USMBaseMsgType> getInterestedNotifications() {
        LOGGER.debug("getInterestedNotifications() - Enter");

        // Fault 108
        List<USMBaseMsgType> vectorForNotification = new ArrayList<>();
        vectorForNotification.add(DCMessageType.DC_NOT_DOMAIN_CREATED);
        vectorForNotification.add(DCMessageType.DC_NOT_DOMAIN_DELETED);
        // This is needed for domain modification, as when the modify domain
        // is clicked, the domain data is fetched from this window only
        vectorForNotification.add(DCMessageType.DC_NOT_DOMAIN_MODIFIED);

        vectorForNotification.add(BSMessageType.BS_NOT_CF_NAME_CHANGED);
        vectorForNotification.add(BSMessageType.BS_NOT_CF_SYNCED_WITH_SEC_OBJS);
        vectorForNotification.add(BSMessageType.BS_NOT_CF_REMOVED);
        vectorForNotification.add(BSMessageType.BS_NOT_CF_INSERTED);
        vectorForNotification.add(BSMessageType.BS_NOT_SEC_OBJS_ASSIGNED_TO_DOMAINS);
        vectorForNotification.add(BSMessageType.BS_NOT_SEC_OBJS_UNASSIGNED_FROM_DOMAINS);
        vectorForNotification.add(BSMessageType.BS_NOT_NEW_SEC_OBJ_REGISTERED);
        vectorForNotification.add(BSMessageType.BS_NOT_SEC_OBJ_UNREGISTERED);
        vectorForNotification.add(BSMessageType.BS_NOT_SEC_OBJ_CHANGED);
        vectorForNotification.add(BSMessageType.BS_NOT_SEC_OBJ_CONTAINER_CHANGE);

        LOGGER.debug("getInterestedNotifications() - exit");
        return vectorForNotification;
    }

    /**
     * This method retrieves all the servers whose securable objects belong to a particular domain.
     * 
     * @param domain - The information about the domain
     */
    void getFirstLevelObjectsOfDomain(DCDomainData domain) {
        LOGGER.debug("getObjectsForDomain(" + domain + ")		Enter");
        DCGetObjectsOfDomainJob job = new DCGetObjectsOfDomainJob(DCMessageType.DC_REQ_DOMAIN_DETAILS_SERVER_LEVEL, this, domain, true, true);
        queueJob(job);
        LOGGER.debug("getObjectsForDomain(" + domain + ")		Exit");
    }

    /**
     * This method retrieves all the domains that are created from the server.
     */
    void getAllDomains() {
        LOGGER.debug("getAllDomains() - Enter");
        DCGetAllDomainsJob job = new DCGetAllDomainsJob(DCMessageType.DC_REQ_DOMAINS, this);
        queueJob(job);
        LOGGER.debug("getAllDomains() - Exit");

    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIntf#handleNotification(com.ossnms
     * .bicnet.securitymanagement.common.basic.USMMessage)
     */
    @Override
    public void handleNotification(final USMMessage msg) {
        LOGGER.debug("handleNotification(" + msg + ")		Enter");

		if (null != associatedView) {
			SwingUtilities.invokeLater(() -> processNotificationMessage(msg));
		}

        LOGGER.debug("handleNotification(" + msg + ")		Exit");
    }

	/**
	 * This method must run in swing thread
	 */
    private void processNotificationMessage(final USMMessage msg) {
		USMBaseMsgType msgType = msg.getMessageType();
	
		if (msgType.equals(DCMessageType.DC_NOT_DOMAIN_CREATED)) {
			handleNotifDomainCreated(msg);
		} else if (msgType.equals(DCMessageType.DC_NOT_DOMAIN_DELETED)) {
			handleNotifDomainDeleted(msg);
		} else if (msgType.equals(DCMessageType.DC_NOT_DOMAIN_MODIFIED)) {
			handleNotifDomainModified(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_CF_NAME_CHANGED)) {
			handleNotifServerNameModified(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_CF_SYNCED_WITH_SEC_OBJS) || msgType.equals(BSMessageType.BS_NOT_CF_INSERTED)) {
			handleNotifAppServerSynchronized(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_CF_REMOVED)) {
			handleNotifAppServerDeleted(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_SEC_OBJS_ASSIGNED_TO_DOMAINS)) {
			handleNotifObjectsAssigment(msg, true);
		} else if (msgType.equals(BSMessageType.BS_NOT_SEC_OBJS_UNASSIGNED_FROM_DOMAINS)) {
			handleNotifObjectsAssigment(msg, false);
		} else if (msgType.equals(BSMessageType.BS_NOT_NEW_SEC_OBJ_REGISTERED)) {
			handleNotifSecObjectRegistered(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_SEC_OBJ_UNREGISTERED)) {
			handleNotifSecObjectUnregistered(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_SEC_OBJ_CHANGED)) {
			handleNotifSecObjectChanged(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_SEC_OBJ_CONTAINER_CHANGE)) {
			handleNotifSecObjectContainerChanged(msg);
		} else {
			LOGGER.error("handleNotification() - Unknown message recieved " + msgType);
		}
	}

	/**
     * Helper function that will be called when the message informing that some securable objects have
     * changed is received
     * 
     * @param msg The message which contains the information about the name change
     */
    private void handleNotifSecObjectChanged(USMMessage msg) {
        LOGGER.debug("Entering handleNotifSecObjectChanged. Message is : " + msg);

        BSTransBicNetCFInfo cf = BSTransBicNetCFInfo.popMe(msg);
        List<BSSecurableObject> lstSecObjs = BSCommonHelper.popSecurableObjectsListFromMessage(msg);
        ((DCDomainConfigView) associatedView).modifySecObjects(cf, lstSecObjs);

        LOGGER.debug("Exiting handleNotifSecObjectChanged.");

    }
    
    /**
     * Helper function that will be called when the message informing that some securable Container objects has
     * changed is recieved
     * 
     * @param msg The message which contains the information about the changes
     */
    private void handleNotifSecObjectContainerChanged(USMMessage msg) {
            LOGGER.debug("Entering handleNotifSecObjectContainerChanged. Message is : " + msg);

        BSTransBicNetCFInfo cf = BSTransBicNetCFInfo.popMe(msg);
        List<BSSecurableObjectContainer> lstSecObjs = BSCommonHelper.popSecurableObjectContainersListFromMessage(msg);
        ((DCDomainConfigView) associatedView).modifySecurableObjectContainers(cf, lstSecObjs);
        
        LOGGER.debug("Exiting handleNotifSecObjectContainerChanged.");
    }
    

    /**
     * Helper function to handle the Securable objects removed notification
     * 
     * @param msg Message which contains information about the Securable Objects that have been removed.
     */
    private void handleNotifSecObjectUnregistered(USMMessage msg) {
        LOGGER.debug("Entering handleNotifSesUnRegistered. Message is : " + msg);

        BSTransBicNetCFInfo cf = BSTransBicNetCFInfo.popMe(msg);
        List<BSSecurableObject> lstSecObjs = BSCommonHelper.popSecurableObjectsListFromMessage(msg);
        ((DCDomainConfigView) associatedView).deleteSecObject(cf, lstSecObjs);

        LOGGER.debug("Exiting handleNotifSesUnRegistered.");

    }

    /**
     * Helper function to handle the Securable objects inserted notification
     * 
     * @param msg Message which contains information about the Securable Objects that have been added.
     */
    private void handleNotifSecObjectRegistered(USMMessage msg) {
        LOGGER.debug("Entering handleNotifSecObjectRegistered. Message is : " + msg);

        BSTransBicNetCFInfo cf = BSTransBicNetCFInfo.popMe(msg);
        List<BSSecurableObject> lstSecObjs = BSCommonHelper.popSecurableObjectsListFromMessage(msg);

        ((DCDomainConfigView) associatedView).addSecObject(cf, lstSecObjs);

        LOGGER.debug("Exiting handleNotifSecObjectRegistered.");

    }

    /**
     * @param msg the message to handle
     */
    private void handleNotifDomainModified(USMMessage msg) {
        LOGGER.debug("handleDomainCreatedNotif - Exit");

        DCDomainData domData = new DCDomainData();
        domData.popMe(msg);
        // Modify the domain from the list of domains
        ((DCDomainConfigView) associatedView).modifyDomain(domData);

        LOGGER.debug("handleDomainCreatedNotif - Exit");

    }

    /**
     * This method handles the "DC_Not_DomainCreated" notification. It directs the window to add the newly created
     * domain.
     * 
     * @param msg - Message containing the DCDomainData.
     */
    private void handleNotifDomainCreated(USMMessage msg) {
        LOGGER.debug("handleDomainCreatedNotif(" + msg + ")		Exit");

        DefaultListModel<DCDomainData> model = ((DCDomainConfigView) associatedView).getDomainListModel();
        DCDomainData domainData = new DCDomainData();
        domainData.popMe(msg);
        model.addElement(domainData);

        LOGGER.debug("handleDomainCreatedNotif(" + msg + ")		Exit");
    }

    /**
     * This method handles the "DC_Not_DomainDeleted" notification. The corresponding domain gets deleted from the
     * window.
     * 
     * @param msg - Message containing the deleted DCDomainData.
     */
    private void handleNotifDomainDeleted(USMMessage msg) {
        LOGGER.debug("handleDomainCreatedNotif(" + msg + ")		Exit");

        DCDomainData domData = new DCDomainData();
        domData.popMe(msg);
        // Delete the domain from the list of domains
        ((DCDomainConfigView) associatedView).deleteDomain(domData);

        LOGGER.debug("handleDomainCreatedNotif(" + msg + ")		Exit");
    }

    /**
     * This method handles the server name change notification from the subsystem AS. This method then delegates the
     * task of changing the server name to the window.
     * 
     * @param msg - Message containing the ASTransBicNetCFInfo data.
     */
    private void handleNotifServerNameModified(USMMessage msg) {
        BSTransBicNetCFInfo server = BSTransBicNetCFInfo.popMe(msg);
        // tell the client window to change the name of the server
        ((DCDomainConfigView) associatedView).bicnetServerRenamed(server);
    }

    /**
     * This method handles the notification about the application server being synchronized. In this case, NEs might
     * have been added or deleted from the app server.
     * 
     * @param msg - Message containing the ASTransBicNetCFInfo data.
     */
    private void handleNotifAppServerSynchronized(USMMessage msg) {
        BSTransBicNetCFInfo server = BSTransBicNetCFInfo.popMe(msg);
        // tell the client window to synch
        ((DCDomainConfigView) associatedView).bicnetServerSynched(server);

    }

    /**
     * This method handles the notification about NEs being assigned to a domain and NEs being removed from the domain.
     * 
     * @param msg - Message containing the list of ASTransNEInfo and a list of DCDomainData.
     * @param assigned - True value to indicate the NEs have been assigned to domains.
     */
    private void handleNotifObjectsAssigment(USMMessage msg, boolean assigned) {
        LOGGER.debug("handleNotifObjectsAssignment() - Enter");

        List<BSSecurableObject> vecNEs = new ArrayList<>();
        DCHelper.popSecurableObjects(msg, vecNEs);

        List<DCDomainData> vecDomains = new ArrayList<>();
        DCDomainData.popDomainsFromMessage(msg, vecDomains);

        ((DCDomainConfigView) associatedView).assignUnAssignNEsToDomainsNotifReceived(vecNEs, vecDomains, assigned);
        LOGGER.debug("handleNotifObjectsAssignment() - Exit");

    }

    /**
     * This method handles the notification about a application server being removed from global security. This method
     * forwards the server details to the window to delete the server.
     * 
     * @param msg - Message containing the ASTransBicNetCFInfo details.
     */
    private void handleNotifAppServerDeleted(USMMessage msg) {
        int nSer = msg.popInteger();
        for (int i = 0; i < nSer; ++i) {
            BSTransBicNetCFInfo server = BSTransBicNetCFInfo.popMe(msg);
            // tell the client window to change the name of the server
            ((DCDomainConfigView) associatedView).functionDeleted(server);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIntf#resultAvailable(com.ossnms.bicnet
     * .securitymanagement.client.basic.controller.jobs.USMJob, java.lang.Object)
     */
    @Override
    public void resultAvailable(USMJob job, final USMMessage message) {
        LOGGER.debug("resultAvailable(" + job + "," + message + ")		Enter");
        
		if (message != null) {
			SwingUtilities.invokeLater(() -> {
                USMBaseMsgType msgType = message.getMessageType();
                // Handling all domain response
                if (msgType.equals(DCMessageType.DC_RES_DOMAINS)) {
                    handleResponseGetAllDomains(message);
                } else if (msgType.equals(DCMessageType.DC_RES_DELETE_DOMAIN)) {
                    // Handling domains delete response
                    handleResponseDeleteSelectedDomains(message);
                } else if (msgType.equals(DCMessageType.DC_RES_DOMAIN_DETAILS_SERVER_LEVEL)) {
                    // Handling servers retrieve for selected domain
                    // response
                    handleResponseGetFirstLevelObjectsOfDomain(message);
                } else if (msgType.equals(DCMessageType.DC_RES_DOMAIN_DETAILS_OBJECT_LEVEL)) {
                    // Handling NEs retrieve for selected server response
                    handleResponseGetObjectsOfDomainForServer(message);
                }
            });
		}

        LOGGER.debug("resultAvailable(" + job + "," + message + ")		Exit");
    }

    /**
     * Handles the response for the expansion or getting the net elems of a domain for the chose server.
     * 
     * @param message Message which contains the domain which was modified.
     */
    private void handleResponseGetObjectsOfDomainForServer(USMMessage message) {
        LOGGER.debug("handleObjectsOfDomainForServerDetails(" + message + ")		Enter");

        Integer errorId = message.popInteger();
        // The domain might have been deleted from some other client.
        if (errorId.equals(DCMessages.DC_NO_ERROR)) {
            // pop this boolean, which is unused at the moment
            message.popBoolean();
            BSTransBicNetCFInfo ser = BSTransBicNetCFInfo.popMe(message);

            List<BSSecurableObject> secObjects = new ArrayList<>();
            DCHelper.popSecurableObjects(message, secObjects);

            ((DCDomainConfigView) associatedView).displayExpandedServerDetails(secObjects, ser);
        } else {
            ((DCDomainConfigView) associatedView).showErrorMessage(DCMessages.getInstance().getString(errorId));
        }

        LOGGER.debug("handleObjectsOfDomainForServerDetails(" + message + ")		Exit");
    }

    /**
     * This method handles the response to a domain getting deleted. The deleted domain gets removed from the list of
     * domains in the window.
     * 
     * @param msg - Message containing the DCDomainData of the domain that got deleted.
     */
    private void handleResponseDeleteSelectedDomains(USMMessage msg) {
        LOGGER.debug("handleDomainDeletedResponse() - Exit");

        boolean bSuccess = true;
        StringBuilder completeErrorMessage = new StringBuilder("Could not delete the following domains:\n");
        int nDomain = msg.popInteger();
        for (int nDx = 0; nDx < nDomain; ++nDx) {
            Integer nErrorId = msg.popInteger();
            DCDomainData dom = new DCDomainData();
            dom.popMe(msg);
            if (DCMessages.DC_NO_ERROR.equals(nErrorId)) {
                ((DCDomainConfigView) associatedView).deleteDomain(dom);
            }
            else if(DCMessages.DC_DOMAIN_MAPPED_ERROR.equals(nErrorId)){
            	bSuccess = false;
            	completeErrorMessage.append(dom.getDomainName());
            	completeErrorMessage.append(" - The domain is mapped");
            	completeErrorMessage.append("\n");
            }
            else {
                bSuccess = false;
                completeErrorMessage.append(dom.getDomainName());
                completeErrorMessage.append(": ");
                completeErrorMessage.append(DCMessages.getInstance().getString(nErrorId));
                completeErrorMessage.append("\n");
            }
        }

       	if (!bSuccess) {
       		((DCDomainConfigView) associatedView).showWarningMessage(completeErrorMessage.toString());
        }

        LOGGER.debug("handleDomainDeletedResponse() - Exit");
    }

    /**
     * This method handles the response of getting the server information of whose securable objects belong to the
     * domain
     * 
     * @param message - Message containing the server information that was retrieved from the server
     */
    private void handleResponseGetFirstLevelObjectsOfDomain(USMMessage message) {
        LOGGER.debug("handleAssignedObjectsReceived(" + message + ")		Enter");

        Integer errorId = message.popInteger();
        String errorMessage;

        if (DCMessages.DC_NO_ERROR.equals(errorId)) {
            List<BSTransBicNetCFInfo> unAssignedServerList = new ArrayList<>();
            DCHelper.popServersFromMessage(message, unAssignedServerList);

            List<BSTransBicNetCFInfo> serverAssignedList = new ArrayList<>();
            DCHelper.popServersFromMessage(message, serverAssignedList);

            // Show the list of available list of NEs to the domain
            ((DCDomainConfigView) associatedView).setFirstLevelList(serverAssignedList);
        } else {
            errorMessage = DCMessages.getInstance().getString(errorId);
            ((DCDomainConfigView) associatedView).showErrorMessage(errorMessage);
        }

        LOGGER.debug("handleAssignedObjectsReceived(" + message + ")		Exit");
    }

    /**
     * This method handles the response for getting the details of the domain from the server
     * 
     * @param msg - Message contains the list of domains that were retrieved from the server
     */
    private void handleResponseGetAllDomains(USMMessage msg) {
        LOGGER.debug("handleDomainsFetched() - Enter");

        List<DCDomainData> domains = new ArrayList<>();

        Integer errId = msg.popInteger();

        if (errId.equals(DCMessages.DC_NO_ERROR)) {
            DCDomainData.popDomainsFromMessage(msg, domains);

            ((DCDomainConfigView) associatedView).displayAllDomains(domains);
        } else {
            ((DCDomainConfigView) associatedView).showErrorMessage(DCMessages.getInstance().getString(errId));

        }

        LOGGER.debug("handleDomainsFetched() - Exit");
    }

    /**
     * Function called by the Window, when the operator selects some domains and presses the "Delete" button.
     * 
     * @param domainsForDeletion The List of Domains that are to be removed from USM.
     */
    boolean deleteSelectedDomains(List<DCDomainData> domainsForDeletion) {
        LOGGER.debug("sendRequestToDeletePolicies(" + domainsForDeletion + ")		Enter");

        DCDeleteDomainJob objJob = new DCDeleteDomainJob(DCMessageType.DC_REQ_DELETE_DOMAIN, this, domainsForDeletion);
        boolean bStatus = queueJob(objJob);

        LOGGER.debug("sendRequestToDeletePolicies(" + domainsForDeletion + ")		Exit : Return :" + bStatus);
        return bStatus;
    }

    /**
     * Send request to server for retrieving NEs for selected server.
     * 
     * @param serverNodeExpanded - selected server in tree to be expanded
     * @param domaindata - Domain detail to which server is belonging
     */
    void getObjectsOfDomainForServer(BSTransBicNetCFInfo serverNodeExpanded, DCDomainData domaindata) {
        LOGGER.debug("getObjectsOfDomainForServer(" + serverNodeExpanded + "," + domaindata + ")		Enter");

        DCGetObjectsOfDomainForServerJob job = new DCGetObjectsOfDomainForServerJob(DCMessageType.DC_REQ_DOMAIN_DETAILS_OBJECT_LEVEL, this, domaindata, true, serverNodeExpanded);
        queueJob(job);

        LOGGER.debug("getObjectsOfDomainForServer(" + serverNodeExpanded + "," + domaindata + ")		Exit");
    }
}
