/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   UAJobModifyUserGroup
 * Author:      Jogender
 * Substitute	Babu B
 * Created on	12-09-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER_GROUP.CONFIGURE 
 *       : TNMS.DX2.SM.USER_GROUP.ASSIGN
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration.job;

import java.util.List;

import org.apache.log4j.Logger;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.useradministration.UADelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserGroup;

/**
 * This class represents the job that is responsible for the modification of
 * the user group
 */
public class UAJobModifyUserGroup extends USMJob {
	/**
	 * Data member to hold user group information
	 */
	UAUserGroup userGroupData = null;

	/**
	 * Data member to hold assigned users to user group
	  */
	List<String> usersForUserGroup = null;

	/**
	 * Holds the mappings to assign/unassign to the user group (unassigned mappings use an invalid policy id: -1)
	 */
	List<DCDomainMapping> mappingsForUserGroup = null;
	
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(UAJobModifyUserGroup.class);

	/**
	 * This is the constructor
	 * 
	 * @param userGroup -
	 *            The user group object that is to be modified
	 * @param usersForUserGroup -
	 *            the list of users assigned to user group
	 * @param jobOwner -
	 *            The controller associated with the job
	 * @param mappingsForUserGroup List of domain and policy mappings to assign to the user group. 
	 */
	public UAJobModifyUserGroup(
		USMControllerIfc jobOwner,
		UAUserGroup userGroup,
		List<String> usersForUserGroup, List<DCDomainMapping> mappingsForUserGroup) {
		super(
			UAMessageType.S_UG_REQ_MODIFY_USER_GROUP,
			USMCommonStrings.EMPTY,
			USMCommonStrings.EMPTY,
			jobOwner);
		this.userGroupData = userGroup;
		this.usersForUserGroup = usersForUserGroup;
		this.mappingsForUserGroup = mappingsForUserGroup;
		
		Object[] arr = {userGroup};
		String str = USMStringTable.IDS_UG_JOB_MODIFY_USER_GROUPS.getFormatedMessage(arr);
		setName(str);
	}

	/**
	 * Executes the given job
	 *
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob#executeJob()
	 */
	@Override
    public USMMessage executeJob() {
		LOGGER.debug("executeJob() Enter");
		USMMessage msg =
			new UADelegate().modifyUserGroup(userGroupData, usersForUserGroup, mappingsForUserGroup);
		LOGGER.debug("executeJob() Exit");
		return msg;
	}

}
