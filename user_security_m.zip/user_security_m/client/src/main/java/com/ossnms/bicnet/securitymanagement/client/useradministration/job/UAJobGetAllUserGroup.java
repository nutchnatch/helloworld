/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   UAJobGetAllUserGroup
 * Author:      Jogender
 * Substitute	Babu B
 * Created on	12-09-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER_GROUP.VIEW       
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-Apr-2005	Asif			CF000834 - Command Log Entries	CF USM
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 * 06-May-2009  Nagaraddi S S    TD004578 - RQT-STDERR errors instead log4j's
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration.job;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.useradministration.UADelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import org.apache.log4j.Logger;

import java.rmi.RemoteException;
/**
 * This class represents the job that is responsible for getting all the user
 * groups
 */
public class UAJobGetAllUserGroup extends USMJob {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(UAJobGetAllUserGroup.class);

	/**
	 * This indicates, whether this method was called for 
	 * User Group window, in which case it has to be logged in command log, indicating the window was opened
	 * False value indicates, that the method was called from the create/modify user window
	*/
	private boolean forUserGroupWindow;

	/** This is the constructor
		 * 
		 * @param pJobOwner -
		 *            The controller associated with the job
		 * @param p_ForUserGroupWindow True value indicates that it was called from the user
		 * group administration window and it should be logged in command log indicating window
		 * was open
		 */
	public UAJobGetAllUserGroup(
		USMControllerIfc pJobOwner,
		boolean p_ForUserGroupWindow) {

		super(
			UAMessageType.S_UG_RES_GET_ALL_USERGROUPS,
			USMStringTable.IDS_UG_JOB_RETRIEVE_USER_GROUPS.toString(),
			USMCommonStrings.EMPTY,
			pJobOwner);
		forUserGroupWindow = p_ForUserGroupWindow;
		LOGGER.debug("in the constructor");
	}

	/**
	 * Executes the given job
	 *
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob#executeJob()
	 */
	@Override
    public USMMessage executeJob() throws BcbSecurityException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("executeJob() Enter");
		}
		USMMessage msg = null;
		try {
			msg = new UADelegate().getAllUserGroup(forUserGroupWindow);
		} catch (RemoteException e) {
			LOGGER.error("Exception :", e);
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("executeJob() Exit");
		}
		return msg;
	}
}