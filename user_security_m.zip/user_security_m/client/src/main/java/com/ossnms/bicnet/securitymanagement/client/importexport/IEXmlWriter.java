/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	IEXmlWriter
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	07-12-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Muyeen Munaver	CF000427 - Implementation of the XML import mechanism needed for the migration process
 * 10-Feb-2005	Muyeen 		CF001177 - User migrated have to change the default password next logon acording to FSPEC
 * 08-Aug-2005	Balasubramanya	CF002760 - 9320_MR_0291 Users, User Groups, Policies lose associations after import
 * 08-Aug-2005	Balasubramanya	CF002759 - 9320_MR_0289 Security information discarded for user after deletion and restore
 * 17-Aug-2005	Balasubramanya	CF002854 - user migration does not work
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.importexport;

import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCIEDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.importexport.IEDataObject;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAIEUserGroup;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * This class is responsible for writing all the XML related data to the
 * Root Element. Its work is only to write.
 */
class IEXmlWriter {

	/**
	 * Data member which will decide whether or not empty nodes are to be written.
	 */
	private static final boolean EXPORT_EMPTY_NODES = true;

	/**
	 * Data member to hold the singleton instance
	 */
	private static IEXmlWriter instance = new IEXmlWriter();

	/**
	 * Data member to do the Tracing
	 */
	private static final Logger LOGGER = Logger.getLogger(IEXmlWriter.class);

	/**
	 * Function to return the singleton instance.
	 * @return IEXmlReader
	 * 		The singleton instance of the class.
	 */
	public static IEXmlWriter getInstance() {
		return instance;
	}

	/**
	 * Function to write all the Users passed in the List to the Root Element
	 * @param rootElm The Root Element that should be used.
	 * @param users The List of Users that should be written to the Root Elm
	 * @return boolean Indicates whether it was possible to do the operation or not. True indicates success.
	 */
	public boolean writeUsers(Element rootElm, List users) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering writeUsers. List : " + users);
		}

		boolean bIsSuccess = false;
		Element userInfoElem =
			getFirstLevelElement(rootElm, IETagNames.USER_SECTION);
		if (null != userInfoElem) {
			int nNoUsers = users.size();
			for (int index = 0; index < nNoUsers; index++) {
				IEDataObject ieData = (IEDataObject) users.get(index);
				UAUser user = (UAUser) ieData.getDataObject();
				writeUserAttributes(userInfoElem, user);
			}
			bIsSuccess = true;
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting writeUsers. Returning : " + bIsSuccess);
		}
		return bIsSuccess;
	}

	/**
	 * Function to write all the UserGroups passed in the List to the Root Element
	 * @param rootElm The Root Element that should be used.
	 * @param lstUGs The List of UserGroups that should be written to the Root Elm
	 * @return boolean Indicates whether it was possible to do the operation or not. True indicates success.
	 */
	public boolean writeUserGroups(Element rootElm, List lstUGs) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering writeUserGroups. List : " + lstUGs);
		}

		boolean bIsSuccess = false;
		Element ugInfoElem =
			getFirstLevelElement(rootElm, IETagNames.USER_GROUP_SECTION);
		if (null != ugInfoElem) {
			int nNoUGs = lstUGs.size();
			for (int index = 0; index < nNoUGs; index++) {
				IEDataObject ieData = (IEDataObject) lstUGs.get(index);
				UAIEUserGroup ug = (UAIEUserGroup) ieData.getDataObject();
				writeUserGroupAttributes(ugInfoElem, ug);
			}

			bIsSuccess = true;
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting writeUserGroups. Returning : " + bIsSuccess);
		}
		return bIsSuccess;
	}

	/**
	 * Function to write all the Policies passed in the List to the Root Element
	 * @param rootElm The Root Element that should be used.
	 * @param lstPolicies The List of Policies that should be written to the Root Elm
	 * @return boolean Indicates whether it was possible to do the operation or not. True indicates success.
	 */
	public boolean writePolicies(Element rootElm, List lstPolicies) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering writePolicies. List : " + lstPolicies);
		}

		boolean bIsSuccess = false;
		Element policyInfoElem =
			getFirstLevelElement(rootElm, IETagNames.POLICIES_SECTION);
		if (null != policyInfoElem) {
			int nNoPol = lstPolicies.size();
			for (int index = 0; index < nNoPol; index++) {
				IEDataObject ieData = (IEDataObject) lstPolicies.get(index);
				PAPolicyData policy = (PAPolicyData) ieData.getDataObject();
				writePolicyAttributes(policyInfoElem, policy);
			}

			bIsSuccess = true;
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting writeDomains. Returning : " + bIsSuccess);
		}
		return bIsSuccess;
	}

	/**
	 * Function to write all the Domains passed in the List to the Root Element
	 * @param rootElm The Root Element that should be used.
	 * @param lstDomains The List of Domains that should be written to the Root Elm
	 * @return boolean Indicates whether it was possible to do the operation or not. True indicates success.
	 */
	public boolean writeDomains(Element rootElm, List lstDomains) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering writeDomains. List : " + lstDomains);
		}

		boolean bIsSuccess = false;
		Element domainInfoElem = getFirstLevelElement(rootElm, IETagNames.DOMAIN_SECTION);
		if (null != domainInfoElem) {
			int nNoDoms = lstDomains.size();
			
			for (int index = 0; index < nNoDoms; index++) {
				IEDataObject ieData = (IEDataObject) lstDomains.get(index);
				Map<DCDomainData, List<BSSecurableObject>> dcDom = (Map<DCDomainData, List<BSSecurableObject>>) ieData.getDataObject();
				writeDomainAttributes(domainInfoElem, dcDom);
			}
			bIsSuccess = true;
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting writeDomains. Returning : " + bIsSuccess);
		}
		return bIsSuccess;
	}

	/**
	 * Function to write all the Mappings passed in the List to the Root Element
	 * @param rootElm The Root Element that should be used.
	 * @param lstMappings The List of Mappings that should be written to the Root Elm
	 * @return boolean Indicates whether it was possible to do the operation or not. True indicates success.
	 */
	public boolean writeMappings(Element rootElm, List lstMappings) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering writeMappings. List : " + lstMappings);
		}

		boolean bIsSuccess = false;
		Element domainMappingInfoElem =
			getFirstLevelElement(rootElm, IETagNames.MAPPING_SECTION);
		if (null != domainMappingInfoElem) {
			int nNoOfMappings = lstMappings.size();
			for (int index = 0; index < nNoOfMappings; index++) {
				// Here is the section for writing the Mapping Data into the 
				// XML file.
				IEDataObject ieData = (IEDataObject) lstMappings.get(index);
				DCIEDomainMapping mapping =
					(DCIEDomainMapping) ieData.getDataObject();
				writeDomainMappingAttributes(domainMappingInfoElem, mapping);
			}
			bIsSuccess = true;
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting writeMappings. Returning : " + bIsSuccess);
		}
		return bIsSuccess;
	}

	/**
	 * Helper function to return the Sub-Element related to the 
	 * Section that we are interested in.
	 * @param rootElm The Root Element under which we have to search
	 * @param element The Name of the Element which has to be searched.
	 * @return Element Element which represents the Sub-Element that was expected.
	 */
	private Element getFirstLevelElement(
		Element rootElm,
		String element) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering getFirstLevelElement. Section : " + element);
		}

		Element elem = null;
		NodeList listOfElements = rootElm.getElementsByTagName(element);
		int nNoOfNodes = listOfElements.getLength();

		if (nNoOfNodes == 0) {
			//we should create DomainInfo element to the list
			elem = rootElm.getOwnerDocument().createElement(element);
			if (null != elem) {
				rootElm.appendChild(elem);
			} else {
				return elem;
			}
		} else {
			//Ideally only one such Element should be present
			elem = (Element) listOfElements.item(0);
		}

		return elem;
	}

	/**
	 * Helper function to write a single Policy object in to the xml file. The element
	 * object will point to the PolicyInfo Element. We have to create and append the
	 * Policy Element with all the sub fields.
	 * @param element The PolicyInfo Object to which the Policy is to be
	 * appeneded
	 * @param policy The Policy Object that has to be written to the xml file.
	 */
	private void writePolicyAttributes(Element element, PAPolicyData policy) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering writePolicyAttributes. Policy : " + policy);
		}

		Element elm = element.getOwnerDocument().createElement(IETagNames.POLICY);
		element.appendChild(elm);
		createAndAppendTextNode(
			elm,
			IETagNames.POLICY_NAME,
			policy.getPolicyName());
		createAndAppendTextNode(
				elm,
				IETagNames.POLICY_DESCRIPTION,
				policy.getPolicyDescription());

		List<PAPermissionData> lstPermissions = policy.getPermissionDataList();
		writeListOfElements(elm, lstPermissions, IETagNames.POLICY_PERMISSION);

		LOGGER.debug("Exiting writePolicyAttributes.");
	}

	/**
	 * Helper function to write a single User Group object in to the xml file. The element
	 * object will point to the UserGroups Element. We have to create and append the
	 * UserGroup Element with all the sub fields.
	 * @param element The UserGroups Object to which the UserGroup is to be appeneded
	 * @param ug The UserGroup Object that has to be written to the xml file.
	 */
	private void writeUserGroupAttributes(Element element, UAIEUserGroup ug) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering writeUserGroupAttributes. Policy : " + ug);
		}

		Element elm =
			element.getOwnerDocument().createElement(IETagNames.USER_GROUP);
		element.appendChild(elm);
		createAndAppendTextNode(
			elm,
			IETagNames.USER_GROUP_NAME,
			ug.getName());
		createAndAppendTextNode(
			elm,
			IETagNames.USER_GROUP_DESCRIPTION,
			ug.getDescription());

		List lstUsers = ug.getAssignedUsers();
		writeListOfElements(elm, lstUsers, IETagNames.USER_GROUP_USER);

		LOGGER.debug("Exiting writeUserGroupAttributes.");
	}

	/**
	 * Helper function to write a List of Objects. Used for writing "Menu" in Policy and
	 * "User" in UserGroup
	 * @param elm The Element under which the objects should be written
	 * @param lstElms The List of Objects which have to be written under the root.
	 * @param strTagName The Tag Name that should be used.
	 */
	private void writeListOfElements(
		Element elm,
		List<? extends Object> lstElms,
		String strTagName) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering writeListOfElements. List : "
					+ lstElms
					+ " Tag : "
					+ strTagName);
		}
		if ((lstElms == null) || (lstElms.size() == 0)) {
			createAndAppendTextNode(elm, strTagName, null);
		} else {
			for (Object lstElm : lstElms) {
				String val = lstElm.toString();
				createAndAppendTextNode(elm, strTagName, val);
			}
		}

		LOGGER.debug(("Eexiting writeListOfElements"));
	}

	/**
	 * Helper function to write a single Domain object in to the xml file. The element
	 * object will point to the DomainInfo Element. We have to create and append the
	 * Domain Element with all the sub fields.
	 * @param domSecElm The "DomainInfo" Element to which the domain is to be
	 * appended
	 * @param dom The actual domain object that is to be written to the xml file
	 */
	private void writeDomainAttributes(	Element domSecElm, Map<DCDomainData, List<BSSecurableObject>> dom) {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering writeDomainAttributes. Domain : " + dom);
		}

		try {

			for (Entry<DCDomainData, List<BSSecurableObject>> entryDomain : dom.entrySet()) {
				Element domElmDomain = domSecElm.getOwnerDocument().createElement(IETagNames.DOMAIN);
				domSecElm.appendChild(domElmDomain);
				
				DCDomainData domain = entryDomain.getKey();
				List<BSSecurableObject> cfSecurObj = entryDomain.getValue();
				
				createAndAppendTextNode(domElmDomain,	IETagNames.DOMAIN_NAME,	domain.getDomainName());
				createAndAppendTextNode(domElmDomain,	IETagNames.DOMAIN_DESCRIPTION, domain.getDomainDescr());
				
				for(BSSecurableObject securObject: cfSecurObj){
					createAndAppendTextNode(domElmDomain, IETagNames.SECURABLE_OBJECT, securObject.getDisplayName());
				}	
			}
			
		} catch (Exception ex) {
			LOGGER.error("Exception occured : " + ex);
		}

		LOGGER.debug("Exiting writeDomainAttributes.");
	}

	/**
	 * @param domMappingSecElm
	 * @param mapping
	 */
	private void writeDomainMappingAttributes(
		Element domMappingSecElm,
		DCIEDomainMapping mapping) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering writeDomainMappingAttributes. Mapping : "
					+ mapping);
		}

		try {
			Element mapElm =
				domMappingSecElm.getOwnerDocument().createElement(
					IETagNames.MAPPING);
			domMappingSecElm.appendChild(mapElm);
			createAndAppendTextNode(
				mapElm,
				IETagNames.MAPPING_USERGROUP,
				mapping.getUserGroup());
			createAndAppendTextNode(
				mapElm,
				IETagNames.MAPPING_DOMAIN_NAME,
				mapping.getDomainName());
			createAndAppendTextNode(
				mapElm,
				IETagNames.MAPPING_POLICY_NAME,
				mapping.getPolicyName());
		} catch (Exception ex) {
			LOGGER.error("Exception occured : " + ex);
		}

		LOGGER.debug("Exiting writeDomainMappingAttributes.");
	}

    /**
     * @param userSecElement
     * @param user
     */
    private void writeUserAttributes(Element userSecElement, UAUser user) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering writeUserAttributes. User : " + user);
        }

        try {
            Element usrElm = userSecElement.getOwnerDocument().createElement(IETagNames.USER_USER);
            userSecElement.appendChild(usrElm);
            createAndAppendTextNode(usrElm, IETagNames.USER_COMMON_NAME, user.getCommonName());
            createAndAppendTextNode(usrElm, IETagNames.USER_FIRST_NAME, user.getFirstName());
            createAndAppendTextNode(usrElm, IETagNames.USER_LAST_NAME, user.getLastName());
            createAndAppendTextNode(usrElm, IETagNames.USER_USER_NAME, user.getUserId());
			createAndAppendTextNode(usrElm, IETagNames.USER_TYPE, user.getAuthenticationType().name());
            createAndAppendTextNode(usrElm, IETagNames.USER_E_MAIL, user.getEmail());
            createAndAppendTextNode(usrElm, IETagNames.USER_TELEPHONE, user.getTelephoneNumber());
            createAndAppendTextNode(usrElm, IETagNames.USER_FAX, user.getFaxNumber());
            createAndAppendTextNode(usrElm, IETagNames.USER_EMPLOYEE_NUMBER, user.getEmployeeNumber());

            createAndAppendTextNode(usrElm, IETagNames.USER_PASSWORD_EXPIRES, String.valueOf(user.getPasswordExpires()));
            createAndAppendTextNode(usrElm, IETagNames.USER_PASSWDCHANGE_INTERVAL, String.valueOf(user.getPasswordChangeInterval()));

            createAndAppendTextNode(usrElm, IETagNames.USER_LAST_LOGIN, user.getLastLogOnTime());
            usrElm.setAttribute(IETagNames.USER_ACTIVATED, "" + user.isAccountActivated());

            createAndAppendTextNode(usrElm, IETagNames.USER_PASSWORD, user.getPassword());

            createAndAppendTextNode(usrElm, IETagNames.USER_CHANGEPASSWD_NEXTLOGON, Boolean.toString(user.isUserMustChangePassword()));
            createAndAppendTextNode(usrElm, IETagNames.USER_CANNOTCHANGE_PASSWORD, Boolean.toString(user.getUserCanNotChangePasswd()));

			createAndAppendTextNode(usrElm, IETagNames.USER_INACTIVITY_TIMEOUT_ENABLED, Boolean.toString(user.isInactivityTimeoutEnabled()));
			createAndAppendTextNode(usrElm, IETagNames.USER_INACTIVITY_TIMEOUT, Integer.toString(user.getInactivityTimeout()));

			createAndAppendTextNode(usrElm, IETagNames.USER_SESSION_RESTRICTION_ENABLED, Boolean.toString(user.isRestrictUserSessions()));
			createAndAppendTextNode(usrElm, IETagNames.USER_ALLOWED_USER_SESSIONS, Integer.toString(user.getSimultaneousUserSessions()));

			createAndAppendTextNode(usrElm, IETagNames.USER_EXPIRATION_DATE_ENABLED, Boolean.toString(user.isAccountExpires()));
			createAndAppendTextNode(usrElm, IETagNames.USER_EXPIRATION_DATE, Long.toString(user.getExpirationDate().getTime()));
        } catch (Exception ex) {
        	LOGGER.error("Exception occured : " + ex);
        }

        LOGGER.debug("Exiting writeUserAttributes.");
    }

	/**
	 * Helper function to write a Text Node to the xml file.
	 * @param element The Element to which this Text node is to be appended.
	 * @param nodeName The Name of the Node that is to be created and appeneded
	 * @param nodeValue The Text that should be associated with the Text Node.
	 */
    private void createAndAppendTextNode(Element element, String nodeName, String nodeValue) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering createAndAppendTextNode. Node Name : " + nodeName + " Value : " + nodeValue);
		}
		if (nodeValue == null) {
			nodeValue = "";
		}
		if (EXPORT_EMPTY_NODES) {
			try {
				Document doc = element.getOwnerDocument();
				Element elm = doc.createElement(nodeName);
				element.appendChild(elm);

				Text txtNode = doc.createTextNode(nodeName);
				txtNode.setNodeValue(nodeValue);
				elm.appendChild(txtNode);
			} catch (Exception ex) {
				LOGGER.error("Exception in createAndAppendTextNode. " + ex);
			}
		}
		LOGGER.debug("Exiting createAndAppendTextNode.");
	}
}