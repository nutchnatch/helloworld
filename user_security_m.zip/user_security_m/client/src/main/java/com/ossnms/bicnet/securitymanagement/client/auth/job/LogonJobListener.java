package com.ossnms.bicnet.securitymanagement.client.auth.job;

/**
 * Receive progress and status information about logon job. Events are called outside AWT thread.
 */
public interface LogonJobListener {
    void handleLoginSuccess();
    void handleLoginError(String errorMessage, String errorTitle, boolean recoverableError);
    void handleLoginProgress(String progressMessage);
    void handleLoginCancelled();
    void handleLoginCancelled(String errorMessage, String errorTitle);
}
