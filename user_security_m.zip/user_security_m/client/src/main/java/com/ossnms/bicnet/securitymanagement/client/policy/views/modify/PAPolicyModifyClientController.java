/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	PAPolicyModifyClientController
 * Author      	Vinay Purohit
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID	:	TNMS.DX2.SM.POLICY.ADMIN
 * 			
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 09-02-2005	Babu B          CF000060-01   CF USM GUI Requirements
 * 18-Mar-2005  Asif khan R     CF001755 Error Messages when LDAP not available
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.policy.views.modify;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMBaseController;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.policy.jobs.PAJobGetPolicyInformation;
import com.ossnms.bicnet.securitymanagement.client.policy.jobs.PAJobModifyPolicy;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.policy.PAMessageType;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import com.ossnms.bicnet.securitymanagement.common.policy.PAStatus;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * This Client Controller is responsible for interacting with the Server for
 * operations like Modify a Configured Policy.
 */
class PAPolicyModifyClientController extends USMBaseController {
	private PAPolicyModifyView modifyPolicyWdw;

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(PAPolicyModifyClientController.class);

	/**
	* Constructor
	* 
	* @param view The View which is responsible for the creation of this controller object.
	*/
	PAPolicyModifyClientController(PAPolicyModifyView view) {
		super(view);
		modifyPolicyWdw = view;
		registerInterestedNotificationIds(getInterestedNotifications());
	}

	/**
	 * Method which will be invoked by the View for sending a request to modify a policy
	 * @param policy The Policy Object which has to be modified.
	 * @return Indicates whether it was possible to send the request or not
	 */
	boolean sendRequestToModifyPolicy(PAPolicyData policy) {
		PAJobModifyPolicy objModifyJob = new PAJobModifyPolicy(this, policy);
		return queueJob(objModifyJob);
	}

	/**
	 * Helper function to return the List of Notification IDs which this controller is interested in.
	 * 
	 * @return  The List of Notification IDs that the controller is interested in
	 */
	private List<USMBaseMsgType> getInterestedNotifications() {
		List<USMBaseMsgType> notifications = new ArrayList<>();

//		notifications.add(PAMessageType.S_PA_NOT_SERVER_INSERTED);
//		notifications.add(PAMessageType.S_PA_NOT_SERVER_REMOVED);
		notifications.add(PAMessageType.S_PA_NOT_POLICY_MODIFIED);
		notifications.add(PAMessageType.S_PA_NOT_POLICY_DELETED);

		return notifications;
	}

	/**
	 *
	 * @param policyToBeModified to fetch permissions related information
	 * @return
	 */
	public boolean sendRequestToFetchPolicyInformation(PAPolicyId policyToBeModified) {
		PAJobGetPolicyInformation policyInformation = new PAJobGetPolicyInformation(this,policyToBeModified);
		return queueJob(policyInformation);
	}
	/**
	 * This method is the handler for the Response :
	 * PA_RES_GET_NONCONFIG_CONFIG_MENU_OPTIONS.
	 * 
	 * @param message The message which contains the configured and the non-configured menu entries.
	 */
	public void handleResponseGetNonConfigAndConfigMenuOptions(USMMessage message) {
		final String functionName = "treatResponseGetAllAvailableMenuOptions ( ) ";
		LOGGER.info(functionName + " ENTER_FUNCTION ");

		// Pop the Result of the Operation.
		PAStatus statusObject = PAStatus.pop(message);
		if (statusObject == PAStatus.S_SUCCESS) {
			List vecConfiguredMenuOptions = null;
			List vecAllAvailableMenuOptions = new ArrayList();

			// Pop the Count of Available Menu options ( STRINGS )
			int nCount = message.popInteger();

			LOGGER.info( functionName + "Number of Available Menu Options retreived from the Server : " + nCount);

			String csMenuOption = null;

			for (int idx = 0; idx < nCount; ++idx) {
				csMenuOption = message.popString();
				vecAllAvailableMenuOptions.add(csMenuOption);
			}
			// added to check vecConfiguredMenuOptions
			PAPolicyData pData = new PAPolicyData();
			pData.popMe(message);
			modifyPolicyWdw.setValueOfComponents(pData.getPolicyName(), pData.getPolicyDescription());

			modifyPolicyWdw.setPolicyData(pData);

//			vecConfiguredMenuOptions = pData.getConfiguredMenuList();

			modifyPolicyWdw.updateWindow(vecAllAvailableMenuOptions, vecConfiguredMenuOptions);
		} else {
			String csUserMessage = statusObject.getErrorString();
			modifyPolicyWdw.showMessage(modifyPolicyWdw, csUserMessage);
			LOGGER.error(functionName + "Error " + csUserMessage);
		}
		LOGGER.info(functionName + " EXIT_FUNCTION ");
	}


	public void handleResponseGetPolicyInformation(USMMessage message) {
		final String FUNC_NAME = "handleResponseGetPolicyInformation () ";
		LOGGER.info(FUNC_NAME + " ENTER_FUNCTION ");
//
		// Pop the Result of the Operation.
		PAStatus statusObject = PAStatus.pop(message);
		if (statusObject == PAStatus.S_SUCCESS) {

			PAPolicyData policyData = new PAPolicyData();
			policyData.popMe(message);

			List<PAPermissionData> availablePermissions = new ArrayList<>();
			List<PAPermissionData> configuredPermissions = policyData.getPermissionDataList();

			int countPermissions = message.popInteger();

			LOGGER.info( FUNC_NAME + "Number of Unused Permissions retrieved from the Server : " + countPermissions);


			for (int idx = 0; idx < countPermissions; ++idx) {
				PAPermissionData permissionData = new PAPermissionData();
				permissionData.popMe(message);
				availablePermissions.add(permissionData);
			}

			modifyPolicyWdw.setValueOfComponents(policyData.getPolicyName(), policyData.getPolicyDescription());
			modifyPolicyWdw.setPolicyData(policyData);

//			vecConfiguredMenuOptions = pData.getConfiguredMenuList();

			modifyPolicyWdw.updateWindow(availablePermissions, configuredPermissions);
		} else {
			String csUserMessage = statusObject.getErrorString();
			modifyPolicyWdw.showMessage(modifyPolicyWdw, csUserMessage);
			LOGGER.error(FUNC_NAME + "Error " + csUserMessage);
		}
		LOGGER.info(FUNC_NAME + " EXIT_FUNCTION ");
	}

	/**
	 * This method is the handler for the Response : PA_RES_MODIFY_POLICY.
	 * 
	 * @param message Message sent by the server on modification of a policy.
	 */
	public void handleResponseModifyPolicy(USMMessage message) {
		final String FUNC_NAME = "handleResponseModifyPolicy ( )";
		LOGGER.info(FUNC_NAME + " ENTER_FUNCTION ");

		// Pop the Result of the Operation.
		PAStatus statusObject = PAStatus.pop(message);

		String csUserMessage;

		if (statusObject == PAStatus.S_SUCCESS) {
			associatedView.close();
		} else {
			csUserMessage = statusObject.getErrorString();
			modifyPolicyWdw.showMessage(modifyPolicyWdw, csUserMessage);
			LOGGER.error(FUNC_NAME + "Error " + csUserMessage);
		}

		LOGGER.info(FUNC_NAME + " EXIT_FUNCTION ");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc#resultAvailable(
	 * com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob, java.lang.Object)
	 */
	@Override
    public void resultAvailable(USMJob job, USMMessage result) {
		USMBaseMsgType msgObj = result.getMessageType();
		if (msgObj.equals(PAMessageType.S_PA_RES_POLICY_CONFIGNONCONFIG_MENU_RECEIVED)) {
			LOGGER.info(" RESULT AVAILABLE");
			handleResponseGetNonConfigAndConfigMenuOptions(result);
		} else if (msgObj.equals(PAMessageType.S_PA_RES_POLICY_MODIFIED)) {
			LOGGER.info(" RESULT AVAILABLE FOR MODIFICATION");
			handleResponseModifyPolicy(result);
		} else if (msgObj.equals(PAMessageType.S_PA_RES_GET_POLICY_INFORMATION)) {
			LOGGER.info(" RESULT AVAILABLE FOR GET_POLICY_INFORMATION");
			handleResponseGetPolicyInformation(result);
		} else {
			LOGGER.info("result is not available ");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc#handleNotification(com.ossnms.bicnet.securitymanagement.common.basic.USMMessage)
	 */
	@Override
    public void handleNotification(USMMessage msg) {
		USMBaseMsgType type = msg.getMessageType();
		if (type.equals(PAMessageType.S_PA_NOT_POLICY_DELETED)) {
			handleNotificationPolicyDeleted(msg);
		} else if (type.equals(PAMessageType.S_PA_NOT_POLICY_MODIFIED)) {
			handleNotificationPolicyModified(msg);
		}
	}

	/**
	 * This method is the handler for the Notification : PA_NOTIFY
	 * POLICY_DELETED
	 * 
	 * @param message Message which contains information about the deleted Policy.
	 */
	private void handleNotificationPolicyDeleted(USMMessage message) {
		final String FUNC_NAME = "handleNotificationPolicyDeleted( )";
		LOGGER.debug(FUNC_NAME + " ENTER_FUNCTION");

		if (message == null) {
			LOGGER.error(FUNC_NAME + "notification message is null");
		} else {
			// Pop the number of deleted policies.
			int nDeletedPolicyCount = message.popInteger();

			List<PAPolicyId> vecDeletedPolicies = new ArrayList<>();
			for (int idx = 0; idx < nDeletedPolicyCount; ++idx) {
				PAPolicyId deletedPolicy = new PAPolicyId();
				deletedPolicy.popMe(message);
				vecDeletedPolicies.add(deletedPolicy);
			}

			((PAPolicyModifyView) associatedView).onPolicyDeleted(vecDeletedPolicies);
			LOGGER.debug(FUNC_NAME + " EXIT_FUNCTION");
		}
	}

	/**
	 * This method is the handler for the Notification : PA_NOTIFY
	 * POLICY_MODIFIED
	 * 
	 * @param message Message which contains information about the modified Policy
	 */
	private void handleNotificationPolicyModified(USMMessage message) {
		final String FUNC_NAME = "treatNotificationPolicyModified ( )";
		LOGGER.debug(FUNC_NAME + " ENTER_FUNCTION ");

		if (message == null) {
			LOGGER.error(FUNC_NAME + "notification message is null");
		} else {
			PAPolicyData modifiedPolicy = new PAPolicyData();
			modifiedPolicy.popMe(message);

			PAPolicyModifyView vw = (PAPolicyModifyView) associatedView;
			if (vw.selectedPolicy.getPolicyID() == modifiedPolicy.getPolicyID()) {
				sendRequestToFetchPolicyInformation(new PAPolicyId(modifiedPolicy.getPolicyID(), modifiedPolicy.getPolicyName()));
			}
		}

		LOGGER.debug(FUNC_NAME + " EXIT_FUNCTION");
	}
}