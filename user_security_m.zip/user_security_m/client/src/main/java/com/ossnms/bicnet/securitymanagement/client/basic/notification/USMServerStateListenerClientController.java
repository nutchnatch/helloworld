/*
 * Project	BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMServerStateListenerClientController
 * Author      	Muyeen M
 * Substitute	Babu B
 * Created on	20-05-2005
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : MMR
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.notification;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.securitymanagement.client.auth.AAClientCache;
import com.ossnms.bicnet.securitymanagement.client.auth.AAUserProfileCache;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandManager;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMBaseController;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.components.JfxDialog;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * This is the main client interactor component which controls the session 
 * on the client side. This class instance will be created on successful login
 * and register for interested notification.
 *
 */
public class USMServerStateListenerClientController extends USMBaseController {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(USMServerStateListenerClientController.class);

	/**
	 * It is Default constructor to register notification for security data cache to be rebuilt    
	 */
	//Fault ID 30
	USMServerStateListenerClientController() {
		super();

		//Policy or Mapping changes notification is subscribed for this handler
		List<USMBaseMsgType> lstInterestingNotifications = new ArrayList<USMBaseMsgType>();

		lstInterestingNotifications.add(USMBaseMsgType.BASIC_SERVER_SHUTDOWN);
		lstInterestingNotifications.add(USMBaseMsgType.BASIC_SERVER_REINITIALIZED);
		lstInterestingNotifications.add(USMBaseMsgType.CLOSE_WINDOWS_AFTER_LDAP_SYNC);

		USMNotificationRegistrar.getInstance().register(lstInterestingNotifications,this);

	}

	/**
	 * Handles notification recieved from the server. 
	 *
	 * @param  notifMsg Message received from the server wrapped in USMMessage
	 *
	 */
	@Override
    public void handleNotification(USMMessage notifMsg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"handleNotification(USMMessage p_NotifMsg = "
					+ notifMsg
					+ ") - entry");
		}
		USMBaseMsgType type = notifMsg.getMessageType();
		if (type.equals(USMBaseMsgType.BASIC_SERVER_REINITIALIZED)) {
			handleServerReInitialized(notifMsg);

		} else if (type.equals(USMBaseMsgType.BASIC_SERVER_SHUTDOWN)) {
			// Server has been shut down. So cleaup
			handleServerShutDown(notifMsg);

		} else if (type.equals(USMBaseMsgType.CLOSE_WINDOWS_AFTER_LDAP_SYNC)) {
			handleDataSync(notifMsg);

		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handleNotification(USMMessage) - exit");
		}

	}

	/**
	 * Function to handle Notification recieved for LDAP Data Sync after reconnect.
	 * @param notifMsg Message which contains information about the loaded OUs.
	 */
	private void handleDataSync(USMMessage notifMsg) {

		String strMessage =
			USMStringTable.IDS_WINDOWS_CLOSE_ON_LDAP_RECONNECT.toString();

		// Display Message
		JfxOptionPane.showMessageBox(null, strMessage);

		USMCommandManager.closeAllWindows();
	}

	/**
	 * Function to handle Notification received for server shutdown.
	 * @param msg Message which contains information about the server.
	 */
	private void handleServerReInitialized(USMMessage msg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"handleServerReInitialized(USMMessage pMsg = "
					+ msg
					+ ") - entry");
		}

		ISessionContext ctx = USMUtility.getInstance().getSessionContext();

		// Cleanup the client data
		USMCommandManager mgr = USMCommandManager.getInstance();
		int nNoOfCmds = mgr.getNumberOfActiveCmds();
		mgr.cleanup();

		String strInfo = "";
		if (nNoOfCmds > 0) {
			strInfo += USMStringTable.IDS_WINDOW_REOPEN;
		}

		strInfo += USMStringTable.IDS_WAIT_FOR_REFETCH;

		USMWaitForUpdateWindow updt = new USMWaitForUpdateWindow(strInfo);
		updt.setVisible(true);

		// Re-Initialize the Client Data
		AAClientCache.getInstance().rebuildCache(ctx);
		AAUserProfileCache.getInstance().getUserProfileCacheData(ctx);

		updt.dispose();

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handleServerReInitialized(USMMessage) - exit");
		}
	}

	/**
	 * Function to handle Notification recieved for server shutdown.
	 * @param msg Message which contains information about the server.
	 */
	private void handleServerShutDown(USMMessage msg) {
		try {
			USMUtility util = USMUtility.getInstance();
			IPluginSecurityProvider provider =
				util.getSecuritySite().getSecurityProvider();
			// Get the Server Name. Currently we do nothing coz the
			// name of the server could be in some format not understandable
			// by client.
			
			// popString() modifies the message
			msg.popString();

			provider.logoff(util.getSecureClientSession(), IPluginSecurityProvider.LogoffReason.SERVER_SHUTDOWN);

		} catch (BiCNetPluginException ex) {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("handleServerShutDown. Exception " + ex);
			}
		}
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc#resultAvailable(com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob, com.ossnms.bicnet.securitymanagement.common.basic.USMMessage)
	 */
	@Override
    public void resultAvailable(USMJob job, USMMessage result) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("resultAvailable. There's something fishy here.");
		}
	}

}

/**
 * Window to show progress & status in case of LDAP disconnect & refetch after reconnnect.
 */
class USMWaitForUpdateWindow extends JfxDialog {

	private static final long serialVersionUID = 4387386221504124959L;

	/**
	 * Constructor
	 * @param info Information to be displayed
	 */
	public USMWaitForUpdateWindow(String info) {
		super();
		setModal(false);
		setTitle(USMStringTable.IDS_SERVER_REINITIALIZED);
		initComponents();
		progressBar.setIndeterminate(true);
		textArea.setText(info);
		setSize(475, 150);
		setResizable(false);
		setDefaultCloseOperation(javax.swing.JDialog.DO_NOTHING_ON_CLOSE);
		//"All Security windows will be closed because the data has changed on the server. \nPlease reopen the windows manually. \n\nPlease wait while the security data is re-fetched.");
	}

	/** This method is called from within the constructor to
	 * initialize the form.
	 */
	private void initComponents() {
		progressBar = new javax.swing.JProgressBar();
		textArea = new javax.swing.JTextArea();

		setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
		getContentPane().add(progressBar, java.awt.BorderLayout.SOUTH);

		getContentPane().add(textArea, java.awt.BorderLayout.CENTER);

		pack();
	}

	/*
	 * Progress bar to show ldap sync progress
	 */
	private javax.swing.JProgressBar progressBar;

	/*
	 * Text box to show mesage after ldap sync
	 */
	private javax.swing.JTextArea textArea;
}