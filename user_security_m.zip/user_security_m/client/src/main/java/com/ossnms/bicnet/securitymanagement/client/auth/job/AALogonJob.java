/*
 * --------------------------------------------------------
 *
 * Project: TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   AALogonJob
 * Author:      Babu B
 * Substitute   Muyeen Munaver
 * Created on   15-03-2005
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.CLIENT.AUTHORIZE
 *      :
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 22-Mar-2005	Muyeen Munaver	CF0001791 - Problems with Login
 * 30-Mar-2005	Muyeen Munaver	CF001854 - Installations with customized ports do not work with build 14 *
 * 14-Apr-2005	Muyeen Munaver	CF001977 - no timeout for Login window => Login window can remain opened forever
 * 21-Apr-2005	Muyeen Munaver	CF001882 - Performance icons should appear on status bar of DX client
 * 10-May-2005	Muyeen Munaver	CF002170 - Resolve the Host name into the IP address fails
 * 10-May-2005	Muyeen Munaver	CF002055 - Advisory Message with wrong last login (Time display option)
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 * 14-June-2005 Muyeen Munaver  CF002457 - Manual Export not working
 * 11-Jan-2006  Balasubramanya  CF002773 - Missing correct computer name in window User Administration
 * 21-Mar-2006	Balasubramanya	CF003548 - Prohibit connection between DX clients and DX server w/ different version/build
 * 05-Sept-2006	Shrinidhi G V	CF004292 - Login fail + Login with success => message in "Open Transactions"
 * 25-Nov-2006	Shrinidhi G V	CF004360 - Product/Version mismatch window ==> has null value
 * 07-Mar-2006	Balasubramanya	CF003764 - Impossible to login to different server then localhost:1099
 * 10-Mar-2006	Balasubramanya	CF002657-01	CES688: Missing hint with different versions of server and client
 * 19-Nov-2007	Shrinidhi G V	DX00135 - Server/Client w/different versions=>warn msg dialog w/Wrong Server/Client versio
 * 18-12-2008   Shilpa S        FX000201 - Log in window should be focused to password field always..
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.auth.job;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ISecurityMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.BiCNetProductType;
import com.ossnms.bicnet.bcb.model.scs.ScsServerErrorCondition;
import com.ossnms.bicnet.bcb.model.security.AccountExpiredException;
import com.ossnms.bicnet.bcb.model.security.AccountLicenseException;
import com.ossnms.bicnet.bcb.model.security.AccountLockedException;
import com.ossnms.bicnet.bcb.model.security.ActiveDirectoryUserGroupModificationException;
import com.ossnms.bicnet.bcb.model.security.ActiveDirectoryUserGroupsNotAvailableException;
import com.ossnms.bicnet.bcb.model.security.AuthorizationFailedException;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.bcb.model.security.InvalidCredentialsException;
import com.ossnms.bicnet.bcb.model.security.InvalidInitializationStateException;
import com.ossnms.bicnet.bcb.model.security.MaxSessionsReachedException;
import com.ossnms.bicnet.bcb.model.security.UserAccountDisabledException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientLogSeverity;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientProperties;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginServerAccessController;
import com.ossnms.bicnet.framework.client.notificationpopup.NotificationPopupDetails;
import com.ossnms.bicnet.framework.client.notificationpopup.NotificationPopupDetails.OpStatus;
import com.ossnms.bicnet.framework.client.notificationpopup.NotificationPopupManager;
import com.ossnms.bicnet.securitymanagement.client.SMSettingsProperties;
import com.ossnms.bicnet.securitymanagement.client.SecurityPlugin;
import com.ossnms.bicnet.securitymanagement.client.auth.AAAdvisoryMessageView;
import com.ossnms.bicnet.securitymanagement.client.auth.AAClientCache;
import com.ossnms.bicnet.securitymanagement.client.auth.AALoginBusinessDelegate;
import com.ossnms.bicnet.securitymanagement.client.auth.AALogonHistoryController;
import com.ossnms.bicnet.securitymanagement.client.auth.AAServerSessionTimer;
import com.ossnms.bicnet.securitymanagement.client.auth.AASessionClientController;
import com.ossnms.bicnet.securitymanagement.client.auth.AAUserProfileCache;
import com.ossnms.bicnet.securitymanagement.client.auth.update.ClientUpdateProcessBuilder;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.client.useradministration.UADelegate;
import com.ossnms.bicnet.securitymanagement.common.auth.exception.AAKerberosAuthenticationException;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityAuthenticationPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.servicelocator.USMServiceLocator;
import com.ossnms.bicnet.servicelocator.BiCNetServiceLocator;
import com.ossnms.bicnet.util.UnexpectedException;
import com.ossnms.tnms.securitymanagement.client.settings.SecuritySettingsManager;
import com.ossnms.tnms.securitymanagement.client.util.USMMessages;
import com.ossnms.tnms.securitymanagement.client.util.USMResourceBundleConstants;
import com.ossnms.tools.jfx.JfxText;
import com.ossnms.tools.jfx.components.JfxButton;
import org.ietf.jgss.GSSException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.security.auth.Subject;
import javax.security.auth.login.LoginException;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.SocketException;
import java.security.PrivilegedActionException;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

/**
 * This class represents a job that is responsible for the login & all related tasks such as fetching authorization data,
 * profile data & displaying the initial advisory message.
 */
public class AALogonJob extends USMJob {

    /**
     * Data member for the Logging of the class.
     *
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(AALogonJob.class);

    private static final String APPLICATION_NAME_TNMS = USMUtility.getInstance().getSecuritySite().getClientProperty(BiCNetPluginClientProperties.CLIENT_NAME_FOR_IMAGE, null);
    private static final String LOGIN_WAS_FAILURE = "Login was failure";

    private static final boolean RECOVERABLE_ERROR = true;
    private static final boolean UNRECOVERABLE_ERROR = !RECOVERABLE_ERROR;
    private static final String PATH_CURRENT_DIRECTORY = ".";

    private final LogonJobListener listener;

    /**
     * Attribute to store the server host name
     */
    private String serverHostName;

    /**
     * Attribute to store the user name
     */
    private String userName;

    /**
     * Attribute to store the user password
     */
    private String strPassword;

    /**
     * Attribute to store the sso login subject
     */
    private Subject ssoSubject;

    // Constants
    private static final String SERVER_LOCAL_HOST = "localhost";

    // Field to store the server product type
    private BiCNetProductType serverProductType;
    // Field to store the server version
    private String serverVersion;
    
    private String clientVersion;
    
    // Boolean to decide whether login has to performed
    private boolean loginToBePerformed = false;
    
    private boolean actionCancelCalled = false;

    /**
     * Constructor
     * @param jobOwner Controller instance
     * @param listener logon progress and status listener
     */
    public AALogonJob(USMControllerIfc jobOwner, LogonJobListener listener) {
        super(USMBaseMsgType.BASIC_LDAP_RECONNECT, USMStringTable.IDS_AA_LOGIN_JOB_NAME.toString(), USMCommonStrings.EMPTY, jobOwner);
        LOGGER.debug("AALogonJob() - Entry");
        this.listener = listener;
        LOGGER.debug("AALogonJob() - Exit");
    }

    /**
     * This method gets the server product type and version from the @P SCS and
     * sets it.<br>
     */
    private void getAndSetServerProductTypeAndVersion() {
        try {
            BiCNetPluginServerAccessController.doPrivileged(this, () -> {
                try {
                    ISecurityAuthenticationPrivateFacade authenticationPrivateFacade = USMServiceLocator.getInstance().getSecurityAuthenticationPrivateFacade();
                    USMMessage message = authenticationPrivateFacade.getServerVersionAndProductType(getSecurityContext());
                    setServerVersion(message.popString());
                    serverProductType = (BiCNetProductType) message.popObject();
                } catch (IllegalStateException ex) {
                    // do not relogin
                    listener.handleLoginError(USMStringTable.getString(USMStringTable.CHECK_CLIENT_AND_SERVER_VERSIONS_ARE_COMPATIBLE),
                            USMStringTable.getString(USMStringTable.IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH_DIALOG_TITLE), UNRECOVERABLE_ERROR);
                } catch (BcbException ex) {
                    // do not relogin
                    listener.handleLoginError(USMStringTable.getString(USMStringTable.CHECK_SERVER_INSTALLED_INITIALISED_PROPERLY),
                            USMStringTable.getString(USMStringTable.IDS_AA_WINDOW_CONTROL_SERVER_INSTALLED_INITIALISED_PROPERLY_DIALOG_TITLE), UNRECOVERABLE_ERROR);
                }
                return null;
            });
        } catch (PrivilegedActionException ex) {
            LOGGER.error("Exception raised while getting server product type and version", ex);

            // SocketException may be thrown by method getServerVersionAndProductType because RemoteFrontControllerDelegate throws any Throwable
            if (ex.getCause() instanceof SocketException) {
                listener.handleLoginError(USMStringTable.getString(USMStringTable.CHECK_SERVER_CONNECTION_BROKEN),
                        USMStringTable.getString(USMStringTable.IDS_AA_WINDOW_CONTROL_SERVER_INSTALLED_INITIALISED_PROPERLY_DIALOG_TITLE), RECOVERABLE_ERROR);
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public USMMessage executeJob() throws BcbSecurityException {
        LOGGER.debug("executeJob() - Entry");

        String password = strPassword;
        String strServer = serverHostName;

        if (strServer.trim().length() == 0) {
            strServer = SERVER_LOCAL_HOST;
        }

        if (strServer.indexOf(':') == -1) {
            // use default port if user does not provide one
            strServer += ":" + SMSettingsProperties.getServerDefaultPort();
        }

        // Checking for password field
        if (null == password) {
            password = "";
        }

        if (!updateServiceLocator(strServer)) {
            return null;
        }

        // Locate Security Plugin
        final SecurityPlugin securityPlugin = USMUtility.getInstance().getSecurityPlugin();

        if (!USMCommonHelper.isSecurityCheckDisabled()) {
            AALoginBusinessDelegate logonDelegate = new AALoginBusinessDelegate();

            // Attempt logon

            long timeBefore = System.currentTimeMillis();
            final IEnhancedSessionContext sessionCtx = tryLogon(logonDelegate, userName, password, strServer, ssoSubject);

            LOGGER.info("TryLogon execution took: {}", (System.currentTimeMillis() - timeBefore));

            // If user credentials are validated successfully then session variable will be initialized
            if (sessionCtx != null) {
                LOGGER.debug("//n USER NAME : {} //n Server : {} ", userName, serverHostName);

                securityPlugin.setContext(sessionCtx);
                securityPlugin.setSession(securityPlugin.new SessionHandler());
                checkVersionAndProductType();
                if (loginToBePerformed) {
                    AAServerSessionTimer objServerSessionTimer = AAServerSessionTimer.getInstance();

                    try {
                        objServerSessionTimer.startTimer();
                    } catch (RuntimeException ex) {
                        LOGGER.error("RuntimeException :", ex);
                    }

                    listener.handleLoginProgress(USMStringTable.IDS_AA_LOGIN_FETCHING_DATA.toString());

                    timeBefore = System.currentTimeMillis();

                    try {
                        // Fetch Authorization data
                        fetchData(sessionCtx);
                    } catch (Exception ex) {
                        //Server not responding
                        LOGGER.error(LOGIN_WAS_FAILURE, ex);
                        listener.handleLoginError(USMStringTable.IDS_AA_DIALOG_MESSAGE_SERVER_UNRESPONSIVE.toString(), USMStringTable.IDS_AA_DIALOG_MESSAGE_LOGIN_FAILURE_TITLE.toString(), RECOVERABLE_ERROR);
                        //Server not responding
                        actionCancelCalled = true;
                    }

                    LOGGER.info("fetchData execution took: {}", (System.currentTimeMillis() - timeBefore));

                    listener.handleLoginSuccess();

                    // for every other login listener, fire the user logged on event
                    SwingUtilities.invokeLater(() -> {
                        securityPlugin.fireUserLoggedOn(sessionCtx);
                        AASessionClientController objClientController = AASessionClientController.getInstance();
                        objClientController.fireUserPermissionsChanged();
                    });

					SwingUtilities.invokeLater(() -> showAdvisoryMessage(sessionCtx));
					
					new Timer().schedule(new TimerTask() {
						@Override
						public void run() {
							try {
								checkExpirePasswordWarning(sessionCtx);
							} catch (BcbSecurityException e) {
								LOGGER.error("TimerTask checkExpirePasswordWarning :", e);
							}
						}
					}, 30000);
					
                }
            }
        } else {
            AALogonHistoryController.getInstance().saveHistory(userName, strServer, isSSOSelected());

            IEnhancedSessionContext ctx = null;
            try {
                ISecurityMgrFacade fcd = BiCNetServiceLocator.getInstance().getSecurityManager(BiCNetComponentType.SECURITY_MANAGER);
                if (fcd != null) {
                    ctx = (IEnhancedSessionContext) fcd.logon(userName, "", "");
                } else {
                    LOGGER.error("The facade object for USM returned is null.");
                }
            } catch (UnsupportedOperationException | UnexpectedException e1) {
                LOGGER.error("Exception :", e1);
            }

            if (ctx == null) {
                LOGGER.warn("Context is null. Using a dummy value. Might lead to problems.");
                ctx = USMCommonHelper.getDummySessionContext(userName);
            }

            ctx.setUserName(userName);
            ctx.setServerName(strServer);
            ctx.setClientMachineName(USMCommonHelper.getLocalHostName());
            ctx.setClientIpAddress(USMCommonHelper.getLocalHostAddress());

            securityPlugin.setContext(ctx);
            securityPlugin.setSession(securityPlugin.new DummySessionHandler());
            checkVersionAndProductType();

            if (loginToBePerformed) {
                securityPlugin.fireUserLoggedOn(ctx);
                AASessionClientController.getInstance().fireUserPermissionsChanged();

                listener.handleLoginSuccess();
            }
        }

        LOGGER.debug("executeJob() - Exit");
        return null;
    }

    /**
     * Update and check the server version and product type
     *
     */
    private void checkVersionAndProductType() {
        // Get the client version
        setClientVersion(USMUtility.getInstance().getSecuritySite().getClientProperty(BiCNetPluginClientProperties.CLIENT_VERSION, ""));
        // Get the server version and product type from @SCS
        getAndSetServerProductTypeAndVersion();

        // If the client version is null, an error message will be put up telling that the version for client is null, login can't proceed
        if (null != getClientVersion()) {
            String clientProductType = USMUtility.getInstance().getSecuritySite().getClientProperty(BiCNetPluginClientProperties.CLIENT_NAME, "");

            // This variable is needed for displaying the server product type in the client frame format
            String serverProductTypeInCFFormat = null;
            if (null != serverProductType) {
                serverProductTypeInCFFormat = APPLICATION_NAME_TNMS;
            }

            if (LOGGER.isInfoEnabled()) {
                LOGGER.info("Client product type: " + clientProductType);
                LOGGER.info("Server product type: " + serverProductType);
                LOGGER.info("Client version: " + getClientVersion());
                LOGGER.info("Server version: " + getServerVersion());
            }

            // The second check below might look confusing but the purpose is to handle the server not running error when m_serverVersion is null or when server product type is null
            if (getClientVersion().equals(getServerVersion()) || (null == getServerVersion()) || (null == serverProductType)) {
                loginToBePerformed = true;
            } else {
                JfxButton abortButton = new JfxButton(USMStringTable.IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH_DIALOG_ABORTBUTTON.toString());
                abortButton.setMnemonic(USMStringTable.IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH_DIALOG_ABORTBUTTON.getMnemonic());
                
                JfxButton continueButton = new JfxButton(USMStringTable.IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH_DIALOG_CONTINUEBUTTON.toString());
                continueButton.setMnemonic(USMStringTable.IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH_DIALOG_CONTINUEBUTTON.getMnemonic());
         
                JfxButton upgradeButton = new JfxButton(USMStringTable.IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH_DIALOG_UPGRADEBUTTON.toString());
                upgradeButton.setMnemonic(USMStringTable.IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH_DIALOG_UPGRADEBUTTON.getMnemonic());
                
                List<Object> listOptions = new ArrayList<>();
                
				listOptions.add(abortButton);

				if (isOnlyPatchDifferent(getServerVersion(), getClientVersion())) {
					listOptions.add(upgradeButton);
				}

				listOptions.add(continueButton);
				
                Object[] options = listOptions.toArray(new Object[listOptions.size()]);
                
                StringBuilder messageBuffer = new StringBuilder(USMStringTable.IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH.toString());
                messageBuffer.append(USMStringTable.IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH_CLIENTVER.toString()).append(" - ").append(clientProductType).append(" ").append(getClientVersion()).append(", ");
                messageBuffer.append(USMStringTable.IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH_SERVERVER.toString()).append(" - ").append(serverProductTypeInCFFormat).append(" ").append(getServerVersion()).append(".\n");
                messageBuffer.append(USMStringTable.IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH_PROCEED.toString());

                JOptionPane pane = new JOptionPane(messageBuffer.toString(), JOptionPane.WARNING_MESSAGE, JOptionPane.NO_OPTION, null, options, null);
                pane.setInitialValue(null);

                final JDialog dialog = pane.createDialog(USMStringTable.IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH_DIALOG_TITLE.toString());
                pane.selectInitialValue();

                abortButton.addActionListener(evt -> {
                    actionCancel(evt);
                    dialog.dispose();
                    actionCancelCalled = true;
                });

                // "ESC" key is equivalent to the "Abort" button action
                abortButton.registerKeyboardAction(e -> {
                    actionCancel(e);
                    dialog.dispose();
                    actionCancelCalled = true;
                }, "ESC", KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), JComponent.WHEN_FOCUSED);

                continueButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        actionContinue();
                    }

                    private void actionContinue() {
                        dialog.dispose();
                        loginToBePerformed = true;
                    }
                });

                upgradeButton.addActionListener(evt -> {
                    actionUpgrade(evt);
                    dialog.dispose();
                });

                dialog.addWindowListener(new WindowAdapter() {
                    @Override
                    public void windowClosing(WindowEvent e) {
                        if (!loginToBePerformed && !actionCancelCalled) {
                            actionCancel(null);
                        }
                    }
                });

                dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
                dialog.setVisible(true);
                // Try to dispose the dialog in either cases - both abort and continue.
                dialog.dispose();
            }
        } else {
            // do not relogin
            listener.handleLoginError(USMStringTable.IDS_AA_WINDOW_CONTROL_VERSION_CLIENTNULL.toString(), null, UNRECOVERABLE_ERROR);
        }
        
    }

	private boolean isOnlyPatchDifferent(String serverVersion, String clientVersion) {
		String majorServerVersion = serverVersion.substring(0, serverVersion.lastIndexOf('.'));
		String majorClientVersion = clientVersion.substring(0, clientVersion.lastIndexOf('.'));

		Long serverPatchNumber = Long.parseLong(last(serverVersion.split("\\.")));
		Long clientPatchNumber = Long.parseLong(last(clientVersion.split("\\.")));

        return clientPatchNumber < serverPatchNumber && majorServerVersion.equalsIgnoreCase(majorClientVersion);
    }
    
    public static <T> T last(T[] array) {
        return array[array.length - 1];
    }

	/**
	 * Called when user pressed "Cancel" button.
	 *
	 * @param e
	 *            Action event.
	 */
    private void actionCancel(ActionEvent e) {
		AALoginBusinessDelegate logonDelegate = new AALoginBusinessDelegate();

		try {
			logonDelegate.logoff(getSecurityContext());

		} catch (RuntimeException ex) {
			LOGGER.error("Exception in logoff for : " + getSecurityContext(), ex);
		}

        listener.handleLoginCancelled();
		LOGGER.debug("Abort logon due to product type or version mismatch. ");
	}

	/**
	 * Called when user pressed "Upgrade" button.
	 *
	 * @param e Upgrade event.
	 */
    private void actionUpgrade(ActionEvent e) {
        String hostname = serverHostName.split(":")[0];

        ClientUpdateProcessBuilder clientUpdate = new ClientUpdateProcessBuilder(hostname, clientVersion, serverVersion)
                .currentDirectory(PATH_CURRENT_DIRECTORY);

        LOGGER.info("COMMAND :: {}", clientUpdate);

        try {
            // if the process was created successfully, then proceed with the logoff
            AALoginBusinessDelegate logonDelegate = new AALoginBusinessDelegate();
            logonDelegate.logoff(getSecurityContext());
        	// launch the client update application
            clientUpdate.launch();
			// exit the application
			LOGGER.debug("Abort logon due to upgrade. ");
			System.exit(0);
		} catch (IOException e1) {
			LOGGER.error(MessageFormat.format("Could not launch process with command string {0}", clientUpdate), e1);
			// show error message, stating that the application could not be launched
            listener.handleLoginCancelled(USMStringTable.getString(USMStringTable.FAILED_LAUNCH_UPGRADE), USMStringTable.getString(USMStringTable.IDS_AA_WINDOW_CLIENT_UPDATE));
    		// server not responding
            actionCancelCalled = true;
		} catch (Exception e1) {
    		// server not responding
        	LOGGER.error(LOGIN_WAS_FAILURE, e1);
            listener.handleLoginCancelled(USMStringTable.IDS_AA_DIALOG_MESSAGE_SERVER_UNRESPONSIVE.toString(), USMStringTable.IDS_AA_DIALOG_MESSAGE_LOGIN_FAILURE_TITLE.toString());
    		// server not responding
            actionCancelCalled = true;
		} 
	}

    /**
     *
     * @param sessionCtx the session context
     */
    private void fetchData(final ISessionContext sessionCtx) {
        // Update the client authorization cache
        AAClientCache objClientCache = AAClientCache.getInstance();
        objClientCache.rebuildCache(sessionCtx);
        // Update the user profile
        AAUserProfileCache objProfileCache = AAUserProfileCache.getInstance();
        objProfileCache.getUserProfileCacheData(sessionCtx);
    }

    /**
     * Try logon
     * @param logonDelegate business logon delegate
     * @param strUser username
     * @param password password
     * @param strServer server hostname
     * @param ssoSubject Single Sign-On subject
     * @return session context
     */
    private IEnhancedSessionContext tryLogon(AALoginBusinessDelegate logonDelegate, final String strUser, final String password, final String strServer, final Subject ssoSubject) {
        LOGGER.debug("tryLogon() Entry");

        IEnhancedSessionContext session;
        JfxText errorString = USMStringTable.IDS_AA_DIALOG_MESSAGE_INTERNAL_ERROR;
        boolean recoverableError = RECOVERABLE_ERROR;

        if (getUsersToBeHidden().contains(strUser)) {
            // do not relogin
            recoverableError = UNRECOVERABLE_ERROR;
            errorString = USMStringTable.IDS_AA_DIALOG_MESSAGE_INTERNAL_USER;
        } else {
            try {
                // Firing login request to server
                if (isSSOSelected()) {
                    session = (IEnhancedSessionContext) logonDelegate.logon(strServer, ssoSubject, strUser, USMCommonHelper.getLocalHostName(), USMCommonHelper.getLocalHostAddress());
                } else {
                    session = (IEnhancedSessionContext) logonDelegate.logon(strServer, strUser, password, USMCommonHelper.getLocalHostName(), USMCommonHelper.getLocalHostAddress());
                }

                if (session != null) {
                    session.setServerName(strServer);
                    AALogonHistoryController.getInstance().saveHistory(strUser, strServer, isSSOSelected());
                    return session;
                }

            } catch (AuthorizationFailedException | InvalidCredentialsException e1) {
                // do not relogin
                recoverableError = UNRECOVERABLE_ERROR;
                errorString = USMStringTable.IDS_AA_DIALOG_MESSAGE_AUTHENTICATION_FAILURE;
                LOGGER.warn(LOGIN_WAS_FAILURE + ", " + errorString);
                LOGGER.debug("Exception thrown!", e1);
            } catch (UserAccountDisabledException e1) {
                // do not relogin
                recoverableError = UNRECOVERABLE_ERROR;
                errorString = USMStringTable.IDS_AA_DIALOG_MESSAGE_ACCOUNT_DISABLED;
                LOGGER.warn(LOGIN_WAS_FAILURE + ", " + errorString);
                LOGGER.debug("Exception thrown!", e1);
            } catch (AccountLockedException e1) {
                // do not relogin
                recoverableError = UNRECOVERABLE_ERROR;
                errorString = USMStringTable.IDS_AA_DIALOG_MESSAGE_ACCOUNT_LOCKED;
                LOGGER.warn(LOGIN_WAS_FAILURE + ", " + errorString);
                LOGGER.debug("Exception thrown!", e1);
            } catch (InvalidInitializationStateException e1) {
                LOGGER.error(LOGIN_WAS_FAILURE + ", ", e1);
                if (e1.getServerErrorCondition() == null) {
                    errorString = USMStringTable.IDS_AA_DIALOG_MESSAGE_USM_NOT_INITIALIZED;
                } else if (e1.getServerErrorCondition() == ScsServerErrorCondition.DB_CONNECTIVITY_ERROR) {
                    errorString = USMStringTable.IDS_AA_DIALOG_MESSAGE_DB_CONNECTION_PROBLEMS;
                } else if (e1.getServerErrorCondition() == ScsServerErrorCondition.SERVER_IS_STANDBY) {
                    errorString = USMStringTable.IDS_AA_DIALOG_MESSAGE_SERVER_IS_STANDBY;
                }
            } catch (AAKerberosAuthenticationException e1) {
                LOGGER.error(LOGIN_WAS_FAILURE + e1.getMessage());
                errorString = USMStringTable.IDS_AA_DIALOG_MESSAGE_SSO_FAILURE_TICKET_VALIDATION;
            } catch (ActiveDirectoryUserGroupsNotAvailableException e1) {
                // do not relogin
                recoverableError = UNRECOVERABLE_ERROR;
                errorString = USMStringTable.IDS_AA_DIALOG_MESSAGE_USER_DOES_NOT_HAVE_TNMS_GROUPS_ON_ACTIVE_DIRECTORY;
                LOGGER.warn(LOGIN_WAS_FAILURE + ", " + errorString);
                LOGGER.debug("Exception thrown!", e1);
            } catch (ActiveDirectoryUserGroupModificationException e1) {
                // do not relogin
                recoverableError = UNRECOVERABLE_ERROR;
                LOGGER.error(LOGIN_WAS_FAILURE + e1.getMessage());
                errorString = USMStringTable.IDS_AA_DIALOG_MESSAGE_MODIFY_USER_GROUPS;
            } catch (AccountLicenseException e) {
                // do not relogin
                recoverableError = UNRECOVERABLE_ERROR;
                LOGGER.error(LOGIN_WAS_FAILURE, e);
                errorString = USMStringTable.IDS_AA_DIALOG_MESSAGE_NO_LICENSE;
            } catch (MaxSessionsReachedException e) {
                // do not relogin
                recoverableError = UNRECOVERABLE_ERROR;
                LOGGER.error(LOGIN_WAS_FAILURE, e);
                errorString = USMStringTable.IDS_AA_DIALOG_MESSAGE_NUMBER_SESSIONS;
            } catch (AccountExpiredException e) {
                // do not relogin
                recoverableError = UNRECOVERABLE_ERROR;
                LOGGER.error(LOGIN_WAS_FAILURE, e);
                errorString = USMStringTable.IDS_AA_DIALOG_MESSAGE_EXPIRED;
            } catch (BcbSecurityException e1) {
                LOGGER.error(LOGIN_WAS_FAILURE, e1);
                errorString = USMStringTable.IDS_AA_DIALOG_MESSAGE_LOGIN_FAILURE;
            }catch (PrivilegedActionException | GSSException | LoginException e){
                // do not relogin
                recoverableError = UNRECOVERABLE_ERROR;
                LOGGER.error(LOGIN_WAS_FAILURE, e);
                errorString = USMStringTable.IDS_ACTIVEDIRECTORY_UNREACHABLE;
            }catch (Exception e1) {
                LOGGER.error(LOGIN_WAS_FAILURE, e1);
                errorString = USMStringTable.IDS_AA_DIALOG_MESSAGE_SERVER_UNRESPONSIVE;
            }
        }

        listener.handleLoginError(errorString.toString(), USMStringTable.IDS_AA_DIALOG_MESSAGE_LOGIN_FAILURE_TITLE.toString(), recoverableError);
        return null;
    }

    /**
     *
     * @return true if Single Sign-On is selected
     */
    private boolean isSSOSelected() {
        return ssoSubject != null;
    }

    /**
     *
     * @return session context
     */
    private ISessionContext getSecurityContext() {
        ISessionContext sessionContext = null;
        try {
            sessionContext = USMUtility.getInstance().getSecurityPlugin().getContext();
        } catch (Exception e1) {
            LOGGER.error("Exception raised. ", e1);
        }
        return sessionContext;
    }

    /**
     *
     * @param strServer the hostname of the server
     * @return true if the service locator can be configured, false otherwise
     */
    private boolean updateServiceLocator(String strServer) {
        try {
            BiCNetServiceLocator.getInstance().updateConfig(strServer);
            return true;

        } catch (BcbException e) {
            LOGGER.error("Exception", e);
            listener.handleLoginError("Could not create a Context for the Server.", null, RECOVERABLE_ERROR);
            return false;
        }
    }

    /**
     *
     * @return the server version
     */
    public String getServerVersion() {
		return serverVersion;
	}

    /**
     *
     * @param serverVersion the server version to set
     */
	public void setServerVersion(String serverVersion) {
		this.serverVersion = serverVersion;
	}

    /**
     *
     * @return get client version
     */
	public String getClientVersion() {
		return clientVersion;
	}

    /**
     *
     * @param clientVersion the client version to set
     */
	public void setClientVersion(String clientVersion) {
		this.clientVersion = clientVersion;
	}

    /**
     * @param string server hostname
     */
    public void setServerHostName(String string) {
        serverHostName = string;
    }


    /**
     * @param string password
     */
    public void setPassword(String string) {
        strPassword = string;
    }

    /**
     * @param string username
     */
    public void setUserName(String string) {
        userName = string;
    }

    public void setSsoSubject(Subject ssoSubject) {
        this.ssoSubject = ssoSubject;
    }

    /**
     * Display the advisory message window on successful logon
     *
     * @param objContext session context
     */
    private void showAdvisoryMessage(ISessionContext objContext) {
        BiCNetPluginFrame frame;
        LOGGER.debug("showAdvisoryMessage()       Entry ");
        AAAdvisoryMessageView advisorymessageView = new AAAdvisoryMessageView();
        try {
            // Retrieving advisory message from the server
            AALoginBusinessDelegate logonDelegate = new AALoginBusinessDelegate();
            USMMessage advisoryMessage = logonDelegate.getAdvisoryDetails(objContext);

            boolean bShow = advisoryMessage.popBoolean();
            advisoryMessage.popInteger();
            if(bShow) {
                // Setting time out for the client inactivity
                advisorymessageView.setAdvisoryMessage(advisoryMessage.popString());
                advisorymessageView.setUserName(advisoryMessage.popString());
                advisorymessageView.setLastLoginTime(advisoryMessage.popString());
                // Showing advisory message dialog
                frame = USMUtility.getInstance().getSecuritySite().createFrame(advisorymessageView, BiCNetPluginFrameType.MODAL);
                advisorymessageView.setFocus();
                frame.showFrame();
            }
        } catch (BiCNetPluginException e) {
            LOGGER.error("showAdvisoryMessage()   Exception :", e);
        }
        LOGGER.debug("showAdvisoryMessage()           Exit ");
    }

    /**
     * This method is used to fill a list with the usernames that are classified
     *
     * to be not considered in the information sent to client side,such as PTC
     * user.
     *
     * This users are listed in a property inside the 'message.properties' file.
     *
     * @return A list with all usernames classified to be hidden and
     */
    private static List<String> getUsersToBeHidden() {
        List<String> usersToBeHidden = new ArrayList<>();
        String usersFromResource = USMMessages.getInstance().getString(USMResourceBundleConstants.USM_INTERNAL_USERS_LIST);
        if (usersFromResource != null && usersFromResource.length() > 0) {
            String[] usersToBeHiddenArray = usersFromResource.split(",");
            if (usersToBeHiddenArray.length > 0) {
                for (String user : usersToBeHiddenArray) {
                    usersToBeHidden.add(user.toLowerCase());
                }
            }
        }
        return usersToBeHidden;
    }
    
    
	/**
	 * check Expire Password Warning
	 * 
	 * @param sessionCtx
	 * @throws BcbSecurityException
	 *
	 */
	private void checkExpirePasswordWarning(ISessionContext sessionCtx) throws BcbSecurityException {
		
		UADelegate uaDelegate = new UADelegate();

		userName = sessionCtx.getUserName();
		UAUser uaUser = uaDelegate.getUserByName(userName);

		GSGeneralSettingData savedSettings = SecuritySettingsManager.getInstance().getGeneralSettingsData();
		
		if (savedSettings == null || uaUser == null) {
			return;
		}
		
		if (savedSettings.getExpirePasswordWarning() > 0 && !uaUser.getUserCanNotChangePasswd()) {

			DateFormat dateFormatter = USMCommonHelper.getUSMDateFormatter();
			Date passwordChangeTime = null;
			
			if(uaUser.getLastPasswordChangeTime() == null || uaUser.getLastPasswordChangeTime().isEmpty()) {
				LOGGER.info("LastPasswordChangeTime is not defined");
				return;
			}
			
			try {
				passwordChangeTime = dateFormatter.parse(uaUser.getLastPasswordChangeTime());
			} catch (ParseException e) {
				LOGGER.error("checkExpirePasswordWarning :", e);
				return;
			}
			
			Date dateNow = new Date();
			int passwordChangeInterval = uaUser.getPasswordChangeInterval();
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(passwordChangeTime);
			cal.add(Calendar.DATE, passwordChangeInterval); // add passwordChangeInterval
			
			Date expirationDate = cal.getTime();
					

			long diffDays = getDateDiff(dateNow,expirationDate,TimeUnit.DAYS);
			
			if (savedSettings.getExpirePasswordWarning() > diffDays) {
				
				DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				String reportDate = df.format(expirationDate);
				showNotification(OpStatus.WITH_WARNINGS, String.format("Your password will expire at %s. Consider changing your password.",reportDate), BiCNetPluginClientLogSeverity.WARNING, "Password expiration");
			}
		}
	}
	
	/**
	 * Get a diff between two dates
	 * @param date1 the oldest date
	 * @param date2 the newest date
	 * @param timeUnit the unit in which you want the diff
	 * @return the diff value, in the provided unit
	 */
	public static long getDateDiff(Date date1, Date date2, TimeUnit timeUnit) {
	    long diffInMillies = date2.getTime() - date1.getTime();
	    return timeUnit.convert(diffInMillies,TimeUnit.MILLISECONDS);
	}
	

	/**
	 * Responsible for the creation and display of the popup notification 
	 * @param status - status of the operation: Finished with success or Failed
	 * @param description - message to be displayed in the popup
	 * @param severity - severity of the message to be displayed
	 * @param notifPopupTitle - title of the popup messagebox
	 */
	private void showNotification(OpStatus status, String description, BiCNetPluginClientLogSeverity severity, String notifPopupTitle) {
		LOGGER.info(description);
		NotificationPopupDetails popupDetails = new NotificationPopupDetails(status, description, BiCNetComponentType.SYSTEM_CONTROL_AND_SUPERVISION, "");
		popupDetails.setTitle(notifPopupTitle);
		NotificationPopupManager.getInstance().showPopup(popupDetails);
	}
}