/*
 * ------------------------History-------------------------
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005  Muyeen Munaver  CF000889 - Client-time-out-box often hidden behind TNMS DX client main window
 * 11-Jan-2005  Asif            CF000987 - "Security settings" instead of "Security Setting" window
 * 18-Jan-2005  Muyeen Munaver  CF000702 - The "OK" could became Grey in the "New User" window
 * 18-Jan-2005  Asif            CF001111 - Login Failure - Internal error occurred Check the traces and try again.
 * 09-02-2005   Babu B          CF000060-01   CF USM GUI Requirements
 * 09-03-2005   Muyeen Munaver  CF000995 - Password Expiration Interval
 * 15-Mar-2005  Babu B          CF001663      Handle login in separate Thread
 * 18-Mar-2005  Asif khan R     CF001755    Error Messages when LDAP not available
 * 30-Mar-2005  Muyeen Munaver  CF001845 - "It it matches..."
 * 05-Apr-2005  Muyeen Munaver  CF001885   XML file without any domain -import all the securtyManagement (includes domains)
 * 14-Apr-2005  Muyeen Munaver  CF001025    Stop the Server - message to the clients
 * 14-Apr-2005  Muyeen Munaver  CF001977 - no timeout for Login window => Login window can remain opened forever
 * 21-Apr-2005  Muyeen Munaver  CF002069 - login with invalid user => Probable reason is not coherent with the root cause
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 * 05-May-2005  Muyeen Munaver  CF001312   Master-Master Replication for Sun ONE DS
 * 02-Feb-2006  Balasubramanya  CF003463-01 Deactivation of administrator
 * 22-Feb-2006  Balasubramanya  CF002657-01 CES688: Missing hint with different versions of server and client
 * 10-Mar-2006  Balasubramanya  CF002657-01 CES688: Missing hint with different versions of server and client
 * 23-Mar-2006  Shrinidhi       CF003795-01 Wrong info with import of Security Management
 * 21-Mar-2006  Balasubramanya  CF003548 - Prohibit connection between DX clients and DX server w/ different version/build
 * 04-Apr-2006  Shrinidhi G V   CF003795-03 - Wrong info with import of Security Management
 * 17-Apr-2006  Shrinidhi G V   CF003548-01 Prohibit connection between DX clients and DX server w/ different version/build
 * 12-Apr-2006  Shrinidhi G V   CF003939-01 Deactivation of administrator
 * 15-Jan-2009  Nagaraddi S S    TD003725   No Validations For New User Window(User Administration)
 * 09-Dec-2010  Rajesh Battu    TD007500    Required Fields in UserAdministraiton marked with * symbol
 * -------------------------------------------------------------------------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.utils;

import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxText;

public final class USMStringTable extends JfxStringTable {

    public static final JfxText
            /***********************************************************************************************/
            /* Basic */
            /***********************************************************************************************/
            IDS_BUTTON_ADD = new JfxText("&Add >"),
            IDS_BUTTON_ADD_ALL = new JfxText("Add A&ll >>"),
            IDS_BUTTON_REMOVE = new JfxText("< Remo&ve"),
            IDS_BUTTON_REMOVE_ALL = new JfxText("<< &Remove All"),
            IDS_PLZ_WAIT = new JfxText("Please wait. "),
            IDS_READY = new JfxText("Ready."),
            IDS_BUTTON_OK = new JfxText("OK"),
            IDS_BUTTON_CANCEL = new JfxText("Cancel"),
            IDS_BUTTON_CLOSE = new JfxText("Close"),
            IDS_BUTTON_HELP = new JfxText("Help"),
            IDS_WINDOW_CLOSE_OBJ_DELETED_OR_REMOVED = new JfxText("Referenced Object has been deleted or removed.\nWindow will be closed."),
            IDS_SERVER_REINITIALIZED = new JfxText("Server has been re-initialized."),
            IDS_WINDOW_REOPEN = new JfxText("Security windows will be closed.\nReason: Security Data change detected during synchronization.\nReopen the windows manually."),
            IDS_WAIT_FOR_REFETCH = new JfxText("\n\nPlease wait while the security data is re-fetched."),

            /***********************************************************************************************/
            /* Auth */
            /***********************************************************************************************/
            // Windows Title Text Messages
            IDS_AA_WINDOW_LOGIN = new JfxText("Login"),
            IDS_AA_SINGLE_SIGNON_LABEL = new JfxText("Single Sign-on"),
            IDS_AA_WINDOW_CHANGE_PASSWORD = new JfxText("Change Password"),
            IDS_AA_WINDOW_ADVISORY_MESSAGE = new JfxText("Advisory Message"),
            IDS_AA_WINDOW_SSO_SETTINGS = new JfxText("Single Sign-on Settings"),
            IDS_AA_WINDOW_LDAP_AUTH_SETTINGS = new JfxText("LDAP Authentication Settings"),
            IDS_AA_WINDOW_RADIUS_AUTH_SETTINGS = new JfxText("RADIUS Authentication Settings"),
            IDS_AA_WINDOW_SESSION_TIMEOUT_WARNING = new JfxText("Session Timeout Warning"),
            IDS_AA_WINDOW_RELOGIN = new JfxText("Automatic Re-login"),

            // Windows Common Control Text Messages
            IDS_AA_WINDOW_CONTROL_LABEL_USERID = new JfxText("&Username:"),
            IDS_AA_WINDOW_CONTROL_LABEL_SERVER = new JfxText("&Server name:"),

            // Login Windows Control Text Messages
            IDS_AA_WINDOW_CONTROL_LABEL_PASSWORD = new JfxText("&Password:"),

            // Change Password Windows Control Text Messages
            IDS_AA_WINDOW_CONTROL_LABEL_OLD_PASSWORD = new JfxText("&Old password:"),
            IDS_AA_WINDOW_CONTROL_LABEL_NEW_PASSWORD = new JfxText("&New password:"),
            IDS_AA_WINDOW_CONTROL_LABEL_CONFIRM_PASSWORD = new JfxText("&Confirm new password:"),

            // SSO Configuration Windows Control Text Messages
            IDS_AA_WINDOW_CONTROL_DOMAIN_NAME = new JfxText("&Domain name:"),
            IDS_AA_WINDOW_CONTROL_DOMAIN_NAME_SERVER = new JfxText("D&omain name server:"),
            IDS_AA_DIALOG_MESSAGE_EMPTY_SSO_CONFIG = new JfxText("None of the Single Sign-on fields can be empty."),
            IDS_AA_DIALOG_MESSAGE_EMPTY_LDAP_AUTH_CONFIG = new JfxText("All LDAP authentication fields must be filled."),
            IDS_AA_DIALOG_MESSAGE_EMPTY_RADIUS_AUTH_CONFIG = new JfxText("All RADIUS authentication fields must be filled."),


            // LDAP Configuration Windows Control Text Messages
            IDS_AA_WINDOW_CONTROL_LABEL_LDAP_HOSTNAME = new JfxText("&Hostname:"),
            IDS_AA_WINDOW_CONTROL_LABEL_LDAP_SSL_INDICATOR = new JfxText("&SSL indicator:"),
            IDS_AA_WINDOW_CONTROL_LABEL_LDAP_SEARCH_ACCOUNT = new JfxText("&Search Account DN:"),
            IDS_AA_WINDOW_CONTROL_LABEL_LDAP_PASSWORD = new JfxText("&Password:"),

            IDS_AA_WINDOW_CONTROL_LABEL_LDAP_USER_SEARCH_BASE = new JfxText("&User Search base:"),
            IDS_AA_WINDOW_CONTROL_LABEL_LDAP_USER_SEARCH_FILTER = new JfxText("&User Search filter:"),
            IDS_AA_WINDOW_CONTROL_LABEL_LDAP_USER_SEARCH_SCOPE = new JfxText("&User Search scope:"),
            IDS_AA_WINDOW_CONTROL_LABEL_LDAP_USER_IDENTIFYING_ATTRIBUTE = new JfxText("&User identifying attribute:"),

            IDS_AA_WINDOW_CONTROL_LABEL_LDAP_GROUP_SEARCH_BASE = new JfxText("&Group Search base:"),
            IDS_AA_WINDOW_CONTROL_LABEL_LDAP_GROUP_SEARCH_FILTER = new JfxText("&Group Search filter:"),
            IDS_AA_WINDOW_CONTROL_LABEL_LDAP_GROUP_SEARCH_SCOPE = new JfxText("&Group Search scope:"),
            IDS_AA_WINDOW_CONTROL_LABEL_LDAP_GROUP_IDENTIFYING_ATTRIBUTE = new JfxText("&Group identifying attribute:"),
            IDS_AA_WINDOW_CONTROL_LABEL_LDAP_GROUP_ATTRIBUTE_IDENTIFYING_USER = new JfxText("Group &Member attribute:"),

            // Advisory Message Windows Control Text Messages
            IDS_AA_WINDOW_CONTROL_LABEL_LAST_LOGIN_TIME = new JfxText("Last login:"),

            // Messages for Login Window
            IDS_AA_DIALOG_MESSAGE_LOGIN_FAILURE_TITLE = new JfxText("Login Failure"),
            IDS_AA_DIALOG_MESSAGE_AUTHENTICATION_FAILURE = new JfxText("System could not log you on.\nThe username or password you entered is incorrect."),
            IDS_AA_DIALOG_MESSAGE_COMMUNICATION = new JfxText("LDAP Directory service is not reachable or properly configured."),
            IDS_AA_DIALOG_MESSAGE_NAMING_SERVICE = new JfxText("LDAP Directory service is not reachable or properly configured."),
            IDS_AA_DIALOG_MESSAGE_ACCOUNT_DISABLED = new JfxText("User account is disabled. Please contact the Administrator and try again."),
            IDS_AA_DIALOG_MESSAGE_BLANK_USER_PASSWORD = new JfxText("User id or the password given was blank.\nPlease enter a valid username and password."),
            IDS_AA_DIALOG_MESSAGE_ACCOUNT_LOCKED = new JfxText("Your account is locked for exceeding the wrong password retries limit\nPlease contact the Administrator and try again."),
            IDS_AA_DIALOG_MESSAGE_USM_NOT_INITIALIZED = new JfxText("System could not log you on.\nServer is still starting up or initializing. Please try again later."),
            IDS_AA_DIALOG_MESSAGE_DB_CONNECTION_PROBLEMS = new JfxText("System could not log you on.\nServer failed to start due to DB connection problems.\nPlease fix the problems and restart TNMS Server."),
            IDS_AA_DIALOG_MESSAGE_SERVER_IS_STANDBY = new JfxText("System could not log you on.\nServer is configured with standby role.\nPlease logon to active server."),
            IDS_AA_DIALOG_MESSAGE_LOGIN_FAILURE = new JfxText("Login Failed. System could not log you on, try again later"),
            IDS_AA_DIALOG_MESSAGE_USER_DOES_NOT_HAVE_TNMS_GROUPS_ON_ACTIVE_DIRECTORY = new JfxText("It's not possible to perform SSO authentication because\nthe user is not associated to any TNMS user groups on Active Directory."),
            IDS_AA_DIALOG_MESSAGE_MODIFY_USER_GROUPS = new JfxText("It's not possible to perform SSO authentication because\nthere was an error on update user groups based on Active Directory information."),
            IDS_AA_DIALOG_MESSAGE_ACTIVE_DIRECTORY_CONTEXT_NOT_INITIALIZED = new JfxText("It's not possible to perform SSO authentication because there\nis a communication problem with the Active Directory.\nPlease check configurations and Active Directory connectivity."),
            IDS_AA_DIALOG_MESSAGE_INTERNAL_ERROR = new JfxText("Login Failed, System could not log you on successfully."),
            IDS_AA_DIALOG_MESSAGE_SSO_FAILURE_TICKET_VALIDATION = new JfxText("It's not possible to perform SSO authentication due to a kerberos ticket validation error at server side."),

            IDS_AA_DIALOG_MESSAGE_NO_LICENSE = new JfxText("Login failed. No license available.\nPlease contact the Administrator."),
            IDS_AA_DIALOG_MESSAGE_EXPIRED = new JfxText("The user account has expired. Please contact your System Administrator."),
            IDS_AA_DIALOG_MESSAGE_NUMBER_SESSIONS = new JfxText("The maximum number of simultaneous user sessions has been reached.\nLogoff from one of the clients or contact your System Administrator."),

            IDS_AA_DIALOG_MESSAGE_SERVER_UNRESPONSIVE = new JfxText("TNMS Server is not responsive."),

            IDS_AA_LOGIN_JOB_NAME = new JfxText("Login to server"),
            IDS_AA_LOGIN_AUTH_STATUS = new JfxText("Authenticating the user..."),
            IDS_AA_LOGIN_FETCHING_DATA = new JfxText("Retrieving user data..."),

            CHECK_CLIENT_AND_SERVER_VERSIONS_ARE_COMPATIBLE = new JfxText("Login to the server failed. Check if the client and server versions are compatible"),

            FAILED_LAUNCH_UPGRADE = new JfxText("The Client Update could not be launched. Please contact your System Administrator"),

            CHECK_SERVER_INSTALLED_INITIALISED_PROPERLY = new JfxText("Login to the server failed. Check whether the server components are installed/initialised properly"),
            CHECK_SERVER_CONNECTION_BROKEN = new JfxText("Login to the server failed. Connection to the server is broken. Please restart machine."),

            IDS_AA_SERVER_HISTORY_ACTIVE_SERVER = new JfxText("Active server"),
            IDS_AA_SERVER_HISTORY_STANDBY_SERVER = new JfxText("Standby server"),

            // Messages for re-login
            RE_LOGIN_IN_PROGRESS = new JfxText("Attempting to re-login to TNMS server."),
            RE_LOGIN_WITH_STANDBY_IN_PROGRESS = new JfxText("Attempting to re-login to active or standby TNMS server."),
            RE_LOGIN_LONG_OPERATION = new JfxText("This operation can take several minutes."),
            RE_LOGIN_FAILED_TITLE = new JfxText("Automatic Re-login Failed"),
            RE_LOGIN_SUCCESS_SAME_SERVER = new JfxText("Logged in automatically after disconnecting from server ({0})."),
            RE_LOGIN_SUCCESS_STANDBY_SERVER = new JfxText("Logged in automatically to standby server {0} after a failover."),
            RE_LOGIN_CANCEL_MESSAGE = new JfxText("Cancelling automatic re-login..."),
            RE_LOGIN_TIMEOUT_MESSAGE = new JfxText("Failed to login automatically within {0} minutes."),
            RE_LOGIN_FAILED_WITH_SSO = new JfxText("Failed to login automatically using single sign-on."),


            // Messages for change password window
            IDS_AA_DIALOG_MESSAGE_CHANGE_PASSWORD_SECCUSSFUL = new JfxText("Password has been changed successfully"),
            IDS_AA_DIALOG_MESSAGE_PASSWORD_CHANGE_FAILURE_TITLE = new JfxText("Password Change Failure"),
            IDS_AA_DIALOG_MESSAGE_INACTIVITY_TIMEOUT = new JfxText("No user activity has been detected in the last {0} minutes"),
            IDS_AA_CANCEL_MUST_CHANGE_PASSWORD_DLG = new JfxText("Forced logged off for not changing password"),
            IDS_AA_FORCED_LOGOFF_MESSAGE = new JfxText("You are logged out forcefully by administrator"),
            IDS_AA_FORCED_LOGOFF_TRIAL_EXPIRED_MESSAGE = new JfxText("You are logged out forcefully due to trial mode expiration"),
            IDS_AA_CHANGE_PASSWORD_JOB_TITLE = new JfxText("Sending request to change password."),
            IDS_AA_SERVER_SHUTDOWN = new JfxText("Due to a server shutdown"),
            IDS_AA_JMS_CONNECTION_LOST = new JfxText("JMS connection loss"),
            IDS_AA_JMS_CONNECTION_ERROR = new JfxText("JMS connection error. If the error persists, check the troubleshooting manual."),
            IDS_LOGGED_OFF_MESSAGE = new JfxText("Logged off from server {0} ({1})."),
            IDS_INACTIVITY_TIMEOUT_POPUP_WARNING = new JfxText("You will be logged off at: {0}. Interact with TNMS to reset countdown."),
            IDS_ACTIVEDIRECTORY_UNREACHABLE = new JfxText("Active directory server is not reachable or single sign-on is not properly configured.\nPlease login locally or contact the Administrator."),
            IDS_ACTIVEDIRECTORY_TIMEDOUT_EXCEPTION = new JfxText("SocketTimeoutException"),

            /***********************************************************************************************/
            /* Security Settings */
            /***********************************************************************************************/

            IDS_SS_GENERAL_TAB_TITLE = new JfxText("General"),
            IDS_SS_TIMEOUT_GROUP_LABEL = new JfxText("Timeout"),
            IDS_SS_ACCOUNT_LOCKOUT_GROUP_LABEL = new JfxText("Account Lockout"),
            IDS_SS_RELOGIN_GROUP_LABEL = new JfxText("Automatic Re-login"),
            IDS_SS_EXPIRE_PASSWORD_WARNING_GROUP_LABEL = new JfxText("Expire Password Warning"),
            IDS_AA_SSO_CONFIGURATION_GROUP_LABEL = new JfxText("Single Sign-on"),
            IDS_AA_LDAP_AUTHENTICATION_CONFIGURATION_GROUP_LABEL = new JfxText("LDAP Authentication"),
            IDS_AA_LABEL_RADIUS_AUTHENTICATION = new JfxText("RADIUS Authentication"),
            IDS_AA_PASSWORD_VALIDATION_RULES_LABEL = new JfxText("Password Rules"),
            IDS_SS_ADVISORY_MESSAGE_TAB_TITLE = new JfxText("Advisory Message"),
            IDS_SS_INIT_PASSWORD_CHANGE_INTERVAL_LABEL = new JfxText("&Default password expiration:"),
            IDS_SS_DAYS_LABEL = new JfxText("days"),
            IDS_SS_INACTIVITY_TIMEOUT_LABEL = new JfxText("&Session timeout:"),
            IDS_SS_INACTIVITY_TIMEOUT_POPUP_LABEL = new JfxText("S&ession timeout warning:"),
            IDS_SS_MINUTES_LABEL = new JfxText("min"),
            IDS_SS_INACTIVITY_TIMEOUT_POPUP_MINUTES_LABEL = new JfxText("min before"),
            IDS_SS_SECONDS_LABEL = new JfxText("s"),
            IDS_SS_PASSWORD_CHANGE_INTERVAL_MSG = new JfxText("Default password expiration should be between {0} and {1}"),
            IDS_PASSWORD_CHANGE_INTERVAL_MSG = new JfxText("Password expiration should be between {0} and {1}"),
            IDS_INACTIVITY_TIMEOUT_INTERVAL_MSG = new JfxText("Inactivity timeout should be between {0} and {1}"),
            IDS_SS_UNSUCCESSFUL_LOGIN_ATT_LABEL = new JfxText("&Maximum login attempts:"),
            IDS_SS_MAX_LOGIN_ATTEMPTS_MSG = new JfxText("Maximum login attempts should be between {0} and {1}"),
            IDS_SS_DEACTIVATE_USER_ACCOUNT_LABEL = new JfxText("&User account deactivation:"),
            IDS_SS_USER_ACCOUNT_DEACTIVATION_MSG = new JfxText("User account deactivation should be between {0} and {1}"),
            IDS_SS_ADMIN_LOCKOUT_LABEL = new JfxText("&Administrator:"),
            IDS_SS_ADMIN_LOCKOUT_MSG = new JfxText("Administrator lockout should be between {0} and {1}"),
            IDS_SS_INACTIVITY_TIMEOUT_WARNING_TIME_MSG = new JfxText("Session timeout warning time should be between {0} and {1} minutes before"),
            IDS_SS_AD_LDAP_ENABLE_SSO_CHECKBOX = new JfxText("Enable &Single Sign-on"),
            IDS_SS_AD_LDAP_AUTHENTICATION_CHECKBOX = new JfxText("Enable &LDAP Authentication"),
            IDS_SS_AD_RADIUS_AUTHENTICATION_CHECKBOX = new JfxText("Enable &RADIUS Authentication"),
            IDS_SS_AD_LDAP_PORT_CHECKBOX = new JfxText("Use de&fault active directory LDAP port"),
            IDS_SS_AD_LDAP_SSLINDICATOR_CHECKBOX = new JfxText("Use LDAP SSL indicator"),
            IDS_SS_AD_LDAP_PORT_LABEL = new JfxText("Por&t:"),
            IDS_SS_DIALOG_MESSAGE_EMPTY_ADVISORY_CONFIG = new JfxText("The advisory message cannot be empty."),
            IDS_SS_ADVISORY_MESSAGE_CHECKBOX_LABEL = new JfxText("&Display advisory message text during application startup"),
            IDS_SS_RELOGIN_TIMEOUT_LABEL = new JfxText("Automatic &re-login timeout:"),
            IDS_SS_RELOGIN_TIMEOUT_MSG = new JfxText("Automatic re-login timeout should be between {0} and {1}"),
            IDS_SS_RELOGIN_DELAY_BETWEEN_TRIES_LABEL = new JfxText("De&lay between login attempts:"),
            IDS_SS_RELOGIN_DELAY_BETWEEN_TRIES_MSG = new JfxText("Delay between automatic re-login attempts should be between {0} and {1}"),
    		IDS_SS_EXPIRE_PASSWORD_WARNING_LABEL = new JfxText("Expire Password Warning:"),
            IDS_SS_EXPIRE_PASSWORD_WARNING_MSG = new JfxText("Expire Password Warning should be between {0} and {1}"),
            IDS_SS_PASSWORD_MUST_NOT_CONTAIN = new JfxText("Must not contain:"),
            IDS_SS_PASSWORD_MUST_BE_DIFFERENT_FROM_NAME = new JfxText("&First/Last name"),
            IDS_SS_PASSWORD_MUST_BE_DIFFERENT_FROM_EMPLOYEE_NUMBER = new JfxText("&Employee number"),
            IDS_SS_PASSWORD_MUST_BE_DIFFERENT_FROM_DATE = new JfxText("D&ate"),
            IDS_SS_PASSWORD_MUST_NOT_HAVE_SPACES = new JfxText("&Spaces"),
            ENUM_LABEL_SUCCESS = new JfxText("SUCCESS"),
            ENUM_LABEL_PASSWORD_MUST_NOT_HAVE_SPACES  = new JfxText("The password must not contain any spaces"),
            ENUM_LABEL_PASSWORD_MUST_BE_DIFFERENT_FROM_LAST_NAME = new JfxText("The password must not contain the last name nor variations of it"),
            ENUM_LABEL_PASSWORD_MUST_BE_DIFFERENT_FROM_FIRST_NAME = new JfxText("The password must not contain the first name nor variations of it"),
            ENUM_LABEL_PASSWORD_MUST_BE_DIFFERENT_FROM_EMPLOYEE_NUMBER = new JfxText("The password must not contain the Employee number nor variations of it"),
            ENUM_LABEL_PASSWORD_MUST_BE_DIFFERENT_FROM_DATE = new JfxText("The password must not contain the current date nor variations of it"),


            IDS_LABEL_RADIUS_TIMEOUT_SPINNER = new JfxText("&Timeout"),

            /***********************************************************************************************/
            /* BicNetServer */
            /***********************************************************************************************/
            IDS_BS_ADMIN_WND_TITLE = new JfxText("TMN Application Server Administration"),
            IDS_BS_ADMIN_WND_COMMON_FUNC = new JfxText("Servers:"),
            IDS_BS_ADMIN_WND_COMMON_FUNC_MNEMONIC = new JfxText("S"),
            IDS_BS_ADMIN_WND_ASSOCIATED_SEC_OBJS = new JfxText("Associated securable objects:"),
            IDS_BS_ADMIN_WND_ASSOCIATED_SEC_OBJS_MNEMONIC = new JfxText("o"),
            IDS_BS_ADMIN_WND_ASSOCIATED_SEC_OBJS_MNEMONIC_INDEX = new JfxText("21"),
            IDS_BS_ADMIN_WND_TOOL_TIP_REMOVE = new JfxText("Remove Server"),
            IDS_BS_ADMIN_WND_TOOL_TIP_SYNC_NE = new JfxText("Synchronize Data"),
            IDS_BS_ADMIN_WND_CONFIRM_CFS_REMOVAL = new JfxText("Are you sure you want to remove these "),
            IDS_BS_ADMIN_WND_CONFIRM_SINGLE_CFS_REMOVAL = new JfxText("Are you sure you want to remove the CF \n "),
            IDS_BS_ADMIN_WND_CONFIRM_CFS_REMOVAL_TITLE = new JfxText("Confirm CF Removal"),
            IDS_BS_CFS = new JfxText(" selected CFs?"),
            IDS_BS_JOB_RETRIEVE_CFS = new JfxText("Retrieving all configured CF(s) from the Server"),
            IDS_BS_JOB_RETRIEVE_SEC_OBJS_SINGLE = new JfxText("Retrieving Securable Object(s) for CF ''{0}'' from Server"),
            IDS_BS_JOB_REMOVE_CFS_SINGLE = new JfxText("Removing CF ''{0}'' from Security"),
            IDS_BS_JOB_REMOVE_CFS_MULTI = new JfxText("Removing ''{0}'' CF(s) from Security"),
            IDS_BS_JOB_SYNC_SEC_OBJS_SINGLE = new JfxText("Synchronizing securable object info with CF ''{0}''"),
            IDS_BS_JOB_SYNC_SEC_OBJS_MULTI = new JfxText("Synchronizing securable object info with ''{0}'' CF(s)"),
            IDS_BS_ERROR_REMOVE_CFS = new JfxText("Following CFs could not be removed.\n"),
            IDS_BS_ERROR_SYNC_CFS = new JfxText("Following CFs could not be synchronized.\n"),
            IDS_BS_ERROR_SECOBJS_RETRIEVAL = new JfxText("Securable Object(s) for the CF could not be retrieved.\n Probable reason is : "),



            // ///////////////////////////////////////////////////////////////////////////////////////////////
            // // Domain ////
            // ///////////////////////////////////////////////////////////////////////////////////////////////
            /**
             * For subsystem DC
             */

            IDS_DC_TITLE_NEW_DOMAIN = new JfxText("New Security Domain"),

            IDS_DC_NAME = new JfxText("&Name:"),
            IDS_DC_DESCRIPTION = new JfxText("&Description:"),
            IDS_DC_MAPPING_TITLE = new JfxText("Assign Policy to Security Domain - "),
            IDS_DC_DOMAIN_ADMIN_TITLE = new JfxText("Security Domain Management"),
            IDS_DC_NOACCESS = new JfxText("NO ACCESS"),
            IDS_DC_NOVISIBILITY = new JfxText("NO VISIBILITY"),
            IDS_DC_ASSIGNED_OBJECTS = new JfxText("A&ssigned:"),
            IDS_DC_AVAILABLE_DOMAINS = new JfxText("Available Security &Domains:"),
            IDS_DC_USER_GROUPS = new JfxText("User Groups"),
            IDS_DC_ASSIGNED_POLICY = new JfxText("Assigned Policy"),
            IDS_DC_NES_LOADING = new JfxText("Loading ..."),
            IDS_DC_POPUP_MODIFY_MENU = new JfxText("Modify"),
            IDS_DC_POPUP_DELETE_MENU = new JfxText("Delete"),
            IDS_DC_ACCESS_RIGHT_WINDOW_TITLE = new JfxText("Access Rights"),
            IDS_DC_MODIFY_DOMAIN_TITLE = new JfxText("Modify Security Domain"),
            IDS_DC_TOOLTIP_CREATE_DOMAIN = new JfxText("New Security Domain"),
            IDS_DC_TOOLTIP_MODIFY_DOMAIN = new JfxText("Modify Security Domain"),
            IDS_DC_TOOLTIP_DELETE_DOMAIN = new JfxText("Delete Security Domain(s)"),
            IDS_DC_TOOLTIP_ASSIGN_POLICY_APPLY = new JfxText("Changes the mappings"),
            IDS_DC_USER_GROUP = new JfxText("User group"),
            IDS_DC_DOMAIN = new JfxText("Security Domain"),
            IDS_DC_POLICY = new JfxText("Policy"),
            IDS_DC_AVAILABLE_OBJECTS = new JfxText("Available N&Es:"),

            IDS_DC_JOB_ASSIGN_MAPPINGS = new JfxText("Assigning/Unassigning of mappings for security domain ''{0}''"),
            IDS_DC_JOB_ASSIGN_OBJECTS_TO_DOMAIN = new JfxText("Assigning/Unassigning objects to security domain ''{0}''"),
            IDS_DC_JOB_CREATE_DOMAIN = new JfxText("Creating security domain ''{0}''"),
            IDS_DC_JOB_GET_ALL_DOMAIN = new JfxText("Retrieving all security domain(s) from the Server"),
            IDS_DC_JOB_GET_ALL_MAPPINGS = new JfxText("Retrieving all mappings from Server"),
            IDS_DC_JOB_GET_MAPPINGS_OF_DOMAIN = new JfxText("Retrieving mappings associated with security domain ''{0}'' from Server"),
            IDS_DC_JOB_GET_ASSIGNED_OBJECTS_FOR_DOMAIN_FROM_SERVER = new JfxText("Retrieving assigned Securable Object(s) for Security Domain ''{0}'' from Server"),
            IDS_DC_JOB_GET_ASSIGNED_UNASSIGNED_OBJECTS_FOR_DOMAIN_FROM_SERVER = new JfxText("Retrieving Securable Object(s) associated with Security Domain ''{0}'' from Server"),
            IDS_DC_JOB_GET_ALL_SEC_OBJECTS_FROM_SERVER = new JfxText("Retrieving all Securable Object(s) from Server"),
            IDS_DC_JOB_GET_SEC_OBJECTS_OF_DOMAIN_OF_CF = new JfxText("Retrieving securable objects to be displayed for selection"),

            IDS_DC_JOB_DESC_DELETE_DOMAIN_SINGLE = new JfxText("Deleting Security Domain ''{0}'' from Security"),
            IDS_DC_JOB_DESC_DELETE_DOMAIN_MULTI = new JfxText("Deleting ''{0}'' Security Domain(s) from Security"),
            IDS_DC_JOB_DESC_MODIFY_DOMAIN = new JfxText("Modifying Security Domain ''{0}''"),

            IDS_DC_MSG_DOMAIN_CFM_DELETION = new JfxText("Are you sure you want to delete these "),
            IDS_DC_MSG_DOMAIN_SINGLE_CFM_DELETION = new JfxText("Are you sure you want to delete the Security Domain \n "),

            IDS_DC_MSG_DOMAIN = new JfxText(" selected Security Domains? "),
            IDS_DC_MSG_MAPPING_NOT_ASSIGNED = new JfxText("Mappings could not be assigned for the following user groups"),
            IDS_DC_DELETE_MESSAGE_TITLE = new JfxText("Confirm Security Domain Deletion"),

            // ///////////////////////////////////////////////////////////////////////////////////////////////
            // // General ////
            // ///////////////////////////////////////////////////////////////////////////////////////////////
            IDS_GS_TITLE_GENERAL_SETTING_WINDOW = new JfxText("Security Settings"),
            IDS_GS_DAYS_LABEL = new JfxText("days"),
            IDS_GS_MINUTES_LABEL = new JfxText("min"),
            IDS_GS_SESSIONS_LABEL = new JfxText("sessions"),
            IDS_GS_ADVISORY_MESSAGE_MSG = new JfxText("Write advisory message here"),

            // ///////////////////////////////////////////////////////////////////////////////////////////////
            // // Import/Export ////
            // ///////////////////////////////////////////////////////////////////////////////////////////////
            IDS_IE_JOB_IMPORT_JOB = new JfxText("Importing security data"),
            IDS_IE_JOB_EXPORT_JOB = new JfxText("Exporting security data"),
            IDS_IE_JOB_DESC_IMPORT_JOB = new JfxText("Importing security data"),
            IDS_IE_JOB_DESC_EXPORT_JOB = new JfxText("Exporting security data"),
            IDS_IE_JOB_EXPORT_ERROR_WHILE_RETRIEVING = new JfxText("Error while retrieving "),
            IDS_IE_JOB_EXPORT_THERE_ARE_NO = new JfxText("There are no "),
            IDS_IE_JOB_EXPORT_LETTER_S = new JfxText("s"),
            IDS_IE_JOB_EXPORT_POLICY = new JfxText("Policy"),
            IDS_IE_JOB_EXPORT_POLICIES = new JfxText("Policies"),
            IDS_IE_JOB_EXPORT_TO_BE_EXPORTED = new JfxText(" to be exported."),
            IDS_IE_JOB_IMPORT_FAIL_REASON = new JfxText(" could not be imported. Reason : "),
            IDS_IE_JOB_IMPORT_FAIL_ALL = new JfxText("Failed to import all "),
            IDS_IE_JOB_IMPORT_SUCCESS_WITHUNRECOGNIZED = new JfxText(" could not be completely imported. Reason : "),
            IDS_IE_JOB_IMPORT_SUCCESS_PARCIAL = new JfxText(" partial imported. Some Nes are invalid "),
            IDS_IE_USERS = new JfxText("Users"),
            IDS_IE_USER_GROUPS = new JfxText("User Groups"),
            IDS_IE_POLICIES = new JfxText("Policies"),
            IDS_IE_DOMAINS = new JfxText("Security Domains"),
            IDS_IE_DOMAIN_MAPPING = new JfxText("Security Domain Mappings"),
            IDS_IE_SKIPPING_IMPORT_OF = new JfxText("Skipping import of "),
            IDS_IE_SPACE = new JfxText(" "),
            IDS_IE_MANDATORY_ATTRIBS = new JfxText("(s). Reason : Mandatory attribute "),
            IDS_IE_MANDATORY_ATTRIBS_MULTIPLE = new JfxText("(s). Reason : Some of mandatory attribute(s) "),
            IDS_IE_MISSING_OR_EMPTY = new JfxText(" missing or empty."),
            IDS_IE_NO_DATA_TO_IMPORT = new JfxText("Warning: There are no ''{0}'' to be imported."),

            // ///////////////////////////////////////////////////////////////////////////////////////////////
            // // Policy ////
            // ///////////////////////////////////////////////////////////////////////////////////////////////
            IDS_PA_ADMIN_TITLE = new JfxText("Policy Management"),
            IDS_PA_MODIFY_TITLE = new JfxText("Modify Policy "),
            IDS_PA_NEW_TITLE = new JfxText("New Policy "),
            IDS_PA_NAME = new JfxText("Name:"),
            IDS_PA_DESCRIPTION = new JfxText("Description: "),
            IDS_PA_AVAILABLE_POLICY = new JfxText("Available &policies: "),
            IDS_PA_ASSIGNED_MENU = new JfxText("Assigned permissions: "),
            IDS_PA_AVAILABLE_MENU = new JfxText("Available permissions:"),
            IDS_PA_DELETE_MESSAGE = new JfxText("Are you sure you want to delete these "),
            IDS_PA_SINGLE_DELETE_MESSAGE = new JfxText("Are you sure you want to delete the policy \n "),
            IDS_PA_DELETE_MESSAGE_FOR_POLICY = new JfxText("The policy deletion operation failed for the following policy(s):"),
            IDS_PA_POLICY = new JfxText(" selected policies?"),
            IDS_PA_DELETE_MESSAGE_TITLE = new JfxText("Policy Deletion "),
            IDS_PA_CREATE_MESSAGE_NAME = new JfxText("Enter some name for the policy "),
            IDS_PA_CREATE_MESSAGE_NAME_VALID = new JfxText("Enter Valid Name For the Policy name should not have +;/<>,#characters"),
            IDS_PA_ERROR_POLICY_MESSAGE = new JfxText("Policy Admin window cannot be initialized - Internal Error"),
            IDS_PA_CREATED_POLICY_DROPPED_MENUS = new JfxText("Policy contained some permissions which were not recognized.\nPolicy created with valid permissions only"),
            IDS_PA_FAILED_TO_CREATE_POLICY = new JfxText("Failed To create the policy.\nReason : "),
            IDS_PA_TOOLTIP_NEW_POLICY = new JfxText("New Policy"),
            IDS_PA_TOOLTIP_MODIFY_POLICY = new JfxText("Modify Policy"),
            IDS_PA_TOOLTIP_DELETE_POLICY = new JfxText("Delete Policy"),
            IDS_PA_JOB_RETRIEVE_ALL_POLICIES = new JfxText("Retrieving all policies from the Server"),
            IDS_PA_JOB_RETRIEVE_PERMISSIONS_FOR_POLICY = new JfxText("Retrieving assigned permission(s) for policy ''{0}'' from Server"),
            IDS_PA_JOB_DELETE_POLICY_SINGLE = new JfxText("Deleting policy ''{0}'' from Security"),
            IDS_PA_JOB_DELETE_POLICY_MULTI = new JfxText("Deleting ''{0}'' policies from Security"),
            IDS_PA_JOB_RETRIEVE_ALL_PERMISSIONS = new JfxText("Retrieving all permission(s) from Server"),
            IDS_PA_JOB_CREATE_POLICY = new JfxText("Creating policy ''{0}''"),
            IDS_PA_JOB_MODIFY_POLICY = new JfxText("Modifying policy ''{0}''"),
            IDS_PA_JOB_GET_POLICY_INFORMATION = new JfxText("Retrieving Policy permission Information ''{0}''"),

            /**
             * For subsystem UA
             */
            // Window captions
            IDS_UA_ADMIN_TITLE = new JfxText("User Management"),
            IDS_UA_CREATE_TITLE = new JfxText("New User"),
            IDS_UA_MODIFY_TITLE = new JfxText("User Modification"),
            IDS_UA_ACTIVATE_USER_TITLE = new JfxText("Confirm User Activation"),
            IDS_UA_DEACTIVATE_USER_TITLE = new JfxText("Confirm User Deactivation"),
            IDS_UA_DELETE_USER_TITLE = new JfxText("Confirm User Deletion"),
            IDS_UA_FORCE_LOGOFF_USER_TITLE = new JfxText("Confirm User Forced Logoff"),
            IDS_UA_UNLOCK_USER_TITLE = new JfxText("Confirm User Unlock"),

            // Description(s) for Buttons
            IDS_UA_FETCH_DESCRIPTION = new JfxText("Retrieving all user(s) from the Server"),
            IDS_UA_JOB_ACTIVATE_USER_SINGLE = new JfxText("Activating user ''{0}''"),
            IDS_UA_JOB_ACTIVATE_USER_MULTI = new JfxText("Activating ''{0}'' user(s)"),
            IDS_UA_JOB_FORCE_LOGOFF_USER_SINGLE = new JfxText("Force Logging off user ''{0}''"),
            IDS_UA_JOB_FORCE_LOGOFF_USER_MULTI = new JfxText("Force Logging off ''{0}'' user(s)"),
            IDS_UA_JOB_UNLOCKING_USER_SINGLE = new JfxText("Unlocking user ''{0}''"),
            IDS_UA_JOB_UNLOCKING_USER_MULTI = new JfxText("Unlocking ''{0}'' user(s)"),
            IDS_UA_JOB_DEACTIVATE_USER_SINGLE = new JfxText("Deactivating user ''{0}''"),
            IDS_UA_JOB_DEACTIVATE_USER_MULTI = new JfxText("Deactivating ''{0}'' user(s)"),
            IDS_UA_JOB_DELETE_USER_SINGLE = new JfxText("Deleting user ''{0}''"),
            IDS_UA_JOB_DELETE_USER_MULTI = new JfxText("Deleting ''{0}'' user(s)"),

            IDS_UA_CREATE_DESCRIPTION = new JfxText("New User"),
            IDS_UA_MODIFY_DESCRIPTION = new JfxText("Modify User"),
            IDS_UA_DELETE_DESCRIPTION = new JfxText("Delete User"),
            IDS_UA_LOGOFF_DESCRIPTION = new JfxText("Force User Logoff"),
            IDS_UA_UNLOCK_DESCRIPTION = new JfxText("Unlock User"),
            IDS_UA_ACTIVATE_DESCRIPTION = new JfxText("Activate User"),
            IDS_UA_DEACTIVATE_DESCRIPTION = new JfxText("Deactivate User"),

            // New/Modify user
            IDS_UA_TEXT_FIRST_NAME = new JfxText("&First name:"),
            IDS_UA_TEXT_LAST_NAME = new JfxText("&Last name:"),
            IDS_UA_TEXT_COMMON_NAME = new JfxText("Full &name:"),
            IDS_UA_TEXT_USERID = new JfxText("&Username:"),
            IDS_UA_TEXT_EMAIL = new JfxText("&E-mail:"),
            IDS_UA_TEXT_PHONENUMBER = new JfxText("&Phone:"),
            IDS_UA_TEXT_FAXNUMBER = new JfxText("F&ax:"),
            IDS_UA_TEXT_EMPLOYEENUMBER = new JfxText("E&mployee Number:"),
            IDS_UA_TEXT_PASSWORD = new JfxText("&Password:"),
            IDS_UA_TEXT_CONFIRM_PASSWORD = new JfxText("&Confirm password:"),
            IDS_UA_TEXT_NEW_PASSWORD = new JfxText("&New password:"),
            IDS_UA_TEXT_CONFIRM_NEW_PASSWORD = new JfxText("&Confirm new password:"),
            IDS_UA_INIT_PASSWORD_CHANGE_INTERVAL_LABEL = new JfxText("Password e&xpires after:"),
            IDS_UA_USER_SPECIFIC_TIMEOUT_LABEL = new JfxText("User &Inactivity Timeout:"),
            IDS_UA_CHECKBOX_USERMUST_CHANGE_PASSWORD = new JfxText("User &must change password at next logon"),
            IDS_UA_CHECKBOX_USERCANNOT_CHANGE_PASSWORD = new JfxText("&User cannot change password"),
            IDS_UA_CHECKBOX_ACCOUNT_IS_DEACTIVATED = new JfxText("&Account is deactivated"),
            IDS_UA_SIMULTANEOUS_USER_SESSIONS_LABEL = new JfxText("Number of allowed simultaneous user sessions"),
            IDS_UA_ACCOUNT_EXPIRES_DATE_LABEL = new JfxText("Account expiration date"),

            IDS_UA_USER_STATE_LOGGED_IN = new JfxText("Logged in"),
            IDS_UA_USER_STATE_LOGGED_OUT = new JfxText("Logged out"),
            IDS_UA_USER_STATE_ACTIVATED = new JfxText("Activated"),
            IDS_UA_USER_STATE_DEACTIVATED = new JfxText("Deactivated"),
            IDS_UA_USER_STATE_LOCKED = new JfxText("Locked"),
            IDS_UA_USER_STATE_EXPIRED = new JfxText("Account Expired"),

            // Tab options
            IDS_UA_TAB_PERSONAL_DATA = new JfxText("Personal Data"),
            IDS_UA_TAB_PASSWORD_AND_ACCOUNT_DATA = new JfxText("Password and Account Data"),
            IDS_UA_TAB_MEMBEROF = new JfxText("Groups"),

            // Button captions
            IDS_UA_BUTTON_MODIFY = new JfxText("Modify"),
            IDS_UA_BUTTON_DELETE = new JfxText("Delete"),
            IDS_UA_BUTTON_FORCE_LOGOFF = new JfxText("Force Logoff"),
            IDS_UA_BUTTON_UNLOCK = new JfxText("Unlock"),
            IDS_UA_BUTTON_ACTIVATE = new JfxText("Activate"),
            IDS_UA_BUTTON_DEACTIVATE = new JfxText("Deactivate"),

            // Table Column captions
            IDS_UA_ACCOUNT_STATE = new JfxText("Account State"),
            IDS_UA_NAME = new JfxText("Full Name"),
            IDS_UA_USERID = new JfxText("Username"),
            IDS_UA_ACCOUNT_TYPE = new JfxText("Account Type"),
            IDS_UA_LAST_LOGIN_TIME = new JfxText("Last Login"),
            IDS_UA_LOGIN_STATUS = new JfxText("Login Status"),
            IDS_UA_HOST_NAME = new JfxText("Computer Name"),
            IDS_UA_FAILED_LOGIN_COUNT = new JfxText("Bad Password Count"),

            // Messages
            IDS_UA_ACTIVATE_MESSAGE = new JfxText("Are you sure you want to activate these "),
            IDS_UA_SINGLE_ACTIVATE_MESSAGE = new JfxText("Are you sure you want to activate the user \n"),

            IDS_UA_DEACTIVATE_MESSAGE = new JfxText("Are you sure you want to deactivate these "),
            IDS_UA_SINGLE_DEACTIVATE_MESSAGE = new JfxText("Are you sure you want to deactivate the user \n "),

            IDS_UA_DELETE_MESSAGE = new JfxText("Are you sure you want to delete these "),
            IDS_UA_DELETE_SINGLE_MESSAGE = new JfxText("Are you sure you want to delete the user \n"),

            IDS_UA_FORCE_LOGOFF_MESSAGE = new JfxText("Are you sure you want to forcefully logoff these "),
            IDS_UA_SINGLE_FORCE_LOGOFF_MESSAGE = new JfxText("Are you sure you want to forcefully logoff the user \n"),

            IDS_UA_UNLOCK_MESSAGE = new JfxText("Are you sure you want to unlock these "),
            IDS_UA_SINGLE_UNLOCK_MESSAGE = new JfxText("Are you sure you want to unlock the user \n  "),

            IDS_UA_USERS = new JfxText(" selected users?"),
            IDS_UA_USERGROUPS = new JfxText(" selected user groups?"),

            IDS_UA_DELETE_USER_ERROR = new JfxText("The following users could not be deleted"),
            IDS_UA_ACTIVATE_USER_ERROR = new JfxText("The following users could not be activated"),
            IDS_UA_DEACTIVATE_USER_ERROR = new JfxText("The following users could not be deactivated"),
            IDS_UA_UNLOCK_USER_ERROR = new JfxText("The following users could not be unlocked"),

            IDS_UA_REASONS_LDAP = new JfxText("Server couldnot process the request, possibly a LDAP error occured."),

            IDS_UA_FIRSTNAME_MESSAGE = new JfxText("First name must be provided"),
            IDS_UA_LASTNAME_MESSAGE = new JfxText("Last name must be provided"),
            IDS_UA_COMMONNAME_MESSAGE = new JfxText("Full name must be provided"),
            IDS_UA_USERID_MESSAGE = new JfxText("Username is empty, or contains space(s) or contains characters \\/?<>:*\"|# or contains more than 64 characters"),
            IDS_INVALID_EMAIL_MESSAGE = new JfxText("Please enter a valid email address"),
            IDS_INVALID_TELEPHONE_MESSAGE = new JfxText("Phone should contain at least one numerical character"),
            IDS_INVALID_FAX_MESSAGE = new JfxText("Fax should start with a number, letter or one of the following symbols ' ( ) + , - . ="),
            IDS_UA_USERGROUP_MESSAGE = new JfxText("User must be assigned to at least one user group."),
            IDS_UA_USER_ALREADY_EXIST_MESSAGE = new JfxText("User with same id already exist "),
            IDS_UA_SERVER_RETURNED_ERROR = new JfxText("An Internal Error has occured in the Server. The user has not been created."),
            IDS_UA_LDAP_ERROR = new JfxText("Could not complete the operation as a LDAP error has occured"),

            IDS_UA_PASSWORD_HISTORY_ERROR = new JfxText("The password could not be modified.\nIt matches one of the previous 5 passwords."),
            IDS_UA_USER_AND_PASSWORD_NOT_COMPLIANT_WITH_RULES = new JfxText("Username and/or password are not compliant with the defined rules.\nPlease check the available documentation."),
            IDS_GS_PASSWORD_COMP_ERROR_MESSAGE = new JfxText("Password complexity error: password should contain at least two alphabetic, one numeric and one special character except #,$,*,/,@"),
            IDS_GS_PASSWORD_CONTAINS_CIRCULAR_ID_MESSAGE = new JfxText("Password error - password should not contain userid either in reverse or in circular."),
            IDS_GS_PASSWORD_CONTAINS_UID_MESSAGE = new JfxText("Password error - password should not contain userid either in reverse or in circular."),
            IDS_GS_PASSWORD_LENGTH_ERROR_MESSAGE = new JfxText("Password error - password should have at least 8 characters"),
            IDS_GS_PASSWORD_SAME_AS_USERID_MESSAGE = new JfxText("Password error - password should not be same as userid."),
            IDS_GS_PASSWORD_CONTAIN_CONSECUTIVE_CHARS = new JfxText("Password error- password should not contain more than 3 consecutive digits or letters from the alphabet."),
            IDS_UA_USER_CREATE_AVAILBLE_USERGROUPS = new JfxText("Availa&ble user groups:"),
            IDS_UA_USER_CREATE_ASSIGNED_USERGROUPS = new JfxText("A&ssigned user groups:"),
            IDS_UA_USER_CREATE_MODIFY_ERROR_FETCH_USERGROYPS = new JfxText("Error occured while fetching user groups some internal error"),
            IDS_UA_USER_CREATE_MODIFY_ERROR_FETCH_PASSWORD_VALIDATION_RULES = new JfxText("Error occured while fetching password validation rules some internal error"),
            IDS_UA_USER_CHANGE_PASSWORD_ERROR_FETCH_ERROR_FETCH_PASSWORD_VALIDATION_RULES = new JfxText("Error occured while fetching password validation rules some internal error"),
            IDS_UA_USER_CHANGE_PASSWORD_ERROR_FETCH_USER_BY_NAME = new JfxText("Error occured while fetching user details due to internal error"),

            // Advisory Message Windows Control Text Messages
            IDS_AA_WINDOW_CONTROL_LABEL_USERNAME = new JfxText("Username:"),

            // Labels,titles and messages constants created for the user group related GUI
            IDS_UG_TABLE_HEADER_USER_GROUP_NAME = new JfxText("Name"),
            IDS_UG_TABLE_HEADER_USER_GROUP_DESCRIPTION = new JfxText("Description"),
            IDS_UG_LABEL_USER_GROUP_NAME = new JfxText("&Name:"),
            IDS_UG_LABEL_USER_GROUP_DESCRIPTION = new JfxText("&Description:"),
            IDS_UG_LABEL_ASSIGNED_USER_LIST = new JfxText("A&ssigned users:"),
            IDS_UG_LABEL_UNASSIGNED_USER_LIST = new JfxText("Available &users:"),
            IDS_UG_TITLE_USER_GROUP_ADMINISTARTOR_WINDOW = new JfxText("User Group Management"),
            IDS_UG_TITLE_USER_GROUP_CREATE_WINDOW = new JfxText("New User Group"),
            IDS_UG_TITLE_USER_GROUP_MODIFY_WINDOW = new JfxText("Modify User Group"),

            // Tab options
            IDS_UG_TAB_GENERAL_DATA = new JfxText("General"),
            IDS_UG_TAB_DOMAINS_AND_POLICIES_DATA = new JfxText("Security Domains and Policies"),

            IDS_UG_MSG_USER_GROUP_NAME_NOT_VALID = new JfxText("The system could not create the user group.\nCheck the user group name and make sure it exists, was not typed with a combination of blank or contains special characters such as +=?;\"/<>,#  "),
            IDS_UG_MSG_USER_GROUP_DESC_NOT_VALID = new JfxText("The system could not create the user group.\nDescription field cannot be empty"),
            IDS_UG_MSG_MODIFY_USER_GROUP_DESC_NOT_VALID = new JfxText("The system could not modify the user group.\nDescription field cannot be empty"),
            IDS_UG_USER_GROUP_CREATE_BTN_TOOLTIP = new JfxText("New User Group"),
            IDS_UG_USER_GROUP_MODIFY_BTN_TOOLTIP = new JfxText("Modify User Group"),
            IDS_UG_USER_GROUP_DELETE_BTN_TOOLTIP = new JfxText("Delete User Group"),

            IDS_UG_JOB_RETRIEVE_USER_GROUPS = new JfxText("Retrieving all user group(s) from Server"),
            IDS_UA_JOB_CREATE_USER = new JfxText("Creating user ''{0}''"),
            IDS_UA_JOB_ASSIGNED_UNASSIGNED_USERGROUPS_FOR_USER = new JfxText("Retrieving user group(s) associated with user ''{0}'' from Server"),
            IDS_UA_JOB_MODIFY_USER = new JfxText("Modifying user ''{0}''"),

            IDS_UG_JOB_DELETE_USERGROUP_Single = new JfxText("Deleting user group ''{0}'' from Security"),
            IDS_UG_JOB_DELETE_USERGROUP_Multi = new JfxText("Deleting ''{0}'' user group(s) from Security"),
            IDS_UG_JOB_RET_USER_FOR_MODIFY_USER_GROUPS = new JfxText("Retrieving user(s) associated with user group ''{0}'' from Server"),
            IDS_UG_JOB_RET_USERS_FOR_CREATE_USER_GROUPS = new JfxText("Retrieving all user(s) from Server"),
            IDS_UG_JOB_RET_PASSWORD_VALIDATION_RULES = new JfxText("Retrieving all password validation rules from Server"),
            IDS_UA_JOB_CREATE_USERGROUP = new JfxText("Creating user group ''{0}''"),
            IDS_UG_JOB_MODIFY_USER_GROUPS = new JfxText("Modifying user group ''{0}''"),
            IDS_UG_TOOL_TIP_MODIFY_USER_GROUPS = new JfxText("Modifies the User Group"),
            IDS_UG_DELETE_MESSAGE_FOR_USER_GROUP = new JfxText("The user group deletion operation failed for the following user groups:"),
            IDS_UG_LDAP_ERROR = new JfxText("Server returned LDAP Error"),
            IDS_UG_INTERNAL_ERROR = new JfxText("Server returned Internal Error"),
            IDS_AA_DIALOG_MESSAGE_INTERNAL_USER = new JfxText("System could not log you on. User does not have permissions."),
            IDS_UG_USER_GROUP_MAPPED_ERROR = new JfxText("A User Group with this name already exists"),
            IDS_UG_CONFIRM_UGS_REMOVAL = new JfxText("Are you sure you want to delete these "),
            IDS_UG_CONFIRM_SINGLE_UG_REMOVAL = new JfxText("Are you sure you want to delete the user group \n"),
            IDS_UG_CONFIRM_UGS_REMOVAL_TITLE = new JfxText("Confirm User Group Deletion"),
            IDS_UG_INVALID_USER_ERROR = new JfxText("User group created successfully.\nFollowing invalid users have been removed.\n"),
            IDS_UG_INVALID_USER_MODIFY_ERROR = new JfxText("User group modified successfully.\nFollowing invalid users have been removed.\n"),
            IDS_UG_ADMINISTRATOR_USER_MODIFY_ERROR = new JfxText("Administrator user cannot be removed from the Administrators user group."),
            IDS_UA_ADMINISTRATOR_USER_MODIFY_ERROR = new JfxText("Administrators group cannot be unassigned for the Administrator user."),
            IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH = new JfxText("There is a product and/or version mismatch between the client and the server\nwhich may result in unpredictable behaviour.\n"),
            IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH_PROCEED = new JfxText("\nDo you still want to proceed?"),
            IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH_CLIENTVER = new JfxText("Client Version"),
            IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH_SERVERVER = new JfxText("\nServer Version"),

            IDS_AA_WINDOW_CONTROL_VERSION_CLIENTNULL = new JfxText("The client version indicates null. Cannot proceed with the login."),
            IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH_DIALOG_TITLE = new JfxText("Product/Version Mismatch!"),
            IDS_AA_WINDOW_CLIENT_UPDATE = new JfxText("Client Update"),
            IDS_AA_WINDOW_CONTROL_SERVER_INSTALLED_INITIALISED_PROPERLY_DIALOG_TITLE = new JfxText("Login Error"),
            IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH_DIALOG_ABORTBUTTON = new JfxText("&Abort"),
            IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH_DIALOG_CONTINUEBUTTON = new JfxText("&Continue"),
            IDS_AA_WINDOW_CONTROL_VERSION_MISMATCH_DIALOG_UPGRADEBUTTON = new JfxText("&Upgrade"),

            /***********************************************************************************************/
            /* Common */
            /***********************************************************************************************/
            IDS_PROPERTIES = new JfxText("Properties..."),
            IDS_SYNC_NE = new JfxText("Sync Data"),
            IDS_SYNC_ACL = new JfxText("Sync ACL"),
            IDS_SYNC_SECURITY_DATA = new JfxText("Sync Data"),
            IDS_NEW = new JfxText("New..."),
            IDS_SYNC_MODIFY = new JfxText("Modify..."),
            IDS_REMOVE = new JfxText("Remove"),
            IDS_ASSIGN_POLICY = new JfxText("Assign Policy..."),

            IDS_WINDOWS_CLOSE_ON_LDAP_RECONNECT = new JfxText("All security windows will be closed. Security data might have changed since the connection to the directory server was lost and re-established."),
            SELECT_VIEW = new JfxText("View"),
            MEDIATOR_VIEW = new JfxText("Mediator"),
            DOMAIN_VIEW = new JfxText("Network Domain"),
            CONTAINER_VIEW = new JfxText("NE Container"),

            NE_MOTYPE = new JfxText("NEs"),
            SUBSCRIBER_MOTYPE = new JfxText("Subscribers");

    public static final String
            IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_HOSTNAME = "LDAP IP address or server fully qualified domain name",
            IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_SEARCH_ACCOUNT = "Search Account DN:",
            IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_PASSWORD = "Password:",
            IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_USER_SEARCH_BASE = "User Search base:",
            IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_USER_SEARCH_FILTER = "User Search filter:",
            IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_USER_SEARCH_SCOPE = "User Search scope:",
            IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_GROUP_SEARCH_BASE = "Group Search base:",
            IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_GROUP_SEARCH_FILTER = "Group Search filter:",
            IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_GROUP_SEARCH_SCOPE = "Group Search scope:",
            IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_ATTRIBUTE_IDENTIFYING_ROLE = "Attribute Identifying Role:",
            IDS_AA_WINDOW_CONTROL_TOOLTIP_LDAP_ATTRIBUTE_IDENTIFYING_USER = "Attribute Identifying User:",

            IDS_AA_WINDOW_CONTROL_TOOLTIP_DOMAINNAME = "Active directory fully qualified domain name",
            IDS_AA_WINDOW_CONTROL_TOOLTIP_DOMAINNAMESERVER = "Active directory IP address or server fully qualified domain name",
            IDS_AA_WINDOW_CONTROL_TOOLTIP_AD_LDAP_PORT = "Active directory LDAP port",
            IDS_AA_DIALOG_MESSAGE_SSO_FAILURE_CLIENT_TICKET_VALIDATION = "It's not possible to perform SSO authentication due to a kerberos ticket validation error.",

            IDS_GS_RADIUS_CLIENT = "Client Settings",
            IDS_GS_RADIUS_SERVER = "Server Settings",
            IDS_GS_RADIUS_ALT_SERVER = "Server Settings",

            IDS_TOOLTIP_RADIUS_TIMEOUT_SPINNER = "Timeout";

    private USMStringTable() {
    }
}