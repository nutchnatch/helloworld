/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.auth;

import com.ossnms.bicnet.securitymanagement.client.SMSettingsProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 This class store the user history 
 Contains
  - Last user name used to login at server
  - Last 10 servers  on which user logged in successfully
  - SSO checkbox state
  
 Don't forget to increment serialVersionUID if private fields change.
 */
public class AALogonHistoryData implements Serializable {
	static final long serialVersionUID = 3L;

	private static final String DEFAULT_PORT_SUFFIX = ":" + SMSettingsProperties.getServerDefaultPort();

    /**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(AALogonHistoryData.class);

	/**
	 * Data member to store user name 
	 */
	private String userName = "";

	/**
	* Data member to store last successful logged in server list
	*/
	private List<LogonHistoryEntry> serverList = new ArrayList<>(0);

	/*
	 * Data member to store ssoCheckBox state
	 */
	private boolean ssoCheckBox = false;

	/**
	 * Returns list of servers.
	 * 
	 *@return List - List of server
	 *
	 */
	public List<LogonHistoryEntry> getServerList() {
		return serverList;
	}

	/**
	 * Returns the user id used for last login
	 * 
	 *@return String
	 *
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * Returns the ssoCheckBox state used for last login
	 * 
	 *@return boolean
	 *
	 */
	public boolean getSsoCheckBox() {
		return ssoCheckBox;
	}
	
	/**
	 * Adds entry to list of servers.
	 * @param hostname new hostname to add
	 */
	public void addServer(String hostname) {
		addServer(new LogonHistoryEntry(hostname, null));
	}

	/**
	 * Adds entry to list of servers. Entry will be added to the top of the list.
	 * If the same server is already on the list, the old entry will be removed so
	 * that each server appears only once in the list.
	 */
	public void addServer(LogonHistoryEntry server) {
		LOGGER.debug("addServer({}, {})         Entry", server.getServer(), server.getServerLabel());

		String strippedHostname = server.getServer().replace(DEFAULT_PORT_SUFFIX, "");

		removeFromServerList(strippedHostname);
		serverList.add(0, new LogonHistoryEntry(strippedHostname, server.getServerLabel()));

		LOGGER.debug("addServer({}, {})         Exit", server.getServer(), server.getServerLabel());
	}

	/**
	 * Clear any marks that are on the list
	 */
	public void clearServerLabels() {
		for (LogonHistoryEntry server : serverList) {
			server.setServerLabel(null);
		}
	}

	/**
	 * Sets the user name used to logged in
	 *
	 *@param user user name
	 *@return void
	 *
	 */
	public void setUserName(String user) {
		userName = user;
	}

	/**
	 * Sets the ssoCheckBox state used to logged in
	 *
	 *@param state new state
	 *@return void
	 *
	 */
	public void setSsoCheckBox(boolean state) {
		ssoCheckBox = state;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
    public String toString() {
		String str =
			"User ID : " + userName + " Server List : " + serverList;
		return str;
	}

	private void removeFromServerList(String hostname) {
		for (Iterator<LogonHistoryEntry> iterator = serverList.iterator(); iterator.hasNext(); ) {
			LogonHistoryEntry server = iterator.next();
			if (server.getServer().equals(hostname)) {
				iterator.remove();
				break;
			}
		}
	}
}
