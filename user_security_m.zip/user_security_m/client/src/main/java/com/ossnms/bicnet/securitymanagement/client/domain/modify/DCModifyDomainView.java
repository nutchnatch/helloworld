/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCModifyDomainView
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CONFIG
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 18-Jan-2005	Muyeen Munaver	CF00702 - The "OK" could became Grey in the "New User" window
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 09-02-2005	Babu B          CF000060-01   CF USM GUI Requirements
 * 
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain.modify;

import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMHelp;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.bicnet.securitymanagement.client.domain.common.DCCreateModifyBaseView;
import com.ossnms.bicnet.securitymanagement.client.domain.common.DCCreateModifyDomainProxy;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import org.apache.log4j.Logger;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

/**
 * This window is invoked when the user clicks "Create" button in the Domain Configuration Window. This acts as the user
 * interface to create a new domain
 */
public class DCModifyDomainView extends DCCreateModifyBaseView {

    private static final long serialVersionUID = -1384293994227976585L;

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(DCModifyDomainView.class);

    /**
     * This represents the domain for which modification is to be performed
     */
    DCDomainData mDomain;

    /**
     * This is the constructor
     */
    DCModifyDomainView(DCDomainData pDomain) {
        super(null, getButtons(), null, "com.ossnms.bicnet.securitymanagement.client.domain.modify.DCModifyDomainView" + "-" + pDomain.getDomainName(), USMStringTable
                .getString(USMStringTable.IDS_DC_MODIFY_DOMAIN_TITLE), true, USMHelp.HID_MODIFY_DOMAIN);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("DCModifyDomainView(" + pDomain + ") - Enter");
        }
        mDomain = pDomain;
        txtFldName.setText(pDomain.getDomainName());
        txtDesc.setText(pDomain.getDomainDescr());
        txtFldName.setEditable(false);

        associatedClientController = new DCCreateModifyDomainProxy(this, pDomain);
        ((DCCreateModifyDomainProxy) associatedClientController).getAllSecurableObjects();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("DCModifyDomainView(" + pDomain + ") - Exit");
        }
    }

    /**
     * Function to return the Buttons that should be added
     * 
     * @return List which contains the List of Buttons to be added to the View
     */
    private static List getButtons() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getButtons() - Enter");
        }
        List vecBtns = new ArrayList();
        USMButtonType ok = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_OK, null, USMStringTable.IDS_DC_TOOLTIP_MODIFY_DOMAIN, true);
        vecBtns.add(ok);
        vecBtns.add(USMButtonType.BTN_TYPE_CANCEL);
        vecBtns.add(USMButtonType.BTN_SEPARATOR);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getButtons() - Exit");
        }
        return vecBtns;
    }

    /**
     * This method gets called when the Apply button is clicked.
     */
    public void onModify() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("onModify() - Enter");
        }
        String csDomainDescription = txtDesc.getText();

        DCDomainData domain = new DCDomainData(mDomain.getDomainName(), mDomain.getDomainID(), mDomain.getDomainUID(), csDomainDescription);
        // Forward Message to Interactor to Send Create Domain Request to Server.
        getProxy().modifyDomain(domain, getAssignedObjects(), getUnassignedObjects());
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("onModify() - Exit");
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView_BtnPnl_StatusBar#handleButtonClick(com.ossnms
     * .bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum)
     */
    @Override
    public void handleButtonClick(USMButtonTypeEnum type) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleButtonClick(" + type + ") - Enter");
        }
        if ((USMButtonTypeEnum.BTN_TYPE_OK).equals(type)) {
            onModify();

        } else {
            super.handleButtonClick(type);
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleButtonClick(" + type + ") - Exit");
        }
    }

    @Override
    protected void enableDisableControls() {
        enableAllButtons();
    }

    @Override
    public boolean isDockable() {
        return false;
    }
    
    @Override
    public Icon getIcon() {
        return ResourcesIconFactory.ICON_WINDOW_DOMAIN_16;
    }
}
