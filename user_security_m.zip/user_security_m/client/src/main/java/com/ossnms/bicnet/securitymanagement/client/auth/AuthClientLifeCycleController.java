/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AuthClientLifeCycleController
 * Author      	Jogender Singh
 * Substitute	Babu B
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.CLIENT.REGSITER_MENU
 *        
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.auth;

import com.ossnms.bicnet.securitymanagement.client.basic.USMClientLifeCycleControllerIfc;

/**
* This class is responsible for the initialization and cleanup activities to be
* performed by the subsystem Auth. These activities are performed at the start of
* the Client process and at the closure of the Client process. This
* class is responsible for registring the Commands with the UICommandRegister. 
*/
public final class AuthClientLifeCycleController
	implements USMClientLifeCycleControllerIfc {

	/**
	* Static data member to hold the static data object
	*/
	private static AuthClientLifeCycleController instance = null;

	/**
	* Constructor
	*/
	private AuthClientLifeCycleController() {
		//super(USMSubSysId.AA);
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.common.basic.USMLifeCycleController#initialize()
	 */
	@Override
    public boolean initialize() {
		new AAChangePasswordCommand();
		//Fault ID 30
		AASessionClientController.getInstance();
		return true;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.common.basic.USMLifeCycleController#cleanup()
	 */
	@Override
    public boolean cleanup() {
		return true;
	}

	/**
	* Static function to retrieve the static instance of the
	* ASClientLifeCycleController's instance
	*
	* @return ASClientLifeCycleController The singleton object.
	*/
	public static synchronized AuthClientLifeCycleController getInstance() {
		if (null == instance) {
			instance = new AuthClientLifeCycleController();
		}
		return instance;
	}
}