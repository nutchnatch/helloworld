package com.ossnms.bicnet.securitymanagement.client.useradministration.passwordvalidation;

import java.util.Objects;

/**
 *
 */
public class UAPasswordValidationParams {

    private String oldPassword;
    private String newPassword;
    private String confirmNewPassword;
    private String employeeId;
    private String lastName;
    private String firstName;
    private String userName;
    private String currentDate;

    public UAPasswordValidationParams() {
    }

    public UAPasswordValidationParams(String newPassword, String employeeNumber,
                                      String lastName, String firstName,
                                      String oldPassword, String confirmNewPassword,
                                      String userName, String currentDate) {
        this.newPassword = newPassword;
        this.employeeId = employeeNumber;
        this.lastName = lastName;
        this.firstName = firstName;
        this.oldPassword = oldPassword;
        this.confirmNewPassword = confirmNewPassword;
        this.userName = userName;
        this.currentDate = currentDate;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getOldPassword() {
        return oldPassword;
    }

    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }

    public String getConfirmNewPassword() {
        return confirmNewPassword;
    }

    public void setConfirmNewPassword(String confirmNewPassword) {
        this.confirmNewPassword = confirmNewPassword;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getCurrentDate() {
        return currentDate;
    }

    public void setCurrentDate(String currentDate) {
        this.currentDate = currentDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UAPasswordValidationParams that = (UAPasswordValidationParams) o;
        return  Objects.equals(getOldPassword(), that.getOldPassword()) &&
                Objects.equals(getNewPassword(), that.getNewPassword()) &&
                Objects.equals(getConfirmNewPassword(), that.getConfirmNewPassword()) &&
                Objects.equals(getCurrentDate(), that.getCurrentDate()) &&
                equalsUserInformation(that);
    }

    /**
     *
     * @param that
     * @return
     */
    private boolean equalsUserInformation(UAPasswordValidationParams that) {
        return  Objects.equals(getEmployeeId(), that.getEmployeeId()) &&
                Objects.equals(getLastName(), that.getLastName()) &&
                Objects.equals(getFirstName(), that.getFirstName()) &&
                Objects.equals(getUserName(), that.getUserName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getOldPassword(), getNewPassword(), getConfirmNewPassword(), getEmployeeId(), getLastName(), getFirstName(), getUserName(), getCurrentDate());
    }
}
