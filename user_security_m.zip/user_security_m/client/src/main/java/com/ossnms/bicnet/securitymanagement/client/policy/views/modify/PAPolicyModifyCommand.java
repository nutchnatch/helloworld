/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	PAPolicyModifyCommand
 * Author      	Vinay Purohit
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID	:	TNMS.DX2.SM.POLICY.ADMIN
 * 			
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.policy.views.modify;

import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import org.apache.log4j.Logger;

/**
 * This Command Class is the Handler for Modifying
 * an existing policy.
 */
public class PAPolicyModifyCommand extends USMCommand {
	private PAPolicyId policy;

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(PAPolicyModifyCommand.class);

	/**
	 * Default Constructor. Registers itself with the UI Frame work
	 */
	public PAPolicyModifyCommand() {
		// Initialize the Base Class.
		super(USMCommandID.S_UI_ID_MODIFY_POLICY);
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#createAndReturnView()
	 */
	@Override
    protected USMBaseView createAndReturnView() {
		return new PAPolicyModifyView(policy);
	}
	/* (non-Javadoc)
		 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#compare(com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand)
		 */
	@Override
    public boolean compare(USMCommand cmd) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("compare(" + cmd + ") - Enter");
		}

		PAPolicyModifyCommand oldCmd = (PAPolicyModifyCommand) cmd;

		//Check if the we have the same domain already in this command
		boolean ret = oldCmd.policy.equals(this.policy);

		if (LOGGER.isInfoEnabled()) {
            String traceStr = "Modify window for the domain " + policy;
			traceStr += "Old window having domain " + oldCmd.policy;
			LOGGER.info(traceStr);
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("compare(" + cmd + ") - Exit: Return :" + ret);
		}
		return ret;

	}

	/* (non-Javadoc)
	   * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#cloneCmd(java.lang.Object)
	   */
	@Override
    public USMCommand cloneCmd(Object selList) {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("cloneCmd(" + selList + ") - Enter");
		}
		PAPolicyModifyCommand newCmd = new PAPolicyModifyCommand();
		if (LOGGER.isInfoEnabled()) {
            String traceStr = "cloning command for the domain " + selList;
			LOGGER.info(traceStr);
		}

		newCmd.policy = (PAPolicyId) selList;

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"cloneCmd(" + selList + ") - Exit : Return :" + newCmd);
		}
		return newCmd;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#getKey()
	 */
	@Override
    public Object getKey() {
		return policy;
	}
}
