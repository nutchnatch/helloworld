/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	BSCFCommand
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID 	 : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 * 		
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.bicnetserver.configuration;

import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * This class is the Command Object for the TMN Application Server Administration
 * Window
 * 
 */
public class BSCFCommand extends USMCommand {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(BSCFCommand.class);

	/**
	 * Constructor
	 */
	public BSCFCommand() {
		super(USMCommandID.S_UI_ID_VIEW_TMN_APPLICATION_SERVER);
		LOGGER.debug("Inside the constructor of BSCFCommand. Result of registration is : {}", isCmdHndlrRegistered());
	}

	/**
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#createAndReturnView()
	 */
	protected USMBaseView createAndReturnView() {
		LOGGER.debug("Entering createAndReturnView");
		BSCFView view = new BSCFView();
		LOGGER.debug("Exiting createAndReturnView");

		return view;
	}
    
    /* (non-Javadoc)
     * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#getKey()
     */
    public Object getKey() { 
        return "Application Server View";
    }
}
