package com.ossnms.bicnet.securitymanagement.client.policy.views.modify;

import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMHelp;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.bicnet.securitymanagement.client.policy.views.base.PACreateModifyBaseView;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxText;
import org.apache.log4j.Logger;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

/**
 * This class models the Modify Policy Window. 
 */
public class PAPolicyModifyView extends PACreateModifyBaseView {

	private static final long serialVersionUID = -2350468037188292494L;

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(PAPolicyModifyView.class);

	/**
	 * Data member to hold the Policy for which this window
	 * has been opened.
	 */
	PAPolicyId selectedPolicy = null;

	/**
	 * Data member to hold the complete Policy for which
	 * this window was opened
	 */
	PAPolicyData selectedPolicyData = null;
	private static final String METHOD_ON_POLICY_DELETED = "onPolicyDeleted ()";

	/**
	 * Constructor
	 * 
	 */
	public PAPolicyModifyView(PAPolicyId policyNameAndID) {
        super(null, getButtons(), null, "PAPolicyModifyView.com.ossnms.bicnet.securitymanagement.client.policy.PAPolicyCreateView_1" + "-"
                        + policyNameAndID.getPolicyName(), JfxStringTable.getString(USMStringTable.IDS_PA_MODIFY_TITLE), true, USMHelp.HID_MODIFY_POLICY);
		selectedPolicy = policyNameAndID;
		associatedClientController = new PAPolicyModifyClientController(this);
        LOGGER.info("getting_nonconfig_menu_options_for_policy___3" + selectedPolicy.getPolicyName());
		((PAPolicyModifyClientController) associatedClientController).sendRequestToFetchPolicyInformation(policyNameAndID);
	}
	
	void setValueOfComponents(String name, String desc) {
		txtFldName.setText(name);
		txtDesc.setText(desc);
		txtFldName.setEnabled(false);
	}

	/**
	 * Returns the list of buttons in the window
	 *
	 * @return List - List of buttons
	 */
	private static List<USMButtonType> getButtons() {
	    List<USMButtonType> buttons = new ArrayList<>();

        USMButtonType ok = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_OK, null, new JfxText("Modifies the Policy"), true);
        buttons.add(ok);
		buttons.add(USMButtonType.BTN_TYPE_CANCEL);
		return buttons;
	}

    /**
     * Helper function that will be called when the user selects the modify policy button.
     */
	private void modifyPolicy() {
		// Get the new Vector of Assigned Menu Options.
		List<PAPermissionData> permissions = getPermissions(S_RIGHT_LIST);

		PAPolicyData modifiedPolicyData =
			new PAPolicyData(
					selectedPolicy.getPolicyID(),
					selectedPolicy.getPolicyName(),
					getDescription(),
					permissions,
					selectedPolicyData.getCreationTimeStamp(),
					selectedPolicyData.getModificationTimeStamp());

		LOGGER.info("  sending request to controller");

        ((PAPolicyModifyClientController) associatedClientController).sendRequestToModifyPolicy(modifiedPolicyData);
	}

	/**
	 * Function called when Policies are deleted.
	 * 
	 * @param deletedPolicies The List of Policies that are deleted.
	 */
	void onPolicyDeleted(List<PAPolicyId> deletedPolicies) {
		LOGGER.debug(METHOD_ON_POLICY_DELETED + " ENTER_FUNCTION");

		if (deletedPolicies != null) {
			for (PAPolicyId deletedPolicy : deletedPolicies) {
				if ((selectedPolicy != null) && (deletedPolicy != null)) {
					if (deletedPolicy.equals(selectedPolicy)) {
						closeWindowOnObjectDeletion();
					}
				}
			}
		}

		LOGGER.debug(METHOD_ON_POLICY_DELETED + "EXIT_FUNCTION");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView_BtnPnl_StatusBar#handleButtonClick(com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType)
	 */
	@Override
    public void handleButtonClick(USMButtonTypeEnum type) {
		if ((USMButtonTypeEnum.BTN_TYPE_OK).equals(type)) {
			modifyPolicy();
		} else if ((USMButtonTypeEnum.BTN_TYPE_CANCEL).equals(type)) {
			close();
		} else {
			LOGGER.info("unexpected...");
		}

	}

    /**
     * Function to show a message to the user
     * 
     * @param comp The Component which is the parent window.
     * @param message The Text that should be displayed
     */
    public void showMessage(final java.awt.Component comp, String message) {
        bringToFront();
        JfxOptionPane.showMessageBox(this, message);
    }

	/*
	 * Function to set the Policy Data.
	 */
	void setPolicyData(PAPolicyData policyData) {
		selectedPolicyData = policyData;
	}

	@Override
    protected void enableDisableControls() {
		enableAllButtons();
	}
	
    @Override
    public boolean isDockable() {
        return false;
    }
    
    @Override
    public Icon getIcon() {
    	return ResourcesIconFactory.ICON_WINDOW_POLICY_16;
    }
}