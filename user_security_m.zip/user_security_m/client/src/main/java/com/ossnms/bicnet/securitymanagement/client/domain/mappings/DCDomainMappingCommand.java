/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCDomainMappingCommand
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.MAPPING.CREATE
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain.mappings;

import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import org.apache.log4j.Logger;

/**
 * The command handler class which initiates the domain mapping user interface
 * window
 */
public class DCDomainMappingCommand extends USMCommand {

	/**
	 * This represents the domain for which mapping is to be performed
	 */
	private DCDomainData domain;

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(DCDomainMappingCommand.class);

	/**
	 * Default constructor
	 *
	 */
	public DCDomainMappingCommand() {
		super(USMCommandID.S_UI_ID_ASSIGN_MAPPINGS);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("DCDomainMappingCommand() - Enter/Exit");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#createAndReturnView()
	 */
	@Override
    protected USMBaseView createAndReturnView() {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("createAndReturnView() - Enter");
		}
		USMBaseView dcView = new DCDomainMappingView(domain);
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info(
				"Opening of the mapping window for the domain " + domain);
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("createAndReturnView() - Exit : Return :" + dcView);
		}
		return dcView;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#compare(com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand)
	 */
	@Override
    public boolean compare(USMCommand cmd) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("compare(" + cmd + ") - Enter");
		}

		DCDomainMappingCommand oldCmd = (DCDomainMappingCommand) cmd;

		//Check if the we have the same domain already in this command
		boolean ret = oldCmd.domain.equals(this.domain);

		if (LOGGER.isInfoEnabled()) {
            String traceStr = "Mapping window for the domain " + domain;
			traceStr += "Old window having domain " + oldCmd.domain;
			LOGGER.info(traceStr);
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("compare(" + cmd + ") - Exit: Return :" + ret);
		}

		return ret;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#cloneCmd(java.lang.Object)
	 */
	@Override
    public USMCommand cloneCmd(Object selList) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("cloneCmd(" + selList + ") - Enter");
		}

		DCDomainMappingCommand newCmd = new DCDomainMappingCommand();
		newCmd.domain = (DCDomainData) selList;

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"cloneCmd(" + selList + ") - Exit : Return :" + newCmd);
		}
		return newCmd;
	}
    
    /* (non-Javadoc)
     * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#getKey()
     */
    @Override
    public Object getKey() { 
        return domain;
    }
    
}
