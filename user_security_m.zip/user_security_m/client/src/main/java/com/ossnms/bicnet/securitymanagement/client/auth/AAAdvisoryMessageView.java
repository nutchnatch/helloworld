/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 09-02-2005	Babu B          CF000060-01   CF USM GUI Requirements
 * 14-Feb-2005  Babu B          CF001294    Time US Central Time - "User Administration" window
 * 22-Jun-2005  Muyeen Munaver  CF002307	BST, GMT and CST -> wrong hours
 * 06-Oct-2005	Balasubramanya	CF002924	USM Error messages in server.log
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.auth;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientProperties;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.tools.jfx.ETimeDisplay;
import com.ossnms.tools.jfx.JfxDate;
import com.ossnms.tools.jfx.JfxFormPanel;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxTextArea;
import com.ossnms.tools.jfx.components.JfxTextField;
import org.apache.log4j.Logger;

import javax.swing.*;
import java.awt.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Collections;
import java.util.Date;

/**
 * This class will display the Advisory Message window. Whenever operator logs in, this window will be displayed if
 * general setting is configured to display this window.
 */
public class AAAdvisoryMessageView extends USMBaseViewWithButtons {
    private static final long serialVersionUID = -713134632835109030L;

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(AAAdvisoryMessageView.class);

    /**
     * Data member for the Window title.
     */
    private static final String WINDOW_TITLE = USMStringTable.IDS_AA_WINDOW_ADVISORY_MESSAGE.toString();

    /**
     * Data member for the class ID.
     */
    private static final String CLASS_ID = "com.ossnms.bicnet.securitymanagement.client.auth.AAAdvisoryMessageView";
    /**
     * Data member to hold advisory message gui frame.
     */
    protected transient BiCNetPluginFrame mFrame = null;
    /**
     * Data m,ember to hold advisory message is accepted or rejected
     */
    protected boolean mBClose = false;

    /**
     * Data member for holding help ID for the window. No help for this window.
     */
    private static final int HELP_ID = 0;

    /**
     * Windows control label constants
     */
    private static final String WINDOW_CONTROL_LABEL_USERNAME = USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_USERNAME.toString();
    private static final String WINDOW_CONTROL_LABEL_LAST_LOGIN_TIME = USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_LAST_LOGIN_TIME.toString();

    /**
     * GUI elements
     */
    private JfxTextArea messageTextArea;
    private JfxTextField userTextField;
    private JfxTextField timeTextField;
    
    private static final int ADVISORY_WINDOW_WIDTH  = 527;
    private static final int ADVISORY_WINDOW_HEIGHT  = 424;

    /** Default Constructor */
    public AAAdvisoryMessageView() {
        super(null, Collections.singletonList(new USMButtonType(USMButtonTypeEnum.BTN_TYPE_OK, null, null, true)),
                null, CLASS_ID, WINDOW_TITLE, true, false, HELP_ID);
        initComponents();
        setGuiNames();
    }

    /**
     * initialize all the GUI elements for this window
     */
    private void initComponents() {
        this.setPreferredSize(new Dimension(ADVISORY_WINDOW_WIDTH, ADVISORY_WINDOW_HEIGHT));

        JfxFormPanel mainPanel = getPanelForPlacingDerviedControls();
        mainPanel.setLayout(new GridBagLayout());
        
        LOGGER.debug("initComponents() Entry");
        
        mainPanel.setBorder(JfxUtils.DIALOG_OUTSIDE_BORDER);
        
        JfxLabel userIDLabel = new JfxLabel();
        userTextField = new JfxTextField();
        JfxLabel timeLabel = new JfxLabel();
        timeTextField = new JfxTextField();
        messageTextArea = new JfxTextArea();
        JScrollPane scrollPane = new JScrollPane(messageTextArea);
        //workaround for growing textarea
        scrollPane.setPreferredSize(new Dimension(1,1));

        userIDLabel.setText(WINDOW_CONTROL_LABEL_USERNAME);
        userTextField.setEditable(false);
        timeLabel.setText(WINDOW_CONTROL_LABEL_LAST_LOGIN_TIME);
        timeTextField.setEditable(false);
        messageTextArea.setWrapStyleWord(true);
        messageTextArea.setEditable(false);
        messageTextArea.setLineWrap(true);

        mainPanel.add(userIDLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(JfxUtils.LABEL_TOP_MARGIN, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        mainPanel.add(userTextField, new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        mainPanel.add(timeLabel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(JfxUtils.LABEL_TOP_MARGIN, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        mainPanel.add(timeTextField, new GridBagConstraints(1, 1, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        mainPanel.add(scrollPane, new GridBagConstraints(0, 2, 2, 2, 1.0, 1.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));

        LOGGER.debug("initComponents() Exit");
    }

    private void setGuiNames() {
        setButtonName(USMButtonTypeEnum.BTN_TYPE_OK, "Ok");
    }

    /**
     * Sets the default focus to Ok button.
     */
    public void setFocus() {
        requestFocus(USMButtonTypeEnum.BTN_TYPE_OK);
    }

    /**
     * Sets the component's frame.
     * @param frame
     *            - advisory message gui frame.
     */
    @Override
    public void setFrame(BiCNetPluginFrame frame) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Coming here in SetFrame Method");
        }
        mFrame = frame;
    }

    /**
     * Returns whether user confirmed the dialog.
     * @return boolean - if advisory message is accepted and ok pressed then it will return true else false
     */

    public final boolean isClose() {
        return mBClose;
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getComponent()
     */
    @Override
    public JComponent getComponent() {
        return this;
    }

    /**************************************************************************
     * Called when user pressed "OK" button.
     **************************************************************************/
    protected void actionOK() {
        LOGGER.debug(" actionOK(ActionEvent e) Entry");
        mFrame.closeFrame();
        mBClose = false;
        LOGGER.debug(" actionOK(ActionEvent e) Exit");
    }

    /**
     * Sets the value displayed for the advisory message and scrolls to the top.
     * @param advisoryMessage
     *            - Advisory Message Content.
     */
    public void setAdvisoryMessage(String advisoryMessage) {
        messageTextArea.setText(advisoryMessage);
        messageTextArea.setCaretPosition(0);
    }

    /**
     * Returns the value displayed for the advisory message.
     * @return String - Advisory Message Content.
     */
    public String getAdvisoryMessage() {
        return messageTextArea.getText();
    }

    /**
     * Sets the value displayed for the user name.
     * @param strUserName
     *            - Logged in user name.
     */
    public final void setUserName(String strUserName) {
        userTextField.setText(strUserName);
    }

    /**
     * Returns the value displayed for the user name.
     * @return String - return the user name displayed in the advisory message window.
     */
    public final String getUserName() {
        return userTextField.getText();
    }

    /**
     * Returns the correct Time Display
     */
    private ETimeDisplay getETimeDisplay() {
        // Query Configured TimeZone for Display
        BiCNetPluginSite pluginSite = USMUtility.getInstance().getSecuritySite();
        String strTimeDisplay = pluginSite.getClientProperty(BiCNetPluginClientProperties.TIME_DISPLAY, BiCNetPluginClientProperties.TIME_DISPLAY_CST);

        // Get the enum value
        ETimeDisplay eTimeDisplay = null;
        if (strTimeDisplay.compareTo(BiCNetPluginClientProperties.TIME_DISPLAY_LOCAL) == 0) {
            eTimeDisplay = ETimeDisplay.fromInteger(ETimeDisplay.i_LOCALTIME);
        } else if (strTimeDisplay.compareTo(BiCNetPluginClientProperties.TIME_DISPLAY_GMT) == 0) {
            eTimeDisplay = ETimeDisplay.fromInteger(ETimeDisplay.i_GMT);
        } else { // by default, CST
            eTimeDisplay = ETimeDisplay.fromInteger(ETimeDisplay.i_CST);
        }

        return eTimeDisplay;
    }

    /**
     * Sets the value displayed for the last login time.
     * @param lastLoginTime
     *            - user last last login time.
     */
    public final void setLastLoginTime(String lastLoginTime) {
        DateFormat dateFormatter = USMCommonHelper.getUSMDateFormatter();

        LOGGER.info("The last login time " + lastLoginTime);
        LOGGER.debug("dateFormatter " + dateFormatter);
        LOGGER.debug("USM Date Parsing Locale Set ");
        
        String strFormattedTime = null;
        if ((lastLoginTime != null) && (lastLoginTime.length() > 0)) {
            // Convert to Date
            Date creationTime = null;
            try {
                dateFormatter.setLenient(true);
                creationTime = dateFormatter.parse(lastLoginTime);
            } catch (ParseException e) {
                LOGGER.warn("Last login time string could not be parsed", e);
            }
            LOGGER.info("creationTime After Date Format operation " + creationTime);
            if (creationTime != null) {
                ETimeDisplay fmtTimeDisplay = getETimeDisplay();
                strFormattedTime = (new JfxDate((creationTime.getTime()))).format(fmtTimeDisplay.getTimeZone()) + " (" + fmtTimeDisplay.getDisplayName() + ")";
            }
        }
        timeTextField.setText(strFormattedTime);
    }

    /**
     * Returns the value displayed for the last login time.
     * @return String - user last last login time.
     */
    public final String getLastLoginTime() {
        return timeTextField.getText();
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#eventClosing()
     */
    @Override
    public void eventClosing() {
        mBClose = false;
    }
    
    @Override
    public boolean isDockable() {
        return false;
    }

    @Override
    public void handleButtonClick(USMButtonTypeEnum type) {
        if(type == USMButtonTypeEnum.BTN_TYPE_OK) {
            actionOK();
        }
    }

    @Override
    protected void enableDisableControls() {
        // do nothing
    }
}