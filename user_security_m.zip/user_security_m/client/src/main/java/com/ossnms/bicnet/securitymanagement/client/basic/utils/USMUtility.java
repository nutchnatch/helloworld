/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMUtility
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Muyeen Munaver	CF000889 - Client-time-out-box often hidden behind TNMS DX client main window
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 11-Jan-2005	Muyeen Munaver	CF001699 - Logged in Clients+set inactivity to 2=>Clients are not logged off
 * 14-Apr-2005	Muyeen Munaver	CF001025	Stop the Server - message to the clients
 * 06-May-2009  Nagaraddi S S    TD004578 - RQT-STDERR errors instead log4j's
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.utils;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientProperties;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.bicnet.framework.client.helpers.FrameworkPluginHelper;
import com.ossnms.bicnet.securitymanagement.client.SecurityPlugin;
import com.ossnms.bicnet.securitymanagement.client.useradministration.passwordvalidation.UAPasswordValidationUtility;
import com.ossnms.tools.jfx.ETimeDisplay;
import com.ossnms.tools.jfx.JfxDate;
import com.ossnms.tools.jfx.JfxText;
import com.ossnms.tools.jfx.JfxValidatorUtils;
import org.apache.commons.validator.routines.EmailValidator;
import org.apache.log4j.Logger;

import javax.swing.*;
import java.security.InvalidParameterException;
import java.util.Arrays;

/**
 * This class is a Utility class that is used by the classes of USM. It is a
 * kind of a holder for some of the important interfaces. These are  -
 * <p/>
 * 1. BiCNetPluginSite
 * 2. ISecureClientSession
 */
public final class USMUtility extends FrameworkPluginHelper {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(USMUtility.class);

    /**
     * Data member to hold the site information
     */
    private static BiCNetPluginSite securitySite;

    /**
     * Data member to hold the ISecureClientSession object.
     */
    private static ISecureClientSession clientSession;

    /**
     * Data member to hold the Session Context that should be passed between the
     * Server and the client
     */
    private ISessionContext sessionCtx = null;

    /**
     * Data member to hold the Logoff reason that triggered logoff
     */
    private LogoffReason logoffReason = null;

    /**
     * Holds singleton instance
     */
    private static USMUtility instance = new USMUtility();

    /**
     * Data member to hold the inactivity Timeout Duration in minutes.
     */
    private static int inactivityTimeOut = 60;

    /**
     * Data member to hold the inactivity Timeout Warning Time in minutes.
     */
    private int inactivityTimeOutWarningTime = 0;

    /**
     * prevents instantiation
     */
    private USMUtility() {
        super(null);

        LOGGER.debug("USMUtility()");
    }

    /**
     * Returns the singleton instance.
     *
     * @return USMUtility
     * The singleton instance
     */
    public static USMUtility getInstance() {
        LOGGER.debug("USMUtility() getInstance() Entry & Exit");

        return instance;
    }

    /**
     * Function that should be called to initialize the class. This
     * would include -
     * Registration of this class with the USMLogonLogoffEvtRegistrar
     */
    public boolean initialize() {
        LOGGER.debug("initialize(): Initializing the component by registering for Logon events");

        return true;
    }

    /**
     * Function to return the site information
     *
     * @return BiCNetPluginSite - returns the site information
     */
    public BiCNetPluginSite getSecuritySite() {
        LOGGER.debug("getSecuritySite called. Returning : " + securitySite);

        return securitySite;
    }

    /**
     * Function to set the site information
     *
     * @param site - The site information for the security
     */
    public void setSecuritySite(BiCNetPluginSite site) {
        if (null == site) {
            LOGGER.error("Setting a null Site");
            throw new InvalidParameterException("Null Site is not allowed");
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setSecuritySite called. Value being set is : " + site);
        }

        securitySite = site;
        this.setCfPluginSite(site);
    }

    /**
     * Retrieve the Security Plugin
     */
    public SecurityPlugin getSecurityPlugin() {
        SecurityPlugin securityPlugin = null;
        try {
            securityPlugin = (SecurityPlugin) getSecuritySite().getSecurityProvider();
        } catch (Exception e) {
            LOGGER.error("Exception raised. ", e);
        }
        return securityPlugin;
    }

    /**
     * Helper function to return the ISecureClientSession object that
     * is stored.
     *
     * @return ISecureClientSession
     * The stored object
     */
    public ISecureClientSession getSecureClientSession() {
        LOGGER.debug("getSecureClientSession called. Returning : " + clientSession);

        return clientSession;
    }

    /**
     * Helper function to return the Session Context.
     *
     * @return
     */
    public ISessionContext getSessionContext() {
        LOGGER.debug("getSessionContext()");

        return this.sessionCtx;
    }

    @Override
    public ISessionContext getLogonContext() {
        return this.sessionCtx;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEventIfc#operatorLoggedOn()
     */
    public void operatorLoggedOn(ISessionContext sessionContext) {
        LOGGER.debug("operatorLoggedOn() Entry");

        this.sessionCtx = sessionContext;
        try {
            clientSession = securitySite.getSecurityProvider().getClientSession(this.sessionCtx);
        } catch (BiCNetPluginException e) {
            LOGGER.error("Exception :", e);
        }
        this.logoffReason = null;

        LOGGER.debug("operatorLoggedOn() Exit");
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEventIfc#operatorLoggedOff()
     */
    public void operatorLoggedOff(ISessionContext sessionContext) {
        LOGGER.debug("operatorLoggedOff() Entry: Setting m_ClientSession to null");

        clientSession = null;
        this.sessionCtx = null;

        LOGGER.debug("operatorLoggedOff() Exit");
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEventIfc#operatorLoggingOff()
     */
    public void operatorLoggingOff(ISessionContext sessionContext) {
        LOGGER.debug("operatorLoggingOff()");
    }

    // Fault ID 46 Provide Helper fucntion for Authrorization check - Begin

    /**
     * Helper function to check if the user has privileges to perform the operation
     *
     * @param strOperationId The Operation Id for the operation
     * @return boolean
     * Indicates whether the user has permission or not.
     */
    public boolean checkIfOperatorHasPermission(String strOperationId) {
        LOGGER.debug("Entering checkIfOperatorHasPermission. Menu Entry being passed is : " + strOperationId);

        boolean bAuthorized = false;
        if (clientSession != null) {
            bAuthorized = clientSession.checkOperationPermission(strOperationId);
        } else {
            LOGGER.error("ISecureClientSession is null");
        }

        LOGGER.debug("Exiting checkIfOperatorHasPermission. Menu Entry being passed was : " + strOperationId + " Result : " + strOperationId);
        return bAuthorized;
    }

    /**
     * Helper function to return the Inactivity Timeout duration
     *
     * @return int The Timeout Duration in minutes
     */
    public int getInactivityTimeOut() {
        LOGGER.debug("getInactivityTimeOut()");

        return inactivityTimeOut;
    }


    /**
     * Helper function to return the Inactivity Timeout Warning Time
     *
     * @return int The Inactivity Timeout Warning Time in minutes
     */
    public int getInactivityTimeoutWarningTime() {
        LOGGER.debug("getInactivityTimeoutWarningTime()");

        return inactivityTimeOutWarningTime;
    }

    /**
     * Helper function to set the Inactivity Timeout Duration
     *
     * @param inactivity The Timeout Duration in minutes.
     */
    public void setInactivityTimeOut(int inactivity) {
        LOGGER.debug("setInactivityTimeOut() Entry");

        inactivityTimeOut = inactivity;

        LOGGER.debug("setInactivityTimeOut() Exit");
    }

    /**
     * Helper function to set the Inactivity Timeout Warning Time
     *
     * @param inactivity The Inactivity Timeout Warning Time in minutes.
     */
    public void setInactivityTimeoutWarningTime(int inactivity) {
        LOGGER.debug("setInactivityTimeoutWarningTime() Entry");

        inactivityTimeOutWarningTime = inactivity;

        LOGGER.debug("setInactivityTimeoutWarningTime() Exit");
    }

    public LogoffReason getLogoffReason() {
        LOGGER.debug("getLogoffReason()");
        return logoffReason;
    }

    /**
     * Function to set the Logoff reason. The logoff info message and ServerContactedAtLogOff
     * will be configured based on the logoff reason.
     *
     * @param logoffReason The trigger used to logoff
     */
    public void setLogoffReason(IPluginSecurityProvider.LogoffReason logoffReason) {
        LOGGER.debug("setLogoffReason() Entry");
        this.logoffReason = LogoffReason.valueOf(logoffReason);
        LOGGER.debug("setLogoffReason() Exit");
    }

    /**
     * Function to return the message that should be displayed to the operator
     *
     * @return String Message to be displayed to the operator
     */
    public String getLogoffMessage() {
        LOGGER.debug("getLogoffMessage()");
        JfxText infoMessage = this.logoffReason.getInfoMessage();
        if (logoffReason == LogoffReason.INACTIVITY_TIMEOUT) {
            return infoMessage.getFormatedMessage(inactivityTimeOut);
        }
        return infoMessage != null ? infoMessage.toString() : null;
    }

    /**
     * Function to return whether the current state requires a log off call to
     * the server
     *
     * @return boolean Indicates whether to contact server or not.
     */
    public boolean isServerContactedAtLogOff() {
        LOGGER.debug("isServerContactedAtLogOff()");
        return this.logoffReason != null ? this.logoffReason.shouldContactServer() : true;
    }

    /**
     * Return whether the client should try to re-login after a logoff
     *
     * @return whether the client should try to re-login
     */
    public boolean shouldClientReLogin() {
        LOGGER.debug("shouldClientReLogin()");
        return this.logoffReason.shouldReLogin();
    }

    /**
     * This method could be used in order to validate an information within a
     * email field.
     *
     * @return True if the information matches the regex expressions, otherwise
     * false.
     */
    public static boolean isEMailValid(String eMail) {
        LOGGER.debug("isEMailValid() Entry");

        boolean isValidEmail = EmailValidator.getInstance(true).isValid(eMail);

        LOGGER.debug("isEMailValid() Exit");

        return isValidEmail;
    }

    /**
     * Simple utility method to validate the phone number. The only requirement
     * is that the given string contains at least one numerical value since this
     * is the only validation which LDAP requires.
     *
     * @param phoneNo telephone number to be validated
     * @return true when telephone is valid, otherwise false
     */
    public static boolean isTelephoneValid(String phoneNo) {
        if (phoneNo.length() > 0 && !phoneNo.matches(".*\\d.*")) {
            return false;
        }
        return true;
    }

    /**
     * Simple utility method to validate the fax number. According to the LDAP
     * specification, fax number must start with a valid "printable" character.
     *
     * @param faxNo the fax number to be validated
     * @return true if valid, otherwise false
     */
    public static boolean isFaxValid(String faxNo) {
        Character[] validSpecialChars = {'\'', '(', ')', '+', ',', '-', '.', '='};

        if (faxNo.length() < 1) {
            return true;
        }
        Character firstChar = faxNo.charAt(0);
        if (Character.isDigit(firstChar)) {
            return true;
        } else if ((firstChar >= 'a' && firstChar <= 'z') || (firstChar >= 'A' && firstChar <= 'Z')) {
            return true;
        } else {
            for (Character specialChar : Arrays.asList(validSpecialChars)) {
                if (firstChar.equals(specialChar)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Gets the current client time according to the client timezone.
     *
     * @param date to be converted. If no date is provided, the current time is used.
     * @return The date of the current time
     */
    public String convertDateToClientTimeZone(JfxDate date) {

        if(date==null){
            date = new JfxDate(System.currentTimeMillis());
        }

        LOGGER.debug("getCurrentETimeDisplay() Entry");
        ETimeDisplay obj;
        BiCNetPluginSite usmPluginSite = USMUtility.getInstance().getSecuritySite();
        String timeDisplayStr = usmPluginSite.getClientProperty(BiCNetPluginClientProperties.TIME_DISPLAY, BiCNetPluginClientProperties.TIME_DISPLAY_CST);

        if(timeDisplayStr.compareTo(BiCNetPluginClientProperties.TIME_DISPLAY_LOCAL) == 0) {
            obj = ETimeDisplay.fromInteger(ETimeDisplay.i_LOCALTIME);
        } else if(timeDisplayStr.compareTo(BiCNetPluginClientProperties.TIME_DISPLAY_GMT) == 0) {
            obj = ETimeDisplay.fromInteger(ETimeDisplay.i_GMT);
        } else { // by default, CST
            obj = ETimeDisplay.fromInteger(ETimeDisplay.i_CST);
        }

        LOGGER.debug("getCurrentETimeDisplay() Exit");
        return date.format(obj.getTimeZone());
    }

    public void updateWarningMessage(String result, JLabel label) {
        if(result.equals(UAPasswordValidationUtility.PasswordValidationResult.SUCCESS.getLabel())){
            JfxValidatorUtils.hideWarningIcon(label);
        } else {
            JfxValidatorUtils.showWarningIcon(label, result);
        }
    }
}
