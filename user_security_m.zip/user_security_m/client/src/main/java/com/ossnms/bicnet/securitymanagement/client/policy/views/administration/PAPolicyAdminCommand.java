/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	PAPolicyAdminCommand
 * Author      	Vinay purohit
 * Substitute	muyeen
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID	:	TNMS.DX2.SM.POLICY.ADMIN
 * 			
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.policy.views.administration;

import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;
import org.apache.log4j.Logger;

/**
 * This Command Class is the Handler for
 * 1. Opening the Policy Administration Window and displaying all the configured policies.
 * 2. Deleting an existing Policy from the list of all available policies.
 */
public class PAPolicyAdminCommand extends USMCommand {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(PAPolicyAdminCommand.class);

	/**
	 * Default Constructor.
	 * Registers itself with the UI Frame work
	 */
	public PAPolicyAdminCommand() {

		// Initialize the Base Class.
		super(USMCommandID.S_UI_ID_VIEW_POLICIES);
		LOGGER.info("PAPolicyAdminCommand  in the constructor");
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#createAndReturnView()
	 */
	@Override
    protected USMBaseView createAndReturnView() {
		LOGGER.debug("createAndReturnView() entering method");
		return new PAPolicyAdminView();
	}

	/* (non-Javadoc)
	* @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#cloneCmd(java.lang.Object)
	*/
	@Override
    public USMCommand cloneCmd(Object selList) {
		LOGGER.info("inside clone ");
		return new PAPolicyAdminCommand();
	}
}
