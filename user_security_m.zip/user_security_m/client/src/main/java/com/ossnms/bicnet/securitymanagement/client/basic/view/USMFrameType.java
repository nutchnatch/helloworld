/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:           USM
 * Author:              USM Team, SCS Bangalore
 * Substitute:          
 *
 * --------------------------------------------------------
 * History
 * created: 			09-06-2004
 * first version completed: 	18-06-2004
 *
 * <date>       <author>        <reason(s) of change>
 * 
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.view;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;

/**
 * This class is an encapsulation class for the different kinds of
 * frames that can be created by Plugin's. Rather then each of the 
 * Views having a dependency on the BiCNetPluginFrameType, this class
 * provides an encapsulated instance.
 */
public final class USMFrameType {
	/**
	 * Internal frame (MDI child window).
	 */
	public static final USMFrameType S_INTERNAL =
		new USMFrameType(BiCNetPluginFrameType.INTERNAL);

	/**
	 * External frame (Nonmodal dialog or secondary frame).
	 */
	public static final USMFrameType S_EXTERNAL =
		new USMFrameType(BiCNetPluginFrameType.EXTERNAL);

	/**
	 * Docked window.
	 */
	public static final USMFrameType S_DOCKED =
		new USMFrameType(BiCNetPluginFrameType.DOCKED);

	/**
	 * Modal dialog.
	 */
	public static final USMFrameType S_MODAL =
		new USMFrameType(BiCNetPluginFrameType.MODAL);

	/**
	 * Data member for the Logging of the class.
	 */
	//	private static final BiCNetLogger LOGGER = BiCNetLogger.getLogger(USMFrameType.class);

	/**
	 * Data attribute to hold the encapsulating Frame Type of BicNet
	 */
	private BiCNetPluginFrameType frmType;

	/**
	 * Constructs the enum object. Only predefined instances are allowed.
	 * 
	 * @param frmType This is the Frame Type of BicNet
	 */
	private USMFrameType(BiCNetPluginFrameType frmType) {
		this.frmType = frmType;
	}

	/**
	 * Returns the Frame type
	 * 
	 * @return BiCNetPluginFrameType - returns the Frame type
	 */
	BiCNetPluginFrameType getFrameType() {
		return frmType;
	}
}
