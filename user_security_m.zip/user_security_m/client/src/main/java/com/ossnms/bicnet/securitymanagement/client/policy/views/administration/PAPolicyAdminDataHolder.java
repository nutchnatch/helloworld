package com.ossnms.bicnet.securitymanagement.client.policy.views.administration;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import org.apache.log4j.Logger;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

/**
 * This class represents the data that is used by the Policy Administration Window.
 * The data is set and updated by the Client controller and the Window refreshes
 * itself from the data.
 */
class PAPolicyAdminDataHolder {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(PAPolicyAdminDataHolder.class);

	/**
	 * This attribute stores the current policy Selection(s) in the Left pane of the
	 * Policy Administration Window.
	 * Vector of PAPolicyNameAndID.
	 */
	private List<PAPolicyId> selectedPolicies;

	/**
	 * This contains All the Configured Policies.
	 * This is a list of data structures of the form PAPolicyNameAndID [ POLICY ID  , POLICY NAME ]
	 * The Policy Names from this list are displayed in the LEFT  Pane of the Policy
	 * Administration Window.
	 * Model for Policy List.
	 */
	private DefaultListModel<PAPolicyId> policyListModel = null;

	/**
	 * This contains all the configured permissions for one policy
	 */
	private DefaultListModel<PAPermissionData> permissionListModel = null;

	/**
	 * Data member to hold the Policy which is selected currently in the View.
	 */
	private PAPolicyData selectedPolicyData = null;
	private static final String METHOD_ON_POLICIES_FETCHED = "OnAllPoliciesFetched()";
	private static final String METHOD_CREATE_PERMISSIONS_LIST = "createPermissionsList()";

	/**
	 * Constructor
	 */
	PAPolicyAdminDataHolder() {
		// Create List Model.
		policyListModel = new DefaultListModel<>();

		//Create Permissions List Model
		permissionListModel = new DefaultListModel<>();

		selectedPolicies = new ArrayList<>();
	}

	/**
	 * This method adds a PAPolicyNameAndID data to the list of All policy names that
	 * has been fetched and stored. A newly created policy is added after receiving a 
	 * POLICY_CREATED notification.
	 * @param createdPolicy The Policy Object which has got created.
	 * @return boolean Indicates whether it was possible to add the Policy to the 
	 * cache or not.
	 */
	boolean addPolicy(PAPolicyId createdPolicy) {
		// Add created policy to the Tree Model.
		policyListModel.addElement(createdPolicy);

		return true;
	}

	/**
	 * This method removes a PAPolicyNameAndID data from the list of All policy names
	 * that has been fetched and stored. A policy is removed after receiving a 
	 * POLICY_DELETED notification.
	 * @param deletedPolicy The Policy which has got deleted and which should be
	 * removed from the cache
	 * @return boolean Indicates whether it was possible to remove the Policy from the 
	 * cache. True indicates success.
	 */
	boolean removePolicy(PAPolicyId deletedPolicy) {
		if (selectedPolicies.size() == 1) {
			// Get the Selected Policy.
			PAPolicyId selectedPolicy = selectedPolicies.get(0);
			if (deletedPolicy.equals(selectedPolicy)) {
				permissionListModel.clear();
			}
		}

		return policyListModel.removeElement(deletedPolicy);
	}

	/**
	 * This method modifies the Policy Data that has been modified. Modifying policy Data would mean replacing the
	 * entire Old Policy Data with the new one.
	 * @param modifiedPolicyData The Modified Policy Object.
	 */
	public void modifyPolicy(PAPolicyData modifiedPolicyData) {
		if (null != selectedPolicyData && !selectedPolicyData.getPermissionDataList().equals(modifiedPolicyData.getPermissionDataList())) {
			// Flush the RIGHT PANE.
			permissionListModel.clear();
			// Create new Tree.
			createPermissionsList(modifiedPolicyData);
			selectedPolicyData = modifiedPolicyData;
		}
	}

	/**
	 * Retrieve the Model that is used for the Policy List.
	 * @return javax.swing.DefaultListModel The List Model used by the Policy List.
	 */
	public DefaultListModel<PAPolicyId> getPolicyListModel() {
		return policyListModel;
	}

	/**
	 *
	 * @return DefaultTreeModel instance of PAPermissionData
	 */
	public DefaultListModel<PAPermissionData> getPermissionsList(){
		return permissionListModel;
	}

	/**
	 * Function called to indicate that all the policies have been fetched.
	 * @param pMsg The message which contains the information about the retrieved policies.
	 * @return boolean Indicates whether it was possible to process the information about the policies.
	 */
	public boolean onAllPoliciesFetched(USMMessage pMsg) {
		LOGGER.info(METHOD_ON_POLICIES_FETCHED + "in the function");

		boolean bOp = true;
		try {
			// Pop the number of Configured Policies.
			int nCountPolicies = pMsg.popInteger();

			LOGGER.info(METHOD_ON_POLICIES_FETCHED + "the number of policies fetched at client=" + nCountPolicies);

			for (int idx = 0; idx < nCountPolicies; ++idx) {
				PAPolicyId dataPolicy = new PAPolicyId();
				dataPolicy.popMe(pMsg);

				// Add created policy to the Tree Model.
				policyListModel.addElement(dataPolicy);
			}
		} catch (Exception ex) {
			bOp = false;
		}
		return bOp;

	}

	/**
	 * Function called when the data about a particular policy gets fetched
	 * @param pMsg The message which contains information about the policy
	 * @return boolean Indicates whether it was possible to process the information. 
	 * True indicates success.
	 */
	public boolean onPolicyDataFetched(USMMessage pMsg) {
		// Pop the PolicyData - Configured Menu Items for the Selected Policy.
		PAPolicyData policyData = new PAPolicyData();
		policyData.popMe(pMsg);
		selectedPolicyData = policyData;
		createPermissionsList(policyData);

		return true;
	}

	/**
	 * Function called to create the Permissions List.
	 * @param policyData The Policy Data that should be converted into a List
	 */
	private void createPermissionsList(PAPolicyData policyData) {

		LOGGER.info(METHOD_CREATE_PERMISSIONS_LIST + " ENTER_FUNCTION ");

		List<PAPermissionData> permissionDataList = policyData.getPermissionDataList();

		try {
			for (PAPermissionData permissionData : permissionDataList) {
				permissionListModel.addElement(permissionData);


////				boolean isValidPermission = false;
//				permissionsBrokenDown = new ArrayList<>();
//				permissionsBrokenDown.add(permissionData);
//				allPermissions.add(permissionsBrokenDown);

				//Replaces above 2 lines
//				if (!permissionName.contains("->")) {
//					permissionsBrokenDown.add(permissionData.getName());
//					isValidPermission = true;
//				} else {
//
//					int indexToSearchFrom = 0;
//					int foundIndex = 0;
//					String subString = null;
//
//					do {
//						foundIndex = permissionName.indexOf("->", indexToSearchFrom);
//						if (-1 == foundIndex) {
//							subString = permissionName.substring(indexToSearchFrom);
//						} else {
//							bIsValidMenu = true;
//							subString = permissionName.substring(indexToSearchFrom, foundIndex);
//						}
//						indexToSearchFrom = foundIndex + 2;
//						vecMenuBrokenDown.add(subString);
//					} while (-1 != foundIndex);
//				}

//				if (isValidPermission) {
//					allPermissions.add(permissionsBrokenDown);
//				}
			}

//			for (List<PAPermissionData> permissions : allPermissions) {
//				for (PAPermissionData permission : permissions) {
//					DefaultMutableTreeNode tempParentNode = searchForChild(parentNode, permission);
//					if (null == tempParentNode) {
//						tempParentNode = new PermissionTreeNode(permission);
//						parentNode.add(tempParentNode);
//					}
//					parentNode = tempParentNode;
//				}
//			}
//			permissionListModel.reload();
		} catch (Exception ex) {
			LOGGER.error(METHOD_CREATE_PERMISSIONS_LIST + "EXCEPTION: "	+ ex.getClass() + "Message : " + ex.getMessage());
		}

		LOGGER.info(METHOD_CREATE_PERMISSIONS_LIST + " EXIT_FUNCTION ");
	}

	public void clearPermissionsList(){
		permissionListModel.clear();
	}

	/**
	 * Function to set the Policies that have been selected by the operator.
	 * @param policyList The List of Policies that have been selected by the operator.
	 */
	void setSelectedPolicies(List<PAPolicyId> policyList) {
		selectedPolicies = policyList;
	}
}
