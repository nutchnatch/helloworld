package com.ossnms.bicnet.securitymanagement.client.domain.common;

import com.ossnms.bicnet.bcb.model.ManagedObjectType;


import static com.ossnms.bicnet.securitymanagement.client.domain.common.SecurableObjectContainerFilterEnum.CONTAINER;
import static com.ossnms.bicnet.securitymanagement.client.domain.common.SecurableObjectContainerFilterEnum.MEDIATOR;
import static com.ossnms.bicnet.securitymanagement.client.domain.common.SecurableObjectContainerFilterEnum.NETWORK_DOMAIN;

/**
 *
 */
public enum SecurableObjectFilterEnum {

    NE	            (ManagedObjectType.NE, MEDIATOR, CONTAINER, NETWORK_DOMAIN),
    SUBSCRIBERS     (ManagedObjectType.COMMON_CONTAINER);

    private ManagedObjectType objectType;
    private SecurableObjectContainerFilterEnum[] containerTypes;

    /**
     *
     * @param objectType
     * @param containerTypes
     */
    SecurableObjectFilterEnum(ManagedObjectType objectType, SecurableObjectContainerFilterEnum... containerTypes){
        this.objectType = objectType;
        this.containerTypes = containerTypes;
    }

    public SecurableObjectContainerFilterEnum[] getContainerTypes(){
        return containerTypes;
    }

    public ManagedObjectType getObjectType(){
        return objectType;
    }


}
