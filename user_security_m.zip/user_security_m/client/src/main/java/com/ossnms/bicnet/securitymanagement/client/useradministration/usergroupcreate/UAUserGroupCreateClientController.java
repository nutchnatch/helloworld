package com.ossnms.bicnet.securitymanagement.client.useradministration.usergroupcreate;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobCreateUserGroup;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobGetAllUserNames;
import com.ossnms.bicnet.securitymanagement.client.useradministration.usergroup.common.UAUserGroupDomainMappingProxy;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessageType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAStatus;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserGroup;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserNameAndID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * This class implements the controller for the User Group Creation View.This
 * listens to the notifications and updates the view
 * 
 */
public class UAUserGroupCreateClientController extends UAUserGroupDomainMappingProxy {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(UAUserGroupCreateClientController.class);

	/**
	 * This is the constructor
	 * 
	 * @param pView -
	 *            The view associated with the controller
	 */
	UAUserGroupCreateClientController(UAUserGroupCreateView pView) {
		super(pView);
		registerInterestedNotificationIds(getInterestedNotifications());
	}

	/**
	 * Function to return a Vector which contains the list of types that this
	 * controller is interested in.
	 * 
	 * @return The List which contains the notification the controller is interested in.
	 */
	private List<USMBaseMsgType> getInterestedNotifications() {
		LOGGER.debug("getInterestedNotifications()  Enter");
		List<USMBaseMsgType> vectorForNotification = new ArrayList<>();

		vectorForNotification.add(UAMessageType.S_UA_NOT_CREATE_USER);
		vectorForNotification.add(UAMessageType.S_UA_NOT_REMOVE_USER);

		LOGGER.debug("getInterestedNotifications()  Exit");
		return vectorForNotification;
	}

	/**
	 * Helper method called by the framework when a notification is received.
	 * Forwards to the appropriate method
	 * 
	 * @param message Message encapsulating the notification
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc#handleNotification(com.ossnms.bicnet.securitymanagement.common.basic.USMMessage)
	 */
	@Override
    public void handleNotification(USMMessage message) {
		LOGGER.debug("handleNotification({}) -  Enter", message.getMessageType());
		
		super.handleNotification(message);
		
		// Adding new user to available list of the user in the Create user window if the window is opened
		if (message.getMessageType().equals(UAMessageType.S_UA_NOT_CREATE_USER)) {
			UAUser objUser = new UAUser();
			objUser.popMe(message);
			UAUserNameAndID objUserNameID = new UAUserNameAndID();
			objUserNameID.setCommonName(objUser.getCommonName());
			objUserNameID.setUserId(objUser.getUserId());
			DefaultListModel model = ((UAUserGroupCreateView) associatedView).getGeneralPane().getAvailableUsersListModel();
			model.addElement(objUserNameID);
		}
		//Deleting user to available list of the user in the Create user window if the window is opened
		else if (message.getMessageType().equals(UAMessageType.S_UA_NOT_REMOVE_USER)) {
			int nNoOfElms = message.popInteger();
			UAUserGroupCreateView view = (UAUserGroupCreateView) associatedView;
			DefaultListModel modelAvail = view.getGeneralPane().getAvailableUsersListModel();
			DefaultListModel modelAssigned = view.getGeneralPane().getAssignedUserListModel();

			for (int index = 0; index < nNoOfElms; index++) {
				String strUserID = message.popString();
				UAUserNameAndID objUserNameID = new UAUserNameAndID();
				objUserNameID.setUserId(strUserID);
				modelAvail.removeElement(objUserNameID);
				modelAssigned.removeElement(objUserNameID);
			}
		}
		LOGGER.debug("handleNotification({})  Exit", message.getMessageType());
	}

	/**
	 * Sends a request to create a user group
	 * 
	 * @param userGroupData -
	 *            The user group object to be created
	 * @param usersForUserGroup -
	 *            Vector of users assigned to this user group
	 * @param mappingsForUserGroup List of domain and policy mappings to be assigned to the user group to be created
	 * @return boolean - True indicates that the operation was successfully
	 *         completed
	 */
	public boolean sendRequestToCreateUserGroup(
		UAUserGroup userGroupData,
		List<String> usersForUserGroup, List<DCDomainMapping> mappingsForUserGroup) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"sendRequestToCreateUserGroup("
					+ userGroupData
					+ ","
					+ usersForUserGroup
					+ ")  Enter");
		}
		UAJobCreateUserGroup objJobgetCreateUserGroup =
			new UAJobCreateUserGroup(this, userGroupData, usersForUserGroup, mappingsForUserGroup);
		boolean bStatus = queueJob(objJobgetCreateUserGroup);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"sendRequestToCreateUserGroup("
					+ userGroupData
					+ ","
					+ usersForUserGroup
					+ ")  Exit - Return:"
					+ bStatus);
		}
		return bStatus;
	}

	/**
	 * Sends a request to get all user names, the default domain mappings, all the 
	 * policies from the server, and all domains, in order to populate necessary data
	 * for user group creation.
	 * 
	 * @return boolean - True indicates the operation was completed
	 *         successfully
	 */
	public boolean sendReqToGetAllUserNames() {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("sendReqToGetAllUserNames()	  Enter");
		}
		UAJobGetAllUserNames objJobgetAllUserGroup =
			new UAJobGetAllUserNames(this);
		boolean bStatus = queueJob(objJobgetAllUserGroup);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"sendReqToGetAllUserNames()	  Exit - Return :" + bStatus);
		}
		return bStatus;

	}
	
	/**
	 * Handler for the Create User group Response
	 * 
	 * @param pMessage
	 *     The message which is sent by the server interactor on creation
	 *     of a user group.
	 */
	private void handleResponseForCreateUserGroup(USMMessage pMessage) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"handleResponseForCreateUserGroup("
					+ pMessage.getMessageType()
					+ ")	  Enter");
		}
		boolean bOp = true;
		String errorMessage = "";
		try {
			// Pop the Result of the Operation.
			UAStatus statusObject = new UAStatus();
			statusObject.popMe(pMessage);

			int nResult = statusObject.getStatus();

			if (nResult == UAStatus.S_SUCCESS) {
				((UAUserGroupCreateView) associatedView).close();
			} else if (
				nResult
					== UAStatus.S_USERGROUP_CAN_BE_CREATED_EVEN_USERS_NOT_VALID) {
				List inValidUsers = (List) pMessage.popObject();
				Iterator iter = inValidUsers.iterator();
				errorMessage =
					USMStringTable.IDS_UG_INVALID_USER_ERROR.toString();
				while (iter.hasNext()) {
					bOp = false;
					String userID = (String) iter.next();
					errorMessage += userID + "\n";
					LOGGER.error(
						"Create User group  : Invalid user removed " + userID);
				}
				((UAUserGroupCreateView) associatedView).close();
			} else {
				if (nResult == UAStatus.S_LDAP_ERROR) {
					bOp = false;
					errorMessage = USMStringTable.IDS_UG_LDAP_ERROR.toString();
					LOGGER.error("Server returned LDAP Error");
				} else if (nResult == UAStatus.S_INTERNAL_ERROR) {
					bOp = false;
					errorMessage =
						USMStringTable.IDS_UG_INTERNAL_ERROR.toString();
					LOGGER.error("Server returned Internal Error");
				} else if (nResult == UAStatus.S_USERGROUP_ALREADY_EXISTS) {
					bOp = false;
					errorMessage =
						USMStringTable
							.IDS_UG_USER_GROUP_MAPPED_ERROR
							.toString();
					LOGGER.error(
						"A User Group with this name already exists");
				}
			}
			if (bOp == false) {
                ((UAUserGroupCreateView) associatedView).showMessage(
					associatedView,
					errorMessage);
            }
		} catch (Exception ex) {
			bOp = false;
			LOGGER.error(
				"EXCEPTION: " + ex.getClass() + "Message : " + ex.getMessage());
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"handleResponseForCreateUserGroup("
					+ pMessage.getMessageType()
					+ ")	  Exit");
		}

	}

	/**
	 * Helper method called by the framework when a response is received.
	 * Forwards to the appropriate method
	 * 
	 * @param pJob reference to the job which resulted in the original request
	 * @param result result of executing the given job
	 */
	@Override
    public void resultAvailable(USMJob pJob, USMMessage result) {
		LOGGER.debug("resultAvailable(" + result.size() + ")	  Enter");

		if (result.getMessageType().equals(UAMessageType.S_UG_RES_CREATE_USER_GROUP)) {
			handleResponseForCreateUserGroup(result);
		} else if (result.getMessageType().equals(DCMessageType.DC_RES_ASSIGN_MAPPING)) {
			handleResponseAssignMappings(result);
		} else {
			handleResponseGetMappingsForUserGroup(result);
			handleResponseForAllUsers(result);
		}

		LOGGER.debug("resultAvailable(" + result.size() + ")	  Exit");
	}

	/**
	 * Updates the available users of the create user group window 
	 * 
	 * @param pMsg
	 *      user group list recieved
	 * @return boolean
	 *      status of the operation
	 *      true if successful; false otherwise
	 */
	public boolean updateDataModel(USMMessage pMsg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("resultAvailable(" + pMsg.size() + ")	  Enter");
		}
		boolean bOp = true;
		DefaultListModel mListModelAvblUser =
			((UAUserGroupCreateView) associatedView).getGeneralPane().getAvailableUsersListModel();
		if (pMsg == null) {
			bOp = false;
			LOGGER.info("Invalid_Message_Passed_27");
		} else {
			// Pop the number of users.
			int ndump = (pMsg.popInteger()).intValue();
			for (int idx = 0; idx < ndump; ++idx) {
				UAUserNameAndID dataUser = new UAUserNameAndID();
				dataUser.popMe(pMsg);
				mListModelAvblUser.addElement(dataUser);
			}
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"resultAvailable("
					+ pMsg.size()
					+ ")	  Exit - Return :"
					+ bOp);
		}
		return bOp;
	}

	/**
	 * Handler for the Get all user names Response 
	 * 
	 * @param pMsg -
	 *     The message which contains the List of user names that are
	 *     available within USM.
	 */
	private void handleResponseForAllUsers(USMMessage pMsg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"handleResponseForAllUsers(" + pMsg.size() + ")	  Enter");
		}
		updateDataModel(pMsg);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"handleResponseForAllUsers(" + pMsg.size() + ")	  Exit");
		}
	}
}
