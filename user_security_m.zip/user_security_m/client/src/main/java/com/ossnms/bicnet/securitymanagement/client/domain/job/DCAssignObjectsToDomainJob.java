/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCAssignObjectsToDomainJob
 * Author      	Muyeen Munaver
 * Substitute	Asifullakhan
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CONFIG
 * 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-Apr-2005	Asif			CF000834 - Command Log Entries	CF USM
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain.job;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.domain.DCBusinessDelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import org.apache.log4j.Logger;

import java.util.List;

/**
 * This class represents a job that is responsible for the domain configuration assign
 * mapping operation.
 */
public class DCAssignObjectsToDomainJob extends USMJob {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(DCAssignObjectsToDomainJob.class);

	/**
	 * Vector of mappings that assigned for a particular domain
	 */
	private List objectsToAssign;

	/**
	 * The vector of objects which need to be assigned/unassigned to domain 
	 */
	private List objectsToUnassign;

	/**
	 * The domain to which objects need to be assigned/unassigned
	 */
	private DCDomainData domain;

	/**
	 * This info to determine whether it was called from create domain window or modify domain window for loggin :(
	 */
	private boolean createWindow;

	/**
	 * Constructor
	 * 
	 * @param p_request -
	 *            The type of message
	 * @param pJobOwner -
	 *            The controller associated with the job
	 * @param p_mappings -
	 *            Vector of mappings
	 */
	public DCAssignObjectsToDomainJob(
		USMBaseMsgType p_request,
		USMControllerIfc pJobOwner,
		List p_objectsToAssign,
		List p_objectsToUnassign,
		DCDomainData p_domain,
		boolean p_createWindow) {

		super(
			p_request,
			USMCommonStrings.EMPTY,
			USMCommonStrings.EMPTY,
			pJobOwner);
		LOGGER.debug("DCAssignMappingJob() - Entry");
		objectsToAssign = p_objectsToAssign;
		objectsToUnassign = p_objectsToUnassign;
		domain = p_domain;
		createWindow = p_createWindow;

		Object[] arr = { p_domain };
		String str =
			USMStringTable
				.IDS_DC_JOB_ASSIGN_OBJECTS_TO_DOMAIN
				.getFormatedMessage(
				arr);
		setName(str);

		LOGGER.debug("DCAssignMappingJob() - Exit");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob#executeJob()
	 */
	@Override
    public USMMessage executeJob() throws BcbSecurityException {
		LOGGER.debug("executeJob() - Entry");
		DCBusinessDelegate delgate = new DCBusinessDelegate();
		USMMessage msg =
			delgate.assignUnassignObjectsToDomain(
				objectsToAssign,
				objectsToUnassign,
				domain,
				createWindow);
		LOGGER.debug("executeJob() - Exit");
		return msg;
	}
}
