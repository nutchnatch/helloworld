/*
 * --------------------------------------------------------
 * History
 * created: 			09-06-2004
 * first version completed: 	18-06-2004
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Jogi			CF000060 - CF USM GUI Requirements
 * 18-Jan-2005	Muyeen Munaver	CF00702 - The "OK" could became Grey in the "New User" window
 * 03-Feb-2005  Babu B          CF000060-01  CF USM GUI Requirements
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 * 29-May-2009	Nagaraddi S S	TD004759	Cancel button is not working for all USM windows
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.view;

import com.ossnms.bicnet.framework.client.utils.FrameworkHelpButton;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.tools.jfx.JfxButtonPanel;
import com.ossnms.tools.jfx.JfxFormPanel;
import com.ossnms.tools.jfx.JfxText;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.EToolBarButtonStyle;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxToolBar;
import com.ossnms.tools.jfx.components.JfxToolBarButton;
import com.ossnms.tools.jfx.components.JfxToolBarSeparator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Since all the windows of User and Security Management have the same look and feel. Where there is a button panel and
 * status bar at bottom, it makes more sense to have this in a base class.
 * 
 * This class provides the possibility of placing the buttons in the button panel and status bar at bottom. It also
 * provides the basic functionality
 */
public abstract class USMBaseViewWithButtons extends USMBaseView implements java.awt.event.ActionListener {

    private static final long serialVersionUID = -8380712340977230983L;

    /**
     * This is the Panel in which the derived classes should place all their controls.
     */
    private JfxFormPanel pnlForDerivedClasses;

    /**
     * Data member to hold the Button Type to Button Mapping. This is needed for the enabling and the disabling of the
     * buttons.
     */
    private Map<USMButtonTypeEnum, JfxButton> tblButtonTypeToButtons;

    /**
     * Data member to hold the Button to Button Type Mapping.
     */
    private Map<JfxButton, USMButtonType> tblButtonToButtonTypes;

    /**
     * Constructor
     * 
     * @param toolbarItems
     *            - The Vector containing the Buttons that are to be placed in this view.
     * @param id
     *            - A string containing the fully qualified class name
     * @param title
     *            - A string containing the title
     * @param resizable
     *            - Indicates whether it is resizable or not
     * @param helpId
     *            - The ID of the Help Screen to be opened
     */
    protected USMBaseViewWithButtons(List<USMButtonType> toolbarItems, String id, String title, boolean resizable,
                                     int helpId) {
        this(toolbarItems, null, null, id, title, resizable, true, helpId);
    }

    /**
     * Constructor
     * 
     * @param toolbarItems
     *            - The Vector containing the Buttons that are to be placed in this view.
     * @param id
     *            - A string containing the fully qualified class name
     * @param title
     *            - A string containing the title
     * @param resizable
     *            - Indicates whether it is resizable or not
     * @param helpId
     *            - The ID of the Help Screen to be opened
     */
    protected USMBaseViewWithButtons(List<USMButtonType> toolbarItems, String id, String title, boolean resizable,
                                     boolean verticalScrollBar, int helpId) {

        this(toolbarItems, null, null, id, title, resizable, verticalScrollBar, helpId);
    }

    /**
     * Constructor
     * 
     * @param toolbarItems
     *            - The Vector containing the Buttons that are to be placed in this view.
     * @param id
     *            - A string containing the fully qualified class name
     * @param title
     *            - A string containing the title
     * @param resizable
     *            - Indicates whether it is resizable or not
     * @param helpId
     *            - The ID of the Help Screen to be opened
     */
    protected USMBaseViewWithButtons(List<USMButtonType> toolbarItems, List<USMButtonType> commitButtons,
                                     List<USMButtonType> functionButtons, String id, String title, boolean resizable,
                                     int helpId) {

        this(toolbarItems, commitButtons, functionButtons, id, title, resizable, true, helpId);
    }

    /**
     * Constructor
     * 
     * @param toolbarItems
     *            - The Vector containing the Buttons that are to be placed in this view.
     * @param id
     *            - A string containing the fully qualified class name
     * @param title
     *            - A string containing the title
     * @param resizable
     *            - Indicates whether it is resizable or not
     * @param helpId
     *            - The ID of the Help Screen to be opened
     */
    protected USMBaseViewWithButtons(List<USMButtonType> toolbarItems, List<USMButtonType> commitButtons,
                                     List<USMButtonType> functionButtons, String id, String title, boolean resizable,
                                     boolean verticalScrollBar, int helpId) {
        
        super(id, title, resizable, helpId);
        initComponents(toolbarItems, commitButtons, functionButtons, verticalScrollBar);
    }

    /**
     * Function to return the Panel where the derived classes will have to place their controls
     * 
     * @return javax.swing.JPanel - The Panel where the controls are to be placed by the Derived class
     */
    protected JfxFormPanel getPanelForPlacingDerviedControls() {
        return pnlForDerivedClasses;
    }

    /**
     * Function to do the initialization of the controls within the View.
     * 
     * @param setObjs The Vector containing the Buttons that are to be placed in this view.
     * @param functionButtons the list of function buttons
     * @param commitButtons the list of commit buttons
     * @param verticalScrollBar Specifies whether a default vertical ScrollBar should be added
     */
    private void initComponents(List<USMButtonType> setObjs, List<USMButtonType> commitButtons,
        List<USMButtonType> functionButtons, boolean verticalScrollBar) {

        FrameworkHelpButton help = null;
        if (getHelpID() != 0) {
            help = new FrameworkHelpButton(getTitle());
            help.addActionListener(e -> showAssociatedHelp());
        }

        tblButtonTypeToButtons = new Hashtable<>();
        tblButtonToButtonTypes = new Hashtable<>();
        setLayout(new BorderLayout());

        if (commitButtons != null && !commitButtons.isEmpty()) {
            List<JfxButton> functionJfxButtons = convertToButtons(functionButtons);
            List<JfxButton> commitJfxButtons = convertToButtons(commitButtons);

            /*
              Panel to embed the Status bar text.
             */
            JfxButtonPanel commitButtonPanel = new JfxButtonPanel(functionJfxButtons, commitJfxButtons, help);
            add(commitButtonPanel, BorderLayout.SOUTH);
        }
        else {
            setObjs.add(USMButtonType.BTN_TYPE_HELP);
        }

        if(setObjs != null && !setObjs.isEmpty()) {
            /*
              This is the data member to store the Buttons that will be displayed to the user
             */
            JfxToolBar toolbar = new JfxToolBar();
            for (USMButtonType obj : setObjs) {
                if (obj.equals(USMButtonType.BTN_SEPARATOR)) {
                    toolbar.add(new JfxToolBarSeparator(EToolBarButtonStyle.SMALL));
                } else {
                    JfxToolBarButton btn = createToolbarButton(obj);
                    Dimension dim = new Dimension(50, 50);
                    btn.setPreferredSize(dim);
                    btn.addActionListener(this);
                    btn.setName(getTitle() + obj.getButtonName());
                    registerShortKey(obj, btn);

                    tblButtonTypeToButtons.put(obj.getAssociatedEnum(), btn);
                    tblButtonToButtonTypes.put(btn, obj);
                    toolbar.add(btn);
                }
            }
            
            add(toolbar, BorderLayout.NORTH);
        }

        pnlForDerivedClasses = new JfxFormPanel();

        if (verticalScrollBar) {
            JScrollPane scrPane = new JScrollPane(pnlForDerivedClasses);
            add(scrPane, BorderLayout.CENTER);

        } else {
            add(pnlForDerivedClasses, BorderLayout.CENTER);
        }

        // Register shortcuts
        registerKeyboardAction(new EnterActionHandler(), "ENTER", KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0, false), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        registerKeyboardAction(new EscapeActionHandler(), "ESC", KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        registerKeyboardAction(new DeleteActionHandler(), "DEL", KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0, false), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        registerKeyboardAction(new FunctionOneActionHandler(), "F1", KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0, false), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        // Fault ID 42, 43, 44, 76 - Provide Button Level Authorization for XX Windows - Begin (XX is for AA, PA, DC and BS)
        performPermissionCheckForButtons();
    }

    private List<JfxButton> convertToButtons(List<USMButtonType> types) {
        List<JfxButton> buttons = new ArrayList<>();

        if (types != null) {
            buttons.addAll(
                    types.stream()
                            .filter(type -> !USMButtonType.BTN_SEPARATOR.equals(type) && type != null)
                            .map(this::createButton)
                            .collect(Collectors.toList())
            );
        }

        return buttons;
    }
    
    private JfxToolBarButton createToolbarButton(USMButtonType obj) {
        JfxText buttonName = obj.getButtonName();

        return new JfxToolBarButton(buttonName, obj.getToolTip(), obj.getIcon(), EToolBarButtonStyle.SMALL);
    }

    private JfxButton createButton(USMButtonType type) {
        JfxText buttonName = type.getButtonName();
        JfxButton button = new JfxButton(buttonName);
        button.addActionListener(this);
        button.setPreferredSize(new Dimension(JfxUtils.BUTTON_PREFERRED_WIDTH, JfxUtils.BUTTON_PREFERRED_HEIGHT));
        registerShortKey(type, button);

        tblButtonTypeToButtons.put(type.getAssociatedEnum(), button);
        tblButtonToButtonTypes.put(button, type);

        return button;
    }

    /**
     * Private class to do the following handling - 1. Call handleButtonClick with either OK or Apply as a parameter if
     * Enter is pressed.
     */
    private class EnterActionHandler implements ActionListener {

        /**********************************************************************
         * Called when action has been performed. This method passes the event to actionOK(), actionCancel() or
         * actionHelp().
         * 
         * @param event
         *            Action event.
         **********************************************************************/

        @Override
        public void actionPerformed(ActionEvent event) {

            USMButtonTypeEnum ok = USMButtonTypeEnum.BTN_TYPE_OK;
            USMButtonTypeEnum apply = USMButtonTypeEnum.BTN_TYPE_APPLY;
            if (tblButtonTypeToButtons.containsKey(ok)) {
                handleButtonClick(ok);
            }
            else if (tblButtonTypeToButtons.containsKey(apply)) {
                handleButtonClick(apply);
            }

        }
    }

    /**
     * Private class to do the following handling - 1. Call onClose if Esc is pressed.
     */
    private class EscapeActionHandler implements ActionListener {

        /**********************************************************************
         * Called when action has been performed. This method passes the event to actionOK(), actionCancel() or
         * actionHelp().
         *
         * @param event
         *            Action event.
         **********************************************************************/

        @Override
        public void actionPerformed(ActionEvent event) {

            getFrame().closeFrame();

        }
    }

    /**
     * Private class to do the following handling - 1. Execute the deletion steps to delete selected elements when the
     * DEL key is pressed
     */
    private class DeleteActionHandler implements ActionListener {

        /**********************************************************************
         * Called when action has been performed. This method passes the event to actionOK(), actionCancel() or
         * actionHelp().
         *
         * @param event
         *            Action event.
         **********************************************************************/

        @Override
        public void actionPerformed(ActionEvent event) {

            onDeleteOrRemove();

        }
    }

    /**
     * Private class to do the following handling - 1. Open the Help if F1 is pressed.
     */
    private class FunctionOneActionHandler implements ActionListener {

        /**********************************************************************
         * Called when action has been performed. This method passes the event to actionOK(), actionCancel() or
         * actionHelp().
         *
         * @param event
         *            Action event.
         **********************************************************************/

        @Override
        public void actionPerformed(ActionEvent event) {

            getFrame().showHelp(getHelpID());

        }
    }

    /*
     * (non-Javadoc)
     * @see java.awt.event ActionListener#actionPerformed(java.awt.event.ActionEvent)
     */
    @Override
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        USMButtonType type = tblButtonToButtonTypes.get(actionEvent.getSource());
        USMButtonTypeEnum associatedEnum = type.getAssociatedEnum();

        if (USMButtonTypeEnum.BTN_TYPE_HELP.equals(associatedEnum)) {
            showAssociatedHelp();
        }
        else {
            handleButtonClick(associatedEnum);
        }
    }

    /**
     * Abstract function that is to be implemented by all the derived views. The Views should do the handling for the
     * Button clicks here
     * 
     * @param type The Button that has got clicked.
     */
    public abstract void handleButtonClick(USMButtonTypeEnum type);

    /**
     * Function to help the derived classes to enable all the buttons that are available.
     */
    protected void enableAllButtons() {
        enableDisableAll(true);
    }

    /**
     * Function to help the derived classes to disabled all the buttons that are available.
     * 
     * This function will disable all the Button, except the Help. The help Button will be available at all times.
     */
    protected void disableAllButtons() {
        enableDisableAll(false);
    }

    /**
     * Helper function to enable or disable all the buttons.
     * 
     * @param enableDisable Indicates whether to enable or disable all the buttons
     */
    private void enableDisableAll(boolean enableDisable) {
        tblButtonTypeToButtons.forEach((enm,button) -> button.setEnabled(enableDisable));
    }

    /**
     * Function to help the derived classes to selectively disable the buttons that are passed.
     * 
     * Even if the derived class send the button Help, the Help Button will not be disabled. This is to guarantee that
     * the Help is available always.
     * 
     * @param list List which contains the Button types that should be disabled
     */
    protected void disableSelectiveButtons(List<USMButtonTypeEnum> list) {
        enableDisableSelectiveButtons(list, false);
    }

    /**
     * Function to help the derived classes to selectively enable the buttons that are passed.
     * 
     * @param list List which contains the Button types that should be enabled
     */
    protected void enableSelectiveButtons(List<USMButtonTypeEnum> list) {
        enableDisableSelectiveButtons(list, true);
    }
    
    protected void setDefaultButton(USMButtonTypeEnum type) {
        JfxButton btn = tblButtonTypeToButtons.get(type);
        if(btn != null && getRootPane() != null) {
            getRootPane().setDefaultButton(btn);
        }
    }
    
    protected void requestFocus(USMButtonTypeEnum type) {
        JfxButton btn = tblButtonTypeToButtons.get(type);
        if(btn != null) {
            btn.requestFocus();
        }
    }
    
    protected void setButtonName(USMButtonTypeEnum type, String name) {
        JfxButton btn = tblButtonTypeToButtons.get(type);
        if(btn != null) {
            btn.setName(name);
        }
    }

    /**
     * Helper function to enable or disable selective buttons.
     * 
     * @param list List which contains the Button types that should be enabled or disabled
     * @param enableDisable Indicates whether to enable or disable the buttons
     */
    private void enableDisableSelectiveButtons(List<USMButtonTypeEnum> list, boolean enableDisable) {
        list.stream()
                .filter(btnType -> !btnType.equals(USMButtonTypeEnum.BTN_TYPE_HELP))
                .forEach(btnType -> {
            JfxButton btn = tblButtonTypeToButtons.get(btnType);
            if (null != btn) {
                btn.setEnabled(enableDisable);
            }
        });
    }

    /**
     * Helper function to perform the Authorization check for the enabled buttons.
     */
    protected void performPermissionCheckForButtons() {
        tblButtonTypeToButtons.forEach((typeEnum, button) -> {
            USMButtonType type = tblButtonToButtonTypes.get(button);
            String strId = type.getAssociatedOperationID();
            // It is null for Help, Close & Cancel. This is because it has to be enabled at all times
            if (strId != null && !USMUtility.getInstance().checkIfOperatorHasPermission(strId)) {
                button.setEnabled(false);
            }
        });
    }

    /**
     * Helper function to retrieve a button given its identifier.
     * 
     * @param buttonType
     *            The type of the button.
     * @return True if enabled.
     */
    public boolean getButtonState(USMButtonTypeEnum buttonType) {
        for (JfxButton button : tblButtonTypeToButtons.values()){
            USMButtonType type = tblButtonToButtonTypes.get(button);
            if (type.getAssociatedEnum() == buttonType) {
                return button.isEnabled();
            }
        }
        return false;
    }

    /**
     * Registers the short key to windows tool baar icons
     * 
     * @param obj
     *            - Button type for registering short key for
     * @param btn
     *            - Button object
     */
    private void registerShortKey(USMButtonType obj, JfxButton btn) {
        if (obj == null || btn == null) {
            return;
        }
        if (obj.getAssociatedEnum().equals(USMButtonTypeEnum.BTN_TYPE_FORCE_LOGOFF)) {
            btn.setMnemonic(KeyEvent.VK_F);
            btn.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_F, KeyEvent.ALT_MASK),
                    JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        }
        else if (obj.getAssociatedEnum().equals(USMButtonTypeEnum.BTN_TYPE_MODIFY)) {
            btn.setMnemonic(KeyEvent.VK_M);
            btn.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_M, KeyEvent.ALT_MASK),
                    JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        }
        else if (obj.getAssociatedEnum().equals(USMButtonTypeEnum.BTN_TYPE_NEW)) {
            btn.setMnemonic(KeyEvent.VK_N);
            btn.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_N, KeyEvent.ALT_MASK),
                    JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        }
        else if (obj.getAssociatedEnum().equals(USMButtonTypeEnum.BTN_TYPE_APPLY)) {
            btn.setMnemonic(KeyEvent.VK_A);
            btn.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_A, KeyEvent.ALT_MASK),
                    JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        }
        else if (obj.getAssociatedEnum().equals(USMButtonTypeEnum.BTN_TYPE_ASSIGN_POLICY)) {
            btn.setMnemonic(KeyEvent.VK_A);
            btn.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_A, KeyEvent.ALT_MASK),
                    JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        }
        else if (obj.getAssociatedEnum().equals(USMButtonTypeEnum.BTN_TYPE_ACTIVATE)) {
            btn.setMnemonic(KeyEvent.VK_A);
            btn.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_A, KeyEvent.ALT_MASK),
                    JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        }
        else if (obj.getAssociatedEnum().equals(USMButtonTypeEnum.BTN_TYPE_DEACTIVATE)) {
            btn.setMnemonic(KeyEvent.VK_D);
            btn.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_D, KeyEvent.ALT_MASK),
                    JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        }
        else if (obj.getAssociatedEnum().equals(USMButtonTypeEnum.BTN_TYPE_REMOVE)) {
            btn.setMnemonic(KeyEvent.VK_V);
            btn.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_V, KeyEvent.ALT_MASK),
                    JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        }
        else if (obj.getAssociatedEnum().equals(USMButtonTypeEnum.BTN_TYPE_PROPERTIES)) {
            btn.setMnemonic(KeyEvent.VK_R);
            btn.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_R, KeyEvent.ALT_MASK),
                    JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        }
        else if (obj.getAssociatedEnum().equals(USMButtonTypeEnum.BTN_TYPE_SYNC_NE)) {
            btn.setMnemonic(KeyEvent.VK_D);
            btn.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_S, KeyEvent.ALT_MASK),
                    JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        }
        else if (obj.getAssociatedEnum().equals(USMButtonTypeEnum.BTN_TYPE_UNLOCK)) {
            btn.setMnemonic(KeyEvent.VK_U);
            btn.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_U, KeyEvent.ALT_MASK),
                    JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        }
    }

    /**
     * Function to handle the keyboard Delete button.
     */
    private void onDeleteOrRemove() {
        USMButtonTypeEnum del = USMButtonTypeEnum.BTN_TYPE_DELETE;
        JfxButton btnDelete = tblButtonTypeToButtons.get(del);

        if (btnDelete != null) {
            if (btnDelete.isEnabled()) {
                handleButtonClick(USMButtonTypeEnum.BTN_TYPE_DELETE);
            }
        }
        else {
            USMButtonTypeEnum remove = USMButtonTypeEnum.BTN_TYPE_REMOVE;
            JfxButton btnRemove = tblButtonTypeToButtons.get(remove);
            if ((btnRemove != null) && (btnRemove.isEnabled())) {
                handleButtonClick(USMButtonTypeEnum.BTN_TYPE_REMOVE);
            }
        }
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView#setWaitCursor()
     */
    @Override
    public final void setWaitCursor() {
        disableBtnsDueToLongOperation();
        super.setWaitCursor();
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView#setNormalCursor()
     */
    @Override
    public void setNormalCursor() {
        super.setNormalCursor();
        enableDisableControls();
    }

    /**
     * Helper function to disable the Buttons, when a long pending operation is initiated
     */
    private void disableBtnsDueToLongOperation() {
        enableDisableBtnsForLongOps(false);
    }

    /**
     * Helper function to enable the Buttons, when a long pending operation is initiated
     */
    protected abstract void enableDisableControls();

    /**
     * Helper function to Enable/ Disable all those buttons which need to be changed, for long pending operations.
     * 
     * @param enable Indicates whether the Buttons should be enabled or not. True indicates enabling.
     */
    private void enableDisableBtnsForLongOps(boolean enable) {
        List<USMButtonTypeEnum> lst = new ArrayList<>();

        for(JfxButton button : tblButtonTypeToButtons.values()){
            USMButtonType type = tblButtonToButtonTypes.get(button);
            if (type.disableBtnForLongoperation()) {
                lst.add(type.getAssociatedEnum());
            }
        }

        if (lst.size() > 0) {
            if (enable) {
                enableSelectiveButtons(lst);
            }
            else {
                disableSelectiveButtons(lst);
            }
        }
    }
}
