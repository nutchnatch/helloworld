/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCGetAllDomainsJob
 * Author      	Muyeen Munaver
 * Substitute	Asifullakhan
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CONFIG  
 * 		:	TNMS.DX2.SM.DOMAIN.VIEW 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Asif 			CF000834 - Command Log Entries 
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain.job;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.domain.DCBusinessDelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import org.apache.log4j.Logger;

/**
 * This class represents a job that is responsible for getting all the objects
 * assigned to a particular domain
 */
public class DCGetObjectsOfDomainJob extends USMJob {

	/**
	 * Indicate if the securable Objects are assigned to the domain
	 */
	boolean mAssigned;

	/**
	 * This represents the domain object
	 */
	DCDomainData mDomain;

	/**
	 * To indicate whether the domain config window called or the create/modify called
	 */
	boolean mDomainConfigWdw;

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(DCGetObjectsOfDomainJob.class);

	/**
	 * This is the constructor
	 * 
	 * @param pId -
	 *            The type of message
	 * @param pJobOwner -
	 *            The controller associated with the job
	 * @param domain -
	 *            Domain object whose details are to be fetched
	 * @param assign -
	 *            True value to indicate the Securable Objects have been
	 *            assigned to domains
	 */
	public DCGetObjectsOfDomainJob(
		USMBaseMsgType pId,
		USMControllerIfc pJobOwner,
		DCDomainData domain,
		boolean assign,
		boolean domainConfigWdw) {
		super(pId, "", "", pJobOwner);
		String strMsg;

		if (domainConfigWdw) {
			// It means the Job was created for the Domain Configuration Window.
			Object[] arr = { domain };
			strMsg = USMStringTable.IDS_DC_JOB_GET_ASSIGNED_OBJECTS_FOR_DOMAIN_FROM_SERVER.getFormatedMessage(arr);
		} else {
			// This means the Job was created either for Create/Modify domain
			if (domain.equals(DCDomainData.GLOBAL_DOMAIN)) {
				// It means this Job is for create domain
				strMsg = USMStringTable.IDS_DC_JOB_GET_ALL_SEC_OBJECTS_FROM_SERVER.toString();
			} else {
				// Means it is for Modify Job
				Object[] arr = { domain };
				strMsg = USMStringTable.IDS_DC_JOB_GET_ASSIGNED_UNASSIGNED_OBJECTS_FOR_DOMAIN_FROM_SERVER.getFormatedMessage(arr);
			}
		}
		setName(strMsg);

		mAssigned = assign;
		mDomain = domain;
		mDomainConfigWdw = domainConfigWdw;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob#executeJob()
	 */
	@Override
    public USMMessage executeJob() throws BcbSecurityException {
		LOGGER.debug("executeJob() - Entry");

		DCBusinessDelegate delegate = new DCBusinessDelegate();
		USMMessage msg = delegate.getServersForDomain(mDomain, mAssigned, mDomainConfigWdw);

		LOGGER.debug("executeJob() - Exits");
		return msg;
	}
}
