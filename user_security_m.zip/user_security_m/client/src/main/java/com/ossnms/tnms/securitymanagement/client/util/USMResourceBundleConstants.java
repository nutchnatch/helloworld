/*
 * Copyright Coriant 2013
 * The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
 *
 * INDIA
 */

/*
 * Project      BiCNET Common Functions
 *
 * Component    CF:USM
 * Class Name   USMResourceBundleConstants
 * Author       Shilpi Jain
 *  
 * Created on   05-09-2008
 *
 * --------------------------------------------------------
 * Project: TNMS_Core 11.4
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * 
 *
 */
package com.ossnms.tnms.securitymanagement.client.util;

public class USMResourceBundleConstants {
    public static final String USM_INTERNAL_USERS_LIST = "InternalUsersList";
    public static final String SECURITY_SETTINGS_RANGE = "SecuritySettings.Range";
    
}