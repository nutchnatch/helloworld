/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCGetMappingsForDomainJob
 * Author      	Muyeen Munaver
 * Substitute	Asifullakhan
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.MAPPING.CREATE
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain.job;

import org.apache.log4j.Logger;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;

/**
 * This class represents a job that is responsible to get mappings for a
 * particular domain
 */
public class DCGetMappingsOfDomainJob extends USMJob {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(DCGetMappingsOfDomainJob.class);

	/**
	 * This represents a domain object
	 */
	private DCDomainData domain;

	/**
	 * Constructor
	 * 
	 * @param request -
	 *            The type of message
	 * @param jobOwner -
	 *            The controller associated with the job
	 * @param domainData - 
	 * 				The domain for which the mappings have to be fetched
	 */
	public DCGetMappingsOfDomainJob(
		USMBaseMsgType request,
		USMControllerIfc jobOwner,
		DCDomainData domainData) {
		super(
			request,
			USMCommonStrings.EMPTY,
			USMCommonStrings.EMPTY,
			jobOwner);

		Object[] arr = { domainData };
		String str =
			USMStringTable
				.IDS_DC_JOB_GET_MAPPINGS_OF_DOMAIN
				.getFormatedMessage(
				arr);
		setName(str);

		LOGGER.debug("DCGetMappingsForDomainJob() - Entry");

		domain = domainData;

		LOGGER.debug("DCGetMappingsForDomainJob() - Exit");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob#executeJob()
	 */
	@Override
    public USMMessage executeJob() throws BcbSecurityException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("executeJob() - Entry");
		}
	//	DCBusinessDelegate delgate = new DCBusinessDelegate();

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Fetching mappings for the domain " + domain);
		}
//		USMMessage msg = delgate.getMappingsOfDomain(domain);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("executeJob() - Exit");
		}

//		return msg;
		return null;

	}

}
