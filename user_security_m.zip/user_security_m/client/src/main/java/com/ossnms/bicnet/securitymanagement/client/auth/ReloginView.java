package com.ossnms.bicnet.securitymanagement.client.auth;

import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.framework.client.command.FrameworkCommitButton;
import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.helpers.FrameworkView;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkJob;
import com.ossnms.bicnet.framework.client.utils.FrameworkCancelCommand;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.auth.ReloginOperation.ReloginOperationListener;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxText;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxLabel;

/**
 * Shows feedback about re-login.
 */
public class ReloginView extends FrameworkView implements ReloginOperationListener {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ReloginView.class);

	private static final long serialVersionUID = -322699943525492046L;

	private static final String VIEW_ID = ReloginView.class.getName();
	private static final String VIEW_TITLE = USMStringTable.IDS_AA_WINDOW_RELOGIN.toString();
	private static final boolean FIXED_SIZE = false;
	private final String logoffReasonMessage;

	private JPanel viewPanel;
	private final ReloginOperation reloginOperation;

	/**
	 * Init re-login view
	 * 
	 * @param logoffMessage
	 *            holds the logoff error message
	 * @param logoffReasonMessage
	 *            holds the logoff reason message. Note that logoffMessage
	 *            already includes this part
	 * @param reloginInfo
	 *            the relogin info data
	 */
	public ReloginView(String logoffMessage, String logoffReasonMessage, ReloginData reloginInfo) {
		super(VIEW_ID, VIEW_TITLE, new EmptyFrameworkDocument(), FIXED_SIZE, 0);
		this.logoffReasonMessage = logoffReasonMessage;
		reloginOperation = new ReloginOperation(reloginInfo);

		initLayout(logoffMessage);
		initControls();

		reloginOperation.setReloginOperationListener(this);
		reloginOperation.startRelogin();
	}

	private void initLayout(String logoffMessage) {
		JfxLabel warningIcon = new JfxLabel(ResourcesIconFactory.ICON_TOOL_EXCLAMATION);

		JfxLabel logoffMessageLabel = new JfxLabel(logoffMessage);
		JfxLabel reloginMessage = new JfxLabel(getReloginInProgressMessage());
		JfxLabel longOperationMessage = new JfxLabel(USMStringTable.RE_LOGIN_LONG_OPERATION);
		JfxLabel ongoingIcon = new JfxLabel(ResourcesIconFactory.ICON_ANIMATION_WAITING);

		JPanel messagePanel = new JPanel(new GridBagLayout());
		messagePanel.add(logoffMessageLabel, new GridBagConstraints(0, 0, 2, 1, 0, 0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
		messagePanel.add(reloginMessage, new GridBagConstraints(0, 1, 2, 1, 0, 0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
		messagePanel.add(longOperationMessage, new GridBagConstraints(0, 2, 1, 1, 0, 0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
		messagePanel.add(ongoingIcon, new GridBagConstraints(1, 2, 1, 1, 0, 0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));

		viewPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, JfxUtils.DEFAULT_MARGIN, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS));
		viewPanel.setBorder(JfxUtils.DIALOG_OUTSIDE_BORDER);
		viewPanel.add(warningIcon);
		viewPanel.add(messagePanel);
	}

	private JfxText getReloginInProgressMessage() {
		if (reloginOperation.hasStandby()) {
			return USMStringTable.RE_LOGIN_WITH_STANDBY_IN_PROGRESS;
		} else {
			return USMStringTable.RE_LOGIN_IN_PROGRESS;
		}
	}

	@Override
	protected List<FrameworkCommitButton> getCommitActions() {
		List<FrameworkCommitButton> actions = new ArrayList<>();
		actions.add(new CancelReloginCommand());
		return actions;
	}

	@Override
	protected JComponent getMainComponent() {
		return viewPanel;
	}

	@Override
	public void updateData(Object key) {
		// updates to the view are performed using methods from
		// ReloginControllerListener interface
	}

	@Override
	public void eventClosing() {
		super.eventClosing();
		reloginOperation.cancelRelogin();
	}

	@Override
	public void loginSuccess() {
		String message = getSuccessMessage();
		JfxOptionPane.showMessageBox(this, VIEW_TITLE, message, JOptionPane.CLOSED_OPTION, JOptionPane.WARNING_MESSAGE);
		this.close();
	}

	private String getSuccessMessage() {
		if (reloginOperation.isTryingActiveServer()) {
			return USMStringTable.RE_LOGIN_SUCCESS_SAME_SERVER.getFormatedMessage(logoffReasonMessage);
		} else {
			return USMStringTable.RE_LOGIN_SUCCESS_STANDBY_SERVER.getFormatedMessage(reloginOperation.getStandbyServer());
		}
	}

	private void showActivityMessage(String message) {
		this.setActivityIndicatorMsg(message);
		this.setActivityIndicatorVisible(true);
	}

	@Override
	public void loginProgress(String progressMessage) {
		showActivityMessage(progressMessage);
	}

	@Override
	public void loginError(String errorMessage, String errorTitle) {
		JfxOptionPane.showMessageBox(this, USMStringTable.RE_LOGIN_FAILED_TITLE.toString(), errorMessage, JOptionPane.CLOSED_OPTION, JOptionPane.ERROR_MESSAGE);
		this.close();
		openLogonWindow();
	}

	@Override
	public void reloginCancelled() {
		this.close();
		openLogonWindow();
	}
	
	private void openLogonWindow() {
		try {
			USMUtility.getInstance().getSecurityPlugin().logon();
		} catch (BiCNetPluginException e) {
			LOGGER.error("Could not open logon window!", e);
		}
	}

	private static class EmptyFrameworkDocument extends FrameworkDocument {
		public EmptyFrameworkDocument() {
			super(null);
		}

		@Override
		public Object getObject(Object key) {
			return null;
		}

		@Override
		public void setResult(IFrameworkJob job, Object result) {
		}
	}

	/**
	 * Handles canceling re-login
	 */
	private class CancelReloginCommand extends FrameworkCancelCommand {

		private static final long serialVersionUID = 2652933182706179163L;

		public CancelReloginCommand() {
			super(ReloginView.this);
		}

		@Override
		public boolean execute(IManagedObject[] arSelectedObjects) {
			showActivityMessage(USMStringTable.RE_LOGIN_CANCEL_MESSAGE.toString());
			setEnabled(false);
			reloginOperation.cancelRelogin();
			return true;
		}
	}
	
}
