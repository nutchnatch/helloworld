/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCBusinessDelegate
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CREATE
 * 		:	TNMS.DX2.SM.DOMAIN.CONFIG	   
 * 		:	TNMS.DX2.SM.DOMAIN.VIEW
 * 		:	TNMS.DX2.SM.MAPPING.CREATE
 * 		:	TNMS.DX2.SM.MAPPING.VIEW 
 *  
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Asif 			CF000834 - Command Log Entries 
 * 06-May-2009  Nagaraddi S S    TD004578 - RQT-STDERR errors instead log4j's
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessageType;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityDomainConfigurationPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.servicelocator.USMServiceLocator;
import com.ossnms.bicnet.util.UnexpectedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * All components with USM use a Business Delegate to perform an operation on the bean. This class is the Business
 * Delegate for the Domain components.
 */
public class DCBusinessDelegate {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(DCBusinessDelegate.class);

    /**
     * This is the constructor
     */
    public DCBusinessDelegate() {
    }

    /**
     * This method retrieves all the domain data from the server.
     * 
     * @return USMMessage - a message that contains all the domains information
     */
    public USMMessage getAllDomains() throws BcbSecurityException {

        LOGGER.debug("getAllDomains() - Enter");

        USMMessage msg;

        ISecurityDomainConfigurationPrivateFacade bean = getDCPrivateFacade();
        try {
            msg = bean.getAllDomains(USMUtility.getInstance().getSessionContext());
        } catch (BcbSecurityException e) {
            LOGGER.debug("Rethrowing BcbSecurityException. Message: {}", e.getMessage());
            throw e;
        } catch (Exception ex) {
            LOGGER.error("Exception thrown when making a call to getAllDomains " + ex.getMessage() + " Exception class " + ex.getClass());
            msg = new USMMessage(DCMessageType.DC_RES_DOMAINS, USMMessage.USMMESSAGE_RESPONSE);
            msg.pushInteger(DCMessages.DC_ERROR_SERVER_EXCEPTION);
        }

        LOGGER.debug("getAllDomains() - Exit");
        return msg;

    }

    /**
     * This method retrieves all the mapping information from the server.
     * 
     * @return USMMessage - a message that contains the mapping information.
     */
    public USMMessage getAllMappings() throws BcbSecurityException {
        LOGGER.debug("getAllMappings() - Enter");
        USMMessage msg = null;

        ISecurityDomainConfigurationPrivateFacade bean = getDCPrivateFacade();
        try {
            msg = bean.getAllMappings(USMUtility.getInstance().getSessionContext());
        } catch (BcbSecurityException e) {
            LOGGER.debug("Rethrowing BcbSecurityException. Message: {}", e.getMessage());
            throw e;
        } catch (Exception ex) {

            LOGGER.error("Exception thrown when making a call to getAllMappings " + ex.getMessage() + " Exception class " + ex.getClass());

            msg = new USMMessage(DCMessageType.DC_RES_ACCESS_RIGHTS, USMMessage.USMMESSAGE_RESPONSE);
            msg.pushInteger(DCMessages.DC_ERROR_SERVER_EXCEPTION);
        }

        LOGGER.debug("getAllMappings() - Exit");
        return msg;

    }

    /**
     * This method gets called when a domain is created.This information needs to be stored in the server.
     * 
     * @param pDomain - information of the doamin that was created.
     * @return USMMessage - a message containing the result of the operation.
     */
    public USMMessage createDomain(DCDomainData pDomain) throws BcbSecurityException {
        LOGGER.debug("getAllMappings() - Enter");
        USMMessage msg = null;

        ISecurityDomainConfigurationPrivateFacade bean = getDCPrivateFacade();
        try {
            msg = bean.createDomain(USMUtility.getInstance().getSessionContext(), pDomain);
        } catch (BcbSecurityException e) {
            LOGGER.debug("Rethrowing BcbSecurityException. Message: {}", e.getMessage());
            throw e;
        } catch (Exception ex) {
            LOGGER.error("Exception thrown when making a call to create domain " + ex.getMessage() + " Exception class " + ex.getClass());
            msg = new USMMessage(DCMessageType.DC_RES_CREATE_DOMAIN, USMMessage.USMMESSAGE_RESPONSE);
            msg.pushInteger(DCMessages.DC_ERROR_SERVER_EXCEPTION);
        }

        LOGGER.debug("getAllMappings() - Exit");
        return msg;

    }

    /**
     * This method gets called when a domain is deleted.This information needs to be removed from the server.
     * 
     * @param aDomain - information of the domain that was deleted.
     * @return USMMessage - a message containing the result of the operation.
     */
    public USMMessage deleteDomain(List aDomain) throws BcbSecurityException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("deleteDomain(" + aDomain + ") - Enter");
        }
        USMMessage msg = null;
        ISecurityDomainConfigurationPrivateFacade bean = getDCPrivateFacade();
        try {
            msg = bean.deleteDomain(USMUtility.getInstance().getSessionContext(), aDomain);
        } catch (BcbSecurityException e) {
            LOGGER.debug("Rethrowing BcbSecurityException. Message: {}", e.getMessage());
            throw e;
        } catch (Exception ex) {

            LOGGER.error("Exception thrown when making a call to delete domains " + ex.getMessage() + " Exception class " + ex.getClass());

            msg = new USMMessage(DCMessageType.DC_RES_DELETE_DOMAIN, USMMessage.USMMESSAGE_RESPONSE);
            msg.pushInteger(DCMessages.DC_ERROR_SERVER_EXCEPTION);

        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("deleteDomain(" + aDomain + ") - Exit");
        }
        return msg;

    }

    /**
     * This method gets called when a domain is modified.This information needs to be modified in the server.
     * 
     * @param p_domain - information of the domain that was modified.
     * @return USMMessage - a message containing the result of the operation.
     */
    public USMMessage modifyDomain(DCDomainData p_domain) throws BcbSecurityException {
        LOGGER.debug("modifyDomain() - Enter");
        USMMessage msg = null;

        ISecurityDomainConfigurationPrivateFacade bean = getDCPrivateFacade();
        try {
            msg = bean.modifyDomain(USMUtility.getInstance().getSessionContext(), p_domain);
        } catch (BcbSecurityException e) {
            LOGGER.debug("Rethrowing BcbSecurityException. Message: {}", e.getMessage());
            throw e;
        } catch (Exception ex) {
            LOGGER.error("Exception thrown when making a call to modify domains " + ex.getMessage() + " Exception class " + ex.getClass());
            msg = new USMMessage(DCMessageType.DC_RES_MODIFY_DOMAIN, USMMessage.USMMESSAGE_RESPONSE);
            msg.pushInteger(DCMessages.DC_ERROR_SERVER_EXCEPTION);

        }

        LOGGER.debug("modifyDomain() - Exit");
        return msg;

    }

    /**
     * This method retrieves the list of server that belong to this domain.
     * 
     * @param domain - The doamin information
     * @param aAssigned - true to retrieve the list of assigned servers
     * @return USMMessage - a message containing information of the server for a particular domain
     */
    public USMMessage getServersForDomain(DCDomainData domain, boolean aAssigned, boolean domainConfigWdw) throws BcbSecurityException {
        USMMessage message;
        ISecurityDomainConfigurationPrivateFacade bean = getDCPrivateFacade();
        try {
            return bean.getServersForDomain(USMUtility.getInstance().getSessionContext(), domain, aAssigned, domainConfigWdw);
        } catch (BcbSecurityException e) {
            LOGGER.debug("Rethrowing BcbSecurityException. Message: {}", e.getMessage());
            throw e;
        } catch (Exception ex) {
            LOGGER.error("Exception thrown when making a call to getServersForDomain " + ex.getMessage() + " Exception class " + ex.getClass());
            message = new USMMessage(DCMessageType.DC_RES_DOMAIN_DETAILS_SERVER_LEVEL, USMMessage.USMMESSAGE_RESPONSE);
            message.pushInteger(DCMessages.DC_ERROR_SERVER_EXCEPTION);

        }

        return message;
    }

    /**
     * This method retrieves all the securable objects of a particular server that are assigned to a particular domain.
     * 
     * @param domain - information of the domain
     * @param server - information of the server
     * @param assigned - true to retrieve the list of securable objects assigned to the domain.
     * @return USMMessage - a message that contains list of securable objects that belong to a particular server and
     *         assigned to a particular domain
     */
    public USMMessage getObjectsOfServerForDomain(DCDomainData domain, BSTransBicNetCFInfo server, boolean assigned) throws BcbSecurityException {

        USMMessage message = null;
        ISecurityDomainConfigurationPrivateFacade bean = getDCPrivateFacade();
        try {
            message = bean.getObjectsOfServerForDomain(USMUtility.getInstance().getSessionContext(), domain, server, assigned);
        } catch (BcbSecurityException e) {
            LOGGER.debug("Rethrowing BcbSecurityException. Message: {}", e.getMessage());
            throw e;
        } catch (Exception ex) {
            LOGGER.error("Exception thrown when making a call to getObjectsOfServerForDomain " + ex.getMessage() + " Exception class " + ex.getClass());
            message = new USMMessage(DCMessageType.DC_RES_DOMAIN_DETAILS_OBJECT_LEVEL, USMMessage.USMMESSAGE_RESPONSE);
            message.pushInteger(DCMessages.DC_ERROR_SERVER_EXCEPTION);

        }

        return message;

    }

    /**
     * This method handles the assignment of securable objects to a particular domain
     * 
     * @param p_aSecurableObjects - a vector of objects that have to be assigned to the domain
     * @param aDomain - information of a particular domain
     * @return USMMessage - a message that contains the result of the operation
     */
    public USMMessage assignUnassignObjectsToDomain(List objectsToAssign, List objectsToUnassign, DCDomainData aDomain, boolean createWindow) throws BcbSecurityException {

        USMMessage message = null;
        ISecurityDomainConfigurationPrivateFacade bean = getDCPrivateFacade();
        try {
            message = bean.assignUnassignObjectsToDomain(USMUtility.getInstance().getSessionContext(), objectsToAssign, objectsToUnassign, aDomain, createWindow);
        } catch (BcbSecurityException e) {
            LOGGER.debug("Rethrowing BcbSecurityException. Message: {}", e.getMessage());
            throw e;
        } catch (Exception ex) {

            LOGGER.error("Exception thrown when making a call to assignUnassignObjectsToDomain " + ex.getMessage() + " Exception class " + ex.getClass());

            message = new USMMessage(DCMessageType.DC_RES_ASSIGN_TO_DOMAIN, USMMessage.USMMESSAGE_RESPONSE);
            message.pushInteger(DCMessages.DC_ERROR_SERVER_EXCEPTION);

        }

        return message;

    }

    /**
     * This method returns the domain configuration bean object to be invoked.
     * 
     * @return DomainConfiguration - a domain configuration bean object
     */
    private ISecurityDomainConfigurationPrivateFacade getDCPrivateFacade() {

        LOGGER.debug("getDCPrivateFacade() - Enter");

        USMServiceLocator servLoc = USMServiceLocator.getInstance();
        ISecurityDomainConfigurationPrivateFacade fcd = null;
        try {
            fcd = servLoc.getSecurityDomainConfigurationPrivateFacade();
        } catch (UnexpectedException ex) {
            LOGGER.error("UnexpectedException recieved " + ex.getMessage() + " Exception class " + ex.getClass());

        }

        LOGGER.debug("getDCPrivateFacade() - Enter");
        return fcd;

    }


    /**
     * This method handles assignment of mapping to a domain
     * 
     * @param mappings - a vector of mappings to be assigned
     * @return Object - returns the result of the operation
     */
    public USMMessage assignMappings(List mappings) throws BcbSecurityException {

        LOGGER.debug("assignMappings() - Enter");

        USMMessage msg;
        ISecurityDomainConfigurationPrivateFacade bean = getDCPrivateFacade();
        try {
            msg = bean.changeMappings(USMUtility.getInstance().getSessionContext(), mappings);
        } catch (BcbSecurityException e) {
            LOGGER.debug("Rethrowing BcbSecurityException. Message: {}", e.getMessage());
            throw e;
        } catch (Exception ex) {
            LOGGER.error("Exception thrown when making a call to assignMappings " + ex.getMessage() + " Exception class " + ex.getClass());
            msg = new USMMessage(DCMessageType.DC_RES_ASSIGN_MAPPING, USMMessage.USMMESSAGE_RESPONSE);
            msg.pushInteger(DCMessages.DC_ERROR_SERVER_EXCEPTION);
        }

        LOGGER.debug("assignMappings() - Exit");
        return msg;

    }
    
    /**
     * This method retrieves all the securable objects that exist on server.
     * 
     * @return USMMessage - a message that contains list of securable objects.
     */
    public USMMessage getAllSecurableObject() throws BcbSecurityException {
        USMMessage message = null;
        ISecurityDomainConfigurationPrivateFacade bean = getDCPrivateFacade();
        try {
            message = bean.getAllSecurableObject(USMUtility.getInstance().getSessionContext());
        } catch (BcbSecurityException e) {
            LOGGER.debug("Rethrowing BcbSecurityException. Message: {}", e.getMessage());
            throw e;
        } catch (Exception ex) {
            LOGGER.error("Exception thrown when making a call to getAllSecurableObject " + ex.getMessage() + " Exception class " + ex.getClass());
            message = new USMMessage(DCMessageType.DC_RES_ALL_SECURABLE_OBJECTS, USMMessage.USMMESSAGE_RESPONSE);
            message.pushInteger(DCMessages.DC_ERROR_SERVER_EXCEPTION);
        }
        return message;

    }

}
