package com.ossnms.bicnet.securitymanagement.client.basic.command;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginActionListener;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import org.apache.log4j.Logger;

import java.security.InvalidParameterException;
import java.util.Arrays;

/**
 * This is the class which is invoked by the Client Frame when the user does
 * any operation. This class is responsible for the following operations 
 * 		1) Enabling and Disabling of the menu 
 * 		2) Action Handling when the menu entry gets selected.
 * 
 */
final class USMMenuSelectionHandler implements BiCNetPluginActionListener {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(USMMenuSelectionHandler.class);

	/**
	 * Data member to hold the Command Object for which this action handler has
	 * been created
	 */
	private USMCommandID commandId;

	/**
	 * Constructor for the Handler
	 * 
	 * @param id -
	 *            The Command ID for which this Action Handler is being created
	 *            This is needed to trigger the calling of the correct Command.
	 */
	USMMenuSelectionHandler(USMCommandID id) {
		if (null == id) {
			LOGGER.error(
				"Creating a USMMenuSelectionHandler with a null Command ID");
			throw new InvalidParameterException("The Command ID cannot be null");
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering constructor. Creating USMMenuSelectionHandler for : "
					+ id);
		}

		commandId = id;
		LOGGER.debug("Exiting the constructor");
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginActionListener#isPluginActionAllowed(com.ossnms.bicnet.bcb.model.IManagedObject[])
	 */
	@Override
    public boolean isPluginActionAllowed(IManagedObject[] arSelectedObjects) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering the function isPluginActionAllowed. Object passed are : "
					+ Arrays.toString(arSelectedObjects));
		}
		boolean bAuth = true;

		String strMenu = commandId.getMenuString();
		// Check added for Change Password. Which has to be enabled always.
		if (strMenu != null) {
			bAuth =
				USMUtility.getInstance().checkIfOperatorHasPermission(strMenu);
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Exiting the function isPluginActionAllowed for "
					+ commandId
					+ ". Returning : "
					+ bAuth);
		}
		return bAuth;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginActionListener#eventPluginActionPerformed(com.ossnms.bicnet.bcb.model.IManagedObject[])
	 */
	@Override
    public void eventPluginActionPerformed(IManagedObject[] arSelectedObjects)
		throws BiCNetPluginException {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Entering the function eventPluginActionPerformed. Object(s) passed are : "
					+ Arrays.toString(arSelectedObjects));
		}

		USMCommandManager mgr = USMCommandManager.getInstance();
		mgr.executeCmd(commandId, arSelectedObjects);
		LOGGER.debug("Exiting the function eventPluginActionPerformed");
	}
}
