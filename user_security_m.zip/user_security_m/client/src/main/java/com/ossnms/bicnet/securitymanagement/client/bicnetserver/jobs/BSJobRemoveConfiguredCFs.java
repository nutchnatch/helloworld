/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	BSJobRemoveConfiguredCFs
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_OBJECTS
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_ACL 
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_SECURITY
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.INSERT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.bicnetserver.jobs;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.bicnetserver.BSAppServerBusinessDelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSMessageType;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * 
 * This class represents a Job which is responsible for removing server(s)
 * from the purview of USM
 */
public class BSJobRemoveConfiguredCFs extends USMJob {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(BSJobRemoveConfiguredCFs.class);

	/**
	 * Data member to hold the List of CF(s) which are to be removed from
	 * USM
	 */
	private List<BSTransBicNetCFInfo> lstCFs;

	/**
	 * Constructor
	 * 
	 * @param jobOwner The Owner of the Job
	 * @param lstCFs The List of CF(s) which are to be removed from USM
	 */
	public BSJobRemoveConfiguredCFs(USMControllerIfc jobOwner, List<BSTransBicNetCFInfo> lstCFs) {
		super(BSMessageType.BS_REQ_REMOVE_CFS,USMCommonStrings.EMPTY, lstCFs.toString(), jobOwner);

		String str;
		if (lstCFs.size() == 1) {
			Object[] arr = { lstCFs.get(0)};
			str = USMStringTable.IDS_BS_JOB_REMOVE_CFS_SINGLE.getFormatedMessage(arr);
		} else {
			Object[] arr = {lstCFs.size()};
			str = USMStringTable.IDS_BS_JOB_REMOVE_CFS_MULTI.getFormatedMessage(arr);
		}
		setName(str);

		this.lstCFs = lstCFs;
	}

	/**
	 *
	 * @return
	 * @throws BcbSecurityException
     */
	public USMMessage executeJob() throws BcbSecurityException {
		LOGGER.debug("Entering executeJob");
		USMMessage msg = new BSAppServerBusinessDelegate().removeCFsFromUSM(lstCFs);
		LOGGER.debug("Exiting executeJob");
		return msg;
	}
}