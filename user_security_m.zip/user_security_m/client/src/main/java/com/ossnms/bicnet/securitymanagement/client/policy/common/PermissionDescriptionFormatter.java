package com.ossnms.bicnet.securitymanagement.client.policy.common;

import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionItemData;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * created on 27/5/2015
 */
public class PermissionDescriptionFormatter {

    private String permissionName;
    private List<PAPermissionItemData> permissionItems;

    /**
     *
     * @param permissionItems
     */
    public PermissionDescriptionFormatter(String permissionName, List<PAPermissionItemData> permissionItems){
        this.permissionName = permissionName;
        this.permissionItems = new ArrayList<>(permissionItems);
    }

    /**
     *
     * @return
     */
    public String toString(){
        String res = "";
        for(PAPermissionItemData permissionItemData : permissionItems){
            res = res.concat(
                    MessageFormat.format(
                        USMCommonStrings.IDS_PA_PERMISSION_ITEM_DESCRIPTION_HTML,
                        permissionItemData.getDescription()
                    )
            );
        }

        return MessageFormat.format(USMCommonStrings.IDS_PA_PERMISSION_DESCRIPTION_HTML, permissionName, res);
    }
}
