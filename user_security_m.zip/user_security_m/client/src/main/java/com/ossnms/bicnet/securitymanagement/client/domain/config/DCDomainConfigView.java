package com.ossnms.bicnet.securitymanagement.client.domain.config;


import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandManager;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMHelp;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMMouseAdapter;
import com.ossnms.bicnet.securitymanagement.client.domain.common.DCDomainRenderer;
import com.ossnms.bicnet.securitymanagement.client.domain.common.SecurableObjectFilterEnum;
import com.ossnms.bicnet.securitymanagement.client.domain.common.SecurableObjectTree;
import com.ossnms.bicnet.securitymanagement.client.domain.common.SecurableObjectTreeNode;
import com.ossnms.bicnet.securitymanagement.client.domain.common.ServerTypeFilterEnum;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMenuNameList;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObjectContainer;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.tools.jfx.JfxAction;
import com.ossnms.tools.jfx.JfxActionPerformed;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxButtonMenu;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxList;
import com.ossnms.tools.jfx.components.JfxMenuItem;
import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeWillExpandListener;
import javax.swing.tree.ExpandVetoException;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.ossnms.bicnet.securitymanagement.client.domain.common.SecurableObjectContainerFilterEnum.CONTAINER;
import static com.ossnms.bicnet.securitymanagement.client.domain.common.SecurableObjectContainerFilterEnum.MEDIATOR;
import static com.ossnms.bicnet.securitymanagement.client.domain.common.SecurableObjectContainerFilterEnum.NETWORK_DOMAIN;
import static com.ossnms.bicnet.securitymanagement.client.domain.common.ServerTypeFilterEnum.COMMON_SERVICE_LIST;
import static com.ossnms.bicnet.securitymanagement.client.domain.common.ServerTypeFilterEnum.DCN_MANAGER;


/**
 * This is a user interface class which displays the all domain view window. This window is invoked when the user clicks
 * "Domain Configuration" menu option in the menu bar.
 */
class DCDomainConfigView extends USMBaseViewWithButtons implements ListSelectionListener {
    // Fault 95 108 110

    private static final long serialVersionUID = -1205427988897626705L;
    /**
     * Model for the list of domains
     */
    private DefaultListModel<DCDomainData> domainModel;
    /**
     * GUI control to hold domain list
     */
    private JfxList<DCDomainData> mDomainList;

    /**
     * This variable stores the server node which were marked to be expanded
     */
    private final List<BSTransBicNetCFInfo> serverExpanded = new ArrayList<>();

    /**
     * Data constants for holding labels
     */
    private static final String S_DC_NES_LOADING = USMStringTable.getString(USMStringTable.IDS_DC_NES_LOADING);
    private static final String S_DC_POPUP_MODIFY_MENU = USMStringTable.getString(USMStringTable.IDS_DC_POPUP_MODIFY_MENU);
    private static final String S_DC_POPUP_DELETE_MENU = USMStringTable.getString(USMStringTable.IDS_DC_POPUP_DELETE_MENU);

    /**
     * GUI control to hold tree
     */
    private SecurableObjectTree assignedTree = null;

    /**
     * GUI control for popup menu in the domain list
     */
    private JPopupMenu contextMenu;

    /**
     * GUI control for popup menu item for modifying domain
     */
    private final JMenuItem modifyContextMenu = new JMenuItem(S_DC_POPUP_MODIFY_MENU);
    /**
     * GUI control for popup menu item for deleting domain
     */
    private final JMenuItem deleteContextMenu = new JMenuItem(S_DC_POPUP_DELETE_MENU);

    private JfxButtonMenu buttonMenu;

    private JfxButtonMenu buttonManagedObjectTypesMenu;

    private JfxMenuItem itemMediator;

    private JfxMenuItem itemDomain;
    
    private JfxMenuItem itemContainer;

    private JfxMenuItem itemNE;

    private JfxMenuItem itemSubscribers;

	private List<BSTransBicNetCFInfo> toFetch;

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(DCDomainConfigView.class);

    /**
     * This is the constructor
     */
    DCDomainConfigView() {
        super(getIcons(), "com.ossnms.bicnet.securitymanagement.client.domain.config.DCDomainConfigView", JfxStringTable.getString(USMStringTable.IDS_DC_DOMAIN_ADMIN_TITLE), true, USMHelp.HID_DOMAIN_CONFIGURATION);

        LOGGER.debug("DCDomainConfigView()	Enter");
        // Initialize all the gui controls except toolbar and status bar
        initComponents();
        setNamesForTesting();
        // Associate the render with the tree, informing if NEs belong to global domain only
        DCDomainRenderer renderer = new DCDomainRenderer();
        assignedTree.setCellRenderer(renderer);

        // Enable/disable control on window startup
        enableDisableControls();
        // Create the controller
        associatedClientController = new DCDomainConfigProxy(this);

        // Get all the domains from the server
        ((DCDomainConfigProxy) associatedClientController).getAllDomains();
        LOGGER.debug("DCDomainConfigView()	Exit");
    }

    /**
     * Helper function that is used to set the Names of all the editable components within the Window. Strings in this
     * function are not to be Internationalized.
     */
    private void setNamesForTesting() {
        mDomainList.setName("AvailableDomains");
        assignedTree.setName("AssignedSecurableObjects");
    }

    /**
     * The method returns the Vector of buttons that have to be displayed in the window
     *
     * @return ArrayList - ArrayList of buttons that have to be displayed in the window
     */
    private static List<USMButtonType> getIcons() {
        LOGGER.debug("getIcons()	Enter");
        List<USMButtonType> icons = new ArrayList<>();
        // Adding create toolbar icon
        USMButtonType create = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_NEW, USMMenuNameList.OPERATION_DOMAIN_NEW, USMStringTable.IDS_DC_TOOLTIP_CREATE_DOMAIN, false);
        icons.add(create);
        // Adding modify toolbar icon
        USMButtonType modify = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_MODIFY, USMMenuNameList.OPERATION_DOMAIN_MODIFY, USMStringTable.IDS_DC_TOOLTIP_MODIFY_DOMAIN, false);
        icons.add(modify);
        // Adding delete toolbar icon
        USMButtonType delete = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_DELETE, USMMenuNameList.OPERATION_DOMAIN_DELETE, USMStringTable.IDS_DC_TOOLTIP_DELETE_DOMAIN, true);
        icons.add(delete);
        icons.add(USMButtonType.BTN_SEPARATOR);
        LOGGER.debug("getIcons()	Exit");
        return icons;
    }

    /**
     * This method initiates all the components except toolbar and status bar and add to window
     */
    private void initComponents() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("initComponents() 	Enter");
        }

        // Initializing all the GUI controls
        JPanel domainPanel = getPanelForPlacingDerviedControls();
        domainModel = new DefaultListModel<>();
        mDomainList = new JfxList<>(domainModel);
        mDomainList.addListSelectionListener(this);

        USMMouseAdapter adap = new USMMouseAdapter(this, USMButtonTypeEnum.BTN_TYPE_MODIFY);
        mDomainList.addMouseListener(adap);

        // Set up the Title and the Scroll Pane for Domains
        JPanel panelForDomains = new JPanel();
        panelForDomains.setLayout(new BoxLayout(panelForDomains, BoxLayout.Y_AXIS));
        panelForDomains.setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);

        // Set up the Title for Domains
        JfxLabel captionForDomains = new JfxLabel(USMStringTable.IDS_DC_AVAILABLE_DOMAINS);
        captionForDomains.setLabelAndMnemonicFor(mDomainList);
        captionForDomains.setAlignmentX(LEFT_ALIGNMENT);
        panelForDomains.add(captionForDomains);
        panelForDomains.add(Box.createRigidArea(new Dimension(0, JfxUtils.VERTICAL_MARGIN_BETWEEN_CAPTION_AND_FIELD)));

        JScrollPane scrollPaneDomains = new JScrollPane(mDomainList);
        scrollPaneDomains.setAlignmentX(LEFT_ALIGNMENT);
        panelForDomains.add(scrollPaneDomains);

        assignedTree = new SecurableObjectTree();
        assignedTree.addTreeWillExpandListener(new ServerNodeClickedListener());

        // Set up the Title and the Scroll Pane for Securable objects
        JPanel panelForSecurableObjects = new JPanel();
        panelForSecurableObjects.setLayout(new GridBagLayout());
        panelForSecurableObjects.setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);

        JfxLabel captionForSecurableObjects = new JfxLabel(USMStringTable.IDS_DC_ASSIGNED_OBJECTS);
        captionForSecurableObjects.setLabelAndMnemonicFor(assignedTree);
        captionForSecurableObjects.setAlignmentX(LEFT_ALIGNMENT);

        initButtons();

		panelForSecurableObjects.add(captionForSecurableObjects,    new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.WEST, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        panelForSecurableObjects.add(buttonManagedObjectTypesMenu, 	new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.EAST, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
		panelForSecurableObjects.add(buttonMenu,                    new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.EAST, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 10), 0, 0));

        JScrollPane assignedPane = new JScrollPane(assignedTree);
        assignedPane.setAlignmentX(LEFT_ALIGNMENT);
		
        panelForSecurableObjects.add(assignedPane,                  new GridBagConstraints(0, 1, 0, 1, 1.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelForDomains, panelForSecurableObjects);
        splitPane.setDividerLocation(125);
        splitPane.setDividerSize(4);
        splitPane.setBorder(null);
        domainPanel.add(splitPane);

        assignedTree.setDragEnabled(true);
        assignedTree.setLargeModel(true);
        assignedTree.setMinimumSize(new Dimension(25, 50));
        assignedTree.setRootVisible(false);
        assignedTree.setShowsRootHandles(true);

        // Adding context menu to table
        contextMenu = new JPopupMenu();
        contextMenu.add(modifyContextMenu);
        contextMenu.add(deleteContextMenu);

        // Adding action listener to context sensitive menu items
        modifyContextMenu.addActionListener(e -> handleButtonClick(USMButtonTypeEnum.BTN_TYPE_MODIFY));
        modifyContextMenu.setIcon(ResourcesIconFactory.ICON_TOOL_MOD_16);
        modifyContextMenu.setMnemonic(KeyEvent.VK_M);
        modifyContextMenu.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_M, KeyEvent.ALT_MASK), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        deleteContextMenu.addActionListener(e -> handleButtonClick(USMButtonTypeEnum.BTN_TYPE_DELETE));
        deleteContextMenu.setIcon(ResourcesIconFactory.ICON_TOOL_DELETE_16);
        deleteContextMenu.setMnemonic(KeyEvent.VK_L);
        deleteContextMenu.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_L, KeyEvent.ALT_MASK), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        // Adding action on domain list to display the context sensitive menus
        mDomainList.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent me) {
                showPopup(me);
            }

            @Override
            public void mouseReleased(MouseEvent me) {
                showPopup(me);
            }
        });

        splitPane.setPreferredSize(new Dimension(350, 300));
        this.setPreferredSize(new Dimension(450, 420));
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("initComponents() 	Exit");
        }
    }

    /**
     * Display the context sensitive menus on right mouse click in the domain list
     *
     * @param event - Mouse event for pop up trigger
     */
    private void showPopup(MouseEvent event) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("showPopup(" + event + ") 	Enter");
        }
        // Is this event a popup trigger?
        if (contextMenu.isPopupTrigger(event)) {
            Point p = event.getPoint();
            contextMenu.show(mDomainList, p.x, p.y);
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("showPopup(" + event + ") 	Exit");
        }
    }

    /**
     * This method displays all the domains retrieved from the server in the window
     *
     * @param domains - List of domains retrieved from the server
     */
    void displayAllDomains(List<DCDomainData> domains) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("displayAllDomains(" + domains + ") 	Enter");
        }
        if (null != domains) {
            for (DCDomainData domain : domains) {
                LOGGER.info("Domain Name :" + domain);
                domainModel.addElement(domain);
            }
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("displayAllDomains(" + domains + ") 	Exit");
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getComponent()
     */
    @Override
    public JComponent getComponent() {
        return this;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView_BtnPnl_StatusBar#handleButtonClick(com.ossnms
     * .bicnet.securitymanagement.client.basic.view.USMButtonType)
     */
    // Fault ID 43 - Provide Button Level Authorization for Domain Windows
    @Override
    public void handleButtonClick(USMButtonTypeEnum buttonType) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleButtonClick(" + buttonType + ") 	Enter");
        }
        if (null != buttonType) {
            // Handling create button action
            if (buttonType.equals(USMButtonTypeEnum.BTN_TYPE_NEW)) {
                openCreateDomainWindow();
            } else if (buttonType.equals(USMButtonTypeEnum.BTN_TYPE_MODIFY)) {
                openModifyDomainWindow();
            } else if (buttonType.equals(USMButtonTypeEnum.BTN_TYPE_ASSIGN_POLICY)) {
                // Handling Assign policy button action
                openChangeMappingsWindow();
            } else if (buttonType.equals(USMButtonTypeEnum.BTN_TYPE_DELETE)) {
                // Handling delete button action
                deleteDomain();
            } else if (buttonType.equals(USMButtonTypeEnum.BTN_TYPE_CLOSE)) {
                // Handling close button action
                closeWindow();
            } else {
                USMBaseView.showNotImplementedFeatureWindow();
            }
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleButtonClick(" + buttonType + ") 	Exit");
        }
    }

    /**
     * Opens the modify window on clicking modify toolbar icon in domain configuration window
     */
    private void openModifyDomainWindow() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("openModifyDomainWindow() Enter");
        }
        USMCommandManager.getInstance().executeCmd(USMCommandID.S_UI_ID_MODIFY_DOMAIN, mDomainList.getSelectedValue());
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("openModifyDomainWindow() Exit");
        }
    }

    /**
     * Opens the create window on clicking create toolbar icon in domain configuration window
     */
    private void openCreateDomainWindow() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("openCreateDomainWindow() Enter");
        }
        USMCommandManager.getInstance().executeCmd(USMCommandID.S_UI_ID_NEW_DOMAIN, null);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("openCreateDomainWindow() Exit");
        }
    }

    /**
     * Close the administrator window
     */
    private void closeWindow() {
        close();
    }

    /**
     * Opens the assign policy window on clicking create toolbar icon in domain configuration window
     */
    private void openChangeMappingsWindow() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("openChangeMappingsWindow() Enter");
        }
        USMCommandManager.getInstance().executeCmd(USMCommandID.S_UI_ID_ASSIGN_MAPPINGS, mDomainList.getSelectedValue());
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("openChangeMappingsWindow() Exit");
        }
    }

    /**
     * This method handles change in selection
     *
     * @param e - The Java ListSelectionEvent.
     */
    @Override
    public void valueChanged(ListSelectionEvent e) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("valueChanged(" + e + ")  Enter");
        }
        // Makes sure we do not send 2 requests to the server for information about the Securable Objects
        if (!e.getValueIsAdjusting()) {
            if (null != domainModel) {
                if (USMUtility.getInstance().checkIfOperatorHasPermission(USMMenuNameList.OPERATION_DOMAIN_ADMIN)) {

                    List<DCDomainData> selectionList = mDomainList.getSelectedValuesList();
                    if (selectionList.size() == 1) {
                        /*
                          This is a domain object
                         */
                        DCDomainData mSelectedDomain = selectionList.get(0);
                        if (associatedClientController != null) { //can be null when the user belongs to a domain with no policies assigned and is logged in (unassigned own domain's policies while logged in)
                            ((DCDomainConfigProxy) associatedClientController).getFirstLevelObjectsOfDomain(mSelectedDomain);
                        }
                    } else {
                        assignedTree.clear();
                    }
                }
            }
            enableDisableControls();
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("valueChanged(" + e + ")  Exit");
        }
    }

    /**
     * Enable/disable the tool bar button and popup menu according to selection in domain list
     */
    @Override
    protected void enableDisableControls() {
        LOGGER.debug("enableDisableControls() Enter");

        // Create Button Always Enabled.
        List<USMButtonTypeEnum> buttons = new ArrayList<>();
        buttons.add(USMButtonTypeEnum.BTN_TYPE_NEW);
        enableSelectiveButtons(buttons);
        buttons.clear();
        buttons.add(USMButtonTypeEnum.BTN_TYPE_MODIFY);
        buttons.add(USMButtonTypeEnum.BTN_TYPE_DELETE);
        buttons.add(USMButtonTypeEnum.BTN_TYPE_ASSIGN_POLICY);

        deleteContextMenu.setEnabled(false);
        modifyContextMenu.setEnabled(false);
        disableSelectiveButtons(buttons);

        if (null != mDomainList) {
            List<DCDomainData> listOfSel = mDomainList.getSelectedValuesList();
            if (1 == listOfSel.size()) {
                DCDomainData domainData = mDomainList.getSelectedValue();
                if (!domainData.isGlobalDomain()) {
                    buttons.clear();
                    buttons.add(USMButtonTypeEnum.BTN_TYPE_DELETE);
                    buttons.add(USMButtonTypeEnum.BTN_TYPE_MODIFY);
                    deleteContextMenu.setEnabled(true);
                    modifyContextMenu.setEnabled(true);
                    enableSelectiveButtons(buttons);
                }
                // Enable assign policy
                buttons.clear();
                buttons.add(USMButtonTypeEnum.BTN_TYPE_ASSIGN_POLICY);
                enableSelectiveButtons(buttons);

            } else if (listOfSel.size() > 1) {
                // Multiple domain allowed to deleted
                boolean bEnable = true;
                for (DCDomainData dom : listOfSel) {
                    if (dom.isGlobalDomain()) {
                        // Global domain also part of selection, cannot be deleted disable selection
                        bEnable = false;
                        break;
                    }
                }
                buttons.clear();
                if (bEnable) {
                    buttons.add(USMButtonTypeEnum.BTN_TYPE_DELETE);
                    deleteContextMenu.setEnabled(true);
                }
                enableSelectiveButtons(buttons);
            }

        }

        // Call the base class for disabling buttons now for authorization
        // This will only disable the buttons based on authorization, nothing else
        performPermissionCheckForButtons();
        LOGGER.debug("enableDisableControls() Exit");
    }

    /**
     * This method gets called when the domain is to be deleted.
     */
    private void deleteDomain() {
        LOGGER.debug("deleteDomain() Enter");
        List<DCDomainData> selectedDomain = mDomainList.getSelectedValuesList();
        List<DCDomainData> domainList = new ArrayList<>();

        for (DCDomainData domainData : selectedDomain) {
            LOGGER.info("Domain Name  :" + domainData.getDomainName());
            domainList.add(domainData);
        }
        if (confirmDomainDeletion(domainList)) {
            ((DCDomainConfigProxy) associatedClientController).deleteSelectedDomains(domainList);
        }
        LOGGER.debug("deleteDomain() Exit");
    }

    /**
     * This method deletes the domain data from the domain configuration window
     *
     * @param domain Domain ID to be deleted This method is called in order to intimate the user that the domain is
     *               deleted. This method is called in two situations. 1. When the user clicks on "Delete" button 2. When a
     *               domain is deleted in an external client and a notification is received by this client. Depending upon
     *               the case, the information is conveyed to the user.
     */
    void deleteDomain(DCDomainData domain) {
        int nSize = domainModel.size();
        for (int index = 0; index < nSize; index++) {
            DCDomainData dom = domainModel.elementAt(index);
            if (dom.equals(domain)) {
                // If domain has to be deleted, set the selection as the previous selection
                int nSelection = mDomainList.getSelectedIndex();
                // Global domain can never get deleted, so no probs.... of 0 or -1
                domainModel.remove(index);
                // If this is the domain which was selected, then move the selection to the previous domain
                if (index == nSelection) {
                    mDomainList.setSelectedIndex(nSelection - 1);
                }
                break;
            }
        }
    }

    /**
     * This helper function handles the server name change notification. It changes the server node name of the
     * appropriate server.
     *
     * @param appServerInfo - The server whose name has changed. This contains the new server name also.
     */
    void bicnetServerRenamed(BSTransBicNetCFInfo appServerInfo) {
        LOGGER.debug("bicnetServerRenamed() Entry");
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Server which was renamed " + appServerInfo);
        }

        assignedTree.renameFunction(appServerInfo);

        LOGGER.debug("bicnetServerRenamed() Exit");
    }

    /**
     * This method gets called when a application server has been synchronized. In this case, Securable Objects might
     * have been added and deleted from the server. This has to be reflected.
     *
     * @param appserver - The server which has been synchronized.
     */
    void bicnetServerSynched(BSTransBicNetCFInfo appserver) {
        LOGGER.debug("bicnetServerSynched()		Exit");
        // For the Synching of App Server
        if (null != mDomainList) {
            List<DCDomainData> selectionList = mDomainList.getSelectedValuesList();
            if (selectionList.size() == 1) {
                DCDomainData selectedDomainData = selectionList.get(0);
                // It could so happen, that some NEs might have been created on this server
                ((DCDomainConfigProxy) associatedClientController).getObjectsOfDomainForServer(appserver, selectedDomainData);
            }
        }
        LOGGER.debug("bicnetServerSynched()		Exit");
    }

    /**
     * This method handles notifications of Securable objects assigned/unassigned to a domain and updates the window
     * appropriately.
     *
     * @param vecNEs     The vector of Securable Objects which have been assigned/unassigned.
     * @param vecDomains The vector of Domains which have been assigned/unassigned to.
     * @param assign     True value indicates the Securable Objects have been assigned.
     */
    void assignUnAssignNEsToDomainsNotifReceived(List vecNEs, List<DCDomainData> vecDomains, boolean assign) {
        // We shall check to see if the domain that is selected is there in the
        // Vector sent. In which case we know the passed NEs have to be added.
        DCDomainData selectedDomainData = null;
        if (mDomainList != null) {
            List<DCDomainData> selectionList = mDomainList.getSelectedValuesList();
            if (selectionList.size() == 1) {
                selectedDomainData = selectionList.get(0);
            }
        }
        if (selectedDomainData == null) {
            return;
        }

        // If selected domain is the global domain, then we again go fetch the list of NEs from the global domain.
        // We don't necessarily go..only minimizing the tree is sufficient.
        if (selectedDomainData.isGlobalDomain()) {
            assignedTree.updateNeUserObjects(vecNEs);
        }

        for (DCDomainData domFromServer : vecDomains) {
            if (domFromServer.equals(selectedDomainData)) {
                // It means that we have found the domain.
                // Go get the domain information from the server, since the NEs have been assigned/unassigned for this
                // server, this is a domain change.
                ((DCDomainConfigProxy) associatedClientController).getFirstLevelObjectsOfDomain(selectedDomainData);
                break;
            }
        }
    }

    /**
     * This class is the listener class that implements the treewillexpandlistener interface. when the server node is
     * clicked, the client sends a request to the server to get the list of NEs belonging to that server for the chosen
     * domain. So we need to listen to this class
     */
    private class ServerNodeClickedListener implements TreeWillExpandListener {
        /**
         * Constructor
         **/
        ServerNodeClickedListener() {
        }

        /**
         * This is an over ridden method of the treewillexpandListener interface. This method finds which server node
         * was clicked and then sends a request to the server to fetch the NEs for the to be expanded server for the
         * chosen domain
         *
         * @param evt The TreeExpansionEvent which cause the event.
         * @throws ExpandVetoException Exception used to stop and expand/collapse from happening.
         */
        @Override
        public void treeWillExpand(TreeExpansionEvent evt) throws ExpandVetoException {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("treeWillExpand(" + evt + ") Enter");
            }

            DCDomainData selectedDomainData = null;
            List<DCDomainData> selectionList = mDomainList.getSelectedValuesList();
            if (selectionList.size() == 1) {
                selectedDomainData = selectionList.get(0);
            }

            Object serNode = ((SecurableObjectTreeNode) evt.getPath().getLastPathComponent()).getUserObject();
            if (serNode instanceof BSTransBicNetCFInfo) {
                serverExpanded.add((BSTransBicNetCFInfo) serNode);
                ((DCDomainConfigProxy) associatedClientController).getObjectsOfDomainForServer((BSTransBicNetCFInfo) serNode, selectedDomainData);
            }
        }

        /**
         * This is an over ridden method of the treewillexpandListener interface.
         *
         * @param evt The TreeExpansionEvent which cause the event.
         * @throws ExpandVetoException Exception used to stop and expand/collapse from happening.
         */
        @Override
        public void treeWillCollapse(TreeExpansionEvent evt) throws ExpandVetoException {
            // Clear up the child...This is done so that the client does not take lot of memory in keeping the closed
            // node of a server
            List<DCDomainData> selectionList = mDomainList.getSelectedValuesList();
            if (selectionList.size() == 1) {
                SecurableObjectTreeNode serNode = (SecurableObjectTreeNode) evt.getPath().getLastPathComponent();
                Object object = serNode.getUserObject();
                if (object instanceof BSTransBicNetCFInfo) {
                    BSTransBicNetCFInfo serverInfo = (BSTransBicNetCFInfo) object;
//                    assignedTree.removeAllServerChildren(serverInfo);
                    assignedTree.reload(serverInfo);
                    assignedTree.insertGeneric(S_DC_NES_LOADING, serNode);
                }
            }
        }
    }

    /**
     * Displays error message dialog
     *
     * @param message Message to be display
     */
    void showErrorMessage(String message) {
        bringToFront();
        JfxOptionPane.showMessageBox(this, message, JOptionPane.CLOSED_OPTION, JOptionPane.ERROR_MESSAGE);
    }

    /**
     * Function to show a warning message to the user
     *
     * @param message The Text that should be displayed
     */
    void showWarningMessage(String message) {
        bringToFront();
        JfxOptionPane.showMessageBox(this, message, JOptionPane.CLOSED_OPTION, JOptionPane.WARNING_MESSAGE);
    }

    /**
     * Returns the List model to be used for data population
     *
     * @return DefaultListModel - DomainList model
     */
    DefaultListModel<DCDomainData> getDomainListModel() {
        return domainModel;
    }

    /**
     * This method is used to delete/remove the securable objects based on a notification received informing sec object
     * has been unregistered
     *
     * @param cf         The owner of the CF for which the sec object was removed
     * @param lstSecObjs List of BSSecurableObject info which have been unregistered
     */
    void deleteSecObject(BSTransBicNetCFInfo cf, List<BSSecurableObject> lstSecObjs) {
        assignedTree.deleteSecurableObjects(lstSecObjs, cf);
    }

    /**
     * This method is used to modify the securable objects based on a notification received informing sec object has
     * been modified(name changed)
     *
     * @param bicNetCFInfo The owner of the CF for which the sec object was added
     * @param lstSecObjs List of BSSecurableObject info which have been modified
     */
    void modifySecObjects(BSTransBicNetCFInfo bicNetCFInfo, List<BSSecurableObject> lstSecObjs) {
        List<DCDomainData> selectedDomain = mDomainList.getSelectedValuesList();
        DCDomainData dom = selectedDomain != null && selectedDomain.size() == 1 ? selectedDomain.get(0) : null;

        List<BSSecurableObject> relevantObjects;

        if(dom != null){
            relevantObjects = filter(lstSecObjs, object -> object.belongsToDomain(dom.getDomainID()));
            assignedTree.modifySecurableObjects(relevantObjects, bicNetCFInfo);
        }

        relevantObjects = filter(lstSecObjs, object -> !object.belongsToDomain(dom.getDomainID()));
        assignedTree.deleteSecurableObjects(relevantObjects, bicNetCFInfo);
    }

    /**
     *
     * @param objects
     */
    List<BSSecurableObject> filter(List<BSSecurableObject> objects, Predicate<BSSecurableObject> predicate){
        List<DCDomainData> selectedDomain = mDomainList.getSelectedValuesList();
        if(selectedDomain != null && selectedDomain.size() == 1){
            DCDomainData dom = selectedDomain.get(0);

            return objects
                    .stream()
                    .filter(predicate)
                    .collect(Collectors.toList());
        }

        return null;
    }

    /**
     * This method is used to add the securable objects based on a notification received informing sec object has been
     * registered
     *
     * @param server     The owner of the CF for which the sec object was added
     * @param securableObjects List of BSSecurableObject info which have been registered
     */
    void addSecObject(BSTransBicNetCFInfo server, List<BSSecurableObject> securableObjects) {
        // Check if only a single domain is selected and it is GLOBAL
        List<DCDomainData> selectedDomain = mDomainList.getSelectedValuesList();
        if ((selectedDomain != null) && (selectedDomain.size() == 1)) {
            DCDomainData dom = selectedDomain.get(0);

            if (dom.isGlobalDomain()) {
                SecurableObjectTreeNode serverNode = assignedTree.getRootNode(server);
                if (serverNode.getChildCount() > 0) {
                    SecurableObjectTreeNode firstChild = (SecurableObjectTreeNode) serverNode.getFirstChild();

                    if (!firstChild.getUserObject().equals(S_DC_NES_LOADING)) {
                        assignedTree.insertSecurableObjects(securableObjects, server);
                    }
                }
            }
        }
    }

    /**
     *
     * @param cf
     * @param securableObjectContainers
     */
    void modifySecurableObjectContainers(BSTransBicNetCFInfo cf, List<BSSecurableObjectContainer> securableObjectContainers) {
        assignedTree.modifySecurableObjectContainers(securableObjectContainers, cf);
    }

    /**
     * This method adds list of NE to the assigned/unassigned NE tree control present in the window.
     *
     * @param listOfFirstLevel List of NE to be added. This would be the first level. ie. the server name.
     */
    final void setFirstLevelList(List<BSTransBicNetCFInfo> listOfFirstLevel) {
        LOGGER.debug("setFirstLevelList(" + listOfFirstLevel + ") Enter");
        
        toFetch = new ArrayList<>(listOfFirstLevel);
        // To decide on which pane should we start displaying the tree
        assignedTree.clear();

        for (BSTransBicNetCFInfo serverInfo : listOfFirstLevel) {
            if(serverInfo.getComponentType().equals(assignedTree.getServerTypeFilter().getServerType())) {
                SecurableObjectTreeNode serverNode = assignedTree.insertRootNode(serverInfo);
                assignedTree.insertGeneric(S_DC_NES_LOADING, serverNode);
            }
        }

        assignedTree.reload();

        LOGGER.debug("setFirstLevelList(" + listOfFirstLevel + ") Exit");
    }

    /**
     * This method displays the expanded server details. Server may be expanded in 2 cases. When the user has explicitly
     * fetched the server details by opening the server node. When the user moves the assigned/unassigned NEs from one
     * pane to the other.
     *
     * @param netElems   The vector of network elements which have been fetched.
     * @param serverNode The server node for which the network elements have been fetched.
     */
    void displayExpandedServerDetails(List<BSSecurableObject> netElems, BSTransBicNetCFInfo serverNode) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("displayExpandedServerDetails(" + netElems + "," + serverNode + ")		Enter");
        }

        if (serverExpanded.contains(serverNode)) {
        	assignedTree.clear(serverNode);
            assignedTree.insertSecurableObjects(netElems, serverNode);
            assignedTree.reload(serverNode);

            serverExpanded.remove(serverNode);

            // Server was inserted or synchronized and the server was not in the list of servers for the global domain being
            // selected, first we need to add the server node.
        } else if (netElems.size() != 0) {
            // Add the server node..that is sufficient.
            SecurableObjectTreeNode serverTreeNode = assignedTree.insertRootNode(serverNode);
            if (serverTreeNode.getChildCount() == 0) {
                assignedTree.insertGeneric(S_DC_NES_LOADING, serverTreeNode);
            }
        }
    }

	/**
     * @param server server info
     */
    void functionDeleted(BSTransBicNetCFInfo server) {
        LOGGER.debug("functionDeleted() - Enter");
        assignedTree.deleteRootNode(server);
        LOGGER.debug("functionDeleted() - Exit");
    }

    /**
     * Function to return the Icon that is associated with this View.
     *
     * @return Icon The Icon that should be used
     */
    @Override
    public Icon getIcon() {
        return ResourcesIconFactory.ICON_WINDOW_DOMAIN_16;
    }

    /**
     * @param domain the domain data to modify
     */
    void modifyDomain(DCDomainData domain) {
        int nSize = domainModel.size();
        for (int index = 0; index < nSize; index++) {
            DCDomainData dom = domainModel.elementAt(index);
            if (dom.equals(domain)) {
                domainModel.set(index, domain);
                break;
            }
        }
    }

    /**
     * Function to display a message box to the operator and ask for the confirmation about removal of Domain .
     *
     * @return boolean Indicates whether the operator wants to continue and remove the domain from GSS. True indicates
     * user's agreement about removal.
     */
    private boolean confirmDomainDeletion(List vec) {
        boolean bOp = false;
        String strMessage;
        if (1 == vec.size()) {
            strMessage = JfxStringTable.getString(USMStringTable.IDS_DC_MSG_DOMAIN_SINGLE_CFM_DELETION) + "'" + vec.get(0).toString() + "'?";
        } else {
            strMessage = JfxStringTable.getString(USMStringTable.IDS_DC_MSG_DOMAIN_CFM_DELETION) + vec.size() + JfxStringTable.getString(USMStringTable.IDS_DC_MSG_DOMAIN);
        }
        int nRetVal = JfxOptionPane.showConfirmDialog(this, strMessage, JfxStringTable.getString(USMStringTable.IDS_DC_DELETE_MESSAGE_TITLE), JfxOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (JfxOptionPane.YES_OPTION == nRetVal) {
            bOp = true;
        }
        return bOp;
    }

    @Override
    public boolean isDockable() {
        return false;
    }
    

    /**
     * Initializes toolbar button actions
     */
    private void initButtons() {
        initViewButtons();
        initMObjectTypeButtons();
    }

    /**
     * Initializes toolbar button actions
     */
    private void initViewButtons() {
        itemMediator = new JfxMenuItem(new NeActionSelect().mediator());
        itemMediator.setSelected(true);
        itemDomain = new JfxMenuItem(new NeActionSelect().domain());
        itemMediator.setSelected(false);
        itemContainer = new JfxMenuItem(new NeActionSelect().container());
        itemContainer.setSelected(false);

        buttonMenu = new JfxButtonMenu(USMStringTable.MEDIATOR_VIEW, ResourcesIconFactory.ICON_TOOL_TREE_VIEW_16);
        buttonMenu.add(itemMediator);
        buttonMenu.add(itemDomain);
        buttonMenu.add(itemContainer);
    }

    /**
     * Initializes Managed Object Type button actions
     */
    private void initMObjectTypeButtons() {

        itemNE = new JfxMenuItem(new MoTypeActionSelect().ne());
        itemNE.setSelected(true);
        itemSubscribers = new JfxMenuItem(new MoTypeActionSelect().subscribers());
        itemSubscribers.setSelected(false);

        buttonManagedObjectTypesMenu = new JfxButtonMenu(USMStringTable.NE_MOTYPE, ResourcesIconFactory.ICON_TOOL_TREE_VIEW_16);
        buttonManagedObjectTypesMenu.add(itemNE);
        buttonManagedObjectTypesMenu.add(itemSubscribers);

    }

    /**
     * Class that handles Managed Object Type selection change.
     */
    private class MoTypeActionSelect{

        JfxAction ne() {
            return new JfxAction(USMStringTable.NE_MOTYPE, USMStringTable.NE_MOTYPE, "93365D0E110e2F81", new PerformOpenNeMoType(), null, null);
        }

        JfxAction subscribers() {
            return new JfxAction(USMStringTable.SUBSCRIBER_MOTYPE, USMStringTable.SUBSCRIBER_MOTYPE, "93365D0E110e2F81", new PerformOpenSubscriberMoType(), null, null);
        }

        private class PerformOpenNeMoType implements JfxActionPerformed {
            @Override
            public void actionPerformed(final JfxAction action) {

                buttonManagedObjectTypesMenu.setText(USMStringTable.NE_MOTYPE);
                buttonManagedObjectTypesMenu.setToolTipText(USMStringTable.NE_MOTYPE);

                assignedTree.setServerTypeFilter(DCN_MANAGER);
                assignedTree.setObjectFilter(SecurableObjectFilterEnum.NE);

                //Set to default NE/Mediator View
                itemNE.setSelected(true);
                itemSubscribers.setSelected(false);

                buttonMenu.setEnabled(true);

                JfxAction mediatorAction = new NeActionSelect().mediator();
                mediatorAction.actionPerformed(null);

                if (toFetch !=null) {
                    setFirstLevelList(toFetch);
                }

            }
        }

        private class PerformOpenSubscriberMoType implements JfxActionPerformed {
            @Override
            public void actionPerformed(final JfxAction action) {

                buttonManagedObjectTypesMenu.setText(USMStringTable.SUBSCRIBER_MOTYPE);
                buttonManagedObjectTypesMenu.setToolTipText(USMStringTable.SUBSCRIBER_MOTYPE);

                assignedTree.setObjectFilter(SecurableObjectFilterEnum.SUBSCRIBERS);
                assignedTree.setServerTypeFilter(COMMON_SERVICE_LIST);
                assignedTree.setFilter(null);

                itemNE.setSelected(false);
                itemSubscribers.setSelected(true);
                itemMediator.setSelected(true);
                itemDomain.setSelected(false);
                itemContainer.setSelected(false);

                buttonMenu.setEnabled(false);

                if (toFetch !=null) {
                    setFirstLevelList(toFetch);
                }

            }
        }

    }

    /**
     *
     */
	private class NeActionSelect {
		JfxAction mediator() {
			return new JfxAction(USMStringTable.MEDIATOR_VIEW, USMStringTable.MEDIATOR_VIEW, "93365D0E110e2F81", new PerformOpenMediatorView(), null, null);
		}

		JfxAction domain() {
			return new JfxAction(USMStringTable.DOMAIN_VIEW, USMStringTable.DOMAIN_VIEW, "93365D0E110e2F81", new PerformOpenDomainView(), null, null);
		}
		
		JfxAction container() {
			return new JfxAction(USMStringTable.CONTAINER_VIEW, USMStringTable.CONTAINER_VIEW, "93365D0E110e2F81", new PerformOpenContainerView(), null, null);
		}

		private class PerformOpenMediatorView implements JfxActionPerformed {
			@Override
			public void actionPerformed(final JfxAction action) {
                buttonMenu.setText(USMStringTable.MEDIATOR_VIEW);
                buttonMenu.setToolTipText(USMStringTable.MEDIATOR_VIEW);

				itemMediator.setSelected(true);
                itemDomain.setSelected(false);
                itemContainer.setSelected(false);

                assignedTree.setFilter(MEDIATOR);
				
				if (toFetch !=null) {
					setFirstLevelList(toFetch);
				}

			}
		}

		private class PerformOpenDomainView implements JfxActionPerformed {
			@Override
			public void actionPerformed(final JfxAction action) {
                buttonMenu.setText(USMStringTable.DOMAIN_VIEW);
                buttonMenu.setToolTipText(USMStringTable.DOMAIN_VIEW);

                itemDomain.setSelected(true);
                itemMediator.setSelected(false);
                itemContainer.setSelected(false);

                assignedTree.setFilter(NETWORK_DOMAIN);
				
				if (toFetch != null) {
					setFirstLevelList(toFetch);
				}

			}
		}
		
		private class PerformOpenContainerView implements JfxActionPerformed {
			@Override
			public void actionPerformed(final JfxAction action) {
				buttonMenu.setText(USMStringTable.CONTAINER_VIEW);
				buttonMenu.setToolTipText(USMStringTable.CONTAINER_VIEW);

				itemMediator.setSelected(false);
				itemDomain.setSelected(false);
				itemContainer.setSelected(true);

                assignedTree.setFilter(CONTAINER);

				if (toFetch != null) {
					setFirstLevelList(toFetch);
				}
			}
		}
	}
}
