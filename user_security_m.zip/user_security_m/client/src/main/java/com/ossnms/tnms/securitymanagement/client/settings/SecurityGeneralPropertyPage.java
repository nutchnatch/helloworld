/*
 * Copyright Coriant 2013
 * The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
 *
 */
package com.ossnms.tnms.securitymanagement.client.settings;

import com.coriant.widgets.spinner.SpinnerIntegerModel;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPageSite;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSettingsPropertyPage;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.general.GSConstants;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.tnms.securitymanagement.client.util.USMMessages;
import com.ossnms.tnms.securitymanagement.client.util.USMResourceBundleConstants;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxSpinner;
import com.ossnms.tools.jfx.components.JfxTitledBorder;
import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;



public class SecurityGeneralPropertyPage extends JPanel implements ISecurityPropertyPage {

    private static final long serialVersionUID = 8056730623811817935L;

    private static final Logger LOGGER = Logger.getLogger(SecurityGeneralPropertyPage.class);
    public static final int INACTIVITY_TIMEOUT_WARNING_SPINNER_WIDTH = 45;
    public static final int INACTIVITY_TIMEOUT_WARNING_RANGE_LABEL_GRID_X = 3;

    private SecuritySettingsDocument doc;

    private BiCNetPluginPropertyPageSite propertyPageSite;

    private JfxSpinner passwordExpIntervalSpinner;

    private JfxSpinner sessionTimeoutSpinner;

    private JfxSpinner inactivityTimeoutWarningPopUpSpinner;

    private JfxSpinner maxLoginAttemptsSpinner;

    private JfxSpinner userAccountDeactivationSpinner;

    private JfxSpinner adminLockoutSpinner;

    private JfxSpinner reloginTimeoutSpinner;

    private JfxSpinner reloginDelayBetweenTriesSpinner;
    
    private JfxSpinner expirePasswordWarningSpinner;

    private JfxButton defaultButton = new JfxButton(JfxStringTable.IDS_Default);

    private final List<ChangeListener> changeListeners = new ArrayList<>();

    public SecurityGeneralPropertyPage(SecuritySettingsDocument doc) {
        this.doc = doc;
        initLayout();
        initListeners();
        setGuiNames();
    }

    private void initListeners() {
        passwordExpIntervalSpinner.addChangeListener(this);
        sessionTimeoutSpinner.addChangeListener(this);
        maxLoginAttemptsSpinner.addChangeListener(this);
        userAccountDeactivationSpinner.addChangeListener(this);
        adminLockoutSpinner.addChangeListener(this);
        reloginTimeoutSpinner.addChangeListener(this);
        reloginDelayBetweenTriesSpinner.addChangeListener(this);
        expirePasswordWarningSpinner.addChangeListener(this);
        inactivityTimeoutWarningPopUpSpinner.addChangeListener(this);

        defaultButton.addActionListener(e -> {
            passwordExpIntervalSpinner.setValue(GSConstants.S_INIT_PASSWORD_CHANGE_INTERVAL);
            sessionTimeoutSpinner.setValue(GSConstants.S_INACTIVITY_TIMEOUT);
            maxLoginAttemptsSpinner.setValue(GSConstants.S_MAX_LOGIN_ATTEMPTS);
            userAccountDeactivationSpinner.setValue(GSConstants.S_USER_ACCOUNT_DEACTIVATE);
            adminLockoutSpinner.setValue(GSConstants.S_ADMIN_LOCKOUT_PERIOD);
            reloginTimeoutSpinner.setValue(GSConstants.S_RELOGIN_TIMEOUT);
            reloginDelayBetweenTriesSpinner.setValue(GSConstants.S_RELOGIN_DELAY_BETWEEN_TRIES);
            expirePasswordWarningSpinner.setValue(GSConstants.S_EXPIRE_PASSWORD_WARNING);
            inactivityTimeoutWarningPopUpSpinner.setValue(GSConstants.S_INACTIVITY_TIMEOUT_WARNING);

            if (propertyPageSite != null) {
                propertyPageSite.eventPageStatusChanged(SecurityGeneralPropertyPage.this);
            }
        });
    }

    private void initLayout() {
        setLayout(new GridBagLayout());
        setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);

        add(createGeneralPanel(), new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING,
                GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        add(createAccountLockoutPanel(), new GridBagConstraints(0, 1, 1, 1, 1.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        add(createAutomaticReloginPanel(), new GridBagConstraints(0, 2, 1, 1, 1.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        add(defaultButton, new GridBagConstraints(0, 3, 1, 1, 1.0, 1.0, GridBagConstraints.SOUTHWEST,
                GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    }

    private JPanel createGeneralPanel() {
        JPanel generalPanel = new JPanel(new GridBagLayout());

        createAndAddPasswordExpirationItems(generalPanel, 0);
        createAndAddSessionTimeoutItems(generalPanel, 1);
		createAndAddInactivityTimeoutWarningPopUpItems(generalPanel, 2);
		createAndAddExpirePasswordWarningItems(generalPanel, 3);		
		generalPanel.add(Box.createGlue(), new GridBagConstraints(4, 2, 1, 1, 1.0, 1.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));

        return generalPanel;
    }

    /**
     *
     * @param generalPanel
     * @param row
     */
    private void createAndAddInactivityTimeoutWarningPopUpItems(JPanel generalPanel, int row) {
        JfxLabel inactivityTimeoutWarningPopUpUnit = new JfxLabel(USMStringTable.IDS_SS_INACTIVITY_TIMEOUT_POPUP_MINUTES_LABEL);
        JfxLabel inactivityTimeoutWarningPopUpLabel = new JfxLabel(USMStringTable.IDS_SS_INACTIVITY_TIMEOUT_POPUP_LABEL);
        JfxLabel inactivityTimeoutWarningPopUpRange = new JfxLabel();
        inactivityTimeoutWarningPopUpSpinner =
                new JfxSpinner(new SpinnerIntegerModel(GSConstants.S_INACTIVITY_TIMEOUT_WARNING,
                        GSConstants.S_INACTIVITY_TIMEOUT_MIN, GSConstants.S_INACTIVITY_TIMEOUT_MAX, 1));
        inactivityTimeoutWarningPopUpSpinner.setPreferredSize(new Dimension(INACTIVITY_TIMEOUT_WARNING_SPINNER_WIDTH, JfxUtils.getPreferredHeightOfTextField()));
        inactivityTimeoutWarningPopUpLabel.setLabelAndMnemonicFor(this.inactivityTimeoutWarningPopUpSpinner);
        inactivityTimeoutWarningPopUpRange.setText(USMMessages.getInstance().getFormatedString(
                USMResourceBundleConstants.SECURITY_SETTINGS_RANGE,
                new Object[] {String.valueOf(GSConstants.S_INACTIVITY_TIMEOUT_MIN),
                        String.valueOf(GSConstants.S_INACTIVITY_TIMEOUT_MAX)}));

        generalPanel.setBorder(new JfxTitledBorder(USMStringTable.IDS_SS_TIMEOUT_GROUP_LABEL));
        generalPanel.add(inactivityTimeoutWarningPopUpLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0,
                JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        generalPanel.add(inactivityTimeoutWarningPopUpSpinner, new GridBagConstraints(1, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0,
                JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        generalPanel.add(inactivityTimeoutWarningPopUpUnit, new GridBagConstraints(2, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0,
                JfxUtils.UNIT_LEFT_MARGIN, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        generalPanel.add(inactivityTimeoutWarningPopUpRange, new GridBagConstraints(INACTIVITY_TIMEOUT_WARNING_RANGE_LABEL_GRID_X, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0,
                JfxUtils.UNIT_LEFT_MARGIN, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
    }

    private void createAndAddSessionTimeoutItems(JPanel generalPanel, int row) {
        JfxLabel sessionTimeoutUnit = new JfxLabel(USMStringTable.IDS_SS_MINUTES_LABEL);
        JfxLabel sessionTimeoutLabel = new JfxLabel(USMStringTable.IDS_SS_INACTIVITY_TIMEOUT_LABEL);
        JfxLabel sessionTimeoutRange = new JfxLabel();
        sessionTimeoutSpinner =
                new JfxSpinner(new SpinnerIntegerModel(GSConstants.S_INACTIVITY_TIMEOUT,
                        GSConstants.S_INACTIVITY_TIMEOUT_MIN, GSConstants.S_INACTIVITY_TIMEOUT_MAX, 1));
        sessionTimeoutSpinner.setPreferredSize(new Dimension(45, JfxUtils.getPreferredHeightOfTextField()));
        sessionTimeoutLabel.setLabelAndMnemonicFor(this.sessionTimeoutSpinner);
        sessionTimeoutRange.setText(USMMessages.getInstance().getFormatedString(
                USMResourceBundleConstants.SECURITY_SETTINGS_RANGE,
                new Object[] {String.valueOf(GSConstants.S_INACTIVITY_TIMEOUT_MIN),
                        String.valueOf(GSConstants.S_INACTIVITY_TIMEOUT_MAX)}));

        generalPanel.setBorder(new JfxTitledBorder(USMStringTable.IDS_SS_TIMEOUT_GROUP_LABEL));
        generalPanel.add(sessionTimeoutLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS,
                        JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        generalPanel.add(sessionTimeoutSpinner, new GridBagConstraints(1, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        generalPanel.add(sessionTimeoutUnit, new GridBagConstraints(2, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0,
                        JfxUtils.UNIT_LEFT_MARGIN, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        generalPanel.add(sessionTimeoutRange, new GridBagConstraints(3, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0,
                        JfxUtils.UNIT_LEFT_MARGIN, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
    }
    
    private void createAndAddExpirePasswordWarningItems(JPanel accountLockoutPanel, int row) {
        JfxLabel expirePasswordLabel = new JfxLabel(USMStringTable.IDS_SS_EXPIRE_PASSWORD_WARNING_LABEL);
        expirePasswordWarningSpinner = new JfxSpinner(new SpinnerIntegerModel(GSConstants.S_EXPIRE_PASSWORD_WARNING,
                        GSConstants.S_EXPIRE_PASSWORD_WARNING_MIN, GSConstants.S_EXPIRE_PASSWORD_WARNING_MAX, 1));
        expirePasswordWarningSpinner.setPreferredSize(new Dimension(45, JfxUtils.getPreferredHeightOfTextField()));
        expirePasswordLabel.setLabelAndMnemonicFor(expirePasswordWarningSpinner);

        JfxLabel expirePasswordUnit = new JfxLabel(USMStringTable.IDS_SS_DAYS_LABEL);
        JfxLabel expirePasswordRange = new JfxLabel(USMMessages.getInstance().getFormatedString(
                USMResourceBundleConstants.SECURITY_SETTINGS_RANGE, GSConstants.S_EXPIRE_PASSWORD_WARNING_MIN, GSConstants.S_EXPIRE_PASSWORD_WARNING_MAX));

        accountLockoutPanel.add(expirePasswordLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        accountLockoutPanel.add(expirePasswordWarningSpinner, new GridBagConstraints(1, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        accountLockoutPanel.add(expirePasswordUnit, new GridBagConstraints(2, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, JfxUtils.UNIT_LEFT_MARGIN, 0, 0), 0, 0));
        accountLockoutPanel.add(expirePasswordRange, new GridBagConstraints(3, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, JfxUtils.UNIT_LEFT_MARGIN, 0, 0), 0, 0));
    }

    private void createAndAddPasswordExpirationItems(JPanel generalPanel, int row) {
        JfxLabel passwordExpIntervalLabel = new JfxLabel(USMStringTable.IDS_SS_INIT_PASSWORD_CHANGE_INTERVAL_LABEL);
        JfxLabel passwordExpIntervalUnit = new JfxLabel(USMStringTable.IDS_SS_DAYS_LABEL);
        JfxLabel passwordExpIntervalRange = new JfxLabel();

        passwordExpIntervalSpinner =
                new JfxSpinner(new SpinnerIntegerModel(GSConstants.S_INIT_PASSWORD_CHANGE_INTERVAL,
                        GSConstants.S_INIT_PASSWORD_CHANGE_INTERVAL_MIN,
                        GSConstants.S_INIT_PASSWORD_CHANGE_INTERVAL_MAX, 1));
        passwordExpIntervalLabel.setLabelAndMnemonicFor(this.passwordExpIntervalSpinner);
        passwordExpIntervalRange.setText(USMMessages.getInstance().getFormatedString(
                USMResourceBundleConstants.SECURITY_SETTINGS_RANGE,
                new Object[] {String.valueOf(GSConstants.S_INIT_PASSWORD_CHANGE_INTERVAL_MIN),
                        String.valueOf(GSConstants.S_INIT_PASSWORD_CHANGE_INTERVAL_MAX)}));
        generalPanel.add(passwordExpIntervalLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0,
                        JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        generalPanel.add(passwordExpIntervalSpinner, new GridBagConstraints(1, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0,
                        JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        generalPanel.add(passwordExpIntervalUnit, new GridBagConstraints(2, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0,
                        JfxUtils.UNIT_LEFT_MARGIN, 0, 0), 0, 0));
        generalPanel.add(passwordExpIntervalRange, new GridBagConstraints(3, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0,
                        JfxUtils.UNIT_LEFT_MARGIN, 0, 0), 0, 0));
    }

    private JPanel createAccountLockoutPanel() {
        JPanel accountLockoutPanel = new JPanel(new GridBagLayout());

        createAndAddLoginAttemptsItems(accountLockoutPanel, 0);
        createAndAddAccountDeactivationItems(accountLockoutPanel, 1);
        createAndAddAdminLockOutItems(accountLockoutPanel, 2);

        accountLockoutPanel.add(Box.createGlue(), new GridBagConstraints(3, 0, 1, 1, 1.0, 1.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));

        return accountLockoutPanel;
    }

    private void createAndAddLoginAttemptsItems(JPanel accountLockoutPanel, int row) {
        JfxLabel maxLoginAttemptsRange = new JfxLabel();
        JfxLabel maxLoginAttemptsLabel = new JfxLabel(USMStringTable.IDS_SS_UNSUCCESSFUL_LOGIN_ATT_LABEL);
        maxLoginAttemptsSpinner =
                new JfxSpinner(new SpinnerIntegerModel(GSConstants.S_MAX_LOGIN_ATTEMPTS,
                        GSConstants.S_MAX_LOGIN_ATTEMPTS_MIN, GSConstants.S_MAX_LOGIN_ATTEMPTS_MAX, 1));
        maxLoginAttemptsSpinner.setPreferredSize(new Dimension(45, JfxUtils.getPreferredHeightOfTextField()));
        maxLoginAttemptsLabel.setLabelAndMnemonicFor(this.maxLoginAttemptsSpinner);
        maxLoginAttemptsRange.setText(USMMessages.getInstance().getFormatedString(
                USMResourceBundleConstants.SECURITY_SETTINGS_RANGE,
                new Object[] {String.valueOf(GSConstants.S_MAX_LOGIN_ATTEMPTS_MIN),
                        String.valueOf(GSConstants.S_MAX_LOGIN_ATTEMPTS_MAX)}));

        accountLockoutPanel.setLayout(new GridBagLayout());
        accountLockoutPanel.setBorder(new JfxTitledBorder(USMStringTable.IDS_SS_ACCOUNT_LOCKOUT_GROUP_LABEL));
        accountLockoutPanel.add(maxLoginAttemptsLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0,
                        JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        accountLockoutPanel.add(maxLoginAttemptsSpinner, new GridBagConstraints(1, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0,
                        JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        accountLockoutPanel.add(maxLoginAttemptsRange, new GridBagConstraints(2, row, 2, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0,
                        JfxUtils.UNIT_LEFT_MARGIN, 0, 0), 0, 0));
    }

    private void createAndAddAccountDeactivationItems(JPanel accountLockoutPanel, int row) {
        JfxLabel userAccountDeactivationLabel = new JfxLabel(USMStringTable.IDS_SS_DEACTIVATE_USER_ACCOUNT_LABEL);
        JfxLabel userAccountDeactivationRange = new JfxLabel();
        JfxLabel userAccountDeactivationUnit = new JfxLabel(USMStringTable.IDS_SS_DAYS_LABEL);

        userAccountDeactivationSpinner =
                new JfxSpinner(new SpinnerIntegerModel(GSConstants.S_USER_ACCOUNT_DEACTIVATE,
                        GSConstants.S_USER_ACCOUNT_DEACTIVATE_MIN, GSConstants.S_USER_ACCOUNT_DEACTIVATE_MAX, 1));

        userAccountDeactivationLabel.setLabelAndMnemonicFor(this.userAccountDeactivationSpinner);
        this.userAccountDeactivationSpinner
                .setPreferredSize(new Dimension(45, JfxUtils.getPreferredHeightOfTextField()));
        userAccountDeactivationRange.setText(USMMessages.getInstance().getFormatedString(
                USMResourceBundleConstants.SECURITY_SETTINGS_RANGE,
                new Object[] {String.valueOf(GSConstants.S_USER_ACCOUNT_DEACTIVATE_MIN),
                        String.valueOf(GSConstants.S_USER_ACCOUNT_DEACTIVATE_MAX)}));
        accountLockoutPanel.add(userAccountDeactivationLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0,
                        JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        accountLockoutPanel.add(userAccountDeactivationSpinner, new GridBagConstraints(1, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0,
                        JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        accountLockoutPanel.add(userAccountDeactivationUnit, new GridBagConstraints(2, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0,
                        JfxUtils.UNIT_LEFT_MARGIN, 0, 0), 0, 0));
        accountLockoutPanel.add(userAccountDeactivationRange, new GridBagConstraints(3, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0,
                        JfxUtils.UNIT_LEFT_MARGIN, 0, 0), 0, 0));
    }

    private void createAndAddAdminLockOutItems(JPanel accountLockoutPanel, int row) {
        JfxLabel adminLockOutPeriodLabel = new JfxLabel(USMStringTable.IDS_SS_ADMIN_LOCKOUT_LABEL);
        JfxLabel adminLockoutRange = new JfxLabel();
        JfxLabel adminLockoutUnit = new JfxLabel(USMStringTable.IDS_SS_MINUTES_LABEL);
        adminLockoutSpinner =
                new JfxSpinner(new SpinnerIntegerModel(GSConstants.S_ADMIN_LOCKOUT_PERIOD,
                        GSConstants.S_ADMIN_LOCKOUT_PERIOD_MIN, GSConstants.S_ADMIN_LOCKOUT_PERIOD_MAX, 1));
        adminLockoutSpinner.setPreferredSize(new Dimension(45, JfxUtils.getPreferredHeightOfTextField()));
        adminLockOutPeriodLabel.setLabelAndMnemonicFor(this.adminLockoutSpinner);

        adminLockoutRange.setText(USMMessages.getInstance().getFormatedString(
                USMResourceBundleConstants.SECURITY_SETTINGS_RANGE,
                new Object[] {String.valueOf(GSConstants.S_ADMIN_LOCKOUT_PERIOD_MIN),
                        String.valueOf(GSConstants.S_ADMIN_LOCKOUT_PERIOD_MAX)}));

        accountLockoutPanel.add(adminLockOutPeriodLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
        accountLockoutPanel.add(adminLockoutSpinner, new GridBagConstraints(1, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        accountLockoutPanel.add(adminLockoutUnit, new GridBagConstraints(2, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0,
                        JfxUtils.UNIT_LEFT_MARGIN, 0, 0), 0, 0));
        accountLockoutPanel.add(adminLockoutRange, new GridBagConstraints(3, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0,
                        JfxUtils.UNIT_LEFT_MARGIN, 0, 0), 0, 0));
    }

    private JPanel createAutomaticReloginPanel() {
        JPanel automaticReloginPanel = new JPanel(new GridBagLayout());
        automaticReloginPanel.setBorder(new JfxTitledBorder(USMStringTable.IDS_SS_RELOGIN_GROUP_LABEL));

        createAndAddReloginTimeoutItems(automaticReloginPanel, 0);
        createAndAddReloginDelayBetweenTriesItems(automaticReloginPanel, 1);

        automaticReloginPanel.add(Box.createGlue(), new GridBagConstraints(4, 0, 1, 1, 1.0, 1.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));

        return automaticReloginPanel;
    }

    private void createAndAddReloginTimeoutItems(JPanel automaticReloginPanel, int row) {
        JfxLabel reloginTimeoutLabel = new JfxLabel(USMStringTable.IDS_SS_RELOGIN_TIMEOUT_LABEL);
        reloginTimeoutSpinner = new JfxSpinner(new SpinnerIntegerModel(GSConstants.S_RELOGIN_TIMEOUT,
                        GSConstants.S_RELOGIN_TIMEOUT_MIN, GSConstants.S_RELOGIN_TIMEOUT_MAX, 1));
        reloginTimeoutSpinner.setPreferredSize(new Dimension(45, JfxUtils.getPreferredHeightOfTextField()));
        reloginTimeoutLabel.setLabelAndMnemonicFor(reloginTimeoutSpinner);

        JfxLabel reloginTimeoutUnit = new JfxLabel(USMStringTable.IDS_SS_MINUTES_LABEL);
        JfxLabel reloginTimeoutRange = new JfxLabel(USMMessages.getInstance().getFormatedString(
                USMResourceBundleConstants.SECURITY_SETTINGS_RANGE, GSConstants.S_RELOGIN_TIMEOUT_MIN, GSConstants.S_RELOGIN_TIMEOUT_MAX));

        automaticReloginPanel.add(reloginTimeoutLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        automaticReloginPanel.add(reloginTimeoutSpinner, new GridBagConstraints(1, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        automaticReloginPanel.add(reloginTimeoutUnit, new GridBagConstraints(2, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, JfxUtils.UNIT_LEFT_MARGIN, 0, 0), 0, 0));
        automaticReloginPanel.add(reloginTimeoutRange, new GridBagConstraints(3, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, JfxUtils.UNIT_LEFT_MARGIN, 0, 0), 0, 0));
    }

    private void createAndAddReloginDelayBetweenTriesItems(JPanel automaticReloginPanel, int row) {
        JfxLabel reloginDelayBetweenTriesLabel = new JfxLabel(USMStringTable.IDS_SS_RELOGIN_DELAY_BETWEEN_TRIES_LABEL);
        reloginDelayBetweenTriesSpinner = new JfxSpinner(new SpinnerIntegerModel(GSConstants.S_RELOGIN_DELAY_BETWEEN_TRIES,
                GSConstants.S_RELOGIN_DELAY_BETWEEN_TRIES_MIN, GSConstants.S_RELOGIN_DELAY_BETWEEN_TRIES_MAX, 1));
        reloginDelayBetweenTriesSpinner.setPreferredSize(new Dimension(45, JfxUtils.getPreferredHeightOfTextField()));
        reloginDelayBetweenTriesLabel.setLabelAndMnemonicFor(reloginDelayBetweenTriesSpinner);

        JfxLabel reloginDelayBetweenTriesUnit = new JfxLabel(USMStringTable.IDS_SS_SECONDS_LABEL);
        JfxLabel reloginDelayBetweenTriesRange = new JfxLabel(USMMessages.getInstance().getFormatedString(
                USMResourceBundleConstants.SECURITY_SETTINGS_RANGE, GSConstants.S_RELOGIN_DELAY_BETWEEN_TRIES_MIN, GSConstants.S_RELOGIN_DELAY_BETWEEN_TRIES_MAX));

        automaticReloginPanel.add(reloginDelayBetweenTriesLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        automaticReloginPanel.add(reloginDelayBetweenTriesSpinner, new GridBagConstraints(1, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        automaticReloginPanel.add(reloginDelayBetweenTriesUnit, new GridBagConstraints(2, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, JfxUtils.UNIT_LEFT_MARGIN, 0, 0), 0, 0));
        automaticReloginPanel.add(reloginDelayBetweenTriesRange, new GridBagConstraints(3, row, 1, 1, 0.0, 0.0,
                GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, JfxUtils.UNIT_LEFT_MARGIN, 0, 0), 0, 0));
    }


    /**
     * Helper function that is used to set the Names of all the editable components within the Window.
     * 
     * Strings in this function are not to be Internationalized.
     */
    private void setGuiNames() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setGuiNames() Entry");
        }

        passwordExpIntervalSpinner.setName("DefaultPasswordExpiration");
        sessionTimeoutSpinner.setName("SessionTimeout");
        inactivityTimeoutWarningPopUpSpinner.setName("InactivityTimeoutWarningPopUp");

        maxLoginAttemptsSpinner.setName("MaximumLoginAttempts");
        userAccountDeactivationSpinner.setName("UserAccountDeactivation");
        adminLockoutSpinner.setName("Administrator");

        reloginTimeoutSpinner.setName("ReloginTimeout");
        reloginDelayBetweenTriesSpinner.setName("ReloginDelayBetweenTries");
        
        expirePasswordWarningSpinner.setName("ReloginTimeout");

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setGuiNames() Exit");
        }
    }

    @Override
    public void actionApply() {
    }

    @Override
    public void actionCancel() {
    }

    @Override
    public void eventClosing() {
    }

    @Override
    public void eventOpened() {
    }

    @Override
    public JComponent getComponent() {
        return this;
    }

    @Override
    public String getID() {
        return USMCommandID.S_UI_ID_SECURITY_SETTINGS_GENERAL.getMenuString();
    }

    @Override
    public String getTitle() {
        return USMStringTable.IDS_SS_GENERAL_TAB_TITLE.toString();
    }

    @Override
    public boolean isPageDirty() {
        GSGeneralSettingData savedSettings = doc.getGeneralSettingsData();

        if (savedSettings == null) {
            return true;
        }

        if (passwordExpIntervalSpinner.getValue() == null ||
                !passwordExpIntervalSpinner.getValue().equals(savedSettings.getInitPasswordChangeInterval())) {
            return true;
        }

        if (sessionTimeoutSpinner.getValue() == null ||
                !sessionTimeoutSpinner.getValue().equals(savedSettings.getInactivityTimeout())) {
            return true;
        }

        if (inactivityTimeoutWarningPopUpSpinner.getValue() == null ||
                !inactivityTimeoutWarningPopUpSpinner.getValue().equals(savedSettings.getInactivityTimeoutWarningTime())) {
            return true;
        }

        if (maxLoginAttemptsSpinner.getValue() == null ||
                !maxLoginAttemptsSpinner.getValue().equals(savedSettings.getDeactivationAfterLoginAttempts())) {
            return true;
        }

        if (userAccountDeactivationSpinner.getValue() == null ||
                !userAccountDeactivationSpinner.getValue().equals(savedSettings.getDeactivationAfterInativity())) {
            return true;
        }

        if (adminLockoutSpinner.getValue() == null ||
                !adminLockoutSpinner.getValue().equals(savedSettings.getAdminLockout())) {
            return true;
        }

        if (reloginTimeoutSpinner.getValue() == null || !reloginTimeoutSpinner.getValue().equals(savedSettings.getReloginTimeout())) {
            return true;
        }

        if (reloginDelayBetweenTriesSpinner.getValue() == null || !reloginDelayBetweenTriesSpinner.getValue().equals(savedSettings.getReloginDelayBetweenTries())) {
            return true;
        }
        
        
        if (expirePasswordWarningSpinner.getValue() == null || !expirePasswordWarningSpinner.getValue().equals(savedSettings.getExpirePasswordWarning())) {
            return true;
        }        

        return false;
    }

    @Override
    public void setObjects(IManagedObjectMarkable[] objects) {
    }

    @Override
    public void setPageSite(BiCNetPluginPropertyPageSite site) {
        this.propertyPageSite = site;
    }

    @Override
    public void setReadOnly(boolean arg0) {
    }

    @Override
    public void update() {
    }

    @Override
    public void validateInput() throws BiCNetPluginException {
        Integer passwordExpInterval = (Integer) passwordExpIntervalSpinner.getValue();
        if (passwordExpInterval == null || passwordExpInterval < GSConstants.S_INIT_PASSWORD_CHANGE_INTERVAL_MIN) {
            throw new BiCNetPluginException(USMStringTable.IDS_SS_PASSWORD_CHANGE_INTERVAL_MSG.getFormatedMessage(
                    Integer.toString(GSConstants.S_INIT_PASSWORD_CHANGE_INTERVAL_MIN),
                    Integer.toString(GSConstants.S_INIT_PASSWORD_CHANGE_INTERVAL_MAX)));
        }

        Integer maxLoginAttempts = (Integer) maxLoginAttemptsSpinner.getValue();
        if (maxLoginAttempts == null || maxLoginAttempts < GSConstants.S_MAX_LOGIN_ATTEMPTS_MIN) {
            throw new BiCNetPluginException(USMStringTable.IDS_SS_MAX_LOGIN_ATTEMPTS_MSG.getFormatedMessage(
                    Integer.toString(GSConstants.S_MAX_LOGIN_ATTEMPTS_MIN),
                    Integer.toString(GSConstants.S_MAX_LOGIN_ATTEMPTS_MAX)));
        }

        Integer userAccountDeactivation = (Integer) userAccountDeactivationSpinner.getValue();
        if (userAccountDeactivation == null || userAccountDeactivation < GSConstants.S_USER_ACCOUNT_DEACTIVATE_MIN) {
            throw new BiCNetPluginException(USMStringTable.IDS_SS_USER_ACCOUNT_DEACTIVATION_MSG.getFormatedMessage(
                    Integer.toString(GSConstants.S_USER_ACCOUNT_DEACTIVATE_MIN),
                    Integer.toString(GSConstants.S_USER_ACCOUNT_DEACTIVATE_MAX)));
        }

        Integer adminLockout = (Integer) adminLockoutSpinner.getValue();
        if (adminLockout == null || adminLockout < GSConstants.S_ADMIN_LOCKOUT_PERIOD_MIN) {
            throw new BiCNetPluginException(USMStringTable.IDS_SS_ADMIN_LOCKOUT_MSG.getFormatedMessage(
                    Integer.toString(GSConstants.S_ADMIN_LOCKOUT_PERIOD_MIN),
                    Integer.toString(GSConstants.S_ADMIN_LOCKOUT_PERIOD_MAX)));
        }

        Integer inactivityTimeoutWarningTime = (Integer) inactivityTimeoutWarningPopUpSpinner.getValue();
        if (inactivityTimeoutWarningTime == null || inactivityTimeoutWarningTime < GSConstants.S_INACTIVITY_TIMEOUT_MIN) {
            throw new BiCNetPluginException(USMStringTable.IDS_SS_INACTIVITY_TIMEOUT_WARNING_TIME_MSG.getFormatedMessage(
                    Integer.toString(GSConstants.S_INACTIVITY_TIMEOUT_MIN),
                    Integer.toString(GSConstants.S_INACTIVITY_TIMEOUT_MAX)));
        }

        Integer reloginTimeout = (Integer) reloginTimeoutSpinner.getValue();
        if (reloginTimeout == null || reloginTimeout < GSConstants.S_RELOGIN_TIMEOUT_MIN) {
            throw new BiCNetPluginException(USMStringTable.IDS_SS_RELOGIN_TIMEOUT_MSG.getFormatedMessage(
                    GSConstants.S_RELOGIN_TIMEOUT_MIN,
                    GSConstants.S_RELOGIN_TIMEOUT_MAX));
        }

        Integer reloginDelayBetweenTries = (Integer) reloginDelayBetweenTriesSpinner.getValue();
        if (reloginDelayBetweenTries == null || reloginDelayBetweenTries < GSConstants.S_RELOGIN_DELAY_BETWEEN_TRIES_MIN) {
            throw new BiCNetPluginException(USMStringTable.IDS_SS_RELOGIN_DELAY_BETWEEN_TRIES_MSG.getFormatedMessage(
                    GSConstants.S_RELOGIN_DELAY_BETWEEN_TRIES_MIN,
                    GSConstants.S_RELOGIN_DELAY_BETWEEN_TRIES_MAX));
        }
        
        
        Integer expirePasswordWarning = (Integer) expirePasswordWarningSpinner.getValue();
        if (expirePasswordWarning == null || expirePasswordWarning < GSConstants.S_EXPIRE_PASSWORD_WARNING_MIN) {
            throw new BiCNetPluginException(USMStringTable.IDS_SS_EXPIRE_PASSWORD_WARNING_MSG.getFormatedMessage(
                    GSConstants.S_EXPIRE_PASSWORD_WARNING_MIN,
                    GSConstants.S_EXPIRE_PASSWORD_WARNING_MAX));
        }

    }

    @Override
    public BiCNetPluginSettingsPropertyPage[] getChildPages() {
        return null;
    }

    @Override
    public boolean isEnabled(IManagedObject[] arg0) {
        return USMUtility.getInstance().checkIfOperatorHasPermission(
                USMCommandID.S_UI_ID_GENERAL_SECURITY_SETTINGS.getMenuString());
    }

    /**
     * ***********************************************************************
     * Sets the interface of the enclosing frame provided by the application.
     * This method is called before the view is displayed. The view should
     * store the given reference for later use.
     *
     * @param frame Reference to plug-in frame.
     *              ************************************************************************
     */
    @Override
    public void setFrame(BiCNetPluginFrame frame) {

    }

    @Override
    public void updateData(Object key) {
        if (key instanceof GSGeneralSettingData) {
            GSGeneralSettingData data = (GSGeneralSettingData) key;

            int adminLockout = data.getAdminLockout();
            adminLockoutSpinner.setValue(adminLockout);
            adminLockoutSpinner.setUnmodifiedValue(adminLockout);

            int passwordExpInterval = data.getInitPasswordChangeInterval();
            passwordExpIntervalSpinner.setValue(passwordExpInterval);
            passwordExpIntervalSpinner.setUnmodifiedValue(passwordExpInterval);

            int inactivityTimeout = data.getInactivityTimeout();
            sessionTimeoutSpinner.setValue(inactivityTimeout);
            sessionTimeoutSpinner.setUnmodifiedValue(inactivityTimeout);

            int inactivityTimeoutWarningTime = data.getInactivityTimeoutWarningTime();
            inactivityTimeoutWarningPopUpSpinner.setValue(inactivityTimeoutWarningTime);
            inactivityTimeoutWarningPopUpSpinner.setUnmodifiedValue(inactivityTimeoutWarningTime);

            maxLoginAttemptsSpinner.setValue(data.getDeactivationAfterLoginAttempts());
            maxLoginAttemptsSpinner.setUnmodifiedValue(data.getDeactivationAfterLoginAttempts());

            int deactivationAfterInativity = data.getDeactivationAfterInativity();
            userAccountDeactivationSpinner.setValue(deactivationAfterInativity);
            userAccountDeactivationSpinner.setUnmodifiedValue(deactivationAfterInativity);

            reloginTimeoutSpinner.setValue(data.getReloginTimeout());
            reloginTimeoutSpinner.setUnmodifiedValue(data.getReloginTimeout());

            reloginDelayBetweenTriesSpinner.setValue(data.getReloginDelayBetweenTries());
            reloginDelayBetweenTriesSpinner.setUnmodifiedValue(data.getReloginDelayBetweenTries());
            
            expirePasswordWarningSpinner.setValue(data.getExpirePasswordWarning());
            expirePasswordWarningSpinner.setUnmodifiedValue(data.getExpirePasswordWarning());
        }
    }

    @Override
    public void saveData(SecuritySettingsData data) {
        GSGeneralSettingData settingsData = data.getData();

        settingsData.setInitPasswordChangeInterval((Integer) passwordExpIntervalSpinner.getValue());
        settingsData.setInactivityTimeout((Integer) sessionTimeoutSpinner.getValue());
        settingsData.setInactivityTimeoutWarningTime((Integer) inactivityTimeoutWarningPopUpSpinner.getValue());
        settingsData.setDeactivationAfterLoginAttempts((Integer) maxLoginAttemptsSpinner.getValue());
        settingsData.setDeactivationAfterInactivity((Integer) userAccountDeactivationSpinner.getValue());
        settingsData.setAdminLockout((Integer) adminLockoutSpinner.getValue());
        settingsData.setReloginTimeout((Integer) reloginTimeoutSpinner.getValue());
        settingsData.setReloginDelayBetweenTries((Integer) reloginDelayBetweenTriesSpinner.getValue());
        settingsData.setExpirePasswordWarning((Integer) expirePasswordWarningSpinner.getValue());
    }

    /**
     * Add listener to listener list.
     * 
     * @param listener
     *            listener
     */
    public void addChangeListener(ChangeListener listener) {
        changeListeners.add(listener);
    }

    /**
     * Remove listener form listener list.
     * 
     * @param listener
     *            listener
     */
    public void removeChangeListener(ChangeListener listener) {
        changeListeners.remove(listener);
    }

    @Override
    public void stateChanged(ChangeEvent e) {
        if (propertyPageSite != null) {
            propertyPageSite.eventPageStatusChanged(this);
        }
        for (ChangeListener listener : changeListeners) {
            listener.stateChanged(null);
        }
    }
}
