/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:           USM
 * Author:              USM Team, SCS Bangalore
 * Substitute:          
 *
 * --------------------------------------------------------
 * History
 * created: 			09-06-2004
 * first version completed: 	18-06-2004
 *
 * <date>       <author>        <reason(s) of change>
 * 18-01-2005	Muyeen Munaver	CF00702 - The "OK" could became Grey in the "New User" window
 * 
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.view;

import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.tools.jfx.JfxText;

/**
 * The base class in User and Security Management is now responsible for the
 * button panel. The derived classes have to indicate to the base class the
 * buttons that need to be added.
 * 
 * To achieve this, the class USMButtonType has been defined, which constitues
 * all the different buttons that are available within USM. This is an enum
 * class which stores the different buttons available
 */
public final class USMButtonType {

	/**
	 * Data member to hold the Enum Cancel. Should not be disabled on wait
	 */
	public static final USMButtonType BTN_TYPE_CANCEL =
		new USMButtonType(
			USMButtonTypeEnum.BTN_TYPE_CANCEL,
			null,
			USMStringTable.IDS_BUTTON_CANCEL,
			false);

	/**
	 * Data member to hold the Enum Close. Should not be disabled on wait
	 */
	public static final USMButtonType BTN_TYPE_CLOSE =
		new USMButtonType(
			USMButtonTypeEnum.BTN_TYPE_CLOSE,
			null,
			USMStringTable.IDS_BUTTON_CLOSE,
			false);

	/**
	 * Data member to hold the Enum Separator. Should not be disabled on wait
	 */
	public static final USMButtonType BTN_SEPARATOR =
		new USMButtonType(
			USMButtonTypeEnum.BTN_SEPARATOR,
			null,
			new JfxText(""),
			false);

	/**
	 * Data member to hold the Enum Help. Should not be disabled on wait
	 */
	public static final USMButtonType BTN_TYPE_HELP =
		new USMButtonType(
			USMButtonTypeEnum.BTN_TYPE_HELP,
			null,
			USMStringTable.IDS_BUTTON_HELP,
			false);

	/**
	 * Data member to hold the Operation Id for the Button
	 */
	private String strOperationId;

	/**
	 * Data member to hold the Tool Tip
	 */
	private JfxText strToolTip;

	/**
	 * Data member to hold the Enum that is associated with this Type.
	 */
	private USMButtonTypeEnum buttonTypeEnum;

	/**
	 * Data member to hold whether the button should be disabled, if the
	 * view on which this button is placed has a wait cursoe. True should 
	 * indicate that the button is to be disabled if view is busy.
	 */
	private boolean disableOnBusy;

	/**
	 * Constructor
	 * 		If a Button should not be authorized, then a null should
	 * be passed in the Identifier
	 * @param pEnum
	 * 		Enum Associated with the Type
	 * @param pId
	 * 		Identifier for the Type
	 * @param pToolTip
	 * 		Tool Tip associated with the Button
	 * @param pDisableOnBusy
	 * 		Boolean to indicate if the button is to be disabled if cursor is busy. 
	 * True indicates disable on wait
	 */
	public USMButtonType(
		USMButtonTypeEnum pEnum,
		String pId,
		JfxText pToolTip,
		boolean pDisableOnBusy) {

		buttonTypeEnum = pEnum;
		strOperationId = pId;
		strToolTip = pToolTip;
		disableOnBusy = pDisableOnBusy;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object p_obj) {
		boolean bEquals = false;
		if ((p_obj instanceof USMButtonType) && (null != p_obj)) {
			USMButtonType usmObject = (USMButtonType) p_obj;
			bEquals = buttonTypeEnum.equals(usmObject.buttonTypeEnum);
		}
		return bEquals;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		return strOperationId.hashCode();
	}

	/**
	 * 
	 * @return
	 */
	public JfxText getButtonName() {
		return buttonTypeEnum.getButtonName();
	}

	/**
	 * 
	 * @return
	 */
	public JfxText getToolTip() {
		return strToolTip;
	}

	/**
	 * 
	 * @return
	 */
	javax.swing.Icon getIcon() {
		return buttonTypeEnum.getIcon();
	}

	/**
	 * Function to return the associated Enum
	 * @return
	 */
	USMButtonTypeEnum getAssociatedEnum() {
		return buttonTypeEnum;
	}

	/**
	 * Function tor return the String associated with the authorization 
	 * @return
	 */
	String getAssociatedOperationID() {
		return strOperationId;
	}

	/**
	 * Helper function to return if the Button is to be disabled for long operation
	 * @return boolean Indicates whether to disable button for long operation. True indicates disable btn
	 */
	public boolean disableBtnForLongoperation() {
		return disableOnBusy;
	}
}
