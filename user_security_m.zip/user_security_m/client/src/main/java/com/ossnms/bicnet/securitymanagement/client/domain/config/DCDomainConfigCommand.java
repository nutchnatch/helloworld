/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCDomainConfigCommand
 * Author      	Asif Khan R, Jogender
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CONFIG   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain.config;

import org.apache.log4j.Logger;

import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;

/**
 * The command handler class which initiates the domain configuration user interface window
 */
public class DCDomainConfigCommand extends USMCommand {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(DCDomainConfigCommand.class);

    /**
     * This is the constructor
     */
    public DCDomainConfigCommand() {
        super(USMCommandID.S_UI_ID_VIEW_DOMAINS);
        LOGGER.info("DCDomainConfigCommand() Creating a instance of this command");
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#createAndReturnView()
     */
    @Override
    protected USMBaseView createAndReturnView() {
        LOGGER.info("createAndReturnView() Creating the domain configuration window instance of this command");
        return new DCDomainConfigView();

    }

}
