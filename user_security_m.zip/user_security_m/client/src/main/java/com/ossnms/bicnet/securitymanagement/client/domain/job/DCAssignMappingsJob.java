/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCAssignMappingJob
 * Author      	Muyeen Munaver
 * Substitute	Asifullakhan
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.MAPPING.CREATE   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain.job;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.domain.DCBusinessDelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import org.apache.log4j.Logger;

import java.util.List;

/**
 * This class represents a job that is responsible for the domain configuration
 * assign mapping operation.
 */
public class DCAssignMappingsJob extends USMJob {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(DCAssignMappingsJob.class);

	/**
	 * Vector of mappings that assigned for a particular domain
	 */
	private List mappings;

	/**
	 * Constructor
	 * 
	 * @param request
	 *            - The type of message
	 * @param jobOwner
	 *            - The controller associated with the job
	 * @param mappings
	 *            - Vector of mappings
	 */
	public DCAssignMappingsJob(USMBaseMsgType request, USMControllerIfc jobOwner, List mappings, DCDomainData domain) {

		super(request, USMCommonStrings.EMPTY, USMCommonStrings.EMPTY, jobOwner);
		LOGGER.debug("DCAssignMappingJob() - Entry");

		Object[] arr = { domain };
		String str = USMStringTable.IDS_DC_JOB_ASSIGN_MAPPINGS.getFormatedMessage(arr);
		setName(str);

		this.mappings = mappings;
		LOGGER.debug("DCAssignMappingJob() - Exit");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public USMMessage executeJob() throws BcbSecurityException {
		LOGGER.debug("executeJob() - Entry");
		DCBusinessDelegate delgate = new DCBusinessDelegate();

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("The number of mappings are " + mappings.size());
		}
		USMMessage msg = delgate.assignMappings(mappings);
		LOGGER.debug("executeJob() - Exit");
		return msg;
	}
}
