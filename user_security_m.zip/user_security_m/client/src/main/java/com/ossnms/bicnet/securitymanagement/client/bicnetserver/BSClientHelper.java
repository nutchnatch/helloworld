/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	BSClientHelper
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_OBJECTS
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_ACL 
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_SECURITY
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.INSERT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.bicnetserver;

import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.tools.jfx.components.JfxList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This class is a Helper to the Client side classes.
 */
public final class BSClientHelper {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(BSClientHelper.class);

	/**
	 * Private constructor
	 */
	private BSClientHelper(){

	}

	/**
	 * This function is called when SEs are assigned to some domains.
	 * @param lst The List which displays the SEs which have got assigned.
	 * @param lstSecObjs The SEs which have been (un)assigned
	 */
	public static void domainInfoChangedForSecObjects(JfxList<BSSecurableObject> lst, List<BSSecurableObject> lstSecObjs) {
		LOGGER.debug("Entering domainInfoChangedForSecObjects. List : {}", lstSecObjs);

		ListModel<BSSecurableObject> mdl = lst.getModel();
		int nElms = mdl.getSize();
		Map<String, BSSecurableObject> mpElms = new HashMap<>(nElms);

		for (int index = 0; index < nElms; index++) {
			BSSecurableObject secObj = mdl.getElementAt(index);
			mpElms.put(secObj.getUniqueName(), secObj);
		}

		for (BSSecurableObject secObj : lstSecObjs) {
			BSSecurableObject lstObj = mpElms.get(secObj.getUniqueName());
			if (lstObj != null) {
				lstObj.setACL(secObj.getACL());
			}
		}
		LOGGER.debug("Exiting domainInfoChangedForSecObjects.");
		lst.repaint();
	}
}
