package com.ossnms.bicnet.securitymanagement.client;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientProperties;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPrintData;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginView;
import com.ossnms.bicnet.framework.client.helpers.feedback.FrameworkActivityIndicator;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.auth.AALogonHistoryController;
import com.ossnms.bicnet.securitymanagement.client.auth.AALogonHistoryData;
import com.ossnms.bicnet.securitymanagement.client.auth.AASessionClientController;
import com.ossnms.bicnet.securitymanagement.client.auth.KerberosCallbackHandler;
import com.ossnms.bicnet.securitymanagement.client.auth.LogonHistoryEntry;
import com.ossnms.bicnet.securitymanagement.client.auth.job.AALogonJob;
import com.ossnms.bicnet.securitymanagement.client.auth.job.LogonJobListener;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.client.useradministration.UADelegate;
import com.ossnms.tnms.securitymanagement.client.res.USMLoginSplashScreenPanel;
import com.ossnms.tools.jfx.JfxButtonPanel;
import com.ossnms.tools.jfx.JfxFormPanel;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxCheckBox;
import com.ossnms.tools.jfx.components.JfxComboBox;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxPasswordField;
import com.ossnms.tools.jfx.components.JfxTextField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.security.auth.Subject;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * ***************************************************************************
 * Logon component for BiCNet.
 * ****************************************************************************
 */

public final class SecurityLogonView extends JfxFormPanel implements BiCNetPluginView, LogonJobListener {

    private static final int LOGIN_HELPID = 1655373825;

	private static final long serialVersionUID = 5754318785028696727L;

    // Data member for the Logging of the class.
    private static final Logger LOGGER = LoggerFactory.getLogger(SecurityLogonView.class);

    // Data member for the Window title.
    private static final String WINDOW_TITLE = USMStringTable.IDS_AA_WINDOW_LOGIN.toString();

    // Constants
    public static final String USER_DEFAULT = "Administrator";

    public static final String SERVER_LOCAL_HOST = "localhost";
    public static final int SERVER_HISTORY_DEPTH = 10;

    public static final String KRB5_REALM = "java.security.krb5.realm";
    public static final String KRB5_KDC = "java.security.krb5.kdc";

    private static final String DEFAULT_PORT_SUFFIX = ":" + SMSettingsProperties.getServerDefaultPort();

    public static final int SPLASH_WIDTH = 282;
    public static final int SPLASH_HEIGHT = 100;
    public static final int FIELD_COLUMNS = 20;
    public static final int WINDOW_SSO_HEIGHT = 271;
    public static final int WINDOW_HEIGHT = 250;

    private transient BiCNetPluginFrame frame = null;
    private boolean bOK = false;
    private ISessionContext sessionContext = null;

    /**
     * Boolean value that should be defined in the properties file to enable SSO option to be visible and enabled
     */
    private boolean isSSOOptionEnabled = false;

    // Data member for controlling logon history on client side
    private final transient AALogonHistoryController historyController = AALogonHistoryController.getInstance();

    private AALogonHistoryData historyData = null;
    private Subject ssoSubject;

    private final JfxCheckBox ssoCheckBox = new JfxCheckBox(USMStringTable.IDS_AA_SINGLE_SIGNON_LABEL);
    private final JfxButton buttonOK = new JfxButton();
    private final JfxButton buttonCancel = new JfxButton();
    private final JfxComboBox comboServer = new WideComboBox();
    private final JfxTextField fieldUserName = new JfxTextField();
    private final JfxPasswordField fieldPassword = new JfxPasswordField();
    // Data member to show the Loading Screen
    private FrameworkActivityIndicator loadingPanel = new FrameworkActivityIndicator(this);

    /**
     * ***********************************************************************
     * Constructs the component
     *
     * @param plugin Parent plugin.
     *               ************************************************************************
     */
    public SecurityLogonView(SecurityPlugin plugin) {
        LOGGER.debug("SecurityLogonView(SecurityPlugin plugin)  Entry");

        isSSOOptionEnabled = this.ssoIsEnabled();

        int nIndex = 1;

        BiCNetPluginSite site = USMUtility.getInstance().getSecuritySite();
        String operationAppFamilyName = site.getClientProperty(BiCNetPluginClientProperties.PRODUCT_FAMILY_NAME, null);
        String operationAppName = site.getClientProperty(BiCNetPluginClientProperties.CLIENT_NAME_FOR_IMAGE, null);

        ImageIcon iconSplash = ResourcesIconFactory.getInstance().getAppLoginImage();
        USMLoginSplashScreenPanel splashScreen = new USMLoginSplashScreenPanel(operationAppFamilyName, operationAppName, iconSplash);
        splashScreen.setPreferredSize(new Dimension(SPLASH_WIDTH, SPLASH_HEIGHT));

        // Set Panel layout
        this.setLayout(new BorderLayout());

        JPanel thisPanel = new JPanel();
        thisPanel.setLayout(new BorderLayout());
        thisPanel.add(splashScreen, BorderLayout.NORTH);

        KeyAdapter userNameAndPasswordHandler = new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                SecurityLogonView.this.checkAndDisableOKBtn();
            }
        };

        this.comboServer.setEditable(true);
        this.comboServer.setSelectedIndex(0);
        this.comboServer.setMandatoryEntry(true);
        this.comboServer.setRenderer(new ServerRenderer(this.comboServer.getRenderer()));
        JfxLabel labelServer = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_SERVER);
        labelServer.setLabelAndMnemonicFor(this.comboServer);

        JPanel inputFieldGroup = new JPanel(new GridBagLayout());
        inputFieldGroup.setOpaque(false);
        inputFieldGroup.setBorder(JfxUtils.DIALOG_OUTSIDE_BORDER);
        inputFieldGroup.add(labelServer, new GridBagConstraints(0, nIndex, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE,
                new Insets(JfxUtils.LABEL_TOP_MARGIN, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, JfxUtils.DEFAULT_MARGIN), 0, 0));
        inputFieldGroup.add(this.comboServer, new GridBagConstraints(1, nIndex++, 1, 1, 1.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));

        JfxLabel labelUserName = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_USERID);
        labelUserName.setLabelAndMnemonicFor(this.fieldUserName);
        this.fieldUserName.setColumns(FIELD_COLUMNS);
        this.fieldUserName.setMandatoryEntry(true);
        this.fieldUserName.addKeyListener(userNameAndPasswordHandler);

        inputFieldGroup.add(labelUserName, new GridBagConstraints(0, nIndex, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE,
                new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, JfxUtils.DEFAULT_MARGIN), 0, 0));
        inputFieldGroup.add(this.fieldUserName, new GridBagConstraints(1, nIndex++, 1, 1, 1.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.HORIZONTAL,
                new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));

        JfxLabel labelPassword = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_LABEL_PASSWORD);
        labelPassword.setLabelAndMnemonicFor(this.fieldPassword);
        this.fieldPassword.setColumns(FIELD_COLUMNS);
        this.fieldPassword.setMandatoryEntry(true);
        this.fieldPassword.addKeyListener(userNameAndPasswordHandler);
        this.fieldPassword.setText("");

        inputFieldGroup.add(labelPassword, new GridBagConstraints(0, nIndex, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE,
                new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, JfxUtils.DEFAULT_MARGIN), 0, 0));
        inputFieldGroup.add(this.fieldPassword, new GridBagConstraints(1, nIndex++, 1, 1, 1.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));

        this.ssoCheckBox.setBorder(new EmptyBorder(0, 0, 0, 0));
        this.ssoCheckBox.addItemListener(e -> SecurityLogonView.this.actionCheckSSO());

        // If single sign-on option is enabled add it to GUI
        if (isSSOOptionEnabled) {
            inputFieldGroup.add(this.ssoCheckBox, new GridBagConstraints(0, nIndex++, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0), 0, 0));
        }

        this.buttonOK.setText(USMStringTable.IDS_BUTTON_OK);
        this.buttonOK.addActionListener(SecurityLogonView.this::actionOK);
        this.buttonOK.setPreferredSize(new Dimension(JfxUtils.BUTTON_PREFERRED_WIDTH, JfxUtils.BUTTON_PREFERRED_HEIGHT));
        this.buttonOK.setMinimumSize(new Dimension(JfxUtils.BUTTON_PREFERRED_WIDTH, JfxUtils.BUTTON_PREFERRED_HEIGHT));

        this.buttonCancel.setText(USMStringTable.IDS_BUTTON_CANCEL);
        this.buttonCancel.addActionListener(evt -> SecurityLogonView.this.actionCancel());
        this.buttonCancel.setPreferredSize(new Dimension(JfxUtils.BUTTON_PREFERRED_WIDTH, JfxUtils.BUTTON_PREFERRED_HEIGHT));
        this.buttonCancel.setMinimumSize(new Dimension(JfxUtils.BUTTON_PREFERRED_WIDTH, JfxUtils.BUTTON_PREFERRED_HEIGHT));

        this.buttonCancel.setMargin(new Insets(0, 0, 0, 0));

        JfxButtonPanel commitButtonPanel = new JfxButtonPanel(null, Arrays.asList(buttonOK, buttonCancel), null);

        thisPanel.add(inputFieldGroup, BorderLayout.CENTER);
        this.add(thisPanel, BorderLayout.CENTER);
        this.add(commitButtonPanel, BorderLayout.SOUTH);

        this.loadHistory();
        // Register ENTER shortcut
        this.registerKeyboardAction(new ActionHandler(), "ENTER", KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0, false), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        // Register ESC shortcut
        this.registerKeyboardAction(new ActionHandler(), "ESC", KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        this.setNamesForTesting();

        // if single sign-on option is visible, window should be bigger in height
        Dimension windowSize;
        if (isSSOOptionEnabled) {
            windowSize = new Dimension(splashScreen.getPreferredSize().width, WINDOW_SSO_HEIGHT);
        } else {
            windowSize = new Dimension(splashScreen.getPreferredSize().width, WINDOW_HEIGHT);
        }

        this.setMinimumSize(windowSize);
        this.setPreferredSize(windowSize);

        LOGGER.debug("SecurityLogonView(SecurityPlugin plugin)  Exit");
        this.checkAndDisableOKBtn();
    }

    /**
     * Method to check if SSO is configured
     *
     * @return true/false
     */
    private boolean ssoIsEnabled() {
        return getDomain() != null;
    }

    /**
     * Helper method to check and disable to OK button.
     */
    public void checkAndDisableOKBtn() {
        if (this.ssoCheckBox.isSelected()) {
            if (this.ssoSubject != null) {
                this.fieldPassword.setText("**********");
                this.fieldPassword.setEnabled(false);
            }
            this.fieldUserName.setEnabled(false);
        }

        String str1 = this.fieldUserName.getText();
        String str2 = String.valueOf(this.fieldPassword.getPassword());
        boolean bBothNonEmpty = ((str1 != null) && (str1.length() > 0)) && ((str2 != null) && (str2.length() > 0));
        this.buttonOK.setEnabled(bBothNonEmpty);
    }

    /**
     * Helper function that is used to set the Names of all the editable components within the Window.
     *
     * Strings in this function are not to be Internationalized.
     */
    private void setNamesForTesting() {
        this.comboServer.setName("ServerName");
        this.fieldUserName.setName("Username");
        this.fieldPassword.setName("Password");
        this.buttonOK.setName("Ok");
        this.buttonCancel.setName("Cancel");
        this.ssoCheckBox.setName("SingleSignOn");
    }

    public void setFocus() {
        Object item = this.comboServer.getSelectedItem();
        if (item == null) {
            this.comboServer.setFocusable(true);
            this.comboServer.requestFocus();
        } else if ((this.fieldUserName.getText() == null) || (this.fieldUserName.getText().length() == 0)) {
            this.fieldUserName.setFocusable(true);
            this.fieldUserName.requestFocus();
        } else {
            this.fieldPassword.setFocusable(true);
            this.fieldPassword.requestFocus();
        }
    }

    /**
     * ***********************************************************************
     * Sets the value displayed for the server. Does nothing in LCT mode,
     * because only "localhost" is allowed.
     *
     * @param strServer Server name or IP address, optional with port.
     *                  ************************************************************************
     */
    private void addServer(String strServer) {
        if (strServer != null) {
            this.comboServer.addString(strServer.replace(DEFAULT_PORT_SUFFIX, ""));
        }
    }

    private void addServer(LogonHistoryEntry server) {
        this.comboServer.addValue(server);
    }

    private void showLoadingPanel(String strMessage) {
        if (!loadingPanel.isLayerVisible()) {
            loadingPanel.setActivityIndicatorVisible(true);
        }
        loadingPanel.setMessage(strMessage);
    }

    private void hideLoadingPanel() {
        if (loadingPanel != null) {
            loadingPanel.setActivityIndicatorVisible(false);
            loadingPanel.setMessage("");
            repaint();
        }
    }

    private void checkAutoLoginProperties() {
        String[] params = System.getProperties().getProperty("lax.command.line.args").split("-");
        List<String> listParams = Stream.of(params).map(String::trim).collect(Collectors.toList());
        if(listParams.contains("test")) {
            listParams.forEach(param -> {
                if (param.startsWith("user")) {
                    setFieldParam(fieldUserName, param);
                }
                else if (param.startsWith("pass")) {
                    setFieldParam(fieldPassword, param);
                }    
            });
           
            if (!fieldUserName.getText().isEmpty() && fieldPassword.getPassword().length > 0) {
                buttonOK.setEnabled(true);
                buttonOK.doClick();
            }
        }
    }

    private void setFieldParam(JTextField textField, String param) {
        String[] fieldParams = param.split(":");
        if (fieldParams.length == 2) {
            textField.setText(fieldParams[1].trim());
        }
    }

    /**
     * ***********************************************************************
     * Returns the value displayed for the server.
     *
     * @return Server name or IP address, optional with port.
     * ************************************************************************
     */
    public String getServer() {
        LOGGER.debug("getServer() 	Entry");
        Object item = this.comboServer.getSelectedItem();

        if (item != null) {

            String server = item.toString();
            if (!server.matches(".+:\\d+")) {
                /*
                 *  if rule <host>:<port> fails we must assume that only the host 
                 *  name was written so we must add to it the default server port
                 */
                server = server.concat(DEFAULT_PORT_SUFFIX);
            }
            return server;
        }
        LOGGER.debug("getServer() 	Exit");
        return "";
    }

    /**
     * ***********************************************************************
     * Returns the value displayed for the user name.
     *
     * @return User name.
     * ************************************************************************
     */
    public String getUserName() {
        return this.fieldUserName.getText();
    }

    /**
     * ***********************************************************************
     * Returns the value displayed for the password as MD5 digest hexdump.
     *
     * @return Password string.
     * ************************************************************************
     */
    public String getPassword() {
        return String.valueOf(this.fieldPassword.getPassword());
    }

    /**
     * ***********************************************************************
     * Sets the component's frame.
     *
     * @param frame Component frame.
     *              ************************************************************************
     */
    @Override
    public void setFrame(BiCNetPluginFrame frame) {
        this.frame = frame;
    }

    /**
     * ***********************************************************************
     * Returns the lightweight component.
     * ************************************************************************
     */
    @Override
    public JComponent getComponent() {
        return loadingPanel;
    }

    /**
     * ***********************************************************************
     * Returns the unique ID identifying the component.
     *
     * @return Unique ID
     * ************************************************************************
     */
    @Override
    public String getID() {
        return this.getClass().getName();
    }

    /**
     * ***********************************************************************
     * Returns the title to be used.
     *
     * @return Title string.
     * ************************************************************************
     */
    @Override
    public String getTitle() {
        return WINDOW_TITLE;
    }

    /**
     * ***********************************************************************
     * Returns the icon to be used.
     *
     * @return Icon.
     * ************************************************************************
     */
    @Override
    public Icon getIcon() {
        return null;
    }

    /**
     * ***********************************************************************
     * Returns whether the component is resizable by the user.
     *
     * @return True if resizable.
     * ************************************************************************
     */
    @Override
    public boolean isResizable() {
        return false;
    }

    /**
     * ***********************************************************************
     * Returns whether the component is closable by the user.
     *
     * @return True if closable.
     * ************************************************************************
     */
    @Override
    public boolean isClosable() {
        return !this.bOK;
    }

    /**
     * ***********************************************************************
     * Returns whether the frame can close.
     *
     * @return True if frame can be closed.
     * ************************************************************************
     */
    @Override
    public boolean canClose() {
        return !this.bOK;
    }

    /**
     * ***********************************************************************
     * Returns the context help ID for the component.
     *
     * @return Globally unique help ID.
     * ************************************************************************
     */
    @Override
    public int getHelpID() {
        return LOGIN_HELPID;
    }

    /**
     * ***********************************************************************
     * Returns whether the component is printable by the user.
     *
     * @return True if printable.
     * ************************************************************************
     */
    @Override
    public boolean isPrintable() {
        return false;
    }

    /**
     * ***********************************************************************
     * Requests the component to provide data for report printing.
     *
     * @return Print data implementation.
     * ************************************************************************
     */
    @Override
    public BiCNetPluginPrintData getPrintData() {
        return null;
    }

    /**
     * ***********************************************************************
     * Notifies the component that the parent frame is going to be opened.
     * ************************************************************************
     */
    @Override
    public void eventOpened() {
        if(!ssoCheckBox.isSelected()) {
            checkAutoLoginProperties();
        }
    }

    /**
     * ***********************************************************************
     * Notifies the component that the parent frame is going to be closed.
     * ************************************************************************
     */
    @Override
    public void eventClosing() {
    }

    /**
     * ***********************************************************************
     * Helper Method to enable / disable buttons
     *
     * @param enable true to enable the buttons, otherwise false
     *               ************************************************************************
     */
    public void enableButtons(boolean enable) {
        this.buttonOK.setEnabled(enable);
        this.buttonCancel.setEnabled(enable);
        this.fieldUserName.setEnabled(enable);
        this.fieldPassword.setEnabled(enable);
        this.comboServer.setEnabled(enable);
        this.ssoCheckBox.setEnabled(enable);

        // Reset controls
        if (enable) {
            this.fieldPassword.setText("");
            hideLoadingPanel();
            this.setFocus();
            this.bOK = false;
        }
    }

    /**
     * **********************************************************************
     * Called when the checkbox for single sign-on is pressed. This method
     * pre-populates the login box with the domain user when checked.
     * ***********************************************************************
     */
    protected void actionCheckSSO() {
        if (this.ssoCheckBox.isSelected()) {

            // if single sign-on is enabled, check if ticket is in cache
            if (isSSOOptionEnabled) {
                // if ticket is in cache there is no need for login
                try {
                    getDomain();

                    LoginContext loginContext = new LoginContext(SecurityLogonView.class.getName());
                    loginContext.login();

                    this.ssoSubject = loginContext.getSubject();

                    this.fieldPassword.setText("**********");
                    this.fieldPassword.setEnabled(false);

                } catch (LoginException le) {
                    LOGGER.error("Unable to get kerberos ticket.", le);
                    this.ssoSubject = null;
                    this.fieldPassword.setText("");
                    this.fieldPassword.setEnabled(true);
                }
            }

            // If ticket is not in cache, get domain username and fill login textfield
            if (!"".equals(this.fieldUserName.getText())) {
                this.historyData.setUserName(this.fieldUserName.getText());
            }

            this.fieldUserName.setText(getSystemUserName() + "@" + getDomain());
            this.fieldUserName.setEnabled(false);
            this.checkAndDisableOKBtn();

        } else {
            // Else, set default username
            this.ssoSubject = null;
            this.fieldUserName.setText(this.historyData.getUserName());
            this.fieldPassword.setEnabled(true);
            this.fieldUserName.setEnabled(true);
            this.fieldPassword.setText("");
            this.checkAndDisableOKBtn();
        }
    }

    private String getSystemUserName() {
        // Use system instead ofNTSystem because its not OS dependent
        return System.getProperty("user.name");
    }

    private String getDomain() {
        String userDomain = System.getenv("USERDNSDOMAIN");
        if (userDomain != null) {
            String userDomainUpperCase = userDomain.toUpperCase();
            System.setProperty(KRB5_REALM, userDomainUpperCase);
            System.setProperty(KRB5_KDC, userDomain);
        }

        return userDomain;
    }

    /**
     * ***********************************************************************
     * Called when user pressed "OK" button.
     *
     * @param e Action event.
     *          ************************************************************************
     */
    protected void actionOK(ActionEvent e) {
        LOGGER.debug("actionOK(ActionEvent e) Entry ");

        if (!this.buttonOK.isEnabled()) {
            // Handling in progress
            return;
        }
        this.bOK = true;

        Component comp = SwingUtilities.getRoot(this);
        JDialog frame = (JDialog) comp;
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        showLoadingPanel(USMStringTable.getString(USMStringTable.IDS_AA_LOGIN_AUTH_STATUS));

        // Disable buttons temporarily
        this.enableButtons(false);

        AASessionClientController objController = AASessionClientController.getInstance();
        AALogonJob objLoginJob = new AALogonJob(objController, this);

        String userName = this.getUserName();
        objLoginJob.setUserName(userName);

        String password = this.getPassword();
        
        objLoginJob.setPassword(password);
 
        String server = this.getServer();
        objLoginJob.setServerHostName(server);

        // if sso is not selected login with normal user and password through ldap
        if (this.ssoCheckBox.isSelected()) {
            // if SSO subject is null, there was no ticket in cache or it is not possible to retrieve it, therefore we need
            // to get the user password and acquire the ticket
            if (this.ssoSubject == null) {
                try {
                    LoginContext loginContext = new LoginContext(
                            SecurityLogonView.class.getName(),
                            new KerberosCallbackHandler(userName, password)
                    );
                    loginContext.login();

                    this.ssoSubject = loginContext.getSubject();
                } catch (LoginException ex) {
                    LOGGER.error("Unable to get kerberos ticket. Check username and password.", ex);
                    final SecurityLogonView windowView = this;

                    String message = USMStringTable.IDS_AA_DIALOG_MESSAGE_AUTHENTICATION_FAILURE.toString();
                    Throwable t = ex.getCause();
                    if (t.toString().contains(USMStringTable.IDS_ACTIVEDIRECTORY_TIMEDOUT_EXCEPTION.toString())) {
                        message = USMStringTable.IDS_ACTIVEDIRECTORY_UNREACHABLE.toString();
                    }

                    JfxOptionPane.showMessageBox(windowView, USMStringTable.IDS_AA_DIALOG_MESSAGE_LOGIN_FAILURE_TITLE.toString(), message, JOptionPane.CLOSED_OPTION, JOptionPane.ERROR_MESSAGE);
                    this.fieldPassword.setText("");
                    this.enableButtons(true);
                    this.checkAndDisableOKBtn();
                    return;
                }
            }
			if (this.ssoSubject != null) {
				String subjectName = this.ssoSubject.getPrincipals().iterator().next().getName();
				// User name is not the same existing on kerberos ticket
				if (subjectName.equalsIgnoreCase(userName)) {
					objLoginJob.setUserName(subjectName);

				} else {
					JfxOptionPane.showMessageBox(this, USMStringTable.IDS_AA_DIALOG_MESSAGE_LOGIN_FAILURE_TITLE.toString(),
                            USMStringTable.IDS_AA_DIALOG_MESSAGE_SSO_FAILURE_CLIENT_TICKET_VALIDATION,
							JOptionPane.CLOSED_OPTION, JOptionPane.ERROR_MESSAGE);
					this.fieldPassword.setText("");
					this.enableButtons(true);
					this.checkAndDisableOKBtn();
					return;
				}
			}
            objLoginJob.setSsoSubject(this.ssoSubject);
        }

        objController.queueJob(objLoginJob);
        LOGGER.debug(" actionOK()  Exit ");
    }

    /**
     * ***********************************************************************
     * Called when user pressed "Cancel" button.
     * ************************************************************************
     */
    protected void actionCancel() {
        LOGGER.debug(" ctionCancel(ActionEvent e)  Entry ");
        this.frame.closeFrame();
        LOGGER.debug(" ctionCancel(ActionEvent e)  Exit ");
    }

    /**
     * ***********************************************************************
     * Sets the IsessionContext after user successful logged in.
     *
     * @param sessionContext - Session token for the user.
     *                       ************************************************************************
     */
    protected void setSessionContext(ISessionContext sessionContext) {
        this.sessionContext = sessionContext;
    }

    /**
     * ***********************************************************************
     * Returns the IsessionContext .
     *
     * @return ISessionContext - Session token for the user.
     * ************************************************************************
     */
    protected ISessionContext getSessionContext() {
        return this.sessionContext;
    }

    /**
     * **********************************************************************
     * Returns whether the SSO is enabled or not.
     *
     * @return True if SSO option is enabled. False otherwise.
     * ***********************************************************************
     */
    public boolean isSSOEnabled() {
        return this.ssoCheckBox.isSelected();
    }

    /**
     * ***********************************************************************
     * Fills the server combo box with the history.
     * ************************************************************************
     */
    private void loadHistory() {
        String strLastUser;

        LOGGER.debug("loadHistory()		Entry");
        this.historyData = this.historyController.readLogonHistory();
        if (this.historyData != null) {
            if (isSSOOptionEnabled) {
                this.ssoCheckBox.setSelected(this.historyData.getSsoCheckBox());
            }

            if (!this.ssoCheckBox.isSelected()) {
                /* Load last user name, otherwise use default */
                strLastUser = this.historyData.getUserName();
                if (strLastUser != null && strLastUser.length() > 0) {
                    this.fieldUserName.setText(strLastUser);
                } else {
                    this.fieldUserName.setText(new UADelegate().getAdminUserName());
                }
            }

            /* Add history items. */
            List<LogonHistoryEntry> serverList = this.historyData.getServerList();

            for (LogonHistoryEntry server : serverList) {
                addServer(server);
            }

        } else {
            addServer(SERVER_LOCAL_HOST);
            this.historyData = new AALogonHistoryData();
        }
        LOGGER.debug("loadHistory()  Exit ");
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getFrame()
     */
    @Override
    public BiCNetPluginFrame getFrame() {
        return this.frame;
    }

    /**
     * Private class to do the following handling - 1. Handle Enter clicked. 2.
     * Handle Esc clicked. 3. Open the Help if F1 is pressed.
     */
    private class ActionHandler implements ActionListener {
        /**
         * *******************************************************************
         * Called when action has been performed. This method passes the event
         * to actionOK(), actionCancel() or actionHelp().
         *
         * @param event Action event.
         *              ********************************************************************
         */
        @Override
        public void actionPerformed(ActionEvent event) {
            String actionCommand = event.getActionCommand();
            if ("ENTER".equals(actionCommand)) {
                SecurityLogonView.this.actionOK(event);
            } else if ("ESC".equals(actionCommand)) {
                SecurityLogonView.this.actionCancel();
            }
        }
    }

    @Override
    public boolean isDockable() {
        return false;
    }

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#eventActivated()
	 */
	@Override
	public void eventActivated() {
		
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#eventDeactivated()
	 */
	@Override
	public void eventDeactivated() {
		
	}

    @Override
    public void handleLoginSuccess() {
        SwingUtilities.invokeLater(() -> getFrame().closeFrame());
    }

    @Override
    public void handleLoginError(String errorMessage, String errorTitle, boolean recoverableError) {
        showErrorMessage(errorMessage, errorTitle);
    }

    private void showErrorMessage(String errorMessage, String errorTitle) {
        SwingUtilities.invokeLater(() -> {
            JfxOptionPane.showMessageBox(SecurityLogonView.this, errorTitle, errorMessage, JOptionPane.CLOSED_OPTION, JOptionPane.ERROR_MESSAGE);
            enableButtons(true);
            checkAndDisableOKBtn();
        });
    }

    /**
     * Sets the specified value in the status bar.
     * @param progressMessage Text to be displayed
     */
    @Override
    public void handleLoginProgress(String progressMessage) {
        SwingUtilities.invokeLater(() -> {
            if (progressMessage != null) {
                showLoadingPanel(progressMessage);
            }
        });
    }

    @Override
    public void handleLoginCancelled() {
        SwingUtilities.invokeLater(() -> {
            enableButtons(true);
            checkAndDisableOKBtn();
        });
    }

    @Override
    public void handleLoginCancelled(String errorMessage, String errorTitle) {
        showErrorMessage(errorMessage, errorTitle);
    }

    private static class ServerRenderer extends JPanel implements ListCellRenderer {
        private final ListCellRenderer defaultRenderer;

        private final JLabel server = new JLabel();
        private final JLabel serverLabel = new JLabel();

        public ServerRenderer(ListCellRenderer defaultRenderer) {
            this.defaultRenderer = defaultRenderer;

            this.setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
            this.setOpaque(true);
            this.add(server);
            this.add(Box.createHorizontalGlue());
            this.add(serverLabel);
        }

        @Override
        public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            Component rendererComponent = defaultRenderer.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

            if (value instanceof JfxComboBox.ItemData && ((JfxComboBox.ItemData) value).getObjValue() instanceof LogonHistoryEntry) {
                JfxComboBox.ItemData itemDataValue = (JfxComboBox.ItemData) value;
                LogonHistoryEntry entry = (LogonHistoryEntry) itemDataValue.getObjValue();

                if (entry.getServerLabel() != null) {
                    server.setText(entry.getServer());
                    serverLabel.setText("(" + entry.getServerLabel() + ")");

                    if (rendererComponent instanceof JLabel) {
                        copyLayout((JLabel) rendererComponent);
                    }

                    return this;
                }
            }

            return rendererComponent;
        }

        private void copyLayout(JLabel rendererComponent) {
            this.setBorder(rendererComponent.getBorder());
            this.setForeground(rendererComponent.getForeground());
            this.setBackground(rendererComponent.getBackground());
            copyFont(rendererComponent);
            server.setHorizontalAlignment(rendererComponent.getHorizontalAlignment());
            serverLabel.setHorizontalAlignment(rendererComponent.getHorizontalAlignment());
        }

        private void copyFont(Component rendererComponent) {
            Font font = rendererComponent.getFont();
            server.setFont(font);
            serverLabel.setFont(new Font(font.getName(), Font.BOLD, font.getSize()));
        }
    }

    private static class WideComboBox extends JfxComboBox {

        private static final long serialVersionUID = -1957384288897690212L;

        private boolean doingLayout = false;

        @Override
        public void doLayout() {
            try {
                doingLayout = true;
                super.doLayout();
            } finally {
                doingLayout = false;
            }
        }

        @Override
        public Dimension getSize() {
            Dimension dim = super.getSize();
            if (!doingLayout) {
                dim.width = Math.max(dim.width, getPreferredSize().width);
            }
            return dim;
        }
    }

}