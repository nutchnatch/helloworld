/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	PAPolicyCreateClientController
 * Author      	Vinay Purohit
 * Substitute	muyeen
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID	:	TNMS.DX2.SM.POLICY.CREATE
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 09-02-2005	Babu B          CF000060-01   CF USM GUI Requirements
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.policy.views.create;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMBaseController;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.policy.jobs.PAJobCreatePolicy;
import com.ossnms.bicnet.securitymanagement.client.policy.jobs.PAJobGetAllPermissions;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.policy.PAMessageType;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAStatus;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * This Client Interactor is responsible for interacting with the Server for
 * operations for create a Policy
 */
class PAPolicyCreateClientController extends USMBaseController {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(PAPolicyCreateClientController.class);

	/**
	 * Data member to hold the window which is created for display of information
	 */
	private PAPolicyCreateView createPolicyWdw = null;
	private static final String METHOD_RESPONSE_ALL_PERMISSIONS = "handleResponseForGetAllAvailablePermissions() ";
	private static final String METHOD_HANDLE_RESPONSE_CREATE_POLICY = "ResponsePolicyCreated ( )";

	/**
	 * Constructor
	 * 
	 * @param view View which is responsible for the creation of
	 * the controller
	 */
	PAPolicyCreateClientController(PAPolicyCreateView view) {
		super(view);
		createPolicyWdw = view;

		registerInterestedNotificationIds(new ArrayList<USMBaseMsgType>());
	}

	/**
	 * This method sends the PA_REQ_CREATE_POLICY Message to the Server with
	 * Policy Data.
	 * 
	 * @param policyData The Policy Data which has to be created.
	 */
	boolean sendRequestToCreatePolicy(PAPolicyData policyData) {
		PAJobCreatePolicy objCreatepolicy = new PAJobCreatePolicy(this, policyData);
		return queueJob(objCreatepolicy);
	}

	/**
	* This method initiates the fetching of the Menu Cache - All Available Menu
	* Options. Sends the Request Message with Primitive :
	* PA_REQ_GET_ALL_AVAILABLE_MENU_OPTIONS
	*/
	boolean sendRequestToFetchAvailPermissions() {
		LOGGER.debug("sendRequestToFetchAvailPermissions() in the job");
		PAJobGetAllPermissions objJob = new PAJobGetAllPermissions(this);
		return queueJob(objJob);
	}

	/**
	 * This method is the handler for the Response : PA_RES_CREATE_POLICY
	 * 
	 * @param message The message which is sent by the server interactor on creation of a policy.
	 */
	private void handleResponseForCreatePolicy(USMMessage message) {
		LOGGER.debug(METHOD_HANDLE_RESPONSE_CREATE_POLICY + " ENTER_FUNCTION");

		try {
			// Pop the Result of the Operation.
			PAStatus statusObject = PAStatus.pop(message);

			if ((statusObject == PAStatus.S_SUCCESS) || (statusObject == PAStatus.S_POLICY_CONTAINS_UNRECOG_MENUS)) {
				if (statusObject == PAStatus.S_POLICY_CONTAINS_UNRECOG_MENUS) {
					// here goes the message to show that I created policy & dropped some menus.
					String strMsg = USMStringTable.IDS_PA_CREATED_POLICY_DROPPED_MENUS.toString();
					createPolicyWdw.showMessage(strMsg);
				}

				LOGGER.debug(METHOD_HANDLE_RESPONSE_CREATE_POLICY + " look created policy in admin window");
				associatedView.close();
			} else {
				String strMsg = USMStringTable.IDS_PA_FAILED_TO_CREATE_POLICY.toString() + statusObject.getErrorString();
				LOGGER.error(strMsg);
				createPolicyWdw.showMessage(strMsg);
			}

		} catch (Exception ex) {
			LOGGER.error(METHOD_HANDLE_RESPONSE_CREATE_POLICY, ex);
		}

		LOGGER.debug(METHOD_HANDLE_RESPONSE_CREATE_POLICY + " EXIT_FUNCTION");
	}

	/**
	 * This method is the handler for the response from the all permission request.
	 * 
	 * @param message Message which contains all the menu options that are available within GSS.
	 */
	private void handleResponseForGetAllAvailablePermissions(USMMessage message) {
		LOGGER.info(METHOD_RESPONSE_ALL_PERMISSIONS + " MESSAGE SIZE ");

		// Pop the Result of the Operation.
		PAStatus statusObject = PAStatus.pop(message);

		if (statusObject == PAStatus.S_SUCCESS) {
			LOGGER.info(METHOD_RESPONSE_ALL_PERMISSIONS + " permissions fetched successfully");
			List<PAPermissionData> availablePermissions = new ArrayList<>();

			// Pop the Count of Available Menu options ( STRINGS )
			int nCount = message.popInteger();

			LOGGER.info(METHOD_RESPONSE_ALL_PERMISSIONS + "Number of Available Menu Options retreived from the Server : " + nCount);

			for (int idx = 0; idx < nCount; ++idx) {
				PAPermissionData permissionData = new PAPermissionData();
				permissionData.popMe(message);
				availablePermissions.add(permissionData);
			}

			createPolicyWdw.updateWindow(availablePermissions, null);
		} else if (statusObject == PAStatus.S_INTERNAL_ERROR) {
			createPolicyWdw.showMessage("Error occurred while fetching permissions: either policy does not exist or some internal error occurred");
			LOGGER.info(METHOD_RESPONSE_ALL_PERMISSIONS	+ "Failed to Fetch All Available Permissions from Server");
		}

		LOGGER.debug(METHOD_RESPONSE_ALL_PERMISSIONS + " EXIT_FUNCTION");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc#resultAvailable(com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob,
	 *      java.lang.Object)
	 */
	@Override
    public void resultAvailable(USMJob job, USMMessage result) {
		LOGGER.info(" resultAvailable() entry");

		USMBaseMsgType msgType = result.getMessageType();
		if (msgType.equals(PAMessageType.S_PA_RES_POLICY_CREATED)) {
			handleResponseForCreatePolicy(result);
		} else if (
			msgType.equals(PAMessageType.S_PA_RES_ALL_PERMISSION_RECEIVED)) {
			handleResponseForGetAllAvailablePermissions(result);
		} else {
			LOGGER.error("Got a message which could not be handled");
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc#handleNotification(com.ossnms.bicnet.securitymanagement.common.basic.USMMessage)
	 */
	@Override
    public void handleNotification(USMMessage pMsg) {
		//Nothing to handle.
	}

}