/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	PAClientLifeCycleController
 * Author      	vpurohit
 * Substitute	muyeen
 * Created on	12-07-2004
 * ReqID	:	TNMS.DX2.SM.CLIENT.REGSITER_MENU
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.policy;

import com.ossnms.bicnet.securitymanagement.client.basic.USMClientLifeCycleControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.policy.views.administration.PAPolicyAdminCommand;
import com.ossnms.bicnet.securitymanagement.client.policy.views.create.PAPolicyCreateCommand;
import com.ossnms.bicnet.securitymanagement.client.policy.views.modify.PAPolicyModifyCommand;
import org.apache.log4j.Logger;

/**
 * This is the Life Cycle Controller that is created in the Client upon start
 * up. This class is responsible for the initialization and cleanup activities
 * to be performed by the subsystem PA. These activities are performed at the
 * start of the Admin Client process and at the closure of the Admin Client
 * process. This class is responsible for registring the Commands with the
 * UICommandRegister. It has to register 3 Commands - 
 * 1. PAPolicyAdminCommand 
 * 2. PAPolicyCreateCommand 
 * 3. PAPolicyModifyCommand.
 */
public final class PAClientLifeCycleController
	implements USMClientLifeCycleControllerIfc {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(PAClientLifeCycleController.class);

	/**
	 * Data member to hold the singleton instance of the class
	 */
	private static PAClientLifeCycleController instance = new PAClientLifeCycleController();

	/**
	 * Constructor
	 */
	public PAClientLifeCycleController() {
	}

	/**
	 * This method performs common initialising operations for policy
	 * administration feature in the client side.
	 * 
	 * @return boolean Indicates whether it was possible to initialize properly.
	 *         True indicates success.
	 */
	public boolean initialize() {
		LOGGER.info("initialize()Register commands");
		new PAPolicyAdminCommand();
		new PAPolicyCreateCommand();
		new PAPolicyModifyCommand();
		return true;
	}

	/**
	 * Performs all the cleanup operations during the closure
	 * 
	 * @return boolean Indicates whether it was possible to cleanup properly.
	 *         True indicates success.
	 */
	public boolean cleanup() {
		return true;
	}

	/**
	 * This static method returns the only instance of PA life cycle controller.
	 * 
	 * @return USMLifeCycleController The instance of this class.
	 */
	public static PAClientLifeCycleController getInstance() {
		return instance;
	}
}