/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMControllerIfc
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.controller;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;

/**
 * This is the base interface for all the controller's that are implemented
 * within USM.
 */
public interface USMControllerIfc {
	/**
	 * Function to add a Job to the list of job's that are currently queued
	 * with the Client Frame waiting to be executed.
	 * 
	 * @param pJob -
	 *            The Job which has to be added to the List of Jobs.
	 */
	void addJob(USMJob pJob);

	/**
	 * Function which is called by the Job when it is being cancelled in the
	 * view which shows all the jobs.
	 * 
	 * @param pJob -
	 *            The Job which has to be removed from the List of Jobs.
	 */
	void endJob(USMJob pJob);

	/**
	 * Method called by the USMJob when the result is availablef after the call
	 * has been made to the bean object.
	 * 
	 * @param pJob -
	 *            The job which has completed and which has invoked this
	 *            method.
	 * @param result -
	 *            The message which contains the result of the operation.
	 */
	void setResult(USMJob pJob, USMMessage result);

	/**
	 * The abstract function which has to be implemented by the derived
	 * classes. This function will be called by the Base class after posting a
	 * request in the Event dispatch queue, by using the
	 * SwingUtilities.invokeLater
	 * 
	 * @param pJob -
	 *            The Job which has completed
	 * @param result -
	 *            The result of the job's invokation.
	 */
	void resultAvailable(USMJob pJob, USMMessage result);

	/**
	 * Function that will be called when a Job needs to be queued using the
	 * site object.
	 * 
	 * @param pJob -
	 *            The USMJob that should be queued with the site.
	 * @return boolean - Indicates whether it was possible to queue the job or
	 *         not.
	 */
	boolean queueJob(USMJob pJob);

	/**
	 * Function provided to do any initialization that are needed by the
	 * controller.
	 */
	void initialize();

	/**
	 * Function that has been provided to do any cleanup operations that are
	 * needed by this Controller. This is needed in case of the window being
	 * closed and the controller still has some jobs that are to be executed.
	 * In this case, the controller should forcefully stop the jobs during the
	 * cleanup operation.
	 */
	void cleanup();

	/**
	 * Function that will be called when a notification is recieved.
	 * 
	 * @param pMsg -
	 *            The message that is sent by the server
	 */
	void handleNotification(USMMessage pMsg);

	/**
	 * Function that is called by the Notification handler. This function
	 * should make sure that the SwingUtilities.invokeLater() is invoked,
	 * before calling the handleNotification.
	 * 
	 * @param pMsg -
	 *            The message that is sent by the server
	 */
	void notificationReceived(USMMessage pMsg);

	/**
	 * Function that will be called by the Job when a BcbSecurityException
	 * is raised by the Server component.
	 * 
	 * @param pJob
	 * 			The Job where this exception occured.
	 * @param excp
	 * 			The Exception that has been raised by the Server.
	 */
	void handleBcbSecurityException(USMJob pJob, BcbSecurityException excp);
}
