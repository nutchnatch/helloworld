/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Muyeen Munaver	CF000427 - Implementation of the XML import mechanism needed for the migration process
 * 10-Feb-2005	Muyeen 		CF001177 - User migrated have to change the default password next logon acording to FSPEC
 * 08-Aug-2005	Balasubramanya	CF002760 - 9320_MR_0291 Users, User Groups, Policies lose associations after import
 * 08-Aug-2005	Balasubramanya	CF002759 - 9320_MR_0289 Security information discarded for user after deletion and restore
 * 17-Aug-2005	Balasubramanya	CF002854 - user migration does not work
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.importexport;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginImportExportListener;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCIEDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.importexport.IEDomainData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAAuthenticationType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAIEUser;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAIEUserGroup;
import com.ossnms.tnms.securitymanagement.client.settings.SecuritySettingsManager;
import org.apache.log4j.Logger;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is responsible for reading all the XML related data from the
 * file. Its work is only to read.
 */
public class IEXmlReader {

	/**
	 * Data member to hold the singleton instance
	 */
	private static IEXmlReader instance = new IEXmlReader();

	/**
	 * Data member to do the Tracing
	 */
	private static final Logger LOGGER = Logger.getLogger(IEXmlReader.class);

	/**
	 * Function to return the singleton instance.
	 * @return IEXmlReader
	 * 		The singleton instance of the class.
	 */
	public static IEXmlReader getInstance() {
		return instance;
	}

	/**
	 * Function to return all the User Object that are there in the Element.
	 * @param elm The Root Element under which we have to search for the
	 * 		Users Object
	 * @param listener The Listener Object where we trace out
	 * 		messages if some mandatory attribute is missing.
	 * @return List The List of Users Object.
	 */
    public List<UAIEUser> getUsers(Element elm, BiCNetPluginImportExportListener listener) {
        LOGGER.debug("Entering getUsers.");

		IETagNames.throwExceptionIfElementIsNull(elm);
		List<UAIEUser> lstUsers = new ArrayList<>();
		int nMandatoryAttributesMissing = 0;

        // First check if there is a single instance of the "Users" Object in the XML file
        Element userObj = getSingleElementForSection(elm, IETagNames.USER_SECTION);

		if (userObj != null) {
            NodeList lstNdUsers = userObj.getElementsByTagName(IETagNames.USER_USER);
            Element userGrpObj = getSingleElementForSection(elm, IETagNames.USER_GROUP_SECTION);
            for (int idx = 0; idx != lstNdUsers.getLength(); ++idx) {
                Element nd = (Element) lstNdUsers.item(idx);

				String usrId = getValueOfNode(IETagNames.USER_USER_NAME, nd);

				String accountType = getValueOfNode(IETagNames.USER_TYPE, nd);

				if(accountType == null || accountType.isEmpty()) {
					accountType = migrateFromEarlierVesions(usrId);
				}

                List<String> vector = getUserGroupsForUser(userGrpObj, usrId);

                String usrFirstName = getValueOfNode(IETagNames.USER_FIRST_NAME, nd);
                String usrLastName = getValueOfNode(IETagNames.USER_LAST_NAME, nd);
                String usrCommonName = getValueOfNode(IETagNames.USER_COMMON_NAME, nd);
                String usrEMail = getValueOfNode(IETagNames.USER_E_MAIL, nd);
                String usrTelephone = getValueOfNode(IETagNames.USER_TELEPHONE, nd);
                String usrFax = getValueOfNode(IETagNames.USER_FAX, nd);
                String usrEmployeeNumber = getValueOfNode(IETagNames.USER_EMPLOYEE_NUMBER, nd);

                String usrLstLogon = getValueOfNode(IETagNames.USER_LAST_LOGIN, nd);

                String strActivated = nd.getAttribute(IETagNames.USER_ACTIVATED);
                strActivated = (strActivated != null) ? strActivated.trim() : null;

                boolean bActivated = Boolean.parseBoolean(strActivated);

                String usrPassword = getValueOfNode(IETagNames.USER_PASSWORD, nd);
                boolean bMustChngPassword = getBooleanForString(getValueOfNode(IETagNames.USER_CHANGEPASSWD_NEXTLOGON, nd), false);
                boolean bCannotChngPassword = getBooleanForString(getValueOfNode(IETagNames.USER_CANNOTCHANGE_PASSWORD, nd), false);

                String usrUsrClass = getValueOfNode(IETagNames.USER_USER_CLASS, nd);
                boolean passwordExpires = getBooleanForString(getValueOfNode(IETagNames.USER_PASSWORD_EXPIRES, nd), true);
                
                String changeInterval = getValueOfNode(IETagNames.USER_PASSWDCHANGE_INTERVAL, nd);
                int passwordChangeInterval = 0;
                if(changeInterval != null && !"".equals(changeInterval)) {
                    try {
                    passwordChangeInterval = Integer.valueOf(changeInterval);
                    } catch (NumberFormatException exp) {
                        LOGGER.error("Exception while parsing the password expiration interval.\n" + exp.getMessage());
                    }
                }

				boolean inactivityTimeoutEnabled = getBooleanForString(getValueOfNode(IETagNames.USER_INACTIVITY_TIMEOUT_ENABLED, nd), false);
				int inactivityTimeout = SecuritySettingsManager.getInstance().getGeneralSettingsData().getInactivityTimeout();
				
				try {
					inactivityTimeout = Integer.valueOf(getValueOfNode(IETagNames.USER_INACTIVITY_TIMEOUT, nd));
				} catch (NumberFormatException e) {
					LOGGER.debug("No valid number in xml found for inactivity tiemout.\n");
				}
				

				/**
				 * Simultaneous allowed user sessions
				 */
				boolean userSessionRestrictionEnabled = getBooleanForString(getValueOfNode(IETagNames.USER_SESSION_RESTRICTION_ENABLED, nd), true);
				int allowedUserSessions = 1; //Default is one

				try{
					allowedUserSessions = Integer.valueOf(getValueOfNode(IETagNames.USER_ALLOWED_USER_SESSIONS, nd));
				}catch(NumberFormatException e){
					LOGGER.debug("No valid number in xml found for number of allowed user sessions.\n");
				}

				/**
				 * Expiration date
				 */
				boolean expirationDateEnabled = getBooleanForString(getValueOfNode(IETagNames.USER_EXPIRATION_DATE_ENABLED, nd), false);
				long expirationDate = 0;

				try{
					expirationDate = Long.valueOf(getValueOfNode(IETagNames.USER_EXPIRATION_DATE, nd));
				}catch(NumberFormatException e) {
					LOGGER.debug("No valid number in xml found for expiration date.\n");
				}

				
                if ((usrId != null) && (usrId.length() > 0)) {
                    UAIEUser usr = new UAIEUser();
                    usr.setFirstName(usrFirstName);
                    usr.setLastName(usrLastName);
                    usr.setUserId(usrId);
					usr.setAuthenticationType(UAAuthenticationType.valueOf(accountType));
                    usr.setCommonName(usrCommonName);
                    usr.setEmail(usrEMail);
                    usr.setTelephoneNumber(usrTelephone);
                    usr.setFaxNumber(usrFax);
                    usr.setEmployeeNumber(usrEmployeeNumber);
                    usr.setUserCanNotChangePasswd(bCannotChngPassword);
                    usr.setUserMustChangePassword(bMustChngPassword);
                    usr.setAccountActivated(bActivated);
                    usr.setUserClass(usrUsrClass);
                    usr.setLastLogOnTime(usrLstLogon);
                    usr.setPasswordExpires(passwordExpires);
                    usr.setPasswordChangeInterval(passwordChangeInterval);
                    usr.setAssignedUserGroups(vector);
                    usr.setPassword(usrPassword);
                    usr.setEncryptedPassword(usrPassword);

					usr.setInactivityTimeoutEnabled(inactivityTimeoutEnabled);
					usr.setInactivityTimeout(inactivityTimeout);

					usr.setRestrictUserSessions(userSessionRestrictionEnabled);
					usr.setSimultaneousUserSessions(allowedUserSessions);

					usr.setAccountExpires(expirationDateEnabled);
					usr.setExpirationDate(new Date(expirationDate));

                    lstUsers.add(usr);
                } else {
                    // Mandatory Attribute for Domain missing
                    nMandatoryAttributesMissing++;
                }

            }
        }

		if (nMandatoryAttributesMissing > 0) {
            String strMsg = USMStringTable.IDS_IE_SKIPPING_IMPORT_OF.toString() + nMandatoryAttributesMissing
                    + USMStringTable.IDS_IE_SPACE.toString() + IETagNames.USER_USER
                    + USMStringTable.IDS_IE_MANDATORY_ATTRIBS.toString() + IETagNames.USER_USER_NAME
                    + USMStringTable.IDS_IE_MISSING_OR_EMPTY.toString();
			LOGGER.info(strMsg);
			listener.eventPluginImportExportMessage(strMsg);
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting getUsers. Returning : " + lstUsers);
		}

		return lstUsers;
	}

	/**
	 *
	 * @param usrId
	 * @return
     */
	private String migrateFromEarlierVesions(String usrId) {
		String accountType;
		if(usrId != null && usrId.contains("@LDAP")) {
            // if the username contains @LDAP, the account is external and of type LDAP
            accountType = "LDAP";
        } else if(usrId != null && usrId.contains("@") && !usrId.contains("@LDAP")){
            // if the user id is not of type 'LDAP', but contains the '@', it's a SSO account
            accountType = "SSO";
        } else {
            accountType = "LOCAL";
        }
		return accountType;
	}

	private List<String> getUserGroupsForUser(Element userGrpObj, String usrId) {
        List<String> userGroups = new ArrayList<>();
        if (userGrpObj != null) {
            NodeList lst = userGrpObj.getElementsByTagName(IETagNames.USER_GROUP);
            for (int i = 0; i < lst.getLength(); i++) {
                Element usrEle = (Element) lst.item(i);
                String userGroup = getValueOfNode(IETagNames.USER_GROUP_NAME, usrEle);
                List usrLst = getMultipleObjects(usrEle, IETagNames.USER_GROUP_USER);
                for (int length = 0; length < usrLst.size(); length++) {
                    if (usrLst.get(length).toString().equalsIgnoreCase(usrId)) {
                        userGroups.add(userGroup);
                    }
                }
            }
        }
        return userGroups;
    }
	
	/**
	 * Function to calculate and return the boolean equivalent for a string. If the string is null it returns
	 * false.
	 * @param str String which has to be checked.
	 * @return boolean Indicates the result of the string operation.
	 */
	private boolean getBooleanForString(String str, boolean defaultValue) {
	    boolean bResult = defaultValue;
	    if(str != null && !str.trim().isEmpty()) {
	        bResult = Boolean.parseBoolean(str.trim());
	    }
	    return bResult;
	}

	/**
	 * Function to return all the Policies Object that are there in the 
	 * Element.
	 * @param element The Root Element under which we have to search for the
	 * 		Policies Object
	 * @param listener The Listener Object where we trace out
	 * 		messages if some mandatory attribute is missing.
	 * @return List The List of Policies Object.
	 */
	public List<PAPolicyData> getPolicies(
		Element element,
		BiCNetPluginImportExportListener listener) {
		LOGGER.debug("Entering getPolicies.");

		IETagNames.throwExceptionIfElementIsNull(element);
		List<PAPolicyData> lstPolicies = new ArrayList<>();
		int nMandatoryAttribMissing = 0;

		// Get all the "Policy" Object and go through each.
        Element policySectionElm = getSingleElementForSection(element, IETagNames.POLICIES_SECTION);
		if (policySectionElm != null) {
            NodeList lstPolicyXMLElms = policySectionElm.getElementsByTagName(IETagNames.POLICY);
			int nNoOfPolicyElm = lstPolicyXMLElms.getLength();
			for (int nPolIdx = 0; nPolIdx != nNoOfPolicyElm; ++nPolIdx) {
				Element policyNode = (Element) lstPolicyXMLElms.item(nPolIdx);
                String name = getValueOfNode(IETagNames.POLICY_NAME, policyNode);
                String desc = getValueOfNode(IETagNames.POLICY_DESCRIPTION, policyNode);

                List<String> vecPermissions = getMultipleObjects(policyNode, IETagNames.POLICY_PERMISSION);

				if ((name != null) && (name.length() > 0)) {
					List<PAPermissionData> permissionDataList = new ArrayList<>(vecPermissions.size());
					for(String permission : vecPermissions){
						PAPermissionData permissionData = new PAPermissionData();
						permissionData.setName(permission);
						permissionDataList.add(permissionData);
					}

                    PAPolicyData policyData = new PAPolicyData(-1, name, desc, 0, 0);
					policyData.setPermissionDataList(permissionDataList);
					lstPolicies.add(policyData);
				} else {
					// Mandatory Attribute for Domain missing
					nMandatoryAttribMissing++;
				}
			}
		}

		if (nMandatoryAttribMissing > 0) {
            String strMsg = USMStringTable.IDS_IE_SKIPPING_IMPORT_OF.toString() + nMandatoryAttribMissing
                    + USMStringTable.IDS_IE_SPACE.toString() + IETagNames.POLICY
                    + USMStringTable.IDS_IE_MANDATORY_ATTRIBS.toString() + IETagNames.POLICY_NAME
                    + USMStringTable.IDS_IE_MISSING_OR_EMPTY.toString();
			LOGGER.info(strMsg);
			listener.eventPluginImportExportMessage(strMsg);
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting getPolicies. Returning : " + lstPolicies);
		}

		return lstPolicies;
	}

	/**
	 * Function to return all the Domain Object that are there in the 
	 * Element.
	 * @param elm The Root Element under which we have to search for the
	 * 		Domains Object
	 * @param listener The Listener Object where we trace out
	 * 		messages if some mandatory attribute is missing.
	 * @return List The List of Domains Object.
	 */
    public List<IEDomainData> getDomains(Element elm, BiCNetPluginImportExportListener listener) {
		LOGGER.debug("Entering getDomains.");

		IETagNames.throwExceptionIfElementIsNull(elm);
		List<IEDomainData> result = new ArrayList<IEDomainData>();
		
		int mandatoryAttribMissing = 0;

		// First check if there is a single instance of the "Domains" Object in the XML file
        Element domainObj = getSingleElementForSection(elm, IETagNames.DOMAIN_SECTION);
        
		if (domainObj != null) {
			int domainId = -1;
            NodeList lstDoms = domainObj.getElementsByTagName(IETagNames.DOMAIN);
			for (int nDomIdx = 0; nDomIdx != lstDoms.getLength(); ++nDomIdx) {
				Element nd = (Element) lstDoms.item(nDomIdx);
				String name = getValueOfNode(IETagNames.DOMAIN_NAME, nd);
				String desc = getValueOfNode(IETagNames.DOMAIN_DESCRIPTION, nd);
				
				if ((name != null) && (name.length() > 0)) {
					domainId--;
					DCDomainData domain = new DCDomainData(name, domainId, domainId, desc);
					
					List<String> securObjects = getMultipleObjects(nd, IETagNames.SECURABLE_OBJECT);
					
					result.add(new IEDomainData(domain, securObjects));
				} else {
					// Mandatory Attribute for Domain missing
					mandatoryAttribMissing++;
				}
				
			}
		}

		if (mandatoryAttribMissing > 0) {
            String strMsg = USMStringTable.IDS_IE_SKIPPING_IMPORT_OF.toString() + mandatoryAttribMissing
                    + USMStringTable.IDS_IE_SPACE.toString() + IETagNames.DOMAIN
                    + USMStringTable.IDS_IE_MANDATORY_ATTRIBS.toString() + IETagNames.DOMAIN_NAME
                    + USMStringTable.IDS_IE_MISSING_OR_EMPTY.toString();
			LOGGER.info(strMsg);
			listener.eventPluginImportExportMessage(strMsg);
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting getDomains. Returning : " +  result);
		}
		
		return result;
	}

	/**
	 * Function to return all the Mapping Object that are there in the 
	 * Element.
	 * @param element The Root Element under which we have to search for the
	 * 		Mappings Object
	 * @param listener The Listener Object where we trace out
	 * 		messages if some mandatory attribute is missing.
	 * @return List The List of Mappings Object.
	 */
	public List<DCIEDomainMapping> getMappings(
		Element element,
		BiCNetPluginImportExportListener listener) {
		LOGGER.debug("Entering getMappings.");

		IETagNames.throwExceptionIfElementIsNull(element);
		List<DCIEDomainMapping> lstMappings = new ArrayList<DCIEDomainMapping>();
		int nMandatoryAttribMissing = 0;

		// First check if there is a single instance of the "Mappings" Object in the XML file
        Element mappingObj = getSingleElementForSection(element, IETagNames.MAPPING_SECTION);
		if (mappingObj != null) {
            NodeList lstNodesMappings = mappingObj.getElementsByTagName(IETagNames.MAPPING);
			for (int idx = 0; idx != lstNodesMappings.getLength(); ++idx) {
				Element nd = (Element) lstNodesMappings.item(idx);
				String ug = getValueOfNode(IETagNames.MAPPING_USERGROUP, nd);
				String dom = getValueOfNode(IETagNames.MAPPING_DOMAIN_NAME, nd);
				String pol = getValueOfNode(IETagNames.MAPPING_POLICY_NAME, nd);

                boolean mappingValidation = (ug != null && ug.length() > 0);
                mappingValidation &= (dom != null && dom.length() > 0);
                mappingValidation &= (pol != null && pol.length() > 0);

                if (mappingValidation) {
                    DCIEDomainMapping domain = new DCIEDomainMapping(dom, ug, pol);
					lstMappings.add(domain);
				} else {
					// Mandatory Attribute for Domain missing
					nMandatoryAttribMissing++;
				}
			}
		}

		if (nMandatoryAttribMissing > 0) {
			StringBuffer strMsgBuffer = new StringBuffer();
            strMsgBuffer.append(USMStringTable.IDS_IE_SKIPPING_IMPORT_OF.toString());
			strMsgBuffer.append(nMandatoryAttribMissing);
			strMsgBuffer.append(USMStringTable.IDS_IE_SPACE.toString());
			strMsgBuffer.append(IETagNames.MAPPING);
            strMsgBuffer.append(USMStringTable.IDS_IE_MANDATORY_ATTRIBS_MULTIPLE.toString());
			strMsgBuffer.append(IETagNames.MAPPING_USERGROUP);
			strMsgBuffer.append(USMStringTable.IDS_IE_SPACE.toString());
			strMsgBuffer.append(IETagNames.MAPPING_DOMAIN_NAME);
			strMsgBuffer.append(USMStringTable.IDS_IE_SPACE.toString());
			strMsgBuffer.append(IETagNames.MAPPING_POLICY_NAME);
            strMsgBuffer.append(USMStringTable.IDS_IE_MISSING_OR_EMPTY.toString());
			LOGGER.info(strMsgBuffer.toString());
			listener.eventPluginImportExportMessage(strMsgBuffer.toString());
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting getMappings. Returning : " + lstMappings);
		}

		return lstMappings;
	}

	/**
	 * Function to return all the User Group Object that are there in the 
	 * Element.
	 * @param elm The Root Element under which we have to search for the
	 * 		UserGroups Object
	 * @param listener The Listener Object where we trace out
	 * 		messages if some mandatory attribute is missing.
	 * @return List The List of UserGroups Object.
	 */
    public List<UAIEUserGroup> getUserGroups(Element elm, BiCNetPluginImportExportListener listener) {
		LOGGER.debug("Entering getUserGroups.");

		IETagNames.throwExceptionIfElementIsNull(elm);
		List<UAIEUserGroup> lstUGs = new ArrayList<UAIEUserGroup>();
		int nMandatoryAttribMissing = 0;

		// First check if there is a single instance of the "UserGroups" Object in the
		// XML file
		Element ugSectionElm =
			getSingleElementForSection(elm, IETagNames.USER_GROUP_SECTION);
		if (ugSectionElm != null) {

            NodeList lstUgXMLElms = ugSectionElm.getElementsByTagName(IETagNames.USER_GROUP);
			int nNoOfUgElm = lstUgXMLElms.getLength();
			for (int nUgIdx = 0; nUgIdx != nNoOfUgElm; ++nUgIdx) {
				Element ugNode = (Element) lstUgXMLElms.item(nUgIdx);
                String name = getValueOfNode(IETagNames.USER_GROUP_NAME, ugNode);
                String desc = getValueOfNode(IETagNames.USER_GROUP_DESCRIPTION, ugNode);
                List vecUsers = getMultipleObjects(ugNode, IETagNames.USER_GROUP_USER);

				if ((name != null) && (name.length() > 0)) {
					UAIEUserGroup ug = new UAIEUserGroup(name, desc, vecUsers);
					lstUGs.add(ug);
				} else {
					// Mandatory Attribute for Domain missing
					nMandatoryAttribMissing++;
				}
			}
		}

		if (nMandatoryAttribMissing > 0) {
            String strMsg = USMStringTable.IDS_IE_SKIPPING_IMPORT_OF.toString() + nMandatoryAttribMissing
                    + USMStringTable.IDS_IE_SPACE.toString() + IETagNames.USER_GROUP
                    + USMStringTable.IDS_IE_MANDATORY_ATTRIBS.toString() + IETagNames.USER_GROUP_NAME
                    + USMStringTable.IDS_IE_MISSING_OR_EMPTY.toString();
			LOGGER.info(strMsg);
			listener.eventPluginImportExportMessage(strMsg);
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting getUserGroups. Returning : " + lstUGs);
		}

		return lstUGs;
	}

	/**
	 * Helper function to check for the number of section that are available
	 * for the certain type.
	 * @param rootElm The Root Element under which we have to search
	 * @param strSecName The Name that should be used to search for the section
	 * @return Element The single instance of the Object which corresponds to the
	 * 	section. Else it will be null. For both zero and multiple instances. 
	 */
    public Element getSingleElementForSection(Element rootElm, String strSecName) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering getSingleElementForSection. Section : " + strSecName);
		}

		Element returnElm = null;
        NodeList ugSectionXMLElms = rootElm.getElementsByTagName(strSecName);
		int nNoOfUGSec = ugSectionXMLElms.getLength();
		if (nNoOfUGSec == 0) {
            LOGGER.info("There are no " + strSecName + " Objects to be Imported");
		} else if (nNoOfUGSec == 1) {
			// Get all the "Policy" Object and go through each.
			returnElm = (Element) ugSectionXMLElms.item(0);
		} else {
            LOGGER.error("Trying to import multiple objects of type : " + strSecName);
		}

		if (LOGGER.isDebugEnabled()) {
            String strTag = (null != returnElm) ? returnElm.getTagName() : "null";
            LOGGER.debug("Exiting getSingleElementForSection. Returning : " + strTag);
		}
		return returnElm;
	}

	/**
	 * Helper function to read the value of a Node.
	 * @param searchString The Name of the Node which has to be searched
	 * @param element The Element under which we have to search for the Node
	 * @return java.lang.String The String value of the Node that is passed.
	 */
	private String getValueOfNode(
		String searchString,
		Element element) {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering returnValueOfNode. Search String : " + searchString + " Element : " + element.getTagName());
		}

		String strValue = "";
        NodeList listOfFndNode = element.getElementsByTagName(searchString);

		//There should be atleast one child element
		if (listOfFndNode.getLength() > 0) {
			Element fndElemNode = (Element) listOfFndNode.item(0);

			if (fndElemNode.hasChildNodes()) {
				NodeList listofChild = fndElemNode.getChildNodes();
				for (int nChildIndex = 0;
					nChildIndex != listofChild.getLength();
					++nChildIndex) {
					Node childNode = listofChild.item(nChildIndex);
					//Get the text value under the nodes (either <Name>  or <Description>)
					if (childNode.getNodeType() == Node.TEXT_NODE) {
						strValue = childNode.getNodeValue();
					}
				} // End of the for Loop
			} // End of if for checking if there are child nodes.
		} // End of if for checking if there is at least one child node.

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting returnValueOfNode. Returning " + strValue);
		}
		return strValue;
	}

	/**
	 * Function to Get a List of objects. Needed in case of 
	 * 1. Menu entries for Policy
	 * 2. Users for User Group 
	 * @param node - The Node under which we have to search for the Objects
	 * @param tagName - The Tag name that should be used.
	 * @return Vector - Vector of objects found.
	 */
	private List<String> getMultipleObjects(Element node, String tagName) {
		if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering getMultipleObjects. Element : " + node + " Tag : " + tagName);
		}

		NodeList listOfNodes = node.getElementsByTagName(tagName);
		int nNoOfNodes = listOfNodes.getLength();
		List<String> vecObjs = new ArrayList<>(nNoOfNodes);
		for (int nOutIdx = 0; nOutIdx != nNoOfNodes; ++nOutIdx) {
			Element menuNode = (Element) listOfNodes.item(nOutIdx);
			NodeList lstChildNodes = menuNode.getChildNodes();
			int nChildNodes = lstChildNodes.getLength();
			for (int nInnerIdx = 0; nInnerIdx != nChildNodes; ++nInnerIdx) {
				Node nd = lstChildNodes.item(nInnerIdx);
				if (Node.TEXT_NODE == nd.getNodeType()) {
					String cmd = nd.getNodeValue();
					vecObjs.add(cmd);
				}
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting getMultipleObjects. Returning : " + vecObjs);
		}
		return vecObjs;
	}
}