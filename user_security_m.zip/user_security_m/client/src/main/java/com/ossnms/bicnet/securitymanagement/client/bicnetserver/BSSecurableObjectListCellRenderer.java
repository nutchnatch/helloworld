/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	BSSecurableObjectListCellRenderer
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_OBJECTS
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_ACL 
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_SECURITY
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.INSERT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Mar-2005	Muyeen Munaver	CF000137 - #678: Add a method getType or so to the ISecurableObject
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.bicnetserver;

import com.coriant.widgets.util.WidgetResources;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;

import javax.swing.*;
import java.awt.*;

/**
 * This is a Renderer class for the List which shows the Configured CFs.
 */
public class BSSecurableObjectListCellRenderer extends JLabel implements ListCellRenderer<BSSecurableObject> {

	/**
	 * @see javax.swing.ListCellRenderer#getListCellRendererComponent(javax.swing.JList, java.lang.Object, int, boolean, boolean)
	 */
	@Override
	public Component getListCellRendererComponent(
		JList list,
		BSSecurableObject value,
		int index,
		boolean isSelected,
		boolean cellHasFocus) {
		// Since this method would be called many times, the tracing has not been added
		setText(value.toString());

		java.awt.Color clrForeGround = isSelected ? list.getSelectionForeground() : list.getForeground();
        java.awt.Color clrBackGrnd = isSelected ? list.getSelectionBackground() : list.getBackground();

        if (value.belongOnlyToGlobalDomain()) {
            clrForeGround = java.awt.Color.BLUE;
        }

		setBackground(clrBackGrnd);
		setForeground(clrForeGround);

		setEnabled(list.isEnabled());
		setFont(list.getFont());
		setOpaque(true);

		Icon img = WidgetResources.getImageIcon(value.getIcon().getId());
		setIcon(img);

		return this;
	}
}
