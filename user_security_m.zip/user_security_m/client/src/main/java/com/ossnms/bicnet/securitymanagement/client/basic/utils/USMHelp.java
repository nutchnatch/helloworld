/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMHelp
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 20-02-2005	Muyeen Munaver  CF001473 - Map Id errors in Online help
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.utils;

import java.util.HashMap;
import java.util.Map;

/**
 * This class defines all the Help IDs for the CF USM.
 */
public final class USMHelp {

    /**
     * Data member to hold the Random number for CF USM based on which the Help
     * IDs will be generated.
     */
    private static final int PREFIX = 25259 << 16;

    /**
     * Help ID for the Login Window
     */
    public static final int HID_LOGIN = PREFIX + 1;

    /**
     * Help ID for the Change Password Window
     */
    public static final int HID_CHANGE_PASSWORD = PREFIX + 2;

    /**
     * Help ID for the Security Settings Window
     */
    public static final int HID_SECURITY_SETTINGS = PREFIX + 3;

    /**
     * Help ID for the Advisory Message Window
     */
    public static final int HID_ADVISORY_MESSAGE = PREFIX + 4;

    /**
     * Help ID for the TMN Application Server Window
     */
    public static final int HID_TMN_APPSERVER = PREFIX + 5;

    /**
     * Help ID for the TMN Application Server Properties Window
     */
    public static final int HID_TMN_APPSERVER_PROPERTIES = PREFIX + 6;

    /**
     * Help ID for the Domain Configuration Window
     */
    public static final int HID_DOMAIN_CONFIGURATION = PREFIX + 7;

    /**
     * Help ID for the Create Domain Window
     */
    public static final int HID_CREATE_DOMAIN = PREFIX + 8;

    /**
     * Help ID for the Modify Domain Window
     */
    public static final int HID_MODIFY_DOMAIN = PREFIX + 8;

    /**
     * Help ID for the Assign Securable Object(s) to Domain(s) Window
     */
    public static final int HID_ASSIGN_SECURABLE_OBJECTS = PREFIX + 10;

    /**
     * Help ID for the Policy Administration Window
     */
    public static final int HID_POLICY_ADMINISTRATION = PREFIX + 11;

    /**
     * Help ID for the Create Policy Window
     */
    public static final int HID_CREATE_POLICY = PREFIX + 12;

    /**
     * Help ID for the Modify Policy Window
     */
    public static final int HID_MODIFY_POLICY = PREFIX + 12;

    /**
     * Help ID for the Access Rights Window
     */
    public static final int HID_ACCESS_RIGHTS = PREFIX + 14;

    /**
     * Help ID for the Assign Mappings Window
     */
    public static final int HID_ASSIGN_MAPPINGS = PREFIX + 15;

    /**
     * Help ID for the User Administration Window
     */
    public static final int HID_USER_ADMINISTRATION = PREFIX + 16;

    /**
     * Help ID for the Create User Window
     */
    public static final int HID_CREATE_USER = PREFIX + 17;

    /**
     * Help ID for the Modify User Window
     */
    public static final int HID_MODIFY_USER = PREFIX + 18;

    /**
     * Help ID for the Assign User to User Group Window
     */
    public static final int HID_ASSIGN_USER_TO_USERGROUP = PREFIX + 19;

    /**
     * Help ID for the User Group Administration Window
     */
    public static final int HID_USERGROUP_ADMINISTRATION = PREFIX + 20;

    /**
     * Help ID for the Create UserGroup Window
     */
    public static final int HID_CREATE_USERGROUP = PREFIX + 21;

    /**
     * Help ID for the Modify UserGroup Window
     */
    public static final int HID_MODIFY_USERGROUP = PREFIX + 22;

    /**
     * Help ID for the Modify UserGroup Window
     */
    public static final int HID_SSO_CONFIG = PREFIX + 23;

    /**
     * Data member added to test whether the windows are all properly giving the
     * Help ID.
     */
    private static Map<Integer, String> mMap = new HashMap<>();

    static {
        mMap.put(HID_LOGIN, String.valueOf("HID_LOGIN"));
        mMap.put(HID_CHANGE_PASSWORD, String.valueOf("HID_CHANGE_PASSWORD"));
        mMap.put(HID_SECURITY_SETTINGS, String.valueOf("HID_SECURITY_SETTINGS"));
        mMap.put(HID_ADVISORY_MESSAGE, String.valueOf("HID_ADVISORY_MESSAGE"));
        mMap.put(HID_TMN_APPSERVER, String.valueOf("HID_TMN_APPSERVER"));
        mMap.put(HID_TMN_APPSERVER_PROPERTIES, String.valueOf("HID_TMN_APPSERVER_PROPERTIES"));
        mMap.put(HID_DOMAIN_CONFIGURATION, String.valueOf("HID_DOMAIN_CONFIGURATION"));
        mMap.put(HID_CREATE_DOMAIN, String.valueOf("HID_CREATE_DOMAIN"));
        mMap.put(HID_MODIFY_DOMAIN, String.valueOf("HID_MODIFY_DOMAIN"));
        mMap.put(HID_ASSIGN_SECURABLE_OBJECTS, String.valueOf("HID_ASSIGN_SECURABLE_OBJECTS"));
        mMap.put(HID_POLICY_ADMINISTRATION, String.valueOf("HID_POLICY_ADMINISTRATION"));
        mMap.put(HID_CREATE_POLICY, String.valueOf("HID_CREATE_POLICY"));
        mMap.put(HID_MODIFY_POLICY, String.valueOf("HID_MODIFY_POLICY"));
        mMap.put(HID_ACCESS_RIGHTS, String.valueOf("HID_ACCESS_RIGHTS"));
        mMap.put(HID_ASSIGN_MAPPINGS, String.valueOf("HID_ASSIGN_MAPPINGS"));
        mMap.put(HID_USER_ADMINISTRATION, String.valueOf("HID_USER_ADMINISTRATION"));
        mMap.put(HID_CREATE_USER, String.valueOf("HID_CREATE_USER"));
        mMap.put(HID_MODIFY_USER, String.valueOf("HID_MODIFY_USER"));
        mMap.put(HID_ASSIGN_USER_TO_USERGROUP, String.valueOf("HID_ASSIGN_USER_TO_USERGROUP"));
        mMap.put(HID_USERGROUP_ADMINISTRATION, String.valueOf("HID_USERGROUP_ADMINISTRATION"));
        mMap.put(HID_CREATE_USERGROUP, String.valueOf("HID_CREATE_USERGROUP"));
        mMap.put(HID_MODIFY_USERGROUP, String.valueOf("HID_MODIFY_USERGROUP"));
        mMap.put(HID_SSO_CONFIG, String.valueOf("HID_SSO_CONFIG"));
    }

    /**
     * Creates an instance of the class. Just needed for generating the help
     * map.
     */
    private USMHelp() {
    }

    /**
     * Helper function added for the Unit Test to check the value of the Prefix.
     * 
     * @return the value of the prefix
     */
    static int getPrefixValue() {
        return PREFIX;
    }

    /**
     * Helper function which returns the String equivalent for the ID that is
     * passed
     * 
     * @param p_ID
     *            The ID for which we wish to get the String associated.
     * 
     * @return String The String which is the representation for the ID passed.
     */
    public static String getStringForID(int p_ID) {
        return mMap.get(p_ID);
    }
}
