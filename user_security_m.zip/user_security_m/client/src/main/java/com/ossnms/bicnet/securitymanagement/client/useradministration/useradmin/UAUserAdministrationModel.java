package com.ossnms.bicnet.securitymanagement.client.useradministration.useradmin;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientProperties;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import com.ossnms.tools.jfx.ETimeDisplay;
import com.ossnms.tools.jfx.JfxDate;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.table.JfxColumnSettings;
import org.apache.log4j.Logger;

import javax.swing.table.AbstractTableModel;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * This class represents the Table Model for the UAUserAdministrationView window
 */
class UAUserAdministrationModel extends AbstractTableModel implements JfxColumnSettings {
    private static final long serialVersionUID = 87146942912609319L;

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(UAUserAdministrationModel.class);

    private static final int COLUMN_USER = -1;
    private static final int COLUMN_ACCOUNT_ACTIVATED = 0;
    private static final int COLUMN_COMMON_NAME = 1;
    private static final int COLUMN_USER_ID = 2;
    private static final int COLUMN_ACCOUNT_TYPE = 3;
    private static final int COLUMN_LAST_LOGON_TIME = 4;
    private static final int COLUMN_CURRENT_LOGIN_STATUS = 5;
    private static final int COLUMN_HOST_NAME = 6;
    private static final int COLUMN_BAD_PASSWORD_COUNT = 7;

    /**
     * The title of the columns
     */
    private String columns[] = {
            JfxStringTable.getString(USMStringTable.IDS_UA_ACCOUNT_STATE),
            JfxStringTable.getString(USMStringTable.IDS_UA_NAME),
            JfxStringTable.getString(USMStringTable.IDS_UA_USERID),
            JfxStringTable.getString(USMStringTable.IDS_UA_ACCOUNT_TYPE),
            JfxStringTable.getString(USMStringTable.IDS_UA_LAST_LOGIN_TIME),
            JfxStringTable.getString(USMStringTable.IDS_UA_LOGIN_STATUS),
            JfxStringTable.getString(USMStringTable.IDS_UA_HOST_NAME),
            JfxStringTable.getString(USMStringTable.IDS_UA_FAILED_LOGIN_COUNT)
    };

    private transient ETimeDisplay eTimeDisplay = null;

    /**
     * Holds the data for this window
     */
    private List<UAUser> data = new ArrayList<>();

    /**
     * Constructor
     */
    UAUserAdministrationModel() {
        super();
        LOGGER.debug("UAUserModel - Enter & Exit");
    }

    /**
     * This method is used to find if a particular cell is editable or not.
     *
     * @param row The row index of the cell.
     * @param col The column index of the cell.
     * @return Returns true if the cell is editable.
     */
    @Override
    public boolean isCellEditable(int row, int col) {
        return false;
    }

    /**
     * Get the column header name to be displayed.
     *
     * @param column The column index of the cell.
     */
    @Override
    public String getColumnName(int column) {
        return columns[column];
    }

    /**
     * Return the number of columns in the table
     *
     * @see javax.swing.table.TableModel#getColumnCount()
     */
    @Override
    public int getColumnCount() {
        return columns.length;
    }

    /**
     * Return the number of columns in the table
     *
     * @see javax.swing.table.TableModel#getRowCount()
     */
    @Override
    public int getRowCount() {
        return data.size();
    }

    /**
     * Retrieve the text at the given row, column from the model
     *
     * @see javax.swing.table.TableModel#getValueAt(int, int)
     */
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        UAUser objData = data.get(rowIndex);
        Object returnValue = getUserValue(columnIndex, objData);
        return returnValue;
    }

    /**
     *
     * @param columnIndex
     * @param objData
     * @return
     */
    private Object getUserValue(int columnIndex, UAUser objData) {
        switch (columnIndex) {
            case COLUMN_USER:
                return objData;
            case COLUMN_ACCOUNT_ACTIVATED:
                return getAccountActivatedValue(objData);
            case COLUMN_COMMON_NAME:
                return objData.getCommonName();
            case COLUMN_USER_ID:
                return objData.getUserId();
            case COLUMN_ACCOUNT_TYPE:
                return objData.getAuthenticationType().name();
            case COLUMN_LAST_LOGON_TIME:
                return getLastLogonTimeValue(objData);
            case COLUMN_CURRENT_LOGIN_STATUS:
                return objData.getCurrentLoginStatus() ? USMStringTable.IDS_UA_USER_STATE_LOGGED_IN.toString() : USMStringTable.IDS_UA_USER_STATE_LOGGED_OUT.toString();
            case COLUMN_HOST_NAME:
                return objData.getHostName();
            case COLUMN_BAD_PASSWORD_COUNT:
                return String.valueOf(objData.getBadPasswordCount());
            default:
                LOGGER.debug("We reached a point we should never have got to using value columnIndex=" + columnIndex);
                return null;
        }
    }

    /**
     *
     * @param objData
     * @return
     */
    private JfxDate getLastLogonTimeValue(UAUser objData) {
        JfxDate returnValue = null;
        DateFormat dateFormatter = USMCommonHelper.getUSMDateFormatter();
        String strFormattedDate = objData.getLastLogOnTime();

        if ((strFormattedDate != null) && (strFormattedDate.length() > 0)) {
            // Convert to Date
            Date creationTime = null;
            try {
                dateFormatter.setLenient(true);
                creationTime = dateFormatter.parse(strFormattedDate);
            } catch (ParseException exception) {
                LOGGER.error("Parse Exception at position" + exception.getErrorOffset() + ", Exception : " + exception);
            }

            if (creationTime != null) {
                returnValue = new JfxDate(creationTime.getTime());
            }
        }
        return returnValue;
    }

    /**
     * Returns an object which represents the value to include in the Account Activated column of any given row
     * @param objData UAUser instance
     * @return Object
     */
    private Object getAccountActivatedValue(UAUser objData) {
        Object returnValue;
        if (objData.isAccountActivated()) {
            if(objData.isAccountExpires() && objData.getExpirationDate().compareTo(getCurrentDate()) < 0) {
                returnValue = ResourcesIconFactory.ICON_STATUS_ACCOUNT_EXPIRED_16;
            } else if (objData.isAccountLocked()) {
                returnValue = ResourcesIconFactory.ICON_STATUS_LOCK_16;
            } else {
                returnValue = ResourcesIconFactory.ICON_TOOL_OK_16;
            }
        } else {
            returnValue = ResourcesIconFactory.ICON_STATUS_DEACTIVATED_16;
        }
        return returnValue;
    }

    /**
     * Force a repaint of the complete table, after resetting the data
     *
     * @param lstUsers The new list of users
     */
    public void updateData(List<UAUser> lstUsers) {
        LOGGER.debug("updateData - Enter, Users:" + lstUsers);

        data = lstUsers;
        fireTableDataChanged();

        LOGGER.debug("updateData - Exit");
    }

    /**
     * Helper method to handle the Users Activated notification
     *
     * @param lstActivatedUsers The list of activated users
     */
    void handleActivatedUsers(List<String> lstActivatedUsers) {
        LOGGER.debug("handleActivatedUsers - Enter, Users:" + lstActivatedUsers);

        // For each activated user
        for (String lstActivatedUser : lstActivatedUsers) {
            // Locate corresponding user in model
            Iterator iterUsersInModel = data.iterator();
            int nUserPosition = 0;
            while (iterUsersInModel.hasNext()) {
                UAUser objUserIdInModel = (UAUser) iterUsersInModel.next();
                String strUserIdInModel = objUserIdInModel.getUserId();
                if (0 == lstActivatedUser.compareToIgnoreCase(strUserIdInModel)) {
                    objUserIdInModel.setAccountActivated(true);
                    fireTableRowsUpdated(nUserPosition, nUserPosition);
                    break;
                }
                ++nUserPosition;
            }
        }
        LOGGER.debug("handleActivatedUsers - Exit");
    }

    /**
     * Helper method to handle the Users Deactivated notification
     *
     * @param lstDeactivatedUsers The list of deactivated users
     */
    void handleDeactivatedUsers(List<String> lstDeactivatedUsers) {
        LOGGER.debug("handleDeactivatedUsers - Enter, Users:" + lstDeactivatedUsers);

        // For each activated user
        for (String lstDeactivatedUser : lstDeactivatedUsers) {
            // Locate corresponding user in model
            Iterator iterUsersInModel = data.iterator();
            int nUserPosition = 0;
            while (iterUsersInModel.hasNext()) {
                UAUser objUserIdInModel = (UAUser) iterUsersInModel.next();
                String strUserIdInModel = objUserIdInModel.getUserId();
                if (0 == lstDeactivatedUser.compareToIgnoreCase(strUserIdInModel)) {
                    objUserIdInModel.setAccountActivated(false);
                    fireTableRowsUpdated(nUserPosition, nUserPosition);
                    break;
                }
                ++nUserPosition;
            }
        }
        LOGGER.debug("handleDeactivatedUsers - Enter");
    }

    /**
     * Helper method to handle the Users Deleted notification
     *
     * @param lstDeletedUsers The list of deleted users
     */
    void handleDeletedUsers(List<String> lstDeletedUsers) {
        LOGGER.debug("handleDeletedUsers - Enter, Users:" + lstDeletedUsers);

        // For each activated user
        for (String lstDeletedUser : lstDeletedUsers) {

            // Locate corresponding user in model
            Iterator iterUsersInModel = data.iterator();
            int position = 0;
            while (iterUsersInModel.hasNext()) {
                UAUser objUserIdInModel = (UAUser) iterUsersInModel.next();
                String strUserIdInModel = objUserIdInModel.getUserId();
                if (0 == lstDeletedUser.compareToIgnoreCase(strUserIdInModel)) {
                    iterUsersInModel.remove();
                    fireTableRowsDeleted(position, position);
                    break;
                }
                ++position;
            }
        }

        LOGGER.debug("handleDeletedUsers - Exit");
    }

    /**
     * Helper method to handle the Users Created notification
     *
     * @param objUser The newly created user
     */
    void handleCreatedUsers(UAUser objUser) {
        LOGGER.debug("handleCreatedUsers - Enter, User:" + objUser);

        int nUserCount = data.size();
        data.add(objUser);
        fireTableRowsInserted(nUserCount, nUserCount);

        LOGGER.debug("handleCreatedUsers - Exit");
    }

    /**
     * Helper method to handle the Users Logged in notification
     *
     * @param objSessionContext The session context of the logged-in user
     */
    void handleUserLoggedIn(IEnhancedSessionContext objSessionContext, String strLastLogonTime) {
        LOGGER.debug("handleUserLoggedIn - Enter, User:" + objSessionContext.getUserName());

        String strUserIdCreated = objSessionContext.getUserName();

        // Locate corresponding user in model
        Iterator iterUsersInModel = data.iterator();
        int nUserPosition = 0;
        while (iterUsersInModel.hasNext()) {
            UAUser objUserIdInModel = (UAUser) iterUsersInModel.next();
            String strUserIdInModel = objUserIdInModel.getUserId();

            if (strUserIdCreated.compareToIgnoreCase(strUserIdInModel) == 0) {
                String strAllHostNames = objUserIdInModel.getHostName();
                boolean bAllHostNamesEmpty = (strAllHostNames == null) || (strAllHostNames.length() == 0);

                // CF000996 - In the "Computer Name" column appears "null"
                String strNewHostName = objSessionContext.getClientMachineName();
                boolean bNewHostNameEmpty = (strNewHostName == null) || (strNewHostName.length() == 0);

                if (bNewHostNameEmpty) {
                    LOGGER.error("Possible Error: Null / Empty Host name in session context " + objSessionContext);
                } else {
                    String strNewHostNames;

                    if (bAllHostNamesEmpty) { // Just overwrite
                        strNewHostNames = strNewHostName;

                    } else { // Append
                        strNewHostNames = strAllHostNames + ", " + strNewHostName;
                    }

                    objUserIdInModel.setHostName(strNewHostNames);

                    objUserIdInModel.setCurrentLoginStatus(true);
                    // Since User logged in, password count to be reset to 0.
                    objUserIdInModel.setBadPasswordCount(0);
                    objUserIdInModel.setLastLogOnTime(strLastLogonTime);
                    fireTableRowsUpdated(nUserPosition, nUserPosition);
                    break;
                }
            }
            ++nUserPosition;
        }
        LOGGER.debug("handleUserLoggedIn - Exit");
    }

    /**
     * Helper method to handle the Users Logged out notification
     *
     * @param objSessionContext The session context of the logged-out user
     */
    void handleUserLoggedOut(IEnhancedSessionContext objSessionContext) {
        LOGGER.debug("handleUserLoggedOut - Enter, User:" + objSessionContext.getUserName());

        String strUserIdCreated = objSessionContext.getUserName();
        String strHostNameOfUser = objSessionContext.getClientMachineName();

        // Locate corresponding user in model
        Iterator iterUsersInModel = data.iterator();
        int nUserPosition = 0;
        while (iterUsersInModel.hasNext()) {
            UAUser objUserIdInModel = (UAUser) iterUsersInModel.next();
            String strUserIdInModel = objUserIdInModel.getUserId();

            if (strUserIdCreated.compareToIgnoreCase(strUserIdInModel) == 0) {
                String strHostNames = objUserIdInModel.getHostName();

                // Break the comma separated host names
                String[] arrHostNames = strHostNames.split(", ");
                boolean bFound = false;
                for (int i = 0; i < arrHostNames.length; ++i) {
                    if (arrHostNames[i].equals(strHostNameOfUser)) {
                        arrHostNames[i] = arrHostNames[arrHostNames.length - 1];
                        bFound = true;
                        break;
                    }
                }

                StringBuilder hostNames = new StringBuilder();
                // Assemble them back again
                int nCount = arrHostNames.length - 1;
                if (bFound) {
                    for (int i = 0; i < nCount; ++i) {
                        if (i != 0) {
                            hostNames.append(", ").append(arrHostNames[i]);
                        } else {
                            hostNames.append(arrHostNames[0]);
                        }
                    }
                }
                objUserIdInModel.setHostName(hostNames.toString());

                if (nCount > 0) {
                    objUserIdInModel.setCurrentLoginStatus(true);
                } else {
                    objUserIdInModel.setCurrentLoginStatus(false);
                }

                fireTableRowsUpdated(nUserPosition, nUserPosition);
                break;
            }
            ++nUserPosition;
        }

        LOGGER.debug("handleUserLoggedOut - Exit");
    }

    /**
     * Helper method to handle the Users Login Failure notification
     *
     * @param strUserId        The user-id of the user
     * @param badPasswordCount The number of consecutive login failures since the last successful login
     * @param accountLocked    The Lockout state of the account
     */
    void handleUserLoginFailure(String strUserId, int badPasswordCount, boolean accountLocked) {
        LOGGER.debug("handleUserLoggedFailure - Enter, User:" + strUserId);

        // Locate corresponding user in model
        Iterator iterUsersInModel = data.iterator();
        int nUserPosition = 0;
        while (iterUsersInModel.hasNext()) {
            UAUser objUserIdInModel = (UAUser) iterUsersInModel.next();
            String strUserIdInModel = objUserIdInModel.getUserId();

            if (0 == strUserId.compareToIgnoreCase(strUserIdInModel)) {
                objUserIdInModel.setBadPasswordCount(badPasswordCount);
                objUserIdInModel.setAccountLocked(accountLocked);
                fireTableRowsUpdated(nUserPosition, nUserPosition);
                break;
            }
            ++nUserPosition;
        }

        LOGGER.debug("handleUserLoggedIn - Exit");
    }

    /**
     * Helper method to handle the Users Unlocked notification
     *
     * @param lstUnlockedUsers The list of the unlocked users
     */
    void handleUnlockedUsers(List<String> lstUnlockedUsers) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleUnlockedUsers - Enter, Users:" + lstUnlockedUsers);
        }

        // For each activated user
        for (String strUserId : lstUnlockedUsers) {
            // Locate corresponding user in model
            Iterator iterUsersInModel = data.iterator();
            int nUserPosition = 0;
            while (iterUsersInModel.hasNext()) {
                UAUser objUserIdInModel = (UAUser) iterUsersInModel.next();
                String strUserIdInModel = objUserIdInModel.getUserId();

                if (0 == strUserId.compareToIgnoreCase(strUserIdInModel)) {
                    objUserIdInModel.setAccountLocked(false);
                    objUserIdInModel.setBadPasswordCount(0);
                    fireTableRowsUpdated(nUserPosition, nUserPosition);
                    break;
                }
                ++nUserPosition;
            }
        }

        LOGGER.debug("handleUnlockedUsers - Exit");
    }

    /**
     * Helper method to handle the User modified notification
     *
     * @param objUser The modified user object
     */
    void handleModifiedUsers(UAUser objUser) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleModifiedUsers - Enter, User:" + objUser);
        }

        String strUserId = objUser.getUserId();

        // Locate corresponding user in model
        Iterator iterUsersInModel = data.iterator();
        int nUserPosition = 0;
        while (iterUsersInModel.hasNext()) {
            UAUser objUserIdInModel = (UAUser) iterUsersInModel.next();
            String strUserIdInModel = objUserIdInModel.getUserId();
            boolean currentStatus = objUserIdInModel.getCurrentLoginStatus();
            String lastLogin = objUserIdInModel.getLastLogOnTime();
            String loginHost = objUserIdInModel.getHostName();
            if (0 == strUserId.compareToIgnoreCase(strUserIdInModel)) {
                objUser.setCurrentLoginStatus(currentStatus);
                objUser.setLastLogOnTime(lastLogin);
                objUser.setHostName(loginHost);
                data.set(nUserPosition, objUser);
                // Replace whole object
                fireTableRowsUpdated(nUserPosition, nUserPosition);
                break;
            }
            ++nUserPosition;
        }
        LOGGER.debug("handleModifiedUsers - Exit");
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.tools.jfx.table.JfxColumnSettings#getPreferredColumnWidth(int)
     */
    @Override
    public int getPreferredColumnWidth(int nColumn) {
        return 0;
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.tools.jfx.table.JfxColumnSettings#isColumnRemovable(int)
     */
    @Override
    public boolean isColumnRemovable(int nColumn) {
        return !(nColumn == 0 || nColumn == 1);
    }


    /**
     * Sets the correct Time Display
     *
     * @param timeDisplayStr string with the time display format
     */
    void setETimeDisplay(String timeDisplayStr) {
        if (timeDisplayStr.compareTo(BiCNetPluginClientProperties.TIME_DISPLAY_LOCAL) == 0) {
            eTimeDisplay = ETimeDisplay.fromInteger(ETimeDisplay.i_LOCALTIME);
        } else if (timeDisplayStr.compareTo(BiCNetPluginClientProperties.TIME_DISPLAY_GMT) == 0) {
            eTimeDisplay = ETimeDisplay.fromInteger(ETimeDisplay.i_GMT);
        } else { // by default, CST
            eTimeDisplay = ETimeDisplay.fromInteger(ETimeDisplay.i_CST);
        }
    }


    /**
     *
     * @return Date instance, current date
     */
    private Date getCurrentDate() {
        Date todayWithZeroTime;
        try {
            DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
            Date today = new Date();
            todayWithZeroTime = formatter.parse(formatter.format(today));
        } catch (ParseException e) {
            LOGGER.error("Error getting the current date with zero time.", e);
            todayWithZeroTime = new Date();
        }
        return todayWithZeroTime;
    }
}