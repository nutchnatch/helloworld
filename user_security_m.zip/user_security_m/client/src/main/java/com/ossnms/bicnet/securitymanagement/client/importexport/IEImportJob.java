/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	IEImportJob
 * Author      	Asifulla Khan
 * Substitute	Muyeen Munaver
 * Created on	07-12-2004
 *
 * --------------------------------------------------------
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : 	TNMS.DX2.SM.MIGRATION
 * 			TNMS.DX2.SM.EXPORT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.importexport;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.tools.jfx.JfxStringTable;
import org.apache.log4j.Logger;

import java.util.List;

/**
 * Job which is to be used for the importing of data.
 */
public class IEImportJob extends USMJob {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(IEImportJob.class);

	/**
	 * Data that should be imported.
	 */
	private List securityData = null;

	/**
	 * Data member which holds the kind of data to be imported.
	 */
	private String type = null;

	/**
	 * Data member to hold whether it is create mode or overwrite mode.
	 */
	private boolean overWrite = false;

	/**
	 * Constructor
	 * @param id The Message Type.
	 * @param jobOwner The Owner of the Job
	 * @param securityData The Data to be imported.
	 * @param type String indicating the type of object to be exported.
	 * @param overWrite Indicates the mode, (create or overwrite).
	 */
	public IEImportJob(USMBaseMsgType id, USMControllerIfc jobOwner, List securityData, String type, boolean overWrite) {
		super(
				id,
				JfxStringTable.getString(USMStringTable.IDS_IE_JOB_IMPORT_JOB),
				JfxStringTable.getString(USMStringTable.IDS_IE_JOB_DESC_IMPORT_JOB),
				jobOwner
		);
		this.securityData = securityData;
		this.type = type;
		this.overWrite = overWrite;
		LOGGER.debug("IEImportJob constructor Over write = " + overWrite + " type = " + type);
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob#executeJob()
	 */
	@Override
    public USMMessage executeJob() throws BcbSecurityException {
		LOGGER.debug("executeJob() - Entry");
		IEBusinessDelegate delgate = new IEBusinessDelegate();

		USMMessage msg = delgate.importSecurityData(securityData, type, overWrite);
		LOGGER.debug("executeJob() - Exit");
		return msg;
	}

}
