package com.ossnms.bicnet.securitymanagement.client.policy.common;

import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionData;

import javax.swing.*;
import java.awt.*;

/**
 * created on 4/6/2015
 */
public class PermissionListCellRenderer extends DefaultListCellRenderer {
    private static final long serialVersionUID = -2680405736803429315L;

    /**
     * This is the only method defined by ListCellRenderer. We just reconfigure the JLabel each time we're called.
     *
     * @param list
     *            The list which is the container for the Objects that need special display
     * @param value
     *            Value to display
     * @param index
     *            Cell index
     * @param isSelected
     *            Is the cell selected
     * @param cellHasFocus
     *            Indicates whether the cell has focus.
     * @return Component The Rendered that is to be used.
     *
     * @see javax.swing.ListCellRenderer#getListCellRendererComponent(javax.swing.JList, java.lang.Object, int, boolean, boolean)
     */
    @Override
    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        // Set the icon here.
        setIcon(ResourcesIconFactory.ICON_LIST_PROPERTY_PAGE);

        if(value instanceof PAPermissionData){
            PAPermissionData permissionData = (PAPermissionData) value;

            setToolTipText(
                    new PermissionDescriptionFormatter(permissionData.getName(), permissionData.getPermissionItems()).toString()
            );
        }

        return this;
    }
}
