/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   UAJobGetAllUsers
 * Author:      Babu B
 * Substitute	Vinay Purohit
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER.VIEW
 *       : TNMS.DX2.SM.FORCE_LOGOFF
 *       : TNMS.DX2.SM.USER.CREATE
 *       : TNMS.DX2.SM.USER.CONFIGURE
 *       : TNMS.DX2.SM.USER.STATUS
 * 		 :
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration.job;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.client.useradministration.UADelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAStatus;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;

/**
 * This class represents the job responsible for retrieving one user from the server
 */
public class UAJobGetUserByName extends USMJob {

	/**
	 * This is the constructor
	 *
	 * @param jobOwner The controller associated with the job
	 */
	public UAJobGetUserByName(USMControllerIfc jobOwner) {
		super(
			UAMessageType.S_UA_REQ_GET_USER_BY_NAME,
			USMStringTable.IDS_UA_FETCH_DESCRIPTION.toString(),
			USMCommonStrings.EMPTY,
			jobOwner);
	}

	/**
	 * Executes the given job
	 *
	 * @see USMJob#executeJob()
	 */
	@Override
    public USMMessage executeJob() throws BcbSecurityException {
		UADelegate delegate = new UADelegate();
        USMMessage pMsg = new USMMessage(UAMessageType.S_UA_RES_GET_USER_BY_NAME, USMMessage.USMMESSAGE_RESPONSE);
        UAUser user = delegate.getUserByName(USMUtility.getInstance().getLogonContext().getUserName());
        user.pushMe(pMsg);
        UAStatus operationStatus = new UAStatus(UAStatus.S_SUCCESS);
        operationStatus.pushMe(pMsg);
		return pMsg;
	}

}
