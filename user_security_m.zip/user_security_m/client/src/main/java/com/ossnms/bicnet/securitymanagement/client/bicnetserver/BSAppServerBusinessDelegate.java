/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	BSAppServerBusinessDelegate
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_OBJECTS
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_ACL 
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_SECURITY
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.INSERT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-02-2005	Muyeen Munaver  CF000060-01   CF USM GUI Requirements
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.bicnetserver;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityServerConfigurationPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.servicelocator.USMServiceLocator;
import com.ossnms.bicnet.util.UnexpectedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Client classes should not make calls to the Bean directly. Instead they should use
 * the Bussiness Delegate approach. This class represents the Bussiness Delegate for the
 * BS subsystem
 */
final public class BSAppServerBusinessDelegate {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(BSAppServerBusinessDelegate.class);

	/**
	 * Constructor
	 */
	public BSAppServerBusinessDelegate() {
	}

	/**
	 * Function to get all the configured CFs within USM
	 * 
	 * @return USMMessage - 
	 * 			The Message which contains the CF(s) which are configured to
	 * be a part of USM
	 * 
	 * @throws BcbSecurityException -
	 * 			The Exception as reported by the Server
	 */
	public USMMessage getConfiguredCFs() throws BcbSecurityException {
		LOGGER.debug("Entering getFunctions");

		ISecurityServerConfigurationPrivateFacade privateFacade = getPrivateFacadeBean();

		ISessionContext secCtx = USMUtility.getInstance().getSessionContext();
		USMMessage msg = privateFacade.getConfiguredCFs(secCtx);

		LOGGER.debug("Exiting getFunctions. Retrieved message : {}", msg);
		return msg;
	}

	/**
	 * Function to remove the CF(s) from USM
	 * 
	 * @param pLstCfs The List of CF(s) that are to be removed from USM
	 * @return Message which contains the result of the operation of removal of the CF(s)
	 * @throws BcbSecurityException The Exception as reported by the Server
	 */
	public USMMessage removeCFsFromUSM(List<BSTransBicNetCFInfo> pLstCfs) throws BcbSecurityException {
		LOGGER.debug("Entering removeCFsFromUSM. List of CF(s) to remove : {}", pLstCfs);

		ISecurityServerConfigurationPrivateFacade privateFacade = getPrivateFacadeBean();

		ISessionContext secCtx = USMUtility.getInstance().getSessionContext();
		USMMessage msg = privateFacade.removeCFsFromUSM(secCtx, pLstCfs);

		LOGGER.debug("Exiting removeCFsFromUSM. Retrieved message : {}", msg);
		return msg;
	}

	/**
	 * Function to synchronize the Securable Object(s) of the CF(s) that are passed as 
	 * a parameter. This function will get the latest information about the securable object
	 * from the CF and update the LDAP.
	 * 
	 * @param pLstCFs The List of CF(s) for which we have to synchronize the Securable Object(s) information
	 * @return The message which contains information about whether a specific
	 * CF was synchronized with the data or not
	 * @throws BcbSecurityException The Exception as reported by the Server
	 */
	public USMMessage synchronizeSecObjsInfoForCFs(List pLstCFs) throws BcbSecurityException {
		LOGGER.debug("Entering synchronizeSecObjsInfoForCFs. List : {}", pLstCFs);

		ISecurityServerConfigurationPrivateFacade privateFacade = getPrivateFacadeBean();

		ISessionContext secCtx = USMUtility.getInstance().getSessionContext();
		USMMessage msg = privateFacade.synchSecObjsWithCFs(secCtx, pLstCFs);

		LOGGER.debug("Exiting getCompleteServerInformation. Retrieved message : {}", msg);
		return msg;
	}

	/**
	 * Function to retrieve the securable object(s) that are managed by the CF.
	 * 
	 * @param cf -
	 * 			The CF for which we want to retrieve the securable objects
	 * 	
	 * @return USMMessage - 
	 * 			The Message which contains the securable object(s) that are managed by
	 * the CF
	 * @throws BcbSecurityException
	 * 			The Exception as reported by the Server
	 */
	public USMMessage getSecurableObjsForCF(BSTransBicNetCFInfo cf)
		throws BcbSecurityException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering getSecurableObjsForCF. CF : " + cf);
		}

		ISecurityServerConfigurationPrivateFacade privateFacade =
			getPrivateFacadeBean();

		ISessionContext secCtx = USMUtility.getInstance().getSessionContext();
		USMMessage msg =
			privateFacade.getManagedSecurableElmsForCF(secCtx, cf);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"Exiting getSecurableObjsForCF. Retrieved message : " + msg);
		}
		return msg;
	}

	/**
	 * Helper function to retrieve the Object which has implemented the 
	 * ISecurityServerConfigurationPrivateFacade.
	 * 
	 * @return ISecurityServerConfigurationPrivateFacade - 
	 * 			The object that will do the operations. Could be a bean or a Mock Obj
	 */
	private ISecurityServerConfigurationPrivateFacade getPrivateFacadeBean() {
		USMServiceLocator servLoc = USMServiceLocator.getInstance();
		ISecurityServerConfigurationPrivateFacade fcd = null;
		try {
			fcd =
				servLoc.getSecurityServerConfigurationPrivateFacade();
		} catch (UnexpectedException e) {
			LOGGER.error("getPrivateFacade failed", e);
		}
		return fcd;
	}
}
