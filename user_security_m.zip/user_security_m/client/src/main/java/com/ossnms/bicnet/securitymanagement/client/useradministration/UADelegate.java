/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   UADelegate
 * Author:      Babu B, Jogender
 * Substitute	Vinay Purohit
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER.VIEW
 *       : TNMS.DX2.SM.FORCE_LOGOFF
 *       : TNMS.DX2.SM.USER.CREATE
 *       : TNMS.DX2.SM.USER.CONFIGURE
 * 	     : TNMS.DX2.SM.USER.ASSIGN
 *       : TNMS.DX2.SM.USER.STATUS
 *       : TNMS.DX2.SM.USER_GROUP.VIEW
 *       : TNMS.DX2.SM.USER_GROUP.CONFIGURE
 *       : TNMS.DX2.SM.USER_GROUP.CREATE
 *       : TNMS.DX2.SM.USER_GROUP.ASSIGN
 * 		 :
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-Apr-2005	Asif			CF000834 - Command Log Entries	CF USM
 * 06-May-2009  Nagaraddi S S    TD004578 - RQT-STDERR errors instead log4j's
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserGroup;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityAuthenticationPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityGeneralSettingPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityUserAdministrationPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.servicelocator.USMServiceLocator;
import com.ossnms.bicnet.util.UnexpectedException;
import com.ossnms.bicnet.util.encode.HashEncode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.rmi.RemoteException;
import java.util.List;

/**
 * This class is a delegate class, which makes synchronous calls to the server.
 * The job(s) delegates all their operations to this class, which in turn
 * forwards the request(s) to the BEAN.
 */

public class UADelegate {

    private static final String DUMMY_PASSWORD = "$$$$$$$$$";

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(UADelegate.class);

    /**
     * This is the constructor
     */
    public UADelegate() {
    }

    /**
     * This method handles modification of a user.
     *
     * @param user  This is the user object that is to be modified
     * @param assignedUserGroups Vector of assigned user groups to which the user has to be assigned
     * @return USMMessage - Message that contains the result of the operation
     */
    public USMMessage modifyUser(UAUser user, List assignedUserGroups)
            throws BcbSecurityException, RemoteException {
        LOGGER.info("modifyUser() ENTRY");
        ISecurityUserAdministrationPrivateFacade objSecurityProvider =
                getUAPrivateFacade();
        LOGGER.info("modifyUser() exit");

        //if the password is empty, it will be filled with {DUMMY_PASSWORD}
        if (!user.getPassword().equals(DUMMY_PASSWORD)) {
            ISecurityAuthenticationPrivateFacade auth = getUAuthPrivateFacade();
            byte[] salt = auth.getUserPasswordSalt(user.getUserId());

            user.setPassword(HashEncode.encodePassword(user.getPassword(), salt));
        }

        return objSecurityProvider.modifyUser(
                USMUtility.getInstance().getSessionContext(),
                user,
                assignedUserGroups);
    }

    /**
     * Retrieves all the assigned and unassigned user groups for the given user
     *
     * @param userData The user string for which the assigned and unassigned user
     *                 groups have to be retrieved
     * @return USMMessage
     * Message that contains all the assigned and unassigned user groups
     */
    public USMMessage getAllAssignedAndUnassignedUserGroups(String userData)
            throws BcbSecurityException, RemoteException {

        LOGGER.info("getAllAssignedAndUnassignedUserGroups() ENTRY");
        ISecurityUserAdministrationPrivateFacade objSecurityProvider = getUAPrivateFacade();
        LOGGER.info("getAllAssignedAndUnassignedUserGroups() exit");
        USMMessage msg = objSecurityProvider.getAllAssignedAndUnassignedUsergroups(
                USMUtility.getInstance().getSessionContext(),
                userData
        );

        return msg;
    }

    /**
     * Creates an user in LDAP
     *
     * @param userData           The user object to be created
     * @param assignedUserGroups -
     *                           Vector of assigned user groups to which the user has to be assigned
     * @return USMMessage - Message that contains the result of the opeartion
     */
    public USMMessage createUser(
            UAUser userData,
            List assignedUserGroups)
            throws BcbSecurityException, RemoteException {
        LOGGER.info("createUser() ENTRY");
        ISecurityUserAdministrationPrivateFacade objSecurityProvider =
                getUAPrivateFacade();
        LOGGER.info("createUser() exit");
        userData.setPassword(HashEncode.encodePassword(userData.getPassword()));
        return objSecurityProvider.createUser(
                USMUtility.getInstance().getSessionContext(),
                userData,
                assignedUserGroups);
    }

    /**
     * Deletes one/more user accounts
     *
     * @param lstUsers -
     *                 The user accounts to be deleted
     * @return USMMessage - Message that contains the result of the operation
     */
    public USMMessage deleteUsers(List lstUsers)
            throws BcbSecurityException {
        LOGGER.debug("deleteUsers() - Enter");

        USMMessage message;
        ISecurityUserAdministrationPrivateFacade bean = getUAPrivateFacade();
        try {
            return bean.deleteUsers(
                    USMUtility.getInstance().getSessionContext(),
                    lstUsers);
        } catch (BcbSecurityException e) {
            LOGGER.debug("BcbSecurityException thrown {}. Rethrowing...", e.getMessage());
            throw e;
        } catch (Exception ex) {
            LOGGER.error("Exception thrown when making a call to assignMappings " + ex.getMessage() + " Exception class " + ex.getClass());
            message = new USMMessage(UAMessageType.S_UA_REQ_GET_ALL_USERS, USMMessage.USMMESSAGE_RESPONSE);
            message.pushInteger(0);
        }

        LOGGER.debug("deleteUsers() - Exit");

        return message;
    }

    /**
     * Activates one/more user accounts
     *
     * @param lstUsers -
     *                 The user accounts to be activated
     * @return USMMessage - Message that contains the result of the operation
     */
    public USMMessage activateUsers(List lstUsers)
            throws BcbSecurityException {
        LOGGER.debug("activateUsers() - Enter");

        USMMessage message;
        ISecurityUserAdministrationPrivateFacade bean = getUAPrivateFacade();
        try {
            return bean.activateUsers(
                    USMUtility.getInstance().getSessionContext(),
                    lstUsers);
        } catch (BcbSecurityException e) {
            LOGGER.debug("BcbSecurityException thrown {}. Rethrowing...", e.getMessage());
            throw e;
        } catch (Exception ex) {
            LOGGER.error("Exception thrown when making a call to activateUsers " + ex.getMessage() + " Exception class " + ex.getClass());
            message = new USMMessage(UAMessageType.S_UA_REQ_GET_ALL_USERS, USMMessage.USMMESSAGE_RESPONSE);
            message.pushInteger(0);
        }

        LOGGER.debug("activateUsers() - Exit");

        return message;
    }

    /**
     * Deactivates one/more user accounts
     *
     * @param lstUsers -
     *                 The user accounts to be de-activated
     * @return USMMessage - Message that contains the result of the operation
     */
    public USMMessage deactivateUsers(List lstUsers)
            throws BcbSecurityException {
        LOGGER.debug("deactivateUsers() - Enter");

        USMMessage message;
        ISecurityUserAdministrationPrivateFacade bean = getUAPrivateFacade();
        try {
            return bean.deactivateUsers(
                    USMUtility.getInstance().getSessionContext(),
                    lstUsers);
        } catch (BcbSecurityException e) {
            LOGGER.debug("BcbSecurityException thrown {}. Rethrowing...", e.getMessage());
            throw e;
        } catch (Exception ex) {
            LOGGER.error("Exception thrown when making a call to deactivateUsers " + ex.getMessage() + " Exception class " + ex.getClass());
            message = new USMMessage(UAMessageType.S_UA_REQ_GET_ALL_USERS, USMMessage.USMMESSAGE_RESPONSE);
            message.pushInteger(0);
        }

        LOGGER.debug("deactivateUsers() - Exit");

        return message;
    }

    /**
     * Unlocks one/more user accounts
     *
     * @param lstUsers -
     *                 The user accounts to be unlocked
     * @return USMMessage - Message that contains the result of the operation
     */
    public USMMessage unlockUsers(List lstUsers)
            throws BcbSecurityException {
        LOGGER.debug("unlockUsers() - Enter");

        USMMessage message;
        ISecurityUserAdministrationPrivateFacade bean = getUAPrivateFacade();
        try {
            return bean.unlockUsers(
                    USMUtility.getInstance().getSessionContext(),
                    lstUsers);
        } catch (BcbSecurityException e) {
            LOGGER.debug("BcbSecurityException thrown {}. Rethrowing...", e.getMessage());
            throw e;
        } catch (Exception ex) {

            LOGGER.error("Exception thrown when making a call to unlockUsers " + ex.getMessage() + " Exception class " + ex.getClass());
            message = new USMMessage(UAMessageType.S_UA_REQ_GET_ALL_USERS, USMMessage.USMMESSAGE_RESPONSE);
            message.pushInteger(0);
        }

        LOGGER.debug("unlockUsers() - Exit");

        return message;
    }

    /**
     * Force-fully logs off one/more user accounts
     *
     * @param lstUsers -
     *                 The user accounts to be logged off
     * @return USMMessage - Message that contains the result of the operation
     */
    public USMMessage forcedLogoffUsers(List lstUsers)
            throws BcbSecurityException {
        LOGGER.debug("forcedLogoffUsers() - Enter");

        USMMessage message;
        ISecurityUserAdministrationPrivateFacade bean = getUAPrivateFacade();
        try {
            return bean.forcedLogoffUsers(
                    USMUtility.getInstance().getSessionContext(),
                    lstUsers);
        } catch (BcbSecurityException e) {
            LOGGER.debug("BcbSecurityException thrown {}. Rethrowing...", e.getMessage());
            throw e;
        } catch (Exception ex) {

            LOGGER.error("Exception thrown when making a call to forcedLogoffUsers " + ex.getMessage() + " Exception class " + ex.getClass());
            message = new USMMessage(UAMessageType.S_UA_REQ_GET_ALL_USERS, USMMessage.USMMESSAGE_RESPONSE);
            message.pushInteger(0);
        }

        LOGGER.debug("forcedLogoffUsers() - Exit");

        return message;
    }

    /**
     * Retrieves all the users from the server
     *
     * @return USMMessage - Message that contains all the users
     */
    public USMMessage getAllUsers() throws BcbSecurityException {
        LOGGER.debug("getAllUsers() - Enter");

        USMMessage message;
        ISecurityUserAdministrationPrivateFacade bean = getUAPrivateFacade();
        try {
            return bean.getAllUsers(
                    USMUtility.getInstance().getSessionContext());
        } catch (BcbSecurityException e) {
            LOGGER.debug("BcbSecurityException thrown {}. Rethrowing...", e.getMessage());
            throw e;
        } catch (Exception ex) {
            LOGGER.error("Exception thrown when making a call to getAllUsers " + ex.getMessage() + " Exception class " + ex.getClass());
            message = new USMMessage(UAMessageType.S_UA_REQ_GET_ALL_USERS, USMMessage.USMMESSAGE_RESPONSE);
            message.pushInteger(0);
        }

        LOGGER.debug("getAllUsers() - Exit");

        return message;
    }


    /**
     * Retrieves all the users from the server
     *
     * @return UAUser - UAUser user
     */
    public UAUser getUserByName(String username) throws BcbSecurityException {
        LOGGER.debug("getUserByName() - Enter");

        ISecurityUserAdministrationPrivateFacade bean = getUAPrivateFacade();
        try {
            return bean.getUserByName(USMUtility.getInstance().getSessionContext(), username);
        } catch (BcbSecurityException e) {
            LOGGER.debug("BcbSecurityException thrown {}. Rethrowing...", e.getMessage());
            throw e;
        } catch (Exception ex) {
            LOGGER.error("Exception thrown when making a call to getUserByName " + ex.getMessage() + " Exception class " + ex.getClass());
        }

        LOGGER.debug("getUserByName() - Exit");

        return null;
    }

    /**
     * Retrieves all the user name/id pairs from the server
     *
     * @return USMMessage - Message that contains all the users
     */
    public USMMessage getAllUserNameAndID() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "getAllUserNameAndID() updated  entry in the Delegate");
        }
        ISecurityUserAdministrationPrivateFacade objSecurityProvider =
                getUAPrivateFacade();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "getAllUserNameAndID() updated exit from the Delegate");
        }
        USMMessage msg = null;
        try {
            msg =
                    objSecurityProvider.getAllUserNameAndID(
                            USMUtility.getInstance().getSessionContext());
        } catch (BcbSecurityException e) {

            LOGGER.error("Exception :", e);
        }
        LOGGER.debug("getAllUserNameAndID() updated exit from the Delegate");
        return msg;
    }

    /**
     * Retrieves all the assigned and unassigned users for the
     * given user group
     *
     * @param userGrp -
     *                The user group object for which the assigned and unassigned
     *                users have to be retrieved
     * @return USMMessage - Message that contains all the assigned and
     * unassigned users
     */
    public USMMessage getAllAssinedAndUnassignedUsers(UAUserGroup userGrp) {
        LOGGER.debug("getAllUserNameAndID() updated  entry in the Delegate");
        ISecurityUserAdministrationPrivateFacade objSecurityProvider =
                getUAPrivateFacade();
        LOGGER.debug("getAllUserNameAndID() updated exit from the Delegate");
        USMMessage msg = null;
        try {
            msg =
                    objSecurityProvider.getAllAssignedAndUnassignedUsers(
                            USMUtility.getInstance().getSessionContext(),
                            userGrp);
        } catch (BcbSecurityException e) {

            LOGGER.error("Exception :", e);
        }
        LOGGER.debug("getAllUserNameAndID() updated exit from the Delegate");
        return msg;
    }

    /**
     * Creates an user group, assigned with the given users
     *
     * @param userGroup            -
     *                             The user group object to be created
     * @param usersForUserGroup    -
     *                             Vector of users that is assigned to the user group
     * @param mappingsForUserGroup List of domain and policy mappings to assign to the user group to be created.
     * @return USMMessage - Message that contains the result of the operation
     */
    public USMMessage createUserGroup(UAUserGroup userGroup, List<String> usersForUserGroup, List<DCDomainMapping> mappingsForUserGroup) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "createUserGroup(" + userGroup + "," + usersForUserGroup + ") Enter");
        }
        ISecurityUserAdministrationPrivateFacade objSecurityProvider =
                getUAPrivateFacade();
        USMMessage msg = null;
        try {
            msg =
                    objSecurityProvider.createUserGroup(
                            USMUtility.getInstance().getSessionContext(),
                            userGroup,
                            usersForUserGroup, mappingsForUserGroup);
        } catch (BcbSecurityException e) {
            LOGGER.error("Exception :", e);
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "createUserGroup(" + userGroup + "," + usersForUserGroup + ")  Exit");
        }
        return msg;
    }

    /**
     * Modifies an user group
     *
     * @param userGroup            -
     *                             The user group to be modifies
     * @param usersForUserGroup    -
     *                             Vector of users assigned to the user group
     * @param mappingsForUserGroup List of domain and policy mappings to assign to the user group.
     * @return USMMessage - Message that contains the result of the operation
     */
    public USMMessage modifyUserGroup(
            UAUserGroup userGroup,
            List<String> usersForUserGroup, List<DCDomainMapping> mappingsForUserGroup) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "modifyUserGroup("
                            + userGroup
                            + ","
                            + usersForUserGroup
                            + ")  Enter");
        }
        ISecurityUserAdministrationPrivateFacade objSecurityProvider =
                getUAPrivateFacade();
        USMMessage msg = null;
        try {
            msg =
                    objSecurityProvider.modifyUserGroup(
                            USMUtility.getInstance().getSessionContext(), userGroup, usersForUserGroup, mappingsForUserGroup);
        } catch (BcbSecurityException e) {
            LOGGER.error("Exception :", e);
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "modifyUserGroup("
                            + userGroup
                            + ","
                            + usersForUserGroup
                            + ")  Exit - Return: "
                            + msg);
        }
        return msg;
    }

    /**
     * Deletes an user group
     *
     * @param userGrp -
     *                Vector of user groups to be deleted
     * @return USMMessage - Message that contains the result of the operation
     */
    public USMMessage deleteUserGroup(List userGrp) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("deleteUserGroup(" + userGrp + ")  Enter");
        }
        ISecurityUserAdministrationPrivateFacade objSecurityProvider =
                getUAPrivateFacade();
        USMMessage msg = null;
        try {
            msg =
                    objSecurityProvider.deleteUserGroup(
                            USMUtility.getInstance().getSessionContext(),
                            userGrp);
        } catch (BcbSecurityException e) {
            LOGGER.error("Exception :", e);
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "deleteUserGroup(" + userGrp + ")  Exit - Return: " + msg);
        }
        return msg;
    }

    /**
     * Retrieves all user groups from the server
     *
     * @return USMMessage - Message that contains all the retrieved user groups
     */
    public USMMessage getAllUserGroup(boolean forUserGroupWindo)
            throws BcbSecurityException, RemoteException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getAllUserGroup()  Enter");
        }
        ISecurityUserAdministrationPrivateFacade objSecurityProvider =
                getUAPrivateFacade();
        LOGGER.debug("getAllUserGroup() updated exit from the Delegate");
        USMMessage msg =
                objSecurityProvider.getAllUserGroup(
                        USMUtility.getInstance().getSessionContext(),
                        forUserGroupWindo);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getAllUserGroup()  Exit - Return :" + msg);
        }
        return msg;

    }

    /**
     * Retrieves the bean object to perform all the operations
     * associated with the user administration
     *
     * @return UserAdministration - User Administration bean
     */
    private ISecurityUserAdministrationPrivateFacade getUAPrivateFacade() {
        LOGGER.debug("getUAPrivateFacade()  entry");

        USMServiceLocator servLoc = USMServiceLocator.getInstance();
        ISecurityUserAdministrationPrivateFacade fcd = null;
        LOGGER.debug(" ISecurityUserAdministrationPrivateFacade() ENTRY");
        try {
            fcd =
                    servLoc.getSecurityUserAdministrationPrivateFacade();
        } catch (UnexpectedException ex) {
            LOGGER.error(
                    "UnexpectedException recieved "
                            + ex.getMessage()
                            + " Exception class "
                            + ex.getClass());
        }
        LOGGER.debug(" getUAPrivateFacade() EXIT");
        return fcd;
    }

    /**
     * Retrieves the bean object to perform all the operations
     * associated with the general settings
     *
     * @return GeneralSettings - General Settings bean
     */
    private ISecurityGeneralSettingPrivateFacade getGSPrivateFacade() {
        LOGGER.debug("getUAPrivateFacade()  entry");

        USMServiceLocator servLoc = USMServiceLocator.getInstance();
        ISecurityGeneralSettingPrivateFacade fcd = null;
        LOGGER.debug(" ISecurityUserAdministrationPrivateFacade() ENTRY");
        try {
            fcd =
                    servLoc.getSecurityGeneralSettingsPrivateFacade();
        } catch (UnexpectedException ex) {
            LOGGER.error(
                    "UnexpectedException recieved "
                            + ex.getMessage()
                            + " Exception class "
                            + ex.getClass());
        }
        LOGGER.debug(" getUAPrivateFacade() EXIT");
        return fcd;
    }

    /**
     * Retrieves the bean object to perform all the operations
     * associated with the user administration
     *
     * @return UserAdministration - User Administration bean
     */
    private ISecurityAuthenticationPrivateFacade getUAuthPrivateFacade() {
        LOGGER.debug("getUAuthPrivateFacade()  entry");

        USMServiceLocator servLoc = USMServiceLocator.getInstance();
        ISecurityAuthenticationPrivateFacade fcd = null;
        LOGGER.debug(" ISecurityAuthenticationPrivateFacade() ENTRY");
        try {
            fcd =
                    servLoc.getSecurityAuthenticationPrivateFacade();
        } catch (UnexpectedException ex) {
            LOGGER.error(
                    "UnexpectedException recieved "
                            + ex.getMessage()
                            + " Exception class "
                            + ex.getClass());
        }
        LOGGER.debug(" getUAuthPrivateFacade() EXIT");
        return fcd;
    }

    /**
     * Check if the specified user group contains the given user
     *
     * @param userGroup User group to search in
     * @param user      User to be located
     * @return USMMessage - Message that contains the result of the operation
     */
    public USMMessage checkUserGroupContainsUser(
            String userGroup,
            String user)
            throws BcbSecurityException, RemoteException {

        LOGGER.debug(
                "checkUserGroupContainsUser() updated  entry in the Delegate");
        ISecurityUserAdministrationPrivateFacade objSecurityProvider =
                getUAPrivateFacade();
        LOGGER.debug(
                "checkUserGroupContainsUser() updated exit from the Delegate");
        USMMessage msg =
                objSecurityProvider.checkUserGroupContainsUser(
                        USMUtility.getInstance().getSessionContext(),
                        userGroup,
                        user);
        return msg;

    }

    /**
     * Gets all password validation rules from server
     *
     * @return USMMessage - Message that contains the result of the operation
     */
    public USMMessage getAllPasswordValidationRules() throws BcbSecurityException {

        LOGGER.debug(
                "getAllPasswordValidationRules() updated  entry in the Delegate");
        ISecurityGeneralSettingPrivateFacade objSecurityProvider = getGSPrivateFacade();
        LOGGER.debug(
                "getAllPasswordValidationRules() updated exit from the Delegate");
        USMMessage msg =
                objSecurityProvider.getPasswordVerificationRulesConfigurationData();

        return msg;

    }

    /**
     * Method to get getAdminUserName
     *
     * @return
     */
    public String getAdminUserName() {

        String adminName = null;

        ISecurityUserAdministrationPrivateFacade bean = getUAPrivateFacade();
        try {
            adminName = getUAPrivateFacade().getAdminName(USMUtility.getInstance().getSessionContext());
        } catch (BcbSecurityException e) {
            LOGGER.debug("BcbSecurityException thrown {}. Rethrowing...", e.getMessage());
        } catch (Exception ex) {
            LOGGER.error("Exception thrown when making a call to getUserByName " + ex.getMessage() + " Exception class " + ex.getClass());
        }


        return  adminName;
    }


}
