/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	BSCFClientController
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_OBJECTS
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_ACL 
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_SECURITY
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.INSERT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 14-June-2005  Muyeen Munaver  CF000209 - Changes in the ISecurityProviderFacade / IManagedObject
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.bicnetserver.configuration;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMBaseController;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.bicnetserver.jobs.BSJobGetConfiguredCFs;
import com.ossnms.bicnet.securitymanagement.client.bicnetserver.jobs.BSJobGetSecurableObjsForCF;
import com.ossnms.bicnet.securitymanagement.client.bicnetserver.jobs.BSJobRemoveConfiguredCFs;
import com.ossnms.bicnet.securitymanagement.client.bicnetserver.jobs.BSJobSynchSecObjsInfoForCFs;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSMessageType;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSReturnType;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * This is the controller class which is a kind of helper to the
 * View to retrieve and display the data.
 */
class BSCFClientController extends USMBaseController {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(BSCFClientController.class);

	/**
	 * Constructor
	 * 
	 * @param view -
	 * 			The View class which is responsible for the creation 
	 * of this controller.
	 */
	BSCFClientController(BSCFView view) {
		super(view);
		LOGGER.debug("Entering constructor.");

		registerInterestedNotificationIds(getInterestedNotifcations());

		LOGGER.debug("Exiting constructor.");
	}

	/**
	 * Helper function to return the List of Notification IDs that the Controller
	 * is interested in.
	 * 
	 * @return List - 
	 * 			The List which contains the Notification IDs that the Controller
	 * is interested in.
	 */
	private List<USMBaseMsgType> getInterestedNotifcations() {
		LOGGER.debug("Entering getInterestedNotifcations");

		List<USMBaseMsgType> lstInterestedNotif = new ArrayList<>();

		lstInterestedNotif.add(BSMessageType.BS_NOT_CF_INSERTED);
		lstInterestedNotif.add(BSMessageType.BS_NOT_CF_REMOVED);
		lstInterestedNotif.add(BSMessageType.BS_NOT_CF_SYNCED_WITH_SEC_OBJS);
		lstInterestedNotif.add(BSMessageType.BS_NOT_NEW_SEC_OBJ_REGISTERED);
		lstInterestedNotif.add(BSMessageType.BS_NOT_SEC_OBJ_UNREGISTERED);
		lstInterestedNotif.add(BSMessageType.BS_NOT_SEC_OBJ_CHANGED);
		lstInterestedNotif.add(BSMessageType.BS_NOT_SEC_OBJS_ASSIGNED_TO_DOMAINS);
		lstInterestedNotif.add(BSMessageType.BS_NOT_SEC_OBJS_UNASSIGNED_FROM_DOMAINS);
		lstInterestedNotif.add(BSMessageType.BS_NOT_CF_NAME_CHANGED);
		LOGGER.debug("Exiting getInterestedNotifcations");

		return lstInterestedNotif;
	}

	/**
	 * Helper function which will send a request to the server to retrieve the
	 * Securable Object(s) for a particular CF.
	 * 
	 * @param pCF - 
	 * 			The CF for which the Securable object(s) are to be retireved
	 * 
	 * @return boolean - 
	 * 			Indicates whether it was possible to send the request or not.
	 */
	boolean sendReqToGetSecObjsForCF(BSTransBicNetCFInfo pCF) {
		LOGGER.debug("Entering sendReqToGetSecObjsForCF. CF is " + pCF);

		BSJobGetSecurableObjsForCF jobToGetSecuObjs = new BSJobGetSecurableObjsForCF(this, pCF);
		boolean bResult = queueJob(jobToGetSecuObjs);

		LOGGER.debug("Exiting sendReqToGetSecObjsForCF. Result is : " + bResult);
		return bResult;
	}

	/**
	 * Function that is invoked by the view to send a request to the server 
	 * to retrieve a list of the CFs that are configured to work with USM
	 * 
	 * @return boolean - 
	 * 			Indicates whether it was possible to send the request or not.
	 */
	boolean sendReqToGetConfCFs() {
		LOGGER.debug("Entering sendReqToGetConfCFs");

		BSJobGetConfiguredCFs jobToGetServers = new BSJobGetConfiguredCFs(this);
		boolean bResult = queueJob(jobToGetServers);

		LOGGER.debug("Exiting sendReqToGetConfCFs. Result is : " + bResult);
		return bResult;
	}

	/**
	 * This function is invoked by the View when the operator
	 * clicks the Remove Button in the View.
	 * 
	 * @param listOfCfs This is the list which contains the CFs
	 * that have been selected in the View and must be removed.
	 */
	boolean sendReqToRemoveCFsFromUSM(List<BSTransBicNetCFInfo> listOfCfs) {
		LOGGER.debug("Entering sendRequestToRemoveCFsFromUSM");

		BSJobRemoveConfiguredCFs jobToGetCFs = new BSJobRemoveConfiguredCFs(this, listOfCfs);
		boolean bResult = queueJob(jobToGetCFs);

		LOGGER.debug("Exiting sendRequestToRemoveCFsFromUSM. Result is : {}", bResult);
		return bResult;
	}

	/**
	 * This function is invoked by the View when the operator
	 * clicks the Synch NEs Button in the View.
	 * 
	 * @param listOfCfs  - 
	 * 				This is the List which contains the CF(s) 
	 * that have been selected in the View and must be Synchronized with SE information.
	 */
	boolean sendReqToSyncSecurableObjs(List<BSTransBicNetCFInfo> listOfCfs) {
		LOGGER.debug("Entering sendReqToSyncSecurableObjs");

		BSJobSynchSecObjsInfoForCFs jobToSyncSecObjs = new BSJobSynchSecObjsInfoForCFs(this, listOfCfs);
		boolean bResult = queueJob(jobToSyncSecObjs);

		LOGGER.debug("Exiting sendReqToSyncSecurableObjs. Result is : " + bResult);
		return bResult;
	}

	/**
	 *
	 * @param job USM job from which the result came
	 * @param result - the USM Result
     */
	@Override
    public void resultAvailable(USMJob job, USMMessage result) {
		LOGGER.debug("Entering resultAvailable. Job is : {} Message is : {}", job, result);

		USMBaseMsgType resultType = result.getMessageType();
		if (resultType.equals(BSMessageType.BS_RES_GET_CONF_CFS)) {
			handleResponseForGetConfCFs(result);
		} else if (
			resultType.equals(BSMessageType.BS_RES_GET_SEC_OBJS_FOR_CF)) {
			handleResponseForGetSecObjsForCF(result);
		} else if (resultType.equals(BSMessageType.BS_RES_REMOVE_CFS)) {
			handleResponseForRemoveCFs(result);
		} else if (
			resultType.equals(BSMessageType.BS_RES_SYNC_CFS_WITH_SEC_OBJS)) {
			handleResponseForSyncSecurableObjects(result);
		} else {
			LOGGER.warn("Do not know how to handle the message. {}", result);
		}

		LOGGER.debug("Exiting resultAvailable");
	}

	/**
	 * Helper function to handle the response for the Sync NE's
	 * @param msg Message which contains the result of the sync operation.
	 */
	private void handleResponseForSyncSecurableObjects(USMMessage msg) {
		LOGGER.debug("Entering handleResponseForSyncSecurableObjects. Message is : {}", msg);

		displayResult(msg, USMStringTable.IDS_BS_ERROR_SYNC_CFS.toString());

		LOGGER.debug("Exiting handleResponseForSyncSecurableObjects");
	}

	/**
	 * Helper function to handle the response for the Configured CFs
	 * @param msg Message which contains the result of the configured cf retrieval.
	 */
	private void handleResponseForGetConfCFs(USMMessage msg) {
		LOGGER.debug("Entering handleResponseForGetConfCFs. Message is : " + msg);

		List<BSTransBicNetCFInfo> lstCFs = BSCommonHelper.popCFsListFromMessage(msg);
		LOGGER.debug("List of CFs {}", lstCFs);
		getAssociatedView().updateConfigCFsList(lstCFs);

		LOGGER.debug("Exiting handleResponseForGetConfCFs");
	}

	/**
	 * Helper function to handle the response for the retrieval of Sec Objects for a CF
	 * @param msg Message which contains the securable object retrieval.
	 */
	private void handleResponseForGetSecObjsForCF(USMMessage msg) {
		LOGGER.debug("Entering handleResponseForGetSecObjsForCF. Message is : {}", msg);

		BSReturnType result = BSReturnType.popMe(msg);
		BSTransBicNetCFInfo cfInfo = BSTransBicNetCFInfo.popMe(msg);

		if (result.equals(BSReturnType.SUCCESS_T)) {
			List<BSSecurableObject> lstSecObjs = BSCommonHelper.popSecurableObjectsListFromMessage(msg);
			LOGGER.debug("Securable Objects", lstSecObjs);
			getAssociatedView().updateSecurableObjectList(cfInfo, lstSecObjs);
		} else {
			String strError = USMStringTable.IDS_BS_ERROR_SECOBJS_RETRIEVAL.toString();
			strError += result.toString();
			getAssociatedView().displayErrorMessage(strError);

			// After displaying the Error message, take corrective messure by removing the server
			// from the View. 
			List<BSTransBicNetCFInfo> lstCfs = new ArrayList<>();
			lstCfs.add(cfInfo);
			getAssociatedView().cfsRemoved(lstCfs);

		}

		LOGGER.debug("Exiting handleResponseForGetSecObjsForCF");
	}

	/**
	 * Helper function to handle the response for the CFs removal
	 * @param msg Message which contains the result of the CF removal
	 */
	private void handleResponseForRemoveCFs(USMMessage msg) {
		LOGGER.debug("Entering handleResponseForRemoveCFs. Message is : {}", msg);

		displayResult(msg, USMStringTable.IDS_BS_ERROR_REMOVE_CFS.toString());

		LOGGER.debug("Exiting handleResponseForRemoveCFs");
	}

	/**
	 * Function to display the result of operation (can be called for Remove/Sync)
	 * @param pMsg Message which contains the result
	 * @param strErrorMsg String which contains the error message
	 */
	private void displayResult(USMMessage pMsg, String strErrorMsg) {
		LOGGER.debug("Entering displayResult");

		StringBuilder strError = new StringBuilder(strErrorMsg);
		boolean bDisplayError = false;
		int nNoOfCFs = pMsg.popInteger();
		for (int index = 0; index < nNoOfCFs; index++) {
			BSTransBicNetCFInfo cf = BSTransBicNetCFInfo.popMe(pMsg);
			BSReturnType result = BSReturnType.popMe(pMsg);

			if (!result.equals(BSReturnType.SUCCESS_T)) {
				bDisplayError = true;
				strError.append(cf.getName());
				strError.append(" : ");
				strError.append(result.toString());
				strError.append("\n");
			}
		}

		if (bDisplayError) {
			getAssociatedView().displayErrorMessage(strError.toString());
		}
		LOGGER.debug("Exiting displayResult");
	}

	/**
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc#handleNotification(com.ossnms.bicnet.securitymanagement.common.basic.USMMessage)
	 */
	@Override
    public void handleNotification(USMMessage msg) {
		LOGGER.debug("Entering handleNotification. Message is : {}", msg);

		USMBaseMsgType msgType = msg.getMessageType();
		if (msgType.equals(BSMessageType.BS_NOT_CF_INSERTED)) {
			handleNotifCFInserted(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_CF_NAME_CHANGED)) {
			handleNotifCFNameChanged(msg);
		} else if (
			msgType.equals(BSMessageType.BS_NOT_CF_SYNCED_WITH_SEC_OBJS)) {
			handleNotifServerSynchronized(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_CF_REMOVED)) {
			handleNotifCFRemoved(msg);
		} else if (
			msgType.equals(BSMessageType.BS_NOT_SEC_OBJS_ASSIGNED_TO_DOMAINS)) {
			handleNotifSesAssignedToDomains(msg);
		} else if (
			msgType.equals(BSMessageType.BS_NOT_SEC_OBJS_UNASSIGNED_FROM_DOMAINS)) {
			handleNotifSesUnAssignedToDomains(msg);
		} else if (
			msgType.equals(BSMessageType.BS_NOT_NEW_SEC_OBJ_REGISTERED)) {
			handleNotifSesRegistered(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_SEC_OBJ_UNREGISTERED)) {
			handleNotifSesUnRegistered(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_SEC_OBJ_CHANGED)) {
			handleNotifSesNameChange(msg);
		}

		LOGGER.debug("Exiting handleNotification.");
	}

	/**
	 * Helper function to change the display name of the CF.
	 * @param msg Message which contains information about the new name of the CF.
	 */
	private void handleNotifCFNameChanged(USMMessage msg) {
		LOGGER.debug("Entering handleNotifCFNameChanged. Message is : {}", msg);

		BSTransBicNetCFInfo cf = BSTransBicNetCFInfo.popMe(msg);
		getAssociatedView().cfNameChanged(cf);

		LOGGER.debug("Exiting handleNotifCFNameChanged.");
	}

	/**
	 * Helper function to handle the Securable objects removed notification
	 * @param msg Message which contains information about the Securable Objects
	 * that have been removed.
	 */
	private void handleNotifSesUnRegistered(USMMessage msg) {
		LOGGER.debug("Entering handleNotifSesUnRegistered. Message is : {}", msg);

		BSTransBicNetCFInfo cf = BSTransBicNetCFInfo.popMe(msg);
		List<BSSecurableObject> lstSecObjs = BSCommonHelper.popSecurableObjectsListFromMessage(msg);
		getAssociatedView().secObjsUnRegisteredForCF(cf, lstSecObjs);

		LOGGER.debug("Exiting handleNotifSesUnRegistered.");
	}

	/**
	 * Helper function to handle the Securable objects inserted notification
	 * @param msg Message which contains information about the Securable Objects
	 * that have been added.
	 */
	private void handleNotifSesRegistered(USMMessage msg) {
		LOGGER.debug("Entering handleNotifSesRegistered. Message is : {}", msg);

		BSTransBicNetCFInfo cf = BSTransBicNetCFInfo.popMe(msg);
		List<BSSecurableObject> lstSecObjs = BSCommonHelper.popSecurableObjectsListFromMessage(msg);
		getAssociatedView().secObjsRegisteredForCF(cf, lstSecObjs);

		LOGGER.debug("Exiting handleNotifSesRegistered.");
	}

	/**
	 * Helper function to handle the Securable objects inserted notification
	 * @param msg Message which contains information about the Securable Objects
	 * that have been added.
	 */
	private void handleNotifSesNameChange(USMMessage msg) {
		LOGGER.debug("Entering handleNotifSesNameChange. Message is : {}", msg);

		BSTransBicNetCFInfo cf = BSTransBicNetCFInfo.popMe(msg);
		List<BSSecurableObject> lstSecObjs = BSCommonHelper.popSecurableObjectsListFromMessage(msg);
		getAssociatedView().secObjsNameChangedForCF(cf, lstSecObjs);

		LOGGER.debug("Exiting handleNotifSesNameChange.");
	}

	/**
	 * Helper function to handle the notification that is recieved when
	 * a server is inserted.
	 * 
	 * @param msg Message which contains the Server(s) which were inserted.
	 */
	private void handleNotifCFInserted(USMMessage msg) {
		LOGGER.debug("Entering handleNotifCFInserted");
		BSTransBicNetCFInfo cf = BSTransBicNetCFInfo.popMe(msg);

		getAssociatedView().cfInserted(cf);

		LOGGER.debug("Exiting handleNotifCFInserted");
	}

	/**
	 * Helper function to handle the notification that is recieved when
	 * a server is removed.
	 * 
	 * @param msg Message which contains the Server(s) which were removed.
	 */
	private void handleNotifCFRemoved(USMMessage msg) {
		LOGGER.debug("Entering handleNotifCFRemoved.");

		List<BSTransBicNetCFInfo> lstCfs = BSCommonHelper.popCFsListFromMessage(msg);
		getAssociatedView().cfsRemoved(lstCfs);

		LOGGER.debug("Exiting handleNotifCFRemoved.");
	}

	/**
	 * Helper function to handle the notification that is recieved when
	 * SE(s) are assigned to Domain(s)
	 * 
	 * @param msg Message which contains the SE(s) and the Domain(s)
	 */
	private void handleNotifSesAssignedToDomains(USMMessage msg) {
		List<BSSecurableObject> lstSecObjs = BSCommonHelper.popSecurableObjectsListFromMessage(msg);
		BSCommonHelper.popDomainsListFromMessage(msg);
		getAssociatedView().sesAssignedToDomains(lstSecObjs);
	}

	/**
	 * Helper function to handle the notification that is recieved when
	 * SE(s) are unassigned from Domain(s)
	 * 
	 * @param msg Message which contains the SE(s) and the Domain(s)
	 */
	private void handleNotifSesUnAssignedToDomains(USMMessage msg) {
		List<BSSecurableObject> lstSecObjs = BSCommonHelper.popSecurableObjectsListFromMessage(msg);
		BSCommonHelper.popDomainsListFromMessage(msg);
		getAssociatedView().sesUnAssignedToDomains(lstSecObjs);
	}

	/**
	 * Helper function to handle the notification that is recieved when
	 * a server is synchronized.
	 * 
	 * @param msg Message which contains the Server(s) which were synchronized.
	 */
	private void handleNotifServerSynchronized(USMMessage msg) {
		BSTransBicNetCFInfo cf = BSTransBicNetCFInfo.popMe(msg);
		getAssociatedView().cfSynchronized(cf);
	}

	/**
	 * Function to return the associated view correctly typecasted.
	 * @return BSCFView the Associated view for this controller.
	 */
	private BSCFView getAssociatedView() {
		return (BSCFView) associatedView;
	}
}
