/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	BSJobGetConfiguredCFs
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_OBJECTS
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_ACL 
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_SECURITY
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.INSERT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.bicnetserver.jobs;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.bicnetserver.BSAppServerBusinessDelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSMessageType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * This class represents a Job which is responsible for getting all the 
 * configured CF which are available within USM.
 */
public class BSJobGetConfiguredCFs extends USMJob {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(BSJobGetConfiguredCFs.class);

	/**
	 * Constructor
	 * @param jobOwner The Controller which is the owner of this Job
	 */
	public BSJobGetConfiguredCFs(USMControllerIfc jobOwner) {
		super(BSMessageType.BS_REQ_GET_CONF_CFS, USMStringTable.IDS_BS_JOB_RETRIEVE_CFS.toString(),	"",	jobOwner);
	}

	/**
	 *
	 * @return USMMessage
	 * @throws BcbSecurityException
     */
	public USMMessage executeJob() throws BcbSecurityException {
		LOGGER.debug("Entering executeJob");
		USMMessage msg = new BSAppServerBusinessDelegate().getConfiguredCFs();
		LOGGER.debug("Exiting executeJob");
		return msg;
	}
}