package com.ossnms.bicnet.securitymanagement.client.policy.views.base;

import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMFrameType;
import com.ossnms.bicnet.securitymanagement.client.policy.common.PermissionList;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionData;
import com.ossnms.tools.jfx.JfxFormPanel;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxTextField;
import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.util.Collections;
import java.util.List;

/**
 * This is a base class for the create/modify window of domain and policy. This window has a left and right tree pane
 * associated.
 */
public abstract class PACreateModifyBaseView extends USMBaseViewWithButtons implements ListSelectionListener {
    private static final long serialVersionUID = 6363970248661141875L;

    private static final Logger LOGGER = Logger.getLogger(PACreateModifyBaseView.class);

    private static final String METHOD_UPDATE_PERMISSION_LIST = "updatePermissionList()";
//    private static final String METHOD_CREATE_PERMISSION_TREE_NODES = "createPermissionTreeNodes()";
    private static final String METHOD_UPDATE_WINDOW = "updateWindow()";

    /**
     * Button for left transfer.
     */
    protected JfxButton btnLTR = null;
    /**
     * Button for right transfer.
     */
    protected JfxButton btnRTL = null;
    /**
     * Button for left group transfer.
     */
    protected JfxButton btnLTRGP = null;
    /**
     * Button for right group transfer.
     */
    protected JfxButton btnRTLGP = null;

    /**
     * Text field for holding the name.
     */
    protected JfxTextField txtFldName = null;
    /**
     * Text field for holding the description.
     */
    protected JfxTextField txtDesc = null;

    private DefaultListModel<PAPermissionData> modelAvailable = null;
    private DefaultListModel<PAPermissionData> modelAssigned = null;

    private PermissionList listAvailable = null;
    private PermissionList listAssigned = null;

    /**
     * Tree for the available permissions.
     */
//    private PermissionTree treeAvailable = null;

    /**
     * DefaultMutableTreeNode for the available tree.
     */
//    private PermissionTreeNode availablePermissionsNode = null;
    /**
     * Tree for the assigned permissions.
     */
//    private PermissionTree treeAssigned = null;
    /**
     * DefaultMutableTreeNode for the assigned tree.
     */
//    private PermissionTreeNode assignedPermissionsNode = null;

    /**
     * Denotes the left tree of the window.
     */
    public static final PAListType S_LEFT_LIST = new PAListType(1);
    /**
     * Denotes the right tree of the window.
     */
    public static final PAListType S_RIGHT_LIST = new PAListType(2);


//    private static final String METHOD_SEARCH_FOR_CHILD = "searchForChild ()";

    /**
     * This method is used to get the tree associated with the Tree type.
     * 
     * @param listType The tree type for which the corresponding tree has to be fetched.
     * @return JTree Returns the associated JTree object.
     */
    protected PermissionList getList(PAListType listType) {
        if (listType.equals(S_LEFT_LIST)) {
            return listAvailable;
        } else if (listType.equals(S_RIGHT_LIST)) {
            return listAssigned;
        } else {
            return null;
        }
    }

    protected DefaultListModel<PAPermissionData> getModel(PAListType listType){
        if (listType.equals(S_LEFT_LIST)) {
            return modelAvailable;
        } else if (listType.equals(S_RIGHT_LIST)) {
            return modelAssigned;
        } else {
            return null;
        }
    }

    /**
     * Gets the name as entered by the user.
     * 
     * @return String Returns the name of the policy or domain as entered by the user.
     */
    @Override
    public final String getName() {
        return txtFldName.getText();
    }

    /**
     * Gets the description as entered by the user.
     * 
     * @return String Returns the description of the policy or domain as entered by the user.
     */
    public final String getDescription() {
        return txtDesc.getText();
    }

    /**
     * Sets the description as entered by the user.
     * 
     * @param strText Description of the policy or domain as entered by the user.
     */
    public final void setDescription(String strText) {
        txtDesc.setText(strText);
    }

    /**
     * Helper function to enable and disabled the << and the >> buttons
     */
    private void toggleFullMoveButtons() {
        if (modelAssigned.getSize() > 0) {
            btnRTLGP.setEnabled(true);
        } else {
            btnRTLGP.setEnabled(false);
        }

        if (modelAvailable.getSize() > 0) {
            btnLTRGP.setEnabled(true);
        } else {
            btnLTRGP.setEnabled(false);
        }
    }


    /**
     * Constructor
     *
     * @param vecObjs List containing the Buttons that need to be displayed
     * @param commitButtons commit buttons
     * @param functionButtons function buttons
     * @param strID The fully qualified name of the concrete class
     * @param strTitle The Title of the Window
     * @param resizable Indicates whether the View is resizable or not
     * @param helpId The Help ID that is associated with the concrete class
     */
    protected PACreateModifyBaseView(
            List<USMButtonType> vecObjs, List<USMButtonType> commitButtons, List<USMButtonType> functionButtons,
            String strID, String strTitle, boolean resizable, int helpId
    ) {
        super(vecObjs, commitButtons, functionButtons, strID, strTitle, resizable, false, helpId);
        initComponents();
        setComponentNames();
    }

    /**
     * Helper function that is used to set the Names of all the editable components within the Window.
     * 
     * Strings in this function are not to be Internationalized.
     */
    private void setComponentNames() {
        btnLTR.setName("Add");
        btnRTL.setName("Remove");
        btnLTRGP.setName("AddAll");
        btnRTLGP.setName("RemoveAll");
        txtFldName.setName("Name");
        txtDesc.setName("Description");
        listAvailable.setName("AvailablePermissions");
        listAssigned.setName("AssignedPermissions");
    }

    /**
     * This is the overridden method that gets called when a value or selection changes. This decides what buttons have to be enabled and disabled.
     * 
     * @param evt The Java TreeSelectionEvent.
     */
    @Override
    public void valueChanged(ListSelectionEvent evt) {
        PAPermissionData permissionData = ((PermissionList) evt.getSource()).getSelectedValue();

        if (permissionData != null) {
            if (modelAvailable.contains(permissionData)) {
                btnLTR.setEnabled(true);
            } else if (modelAssigned.contains(permissionData)) {
                btnRTL.setEnabled(true);
            } else {
                if (evt.getSource() == listAvailable) {
                    btnLTR.setEnabled(true);
                } else if (evt.getSource() == listAssigned) {
                    btnRTL.setEnabled(true);
                }
            }
        } else {
            if (evt.getSource() == listAvailable) {
                btnLTR.setEnabled(false);
            } else if (evt.getSource() == listAssigned) {
                btnRTL.setEnabled(false);
            }
        }
        toggleFullMoveButtons();
    }

    /**
     * This method clears the tree.
     * 
     * @param treeType The tree which has to be cleared. Whether the left or the right tree.
     */
    public void clear(PAListType treeType) {
        PermissionList list = getList(treeType);
        DefaultListModel<PAPermissionData> listModel = (DefaultListModel<PAPermissionData>) list.getModel();
        listModel.clear();
        setGroupTransferButtonsState();
    }

    /**
     * This method deletes a node from the tree as specified by the tree type.
     * 
     * @param treeType The tree from which the node has to be deleted.
     * @param objToBeDeleted The object which has to be searched and deleted.
     * @return boolean Returns true to indicate successful deletion. Returns false if the object is not found.
     */
    public boolean deleteNode(PAListType treeType, Object objToBeDeleted) {
//        if (null != objToBeDeleted) {
//
//            PermissionTreeNode rootNode = getTreeRoot(treeType);
//            List<PermissionTreeNode> children = rootNode.getChildren();
//
//            for(PermissionTreeNode treeNode : children){
//                if (objToBeDeleted.equals(treeNode.getUserObject())) {
//                    getList(treeType).setSelectionPath(new TreePath(treeNode.getPath()));
//                    removeElement(treeType, treeNode);
//                    return true;
//                }
//            }
//            setGroupTransferButtonsState();
//        }
//
        return false;
    }

    /**
     * This method adds an element to the list type.
     * 
     * @param listType
     *            The list to which the element has to be added.
     * @param permissionData
     *            The data or element which has to be added.
     */
	public void addElement(PAListType listType, PAPermissionData permissionData) {
		if (!getModel(listType).contains(permissionData)) {
			getModel(listType).addElement(permissionData);
		}
	}

    /**
     * This method adds a vector of nodes to the tree.
     * 
     * @param listType The tree to which the nodes have to be added.
     * @param elements The nodes which have to be added.
     */
    public void addElement(PAListType listType, List<PAPermissionData> elements) {
        if (null != elements) {
            for(PAPermissionData permissionData : elements){
                addElement(listType, permissionData);
            }
        }
        toggleFullMoveButtons();
    }

    /**
     * This method gets called when the left transfer button is clicked. This method transfers the selected objects to
     * the right pane.
     */
    protected void onLTR() {
        transferNodes(S_LEFT_LIST, S_RIGHT_LIST);
    }


    /**
     * This method gets called when the right transfer button is clicked. This method transfers the selected objects to
     * the left pane.
     */
    protected void onRTL() {
        transferNodes(S_RIGHT_LIST, S_LEFT_LIST);
    }


    /**
     *
     * @param source The source list
     * @param destination the destination list
     */
    private void transferNodes(PAListType source, PAListType destination) {
        if (!isWaitCursorSet()) {
            setWaitCursor();

            List<PAPermissionData> elementsToTransfer = getElementsToTransfer(source);

            //Execute operations on both objects
            removeElement(source, elementsToTransfer);
            insertElement(destination, elementsToTransfer);

            setGroupTransferButtonsState();
            setNormalCursor();
        }
    }

    /**
     * This method gets called when the left group transfer button is clicked. This method transfers the all the objects to the right pane.
     */
    protected void onLTRGP() {
        if (!isWaitCursorSet()) {
            setWaitCursor();

			for (PAPermissionData permissionData : Collections.list(getModel(S_LEFT_LIST).elements())) {
				if (!getModel(S_RIGHT_LIST).contains(permissionData)) {
					getModel(S_RIGHT_LIST).addElement(permissionData);
				}
			}

            getModel(S_LEFT_LIST).clear();

            setNormalCursor();
            setGroupTransferButtonsState();
            toggleFullMoveButtons();
        }
    }

    /**
     * This method gets called when the right group transfer button is clicked. This method transfers the all the objects to the left pane.
     */
    protected void onRTLGP() {
        if (!isWaitCursorSet()) {
            setWaitCursor();

            for(PAPermissionData permissionData : Collections.list(getModel(S_RIGHT_LIST).elements())){
            	if (!getModel(S_LEFT_LIST).contains(permissionData)) {
            		getModel(S_LEFT_LIST).addElement(permissionData);
            	}
            }

            getModel(S_RIGHT_LIST).clear();

            setNormalCursor();
            setGroupTransferButtonsState();
            toggleFullMoveButtons();
        }
    }

    /**
     * This method is called from the constructor to initialize all the GUI objects of the window.
     */
    private void initComponents() {
        Dimension listMinDimension = new Dimension(35, 50);

        JfxFormPanel mainPanel = getPanelForPlacingDerviedControls();
        mainPanel.setLayout(new GridBagLayout());
        mainPanel.setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);
        mainPanel.setMinimumSize(new Dimension(200, 200));
        mainPanel.setPreferredSize(new Dimension(450, 350));

        JfxLabel lblName = new JfxLabel(USMStringTable.IDS_PA_NAME);
        lblName.setLabelAndMnemonicFor(txtFldName);
        txtFldName = new JfxTextField("");
        txtFldName.limitText(64);
        txtFldName.setMandatoryEntry(true);

        JfxLabel lblDesc = new JfxLabel(USMStringTable.IDS_PA_DESCRIPTION);
        lblDesc.setLabelAndMnemonicFor(txtDesc);
        txtDesc = new JfxTextField("");
        txtDesc.limitText(128);
        
        JPanel nameAndDescriptionPanel = new JPanel();
        nameAndDescriptionPanel.setLayout(new GridBagLayout());
        
//        availablePermissionsNode = new PermissionTreeNode(USMStringTable.IDS_PA_AVAILABLE_MENU);
//        treeAvailable = new PermissionTree(new DefaultTreeModel(availablePermissionsNode));
//        treeAvailable.setRootVisible(false);
//        treeAvailable.setShowsRootHandles(true);

        modelAvailable = new DefaultListModel<>();
        listAvailable = new PermissionList(modelAvailable);
        
        // Set up the Title for Available objects
        JfxLabel captionForAvailableObjectsLabel = new JfxLabel(USMStringTable.IDS_PA_AVAILABLE_MENU);
        captionForAvailableObjectsLabel.setLabelAndMnemonicFor(listAvailable);
        captionForAvailableObjectsLabel.setAlignmentX(LEFT_ALIGNMENT);

        // Set up the tree with scroll pane
        JScrollPane availableObjectsPane = new JScrollPane();
        availableObjectsPane.setViewportView(listAvailable);
        availableObjectsPane.setAlignmentX(LEFT_ALIGNMENT);
        availableObjectsPane.setMinimumSize(listMinDimension);
        availableObjectsPane.setPreferredSize(listMinDimension);
        
        JfxFormPanel navigationPanel = new JfxFormPanel();
        navigationPanel.setLayout(new GridBagLayout());
        
        btnLTR = new JfxButton(USMStringTable.IDS_BUTTON_ADD);
        btnLTRGP = new JfxButton(USMStringTable.IDS_BUTTON_ADD_ALL);
        btnRTL = new JfxButton(USMStringTable.IDS_BUTTON_REMOVE);
        btnRTLGP = new JfxButton(USMStringTable.IDS_BUTTON_REMOVE_ALL);
        
        btnLTR.setEnabled(false);
        btnRTL.setEnabled(false);
//
//        assignedPermissionsNode = new PermissionTreeNode(USMStringTable.IDS_PA_ASSIGNED_MENU);
//        treeAssigned = new PermissionTree(new DefaultTreeModel(assignedPermissionsNode));
//        treeAssigned.setDragEnabled(true);
//        treeAssigned.setLargeModel(true);
//        treeAssigned.setRootVisible(false);
//        treeAssigned.setShowsRootHandles(true);

        modelAssigned = new DefaultListModel<>();
        listAssigned = new PermissionList(modelAssigned);
        listAssigned.setDragEnabled(true);

        // Set up the Title for Securable objects
        JfxLabel captionForAssignedObjectsLabel = new JfxLabel(USMStringTable.IDS_PA_ASSIGNED_MENU);
        captionForAssignedObjectsLabel.setLabelAndMnemonicFor(listAssigned);
        captionForAssignedObjectsLabel.setAlignmentX(LEFT_ALIGNMENT);

        JScrollPane assignedObjectsPane = new JScrollPane();
        assignedObjectsPane.setAlignmentX(LEFT_ALIGNMENT);
        assignedObjectsPane.setMinimumSize(listMinDimension);
        assignedObjectsPane.setPreferredSize(listMinDimension);
        assignedObjectsPane.setViewportView(listAssigned);

        nameAndDescriptionPanel.add(lblName, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        nameAndDescriptionPanel.add(txtFldName, new GridBagConstraints(1, 0, 3, 1, 1.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        nameAndDescriptionPanel.add(lblDesc, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        nameAndDescriptionPanel.add(txtDesc, new GridBagConstraints(1, 1, 3, 1, 1.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        
        navigationPanel.add(btnLTR, new GridBagConstraints(0, 0, 4, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, JfxUtils.MINIMUM_DISTANCE_BETWEEN_BUTTONS, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        navigationPanel.add(btnLTRGP, new GridBagConstraints(0, 1, 4, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, JfxUtils.MINIMUM_DISTANCE_BETWEEN_BUTTONS, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        navigationPanel.add(btnRTL, new GridBagConstraints(0, 2, 4, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, JfxUtils.MINIMUM_DISTANCE_BETWEEN_BUTTONS, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        navigationPanel.add(btnRTLGP, new GridBagConstraints(0, 3, 4, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));

        mainPanel.add(nameAndDescriptionPanel, new GridBagConstraints(0, 0, 3, 2, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        mainPanel.add(captionForAvailableObjectsLabel, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VERTICAL_MARGIN_BETWEEN_CAPTION_AND_FIELD, 0), 0, 0));
        mainPanel.add(captionForAssignedObjectsLabel, new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VERTICAL_MARGIN_BETWEEN_CAPTION_AND_FIELD, 0), 0, 0));
        mainPanel.add(availableObjectsPane, new GridBagConstraints(0, 3, 1, 1, 1.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        mainPanel.add(navigationPanel, new GridBagConstraints(1, 3, 1, 1, 0.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.VERTICAL, new Insets(0, 0, 0, 0), 0, 0));
        mainPanel.add(assignedObjectsPane, new GridBagConstraints(2, 3, 1, 1, 1.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));

//        treeAvailable.addTreeSelectionListener(this);
//        treeAssigned.addTreeSelectionListener(this);

        listAvailable.addListSelectionListener(this);
        listAssigned.addListSelectionListener(this);

        btnLTR.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                onLTR();
            }
        });

        btnRTL.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                onRTL();
            }
        });

        btnLTRGP.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                onLTRGP();
            }
        });

        btnRTLGP.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                onRTLGP();
            }
        });

        setGroupTransferButtonsState();
    }

    /**
     * This helper method gets the nodes to be transferred given the tree type.
     * 
     * @param listType The tree for which the request is made.
     * @return Vector Returns the nodes which are to be added.
     */
    private List<PAPermissionData> getElementsToTransfer(PAListType listType) {
        return getList(listType).getSelectedValuesList();
    }

    /**
     *
     * @param listType
     * @param elements
     */
    protected void removeElement(PAListType listType, List<PAPermissionData> elements){
        for(PAPermissionData permission : elements){
            removeElement(listType, permission);
        }
    }

    /**
     *
     * @param listType
     * @param elements
     */
    protected void insertElement(PAListType listType, List<PAPermissionData> elements){
        for(PAPermissionData permission : elements){
            insertElement(listType, permission);
        }
    }

    /**
     * This helper method is used to remove the transferred node from the given tree.
     * 
     * @param listType The tree from which the node has to be removed.
     * @param element The node which has to be removed.
     */
    protected void removeElement(PAListType listType, PAPermissionData element) {
        DefaultListModel<PAPermissionData> listModel = getModel(listType);

        if(listModel.contains(element)){
            int index = listModel.indexOf(element);
            listModel.remove(index);
        }
    }

    /**
     *
     * @param listType
     * @param element
     */
    private void insertElement(PAListType listType, PAPermissionData element) {
		if (!getModel(listType).contains(element)) {
			getModel(listType).addElement(element);
		}
        setGroupTransferButtonsState();
    }

    /**
     * This method is used to enable and disable the group transfer buttons.
     */
    protected void setGroupTransferButtonsState() {
        DefaultListModel<PAPermissionData> rightDefaultList = getModel(S_RIGHT_LIST);
        DefaultListModel<PAPermissionData> leftDefaultList = getModel(S_LEFT_LIST);

        int rightTreeCount = 0;
        int leftTreeCount = 0;

        if (null != rightDefaultList) {
            rightTreeCount = rightDefaultList.size();
        }
        if (null != leftDefaultList) {
            leftTreeCount = leftDefaultList.size();
        }

        btnRTLGP.setEnabled(true);
        btnLTRGP.setEnabled(true);

        if (0 == rightTreeCount) {
            btnRTLGP.setEnabled(true);
        }

        if (0 == leftTreeCount) {
            btnLTRGP.setEnabled(true);
        }
    }

    /**
     * This method gets all the leaf nodes currently associated with the tree.
     * 
     * @param listType The left tree or the right tree for which the NEs have to be retrieved.
     * @return Vector Returns all the leaf nodes of the tree.
     */
    public List<PAPermissionData> getPermissions(PAListType listType) {
        return Collections.list(getModel(listType).elements());
    }

    /**
     * Function called to update the window with the new information.
     * @param availablePermissions The List of Menu entries that are to be shown in the available tree.
     * @param configuredPermissions The List of Menu entries that are to be shown in the assigned tree.
     */
    public void updateWindow(List<PAPermissionData> availablePermissions, List<PAPermissionData> configuredPermissions) {
        LOGGER.debug(METHOD_UPDATE_WINDOW + "PAPolicyCreateView.__with_menu_options");

        //Set available Permissions
        if (availablePermissions != null) {
            LOGGER.debug(METHOD_UPDATE_WINDOW + "Number of Available Permissions is : " + availablePermissions.size());
            if (availablePermissions.size() > 0) {
                updatePermissionList(S_LEFT_LIST, availablePermissions);
            }
        } else {
            LOGGER.info(METHOD_UPDATE_WINDOW + "Null Vector of Available Permissions.");
        }

        //Set configured Permissions
        if (configuredPermissions != null) {
            LOGGER.info(METHOD_UPDATE_WINDOW + "Number of Configured Permissions is : " + configuredPermissions.size());
            if (configuredPermissions.size() > 0) {
                updatePermissionList(S_RIGHT_LIST, configuredPermissions);
            }
        } else {
            LOGGER.info(METHOD_UPDATE_WINDOW + "Null Vector of Configured Permissions");
        }

        LOGGER.debug(METHOD_UPDATE_WINDOW + "PAPolicyCreateView._EXIT_FUNCTION");
    }

    /**
     * Update the specified list of permissions.
     *
     * @param treeType type of tree: left or right
     * @param permissions the list of permissions
     */
    private void updatePermissionList(PAListType treeType, List<PAPermissionData> permissions) {
        LOGGER.debug(METHOD_UPDATE_PERMISSION_LIST + " Number of Available Left List Child Nodes : " + permissions.size());
        addElement(treeType, permissions);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getComponent()
     */
    @Override
    public JComponent getComponent() {
        return this;
    }

    /**
     * Function to decide what is the Frame that should be used.
     * 
     * @return USMFrameType The Frame type that should be used.
     */
    @Override
    protected USMFrameType getFrameTypeToBeUsed() {
        return USMFrameType.S_INTERNAL;
    }
}

