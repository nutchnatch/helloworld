/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	PAPolicyCreateCommand
 * Author      	Vinay Purohit
 * Substitute	muyeen
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID	:	TNMS.DX2.SM.POLICY.CREATE
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.policy.views.create;

import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;

/**
 * This Command Class is the Handler for 1. Creating a new Policy 2. Modifying
 * an existing policy.
 */
public class PAPolicyCreateCommand extends USMCommand {

	/**
	 * Default Constructor. Registers itself with the UI Frame work
	 */
	public PAPolicyCreateCommand() {
		super(USMCommandID.S_UI_ID_NEW_POLICIES);
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#createAndReturnView()
	 */
	@Override
    protected USMBaseView createAndReturnView() {

		return new PAPolicyCreateView();
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#cloneCmd(java.lang.Object)
	 */
	@Override
    public USMCommand cloneCmd(Object selList) {
		return new PAPolicyCreateCommand();
	}
}
