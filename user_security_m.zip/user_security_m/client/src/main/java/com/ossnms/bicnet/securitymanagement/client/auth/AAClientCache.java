package com.ossnms.bicnet.securitymanagement.client.auth;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.facade.security.SecurableObjectContainerIdItem;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkableId;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.SecurityPlugin;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.auth.AAClientCacheData;
import com.ossnms.bicnet.securitymanagement.common.auth.AAClientCacheData.ClientMapping;
import com.ossnms.bicnet.securitymanagement.common.basic.SecurableObjectACL;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSMessageType;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCGlobal;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessageType;
import com.ossnms.bicnet.securitymanagement.common.policy.PAMessageType;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionItemData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.ossnms.bicnet.bcb.model.ManagedObjectType.NE;
import static com.ossnms.bicnet.bcb.model.ManagedObjectType.SECURABLE_OBJECT;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.POLICY_NO_ACCESS;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.POLICY_NO_VISIBILITY;
import static java.util.stream.Collectors.toSet;

/**
*
* This class maintains a cache based on the following structure
* 
* Cache -> Map<DomainId Vs PolicyIdList>
* 
* Map2 -> Map<PolicyId Vs MenuEntryList>
*
*/
public final class AAClientCache {

	public static final int GLOBAL_DOMAIN = 0;
	/**
	 * Data member to hold self reference
	 */
	private static AAClientCache smSelf = new AAClientCache();

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(AAClientCache.class);

	/**
	 *  Cache -> Map<DomainId Vs PolicyIdList>     
	 */
	private Map<Integer, Set<Integer>> mainCache = new HashMap<>();

	/**
	 *  Map2 -> Map<PolicyId Vs MenuEntryList>
	 */
	private Map<Integer,Set<String>> policyMap = new HashMap<>();

	/** Cached value of Accessible DomainIds */
	private BitSet bitsetAccessibleDomainIds =
		new BitSet(DCGlobal.MAX_DOMAINS);

	/**
	 * On notification for policy/mapping changes, client retrieves the security data cache again from server.
	 * @param   ctx - session context retrieved on logged in
	 */
	public synchronized void rebuildCache(ISessionContext ctx) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("rebuildCache(" + ctx + ") Entry");
		}

		AALoginBusinessDelegate objDelegate = new AALoginBusinessDelegate();
		AAClientCacheData objClientCachedata = objDelegate.getClientCacheData(ctx);

		mainCache.clear();
		policyMap.clear();

		bitsetAccessibleDomainIds.clear();

		// Populate the Policies into the local cache
		List<PAPolicyData> vecPolicies = objClientCachedata.getPolicies();
		int nPolicyCount = vecPolicies.size();

		LOGGER.debug("Policy count - " + nPolicyCount);

		vecPolicies.forEach(this::updatePolicyInMap);

		// Populate the Client Mappings into the local cache
		List<ClientMapping> vecClientMappings = objClientCachedata.getClientMappingVector();
		int nClientMappingCount = vecClientMappings.size();

		// actions for each of the client mappings
		vecClientMappings.forEach(mapping -> {
			int nDomainId = mapping.domainId;
			Integer objDomainId = nDomainId;

			List<Integer> vecPolicyIds = mapping.policyIds;
			Set<Integer> setPolicyIds = vecPolicyIds.stream().collect(toSet());

			LOGGER.debug("Domain - {}, Policy Ids - {}", nDomainId, setPolicyIds);

			mainCache.put(objDomainId, setPolicyIds);
		});

		LOGGER.debug("Updated cache with {} Policies and {} Client Mappings", nPolicyCount, nClientMappingCount);

		AALoginBusinessDelegate delegate = new AALoginBusinessDelegate();

		long timeBefore = System.currentTimeMillis();
		try {
			Set<SecurableObjectACL> msgSecurableObjects = delegate.getSecurableObjects();
			LOGGER.info("getSecurableObjects execution took: {}", (System.currentTimeMillis() - timeBefore));
			
			// Get the Managed Object Cache
			AAManagedObjectCache objMOCache = AAManagedObjectCache.getInstance();
	
			// Now, add the securable objects to the Cache
			LOGGER.debug("Retrieved - " + msgSecurableObjects.size() + " Securable Objects.");
	
			timeBefore = System.currentTimeMillis();

			msgSecurableObjects.forEach(secObject -> {
				LOGGER.debug(" Unique Name - {} : ACL - {}", secObject.getUniqueName(), secObject.getBitSetACL());
				objMOCache.addManagedobject(secObject.getUniqueName(), secObject.getBitSetACL());
			});
		} catch (BcbSecurityException e) {
			LOGGER.error("Exception :", e);
		}
		LOGGER.info("getSecurableObjects processing execution took: {}", (System.currentTimeMillis() - timeBefore));
		
		LOGGER.debug("rebuildCache(ISessionContext ctx)  Exit");
	}

	/**
	* Clears the cache created on client side at login time.
	*/
	public synchronized void clearCache() {
		LOGGER.debug("clearCache  Entry");

		bitsetAccessibleDomainIds.clear();
		mainCache.clear();
		policyMap.clear();

		// Get the Managed Object Cache
		AAManagedObjectCache objMOCache = AAManagedObjectCache.getInstance();
		objMOCache.cleanup();

		LOGGER.debug("clearCache  Exit");
	}

	/**
	 * Default Constructor
	 *
	*/
	private AAClientCache() {
		super();
	}

	/**
	 * Function to return the singleton instance of the class
	 * 
	 * @return USMServerCache - 
	 * 			The singleton instance of the class.
	 * 
	 */
	public static AAClientCache getInstance() {
		return smSelf;
	}

	/**
	 * Checks whether the current user is allowed to use the given
	 * operation.
	 * 
	 * @param strOperation The name of the operation to be analyzed
	 * @return false, if the operation is not permitted true, otherwise
	 */
	public synchronized boolean checkOperationPermission(String strOperation) {
		LOGGER.debug("checkOperationPermission({})		Enter", strOperation);
		boolean bOperationAllowed = false;

		for (Entry<Integer, Set<String>> entry : policyMap.entrySet()) {
			Set<String> setMenuEntries = entry.getValue();

			bOperationAllowed = setMenuEntries.contains(strOperation);

			if (bOperationAllowed) {
				break;
			}
		}

		LOGGER.debug("checkOperationPermission({})		Exit", strOperation);
		return bOperationAllowed;
	}

	/**
	 * Helper function to return if the user has access to the GLOBAL Domain.
	 * @return boolean Indicates if user has access to GLOBAL Domain. True indicates
	 * has permission
	 */
	private synchronized boolean hasAccessToGlobalDomain() {
		LOGGER.debug("Entering hasAccessToGlobalDomain");
		boolean bHasGlobalDomainAccess;

		Set<Integer> policies = mainCache.get(GLOBAL_DOMAIN);
		if(policies == null) {
			bHasGlobalDomainAccess = false;
		} else {
			bHasGlobalDomainAccess = policies.stream().anyMatch(policyId -> policyId > -1);
		}

		LOGGER.debug( "Exiting hasAccessToGlobalDomain. Returning : {}", bHasGlobalDomainAccess);
		return bHasGlobalDomainAccess;
	}

	/**
	 * Helper function to return if the user has access to the GLOBAL Mapping.
	 * i.e. UG <-> GLOBAL Domain <-> GLOBAL Policy
	 * @return boolean Indicates if user has access to GLOBAL Mapping. True indicates
	 * has permission
	 */
	private synchronized boolean hasAccessToGlobalMapping() {
		LOGGER.debug("Entering hasAccessToGlobalMapping");
		Integer nGlobal = 0;

		boolean bHasGlobalMappingAccess = false;
		Set<Integer> stPolicyID = mainCache.get(nGlobal);
		if (stPolicyID != null) {
			bHasGlobalMappingAccess = stPolicyID.contains(nGlobal);
		}

		LOGGER.debug("Exiting hasAccessToGlobalMapping. Returning : {}", bHasGlobalMappingAccess);
		return bHasGlobalMappingAccess;
	}

	public synchronized IManagedObjectId[] filterAccessibleObjects(IManagedObjectMarkableId[] criteria, String operation) {
		LOGGER.debug("filterAccessibleObjects() - Enter");

		// Get objects from client cache
		Stream<Entry<String,BitSet>> objManagedObjectCache = AAManagedObjectCache.getInstance().stream();

		// Filtering objects
		IManagedObjectId[] accessibleObjects = objManagedObjectCache
				.filter(byMOType(criteria))
				.filter(byId(criteria))
				.filter(byOperation(operation))
				.filter(byAccess())
				.map(toManagedObjects())
				.toArray(IManagedObjectId[]::new);

		LOGGER.debug("filterAccessibleObjects() - Exit");

		return accessibleObjects;
	}

	public synchronized IManagedObjectId[] filterVisibleObjects(IManagedObjectMarkableId[] criteria) {
		LOGGER.debug("filterVisibleObjects() - Enter");

		// Get objects from client cache
		Stream<Entry<String,BitSet>> objManagedObjectCache = AAManagedObjectCache.getInstance().stream();

		// Filtering objects
		IManagedObjectId[] visibleObjects = objManagedObjectCache
				.filter(byMOType(criteria))
				.filter(byId(criteria))
				.filter(byVisibility())
				.map(toManagedObjects())
				.toArray(IManagedObjectId[]::new);

		LOGGER.debug("filterVisibleObjects() - Exit");

		return visibleObjects;
	}


	private Function<Entry<String,BitSet>,IManagedObjectId> toManagedObjects() {
		return mapEntry -> {
			IManagedObjectId id = null;

			if (mapEntry.getKey().contains(NE.getKeyName() + '=')) {
				String objectName = mapEntry.getKey().replace(NE.getKeyName() + '=', "");
				id = new NEIdItem(Integer.parseInt(objectName));
			} else if(mapEntry.getKey().contains(SECURABLE_OBJECT.getKeyName() + '=')) {
				String objectName = mapEntry.getKey().replace(SECURABLE_OBJECT.getKeyName() + '=', "");
				id = new SecurableObjectContainerIdItem(objectName);
			}

			return id;
		};
	}

	private Predicate<? super Entry<String,BitSet>> byMOType(IManagedObjectMarkableId[] criteria) {
		return mapEntry -> {
			if (criteria.length == 1 && criteria[0].countMarks() == 0){
				return mapEntry.getKey().toUpperCase().contains(criteria[0].moType().getKeyName().toUpperCase() + '=');
			} else {
				return true;
			}
		};
	}

	private Predicate<? super Entry<String,BitSet>> byId(IManagedObjectMarkableId[] criteria) {
		return mapEntry -> {
			if (criteria.length >= 1 && criteria[0].countMarks() != 0) {
				for(IManagedObjectMarkableId idMarkable : criteria){
					if(mapEntry.getKey().toUpperCase().equals(idMarkable.key().toUpperCase())){
						return true;
					}
				}
			} else if (criteria.length == 1 && criteria[0].countMarks() == 0){
				return true;
			}

			return false;
		};
	}

	private Predicate<? super Entry<String,BitSet>> byAccess() {
		return mapEntry -> {
			BitSet bitSetACLCurrentObject = mapEntry.getValue();
			BitSet bitSetDomainIdsWithAccess = getAccessDomainIds();

			return !bitSetDomainIdsWithAccess.isEmpty() && bitSetACLCurrentObject != null
					&& bitSetACLCurrentObject.intersects(bitSetDomainIdsWithAccess);
		};
	}

	private Predicate<? super Entry<String,BitSet>> byOperation(String operation) {
		return mapEntry -> {

			if(operation == null){
				return true;
			}

			BitSet bitSetACLCurrentObject = mapEntry.getValue();
			List<Integer> domainIds = bitSetACLCurrentObject.stream().boxed().collect(Collectors.toList());

			for (int domainId : domainIds){
				if (mainCache.get(domainId).stream().anyMatch(policy ->
						(policyMap.get(policy) != null && policyMap.get(policy).contains(operation)))){
					return true;
				}
			}

			return false;
		};
	}

	private BitSet getVisibleDomainIds() {
		BitSet bitSetVisibleDomainIds = new BitSet();
		mainCache.keySet().stream()
				.filter(domainId -> (mainCache.get(domainId).size() > 1
						||  mainCache.get(domainId).isEmpty()
						|| (mainCache.get(domainId).size() == 1
							&& !mainCache.get(domainId)
								.contains(POLICY_NO_VISIBILITY.getPolicyID()))))
				.forEach(bitSetVisibleDomainIds::set);

		return bitSetVisibleDomainIds;
	}

	/**
	 *
	 * @return
     */
	private BitSet getAccessDomainIds() {
		BitSet bitSetAccessDomainIds = new BitSet();
		mainCache.keySet().stream()
				.filter(domainId -> !mainCache.get(domainId).isEmpty() && isAccessible(domainId)
				)
				.forEach(bitSetAccessDomainIds::set);

		return bitSetAccessDomainIds;
	}

	/**
	 *
	 * @param domainId
	 * @return
     */
	private boolean isAccessible(Integer domainId) {
		return mainCache.get(domainId).size() > 1
				|| (mainCache.get(domainId).size() == 1
						&& !mainCache.get(domainId).contains(POLICY_NO_VISIBILITY.getPolicyID())
						&& !mainCache.get(domainId).contains(POLICY_NO_ACCESS.getPolicyID())
		);
	}


	private Predicate<? super Entry<String,BitSet>> byVisibility(){
		return mapEntry -> {
			BitSet bitSetACLCurrentObject = mapEntry.getValue();
			BitSet bitSetVisibleDomainIds = getVisibleDomainIds();

			return bitSetACLCurrentObject != null && !bitSetVisibleDomainIds.isEmpty() &&
					bitSetACLCurrentObject.intersects(bitSetVisibleDomainIds);
		};
	}

	/**
	 * Checks whether the current user is allowed to manage the desired
	 * objects by means that the objects are part of the user's security
	 * domain. This method is called by plug-ins to decide whether a
	 * specific object may be displayed on the GUI or not.
	 * 
	 * @param arDesiredObjects List of objects to be analzyed
	 * @return The set of valid objects being a subset of arDesiredObjects
	 * 
	 * @see com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession#checkObjectPermission(IManagedObjectId[])
	 */
	public synchronized IManagedObjectId[] checkObjectPermission(IManagedObjectId[] arDesiredObjects) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("checkObjectPermission({})		Enter", USMCommonHelper.getStringForArrayOfIManagedObjectId(arDesiredObjects));
		}

		// Vector<ManagedObjectId>
		List<IManagedObjectId> allowedObjects = new ArrayList<>();

		if (hasAccessToGlobalDomain()) {
			// User has access to Global Domain. So return back everything as having permission
			LOGGER.info("Security Check circumvented since user has Global Domain Access");
			return arDesiredObjects;
		} else {
			dumpCache();
			BitSet bitsetDomainIds;

			// Premature optimization - Is it worth to optimize here?
			synchronized (this) {
				// Collate all accessible Domain Ids
				bitsetDomainIds = bitsetAccessibleDomainIds;

				if ((null == bitsetDomainIds) || (bitsetDomainIds.isEmpty())) {
					bitsetDomainIds = getAccessibleDomainIds();
					bitsetAccessibleDomainIds = bitsetDomainIds;
				}
			}

			// Check whether each of the given Managed Objects are present in any of the domains
			if (bitsetDomainIds.size() != 0) {
				for (IManagedObjectId objManagedObject : arDesiredObjects) {
					AAManagedObjectCache objManagedObjectCache = AAManagedObjectCache.getInstance();
					String strKey = extractNEId(objManagedObject);
					BitSet bitSetACLCurrentNE = objManagedObjectCache.getACL(USMCommonHelper.getUSMizedStringForKey(strKey));

					if (bitSetACLCurrentNE != null && bitSetACLCurrentNE.intersects(bitsetDomainIds)) {
						// At least one matching domain
						allowedObjects.add(objManagedObject);
					}
				}
			} else {
				LOGGER.info(
					"The operator has no permissions to execute the command");
			}
		}
		// Convert Vector to Array
		IManagedObjectId[] arrIDs = allowedObjects.toArray(new IManagedObjectId[allowedObjects.size()]);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("checkObjectPermission Exit. Returning : {}", USMCommonHelper.getStringForArrayOfIManagedObjectId(arrIDs));
		}
		return arrIDs;
	}

	/**
	 * Retruns the Domain IDs 
	 * @return - Bitset of Domain IDs
	 */
	private synchronized BitSet getAccessibleDomainIds() {
		LOGGER.debug("getAccessibleDomainIds() 	Enter");
		BitSet bitsetDomainIds = new BitSet(DCGlobal.MAX_DOMAINS);

		for (Entry<Integer, Set<Integer>> entry : mainCache.entrySet()) {
			if(entry.getValue().stream().anyMatch(policyId -> policyId > -1)) {
				bitsetDomainIds.set(entry.getKey());
			}

		}

		LOGGER.debug("getAccessibleDomainIds() Exit. Returning : {}", bitsetDomainIds);
		return bitsetDomainIds;
	}

	/**
	 * Checks whether the current user is allowed to apply the given
	 * operation to the desired objects.
	 * 
	 * @param strOperation The name of the operation to be applied
	 * @param arDesiredObjects List of desired objects to be analzyed
	 * @return The set of valid objects for the given operation being a
	 *         subset of arDesiredObjects
	 *		
	 */
	public synchronized IManagedObjectId[] checkObjectPermission(String strOperation, IManagedObjectId[] arDesiredObjects) {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("checkObjectPermission({},{}) Enter", strOperation, Arrays.toString(arDesiredObjects));
		}


		// Vector<ManagedObjectId>
		List<IManagedObjectId> vecAllowedObjects = new ArrayList<>();
		if (hasAccessToGlobalMapping()) {
			LOGGER.info("Security Check circumvented since user has Global Domain & Global Policy Access");
			return arDesiredObjects;
		} else {
			// Dump the full cache contents
			dumpCache();
			for (IManagedObjectId objManagedObject : arDesiredObjects) {
				AAManagedObjectCache objManagedObjectCache = AAManagedObjectCache.getInstance();

				String strKey = extractNEId(objManagedObject);
				BitSet bitsetACLCurrentNE =	objManagedObjectCache.getACL(USMCommonHelper.getUSMizedStringForKey(strKey));

				// Check if the Object is null.
				if (bitsetACLCurrentNE != null) {
					// Remove workaround later, when BS is fully implemented.
					// For now, assume NE belongs only to GLOBAL domain.
					// Fault ID 35 - Provide default handling for domaining
					// bitsetACLCurrentNE = new BitSet();
					// bitsetACLCurrentNE.set(0);
					Set<Integer> setPolicyIds = new HashSet<>();
					// Check each mapping
					for (Entry<Integer, Set<Integer>> entry : mainCache.entrySet()) {
						int nDomainValue = entry.getKey();
						Set<Integer> setOfPoliciesAssociatedWithDomain = entry.getValue();
						boolean bDomainAllowed = bitsetACLCurrentNE.get(nDomainValue);
						if (bDomainAllowed) {
							setPolicyIds.addAll(setOfPoliciesAssociatedWithDomain);
						}
					}

					boolean bResult = false;
					// Check whether the given operation is present in any of the policies
					if (setPolicyIds.size() != 0) {
						// Iterate through all the permission class Ids to check if the
						// the required command can be executed on at least one of them.
						for (Integer objPolicyId : setPolicyIds) {
							// Determine the command Ids in the permission class identified by its Id.
							Set<String> setMenuEntries = policyMap.get(objPolicyId);
							if (null != setMenuEntries) {
								bResult = setMenuEntries.contains(strOperation);
								// If the value returned is true, the operation can be executed.
								if (bResult) {
									break;
								}
							}
						}
					}
					if (bResult) {
						vecAllowedObjects.add(objManagedObject);
					}
				}
			}
		}

		IManagedObjectId[] arr = vecAllowedObjects.toArray(new IManagedObjectId[vecAllowedObjects.size()]);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("checkObjectPermission Exit. Returning {0}", USMCommonHelper.getStringForArrayOfIManagedObjectId(arr));
		}

		// Convert Vector to Array
		return arr;
	}

	private String extractNEId(IManagedObjectId objManagedObject) {
		String strKey;
		if (objManagedObject.neId() == null) {
            strKey = objManagedObject.key();
        } else {
            strKey = objManagedObject.neId().key();
        }
		return strKey;
	}

	/**
	 * Notification handler for all USM messages
	 * 
	 * @param msg - Message recieved for updating the client cache
	 * 
	 * @return boolean
	 *      true if client security data was modified.
	 */
	public boolean handleNotification(USMMessage msg) {

		boolean bDataModified = false;
		// Fault ID 4 - Improper handling of notification in Authentication Client and Server
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handleNotification(" + msg + ")		Enter");
		}
		USMBaseMsgType type = msg.getMessageType();

		if (type.equals(PAMessageType.S_PA_NOT_POLICY_MODIFIED)) {
			handlePolicyModified(msg);
			bDataModified = true;
		} else if (type.equals(PAMessageType.S_PA_NOT_POLICY_DELETED)) {
			handlePolicyDeleted(msg);
			bDataModified = true;
		} else if (type.equals(DCMessageType.DC_NOT_DOMAIN_DELETED)) {
			handleDomainDeleted(msg);
			bDataModified = true;

		} else if (type.equals(DCMessageType.DC_NOT_MAPPINGS_MODIFIED)) {
			handleDomainMappingsModified(msg);
			bDataModified = true;

		} else if (
			type.equals(BSMessageType.BS_NOT_SEC_OBJS_ASSIGNED_TO_DOMAINS)) {
			handleNEAssigned(msg);
			bDataModified = true;

		} else if (
			type.equals(
				BSMessageType.BS_NOT_SEC_OBJS_UNASSIGNED_FROM_DOMAINS)) {
			handleNEUnassigned(msg);
			bDataModified = true;

		} else if (type.equals(BSMessageType.BS_NOT_NEW_SEC_OBJ_REGISTERED)) {
			handleNERegistered(msg);
			bDataModified = true;

		} else if (type.equals(BSMessageType.BS_NOT_SEC_OBJ_UNREGISTERED)) {
			handleNEUnregistered(msg);
			bDataModified = true;

			//these three next notifications do not need to be handled.
		} else if (!type.equals(PAMessageType.S_PA_NOT_POLICY_CREATED) &&
					!type.equals(DCMessageType.DC_NOT_DOMAIN_CREATED) &&
					!type.equals(DCMessageType.DC_NOT_DOMAIN_MODIFIED)){
			LOGGER.error("Unhandled notification " + msg);
		}

		LOGGER.debug("Cache modified ? " + bDataModified);
		if (bDataModified) {
			dumpCache();
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handleNotification(" + msg + ")		Exit");
		}
		return bDataModified;
	}

	/**
	 * Helper method for NE Assigned Notifications
	 * 
	 * @param msg The notification message
	 */
	private synchronized void handleNEAssigned(USMMessage msg) {
		LOGGER.debug("handleNEAssigned(" + msg + ")		Enter");
		AAManagedObjectCache objMOCache = AAManagedObjectCache.getInstance();

		// Extract the Assigned NEs
		int nSecurableObjectCount = msg.popInteger();

		if (USMCommonHelper.isDetailedTracesEnabled()) {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(
					"Securable Objects assigned to domains - "
						+ nSecurableObjectCount
						+ " Securable Objects.");
			}
		}

		while (nSecurableObjectCount-- > 0) {
			BSSecurableObject objSecurable = BSSecurableObject.popMe(msg);

			if (USMCommonHelper.isDetailedTracesEnabled()) {
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug(
						" "
							+ nSecurableObjectCount
							+ " : Unique Name - "
							+ objSecurable.getUniqueName()
							+ " : ACL - "
							+ objSecurable.getACL());
				}
			}

			// Replace the entry in the map
			objMOCache.addManagedobject(
				objSecurable.getUniqueName(),
				objSecurable.getBitSetACL());
		}
		LOGGER.debug("handleNEAssigned(" + msg + ")		Exit");
	}

	/**
	 * Helper method for NE Unassigned Notifications
	 * 
	 * @param msg
	 *      The notification message
	 */
	private synchronized void handleNEUnassigned(USMMessage msg) {
		LOGGER.debug("handleNEUnassigned(" + msg + ")		Enter");
		AAManagedObjectCache objMOCache = AAManagedObjectCache.getInstance();

		// Extract the Assigned NEs
		int nSecurableObjectCount = msg.popInteger();

		if (USMCommonHelper.isDetailedTracesEnabled()) {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug(
					"Securable Objects Un-Assigned to domains - "
						+ nSecurableObjectCount
						+ " Securable Objects.");
			}
		}

		while (nSecurableObjectCount-- > 0) {
			BSSecurableObject objSecurable =
				BSSecurableObject.popMe(msg);

			if (USMCommonHelper.isDetailedTracesEnabled()) {
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug(
						" "
							+ nSecurableObjectCount
							+ " : Unique Name - "
							+ objSecurable.getUniqueName()
							+ " : ACL - "
							+ objSecurable.getACL());
				}
			}

			// Replace the entry in the map
			objMOCache.addManagedobject(
				objSecurable.getUniqueName(),
				objSecurable.getBitSetACL());
		}
		LOGGER.debug("handleNEUnassigned(" + msg + ")		Exit");
	}

	/**
	 * Helper method for NE Registered Notifications
	 * This can happen when a sync is performed on any CF
	 * 
	 * @param msg
	 *      The notification message
	 */
	private synchronized void handleNERegistered(USMMessage msg) {
		LOGGER.debug("handleNERegistered(" + msg + ")		Enter");
		AAManagedObjectCache objMOCache = AAManagedObjectCache.getInstance();

	    //Extract server version information
        BSTransBicNetCFInfo.popMe(msg);
		
		// Extract the Assigned NEs
		int nSecurableObjectCount = msg.popInteger();

		if (USMCommonHelper.isDetailedTracesEnabled() &&
			 LOGGER.isDebugEnabled()) {
				
			LOGGER.debug("New Securable Objects Registered - "
							+ nSecurableObjectCount
							+ " Securable Objects.");
		}

		while (nSecurableObjectCount-- > 0) {
			BSSecurableObject objSecurable =
				BSSecurableObject.popMe(msg);

			if (USMCommonHelper.isDetailedTracesEnabled() &&
				LOGGER.isDebugEnabled()) {
				
					LOGGER.debug(" "
							+ nSecurableObjectCount
							+ " : Unique Name - "
							+ objSecurable.getUniqueName()
							+ " : ACL - "
							+ objSecurable.getACL());

			}

			// Add the entry to the map
			objMOCache.addManagedobject(
				objSecurable.getUniqueName(),
				objSecurable.getBitSetACL());
		}
		LOGGER.debug("handleNERegistered(" + msg + ")		Exit");
	}

	/**
	 * Helper method for NE Unregistered Notifications
	 * This can happen when a sync is performed on any CF
	 * 
	 * @param msg
	 *      The notification message
	 */
	private synchronized void handleNEUnregistered(USMMessage msg) {
		LOGGER.debug("handleNEUnregistered(" + msg + ")		Enter");
		AAManagedObjectCache objMOCache = AAManagedObjectCache.getInstance();

		//Extract server version information
		BSTransBicNetCFInfo.popMe(msg);
		
		// Extract the Unassigned NEs
		int nSecurableObjectCount = msg.popInteger();

		if (USMCommonHelper.isDetailedTracesEnabled() &&
			 LOGGER.isDebugEnabled()) {
				
			LOGGER.debug("Securable Objects unregistered - "
						+ nSecurableObjectCount
						+ " Securable Objects.");
		}

		while (nSecurableObjectCount-- > 0) {
			BSSecurableObject objSecurable =
				BSSecurableObject.popMe(msg);

			if (USMCommonHelper.isDetailedTracesEnabled()) {
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug(
						" "
							+ nSecurableObjectCount
							+ " : Unique Name - "
							+ objSecurable.getUniqueName()
							+ " : ACL - "
							+ objSecurable.getACL());
				}
			}

			// Remove the entry from the map
			objMOCache.removeManagedobject(objSecurable.getUniqueName());
		}
		LOGGER.debug("handleNEUnregistered(" + msg + ")		Exit");
	}

	/**
	 * Helper method for modified domain mapping Notifications	
	 * 
	 * @param msg
	 *      The notification message
	 */
	private synchronized void handleDomainMappingsModified(USMMessage msg) {
		// The full cache has to be re-built.
		// It cannot be optimized further to change the cache relying 
		// only on the incoming message, without introducing additional complexity 
		// into the cache structure & the authorization checks.
		LOGGER.debug(
			"handleDomainMappingsModified(" + msg + ")		Enter");
		SecurityPlugin plugin = USMUtility.getInstance().getSecurityPlugin();
		ISessionContext ctx = plugin.getSessionContext();
		rebuildCache(ctx);
		LOGGER.debug(
			"handleDomainMappingsModified(" + msg + ")		Exit");
	}

	/**
	 * Helper method for deleted domain Notifications	
	 * @param msg
	 *      The notification message
	 */
	private synchronized void handleDomainDeleted(USMMessage msg) {
		LOGGER.debug("handleDomainDeleted(" + msg + ")		Enter");
		DCDomainData objDomain = new DCDomainData();
		objDomain.popMe(msg);

		if (USMCommonHelper.isDetailedTracesEnabled() &&
			LOGGER.isDebugEnabled()) {
			
			LOGGER.debug("Deleted domain details - ");
			LOGGER.debug("    Id - " + objDomain.getDomainID());
			LOGGER.debug("    Name - " + objDomain.getDomainName());

		}

		Integer objDomainIdOfDeletedDomain = objDomain.getDomainID();

		// Cleanup all associated client mappings
		mainCache.remove(objDomainIdOfDeletedDomain);

		// Cleanup all un-referenced policies
		Map<Integer, Integer> mapPolicyRefCounts = new HashMap<>();
		// Generate reference count for each policy
		for (Entry<Integer, Set<Integer>> o : mainCache.entrySet()) {
			Set<Integer> setPolicyIds = o.getValue();
			for (Integer objPolicyId : setPolicyIds) {
				Integer objPolicyRefCount = mapPolicyRefCounts.get(objPolicyId);
				if (null == objPolicyRefCount) {
					objPolicyRefCount = 1;
				} else {
					objPolicyRefCount = objPolicyRefCount + 1;
				}
				mapPolicyRefCounts.put(objPolicyId, objPolicyRefCount);
			}
		}

		// Now cleanup the  un-referenced policies

		for (Entry<Integer, Set<String>> o : policyMap.entrySet()) {
			Integer objPolicyId = o.getKey();
			Integer objRefCountForPolicy = mapPolicyRefCounts.get(objPolicyId);
			if ((objRefCountForPolicy == null) || (objRefCountForPolicy == 0)) {
				policyMap.remove(objPolicyId);
			}
		}

		LOGGER.debug("handleDomainDeleted(" + msg + ")		Exit");
	}

	/**
	 * Helper method for policy deletion  Notifications	
	 * 
	 * @param msg
	 *      The notification message
	 */
	private synchronized void handlePolicyDeleted(USMMessage msg) {
		LOGGER.debug("handlePolicyDeleted(" + msg + ")		Enter");
		// Fault ID 9 - NullPointerException in Authentication on Policy Deleted (both server and client)
		int nDeletedPolicyCount = msg.popInteger();
		for (int nPolicyIndex = 0;nPolicyIndex < nDeletedPolicyCount;++nPolicyIndex) {
			// Pop objects of type PAPolicyNameAndID
			PAPolicyId objPolicyNameAndId = new PAPolicyId();
			objPolicyNameAndId.popMe(msg);

			if (USMCommonHelper.isDetailedTracesEnabled() &&
				 LOGGER.isDebugEnabled()) {
				
				LOGGER.debug("Deleted policy details - ");
				LOGGER.debug("    Id - {0}", objPolicyNameAndId.getPolicyID());
				LOGGER.debug("    Name - {0}", objPolicyNameAndId.getPolicyName());

			}

			Integer objPolicyId = objPolicyNameAndId.getPolicyID();
			// Remove the Policy
			policyMap.remove(objPolicyId);
			// Cleanup all associated mappings
			Iterator<Entry<Integer, Set<Integer>>> iterClientMapping = mainCache.entrySet().iterator();
			while (iterClientMapping.hasNext()) {
				Entry<Integer, Set<Integer>> mapEntry = iterClientMapping.next();
				Set<Integer> setPolicyIds = mapEntry.getValue();
				// Remove the Policy Id from set
				setPolicyIds.remove(objPolicyId);
				if (setPolicyIds.size() == 0) {
					iterClientMapping.remove();
				}
			}
		}
		LOGGER.debug("handlePolicyDeleted(" + msg + ")		Exit");
	}

	/**
	 * Helper method for policy modification  Notifications	
	 * 
	 * @param msg
	 *      The notification message
	 */
	private synchronized void handlePolicyModified(USMMessage msg) {
		LOGGER.debug("handlePolicyModified(" + msg + ")		Enter");
		PAPolicyData objPolicy = new PAPolicyData();
		objPolicy.popMe(msg);

		if (USMCommonHelper.isDetailedTracesEnabled() && LOGGER.isDebugEnabled()) {
			LOGGER.debug("Modified policy details - ");
			LOGGER.debug("    Id - " + objPolicy.getPolicyID());
			LOGGER.debug("    Name - " + objPolicy.getPolicyName());
		}

		Integer objPolicyId = objPolicy.getPolicyID();
		// Fault ID 15 - Client Side authorization fails on Policy Creation
		if (policyMap.containsKey(objPolicyId)) {
			updatePolicyInMap(objPolicy);
		}
		LOGGER.debug("handlePolicyModified(" + msg + ")		Exit");
	}

	/**
	 * Helper method for policy map updation  Notifications	
	 * 
	 * @param objPolicy
	 *      policy details with updated maps
	 */
	private synchronized void updatePolicyInMap(PAPolicyData objPolicy) {
		LOGGER.debug("updatePolicyInMap(" + objPolicy + ")		Enter");
		Integer objPolicyId = objPolicy.getPolicyID();

		Set<String> permissionItems = policyMap.get(objPolicyId);
		if (null == permissionItems) {
			permissionItems = new HashSet<>();
		}
		permissionItems.clear();

		List<PAPermissionData> permissionDataList = objPolicy.getPermissionDataList();
		Set<PAPermissionItemData> permissionItemDataSet = new HashSet<>();
		for (PAPermissionData permission : permissionDataList){
			permissionItemDataSet.addAll(permission.getPermissionItems());
		}

		for (PAPermissionItemData permissionItem : permissionItemDataSet) {
			permissionItems.add(permissionItem.getName());
		}

		policyMap.put(objPolicyId, permissionItems);
		LOGGER.debug("updatePolicyInMap(" + objPolicy + ")		Exit");
	}

	/**
	     * Helper method for Cache dumping
	     */
	private synchronized void dumpCache() {
		if (LOGGER.isDebugEnabled()) {

			LOGGER.debug("Dumping the full cache contents : ");

			int nPolicyCount = policyMap.size();
			LOGGER.debug("Policy Count - " + nPolicyCount);

			for (Entry<Integer, Set<String>> mapEntry : policyMap.entrySet()) {
				int nPolicyValue = mapEntry.getKey();

				Set<String> setMenuEntries = mapEntry.getValue();

				LOGGER.debug("    Policy Id = " + nPolicyValue);
				LOGGER.debug("    Menus - ");

				for (String strMenuEntry : setMenuEntries) {
					LOGGER.debug("	- {0}", strMenuEntry);

				}
			}

			LOGGER.debug("Dumping the mappings : ");

			for (Entry<Integer, Set<Integer>> o : mainCache.entrySet()) {
				Integer objDomainId = o.getKey();
				Set<Integer> setPolicyIds = o.getValue();

				String strPolicyIds = setPolicyIds.toString();


				LOGGER.debug("   Domain - {0}, Policies - {1}", objDomainId, strPolicyIds);
			}

			LOGGER.debug("Dumping the securable objects : ");

			Stream<Entry<String,BitSet>> iterMOs = AAManagedObjectCache.getInstance().stream();
			iterMOs.forEach(mapEntry -> {
				String strMOId = mapEntry.getKey();
				BitSet bitsetACL = mapEntry.getValue();

				LOGGER.debug("   Object - {0}, ACL - {1}", strMOId, bitsetACL);
			});
		}
	}
}