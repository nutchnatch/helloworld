/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   UAJobCreateUserGroup
 * Author:      Jogender
 * Substitute	Babu B
 * Created on	12-09-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER_GROUP.CONFIGURE
         : TNMS.DX2.SM.USER_GROUP.CREATE
         : TNMS.DX2.SM.USER_GROUP.ASSIGN
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration.job;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.useradministration.UADelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserGroup;
import org.apache.log4j.Logger;

import java.util.List;

/**
 * This class represents a job that is responsible for creation of user groups
 */
public class UAJobCreateUserGroup extends USMJob {
	/**
	 * Data member to hold user group details
	 */
	private UAUserGroup userGroupData = null;
	
	/**
	 * Holds the mappings to assign to the user group that will be created
	 */
	private List<DCDomainMapping> mappingsForUserGroup = null;

	/**
	 * Data member to hold assigned users to user group
	 */
	private List<String> usersForUserGroup = null;
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(UAJobCreateUserGroup.class);

	/**
	 * This is the constructor
	 * 
	 * @param jobOwner -
	 *            The controller associated with the job
	 * @param userGroup -
	 *            User Group Object that is to be created
	 * @param mappingsForUserGroup List of domain and policy mappings to assign to the user group to be created.
	 */
	public UAJobCreateUserGroup(
		USMControllerIfc jobOwner,
		UAUserGroup userGroup,
		List<String> usersForUserGroup, List<DCDomainMapping> mappingsForUserGroup) {
		super(
			UAMessageType.S_UG_REQ_CREATE_USER_GROUP,
			USMCommonStrings.EMPTY,
			USMCommonStrings.EMPTY,
			jobOwner);
		this.userGroupData = userGroup;
		this.usersForUserGroup = usersForUserGroup;
		this.mappingsForUserGroup = mappingsForUserGroup;

		Object[] arr = { userGroup };
		String str =
			USMStringTable.IDS_UA_JOB_CREATE_USERGROUP.getFormatedMessage(arr);
		setName(str);
	}

	/**
	 * Executes the given job
	 *
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob#executeJob()
	 */
	@Override
	public USMMessage executeJob() {
		LOGGER.debug("executeJob() Enter");
		USMMessage msg =
			new UADelegate().createUserGroup(userGroupData, usersForUserGroup, mappingsForUserGroup);
		LOGGER.debug("executeJob() Exit");
		return msg;
	}

}
