/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AAUserProfileCache
 * Author      	Babu B
 * Substitute	Jogender Singh
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 * 16-Feb-2005	Muyeen Munaver	CF001454 - Wrong behavior in "Force logoff" for different scenarios
 * 20-02-2005	Muyeen Munaver  CF001451 - Load/save user profile does not work
 * 09-10-2007   Shrinidhi G V   CF004512-07  Improvement for server side filtering
 * 06-May-2009  Nagaraddi S S    TD004578 - RQT-STDERR errors instead log4j's
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.auth;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.auth.AAMessageType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import org.apache.log4j.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
*
* This class maintains a user profile cache 
*/
public final class AAUserProfileCache {

	/**
	 * Data member to hold self reference
	 */
	private static AAUserProfileCache self = new AAUserProfileCache();

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(AAUserProfileCache.class);

	/**
	 *  Data member to hold user profile cache    
	 */
	private Map objMaincache = new HashMap();

	/**
	* Clears the cache created on client side at login time.
	*/
	public synchronized void clearCache() {
		LOGGER.debug("clearCache  Entry");
		objMaincache.clear();
		LOGGER.debug("clearCache  Exit");
	}
	/**
	*Returns the profile created in cache from the server.	
	*@param appID - Common function unique id	
	*/
	public Properties getProfile(String appID) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("getProfile  Entry. App ID : " + appID);
		}

		Properties profile = new Properties();
		profile = (Properties) objMaincache.get(appID);
		if (profile == null) {
			profile = new Properties();
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("getProfile  Exit.");
		}
		return profile;
	}

	/**
	*Updates the profile created in cache from the client to server.	
	*@param appID - Common function unique id	
	*/
	public void setProfile(String appID, Properties profile) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"setProfile(" + appID + " ," + profile + ")  Entry");
		}

		//Updating client profile cache	
		objMaincache.put(appID, profile);
		//updating profile data on LDAP server
		AALoginBusinessDelegate aaDelegate = new AALoginBusinessDelegate();
		try {
			aaDelegate.setUserProfileCache(appID, profile);
		} catch (BcbSecurityException e) {
			LOGGER.error("BcbSecurityException at setProfile. ", e);
		} catch (Exception e) {
			LOGGER.error(
				"Type of Object is : "
					+ profile.getClass().getName()
					+ " Application ID : "
					+ appID);
			LOGGER.error("Exception at setProfile. ", e);
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"setProfile(" + appID + " ," + profile + ")  Exit");
		}
	}

	/**
	*Updates the profile created in cache from the client to server.	
	*@param appID - Application Unique Id	
	*/
	public void removeUserProfile(String appID) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"removeUserProfile(" + appID +")" + "Entry");
		}
		
		//Removing profile data on LDAP server
		AALoginBusinessDelegate aaDelegate = new AALoginBusinessDelegate();
		try {
			  
			  USMMessage msgResponse = aaDelegate.removeUserProfile(appID);
			  
			  LOGGER.debug(
						"Status of Profile Removal(" + appID +")" + msgResponse);
			  
             if(msgResponse != null)	{		  
			  USMBaseMsgType type =  msgResponse.getMessageType();
			    if(type.equals(AAMessageType.AA_USER_PROFILE_REMOVE_RESPONSE)){
			    	
			    	 LOGGER.debug(
								"Profile Removal in cache(" + appID +")" + msgResponse);
			    	 
					 if(msgResponse.popBoolean()){
						 
									 objMaincache.remove(appID);
									 
									 LOGGER.debug(
												"Profile Removed in Cache(" + appID +")" + msgResponse);

								}
							}
            }else{
            	LOGGER.info("Messsage Response from Remove User Profile is null");
					 }

		} catch (BcbSecurityException e) {
			LOGGER.error("BcbSecurityException at removeUserProfile. ", e);
		} catch (Exception e) {
			LOGGER.error(
				   " Application ID : "
					+ appID);
			LOGGER.error("Exception at removeUserProfile. ", e);
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"removeUserProfile(" + appID + ")" + "  Exit");
		}
	}
	
	
	/**
	*Returns the profile created in cache from the server.	
	*@param context - The Context for the current user	
	*/
	public void getUserProfileCacheData(ISessionContext context) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("getUserProfileCacheData Entry. " + context);
		}

		AALoginBusinessDelegate aadelegate = new AALoginBusinessDelegate();
		USMMessage profileMsg = null;
		try {
			profileMsg = aadelegate.getUserProfileCache(context);
		} catch (BcbSecurityException e) {
			LOGGER.error("Exception occured at getUserProfileCacheData. ", e);
		} catch (Exception e) {
			LOGGER.error("Exception at getProfile. : " + context, e);
		}

		if (profileMsg != null) {
			objMaincache = (Map) profileMsg.popObject();
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("getUserProfileCacheData Exit. " + context);
		}
	}
	/**
	 * Default Constructor
	 *
	*/
	private AAUserProfileCache() {
		super();
	}

	/**
	 * Function to return the singleton instance of the class
	 * 
	 * @return USMServerCache - 
	 * 			The singleton instance of the class.
	 * 
	 */
	public static AAUserProfileCache getInstance() {
		return self;
	}

	/**
	* Notification handler for all USM messages
	* 
	* @param msg - Message recieved for updating the client cache
	* 
	* @return boolean
	*      true if client security data was modified.
	*/
	public boolean handleNotification(USMMessage msg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handleNotification(" + msg + ")		Enter");
		}
		boolean bDataModified = false;

		USMBaseMsgType type = msg.getMessageType();

		if (type.equals(AAMessageType.AA_NOT_PROFILE_UPDATED)) {
			String userid = msg.popString();
			ISessionContext sc = USMUtility.getInstance().getSessionContext();
			if (sc != null && userid != null) {
				String userIDFromSession =
					((IEnhancedSessionContext) sc).getUserName();
				if (userIDFromSession.compareToIgnoreCase(userid) == 0) {
					String appUID = msg.popString();
					Properties profile = (Properties) msg.popObject();
					objMaincache.remove(appUID);
					objMaincache.put(appUID, profile);
				}
			}
		}else if (type.equals(AAMessageType.AA_NOT_PROFILE_DELETED)) {
			String userid = msg.popString();
			String appId = msg.popString();
			ISessionContext sc = USMUtility.getInstance().getSessionContext();
			if (sc != null && userid != null) {
				String userIDFromSession =
					((IEnhancedSessionContext) sc).getUserName();
				if (userIDFromSession.compareToIgnoreCase(userid) == 0) {
						objMaincache.remove(appId);				
				}
			}
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handleNotification(" + msg + ")		Exit");
		}
		return bDataModified;
	}
}