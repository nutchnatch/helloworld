/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Jogi			CF000060 - CF USM GUI Requirements
 * 09-02-2005	Babu B          CF000060-01   CF USM GUI Requirements
 * 14-June-2005  Asif  CF000209 - Changes in the ISecurityProviderFacade / IManagedObject
 * 06-May-2009  Nagaraddi S S    TD004578 - RQT-STDERR errors instead log4j's
 * The following fixes are done for this window: Fault 95  96  98  108  109
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain.common;

import com.coriant.widgets.togglebuttontree.ToggleButtonTreeSelectionModel;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandManager;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableBase;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObjectContainer;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.tools.jfx.JfxAction;
import com.ossnms.tools.jfx.JfxActionPerformed;
import com.ossnms.tools.jfx.JfxFormPanel;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxButtonMenu;
import com.ossnms.tools.jfx.components.JfxCheckBox;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxMenuItem;
import com.ossnms.tools.jfx.components.JfxTextField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import static com.ossnms.bicnet.securitymanagement.client.domain.common.SecurableObjectContainerFilterEnum.CONTAINER;
import static com.ossnms.bicnet.securitymanagement.client.domain.common.SecurableObjectContainerFilterEnum.MEDIATOR;
import static com.ossnms.bicnet.securitymanagement.client.domain.common.SecurableObjectContainerFilterEnum.NETWORK_DOMAIN;
import static com.ossnms.bicnet.securitymanagement.client.domain.common.SecurableObjectFilterEnum.NE;
import static com.ossnms.bicnet.securitymanagement.client.domain.common.SecurableObjectFilterEnum.SUBSCRIBERS;
import static com.ossnms.bicnet.securitymanagement.client.domain.common.ServerTypeFilterEnum.COMMON_SERVICE_LIST;
import static com.ossnms.bicnet.securitymanagement.client.domain.common.ServerTypeFilterEnum.DCN_MANAGER;

/**
 * This is a base class for the create/modify window of domain. This window has
 * a left and right tree pane associated with it that displays the objects.
 * Hence also implements the TreeSelectionListener useful for transferring nodes
 * across panes.
 */
public abstract class DCCreateModifyBaseView extends USMBaseViewWithButtons implements TreeSelectionListener {

	private static final long serialVersionUID = 1306944606450699854L;

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(DCCreateModifyBaseView.class);

	/**
	 * Text field for holding the name.
	 */
	protected JfxTextField txtFldName = null;

	/**
	 * Text field for holding the description.
	 */
	protected JfxTextField txtDesc = null;

	/**
	 * Check box to open the associated window after clicking on the OK button.
	 */
	private JfxCheckBox cbOpenWdw = null;

	private SecurableObjectToggleButtonTree itemsTree;

	private JfxMenuItem itemMediator;

	private JfxMenuItem itemDomain;
	
	private JfxMenuItem itemContainer;

	private JfxMenuItem itemNE;

	private JfxMenuItem itemSubscribers;

	private JfxButtonMenu buttonMenu;

	private JfxButtonMenu buttonManagedObjectTypesMenu;

	private Map<BSTransBicNetCFInfo, List<BSSecurableObject>> securableObjectsLocalCache;

	private List<BSSecurableObject> selectedSecurableObject = new ArrayList<>();

	private List<BSSecurableObject> unSelectedSecurableObject = new ArrayList<>();

	/**
	 * Constructor
	 * 
	 * @param vecObjs List containing the Buttons that need to be displayed
	 * @param strID The fully qualified name of the concrete class
	 * @param strTitle The Title of the Window
	 * @param resizable Indicates whether the View is resizable or not
	 * @param helpId The Help ID that is associated with the concrete class
	 */
	protected DCCreateModifyBaseView(List<USMButtonType> vecObjs, List<USMButtonType> commitButtons, List<USMButtonType> functionButtons, String strID, String strTitle, boolean resizable, int helpId) {
		super(vecObjs, commitButtons, functionButtons, strID, strTitle, resizable, false, helpId);
		initComponents();

		setNamesForTesting();

		// Associate the render with the tree, informing if NEs belong to global
		// domain only
		DCDomainRenderer renderer = new DCDomainRenderer();
		itemsTree.setCellRenderer(renderer);
	}

	/**
	 * Helper function that is used to set the Names of all the editable
	 * components within the Window. Strings in this function are not to be
	 * Internationalized.
	 */
	private void setNamesForTesting() {
		txtFldName.setName("Name");
		txtDesc.setName("Description");
		itemsTree.setName("SecurableObjectTree");
		cbOpenWdw.setName("OpenDomainAdministrationWindow");
	}

	/**
	 * This method is called from the constructor to initialize all the GUI
	 * objects of the window.
	 */
	private void initComponents() {
		cbOpenWdw = new JfxCheckBox();

		Dimension listMinDimension = new Dimension(35, 50);

		JfxFormPanel mainPanel = getPanelForPlacingDerviedControls();
		mainPanel.setLayout(new GridBagLayout());
		mainPanel.setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);
		mainPanel.setMinimumSize(new Dimension(200, 200));
		mainPanel.setPreferredSize(new Dimension(450, 350));

		/*
	  		To hold the label for the Name.
	 	*/
		JfxLabel lblName = new JfxLabel(USMStringTable.IDS_DC_NAME);
		lblName.setLabelAndMnemonicFor(txtFldName);
		txtFldName = new JfxTextField("");
		txtFldName.limitText(64);
		txtFldName.setMandatoryEntry(true);

		/*
	  		To hold the label for the description.
	 	*/
		JfxLabel lblDesc = new JfxLabel(USMStringTable.IDS_DC_DESCRIPTION);
		lblDesc.setLabelAndMnemonicFor(txtDesc);
		txtDesc = new JfxTextField("");
		txtDesc.limitText(128);

		JPanel nameAndDescriptionPanel = new JPanel();
		nameAndDescriptionPanel.setLayout(new GridBagLayout());
		
		
		JPanel availableObjectsTreeViewPane = new JPanel();
		availableObjectsTreeViewPane.setLayout(new GridBagLayout());

		itemsTree = new SecurableObjectToggleButtonTree();
		itemsTree.setRootVisible(false);
		itemsTree.setShowsRootHandles(true);
		itemsTree.setDigInMode(true);

		// Set up Available objects
		JfxLabel availableObjectsLabel = new JfxLabel(USMStringTable.IDS_DC_ASSIGNED_OBJECTS);
		availableObjectsLabel.setLabelAndMnemonicFor(itemsTree);
		availableObjectsLabel.setAlignmentX(LEFT_ALIGNMENT);

		JScrollPane availableObjectsPane = new JScrollPane();
		availableObjectsPane.setAlignmentX(LEFT_ALIGNMENT);
		availableObjectsPane.setMinimumSize(listMinDimension);
		availableObjectsPane.setPreferredSize(listMinDimension);
		availableObjectsPane.setViewportView(itemsTree);

		initButtons();

		nameAndDescriptionPanel.add(lblName, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
		nameAndDescriptionPanel.add(txtFldName, new GridBagConstraints(1, 0, 0, 1, 1.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
		nameAndDescriptionPanel.add(lblDesc, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
		nameAndDescriptionPanel.add(txtDesc, new GridBagConstraints(1, 1, 1, 1, 1.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
		
		mainPanel.add(nameAndDescriptionPanel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
				
		availableObjectsTreeViewPane.add(availableObjectsLabel, 	    new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.WEST, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
		availableObjectsTreeViewPane.add(buttonManagedObjectTypesMenu, 	new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.EAST, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
		availableObjectsTreeViewPane.add(buttonMenu, 				    new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.EAST, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));

		mainPanel.add(availableObjectsTreeViewPane, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
		mainPanel.add(availableObjectsPane, new GridBagConstraints(0, 2, 1, 1, 1.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));

		itemsTree.getToggleButtonTreeSelectionModel().addTreeSelectionListener(this);

		txtFldName.setFocusable(true);
		txtFldName.requestFocus();

		this.setPreferredSize(new Dimension(450, 450));
	}

	/**
	 * This is the implemented method that gets called when a value or selection
	 * changes. This decides what buttons have to be enabled and disabled.
	 *
	 * @param evt The Java TreeSelectionEvent.
	 */
	@Override
	public void valueChanged(TreeSelectionEvent evt) {
		LOGGER.debug("Create/Modify value changed :: {}", evt.toString());

		SecurableObjectTreeNode treeNode = (SecurableObjectTreeNode) evt.getPath().getLastPathComponent();
		if(treeNode.getUserObject() instanceof BSSecurableObject){
			final BSSecurableObject selectedObject = (BSSecurableObject) treeNode.getUserObject();
			selectSecurableObjects(selectedObject, evt.isAddedPath());
		} else if(treeNode.getUserObject() instanceof BSSecurableObjectContainer){
			final BSSecurableObjectContainer selectedObjectContainer = (BSSecurableObjectContainer) treeNode.getUserObject();
			selectSecurableObjects(selectedObjectContainer, evt.isAddedPath());
		}
	}

	/**
	 *
	 * @param container
	 * @param select
     */
	private void selectSecurableObjects(BSSecurableObjectContainer container, boolean select){
		// go through the containers
		List<BSSecurableObject> toSelect = securableObjectsLocalCache
				.values()
				.stream()
				.flatMap(Collection::stream)
				.filter(securableObject -> securableObject.getObjectContainers().contains(container))
				.collect(Collectors.toList());

		selectSecurableObjects(toSelect, select);
	}

	/**
	 *
	 * @param object
	 * @param select
     */
	private void selectSecurableObjects(BSSecurableObject object, boolean select){
		object.getObjectContainers()
				.stream()
				// if the container is compound (and should be treated as a single unit)
				.filter(BSSecurableObjectContainer::isCompound)
				.forEach(container -> {
					LOGGER.warn("Securable Object belongs to a system container...adding children.");
					selectSecurableObjects(container, select);
				});
	}

	/**
	 *
	 * @param securableObjects
	 */
	private void selectSecurableObjects(List<BSSecurableObject> securableObjects, boolean select){
		LOGGER.info("selecting securable objects...");
		List<TreePath> selectionPaths = new ArrayList<>();

		securableObjects
				.stream()
				.forEach(base -> {
					List<TreePath> treePaths = itemsTree.findNodePath(base, itemsTree.getRootNode());

					for (TreePath path : treePaths) {
						// fetch the selection model
						ToggleButtonTreeSelectionModel<SecurableObjectTreeNode> selectionModel = itemsTree.getToggleButtonTreeSelectionModel();
						// control selection or de-selection
						if (select && !selectionModel.isPathSelected(path, true)) {
							selectionPaths.add(path);
						} else if (!select && selectionModel.isPathSelected(path, true)) {
							selectionPaths.add(path);
						}
					}
				});

		if(selectionPaths.size() > 0){
			ToggleButtonTreeSelectionModel<SecurableObjectTreeNode> selectionModel = itemsTree.getToggleButtonTreeSelectionModel();
			selectionModel.removeTreeSelectionListener(this);

			if(select){
				selectionModel.addSelectionPaths(selectionPaths.toArray(new TreePath[selectionPaths.size()]));
			}else{
				selectionModel.removeSelectionPaths(selectionPaths.toArray(new TreePath[selectionPaths.size()]));
			}

			selectionModel.addTreeSelectionListener(this);
		}
	}


	/**
	 * This function is used to return the corresponding proxy associated with
	 * this window.
	 * 
	 * @return Returns the type casted proxy associated with this window.
	 */
	protected DCCreateModifyDomainProxy getProxy() {
		return (DCCreateModifyDomainProxy) associatedClientController;
	}

	/**
	 * Gets the name as entered by the user.
	 * 
	 * @return Returns the name of the domain as entered by the user.
	 */
	@Override
	public final String getName() {
		return txtFldName.getText();
	}

	/**
	 * Gets the description as entered by the user.
	 * 
	 * @return Returns the description of the domain as entered by the user.
	 */
	public final String getDescr() {
		return txtDesc.getText();
	}

	/**
	 * Sets the description as entered by the user.
	 * 
	 * @param strText
	 *            Description of the domain as entered by the user.
	 */
	final void setDescr(String strText) {
		txtDesc.setText(strText);
	}

	/**
	 * Function to check if the check-box is currently checked or not.
	 * 
	 * @return Returns true if the check box was selected.
	 */
	private boolean isOpenWdwChecked() {
		return cbOpenWdw.isSelected();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.view.
	 * USMBaseView_BtnPnl_StatusBar#handleButtonClick(com.ossnms
	 * .bicnet.securitymanagement.client.basic.view.USMButtonType)
	 */
	// Fault ID 42 - Provide Button Level Authorization for Windows - Begin
	@Override
	public void handleButtonClick(USMButtonTypeEnum type) {
		if ((USMButtonTypeEnum.BTN_TYPE_CANCEL).equals(type)) {
			closeWindow();
		} else {
			LOGGER.info("unexpected...");
		}
	}

	/**
	 *
	 */
	void openAssociatedWindow() {
		if (isOpenWdwChecked()) {
			USMCommandManager cMger = USMCommandManager.getInstance();
			cMger.executeCmd(USMCommandID.S_UI_ID_VIEW_DOMAINS);
		}
	}

	/**
	 * close the administrator window
	 */
	void closeWindow() {

		close();
	}

	/**
	 * Sets all securable object from server
	 * 
	 * @param securableObjects the map which holds the list of securable Objects
	 */
	final void setAllSecurableObjectsFromServer(Map<BSTransBicNetCFInfo, List<BSSecurableObject>> securableObjects) {
		securableObjectsLocalCache = new HashMap<>(securableObjects);

		// gets the selected domain to modify or create
		DCDomainData selectedDomain = getProxy().modifiedDomain;

		// Global domain
		int selectedDomainId = 0;
		if (selectedDomain != null) {
			selectedDomainId = selectedDomain.getDomainID();
		}

		for (Entry<BSTransBicNetCFInfo, List<BSSecurableObject>> entry : securableObjects.entrySet()) {
			BSTransBicNetCFInfo bicNetCFInfo = entry.getKey();

            if(bicNetCFInfo.getComponentType() != itemsTree.getServerTypeFilter().getServerType()){
                continue;
            }

			if(itemsTree.getRootNode(bicNetCFInfo) == null){
				// insert the root node and expand
				itemsTree.insertRootNode(bicNetCFInfo);
			}

			List<BSSecurableObject> securableObjectList = entry.getValue();

			insertSecurableObjects(bicNetCFInfo, securableObjectList);
			List<TreePath> selectedPaths = new ArrayList<>();

			for (BSSecurableObject securObj : securableObjectList) {
				// see if belongs to selected domain
				if (!unSelectedSecurableObject.contains(securObj)) {
					if (selectedDomainId != 0 && securObj.belongsToDomain(selectedDomainId) || selectedSecurableObject.contains(securObj)) {
						selectedPaths.addAll(itemsTree.findNodePath(securObj, itemsTree.getRootNode()));
					}
				}
			}

			if (selectedPaths.size() > 0) {
				itemsTree.getToggleButtonTreeSelectionModel().removeTreeSelectionListener(this);
				itemsTree.getToggleButtonTreeSelectionModel().addSelectionPaths(selectedPaths.toArray(new TreePath[selectedPaths.size()]));
				itemsTree.getToggleButtonTreeSelectionModel().addTreeSelectionListener(this);
			}

			itemsTree.reload();
		}
	}

	/**
	 * Fill the tree, on the right, with the available securable objects. If it
	 * is a create domain all the securable object are all not assigned. If it
	 * is a modify domain there can be already some securable objects assigned.
	 * 
	 * @param bicNetCFInfo function
	 * @param availableSecurableObject securable objects to add onto the tree
	 */
	private void insertSecurableObjects(BSTransBicNetCFInfo bicNetCFInfo, List<BSSecurableObject> availableSecurableObject) {
		if (availableSecurableObject != null && availableSecurableObject.size() > 0) {
			itemsTree.insertSecurableObjects(availableSecurableObject, bicNetCFInfo);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getComponent()
	 */
	@Override
	public JComponent getComponent() {
		return this;
	}

	/**
	 * Displays message dialog
	 * 
	 * @param aString Message to be display
	 */
	public void showMessage(String aString) {
		bringToFront();
		JfxOptionPane.showMessageBox(this, aString, JOptionPane.CLOSED_OPTION, JOptionPane.ERROR_MESSAGE);
	}

	/**
	 * @param server
	 */
	void deleteServer(BSTransBicNetCFInfo server) {
		itemsTree.deleteRootNode(server);
	}

	/**
	 * This method renames the server displayed. It identifies based on the
	 * server id.
	 * 
	 * @param appServerInfo The server which was renamed.
	 */
	void renameServer(BSTransBicNetCFInfo appServerInfo) {
		itemsTree.renameFunction(appServerInfo);
	}

	/**
	 * This function to inform that the NEs have been assigned/unassigned from a
	 * domain and the colour has to change approrpriately
	 * 
	 * @param nes The Nes which have been assigned/unassigned
	 */
	void domainsAssignUnAssigned(List nes) {
		itemsTree.updateNeUserObjects(nes);
	}

	/**
	 * This method is used to delete/remove the securable objects based on a
	 * notification recieved informing sec object has been unregsitered
	 * 
	 * @param bicNetCFInfo The owner of the CF for which the sec object was removed
	 * @param lstSecObjs List of BSSecurableObject info which have been unregistered
	 */
	void deleteSecurableObjects(BSTransBicNetCFInfo bicNetCFInfo, List<BSSecurableObject> lstSecObjs) {
		itemsTree.deleteSecurableObjects(lstSecObjs, bicNetCFInfo);
		// update cache
		lstSecObjs.forEach(securableObject -> deleteSecurableObjectFromCache(bicNetCFInfo, securableObject));
	}

	/**
	 *
	 * @param function
	 * @param securableObject
     */
	private void deleteSecurableObjectFromCache(BSTransBicNetCFInfo function, BSSecurableObject securableObject){
		// get the cached object
		List<BSSecurableObject> cachedObjects = securableObjectsLocalCache.get(function);
		int index = cachedObjects.indexOf(securableObject);
		BSSecurableObject cachedObject = cachedObjects.get(index);

		// remove the object from his containers
		cachedObject.getObjectContainers().forEach(
				container -> {
					container.getChildObjects().remove(cachedObject);
				}
		);

		// remove the containers from the list
		cachedObject.getObjectContainers().clear();

		// remove the object (call the map again for emotional comfort)
		securableObjectsLocalCache.get(function).remove(cachedObject);
	}

	/**
	 * This method is used to modify the securable objects based on a
	 * notification recieved informing sec object has been modified
	 * 
	 * @param bicNetCFInfo The owner of the CF for which the sec object was added
	 * @param lstSecObjs List of BSSecurableObject info which have been modified
	 */
	void modifySecurableObjects(BSTransBicNetCFInfo bicNetCFInfo, List<BSSecurableObject> lstSecObjs) {
		List<BSSecurableObject> modifiedCachedObjects = modifySecurableObjectsFromCache(bicNetCFInfo, lstSecObjs);
		itemsTree.modifySecurableObjects(modifiedCachedObjects, bicNetCFInfo);
	}

	/**
	 *
	 * @param function
	 * @param securableObjects
     */
	private List<BSSecurableObject> modifySecurableObjectsFromCache(BSTransBicNetCFInfo function, List<BSSecurableObject> securableObjects){
		return securableObjects.stream().map(object -> modifySecurableObjectFromCache(function, object)).collect(Collectors.toList());
	}

	/**
	 *
	 * @param function
	 * @param securableObject
     */
	private BSSecurableObject modifySecurableObjectFromCache(BSTransBicNetCFInfo function, BSSecurableObject securableObject){
		// retrieve the cached object
		int index = securableObjectsLocalCache.get(function).indexOf(securableObject);
		BSSecurableObject cachedObject = securableObjectsLocalCache.get(function).get(index);

		// update the details of the securable object
		cachedObject.setDisplayName(securableObject.getDisplayName());
		cachedObject.setACL(securableObject.getACL());

		// get the containers to assign the object to
		List<BSSecurableObjectContainer> containersToAssign = securableObject.getObjectContainers()
				.stream()
				.filter(container -> !cachedObject.getObjectContainers().contains(container))
				.collect(Collectors.toList());

		// get the containers to unassign the object to
		List<BSSecurableObjectContainer> containersToUnassign = cachedObject.getObjectContainers()
				.stream()
				.filter(cachedContainer -> !securableObject.getObjectContainers().contains(cachedContainer))
				.collect(Collectors.toList());

		if(containersToAssign.size() > 0) {
			// retrieve the cached containers
			List<BSSecurableObjectContainer> cachedContainers = securableObjectsLocalCache.get(function)
					.stream()
					.map(BSSecurableBase::getObjectContainers)
					.flatMap(Collection::stream)
					.distinct()
					.collect(Collectors.toList());

			containersToAssign.forEach(container -> {
				int containerIndex = cachedContainers.indexOf(container);
				BSSecurableObjectContainer cachedContainer = cachedContainers.get(containerIndex);

				cachedContainer.getChildObjects().add(cachedObject);
				cachedObject.getObjectContainers().add(cachedContainer);
			});

		}

		if(containersToUnassign.size() > 0){
			containersToUnassign.forEach(container -> {
				container.getChildObjects().remove(cachedObject);
				cachedObject.getObjectContainers().remove(container);
			});
		}

		return cachedObject;
	}

	/**
	 * This method is used to add the securable objects based on a notification
	 * recieved informing sec object has been regsitered. They, at first, are
	 * all unregistered.
	 * 
	 * @param bicNetCFInfo The owner of the CF for which the sec object was added
	 * @param lstSecObjs List of BSSecurableObject info which have been registered
	 */
	void addSecurableObjects(BSTransBicNetCFInfo bicNetCFInfo, List<BSSecurableObject> lstSecObjs) {
		if (lstSecObjs.size() > 0) {
			List<BSSecurableObject> cachedObjects = lstSecObjs
					.stream()
					.map(securableObject -> addSecurableObjectFromCache(bicNetCFInfo, securableObject))
					.collect(Collectors.toList());

			itemsTree.insertSecurableObjects(cachedObjects, bicNetCFInfo);
		}
	}

	/**
	 *
	 * @param function
	 * @param securableObject
     */
	private BSSecurableObject addSecurableObjectFromCache(BSTransBicNetCFInfo function, BSSecurableObject securableObject){
		// get the cached objects
		List<BSSecurableObject> cachedObjects = securableObjectsLocalCache.get(function);

		// get the list of cached containers
		List<BSSecurableObjectContainer> cachedContainers = cachedObjects
				.stream()
				.map(BSSecurableBase::getObjectContainers)
				.flatMap(Collection::stream)
				.distinct()
				.collect(Collectors.toList());

		// replace the containers with the cached version
		List<BSSecurableObjectContainer> containerList = securableObject.getObjectContainers()
				.stream()
				.map(container -> {
					if(cachedContainers.contains(container)){
						int index = cachedContainers.indexOf(container);
						return cachedContainers.get(index);
					}else{
						return container;
					}
				}).collect(Collectors.toList());

		securableObject.setObjectContainers(containerList);

		// add the object to its containers
		containerList.forEach(container -> container.addChildObject(securableObject));
		cachedObjects.add(securableObject);

		return securableObject;
	}

	/**
	 *
	 * @param cf
	 * @param securableContainers
     */
	void modifySecurableObjectContainers(BSTransBicNetCFInfo cf, List<BSSecurableObjectContainer> securableContainers) {
		itemsTree.modifySecurableObjectContainers(securableContainers, cf);
	}

	protected List<BSSecurableObject> getAssignedObjects() {
		List<BSSecurableObject> securableObjects = new ArrayList<>();

		itemsTree.getTreePaths()
				.stream()
				.filter(path -> itemsTree.getToggleButtonTreeSelectionModel().isPathSelected(path, itemsTree.isDigInMode()))
				.forEach(path -> {
					SecurableObjectTreeNode node = (SecurableObjectTreeNode) path.getLastPathComponent();
					if (node.getUserObject() instanceof BSSecurableObject) {
						BSSecurableObject secObject = (BSSecurableObject) node.getUserObject();
						if (!securableObjects.contains(secObject)) {
							securableObjects.add((BSSecurableObject) node.getUserObject());
						}
					}
				});

		return securableObjects;
	}

	protected List<BSSecurableObject> getUnassignedObjects() {
		List<BSSecurableObject> securableObjects = new ArrayList<>();
		List<BSSecurableObject> assignedObjects = getAssignedObjects();

		itemsTree.getTreePaths()
				.stream()
				.filter(path -> !itemsTree.getToggleButtonTreeSelectionModel().isPathSelected(path, itemsTree.isDigInMode()))
				.forEach(path -> {
					SecurableObjectTreeNode node = (SecurableObjectTreeNode) path.getLastPathComponent();
					if (node.getUserObject() instanceof BSSecurableObject) {
						BSSecurableObject secObject = (BSSecurableObject) node.getUserObject();
						if (!assignedObjects.contains(secObject)) {
							securableObjects.add((BSSecurableObject) node.getUserObject());
						}
					}
				});
		return securableObjects;
	}

    /**
     * Initializes toolbar button actions
     */
    private void initButtons() {
        initViewButtons();
        initMObjectTypeButtons();
    }

	/**
	 * Initializes toolbar button actions
	 */
	private void initViewButtons() {
		itemMediator = new JfxMenuItem(new NeActionSelect().mediator());
		itemMediator.setSelected(true);
		itemDomain = new JfxMenuItem(new NeActionSelect().domain());
		itemMediator.setSelected(false);
		itemContainer = new JfxMenuItem(new NeActionSelect().container());
		itemContainer.setSelected(false);

		buttonMenu = new JfxButtonMenu(USMStringTable.MEDIATOR_VIEW, ResourcesIconFactory.ICON_TOOL_TREE_VIEW_16);
		buttonMenu.add(itemMediator);
		buttonMenu.add(itemDomain);
		buttonMenu.add(itemContainer);
	}

    /**
     * Initializes Managed Object Type button actions
     */
    private void initMObjectTypeButtons() {

        itemNE = new JfxMenuItem(new MoTypeActionSelect().ne());
        itemNE.setSelected(true);
        itemSubscribers = new JfxMenuItem(new MoTypeActionSelect().subscribers());
        itemSubscribers.setSelected(false);

        buttonManagedObjectTypesMenu = new JfxButtonMenu(USMStringTable.NE_MOTYPE, ResourcesIconFactory.ICON_TOOL_TREE_VIEW_16);
        buttonManagedObjectTypesMenu.add(itemNE);
        buttonManagedObjectTypesMenu.add(itemSubscribers);

    }

    /**
     * Class that handles Managed Object Type selection change.
     */
    private class MoTypeActionSelect{

        JfxAction ne() {
            return new JfxAction(USMStringTable.NE_MOTYPE, USMStringTable.NE_MOTYPE, "93365D0E110e2F81", new PerformOpenNeMoType(), null, null);
        }

        JfxAction subscribers() {
            return new JfxAction(USMStringTable.SUBSCRIBER_MOTYPE, USMStringTable.SUBSCRIBER_MOTYPE, "93365D0E110e2F81", new PerformOpenSubscriberMoType(), null, null);
        }

        private class PerformOpenNeMoType implements JfxActionPerformed {
            @Override
            public void actionPerformed(final JfxAction action) {

                buttonManagedObjectTypesMenu.setText(USMStringTable.NE_MOTYPE);
                buttonManagedObjectTypesMenu.setToolTipText(USMStringTable.NE_MOTYPE);

                itemsTree.setServerTypeFilter(DCN_MANAGER);
                itemsTree.setObjectFilter(NE);

                itemNE.setSelected(true);
                itemSubscribers.setSelected(false);

                buttonMenu.setEnabled(true);

                JfxAction mediatorAction = new NeActionSelect().mediator();
                mediatorAction.actionPerformed(null);

            }
        }

        private class PerformOpenSubscriberMoType implements JfxActionPerformed {
            @Override
            public void actionPerformed(final JfxAction action) {

                buttonManagedObjectTypesMenu.setText(USMStringTable.SUBSCRIBER_MOTYPE);
                buttonManagedObjectTypesMenu.setToolTipText(USMStringTable.SUBSCRIBER_MOTYPE);

                itemsTree.setServerTypeFilter(COMMON_SERVICE_LIST);
                itemsTree.setFilter(null);
                itemsTree.setObjectFilter(SUBSCRIBERS);

                itemMediator.setSelected(true);
                itemDomain.setSelected(false);
                itemContainer.setSelected(false);

                itemNE.setSelected(false);
                itemSubscribers.setSelected(true);

                buttonMenu.setEnabled(false);

                selectedSecurableObject = getAssignedObjects();
                unSelectedSecurableObject = getUnassignedObjects();

                itemsTree.clear();
                itemsTree.reload();

                setAllSecurableObjectsFromServer(securableObjectsLocalCache);

            }
        }

    }


	/**
	 *
	 */
	private class NeActionSelect {

		JfxAction mediator() {
			return new JfxAction(USMStringTable.MEDIATOR_VIEW, USMStringTable.MEDIATOR_VIEW, "93365D0E110e2F81", new PerformOpenMediatorView(), null, null);
		}

		JfxAction domain() {
			return new JfxAction(USMStringTable.DOMAIN_VIEW, USMStringTable.DOMAIN_VIEW, "93365D0E110e2F81", new PerformOpenDomainView(), null, null);
		}

		JfxAction container() {
			return new JfxAction(USMStringTable.CONTAINER_VIEW, USMStringTable.CONTAINER_VIEW, "93365D0E110e2F81", new PerformOpenContainerView(), null, null);
		}

		private class PerformOpenMediatorView implements JfxActionPerformed {
			@Override
			public void actionPerformed(final JfxAction action) {
				buttonMenu.setText(USMStringTable.MEDIATOR_VIEW);
				buttonMenu.setToolTipText(USMStringTable.MEDIATOR_VIEW);

				itemMediator.setSelected(true);
				itemDomain.setSelected(false);
				itemContainer.setSelected(false);

				itemsTree.setFilter(MEDIATOR);

				selectedSecurableObject = getAssignedObjects();
				unSelectedSecurableObject = getUnassignedObjects();

				itemsTree.clear();
				itemsTree.reload();

				setAllSecurableObjectsFromServer(securableObjectsLocalCache);
			}
		}

		private class PerformOpenDomainView implements JfxActionPerformed {
			@Override
			public void actionPerformed(final JfxAction action) {
				buttonMenu.setText(USMStringTable.DOMAIN_VIEW);
				buttonMenu.setToolTipText(USMStringTable.DOMAIN_VIEW);

				itemDomain.setSelected(true);
				itemMediator.setSelected(false);
				itemContainer.setSelected(false);

				itemsTree.setFilter(NETWORK_DOMAIN);

				selectedSecurableObject = getAssignedObjects();
				unSelectedSecurableObject = getUnassignedObjects();

				itemsTree.clear();
				itemsTree.reload();

				setAllSecurableObjectsFromServer(securableObjectsLocalCache);
			}
		}

		private class PerformOpenContainerView implements JfxActionPerformed {
			@Override
			public void actionPerformed(final JfxAction action) {
				buttonMenu.setText(USMStringTable.CONTAINER_VIEW);
				buttonMenu.setToolTipText(USMStringTable.CONTAINER_VIEW);


				itemMediator.setSelected(false);
				itemDomain.setSelected(false);
				itemContainer.setSelected(true);

				itemsTree.setFilter(CONTAINER);

				selectedSecurableObject = getAssignedObjects();
				unSelectedSecurableObject = getUnassignedObjects();

				itemsTree.clear();
				itemsTree.reload();

				setAllSecurableObjectsFromServer(securableObjectsLocalCache);
			}
		}

	}
}
