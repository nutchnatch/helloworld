/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	IEExportJob
 * Author      	Asifulla Khan
 * Substitute	Muyeen Munaver
 * Created on	07-12-2004
 *
 * --------------------------------------------------------
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : 	TNMS.DX2.SM.EXPORT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.importexport;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.tools.jfx.JfxStringTable;
import org.apache.log4j.Logger;

/**
 * Job which is to be used for the exporting of data.
 */
public class IEExportJob extends USMJob {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(IEExportJob.class);

	/**
	 * Data member which holds the kind of data to be exported.
	 */
	String mType;

	/**
	 * Constructor
	 * @param pId The Message Type.
	 * @param pJobOwner The Owner of the Job
	 * @param pType String indicating the type of object to be exported.
	 */
	protected IEExportJob(
		USMBaseMsgType pId,
		USMControllerIfc pJobOwner,
		String pType) {
		super(
			pId,
			JfxStringTable.getString(USMStringTable.IDS_IE_JOB_EXPORT_JOB),
			JfxStringTable.getString(USMStringTable.IDS_IE_JOB_DESC_EXPORT_JOB),
			pJobOwner);
		mType = pType;
		LOGGER.debug("IEExportJob constructor  type = " + pType);
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob#executeJob()
	 */
	@Override
    public USMMessage executeJob() throws BcbSecurityException {
		LOGGER.debug("executeJob() - Entry");
		IEBusinessDelegate delgate = new IEBusinessDelegate();

		USMMessage msg = delgate.exportSecurityData(mType);
		LOGGER.debug("executeJob() - Exit");
		return msg;

	}

}
