/*
*
* Copyright (C)        Coriant 2013
* All Rights reserved.
*/
package com.ossnms.bicnet.securitymanagement.client.policy.jobs;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.policy.PABusinessDelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.policy.PAMessageType;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import org.apache.log4j.Logger;

import java.rmi.RemoteException;
import java.util.List;

/**
 * 
 * This class represents a Job that is responsible for sending a request
 * to delete a specific policies.
 */
public class PAJobDeletePolicies extends USMJob {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(PAJobDeletePolicies.class);

	/**
	 * Data member to hold the list of Policies that have to be deleted.
	 */
	private List<PAPolicyId> lstPolicies;

	/**
	 * Constructor
	 * 
	 * @param jobOwner The owner of the Job.
	 * @param policies The List of Policies that have to be deleted.
	 */
	public PAJobDeletePolicies(USMControllerIfc jobOwner, List<PAPolicyId> policies) {
		// This needs to be updated. We need to send a Request not a 
		super(
			PAMessageType.S_PA_REQ_POLICY_DELETED,
			USMCommonStrings.EMPTY,
			USMCommonStrings.EMPTY,
			jobOwner);
		lstPolicies = policies;

		String str;
		if (policies.size() == 1) {
			Object[] arr = { policies.get(0)};
			str = USMStringTable.IDS_PA_JOB_DELETE_POLICY_SINGLE.getFormatedMessage(arr);
		} else {
			Object[] arr = { policies.size()};
			str = USMStringTable.IDS_PA_JOB_DELETE_POLICY_MULTI.getFormatedMessage(arr);
		}
		setName(str);
		LOGGER.debug("PAJobDeletePolicies() In the constructor");

	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob#executeJob()
	 */
	@Override
    public USMMessage executeJob() throws BcbSecurityException {
		LOGGER.debug("executeJob()in the method");

		USMMessage msg = null;
		try {
			msg = new PABusinessDelegate().deletePolicies(lstPolicies);
		} catch (RemoteException e) {
			LOGGER.error("executeJob() error in getting response");

		}
		return msg;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.common.controller.USMJob#executeJob()
	 */

}