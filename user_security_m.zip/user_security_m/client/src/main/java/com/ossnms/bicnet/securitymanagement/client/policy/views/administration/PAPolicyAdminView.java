/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Jogi			CF000060 - CF USM GUI Requirements
 * 18-Jan-2005	Muyeen Munaver	CF00702 - The "OK" could became Grey in the "New User" window
 * 09-Feb-2005	Babu B          CF000060-01   CF USM GUI Requirements
 * 26-Apr-2005	Asif			CF000834 - Command Log Entries	CF USM
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.policy.views.administration;

import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandManager;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMHelp;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMMouseAdapter;
import com.ossnms.bicnet.securitymanagement.client.policy.common.PermissionList;
import com.ossnms.bicnet.securitymanagement.client.policy.views.base.PAUpdateHint;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMenuNameList;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import com.ossnms.tools.jfx.JfxFormPanel;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxText;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxList;
import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * This class models the Policy Administration Window.
 * Enables the NGPM User to
 * View All the Configured Policies.
 * View All the Configured menu options of a Configured Policy.
 */
public class PAPolicyAdminView extends USMBaseViewWithButtons implements ListSelectionListener {
    private static final long serialVersionUID = -3668059847069182872L;

    /**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(PAPolicyAdminView.class);
    private static final String METHOD_ON_MODIFY_CLICKED = "OnModifyButtonClicked()";

    /**
	 * This member holds the Data about the window.
	 */
	private transient PAPolicyAdminDataHolder data;

	private DefaultListModel<PAPolicyId> lstModelPolicies = null;

	/**
	* List View in the Left Pane - Displays all the Configured Policies.
	*/
	private JfxList<PAPolicyId> policyList = null;
    private JfxList<PAPermissionData> permissionList = null;

	private JPopupMenu popupMenu = null;
	private JMenuItem menuItemModify = null;
	private JMenuItem menuItemDelete = null;

    private static final String METHOD_ON_DELETE_CLICK = "OnDeleteButtonClicked";
    private static final String METHOD_ON_VALUE_CHANGED = "valueChanged ()";
    private static final String METHOD_UPDATE_DATA_MODEL = "updateDataModel()";

    /**
     * Constructor
     */
    public PAPolicyAdminView() {
        super(getToolbarButtons(), "com.ossnms.bicnet.securitymanagement.client.policy.PAPolicyAdminView", JfxStringTable.getString(USMStringTable.IDS_PA_ADMIN_TITLE), true, USMHelp.HID_POLICY_ADMINISTRATION);

        associatedClientController = new PAPolicyAdminClientController(this);

        data = new PAPolicyAdminDataHolder();
		initializeWindow();

		// Setup context menus
		setupMenu();

		setNamesForComponents();
		LOGGER.info("getting policies");
		((PAPolicyAdminClientController) associatedClientController).sendRequestToFetchAllPolicies();
	}

    /*
     * Helper method to setup the context menu
     */
    private void setupMenu() {
        // Create the popup menu.
        popupMenu = new JPopupMenu();

        menuItemModify = new JMenuItem(USMStringTable.IDS_SYNC_MODIFY.toString());
        menuItemModify.setIcon(ResourcesIconFactory.ICON_TOOL_MOD_16);
        menuItemModify.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleButtonClick(USMButtonTypeEnum.BTN_TYPE_MODIFY);
            }
        });
        popupMenu.add(menuItemModify);

        menuItemDelete = new JMenuItem(USMStringTable.IDS_Delete.toString());
        menuItemDelete.setIcon(ResourcesIconFactory.ICON_TOOL_DELETE_16);
        menuItemDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleButtonClick(USMButtonTypeEnum.BTN_TYPE_DELETE);
            }
        });
        popupMenu.add(menuItemDelete);

        // Add listener to components that can bring up popup menus.
        MouseListener popupListener = new PopupListener();
        policyList.addMouseListener(popupListener);
    }

    /**
     * All the controls of the Policy Administration Window are created and initialized in this method.
     */
    private void initializeWindow() {

        JfxFormPanel policyPanel = getPanelForPlacingDerviedControls();
        lstModelPolicies = data.getPolicyListModel();
        policyList = new JfxList<>(lstModelPolicies);
        policyList.addListSelectionListener(this);

        USMMouseAdapter adap = new USMMouseAdapter(this, USMButtonTypeEnum.BTN_TYPE_MODIFY);
        policyList.addMouseListener(adap);

        // Set up the Title and the Scroll Pane for Policies
        JPanel panelForPolicies = new JPanel();
        panelForPolicies.setLayout(new BoxLayout(panelForPolicies, BoxLayout.Y_AXIS));
        panelForPolicies.setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);

        // Set up the Title for Domains
        JfxLabel captionForDomains = new JfxLabel(USMStringTable.IDS_PA_AVAILABLE_POLICY);
        captionForDomains.setLabelAndMnemonicFor(policyList);
        captionForDomains.setAlignmentX(LEFT_ALIGNMENT);
        panelForPolicies.add(captionForDomains);
        panelForPolicies.add(Box.createRigidArea(new Dimension(0, JfxUtils.VERTICAL_MARGIN_BETWEEN_CAPTION_AND_FIELD)));

        JScrollPane scrollPanePolicies = new JScrollPane(policyList);

        // Setting out layout for the GUI controls
        scrollPanePolicies.setAlignmentX(LEFT_ALIGNMENT);
        panelForPolicies.add(scrollPanePolicies);

        DefaultListModel<PAPermissionData> assignedListModel = data.getPermissionsList();
        permissionList = new PermissionList(assignedListModel);

        // Set up the Title and the Scroll Pane for Menus
        JPanel panelForMenus = new JPanel();
        panelForMenus.setLayout(new BoxLayout(panelForMenus, BoxLayout.Y_AXIS));
        panelForMenus.setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);

        JfxLabel captionForMenus = new JfxLabel(USMStringTable.IDS_PA_ASSIGNED_MENU);
        captionForMenus.setLabelAndMnemonicFor(permissionList);
        captionForMenus.setAlignmentX(LEFT_ALIGNMENT);
        panelForMenus.add(captionForMenus);
        panelForMenus.add(Box.createRigidArea(new Dimension(0, JfxUtils.VERTICAL_MARGIN_BETWEEN_CAPTION_AND_FIELD)));

        JScrollPane menuPane = new JScrollPane(permissionList);
        menuPane.setAlignmentX(LEFT_ALIGNMENT);
        panelForMenus.add(menuPane);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelForPolicies, panelForMenus);
        splitPane.setDividerLocation(125);
        splitPane.setDividerSize(4);
        splitPane.setBorder(null);
        policyPanel.add(splitPane);
        splitPane.setPreferredSize(new Dimension(350, 300));
        this.setPreferredSize(new Dimension(450, 420));

        enableDisableControls();
    }

    /**
     * Helper function that is used to set the Names of all the editable components within the Window.
     * 
     * Strings in this function are not to be Internationalized.
     */
    private void setNamesForComponents() {
        policyList.setName("AvailablePolicies");
        permissionList.setName("AssignedPermissions");
    }

    /**
     * Retrieves the buttons for the toolbar
     * @return list of {@link USMButtonType}
     */
    private static List<USMButtonType> getToolbarButtons() {
        List<USMButtonType> buttons = new ArrayList<>();

        USMButtonType create = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_NEW, USMMenuNameList.OPERATION_POLICY_NEW, USMStringTable.IDS_PA_TOOLTIP_NEW_POLICY, false);
        buttons.add(create);
        USMButtonType modify = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_MODIFY, USMMenuNameList.OPERATION_POLICY_MODIFY, USMStringTable.IDS_PA_TOOLTIP_MODIFY_POLICY, false);
        buttons.add(modify);
        USMButtonType delete = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_DELETE, USMMenuNameList.OPERATION_POLICY_DELETE, USMStringTable.IDS_PA_TOOLTIP_DELETE_POLICY, true);
        buttons.add(delete);
        buttons.add(USMButtonType.BTN_SEPARATOR);
        return buttons;
    }

    /**
     * Function called by the swing framework, when the delete Button gets clicked
     */
    private void onDeleteButtonClicked() {
        LOGGER.debug(METHOD_ON_DELETE_CLICK + " enter function");

        List<PAPolicyId> selectionList = policyList.getSelectedValuesList();
        List<PAPolicyId> deletionPolicyList = new ArrayList<>();

        for (PAPolicyId selectedPolicy : selectionList) {
            if (null != selectedPolicy) {
                deletionPolicyList.add(selectedPolicy);
                LOGGER.info("Selected Policy" + selectedPolicy.toString() + "to be deleted");
            } else {
                LOGGER.info(METHOD_ON_DELETE_CLICK + "Internal Error-Invalid Selection");
            }
        }

        if (confirmPolicyDeletion(deletionPolicyList)) {
            ((PAPolicyAdminClientController) associatedClientController).sendRequestToDeletePolicies(deletionPolicyList);
        }

        LOGGER.info(METHOD_ON_DELETE_CLICK + " EXIT_FUNCTION");
    }

    /**
     * Function called by the swing framework, when the modify Button gets clicked
     */
    private void onModifyButtonClicked() {
        LOGGER.debug(METHOD_ON_MODIFY_CLICKED + " ENTER_FUNCTION");

        PAPolicyId selectedPolicy = policyList.getSelectedValue();
        if (selectedPolicy != null) {
            LOGGER.info(METHOD_ON_MODIFY_CLICKED + selectedPolicy.getPolicyName());
            USMCommandManager.getInstance().executeCmd(USMCommandID.S_UI_ID_MODIFY_POLICY, selectedPolicy);
        }
    }

    /**
     * Function called by the Swing Framework, when the Selection in the list changes
     * 
     * @param e
     *            The object which has the information about what is the new selection.
     */
    @Override
    public void valueChanged(ListSelectionEvent e) {
        LOGGER.info(METHOD_ON_VALUE_CHANGED + " ENTER_FUNCTION"); //$NON-NLS-1$
        // Fault ID 42 - Provide Button Level Authorization for Policy Windows

        enableDisableControls();

        if ((!e.getValueIsAdjusting()) && (null != lstModelPolicies)) {
            List<PAPolicyId> selectionList = policyList.getSelectedValuesList();

            data.setSelectedPolicies(selectionList);

            if (selectionList.size() == 1) {
                LOGGER.info(METHOD_ON_VALUE_CHANGED + " one policy selected..... fetching menu options"); //$NON-NLS-1$
                PAPolicyId selectedPolicy = selectionList.get(0);
                // Fault ID 78 - Controller cleanup should be done correctly by all classes
                ((PAPolicyAdminClientController) associatedClientController).sendRequestToFetchPermissionsForPolicy(selectedPolicy);
            } else {
                data.clearPermissionsList();
            }
        }
        LOGGER.debug(METHOD_ON_VALUE_CHANGED + "EXIT_FUNCTION"); //$NON-NLS-1$
    }

    /**
     * Function to display a message box to the operator and ask for the confirmation about removal of Policy (Policies)
     * @return boolean Indicates whether the operator wants to continue and remove the policies from GSS. True indicates user's agreement about removal.
     */
    public boolean confirmPolicyDeletion(List pVec) {
        boolean bOp = false;
        String strMessage;
        if (1 == pVec.size()) {
            strMessage = JfxStringTable.getString(USMStringTable.IDS_PA_SINGLE_DELETE_MESSAGE) + "'" + pVec.get(0).toString() + "'?";
        } else {
            strMessage = JfxStringTable.getString(USMStringTable.IDS_PA_DELETE_MESSAGE) + pVec.size() + JfxStringTable.getString(USMStringTable.IDS_PA_POLICY);
        }
        int nRetVal = JfxOptionPane.showMessageBox(this, new JfxText(JfxStringTable.getString(USMStringTable.IDS_PA_DELETE_MESSAGE_TITLE)), new JfxText(strMessage), null, JfxOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, JfxOptionPane.NO_OPTION);
        if (JfxOptionPane.YES_OPTION == nRetVal) {
            bOp = true;
        }

        return bOp;
    }

    /**
     * Function to enable and disable the buttons based on the selection.
     * 
     * The expected behavior regarding to enabling and disabling the DELETE and MODIFY buttons is as follow:
     * 
     * 1. For GLOBAL and default policies the DELETE button should be disabled. 
     * 2. For default policies the MODIFY button should be enabled. 
     * 3. For other customized policies, both buttons should be enabled. 
     * 4. If GLOBAL and some default policies are selected, even if another customized policy is selected, the DELETE button should be disabled.
     */
    @Override
    protected void enableDisableControls() {
        List<USMButtonTypeEnum> buttons = new ArrayList<>();
        buttons.add(USMButtonTypeEnum.BTN_TYPE_MODIFY);
        buttons.add(USMButtonTypeEnum.BTN_TYPE_DELETE);

        List<USMButtonTypeEnum> butDel = new ArrayList<>();
        butDel.add(USMButtonTypeEnum.BTN_TYPE_DELETE);

        List<USMButtonTypeEnum> butMod = new ArrayList<>();
        butMod.add(USMButtonTypeEnum.BTN_TYPE_MODIFY);

        if (policyList != null) {
            List<PAPolicyId> selectValues = policyList.getSelectedValuesList();
            if (selectValues.size() == 1) {
                PAPolicyId selectedPolicy = policyList.getSelectedValue();
                if (selectedPolicy != null) {
                    if (selectedPolicy.getPolicyID() == USMCommonStrings.GLOBAL_POLICY_INTERNAL_ID) {
                        disableSelectiveButtons(buttons);
                    } else if (isDefaultPolicy(selectedPolicy.getPolicyName())) {
                        enableSelectiveButtons(butMod);
                        disableSelectiveButtons(butDel);
                    } else {
                        enableSelectiveButtons(buttons);
                    }
                }
            } else {
                boolean isGlobalSelected = false;
                boolean isDefaultPolicySelected = false;

                for (PAPolicyId selectedPolicy : selectValues) {
                    if (selectedPolicy != null) {
                        if (selectedPolicy.getPolicyID() == USMCommonStrings.GLOBAL_POLICY_INTERNAL_ID) {
                            isGlobalSelected = true;
                            break;
                        } else if (isDefaultPolicy(selectedPolicy.getPolicyName())) {
                            isDefaultPolicySelected = true;
                            break;
                        }
                    }
                }

                if ((selectValues.size() == 0) || isGlobalSelected || isDefaultPolicySelected) {
                    disableSelectiveButtons(butDel);
                } else {
                    enableSelectiveButtons(butDel);
                }

                disableSelectiveButtons(butMod);
            }
        }

        // Call the base class for disabling buttons now for authorization
        // This will only disable the buttons based on authorization, nothing else
        performPermissionCheckForButtons();
    }

	/**
	 * Function to return the data holder for the window.
	 * @return xdm.security.pa.client.PAPolicyAdminDataHolder The data holder that is 
	 * associated with this window.
	 */
	public PAPolicyAdminDataHolder getData() {
		return data;
	}

	/**
	 * Policy Admin Window can be updated due to several reasons.
	 * Hence after every operation, this method "updateDataModel" is called and a HINT
	 * is
	 * Passed.
	 * HINT
	 * {
	 * POLICY_LIST_FETCHED
	 * POLICY_CREATED
	 * POLICY_DELETED
	 * POLICY_MODIFIED
	 * POLICY_DATA_FETCHED
	 * }
	 * If HINT = ALL_POLICY_NAMES_FETCHED , the left pane is updated.
	 * If HINT = POLICY_CREATED , the newly created Policy is added to the list of
	 * policies displayed in the left pane.
	 * If HINT = POLICY_DELETED, the deleted Policy name is removed from the list
	 * displayed in the left pane. If the configured menu items of the deleted policy
	 * are being displayed in the right pane, then it is refreshed.
	 * If HINT = POLICY_MODIFIED,the modified policy data ( changed configured menu
	 * items) is refreshed in the right pane
	 * If Hint = POLICY_DATA_FETCHED , then the configured menu items are displayed
	 * int he right pane of the policy Admin Window.
	 * The HINT helps to 'RENDER" only the changed components.
	 * @param pMsg The message which contains the information
	 * @param p_UpdateHint The Object which will be used to decide what is the 
	 * operation that needs to be done.
	 * @return boolean Indicates whether it was possible to process the information . 
	 * True indicates success.
	 */
    public boolean updateDataModel(USMMessage pMsg, PAUpdateHint p_UpdateHint) {
        LOGGER.info(METHOD_UPDATE_DATA_MODEL + " ENTER_FUNCTION ");
        LOGGER.info(METHOD_UPDATE_DATA_MODEL + p_UpdateHint.getHint());

        try {
            if (pMsg == null) {
                LOGGER.info("Invalid_Message_Passed_27");
                return false;
            } else {
                boolean bOp = true;

                switch (p_UpdateHint.getHint()) {
                    case PAUpdateHint.POLICY_CREATED: {
                        PAPolicyData pData = new PAPolicyData();
                        pData.popMe(pMsg);

                        PAPolicyId createdPolicy = new PAPolicyId(pData.getPolicyID(), pData.getPolicyName());

                        data.addPolicy(createdPolicy);
                    }
                    break;

                    case PAUpdateHint.POLICY_DELETED: {
                        int nPolicies = pMsg.popInteger();
                        int currentSelectionIndex = policyList.getSelectedIndex();
                        if ((1 == nPolicies) && (-1 != currentSelectionIndex)) {
                            policyList.setSelectedIndex(currentSelectionIndex - 1);
                        } else {
                            // in case of multiple selection
                            policyList.setSelectedIndex(0);
                        }
                        for (int i = 0; i < nPolicies; ++i) {
                            PAPolicyId deletedPolicy = new PAPolicyId();
                            deletedPolicy.popMe(pMsg);
                            bOp &= data.removePolicy(deletedPolicy);
                        }
                    }
                    break;

                    case PAUpdateHint.POLICY_MODIFIED: {
                        PAPolicyData modifiedPolicy = new PAPolicyData();
                        modifiedPolicy.popMe(pMsg);

                        List<PAPolicyId> selectedList = policyList.getSelectedValuesList();

                        if (selectedList.size() == 1) {
                            PAPolicyId selectedPolicy = selectedList.get(0);

                            if (selectedPolicy.getPolicyID() == modifiedPolicy.getPolicyID()) {
                                data.modifyPolicy(modifiedPolicy);
                            }
                        }
                    }
                    break;

                    case PAUpdateHint.POLICY_LIST_FETCHED: {
                        bOp = data.onAllPoliciesFetched(pMsg);
                    }
                    break;

                    case PAUpdateHint.POLICY_DATA_FETCHED: {
                        LOGGER.debug(METHOD_UPDATE_DATA_MODEL + "POLICY_DATA_FETCHED_switch_fetching_policy_data..._28"); //$NON-NLS-1$
                        data.clearPermissionsList();
                        if (pMsg.popInteger() == 1)
                            bOp = data.onPolicyDataFetched(pMsg);
                    }
                    break;

                    default: {
                        LOGGER.error("I don't know how this happened");
                    }
                }

                return bOp;
            }
        } finally {
            LOGGER.debug(METHOD_UPDATE_DATA_MODEL + " EXIT_FUNCTION");
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView_BtnPnl_StatusBar#handleButtonClick(com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType)
     */
    @Override
    public void handleButtonClick(USMButtonTypeEnum type) {
        if ((USMButtonTypeEnum.BTN_TYPE_NEW).equals(type)) {
            USMCommandManager.getInstance().executeCmd(USMCommandID.S_UI_ID_NEW_POLICIES);
        } else if ((USMButtonTypeEnum.BTN_TYPE_MODIFY).equals(type)) {
            onModifyButtonClicked();
        } else if ((USMButtonTypeEnum.BTN_TYPE_DELETE).equals(type)) {
            LOGGER.info("handleButtonClick() on delete button clicked...."); //$NON-NLS-1$
            onDeleteButtonClicked();
        } else if ((USMButtonTypeEnum.BTN_TYPE_CLOSE).equals(type)) {
            close();
        } else {
            LOGGER.debug("handleButtonClick() handleButtonClick() EXIT_FUNCTION"); //$NON-NLS-1$
        }
    }

	/**
	 * Function to show a message to the user
	 * 
	 * @param component The Component which is the parent window.
	 * @param message The Text that should be displayed
	 */
    public void showMessage(final Component component, String message) {
        JfxOptionPane.showMessageBox(this, message);
    }

    @Override
    public JComponent getComponent() {
        return this;
    }

    /**
     * Function to return the Icon that is associated with this View.
     * 
     * @return Icon The Icon that should be used
     */
    @Override
    public Icon getIcon() {
        return ResourcesIconFactory.ICON_WINDOW_POLICY_16;
    }

    /**
     * This method is used to validate if a certain policy is classified as a default.
     * 
     * @param policyName
     *            Policy name to be verified if existing policy is a default policy
     * @return True if the policy name belongs to those defined as DEFAULT,
     *         otherwise false.
     */
    private boolean isDefaultPolicy(String policyName) {
        return Arrays.asList(USMCommonStrings.DEFAULT_POLICIES_NAMES).contains(policyName);
    }

    @Override
    public boolean isDockable() {    
        return true;
    }


    /**
     *
     */
    private class PopupListener extends MouseAdapter {
        @Override
        public void mousePressed(MouseEvent e) {
            maybeShowPopup(e);
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            maybeShowPopup(e);
        }

        private void maybeShowPopup(MouseEvent e) {
            if (e.isPopupTrigger()) {
                Component srcComponent = e.getComponent();
                if (srcComponent instanceof JfxList ) {

                    boolean isGlobalSelected = false;
                    boolean isDefaultPolicySelected = false;

                    JfxList<PAPolicyId> lstPolicies = (JfxList) srcComponent;
                    List<PAPolicyId> policies = lstPolicies.getSelectedValuesList();
                    int nPolicySelectedCount = policies.size();

                    if (nPolicySelectedCount > 0) {

                        for (PAPolicyId policy : policies) {
                            if (policy.getPolicyID() == USMCommonStrings.GLOBAL_POLICY_INTERNAL_ID) {
                                isGlobalSelected = true;
                                break;
                            } else if (isDefaultPolicy(policy.getPolicyName())) {
                                isDefaultPolicySelected = true;
                                break;
                            }
                        }
                    }
                    menuItemModify.setEnabled(!isGlobalSelected && (nPolicySelectedCount == 1));
                    menuItemDelete.setEnabled(!isGlobalSelected && (nPolicySelectedCount > 0) && !isDefaultPolicySelected);
                    popupMenu.show(e.getComponent(), e.getX(), e.getY());
                }
            }
        }
    }
}

