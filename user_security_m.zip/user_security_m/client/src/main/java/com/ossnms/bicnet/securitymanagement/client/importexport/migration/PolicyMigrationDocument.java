package com.ossnms.bicnet.securitymanagement.client.importexport.migration;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Class representing the XML document which describes changes which should be
 * applied to menu options.
 * 
 */
public class PolicyMigrationDocument {

    private static final Logger LOGGER = Logger.getLogger(PolicyMigrationDocument.class);
    private static final String POLICY_ELEMENT = "policy";
    private static final String POLICY_NAME_ATTRIBUTE = "name";
    private static final String ADD_POLICY_ELEMENT = "add";
    private static final String REMOVE_POLICY_ELEMENT = "remove";
    private static final String POLICY_NAME_ELEMENT = "name";
    private static final String REMOVE_ELEMENT = "remove";
    private static final String REPLACE_ELEMENT = "replace";
    private static final String MENU_OPTION_ELEMENT = "menu-option";
    private static final String MENU_OPTION_UPDATES_ELEMENT = "menu-option-updates";
    private static final String NEW_NAME_ELEMENT = "new-name";
    private static final String OLD_NAME_ELEMENT = "old-name";

    private Map<String, List<String>> menusToAddByPolicy = new HashMap<String, List<String>>();
    private Map<String, List<String>> menusToRemoveByPolicy = new HashMap<String, List<String>>();
    private List<String> menusToRemove = new ArrayList<String>();
    private Map<String, String> menuOldNameNewName = new HashMap<String, String>();

    public List<String> getMenusToAdd(String policyName) {
        return menusToAddByPolicy.get(policyName);
    }

    public boolean isMenuToBeRemoved(String policyName, String menuName) {
        if (menusToRemoveByPolicy.get(policyName) == null) {
            return menusToRemove.contains(menuName);
        } else {
            return menusToRemove.contains(menuName) || menusToRemoveByPolicy.get(policyName).contains(menuName);
        }
    }

    public String getNewNameForMenu(String menuName) {
        return menuOldNameNewName.get(menuName);
    }

    private void loadMenusByPolicy(NodeList nodeList) {
        for (int i = 0; i < nodeList.getLength(); i++) {
            Element policyElement = (Element) nodeList.item(i);
            String policy = policyElement.getAttribute(POLICY_NAME_ATTRIBUTE);
            List<String> menusToAdd = loadPoliciesForElement(policyElement, ADD_POLICY_ELEMENT);
            menusToAddByPolicy.put(policy, menusToAdd);
            List<String> menusToRemove = loadPoliciesForElement(policyElement, REMOVE_POLICY_ELEMENT);
            menusToRemoveByPolicy.put(policy, menusToRemove);
        }
    }

    private List<String> loadPoliciesForElement(Element policyElement, String elementName) {
        NodeList addOps = policyElement.getElementsByTagName(elementName);
        List<String> menus = new ArrayList<String>();
        for (int j = 0; j < addOps.getLength(); j++) {
            NodeList names = ((Element) addOps.item(j)).getElementsByTagName(POLICY_NAME_ELEMENT);
            for (int k = 0; k < names.getLength(); k++) {
                Element addElement = (Element) names.item(k);
                menus.add(addElement.getFirstChild().getNodeValue());
            }
        }
        return menus;
    }

    private void loadMenusToRemove(NodeList nodeList) {
        Element removeElement = (Element) nodeList.item(0);
        NodeList removeOps = removeElement.getElementsByTagName(POLICY_NAME_ELEMENT);

        for (int i = 0; i < removeOps.getLength(); i++) {
            Element removeName = (Element) removeOps.item(i);
            menusToRemove.add(removeName.getFirstChild().getNodeValue());
        }
    }

    private void loadMenusToRename(NodeList nodeList) {
        Element replaceElement = (Element) nodeList.item(0);
        NodeList renameOps = replaceElement.getElementsByTagName(MENU_OPTION_ELEMENT);
        for (int i = 0; i < renameOps.getLength(); i++) {
            Element renameEntry = (Element) renameOps.item(i);
            String oldName = renameEntry.getElementsByTagName(OLD_NAME_ELEMENT).item(0).getFirstChild().getNodeValue();
            String newName = renameEntry.getElementsByTagName(NEW_NAME_ELEMENT).item(0).getFirstChild().getNodeValue();
            menuOldNameNewName.put(oldName, newName);
        }
    }

    private void loadMenuOptionUpdates(NodeList nodeList) {
        Element menuOptionUpdatesElement = (Element) nodeList.item(0);
        loadMenusToRemove(menuOptionUpdatesElement.getElementsByTagName(REMOVE_ELEMENT));
        loadMenusToRename(menuOptionUpdatesElement.getElementsByTagName(REPLACE_ELEMENT));
    }

    public void loadValues(InputStream xmlFile) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();

            Document dom = db.parse(xmlFile);
            Element docEle = dom.getDocumentElement();
            loadMenusByPolicy(docEle.getElementsByTagName(POLICY_ELEMENT));
            loadMenuOptionUpdates(docEle.getElementsByTagName(MENU_OPTION_UPDATES_ELEMENT));

        } catch (ParserConfigurationException e) {
            LOGGER.error(e);
        } catch (SAXException e) {
            LOGGER.error(e);
        } catch (IOException e) {
            LOGGER.error(e);
        }
    }
}
