/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   UAUserGroupCreateCommand
 * Author:      Jogender
 * Substitute	Babu B
 * Created on	12-09-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER_GROUP.CONFIGURE 
 *       : TNMS.DX2.SM.USER_GROUP.CREATE
 *       : TNMS.DX2.SM.USER_GROUP.ASSIGN 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration.usergroupcreate;

import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;

/**
 * Concrete class for the Command of the User Group Creation View. This Command
 * is registered with the UI and is responsible to display the User Group
 * Creation view
 */
public class UAUserGroupCreateCommand extends USMCommand {

	/**
	 * Default constructor 
	 */
	public UAUserGroupCreateCommand() {
		super(USMCommandID.S_UI_ID_USER_MGMT_CREATE_USER_GROUP);
	}

	/**
	 * THis class returns the view associated with the controller
	 * 
	 * @return USMBaseView - The Create User Group View
	 */
	@Override
    protected USMBaseView createAndReturnView() {
		return new UAUserGroupCreateView();
	}
}
