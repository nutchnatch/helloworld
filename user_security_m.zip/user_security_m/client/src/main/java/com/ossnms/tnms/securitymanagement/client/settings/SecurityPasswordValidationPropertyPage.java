package com.ossnms.tnms.securitymanagement.client.settings;

import static com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable.IDS_SS_PASSWORD_MUST_BE_DIFFERENT_FROM_DATE;
import static com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable.IDS_SS_PASSWORD_MUST_BE_DIFFERENT_FROM_EMPLOYEE_NUMBER;
import static com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable.IDS_SS_PASSWORD_MUST_BE_DIFFERENT_FROM_NAME;
import static com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable.IDS_SS_PASSWORD_MUST_NOT_CONTAIN;
import static com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable.IDS_SS_PASSWORD_MUST_NOT_HAVE_SPACES;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPageSite;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSettingsPropertyPage;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.auth.PasswordValidationRulesConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxCheckBox;
import com.ossnms.tools.jfx.components.JfxLabel;

class SecurityPasswordValidationPropertyPage extends JPanel implements ISecurityPropertyPage {
    private static final long serialVersionUID = 1205933066789166961L;

    private static final Logger LOGGER = LoggerFactory.getLogger(SecurityPasswordValidationPropertyPage.class);
    private static final int LABEL_ROW = 0;
    private static final int NAME_CHECKBOX_ROW = LABEL_ROW + 1;
    private static final int EMPLOYEE_NUMBER_CHECKBOX_ROW = NAME_CHECKBOX_ROW + 1;
    private static final int DATE_CHECKBOX_ROW = EMPLOYEE_NUMBER_CHECKBOX_ROW + 1;
    private static final int SPACE_CHECKBOX_ROW = DATE_CHECKBOX_ROW + 1;

    private final List<ChangeListener> changeListeners = new ArrayList<>();

    private SecuritySettingsDocument doc;
    private BiCNetPluginPropertyPageSite propertyPageSite;

    private JfxCheckBox firstLastName = new JfxCheckBox(IDS_SS_PASSWORD_MUST_BE_DIFFERENT_FROM_NAME);
    private JfxCheckBox employeeNumber = new JfxCheckBox(IDS_SS_PASSWORD_MUST_BE_DIFFERENT_FROM_EMPLOYEE_NUMBER);
    private JfxCheckBox date = new JfxCheckBox(IDS_SS_PASSWORD_MUST_BE_DIFFERENT_FROM_DATE);
    private JfxCheckBox spaces = new JfxCheckBox(IDS_SS_PASSWORD_MUST_NOT_HAVE_SPACES);

    private JfxButton defaultButton = new JfxButton(JfxStringTable.IDS_Default);

    public SecurityPasswordValidationPropertyPage(SecuritySettingsDocument doc) {
        this.doc = doc;
        initLayout();
        initListeners();
        setGuiNames();
    }

    private void setGuiNames() {
        LOGGER.debug("setGuiNames() Entry");

        firstLastName.setName("FirstLastName");
        employeeNumber.setName("EmployeeNumber");
        date.setName("Date");
        spaces.setName("Spaces");

        LOGGER.debug("setGuiNames() Exit");
    }

    private void initListeners() {
        firstLastName.addActionListener(e -> this.stateChanged(new ChangeEvent(firstLastName)));
        employeeNumber.addActionListener(e -> this.stateChanged(new ChangeEvent(employeeNumber)));
        date.addActionListener(e -> this.stateChanged(new ChangeEvent(date)));
        spaces.addActionListener(e -> this.stateChanged(new ChangeEvent(spaces)));

        defaultButton.addActionListener(e -> {
            firstLastName.setSelected(false);
            employeeNumber.setSelected(false);
            date.setSelected(false);
            spaces.setSelected(false);
        });

        if (propertyPageSite != null) {
            propertyPageSite.eventPageStatusChanged(SecurityPasswordValidationPropertyPage.this);
        }
    }

    private void initLayout() {
        setLayout(new GridBagLayout());
        setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);

        add(createPasswordValidationRulesPanel(), new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        add(defaultButton, new GridBagConstraints(0, 1, 1, 1, 0.0, 1.0, GridBagConstraints.SOUTHWEST, GridBagConstraints.NONE, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0), 0, 0));
    }

    private JPanel createPasswordValidationRulesPanel() {
        JPanel passwordValidationRulesPanel = new JPanel(new GridBagLayout());
        JfxLabel mustNotContainLabel = new JfxLabel(IDS_SS_PASSWORD_MUST_NOT_CONTAIN);

        firstLastName.setMnemonic(IDS_SS_PASSWORD_MUST_BE_DIFFERENT_FROM_NAME.getMnemonic());
        employeeNumber.setMnemonic(IDS_SS_PASSWORD_MUST_BE_DIFFERENT_FROM_EMPLOYEE_NUMBER.getMnemonic());
        date.setMnemonic(IDS_SS_PASSWORD_MUST_BE_DIFFERENT_FROM_DATE.getMnemonic());
        spaces.setMnemonic(IDS_SS_PASSWORD_MUST_NOT_HAVE_SPACES.getMnemonic());
        
        passwordValidationRulesPanel.add(mustNotContainLabel, new GridBagConstraints(0, LABEL_ROW, 0, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        passwordValidationRulesPanel.add(firstLastName, new GridBagConstraints(0, NAME_CHECKBOX_ROW, 0, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, JfxUtils.FIELD_INDENTATION, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        passwordValidationRulesPanel.add(employeeNumber, new GridBagConstraints(0, EMPLOYEE_NUMBER_CHECKBOX_ROW, 0, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, JfxUtils.FIELD_INDENTATION, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        passwordValidationRulesPanel.add(date, new GridBagConstraints(0, DATE_CHECKBOX_ROW, 0, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, JfxUtils.FIELD_INDENTATION, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        passwordValidationRulesPanel.add(spaces, new GridBagConstraints(0, SPACE_CHECKBOX_ROW, 0, 1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, JfxUtils.FIELD_INDENTATION, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));

        return passwordValidationRulesPanel;
    }

    @Override
    public void saveData(SecuritySettingsData data) {
        PasswordValidationRulesConfigurationData settingsData = data.getData().getPasswordValidationRulesConfigurationData();

        settingsData.setPasswordMustBeDifferentFromDate(date.isSelected());
        settingsData.setPasswordMustBeDifferentFromEmployeeNumber(employeeNumber.isSelected());
        settingsData.setPasswordMustBeDifferentFromName(firstLastName.isSelected());
        settingsData.setPasswordMustNotHaveSpaces(spaces.isSelected());

        data.getData().setPasswordValidationRulesConfigurationData(settingsData);
    }

    /**
     * Add listener to listener list.
     *
     * @param listener
     *            listener
     */
    public void addChangeListener(ChangeListener listener) {
        changeListeners.add(listener);
    }

    @Override
    public BiCNetPluginSettingsPropertyPage[] getChildPages() {
        return null;
    }

    @Override
    public boolean isEnabled(IManagedObject[] iManagedObjects) {
        return USMUtility.getInstance().checkIfOperatorHasPermission(USMCommandID.S_UI_ID_GENERAL_SECURITY_SETTINGS.getMenuString());
    }

    /**
     * Sets the interface of the enclosing frame provided by the application. This method is called before the view is displayed. 
     * The view should store the given reference for later use.
     *
     * @param biCNetPluginFrame Reference to plug-in frame. *
     */
    @Override
    public void setFrame(BiCNetPluginFrame biCNetPluginFrame) {
        // Do nothing
    }

    @Override
    public void setPageSite(BiCNetPluginPropertyPageSite biCNetPluginPropertyPageSite) {
        this.propertyPageSite = biCNetPluginPropertyPageSite;
    }

    @Override
    public String getID() {
        return USMCommandID.S_UI_ID_SECURITY_SETTINGS_PASSWORD_VALIDATION_RULES.getMenuString();
    }

    @Override
    public JComponent getComponent() {
        return this;
    }

    @Override
    public String getTitle() {
        return USMStringTable.IDS_AA_PASSWORD_VALIDATION_RULES_LABEL.toString();
    }

    @Override
    public void setObjects(IManagedObjectMarkable[] iManagedObjectMarkables) {
        // Do nothing
    }

    @Override
    public void update() {
        // Do nothing
    }

    @Override
    public void setReadOnly(boolean b) {
        // Do nothing
    }

    @Override
    public boolean isPageDirty() {
        GSGeneralSettingData savedSettings = doc.getGeneralSettingsData();

        boolean retValue = (savedSettings == null);
        retValue = retValue || (savedSettings.getPasswordValidationRulesConfigurationData() == null);
        retValue = retValue || (savedSettings.getPasswordValidationRulesConfigurationData().isPasswordMustBeDifferentFromEmployeeNumber() != employeeNumber.isSelected());
        retValue = retValue || (savedSettings.getPasswordValidationRulesConfigurationData().isPasswordMustBeDifferentFromName() != firstLastName.isSelected());
        retValue = retValue || (savedSettings.getPasswordValidationRulesConfigurationData().isPasswordMustBeDifferentFromDate() != date.isSelected());
        retValue = retValue || (savedSettings.getPasswordValidationRulesConfigurationData().isPasswordMustNotHaveSpaces() != spaces.isSelected());

        return retValue;
    }

    @Override
    public void validateInput() throws BiCNetPluginException {
        // Do nothing
    }

    @Override
    public void actionApply() {
        // Do nothing
    }

    @Override
    public void actionCancel() {
        // Do nothing
    }

    @Override
    public void eventOpened() {
        // Do nothing
    }

    @Override
    public void eventClosing() {
        // Do nothing
    }

    @Override
    public void updateData(Object o) {
        if (o instanceof GSGeneralSettingData) {
            GSGeneralSettingData data = (GSGeneralSettingData) o;
            PasswordValidationRulesConfigurationData passwordData = data.getPasswordValidationRulesConfigurationData();

            // Password Verification Rules Configuration
            date.setUnmodifiedValue(passwordData.isPasswordMustBeDifferentFromDate());
            date.setSelected(passwordData.isPasswordMustBeDifferentFromDate());

            firstLastName.setUnmodifiedValue(passwordData.isPasswordMustBeDifferentFromName());
            firstLastName.setSelected(passwordData.isPasswordMustBeDifferentFromName());

            employeeNumber.setUnmodifiedValue(passwordData.isPasswordMustBeDifferentFromEmployeeNumber());
            employeeNumber.setSelected(passwordData.isPasswordMustBeDifferentFromEmployeeNumber());

            spaces.setUnmodifiedValue(passwordData.isPasswordMustNotHaveSpaces());
            spaces.setSelected(passwordData.isPasswordMustNotHaveSpaces());
        }
    }

    @Override
    public void stateChanged(ChangeEvent e) {
        if (propertyPageSite != null) {
            propertyPageSite.eventPageStatusChanged(this);
        }

        for (ChangeListener listener : changeListeners) {
            listener.stateChanged(null);
        }
    }
}