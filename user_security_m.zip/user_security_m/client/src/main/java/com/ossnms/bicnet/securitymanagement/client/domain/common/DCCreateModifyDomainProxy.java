/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCCreateModifyDomainProxy
 * Author      	Asif khan R
 * Substitute	Muyeen M
 * Created on	12-09-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID	:	TNMS.DX2.SM.DOMAIN.VIEW
 * 			:	TNMS.DX2.SM.DOMAIN.CREATE
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Asif 			CF000834 - Command Log Entries 
 * 18-Mar-2005  Asif khan R     CF001755 Error Messages when LDAP not available
 * 14-June-2005  Asif  CF000209 - Changes in the ISecurityProviderFacade / IManagedObject
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain.common;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMBaseController;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;
import com.ossnms.bicnet.securitymanagement.client.domain.job.DCAssignObjectsToDomainJob;
import com.ossnms.bicnet.securitymanagement.client.domain.job.DCCreateDomainJob;
import com.ossnms.bicnet.securitymanagement.client.domain.job.DCGetAllSecurableObjectsJob;
import com.ossnms.bicnet.securitymanagement.client.domain.job.DCGetObjectsOfDomainForServerJob;
import com.ossnms.bicnet.securitymanagement.client.domain.job.DCModifyDomainJob;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSMessageType;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObjectContainer;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCHelper;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessageType;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * This Client side Controller is responsible for interacting with the Server for operations like create, Modify a
 * domain
 */
public class DCCreateModifyDomainProxy extends USMBaseController {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(DCCreateModifyDomainProxy.class);

    /**
     * The domain which has to be modified, null in case of create domain
     */
    DCDomainData modifiedDomain;

    /**
     * To hold the list of objects which need to be assigned
     */
    private List<BSSecurableObject> assignedObjects = new ArrayList<>();

    /**
     * To hold the list of objects which need to be unassigned to domain
     */

    private List<BSSecurableObject> unAssignedObjects = new ArrayList<>();

    /**
     * This is the constructor
     * 
     * @param view The view associated with the controller
     * @param domain The domain which needs to be modified, null in case of create domain
     */
    public DCCreateModifyDomainProxy(USMBaseView view, DCDomainData domain) {

        super(view);

        LOGGER.debug("DCCreateModifyProxy() - Enter");

        modifiedDomain = domain;
        // Register for interested notifications
        registerInterestedNotificationIds(getInterestedNotifications());
        LOGGER.debug("DCCreateModifyProxy() - Exit");
    }

    /**
     * Gets the associated window with this proxy
     * 
     * @return Returns the DCCreateModifyBaseView associated with this proxy
     */
    DCCreateModifyBaseView getWindow() {
        return (DCCreateModifyBaseView) associatedView;
    }

    /**
     * Function to return a Vector which contains the list of types that this proxy is interested in.
     * 
     * @return List - The List which contains the notification the controller is interested in.
     */
    private static List<USMBaseMsgType> getInterestedNotifications() {
        LOGGER.debug("getInterestedNotifications() - Enter");

        ArrayList<USMBaseMsgType> vectorForNotification = new ArrayList<>();
        vectorForNotification.add(DCMessageType.DC_NOT_DOMAIN_MODIFIED);
        vectorForNotification.add(DCMessageType.DC_NOT_DOMAIN_DELETED);

        vectorForNotification.add(BSMessageType.BS_NOT_CF_NAME_CHANGED);
        vectorForNotification.add(BSMessageType.BS_NOT_CF_SYNCED_WITH_SEC_OBJS);
        vectorForNotification.add(BSMessageType.BS_NOT_CF_REMOVED);
        vectorForNotification.add(BSMessageType.BS_NOT_CF_INSERTED);
        vectorForNotification.add(BSMessageType.BS_NOT_SEC_OBJS_ASSIGNED_TO_DOMAINS);
        vectorForNotification.add(BSMessageType.BS_NOT_SEC_OBJS_UNASSIGNED_FROM_DOMAINS);

        vectorForNotification.add(BSMessageType.BS_NOT_NEW_SEC_OBJ_REGISTERED);
        vectorForNotification.add(BSMessageType.BS_NOT_SEC_OBJ_UNREGISTERED);
        vectorForNotification.add(BSMessageType.BS_NOT_SEC_OBJ_CHANGED);
        vectorForNotification.add(BSMessageType.BS_NOT_SEC_OBJ_CONTAINER_CHANGE);

        LOGGER.debug("getInterestedNotifications() - Exit");
        return vectorForNotification;
    }

    /**
     * Handles the response for the expansion or getting the securable objects of a domain for the chosen server.
     * 
     * @param message Message which contains the securable objects of domain for the given server.
     */
    private void handleResponseGetObjectsOfDomainForServer(USMMessage message) {

        LOGGER.debug("handleResponseGetObjectsOfDomainForServer() - Enter");

        Integer errorId = message.popInteger();
        String errorMessage = null;
        // The domain might have been deleted from some other client.
        if (errorId.equals(DCMessages.DC_NO_ERROR)) {
            boolean bAssign = message.popBoolean();
            BSTransBicNetCFInfo ser = BSTransBicNetCFInfo.popMe(message);

            List netElem = new ArrayList();
            DCHelper.popSecurableObjects(message, netElem);

            // In case of create domain window.
            if (null == modifiedDomain) {
                bAssign = false;
            }

            LOGGER.debug("Assign {}; Function Info {}", bAssign, ser);
        } else {
            errorMessage = DCMessages.getInstance().getString(errorId);
            getWindow().showMessage(errorMessage);
        }
        LOGGER.debug("handleResponseGetObjectsOfDomainForServer() - Exit");
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIntf#resultAvailable(com.ossnms.bicnet
     * .securitymanagement.client.basic.controller.jobs.USMJob, java.lang.Object)
     */
    @Override
    public void resultAvailable(USMJob job, final USMMessage result) {

        LOGGER.debug("resultAvailable() - Enter");

        SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				USMBaseMsgType msgType = result.getMessageType();
				
				if (msgType.equals(DCMessageType.DC_RES_DOMAIN_DETAILS_OBJECT_LEVEL)) {
					handleResponseGetObjectsOfDomainForServer(result);
				} else if (msgType.equals(DCMessageType.DC_RES_CREATE_DOMAIN)) {
					handleResponseCreateDomain(result);
				} else if (msgType.equals(DCMessageType.DC_RES_ASSIGN_TO_DOMAIN)) {
					handleResponsesAssignUnassignObjectsToDomain(result);
				} else if (msgType.equals(DCMessageType.DC_RES_MODIFY_DOMAIN)) {
					handleResponseModifyDomain(result);
				} else if (msgType.equals(DCMessageType.DC_RES_ALL_SECURABLE_OBJECTS)) {
					handleResponseGetAllSecurableObject(result);
				}
			}
		});
        LOGGER.debug("resultAvailable() - Exit");

    }
    
    private void handleResponseGetAllSecurableObject(USMMessage msg) {
    	Integer errorId = msg.popInteger();
        
        if (DCMessages.DC_NO_ERROR.equals(errorId)) {
        	Map<BSTransBicNetCFInfo, List<BSSecurableObject>> result = (Map<BSTransBicNetCFInfo, List<BSSecurableObject>>) msg.popObject();
        	getWindow().setAllSecurableObjectsFromServer(result);
        }
    }

    /**
     * Handles the response for modificaiton of domain, Starts the assign/unassign of securable objects to a domain job.
     * 
     * @param msg Message contains the status of domain modified operation.
     */
    private void handleResponseModifyDomain(USMMessage msg) {
        LOGGER.debug("handleResponseModifyDomain() - Enter");

        Integer errorId = msg.popInteger();
        // The domain might have been deleted from some other client.
        // so u have to close the window and go home
        if (!errorId.equals(DCMessages.DC_NO_ERROR)) {
            if (errorId.equals(DCMessages.DC_DOMAIN_INVALID)) {
                getWindow().closeWindowOnObjectDeletion();
            } else {
                getWindow().showMessage(DCMessages.getInstance().getString(errorId));
            }
        } else {
            assignUnassignObjectsToDomain(modifiedDomain, false);
        }

        LOGGER.debug("handleResponseModifyDomain() - Exit");

    }

    /**
     * Handles the response for the creation of domain. It starts now the job to assign the securable objects to this
     * newly created domain.
     * 
     * @param message Message containing the information of the newly created domain and status of the create domain
     *            operation
     */
    private void handleResponseCreateDomain(USMMessage message) {

        LOGGER.debug("handleResponseCreateDomain() - Enter");

        boolean bOp = false;

        Integer errorId = message.popInteger();
        String errorMessage = null;
        if (DCMessages.DC_NO_ERROR.equals(errorId)) {
            // Pop the Domian ID of the
            DCDomainData createdDomain = new DCDomainData();
            createdDomain.popMe(message);

            if (createdDomain.getDomainID() < 0) {
                errorMessage = " Invalid Domain ID ";
            } else {
                if (0 <= assignedObjects.size()) {
                    assignUnassignObjectsToDomain(createdDomain, true);
                    bOp = true;
                } else {
                    getWindow().closeWindow();
                }
            }
            // TO DO - Update Status Bar.
        } else {
            errorMessage = DCMessages.getInstance().getString(errorId);
        }
        if (bOp == false) {
            getWindow().showMessage(errorMessage);
        }
        LOGGER.debug("handleResponseCreateDomain() - Exit");

    }

    /**
     * This method is used to send the list of assigned/unassign objects to domain.
     * 
     * @param domainData The domain data to which the objects are assigned/unassigned.
     */
    public void assignUnassignObjectsToDomain(DCDomainData domainData, boolean createWindow) {

        LOGGER.debug("assignUnassignObjectsToDomain() - Enter");

        DCAssignObjectsToDomainJob job = new DCAssignObjectsToDomainJob(DCMessageType.DC_REQ_ASSIGN_TO_DOMAIN, this, assignedObjects, unAssignedObjects, domainData, createWindow);

        queueJob(job);
        LOGGER.debug("assignUnassignObjectsToDomain() - Exit");

    }

    /**
     * This handles notifications about domain deletion. When a domain is deleted, it delegates this task to the window.
     * 
     * @param msg - The DCDomainData of the domain which is deleted.
     */
    private void handleNotifDomainDeleted(USMMessage msg) {

        LOGGER.debug("handleDomainDeletedNotif() - Enter");

        DCDomainData domData = new DCDomainData();
        domData.popMe(msg);

        // Only it it is a modify window, do this
        if (domData.equals(modifiedDomain)) {
            getWindow().closeWindowOnObjectDeletion();
        }

        LOGGER.debug("handleDomainDeletedNotif() - Exit");

    }

    /**
     * This handles the notification of a domain being modified.
     * 
     * @param msg - The message contains the domain which was modified.
     */
    private void handleNotifDomainModified(USMMessage msg) {

        LOGGER.debug("handleDomainModifiedNotif() - Enter");
        DCDomainData dom = new DCDomainData();
        dom.popMe(msg);

        // Only it it is a modify window, do this
        if (dom.equals(modifiedDomain)) {
            // Update the description of the domain
            getWindow().setDescr(dom.getDomainDescr());
        }
        LOGGER.debug("handleDomainModifiedNotif() - Exit");

    }

    /**
     * This method handles the application server deleted notification.
     * 
     * @param msg - The message contains the BSTransCFInfo of the deleted server.
     */
    private void handleNotifCommonFunctionDeleted(USMMessage msg) {
        LOGGER.debug("handleCommonFunctionDeletion() - Enter");

        int nServers = msg.popInteger().intValue();
        for (int i = 0; i < nServers; ++i) {
            BSTransBicNetCFInfo server = BSTransBicNetCFInfo.popMe(msg);
            // tell the client window to delete all the NEs of this server
            getWindow().deleteServer(server);
        }
        LOGGER.debug("handleCommonFunctionDeletion() - Exit");
    }

    /**
     * Handles the common function display name being changed notification.
     * 
     * @param msg - Message contains the changed server details.
     */
    private void handleNotifCommonFunctionNameModified(USMMessage msg) {
        LOGGER.debug("handleCommonFunctionNameModifcation() - Enter");
        BSTransBicNetCFInfo server = BSTransBicNetCFInfo.popMe(msg);
        // tell the client window to change the name of the server
        getWindow().renameServer(server);
        LOGGER.debug("handleCommonFunctionNameModifcation() - Exit");
    }

    /**
     * This method handles the common function being synchronized, in which case the NEs will be added or deleted.
     * 
     * @param msg - The message contains the CF details(BSTransCFInfo).
     */
    private void handleNotifCommonFunctionSynchronized(USMMessage msg) {
        LOGGER.debug("handleCommonFunctionSynchrnozed() - Enter");

        BSTransBicNetCFInfo server = BSTransBicNetCFInfo.popMe(msg);
        // tell the client window to delete all the NEs of this server
        getWindow().deleteServer(server);
        getObjectsOfDomainForServer(server, false);
        // Only in case of modification also get the unassigned NEs
        if (modifiedDomain != null) {

            getObjectsOfDomainForServer(server, true);
        }

        LOGGER.debug("handleCommonFunctionSynchrnozed() - Exit");
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIntf#handleNotification(com.ossnms
     * .bicnet.securitymanagement.common.basic.USMMessage)
     */
    @Override
    public void handleNotification(final USMMessage msg) {
        LOGGER.debug("handleNotification() - Enter");

        if (null != associatedView) {

        	SwingUtilities.invokeLater(new Runnable() {
				@Override
				public void run() {
					processNotificationMessage(msg);
				}
			});
        	LOGGER.debug("handleNotification() - Exit");
        }
    }

	/**
	 * This method must run in swing thread
	 */
	private void processNotificationMessage(final USMMessage msg) {
		USMBaseMsgType msgType = msg.getMessageType();
		if (msgType.equals(DCMessageType.DC_NOT_DOMAIN_DELETED)) {
			handleNotifDomainDeleted(msg);
		} else if (msgType.equals(DCMessageType.DC_NOT_DOMAIN_MODIFIED)) {
			handleNotifDomainModified(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_CF_NAME_CHANGED)) {
			handleNotifCommonFunctionNameModified(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_CF_SYNCED_WITH_SEC_OBJS) || msgType.equals(BSMessageType.BS_NOT_CF_INSERTED)) {
			handleNotifCommonFunctionSynchronized(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_CF_REMOVED)) {
			handleNotifCommonFunctionDeleted(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_SEC_OBJS_ASSIGNED_TO_DOMAINS) || msgType.equals(BSMessageType.BS_NOT_SEC_OBJS_UNASSIGNED_FROM_DOMAINS)) {
			handleNotifObjectsAssignedUnassigned(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_NEW_SEC_OBJ_REGISTERED)) {
			handleNotifSecObjectRegistered(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_SEC_OBJ_UNREGISTERED)) {
			handleNotifSecObjectUnregistered(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_SEC_OBJ_CHANGED)) {
			handleNotifSecObjectChanged(msg);
		} else if (msgType.equals(BSMessageType.BS_NOT_SEC_OBJ_CONTAINER_CHANGE)) {
			handleNotifSecObjectContainerChanged(msg);   
		} else {
			LOGGER.error("handleNotification() - Unknown message recieved " + msgType);
		}
	}

	/**
     * Helper function to change the securable objects
     * 
     * @param msg The message which contains the information about which Securable Objects have changed 
     */
    private void handleNotifSecObjectChanged(USMMessage msg) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering handleNotifSecObjectChanged. Message is : " + msg);
        }

        BSTransBicNetCFInfo cf = BSTransBicNetCFInfo.popMe(msg);
        List<BSSecurableObject> lstSecObjs = BSCommonHelper.popSecurableObjectsListFromMessage(msg);
        getWindow().modifySecurableObjects(cf, lstSecObjs);

        LOGGER.debug("Exiting handleNotifSecObjectChanged.");

    }
    
    /**
     * Helper function to change the securable  container Objects
     * 
     * @param msg
     */
	private void handleNotifSecObjectContainerChanged(USMMessage msg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering handleNotifSecObjecContainertChanged. Message is : " + msg);
		}

		BSTransBicNetCFInfo cf = BSTransBicNetCFInfo.popMe(msg);
		List<BSSecurableObjectContainer> securableContainers = BSCommonHelper.popSecurableObjectContainersListFromMessage(msg);
		getWindow().modifySecurableObjectContainers(cf, securableContainers);

		LOGGER.debug("Exiting handleNotifSecObjecContainertChanged.");
	}    

    /**
     * Helper function to handle the Securable objects removed notification
     * 
     * @param msg Message which contains information about the Securable Objects that have been removed.
     */
    private void handleNotifSecObjectUnregistered(USMMessage msg) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering handleNotifSesUnRegistered. Message is : " + msg);
        }

        BSTransBicNetCFInfo cf = BSTransBicNetCFInfo.popMe(msg);
        List lstSecObjs = BSCommonHelper.popSecurableObjectsListFromMessage(msg);
        getWindow().deleteSecurableObjects(cf, lstSecObjs);

        LOGGER.debug("Exiting handleNotifSesUnRegistered.");

    }

    /**
     * Helper function to handle the Securable objects inserted notification
     * 
     * @pMsg pMsg Message which contains information about the Securable Objects that have been added.
     */
    private void handleNotifSecObjectRegistered(USMMessage msg) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering handleNotifSecObjectRegistered. Message is : " + msg);
        }

        BSTransBicNetCFInfo cf = BSTransBicNetCFInfo.popMe(msg);
        List lstSecObjs = BSCommonHelper.popSecurableObjectsListFromMessage(msg);

        getWindow().addSecurableObjects(cf, lstSecObjs);

        LOGGER.debug("Exiting handleNotifSecObjectRegistered.");

    }

    /**
     * @param msg
     */
    private void handleNotifObjectsAssignedUnassigned(USMMessage msg) {
        LOGGER.debug("handleObjectsAssigned() - Enter");
        boolean found = false;
        // This is not of relevance to us
        List nes = new ArrayList();

        DCHelper.popSecurableObjects(msg, nes);
        // End of message content not of relevance
        if (null != modifiedDomain) {

            int nNoOfDomains = msg.popInteger();

            for (int nDomIndex = 0; nDomIndex < nNoOfDomains; nDomIndex++) {
                DCDomainData domInfo = new DCDomainData();
                domInfo.popMe(msg);
                // Check if this the current domain that we are changing
                if (domInfo.equals(modifiedDomain)) {
                    found = true;
                    // we handle only one domain, so that is it
                    break;
                }
            }

            if (found) {
                // This is the Domain for which the NEs have been assigned/unassigned
                // Re fetch all the data for this domain..
                getAllSecurableObjects();

            }
        }
        if (!found) {
            // Update the colour icon for the NEs which belong to the global domain only
            getWindow().domainsAssignUnAssigned(nes);
        }
        LOGGER.debug("handleObjectsAssigned() - Exit");

    }

    /**
     * Handles the response to the assign/unassign of objects to domain
     * 
     * @param msg The result of the assign objects response
     */
    private void handleResponsesAssignUnassignObjectsToDomain(USMMessage msg) {
        LOGGER.debug("handleResponsesAssignUnassignObjectsToDomain() - Enter");
        Integer errorId = msg.popInteger();
        String errorMessage = null;
        if (DCMessages.DC_NO_ERROR.equals(errorId)) {
            getWindow().openAssociatedWindow();
            getWindow().closeWindow();
        } else {
            errorMessage = DCMessages.getInstance().getString(errorId);
            getWindow().showMessage(errorMessage);
        }

        LOGGER.debug("handleResponsesAssignUnassignObjectsToDomain() - Exit");
    }

    /**
     * This method is invoked to create a domain. The list of objects to be assigned are also passed, but get sent only
     * after the creation of domain is successful
     * 
     * @param domain DCDomainData containing name and description which needs to be created
     * @param assignedObjectsList The BSTransSecObjects which need to be assigned to the created domain.
     */
    public void createDomain(DCDomainData domain, List assignedObjectsList) {
        LOGGER.debug("createDomain() - Enter");
        assignedObjects = assignedObjectsList;
        // To unnecessary prevent of checking of null in all places, instead
        // check of size zero should do the task
        unAssignedObjects = new ArrayList();
        DCCreateDomainJob job = new DCCreateDomainJob(DCMessageType.DC_REQ_CREATE_DOMAIN, this, domain);
        queueJob(job);
        LOGGER.debug("createDomain() - Exit");

    }

    /**
     * This method is called to modify the domain details. The list of objects which need to be assigned/unassigned to
     * this domain gets done only after the modify domain(description only) gets done successfully.
     * 
     * @param domain The domain which needs to be modified
     * @param objectsToAssign The BSTransSecObjs which needs to be assigned to this domain
     * @param objectsToUnassign The BSTransSecObjs which needs to be unassigned to this domain
     */
    public void modifyDomain(DCDomainData domain, List objectsToAssign, List objectsToUnassign) {
        LOGGER.debug("modifyDomain() - Enter");
        // Store the domain information that is needed for later assigning of NEs to domain
        modifiedDomain = domain;
        assignedObjects = objectsToAssign;
        unAssignedObjects = objectsToUnassign;

        // Send modify Domain Request message.

        DCModifyDomainJob job = new DCModifyDomainJob(DCMessageType.DC_REQ_MODIFY_DOMAIN, this, domain);
        queueJob(job);
        LOGGER.debug("modifyDomain() - Exit");
    }

    /**
     * This method gets the second level objects of the expanded server for the given domain In the case of create
     * domain, the domain is global domain
     * 
     * @param serverNodeExpanded The server node which is expanded and whose objects for the domain need to be fetched
     * @param assigned True indicating to fetch the assigned objects to this domain and false to indicate to fetch the
     *            not yet assigned objects of this domain
     */
    public void getObjectsOfDomainForServer(BSTransBicNetCFInfo serverNodeExpanded, boolean assigned) {

        LOGGER.debug("getObjectsOfDomainForServer() - Enter");

        DCDomainData domain = modifiedDomain;
        boolean bAssign = assigned;
        if (null == modifiedDomain) {
            // In this case, it has to be only the left tree or un-assigned tree
            if (!assigned) {
                domain = DCDomainData.GLOBAL_DOMAIN;
                bAssign = true;
            }
        }

        DCGetObjectsOfDomainForServerJob job = new DCGetObjectsOfDomainForServerJob(DCMessageType.DC_REQ_DOMAIN_DETAILS_OBJECT_LEVEL, this, domain, bAssign, serverNodeExpanded);
        queueJob(job);
        LOGGER.debug("getObjectsOfDomainForServer() - Exit");

    }
    
    /**
     * This method gets all the securable object from server
     * 
     */
    public void getAllSecurableObjects() {

        LOGGER.debug("getSecurableObjects() - Enter");

        DCGetAllSecurableObjectsJob job = new DCGetAllSecurableObjectsJob(DCMessageType.DC_REQ_ALL_SECURABLE_OBJECTS, this);

        queueJob(job);
        LOGGER.debug("getObjectsOfDomainForServer() - Exit");

    }

}
