package com.ossnms.bicnet.securitymanagement.client.basic.view;

import com.ossnms.bicnet.bcb.model.ManagedObjectType;
import com.ossnms.bicnet.bcb.model.common.IIconPair;
import com.ossnms.bicnet.bcb.model.common.ImageData;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.tools.jfx.JfxIconImpl;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.image.JfxImageUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Some of the Icons are not available in the main Resource Factory. Therefore a Factory tailored for CF USM.
 */
public final class USMResourcesIconFactory {
    private static final Logger LOGGER = LoggerFactory.getLogger(USMResourcesIconFactory.class);

    private static final int ICON_SIZE_16PX = 16;
    private static final Map<ManagedObjectType, JfxIconImpl> managedObjectTypeIconsMap = new HashMap<>();

    static {
        managedObjectTypeIconsMap.put(ManagedObjectType.NE, getNetworkIcon(ResourcesIconFactory.NetworkIcon.NE));
        managedObjectTypeIconsMap.put(ManagedObjectType.MEDIATOR, getNetworkIcon(ResourcesIconFactory.NetworkIcon.MEDIATOR));
        managedObjectTypeIconsMap.put(ManagedObjectType.NETWORK_DOMAIN, getNetworkIcon(ResourcesIconFactory.NetworkIcon.DOMAIN));
        managedObjectTypeIconsMap.put(ManagedObjectType.SYSTEM_CONTAINER, getNetworkIcon(ResourcesIconFactory.NetworkIcon.NE_hit7300));
        managedObjectTypeIconsMap.put(ManagedObjectType.GENERIC_CONTAINER, getNetworkIcon(ResourcesIconFactory.NetworkIcon.CONTAINER));
    }

    /**
     *
     */
    private USMResourcesIconFactory(){

    }


    /**
     * Helper function to return the Icon associated with the ManagedObjectType
     * 
     * @param type
     *            The ManagedObjectType for which we have to get the Icon.
     * @return Icon The icon that should be used for displaying
     */
    public static Icon getIconForManagedObjectType(ManagedObjectType type) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering getIconForManagedObjectType. Object passed is : " + type);
        }

        return getDefaultIcon16x16ForMOType(type);
    }

    private static Icon getDefaultIcon16x16ForMOType(ManagedObjectType type) {
        try {
            JfxIconImpl icon = managedObjectTypeIconsMap.get(type);
            return icon != null ? icon : getNetworkIcon(ResourcesIconFactory.NetworkIcon.NE_UNKNOWN);
        } catch (Exception e) {
            LOGGER.error("Exception when retrieving icons. ", e);
        }
        return null;
    }

    private static JfxIconImpl getNetworkIcon(ResourcesIconFactory.NetworkIcon iconType) {
        try {
            return new JfxIconImpl(ResourcesIconFactory.getNetworkIcon(iconType, JfxUtils.DEFAULT_ICON_SIZE));
        }
        catch (Exception e) {
            LOGGER.error("Error getting network icon",e);
        }
        return null;
    }

    /**
     * @param iconPair implementation of interface IIconPair
     * @return the icon requested
     */
    public static Icon getIcon(IIconPair iconPair, ManagedObjectType moType) {
    	Icon result = null;
    	
    	if(iconPair == null) {
    	    return getIconForManagedObjectType(moType);
    	}
    	
    	try {
    		ImageData imageDat = iconPair.getGraphicalImage();
    		result = JfxImageUtil.createFromFileData(imageDat.getData(), imageDat.getFormat().toString(), ICON_SIZE_16PX);
    	} catch (Exception ex) {
    		LOGGER.error("Problem when trying to analyse icon or bitmap data.", ex);
    	}

        if (result == null) {
            result = getIconForManagedObjectType(moType);
        }
        return result;
    }

}