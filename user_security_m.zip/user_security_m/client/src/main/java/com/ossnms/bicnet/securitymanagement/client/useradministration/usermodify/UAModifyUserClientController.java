/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 15-Feb-2005	Muyeen Munaver	CF000995 - Password Expiration Interval
 * 15-Feb-2005	Muyeen Munaver	CF001006 - "Make user change inital password after ...Days" doesn't work properly
 * 18-Mar-2005  Asif khan R     CF001755 Error Messages when LDAP not available
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.useradministration.usermodify;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMBaseController;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobCheckUsergroupContainsUser;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobGetAllAssignedAndUnAssignedUsergroups;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobGetAllPasswordValidationRules;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobModifyUser;
import com.ossnms.bicnet.securitymanagement.common.auth.AAMessageType;
import com.ossnms.bicnet.securitymanagement.common.auth.PasswordValidationRulesConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.general.GSStatus;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAStatus;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserGroup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * This class implements the controller for modify user view.This listens to the
 * notifications and updates the view
 */
class UAModifyUserClientController extends USMBaseController {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(UAModifyUserClientController.class);

    /**
     * This is the constructor
     *
     * @param view -
     *             The view associated with the controller
     */
    UAModifyUserClientController(USMBaseView view) {
        super(view);

        registerInterestedNotificationIds(getInterestedNotifcations());
    }

    /**
     * This method handles modification of users
     *
     * @param userData           -
     *                           The user object to be modified
     * @param assignedUserGroups -
     *                           The Vector of user groups to which the user is assigned to
     * @return boolean - True indicates that the operation was successful
     */
    boolean modifyUser(UAUser userData, List<?> assignedUserGroups) {
        UAJobModifyUser objCreatepolicy = new UAJobModifyUser(userData, this, assignedUserGroups);
        return queueJob(objCreatepolicy);
    }

    UAModifyUserView getAssociatedView() {
        return (UAModifyUserView) associatedView;
    }

    /**
     * Helper function to return the List of Notification IDs which this
     * controller is interested in.
     *
     * @return List -
     * The List of Notification IDs that the controller is interested in
     */
    private List<USMBaseMsgType> getInterestedNotifcations() {
        LOGGER.debug("getInterestedNotifcations() entry");
        List<USMBaseMsgType> vecNotif = new ArrayList<>();
        vecNotif.add(UAMessageType.S_UA_NOT_MODIFY_USER);
        vecNotif.add(UAMessageType.S_UA_NOT_REMOVE_USER);
        vecNotif.add(UAMessageType.S_UA_NOT_REMOVE_USERGROUP);
        vecNotif.add(UAMessageType.S_UA_NOT_CREATE_USERGROUP);
        vecNotif.add(UAMessageType.S_UA_NOT_ACTIVATE_USER);
        vecNotif.add(UAMessageType.S_UA_NOT_DEACTIVATE_USER);
        vecNotif.add(UAMessageType.S_UG_NOT_MODIFY_USER_GROUP);
        vecNotif.add(UAMessageType.S_UG_NOT_CREATE_USER_GROUP);
        vecNotif.add(AAMessageType.AA_NOTIFICATION_USER_PASSWORD_CHANGED);
        LOGGER.debug("getInterestedNotifcations() exit");
        return vecNotif;
    }

    /**
     * This method gets all assigned and unassigned user groups
     *
     * @param userID - The user string which is used to get the vector of assigned and unassigned user groups
     * @return boolean - True indicates that the operation was successfully completed
     */
    boolean getAllAssignedAndUnassignedUsergroups(String userID) {
        UAJobGetAllAssignedAndUnAssignedUsergroups objModifyuser = new UAJobGetAllAssignedAndUnAssignedUsergroups(this, userID);
        return queueJob(objModifyuser);
    }

    /**
     * Helper method called by the framework when a response is received.
     * Forwards to the appropriate method
     *
     * @param job    reference to the job which resulted in the original request
     * @param result result of executing the given job
     */
    @Override
    public void resultAvailable(USMJob job, USMMessage result) {
        LOGGER.info(" resultAvailable() entry");

        USMBaseMsgType msgType = result.getMessageType();
        if (msgType.equals(UAMessageType.S_UA_RES_MODIFY_USER)) {
            handleResponseForModifyUser(result);
        } else if (
                msgType.equals(UAMessageType.S_UA_RES_GET_ASSIGNED_AND_UNASSIGNED_USERGROUP)) {
            handleResponseForGetAllAssignedAndUnassignedUserGroups(result);
        } else if (
                msgType.equals(UAMessageType.S_UA_RES_GET_ALL_PASSWORD_VALIDATION_RULES)) {
            handleResponseForGetAllPasswordValidationRules(result);
        } else if (
                msgType.equals(UAMessageType.S_UA_RES_CHECK_USERGROUP_CONTAINS_USER)) {
            handleResponseForCheckUsergroupContainsUser(result);
        } else {
            LOGGER.error("Got a message which could not be handled. Message is {}", msgType.toString());
        }
    }

    /**
     * Handles the check of whether the user group contains the specified user
     *
     * @param result contains the result of the operation
     */
    private void handleResponseForCheckUsergroupContainsUser(USMMessage result) {
        Boolean bop = result.popBoolean();
        String ugrp = result.popString();
        if (ugrp == null) {
            LOGGER.info(" invalid usergroup value");
        } else {
            getAssociatedView().updateViewWithCheckUserGroupContainsUser(ugrp, bop);
        }
    }

    /**
     * Handles the response for the modify user operation
     *
     * @param message contains the result of the operation
     */
    private void handleResponseForModifyUser(USMMessage message) {
        final String functionName = "handleResponseForModifyUser()";
        LOGGER.debug("{} ENTER_FUNCTION", functionName);

        try {
            // Pop the Result of the Operation.
            UAStatus statusObject = new UAStatus();
            statusObject.popMe(message);
            int nUAResult = statusObject.getStatus();

            GSStatus gsStatusObject = new GSStatus();
            gsStatusObject.popMe(message);
            int nGSResult = gsStatusObject.getStatus();

            if ((nUAResult == UAStatus.S_SUCCESS) && (nGSResult == GSStatus.S_SUCCESS)) {
                LOGGER.debug("{} close MODIFY user window", functionName);
                getAssociatedView().close();
            } else {
                String csUserMessage = null;

                if (nUAResult == UAStatus.S_LDAP_ERROR) {
                    LOGGER.error("{} Server returned LDAP Error", functionName);
                    csUserMessage = USMStringTable.getString(USMStringTable.IDS_UA_LDAP_ERROR);

                } else if (nUAResult == UAStatus.S_INTERNAL_ERROR) {
                    LOGGER.error("{} Server returned Internal Error", functionName);
                    csUserMessage = USMStringTable.getString(USMStringTable.IDS_UA_SERVER_RETURNED_ERROR);

                } else if (nUAResult == UAStatus.S_LDAP_PASSWORD_HISTORY) {
                    LOGGER.error("{} Could not change password", functionName);
                    csUserMessage = USMStringTable.getString(USMStringTable.IDS_UA_PASSWORD_HISTORY_ERROR);
                } else if (nUAResult == UAStatus.USER_AND_PASSWORD_NOT_COMPLIANT_WITH_RULES) {
                    csUserMessage = USMStringTable.getString(USMStringTable.IDS_UA_USER_AND_PASSWORD_NOT_COMPLIANT_WITH_RULES);

                } else if (nGSResult == GSStatus.S_PASSWORD_COMP_ERROR) {
                    csUserMessage = USMStringTable.getString(USMStringTable.IDS_GS_PASSWORD_COMP_ERROR_MESSAGE);

                } else if (nGSResult == GSStatus.S_PASSWORD_CONTAIN_CIRCULARID) {
                    csUserMessage = USMStringTable.getString(USMStringTable.IDS_GS_PASSWORD_CONTAINS_CIRCULAR_ID_MESSAGE);

                } else if (nGSResult == GSStatus.S_PASSWORD_CONTAINS_UID) {
                    csUserMessage = USMStringTable.getString(USMStringTable.IDS_GS_PASSWORD_CONTAINS_UID_MESSAGE);

                } else if (nGSResult == GSStatus.S_PASSWORD_LENGTH_ERROR) {
                    csUserMessage = USMStringTable.getString(USMStringTable.IDS_GS_PASSWORD_LENGTH_ERROR_MESSAGE);

                } else if (nGSResult == GSStatus.S_PASSWORD_SAME_AS_USERID) {
                    csUserMessage = USMStringTable.getString(USMStringTable.IDS_GS_PASSWORD_SAME_AS_USERID_MESSAGE);

                } else if (nGSResult == GSStatus.S_PASSWORD_CONTAIN_CONSECUTIVE_CHARS) {
                    csUserMessage = USMStringTable.getString(USMStringTable.IDS_GS_PASSWORD_CONTAIN_CONSECUTIVE_CHARS);

                }
                if (csUserMessage != null) {
                    getAssociatedView().showMessage(csUserMessage);
                }
            }

        } catch (Exception ex) {
            LOGGER.error("{} EXCEPTION: {} Message : {}", functionName, ex.getClass(), ex.getMessage());
        }

        LOGGER.debug("{} EXIT_FUNCTION", functionName);

    }

    /**
     * Handles the response for the get assigned/unassigned user groups operation
     *
     * @param result contains the result of the operation
     */
    private void handleResponseForGetAllAssignedAndUnassignedUserGroups(USMMessage result) {
        LOGGER.info("handleResponseForGetAllAvailableMenuOptions() MESSAGE SIZE ");
        final String FUNC_NAME = "treatResponseGetAllAvailableMenuOptions ( ) ";

        LOGGER.debug("user groups fetched successfully ");
        UAUser userdata = new UAUser();

        List<String> vecassignedUgrp = new ArrayList<>();
        List<String> vecAvailableUgrp = new ArrayList<>();

        // Pop the Count of Available Menu options ( STRINGS )
        int nCount = result.popInteger();

        LOGGER.debug("{} Number of Available user groups retrieved from the Server : {}", FUNC_NAME, nCount);

        for (int idx = 0; idx < nCount; ++idx) {
            String ugrpName = result.popString();
            vecAvailableUgrp.add(ugrpName);
        }
        int nCount1 = result.popInteger();

        LOGGER.debug("{} Number of Assigned user groups retrieved from the Server : {}", FUNC_NAME, nCount1);

        for (int idx = 0; idx < nCount1; ++idx) {
            String ugrpName1 = result.popString();
            vecassignedUgrp.add(ugrpName1);
        }
        userdata.popMe(result);
        getAssociatedView().updateViewWithAssignedUnassignedUserGroupResult(vecAvailableUgrp, vecassignedUgrp, userdata);

        LOGGER.debug("{} EXIT_FUNCTION", FUNC_NAME);
    }

    /**
     * Helper method called by the framework when a notifiaction is received.
     * Forwards to the appropriate method
     *
     * @param message Message encapsulating the notification
     */
    @Override
    public void handleNotification(USMMessage message) {
        USMBaseMsgType type = message.getMessageType();
        if (type.equals(UAMessageType.S_UG_NOT_CREATE_USER_GROUP)) {
            handleNotificationUserGroupCreated(message);
        } else if (type.equals(UAMessageType.S_UG_NOT_REMOVE_USER_GROUP)) {
            handleNotificationUserGroupRemoved(message);
        } else if (type.equals(UAMessageType.S_UG_NOT_MODIFY_USER_GROUP)) {
            handleNotificationUserGroupModified(message);
        } else if (type.equals(UAMessageType.S_UA_NOT_MODIFY_USER)) {
            handleNotificationUserModified(message);
        } else if (type.equals(UAMessageType.S_UA_NOT_REMOVE_USER)) {
            handleNotificationUserDeleted(message);
        } else if (type.equals(UAMessageType.S_UA_NOT_ACTIVATE_USER)) {
            handleNotificationUserActivated(message);
        } else if (type.equals(UAMessageType.S_UA_NOT_DEACTIVATE_USER)) {
            handleNotificationUserDeactivated(message);
        } else if (
                type.equals(AAMessageType.AA_NOTIFICATION_USER_PASSWORD_CHANGED)) {
            handleNotificationUserPasswordChanged(message);
        }
    }

    /**
     * @param message
     */
    private void handleNotificationUserPasswordChanged(USMMessage message) {
        String strUserID = message.popString();
        ((UAModifyUserView) associatedView).onUserPasswordChanged(strUserID);
    }

    /**
     * Function that is called for handling of User Group Modified
     *
     * @param message
     */
    private void handleNotificationUserGroupModified(USMMessage message) {
        LOGGER.debug("Entering handleNotificationUserGroupModified.");
        UAUserGroup ug = new UAUserGroup();
        ug.popMe(message);
        String strUsrID =
                ((UAModifyUserView) associatedView).getAssociatedUserID();
        String strUGId = ug.getName();
        UAJobCheckUsergroupContainsUser job =
                new UAJobCheckUsergroupContainsUser(strUGId, strUsrID, this);
        queueJob(job);

        LOGGER.debug("Exiting handleNotificationUserGroupModified.");
    }

    /**
     * Handles the notification for the user activated operation
     *
     * @param message the notification message
     */
    private void handleNotificationUserDeactivated(USMMessage message) {
        final String FUNC_NAME = "handleNotificationUserDeactivated( )";
        LOGGER.debug("{} ENTER_FUNCTION", FUNC_NAME);

        if (message == null) {
            LOGGER.error("{} notification message is null", FUNC_NAME);
        } else {
            int nDeactivatedUserCount = message.popInteger();

            List<String> lstDeactivatedUsers = new ArrayList<>();
            while (nDeactivatedUserCount-- > 0) {
                String strUserId = message.popString();
                lstDeactivatedUsers.add(strUserId);
            }

            ((UAModifyUserView) associatedView).onUserDeactivated(
                    lstDeactivatedUsers);
            LOGGER.debug("{} EXIT_FUNCTION", FUNC_NAME);
        }
    }

    /**
     * Handles the notification for the user activated operation
     *
     * @param message the notification message
     */
    private void handleNotificationUserActivated(USMMessage message) {
        final String FUNC_NAME = "handleNotificationUserActivated( )";
        LOGGER.debug("{} ENTER_FUNCTION", FUNC_NAME);

        if (message == null) {
            LOGGER.error("{} notification message is null", FUNC_NAME);
        } else {
            int nActivatedUserCount = message.popInteger();

            List<String> lstActivatedUsers = new ArrayList<>();
            while (nActivatedUserCount-- > 0) {
                String strUserId = message.popString();
                lstActivatedUsers.add(strUserId);
            }

            ((UAModifyUserView) associatedView).onUserActivated(
                    lstActivatedUsers);
            LOGGER.debug("{} EXIT_FUNCTION", FUNC_NAME);
        }
    }

    /**
     * Handles the notification for the user deleted operation
     *
     * @param message the notification message
     */
    private void handleNotificationUserDeleted(USMMessage message) {
        final String FUNC_NAME = "handleNotificationUserDeleted( )";
        LOGGER.debug("{} ENTER_FUNCTION", FUNC_NAME);

        if (message == null) {
            LOGGER.error("{} notification message is null", FUNC_NAME);
        } else {
            // Pop the number of deleted policies.
            int nDeletedPolicyCount = message.popInteger();

            List<String> vecDeletedUser = new ArrayList<>();
            for (int idx = 0; idx < nDeletedPolicyCount; ++idx) {
                String deletedUser = message.popString();
                vecDeletedUser.add(deletedUser);
            }

            if (associatedView.isShowing()) {
                ((UAModifyUserView) associatedView).onUserDeleted(vecDeletedUser);
            }
            LOGGER.debug("{} EXIT_FUNCTION", FUNC_NAME);
        }
    }

    /**
     * Handles the notification for the user modified operation
     *
     * @param message the notification message
     */
    private void handleNotificationUserModified(USMMessage message) {
        final String FUNC_NAME = "handleNotificationUserModified()";
        LOGGER.debug("{} ENTER_FUNCTION ", FUNC_NAME);

        if (message == null) {
            LOGGER.error("{} notification message is null", FUNC_NAME);
        } else {
            UAUser modifiedUser = new UAUser();
            modifiedUser.popMe(message);

            UAModifyUserView vw = (UAModifyUserView) associatedView;
            if (vw.getUserID().equals(modifiedUser.getUserId())) {
                getAllAssignedAndUnassignedUsergroups(modifiedUser.getUserId());
            }
        }
        LOGGER.debug("{} EXIT_FUNCTION", FUNC_NAME);
    }

    /**
     * Handles the notification for the user group removed operation
     *
     * @param message the notification message
     */
    private void handleNotificationUserGroupRemoved(USMMessage message) {
        final String FUNC_NAME = "handleNotificationUsergroupRemoved( )";
        LOGGER.info("{} ENTER_FUNCTION", FUNC_NAME);

        if (message == null) {
            LOGGER.warn("{} notification message is null", FUNC_NAME);
        } else {
            UAUserGroup ugrp = new UAUserGroup();
            ugrp.popMe(message);

            ((UAModifyUserView) associatedView).onUserGroupRemoved(ugrp.getName());
        }
        LOGGER.info("{} EXIT_FUNCTION", FUNC_NAME);
    }

    /**
     * Handles the notification for the user group created operation
     *
     * @param message the notification message
     */
    private void handleNotificationUserGroupCreated(USMMessage message) {
        final String FUNC_NAME = "handleNotificationUserModified()";
        LOGGER.debug("{} ENTER_FUNCTION ", FUNC_NAME);

        if (message == null) {
            LOGGER.error("{} notification message is null", FUNC_NAME);
        } else {

            UAModifyUserView vw = (UAModifyUserView) associatedView;
            UAUserGroup ugrp = new UAUserGroup();
            ugrp.popMe(message);

            checkUserGroupContainsUser(ugrp.getName(), vw.getUserID());
        }

        LOGGER.debug("{} EXIT_FUNCTION", FUNC_NAME);
    }

    /**
     * Verifies whether the given usergroup contains the given user.
     * Returns true if the user group contains the given user
     *
     * @param ugrp user group id
     * @param user user id
     */
    private boolean checkUserGroupContainsUser(String ugrp, String user) {
        UAJobCheckUsergroupContainsUser objUserGroupContainsUser = new UAJobCheckUsergroupContainsUser(ugrp, user, this);
        return queueJob(objUserGroupContainsUser);
    }

    /**
     * Overriding the add job method for showing the loading image
     */
    @Override
    public void addJob(USMJob job) {
        LOGGER.debug("addJob() Entry");

        if (job == null) {
            LOGGER.error("addJob() Job passed cannot be null.");
            return;
        }

        synchronized (jobs) {
            job.registerJobAddedToQueue();
            jobs.put(job.getID(), job);
        }

        // Since there is a Job it means that we have to wait for some
        // response.
        if (associatedView != null) {
            associatedView.setWaitCursor();
        }

        LOGGER.debug("addJob() Exit");
    }

    /**
     * Overriding the method endjob to remove the Loading screen
     */
    @Override
    public void endJob(USMJob job) {
        LOGGER.debug("endJob() Entry");

        if (job == null) {
            LOGGER.error("Job passed cannot be null.");
            return;
        }
        boolean bFlagSetNormalCursor;
        synchronized (jobs) {
            jobs.remove(job.getID());
            bFlagSetNormalCursor = (jobs.size() == 0);
        }

        if (bFlagSetNormalCursor
                // Now we have received all the responses for the requests. So we can remove the cursor.
                && associatedView != null) {
            associatedView.setNormalCursor();
        }

        LOGGER.debug("endJob() Exit");
    }

    /**
     * Sends a request to get all password validation rules. The objective is to enforce these rules
     * when creating/modifying a users password.
     *
     * @return boolean - True indicates the operation was completed
     *         successfully
     */
    public boolean sendReqToGetAllPasswordValidationRules() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("sendReqToGetAllPasswordValidationRules()	  Enter");
        }
        UAJobGetAllPasswordValidationRules objJobgetAllPasswordValidationRules =
                new UAJobGetAllPasswordValidationRules(this);
        boolean bStatus = queueJob(objJobgetAllPasswordValidationRules);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "sendReqToGetAllPasswordValidationRules()	  Exit - Return :" + bStatus);
        }
        return bStatus;

    }

    /**
     * Handles the response for the get all user groups operation
     *
     * @param result
     *            contains the result of the operation
     */
    private void handleResponseForGetAllPasswordValidationRules(USMMessage result) {
        LOGGER.info("handleResponseForGetAllPasswordValidationRules() MESSAGE SIZE ");
        UAModifyUserView vw = (UAModifyUserView) associatedView;
        PasswordValidationRulesConfigurationData data = new PasswordValidationRulesConfigurationData();

        // Pop the Result of the Operation.
        UAStatus statusObject = new UAStatus();
        statusObject.popMe(result);

        if (statusObject.getStatus() == UAStatus.S_SUCCESS) {
            LOGGER.info("rules fetched successfully ");

            data.popMe(result);

            vw.updateViewWithPasswordValidationRulesResult(data.isPasswordMustNotHaveSpaces(), data.isPasswordMustBeDifferentFromName(),
                    data.isPasswordMustBeDifferentFromEmployeeNumber(), data.isPasswordMustBeDifferentFromDate());
        } else if (statusObject.getStatus() == UAStatus.S_INTERNAL_ERROR) {
            vw.showMessage(
                    USMStringTable.getString(USMStringTable.IDS_UA_USER_CREATE_MODIFY_ERROR_FETCH_PASSWORD_VALIDATION_RULES));
            LOGGER.info(" handleResponseForGetAllAvailableUserGroups() Failed to Fetch All Available rules from Server");
        }

        LOGGER.debug(" handleResponseForGetAllAvailableUserGroups() EXIT_FUNCTION");
    }

}