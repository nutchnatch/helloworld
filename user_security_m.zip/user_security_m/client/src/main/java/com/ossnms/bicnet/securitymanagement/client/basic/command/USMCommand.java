/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMCommand
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 06-May-2009  Nagaraddi S S    TD004578 - RQT-STDERR errors instead log4j's
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.command;

import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;
import org.apache.log4j.Logger;

import javax.swing.*;
import java.security.InvalidParameterException;

/**
 * This is the generic command interface which declares the necessary  methods to
 * be overriden by the user inteface command handlers. This is the core class
 * which streamlines the process of command execution in a generic manner.
 */
public abstract class USMCommand implements Cloneable {
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(USMCommand.class);

    /**
     * This attribute indicates if the command handler is successfully registered with
     * the UI command register.
     */
    private boolean isCmdHndlrRegistered = false;

    /**
     * Command ID associated with the command
     */
    private USMCommandID nCommandId;

    /**
     * Data member to hold the View object that is associated with 
     * this Command. This is needed so that the base class itself can
     * do the following operations
     * 1) Reactivation of the window if the user selects the same menu 
     * 2) Closing of the window in case user logging off.
     */
    private USMBaseView view;

    /**
     * This is the constructor that will register the passed command
     * handler object with UICmdRegister in order to be invoked when the command is
     * invoked.
     * Note : This method will register the command handler object and the command ID
     * with the UI command register. Further call to registerCmd() with the same ID
     * will fail. The user should call isCmdHndlrRegistered() method to check if the
     * command handler is registered successfully.
     * 
     * @param uiCmdID - This is the command ID associated with the command handler
     * object
     */
    protected USMCommand(USMCommandID uiCmdID) {
        if (null == uiCmdID) {
            throw new InvalidParameterException("The CommandID cannot be null");
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering Constructor for Command ID : " + uiCmdID);
        }

        nCommandId = uiCmdID;
        isCmdHndlrRegistered =
            USMCommandManager.getInstance().registerCmd(this);

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                "Exiting Constructor for Command ID : "
                    + uiCmdID
                    + " result of registration is : "
                    + isCmdHndlrRegistered);
        }
    }

    /**
     * This method which should be overridden by the interface
     * users in order to handle the associated command invocations. If the execution
     * of command fails, the overriden execute should return false indicating that
     * command should not be added to active command list
     * 
     * @param selList - The selection list containing the selection items
     * 
     * @return boolean - Return true to indicate a successful execution of over ridden command.
     */
    public boolean execute(Object selList) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering execute. Selection List is : " + selList);
        }

        view = createAndReturnView();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                "Created View successfully for the Command. View is : "
                    + view);
        }
        view.setCommand(this);

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                view.showWindow();
            }
        });

        LOGGER.debug("Exiting execute. Result of show window is : ");
        return true;
    }

    /**
     * Abstract method that has to be implemented by the derived class.
     * 
     * @return USMBaseView - The View object that has been created.
     */
    protected abstract USMBaseView createAndReturnView();

    /**
     * This method returns the command ID
     * 
     * @return USMCommandID - Returns the command id associated with the command.
     */
    public final USMCommandID getCommandID() {
        return nCommandId;
    }

    /**
     * This method reactivates the already active window
     * 
     * @param selList - The list of objects that got selected.
     * 
     * @return boolean - Returns true on successful activation of the command.
     */
    public boolean reactivate(final Object selList) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                "Entering reactivate. Selection List is : " + selList);
        }

        boolean bReactivated = false;
        if (null != view) {
            view.bringToFront();
            bReactivated = true;
        } else {
            LOGGER.error("Trying to reactivate a null view");
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                "Exiting reactivate. Result of reactivation is : "
                    + bReactivated);
        }

        return bReactivated;
    }

    /**
     * This method should be overriden by the command handlers and the base class
     * cleanup should be called in order to deregister the command from the list of
     * active commands
     */
    public void cleanup() {
        LOGGER.debug("Entering cleanup");
        // Fault ID 78 - Controller sleanup should be done correctly by all classes - Begin
        if (null != view) {
            view.cleanup();
        }
        // Fault ID 78 - Controller sleanup should be done correctly by all classes - End
        view = null;

        USMCommandManager.getInstance().removeFromActiveCmdList(this);

        LOGGER.debug("Exiting cleanup");
    }

    /**
     * This method should be overrriden by command handlers to find out if a new
     * command should be invoked or an already existing should be reactivated.
     * 
     * By default this function will return true. Therefore windows which should have
     * only a single instance need not bother to over ride it. But Windows like
     * Server Properties or Modify Domain window which are dependent on the selection
     * should over ride this function and return true or false, depending on whether
     * instance is the same or not.
     * 
     * @param cmd - The command object against which this should be comapred.
     * 
     * @return boolean - Returns true always
     */
    public boolean compare(USMCommand cmd) {
        return true;
    }

    /**
     * This method returns a cloned instance of command handler object on which the
     * method is invoked.
     * 
     * @param selList - The selection list containing selection item
     * 
     * @return USMCommand - Returns the USMCommand that newly got created.
     */
    public USMCommand cloneCmd(Object selList) {
        LOGGER.debug("Entering cloneCmd");
        USMCommand cmdObj = null;
        try {
            cmdObj = (USMCommand) clone();
        } catch (CloneNotSupportedException e) {
            LOGGER.error("Error while cloning. " + e.getMessage());
           
        }

        LOGGER.debug("Exiting cloneCmd");
        return cmdObj;
    }

    /**
     * This method should be called if the command handler is registered using
     * constructor. (See the documentation for constructor for
     * further details)
     * 
     * @return boolean - Returns true if the command was successfully registered.
     */
    public boolean isCmdHndlrRegistered() {
        return isCmdHndlrRegistered;
    }

    /**
     * Function to retrieve the associated view with this command
     * 
     * @return USMBaseView - Returns the m_View.
     */
    public USMBaseView getView() {
        return view;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Command for " + nCommandId;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    public Object getKey() {
        return "Command for " + nCommandId;
    }

}
