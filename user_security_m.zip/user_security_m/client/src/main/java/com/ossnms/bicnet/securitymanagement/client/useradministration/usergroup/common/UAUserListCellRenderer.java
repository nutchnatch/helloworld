package com.ossnms.bicnet.securitymanagement.client.useradministration.usergroup.common;

import java.awt.Component;

import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;

import com.ossnms.bicnet.resources.ResourcesIconFactory;

/**
 * Renderer for the list to display available and assigned users with an icon in front
 */
class UAUserListCellRenderer extends DefaultListCellRenderer {
    private static final long serialVersionUID = -2680405736803429315L;

    /**
     * This is the only method defined by ListCellRenderer. We just reconfigure the JLabel each time we're called.
     * 
     * @param list
     *            The list which is the container for the Objects that need special display
     * @param value
     *            Value to display
     * @param index
     *            Cell index
     * @param isSelected
     *            Is the cell selected
     * @param cellHasFocus
     *            Indicates whether the cell has focus.
     * @return Component The Rendered that is to be used.
     * 
     * @see javax.swing.ListCellRenderer#getListCellRendererComponent(javax.swing.JList, java.lang.Object, int, boolean, boolean)
     */
    @Override
    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        // Set the icon here.
        setIcon(ResourcesIconFactory.ICON_STATUS_ACTIVATED_USER_16);

        return this;
    }
  
}