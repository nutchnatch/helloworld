/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 31-Jan-2005  Babu B          CF001093    Computer name column - not empty when nobody is logged with that UserId
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 * 01-Sep-2005  Muyeen Munaver  CF002611 - 9320_MR_0217:EMS Client logged out despite inactivity setting of "0".
 * 11-Jan-2006  Balasubramanya  CF002611 - 9320_MR_0217:EMS Client logged out despite inactivity setting of "0".
 * 08-Sep-2005  Muyeen Munaver  CF002611 - 9320_MR_0217:EMS Client logged out despite inactivity setting of "0".
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.auth;

import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.bicnet.securitymanagement.api.common.OperationResult;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Simple demo that uses java.util.Timer to schedule a task to execute
 * once configured period have passed.
 */

public final class AAServerSessionTimer {
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(AAServerSessionTimer.class);

    /**
     * Data member to hold timer object
     */
	private Timer timer;

    /**
     * Holds the interval period for the timer (in seconds)
     */
    private static final int S_INTERVAL = 150;
    
    private static final int S_PERIOD = S_INTERVAL * 1000;

    /**
     * Data Member for self reference of the object
     */
    private static AAServerSessionTimer instance = new AAServerSessionTimer();

    /**
     * Returns the single instance of the class
     * @return AAServerSessionTimer - Self instance of the class
     */
    public static synchronized AAServerSessionTimer getInstance() {
        return instance;
    }

    /**
     * Default constructor for singleton class
     *
     */
    private AAServerSessionTimer() {
    }

	/**
	 * Starts the timer to be executed at given interval
	 */
	public void startTimer() {
		LOGGER.debug("AAServerSessionTimer() - entry");

		timer = new Timer();
		timer.schedule(
				new ServerPingingTask(),
				S_PERIOD,
				S_PERIOD);

		LOGGER.debug("AAServerSessionTimer() - exit");
	}

    /**
     * Terminates the timer to be executed at given interval
     */
    public void cancelTimer() {
        LOGGER.debug("cancelTimer() - entry");

        timer.cancel();
		timer = null;

        LOGGER.debug("cancelTimer() - exit");
    }

	/**
     * This class provides the functionality to ping the user monitoring bean object at fixed interval. 
     * Whenever scheduled timer executed, this class run method will be called.
     * 
     */
    static class ServerPingingTask extends TimerTask {
        /**
         * Logger for this class
         */
        private static final Logger LOGGER = LoggerFactory.getLogger("Interface.Client-Server");

        @Override
        public void run() {
            LOGGER.debug("run() - entry");

            try {
                LOGGER.info("Calling the setActive method on the server...");
                // calling bean method to set the last request time on server
                OperationResult result = new AALoginBusinessDelegate().setActive();

                switch (result.getStatus()){
                    case INTERNAL_ERROR:
                        // in case the set active was not possible
                        LOGGER.info("Server returned error when calling set active. Logging off.");
                        ISecureClientSession secureClientSession = USMUtility.getInstance().getSecureClientSession();
                        USMUtility.getInstance().getSecurityPlugin().logoff(secureClientSession, IPluginSecurityProvider.LogoffReason.JMS_CONNECTION_ERROR);
                        break;
                    default:
                        LOGGER.debug("Server returned {}", result);
                        break;
                }
            } catch (Exception e) {
                LOGGER.error("Exception when calling setActive", e);
            }

            LOGGER.debug("run() - exit");
        }
    }
}
