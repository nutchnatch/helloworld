/*
 * Classname			-	AAJobChangePassword
 * 
 * Version information	-	V1.0
 * 	
 * Date					-	July 14, 2004
 * 
 * Author				-	Jogender Singh
 * Substitue			-	Babu B
 * 
 * Copyright notice	
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.PASSWORD.CHANGE
 *   
 * --------------------------------------------------------
 * History
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 * 
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.auth.job;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.auth.AAChangePasswordDelegate;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.common.auth.AAChangePasswordDetails;
import com.ossnms.bicnet.securitymanagement.common.auth.AAMessageType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import org.apache.log4j.Logger;

/**
 * This is the job scheduler for change password which schedules the 
 * change password operation by putting the request 
 * in the queue job on the client side.
*/
public class AAJobChangePassword extends USMJob {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(AAJobChangePassword.class);

	/**
	 * Data member to hold the User Details Object that has to be created.
	 */
	private AAChangePasswordDetails userDetails;

	/** Constructor 
	  * @param pJobOwner- Handler for received message
	  * @param userDetails- Change password details
	*/
	public AAJobChangePassword(
		USMControllerIfc pJobOwner,
		AAChangePasswordDetails userDetails) {
		super(
			AAMessageType.AA_RESPONSE_USER_CHANGEPASSWORD,
			USMStringTable.IDS_AA_CHANGE_PASSWORD_JOB_TITLE.toString(),
			USMCommonStrings.EMPTY,
			pJobOwner);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"AAJobChangePassword(" + userDetails + ")	Entry");
		}

		this.userDetails = userDetails;
		LOGGER.debug("AAJobChangePassword	Exit");
	}

	/* (non-Javadoc)
	* @see com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob#executeJob()
	*/
	@Override
    public USMMessage executeJob() throws BcbSecurityException {
		LOGGER.debug("executeJob() 	Entry");
		AAChangePasswordDelegate objChgPwdDelegate =
			new AAChangePasswordDelegate();
		USMMessage objUSMMessage =
			objChgPwdDelegate.changePassword(userDetails);
		LOGGER.debug("executeJob() 	Exit");
		return objUSMMessage;
	}

}