/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-Apr-2005	Asif			CF000834 - Command Log Entries	CF USM
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration.usergroupadmin;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMBaseController;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobDeleteUserGroup;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobGetAllUserGroup;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAStatus;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserGroup;
import com.ossnms.tools.jfx.JfxStringTable;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * This class implements the controller for the User Group Administration
 * View. This listens to the notifications and updates the view.
 * 
 * Handles following notification:
 * 1. S_UG_NOT_CREATE_USER_GROUP - Creation of the user group
 * 2. S_UG_NOT_MODIFY_USER_GROUP - Modification of the user group
 * 3. S_UG_NOT_REMOVE_USER_GROUP - Deletion of the user groups
 */
public class UAUserGroupAdministrationClientController
	extends USMBaseController {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(UAUserGroupAdministrationClientController.class);

	/**
	 * This constructor associate the view to this controller and 
	 * register for the interested notifications
	 * 
	 * @param pView -
	 *            The view associated with the controller
	 */
	public UAUserGroupAdministrationClientController(UAUserGroupAdministrationView pView) {
		super(pView);
		registerInterestedNotificationIds(getInterestedNotifications());
	}

	/**
	 * Function to return a Vector which contains the list of types that this
	 * controller is interested in.
	 * 
	 * @return List - 
	 *     The List which contains the notifications the controller is
	 * 	interested in.
	 */
	private List getInterestedNotifications() {
		LOGGER.debug("getInterestedNotifications() 	Entered");
		List vectorForNotification = new ArrayList();
		vectorForNotification.add(UAMessageType.S_UG_NOT_CREATE_USER_GROUP);
		vectorForNotification.add(UAMessageType.S_UG_NOT_MODIFY_USER_GROUP);
		vectorForNotification.add(UAMessageType.S_UG_NOT_REMOVE_USER_GROUP);
		LOGGER.debug("getInterestedNotifications() 	Exit");
		return vectorForNotification;
	}

	/**
	 * Helper method called by the framework when a notifiaction is received.
	 * Forwards to the appropriate method
	 * 
	 * @param p_message
	 *      Message encapsulating the notification
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc#handleNotification(com.ossnms.bicnet.securitymanagement.common.basic.USMMessage)
	 */
	@Override
    public void handleNotification(USMMessage p_message) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"handleNotification("
					+ p_message.getMessageType()
					+ ") 	Entered");
		}
		//Check for the message is null or not
		if (p_message == null) {
			LOGGER.info("Invalid_Message_Passed_27");
		} else {
			// action on user group creation notification
			if (p_message
				.getMessageType()
				.equals(UAMessageType.S_UG_NOT_CREATE_USER_GROUP)) {
				updateViewOnCreateNotification(p_message);
			}
			//			action on user group deletion notification 
			else if (
				p_message.getMessageType().equals(
					UAMessageType.S_UG_NOT_REMOVE_USER_GROUP)) {
				updateViewOnDeleteNotification(p_message);
			}
			//			action on user group modification notification
			else if (
				p_message.getMessageType().equals(
					UAMessageType.S_UG_NOT_MODIFY_USER_GROUP)) {
				updateViewOnModifyNotification(p_message);
			}

		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"handleNotification("
					+ p_message.getMessageType()
					+ ") 	Exit");
		}
	}

	/**
	 * This method updates the view with the modified user group information notification
	 * 
	 * @param p_message
	 *     Message that contains the modified user group information
	 */
	private void updateViewOnModifyNotification(USMMessage p_message) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"updateViewOnModifyNotification("
					+ p_message.getMessageType()
					+ ") 	Entered");
		}
		// retrieve the model for the user group list in  administration window 
		UAUserGroupAdministrationTableModel model =
			((UAUserGroupAdministrationView) associatedView).getTableModel();
		UAUserGroup dataUserGroup = new UAUserGroup();
		dataUserGroup.popMe(p_message);
		LOGGER.info("Rcv User Group Data - Name :" + dataUserGroup.getName());
		LOGGER.info(
			"Rcv User Group Data - Description :"
				+ dataUserGroup.getDescription());
		model.modifyUserGroupInVector(dataUserGroup);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"updateViewOnModifyNotification("
					+ p_message.getMessageType()
					+ ") 	Exit");
		}

	}

	/**
	 * Updates the view when the create user group notification is received
	 * 
	 * @param p_message 
	 *      contains the data about the newly created user
	 */
	private void updateViewOnCreateNotification(USMMessage p_message) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"updateViewOnCreateNotification("
					+ p_message.getMessageType()
					+ ") 	Entered");
		}
		//		retrieve the model for the user group list in  administration window 
		UAUserGroupAdministrationTableModel model =
			((UAUserGroupAdministrationView) associatedView).getTableModel();
		UAUserGroup dataUserGroup = new UAUserGroup();
		dataUserGroup.popMe(p_message);
		LOGGER.info("Rcv User Group Data - Name :" + dataUserGroup.getName());
		LOGGER.info(
			"Rcv User Group Data - Description :"
				+ dataUserGroup.getDescription());
		model.addUserGroupToVector(dataUserGroup);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"updateViewOnCreateNotification("
					+ p_message.getMessageType()
					+ ") 	Exit");
		}

	}
	/**
	 * Updates the view when the delete user groups notification ic received 
	 * 
	 * @param p_message
	 *      a Vector of UAUserGroup which contains the list of deleted user
	 */
	private void updateViewOnDeleteNotification(USMMessage p_message) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"updateViewOnDeleteNotification("
					+ p_message.getMessageType()
					+ ") 	Entered");
		}
		//		retrieve the model for the user group list in  administration window 
		UAUserGroupAdministrationTableModel model =
			((UAUserGroupAdministrationView) associatedView).getTableModel();
		int nCountUserGroups = (p_message.popInteger()).intValue();
		for (int idx = 0; idx < nCountUserGroups; ++idx) {
			UAUserGroup dataUserGroup = new UAUserGroup();
			dataUserGroup.popMe(p_message);
			LOGGER.info(
				"Rcv User Group Data - Name :" + dataUserGroup.getName());
			LOGGER.info(
				"Rcv User Group Data - Description :"
					+ dataUserGroup.getDescription());
			model.deleteUserGroupFromVector(dataUserGroup);
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"updateViewOnDeleteNotification("
					+ p_message.getMessageType()
					+ ") 	Exit");
		}
	}

	/**
	 * This method sends a request to delete the specified user groups
	 * 
	 * @param pLstUserGroups -
	 *            List of user groups to be deleted
	 * @return boolean - True indicates the operation was completed
	 *         successfully.
	 */
	boolean deleteUserGroup(List pLstUserGroups) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"deleteUserGroup(" + pLstUserGroups + ") 	Entered");
		}
		UAJobDeleteUserGroup objJobDeleteUserGroup =
			new UAJobDeleteUserGroup(this, pLstUserGroups);
		boolean bStatus = queueJob(objJobDeleteUserGroup);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"deleteUserGroup("
					+ pLstUserGroups
					+ ") 	Exit : Return -"
					+ bStatus);
		}
		return bStatus;
	}

	/**
	 * This method sends a request to get all user groups from the server.
	 * 
	 * @return boolean - True indicates the operation was completed
	 *         successfully
	 */
	boolean sendReqToGetAllUserGroups() {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("sendReqToGetAllUserGroups() 	Entered");
		}
		UAJobGetAllUserGroup objJobgetAllUserGroup =
			new UAJobGetAllUserGroup(this, true);
		boolean bStatus = queueJob(objJobgetAllUserGroup);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"sendReqToGetAllUserGroups() 	Exit : Return -" + bStatus);
		}
		return bStatus;

	}

	/**
	 * This method updates the list to add all user groups recieved from the server.
	 * 
	 * @param pMsg
	 *      Contains recieved list of the user groups
	 * @return boolean 
	 *      True indicates the operation was completed successfully
	 */
	private boolean updateDataModel(USMMessage pMsg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("updateDataModel(" + pMsg + ") 	Entered");
		}
		boolean bOp = true;
		if (pMsg == null) {
			bOp = false;
			LOGGER.info("Invalid_Message_Passed_27");
		} else {
			// Pop the number of user groups recieved. 
			int iStatus = (pMsg.popInteger()).intValue();
			if (iStatus == UAStatus.S_SUCCESS) {
				int nCountUserGroups = (pMsg.popInteger()).intValue();
				List data = new ArrayList(nCountUserGroups);
				for (int idx = 0; idx < nCountUserGroups; ++idx) {
					UAUserGroup dataUserGroup = new UAUserGroup();
					dataUserGroup.popMe(pMsg);
					data.add(dataUserGroup);
				}
				UAUserGroupAdministrationTableModel model =
					((UAUserGroupAdministrationView) associatedView)
						.getTableModel();
				model.updateData(data);
				bOp = true;
			}
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"updateDataModel(" + pMsg + ") 	Exit - Return :" + bOp);
		}
		return bOp;
	}

	/**
	 * Updates the list for deleted user groups.
	 * 
	 * @param pMsg
	 *      Contains deleted list of the user groups
	 * @return boolean 
	 *      True indicates the operation was completed successfully
	 */
	public boolean updateModelForDeletedUserGroups(USMMessage pMsg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"updateModelForDeletedUserGroups(" + pMsg + ") 	Entered");
		}
		boolean bOp = true;
		UAUserGroupAdministrationTableModel model =
			((UAUserGroupAdministrationView) associatedView).getTableModel();
		if (pMsg == null) {
			bOp = false;
			LOGGER.info("Invalid_Message_Passed");
		} else {
			boolean showErrorMessage = false;
			StringBuilder errorMessage = new StringBuilder( JfxStringTable.getString( USMStringTable.IDS_UG_DELETE_MESSAGE_FOR_USER_GROUP));
			int iStatus = (pMsg.popInteger()).intValue();
			if (iStatus == UAStatus.S_SUCCESS) {
				// Pop the number of deleted user groups.          
				int nCountUserGroups = (pMsg.popInteger()).intValue();
				for (int idx = 0; idx < nCountUserGroups; ++idx) {
					int status = (pMsg.popInteger()).intValue();
					UAUserGroup dataUserGroup = new UAUserGroup();
					dataUserGroup.popMe(pMsg);
					if (status == UAStatus.S_SUCCESS) {
						model.deleteUserGroupFromVector(dataUserGroup);
					} else if ( status == UAStatus .S_USERGROUP_CANNOT_BE_DELETED_SINCE_MAPPED) {
						showErrorMessage = true;
						errorMessage.append("\n");
						errorMessage.append(dataUserGroup.getName());
						errorMessage.append(" - The user group is mapped");
					} else if (status == UAStatus.S_LDAP_ERROR) {
						showErrorMessage = true;
						errorMessage.append("\n");
						errorMessage.append(dataUserGroup.getName());
						errorMessage.append(" - The user group could not be deleted from the LDAP");
					} else if (status == UAStatus.S_USERGROUP_DOES_NOT_EXIST) {
						showErrorMessage = true;
						errorMessage.append("\n");
						errorMessage.append(dataUserGroup.getName());
						errorMessage.append(" - The user group does not exist. It may be deleted by other client");
					} else {
						showErrorMessage = true;
						errorMessage.append("\n");
						errorMessage.append(dataUserGroup.getName());
						errorMessage.append(" - Internal processing error");
					}
				}
				bOp = true;
			} else {
				showErrorMessage = true;
				errorMessage = new StringBuilder("Failed to delete the selected user groups - General Error");
			}
			if (showErrorMessage) {
				((UAUserGroupAdministrationView) associatedView).showWarningMessage(errorMessage.toString());
			}

		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"updateModelForDeletedUserGroups("
					+ pMsg
					+ ") 	Exit - Return :"
					+ bOp);
		}
		return bOp;
	}

	/**
	 * Helper method called by the framework when a response is received.
	 * Forwards to the appropriate method
	 * 
	 * @param pJob
	 *      reference to the job which resulted in the original request
	 * @param result
	 *      result of executing the given job
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIntf#resultAvailable(com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob,
	 *      java.lang.Object)
	 */
	@Override
    public void resultAvailable(USMJob pJob, USMMessage result) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"resultAvailable(" + pJob + "," + result + ") 	Entered");
		}
		LOGGER.info("ALL User GROUP rcv :" + result.size());
		LOGGER.info("RESPONSE TYPE : " + result.getMessageType());
		if (result
			.getMessageType()
			.equals(UAMessageType.S_UG_RES_GET_ALL_USERGROUPS)) {
			updateDataModel(result);
		} else if (
			result.getMessageType().equals(
				UAMessageType.S_UG_RES_REMOVE_USER_GROUP)) {
			updateModelForDeletedUserGroups(result);

		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"resultAvailable(" + pJob + "," + result + ") 	Exit");
		}
	}

}
