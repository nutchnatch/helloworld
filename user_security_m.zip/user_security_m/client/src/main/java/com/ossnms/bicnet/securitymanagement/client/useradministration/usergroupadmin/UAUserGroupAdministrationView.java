/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005  Jogi            CF000060 - CF USM GUI Requirements
 * 18-Jan-2005	Muyeen Munaver	CF00702 - The "OK" could became Grey in the "New User" window
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 09-Feb-2005  Babu B          CF000060-01   CF USM GUI Requirements
 * 14-Feb-2005  Babu B          CF001293   Columns in security windows 
 * 26-Apr-2005	Asif			CF000834 - Command Log Entries	CF USM
 * 06-May-2009  Nagaraddi S S    TD004578 - RQT-STDERR errors instead log4j's
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration.usergroupadmin;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import org.apache.log4j.Logger;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.framework.client.jfx.FrameworkDialogApp;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandManager;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMHelp;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMMouseAdapter;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMenuNameList;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserGroup;
import com.ossnms.tools.jfx.JfxAction;
import com.ossnms.tools.jfx.JfxActionCondition;
import com.ossnms.tools.jfx.JfxActionPerformed;
import com.ossnms.tools.jfx.JfxFormPanel;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxText;
import com.ossnms.tools.jfx.components.JfxMenuItem;
import com.ossnms.tools.jfx.table.JfxTable;
import com.ossnms.tools.jfx.table.JfxTablePosAction;

/**
 * This is a user interface class and it displays the User Group Administration
 * Window.
 */
public class UAUserGroupAdministrationView extends USMBaseViewWithButtons implements ListSelectionListener {
    private static final long serialVersionUID = -3066851952435880615L;

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(UAUserGroupAdministrationView.class);
    /**
     * Data member to store administration user group name
     */
    private static String adminUserGroup = "Administrators";

    /**
     * Data members for the window title and messages
     */
    private static final String S_UG_TITLE_USER_GROUP_ADMINISTARTOR_WINDOW = JfxStringTable.getString(USMStringTable.IDS_UG_TITLE_USER_GROUP_ADMINISTARTOR_WINDOW);

    private static final String PROFILE_NAME = "User Group Window Settings";

    /**
     * Default constructor
     */
    public UAUserGroupAdministrationView() {
        super(getButtons(), "com.ossnms.bicnet.securitymanagement.client.useradministration.usergroupadmin.UAUserGroupAdministrationView",
                S_UG_TITLE_USER_GROUP_ADMINISTARTOR_WINDOW, true, false, USMHelp.HID_USERGROUP_ADMINISTRATION);
        LOGGER.debug("UAUserGroupAdministrationView()     Entered");

        // Initializing GUI controls
        initComponents();
        setNamesForTesting();

        // Initializing client controller for the window
        associatedClientController = new UAUserGroupAdministrationClientController(this);
        // Retrieving all the existing user groups
        ((UAUserGroupAdministrationClientController) associatedClientController).sendReqToGetAllUserGroups();

        LOGGER.debug("UAUserGroupAdministrationView()     Exit");

    }

    /**
     * Helper function that is used to set the Names of all the editable components within the Window.
     * 
     * Strings in this function are not to be Internationalized.
     */
    private void setNamesForTesting() {
        tblUserGroups.setName("UserGroupManagement");
    }

    /**
     * Returns the Vector of buttons that have to be displayed in the button bar
     * of the window.
     * 
     * @return Vector - Vector of buttons that have to be displayed in the
     *         window
     */
    private static List<USMButtonType> getButtons() {
        LOGGER.debug("getButtons()    Entered");

        List<USMButtonType> buttons = new ArrayList<USMButtonType>();
        USMButtonType create = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_NEW, USMMenuNameList.OPERATION_USER_GROUP_NEW, USMStringTable.IDS_UG_USER_GROUP_CREATE_BTN_TOOLTIP, false);
        buttons.add(create);

        USMButtonType modify = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_MODIFY, USMMenuNameList.OPERATION_USER_GROUP_MODIFY, USMStringTable.IDS_UG_USER_GROUP_MODIFY_BTN_TOOLTIP, false);
        buttons.add(modify);

        USMButtonType delete = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_DELETE, USMMenuNameList.OPERATION_USER_GROUP_DELETE, USMStringTable.IDS_UG_USER_GROUP_DELETE_BTN_TOOLTIP, true);
        buttons.add(delete);

        buttons.add(USMButtonType.BTN_SEPARATOR);

        LOGGER.debug("getButtons()    Exit ");
        return buttons;
    }

    /**
     * Handler for buttons in button bar. Called by USM framework, when a button
     * is clicked
     * 
     * Delegates to appropriate helper method
     * 
     * @see com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons#handleButtonClick(com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum)
     */
    @Override
    public void handleButtonClick(USMButtonTypeEnum buttonType) {
        LOGGER.debug("handleButtonClick(" + buttonType + ")   Entered");
        if ((USMButtonTypeEnum.BTN_TYPE_NEW).equals(buttonType)) {
            USMCommandManager.getInstance().executeCmd(USMCommandID.S_UI_ID_USER_MGMT_CREATE_USER_GROUP);
        } else if ((USMButtonTypeEnum.BTN_TYPE_MODIFY).equals(buttonType)) {
            openModifyWindow();
        } else if ((USMButtonTypeEnum.BTN_TYPE_DELETE).equals(buttonType)) {
            onDeleteButtonClicked();
        } else if ((USMButtonTypeEnum.BTN_TYPE_CLOSE).equals(buttonType)) {
            close();
        } else {

            LOGGER.debug("handleButtonClick() handleButtonClick() EXIT_FUNCTION");
        }
        LOGGER.debug("handleButtonClick(" + buttonType + ")   Exit");
    }

    /**
     * Function that is called by this class when the operator selects an user
     * group and clicks MODIFY.
     */
    private void openModifyWindow() {
        LOGGER.debug("openModifyWindow()  Entered");

        int selectedRow = tblUserGroups.getSelectedRow();
        UAUserGroup selectedUsergroup = (UAUserGroup) tblUserGroups.getValueAt(selectedRow, -1);
        if (selectedUsergroup != null) {
            LOGGER.info("modifying_policy" + selectedUsergroup.getName());
            USMCommandManager.getInstance().executeCmd(USMCommandID.S_UI_ID_MODIFY_USERGROUP, selectedUsergroup);
        }

        LOGGER.debug("openModifyWindow()  Exit");

    }

    /**
     * Function that is called by this class when the operator selects an user
     * group and clicks DELETE.
     */
    private void onDeleteButtonClicked() {
        LOGGER.debug("OnDeleteButtonClicked()     Entered");

        int rows[] = tblUserGroups.getSelectedRows();
        List<UAUserGroup> userGroupList = new ArrayList<UAUserGroup>();
        for (int index = 0; index < rows.length; index++) {

            UAUserGroup objuserGroup = (UAUserGroup) tblUserGroups.getValueAt(rows[index], -1);
            userGroupList.add(objuserGroup);
            LOGGER.debug("GROUP NAME :" + objuserGroup);
        }

        if ((confirmUserGroupRemoval(userGroupList)) && (userGroupList.size() > 0)) {
            UAUserGroupAdministrationClientController ctl = (UAUserGroupAdministrationClientController) associatedClientController;
            ctl.deleteUserGroup(userGroupList);
        }

        LOGGER.debug("OnDeleteButtonClicked()     Exit");
    }

    /**
     * Helper function to confirm whether UG's should be removed or not.
     * 
     * @param userGroups
     *            List of CFs that are to be removed.
     * @return Indicates the choice of the operator. True indicates Remove.
     */
    boolean confirmUserGroupRemoval(List<UAUserGroup> userGroups) {
        boolean bOp = false;
        String strTitle = USMStringTable.IDS_UG_CONFIRM_UGS_REMOVAL_TITLE.toString();
        String strMessage;
        if (1 == userGroups.size()) {
            strMessage = USMStringTable.IDS_UG_CONFIRM_SINGLE_UG_REMOVAL.toString() + "'" + userGroups.get(0) + "'?";
        } else {
            strMessage = USMStringTable.IDS_UG_CONFIRM_UGS_REMOVAL.toString() + userGroups.size() + JfxStringTable.getString(USMStringTable.IDS_UA_USERGROUPS);
        }
        int nRetVal = JfxOptionPane.showMessageBox(this, new JfxText(strTitle), new JfxText(strMessage), null, JfxOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, JfxOptionPane.NO_OPTION);

        if (JfxOptionPane.YES_OPTION == nRetVal) {
            bOp = true;
        }

        return bOp;
    }

    /**
     * Handler for selection changes in any of the list controls
     * 
     * @param p_event
     *            Event describing the action on te list control
     * 
     * @see javax.swing.event.ListSelectionListener#valueChanged(javax.swing.event.ListSelectionEvent)
     */
    @Override
    public void valueChanged(ListSelectionEvent p_event) {
        enableDisableControls();
    }

    /**
     * This method is used to validate if a certain user group name is
     * classified as a default.
     * 
     * @param userGroupName
     *            User group name to be verified if is a default user group.
     * @return True if the user group name belongs to those defined as DEFAULT,
     *         otherwise false.
     */
    private boolean isDefaultUserGroup(String userGroupName) {
        return Arrays.asList(USMCommonStrings.DEFAULT_GROUPS_NAMES).contains(userGroupName);
    }

    /**
     * Helper function to enable and disable the buttons based on the selection.
     */
    @Override
    protected void enableDisableControls() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("enableDisableControls() - Entry");
        }

        List<USMButtonTypeEnum> buttons = new ArrayList<USMButtonTypeEnum>();
        buttons.add(USMButtonTypeEnum.BTN_TYPE_DELETE);

        if (tblUserGroups != null) {
            int[] listOfSel = tblUserGroups.getSelectedRows();
            // If the single row is selected
            if (listOfSel.length == 1) {
                String admin = tblUserGroups.getValueAt(listOfSel[0], 1).toString();
                if (admin.equals(adminUserGroup) || isDefaultUserGroup(admin)) {
                    disableSelectiveButtons(buttons);
                    deleteContextMenu.setEnabled(false);
                    List<USMButtonTypeEnum> modBtn = new ArrayList<USMButtonTypeEnum>();
                    modBtn.add(USMButtonTypeEnum.BTN_TYPE_MODIFY);
                    enableSelectiveButtons(modBtn);
                    modifyContextMenu.setEnabled(true);
                } else {
                    buttons.add(USMButtonTypeEnum.BTN_TYPE_MODIFY);
                    enableSelectiveButtons(buttons);
                    deleteContextMenu.setEnabled(true);
                    modifyContextMenu.setEnabled(true);
                }
            } // If the multiple rows are selected
            else {
                boolean isAdminGroupSelected = false;
                boolean isDefaultGroupSelected = false;

                for (int i = 0; i < listOfSel.length; ++i) {
                    String admin = tblUserGroups.getValueAt(listOfSel[i], 1).toString();
                    if (admin.equals(adminUserGroup)) {
                        isAdminGroupSelected = true;
                        break;
                    } else if (isDefaultUserGroup(admin)) {
                        isDefaultGroupSelected = true;
                        break;
                    }
                }

                List<USMButtonTypeEnum> butdel = new ArrayList<USMButtonTypeEnum>();
                butdel.add(USMButtonTypeEnum.BTN_TYPE_DELETE);

                List<USMButtonTypeEnum> butMod = new ArrayList<USMButtonTypeEnum>();
                butMod.add(USMButtonTypeEnum.BTN_TYPE_MODIFY);

                if ((listOfSel.length == 0) || isAdminGroupSelected || isDefaultGroupSelected) {
                    disableSelectiveButtons(butdel);
                    deleteContextMenu.setEnabled(false);
                } else {
                    deleteContextMenu.setEnabled(true);
                    enableSelectiveButtons(butdel);
                }

                disableSelectiveButtons(butMod);
                modifyContextMenu.setEnabled(false);
            }
        }

        // Call the base class for disabling buttons now for authorization. This will only disable the buttons based on authorization, nothing else
        performPermissionCheckForButtons();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("enableDisableControls() - Entry");
        }
    }

    /**
     * Helper function to enable and disable the buttons at window opened.
     */
    public void disableButtonsAtStartup() {
        LOGGER.debug("disableButtonsAtStartup()   Entered");

        List<USMButtonTypeEnum> buttons = new ArrayList<USMButtonTypeEnum>();
        buttons.add(USMButtonTypeEnum.BTN_TYPE_MODIFY);
        buttons.add(USMButtonTypeEnum.BTN_TYPE_DELETE);
        disableSelectiveButtons(buttons);
        deleteContextMenu.setEnabled(false);
        modifyContextMenu.setEnabled(false);

        LOGGER.debug("disableButtonsAtStartup()   Exit");
    }

    /**
     * Helper function to set the preferred size of table columns in user group
     * administration window.
     */
    void setWidthOfColumns() {
        LOGGER.debug("setWidthOfColumns()     Entered");

        TableColumnModel cm = tblUserGroups.getColumnModel();
        int nNoOfColumns = cm.getColumnCount();
        for (int index = 0; index < nNoOfColumns; index++) {
            TableColumn tbCl = cm.getColumn(index);
            switch (index) {
            // For the icons
            case 0: {
                tbCl.setPreferredWidth(2);
                break;
            }
            case 1: {
                tbCl.setPreferredWidth(180);
                break;
            }
            case 2: {
                tbCl.setPreferredWidth(300);
                break;
            }
            default: {
                LOGGER.debug("We reached a point we should never have got to using value index=" + index);
                break;
            }
            }
        }
        LOGGER.debug("setWidthOfColumns()     Exit");

    }

    /**
     * Overridden method to return the component to be embedded in the view
     * 
     * @return the view itself
     * 
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getComponent()
     */
    @Override
    public JComponent getComponent() {
        return this;
    }

    /**
     * Returns the table model associated with the table
     * @return UAUserGroupAdministrationTableModel table model
     */
    public UAUserGroupAdministrationTableModel getTableModel() {
        return model;
    }

    /**
     * Function to return the Icon that is associated with this View.
     * 
     * @return Icon The Icon that should be used
     */
    @Override
    public Icon getIcon() {
        return ResourcesIconFactory.ICON_LIST_USER_GROUP_16;
    }

    /**
     * Initializes the view by creating / placing all required controls
     */
    private void initComponents() {
        LOGGER.debug("initComponents()    Enter");

        JfxFormPanel contentPanel = getPanelForPlacingDerviedControls();
        model = new UAUserGroupAdministrationTableModel();
        tblUserGroups = new UAUserGroupAdministrationTable(model);

        USMMouseAdapter adap = new USMMouseAdapter(this, USMButtonTypeEnum.BTN_TYPE_MODIFY);
        tblUserGroups.addMouseListener(adap);

        tblUserGroups.setParentView(this);
        tblUserGroups.setSortable(true);
        tblUserGroups.setFilterable(true);
        tblUserGroups.setHeaderToolTipsEnabled(true);

        // Layout
        GridBagLayout layout = new GridBagLayout();
        contentPanel.setLayout(layout);

        GridBagConstraints c = new GridBagConstraints();

        c.weightx = 1.0;
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.BOTH;
        c.weighty = 1.0;
        JScrollPane scrPane = new JScrollPane(tblUserGroups);
        layout.setConstraints(scrPane, c);
        contentPanel.add(scrPane);

        int vColIndex = 0;
        TableColumn col = tblUserGroups.getColumnModel().getColumn(vColIndex);
        int width = 50;
        col.setPreferredWidth(width);

        // Ask to be notified of selection changes.
        ListSelectionModel rowSM = tblUserGroups.getSelectionModel();
        rowSM.addListSelectionListener(this);
        disableButtonsAtStartup();

        scrPane.setPreferredSize(new Dimension(300, 300));
        setPreferredSize(new Dimension(400, 420));

        // Allow horizontal scrollbar
        tblUserGroups.setAutoResizeMode(JfxTable.AUTO_RESIZE_OFF);

        LOGGER.debug("initComponents()    Exit");
    }

    /**
     * Function to show a message to the user
     * 
     * @param parComp
     *            The Component which is the parent window.
     * @param message
     *            The Text that should be displayed
     */
    public void showMessage(final java.awt.Component parComp, String message) {
        JfxOptionPane.showMessageBox(this, message);
    }

    /**
     * Function to show a warning message to the user
     * @param message The Text that should be displayed
     */
    public void showWarningMessage(String message) {
    	bringToFront();
        JfxOptionPane.showMessageBox(this, message, JOptionPane.CLOSED_OPTION, JOptionPane.WARNING_MESSAGE);
    }
    
    // GUI Control declarations
    private JMenuItem modifyContextMenu = new JMenuItem("Modify");
    private JMenuItem deleteContextMenu = new JMenuItem("Delete");

    private UAUserGroupAdministrationTable tblUserGroups;
    private UAUserGroupAdministrationTableModel model = null;

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#eventClosing()
     */
    @Override
    public void eventClosing() {
        // Save table's properties
        saveProperties(tblUserGroups, 0, PROFILE_NAME);
        super.eventClosing();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#eventOpened()
     */
    @Override
    public void eventOpened() {
        // Load table's properties
        loadProperties(tblUserGroups, 0, PROFILE_NAME);
        super.eventOpened();
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#setFrame(com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame)
     */
    @Override
    public void setFrame(BiCNetPluginFrame frame) {
        super.setFrame(frame);
        tblUserGroups.setDialogApp(new FrameworkDialogApp(getFrame()));
    }

    @Override
    public boolean isDockable() {
        return true;
    }
}

/**
 * This class defines the table default behavior to be used by user group
 * administration window .
 */

class UAUserGroupAdministrationTable extends JfxTable {
    private static final long serialVersionUID = 3488789234959452985L;

    private UAUserGroupAdministrationView parentView;

    public UAUserGroupAdministrationTable(TableModel model) {
        super(model);

        setAutoResizeMode(JfxTable.AUTO_RESIZE_ALL_COLUMNS);
        setSortable(false);
        setFilterable(false);
        setHeaderToolTipsEnabled(true);

        // Setup context menus
        setupMenu();
    }

    protected void setupMenu() {

        // Table popup menu
        // ----------------------------------------------------------------

        // JfxTable default menu entries:
        //
        // Column Settings...
        // Set Default Column Settings
        // ---------------------------

        // Modify...
        JfxTablePosAction actionUserModify = new JfxTablePosAction(ResourcesIconFactory.ICON_TOOL_MOD_16, USMStringTable.IDS_UA_BUTTON_MODIFY, null, null);
        actionUserModify.setIfConditionHandler(new JfxActionCondition() {
            @Override
            public boolean fulfilled(JfxAction action) {
                boolean bEnabled = true;
                bEnabled = parentView.getButtonState(USMButtonTypeEnum.BTN_TYPE_MODIFY);
                return bEnabled;
            }
        });
        actionUserModify.setIfPerformedHandler(new JfxActionPerformed() {
            @Override
            public void actionPerformed(JfxAction action) {
                parentView.handleButtonClick(USMButtonTypeEnum.BTN_TYPE_MODIFY);
            }
        });
        addTablePopupItem(new JfxMenuItem(actionUserModify), false);

        // Delete...
        JfxTablePosAction actionUserDelete = new JfxTablePosAction(ResourcesIconFactory.ICON_TOOL_DELETE_16, USMStringTable.IDS_UA_BUTTON_DELETE, null, null);
        actionUserDelete.setIfConditionHandler(new JfxActionCondition() {
            @Override
            public boolean fulfilled(JfxAction action) {
                boolean bEnabled = true;
                bEnabled = parentView.getButtonState(USMButtonTypeEnum.BTN_TYPE_DELETE);
                return bEnabled;
            }
        });
        actionUserDelete.setIfPerformedHandler(new JfxActionPerformed() {
            @Override
            public void actionPerformed(JfxAction action) {
                parentView.handleButtonClick(USMButtonTypeEnum.BTN_TYPE_DELETE);
            }
        });
        addTablePopupItem(new JfxMenuItem(actionUserDelete), false);
    }

    /**
     * @param view the parent view.
     */
    public void setParentView(UAUserGroupAdministrationView view) {
        parentView = view;
    }
}

/**
 * This class defines the table model to be used by user group administration
 * window for adding, deleting or modifying the user group from the table.
 * 
 */
class UAUserGroupAdministrationTableModel extends AbstractTableModel {
    private static final long serialVersionUID = -4078351919816171835L;
    /**
     * Data members for the label strings
     */
    private static final String S_UG_TABLE_HEADER_USER_GROUP_NAME = JfxStringTable.getString(USMStringTable.IDS_UG_TABLE_HEADER_USER_GROUP_NAME);
    private static final String S_UG_TABLE_HEADER_USER_GROUP_DESCRIPTION = JfxStringTable.getString(USMStringTable.IDS_UG_TABLE_HEADER_USER_GROUP_DESCRIPTION);

    /**
     * Data member to hold table header
     */
    private String[] ColumnNames = { S_UG_TABLE_HEADER_USER_GROUP_NAME, S_UG_TABLE_HEADER_USER_GROUP_DESCRIPTION };

    /**
     * Data member to hold all the user group to display in the table
     */
    private List<UAUserGroup> userGroups = new ArrayList<UAUserGroup>();

    /**
     * Creates a new instance of UAUserGroupAdministrationTableModel
     */
    public UAUserGroupAdministrationTableModel() {
    }

    /**
     * Helper method to retrieve the number of columns
     * 
     * @see javax.swing.table.TableModel#getColumnCount()
     */
    @Override
    public int getColumnCount() {
        return ColumnNames.length;
    }

    /**
     * Helper method to retrieve the name of a given column
     * 
     * @see javax.swing.table.TableModel#getColumnName(int)
     */
    @Override
    public String getColumnName(int col) {
        return ColumnNames[col];
    }

    /**
     * Helper method to retrieve the number of rows
     * 
     * @see javax.swing.table.TableModel#getRowCount()
     */
    @Override
    public int getRowCount() {
        return userGroups.size();
    }

    /**
     * This functions add the user group list passed as parameter in the table
     * 
     * @param userGroups
     *            List of the user groups
     */
    public void addRows(List<UAUserGroup> userGroups) {
        this.userGroups.addAll(userGroups);
    }

    /**
     * Retrieve the text at the given row, column from the model
     * 
     * @see javax.swing.table.TableModel#getValueAt(int, int)
     */
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Object obj = null;
        UAUserGroup usr = userGroups.get(rowIndex);

        switch (columnIndex) {
        case -1: {
            obj = usr;
            break;
        }
        case 0: {
            obj = usr.getName();
            break;
        }
        case 1: {
            obj = usr.getDescription();
            break;
        }

        }
        return obj;
    }

    /**
     * Sets the user groups list to be displayed in the table
     * 
     * @param userGroupList
     *            list of the user groups
     */
    void updateData(List<UAUserGroup> userGroupList) {
        userGroups = userGroupList;
        fireTableDataChanged();
    }

    /**
     * Adds the new row for user group passed as parameter in the table
     * 
     * @param UAUserGroup
     *            user group info
     */
    void addUserGroupToVector(UAUserGroup usergp) {
        int nCount = userGroups.size();
        userGroups.add(usergp);
        fireTableRowsInserted(nCount, nCount);
        // fireTableDataChanged();
    }

    /**
     * Removes the rows for user group passed as parameter in the table
     * 
     * @param UAUserGroup
     *            user group info
     */
    void deleteUserGroupFromVector(UAUserGroup usergp) {
        userGroups.remove(usergp);
        fireTableDataChanged();
    }

    /**
     * Modifies the rows for user group passed as parameter in the table
     * 
     * @param UAUserGroup
     *            user group info
     */
    void modifyUserGroupInVector(UAUserGroup usergp) {
        for (int index = 0; index < userGroups.size(); index++) {
            UAUserGroup usergroup = userGroups.get(index);
            if (usergroup.getName().equals(usergp.getName())) {
                userGroups.set(index, usergp);
                break;
            }
        }
        fireTableDataChanged();
    }
}