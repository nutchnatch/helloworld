/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   UAUserAdministrationCommand
 * Author:      Babu B
 * Substitute	Vinay Purohit
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER.VIEW
 *       : TNMS.DX2.SM.FORCE_LOGOFF
 *       : TNMS.DX2.SM.USER.CREATE
 *       : TNMS.DX2.SM.USER.CONFIGURE
 * 	 : TNMS.DX2.SM.USER.ASSIGN
 *       : TNMS.DX2.SM.USER.STATUS
 * 	 :
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration.useradmin;

import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;

/**
 * Concrete class for the Command of the USer Administration View. This Command
 * is registered with the UI and is responsible to display the User
 * Administration View.
 */
public class UAUserAdministrationCommand extends USMCommand {

	/**
	 * This is the constructor
	 *
	 */
	public UAUserAdministrationCommand() {
		super(USMCommandID.S_UI_ID_USER_MGMT_VIEW_USER);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#createAndReturnView()
	 */
	@Override
    protected USMBaseView createAndReturnView() {
		return new UAUserAdministrationView();
	}

}
