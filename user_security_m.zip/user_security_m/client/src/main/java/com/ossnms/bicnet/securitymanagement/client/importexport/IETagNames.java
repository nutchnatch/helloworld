/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	IETagNames
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	07-12-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Muyeen Munaver	CF000427 - Implementation of the XML import mechanism needed for the migration process
 * 10-Feb-2005	Muyeen 		CF001177 - User migrated have to change the default password next logon acording to FSPEC
 * 08-Aug-2005	Balasubramanya	CF002760 - 9320_MR_0291 Users, User Groups, Policies lose associations after import
 * 08-Aug-2005	Balasubramanya	CF002759 - 9320_MR_0289 Security information discarded for user after deletion and restore
 * 17-Aug-2005	Balasubramanya	CF002854 - user migration does not work
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.importexport;

import org.apache.log4j.Logger;
import org.w3c.dom.Element;

import java.security.InvalidParameterException;

/**
 * This interface is used to define all the Tag names that will be used within Import/Export and Migration.
 */
public final class IETagNames {

    //Private constructor for utility class
    private IETagNames(){
    }

    /**
     * Data member to do the Tracing
     */
    private static final Logger LOGGER = Logger.getLogger(IETagNames.class);

    /**
     * Version attribute of the BiCNetData tag.
     */
    static final String BICNETDATA_VERSION = "Version";
    
    /**
     * Data member to hold the Tag Name for the Users Section.
     */
    public static final String USER_SECTION = "Users";

    /**
     * Data member to hold the Tag Name for the UserGroups Section.
     */
    public static final String USER_GROUP_SECTION = "UserGroups";

    /**
     * Data member to hold the Tag Name for the Domains Section.
     */
    public static final String DOMAIN_SECTION = "Domains";

    /**
     * Data member to hold the Tag Name for the Policies Section.
     */
    public static final String POLICIES_SECTION = "Policies";

    /**
     * Data member to hold the Tag Name for the Mappings Section.
     */
    public static final String MAPPING_SECTION = "Mappings";

    /**
     * Section for defining the Tag names used by the User
     */
    static final String USER_USER = "User";
    static final String USER_USER_NAME = "UserName";
    static final String USER_TYPE = "AccountType";
    static final String USER_FIRST_NAME = "FirstName";
    static final String USER_LAST_NAME = "LastName";
    static final String USER_COMMON_NAME = "CommonName";
    static final String USER_E_MAIL = "EMail";
    static final String USER_TELEPHONE = "Telephone";
    static final String USER_FAX = "Fax";
    static final String USER_EMPLOYEE_NUMBER = "EmployeeNumber";
    static final String USER_LAST_LOGIN = "LastLoginTime";

    // DXV1 compatible
    static final String USER_ACTIVATED = "Activated";
    static final String USER_PASSWORD = "Password";
    static final String USER_CHANGEPASSWD_NEXTLOGON = "PasswordChangeNextLogon";
    static final String USER_CANNOTCHANGE_PASSWORD = "CannotChangePassword";
    static final String USER_USER_CLASS = "UserClass";
    static final String USER_PASSWORD_EXPIRES = "PasswordExpires";
    static final String USER_PASSWDCHANGE_INTERVAL = "PasswordChangeInterval";

    static final String USER_INACTIVITY_TIMEOUT_ENABLED = "InactivityTimeoutEnabled";
    static final String USER_INACTIVITY_TIMEOUT = "InactivityTimeout";

    static final String USER_SESSION_RESTRICTION_ENABLED = "UserSessionRestrictionEnabled";
    static final String USER_ALLOWED_USER_SESSIONS = "AllowedUserSessions";

    static final String USER_EXPIRATION_DATE_ENABLED = "ExpirationDateEnabled";
    static final String USER_EXPIRATION_DATE = "ExpirationDate";

    /**
     * Section for defining the Tag names used by the User Group
     */
    public static final String USER_GROUP = "UserGroup";
    static final String USER_GROUP_NAME = "Name";
    static final String USER_GROUP_DESCRIPTION = "Description";
    static final String USER_GROUP_USER = "User";

    /**
     * Section for defining the Tag names used by the Domain
     */
    public static final String DOMAIN = "Domain";
    static final String DOMAIN_NAME = "Name";
    static final String DOMAIN_DESCRIPTION = "Description";
    static final String SECURABLE_OBJECT = "SecurableObject";

    /**
     * Section for defining the Tag names used by the Policy
     */
    public static final String POLICY = "Policy";
    public static final String POLICY_NAME = "Name";
    public static final String POLICY_DESCRIPTION = "Description";
    public static final String POLICY_PERMISSION = "Permission";

    /**
     * Section for defining the Tag names used by the Mapping
     */
    public static final String MAPPING = "Mapping";
    public static final String MAPPING_USERGROUP = "UserGroup";
    public static final String MAPPING_DOMAIN_NAME = "DomainName";
    public static final String MAPPING_POLICY_NAME = "PolicyName";

    /**
     * Helper function to check if the passed Element is null. If it is null, this method will throw
     * InvalidParameterException
     * 
     * @param element
     *            The Root Element which has been given for the check
     */
    static void throwExceptionIfElementIsNull(Element element) {
        if (element == null) {
            LOGGER.error("Element passed is null.");
            throw new InvalidParameterException();
        }
    }
}