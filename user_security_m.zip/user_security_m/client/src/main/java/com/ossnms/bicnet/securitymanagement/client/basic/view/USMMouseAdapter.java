/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: CF00060
 * --------------------------------------------------------
 *
 * Component:           USM
 * Author:              Muyeen Munaver
 * Substitute:          Asifulla Khan
 *
 * --------------------------------------------------------
 * History
 * created: 			15-02-2005
 * first version completed: 	18-06-2004
 *
 * <date>       <author>        <reason(s) of change>
 * 
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.view;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


/**
 * This is the class for the Buttons that are used within USM Since the
 * JButton class does not support the storing and retrieving of a user
 * object this has been extended and used.
 */
public final class USMMouseAdapter extends MouseAdapter {

	/**
	 * Data member to hold the View which has to be called back.
	 */
	private USMBaseViewWithButtons view = null;

	/**
	 * Data member to hold the Enum that should be returned when calling back the view
	 */
	private USMButtonTypeEnum mEnum = null;

	/**
	 * Constructor
	 * @param view The View which should be notified of mouse event
	 * @param p_Comp The Component on which to register the mouse event
	 * @param enum The Enum that should be returned to the View when the mouse event occurs
	 */
	public USMMouseAdapter(
		USMBaseViewWithButtons view,
		USMButtonTypeEnum penum) {

		this.view = view;
		mEnum = penum;
	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
	 */
	public void mouseClicked(MouseEvent e) {
		if (e.getClickCount() == 2) {
			boolean bIsEnabled = view.getButtonState(mEnum);
			if (bIsEnabled) {
				view.handleButtonClick(mEnum);
			}
		}
	}

}