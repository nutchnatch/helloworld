package com.ossnms.bicnet.securitymanagement.client.auth;

import com.ossnms.bicnet.securitymanagement.client.SecurityLogonView;
import com.ossnms.bicnet.securitymanagement.client.auth.job.AALogonJob;
import com.ossnms.bicnet.securitymanagement.client.auth.job.LogonJobListener;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.tnms.securitymanagement.client.settings.SecuritySettingsManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.security.auth.Subject;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import javax.swing.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ReloginOperation implements LogonJobListener {

	private static final Logger LOGGER = LoggerFactory.getLogger(ReloginOperation.class);

	private static final int EXECUTE_NOW = 0;

	private volatile ReloginData reloginInfo;
	private volatile boolean tryingActiveServer = true;

	private volatile ReloginOperationListener listener;
	
	private static final int MAX_RELOGIN_TRIES = 5;	
	
	private int reloginTries = 0;

	/**
	 * This is a single threaded executor to handle the relogin attempts. Any task scheduled to run will only actually
	 * run when any other running task ends.
	 * The logon jobs will run in this executor and not in client frame. Each logon job schedules the next retry with
	 * a delay.
	 * A timeout is scheduled to run in this same executor. Meaning that when a timeout occurs, any running logon job
	 * needs to finish first before the timeout is processed. Likewise, when the user cancels the relogin, it is also
	 * scheduled in this executor, and it is also only processed when any running logon job has finished. So, the effect
	 * of a timeout or cancel is simply to stop any more scheduled logon jobs to run, but it doesn't stop any job that
	 * is already running.
	 */
	private final ScheduledExecutorService jobRunner = Executors.newSingleThreadScheduledExecutor();

	public ReloginOperation(ReloginData reloginInfo) {
		this.reloginInfo = reloginInfo;
	}

	private void fireLoginSuccess() {
		final ReloginOperationListener listener = this.listener;
		if (listener != null) {
			SwingUtilities.invokeLater(listener::loginSuccess);
		}
	}

	private void fireLoginProgress(String progressMessage) {
		final ReloginOperationListener listener = this.listener;
		if (listener != null) {
			SwingUtilities.invokeLater(() -> listener.loginProgress(progressMessage));
		}
	}

	private void fireLoginError(String errorMessage, String errorTitle) {
		final ReloginOperationListener listener = this.listener;
		if (listener != null) {
			SwingUtilities.invokeLater(() -> listener.loginError(errorMessage, errorTitle));
		}
	}

	private void fireReloginCancelled() {
		final ReloginOperationListener listener = this.listener;
		if (listener != null) {
			SwingUtilities.invokeLater(listener::reloginCancelled);
		}
	}

	void startRelogin() {
		relogin(EXECUTE_NOW);
		jobRunner.schedule(this::reloginTimedOut, getReloginTimeout(), TimeUnit.MINUTES);
	}

	private void relogin(int delay) {
		try {
			AASessionClientController objController = AASessionClientController.getInstance();
			AALogonJob loginJob = new AALogonJob(objController, this);
			loginJob.setUserName(reloginInfo.getUser());
			loginJob.setPassword(reloginInfo.getPassword());
			loginJob.setServerHostName(this.obtainNextServerToConnect());
			if (reloginInfo.isSso()) {
                loginJob.setSsoSubject(obtainSsoSubject());
            }

			jobRunner.schedule(loginJob::run, delay, TimeUnit.SECONDS);

			LOGGER.info("Job created for a relogin attempt to server {} with delay {} seconds", this.obtainCurrentServerToConnect(), delay);

		} catch (LoginException e) {
			LOGGER.error("Unable to get kerberos ticket", e);
			loginErrorOccurred(USMStringTable.RE_LOGIN_FAILED_WITH_SSO.toString(), null);
		}
	}

	private Subject obtainSsoSubject() throws LoginException {
		LoginContext loginContext = new LoginContext(SecurityLogonView.class.getName(), new KerberosCallbackHandler(reloginInfo.getUser(), ""));
		loginContext.login();

		return loginContext.getSubject();
	}

	private void reloginTimedOut() {
		loginErrorOccurred(USMStringTable.RE_LOGIN_TIMEOUT_MESSAGE.getFormatedMessage(getReloginTimeout()), null);
	}

	void cancelRelogin() {
		jobRunner.schedule(()->handleLoginCancelled(), EXECUTE_NOW, TimeUnit.MINUTES);
	}


	@Override
	public void handleLoginSuccess() {
		fireLoginSuccess();
		jobRunner.shutdownNow();
	}

	@Override
	public void handleLoginError(String errorMessage, String errorTitle, boolean recoverableError) {
		LOGGER.warn("Login attempt failed to server {}: {}", this.obtainCurrentServerToConnect(), errorMessage);
		if (recoverableError) {
			
			if (reloginTries < MAX_RELOGIN_TRIES) {
				reloginTries = reloginTries + 1;
			}
			
			relogin(getReloginDelayBetweenTries() * reloginTries);
		} else {
			loginErrorOccurred(errorMessage, errorTitle);
		}
	}

	@Override
	public void handleLoginProgress(String progressMessage) {
		fireLoginProgress(progressMessage);
	}

	@Override
	public void handleLoginCancelled() {
		fireReloginCancelled();
		jobRunner.shutdownNow();
	}

	@Override
	public void handleLoginCancelled(String errorMessage, String errorTitle) {
		loginErrorOccurred(errorMessage, errorTitle);
	}

	private void loginErrorOccurred(String errorMessage, String errorTitle) {
		fireLoginError(errorMessage, errorTitle);
		jobRunner.shutdownNow();
	}

	void setReloginOperationListener(ReloginOperationListener listener) {
		this.listener = listener;
	}

	boolean hasStandby() {
		return reloginInfo.getStandbyServer() != null;
	}

	boolean isTryingActiveServer() {
		return tryingActiveServer;
	}

	String getStandbyServer() {
		return reloginInfo.getStandbyServer();
	}

	private String obtainNextServerToConnect() {
		String server;
		if (tryingActiveServer && reloginInfo.getStandbyServer() != null) {
			tryingActiveServer = false;
			server = reloginInfo.getStandbyServer();
		} else {
			tryingActiveServer = true;
			server = reloginInfo.getActiveServer();
		}
		return server;
	}

	private String obtainCurrentServerToConnect() {
		String server;
		if (tryingActiveServer) {
			server = reloginInfo.getActiveServer();
		} else {
			server = reloginInfo.getStandbyServer();
		}
		return server;
	}

    private int getReloginTimeout() {
        return SecuritySettingsManager.getInstance().getGeneralSettingsData().getReloginTimeout();
    }

    private int getReloginDelayBetweenTries() {
        return SecuritySettingsManager.getInstance().getGeneralSettingsData().getReloginDelayBetweenTries();
    }

    interface ReloginOperationListener {
        void loginSuccess();

		void loginProgress(String progressMessage);

		void loginError(String errorMessage, String errorTitle);

		void reloginCancelled();
	}
}
