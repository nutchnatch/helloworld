package com.ossnms.bicnet.securitymanagement.client.policy.common;

import com.ossnms.bicnet.securitymanagement.client.basic.component.JScrollableToolTip;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionData;
import com.ossnms.tools.jfx.components.JfxList;

import javax.swing.*;
import java.awt.*;

/**
 * created on 4/6/2015
 */
public class PermissionList extends JfxList<PAPermissionData> {

    /**
     *
     * @param dataModel
     */
    public PermissionList(ListModel<PAPermissionData> dataModel) {
        super(dataModel);
        super.setCellRenderer(new PermissionListCellRenderer());
    }

    /**
     *
     * @return
     */
    @Override
    public JToolTip createToolTip(){
        JToolTip tooltip = new JScrollableToolTip(this);
        return tooltip;
    }
}
