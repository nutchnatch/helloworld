package com.ossnms.tnms.securitymanagement.client.jobs;

import javax.swing.*;

public abstract class BackgroundJob {
    public void start() {
        new Thread() {
            Object result = null;

            @Override
            public void run() {
                this.result = BackgroundJob.this.execute();
                SwingUtilities.invokeLater(() -> BackgroundJob.this.done(result));

            }
        }.start();
    }

    protected abstract void done(Object obj);

    protected abstract Object execute();

}
