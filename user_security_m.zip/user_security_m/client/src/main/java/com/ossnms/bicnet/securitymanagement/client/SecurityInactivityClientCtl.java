/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	SecurityInactivityClientCtl
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	17-12-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID 	 : TNMS.DX2.SM.LOGOUT.USER
 * 		
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Muyeen Munaver	CF000889 - Client-time-out-box often hidden behind TNMS DX client main window
 * 16-Mar-2005	Muyeen Munaver	CF001699 - Logged in Clients+set inactivity to 2=>Clients are not logged off
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginServerAccessController;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginTimerListener;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.bcb.plugin.security.ISecureClientSession;
import com.ossnms.bicnet.framework.client.notificationpopup.NotificationPopupDetails;
import com.ossnms.bicnet.framework.client.notificationpopup.NotificationPopupManager;
import com.ossnms.bicnet.securitymanagement.client.auth.AALoginBusinessDelegate;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMBaseController;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEventIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEvtRegistrar;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.bicnet.securitymanagement.common.general.GSMessageType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityAuthenticationPrivateFacade;
import com.ossnms.tnms.securitymanagement.client.settings.SecuritySettingsDocument;
import com.ossnms.tools.jfx.JfxDate;
import org.apache.log4j.Logger;

import java.awt.*;
import java.awt.event.AWTEventListener;
import java.security.PrivilegedActionException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable.IDS_INACTIVITY_TIMEOUT_POPUP_WARNING;

/**
 * Class to check for the Inactivity of the Client
 */
public class SecurityInactivityClientCtl extends USMBaseController implements USMLogonLogoffEventIfc {

    /**
     * Data member for the Logging
     */
    private static final Logger LOGGER = Logger.getLogger(SecurityInactivityClientCtl.class);
    public static final int TO_SECONDS = 1000;

    /**
     * Data member for the singleton instance.
     */
    private static SecurityInactivityClientCtl instance = new SecurityInactivityClientCtl();

    /**
     * Data member to hold the Object which will monitor the User Inactivity
     */
    private USMTimeoutListener timeoutHandler = null;

    /**
     * Data member to hold the sessionContext Object
     */
	private ISessionContext pSessionContext;

    /**
     * Data member to hold the conversion ratio. To convert Minutes to
     * Milliseconds multiply no, by this data. Conversely, to convert millisecond
     * to minutes, divide no by factor.
     */
    private static final int CONV_RATIO_MIN_TO_SEC = 60;

    /**
     * Data member to hold the type of the notification this class is interested
     * in
     */
    private static final USMBaseMsgType GENERAL_SETTINGS_INACTIVITY_TIMEOUT = GSMessageType.GS_NOT_GENERAL_SETTING_DATA_UPDATE;
    private static final USMBaseMsgType USER_MODIFY = UAMessageType.S_UA_NOT_MODIFY_USER;

    /**
     * Function to return the singleton instance
     * 
     * @return SecurityInactivityClientCtl The singleton instance of the class.
     */
    public static SecurityInactivityClientCtl getInstance() {
        return instance;
    }

    /**
     * Helper function to Initialize the class. This includes - Registration for
     * Logging events Registration for Notifications.
     */
    public void initialize() {
        this.registerInterestedNotificationIds(this.getInterestedNotifications());
        USMLogonLogoffEvtRegistrar.getInstance().register(this);
    }

    /**
     * Helper function to return the List of Notification IDs that the
     * Controller is interested in.
     * 
     * @return List - The List which contains the Notification IDs that the
     *         Controller is interested in.
     */
    private List<USMBaseMsgType> getInterestedNotifications() {
        LOGGER.debug("Entering getInterestedNotifications");

        List<USMBaseMsgType> lstInterestedNotif = new ArrayList<>();
        lstInterestedNotif.add(GENERAL_SETTINGS_INACTIVITY_TIMEOUT);
        lstInterestedNotif.add(USER_MODIFY);
        LOGGER.debug("Exiting getInterestedNotifications");

        return lstInterestedNotif;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.
     * USMControllerIfc
     * #resultAvailable(com.ossnms.bicnet.securitymanagement.client
     * .basic.controller.jobs.USMJob,
     * com.ossnms.bicnet.securitymanagement.common.basic.USMMessage)
     */
    @Override
    public void resultAvailable(USMJob pJob, USMMessage pMsg) {
        LOGGER.debug("resultAvailable - Enter");
        if(pMsg.getMessageType().equals(GSMessageType.GS_GENERAL_SETTING_DATA_RESPONSE) || pMsg.getMessageType().equals(UAMessageType.S_UA_RES_MODIFY_USER)) {

            int nInactivity =  getInactivityTimeout(pSessionContext).popInteger();
            USMUtility.getInstance().setInactivityTimeOut(nInactivity);

            int nInactivityTimeoutWarningTime =  getInactivityTimeoutWarningTime(pSessionContext).popInteger();
            USMUtility.getInstance().setInactivityTimeoutWarningTime(nInactivityTimeoutWarningTime);

            this.createAndStartupTimer();
            if(nInactivity == 0) {
                this.cleanupTimer();
            } else {
                if(this.timeoutHandler == null) {
                    // Case when user did not have the feature activated, but
                    // now wants to activate it.
                    this.createAndStartupTimer();
                }
            }
        }
        LOGGER.debug("resultAvailable - Exit");
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.
     * USMControllerIfc
     * #handleNotification(com.ossnms.bicnet.securitymanagement.
     * common.basic.USMMessage)
     */
    @Override
    public void handleNotification(USMMessage pMsg) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("Entering handleNotification. Msg : " + pMsg);
        }
        if(pMsg.getMessageType().equals(GENERAL_SETTINGS_INACTIVITY_TIMEOUT) || pMsg.getMessageType().equals(USER_MODIFY)) {
            // Action on general setting data update notification

            int nInactivity =  getInactivityTimeout(pSessionContext).popInteger();
            USMUtility.getInstance().setInactivityTimeOut(nInactivity);

            int nInactivityTimeoutWarningTime =  getInactivityTimeoutWarningTime(pSessionContext).popInteger();
            USMUtility.getInstance().setInactivityTimeoutWarningTime(nInactivityTimeoutWarningTime);

            if(nInactivity == 0) {
                this.cleanupTimer();
            } else {
                if(this.timeoutHandler == null) {
                    // Case when user did not have the feature activated, but
                    // now wants to activate it.
                    this.createAndStartupTimer();
                }
            }
        }       

        LOGGER.debug("Exiting handleNotification. ");
    }
    
    
    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.
     * USMControllerIfc
     * #handleNotification(com.ossnms.bicnet.securitymanagement.
     * common.basic.USMMessage)
     */
   
    public void handleNotification(GSGeneralSettingData settingsData) {

        int nInactivity =  getInactivityTimeout(pSessionContext).popInteger();
        USMUtility.getInstance().setInactivityTimeOut(nInactivity);

        int nInactivityTimeoutWarningTime =  getInactivityTimeoutWarningTime(pSessionContext).popInteger();
        USMUtility.getInstance().setInactivityTimeoutWarningTime(nInactivityTimeoutWarningTime);

            if(nInactivity == 0) {
                this.cleanupTimer();
            } else {
                if(this.timeoutHandler == null) {
                    // Case when user did not have the feature activated, but
                    // now wants to activate it.
                    this.createAndStartupTimer();
                }
            }

        LOGGER.debug("Exiting handleNotification. ");
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.securitymanagement.client.basic.logonevt.
     * USMLogonLogoffEventIfc
     * #operatorLoggedOn(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
     */
    @Override
    public void operatorLoggedOn(ISessionContext sessionContext) {
        LOGGER.debug("Entering operatorLoggedOn");
        
        
        this.pSessionContext = sessionContext;
        // // During the user login, we get the updated value for
        // // inactivity timeout which needs
        // // to be retrieved from the server.
        int nInactivityDuration = getInactivityTimeout(sessionContext).popInteger();
        USMUtility.getInstance().setInactivityTimeOut(nInactivityDuration);

        int nInactivityTimeoutWarningTime =  getInactivityTimeoutWarningTime(pSessionContext).popInteger();
        USMUtility.getInstance().setInactivityTimeoutWarningTime(nInactivityTimeoutWarningTime);

        // //Also initialize general settings values that are needed for user creation
        SecuritySettingsDocument doc = new SecuritySettingsDocument();
        doc.init();

        LOGGER.debug("Exiting operatorLoggedOn");
    }
    
    
    /**
	 * Returns the expected Inactivity Timeout for the user
	 * 
	 * @param sessionContext
	 *            - Session Token.
	 * @return USMMessage - User Inactivity Timeout
	 */
	public USMMessage getInactivityTimeout(final ISessionContext sessionContext) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("getInactivityTimeout(" + sessionContext + ") Entry");
		}

		try {
			return (USMMessage) BiCNetPluginServerAccessController.doPrivileged(this, () -> {
                ISecurityAuthenticationPrivateFacade usmAuthentication = AALoginBusinessDelegate.getAuthenticationBean();
                if (usmAuthentication != null) {
                    return usmAuthentication.getInactivityTimeout(sessionContext);
                }
                return null;
            });
		} catch (PrivilegedActionException e) {
			LOGGER.error("Exception raised for ctx : " + sessionContext, e);
		}

		LOGGER.debug("getInactivityTimeout(ISessionContext sessionContext) 		Exit");
		return null;
	}

    /**
     * Returns the expected Inactivity Timeout Warning Time for the user
     *
     *            - Session Token.
     * @return USMMessage - User Inactivity Timeout Warning Time
     */
    public USMMessage getInactivityTimeoutWarningTime(final ISessionContext sessionContext) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getInactivityTimeoutWarningTime() Entry");
        }

        try {
            return (USMMessage) BiCNetPluginServerAccessController.doPrivileged(this, () -> {
                ISecurityAuthenticationPrivateFacade usmAuthentication = AALoginBusinessDelegate.getAuthenticationBean();
                if (usmAuthentication != null) {
                    return usmAuthentication.getInactivityTimeoutWarningTime(sessionContext);
                }
                return null;
            });
        } catch (PrivilegedActionException e) {
            LOGGER.error("Exception raised", e);
        }

        LOGGER.debug("getInactivityTimeoutWarningTime() 		Exit");
        return null;
    }

    /**
     * Helper function to create and start up the timer and the AWT Object
     * 
     */
    private void createAndStartupTimer() {
        LOGGER.debug("Entering createAndStartupTimer");

        int nInactivityDurInMins = USMUtility.getInstance().getInactivityTimeOut();

        // It is possible to disable to logout due to inactivity
        // if the value is set as 0. Therefore check if the value is greater
        // then 0
        // and only then set the logout.
        if(nInactivityDurInMins > 0) {

            this.timeoutHandler = new USMTimeoutListener();
            USMUtility.getInstance().getSecuritySite().addTimerListener(this.timeoutHandler);

            // Register global AWT handler for user activity supervision
            Toolkit.getDefaultToolkit().addAWTEventListener(
                    this.timeoutHandler,
                    AWTEvent.KEY_EVENT_MASK | AWTEvent.MOUSE_EVENT_MASK
            );
            LOGGER.info("Successfully added both Timerlistener and AWTEventListener");
        }

        LOGGER.debug("Exiting createAndStartupTimer");
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.securitymanagement.client.basic.logonevt.
     * USMLogonLogoffEventIfc
     * #operatorLoggedOff(com.ossnms.bicnet.bcb.facade.security
     * .ISessionContext, java.lang.String)
     */
    @Override
    public void operatorLoggedOff(ISessionContext sessionContext) {

        LOGGER.debug("Entering operatorLoggedOff");

        this.cleanupTimer();

        LOGGER.debug("Exiting operatorLoggedOff");
    }

    /**
     * Helper function to remove the Timer object and also the AWT Listener. If
     * this function gets called, if the AWT Listener is not already registered,
     * no action occurs.
     */
    private void cleanupTimer() {
        LOGGER.debug("Entering cleanupTimer");

        // Since it is possible that the Timer itself is not activated, we
        // should be
        // careful not to remove a removed timer.
        if(this.timeoutHandler != null) {
            Toolkit.getDefaultToolkit().removeAWTEventListener(this.timeoutHandler);
            USMUtility.getInstance().getSecuritySite().removeTimerListener(this.timeoutHandler);
            this.timeoutHandler = null;
            LOGGER.info("Successfully removed both Timerlistener and AWTEventListener");
        }

        LOGGER.debug("Exiting cleanupTimer");
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.securitymanagement.client.basic.logonevt.
     * USMLogonLogoffEventIfc
     * #operatorLoggingOff(com.ossnms.bicnet.bcb.facade.security
     * .ISessionContext)
     */
    @Override
    public void operatorLoggingOff(ISessionContext sessionContext) {
        LOGGER.debug("Entering operatorLoggingOff");
        LOGGER.debug("Exiting operatorLoggingOff");
    }

    /**
     * Accepts activity reports from 3rd party
     *
     * @param timestamp
     */
    void reportActivity(long timestamp) {
        // add the event to report activity
        if(timeoutHandler != null){
            timeoutHandler.reportActivity(timestamp);
        }
    }

    /**
     * The purpose of this class getting the current system clock reading is to
     * be able to evaluate the period of inactivity and do shut the app down if
     * it exceeds the threshold. The timer actually runs in a very low-intensity
     * mode, firing once every X minutes, "X" being the inactivity threshold.
     * 
     */
    private static class USMTimeoutListener implements AWTEventListener, BiCNetPluginTimerListener {

        public static final int ONE_MINUTE_IN_SECONDS = 60;
        /**
         * Data member to hold the count of the times the call has been made. We
         * will have to count till 15 (15 secs) and then do the processing here.
         */
        private int counter;
        private boolean popUpShown = false;

        /**
         * Constructor
         */
        USMTimeoutListener() {
            this.counter = 0;
        }

        /**
         * (non-Javadoc)
         * 
         * @see java.awt.event.AWTEventListener#eventDispatched(java.awt.AWTEvent)
         * 
         *      This function will get called everytime there is a message that
         *      is getting dispatched. This means, that the client is active.
         */
        @Override
        public synchronized void eventDispatched(AWTEvent event) {
            this.counter = 0;
            popUpShown = false;
        }

        /**
         * Helper function to logoff due to inactivity
         */
        private void logoffDueToInactivity() {
            LOGGER.debug("Entering logoffDueToInactivity");
            try {
                USMUtility util = USMUtility.getInstance();

                ISecureClientSession clSes = util.getSecureClientSession();
                BiCNetPluginSite site = util.getSecuritySite();

                IPluginSecurityProvider secProv = site.getSecurityProvider();
                secProv.logoff(clSes, IPluginSecurityProvider.LogoffReason.INACTIVITY_TIMEOUT);
            } catch (Exception e1) {
                LOGGER.error("Exception raised : ", e1);
            }
            LOGGER.debug("Exiting logoffDueToInactivity");
        }

        /**
         * Helper function to show a popup notification pre-defined minutes before inactivity timeout
         */
        private void showInactivityTimeoutWarningDialog() {
            LOGGER.debug("Entering showInactivityTimeoutWarningDialog");

            int inactivityTimeout = USMUtility.getInstance().getInactivityTimeOut();

            //When showing the window, the best way to assert the date to subtract the elapsed inactive time to inactivity
            //timeout value.
            int timeToDisplay = inactivityTimeout - (this.counter / ONE_MINUTE_IN_SECONDS);

            NotificationPopupDetails popupDetails = new NotificationPopupDetails(NotificationPopupDetails.OpStatus.WITH_WARNINGS,
                    IDS_INACTIVITY_TIMEOUT_POPUP_WARNING.getFormatedMessage(getFormattedTimeForInactivityWarning(timeToDisplay)), BiCNetComponentType.SECURITY_MANAGER, "");
            popupDetails.setTitle(USMStringTable.IDS_AA_WINDOW_SESSION_TIMEOUT_WARNING.toString());
            // show popup and don't let it hide automatically
            NotificationPopupManager.getInstance().showPopup(popupDetails, true);

            LOGGER.debug("Exiting showInactivityTimeoutWarningDialog");
        }


        /**
         * This method will return the time at which the logoff will occur according to the
         *
         * @param minutesUntilLogoff
         * @return
         */
        private String getFormattedTimeForInactivityWarning(int minutesUntilLogoff){

            JfxDate date = new JfxDate(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(minutesUntilLogoff));

            return USMUtility.getInstance().convertDateToClientTimeZone(date);

        }

        /*
         * (non-Javadoc)
         * 
         * @see
         * com.ossnms.bicnet.bcb.plugin.BiCNetPluginTimerListener#eventPluginTimer
         * ()
         */
        @Override
        public synchronized void eventPluginTimer() {
            this.counter++;
            boolean shouldShowPopUp;

            //Inactivity timeout defined either in the property page or in the user property page
            int nTimeoutInSec = USMUtility.getInstance().getInactivityTimeOut() * CONV_RATIO_MIN_TO_SEC;

            //Inactivity timeout defined either in the property page or in the user property page
            int nTimeoutWarningInSec = USMUtility.getInstance().getInactivityTimeoutWarningTime() * CONV_RATIO_MIN_TO_SEC;

            //Since the time defined in the property page represents minutes "before" the timeout,
            //the correct way to calculate the time to trigger the pop up is, the value for the timeout
            //minus the time of the warning.
            int timeUntilWarningInSec = nTimeoutInSec - nTimeoutWarningInSec;

            //In order to show popup the user should have any sort of inactivity timeout enabled;
            shouldShowPopUp = (nTimeoutInSec != 0);

            //Should have the pop up warning enabled;
            shouldShowPopUp &= (nTimeoutWarningInSec != 0);

            //The inactivity counter should be over the stipulated time until the warning;
            shouldShowPopUp &= (this.counter >= timeUntilWarningInSec);

            //The popup was never shown in the current inactivity countdown;
            shouldShowPopUp &= (!popUpShown);

            //The verification to show the pop up can only be done in a minute by minute basis.
            shouldShowPopUp &= this.counter%ONE_MINUTE_IN_SECONDS == 0;

            if((nTimeoutInSec != 0) && (this.counter >= nTimeoutInSec)) {
                this.logoffDueToInactivity();
            } else if(shouldShowPopUp) {
                this.showInactivityTimeoutWarningDialog();
                popUpShown = true;
            }

            LOGGER.debug("eventPluginTimer called. Timeout : " + nTimeoutInSec + " current inactivity : " + this.counter);
        }


        /**
         * Report activity into the timeout listener
         *
         * @param timestamp the time to set
         */
        synchronized void reportActivity(long timestamp) {
            // get the current time
            long now = new Date().getTime();
            // calculate the diff
            long diff = now - timestamp;
            // to seconds
            int diffSeconds = (int) (diff / TO_SECONDS);

            if(counter > diffSeconds){
                this.counter = diffSeconds;
            }
        }
    }
}
