/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Jogi			CF000060 - CF USM GUI Requirements
 * 18-Jan-2005	Muyeen Munaver	CF00702 - The "OK" could became Grey in the "New User" window
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 09-02-2005	Babu B          CF000060-01   CF USM GUI Requirements
 * 15-Feb-2005	Muyeen Munaver	CF000995 - Password Expiration Interval
 * 15-Feb-2005	Muyeen Munaver	CF001006 - "Make user change inital password after ...Days" doesn't work properly
 * 20-02-2005	Muyeen Munaver  CF001473 - Map Id errors in Online help
 * 05-May-2005  Babu B          CF001312   Master-Master Replication for Sun ONE DS
 * 12-Apr-2006	Shrinidhi G V	CF003939-01	Deactivation of administrator
 * 02-Feb-2006	Balasubramanya	CF003463-01	Deactivation of administrator
 * 26-May-2009	Nagaraddi S S	TD004589	Pop up window is appearing when user account is deleted after modifying the same user account
 * 29-May-2009	Nagaraddi S S	TD004757	Short cut key works only for the first time in USM windows
 * 29-May-2009	Nagaraddi S S	TD000874-04	Packet Manager - Form fields lacks validation on string size
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.useradministration.usermodify;

import com.ossnms.bicnet.framework.client.helpers.feedback.FrameworkActivityIndicator;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMHelp;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMFrameType;
import com.ossnms.bicnet.securitymanagement.client.useradministration.usercreate.UAUserDetailsTabGroup;
import com.ossnms.bicnet.securitymanagement.client.useradministration.usercreate.UAUserGroupDataHolder;
import com.ossnms.bicnet.securitymanagement.common.auth.PasswordValidationRulesConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMenuNameList;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UACommonHelper;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxStringTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * This is a user interface class that displays a window for modifying user information
 */
class UAModifyUserView extends USMBaseViewWithButtons {
    private String userID = null;
    private transient UAModifyUserClientController controller = null;
    private transient UAUserGroupDataHolder ugrpDataMdl = null;
    private UAUser userData = null;
    private UAUserDetailsTabGroup tabGroup = null;
    private final FrameworkActivityIndicator loadingPanel = new FrameworkActivityIndicator();
    // Data member to hold the Password Validation Rules.
    private transient PasswordValidationRulesConfigurationData passwordValidationRules = new PasswordValidationRulesConfigurationData();
    private static final int WINDOW_WIDTH = 470;
    private static final int WINDOW_HEIGHT = 370;
    /**
     * Data member for the Logging of the class.
     */
    private static final long serialVersionUID = -4610279421620152042L;
    private static final Logger LOGGER = LoggerFactory.getLogger(UAModifyUserView.class);

    /**
     * Constructor with user id as param
     *
     * @param userId The user ID
     */
    UAModifyUserView(String userId) {
        super(null, getCommitButtons(), null, "com.ossnms.bicnet.securitymanagement.client.useradministration.usermodify.UAModifyUserView" + "-"
                + userId, JfxStringTable.getString(USMStringTable.IDS_UA_MODIFY_TITLE), true, false, USMHelp.HID_MODIFY_USER);
        this.controller = new UAModifyUserClientController(this);

        associatedClientController = controller;
        this.setUserID(userId);
        this.ugrpDataMdl = new UAUserGroupDataHolder();
        this.userData = new UAUser();
        this.userData.setUserId(userId);

        initComponents();
        this.showLoadingPanel();
        this.controller.getAllAssignedAndUnassignedUsergroups(userId);
        this.controller.sendReqToGetAllPasswordValidationRules();
    }

    /**
     * Handles the modification of user. Sends the modified details to server.
     *
     * @return boolean True if request was successfully sent
     */
    private boolean modifyUser() {
        LOGGER.debug("modifyUser() Entry");

        boolean userDataValid = tabGroup.setComponentValueToUserData(true);
        int assignedListSize = ugrpDataMdl.getAssignedUsersList().size();
        List<String> userGroups = new ArrayList<>();

        for (int index = 0; index < assignedListSize; index++) {
            LOGGER.debug("ELEMENT {}", ugrpDataMdl.getAssignedUsersList().elementAt(index));
            userGroups.add(ugrpDataMdl.getAssignedUsersList().get(index));
        }

        if (userData.isAdminUser()) {
            boolean bAssignedHasAdmin = false;
            for (Object aVecUgrp : userGroups) {
                if (aVecUgrp instanceof String) {
                    String userGroupAssgToAdmin = (String) aVecUgrp;
                    if (userGroupAssgToAdmin.equalsIgnoreCase(UACommonHelper.ADMIN_GROUP_NAME)) {
                        bAssignedHasAdmin = true;
                    }
                }
            }
            // If assigned user group does not have the Admin group
            if (!bAssignedHasAdmin) {
                JfxOptionPane.showMessageBox(
                        this,
                        USMStringTable.IDS_UA_ADMINISTRATOR_USER_MODIFY_ERROR.toString(),
                        JOptionPane.CLOSED_OPTION,
                        JOptionPane.ERROR_MESSAGE
                );
                return false;
            }
        }

        if (userDataValid) {
            controller.modifyUser(userData, userGroups);
        } else {
            LOGGER.debug("modifyUser() Component value is wrong.");
        }

        LOGGER.debug("modifyUser() Exit");

        return userDataValid;
    }

    /**
     * Handler for buttons in button bar. Called by USM framework, when a button is clicked Delegates to appropriate
     * helper method
     *
     * @see com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons#handleButtonClick
     */
    // Fault ID 77 - Provide Button Level Authorization for UA Windows
    @Override
    public void handleButtonClick(USMButtonTypeEnum type) {
        LOGGER.debug("handleButtonClick() Entry");

        if ((USMButtonTypeEnum.BTN_TYPE_OK).equals(type)) {
            modifyUser();

        } else if ((USMButtonTypeEnum.BTN_TYPE_CANCEL).equals(type)) {
            close();

        } else {
            LOGGER.error("handleButtonClick() Received an unexpected USMButtonTypeEnum. {}", type);
        }
        LOGGER.debug("handleButtonClick() Exit");
    }

    /**
     * Overridden method to return the component to be embedded in the view
     *
     * @return the view itself
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getComponent()
     */
    @Override
    public JComponent getComponent() {
        return this;
    }

    /**
     * Overridden method to return the icons to be embedded in the button bar
     *
     * @return vector of icons
     */
    private static List<USMButtonType> getCommitButtons() {
        List<USMButtonType> icons = new ArrayList<>();

        USMButtonType apply = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_OK, USMMenuNameList.OPERATION_USER_NEW, USMStringTable.IDS_UA_MODIFY_DESCRIPTION, true);
        icons.add(apply);

        icons.add(USMButtonType.BTN_TYPE_CANCEL);
        return icons;
    }

    /**
     * All the controls of the User Create / Modify Window are created and initialized in this method.
     */
    private void initComponents() {
        // The Administrator user can't be deactivated using the icons on the window but when the user can be deactivated using Edit User option Begin
        tabGroup = new UAUserDetailsTabGroup(ugrpDataMdl, userData, userID, passwordValidationRules);
        setPreferredSize(new Dimension(WINDOW_WIDTH, WINDOW_HEIGHT));
    }

    /**
     * Update view with response of assigned & unassigned user groups request
     *
     * @param vecAllAvailableUgrp  All user groups available in LDAP
     * @param configuredUserGroups User groups to which the user belongs
     */
    void updateViewWithAssignedUnassignedUserGroupResult(
            List<String> vecAllAvailableUgrp,
            List<String> configuredUserGroups,
            UAUser user) {

        final String FUNC_NAME = "updateViewWithAssignedUnassignedUserGroupResult";
        LOGGER.debug("{} in the result", FUNC_NAME);

        userData = user;

        if (vecAllAvailableUgrp != null) {
            LOGGER.debug("{} Number of Available user groups are : {}", FUNC_NAME, vecAllAvailableUgrp.size());
            synchronized (ugrpDataMdl) {
                ugrpDataMdl.getAvailableUsersList().clear();
                for (String vecAvailableUserGroup : vecAllAvailableUgrp) {
                    ugrpDataMdl.getAvailableUsersList().addElement(vecAvailableUserGroup);
                }
            }

        } else {
            LOGGER.info("{} Null Vector of user groups.", FUNC_NAME);
        }
        if (configuredUserGroups != null) {
            LOGGER.debug("{} Number of Assigned user groups are : {}", FUNC_NAME, configuredUserGroups.size());
            synchronized (ugrpDataMdl) {
                ugrpDataMdl.getAssignedUsersList().clear();
                for (String vecConfiguredUserGroup : configuredUserGroups) {
                    ugrpDataMdl.getAssignedUsersList().addElement(vecConfiguredUserGroup);
                }
            }
        } else {
            LOGGER.info("{} Null Vector of user groups.", FUNC_NAME);
        }

        tabGroup.setComponentValueFromUserData(user);

        this.hideLoadingPanel();

    }

    /**
     * Handle user group removed notification & update view
     *
     * @param strUserGroup User group which has been deleted
     */
    void onUserGroupRemoved(String strUserGroup) {
        if (ugrpDataMdl.getAssignedUsersList().contains(strUserGroup)) {
            ugrpDataMdl.getAssignedUsersList().removeElement(strUserGroup);
        }
        if (ugrpDataMdl.getAvailableUsersList().contains(strUserGroup)) {
            ugrpDataMdl.getAvailableUsersList().removeElement(strUserGroup);
        }
    }

    /**
     * Handle user removed notification & update view
     *
     * @param vecDeletedUser User(s) which has been deleted
     */
    void onUserDeleted(List<String> vecDeletedUser) {
        LOGGER.debug("onUserDeleted () ENTER_FUNCTION");

        if (vecDeletedUser != null && vecDeletedUser.contains(getUserID())) {
            closeWindowOnObjectDeletion();
        }

        LOGGER.debug("onUserDeleted () EXIT_FUNCTION");
    }

    /**
     * Helper method to show a message to the user
     *
     * @param strMsgText The Text that should be displayed
     */
    public void showMessage(String strMsgText) {
        JfxOptionPane.showMessageBox(this, strMsgText);
    }

    /**
     * Adds an user group to either the assigned / available list
     *
     * @param strUserGroup User group to be added
     * @param bAssigned    If true, user group is added to Assigned users list; otherwise, user group is added to Available users
     *                     list.
     */
    void updateViewWithCheckUserGroupContainsUser(String strUserGroup, boolean bAssigned) {
        if (bAssigned) {
            if (!ugrpDataMdl.getAssignedUsersList().contains(strUserGroup)) {
                ugrpDataMdl.getAssignedUsersList().addElement(strUserGroup);
            }
            ugrpDataMdl.getAvailableUsersList().removeElement(strUserGroup);
        } else {
            if (!ugrpDataMdl.getAvailableUsersList().contains(strUserGroup)) {
                ugrpDataMdl.getAvailableUsersList().addElement(strUserGroup);
            }
            ugrpDataMdl.getAssignedUsersList().removeElement(strUserGroup);
        }
    }


    /**
     * Handle user activated notification & update view
     *
     * @param lstActivatedUsers the list of user ids
     */
    void onUserActivated(List<String> lstActivatedUsers) {
        LOGGER.debug("onUserActivated () ENTER_FUNCTION");

        if (lstActivatedUsers != null && lstActivatedUsers.contains(getUserID())) {
            userData.setAccountActivated(true);
            tabGroup.setComponentValueFromUserData(userData);
        }

        LOGGER.debug("onUserActivated () EXIT_FUNCTION");
    }

    /**
     * Handle user activated notification & update view
     *
     * @param lstDeactivatedUsers list of deactivated users, identified by user id
     */
    void onUserDeactivated(List<String> lstDeactivatedUsers) {
        LOGGER.debug("onUserActivated () ENTER_FUNCTION");

        if (lstDeactivatedUsers != null && lstDeactivatedUsers.contains(getUserID())) {
            userData.setAccountActivated(false);
            tabGroup.setComponentValueFromUserData(userData);
        }
        LOGGER.debug("onUserActivated () EXIT_FUNCTION");
    }

    /**
     * Function to return the User ID for which this View has been opened
     *
     * @return String User ID for which the VIew has been opened
     */
    String getAssociatedUserID() {
        return getUserID();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView_BtnPnl_StatusBar#enableBtnsAfterLongOperationCompleted()
     */
    @Override
    protected void enableDisableControls() {
        enableAllButtons();
    }

    /**
     * @param userId the user id
     */
    void onUserPasswordChanged(String userId) {
        if (getUserID().compareToIgnoreCase(userId) == 0) {
            userData.setUserMustChangePassword(false);
            tabGroup.setComponentValueFromUserData(userData);
        }
    }

    /**
     * Method to show the loading screen
     */
    private void showLoadingPanel() {
        getPanelForPlacingDerviedControls().add(loadingPanel, BorderLayout.CENTER);
        loadingPanel.setActivityIndicatorVisible(true);
    }

    /**
     * Method to remove the loading screen
     */
    private void hideLoadingPanel() {
        getPanelForPlacingDerviedControls().remove(loadingPanel);
        getPanelForPlacingDerviedControls().add(tabGroup);
        loadingPanel.setActivityIndicatorVisible(false);
        this.revalidate();
    }

    /**
     * Function to decide what is the Frame that should be used.
     *
     * @return USMFrameType The Frame type that should be used.
     */
    @Override
    protected USMFrameType getFrameTypeToBeUsed() {
        return USMFrameType.S_INTERNAL;
    }

    String getUserID() {
        return userID;
    }

    private void setUserID(String userID) {
        this.userID = userID;
    }

    @Override
    public boolean isDockable() {
        return false;
    }

    @Override
    public Icon getIcon() {
        return ResourcesIconFactory.ICON_WINDOW_USER_16;
    }

    /**
     * Function called to update the window with the new information.
     *
     * @param isPasswordMustNotHaveSpaces If the PasswordMustNotHaveSpaces rule is active;
     * @param isPasswordMustBeDifferentFromName If the PasswordMustBeDifferentFromName rule is active;
     * @param isPasswordMustBeDifferentFromEmployeeNumber If the PasswordMustBeDifferentFromEmployeeNumber rule is active;
     * @param isPasswordMustBeDifferentFromDate If the PasswordMustBeDifferentFromDate rule is active;
     */
    public void updateViewWithPasswordValidationRulesResult(boolean isPasswordMustNotHaveSpaces, boolean isPasswordMustBeDifferentFromName,
                                                            boolean isPasswordMustBeDifferentFromEmployeeNumber, boolean isPasswordMustBeDifferentFromDate) {
        LOGGER.debug("updateViewWithPasswordValidationRulesResult() entry");
        this.hideLoadingPanel();

        passwordValidationRules.setPasswordMustBeDifferentFromEmployeeNumber(isPasswordMustBeDifferentFromEmployeeNumber);
        passwordValidationRules.setPasswordMustBeDifferentFromName(isPasswordMustBeDifferentFromName);
        passwordValidationRules.setPasswordMustNotHaveSpaces(isPasswordMustNotHaveSpaces);
        passwordValidationRules.setPasswordMustBeDifferentFromDate(isPasswordMustBeDifferentFromDate);

    }
}