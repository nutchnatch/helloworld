package com.ossnms.bicnet.securitymanagement.client.useradministration.usercreate;

import com.ossnms.bicnet.framework.client.helpers.feedback.FrameworkActivityIndicator;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMHelp;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMFrameType;
import com.ossnms.bicnet.securitymanagement.common.auth.PasswordValidationRulesConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMenuNameList;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import com.ossnms.tnms.securitymanagement.client.settings.SecuritySettingsManager;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxText;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.awt.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This is a user interface class that displays a window for creating a user
 */
class UACreateUserView extends USMBaseViewWithButtons {
    private static final long serialVersionUID = 8484436430323370799L;

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(UACreateUserView.class);

    private static final String FORMAT_DATE = "dd/MM/yyyy";

    private transient UAUserGroupDataHolder userGroupDataHolder = null;

    // Data member to hold the Password Validation Rules.
    private transient PasswordValidationRulesConfigurationData passwordValidationRules = new PasswordValidationRulesConfigurationData();

    //Data member to hold the which contains different tabs.
    private UAUserDetailsTabGroup detailsTabGroup = null;
    
    // Data member to hold the user object.
    private UAUser mUser = null;

    // Data member to show the Loading Screen
    private FrameworkActivityIndicator loadingPanel = new FrameworkActivityIndicator();

    private static final int WINDOW_WIDTH = 470;
    private static final int WINDOW_HEIGHT = 370;

    /**
     * Default Constructor
     */
    UACreateUserView() {
        super(null, getIcons(), null, UACreateUserView.class.getName(), JfxStringTable.getString(USMStringTable.IDS_UA_CREATE_TITLE), true, false, USMHelp.HID_CREATE_USER);

        userGroupDataHolder = new UAUserGroupDataHolder();
        associatedClientController = new UACreateUserClientController(this);
        mUser = new UAUser();

        initComponents();
        getAssociatedController().sendRequestToGetAllUsergroups();
        getAssociatedController().sendReqToGetAllPasswordValidationRules();
        this.showLoadingPanel();
        LOGGER.debug(" in the constructor");
    }

    /**
     * Function called to update the window with the new information.
     *
     * @param isPasswordMustNotHaveSpaces If the PasswordMustNotHaveSpaces rule is active;
     * @param isPasswordMustBeDifferentFromName If the PasswordMustBeDifferentFromName rule is active;
     * @param isPasswordMustBeDifferentFromEmployeeNumber If the PasswordMustBeDifferentFromEmployeeNumber rule is active;
     * @param isPasswordMustBeDifferentFromDate If the PasswordMustBeDifferentFromDate rule is active;
     */
    void updateViewWithPasswordValidationRulesResult(boolean isPasswordMustNotHaveSpaces, boolean isPasswordMustBeDifferentFromName,
                                                            boolean isPasswordMustBeDifferentFromEmployeeNumber, boolean isPasswordMustBeDifferentFromDate) {
        LOGGER.debug("updateViewWithPasswordValidationRulesResult() entry");
        this.hideLoadingPanel();

        passwordValidationRules.setPasswordMustBeDifferentFromEmployeeNumber(isPasswordMustBeDifferentFromEmployeeNumber);
        passwordValidationRules.setPasswordMustBeDifferentFromName(isPasswordMustBeDifferentFromName);
        passwordValidationRules.setPasswordMustNotHaveSpaces(isPasswordMustNotHaveSpaces);
        passwordValidationRules.setPasswordMustBeDifferentFromDate(isPasswordMustBeDifferentFromDate);

    }

    /**
     * Function called to update the window with the new information.
     *
     * @param availableUserGroups
     *            The List of user group entries that are to be shown in the available tree.
     */
    void updateViewWithCreateUserResult(List<String> availableUserGroups) {
        LOGGER.debug("updateViewWithCreateUserResult() entry");
        this.hideLoadingPanel();

        if (availableUserGroups != null) {
            LOGGER.debug("updateViewWithCreateUserResult - Number of Available user groups are : " + availableUserGroups.size());
            for (String userGroup : availableUserGroups) {
                userGroupDataHolder.getAvailableUsersList().addElement(userGroup);
            }
        } else {
            LOGGER.info("updateViewWithCreateUserResult() - Null Vector of user groups.");
        }
    }

    /**
     * Handler for buttons in button bar. Called by USM framework, when a button is clicked
     * Delegates to appropriate helper method
     * 
     * @param buttonType
     *            Identifier for the button that was clicked
     * 
     * @see com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons#handleButtonClick
     */
    @Override
    public void handleButtonClick(USMButtonTypeEnum buttonType) {
        LOGGER.info("handleButtonClick() entry");
        if (USMButtonTypeEnum.BTN_TYPE_OK.equals(buttonType)) {
            createUser();
        } else if (USMButtonTypeEnum.BTN_TYPE_CANCEL.equals(buttonType)) {
            this.getFrame().closeFrame();
        } else {
            LOGGER.info("unexpected...");
        }
        LOGGER.info("handleButtonClick() exit");
    }

    /**
     * Helper function to return the Associated Controller. This is correctly type casted to the correct type so that it
     * can be used.
     * 
     * @return UACreateUserClientController The Client Controller associated with the View.
     */
    private UACreateUserClientController getAssociatedController() {
        return (UACreateUserClientController) associatedClientController;
    }

    /**
     * Sends request to create the user.
     */
    private void createUser() {
        LOGGER.debug("createUser() entry");

        boolean userDataValid = detailsTabGroup.setComponentValueToUserData(false);
        DefaultListModel<String> listModel = userGroupDataHolder.getAssignedUsersList();
        List<String> userGroups = new ArrayList<>();

        for (int index = 0; index < listModel.size(); index++) {
            LOGGER.debug("ELEMENT {}", userGroupDataHolder.getAssignedUsersList().get(index));
            userGroups.add(listModel.get(index));
        }

        if (userDataValid) {
            getAssociatedController().sendRequestToCreateUser(mUser, userGroups);
        } else {
            LOGGER.debug(" component value are wrong");
        }
        LOGGER.debug(" createUser () exit from the function");
    }

    /**
     * Overridden method to return the component to be embedded in the view
     * @return the view itself
     * 
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getComponent()
     */
    @Override
    public JComponent getComponent() {
        return this;
    }

    /**
     * Overridden method to return the icons to be embedded in the button bar
     * @return vector of icons
     * 
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getComponent()
     */
    private static List<USMButtonType> getIcons() {
        List<USMButtonType> icons = new ArrayList<>();
        LOGGER.debug("getIcons() entry");
        USMButtonType apply = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_OK, USMMenuNameList.OPERATION_USER_NEW, new JfxText("Create a new user with specified settings"), true);
        icons.add(apply);
        icons.add(USMButtonType.BTN_TYPE_CANCEL);
        LOGGER.debug("getIcons() exit");
        return icons;
    }

    /**
     * All the controls of the User Create / Modify Window are created and initialized in this method.
     */
    private void initComponents() {
        LOGGER.debug("initcomponents() enter");

        // The Administrator user can't be deactivated using the icons on the window but when the user can be deactivated using Edit User option Begin
        detailsTabGroup = new UAUserDetailsTabGroup(userGroupDataHolder, mUser, null, passwordValidationRules);
        populatePwdExpirationData(SecuritySettingsManager.getInstance().getGeneralSettingsData().getInitPasswordChangeInterval());
        populateInactivityTimeoutData(SecuritySettingsManager.getInstance().getGeneralSettingsData().getInactivityTimeout());

        populateAccountExpireDateValue(getCurrentDate());

        setPreferredSize(new Dimension(WINDOW_WIDTH, WINDOW_HEIGHT));
        LOGGER.debug("Initcomponents() exit");
    }

    /**
     * Function to show a message to the user
     *
     * @param message
     *            The Text that should be displayed
     */
    public void showMessage(String message) {
        JfxOptionPane.showMessageBox(this, message);
    }

    /**
     * Handle user group created notification & update view
     * 
     * @param p_strUserGroup
     *            User group which has been created
     */
    void onUserGroupCreated(String p_strUserGroup) {
        LOGGER.debug("onUserGroupCreated() in the method ");

        userGroupDataHolder.getAvailableUsersList().addElement(p_strUserGroup);
    }

    /**
     * Handle the user removed notification
     * 
     * @param strUserGroup
     *            string contains the removed user group name
     */
    void onUserGroupRemoved(String strUserGroup) {
        LOGGER.debug("onUserGroupRemoved() in the method ");
        if (userGroupDataHolder.getAssignedUsersList().contains(strUserGroup)) {
            userGroupDataHolder.getAssignedUsersList().removeElement(strUserGroup);
        }
        if (userGroupDataHolder.getAvailableUsersList().contains(strUserGroup)) {
            userGroupDataHolder.getAvailableUsersList().removeElement(strUserGroup);
        }
        LOGGER.debug("onUserGroupRemoved() exit ");
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView_BtnPnl_StatusBar#enableBtnsAfterLongOperationCompleted()
     */
    @Override
    protected void enableDisableControls() {
        enableAllButtons();
    }

    /**
     * Method to show the loading screen
     */
    private void showLoadingPanel() {
        getPanelForPlacingDerviedControls().add(loadingPanel, BorderLayout.CENTER);
        loadingPanel.setActivityIndicatorVisible(true);
    }

    /**
     * Method to remove the loading screen
     */
    private void hideLoadingPanel() {
        getPanelForPlacingDerviedControls().remove(loadingPanel);
        getPanelForPlacingDerviedControls().add(detailsTabGroup);
        loadingPanel.setActivityIndicatorVisible(false);
        this.revalidate();
    }

    /**
     * Settings the Pwd expiration value
     * 
     * @param noOfDays
     */
    private void populatePwdExpirationData(int noOfDays) {
        detailsTabGroup.setPwdExpirationValue(noOfDays);
    }
    
    /**
     * Settings the Inactivity Timeout value
     * 
     * @param noOfMin
     */
    private void populateInactivityTimeoutData(int noOfMin) {
        detailsTabGroup.setInactTimeoutValue(noOfMin);
    }

    /**
     *
     * @param expirationDate
     */
    private void populateAccountExpireDateValue(Date expirationDate) {
        detailsTabGroup.setAccountExpireDateValue(expirationDate);
    }


 
    /**
     * Function to decide what is the Frame that should be used.
     * 
     * @return USMFrameType The Frame type that should be used.
     */
    @Override
    protected USMFrameType getFrameTypeToBeUsed() {
        return USMFrameType.S_INTERNAL;
    }

    @Override
    public boolean isDockable() {    
        return false;
    }
    
    @Override
    public Icon getIcon() {
        return ResourcesIconFactory.ICON_WINDOW_USER_16;
    }

    /**
     *
     * @return
     * @throws ParseException
     */
    private Date getCurrentDate() {
        Date todayWithZeroTime;
        try {
            DateFormat formatter = new SimpleDateFormat(FORMAT_DATE);
            Date today = new Date();
            todayWithZeroTime = formatter.parse(formatter.format(today));
        } catch (ParseException e) {
            LOGGER.error("Error getting the current date with zero time.", e);
            todayWithZeroTime = new Date();
        }
        return todayWithZeroTime;
    }
}