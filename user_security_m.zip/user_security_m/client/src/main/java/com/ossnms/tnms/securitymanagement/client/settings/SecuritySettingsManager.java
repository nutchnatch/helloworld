package com.ossnms.tnms.securitymanagement.client.settings;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMBaseController;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.bicnet.securitymanagement.common.general.GSMessageType;

import java.util.ArrayList;
import java.util.List;

public class SecuritySettingsManager extends USMBaseController {
    
    private GSGeneralSettingData generalSettingsData = new GSGeneralSettingData();
    private static SecuritySettingsManager instance = new SecuritySettingsManager();

    public static SecuritySettingsManager getInstance() {
        return instance;
    }

    public void initialize() {
        registerSecuritySettingsNotifications();
    }

    public GSGeneralSettingData getGeneralSettingsData() {
        return generalSettingsData;
    }

    public void setGeneralSettingsData(GSGeneralSettingData generalSettingsData) {
        this.generalSettingsData = generalSettingsData;
    }

    @Override
    public void handleNotification(USMMessage message) {
        if (message.getMessageType().equals(GSMessageType.GS_NOT_GENERAL_SETTING_DATA_UPDATE)) {
            GSGeneralSettingData generalSettings = (GSGeneralSettingData) message.popObject();
            this.setGeneralSettingsData(generalSettings);
        }
    }

    @Override
    public void resultAvailable(USMJob job, USMMessage result) {
        // This manager executes no jobs
    }

    private void registerSecuritySettingsNotifications() {
        List<USMBaseMsgType> messageTypes = new ArrayList<>();
        messageTypes.add(GSMessageType.GS_NOT_GENERAL_SETTING_DATA_UPDATE);

        registerInterestedNotificationIds(messageTypes);
    }
}
