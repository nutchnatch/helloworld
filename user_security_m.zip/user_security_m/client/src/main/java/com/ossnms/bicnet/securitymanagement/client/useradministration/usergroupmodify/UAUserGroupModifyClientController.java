package com.ossnms.bicnet.securitymanagement.client.useradministration.usergroupmodify;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobGetAllAssignedAndUnAssignedUsergroups;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobGetAllAssignedAndUnAssignedUsers;
import com.ossnms.bicnet.securitymanagement.client.useradministration.job.UAJobModifyUserGroup;
import com.ossnms.bicnet.securitymanagement.client.useradministration.usergroup.common.UAUserGroupDomainMappingProxy;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessageType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAStatus;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserGroup;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserNameAndID;
import org.apache.log4j.Logger;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * This class implements the controller for the User Group Modification
 *  View.This listens to the notifications and updates the view
 * Listen following notifications
 * 1. S_UA_REMOVE_USER_GROUP - Same user group removal by other client
 * 2. S_UA_MODIFY_USER_GROUP - Same user group modification by other client
 * 3. S_UA_NOT_CREATE_USER   - new user created by other client
 * 4. S_UA_NOT_REMOVE_USER   - Users deleted by other client
 **/
public class UAUserGroupModifyClientController extends UAUserGroupDomainMappingProxy {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(UAUserGroupModifyClientController.class);

	/**
	 * Data member to hold the User Group for which this View was opened.
	 */
	private UAUserGroup associatedUG = null;
	/**
	 * This is the constructor
	 * 
	 * @param view -
	 *            This is the view associated with the controller
	 */
	public UAUserGroupModifyClientController(
		UAUserGroup associatedUG,
		UAUserGroupModifyView view) {
		super(view);
		this.associatedUG = associatedUG;
		registerInterestedNotificationIds(getInterestedNotifications());
	}
	/**
	 * Function to return a Vector which contains the list of types that this
	 * controller is interested in.
	 * 
	 * @return List - 
	 *      The List which contains the notification types,
	 *      the controller is interested in.
	 */
	private List getInterestedNotifications() {
		LOGGER.debug("getInterestedNotifications()  Enter");
		List vectorForNotification = new ArrayList();
		vectorForNotification.add(UAMessageType.S_UG_NOT_REMOVE_USER_GROUP);
		vectorForNotification.add(UAMessageType.S_UG_NOT_MODIFY_USER_GROUP);
		vectorForNotification.add(UAMessageType.S_UA_NOT_CREATE_USER);
		vectorForNotification.add(UAMessageType.S_UA_NOT_REMOVE_USER);
		vectorForNotification.add(UAMessageType.S_UA_NOT_MODIFY_USER);
		LOGGER.debug("getInterestedNotifications()  Exit");
		return vectorForNotification;
	}
	/**
	 * Helper method called by the framework when a notifiaction is received.
	 * Forwards to the appropriate method
	 * 
	 * @param message
	 *      Message encapsulating the notification
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc#handleNotification(com.ossnms.bicnet.securitymanagement.common.basic.USMMessage)
	 */
	@Override
    public void handleNotification(USMMessage message) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handleNotification(" + message.size() + ")  Enter");
		}
		
		super.handleNotification(message);
		
		// handling user group removal notification
		if (message.getMessageType().equals(UAMessageType.S_UG_NOT_REMOVE_USER_GROUP)) {
			updateDeleteUserGroupView(message);
		}
		// handling user group modification notification
		else if (message.getMessageType().equals(UAMessageType.S_UG_NOT_MODIFY_USER_GROUP)) {
			updateUserGroupModified(message);

		}
		// handling user creation notification
		else if (message.getMessageType().equals(UAMessageType.S_UA_NOT_CREATE_USER)) {
			updateModifyUserGroupViewForNewUserNot(message);
		}
		// handling users deletion notification
		else if (message.getMessageType().equals(UAMessageType.S_UA_NOT_REMOVE_USER)) {
			updateModifyUserGroupViewForUsersDelNot(message);
		} else if (message.getMessageType().equals(UAMessageType.S_UA_NOT_MODIFY_USER)) {
			updateModifyUserGroupViewForUsersModifyNot(message);
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handleNotification(" + message.size() + ")  Exit");
		}
	}
	/**
	 * @param message
	 */
	private void updateModifyUserGroupViewForUsersModifyNot(USMMessage message) {
		// TODO Auto-generated method stub
		UAUser usr = new UAUser();
		usr.popMe(message);

		UAJobGetAllAssignedAndUnAssignedUsergroups job =
			new UAJobGetAllAssignedAndUnAssignedUsergroups(
				this,
				usr.getUserId());
		queueJob(job);
	}
	/**
	 * @param message
	 */
	private void updateUserGroupModified(USMMessage message) {

		UAUserGroup grp = new UAUserGroup();
		grp.popMe(message);
		if (associatedUG.equals(grp)) {
			// Only if the User Group modified is the same as this one should
			// we do the extra handling.
			 ((UAUserGroupModifyView) associatedView).groupModified(grp);
			sendRequestToFetchAssignedNonAvailableUsers();
		}

	}

	/**
	* Handles the notification for the user group deletion
	* 
	* @param message
	*       Message that contains the user group deleted
	*/
	private void updateDeleteUserGroupView(USMMessage message) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"updateDeleteUserGroupView(" + message.size() + ")  Enter");
		}
		int nCountUserGroups = (message.popInteger()).intValue();
		for (int idx = 0; idx < nCountUserGroups; ++idx) {
			UAUserGroup dataUserGroup = new UAUserGroup();
			dataUserGroup.popMe(message);
			String usergroupName = dataUserGroup.getName();
			String usergroupNameDisplayed =
				((UAUserGroupModifyView) associatedView).getUserGroupName();
			if (usergroupName.equals(usergroupNameDisplayed)) {
				associatedView.closeWindowOnObjectDeletion();
			}
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"updateDeleteUserGroupView(" + message.size() + ")  Exit");
		}

	}
	/**
	 * Handles notification for newly created user 
	 * 
	 * @param message
	 *      Message that contains the user information
	 */
	private void updateModifyUserGroupViewForNewUserNot(USMMessage message) {
		LOGGER.debug(
			"updateModifyUserGroupViewForNewUserNot("
				+ message.size()
				+ ")  Enter");
		UAUser objUser = new UAUser();
		objUser.popMe(message);

		UAJobGetAllAssignedAndUnAssignedUsergroups job =
			new UAJobGetAllAssignedAndUnAssignedUsergroups(
				this,
				objUser.getUserId());
		queueJob(job);
		LOGGER.debug(
			"updateModifyUserGroupViewForNewUserNot("
				+ message.size()
				+ ")  Exit");
	}
	/**
	 * Handles notification for users deletion 
	 * 
	 * @param message
	 *      Message that contains the user group information
	 */
	private void updateModifyUserGroupViewForUsersDelNot(USMMessage message) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"updateModifyUserGroupViewForUsersDelNot("
					+ message.size()
					+ ")  Enter");
		}
		int nNoOfElms = message.popInteger();
		for (int index = 0; index < nNoOfElms; index++) {
			String strUserID = message.popString();
			UAUserNameAndID objUserNameID = new UAUserNameAndID();
			objUserNameID.setUserId(strUserID);
			DefaultListModel modelUnAssigned =
				((UAUserGroupModifyView) associatedView)
					.getGeneralPane().getAvailableUsersListModel();
			modelUnAssigned.removeElement(objUserNameID);

			DefaultListModel modelAssigned =
				((UAUserGroupModifyView) associatedView)
					.getGeneralPane().getAssignedUserListModel();
			modelAssigned.removeElement(objUserNameID);
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"updateModifyUserGroupViewForUsersDelNot("
					+ message.size()
					+ ")  Exit");
		}
	}

	/**
	 * Retrieves all the assigned and unassigned users for the given user group
	 *
	 */
	public boolean sendRequestToFetchAssignedNonAvailableUsers() {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"sendRequestToFetchAssignedNonAvailableUsers("
					+ associatedUG
					+ ")  Enter");
		}
		UAJobGetAllAssignedAndUnAssignedUsers objJobgetAllUserGroup =
			new UAJobGetAllAssignedAndUnAssignedUsers(this, associatedUG);
		boolean bStatus = queueJob(objJobgetAllUserGroup);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"sendRequestToFetchAssignedNonAvailableUsers("
					+ associatedUG
					+ ")  Exit - Return :"
					+ bStatus);
		}
		return bStatus;
	}

	/**
	 * Populates all the details for the user group to be modified
	 * 
	 * @param msg 
	 *      Details of the user group( name, description, assigned users and available users)
	 * @return 
	 *       operation status; true if successful; false otherwise
	 */
	public boolean updateDataModel(USMMessage msg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("updateDataModel(" + msg.size() + ")  Enter");
		}
		boolean bOp = true;
		if (msg == null) {
			bOp = false;
			LOGGER.info("Invalid_Message_Passed_27");
		} else {
			// Pop the number of unassigned  users.			
			int ndump = msg.popInteger();
	        if(associatedView != null) {
    			DefaultListModel unassigneduserModel =
    				((UAUserGroupModifyView) associatedView)
    					.getGeneralPane().getAvailableUsersListModel();
    			unassigneduserModel.clear();
    			for (int idx = 0; idx < ndump; ++idx) {
    				UAUserNameAndID objzUser = new UAUserNameAndID();
    
    				objzUser.popMe(msg);
    				unassigneduserModel.addElement(objzUser);
    			}
    			//Pop the number of assigned  users.
    			ndump = msg.popInteger();
    			DefaultListModel assigneduserModel =
    				((UAUserGroupModifyView) associatedView)
    					.getGeneralPane().getAssignedUserListModel();
    			assigneduserModel.clear();
    			for (int idx = 0; idx < ndump; ++idx) {
    				UAUserNameAndID objzUser = new UAUserNameAndID();
    				objzUser.popMe(msg);
    				assigneduserModel.addElement(objzUser);
    			}
			}
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"updateDataModel(" + msg.size() + ")  Exit - Return :" + bOp);
		}
		return bOp;
	}

	/**
	 * Sends a request to modify a user group
	 * 
	 * @param userGroupData -
	 *      The user group object to be modified
	 * @param usersForUserGroup -
	 *      Vector of users to be assigned to this user group
	 * @param mappingsForUserGroup 
	 * @return boolean 
	 *      operation status; true if successful; false otherwise
	 */
	public boolean sendRequestToModifyUserGroup(
		UAUserGroup userGroupData,
		List<String> usersForUserGroup, List<DCDomainMapping> mappingsForUserGroup) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"sendRequestToModifyUserGroup("
					+ userGroupData
					+ ","
					+ usersForUserGroup
					+ ")  Enter");
		}
		UAJobModifyUserGroup objJobgetCreateUserGroup =
			new UAJobModifyUserGroup(this, userGroupData, usersForUserGroup, mappingsForUserGroup);
		boolean bStatus = queueJob(objJobgetCreateUserGroup);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"sendRequestToModifyUserGroup("
					+ userGroupData
					+ ","
					+ usersForUserGroup
					+ ")  Exit - Return :"
					+ bStatus);
		}
		return bStatus;
	}

	/**
	 * Helper method called by the framework when a response is received.
	 * Forwards to the appropriate method
	 * 
	 * @param job
	 *      reference to the job which resulted in the original request
	 * @param result
	 *      result of executing the given job
	 *
	 */
	@Override
	public void resultAvailable(USMJob job, USMMessage result) {
		LOGGER.debug("resultAvailable() Enter" + result.getMessageType());
		if (result.getMessageType().equals(UAMessageType.S_UG_RES_MODIFY_USER_GROUP)) {
			handleResponseForModifyUserGroup(result);
		} else if (result.getMessageType().equals(UAMessageType.S_UA_RES_GET_ASSIGNED_AND_UNASSIGNED_USERGROUP)) {
			handleResponseForModifyUser(result);
		} else if (result.getMessageType().equals(DCMessageType.DC_RES_ASSIGN_MAPPING)) {
			handleResponseAssignMappings(result);
		}
		else{
			handleResponseGetMappingsForUserGroup(result);
			updateDataModel(result);
		}
		LOGGER.debug("handleResponseForAllUsers() Exit" + result.getMessageType());
	}

	/**
	 * @param result
	 */
	private void handleResponseForModifyUser(USMMessage result) {
		UAUser userdata = new UAUser();
		List vecassignedUgrp = new ArrayList();
		List vecAvailableUgrp = new ArrayList();

		// Pop the Count of Available Menu options ( STRINGS )
		int nCount = result.popInteger();

		for (int idx = 0; idx < nCount; ++idx) {
			String ugrpName = result.popString();
			vecAvailableUgrp.add(ugrpName);
		}
		int nCount1 = result.popInteger();

		for (int idx = 0; idx < nCount1; ++idx) {
			String ugrpName1 = result.popString();
			vecassignedUgrp.add(ugrpName1);
		}
		userdata.popMe(result);

		String strUGName = associatedUG.getName();
		UAUserNameAndID objUserNameID = new UAUserNameAndID();
		objUserNameID.setCommonName(userdata.getCommonName());
		objUserNameID.setUserId(userdata.getUserId());

		DefaultListModel modelUnAssignedList = ((UAUserGroupModifyView) associatedView).getGeneralPane().getAvailableUsersListModel();
		DefaultListModel modelAssignedList = ((UAUserGroupModifyView) associatedView).getGeneralPane().getAssignedUserListModel();

		if (vecAvailableUgrp.contains(strUGName)) {
			modelUnAssignedList.addElement(objUserNameID);
			modelAssignedList.removeElement(objUserNameID);
		} else if (vecassignedUgrp.contains(strUGName)) {
			modelAssignedList.addElement(objUserNameID);
			modelUnAssignedList.removeElement(objUserNameID);
		}

	}
	/**
	 * Handles the response for the modify user group operation
	 * 
	 * @param message
	 *      The message which is sent by the server interactor on modification
	 *      of a user group.
	 */
	private void handleResponseForModifyUserGroup(USMMessage message) {
		final String functionName = "handleResponseForModifyUserGroup ( )";
		LOGGER.debug(functionName + " ENTER_FUNCTION");
		boolean bOp = true;
		String errorMessage = "";
		try {
			// Pop the Result of the Operation.
			UAStatus statusObject = new UAStatus();
			statusObject.popMe(message);
			int nResult = statusObject.getStatus();
			if (nResult == UAStatus.S_SUCCESS) {
                LOGGER.debug(functionName + " look created user group in admin window");
				associatedView.close();
			} else if (
			        nResult == UAStatus.S_USERGROUP_CAN_BE_CREATED_EVEN_USERS_NOT_VALID) {
				List inValidUsers = (List) message.popObject();
				Iterator iter = inValidUsers.iterator();
				errorMessage = USMStringTable.IDS_UG_INVALID_USER_MODIFY_ERROR.toString();
				while (iter.hasNext()) {
					bOp = false;
					String userID = (String) iter.next();
					errorMessage += userID + "\n";
					LOGGER.error("Modify User group  : Invalid user removed " + userID);
				}
				associatedView.close();
			} else {
				if (nResult == UAStatus.S_LDAP_ERROR) {
					bOp = false;
					errorMessage += "Server returned LDAP Error";
					LOGGER.error(functionName + "Server returned LDAP Error");
				} else if (nResult == UAStatus.S_INTERNAL_ERROR) {
					bOp = false;
					errorMessage += "Server returned Internal Error";
					LOGGER.error(functionName + "Server returned Internal Error");
				}
			}
			if (!bOp) {
				((UAUserGroupModifyView) associatedView).showMessageWindow(errorMessage);
			}

		} catch (Exception ex) {
            bOp = false;
            LOGGER.error(functionName + "EXCEPTION: " + ex.getClass() + "Message : " + ex.getMessage());
		}
		LOGGER.debug(functionName + " EXIT_FUNCTION");
	}
}