/*
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *11-Apr-2011	Ajay			GX000841:XML Export/Import - Users with USERIDs with Lower and Capital letters (e.g. DXuser) aren't assigned to there "UserGroups"
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.basic;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginAction;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginImportExportItem;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandManager;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.importexport.IEDefaultImportExportItem;
import com.ossnms.bicnet.securitymanagement.client.importexport.IETagNames;
import com.ossnms.bicnet.securitymanagement.client.importexport.IEXmlReader;
import org.w3c.dom.Element;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents the single access point that should be used by the other calling subsystems to do their work. These include - 1. Retrieval of the Menu Actions
 */
public final class USMBasicSAP {
    /**
     * Private Constructor to make sure no one can instantiate the class.
     */
    private USMBasicSAP() {
    }

    /**
     * Function to return the Actions that are associated with USM for the File menu
     *
     * @return BiCNetPluginAction[] - The Array of Actions of USM
     */
    public static BiCNetPluginAction[] getFileMainActions() {
        return USMCommandManager.getInstance().getFileMainActions();
    }

    /**
     * Function to return the Actions that are associated with USM
     *
     * @return BiCNetPluginAction[] - The Array of Actions of USM
     */
    public static BiCNetPluginAction[] getMainActions() {
        return USMCommandManager.getInstance().getMainActions();
    }

    /**
     * Function to return the Import/Export item that are associated with USM
     *
     * @return BiCNetPluginImportExportItem[] - The Array of Import/Export item of USM
     */
    public static BiCNetPluginImportExportItem[] getImportExportItems(Element arg0) {

        List importableItems = new ArrayList();

        if (arg0 == null) {
            return new BiCNetPluginImportExportItem[]{
                    // GX000841 :changed the sequence of array list.For import/export ,first User groups and then user.
                    new IEDefaultImportExportItem(USMStringTable.IDS_IE_USER_GROUPS, true, true), new IEDefaultImportExportItem(USMStringTable.IDS_IE_USERS, true, true),

                    new IEDefaultImportExportItem(USMStringTable.IDS_IE_DOMAINS, true, true), new IEDefaultImportExportItem(USMStringTable.IDS_IE_POLICIES, true, true),
                    new IEDefaultImportExportItem(USMStringTable.IDS_IE_DOMAIN_MAPPING, true, true)};
        } else {

            IEXmlReader reader = IEXmlReader.getInstance();
            Element domainObj = reader.getSingleElementForSection(arg0, IETagNames.DOMAIN_SECTION);
            BiCNetPluginImportExportItem domainItem = new IEDefaultImportExportItem(USMStringTable.IDS_IE_DOMAINS, true, true);

            if (domainObj != null) {
                importableItems.add(domainItem);
            }

            Element usergroups = reader.getSingleElementForSection(arg0, IETagNames.USER_GROUP_SECTION);
            BiCNetPluginImportExportItem usergroupsItem = new IEDefaultImportExportItem(USMStringTable.IDS_IE_USER_GROUPS, true, true);

            if (usergroups != null) {
                importableItems.add(usergroupsItem);
            }
            Element users = reader.getSingleElementForSection(arg0, IETagNames.USER_SECTION);
            BiCNetPluginImportExportItem usersItem = new IEDefaultImportExportItem(USMStringTable.IDS_IE_USERS, true, true);

            if (users != null) {
                importableItems.add(usersItem);
            }

            Element policies = reader.getSingleElementForSection(arg0, IETagNames.POLICIES_SECTION);
            BiCNetPluginImportExportItem policiesItem = new IEDefaultImportExportItem(USMStringTable.IDS_IE_POLICIES, true, true);

            if (policies != null) {
                importableItems.add(policiesItem);
            }

            Element domainMappings = reader.getSingleElementForSection(arg0, IETagNames.MAPPING_SECTION);
            BiCNetPluginImportExportItem domainMappingsItem = new IEDefaultImportExportItem(USMStringTable.IDS_IE_DOMAIN_MAPPING, true, true);

            if (domainMappings != null) {
                importableItems.add(domainMappingsItem);
            }

            BiCNetPluginImportExportItem[] importables = new BiCNetPluginImportExportItem[importableItems.size()];
            importableItems.toArray(importables);
            return importables;
        }
    }
}