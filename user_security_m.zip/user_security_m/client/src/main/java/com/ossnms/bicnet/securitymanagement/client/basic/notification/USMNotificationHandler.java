/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMNotificationHandler
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.MMR
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Mar-2005	Muyeen Munaver	CF001328 - Handle all client notifications via client topic
 * 26-May-2005  Muyeen Munaver  CF002321 - Client Message Flow Control
 * 05-May-2005  Muyeen Munaver  CF001312   Master-Master Replication for Sun ONE DS
 * 05-May-2005  Babu B          CF001312   Master-Master Replication for Sun ONE DS
 * 06-May-2009  Nagaraddi S S    TD004578 - RQT-STDERR errors instead log4j's
 * 24-Aug-2011   João Pires      GX000987 - Avoiding ClassCastException between UserLogoff and USMMessage
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.notification;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginServerAccessController;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginTopicListener;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEventIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEvtRegistrar;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.auth.AAMessageType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSMessageType;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessageType;
import com.ossnms.bicnet.securitymanagement.common.general.GSMessageType;
import com.ossnms.bicnet.securitymanagement.common.policy.PAMessageType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import java.security.PrivilegedActionException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.MESSAGE_TYPE;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.NOTIFICATION;

/**
 * This is the single class which is responsible for registering with the Topic.
 * This class will then forward the notification that it receives to the
 * interested
 */
public final class USMNotificationHandler implements BiCNetPluginTopicListener, USMLogonLogoffEventIfc {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(USMNotificationHandler.class);

	/**
	 * Data member to hold the USM string defined in BiCNetComponentType
	 */
	private static final String STR_USM = BiCNetComponentType.SECURITY_MANAGER.toString();

	/**
	 * Data member to hold the JNDIName for the topic
	 */
	private static final String S_TOPIC_NAME = "topic/client";

	/**
	 * Data member to hold the JNDI Nmae for the Factory
	 */
	private static final String S_TOPIC_FACTORY = null;

	/**
	 * prevents instantiation
	 */
	public USMNotificationHandler() {
		LOGGER.debug("Creating an instance of USMNotificationHandler");

		// This is a dummy creation so that the object can be registered for
		// listening to the notifications related to
		// Server shutdown 
		// Server re-initialized
		new USMServerStateListenerClientController();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginTopicListener#eventPluginTopicMessage(javax.jms.Message)
	 */
	@Override
    public void eventPluginTopicMessage(final Message message) {
		LOGGER.debug("Entering eventPluginTopicMessage. Message being passed is : {}", message);

		try {
			String strSender = message.getStringProperty(IBiCNetMessage.PROP_SENDER_ID);

			if (strSender.compareTo(STR_USM) == 0) {
				BiCNetPluginServerAccessController.doPrivileged(this, () -> {
                    LOGGER.debug("Inside the Run of the Message Handler");

					ObjectMessage obj = (ObjectMessage) message;
                    if(obj.getObject() instanceof USMMessage){
						USMMessage msg = (USMMessage) obj.getObject();

						LOGGER.debug("Successfully converted to USMMessage. {}", msg);
						USMBaseMsgType type = msg.getMessageType();
						Set<USMControllerIfc> stOrig = USMNotificationRegistrar.getInstance().getRegisteredCtls(type);

						if (stOrig == null) {
							LOGGER.debug("Set of Controllers registered is null. Message type is : {}", type);
							return null;
						}
						// make/operate on the clone to avoid ConcurrentModificationException
						Set<USMControllerIfc> st = new HashSet<>(stOrig);
						// notify each of the controllers
						st.forEach(ctl -> {
							USMMessage copy = msg.copy();
							try {
								ctl.notificationReceived(copy);
							} catch (Exception e) {
								LOGGER.error("Exception reported.", e);
							}
						});
                    }
                    return null;
                });
			}
		} catch (PrivilegedActionException | JMSException ex) {
			LOGGER.error("Exception :", ex);
		}
		LOGGER.debug("Exiting eventPluginTopicMessage");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginTopicListener#eventPluginTopicLost()
	 */
	@Override
    public void eventPluginTopicLost() {
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEventInfc#operatorLoggedOn()
	 */
	@Override
    public void operatorLoggedOn(ISessionContext sessionContext) {
		try {
			USMUtility.getInstance().subscribeServerMessages(S_TOPIC_FACTORY, getMessageTypeList(), "", this);
		} catch (FrameworkException e) {
			LOGGER.error("Could not subscribe server messages due to an exception.", e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEventInfc#operatorLoggedOff()
	 */
	@Override
    public void operatorLoggedOff(ISessionContext sessionContext) {
		USMUtility.getInstance().unsubscribeServerMessages(S_TOPIC_FACTORY, getMessageTypeList(), "", this);
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.common.basic.USMLifeCycleController#initialize()
	 */
	public boolean initialize() {
		USMLogonLogoffEvtRegistrar.getInstance().register(this);
		return true;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.common.basic.USMLifeCycleController#cleanup()
	 */
	public boolean cleanup() {
		return false;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEventIfc#operatorLoggingOff()
	 */
	@Override
    public void operatorLoggingOff(ISessionContext sessionContext) {}

	/**
	 * List of message types to (un)subscribe
	 * @return
     */
	public List<String> getMessageTypeList() {
		List<String> messsageTypeList = new ArrayList<>();

		// policy messages
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(PAMessageType.S_PA_NOT_POLICY_DELETED));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(PAMessageType.S_PA_NOT_POLICY_CREATED));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(PAMessageType.S_PA_NOT_POLICY_MODIFIED));

		// server status messages
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(USMBaseMsgType.BASIC_SERVER_REINITIALIZED));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(USMBaseMsgType.BASIC_SERVER_SHUTDOWN));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(USMBaseMsgType.CLOSE_WINDOWS_AFTER_LDAP_SYNC));

		// settings data messages
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(GSMessageType.GS_NOT_GENERAL_SETTING_DATA_UPDATE));

		// acl messages
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(BSMessageType.BS_NOT_SEC_OBJS_ASSIGNED_TO_DOMAINS));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(BSMessageType.BS_NOT_SEC_OBJS_UNASSIGNED_FROM_DOMAINS));

		// sec. objects messages
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(BSMessageType.BS_NOT_NEW_SEC_OBJ_REGISTERED));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(BSMessageType.BS_NOT_SEC_OBJ_UNREGISTERED));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(BSMessageType.BS_NOT_SEC_OBJ_CONTAINER_CHANGE));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(BSMessageType.BS_NOT_SEC_OBJ_CHANGED));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(BSMessageType.BS_NOT_CF_INSERTED));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(BSMessageType.BS_NOT_CF_REMOVED));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(BSMessageType.BS_NOT_CF_SYNCED_WITH_SEC_OBJS));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(BSMessageType.BS_NOT_CF_NAME_CHANGED));

		// user groups messages
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(UAMessageType.S_UG_NOT_MODIFY_USER_GROUP));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(UAMessageType.S_UG_NOT_REMOVE_USER_GROUP));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(UAMessageType.S_UG_NOT_CREATE_USER_GROUP));

		// user messages
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(UAMessageType.S_UA_NOTIFICATION_USER_LOGIN_FAILED));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(UAMessageType.S_UA_NOT_ACTIVATE_USER));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(UAMessageType.S_UA_NOT_DEACTIVATE_USER));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(UAMessageType.S_UA_NOT_UNLOCK_USER));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(UAMessageType.S_UA_NOT_CREATE_USER));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(UAMessageType.S_UA_NOT_REMOVE_USER));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(UAMessageType.S_UA_NOT_MODIFY_USER));

		// auth messages
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(AAMessageType.AA_NOTIFICATION_SERVER_SHUTDOWN));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(AAMessageType.AA_NOTIFICATION_USER_LOGIN_ATTEMPT));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(AAMessageType.AA_NOTIFICATION_USER_PASSWORD_CHANGED));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(AAMessageType.AA_NOT_PROFILE_DELETED));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(AAMessageType.AA_NOT_PROFILE_UPDATED));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(AAMessageType.AA_NOTIFICATION_USER_LOGIN_FAILED));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(AAMessageType.AA_NOTIFICATION_USER_LOGGEDIN));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(AAMessageType.AA_NOTIFICATION_USER_LOGGEDOUT));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(AAMessageType.AA_NOTIFICATION_USER_FORCE_LOGOUT_TRIAL_EXPIRED));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(AAMessageType.AA_NOTIFICATION_USER_FORCE_LOGOUT));

		// mapping messages
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(DCMessageType.DC_NOT_MAPPINGS_MODIFIED));

		// domain messages
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(DCMessageType.DC_NOT_DOMAIN_CREATED));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(DCMessageType.DC_NOT_DOMAIN_MODIFIED));
		messsageTypeList.add(NOTIFICATION + getMessageTypeFQN(DCMessageType.DC_NOT_DOMAIN_DELETED));


		return messsageTypeList;
	}

	/**
	 * Get FQN from message
	 * @param message
     * @return
     */
	private String getMessageTypeFQN(USMBaseMsgType message) {
		return "@" + message.getMsgType().toUpperCase() + "@" + MESSAGE_TYPE;
	}
}
