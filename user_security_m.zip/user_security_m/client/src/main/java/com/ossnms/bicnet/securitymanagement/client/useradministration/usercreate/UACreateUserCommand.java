/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name:  UACreateUserCommand
 * Author:      Vinay Purohit
 * Substitute	Babu B
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER.VIEW
 *       : TNMS.DX2.SM.USER.CREATE
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.useradministration.usercreate;

import org.apache.log4j.Logger;

import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;

/**
 * This class is a command handler which handles the user craetion operation
 */
public class UACreateUserCommand extends USMCommand {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(UACreateUserCommand.class);

	/**
	 * This is the constructor
	 */
	public UACreateUserCommand() {
		super(USMCommandID.S_UI_ID_USER_MGMT_CREATE_USER);
		LOGGER.debug("in the constructor");
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#createAndReturnView()
	 */
	@Override
    protected USMBaseView createAndReturnView() {
		LOGGER.debug("createAndReturnView() entry");
		UACreateUserView view = new UACreateUserView();
		LOGGER.debug("createAndReturnView() exit");
		return view;
	}

}
