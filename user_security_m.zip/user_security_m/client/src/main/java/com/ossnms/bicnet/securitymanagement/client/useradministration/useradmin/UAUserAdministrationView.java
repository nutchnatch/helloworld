package com.ossnms.bicnet.securitymanagement.client.useradministration.useradmin;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientProperties;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientPropertyListener;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.framework.client.jfx.FrameworkDialogApp;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandManager;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMHelp;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMMouseAdapter;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMenuNameList;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAAuthenticationType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UACommonHelper;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import com.ossnms.tools.jfx.JfxFormPanel;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxText;
import com.ossnms.tools.jfx.table.JfxTable;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableColumnModel;
import org.apache.log4j.Logger;

/**
 * This is a user interface class that displays a window for user administration
 */
public class UAUserAdministrationView extends USMBaseViewWithButtons implements TableModelListener, ListSelectionListener, BiCNetPluginClientPropertyListener {
    private static final long serialVersionUID = -4891300704855525811L;
    /**
     * The ID of the Help Screen to be viewed from this window
     */
    private static final int S_HLPID = USMHelp.HID_USER_ADMINISTRATION;
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(UAUserAdministrationView.class);

    // TABLE Control & the associated model
    private UAUserAdministrationTable objTableOfUsers;
    private UAUserAdministrationModel objUserTableModel;

    // Stings to identify operations
    private static final String ACTIVATE = "Users_Activate";
    private static final String DEACTIVATE = "Users_Deactivate";
    private static final String UNLOCK = "Users_Unlock";
    private static final String DELETE = "Users_Delete";
    private static final String FORCELOGOFF = "Users_ForceLogoff";
    private static final String SINGLE_ACTIVATE = "Users_Single_Activate";
    private static final String SINGLE_DEACTIVATE = "Users_Single_Deactivate";
    private static final String SINGLE_UNLOCK = "Users_Single_Unlock";
    private static final String SINGLE_FORCE_LOGOFF = "Users_Single_ForceLogoff";
    private static final String SINGLE_DELETE = "Users_Single_Delete";

    private static final String PROFILE_NAME = "User Admin Window Settings";

    /**
     * This is the constructor
     */
    public UAUserAdministrationView() {
        super(getButtons(), "com.ossnms.bicnet.securitymanagement.client.useradministration.useradministrationview", JfxStringTable.getString(USMStringTable.IDS_UA_ADMIN_TITLE), true, false, S_HLPID);

        // Layout GUI
        initComponents();
        setNamesForTesting();
        // Create the controller and fetch the users from the server
        associatedClientController = new UAUserAdministrationClientController(this);
        getController().sendReqToGetAllUsers();
    }

    /**
     * Helper function that is used to set the Names of all the editable components within the Window.
     *
     * Strings in this function are not to be Internationalized.
     */
    private void setNamesForTesting() {
        objTableOfUsers.setName("UserManagement");
    }

    /**
     * Returns the type-safe UAUserAdministrationClientController
     */
    private UAUserAdministrationClientController getController() {
        return (UAUserAdministrationClientController) associatedClientController;
    }

    /**
     * Handler for buttons in button bar. Called by USM framework, when a button is clicked
     *
     * Delegates to appropriate helper method
     *
     * @see com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons#handleButtonClick(com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum)
     */
    @Override
    public void handleButtonClick(USMButtonTypeEnum type) {
        LOGGER.debug("handleButtonClick - Enter, Button - " + type.toString());

        if (type.equals(USMButtonTypeEnum.BTN_TYPE_NEW)) {
            USMCommandManager.getInstance().executeCmd(USMCommandID.S_UI_ID_USER_MGMT_CREATE_USER, null);
        } else if (type.equals(USMButtonTypeEnum.BTN_TYPE_MODIFY)) {
            onModifyButtonClicked();

        } else if (type.equals(USMButtonTypeEnum.BTN_TYPE_DELETE)) {
            handleDeleteUser();

        } else if (type.equals(USMButtonTypeEnum.BTN_TYPE_FORCE_LOGOFF)) {
            handleForcedLogoffUser();

        } else if (type.equals(USMButtonTypeEnum.BTN_TYPE_UNLOCK)) {
            handleUnlockUser();

        } else if (type.equals(USMButtonTypeEnum.BTN_TYPE_ACTIVATE)) {
            handleActivateUser();

        } else if (type.equals(USMButtonTypeEnum.BTN_TYPE_DEACTIVATE)) {
            handleDeactivateUser();

        } else if (type.equals(USMButtonTypeEnum.BTN_TYPE_CLOSE)) {
            this.getFrame().closeFrame();

        } else {
            USMBaseView.showNotImplementedFeatureWindow();
        }

        LOGGER.debug("handleButtonClick - Exit");
    }

    /**
     * Helper method to handle 'Modify' Button click
     */
    private void onModifyButtonClicked() {
        LOGGER.debug("OnModifyButtonClicked - Enter");

        int arrSelectedRow = objTableOfUsers.getSelectedRow();

        // Locate the user object first
        UAUser objUser = (UAUser) objTableOfUsers.getValueAt(arrSelectedRow, -1);
        String selectedUser = objUser.getUserId();
        USMCommandManager.getInstance().executeCmd(USMCommandID.S_UI_ID_MODIFY_USER, selectedUser);

        LOGGER.debug("OnModifyButtonClicked - Exit");
    }

    /**
     * This method handles the Deletion of one/more user account(s)
     */
    private void handleDeleteUser() {
        LOGGER.debug("handleDeleteUser()  Entry");

        int nSelectedRowCount = objTableOfUsers.getSelectedRowCount();
        int[] arrSelectedRow = objTableOfUsers.getSelectedRows();

        List<String> lstSelectedUsers = new ArrayList<>();

        for (int nRowIndex = 0; nRowIndex < nSelectedRowCount; ++nRowIndex) {
            // Locate the user object first
            UAUser objUser = (UAUser) objTableOfUsers.getValueAt(arrSelectedRow[nRowIndex], -1);
            lstSelectedUsers.add(objUser.getUserId());
        }
        String strMessage;
        if (1 == arrSelectedRow.length) {
            strMessage = SINGLE_DELETE;
        } else {
            strMessage = DELETE;
        }
        if (confirmUserActivity(lstSelectedUsers, strMessage)) {
            getController().sendReqToDeleteSelectedUsers(lstSelectedUsers);
        }

        LOGGER.debug("handleDeleteUser()  Exit");
    }

    /**
     * Retrives the list if users selected in the table
     *
     * @return List of UAUser ids
     */
    private List<String> getSelectedUsers() {
        LOGGER.debug("getSelectedUsers()  Exit");

        int nSelectedRowCount = objTableOfUsers.getSelectedRowCount();
        int[] arrSelectedRow = objTableOfUsers.getSelectedRows();

        List<String> lstSelectedUsers = new ArrayList<>();

        for (int nRowIndex = 0; nRowIndex < nSelectedRowCount; ++nRowIndex) {
            // Locate the user object first
            int nSelectedRow = arrSelectedRow[nRowIndex];
            UAUser objUser = (UAUser) objTableOfUsers.getValueAt(nSelectedRow, -1);
            lstSelectedUsers.add(objUser.getUserId());
        }

        LOGGER.debug("getSelectedUsers()  Exit");
        return lstSelectedUsers;
    }

    /**
     * Hhandles the Activation of one/more user account(s)
     */
    private void handleActivateUser() {
        LOGGER.debug("handleActivateUser()  Entry");

        List<String> lstSelectedUsers = getSelectedUsers();
        String strMessage;
        if (1 == lstSelectedUsers.size()) {
            strMessage = SINGLE_ACTIVATE;
        } else {
            strMessage = ACTIVATE;
        }

        if (confirmUserActivity(lstSelectedUsers, strMessage)) {
            getController().sendReqToActivateSelectedUsers(lstSelectedUsers);
        }

        LOGGER.debug("handleActivateUser()  Entry");
    }

    /**
     * Handles the Deactivation of one/more user account(s)
     */
    private void handleDeactivateUser() {
        LOGGER.debug("handleDeactivateUser()  Entry");

        List<String> lstSelectedUsers = getSelectedUsers();
        String strMessage;
        if (1 == lstSelectedUsers.size()) {
            strMessage = SINGLE_DEACTIVATE;
        } else {
            strMessage = DEACTIVATE;
        }

        if (confirmUserActivity(lstSelectedUsers, strMessage)) {
            getController().sendReqToDeactivateSelectedUsers(lstSelectedUsers);
        }

        LOGGER.debug("handleDeactivateUser()  Exit");
    }

    /**
     * Handles the unlock of one/more user account(s)
     */
    private void handleUnlockUser() {
        LOGGER.debug("handleUnlockUser()  Entry");

        List<String> lstSelectedUsers = getSelectedUsers();
        String strMessage;
        if (1 == lstSelectedUsers.size()) {
            strMessage = SINGLE_UNLOCK;
        } else {
            strMessage = UNLOCK;
        }
        if (confirmUserActivity(lstSelectedUsers, strMessage)) {
            getController().sendReqToUnlockSelectedUsers(lstSelectedUsers);
        }

        LOGGER.debug("handleUnlockUser()  Exit");
    }

    /**
     * Handles the Forced Logoff of an user account
     */
    private void handleForcedLogoffUser() {
        LOGGER.debug("handleForcedLogoffUser()  Entry");

        List<String> lstSelectedUsers = getSelectedUsers();
        String strMessage;
        if (1 == lstSelectedUsers.size()) {
            strMessage = SINGLE_FORCE_LOGOFF;
        } else {
            strMessage = FORCELOGOFF;
        }

        if (confirmUserActivity(lstSelectedUsers, strMessage)) {
            getController().sendReqToForcedLogoffSelectedUsers(lstSelectedUsers);
        }

        LOGGER.debug("handleForcedLogoffUser()  Exit");
    }

    /**
     * This method returns all the buttons that needs to be displayed on the view
     *
     * @return Vector - Vector of buttons that needs to be displayed
     */
    private static List<USMButtonType> getButtons() {
        List<USMButtonType> vecButtons = new ArrayList<>();

        USMButtonType create = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_NEW, USMMenuNameList.OPERATION_USER_NEW, USMStringTable.IDS_UA_CREATE_DESCRIPTION, false);
        vecButtons.add(create);

        USMButtonType modify = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_MODIFY, USMMenuNameList.OPERATION_USER_MODIFY, USMStringTable.IDS_UA_MODIFY_DESCRIPTION, false);
        vecButtons.add(modify);

        USMButtonType delete = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_DELETE, USMMenuNameList.OPERATION_USER_DELETE, USMStringTable.IDS_UA_DELETE_DESCRIPTION, true);
        vecButtons.add(delete);

        vecButtons.add(USMButtonType.BTN_SEPARATOR);

        USMButtonType forceLogoff = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_FORCE_LOGOFF, USMMenuNameList.OPERATION_USER_FORCE_LOGOFF, USMStringTable.IDS_UA_LOGOFF_DESCRIPTION, true);
        vecButtons.add(forceLogoff);

        USMButtonType unlockUser = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_UNLOCK, USMMenuNameList.OPERATION_USER_UNLOCK, USMStringTable.IDS_UA_UNLOCK_DESCRIPTION, true);
        vecButtons.add(unlockUser);

        USMButtonType activate = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_ACTIVATE, USMMenuNameList.OPERATION_USER_ACTIVATE, USMStringTable.IDS_UA_ACTIVATE_DESCRIPTION, true);
        vecButtons.add(activate);

        USMButtonType deactivate = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_DEACTIVATE, USMMenuNameList.OPERATION_USER_DEACTIVATE, USMStringTable.IDS_UA_DEACTIVATE_DESCRIPTION, true);
        vecButtons.add(deactivate);

        vecButtons.add(USMButtonType.BTN_SEPARATOR);

        return vecButtons;
    }

    /**
     * Handler for selection changes in any of the list controls
     *
     * @param e Event describing the action on te list control
     * @see javax.swing.event.ListSelectionListener#valueChanged(javax.swing.event.ListSelectionEvent)
     */
    @Override
    public void valueChanged(ListSelectionEvent e) {
        LOGGER.debug("valueChanged()  Entry");
        enableDisableControls();
        LOGGER.debug("valueChanged()  Exit");
    }

    /**
     * Function to enable and disable the buttons based on the selection.
     */
    @Override
    protected void enableDisableControls() {

        int nTotalRowCount = objTableOfUsers.getRowCount();
        int nSelectedRowCount = objTableOfUsers.getSelectedRowCount();
        int[] arrSelectedRow = objTableOfUsers.getSelectedRows();

        IEnhancedSessionContext objSelfSessionContext = (IEnhancedSessionContext) USMUtility.getInstance().getSessionContext();

        // Count Logged in users
        int nCountSelectedLoggedInUsers = 0;

        int nCountActivatedUsers = 0;
        int nCountDeactivatedUsers = 0;
        int nCountLockedUsers = 0;
        int nCountExternalUsers = 0;

        // Is self selected ?
        boolean bSelfSelected = false;

        // Is Predefined Account (for e.g. Administrator) selected ?
        boolean bPreDefinedAccountSelected = false;

        // Flag to decide whether the selected user is the 'Administrator' user
        boolean bAdminUserSelected = false;

        for (int nSelectedRowIndex = 0; nSelectedRowIndex < nSelectedRowCount; nSelectedRowIndex++) {
            int nSelectedUserIndex = arrSelectedRow[nSelectedRowIndex];

            UAUser objUser = (UAUser) objTableOfUsers.getValueAt(nSelectedUserIndex, -1);

            if (objUser.getCurrentLoginStatus()) {
                nCountSelectedLoggedInUsers++;
            }

            if (objUser.isPredefinedAccount()) {
                bPreDefinedAccountSelected = true;
            }

            if (0 == objSelfSessionContext.getUserName().compareToIgnoreCase(objUser.getUserId())) {
                bSelfSelected = true;
            }

            if (objUser.isAccountActivated()) {
                nCountActivatedUsers++;
            } else {
                nCountDeactivatedUsers++;
            }

            if (objUser.isAccountLocked()) {
                nCountLockedUsers++;
            }

            if (objUser.isAdminUser()) {
                bAdminUserSelected = true;
            }
            
            if (!objUser.getAuthenticationType().equals(UAAuthenticationType.LOCAL)) {
            	nCountExternalUsers++;
            }
        }

        List<USMButtonTypeEnum> enabledButtons = new ArrayList<>();
        List<USMButtonTypeEnum> disabledButtons = new ArrayList<>();

        if (1 == nSelectedRowCount) {
            enabledButtons.add(USMButtonTypeEnum.BTN_TYPE_MODIFY);
        } else {
            disabledButtons.add(USMButtonTypeEnum.BTN_TYPE_MODIFY);
        }
        //    Nothing Selected                  Everything Selected                         Murder                        Predefined Account
        if ((nSelectedRowCount == 0) || (nSelectedRowCount == nTotalRowCount) || (nCountSelectedLoggedInUsers > 0) || (bPreDefinedAccountSelected) || (bAdminUserSelected)) {
            disabledButtons.add(USMButtonTypeEnum.BTN_TYPE_DELETE);
        } else {
            enabledButtons.add(USMButtonTypeEnum.BTN_TYPE_DELETE);
        }

        if ((nCountSelectedLoggedInUsers > 0) && (!bSelfSelected)) { // Suicide strongly discouraged
            enabledButtons.add(USMButtonTypeEnum.BTN_TYPE_FORCE_LOGOFF);
        } else {
            disabledButtons.add(USMButtonTypeEnum.BTN_TYPE_FORCE_LOGOFF);
        }

        if (nCountActivatedUsers > 0 && !bAdminUserSelected && nCountExternalUsers == 0) { // Also the 'Administrator' should not be deactivated - CF003463-01 and external user (LDA,SSO,RADIUS)
            enabledButtons.add(USMButtonTypeEnum.BTN_TYPE_DEACTIVATE);
        } else {
            disabledButtons.add(USMButtonTypeEnum.BTN_TYPE_DEACTIVATE);
        }

        if (nCountDeactivatedUsers > 0) {
            enabledButtons.add(USMButtonTypeEnum.BTN_TYPE_ACTIVATE);
        } else {
            disabledButtons.add(USMButtonTypeEnum.BTN_TYPE_ACTIVATE);
        }

        if (nCountLockedUsers > 0) {
            enabledButtons.add(USMButtonTypeEnum.BTN_TYPE_UNLOCK);
        } else {
            disabledButtons.add(USMButtonTypeEnum.BTN_TYPE_UNLOCK);
        }

        enableSelectiveButtons(enabledButtons);
        disableSelectiveButtons(disabledButtons);

        // Call the base class for disabling buttons now for authorization. This will only disable the buttons based on authorization, nothing else
        performPermissionCheckForButtons();
    }

    /**
     * All the controls of the User Administration Window are created and initialized in this method.
     */
    private void initComponents() {
        JfxFormPanel contentPanel = getPanelForPlacingDerviedControls();

        objUserTableModel = new UAUserAdministrationModel();
        objUserTableModel.setETimeDisplay(getTimeDisplay());

        objTableOfUsers = new UAUserAdministrationTable(objUserTableModel);
        objTableOfUsers.setParentView(this);

        USMMouseAdapter adap = new USMMouseAdapter(this, USMButtonTypeEnum.BTN_TYPE_MODIFY);
        objTableOfUsers.addMouseListener(adap);

        objTableOfUsers.setSortable(true);
        objTableOfUsers.setFilterable(true);
        objTableOfUsers.setHeaderToolTipsEnabled(true);
        objTableOfUsers.setDefaultToolTipBehaviour(true);
        objTableOfUsers.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

        // Miscellaneous settings
        TableColumnModel columnModel = objTableOfUsers.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(96);
        columnModel.getColumn(1).setPreferredWidth(128);
        columnModel.getColumn(2).setPreferredWidth(96);
        columnModel.getColumn(3).setPreferredWidth(128);
        columnModel.getColumn(4).setPreferredWidth(96);
        columnModel.getColumn(5).setPreferredWidth(96);
        columnModel.getColumn(6).setPreferredWidth(96);

        objUserTableModel.addTableModelListener(this);
        objTableOfUsers.getSelectionModel().addListSelectionListener(this);

        // Layout
        contentPanel.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.weightx = 1.0;
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.BOTH;
        c.weighty = 1.0;
        JScrollPane scrPane = new JScrollPane(objTableOfUsers);
        contentPanel.add(scrPane, c);

        scrPane.setPreferredSize(new Dimension(500, 300));
        setPreferredSize(new Dimension(600, 420));

        // Allow horizontal scrollbar
        objTableOfUsers.setAutoResizeMode(JfxTable.AUTO_RESIZE_OFF);
    }

    /**
     * Overridden method to return the component to be embedded in the view
     *
     * @return the view itself
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getComponent()
     */
    @Override
    public JComponent getComponent() {
        return this;
    }

    /**
     * Update the table with the given list of users. Forwards to the table model.
     *
     * @param lstUsers list of UAUser
     */
    public void updateUsers(List<UAUser> lstUsers) {
        objUserTableModel.updateData(lstUsers);
    }

    /**
     * Handler for the table selection change notifications. Enables/Disables controls appropriately.
     *
     * @see javax.swing.event.TableModelListener#tableChanged(javax.swing.event.TableModelEvent)
     */
    @Override
    public void tableChanged(TableModelEvent arg0) {
        LOGGER.debug("tableChanged()  Entry");
        enableDisableControls();
        LOGGER.debug("tableChanged()  Exit");
    }

    /**
     * Forwards the Users Activated notification to the model
     *
     * @param lstActivatedUsers list of user ids
     */
    public void handleActivatedUsers(List<String> lstActivatedUsers) {
        objUserTableModel.handleActivatedUsers(lstActivatedUsers);
    }

    /**
     * Forwards the Users deactivated notification to the model
     *
     * @param lstDeactivatedUsers list of user ids
     */
    public void handleDeactivatedUsers(List<String> lstDeactivatedUsers) {
        objUserTableModel.handleDeactivatedUsers(lstDeactivatedUsers);
    }

    /**
     * Function to display a message box to the operator and ask for the confirmation of the specified operation
     *
     * @param lstSelectedUsers Users selected in the window
     * @param strOperationType Operation to be performed in the window
     * @return boolean Indicates whether the operator wants to continue and remove the users. True indicates user's
     * agreement about removal.
     */
    private boolean confirmUserActivity(List<String> lstSelectedUsers, String strOperationType) {
        boolean bOp;

        String strMessageFragment = null;
        String strCaption = null;

        switch (strOperationType) {
            case ACTIVATE:
                strMessageFragment = JfxStringTable.getString(USMStringTable.IDS_UA_ACTIVATE_MESSAGE);
                strCaption = JfxStringTable.getString(USMStringTable.IDS_UA_ACTIVATE_USER_TITLE);

                break;
            case SINGLE_ACTIVATE:
                strMessageFragment = JfxStringTable.getString(USMStringTable.IDS_UA_SINGLE_ACTIVATE_MESSAGE) + "'" + lstSelectedUsers.get(0) + "'?";
                strCaption = JfxStringTable.getString(USMStringTable.IDS_UA_DEACTIVATE_USER_TITLE);

                break;
            case DEACTIVATE:
                strMessageFragment = JfxStringTable.getString(USMStringTable.IDS_UA_DEACTIVATE_MESSAGE);
                strCaption = JfxStringTable.getString(USMStringTable.IDS_UA_DEACTIVATE_USER_TITLE);

                break;
            case SINGLE_DEACTIVATE:
                strMessageFragment = JfxStringTable.getString(USMStringTable.IDS_UA_SINGLE_DEACTIVATE_MESSAGE) + "'" + lstSelectedUsers.get(0) + "'?";
                strCaption = JfxStringTable.getString(USMStringTable.IDS_UA_DEACTIVATE_USER_TITLE);

                break;
            case DELETE:
                strMessageFragment = JfxStringTable.getString(USMStringTable.IDS_UA_DELETE_MESSAGE);
                strCaption = JfxStringTable.getString(USMStringTable.IDS_UA_DELETE_USER_TITLE);

                break;
            case SINGLE_DELETE:
                strMessageFragment = JfxStringTable.getString(USMStringTable.IDS_UA_DELETE_SINGLE_MESSAGE) + "'" + lstSelectedUsers.get(0) + "'?";
                strCaption = JfxStringTable.getString(USMStringTable.IDS_UA_DELETE_USER_TITLE);

                break;
            case UNLOCK:
                strMessageFragment = JfxStringTable.getString(USMStringTable.IDS_UA_UNLOCK_MESSAGE);
                strCaption = JfxStringTable.getString(USMStringTable.IDS_UA_UNLOCK_USER_TITLE);

                break;
            case SINGLE_UNLOCK:
                strMessageFragment = JfxStringTable.getString(USMStringTable.IDS_UA_SINGLE_UNLOCK_MESSAGE) + "'" + lstSelectedUsers.get(0) + "'?";
                strCaption = JfxStringTable.getString(USMStringTable.IDS_UA_UNLOCK_USER_TITLE);

                break;
            case FORCELOGOFF:
                strMessageFragment = JfxStringTable.getString(USMStringTable.IDS_UA_FORCE_LOGOFF_MESSAGE);
                strCaption = JfxStringTable.getString(USMStringTable.IDS_UA_FORCE_LOGOFF_USER_TITLE);

                break;
            case SINGLE_FORCE_LOGOFF:
                strMessageFragment = JfxStringTable.getString(USMStringTable.IDS_UA_SINGLE_FORCE_LOGOFF_MESSAGE) + "'" + lstSelectedUsers.get(0) + "'?";
                strCaption = JfxStringTable.getString(USMStringTable.IDS_UA_FORCE_LOGOFF_USER_TITLE);

                break;
            default:
                break;
        }
        String strMessage;
        if (1 == lstSelectedUsers.size()) {
            strMessage = strMessageFragment;
        } else {
            strMessage = strMessageFragment + lstSelectedUsers.size() + JfxStringTable.getString(USMStringTable.IDS_UA_USERS);
        }

        int nRetVal = JfxOptionPane.showMessageBox(this, new JfxText(strCaption), new JfxText(strMessage), null, JfxOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, JfxOptionPane.NO_OPTION);
        bOp = (JfxOptionPane.YES_OPTION == nRetVal);

        return bOp;
    }

    /**
     * Handle the Delete users notification
     *
     * @param lstDeletedUsers List of deleted users
     */
    public void handleDeletedUsers(List<String> lstDeletedUsers) {
        objTableOfUsers.clearSelection();
        objUserTableModel.handleDeletedUsers(lstDeletedUsers);
        enableDisableControls();
    }

    /**
     * Handle the Create users notification
     *
     * @param objUser the newly created user
     */
    public void handleCreatedUsers(UAUser objUser) {
        objUserTableModel.handleCreatedUsers(objUser);
    }

    /**
     * Handle the user logged in notification
     *
     * @param objSessionContext Session context of logged in user
     */
    public void handleUserLoggedIn(IEnhancedSessionContext objSessionContext, String strLastLogonTime) {
        objUserTableModel.handleUserLoggedIn(objSessionContext, strLastLogonTime);
    }

    /**
     * Handle the user logged out notification
     *
     * @param objSessionContext Session context of logged out user
     */
    public void handleUserLoggedOut(IEnhancedSessionContext objSessionContext) {
        objUserTableModel.handleUserLoggedOut(objSessionContext);
    }

    /**
     * Handle the user login failure out notification
     *
     * @param strUserId User Id of logged out user
     */
    public void handleUserLoginFailure(String strUserId, int nBadPasswordCount, boolean bAccountLocked) {
        objUserTableModel.handleUserLoginFailure(strUserId, nBadPasswordCount, bAccountLocked);
    }

    /**
     * Handle the user unlocked notification
     *
     * @param lstUnlockedUsers List of unlocked users
     */
    public void handleUnlockedUsers(List<String> lstUnlockedUsers) {
        objUserTableModel.handleUnlockedUsers(lstUnlockedUsers);
    }

    /**
     * Handle the user modified notification
     *
     * @param objUser the modified user
     */
    public void handleModifiedUsers(UAUser objUser) {
        objUserTableModel.handleModifiedUsers(objUser);
    }

    /**
     * Function to return the Icon that is associated with this View.
     *
     * @return Icon The Icon that should be used
     */
    @Override
    public Icon getIcon() {
        return ResourcesIconFactory.ICON_WINDOW_USER_16;
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#eventClosing()
     */
    @Override
    public void eventClosing() {
        // Save table's properties
        saveProperties(objTableOfUsers, 0, PROFILE_NAME);

        // Register Listeners here
        // Listener for change in Configured TimeZone for Display
        BiCNetPluginSite pluginSite = USMUtility.getInstance().getSecuritySite();
        pluginSite.removeClientPropertyListener(this);

        super.eventClosing();
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#eventOpened()
     */
    @Override
    public void eventOpened() {
        super.eventOpened();
        // Register Listeners here
        // Listener for change in Configured TimeZone for Display
        BiCNetPluginSite pluginSite = USMUtility.getInstance().getSecuritySite();
        pluginSite.addClientPropertyListener(this);

        // Load table's properties
        loadProperties(objTableOfUsers, 0, PROFILE_NAME);
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientPropertyListener#eventPluginClientPropertiesChanged()
     */
    @Override
    public void eventPluginClientPropertiesChanged() {
        objUserTableModel.setETimeDisplay(getTimeDisplay());

        objTableOfUsers.updateColumnTitles();
        SwingUtilities.invokeLater(() -> objTableOfUsers.repaint());
    }

    /**
     *
     * @return the String with the time display format
     */
    private String getTimeDisplay() {
        BiCNetPluginSite pluginSite = USMUtility.getInstance().getSecuritySite();
        return pluginSite.getClientProperty(BiCNetPluginClientProperties.TIME_DISPLAY, BiCNetPluginClientProperties.TIME_DISPLAY_CST);
    }

    /**
     * This displays the error message
     *
     * @param errId the error id
     */
    public void showErrorMessage(String errId) {
        bringToFront();
        JfxOptionPane.showMessageBox(this, errId, JOptionPane.CLOSED_OPTION, JOptionPane.ERROR_MESSAGE);
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#setFrame(com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame)
     */
    @Override
    public void setFrame(BiCNetPluginFrame frame) {
        super.setFrame(frame);

        objTableOfUsers.setDialogApp(new FrameworkDialogApp(getFrame()));
    }

    @Override
    public boolean isDockable() {
        return true;
    }
}