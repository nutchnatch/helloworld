/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCAccessRightsController
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID	    :   TNMS.DX2.SM.MAPPING.VIEW
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain.accessrights;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMBaseController;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.domain.job.DCGetAllMappingsJob;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessageType;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * The client interactor class for access rights operation and also to listen to notifications informing about the
 * creation/modification of the access rights.
 */
public class DCAccessRightsProxy extends USMBaseController {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(DCAccessRightsProxy.class);

    /**
     * Constructor
     *
     * @param pView - This is the associated view for access rights
     */
    public DCAccessRightsProxy(DCAccessRightsView pView) {
        super(pView);
        registerInterestedNotificationIds(getInterestedNotifications());
    }

    /**
     * Function to return a Vector which contains the list of types that this controller is interested in.
     *
     * @return List - The List which contains the notification the controller is interested in.
     */
    private List getInterestedNotifications() {
        LOGGER.debug("getInterestedNotifications() Entry");
        // Fault 108
        List vec = new ArrayList();
        vec.add(DCMessageType.DC_NOT_DOMAIN_DELETED);
        vec.add(DCMessageType.DC_NOT_MAPPINGS_MODIFIED);
        LOGGER.debug("getInterestedNotifications() Exit");
        return vec;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIntf#resultAvailable(com.ossnms.bicnet
     * .securitymanagement.client.basic.controller.jobs.USMJob, java.lang.Object)
     */
    @Override
    public void resultAvailable(USMJob pJob, USMMessage result) {
        LOGGER.debug("resultAvailable() - Enter");
        USMBaseMsgType msgType = result.getMessageType();
        if (msgType.equals(DCMessageType.DC_RES_ACCESS_RIGHTS)) {
            handleResponseGetAllMappings(result);
        } else {
            LOGGER.error("Got a message which could not be handled");
        }
        LOGGER.debug("resultAvailable() - Exit");
    }

    /**
     * This method handles the response of the primitive "DC_Res_AccessRights". All the mappings are retrieved in the
     * message. This is passed to the window to display the accesss rights.
     *
     * @param p_msg The message contains the error id, the list of domain mappings(DCDomainMapping) and the list of
     *              associated domain data(DCDomainData) and the list of PAPolicyNameAndID.
     */
    private void handleResponseGetAllMappings(USMMessage p_msg) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleAccessRightsResponse(" + p_msg + ")		Enter");
        }
        Integer errId = p_msg.popInteger();
        if (errId.equals(DCMessages.DC_NO_ERROR)) {

            List mappings = new ArrayList();
            DCDomainMapping.popMappingsFromMessage(p_msg, mappings);

            List domains = new ArrayList();
            DCDomainData.popDomainsFromMessage(p_msg, domains);
            ArrayList policies = new ArrayList();
            int nPol = p_msg.popInteger().intValue();
            for (int nDx = 0; nDx < nPol; ++nDx) {
                PAPolicyId policy = new PAPolicyId();
                policy.popMe(p_msg);
                policies.add(policy);
            }
            ((DCAccessRightsView) associatedView).initWindow(mappings, domains, policies);
            LOGGER.debug("DC" + "DCAccessRightsCientInteractor - For showing the Access rights window with the above details");

        } else {
            // Fault 108
            ((DCAccessRightsView) associatedView).showMessage(DCMessages.getInstance().getString(errId));
            LOGGER.debug("DCAccessRightsInteractor" + "handleAccessRightsResponse()" + "Error in getting access rights ");
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleAccessRightsResponse(" + p_msg + ")		Exit");
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIntf#handleNotification(com.ossnms
     * .bicnet.securitymanagement.common.basic.USMMessage)
     */
    @Override
    public void handleNotification(USMMessage pMsg) {
        LOGGER.debug("handleNotification() - Enter");
        if (null != associatedView) {
            USMBaseMsgType messageType = pMsg.getMessageType();

            if (messageType.equals(DCMessageType.DC_NOT_DOMAIN_DELETED)) {
                handleNotifDomainDeleted(pMsg);
            } else if (messageType.equals(DCMessageType.DC_NOT_MAPPINGS_MODIFIED)) {
                handleNotifMappingsModified(pMsg);
            } else {
                LOGGER.warn("Unknown notification has been sent " + messageType);
            }

        }
        LOGGER.debug("handleNotification() - Exit");

    }

    /**
     * This method is used to handle the mappings modified notification. This method retrieves the modified mappings and
     * asks the window to update with the modified mappings.
     *
     * @param p_msg - The message contains the list of DCDomainMapping, list of DCDomainData and list of
     *              PAPolicyNameAndID associated with the DCDomainMapping.
     */
    private void handleNotifMappingsModified(USMMessage p_msg) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleMappingsModifiedNotif(" + p_msg + ")		Enter");
        }
        List deletedMappings = new ArrayList();
        List modifiedMappings = new ArrayList();
        int nMappings = p_msg.popInteger().intValue();
        for (int nDx = 0; nDx < nMappings; ++nDx) {
            DCDomainMapping domMap = new DCDomainMapping();
            domMap.popMe(p_msg);
            // Check if it is deleted policy
            if (domMap.getPolicyID() == -1) {
                deletedMappings.add(domMap);
            }
            // It is created or modified mappings
            else {
                modifiedMappings.add(domMap);
            }
        }

        // Now get the list of domains which are part of the mapping
        int nDomains = p_msg.popInteger().intValue();
        for (int nDx = 0; nDx < nDomains; ++nDx) {
            DCDomainData dom = new DCDomainData();
            dom.popMe(p_msg);
            ((DCAccessRightsView) associatedView).domainCreated(dom);
        }

        // Now get the list of policy which are part of the mapping
        int nPolicy = p_msg.popInteger().intValue();
        for (int nDx = 0; nDx < nPolicy; ++nDx) {
            PAPolicyId policy = new PAPolicyId();
            policy.popMe(p_msg);
            ((DCAccessRightsView) associatedView).policyCreated(policy);
        }

        ((DCAccessRightsView) associatedView).mappingsDeleted(deletedMappings);
        ((DCAccessRightsView) associatedView).mappingsCreated(modifiedMappings);
        LOGGER.info("DC" + "DCAccessRightsCientInteractor - For popping the information and displaying deleted mappings = " + deletedMappings.size() + " and created mappings = " + modifiedMappings.size()
                + " and domains = " + nDomains + " and policies = " + nPolicy);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleMappingsModifiedNotif(" + p_msg + ")		Exit");
        }

    }

    /**
     * When a domain is deleted, all mappings associated with the domain have to be deleted. This method handles this
     * operation.
     *
     * @param pMsg - The message contains the information of the deleted domains
     */
    private void handleNotifDomainDeleted(USMMessage pMsg) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleDomainDeletedNotif(" + pMsg + ")		Enter");
        }
        DCDomainData dom = new DCDomainData();
        dom.popMe(pMsg);
        // All the mappings of the window relevant to the delted domain should
        // be deleted
        ((DCAccessRightsView) associatedView).domainDeleted(dom);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleDomainDeletedNotif(" + pMsg + ")		Exit");
        }
    }

    /**
     * This method sends a request to server to fetch the mapping between user groups, domain data and policy data.
     */
    public boolean getAllMappings() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getAllMappings()		Enter");
        }
        DCGetAllMappingsJob objJob = new DCGetAllMappingsJob(DCMessageType.DC_REQ_ACCESS_RIGHTS, this);
        boolean bStatus = queueJob(objJob);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getAllMappings()		Exit");
        }
        return bStatus;

    }
}
