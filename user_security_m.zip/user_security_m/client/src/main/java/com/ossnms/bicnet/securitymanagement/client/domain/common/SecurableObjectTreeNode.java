package com.ossnms.bicnet.securitymanagement.client.domain.common;

import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableBase;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObjectContainer;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSTransBicNetCFInfo;

import javax.swing.tree.DefaultMutableTreeNode;


public class SecurableObjectTreeNode extends DefaultMutableTreeNode implements Comparable<SecurableObjectTreeNode> {

    private static final long serialVersionUID = -5599951984932340013L;


    SecurableObjectTreeNode() {
        super();
    }

    /**
     *
     * @param userObject
     */
    SecurableObjectTreeNode(Object userObject) {
        super(userObject);
    }

    /**
     *
     * @param node
     * @return
     */
    @Override
    public int compareTo(SecurableObjectTreeNode node) {
        if (this.getUserObject() instanceof BSSecurableObjectContainer && node.getUserObject() instanceof BSSecurableObjectContainer) {
            BSSecurableObjectContainer thisContainer = (BSSecurableObjectContainer) this.getUserObject();
            BSSecurableObjectContainer otherContainer = (BSSecurableObjectContainer) node.getUserObject();
            return thisContainer.getDisplayName().compareTo(otherContainer.getDisplayName());
        }

        if (this.getUserObject() instanceof BSSecurableObject && node.getUserObject() instanceof BSSecurableObject) {
            BSSecurableObject thisObject = (BSSecurableObject) this.getUserObject();
            BSSecurableObject otherObject = (BSSecurableObject) node.getUserObject();
            return thisObject.getDisplayName().compareTo(otherObject.getDisplayName());
        }

        if (this.getUserObject() instanceof BSTransBicNetCFInfo && node.getUserObject() instanceof BSTransBicNetCFInfo) {
            BSTransBicNetCFInfo thisCf = (BSTransBicNetCFInfo) this.getUserObject();
            BSTransBicNetCFInfo otherCf = (BSTransBicNetCFInfo) node.getUserObject();
            return thisCf.getName().compareTo(otherCf.getName());
        }

        return -1;
    }

    /**
     *
     * @param securableObject
     * @return
     */
    public boolean equals(BSSecurableBase securableObject) {
        if (securableObject instanceof BSSecurableObject && this.getUserObject() instanceof BSSecurableObject) {
            BSSecurableObject thisObject = (BSSecurableObject) this.getUserObject();
            return thisObject.getDisplayName().equals(securableObject.getDisplayName());
        }
        return false;
    }




}
