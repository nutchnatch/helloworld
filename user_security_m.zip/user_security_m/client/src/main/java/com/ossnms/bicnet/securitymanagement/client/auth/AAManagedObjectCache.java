/*
 * Project      BiCNET Common Functions
 *
 * Component    CF:USM
 * Class Name   AAClientCache
 * Author       Jogender Singh
 * Substitute   Babu B
 * Created on   11-08-2004
 *
 * --------------------------------------------------------
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.CLIENT.REGSITER_MENU
 *        TNMS.DX2.SM.CLIENT.AUTHORIZE
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.auth;

import org.apache.log4j.Logger;

import java.util.BitSet;
import java.util.Collections;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.stream.Stream;

/**
 * Cache that represents the mapping of a Managed Object Key Vs ACL 
  */
public class AAManagedObjectCache {
	/**
	 * data member to hold singleton reference
	 */
	private static AAManagedObjectCache self = new AAManagedObjectCache();

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(AAManagedObjectCache.class);

	/**
	 * Map of Managed Object Keys Vs ACL
	 */
	private Map<String,BitSet> mapManagedObjectCache = Collections.synchronizedMap(new TreeMap<String,BitSet>());

	/**
	 * Function to return the singleton instance of the class
	 *
	 * @return AAManagedObjectCache -
	 *          The singleton instance of the class.
	 *
	 */
	public static synchronized AAManagedObjectCache getInstance() {
		return self;
	}

	/**
	 * Init method - initializes itself with data from server
	 */
	public void initialize() {
		mapManagedObjectCache.clear();
	}

	/**
	 * Cleanup method - clean all data
	 */
	public void cleanup() {
		LOGGER.debug("cleanup called");
		mapManagedObjectCache.clear();
	}

	/**
	 * Add managed object & ACL to map
	 * @param managedObjectKey - managed object key
	 * @param bitsetACL - ACL for the managed object
	 */
	public synchronized void addManagedobject(String managedObjectKey, BitSet bitsetACL) {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Object inserted into cache. Object Key - " + managedObjectKey + ", ACL - " + bitsetACL);

		}
		mapManagedObjectCache.put(managedObjectKey, bitsetACL);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Object inserted into cache. Cache size: " + mapManagedObjectCache.size());
		}

	}

	/**
	 * Remove managed object & ACL from map
	 * @param managedObjectKey - managed object key
	 */
	public void removeManagedobject(String managedObjectKey) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug( "Object removed from cache. Object Key - " + managedObjectKey);
		}
		mapManagedObjectCache.remove(managedObjectKey);
	}

	/**
	 * Update managed object's ACL in map
	 * @param managedObjectKey - managed object key
	 * @param bitsetACL - ACL for the managed object
	 */
	public void updateManagedobject( String managedObjectKey, BitSet bitsetACL) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Object ACL overwritten in cache. Object Key - " + managedObjectKey + ", ACL - " + bitsetACL);
		}
		mapManagedObjectCache.put(managedObjectKey, bitsetACL);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Object ACL overwritten in cache. Cache size: " + mapManagedObjectCache.size());
		}
	}

	/**
	 * Retrieve ACL for a given managed object from map
	 * @return BitSet - ACL for given managed object
	 */
	public BitSet getACL(String managedObjectKey) {
		boolean bAvail = mapManagedObjectCache.containsKey(managedObjectKey);
		if (!bAvail) {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.warn("ACL requested for object not in cache. Object Key - " + managedObjectKey);
			}
		}
		return mapManagedObjectCache.get(managedObjectKey);
	}

	/**
	 * Returns an stream for the MO-ACL pairs
	 * @return Stream - same as that returned by a Map's entryset's stream
	 */
	public Stream<Entry<String,BitSet>> stream() {
		return mapManagedObjectCache.entrySet().stream();
	}
}
