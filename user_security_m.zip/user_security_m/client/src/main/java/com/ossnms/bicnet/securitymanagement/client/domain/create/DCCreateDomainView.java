/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCCreateDomainView
 * Author      	Asif khan R
 * Substitute	muyeen
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID	:	TNMS.DX2.SM.DOMAIN.CREATE
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 18-Jan-2005	Muyeen Munaver	CF00702 - The "OK" could became Grey in the "New User" window
 * 09-02-2005	Babu B          CF000060-01   CF USM GUI Requirements
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.domain.create;

import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMHelp;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.bicnet.securitymanagement.client.domain.common.DCCreateModifyBaseView;
import com.ossnms.bicnet.securitymanagement.client.domain.common.DCCreateModifyDomainProxy;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCHelper;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessages;
import com.ossnms.tools.jfx.JfxStringTable;
import org.apache.log4j.Logger;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

/**
 * This class models the Create Domain Window.
 */
public class DCCreateDomainView extends DCCreateModifyBaseView {

    private static final long serialVersionUID = 8867769829350765434L;
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(DCCreateDomainView.class);

    /**
     * Constructor
     * 
     */
    public DCCreateDomainView() {
        super(null, getButtons(), null, "com.ossnms.bicnet.securitymanagement.client.domain.DCCreateDomainView", JfxStringTable.getString(USMStringTable.IDS_DC_TITLE_NEW_DOMAIN), true, USMHelp.HID_CREATE_DOMAIN);
        LOGGER.debug("DCCreateDomainView() - Enter");
        associatedClientController = new DCCreateModifyDomainProxy(this, null);
        ((DCCreateModifyDomainProxy) associatedClientController).getAllSecurableObjects();
        //((DCCreateModifyDomainProxy) m_AssocaitedClientController).getFirstLevelObjectsOfDomain(DCDomainData.GLOBAL_DOMAIN);
        LOGGER.debug("DCCreateDomainView() - Exit");
    }

    /**
     * Function to return the Buttons that should be added
     * 
     * @return Vector of buttons to be added to the view
     */
    private static List<USMButtonType> getButtons() {
        LOGGER.debug("getButtons() - Enter");
        List<USMButtonType> vecBtns = new ArrayList<>();
        USMButtonType ok = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_OK, null, USMStringTable.IDS_DC_TOOLTIP_CREATE_DOMAIN, true);
        vecBtns.add(ok);
        vecBtns.add(USMButtonType.BTN_TYPE_CANCEL);
        LOGGER.debug("getButtons() - Exit");
        return vecBtns;
    }

    /**
     * Function that is called by this class when the window is opened for the create and operator has pressed APPLY.
     */
    private void onCreate() {
        LOGGER.debug("onCreate() - Enter");
        String csDomainName = txtFldName.getText();
        String csDomainDescription = txtDesc.getText();

        if (null == csDomainName || !DCHelper.isValidName(csDomainName.trim())) {
            showMessage(DCMessages.getInstance().getString(DCMessages.DC_DOMAIN_NAME_INVALID));
            return;
        }

        DCDomainData domain = new DCDomainData(csDomainName, -1, -1, csDomainDescription);
        // Forward Message to Interactor to Send Create Domain Request to Server.
        getProxy().createDomain(domain, getAssignedObjects());
        LOGGER.debug("onCreate() - Exit");
    }

    @Override
    public void handleButtonClick(USMButtonTypeEnum type) {

        LOGGER.debug("handleButtonClick() - Enter");
        if ((USMButtonTypeEnum.BTN_TYPE_OK).equals(type)) {
            onCreate();

        } else {
            super.handleButtonClick(type);
        }
        LOGGER.debug("handleButtonClick() - Exit");

    }

    @Override
    protected void enableDisableControls() {
        enableAllButtons();
    }

    @Override
    public boolean isDockable() {
        return false;
    }
    
    @Override
    public Icon getIcon() {
        return ResourcesIconFactory.ICON_WINDOW_DOMAIN_16;
    }
}
