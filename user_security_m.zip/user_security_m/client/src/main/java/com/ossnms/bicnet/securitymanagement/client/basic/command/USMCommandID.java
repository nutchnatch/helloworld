/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMCommandID
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 20-Feb-2005  Asifulla Khan   CF000060-01  CF USM GUI Requirements
 * 
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.command;

import com.ossnms.bicnet.securitymanagement.common.basic.USMMenuNameList;

import java.security.InvalidParameterException;
import java.util.HashMap;
import java.util.Map;

/**
 * This class declares the User Interface component's unique command
 * Identifier.
 * 
 * There are some commands in USM which are always enabled. As such these
 * will not be authorized. For these commands the menu entry (associated for
 * authorization check) will be null. 
 */
final public class USMCommandID {
    /**
     * Represents the int equivalent for the change password
     */
    private static final int S_CHANGE_PASSWORD = 1;

    /**
     * Represents the int equivalent for the View TMN Application Server
     */
    private static final int S_VIEW_TMN_APPLICATION_SERVERS = 2;

    /**
     * Represents the int equivalent for the View Domains
     */
    private static final int S_VIEW_DOMAINS = 3;

    /**
     * Represents the int equivalent for the View Policies
     */
    private static final int S_VIEW_POLICIES = 4;

    /**
     * Represents the int equivalent for the View Access Rights
     */
    private static final int S_VIEW_ACCESS_RIGHTS = 5;

    /**
     * Represents the int equivalent for the New Domains
     */
    private static final int S_NEW_DOMAINS = 6;

    /**
     * Represents the int equivalent for the New Policies
     */
    private static final int S_NEW_POLICIES = 7;

    /**
     * Represents the int equivalent for the Create User
     */
    private static final int S_USER_MGMT_CREATE_USER = 8;

    /**
     * Represents the int equivalent for the View User
     */
    private static final int S_USER_MGMT_VIEW_USER = 9;

    /**
     * Represents the int equivalent for the Create User Group
     */
    private static final int S_USER_MGMT_CREATE_USER_GROUP = 10;

    /**
     * Represents the int equivalent for the View User Group
     */
    private static final int S_USER_MGMT_VIEW_USER_GROUP = 11;

    /**
     * Represents the int equivalent for the General Security Settings
     */
    private static final int S_GENERAL_SECURITY_SETTINGS = 12;

    /**
     * Represents the int equivalent for the Modify Domain
     */
    private static final int S_MODIFY_DOMAIN = 15;

    /**
     * Represents the int equivalent for the Modify Policy
     */
    private static final int S_MODIFY_POLICY = 16;

    /**
     * Represents the int equivalent for the Modify Policy
     */
    private static final int S_ASSIGN_MAPPINGS = 17;

    /**
     * Represents the int equivalent for the Modify User
     */
    private static final int S_MODIFY_USER = 18;

    /**
     * Represents the int equivalent for the Modify User Group
     */
    private static final int S_MODIFY_USERGROUP = 19;

    /**
     * Represents the int equivalent for the System Settings, general tab
     */
    private static final int S_SECURITY_SETTINGS_GENERAL = 20;

    /**
     * Represents the int equivalent for the System Settings, Single sign-on tab
     */
    private static final int S_SECURITY_SETTINGS_SSO = 21;

    /**
     * Represents the int equivalent for the System Settings, advisory message tab
     */
    private static final int S_SECURITY_SETTINGS_MESSAGE = 22;

    /**
     * Represents the int equivalent for the System Settings, LDAP Authentication tab
     */
    private static final int S_SECURITY_SETTINGS_LDAP_AUTH = 23;

    /**
     * Represents the int equivalent for the System Settings, Password Validation Rules tab
     */
    private static final int S_SECURITY_SETTINGS_PASSWORD_VALIDATION_RULES = 24;

    /**
     * Represents the int equivalent for the System Settings, Password Validation Rules tab
     */
    private static final int S_SECURITY_SETTINGS_RADIUS_AUTHENTICATION = 25;

    /**
     * Represents the USMCommandID for the change password
     */
    public static final USMCommandID S_UI_ID_CHANGE_PASSWORD = new USMCommandID(S_CHANGE_PASSWORD, null);
    // For all those menu's for which there should be no authorization check, we shall keep this null

    /**
     * Represents the USMCommandID for the TMN Application Server
     */
    public static final USMCommandID S_UI_ID_VIEW_TMN_APPLICATION_SERVER = new USMCommandID(S_VIEW_TMN_APPLICATION_SERVERS, USMMenuNameList.OPERATION_TMN_APP_SERVERS_ADMIN);

    /**
     * Represents the USMCommandID for the View Domains
     */
    public static final USMCommandID S_UI_ID_VIEW_DOMAINS = new USMCommandID(S_VIEW_DOMAINS, USMMenuNameList.OPERATION_DOMAIN_ADMIN);

    /**
     * Represents the USMCommandID for the View Policies
     */
    public static final USMCommandID S_UI_ID_VIEW_POLICIES = new USMCommandID(S_VIEW_POLICIES, USMMenuNameList.OPERATION_POLICY_ADMIN);

    /**
     * Represents the USMCommandID for the View Access Rights
     */
    public static final USMCommandID S_UI_ID_VIEW_ACCESS_RIGHTS = new USMCommandID(S_VIEW_ACCESS_RIGHTS, USMMenuNameList.OPERATION_ACCESS_RIGHTS);

    /**
     * Represents the USMCommandID for the New Domain
     */
    public static final USMCommandID S_UI_ID_NEW_DOMAIN = new USMCommandID(S_NEW_DOMAINS, USMMenuNameList.OPERATION_DOMAIN_NEW);

    /**
     * Represents the USMCommandID for the New Policies
     */
    public static final USMCommandID S_UI_ID_NEW_POLICIES = new USMCommandID(S_NEW_POLICIES, USMMenuNameList.OPERATION_POLICY_NEW);

    /**
     * Represents the USMCommandID for the Create User
     */
    public static final USMCommandID S_UI_ID_USER_MGMT_CREATE_USER = new USMCommandID(S_USER_MGMT_CREATE_USER, USMMenuNameList.OPERATION_USER_NEW);

    /**
     * Represents the USMCommandID for the View User
     */
    public static final USMCommandID S_UI_ID_USER_MGMT_VIEW_USER = new USMCommandID(S_USER_MGMT_VIEW_USER, USMMenuNameList.OPERATION_USERS_ADMIN);

    /**
     * Represents the USMCommandID for the Create User Group
     */
    public static final USMCommandID S_UI_ID_USER_MGMT_CREATE_USER_GROUP = new USMCommandID(S_USER_MGMT_CREATE_USER_GROUP, USMMenuNameList.OPERATION_USER_GROUP_NEW);

    /**
     * Represents the USMCommandID for the View User Group
     */
    public static final USMCommandID S_UI_ID_USER_MGMT_VIEW_USER_GROUP = new USMCommandID(S_USER_MGMT_VIEW_USER_GROUP, USMMenuNameList.OPERATION_USER_GROUP_ADMIN);

    /**
     * Represents the USMCommandID for the Modify Domain
     */
    public static final USMCommandID S_UI_ID_MODIFY_DOMAIN = new USMCommandID(S_MODIFY_DOMAIN, USMMenuNameList.OPERATION_DOMAIN_MODIFY);

    /**
     * Represents the USMCommandID for the Modify Policy
     */
    public static final USMCommandID S_UI_ID_MODIFY_POLICY = new USMCommandID(S_MODIFY_POLICY, USMMenuNameList.OPERATION_POLICY_MODIFY);

    /**
     * Represents the USMCommandID for the Assign mappings
     */
    public static final USMCommandID S_UI_ID_ASSIGN_MAPPINGS = new USMCommandID(S_ASSIGN_MAPPINGS, USMMenuNameList.OPERATION_DOMAIN_ASSIGN_MAPPINGS);

    /**
     * Represents the USMCommandID for the Modify User
     */
    public static final USMCommandID S_UI_ID_MODIFY_USER = new USMCommandID(S_MODIFY_USER, USMMenuNameList.OPERATION_USER_MODIFY);

    /**
     * Represents the USMCommandID for the Modify User Group
     */
    public static final USMCommandID S_UI_ID_MODIFY_USERGROUP = new USMCommandID(S_MODIFY_USERGROUP, USMMenuNameList.OPERATION_USER_GROUP_MODIFY);

    /**
     * Represents the USMCommandID for the General Security Settings
     */
    public static final USMCommandID S_UI_ID_GENERAL_SECURITY_SETTINGS = new USMCommandID(S_GENERAL_SECURITY_SETTINGS, USMMenuNameList.OPERATION_SECURITY_SETTINGS);

    /**
     * Represents the USMCommandID for the General Security Settings
     */
    public static final USMCommandID S_UI_ID_SECURITY_SETTINGS_GENERAL = new USMCommandID(S_SECURITY_SETTINGS_GENERAL, USMMenuNameList.OPERATION_SECURITY_SETTINGS_GENERAL);

    /**
     * Represents the USMCommandID for the General Security Settings
     */
    public static final USMCommandID S_UI_ID_SECURITY_SETTINGS_SSO = new USMCommandID(S_SECURITY_SETTINGS_SSO, USMMenuNameList.OPERATION_SECURITY_SETTINGS_SSO);

    /**
     * Represents the USMCommandID for the General Security Settings
     */
    public static final USMCommandID S_UI_ID_SECURITY_SETTINGS_MESSAGE = new USMCommandID(S_SECURITY_SETTINGS_MESSAGE, USMMenuNameList.OPERATION_SECURITY_SETTINGS_MESSAGE);


    /**
     * Represents the USMCommandID for the General Security Settings
     */
    public static final USMCommandID S_UI_ID_SECURITY_SETTINGS_LDAP_AUTH = new USMCommandID(S_SECURITY_SETTINGS_LDAP_AUTH, USMMenuNameList.OPERATION_SECURITY_SETTINGS_LDAP_AUTH);

    /**
     * Represents the USMCommandID for the General Security Settings
     */
    public static final USMCommandID S_UI_ID_SECURITY_SETTINGS_PASSWORD_VALIDATION_RULES = new USMCommandID(S_SECURITY_SETTINGS_PASSWORD_VALIDATION_RULES, USMMenuNameList.OPERATION_SECURITY_SETTINGS_PASSWORD_VALIDATION_RULES);

    /**
     * Represents the USMCommandID for the General Security Settings
     */
    public static final USMCommandID S_UI_ID_SECURITY_SETTINGS_RADIUS_AUTHENTICATION = new USMCommandID(S_SECURITY_SETTINGS_RADIUS_AUTHENTICATION, USMMenuNameList.OPERATION_SECURITY_SETTINGS_RADIUS_AUTHENTICATION);

    /**
     * This member variable represents the command ID associated with the user interface component. This uniquely
     * identifies the user interface element(s). (More than one user interface component may carry the same command ID.
     * For ex:- UI_ID_XXX may identify a radiobutton menu item and a toolbar item).
     */
    private int commandID;

    /**
     * Data member to hold the Complete Menu entry for this Command.
     * This is needed for the authorization
     */
    private String menuEntryString;

    /**
     * This is the overloaded constructor which takes a command ID as its
     * argument
     *
     * @param nCommandID -
     *            This is the interface user's command ID
     */
    private USMCommandID(final int nCommandID, String strMenuEntry) {
        // No check for Command ID as it could be null for always enabled entries.
        if (nCommandID < 0) {
            throw new InvalidParameterException();
        }

        commandID = nCommandID;
        menuEntryString = strMenuEntry;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        boolean bEqual = false;
        if ((obj != null) && (obj instanceof USMCommandID)) {
            USMCommandID uiCmdID = (USMCommandID) obj;
            bEqual = (uiCmdID.commandID == commandID) ? true : false;
        }
        return bEqual;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        return getIntValue();
    }

    /**
     * This is an overridden method of java.lang.Object class. This method
     * returns the string representation of command ID.
     *
     * @return String - Returns the string representation of the command id.
     */
    @Override
    public String toString() {
        return " id : " + commandID + ", menu : " + menuEntryString;
    }

    /**
     * Return the int equivalent of the class.
     * @return int
     * 			The integer equivalent of this command class.
     */
    public int getIntValue() {
        return commandID;
    }

    /**
     * Function to retrieve the Menu String that is associated with this
     * Command ID.
     *
     * If this function  were to return a null. Then it means that this commandid
     * is created for the object which should be enabled always and there should be
     * no authorization check.
     *
     * @return String
     * 			The Menu String that is associated with this Command ID.
     */
    public String getMenuString() {
        return menuEntryString;
    }

    private static Map<Integer,USMCommandID> mapIdToObject = new HashMap<Integer,USMCommandID>();

    /**
     * Returns the USMCommandID instance given the integer command id value
     * @param nCommandId The command identifier.
     * @return The command id object.
     */
    public static USMCommandID getCommandID(int nCommandId) {
        return (USMCommandID) mapIdToObject.get(nCommandId);
    }

    /**
     * Return the integer id associated with this command instance
     * @return The id.
     */
    public int getIntegerId() {
        return commandID;
    }

    /**
     * Map of integer ids to USMCommandId instances
     */
    static {
        mapIdToObject.put(S_CHANGE_PASSWORD, S_UI_ID_CHANGE_PASSWORD);
        mapIdToObject.put(S_VIEW_TMN_APPLICATION_SERVERS, S_UI_ID_VIEW_TMN_APPLICATION_SERVER);
        mapIdToObject.put(S_VIEW_DOMAINS, S_UI_ID_VIEW_DOMAINS);
        mapIdToObject.put(S_VIEW_POLICIES, S_UI_ID_VIEW_POLICIES);
        mapIdToObject.put(S_VIEW_ACCESS_RIGHTS, S_UI_ID_VIEW_ACCESS_RIGHTS);
        mapIdToObject.put(S_NEW_DOMAINS, S_UI_ID_NEW_DOMAIN);
        mapIdToObject.put(S_NEW_POLICIES, S_UI_ID_NEW_POLICIES);
        mapIdToObject.put(S_USER_MGMT_CREATE_USER, S_UI_ID_USER_MGMT_CREATE_USER);
        mapIdToObject.put(S_USER_MGMT_VIEW_USER, S_UI_ID_USER_MGMT_VIEW_USER);
        mapIdToObject.put(S_USER_MGMT_CREATE_USER_GROUP, S_UI_ID_USER_MGMT_CREATE_USER_GROUP);
        mapIdToObject.put(S_USER_MGMT_VIEW_USER_GROUP, S_UI_ID_USER_MGMT_VIEW_USER_GROUP);
        mapIdToObject.put(S_GENERAL_SECURITY_SETTINGS, S_UI_ID_GENERAL_SECURITY_SETTINGS);
        mapIdToObject.put(S_MODIFY_DOMAIN, S_UI_ID_MODIFY_DOMAIN);
        mapIdToObject.put(S_MODIFY_POLICY, S_UI_ID_MODIFY_POLICY);
        mapIdToObject.put(S_ASSIGN_MAPPINGS, S_UI_ID_ASSIGN_MAPPINGS);
        mapIdToObject.put(S_MODIFY_USER, S_UI_ID_MODIFY_USER);
        mapIdToObject.put(S_MODIFY_USERGROUP, S_UI_ID_MODIFY_USERGROUP);
    }
}