package com.ossnms.bicnet.securitymanagement.client.basic.utils;

import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.tools.jfx.JfxText;

import java.util.EnumMap;

/**
 * Possible logoff reasons and their associated behaviour.
 * This enum should be aligned with com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider.LogoffReason.
 * @see IPluginSecurityProvider.LogoffReason
 */
public enum LogoffReason {

    NORMAL_LOGOFF           (null,                                                      true,   false,  IPluginSecurityProvider.LogoffReason.NORMAL_LOGOFF),
    INACTIVITY_TIMEOUT      (USMStringTable.IDS_AA_DIALOG_MESSAGE_INACTIVITY_TIMEOUT,   true,   false,  IPluginSecurityProvider.LogoffReason.INACTIVITY_TIMEOUT),
    ADMIN_FORCED_LOGOFF     (USMStringTable.IDS_AA_FORCED_LOGOFF_MESSAGE,               true,   false,  IPluginSecurityProvider.LogoffReason.ADMIN_FORCED_LOGOFF),
    SERVER_SHUTDOWN         (USMStringTable.IDS_AA_SERVER_SHUTDOWN,                     false,  true,   IPluginSecurityProvider.LogoffReason.SERVER_SHUTDOWN),
    JMS_CONNECTION_LOST     (USMStringTable.IDS_AA_JMS_CONNECTION_LOST,                 false,  true,   IPluginSecurityProvider.LogoffReason.JMS_CONNECTION_LOST),
    JMS_CONNECTION_ERROR    (USMStringTable.IDS_AA_JMS_CONNECTION_ERROR,                true,   false,  IPluginSecurityProvider.LogoffReason.JMS_CONNECTION_ERROR),
    MUST_CHANGE_PASSWORD    (USMStringTable.IDS_AA_CANCEL_MUST_CHANGE_PASSWORD_DLG,     true,   false,  IPluginSecurityProvider.LogoffReason.MUST_CHANGE_PASSWORD),
    TRIAL_EXPIRED           (USMStringTable.IDS_AA_FORCED_LOGOFF_TRIAL_EXPIRED_MESSAGE, true,   false,  IPluginSecurityProvider.LogoffReason.TRIAL_EXPIRED);

    private static volatile transient EnumMap<IPluginSecurityProvider.LogoffReason, LogoffReason> translationMap;

    private final JfxText infoMessage;
    private final boolean contactServer;
    private final boolean reLogin;
    private final IPluginSecurityProvider.LogoffReason logoffReason;

    /**
     *
     * @param infoMessage
     * @param contactServer
     * @param reLogin
     * @param logoffReason
     */
    LogoffReason(JfxText infoMessage, boolean contactServer, boolean reLogin, IPluginSecurityProvider.LogoffReason logoffReason) {
        this.infoMessage = infoMessage;
        this.contactServer = contactServer;
        this.reLogin = reLogin;
        this.logoffReason = logoffReason;
    }

    public JfxText getInfoMessage() {
        return infoMessage;
    }

    public boolean shouldContactServer() {
        return contactServer;
    }

    public boolean shouldReLogin() {
        return reLogin;
    }

    public static LogoffReason valueOf(IPluginSecurityProvider.LogoffReason reason) {
        if (translationMap == null) {
            EnumMap<IPluginSecurityProvider.LogoffReason, LogoffReason> map = new EnumMap<>(IPluginSecurityProvider.LogoffReason.class);
            for (LogoffReason value : LogoffReason.values()) {
                map.put(value.logoffReason, value);
            }
            translationMap = map;
        }
        return translationMap.get(reason);
    }
}
