package com.ossnms.bicnet.securitymanagement.client.basic.component;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

/**
 * JToolTip extention that intends to allow the tooltip to include a scrollbar in situations were the content is too big
 * for the enclosing window/pane
 */
public class JScrollableToolTip extends JToolTip implements MouseWheelListener{

    private JTextPane tipPane;
    private JScrollPane scrollpane;
    private JComponent comp;

    /**
     *
     * @param comp
     */
    public JScrollableToolTip(final JComponent comp) {
        this.comp = comp;
        // set layout
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder());
        // get the scrollpane
        scrollpane = getScrollPane();
        add(scrollpane);
        // get the text pane and add it to the scrollpane's viewport view
        tipPane = getTextPane();
        scrollpane.setViewportView(tipPane);

        if(comp != null){
            comp.addMouseWheelListener(this);
        }
    }

    @Override
    public Dimension getPreferredSize(){
        // get the window dimensions and retrieve width and height
        Window ancestor = SwingUtilities.getWindowAncestor(comp);
        int windowHeight = ancestor.getHeight();
        int windowWidth = ancestor.getWidth();
        // calculate maximum widths
        int maximumHeight   = 2 * windowHeight / 3;
        int maximumWidth    = 2 * windowWidth / 3;

        // get size of TextPane
        int tipHeight = (int) tipPane.getPreferredSize().getHeight();
        int tipWidth = (int) tipPane.getPreferredSize().getWidth();

        // calculate preffered
        int tooltipHeight = tipHeight > maximumHeight   ? maximumHeight : (int) (tipHeight * 1.05);
        int tooltipWidth = tipWidth > maximumWidth      ? maximumWidth  : (int) (tipWidth * 1.05);

        return new Dimension(tooltipWidth, tooltipHeight);
    }

    /**
     *
     * @param e
     */
    public void mouseWheelMoved(final MouseWheelEvent e) {
        scrollpane.dispatchEvent(e);
        MouseEvent e2 = new MouseEvent(comp, MouseEvent.MOUSE_MOVED, 0, 0, 0, 0, 0, false);
        comp.dispatchEvent(e2);
    }

    /**
     *
     * @param tipText
     */
    @Override
    public void setTipText(final String tipText) {
        String oldValue = this.tipPane.getText();
        tipPane.setText(tipText);
        tipPane.setCaretPosition(0);

        firePropertyChange("tiptext", oldValue, tipText);
    }

    /**
     *
     * @return
     */
    @Override
    public String getTipText() {
        return tipPane == null ? "" : tipPane.getText();
    }

    /**
     *
     * @return
     */
    @Override
    protected String paramString() {
        String tipTextString = (tipPane.getText() != null ? tipPane.getText() : "");

        return super.paramString() +
                ",tipText=" + tipTextString;
    }


    /**
     *
     * @return
     */
    private JTextPane getTextPane() {
        JTextPane textPane = new JTextPane();

        textPane.setEditable(false);
        textPane.setContentType("text/html");
        textPane.setBorder(BorderFactory.createEmptyBorder(2, 4, 2, 2));
        // follows style of parent components
        textPane.putClientProperty(JEditorPane.HONOR_DISPLAY_PROPERTIES, true);

        return textPane;
    }

    /**
     *
     * @return
     */
    private JScrollPane getScrollPane() {
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.getViewport().setBackground(Color.WHITE);
        return scrollPane;
    }
}
