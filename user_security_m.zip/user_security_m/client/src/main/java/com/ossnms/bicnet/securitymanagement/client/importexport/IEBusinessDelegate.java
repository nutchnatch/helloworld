/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	IEBusinessDelegate
 * Author      	Asifulla Khan
 * Substitute	Muyeen M
 * Created on	07-12-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : 	TNMS.DX2.SM.MIGRATION
 * 			TNMS.DX2.SM.EXPORT
 * 			TNMS.DX2.SM.IMPORT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.importexport;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginServerAccessController;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.importexport.IEMessageType;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityImportExportPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.servicelocator.USMServiceLocator;
import com.ossnms.bicnet.util.UnexpectedException;
import org.apache.log4j.Logger;

import java.security.PrivilegedActionException;
import java.util.List;

/**
 * The Business Delegate class which encapsulates the calls to the
 * Server. 
 */
public class IEBusinessDelegate {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(IEBusinessDelegate.class);

	/**
	 * This is the constructor
	 */
	public IEBusinessDelegate() {
	}

	/**
	 * This method returns the Import/Export Configuration bean object to be invoked.
	 * 
	 * @return ISecurityImportExportPrivateFacade - Import/Export COnfiguration bean object
	 */
	private ISecurityImportExportPrivateFacade getIEPrivateFacade() {

		LOGGER.debug("getIEPrivateFacade() - Enter");

		USMServiceLocator servLoc = USMServiceLocator.getInstance();
		ISecurityImportExportPrivateFacade fcd = null;
		try {
			fcd = servLoc.getSecurityImportExportPrivateFacade();
		} catch (UnexpectedException ex) {
			LOGGER.error("UnexpectedException received ", ex);
		}

		LOGGER.debug("getIEPrivateFacade() - Exit");
		return fcd;

	}

	/**
	 * Function to return the result of the Import
	 * @param securityData The Data to be imported
	 * @param p_type The Name which denotes the type of the data.
	 * @param p_overWrite Boolean indicating whether it is create or overwrite mode.
	 * @return USMMessage Message which contains the result of the import.
	 * @throws BcbSecurityException Exception that is raised by Server
	 */
	public USMMessage importSecurityData(final List securityData,final String p_type,final Boolean p_overWrite) throws BcbSecurityException {
		LOGGER.debug("importSecurityData() - Enter");

		USMMessage msgResult;
		try {
			msgResult = (USMMessage) BiCNetPluginServerAccessController.doPrivileged(this, () -> {
                ISecurityImportExportPrivateFacade bean = getIEPrivateFacade();
                if (bean != null) {
                    return bean.importSecurityData(USMUtility.getInstance().getSessionContext(), securityData, p_type, p_overWrite);
                }
                return null;
            });

		} catch (PrivilegedActionException e) {
			LOGGER.error("PrivilegedActionException in importSecurityData.", e);
			msgResult = new USMMessage(IEMessageType.IE_RES_IMPORT,USMMessage.USMMESSAGE_RESPONSE);
		}

		LOGGER.debug("importSecurityData() - Exit");
		return msgResult;

	}

	/**
	 * Function to get the data to be exported.
	 * @param typeOfData The Name which denotes the type of the data.
	 * @return USMMessage Message which contains the data that is to be exported.
	 * @throws BcbSecurityException Exception that is raised by Server
	 */
	public USMMessage exportSecurityData(final String typeOfData)
		throws BcbSecurityException {

		LOGGER.debug("exportSecurityData() - Enter");

		USMMessage msgResult = null;
		try {
			msgResult =(USMMessage) BiCNetPluginServerAccessController.doPrivileged(this, () -> {
				ISecurityImportExportPrivateFacade bean = getIEPrivateFacade();
                if (bean != null) {
                	return bean.exportSecurityData(USMUtility.getInstance().getSessionContext(),typeOfData);
				}
                return null;
			});
		} catch (PrivilegedActionException e) {
			LOGGER.error("PrivilegedActionException in exportSecurityData.", e);
		}

		LOGGER.debug("exportSecurityData() - Exit");
		return msgResult;
	}
}
