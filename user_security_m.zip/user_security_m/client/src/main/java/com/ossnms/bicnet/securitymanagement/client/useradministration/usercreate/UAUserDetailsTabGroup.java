package com.ossnms.bicnet.securitymanagement.client.useradministration.usercreate;

import com.coriant.widgets.spinner.SpinnerIntegerModel;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.client.useradministration.UADelegate;
import com.ossnms.bicnet.securitymanagement.client.useradministration.passwordvalidation.UAPasswordValidationKeyAdapter;
import com.ossnms.bicnet.securitymanagement.client.useradministration.passwordvalidation.UAPasswordValidationParams;
import com.ossnms.bicnet.securitymanagement.client.useradministration.passwordvalidation.UAPasswordValidationUtility;
import com.ossnms.bicnet.securitymanagement.common.auth.PasswordValidationRulesConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.GSConstants;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UACommonHelper;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUser;
import com.ossnms.tnms.securitymanagement.client.util.USMMessages;
import com.ossnms.tnms.securitymanagement.client.util.USMResourceBundleConstants;
import com.ossnms.tools.jfx.JfxFormPanel;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxCheckBox;
import com.ossnms.tools.jfx.components.JfxDateCalendarField;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxList;
import com.ossnms.tools.jfx.components.JfxPasswordField;
import com.ossnms.tools.jfx.components.JfxSpinner;
import com.ossnms.tools.jfx.components.JfxTextField;
import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import static com.ossnms.bicnet.securitymanagement.client.useradministration.passwordvalidation.UAPasswordValidationUtility.validateWithNoOldPassword;

public class UAUserDetailsTabGroup extends JTabbedPane {
    private static final long serialVersionUID = 5734540132885278183L;
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(UAUserDetailsTabGroup.class);
    /**
     * Data member to hold string for member of tab.
     */
    private static final String MEMBER_OF = USMStringTable.getString(USMStringTable.IDS_UA_TAB_MEMBEROF);
    /**
     * Data member which hold string for password account data.
     */
    private static final String PASSWORD_ACCOUNT_DATA = USMStringTable.getString(USMStringTable.IDS_UA_TAB_PASSWORD_AND_ACCOUNT_DATA);

    /**
     * Data member which hold string for personal data.
     */
    private static final String PERSONAL_DATA = USMStringTable.getString(USMStringTable.IDS_UA_TAB_PERSONAL_DATA);

    /**
     * Data member which hold object for personal pane .
     */
    private UAUserPersonalDetailsPane personalPane = null;
    /**
     * Data member which hold object for account pane .
     */
    private UAUserAccountDetailsPane accountDetail = null;
    /**
     * Data member which hold object for member of pane .
     */
    private UAUserDetailsMemberOfPane memberOfPane = null;

    /**
     * Data member which hold user object.
     */
    private UAUser user = null;

    private JfxTextField editUserId;

    private JfxTextField editEmployeeNumber;

    private JfxTextField editLastName;

    private JfxTextField editFirstName;

    private PasswordValidationRulesConfigurationData passwordValidationRules;


    private static final int PASSWORD_EXP_INTERVAL_MAX = GSConstants.S_INIT_PASSWORD_CHANGE_INTERVAL_MAX;
    private static final int PASSWORD_EXP_INTERVAL_MIN = GSConstants.S_INIT_PASSWORD_CHANGE_INTERVAL_MIN;

    /**
     * Initializes the view by creating / placing all required controls
     */
    private void init(UAUserGroupDataHolder mdl, UAUser user, String userId) {
        LOGGER.debug("init() Entry");

        this.user = user;
        personalPane = new UAUserPersonalDetailsPane(this.user);
        add(PERSONAL_DATA, personalPane);

        //The Administrator user can't be deactivated using the icons on the window but when the user can be deactivated using Edit User option
        accountDetail = new UAUserAccountDetailsPane(this.user, userId);
        add(PASSWORD_ACCOUNT_DATA, accountDetail);

        memberOfPane = new UAUserDetailsMemberOfPane(mdl);
        memberOfPane.initComponent();
        add(MEMBER_OF, memberOfPane);

        LOGGER.debug("init() Exit");
    }

    /**
     * Constructor
     *
     * @param mdl  contains model for create user
     * @param user user object contains user information
     */
    public UAUserDetailsTabGroup(UAUserGroupDataHolder mdl, UAUser user, String userId, PasswordValidationRulesConfigurationData passwordValidationRules) {
        super();

        LOGGER.debug("UAUserDetailsTabGroup() Entry");
        this.passwordValidationRules = passwordValidationRules;
        this.user = user;
        //The Administrator user can't be deactivated using the icons on the window but when the user can be deactivated using Edit User option
        init(mdl, this.user, userId);

        LOGGER.debug("UAUserDetailsTabGroup() Exit");
    }

    /**
     * Load the details from the user object & populate the controls
     */
    public boolean setComponentValueToUserData(boolean ignoreEmptyPassword) {
        LOGGER.debug("setComponentValueToUserData() Entry");

        boolean bop = personalPane.setComponentValueToUserData();
        if (!bop) {
            return false;
        }

        boolean bop1 = accountDetail.setComponentValueToUserData(ignoreEmptyPassword);
        boolean bop2 = memberOfPane.getAssignList();

        LOGGER.debug("setComponentValueToUserData() Exit");

        return bop && bop1 && bop2;
    }

    /**
     * Initialize the controls from the given user object
     *
     * @param user User object which holds the data
     * @return boolean
     * true if successful; false otherwise
     */
    public boolean setComponentValueFromUserData(UAUser user) {
        LOGGER.debug("setComponentValueFromUserData() Entry");

        this.user = user;
        boolean bop = personalPane.setComponentValueFromUserData(user);
        if (!bop) {
            return false;
        }

        boolean bop1 = accountDetail.setComponentValueFromUserData(user);
        boolean bop2 = memberOfPane.setComponentValueFromUserData();

        LOGGER.debug("setComponentValueFromUserData() Exit");

        return bop && bop1 && bop2;
    }

    /**
     * Setting the pwd expiration value
     *
     * @param noOfDays
     */
    public void setPwdExpirationValue(int noOfDays) {
        LOGGER.debug("setPwdExpirationValue() Entry");

        accountDetail.setPwdExpValue(noOfDays);

        LOGGER.debug("setPwdExpirationValue() Exit");
    }
    
    /**
     * Setting the inactivity timeout value
     *
     * @param noOfMin
     */
    public void setInactTimeoutValue(int noOfMin) {
        LOGGER.debug("setInactTimeoutValue() Entry");

        accountDetail.setInacTimeValue(noOfMin);

        LOGGER.debug("setInactTimeoutValue() Exit");
    }
    
    public void setAccountExpireDateValue(Date expirationDate) {
        LOGGER.debug("setAccountExpireDateValue() Entry");

        accountDetail.setAccountExpireDateValue(expirationDate);

        LOGGER.debug("setAccountExpireDateValue() Exit");
    }

    /**
     * class is responsible for showing the personal detail pane on create user window
     */
    class UAUserPersonalDetailsPane extends JPanel {
        private static final long serialVersionUID = 6001754075334780236L;
        private static final int USERNAME_MAX_BYTE_SIZE = 64;
        private static final int ICON_SIZE_PX = 16;

        private static final int ROW_FIRST_NAME = 0;
        private static final int ROW_LAST_NAME = ROW_FIRST_NAME + 1;
        private static final int ROW_COMMON_NAME = ROW_LAST_NAME + 1;
        private static final int ROW_USER_ID = ROW_COMMON_NAME + 1;
        private static final int ROW_EMAIL = ROW_USER_ID + 1;
        private static final int ROW_PHONE_NUMBER = ROW_EMAIL + 1;
        private static final int ROW_FAX_NUMBER = ROW_PHONE_NUMBER + 1;
        private static final int ROW_EMPLOYEE_NUMBER = ROW_FAX_NUMBER + 1;
        private static final int ROW_BOX = ROW_EMPLOYEE_NUMBER + 1;

        // User object to hold the user data
        private UAUser user = null;

        // GUI controls
        private final JfxTextField editCommonName;
        private final JfxTextField editEMail;
        private final JfxTextField editPhoneNumber;
        private final JfxTextField editFaxNumber;
        private final JfxLabel editUserIdIcon;

        /*
         * Constructor
         */
        public UAUserPersonalDetailsPane(UAUser user) {
            super();

            LOGGER.debug("UAUserPersonalDetailsPane() Entry");

            this.setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);
            this.user = user;

            this.setLayout(new GridBagLayout());
            JfxLabel labelFirstName = new JfxLabel(USMStringTable.IDS_UA_TEXT_FIRST_NAME);
            editFirstName = new JfxTextField();
            editFirstName.setMandatoryEntry(true);
            labelFirstName.setLabelAndMnemonicFor(editFirstName);

            JfxLabel labelLastName = new JfxLabel(USMStringTable.IDS_UA_TEXT_LAST_NAME);
            editLastName = new JfxTextField();
            editLastName.setMandatoryEntry(true);
            labelLastName.setLabelAndMnemonicFor(editLastName);

            JfxLabel labelCommonName = new JfxLabel(USMStringTable.IDS_UA_TEXT_COMMON_NAME);
            editCommonName = new JfxTextField();
            editCommonName.setMandatoryEntry(true);
            labelCommonName.setLabelAndMnemonicFor(editCommonName);

            JfxLabel labelUserId = new JfxLabel(USMStringTable.IDS_UA_TEXT_USERID);
            editUserId = new JfxTextField();
            labelUserId.setLabelAndMnemonicFor(editUserId);
//            editUserId.limitText(USERNAME_MAX_BYTE_SIZE);
            editUserId.setMandatoryEntry(true);
            editUserIdIcon = new JfxLabel();
            editUserIdIcon.setMinimumSize(new Dimension(ICON_SIZE_PX, ICON_SIZE_PX));
            editUserIdIcon.setPreferredSize(new Dimension(ICON_SIZE_PX, ICON_SIZE_PX));

            JfxLabel labelEMail = new JfxLabel(USMStringTable.IDS_UA_TEXT_EMAIL);
            editEMail = new JfxTextField();
            labelEMail.setLabelAndMnemonicFor(editEMail);

            JfxLabel labelPhoneNumber = new JfxLabel(USMStringTable.IDS_UA_TEXT_PHONENUMBER);
            editPhoneNumber = new JfxTextField();
            labelPhoneNumber.setLabelAndMnemonicFor(editPhoneNumber);

            JfxLabel labelFaxNumber = new JfxLabel(USMStringTable.IDS_UA_TEXT_FAXNUMBER);
            editFaxNumber = new JfxTextField();
            labelFaxNumber.setLabelAndMnemonicFor(editFaxNumber);

            JfxLabel labelEmployeeNumber = new JfxLabel(USMStringTable.IDS_UA_TEXT_EMPLOYEENUMBER);
            editEmployeeNumber = new JfxTextField();
            labelEmployeeNumber.setLabelAndMnemonicFor(editEmployeeNumber);

            this.add(labelFirstName, new GridBagConstraints(0, ROW_FIRST_NAME, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
            this.add(editFirstName, new GridBagConstraints(1, ROW_FIRST_NAME, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
            this.add(labelLastName, new GridBagConstraints(0, ROW_LAST_NAME, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
            this.add(editLastName, new GridBagConstraints(1, ROW_LAST_NAME, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
            this.add(labelCommonName, new GridBagConstraints(0, ROW_COMMON_NAME, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
            this.add(editCommonName, new GridBagConstraints(1, ROW_COMMON_NAME, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
            this.add(labelUserId, new GridBagConstraints(0, ROW_USER_ID, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
            this.add(editUserId, new GridBagConstraints(1, ROW_USER_ID, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
            this.add(editUserIdIcon, new GridBagConstraints(2, ROW_USER_ID, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, 0, 0), 0, 0));

            this.add(labelEMail, new GridBagConstraints(0, ROW_EMAIL, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
            this.add(editEMail, new GridBagConstraints(1, ROW_EMAIL, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
            this.add(labelPhoneNumber, new GridBagConstraints(0, ROW_PHONE_NUMBER, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
            this.add(editPhoneNumber, new GridBagConstraints(1, ROW_PHONE_NUMBER, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
            this.add(labelFaxNumber, new GridBagConstraints(0, ROW_FAX_NUMBER, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
            this.add(editFaxNumber, new GridBagConstraints(1, ROW_FAX_NUMBER, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
            this.add(labelEmployeeNumber, new GridBagConstraints(0, ROW_EMPLOYEE_NUMBER, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
            this.add(editEmployeeNumber, new GridBagConstraints(1, ROW_EMPLOYEE_NUMBER, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
            this.add(Box.createGlue(), new GridBagConstraints(0, ROW_BOX, 1, 1, 0.0, 1.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.VERTICAL, new Insets(0, 0, 0, 0), 0, 0));

            KeyListener keyHandler = new KeyAdapter() {
                @Override
                public void keyReleased(KeyEvent e) {
                    handleNameFields();
                }
            };

            editFirstName.addKeyListener(keyHandler);
            editLastName.addKeyListener(keyHandler);

            setNames();

            LOGGER.debug("UAUserPersonalDetailsPane() Entry");
        }

        /**
         * Helper function that is used to set the Names of all the editable
         * components within the Window.
         *
         * Strings in this function are not to be Internationalized.
         */
        private void setNames() {
            LOGGER.debug("setNames() Entry");

            editFirstName.setName("FirstName");
            editLastName.setName("LastName");
            editCommonName.setName("FullName");
            editUserId.setName("Username");
            editEMail.setName("Email");
            editPhoneNumber.setName("Phone");
            editFaxNumber.setName("Fax");
            editEmployeeNumber.setName("EmployeeNumber");

            LOGGER.debug("setNames() Exit");
        }

        /**
         * Load the controls from the given user object
         *
         * @param user User from which the data has to be loaded
         * @return true always
         */
        public boolean setComponentValueFromUserData(UAUser user) {
            LOGGER.debug("setComponentValueFromUserData() Entry");

            this.user = user;

            editFirstName.setText(user.getFirstName());
            editLastName.setText(user.getLastName());
            editCommonName.setText(user.getCommonName());
            editUserId.setText(user.getUserId());
            editUserId.setEditable(false);
            editEMail.setText(user.getEmail());
            editPhoneNumber.setText(user.getTelephoneNumber());
            editFaxNumber.setText(user.getFaxNumber());
            editEmployeeNumber.setText(user.getEmployeeNumber());

            LOGGER.debug("setComponentValueFromUserData() Exit");
            return true;
        }

        /*
         * Updates the model by reading the value from the controls
         */
        public boolean setComponentValueToUserData() {
            LOGGER.debug("setComponentValueToUserData() Entry");

            String firstName = editFirstName.getText().trim();
            editFirstName.setText(firstName);
            user.setFirstName(firstName);
            if (user.getFirstName().isEmpty()) {
                JfxOptionPane.showMessageBox(this, USMStringTable.IDS_UA_FIRSTNAME_MESSAGE);
                return false;
            }

            String lastName = editLastName.getText().trim();
            editLastName.setText(lastName);
            user.setLastName(lastName);
            if (user.getLastName().isEmpty()) {
                JfxOptionPane.showMessageBox(this, USMStringTable.IDS_UA_LASTNAME_MESSAGE);
                return false;
            }

            String commonName = editCommonName.getText().trim();
            editCommonName.setText(commonName);
            user.setCommonName(commonName);
            if (user.getCommonName().isEmpty()) {
                JfxOptionPane.showMessageBox(this, USMStringTable.IDS_UA_COMMONNAME_MESSAGE);
                return false;
            }

            String userId = editUserId.getText().trim();
            user.setUserId(userId);

            String eMail = editEMail.getText().trim();
            user.setEmail(eMail);
            if ((eMail != null && eMail.length() > 0) && !USMUtility.isEMailValid(eMail)) {
                JfxOptionPane.showMessageBox(this, USMStringTable.IDS_INVALID_EMAIL_MESSAGE);
                return false;
            }

            String telephone = editPhoneNumber.getText();
            user.setTelephoneNumber(telephone);
            if (!USMUtility.isTelephoneValid(telephone)) {
                JfxOptionPane.showMessageBox(this, USMStringTable.IDS_INVALID_TELEPHONE_MESSAGE);
                return false;
            }

            String faxNo = editFaxNumber.getText();
            user.setFaxNumber(faxNo);
            if (!USMUtility.isFaxValid(faxNo)) {
                JfxOptionPane.showMessageBox(this, USMStringTable.IDS_INVALID_FAX_MESSAGE);
                return false;
            }

            //No check is made since string can be anything and is not mandatory.
            String employeeNo = editEmployeeNumber.getText();
            user.setEmployeeNumber(employeeNo);

            LOGGER.debug("setComponentValueToUserData() Exit");

            return true;
        }

        private void handleNameFields() {
            String str1 = editFirstName.getText();
            String str2 = editLastName.getText();

            if (str1.length() > 0) {
                editCommonName.setText(str1 + " " + str2);
            } else {
                editCommonName.setText(str2);
            }

            String strUserId = "";
            if (str1.length() > 0) {
                strUserId += str1.charAt(0);
            }
            if (editUserId.isEditable()) {
                editUserId.setText(strUserId + str2);
            }
        }
    }

    /**
     * class is responsible for account tab on create user window
     */

    class UAUserAccountDetailsPane extends JPanel {
        private static final long serialVersionUID = 1460578293823865643L;

        private static final String NAME_SPINNER_INACTIVITY_TIMEOUT = "InactivityTimeout";
        private static final String NAME_CHECKBOX_INACTIVITY_TIMEOUT_ENABLED = "InactivityTimeoutEnabled";

        private static final String NAME_SPINNER_NUMBER_SESSIONS = "NumberUserSessions";
        private static final String NAME_CHECKBOX_SESSION_RESTRICTION_ENABLED = "SessionRestrictionEnabled";

        private static final String NAME_CALENDAR_EXPIRATION_DATE = "ExpirationDate";
        private static final String NAME_CHECKBOX_ACCOUNT_EXPIRATION_ENABLED = "AccountExpirationEnabled";

        private PasswordPanel passPanel = null;
        private UAUser uaUser;
        private String userId;

        private JfxLabel passwordExpirationRange;
        private JfxLabel passwordExpirationPeriodLabel;
        private JfxLabel inactivityTimeoutExpirationRange;
        private JfxLabel inactivityTimeoutPeriodLabel;
        private JfxCheckBox cannotChangePasswordCheckbox;
        private JfxCheckBox specificInactivityTimeoutCheckbox;
        private JfxCheckBox mustChangePasswordCheckbox;
        private JfxCheckBox passwordExpirationCheckbox;
        private JfxCheckBox accountDeactivatedCheckbox;

        private JfxCheckBox specificSimultaneousUserSessionsCheckbox;
        private JfxLabel simultaneousUserSessionsLabel;

        private JfxCheckBox specificAccountExpirationDateCheckbox;
        
        private SpinnerIntegerModel passwordExpirationSpinnerModel;
        private SpinnerIntegerModel specificInactivityTimeoutSpinnerModel;
        private SpinnerIntegerModel specificSimultaneousUserSessionsSpinnerModel;
        private JfxSpinner passwordExpirationSpinner;
        private JfxSpinner specificInactivityTimeoutSpinner;

        private JfxSpinner specificSimultaneousUserSessionsSpinner;
        
        private JfxDateCalendarField specificAccountExpirationDateCalendar;

        /**
         * class is responsible for password tab on create user window
         */
        class PasswordPanel extends JPanel {
            private static final long serialVersionUID = -4275898255723406145L;
            static final int PASSWORD_ROW = 0;
            static final int CONFIRM_PASSWORD_ROW = PASSWORD_ROW + 1;
            static final int CANNOT_CHANGE_PASSWORD_ROW = CONFIRM_PASSWORD_ROW + 1;
            static final int PASSWORD_CHANGE_PANEL_ROW = CANNOT_CHANGE_PASSWORD_ROW + 1;
            static final int ACCOUNT_DEACTIVATED_ROW = PASSWORD_CHANGE_PANEL_ROW + 1;
            static final int INACTIVITY_TIMEOUT_PANEL_ROW = ACCOUNT_DEACTIVATED_ROW + 1;
            static final int SIM_SESSIONS_PANEL_ROW = INACTIVITY_TIMEOUT_PANEL_ROW + 1;
            static final int ACCOUNT_EXPIRATION_ROW = SIM_SESSIONS_PANEL_ROW + 1;
            static final int BOX_ROW = ACCOUNT_EXPIRATION_ROW + 1;

            private final transient USMMessages usmMessages;

            private static final int ICON_SIZE = 16;

            private final JfxPasswordField editPassword;
            private final JfxPasswordField editConfirmPassword;
            private final JfxLabel editPasswordIcon;
            private final JfxLabel editConfirmPasswordIcon;

            private JPanel passwordChangePanel              = new JPanel(new GridBagLayout());
            private final JPanel passwordExpirationPanel    = new JPanel();
            
            private JPanel inactivityTimeoutPanel           = new JPanel(new GridBagLayout());
            private JPanel simultaneousUserSessionsPanel    = new JPanel(new GridBagLayout());
            private JPanel accountExpirationDatePanel       = new JPanel(new GridBagLayout());

            PasswordPanel() {
                LOGGER.debug("PasswordPanel() Entry");

                this.usmMessages = USMMessages.getInstance();

                this.setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);
                this.setLayout(new GridBagLayout());

                final JfxLabel labelPassword = new JfxLabel(USMStringTable.IDS_UA_TEXT_PASSWORD);
                editPassword = new JfxPasswordField();
                editPassword.setMandatoryEntry(true);
                labelPassword.setLabelAndMnemonicFor(editPassword);
                editPasswordIcon = new JfxLabel();
                editPasswordIcon.setMinimumSize(new Dimension(ICON_SIZE, ICON_SIZE));
                editPasswordIcon.setPreferredSize(new Dimension(ICON_SIZE, ICON_SIZE));

                final JfxLabel labelConfirmPassword = new JfxLabel(USMStringTable.IDS_UA_TEXT_CONFIRM_PASSWORD);
                editConfirmPassword = new JfxPasswordField();
                editConfirmPassword.setMandatoryEntry(true);
                labelConfirmPassword.setLabelAndMnemonicFor(editConfirmPassword);
                editConfirmPasswordIcon = new JfxLabel();
                editConfirmPasswordIcon.setMinimumSize(new Dimension(ICON_SIZE, ICON_SIZE));
                editConfirmPasswordIcon.setPreferredSize(new Dimension(ICON_SIZE, ICON_SIZE));

                if (inModifyUserView()) {
                    labelPassword.setText(USMStringTable.IDS_UA_TEXT_NEW_PASSWORD);
                    labelConfirmPassword.setText(USMStringTable.IDS_UA_TEXT_CONFIRM_NEW_PASSWORD);
                }

                passwordExpirationPanel.setLayout(new GridBagLayout());
                passwordExpirationCheckbox = new JfxCheckBox(USMStringTable.IDS_UA_INIT_PASSWORD_CHANGE_INTERVAL_LABEL);
                passwordExpirationCheckbox.setMnemonic(USMStringTable.IDS_UA_INIT_PASSWORD_CHANGE_INTERVAL_LABEL.getMnemonic());
                passwordExpirationSpinnerModel = new SpinnerIntegerModel(GSConstants.S_USER_ACCOUNT_DEACTIVATE, GSConstants.S_USER_ACCOUNT_DEACTIVATE_MIN, GSConstants.S_USER_ACCOUNT_DEACTIVATE_MAX, 1);
                passwordExpirationSpinner = new JfxSpinner(passwordExpirationSpinnerModel);
                passwordExpirationRange = new JfxLabel(this.usmMessages.getFormatedString(USMResourceBundleConstants.SECURITY_SETTINGS_RANGE, new Object[]{String.valueOf(PASSWORD_EXP_INTERVAL_MIN), String.valueOf(PASSWORD_EXP_INTERVAL_MAX)}));
                passwordExpirationPeriodLabel = new JfxLabel(USMStringTable.IDS_GS_DAYS_LABEL);
                enablePasswordExpirationFields(false);

                passwordExpirationCheckbox.addItemListener(e -> enablePasswordExpirationFields(passwordExpirationCheckbox.isSelected()));

                mustChangePasswordCheckbox = new JfxCheckBox(USMStringTable.IDS_UA_CHECKBOX_USERMUST_CHANGE_PASSWORD);
                mustChangePasswordCheckbox.setMnemonic(USMStringTable.IDS_UA_CHECKBOX_USERMUST_CHANGE_PASSWORD.getMnemonic());
                mustChangePasswordCheckbox.setSelected(true);

                cannotChangePasswordCheckbox = new JfxCheckBox(USMStringTable.IDS_UA_CHECKBOX_USERCANNOT_CHANGE_PASSWORD);
                cannotChangePasswordCheckbox.setMnemonic(USMStringTable.IDS_UA_CHECKBOX_USERCANNOT_CHANGE_PASSWORD.getMnemonic());

                // If the user can not change their password, the password expiration has no effect
                cannotChangePasswordCheckbox.addItemListener(e -> {
                    boolean cannotChangePasswordSelected = cannotChangePasswordCheckbox.isSelected();
                    boolean isPasswordExpirationEnabled = passwordExpirationCheckbox.isSelected();

                    mustChangePasswordCheckbox.setEnabled(!cannotChangePasswordSelected);
                    passwordExpirationCheckbox.setEnabled(!cannotChangePasswordSelected);
                    if (cannotChangePasswordSelected) {
                        enablePasswordExpirationFields(false);
                    } else {
                        enablePasswordExpirationFields(isPasswordExpirationEnabled);
                    }
                });
                
                specificInactivityTimeoutCheckbox = new JfxCheckBox(USMStringTable.IDS_UA_USER_SPECIFIC_TIMEOUT_LABEL);
                specificInactivityTimeoutCheckbox.setMnemonic(USMStringTable.IDS_UA_USER_SPECIFIC_TIMEOUT_LABEL.getMnemonic());
                specificInactivityTimeoutSpinnerModel = new SpinnerIntegerModel(GSConstants.S_INACTIVITY_TIMEOUT, GSConstants.S_INACTIVITY_TIMEOUT_MIN, GSConstants.S_INACTIVITY_TIMEOUT_MAX, 1);
                specificInactivityTimeoutSpinner = new JfxSpinner(specificInactivityTimeoutSpinnerModel);
                inactivityTimeoutExpirationRange = new JfxLabel(this.usmMessages.getFormatedString(USMResourceBundleConstants.SECURITY_SETTINGS_RANGE, new Object[]{String.valueOf(GSConstants.S_INACTIVITY_TIMEOUT_MIN), String.valueOf(GSConstants.S_INACTIVITY_TIMEOUT_MAX)}));
                inactivityTimeoutPeriodLabel = new JfxLabel(USMStringTable.IDS_GS_MINUTES_LABEL);
                enableInactivityTimeoutFields(false);

                specificInactivityTimeoutCheckbox.addItemListener(e -> enableInactivityTimeoutFields(specificInactivityTimeoutCheckbox.isSelected()));

                accountDeactivatedCheckbox = new JfxCheckBox(USMStringTable.IDS_UA_CHECKBOX_ACCOUNT_IS_DEACTIVATED);
                accountDeactivatedCheckbox.setMnemonic(USMStringTable.IDS_UA_CHECKBOX_ACCOUNT_IS_DEACTIVATED.getMnemonic());

                //specificSimultaneousUserSessions
                specificSimultaneousUserSessionsCheckbox = new JfxCheckBox(USMStringTable.IDS_UA_SIMULTANEOUS_USER_SESSIONS_LABEL);
                specificSimultaneousUserSessionsCheckbox.setMnemonic(USMStringTable.IDS_UA_SIMULTANEOUS_USER_SESSIONS_LABEL.getMnemonic());
                specificSimultaneousUserSessionsCheckbox.setSelected(true); //Default behaviour
                specificSimultaneousUserSessionsSpinnerModel = new SpinnerIntegerModel(GSConstants.S_SIMULTANEOUS_USER_SESSIONS, GSConstants.S_SIMULTANEOUS_USER_SESSIONS_MIN, GSConstants.S_SIMULTANEOUS_USER_SESSIONS_MAX, 1);
                specificSimultaneousUserSessionsSpinner = new JfxSpinner(specificSimultaneousUserSessionsSpinnerModel);
                simultaneousUserSessionsLabel = new JfxLabel(USMStringTable.IDS_GS_SESSIONS_LABEL);

                enableSimultaneousUserSessionsFields(specificSimultaneousUserSessionsCheckbox.isSelected());

                specificSimultaneousUserSessionsCheckbox.addItemListener(e -> enableSimultaneousUserSessionsFields(specificSimultaneousUserSessionsCheckbox.isSelected()));

                //specificAccountExpirationDateCheckbox
                specificAccountExpirationDateCheckbox = new JfxCheckBox(USMStringTable.IDS_UA_ACCOUNT_EXPIRES_DATE_LABEL);
                specificAccountExpirationDateCheckbox.setMnemonic(USMStringTable.IDS_UA_ACCOUNT_EXPIRES_DATE_LABEL.getMnemonic());
                specificAccountExpirationDateCalendar = new JfxDateCalendarField(2);
                specificAccountExpirationDateCalendar.setTimeZone(TimeZone.getDefault());
				enableAccountExpirationDateFields(false);

				specificAccountExpirationDateCheckbox.addItemListener(e -> enableAccountExpirationDateFields(specificAccountExpirationDateCheckbox.isSelected()));

                // add elements and their position on the panel
                this.add(labelPassword,                         new GridBagConstraints(0, PASSWORD_ROW, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
                this.add(editPassword, 	                        new GridBagConstraints(1, PASSWORD_ROW, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
                this.add(editPasswordIcon, 	                    new GridBagConstraints(2, PASSWORD_ROW, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, 0, 0), 0, 0));

                this.add(labelConfirmPassword,                  new GridBagConstraints(0, CONFIRM_PASSWORD_ROW, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
                this.add(editConfirmPassword,                   new GridBagConstraints(1, CONFIRM_PASSWORD_ROW, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
                this.add(editConfirmPasswordIcon,               new GridBagConstraints(2, CONFIRM_PASSWORD_ROW, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, 0, 0), 0, 0));

                this.add(cannotChangePasswordCheckbox,          new GridBagConstraints(0, CANNOT_CHANGE_PASSWORD_ROW, 4, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
                this.add(createPasswordChangePanel(),           new GridBagConstraints(0, PASSWORD_CHANGE_PANEL_ROW, 4, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, JfxUtils.FIELD_INDENTATION, 0, 0), 0, 0));
                this.add(accountDeactivatedCheckbox,            new GridBagConstraints(0, ACCOUNT_DEACTIVATED_ROW, 4, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0), 0, 0));
                this.add(createInactivityTimeoutPanel(),        new GridBagConstraints(0, INACTIVITY_TIMEOUT_PANEL_ROW, 4, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0), 0, 0));
                this.add(createSimultaneousUserSessionsPanel(), new GridBagConstraints(0, SIM_SESSIONS_PANEL_ROW, 4, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0), 0, 0));
                this.add(createAccountExpirationDatePanel(),    new GridBagConstraints(0, ACCOUNT_EXPIRATION_ROW, 4, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0), 0, 0));
                this.add(Box.createGlue(),                      new GridBagConstraints(0, BOX_ROW, 4, 1, 0.0, 1.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.VERTICAL, new Insets(0, 0, 0, 0), 0, 0));

                KeyListener passwordHandler = new UAPasswordValidationKeyAdapter(editPassword, editUserId,
                        editPasswordIcon, editConfirmPassword, editConfirmPasswordIcon, inModifyUserView(),
                        mustChangePasswordCheckbox, editEmployeeNumber, editLastName, editFirstName, passwordValidationRules);

                editPassword.addKeyListener(passwordHandler);
                editConfirmPassword.addKeyListener(passwordHandler);
                editUserId.addKeyListener(passwordHandler);

                setNames();

                LOGGER.debug("PasswordPanel() Exit");
            }

            /**
             *
             * @return
             */
            private JPanel createPasswordChangePanel() {
                passwordChangePanel.add(mustChangePasswordCheckbox, new GridBagConstraints(0, 0, 3, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0), 0, 0));

                passwordExpirationPanel.add(passwordExpirationCheckbox, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
                passwordExpirationPanel.add(passwordExpirationSpinner, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
                passwordExpirationPanel.add(passwordExpirationPeriodLabel, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, 0, 0), 0, 0));
                passwordExpirationPanel.add(passwordExpirationRange, new GridBagConstraints(3, 0, 1, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, 0, 0), 0, 0));
                passwordChangePanel.add(passwordExpirationPanel, new GridBagConstraints(0, 1, 3, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0), 0, 0));

                return passwordChangePanel;
            }

            /**
             *
             * @return
             */
            private JPanel createInactivityTimeoutPanel() {
                specificInactivityTimeoutCheckbox.setName(NAME_CHECKBOX_INACTIVITY_TIMEOUT_ENABLED);
                specificInactivityTimeoutSpinner.setName(NAME_SPINNER_INACTIVITY_TIMEOUT);

            	inactivityTimeoutPanel.add(specificInactivityTimeoutCheckbox,   new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
            	inactivityTimeoutPanel.add(specificInactivityTimeoutSpinner,    new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
            	inactivityTimeoutPanel.add(inactivityTimeoutPeriodLabel,        new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, 0, 0), 0, 0));
            	inactivityTimeoutPanel.add(inactivityTimeoutExpirationRange,    new GridBagConstraints(3, 0, 1, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, 0, 0), 0, 0));
                
            	return inactivityTimeoutPanel;
            }

            /**
             *
             * @return
             */
            private JPanel createSimultaneousUserSessionsPanel() {
            	
            	specificSimultaneousUserSessionsCheckbox.setName(NAME_CHECKBOX_SESSION_RESTRICTION_ENABLED);
            	specificSimultaneousUserSessionsSpinner.setName(NAME_SPINNER_NUMBER_SESSIONS);

            	simultaneousUserSessionsPanel.add(specificSimultaneousUserSessionsCheckbox, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE,          new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
            	simultaneousUserSessionsPanel.add(specificSimultaneousUserSessionsSpinner,  new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL,    new Insets(0, 0, 0, 0), 0, 0));
                simultaneousUserSessionsPanel.add(simultaneousUserSessionsLabel,            new GridBagConstraints(2, 0, 1, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, 0, 0), 0, 0));

            	return simultaneousUserSessionsPanel;
            }

            /**
             *
             * @return
             */
            private JPanel createAccountExpirationDatePanel() {
            	
            	specificAccountExpirationDateCheckbox.setName(NAME_CHECKBOX_ACCOUNT_EXPIRATION_ENABLED);
            	specificAccountExpirationDateCalendar.setDateFieldName(NAME_CALENDAR_EXPIRATION_DATE);

            	accountExpirationDatePanel.add(specificAccountExpirationDateCheckbox, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
            	accountExpirationDatePanel.add(specificAccountExpirationDateCalendar, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
                accountExpirationDatePanel.add(Box.createGlue(), new GridBagConstraints(2, 0, 1, 1, 1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, 0, 0), 0, 0));
                
            	return accountExpirationDatePanel;
            }

            /**
             *
             * @param enable
             */
            private void enablePasswordExpirationFields(boolean enable) {
                passwordExpirationSpinner.setEnabled(enable);
                passwordExpirationRange.setEnabled(enable);
                passwordExpirationPeriodLabel.setEnabled(enable);
            }

            /**
             *
             * @param enable
             */
            private void enableInactivityTimeoutFields(boolean enable) {
            	specificInactivityTimeoutSpinner.setEnabled(enable);
            	inactivityTimeoutExpirationRange.setEnabled(enable);
            	inactivityTimeoutPeriodLabel.setEnabled(enable);
            }

            /**
             *
             * @param enable
             */
            private void enableSimultaneousUserSessionsFields(boolean enable) {
            	specificSimultaneousUserSessionsSpinner.setEnabled(enable);
            }

            /**
             *
             * @param enable
             */
            private void enableAccountExpirationDateFields(boolean enable) {
            	specificAccountExpirationDateCalendar.setEnabled(enable);
            }

            /**
             * Helper function that is used to set the Names of all the editable
             * components within the Window.
             *
             * Strings in this function are not to be Internationalized.
             */
            private void setNames() {
                LOGGER.debug("setNames() Entry");
                if (inModifyUserView()) {
                    editPassword.setName("NewPassword");
                    editConfirmPassword.setName("ConfirmNewPassword");
                } else {
                    editPassword.setName("Password");
                    editConfirmPassword.setName("ConfirmPassword");
                }

                // from the other panel
                cannotChangePasswordCheckbox.setName("CannotChangePassword");
                mustChangePasswordCheckbox.setName("MustChangePassword");
                passwordExpirationCheckbox.setName("PasswordExpires");
                accountDeactivatedCheckbox.setName("AccountIsDeactivated");

                LOGGER.debug("setNames() Exit");
            }

            /*
             * Updates the model by reading the value from the password controls
             */
            public boolean setComponentValueToUserDataOne(boolean ignoreEmptyPassword) {
                LOGGER.debug("setComponentValueToUserDataOne() Entry");

                boolean isUserDataValid = true;
                String strPassword = String.valueOf(editPassword.getPassword());
                String strConfirmPassword = String.valueOf(editConfirmPassword.getPassword());
                String currentDate = USMUtility.getInstance().convertDateToClientTimeZone(null);
                if (ignoreEmptyPassword && strPassword.isEmpty() && strConfirmPassword.isEmpty()) {
                    return true;
                }

                if (uaUser.getUserId() != null) {
                    userId = uaUser.getUserId();
                }

                UAPasswordValidationParams params = new UAPasswordValidationParams(String.valueOf(editPassword.getPassword()),
                        editEmployeeNumber.getText(), editLastName.getText(), editFirstName.getText(), null,
                        String.valueOf(editConfirmPassword.getPassword()), userId, currentDate);

                String result = validateWithNoOldPassword(params, passwordValidationRules);

                if (!result.equals(UAPasswordValidationUtility.PasswordValidationResult.SUCCESS.getLabel())){
                    JfxOptionPane.showMessageBox(this, result);
                    isUserDataValid = false;
                } else {
                	uaUser.setPassword(String.valueOf(strPassword));
                }

                LOGGER.debug("setComponentValueToUserDataOne() Exit");

                return isUserDataValid;
            }


            /**
             * Retrieve the values from the controls & do some sanitary checks
             */
            public boolean setComponentValueToUserDataTwo() {
                LOGGER.debug("setComponentValueToUserDataTwo() Entry");

                if (passwordExpirationSpinner.isEnabled()) {
                    Integer passExpiration = (Integer) passwordExpirationSpinner.getValue();

                    if (passExpiration == null || passExpiration < GSConstants.S_USER_ACCOUNT_DEACTIVATE_MIN || passExpiration > GSConstants.S_USER_ACCOUNT_DEACTIVATE_MAX) {
                        JfxOptionPane.showMessageBox(
                                this,
                                USMStringTable.IDS_PASSWORD_CHANGE_INTERVAL_MSG.getFormatedMessage(Integer.toString(GSConstants.S_INIT_PASSWORD_CHANGE_INTERVAL_MIN),
                                        Integer.toString(GSConstants.S_INIT_PASSWORD_CHANGE_INTERVAL_MAX)));
                        return false;
                    } else {
                        uaUser.setPasswordChangeInterval(passExpiration);
                    }
                }
                
                Integer timeout = (Integer) specificInactivityTimeoutSpinner.getValue();

                if (timeout == null || timeout < GSConstants.S_INACTIVITY_TIMEOUT_MIN || timeout > GSConstants.S_INACTIVITY_TIMEOUT_MAX) {
                    JfxOptionPane.showMessageBox(
                            this,
                            USMStringTable.IDS_INACTIVITY_TIMEOUT_INTERVAL_MSG.getFormatedMessage(Integer.toString(GSConstants.S_INACTIVITY_TIMEOUT_MIN),
                                    Integer.toString(GSConstants.S_INACTIVITY_TIMEOUT_MAX)));
                    return false;
                } else {
                	uaUser.setInactivityTimeout(timeout);
                }
          
                uaUser.setAccountActivated(!accountDeactivatedCheckbox.isSelected());
                uaUser.setUserCanNotChangePasswd(cannotChangePasswordCheckbox.isSelected());
                uaUser.setUserMustChangePassword(mustChangePasswordCheckbox.isSelected());
                uaUser.setPasswordExpires(passwordExpirationCheckbox.isSelected());
                uaUser.setInactivityTimeoutEnabled(specificInactivityTimeoutCheckbox.isSelected());
                uaUser.setRestrictUserSessions(specificSimultaneousUserSessionsCheckbox.isSelected());

            	Integer simultaneousUserSessions = (Integer) specificSimultaneousUserSessionsSpinner.getValue();
            	uaUser.setSimultaneousUserSessions(simultaneousUserSessions);
                
            	uaUser.setAccountExpires(specificAccountExpirationDateCheckbox.isSelected());
            	
                if (specificAccountExpirationDateCheckbox.isSelected()) {
                	uaUser.setExpirationDate(specificAccountExpirationDateCalendar.getDate());
                }
                
                LOGGER.debug("setComponentValueToUserDataTwo() Exit");

                return true;
            }

            /**
             * Load the controls from the given user object
             *
             * @param user User from which the data has to be loaded
             * @return true always
             */
            boolean setComponentValueFromUserData(UAUser user) {
                LOGGER.debug("setComponentValueFromUserDataOne() Entry");

                passwordExpirationSpinner.setValue(user.getPasswordChangeInterval());
                specificInactivityTimeoutSpinner.setValue(user.getInactivityTimeout());
                specificSimultaneousUserSessionsSpinner.setValue(user.getSimultaneousUserSessions());
                specificAccountExpirationDateCalendar.setDate(user.getExpirationDate());
                
                accountDeactivatedCheckbox.setSelected(!user.isAccountActivated());
                mustChangePasswordCheckbox.setSelected(user.isUserMustChangePassword());
                passwordExpirationCheckbox.setSelected(user.getPasswordExpires());
                cannotChangePasswordCheckbox.setSelected(user.getUserCanNotChangePasswd());
                specificInactivityTimeoutCheckbox.setSelected(user.isInactivityTimeoutEnabled());
                specificSimultaneousUserSessionsCheckbox.setSelected(user.isRestrictUserSessions());
                specificAccountExpirationDateCheckbox.setSelected(user.isAccountExpires());
                
                if(user.isAccountExternal()){
                	editPassword.setEnabled(false);
                	editConfirmPassword.setEnabled(false);
                	passwordExpirationSpinner.setEnabled(false);
                	specificAccountExpirationDateCalendar.setEnabled(false);
                	mustChangePasswordCheckbox.setEnabled(false);
                	accountDeactivatedCheckbox.setEnabled(false);
                	passwordExpirationCheckbox.setEnabled(false);
                	cannotChangePasswordCheckbox.setEnabled(false);
                	specificAccountExpirationDateCheckbox.setEnabled(false);
                	specificAccountExpirationDateCheckbox.setSelected(false);
                }
                
                LOGGER.debug("setComponentValueFromUserDataOne() Exit");

                return true;
            }

            /**
             * Setting password expiration value
             *
             * @param noOfDays
             */
            void setPwdExpirationValue(int noOfDays) {
                LOGGER.debug("setPwdExpirationValue() Entry");

                passwordExpirationSpinner.setValue(noOfDays);
                passwordExpirationCheckbox.setSelected(true);
                uaUser.setPasswordChangeInterval(noOfDays);

                LOGGER.debug("setPwdExpirationValue() Exit");
            }
            
            /**
             * Setting inactivity timeout value
             *
             * @param noOfMin
             */
            void setInactivityTimeoutValue(int noOfMin) {
                LOGGER.debug("setInactivityTimeoutValue() Entry");

                specificInactivityTimeoutSpinner.setValue(noOfMin);
                specificInactivityTimeoutCheckbox.setSelected(false);
                uaUser.setInactivityTimeout(noOfMin);
//                uaUser.setInactivityTimeoutEnabled(false);

                LOGGER.debug("setInactivityTimeoutValue() Exit");
            }

            void setAccountExpireDateValue(Date expirationDate) {
                LOGGER.debug("setAccountExpireDateValue() Entry");

                specificAccountExpirationDateCalendar.setDate(expirationDate);
                specificAccountExpirationDateCheckbox.setSelected(false);
                
                uaUser.setExpirationDate(expirationDate);

                LOGGER.debug("setAccountExpireDateValue() Exit");
            }
        }

        /**
         * Constructor
         */
        UAUserAccountDetailsPane(UAUser user, String userId) {
            super();

            LOGGER.debug("UAUserAccountDetailsPane() Entry");

            uaUser = user;
            this.userId = userId;
            passPanel = new PasswordPanel();


            if (inModifyUserView() && userId.equalsIgnoreCase(new UADelegate().getAdminUserName())) {
                accountDeactivatedCheckbox.setEnabled(false);
                specificAccountExpirationDateCheckbox.setEnabled(false);
            }

            setLayout(new GridBagLayout());
            add(passPanel, new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0, GridBagConstraints.PAGE_START, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));

            LOGGER.debug("UAUserAccountDetailsPane() Exit");
        }

        /**
         * Initialize the controls from the given user object
         *
         * @param user User object which holds the data
         * @return boolean
         * true if successful; false otherwise
         */
        public boolean setComponentValueFromUserData(UAUser user) {
            LOGGER.debug("setComponentValueFromUserData() Entry");

            uaUser = user;
            boolean bop = passPanel.setComponentValueFromUserData(user);

            LOGGER.debug("setComponentValueFromUserData() Exit");

            return bop;
        }

        /**
         * Load the data from the controls and populate the member user object
         *
         * @param ignoreEmptyPassword User object which holds the data
         * @return boolean
         * true if successful; false otherwise
         */
        public boolean setComponentValueToUserData(boolean ignoreEmptyPassword) {
            LOGGER.debug("setComponentValueToUserData() Entry");

            boolean bop = passPanel.setComponentValueToUserDataOne(ignoreEmptyPassword);
            boolean bop1 = passPanel.setComponentValueToUserDataTwo();

            LOGGER.debug("setComponentValueToUserData() Exit");

            return bop && bop1;
        }

        /**
         * Setting password expiration value
         *
         * @param noOfDays
         */
        public void setPwdExpValue(int noOfDays) {
            LOGGER.debug("setPwdExpValue() Entry");

            passPanel.setPwdExpirationValue(noOfDays);

            LOGGER.debug("setPwdExpValue() Exit");
        }
        
        /**
         * Setting inactivity timeout value
         *
         * @param noOfMin
         */
        public void setInacTimeValue(int noOfMin) {
            LOGGER.debug("setInacTimeValue() Entry");

            passPanel.setInactivityTimeoutValue(noOfMin);

            LOGGER.debug("setInacTimeValue() Exit");
        }

        /**
         *
         * @param expirationDate
         */
        public void setAccountExpireDateValue(Date expirationDate) {
            LOGGER.debug("setAccountExpireDateValue() Entry");

            passPanel.setAccountExpireDateValue(expirationDate);

            LOGGER.debug("setAccountExpireDateValue() Exit");
        }

        /**
         *
         * @return
         */
        private boolean inModifyUserView() {
            return userId != null;
        }
    }

    /**
     * class is responsible for member of tab on create/modify user window
     */

    private class UAUserDetailsMemberOfPane extends JPanel implements ListSelectionListener, ActionListener {
        private static final long serialVersionUID = 4380088769320475740L;
        /**
         * List of assigned user groups.
         */
        private JfxList<String> lstAssignedUserGroups = null;
        /**
         * List o available user groups user groups.
         */
        private JfxList<String> lstAvailUserGroups = null;
        /**
         * data model for available user groups
         */
        private DefaultListModel<String> lstMdlAvailable = null;
        /**
         * Data model for assigned user groups.
         */
        private DefaultListModel<String> lstMdlAssigned = null;

        /**
         * Button for left transfer.
         */
        private JfxButton btnLTR = null;
        /**
         * Button for right transfer.
         */
        private JfxButton btnRTL = null;
        /**
         * Button for left group transfer.
         */
        private JfxButton btnLTRGP = null;
        /**
         * Button for right group transfer.
         */
        private JfxButton btnRTLGP = null;

        /*
         * Constructor
         */
        UAUserDetailsMemberOfPane(UAUserGroupDataHolder userGroups) {
            super();

            LOGGER.debug("UAUserDetailsMemberOfPane() Entry");

            lstMdlAvailable = userGroups.getAvailableUsersList();
            lstMdlAssigned = userGroups.getAssignedUsersList();

            LOGGER.debug("UAUserDetailsMemberOfPane() Exit");
        }

        /**
         * Helper function that is used to set the Names of all the editable
         * components within the Window.
         *
         * Strings in this function are not to be Internationalized.
         */
        private void setNames() {
            LOGGER.debug("setNames() Entry");

            lstAssignedUserGroups.setName("AvailableUserGroups:");
            lstAvailUserGroups.setName("AssignedUserGroups:");
            btnLTR.setName("Add");
            btnRTL.setName("Remove");
            btnLTRGP.setName("AddAll");
            btnRTLGP.setName("RemoveAll");

            LOGGER.debug("setNames() Exit");
        }

        /**
         * check whether any user group assigned or not.
         */
        boolean getAssignList() {
            if (!lstMdlAssigned.isEmpty()) {
                return true;
            } else {
                JfxOptionPane.showMessageBox(this, USMStringTable.IDS_UA_USERGROUP_MESSAGE);
                return false;
            }
        }

        /*
         * Initialize the panel by creating / placing the controls
         */
        void initComponent() {
            LOGGER.debug("initComponent() Entry");

            Dimension listMinDimension = new Dimension(35, 50);

            this.setLayout(new GridBagLayout());
            this.setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);

            // Set up the Title and the Scroll Pane for Available UGs
            JfxFormPanel navigationPanel = new JfxFormPanel();
            navigationPanel.setLayout(new GridBagLayout());

            btnLTR = new JfxButton(USMStringTable.IDS_BUTTON_ADD);
            btnLTR.setEnabled(false);
            btnLTRGP = new JfxButton(USMStringTable.IDS_BUTTON_ADD_ALL);
            btnLTRGP.setEnabled(false);
            btnRTL = new JfxButton(USMStringTable.IDS_BUTTON_REMOVE);
            btnRTL.setEnabled(false);
            btnRTLGP = new JfxButton(USMStringTable.IDS_BUTTON_REMOVE_ALL);
            btnRTLGP.setEnabled(false);

            lstAvailUserGroups = new JfxList<>(lstMdlAvailable);
            lstAvailUserGroups.addListSelectionListener(this);
            lstAvailUserGroups.setCellRenderer(new UAUserListCellRenderer());
            lstAvailUserGroups.setEnabled(false);

            JfxLabel availableUserGroupsLabel = new JfxLabel(USMStringTable.IDS_UA_USER_CREATE_AVAILBLE_USERGROUPS);
            availableUserGroupsLabel.setLabelAndMnemonicFor(lstAvailUserGroups);
            availableUserGroupsLabel.setAlignmentX(LEFT_ALIGNMENT);

            JScrollPane availableUserGroupsPane = new JScrollPane(lstAvailUserGroups);
            availableUserGroupsPane.setAlignmentX(LEFT_ALIGNMENT);
            availableUserGroupsPane.setMinimumSize(listMinDimension);
            availableUserGroupsPane.setPreferredSize(listMinDimension);

            lstAssignedUserGroups = new JfxList<>(lstMdlAssigned);
            lstAssignedUserGroups.addListSelectionListener(this);
            lstAssignedUserGroups.setCellRenderer(new UAUserListCellRenderer());
            lstAssignedUserGroups.setEnabled(false);

            // Set up the Title and the Scroll Pane for Available UGs
            JfxLabel captionForAssignedUGsLabel = new JfxLabel(USMStringTable.IDS_UA_USER_CREATE_ASSIGNED_USERGROUPS);
            captionForAssignedUGsLabel.setLabelAndMnemonicFor(lstAssignedUserGroups);
            captionForAssignedUGsLabel.setAlignmentX(LEFT_ALIGNMENT);

            JScrollPane assignedUserGroupsPane = new JScrollPane(lstAssignedUserGroups);
            assignedUserGroupsPane.setAlignmentX(LEFT_ALIGNMENT);
            assignedUserGroupsPane.setMinimumSize(listMinDimension);
            assignedUserGroupsPane.setPreferredSize(listMinDimension);

            navigationPanel.add(btnLTR, new GridBagConstraints(0, 0, 4, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, JfxUtils.MINIMUM_DISTANCE_BETWEEN_BUTTONS, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
            navigationPanel.add(btnLTRGP, new GridBagConstraints(0, 1, 4, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, JfxUtils.MINIMUM_DISTANCE_BETWEEN_BUTTONS, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
            navigationPanel.add(btnRTL, new GridBagConstraints(0, 2, 4, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, JfxUtils.MINIMUM_DISTANCE_BETWEEN_BUTTONS, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
            navigationPanel.add(btnRTLGP, new GridBagConstraints(0, 3, 4, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));

            this.add(availableUserGroupsLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
            this.add(captionForAssignedUGsLabel, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
            this.add(availableUserGroupsPane, new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
            this.add(navigationPanel, new GridBagConstraints(1, 1, 1, 1, 0.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.VERTICAL, new Insets(0, 0, 0, 0), 0, 0));
            this.add(assignedUserGroupsPane, new GridBagConstraints(2, 1, 1, 1, 1.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));

            toggleLocalAccountFields();
            setNames();

            LOGGER.debug("initComponent() Exit");
        }

        /**
         *
         */
        private void toggleLocalAccountFields() {
            boolean isLocal = !user.isAccountExternal();

            btnLTR.setEnabled(isLocal);
            btnRTL.setEnabled(isLocal);
            btnLTRGP.setEnabled(isLocal);
            btnRTLGP.setEnabled(isLocal);

            lstAvailUserGroups.setEnabled(isLocal);
            lstAssignedUserGroups.setEnabled(isLocal);

            if(isLocal){
                btnLTR.addActionListener    (evt -> onSingleRightTransfer());
                btnRTL.addActionListener    (evt -> onSingleLeftTransfer());
                btnLTRGP.addActionListener  (evt -> onMultiRightTransfer());
                btnRTLGP.addActionListener  (evt -> onMultiLeftTransfer());

                DefaultListModelListener dataListener = new DefaultListModelListener();
                lstMdlAssigned.addListDataListener(dataListener);
                lstMdlAvailable.addListDataListener(dataListener);
            }
        }

        /**
         * This method gets called when the left transfer button is clicked. This method transfers the
         * selected objects to the right pane.
         */
        protected void onSingleRightTransfer() {
            LOGGER.debug("onSingleRightTransfer() Entry");

            List<String> selectedList = lstAvailUserGroups.getSelectedValuesList();

            for (String aSelectedList : selectedList) {
                lstMdlAssigned.addElement(aSelectedList);
                lstMdlAvailable.removeElement(aSelectedList);
            }
            toggleShiftButtons();

            LOGGER.debug("onSingleRightTransfer() Exit");
        }

        /**
         * This method gets called when the right transfer button is clicked. This method transfers the
         * selected objects to the left pane.
         */
        protected void onSingleLeftTransfer() {
            LOGGER.debug("onSingleLeftTransfer() Entry");

            List<String> selectedList = lstAssignedUserGroups.getSelectedValuesList();
            for (String aSelectedList : selectedList) {
                lstMdlAvailable.addElement(aSelectedList);
                lstMdlAssigned.removeElement(aSelectedList);
            }
            toggleShiftButtons();

            LOGGER.debug("onSingleLeftTransfer() Exit");
        }

        /**
         * This method gets called when the left group transfer button is clicked. This method transfers the
         * all the objects to the right pane.
         */
        protected void onMultiRightTransfer() {
            LOGGER.debug("onMultiRightTransfer() Entry");

            int listLen = lstMdlAvailable.size();
            for (int index = listLen - 1; index >= 0; index--) {
                lstMdlAssigned.addElement(lstMdlAvailable.elementAt(index));
                lstMdlAvailable.removeElementAt(index);
            }
            toggleShiftButtons();

            LOGGER.debug("onMultiRightTransfer() Exit");
        }

        /**
         * This method gets called when the right group transfer button is clicked. This method transfers the
         * all the objects to the left pane.
         */
        protected void onMultiLeftTransfer() {
            LOGGER.debug("onMultiLeftTransfer() Entry");

            int listLen = lstMdlAssigned.size();
            for (int index = listLen - 1; index >= 0; index--) {
                lstMdlAvailable.addElement(lstMdlAssigned.elementAt(index));
                lstMdlAssigned.removeElementAt(index);
            }
            toggleShiftButtons();

            LOGGER.debug("onMultiLeftTransfer() Exit");
        }

        /**
         * Handler for selection changes in any of the list controls
         *
         * @param event Event describing the action on te list control
         * @see javax.swing.event.ListSelectionListener#valueChanged(javax.swing.event.ListSelectionEvent)
         */
        @Override
        public void valueChanged(ListSelectionEvent event) {
            LOGGER.debug("valueChanged() Entry");

            toggleShiftButtons();

            LOGGER.debug("valueChanged() Exit");
        }

        /**
         * Helper function that should be called when the <, >, <<, >> buttons are to be
         * enabled and disabled. Checks are made internally for the enabling and disabling.
         */
        private void toggleShiftButtons() {
            if(user.isAccountExternal()){
                return;
            }

            LOGGER.debug("toggleShiftButtons() Entry");

            btnLTR.setEnabled(false);
            btnRTL.setEnabled(false);
            btnRTLGP.setEnabled(false);
            btnLTRGP.setEnabled(false);

            if (lstAvailUserGroups.getSelectedIndices().length > 0) {
                btnLTR.setEnabled(true);
            }
            if (lstAssignedUserGroups.getSelectedIndices().length > 0) {
                btnRTL.setEnabled(true);
            }
            if (lstMdlAvailable.size() > 0) {
                btnLTRGP.setEnabled(true);
            }
            if (lstMdlAssigned.size() > 0) {
                btnRTLGP.setEnabled(true);
            }

            LOGGER.debug("toggleShiftButtons() Exit");
        }

        boolean setComponentValueFromUserData() {
            toggleLocalAccountFields();
            return true;
        }

        class DefaultListModelListener implements ListDataListener {

            /* (non-Javadoc)
             * @see javax.swing.event.ListDataListener#contentsChanged(javax.swing.event.ListDataEvent)
             */
            @Override
            public void contentsChanged(ListDataEvent e) {
                LOGGER.debug("contentsChanged() Entry");

                toggleShiftButtons();

                LOGGER.debug("contentsChanged() Exit");
            }

            /* (non-Javadoc)
             * @see javax.swing.event.ListDataListener#intervalAdded(javax.swing.event.ListDataEvent)
             */
            @Override
            public void intervalAdded(ListDataEvent e) {
                LOGGER.debug("intervalAdded() Entry");

                toggleShiftButtons();

                LOGGER.debug("intervalAdded() Exit");
            }

            /* (non-Javadoc)
             * @see javax.swing.event.ListDataListener#intervalRemoved(javax.swing.event.ListDataEvent)
             */
            @Override
            public void intervalRemoved(ListDataEvent e) {
                LOGGER.debug("intervalRemoved() Entry");

                toggleShiftButtons();

                LOGGER.debug("intervalRemoved() Exit");
            }
        }

        /* (non-Javadoc)
         * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
         */
        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            LOGGER.debug("actionPerformed() Entry");

            JfxButton btn = (JfxButton) actionEvent.getSource();

            if (btn.equals(btnLTR)) {
                onSingleRightTransfer();
            } else if (btn.equals(btnLTRGP)) {
                onMultiRightTransfer();
            } else if (btn.equals(btnRTL)) {
                onSingleLeftTransfer();
            } else if (btn.equals(btnRTLGP)) {
                onMultiLeftTransfer();
            }

            LOGGER.debug("actionPerformed() Exit");
        }
    }

    /**
     * Renderer for the list to display available and assigned users with an icon in front
     */
    class UAUserListCellRenderer extends DefaultListCellRenderer {
        private static final long serialVersionUID = -2680405736803429315L;

        /**
         * This is the only method defined by ListCellRenderer. We just reconfigure the JLabel each time we're called.
         *
         * @param list         The list which is the container for the Objects that need special display
         * @param value        Value to display
         * @param index        Cell index
         * @param isSelected   Is the cell selected
         * @param cellHasFocus Indicates whether the cell has focus.
         * @return Component The Rendered that is to be used.
         * @see javax.swing.ListCellRenderer#getListCellRendererComponent(javax.swing.JList, java.lang.Object, int, boolean, boolean)
         */
        @Override
        public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            // Set the icon here.
            setIcon(ResourcesIconFactory.ICON_STATUS_ACTIVATED_USER_16);
            return this;
        }
    }
}
