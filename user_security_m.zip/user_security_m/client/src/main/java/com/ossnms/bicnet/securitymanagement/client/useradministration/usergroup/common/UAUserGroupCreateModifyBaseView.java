package com.ossnms.bicnet.securitymanagement.client.useradministration.usergroup.common;

import java.awt.Dimension;
import java.util.List;

import javax.swing.JComponent;

import org.apache.log4j.Logger;

import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMFrameType;
import com.ossnms.tools.jfx.JfxOptionPane;

/**
 * This is a base class for the create/modify window of user group.
 */
abstract public class UAUserGroupCreateModifyBaseView extends USMBaseViewWithButtons {
    private static final long serialVersionUID = 1794571257710326432L;

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(UAUserGroupCreateModifyBaseView.class);

    protected UAUserGroupDetailsTabGroup tabGroup = null;
 
    /**
     * Constructor with detailed parameter list
     * 
     * @param vecObjs
     *            - Abstract list of objects to be to be displayed in the view
     * @param strID
     *            - A string containing the fully qualified class name
     * @param strTitle
     *            - A string containing the title
     * @param resizable
     *            - Indicates whether it is resizable or not
     * @param helpID
     *            - The ID of the Help Screen to be opened
     */
    protected UAUserGroupCreateModifyBaseView(List<USMButtonType> vecObjs, List<USMButtonType> commitButtons,
                                              List<USMButtonType> functionButtons, String strID, String strTitle,
                                              boolean resizable, int helpID) {
        
        super(vecObjs, commitButtons, functionButtons, strID, strTitle, resizable, false, helpID);
        initComponents();
    }

    /**
     * Overridden method to return the component to be embedded in the view
     * 
     * @return the view itself
     * 
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getComponent()
     */
    @Override
    public JComponent getComponent() {
        return this;
    }

    /**
     * Initializes the view by creating / placing all required controls
     */
    private void initComponents() {
        LOGGER.debug("initComponents() Enter");

        tabGroup = new UAUserGroupDetailsTabGroup();
        getPanelForPlacingDerviedControls().add(tabGroup);
 
        setPreferredSize(new Dimension(550, 450));
        LOGGER.debug("initComponents() Exit");
    }

    /**
     * Function to decide what is the Frame that should be used.
     * @return USMFrameType The Frame type that should be used.
     */
    @Override
    protected USMFrameType getFrameTypeToBeUsed() {
        // NA000146-Making window secondary
        return USMFrameType.S_INTERNAL;
    }

    /**
     * Retrieves the General tab
     * @return the General tab pane
     */
    public UAUserGroupGeneralPane getGeneralPane(){
        return tabGroup.getGeneralPane();
    }

    /**
     * Retrieves the Domains and Policies tab
     * @return the Domains and Policies tab pane
     */
    public UAUserGroupDomainsAndPoliciesPane getDomainsPoliciesPane() {
    	return tabGroup.getDomainsPoliciesPane();
    }
    

    public void closeWindow() {
		close();

	}
	
	public void showMessage(String msg) {
		bringToFront();
		JfxOptionPane.showMessageBox(this, msg);
	}
}