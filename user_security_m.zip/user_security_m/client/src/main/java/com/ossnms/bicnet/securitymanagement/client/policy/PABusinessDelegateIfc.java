package com.ossnms.bicnet.securitymanagement.client.policy;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;

import java.rmi.RemoteException;
import java.util.List;

/**
 * Created by novo on 2015-05-08.
 */
public interface PABusinessDelegateIfc {
    /**
     *
     * @return
     * @throws BcbSecurityException
     * @throws RemoteException
     */
    USMMessage getPolicies() throws BcbSecurityException, RemoteException;

    /**
     *
      * @param paPolicyDataList
     * @return
     * @throws BcbSecurityException
     * @throws RemoteException
     */
    USMMessage deletePolicies(List<PAPolicyId> paPolicyDataList) throws BcbSecurityException, RemoteException;

    /**
     *
     * @param policyData
     * @return
     * @throws BcbSecurityException
     * @throws RemoteException
     */
    USMMessage modifyPolicy(PAPolicyData policyData) throws BcbSecurityException, RemoteException;

    /**
     *
     * @param policyData
     * @return
     * @throws BcbSecurityException
     * @throws RemoteException
     */
    USMMessage createPolicy(PAPolicyData policyData) throws BcbSecurityException, RemoteException;

    /**
     *
     * @return
     * @throws BcbSecurityException
     * @throws RemoteException
     */
    USMMessage getPermissions() throws BcbSecurityException, RemoteException;

    /**
     *
     * @param policyId
     * @return
     * @throws BcbSecurityException
     * @throws RemoteException
     */
    USMMessage getPermissionsForPolicy(PAPolicyId policyId) throws BcbSecurityException, RemoteException;
}
