/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCClientLifeCycleController
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CREATE
 * 		:	TNMS.DX2.SM.DOMAIN.CONFIG	   
 * 		:	TNMS.DX2.SM.DOMAIN.VIEW
 * 		:	TNMS.DX2.SM.MAPPING.CREATE
 * 		:	TNMS.DX2.SM.MAPPING.VIEW 
 * 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain;

import org.apache.log4j.Logger;

import com.ossnms.bicnet.securitymanagement.client.basic.USMClientLifeCycleControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.domain.accessrights.DCAccessRightsCommand;
import com.ossnms.bicnet.securitymanagement.client.domain.config.DCDomainConfigCommand;
import com.ossnms.bicnet.securitymanagement.client.domain.create.DCCreateDomainCommand;
import com.ossnms.bicnet.securitymanagement.client.domain.modify.DCModifyDomainCommand;

/**
 * This is the Life Cycle Controller that is created in the Client upon start up. This class is responsible for the
 * initialization and cleanup activities to be performed by the subsystem DC. These activities are performed at the
 * start of the Admin Client process and at the closure of the Admin Client process. This class is responsible for
 * registering the Commands with the USMCommandRegister. It has to register 5 Commands - 1. DCDomainConfigCommand 2.
 * DCDomainMappingCommand 3. DCModifyDomainCommand 4. DCCreateDomainCommand 5. DCAccessRightsCommand.
 */
public final class DCClientLifeCycleController implements USMClientLifeCycleControllerIfc {
    /**
     * Data member to hold the singleton instance of the class
     */
    private static DCClientLifeCycleController instance = new DCClientLifeCycleController();

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(DCClientLifeCycleController.class);

    /**
     * Private constructor for preventing initialization of the class from outside.
     * 
     * @return String - Sub system id for Domain
     */
    private DCClientLifeCycleController() {

    }

    /**
     * Function to return the singleton instance of this class
     * 
     * @return DCClientLifeCycleController - Object of this class
     */
    public static DCClientLifeCycleController getInstance() {
        return instance;
    }

    @Override
    public boolean initialize() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("initialize() - Enter");
        }
        boolean isCommandRegistered = true;

        DCDomainConfigCommand domainConfigCommand = new DCDomainConfigCommand();
        isCommandRegistered = isCommandRegistered && domainConfigCommand.isCmdHndlrRegistered();

        DCModifyDomainCommand modifyDomainCmd = new DCModifyDomainCommand();
        isCommandRegistered = isCommandRegistered && modifyDomainCmd.isCmdHndlrRegistered();

        DCCreateDomainCommand createDomainCmd = new DCCreateDomainCommand();
        isCommandRegistered = isCommandRegistered && createDomainCmd.isCmdHndlrRegistered();

        DCAccessRightsCommand accessRightsCmd = new DCAccessRightsCommand();
        isCommandRegistered = isCommandRegistered && accessRightsCmd.isCmdHndlrRegistered();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("initialize() - Exit");
        }

        return isCommandRegistered;
    }

    @Override
    public boolean cleanup() {
        return true;
    }
}
