/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCCreateDomainCommand
 * Author      	Asif khan R
 * Substitute	Muyeen M
 * Created on	12-09-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID	:	TNMS.DX2.SM.DOMAIN.CREATE
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain.create;

import org.apache.log4j.Logger;

import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;

/**
 * The command handler which handles domain creation(Create Domain operation)
 */
public class DCCreateDomainCommand extends USMCommand {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(DCCreateDomainCommand.class);

    /**
     * Default Constructor
     */
    public DCCreateDomainCommand() {
        super(USMCommandID.S_UI_ID_NEW_DOMAIN);
        LOGGER.debug("DCCreateDomainCommand() - Enter/Exit");
    }

    @Override
    protected USMBaseView createAndReturnView() {
        LOGGER.debug("createAndReturnView() - Enter");
        DCCreateDomainView dcCreateView = new DCCreateDomainView();
        LOGGER.debug("createAndReturnView() - Exit");
        return dcCreateView;
    }

}
