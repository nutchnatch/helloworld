/*
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 */
package com.ossnms.bicnet.securitymanagement.client.policy.jobs;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.policy.PABusinessDelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.policy.PAMessageType;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import org.apache.log4j.Logger;

import java.rmi.RemoteException;

/**
 * This class represents the Job that is responsible for sending a request
 * to create a Policy
 */
public class PAJobCreatePolicy extends USMJob {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(PAJobCreatePolicy.class);

	/**
	 * Data member to hold the Policy Object that has to be created.
	 */
	private PAPolicyData policy;

	/**	
	 * Cosntructor
	 *
	 * @param jobOwner The owner of the Job
	 * @param policy The Policy that has to be created
	 */
	public PAJobCreatePolicy(USMControllerIfc jobOwner, PAPolicyData policy) {
		super(
			PAMessageType.S_PA_NOT_POLICY_CREATED,
			USMCommonStrings.EMPTY,
			USMCommonStrings.EMPTY,
			jobOwner);

		Object[] arr = { policy };
		String str = USMStringTable.IDS_PA_JOB_CREATE_POLICY.getFormatedMessage(arr);
		setName(str);

		LOGGER.debug("PAJobCreatePolicy() in the method");
		this.policy = policy;
		LOGGER.debug("PAJobCreatePolicy()in the constructor");
	}

	/*
	* (non-Javadoc)
	*
	* @see com.ossnms.bicnet.securitymanagement.client.common.controller.USMJob#executeJob()
	*/
	public USMMessage executeJob() throws BcbSecurityException {
		LOGGER.debug("executeJob()in the method");
		USMMessage msg = null;
		try {
			msg = new PABusinessDelegate().createPolicy(policy);
		} catch (RemoteException e) {
			LOGGER.error("executeJob() error in getting response");
		}
		return msg;
	}
}