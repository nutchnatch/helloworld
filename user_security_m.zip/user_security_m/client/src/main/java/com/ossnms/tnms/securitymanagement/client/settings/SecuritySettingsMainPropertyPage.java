/*
 * Copyright Coriant 2013
 * The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
 *
 */
package com.ossnms.tnms.securitymanagement.client.settings;

import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPageSite;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSettingsPropertyPage;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.tools.jfx.JfxUtils;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;


public class SecuritySettingsMainPropertyPage extends JPanel implements BiCNetPluginSettingsPropertyPage, ChangeListener {

    private static final long serialVersionUID = 1L;

    private static final int GENERAL_PANEL_POSITION = 0;
    private static final int SSO_PANEL_POSITION = GENERAL_PANEL_POSITION + 1;
    private static final int LDAP_PANEL_POSITION = SSO_PANEL_POSITION + 1;
    private static final int RADIUS_PANEL_POSITION = LDAP_PANEL_POSITION + 1;
    private static final int ADVISORY_MESSAGE_PANEL_POSITION = RADIUS_PANEL_POSITION + 1;
    private static final int PASSWORD_VALIDATION_PANEL_POSITION = ADVISORY_MESSAGE_PANEL_POSITION + 1;

    private BiCNetPluginPropertyPageSite propertyPageSite;
    
    private ISecurityPropertyPage[] childPages;

    private SecuritySettingsDocument doc;

    public SecuritySettingsMainPropertyPage() {
        doc = new SecuritySettingsDocument();
        this.childPages = new ISecurityPropertyPage[6];

        SecurityGeneralPropertyPage generalPropertyPage = new SecurityGeneralPropertyPage(doc);
        this.childPages[GENERAL_PANEL_POSITION] = generalPropertyPage;
        generalPropertyPage.addChangeListener(this);

        SecuritySSOPropertyPage ssoPropertyPage = new SecuritySSOPropertyPage(doc);
        this.childPages[SSO_PANEL_POSITION] = ssoPropertyPage;
        ssoPropertyPage.addChangeListener(this);

        SecurityLDAPAuthPropertyPage ldapAuthPropertyPage = new SecurityLDAPAuthPropertyPage(doc);
        this.childPages[LDAP_PANEL_POSITION] = ldapAuthPropertyPage;
        ldapAuthPropertyPage.addChangeListener(this);

        RadiusAuthenticationPropertyPage radiusAuthenticationPropertyPage = new RadiusAuthenticationPropertyPage(doc);
        this.childPages[RADIUS_PANEL_POSITION] = radiusAuthenticationPropertyPage;
        radiusAuthenticationPropertyPage.addChangeListener(this);

        SecurityMessagePropertyPage messagePropertyPage = new SecurityMessagePropertyPage(doc);
        this.childPages[ADVISORY_MESSAGE_PANEL_POSITION] = messagePropertyPage;
        messagePropertyPage.addChangeListener(this);

        SecurityPasswordValidationPropertyPage passwordValidationPropertyPage = new SecurityPasswordValidationPropertyPage(doc);
        this.childPages[PASSWORD_VALIDATION_PANEL_POSITION] = passwordValidationPropertyPage;
        passwordValidationPropertyPage.addChangeListener(this);

        doc.setDataChangeListener(object -> SwingUtilities.invokeLater(() -> {
            for (ISecurityPropertyPage page : childPages) {
                page.updateData(object);
            }
        }));

        initLayout();
        doc.init();
    }

    private void initLayout() {
        setLayout(new GridBagLayout());
        setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);
        add(new JLabel("See sub-pages for settings."), new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0, GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    }

    @Override
    public void setObjects(IManagedObjectMarkable[] arObjects) {
    }

    @Override
    public void update() {
    }

    @Override
    public void setReadOnly(boolean bReadOnly) {
    }

    @Override
    public boolean isPageDirty() {
        for (ISecurityPropertyPage page : childPages) {
            if (page.isPageDirty()) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void validateInput() throws BiCNetPluginException {
    }

    @Override
    public void setPageSite(BiCNetPluginPropertyPageSite site) {
        this.propertyPageSite = site;
    }

    @Override
    public String getID() {
        return USMCommandID.S_UI_ID_GENERAL_SECURITY_SETTINGS.getMenuString();
    }

    @Override
    public JComponent getComponent() {
        return this;
    }

    @Override
    public String getTitle() {
        return USMStringTable.IDS_GS_TITLE_GENERAL_SETTING_WINDOW.toString();
    }

    @Override
    public void actionApply() {
        SecuritySettingsData data = new SecuritySettingsData();
        
        for (ISecurityPropertyPage page : childPages) {
            page.saveData(data);
        }

        doc.setSecuritySettingsData(data.getData());
    }

    @Override
    public void actionCancel() {
    }

    @Override
    public void eventOpened() {
    }

    @Override
    public void eventClosing() {
    }

    @Override
    public BiCNetPluginSettingsPropertyPage[] getChildPages() {
        return childPages;
    }

    @Override
    public boolean isEnabled(IManagedObject[] mos) {
        return true;
    }

    /**
     * ***********************************************************************
     * Sets the interface of the enclosing frame provided by the application.
     * This method is called before the view is displayed. The view should
     * store the given reference for later use.
     *
     * @param frame Reference to plug-in frame.
     *              ************************************************************************
     */
    @Override
    public void setFrame(BiCNetPluginFrame frame) {

    }

    @Override
    public void stateChanged(ChangeEvent e) {
        if (propertyPageSite != null) {
            propertyPageSite.eventPageStatusChanged(this);
        }
    }
}