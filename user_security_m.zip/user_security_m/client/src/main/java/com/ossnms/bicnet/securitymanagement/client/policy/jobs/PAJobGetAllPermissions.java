package com.ossnms.bicnet.securitymanagement.client.policy.jobs;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.policy.PABusinessDelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.policy.PAMessageType;
import org.apache.log4j.Logger;

import java.rmi.RemoteException;

/**
 *
 */
public class PAJobGetAllPermissions extends USMJob {
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(PAJobGetAllPermissions.class);

    /**
     * Constructor
     *
     * @param jobOwner The Controller which is the owner of this Job
     */
    public PAJobGetAllPermissions(USMControllerIfc jobOwner) {
        super(
                PAMessageType.S_PA_REQ_GET_ALL_PERMISSIONS,
                USMStringTable.IDS_PA_JOB_RETRIEVE_ALL_PERMISSIONS.toString(),
                USMCommonStrings.EMPTY,
                jobOwner);
    }


    @Override
    public USMMessage executeJob() throws BcbSecurityException {
        LOGGER.debug("executeJob()in the method");

        USMMessage msg = null;
        try {
            msg = new PABusinessDelegate().getPermissions();
        }catch (RemoteException e){
            LOGGER.error("executeJob() error in getting response");
        }
        return msg;
    }
}
