package com.ossnms.bicnet.securitymanagement.client.domain.common;

import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObject;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSSecurableObjectContainer;

import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * Filters the containers available for a set of Securable Objects
 */
final class SecurableObjectContainerFilter {

	/**
	 * Hidden constructor
	 */
	private SecurableObjectContainerFilter(){}

//	/**
//	 * Filters and maps a set of securable objects
//	 *
//	 * @param availableSecurableObject the list of available securable objects
//	 * @param filter the filter of containers to apply
//	 *
//     * @return the filtered list of securable objects
//     */
//	public static List<BSSecurableObject> filterSecurableObject(List<BSSecurableObject> availableSecurableObject, SecurableObjectContainerFilterEnum filter, SecurableObjectFilterEnum objectFilter) {
//		return availableSecurableObject.stream()
//				.filter(getSecurableObjectFilterPredicate(objectFilter, filter))
//				.map(securableObjectTransform(filter))
//				.collect(Collectors.toList());
//	}

	/**
	 * Filters the list of securable object containers given the specified filter
	 *
	 * @param containers the list of containers to filter
	 * @param filter the filter of container type to apply
     *
	 * @return the filtered list of securable object containers
     */
	static List<BSSecurableObjectContainer> filterSecurableObjectContainer(List<BSSecurableObjectContainer> containers, SecurableObjectContainerFilterEnum filter) {
		return containers.parallelStream()
				.filter(getSecurableObjectContainerFilterPredicate(filter))
				.distinct()
				.collect(Collectors.toList());
	}

	/**
	 * Provides a predicate which filters the securable object containers
	 *
	 * @param filter the filter to apply
	 *
	 * @return predicate of {@link BSSecurableObjectContainer}
     */
	private static Predicate<BSSecurableObjectContainer> getSecurableObjectContainerFilterPredicate(SecurableObjectContainerFilterEnum filter) {
		return objectContainer -> objectContainer != null && filter.isTypeValid(objectContainer.getManagedObjectType());
	}


//    /**
//     * Provides a predicate which filters securable objects
//     *
//     * @param filter the filter to apply to the containers
//     *
//     * @return predicate of {@link BSSecurableObject}
//     */
//    private static Predicate<BSSecurableObject> getSecurableObjectFilterPredicate(SecurableObjectFilterEnum objectFilter, SecurableObjectContainerFilterEnum filter) {
//        return securableObject -> {
//            if(!securableObject.getManagedObjectType().equals(objectFilter.getObjectType())){
//                return false;
//            }
//
//            if(objectFilter.getContainerTypes()!=null && Arrays.stream(objectFilter.getContainerTypes()).anyMatch(containerType -> containerType.equals(filter))) {
//                return false;
//            }
//
//            List<BSSecurableObjectContainer> containers = filterSecurableObjectContainer(securableObject.getObjectContainers(), filter);
//            return containers != null && containers.size() > 0;
//        };
//    }

	/**
	 * Provides a function to transform a {@link BSSecurableObject} into an instance of the same type with a filtered
	 * list of object containers.
	 *
	 * @param filter the filter to apply
	 *
	 * @return the function which maps {@link BSSecurableObject} into an instance of the same type
	 */
	private static Function<BSSecurableObject, BSSecurableObject> securableObjectTransform(SecurableObjectContainerFilterEnum filter) {
		return securableObject -> {
			securableObject.setObjectContainers(
					securableObject.getObjectContainers().stream().filter(getSecurableObjectContainerFilterPredicate(filter)).collect(Collectors.toList())
			);

			return securableObject;
		};
	}
}
