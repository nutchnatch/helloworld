/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AALogonHistoryController
 * Author      	Jogender Singh
 * Substitute	Babu B
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.AUTHENTHICATE.USER
 *        TNMS.DX2.SM.LOGIN.USERID
 *  
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 * 26-Aug-2005  Babu B          CF002870 - No client log file created when working as normal user
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.auth;

import org.apache.log4j.Logger;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.function.Consumer;

/**
 * This class provides the functionality for reading and writing logon history in a file. 
 */
public final class AALogonHistoryController {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER =
        Logger.getLogger(AALogonHistoryController.class);

    /**
     * Data member to hold logon history file name 
     */
    private static final String S_LOGON_HISTORY = "logon_history_%d.ser";
    
    private static final String S_LOGON_FILE_NAME = System.getProperty("user.home") + "/" + S_LOGON_HISTORY;
    /**
     * Data member for holding self reference
     */
    private static AALogonHistoryController instance = new AALogonHistoryController();
    /**
     * Default Constructor
     *
     */
    private AALogonHistoryController() {
    }
    /**
     * 
     *Creates the single instance of this class and return.
     *@return AALogonHistoryController - Self reference
     *
     */
    public static AALogonHistoryController getInstance() {
        LOGGER.debug("getInstance() 		Called");
        return instance;
    }
    /**
     * Reads the logon history from the file
     * @return  AALogonHistoryData - Logon history data
     */
    public AALogonHistoryData readLogonHistory() {
        LOGGER.debug("readLogonHistory() 		Entry");
        AALogonHistoryData data = null;
        ObjectInputStream objOutputStream = null;
        try {
            objOutputStream =
                new ObjectInputStream(new FileInputStream(getLogonHistoryFilename()));
            data = (AALogonHistoryData) objOutputStream.readObject();
        } catch (FileNotFoundException e) {
        	// Changed to DEBUG trace because this is really not an error
            LOGGER.debug("readLogonHistory() 		Exception :", e);
        } catch (IOException e) {
            LOGGER.error("readLogonHistory() 		Exception :", e);
        } catch (ClassNotFoundException e) {
            LOGGER.error("readLogonHistory() 		Exception :", e);
        } finally {
            try {
                if (objOutputStream != null) {
                        objOutputStream.close();
                }
            } catch (IOException e) {
                LOGGER.error(e);
            }
        }
        
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("readLogonHistory() Exit. Returning : " + data);
        }
        return data;
    }

    /**
     * Saves the server combo box history.
     * @param strUserName User name.
     * @param strServer   Host name or IP address.
     * @param ssoSelected SSO authentication is selected
     */
    public void saveHistory(String strUserName, String strServer, boolean ssoSelected) {
        LOGGER.debug("saveHistory Entry");
        manipulateHistory(historyData -> {
            if (!ssoSelected) {
                historyData.setUserName(strUserName);
            }
            historyData.addServer(strServer);
            historyData.setSsoCheckBox(ssoSelected);
            historyData.clearServerLabels();
        });
        LOGGER.debug("saveHistory Exit");
    }

    /**
     * Saves a list of servers in history along with its labels.
     * The last server on the list will be the top one on server history.
     * @param servers the list of servers.
     */
    public void saveServersInHistory(LogonHistoryEntry... servers) {
        LOGGER.debug("saveServersInHistory Entry");
        manipulateHistory(historyData -> {
            historyData.clearServerLabels();
            for (LogonHistoryEntry server : servers) {
                historyData.addServer(server);
            }
        });
        LOGGER.debug("saveServersInHistory Exit");
    }

    private void manipulateHistory(Consumer<AALogonHistoryData> historyManipulation) {
        AALogonHistoryData historyData = readLogonHistory();
        if (historyData == null) {
            historyData = new AALogonHistoryData();
        }

        historyManipulation.accept(historyData);

        AALogonHistoryController.getInstance().writeLogonHistory(historyData);
    }

    /**
     * writes the logon history into the file
     * @param  historyData - Logon history data
     * @return  boolean - if logon history is updated successfully then return true otherwise false.
     */
    private boolean writeLogonHistory(AALogonHistoryData historyData) {
        boolean status = false;
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("writeLogonHistory(" + historyData + " Entry");
        }

        ObjectOutputStream objOutputStream = null;
        try {
            objOutputStream =
                new ObjectOutputStream(new FileOutputStream(getLogonHistoryFilename()));
            objOutputStream.writeObject(historyData);
            objOutputStream.flush();
            
            status = true;
        } catch (IOException ioe) {
            LOGGER.error("Exception : ", ioe);
        } finally {
            try {
                if (objOutputStream != null) {
                    objOutputStream.close();
                }
            } catch (IOException ioe) {
                LOGGER.error(ioe);
            }
        }

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("writeLogonHistory Exit. Returning : " + status);
        }
        return status;

    }

	private String getLogonHistoryFilename() {
		return String.format(S_LOGON_FILE_NAME, AALogonHistoryData.serialVersionUID);
	}
}
