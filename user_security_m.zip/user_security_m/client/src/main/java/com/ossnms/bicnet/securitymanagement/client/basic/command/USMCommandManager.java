/*
 * ------------------------History-------------------------
 * <date>       <author>        <reason(s) of change>
 * 22-Mar-2005	Muyeen Munaver	CF001809 - USM plugin passes empty actions in getMainActions()
 * 05-May-2005  Babu B          CF001312   Master-Master Replication for Sun ONE DS
 * 05-Aug-2005  Shrinidhi G V   CF002751   9320_MR_0282 Why do we have the TMN Application Server Administration Window?
 * 06-May-2009  Nagaraddi S S    TD004578 - RQT-STDERR errors instead log4j's
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.basic.command;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginAction;
import com.ossnms.bicnet.bcb.plugin.DefaultPluginAction;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEvtRegistrar;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMenuNameList;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * This is the Main Command Class of the application. It is the single point of entry for the Menu Handler when invoking of the commands.
 */
final public class USMCommandManager {
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(USMCommandManager.class);

    /**
     * Data member to hold the Registrar
     */
    private USMCommandRegistrar registrar = null;

    /**
     * Data member to hold the singleton instance
     */
    private static USMCommandManager instance = new USMCommandManager();

    /**
     * Default constructor
     */
    private USMCommandManager() {
        LOGGER.debug("Creating an object of USMCommandManager type");
    }

    /**
     * Function to return the singleton instance of the class.
     * 
     * @return USMCommandManager -
     * 			The singleton instance of the class.
     */
    public static USMCommandManager getInstance() {
        LOGGER.debug("Called getInstance");
        return instance;
    }

    /**
     * Function to return the Array of actions which will decide the menu that would be displayed for USM.
     * 
     * @return BiCNetPluginAction[] - The Array of Action items that are to be returned to the Client Frame
     */
    public BiCNetPluginAction[] getFileMainActions() {
        LOGGER.debug("Entering and returning Main Actions");

        int numActions = 1;
        List<BiCNetPluginAction> lstActions = new ArrayList<>(numActions);
        if (!USMUtility.getInstance().getSecurityPlugin().isLoggedInWithSSO()) {
            lstActions.add(getPluginActionForChangePassword());
        }
        
        BiCNetPluginAction[] arr = new BiCNetPluginAction[lstActions.size()];
        lstActions.toArray(arr);
        return arr;
    }

	/**
     * Function to return the Array of actions which will decide the menu that would be displayed for USM.
     * 
     * @return BiCNetPluginAction[] - The Array of Action items that are to be returned to the Client Frame
     */
    public BiCNetPluginAction[] getMainActions() {
        LOGGER.debug("Entering and returning Main Actions");

        int numActions = 11;
        List<BiCNetPluginAction> lstActions = new ArrayList<>(numActions);
        DefaultPluginAction actDomainAdmin = (DefaultPluginAction) getPluginActionForViewDomains();
        lstActions.add(actDomainAdmin);
        actDomainAdmin.setMenuSeparator(true);

        lstActions.add(getPluginActionForViewPolicies());
        lstActions.add(getPluginActionForViewUsers());
        lstActions.add(getPluginActionForViewUserGroups());
        lstActions.add(getPluginActionForViewAccessRights());

        BiCNetPluginAction[] arr = new BiCNetPluginAction[lstActions.size()];
        lstActions.toArray(arr);
        return arr;
    }

    /**
     * Helper function to create a BiCNetPluginAction for the Change Password
     * Menu Entry
     * 
     * @return BiCNetPluginAction - The BiCNetPluginAction for the change
     *         password menu entry
     */
    private static BiCNetPluginAction getPluginActionForChangePassword() {
        LOGGER.debug("Entering getPluginActionForChangePassword");

        DefaultPluginAction action = new DefaultPluginAction();

        String strChangePassword = USMMenuNameList.MENU_CHANGE_PASSWORD_LABEL;
        action.setMenuName(strChangePassword);

        String strChangePasswordSD = USMMenuNameList.MENU_CHANGE_PASSWORD_SHORT_DESC;
        action.setShortDescription(strChangePasswordSD);

        String strChangePasswordLD = USMMenuNameList.MENU_CHANGE_PASSWORD_LONG_DESC;
        action.setLongDescription(strChangePasswordLD);
        action.setActionListener(new USMMenuSelectionHandler(USMCommandID.S_UI_ID_CHANGE_PASSWORD));

        action.setToolName(USMMenuNameList.MENU_CHANGE_PASSWORD_LABEL);
        action.setMenuID(USMMenuNameList.MENU_CHANGE_PASSWORD_LABEL);
        
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting getPluginActionForChangePassword. " + "Returning object with Menu Label : "
                        + action.getMenuName() + " Menu ID : " + action.getMenuID() + " Short Desc. :" + action.getShortDescription() + " Long Desc. :" + action.getLongDescription());
        }
        return action;
    }

    /**
     * Helper function to create a BiCNetPluginAction for the View Domains
     * 
     * @return BiCNetPluginAction - The BiCNetPluginAction for the View Domains
     */
    private static BiCNetPluginAction getPluginActionForViewDomains() {
        DefaultPluginAction action = new DefaultPluginAction();
        action.setMenuName(USMMenuNameList.MENU_DOMAIN_ADMIN_LABEL);
        action.setShortDescription("View Domains");
        action.setLongDescription("View all the configured Domain(s) with Security");
        action.setToolIcon(ResourcesIconFactory.ICON_WINDOW_DOMAIN_16);
        action.setToolName(USMMenuNameList.MENU_DOMAIN_ADMIN_LABEL);
        action.setToolID("DomainManagement");
        action.setMenuID(USMMenuNameList.MENU_DOMAIN_ADMIN_LABEL);
        action.setActionListener(new USMMenuSelectionHandler(USMCommandID.S_UI_ID_VIEW_DOMAINS));

        return action;
    }

    /**
     * Helper function to create a BiCNetPluginAction for the View Policies
     * 
     * @return BiCNetPluginAction - The BiCNetPluginAction for the View Policies
     */
    private static BiCNetPluginAction getPluginActionForViewPolicies() {
        DefaultPluginAction action = new DefaultPluginAction();
        action.setMenuName(USMMenuNameList.MENU_POLICY_ADMIN_LABEL);
        action.setShortDescription("View Policies");
        action.setLongDescription("View all the configured Domain(s) with Security");
        action.setToolIcon(ResourcesIconFactory.ICON_WINDOW_POLICY_16);
        action.setToolName(USMMenuNameList.MENU_POLICY_ADMIN_LABEL);
        action.setToolID("PolicyManagement");
        action.setMenuID(USMMenuNameList.MENU_POLICY_ADMIN_LABEL);
        action.setActionListener(new USMMenuSelectionHandler(USMCommandID.S_UI_ID_VIEW_POLICIES));

        return action;
    }

    /**
     * Helper function to create a BiCNetPluginAction for the View Access
     * Rights
     * 
     * @return BiCNetPluginAction - The BiCNetPluginAction for the View Access
     *         Rights
     */
    private static BiCNetPluginAction getPluginActionForViewAccessRights() {
        DefaultPluginAction action = new DefaultPluginAction();
        action.setMenuName(USMMenuNameList.MENU_ACCESS_RIGHTS_LABEL);
        action.setShortDescription("View Access Rights");
        action.setLongDescription("View all the configured Access Right(s) with Security");
        action.setToolIcon(ResourcesIconFactory.ICON_TOOL_ASSIGN_16);
        action.setToolName(USMMenuNameList.MENU_ACCESS_RIGHTS_LABEL);
        action.setToolID("AccessRights");
        action.setMenuID(USMMenuNameList.MENU_ACCESS_RIGHTS_LABEL);
        action.setActionListener(new USMMenuSelectionHandler(USMCommandID.S_UI_ID_VIEW_ACCESS_RIGHTS));
        action.setMenuSeparator(true);

        return action;
    }

    /**
     * Helper function to create a BiCNetPluginAction for the View User
     * 
     * @return BiCNetPluginAction - The BiCNetPluginAction for the View User
     */
    private static BiCNetPluginAction getPluginActionForViewUsers() {
        DefaultPluginAction action = new DefaultPluginAction();
        action.setMenuName(USMMenuNameList.MENU_USER_ADMIN_LABEL);
        action.setShortDescription("View Users");
        action.setLongDescription("View all User(s) in Security");
        action.setToolIcon(ResourcesIconFactory.ICON_WINDOW_USER_16);
        action.setToolName(USMMenuNameList.MENU_USER_ADMIN_LABEL);
        action.setToolID("UserManagement");
        action.setMenuID(USMMenuNameList.MENU_USER_ADMIN_LABEL);
        action.setActionListener(new USMMenuSelectionHandler(USMCommandID.S_UI_ID_USER_MGMT_VIEW_USER));

        return action;
    }

    /**
     * Helper function to create a BiCNetPluginAction for the View User Groups
     * 
     * @return BiCNetPluginAction - The BiCNetPluginAction for the View User
     *         Groups
     */
    private static BiCNetPluginAction getPluginActionForViewUserGroups() {
        DefaultPluginAction action = new DefaultPluginAction();
        action.setMenuName(USMMenuNameList.MENU_USER_GROUP_ADMIN_LABEL);
        action.setShortDescription("View User Groups");
        action.setLongDescription("View all User Group(s) in Security");
        action.setToolIcon(ResourcesIconFactory.ICON_WINDOW_USERGROUP_16);
        action.setToolName(USMMenuNameList.MENU_USER_GROUP_ADMIN_LABEL);
        action.setToolID("UserGroupManagement");
        action.setMenuID(USMMenuNameList.MENU_USER_GROUP_ADMIN_LABEL);
        action.setActionListener(new USMMenuSelectionHandler(USMCommandID.S_UI_ID_USER_MGMT_VIEW_USER_GROUP));

        return action;
    }

    /**
     * This method provides the user to invoke the command explicitly (Not
     * through the user interface component).
     * 
     * @param nCommandID -
     *            This is the command ID which represents the command to be
     *            invoked.
     * 
     * @return boolean - Returns true on successful execution of the command
     *         associated with the command id.
     */
    public boolean executeCmd(final USMCommandID nCommandID) {
        return this.execute(nCommandID, null);
    }

    /**
     * This method provides the user to invoke the command explicitly (Not through the user interface component).
     * 
     * @param nCommandID
     *            - The command ID indicating which command to be executed
     * @param selList
     *            - The selection list
     * 
     * @return boolean - Returns true on successful execution of the command associated with the command id.
     */
    public boolean executeCmd(final USMCommandID nCommandID, final Object selList) {
        return this.execute(nCommandID, selList);
    }

    /**
     * This method is used to execute the commands. It looks whether the
     * command is already active. If it is already active..the default
     * behavior is to re-activate the command, which brings back the window to
     * focus. If the command does not exist in the list of active commands. A
     * new command is cloned and execute is called on that.
     * 
     * @param uiID -
     *            Command id associated with the menu that has to be executed.
     * @param selList -
     *            The selection list.
     * 
     * @return boolean - Returns true if there was no error in executing the
     *         command.
     */
    private boolean execute(USMCommandID uiID, Object selList) {
        boolean bIsExecuted = false;

        try {
            // Get the Prototype.
            USMCommand cmdHndlr = this.registrar.getCmdHndlr(uiID);

            // Fault ID 48 - Show a message informing not released feature - Begin
            if (cmdHndlr == null) {
                USMBaseView.showNotImplementedFeatureWindow();
                return false;
            }
            // Fault ID 48 - Show a message informing not released feature - End

            // Clone the Prototype.
            USMCommand clonedCmd = cmdHndlr.cloneCmd(selList);

            // Get List of All Active Commands with the Command ID.
            List<USMCommand> vecActiveCommandList = this.registrar.getListOfActiveCmds(uiID);

            // Compare the Active Commands with the Clone Command.
            // If Compare returns TRUE , then call "Reactivate" method.
            // Else If Compare returns FALSE, then add to list of active commands and call "Execute" method.
            USMCommand pActiveCmd = null;

            boolean bIsCommandFound = false;

            if (null != vecActiveCommandList) {
                for (USMCommand aVecActiveCommandList : vecActiveCommandList) {
                    pActiveCmd = aVecActiveCommandList;

                    if (null != pActiveCmd) {
                        if (pActiveCmd.compare(clonedCmd)) {
                            // Command Already Exists. Has to be Reactivated.
                            bIsCommandFound = true;
                            pActiveCmd.reactivate(selList);
                            bIsExecuted = true;
                            break;
                        }
                    }
                }
            }

            if (!bIsCommandFound) {
                if (clonedCmd.execute(selList)) {
                    this.registrar.addToListOfActiveCmds(clonedCmd);
                    bIsExecuted = true;
                } else {
                    LOGGER.error("Command did not execute properly");
                }
            }
        } catch (NullPointerException nullPtExcp) {
            LOGGER.error("Null Pointer raised. : ", nullPtExcp);

        }

        return bIsExecuted;
    }

    /**
     * This method registers the command associated with a specific command ID.
     * If there is a command handler already registered for the command ID,
     * this method call will fail.
     * 
     * @param uiCmdHdlr -
     *            This is the command handler object to be registered.
     * 
     * @return boolean - Returns true if the command was successfully
     *         registered.
     */
    boolean registerCmd(final USMCommand uiCmdHdlr) {
        return this.registrar.registerCmd(uiCmdHdlr);
    }

    /**
     * This method removes the active command object from the acitve command
     * list associated with a command ID. This method is called by
     * UICmdHndlrInfce when one of its derived object is about to be shut down.
     * 
     * @param cmdHndlrObj -
     *            The command handler object which should be removed
     */
    void removeFromActiveCmdList(final USMCommand cmdHndlrObj) {
        this.registrar.removeFromActiveCmdList(cmdHndlrObj);
    }

    /**
     * Function to initialize the Command Manager. The Manager is responsible
     * to register the registrar with the Logon Logoff Event Manager.
     * 
     * @return boolean
     * 			Indicates whether it was possible to initialize or not correctly.
     */
    public boolean initialize() {
        this.registrar = USMCommandRegistrar.getInstance();
        return USMLogonLogoffEvtRegistrar.getInstance().register(this.registrar);
    }

    /**
     * Function to return the number of Active commands.
     * @return int The number of active commands
     */
    public int getNumberOfActiveCmds() {
        return this.registrar.getNumberOfActiveCmds();
    }

    /**
     * @return
     */
    public boolean cleanup() {
        return this.registrar.cleanup();
    }

    /**
     * Close all windows associated with the specified OU.
     * 
     * @param strOUName OU which has been reloaded
     */
    public static void closeWindows(String strOUName) {

        // Now, close all specified windows.
        USMCommandRegistrar.getInstance().closeWindows(strOUName);
    }

    /**
     * Close all USM windows.
     */
    public static void closeAllWindows() {
        USMCommandRegistrar.getInstance().closeAllWindows();
    }
}