/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   UAJobGetAllAssignedAndUnAssignedUsers
 * Author:      Jogender
 * Substitute	Babu B
 * Created on	12-09-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER_GROUP.CONFIGURE 
 *       : TNMS.DX2.SM.USER_GROUP.ASSIGN
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration.job;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.useradministration.UADelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserGroup;
import org.apache.log4j.Logger;

/**
 * This class represents the job that is responsible for getting all the
 * assigned and unassigned user groups
 */
public class UAJobGetAllAssignedAndUnAssignedUsers extends USMJob {
	/**
	 * Data member to hold user group information
	 */
	UAUserGroup mUserGroup = null;

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(UAJobGetAllAssignedAndUnAssignedUsergroups.class);

	/**
	 * This is the constructor
	 * 
	 * @param pJobOwner -
	 *            The controller that is associated with the job
	 * @param p_userGroup
	 *      The user group for which the assigned/unassigned users have to be fetched
	 */
	public UAJobGetAllAssignedAndUnAssignedUsers(
		USMControllerIfc pJobOwner,
		UAUserGroup p_userGroup) {
		super(
			UAMessageType.S_UA_NOT_MODIFY_USER,
			USMCommonStrings.EMPTY,
			USMCommonStrings.EMPTY,
			pJobOwner);

		Object[] arr = { p_userGroup };
		String str =
			USMStringTable
				.IDS_UG_JOB_RET_USER_FOR_MODIFY_USER_GROUPS
				.getFormatedMessage(
				arr);
		setName(str);

		mUserGroup = p_userGroup;
	}

	/**
	 * Executes the given job
	 *
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob#executeJob()
	 */
	public USMMessage executeJob() throws BcbSecurityException {
		LOGGER.debug("executeJob() Enter");
		USMMessage msg =
			new UADelegate().getAllAssinedAndUnassignedUsers(mUserGroup);
		LOGGER.debug("executeJob() Exit");
		return msg;
	}

}
