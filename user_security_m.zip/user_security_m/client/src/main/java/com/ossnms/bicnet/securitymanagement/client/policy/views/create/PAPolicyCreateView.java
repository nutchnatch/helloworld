package com.ossnms.bicnet.securitymanagement.client.policy.views.create;

import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMHelp;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.bicnet.securitymanagement.client.policy.views.base.PACreateModifyBaseView;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPermissionData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxText;
import org.apache.log4j.Logger;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

/**
 * This class models the Create Policy Window. 
 */
public class PAPolicyCreateView extends PACreateModifyBaseView {
	
	private static final long serialVersionUID = 2374791300173184697L;

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(PAPolicyCreateView.class);

	/**
	 * Constructor
	 * 
	 */
	public PAPolicyCreateView() {
        super(null, getButtons(), null, "PAPolicyCreateView.com.ossnms.bicnet.securitymanagement.client.policy.PAPolicyCreateView_1",
				JfxStringTable.getString(USMStringTable.IDS_PA_NEW_TITLE), true, USMHelp.HID_CREATE_POLICY);
        associatedClientController = new PAPolicyCreateClientController(this);
        ((PAPolicyCreateClientController) associatedClientController).sendRequestToFetchAvailPermissions();
	}

	/**
	 * Function to return the Buttons that should be added
	 * 
	 * @return List which contains the List of Buttons to be added to
	 * the View
	 */
	private static List<USMButtonType> getButtons() {
		List<USMButtonType> buttons = new ArrayList<>();

        buttons.add(new USMButtonType(USMButtonTypeEnum.BTN_TYPE_OK, null, new JfxText("Creates the Policy"), true));
		buttons.add(USMButtonType.BTN_TYPE_CANCEL);

		return buttons;
	}

	/**
	 * Function that is called by this class when the window is opened for the
	 * create Policy and operator has pressed APPLY.
	 */
	private void createPolicy() {
		// Get the new Vector of Assigned Permissions
		List<PAPermissionData> permissions = getPermissions(S_RIGHT_LIST);
		LOGGER.info("no of assigned permissions are" + permissions.size());

		String csDescription = getDescription();
		String csName = getName();

		if (null != getName()) {
			csName = csName.trim();
		}

		if (isValidPolicyName(csName)) {
            PAPolicyData newPolicyData = new PAPolicyData(-1, csName, csDescription, permissions, 0, 0);
            ((PAPolicyCreateClientController) associatedClientController).sendRequestToCreatePolicy(newPolicyData);
        } else {
			if (0 == csName.length()) {
				showMessage(JfxStringTable.getString(USMStringTable.IDS_PA_CREATE_MESSAGE_NAME));
            } else {
                showMessage(JfxStringTable.getString(USMStringTable.IDS_PA_CREATE_MESSAGE_NAME_VALID));
            }
		}
	}

	/**
	 * Function to check if the name that the user has written is a valid name
	 * or not.
	 * 
	 * @param policyName The String which is entered by the operator for the name of the policy
	 * @return boolean Indicates whether the name is valid or not. True indicates that the name is alright.
	 */
	private boolean isValidPolicyName(String policyName) {
		//Check if it begins with blank spaces
		String regExpInvalid = "+;/<>,#";
		boolean valid = true;

		for (int i = 0; i < regExpInvalid.length(); i++) {
			if (-1 != policyName.indexOf((regExpInvalid.charAt(i)))) {
				valid = false;
				break;
			}
		}
        if (!validatePolicyNameSize(policyName) || !valid || !validatePolicySyntax(policyName)) {
            valid = false;
        }
		return valid;
	}

	/**
	 * Function to show a message to the user
	 * 
	 * @param message The Text that should be displayed
	 */
	public void showMessage(String message) {
		JfxOptionPane.showMessageBox(this, message);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView_BtnPnl_StatusBar#handleButtonClick(com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType)
	 */
	@Override
    public void handleButtonClick(USMButtonTypeEnum type) {
		if ((USMButtonTypeEnum.BTN_TYPE_OK).equals(type)) {
			createPolicy();
		} else if ((USMButtonTypeEnum.BTN_TYPE_CANCEL).equals(type)) {
			close();
		} else {
			LOGGER.info("unexpected...");
		}
	}

	@Override
    protected void enableDisableControls() {
		enableAllButtons();
	}

    @Override
    public boolean isDockable() {    
        return false;
    }
    
    @Override
    public Icon getIcon() {
    	return ResourcesIconFactory.ICON_WINDOW_POLICY_16;
    }

	private boolean validatePolicySyntax(String policyName) {
		boolean isValid = true;
		if (policyName.startsWith(" ") ||  policyName.endsWith(" ")) {
			isValid = false;
		}
		return isValid;
	}

	private boolean validatePolicyNameSize(String policyName) {
		boolean isValid = true;
		final int policyLength = 64;
		if ((0 == policyName.length()) || policyName.length() > policyLength) {
			isValid = false;
		}
		return isValid;
	}
}