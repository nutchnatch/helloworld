/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	AALogonListener
 * Author      	Jogender Singh
 * Substitute	Babu B
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: TNMS.DX2.SM.AUTHENTHICATE.USER
 *        TNMS.DX2.SM.LOGIN.USERID
 *
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.auth;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginServerAccessController;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandManager;
import com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEventIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityAuthenticationPrivateFacade;
import org.apache.log4j.Logger;

import javax.swing.*;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;

/**
 * Helper class to listen to logon event & change password if necessary
 */
public class AALogonListener implements USMLogonLogoffEventIfc {

	/**
	 * Data member for Logging
	 */
	private static final Logger LOGGER = Logger.getLogger(AALogonListener.class);

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEventIfc#operatorLoggedOn(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
	@Override
    public void operatorLoggedOn(ISessionContext sessionContext) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering operatorLoggedOn. " + sessionContext);
		}

		/* Handle the case that user must change password at next logon
           In the case of SSO, we never check if the password has expired */		
		boolean bResult;
		if (USMUtility.getInstance().getSecurityPlugin().isLoggedInWithSSO()) {
            bResult = false;
        } else {
            bResult = chkIfUserMustChangePassword(sessionContext);
        }

		final boolean bPasswordMustChange = bResult;

		if (bPasswordMustChange) {
			SwingUtilities.invokeLater(() -> USMCommandManager.getInstance().executeCmd(USMCommandID.S_UI_ID_CHANGE_PASSWORD, bPasswordMustChange));
		} else {
			LOGGER.debug("Operator is not forced to change password");
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting operatorLoggedOn. " + sessionContext);
		}
	}

	/**
	 * Function to check if the user should change the password.
	 * 
	 * @param sessionContext Sesssion Context which decides who the user is
	 * @return Boolean Indicates whether the user should change password or not. True indicates change password.
	 */
	private Boolean chkIfUserMustChangePassword(final ISessionContext sessionContext) {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Entering chkIfUserMustChangePassword. " + sessionContext);
		}
		final boolean chngPassword = false;
		if (null != sessionContext) {

			try {
                return (Boolean) BiCNetPluginServerAccessController.doPrivileged(this, new PrivilegedExceptionAction<Boolean>() {
                    @Override
                    public Boolean run() throws BcbSecurityException {
                        ISecurityAuthenticationPrivateFacade usmAuthentication = AALoginBusinessDelegate.getAuthenticationBean();
                        if (usmAuthentication != null) {
                            USMMessage objPasswordMustChange = usmAuthentication.isPasswordMustChanged(sessionContext);
                            return objPasswordMustChange.popBoolean();
                        }
                        return chngPassword;
                    }
                });
			} catch (PrivilegedActionException e) {
				LOGGER.error("Exception raised.", e);
			}

		}

		if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Exiting chkIfUserMustChangePassword. Returning " + chngPassword);
		}
		return chngPassword;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEventIfc#operatorLoggedOff(com.ossnms.bicnet.bcb.facade.security.ISessionContext, java.lang.String)
	 */
	@Override
    public void operatorLoggedOff(ISessionContext sessionContext) {
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEventIfc#operatorLoggingOff(com.ossnms.bicnet.bcb.facade.security.ISessionContext)
	 */
	@Override
    public void operatorLoggingOff(ISessionContext sessionContext) {
		LOGGER.debug("operatorLoggingOff ");
	}
}