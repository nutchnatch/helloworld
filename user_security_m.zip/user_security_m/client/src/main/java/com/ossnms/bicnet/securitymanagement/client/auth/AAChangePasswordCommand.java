package com.ossnms.bicnet.securitymanagement.client.auth;

import org.apache.log4j.Logger;

import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;

/**
 * This is the main client component which is responsible to display Change Password window. When operator presses
 * change password menu entry, this class will be called to create and return the view.
 */

public class AAChangePasswordCommand extends USMCommand {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(AAChangePasswordCommand.class);

    /**
     * Data member to indicate whether invoked automatically at startup
     */
    private boolean invokedAtStartup;

    /**
     * Default Constructor
     */
    public AAChangePasswordCommand() {
        super(USMCommandID.S_UI_ID_CHANGE_PASSWORD);
        invokedAtStartup = false;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#createAndReturnView()
     */
    protected USMBaseView createAndReturnView() {
        LOGGER.debug("createAndReturnView() Entry");
        AAChangePasswordView changePasswordView = new AAChangePasswordView();
        changePasswordView.setFocus();

        LOGGER.debug("createAndReturnView() Exit");
        return changePasswordView;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#cloneCmd(java.lang.Object)
     */
    public USMCommand cloneCmd(Object selList) {
        boolean bShownAtStartup = false;
        if (selList != null) {
            bShownAtStartup = ((Boolean) selList).booleanValue();
        }

        AAChangePasswordCommand cmd = new AAChangePasswordCommand();
        cmd.invokedAtStartup = bShownAtStartup;
        return cmd;
    }

    /**
     * @return
     */
    public boolean isInvokedAtStartup() {
        return invokedAtStartup;
    }
}