/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCDeleteDomainJob
 * Author      	Muyeen Munaver
 * Substitute	Asifullakhan
 * Created on	26-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CONFIG
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain.job;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.domain.DCBusinessDelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents a job that is responsible for the domain deletion
 * operation
 */
public class DCDeleteDomainJob extends USMJob {
	/**
	 * This is a vector of domains to be deleted
	 */
	private List<DCDomainData> domainsList = new ArrayList<>();

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(DCDeleteDomainJob.class);

	/**
	 * This is the constructor
	 * 
	 * @param id
	 *            - The type of message
	 * @param jobOwner
	 *            - The controller associated with the job
	 * @param domains
	 *            - Vector of domains to be deleted
	 */
	public DCDeleteDomainJob(USMBaseMsgType id, USMControllerIfc jobOwner, List<DCDomainData> domains) {
		super(id, USMCommonStrings.EMPTY, domains.toString(), jobOwner);

		String str;
		if (domains.size() == 1) {
			Object[] arr = { domains.get(0) };
			str = USMStringTable.IDS_DC_JOB_DESC_DELETE_DOMAIN_SINGLE.getFormatedMessage(arr);
		} else {
			Object[] arr = { domains.size() };
			str = USMStringTable.IDS_DC_JOB_DESC_DELETE_DOMAIN_MULTI.getFormatedMessage(arr);
		}
		setName(str);

		LOGGER.debug("DCDeleteDomainJob() - Entry");
		this.domainsList = domains;
		LOGGER.debug("DCDeleteDomainJob() - Exit");

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public USMMessage executeJob() throws BcbSecurityException {
		LOGGER.debug("executeJob() Enter");
		USMMessage msg = new DCBusinessDelegate().deleteDomain(domainsList);
		LOGGER.debug("executeJob() Exit");
		return msg;
	}

}
