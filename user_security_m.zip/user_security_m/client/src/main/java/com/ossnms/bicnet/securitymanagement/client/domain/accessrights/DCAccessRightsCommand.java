/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCAccessRightsCmd
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID	    :   TNMS.DX2.SM.MAPPING.VIEW
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain.accessrights;

import org.apache.log4j.Logger;

import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;

/**
 * The command handler for access rights window. When the user clicks on the View Access Rights, this command comes into
 * action.
 */
public class DCAccessRightsCommand extends USMCommand {

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(DCAccessRightsCommand.class);

    /**
     * default constructor
     */
    public DCAccessRightsCommand() {
        super(USMCommandID.S_UI_ID_VIEW_ACCESS_RIGHTS);
        LOGGER.info("DCAccessRightsCmd() Creating a instance of this command");
    }

    @Override
    protected USMBaseView createAndReturnView() {
        LOGGER.info("createAndReturnView() Creating the access rights window");
        return new DCAccessRightsView();
    }

}
