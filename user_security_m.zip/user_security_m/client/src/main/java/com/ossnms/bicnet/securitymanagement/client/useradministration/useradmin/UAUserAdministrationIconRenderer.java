package com.ossnms.bicnet.securitymanagement.client.useradministration.useradmin;

import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import java.awt.Component;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 * Renderer class for columns that contain icons Also supports tooltips
 */
public class UAUserAdministrationIconRenderer extends DefaultTableCellRenderer {
    private static final long serialVersionUID = -8124702220303135002L;

    private static final Icon iconActivatedUser = ResourcesIconFactory.ICON_TOOL_OK_16;
    private static final Icon iconDeactivatedUser = ResourcesIconFactory.ICON_STATUS_DEACTIVATED_16;
    private static final Icon iconLockedUser = ResourcesIconFactory.ICON_STATUS_LOCK_16;
    private static final Icon iconExpiredUser = ResourcesIconFactory.ICON_STATUS_ACCOUNT_EXPIRED_16;

    /**
     * Helper method to render the icon for a given cell
     *
     * @see javax.swing.table.TableCellRenderer#getTableCellRendererComponent(javax.swing.JTable, java.lang.Object, boolean, boolean, int, int)
     */
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {

        Icon icon = null;
        String strText = null;
        String strToolTipText = null;

        if (value instanceof String) {
            // Value is text
            strToolTipText = value.toString();
            strText = strToolTipText;
        } else if (value instanceof Icon) {
            // Value is an Icon
            icon = (Icon) value;

            if (icon.equals(iconActivatedUser)) {
                strToolTipText = USMStringTable.IDS_UA_USER_STATE_ACTIVATED.toString();
            } else if (icon.equals(iconDeactivatedUser)) {
                strToolTipText = USMStringTable.IDS_UA_USER_STATE_DEACTIVATED.toString();
            } else if (icon.equals(iconLockedUser)) {
                strToolTipText = USMStringTable.IDS_UA_USER_STATE_LOCKED.toString();
            } else if(icon.equals(iconExpiredUser)) {
                strToolTipText = USMStringTable.IDS_UA_USER_STATE_EXPIRED.toString();
            }
        }

        setText(strText);
        setToolTipText(strToolTipText);
        setIcon(icon);

        setHorizontalAlignment(JLabel.CENTER);

        if (isSelected) {
            setBackground(table.getSelectionBackground());
            setForeground(table.getSelectionForeground());
        } else {
            setBackground(table.getBackground());
            setForeground(table.getForeground());
        }

        return this;
    }
}