package com.ossnms.bicnet.securitymanagement.client.policy.views.base;

/**
 * The class which differentiates what type of list it is. It could be a left list or a right list.
 */
final class PAListType {

    /**
     * To identify whether it is a left tree or a right tree
     */
    private int nTreeType;

    /**
     * Constructor which takes a tree type
     *
     * @param nTreeType
     *            Identifies whether it is to be a left tree or a right tree.
     */
    PAListType(int nTreeType) {
        this.nTreeType = nTreeType;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + nTreeType;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        PAListType other = (PAListType) obj;
        return nTreeType == other.nTreeType;
    }
}
