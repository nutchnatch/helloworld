/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	DCModifyDomainCommand
 * Author      	Asif Khan R
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID: 	TNMS.DX2.SM.DOMAIN.CONFIG
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain.modify;

import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import org.apache.log4j.Logger;

/**
 * The command handler which handles domain modification(Modify Domain operation)
 */
public class DCModifyDomainCommand extends USMCommand {

	/**
	 * This represents the domain for which modification is to be performed
	 */
	DCDomainData mDomain;

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(DCModifyDomainCommand.class);

	/**
	 * Constructor
	 */
	public DCModifyDomainCommand() {
		super(USMCommandID.S_UI_ID_MODIFY_DOMAIN);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("DCModifyDomainCommand() - Enter/Exit");
		}

	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#createAndReturnView()
	 */
	@Override
    protected USMBaseView createAndReturnView() {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("createAndReturnView() - Enter");
		}
		DCModifyDomainView dcView = new DCModifyDomainView(mDomain);

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info(
				"Opening of the modify window for the domain " + mDomain);
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("createAndReturnView() - Exit : Return :" + dcView);
		}
		return dcView;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#compare(com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand)
	 */
	@Override
    public boolean compare(USMCommand cmd) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("compare(" + cmd + ") - Enter");
		}

		DCModifyDomainCommand oldCmd = (DCModifyDomainCommand) cmd;

		//Check if the we have the same domain already in this command
		boolean ret = oldCmd.mDomain.equals(this.mDomain);

		if (LOGGER.isInfoEnabled()) {
            String traceStr = "Modify window for the domain " + mDomain;
			traceStr += "Old window having domain " + oldCmd.mDomain;
			LOGGER.info(traceStr);
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("compare(" + cmd + ") - Exit: Return :" + ret);
		}
		return ret;

	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#cloneCmd(java.lang.Object)
	 */
	@Override
    public USMCommand cloneCmd(Object selList) {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("cloneCmd(" + selList + ") - Enter");
		}
		DCModifyDomainCommand newCmd = new DCModifyDomainCommand();
		if (LOGGER.isInfoEnabled()) {
            String traceStr = "cloning command for the domain " + selList;
			LOGGER.info(traceStr);
		}

		newCmd.mDomain = (DCDomainData) selList;

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(
				"cloneCmd(" + selList + ") - Exit : Return :" + newCmd);
		}
		return newCmd;
	}
    
    /* (non-Javadoc)
     * @see com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommand#getKey()
     */
    @Override
    public Object getKey() { 
        return mDomain;
    }

}