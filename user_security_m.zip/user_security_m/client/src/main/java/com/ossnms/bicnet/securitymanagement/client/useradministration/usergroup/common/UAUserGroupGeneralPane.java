package com.ossnms.bicnet.securitymanagement.client.useradministration.usergroup.common;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.apache.log4j.Logger;

import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.tools.jfx.JfxFormPanel;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxList;
import com.ossnms.tools.jfx.components.JfxTextField;

/**
 * This class represents the General tab, to be shown in the User Group creation/modification window. 
 *
 */
public class UAUserGroupGeneralPane extends JPanel implements ListSelectionListener{
    
    private static final long serialVersionUID = -8811138166733247435L;

    private static final Logger LOGGER = Logger.getLogger(UAUserGroupGeneralPane.class);

    /**
     * Text field for holding the name.
     */
    protected JfxTextField nameTextField = null;
    
    /**
     * Text field for holding the description.
     */
    protected JfxTextField descriptionTextField = null;

    /**
     * GUI control declaration
     */
    public DefaultListModel availableUserListModel;
    public DefaultListModel assignedUserListModel;

    /**
     * List for the available users.
     */
    private JfxList listAvblUser = null;

    /**
     * List for the assigned users.
     */
    private JfxList listAsndUser = null;
    
    /**
     * Button for left transfer.
     */
    private JfxButton btnLTR = null;
    /**
     * Button for right transfer.
     */
    private JfxButton btnRTL = null;
    /**
     * Button for left group transfer.
     */
    private JfxButton btnLTRGP = null;
    /**
     * Button for right group transfer.
     */
    private JfxButton btnRTLGP = null;
    
    
    public UAUserGroupGeneralPane(){
        initComponents();
        setNamesForTesting();
    }
    
    
    private void initComponents(){
        this.setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);
        this.setLayout(new GridBagLayout());
        
        Dimension listMinDimension = new Dimension(35, 50);
        
        JfxLabel lblName = new JfxLabel(USMStringTable.IDS_UG_LABEL_USER_GROUP_NAME);
        nameTextField = new JfxTextField();
        nameTextField.limitText(64);
        nameTextField.setMandatoryEntry(true);
        lblName.setLabelAndMnemonicFor(nameTextField);
        
        JfxLabel lblDesc = new JfxLabel(USMStringTable.IDS_UG_LABEL_USER_GROUP_DESCRIPTION);
        descriptionTextField = new JfxTextField();
        descriptionTextField.limitText(128);
        descriptionTextField.setMandatoryEntry(true);
        lblDesc.setLabelAndMnemonicFor(descriptionTextField);
        descriptionTextField.setMandatoryEntry(true);

        availableUserListModel = new DefaultListModel();
        listAvblUser = new JfxList(availableUserListModel);
        listAvblUser.setCellRenderer(new UAUserListCellRenderer());
        listAvblUser.setName("AvailableUsers");

        assignedUserListModel = new DefaultListModel();
        listAsndUser = new JfxList(assignedUserListModel);
        listAsndUser.setCellRenderer(new UAUserListCellRenderer());
        listAsndUser.setDragEnabled(true);

        btnLTR = new JfxButton(USMStringTable.IDS_BUTTON_ADD);
        btnLTRGP = new JfxButton(USMStringTable.IDS_BUTTON_ADD_ALL);
        btnRTL = new JfxButton(USMStringTable.IDS_BUTTON_REMOVE);
        btnRTLGP = new JfxButton(USMStringTable.IDS_BUTTON_REMOVE_ALL);

        // Set up Available users
        JfxLabel availableUsersLabel = new JfxLabel(USMStringTable.IDS_UG_LABEL_UNASSIGNED_USER_LIST);
        availableUsersLabel.setLabelAndMnemonicFor(listAvblUser);
        availableUsersLabel.setAlignmentX(LEFT_ALIGNMENT);

        JScrollPane availableUsersPane = new JScrollPane(listAvblUser);
        availableUsersPane.setAlignmentX(LEFT_ALIGNMENT);
        availableUsersPane.setMinimumSize(listMinDimension);
        availableUsersPane.setPreferredSize(listMinDimension);
        availableUsersPane.setName("ScrollUsers");
        
        // Set up Assigned users
        JfxLabel assignedUsersLabel = new JfxLabel(USMStringTable.IDS_UG_LABEL_ASSIGNED_USER_LIST);
        assignedUsersLabel.setLabelAndMnemonicFor(listAsndUser);
        assignedUsersLabel.setAlignmentX(LEFT_ALIGNMENT);
        
        JScrollPane assignedUsersPane = new JScrollPane(listAsndUser);
        assignedUsersPane.setAlignmentX(LEFT_ALIGNMENT);
        assignedUsersPane.setMinimumSize(listMinDimension);
        assignedUsersPane.setPreferredSize(listMinDimension);
        
        JPanel nameAndDescriptionPanel = new JPanel();
        nameAndDescriptionPanel.setLayout(new GridBagLayout());

        nameAndDescriptionPanel.add(lblName, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.DEFAULT_MARGIN), 0, 0));
        nameAndDescriptionPanel.add(nameTextField, new GridBagConstraints(1, 0, 3, 1, 1.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        nameAndDescriptionPanel.add(lblDesc, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.DEFAULT_MARGIN), 0, 0));
        nameAndDescriptionPanel.add(descriptionTextField, new GridBagConstraints(1, 1, 3, 1, 1.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));

        JfxFormPanel navigationPanel = new JfxFormPanel();
        navigationPanel.setLayout(new GridBagLayout());
        
        navigationPanel.add(btnLTR, new GridBagConstraints(0, 0, 4, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, JfxUtils.MINIMUM_DISTANCE_BETWEEN_BUTTONS, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        navigationPanel.add(btnLTRGP, new GridBagConstraints(0, 1, 4, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, JfxUtils.MINIMUM_DISTANCE_BETWEEN_BUTTONS, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        navigationPanel.add(btnRTL, new GridBagConstraints(0, 2, 4, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, JfxUtils.MINIMUM_DISTANCE_BETWEEN_BUTTONS, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        navigationPanel.add(btnRTLGP, new GridBagConstraints(0, 3, 4, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));

        this.add(nameAndDescriptionPanel, new GridBagConstraints(0, 0, 3, 2, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        this.add(availableUsersLabel, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        this.add(assignedUsersLabel, new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.NONE, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
        this.add(availableUsersPane, new GridBagConstraints(0, 3, 1, 1, 1.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
        this.add(navigationPanel, new GridBagConstraints(1, 3, 1, 1, 0.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.VERTICAL, new Insets(0, 0, 0, 0), 0, 0));
        this.add(assignedUsersPane, new GridBagConstraints(2, 3, 1, 1, 1.0, 1.0, GridBagConstraints.FIRST_LINE_START, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));

        // Adding listeners for the GUI controls
        btnLTR.addActionListener(evt -> onLTR());
        btnRTL.addActionListener(evt -> onRTL());
        btnLTRGP.addActionListener(evt -> onLTRGP());
        btnRTLGP.addActionListener(evt -> onRTLGP());

        listAsndUser.addListSelectionListener(this);
        listAvblUser.addListSelectionListener(this);
        DefaultListModelListener dataListener = new DefaultListModelListener();

        availableUserListModel.addListDataListener(dataListener);
        assignedUserListModel.addListDataListener(dataListener);
    }
    
    /**
     * Helper function that is used to set the Names of all the editable components within the tab.
     * 
     * Strings in this function are not to be Internationalized.
     */
    private void setNamesForTesting() {
        btnLTR.setName("Add");
        btnRTL.setName("Remove");
        btnLTRGP.setName("AddAll");
        btnRTLGP.setName("RemoveAll");
        nameTextField.setName("Name");
        descriptionTextField.setName("Description");
    }

    /**
     * Getter for the Name text field
     * @return the Name text field
     */
    public JfxTextField getNameTextField() {
        return nameTextField;
    }

    /**
     * Getter for the Description text field
     * @return the Description text field
     */
    public JfxTextField getDescriptionTextField() {
        return descriptionTextField;
    }

    /**
     * Getter for the AssignedUserListModel
     * @return the AssignedUserListModel
     */
    public DefaultListModel getAssignedUserListModel() {
        return assignedUserListModel;
    }

    /**
     * Getter for the AvailableUserListModel
     * @return the AvailableUserListModel
     */
    public DefaultListModel getAvailableUsersListModel(){
        return availableUserListModel;
    }
    
    /**
     * Handler for the left transfer button. This method transfers the selected objects to the right pane.
     */
    protected void onLTR() {
        LOGGER.debug("onLTR() Enter");

        List selectedList = listAvblUser.getSelectedValuesList();
        int len = selectedList.size();
        for (Object aSelectedList : selectedList) {
            assignedUserListModel.addElement(aSelectedList);
            availableUserListModel.removeElement(aSelectedList);
        }

        enableDisableShiftBtns();
        LOGGER.debug("onLTR() Exit");
    }

    /**
     * Handler for the right transfer button. This method transfers the selected objects to the left pane.
     */
    protected void onRTL() {
        LOGGER.debug("onRTL() Enter");

        List selectedList = listAsndUser.getSelectedValuesList();
        for (Object aSelectedList : selectedList) {
            availableUserListModel.addElement(aSelectedList);
            assignedUserListModel.removeElement(aSelectedList);
        }

        enableDisableShiftBtns();
        LOGGER.debug("onRTL() Exit");
    }

    /**
     * Handler for the left group transfer button. This method transfers the all the objects to the right pane.
     */
    protected void onLTRGP() {
        LOGGER.debug("onLTRGP() Enter");

        int listLen = availableUserListModel.size();
        for (int index = listLen - 1; index >= 0; index--) {
            assignedUserListModel.addElement(availableUserListModel.elementAt(index));
            availableUserListModel.removeElementAt(index);
        }

        enableDisableShiftBtns();
        LOGGER.debug("onLTRGP() Exit");
    }

    /**
     * Handler for the right group transfer button . This method transfers the all the objects to the left pane.
     */
    protected void onRTLGP() {
        LOGGER.debug("onRTLGP() Enter");

        int listLen = assignedUserListModel.size();
        for (int index = listLen - 1; index >= 0; index--) {
            availableUserListModel.addElement(assignedUserListModel.elementAt(index));
            assignedUserListModel.removeElementAt(index);
        }

        enableDisableShiftBtns();
        LOGGER.debug("onRTLGP() Exit");
    }
    /**
     * Handler for selection changes in any of the list controls
     * 
     * @param p_event
     *            Event describing the action on te list control
     * 
     * @see javax.swing.event.ListSelectionListener#valueChanged(javax.swing.event.ListSelectionEvent)
     */
    @Override
    public void valueChanged(ListSelectionEvent p_event) {
        LOGGER.debug("Entering valueChanged");
        enableDisableShiftBtns();
        LOGGER.debug("Exiting valueChanged");
    }
    
    /**
     * Helper function that should be called when the <, >, <<, >> buttons are to be enabled and disabled. Checks are made internally for the enabling and disabling.
     */
    private void enableDisableShiftBtns() {
        btnLTR.setEnabled(false);
        btnRTL.setEnabled(false);
        btnRTLGP.setEnabled(false);
        btnLTRGP.setEnabled(false);

        if (listAvblUser.getSelectedIndices().length > 0) {
            btnLTR.setEnabled(true);
        }
        if (listAsndUser.getSelectedIndices().length > 0) {
            btnRTL.setEnabled(true);
        }
        if (availableUserListModel.size() > 0) {
            btnLTRGP.setEnabled(true);
        }
        if (assignedUserListModel.size() > 0) {
            btnRTLGP.setEnabled(true);
        }
    }
    
    class DefaultListModelListener implements ListDataListener {

        /**
         * {@inheritDoc}
         */
        @Override
        public void contentsChanged(ListDataEvent e) {
            enableDisableShiftBtns();
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public void intervalAdded(ListDataEvent e) {
            enableDisableShiftBtns();
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public void intervalRemoved(ListDataEvent e) {
            enableDisableShiftBtns();
        }
    }
 
}
