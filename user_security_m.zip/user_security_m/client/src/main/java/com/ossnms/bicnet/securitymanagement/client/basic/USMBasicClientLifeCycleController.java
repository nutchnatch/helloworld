/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMBasicClientLifeCycleController
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.basic;

import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandManager;
import com.ossnms.bicnet.securitymanagement.client.basic.notification.USMNotificationHandler;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import org.apache.log4j.Logger;

/**
* This class is the Life Cycle controller for all the basic classes.
* This is the single point of contact for the Basic classes.
*/

public final class USMBasicClientLifeCycleController
	implements USMClientLifeCycleControllerIfc {
	/**
	 * Data member to hold the Logger that is associated with this class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(USMBasicClientLifeCycleController.class);

	/**
	* Holds singleton instance
	*/
	private static USMBasicClientLifeCycleController instance = new USMBasicClientLifeCycleController();

	/**
	 * Data member to hold the INotificationHandler object
	 */
	private USMNotificationHandler notifHandler;

	/**
	* prevents instantiation
	*/
	private USMBasicClientLifeCycleController() {
		LOGGER.debug("Entering the create");

		notifHandler = new USMNotificationHandler();

		LOGGER.debug("Exiting the create");
	}

	/**
	* Returns the singleton instance.
	* 
	* @return USMBasicClientLifeCycleController -
	* 		The singleton instance
	*/
	public static USMBasicClientLifeCycleController getInstance() {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting the getInstance. Returning : " + instance);
		}
		return instance;
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.common.basic.USMLifeCycleController#initialize()
	 */
	public boolean initialize() {
		LOGGER.debug("Entering the initialize");

		boolean bCmdMgrInit = USMCommandManager.getInstance().initialize();
		boolean bNotifHandInit = notifHandler.initialize();
		boolean bUtil = USMUtility.getInstance().initialize();

		LOGGER.debug("Exiting the initialize");
		return (bCmdMgrInit && bNotifHandInit && bUtil);
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.common.basic.USMLifeCycleController#cleanup()
	 */
	public boolean cleanup() {
		LOGGER.debug("Entering the cleanup");

		boolean bCmdMgrCleaned = USMCommandManager.getInstance().cleanup();
		boolean bNotifHandCleaned = notifHandler.cleanup();

		LOGGER.debug("Exiting the cleanup");
		return (bCmdMgrCleaned && bNotifHandCleaned);
	}
}
