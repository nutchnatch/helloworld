/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	PAUpdateHint
 * Author      	Vinay Purohit
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID	:	TNMS.DX2.SM.POLICY.VIEW
 * 			:	TNMS.DX2.SM.POLICY.ADMIN
 * 			:	TNMS.DX2.SM.POLICY.CREATE
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.policy.views.base;


/**
 * This is the helper class for policy sub system. 
 * It is used to refresh Appropriate policies window as per notification 
 */

public class PAUpdateHint {

	/**
	 * Data member to indicate that a Policy has been created.
	 */
	public static final int POLICY_CREATED = 1;

	/**
	 * Data member to indicate that a Policy has been deleted.
	 */
	public static final int POLICY_DELETED = 2;

	/**
	 * Data member to indicate that a Policy has been modified.
	 */
	public static final int POLICY_MODIFIED = 3;

	/**
	 * Data member to indicate that a Policy data has been fetched.
	 */
	public static final int POLICY_DATA_FETCHED = 4;

	/**
	 * Data member to indicate that a Policy list has been fetched.
	 */
	public static final int POLICY_LIST_FETCHED = 5;

	/**
	 * Data member to indicate what is the operation.
	 */
	private int updateHint;

	/**
	 * Constructor
	 * @param p_Hint The integer which suggests what is the operation 
	 * (Create/Delete/etc..)
	 */
	public PAUpdateHint(int p_Hint) {
		updateHint = p_Hint;
	}

	/**
	 * Function to retrieve the operation for this Object.
	 * @return int The operation for which this object has been created.
	 */
	public int getHint() {
		return updateHint;
	}
}
