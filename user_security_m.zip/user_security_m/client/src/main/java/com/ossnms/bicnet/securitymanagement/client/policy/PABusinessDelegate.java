/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	PABusinessDelegate
 * Author      	Vinay Purohit
 * Substitute	Muyeen M
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID	:	TNMS.DX2.SM.POLICY.VIEW
 * 			:	TNMS.DX2.SM.POLICY.ADMIN
 * 			:	TNMS.DX2.SM.POLICY.CREATE
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 06-May-2009  Nagaraddi S S    TD004578 - RQT-STDERR errors instead log4j's
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.policy;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyData;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityPolicyAdministrationPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.servicelocator.USMServiceLocator;
import com.ossnms.bicnet.util.UnexpectedException;
import org.apache.log4j.Logger;

import java.rmi.RemoteException;
import java.util.List;

/**
 * All components with USM use a Business Delegate to perform an operation
 * on the bean. This class is the Business Delegate for the Policy components.
 */
public final class PABusinessDelegate implements PABusinessDelegateIfc {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(PABusinessDelegate.class);

	public PABusinessDelegate() {
	}

	/**
	 * Function to retrieve all the Policies that are configured with USM
	 * 
	 * @return Message which contains the List of Policies currently available
	 * within USM
	 */
	public USMMessage getPolicies()
		throws BcbSecurityException, RemoteException {
		LOGGER.debug(" getAllConfiguredPolicies() ENTRY");
		USMMessage msg;
		ISecurityPolicyAdministrationPrivateFacade objSecurityProvider = getPolicyAdministrationBean();

		msg = objSecurityProvider.getPolicies(USMUtility.getInstance().getSessionContext());
		LOGGER.debug(" getAllConfiguredPolicies() EXIT");

		return msg;
	}

	/**
	 * Function to delete Policies
	 * @param policies The List of Policies that are to be deleted
	 * @return USMMessage The message which contains the status of the operation that was performed
	 */
	public USMMessage deletePolicies(List<PAPolicyId> policies) throws BcbSecurityException, RemoteException {
		LOGGER.debug(" deletePolicies() ENTRY");
		ISecurityPolicyAdministrationPrivateFacade objSecurityProvider = getPolicyAdministrationBean();
		LOGGER.debug(" deletePolicies() EXIT");
		return objSecurityProvider.deletePolicy(USMUtility.getInstance().getSessionContext(), policies);
	}

	/**
	 * Function to get all the menu options that are related to a specific policy
	 * 
	 * @param policy The Policy for which the menu entries are to be retrieved.
	 * 
	 * @return The Message which contains the menu optinos that are associated with the policy
	 */
	public USMMessage getPermissionsForPolicy(PAPolicyId policy)	throws BcbSecurityException, RemoteException {
		LOGGER.debug(" getMenuOptionsForPolicy() ENTRY");
		ISecurityPolicyAdministrationPrivateFacade objSecurityProvider = getPolicyAdministrationBean();
		LOGGER.debug(" getMenuOptionsForPolicy() EXIT");
		return objSecurityProvider.getPermissions(USMUtility.getInstance().getSessionContext(), policy);
	}

	/**
	 * Function to modify a policy
	 * @param p_Policy The policy Object which has to be modified.
	 * 
	 * @return The Message which contains the result of the operation
	 * for the modification of a policy
	 */
	public USMMessage modifyPolicy(PAPolicyData p_Policy) throws BcbSecurityException, RemoteException {
		LOGGER.debug(" modifyPolicy() ENTRY");

		ISecurityPolicyAdministrationPrivateFacade objSecurityProvider = getPolicyAdministrationBean();
		LOGGER.debug(" modifyPolicy() EXIT");
		return objSecurityProvider.modifyPolicy(USMUtility.getInstance().getSessionContext(), p_Policy);
	}

	/**
	 * Helper function to retrieve the Bean object/
	 * @return The Bean object that will do the operations.
	 */
	private ISecurityPolicyAdministrationPrivateFacade getPolicyAdministrationBean() {
		USMServiceLocator serviceLocator = USMServiceLocator.getInstance();
		ISecurityPolicyAdministrationPrivateFacade fcd = null;
		LOGGER.debug(" getPolicyAdministrationBean() ENTRY");
		try {
			fcd = serviceLocator.getSecurityPolicyAdministrationPrivateFacade();
		} catch (UnexpectedException e) {
			LOGGER.error("Exception :", e);
		}
		LOGGER.debug(" getPolicyAdministrationBean() EXIT");
		return fcd;
	}

	/**
	 * Function to retrive all the permissions that are available within USM
	 * 
	 * @return The Message which contains the menu options that are configured within USM
	 */
	public USMMessage getPermissions() throws BcbSecurityException, RemoteException {
		LOGGER.info("getAllMenuOptions() ENTRY");
		ISecurityPolicyAdministrationPrivateFacade objSecurityProvider = getPolicyAdministrationBean();
		LOGGER.info("getAllMenuOptions() EXIT");
		return objSecurityProvider.getPermissions(USMUtility.getInstance().getSessionContext());

	}

	/**
	 *
	 * @param policyNameAndID - The policy which the information belongs
	 * @return - The message which contains all the permissions used by the policy and the list of available permissions
	 * @throws BcbSecurityException
	 * @throws RemoteException
	 */
	public USMMessage getPolicyInformation(PAPolicyId policyNameAndID) throws BcbSecurityException, RemoteException {
		LOGGER.debug("getPolicyInformation() Entry");
		ISecurityPolicyAdministrationPrivateFacade objSecurityProvider = getPolicyAdministrationBean();
		LOGGER.debug("getPolicyInformation() Exit");
		return objSecurityProvider.getPolicyInformation(USMUtility.getInstance().getSessionContext(),policyNameAndID);
	}

	/**
	 * Function to create a policy
	 * 
	 * @param policy The Policy which has to be created.
	 * 
	 * @return The Message which contains the result of the operation of create.
	 */
	public USMMessage createPolicy(PAPolicyData policy) throws BcbSecurityException, RemoteException {
		LOGGER.info("createPolicy() Entry");
		ISecurityPolicyAdministrationPrivateFacade objSecurityProvider = getPolicyAdministrationBean();
		LOGGER.info("createPolicy() Exit");
		return objSecurityProvider.createPolicy(USMUtility.getInstance().getSessionContext(), policy);
	}

}
