/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   UAClientLifeCycleController
 * Author:      Babu B, Jogender
 * Substitute	Vinay Purohit
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER.VIEW
 *       : TNMS.DX2.SM.FORCE_LOGOFF
 *       : TNMS.DX2.SM.USER.CREATE
 *       : TNMS.DX2.SM.USER.CONFIGURE
 * 	     : TNMS.DX2.SM.USER.ASSIGN
 *       : TNMS.DX2.SM.USER.STATUS
 *       : TNMS.DX2.SM.USER_GROUP.VIEW
 *       : TNMS.DX2.SM.USER_GROUP.CONFIGURE
 *       : TNMS.DX2.SM.USER_GROUP.CREATE
 *       : TNMS.DX2.SM.USER_GROUP.ASSIGN
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration;

import com.ossnms.bicnet.securitymanagement.client.basic.USMClientLifeCycleControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.useradministration.useradmin.UAUserAdministrationCommand;
import com.ossnms.bicnet.securitymanagement.client.useradministration.usercreate.UACreateUserCommand;
import com.ossnms.bicnet.securitymanagement.client.useradministration.usergroupadmin.UAUserGroupAdministrationCommand;
import com.ossnms.bicnet.securitymanagement.client.useradministration.usergroupcreate.UAUserGroupCreateCommand;
import com.ossnms.bicnet.securitymanagement.client.useradministration.usergroupmodify.UAUserGroupModifyCommand;
import com.ossnms.bicnet.securitymanagement.client.useradministration.usermodify.UAModifyUserCommand;
import org.apache.log4j.Logger;

/**
 * This class is the life cycle controller which creates the UI command object(s)
 * during client startup.
 *
 */
public final class UAClientLifeCycleController
	implements USMClientLifeCycleControllerIfc {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(UAClientLifeCycleController.class);

	/**
	 * Data member to hold self reference 
	 */
	private static UAClientLifeCycleController instance =
		new UAClientLifeCycleController();

	/**
	 * This is the default controller
	 *
	 */
	private UAClientLifeCycleController() {

	}

	/**
	 * This method returns a static instance of this class
	 *
	 * @return USMLifeCycleController - The singleton object
	 */
	public static UAClientLifeCycleController getInstance() {
		LOGGER.debug("Entering/Exiting getInstance");
		return instance;
	}

	/**
	 * Initializes the lifecycle controller instance.
	 * Called by the USM framework.
	 *
	 * @see com.ossnms.bicnet.securitymanagement.common.basic.USMLifeCycleController#initialize()
	 */
	@Override
    public boolean initialize() {
		LOGGER.debug("Entering initialize");
		boolean bUGRegistered = initializeUGCmd();
		boolean bUARegistered = initializeUACmd();
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting initialize. Returning Result : " + true);
		}
		return bUGRegistered && bUARegistered;

	}
	/**
	 * Registers the user group commands
	 * @return boolean - If user Group admin,
	 *                   create and modify command registered 
	 *                   successfully then return true otherwise false
	 */
	private boolean initializeUGCmd() {
		LOGGER.debug("Entering initializeUGCmd()");
		//		User Group commands
		UAUserGroupAdministrationCommand cmdUGAdminCmd =
			new UAUserGroupAdministrationCommand();
		boolean bUGAdminInitialized = cmdUGAdminCmd.isCmdHndlrRegistered();
		UAUserGroupCreateCommand cmdUGCreate = new UAUserGroupCreateCommand();
		boolean bUGCreateInitialized = cmdUGCreate.isCmdHndlrRegistered();
		UAUserGroupModifyCommand cmdUGModify = new UAUserGroupModifyCommand();
		boolean bUGModifyInitialized = cmdUGModify.isCmdHndlrRegistered();
		LOGGER.debug("Exiting initializeUGCmd()");
		return bUGAdminInitialized
			&& bUGCreateInitialized
			&& bUGModifyInitialized;
	}

	/**
		 * Registers the user admin commands
		 * @return boolean - If user Group admin,
		 *                   create and modify command registered 
		 *                   successfully then return true otherwise false
		 */
	private boolean initializeUACmd() {
		LOGGER.debug("Entering initializeUACmd()");
		//		User commands
		UAUserAdministrationCommand cmdUserAdmin = new UAUserAdministrationCommand();
		boolean bUAAdminInitialized = cmdUserAdmin.isCmdHndlrRegistered();

		UACreateUserCommand cmdCreateUser = new UACreateUserCommand();
		boolean bUACreateInitialized = cmdCreateUser.isCmdHndlrRegistered();

		UAModifyUserCommand cmdModifyUser = new UAModifyUserCommand();
		boolean bUAModifyInitialized = cmdModifyUser.isCmdHndlrRegistered();

		LOGGER.debug("Exiting initializeUACmd()");
		return bUAAdminInitialized
			&& bUACreateInitialized
			&& bUAModifyInitialized;
	}

	/**
	 * 
	 * Cleans up the lifecycle controller instance.
	 * Called by the USM framework.
	 *
	 * @see com.ossnms.bicnet.securitymanagement.common.basic.USMLifeCycleController#cleanup()
	 */
	@Override
    public boolean cleanup() {
		return false;
	}

}
