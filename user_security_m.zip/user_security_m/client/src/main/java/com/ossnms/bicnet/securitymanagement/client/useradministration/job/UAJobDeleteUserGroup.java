/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   UAJobDeleteUserGroup
 * Author:      Jogender
 * Substitute	Babu B
 * Created on	12-09-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER_GROUP.CONFIGURE 
 *       : TNMS.DX2.SM.USER_GROUP.VIEW
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration.job;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.useradministration.UADelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import org.apache.log4j.Logger;

import java.util.List;
/**
 * This class represents a job that is responsible for the deletion of the user
 * group
 */
public class UAJobDeleteUserGroup extends USMJob {
	/**
	 * Data member to hold user group information
	 */
	List mUserGroups = null;
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(UAJobDeleteUserGroup.class);

	/**
	 * This is the constructor
	 * 
	 * @param p_User -
	 *            The user group that is to be deleted
	 * @param pJobOwner -
	 *            The controller associated with the job
	 */
	public UAJobDeleteUserGroup(
		USMControllerIfc pJobOwner,
		List p_usergroups) {
		super(
			UAMessageType.S_UG_REQ_REMOVE_USER_GROUP,
			USMCommonStrings.EMPTY,
			p_usergroups.toString(),
			pJobOwner);

		String str = USMCommonStrings.EMPTY;
		if (p_usergroups.size() == 1) {
			Object[] arr = { p_usergroups.get(0)};
			str =
				USMStringTable
					.IDS_UG_JOB_DELETE_USERGROUP_Single
					.getFormatedMessage(
					arr);
		} else {
			Object[] arr = { p_usergroups.size()};
			str =
				USMStringTable
					.IDS_UG_JOB_DELETE_USERGROUP_Multi
					.getFormatedMessage(
					arr);
		}
		setName(str);
		mUserGroups = p_usergroups;
	}

	/**
	 * Executes the given job
	 *
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob#executeJob()
	 */
	@Override
    public USMMessage executeJob() {
		LOGGER.debug("executeJob() Enter");
		USMMessage msg = new UADelegate().deleteUserGroup(mUserGroups);
		LOGGER.debug("executeJob() Exit");
		return msg;
	}

}
