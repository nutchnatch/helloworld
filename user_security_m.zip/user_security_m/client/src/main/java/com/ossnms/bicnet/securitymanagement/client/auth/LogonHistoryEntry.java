package com.ossnms.bicnet.securitymanagement.client.auth;

import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;

import java.io.Serializable;

/**
 * Entries for the logon window server history.
 * Each entry is composed of a string specifying the server and an optional server label.
 * Valid labels are ACTIVE or STANDBY
 */
public class LogonHistoryEntry implements Serializable {

    private static final long serialVersionUID = 1L;

    private final String server;
    private ServerLabel serverLabel;

    public LogonHistoryEntry(String server, ServerLabel serverLabel) {
        this.server = server;
        this.serverLabel = serverLabel;
    }

    public String getServer() {
        return server;
    }

    public ServerLabel getServerLabel() {
        return serverLabel;
    }

    public void setServerLabel(ServerLabel serverLabel) {
        this.serverLabel = serverLabel;
    }

    @Override
    public String toString() {
        return server;
    }

    public enum ServerLabel {
        ACTIVE(USMStringTable.IDS_AA_SERVER_HISTORY_ACTIVE_SERVER.toString()),
        STANDBY(USMStringTable.IDS_AA_SERVER_HISTORY_STANDBY_SERVER.toString());

        private final String guiLabel;

        ServerLabel(String guiLabel) {
            this.guiLabel = guiLabel;
        }

        @Override
        public String toString() {
            return guiLabel;
        }
    }
}
