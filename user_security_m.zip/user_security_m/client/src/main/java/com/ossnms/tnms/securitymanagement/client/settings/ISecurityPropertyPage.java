/*
 * Copyright Coriant 2013
 * The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
 *
 */
package com.ossnms.tnms.securitymanagement.client.settings;

import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSettingsPropertyPage;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDataChangeListener;
import com.ossnms.tools.jfx.JfxUtils;

import javax.swing.event.ChangeListener;
import java.awt.*;


/**
 *
 */
interface ISecurityPropertyPage extends
        BiCNetPluginSettingsPropertyPage,
        IFrameworkDataChangeListener,
        ChangeListener {

    /**
     * Updates the data object with the page configuration
     * 
     * @param data The data object to be updated (cannot be null).
     */
    void saveData(SecuritySettingsData data);

    /**
     * Registers a change listener
     *
     * @param listener the {@link ChangeListener} instance to register
     */
    void addChangeListener(ChangeListener listener);

    /**
     *
     * @param x
     * @param y
     * @param width
     * @return
     */
    default GridBagConstraints getConstraints(int x, int y, int width, boolean firstElement, boolean fullWidth) {
        return new GridBagConstraints(
                x,
                y,
                width,
                1,
                fullWidth ? 1.0 : 0.0,
                0.0,
                GridBagConstraints.BASELINE_LEADING,
                fullWidth ? GridBagConstraints.HORIZONTAL : GridBagConstraints.NONE,
                new Insets(firstElement ? JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS : 0, JfxUtils.DEFAULT_MARGIN, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, JfxUtils.DEFAULT_MARGIN),
                0,
                0
        );
    }

    /**
     *
     * @param x
     * @param y
     * @param width
     * @param firstElement
     * @return
     */
    default GridBagConstraints getConstraints(int x, int y, int width, boolean firstElement) {
        return getConstraints(x, y, width, firstElement, false);
    }

    /**
     *
     * @param x
     * @param y
     * @param width
     * @return
     */
    default GridBagConstraints getConstraints(int x, int y, int width) {
        return getConstraints(x, y, width, false, false);
    }

    /**
     *
     * @param x
     * @param y
     * @param firstElement
     * @return
     */
    default GridBagConstraints getConstraints(int x, int y, boolean firstElement){
        return getConstraints(x, y, 1, firstElement, false);
    }

    /**
     *
     * @param x
     * @param y
     * @return
     */
    default GridBagConstraints getConstraints(int x, int y) {
        return getConstraints(x, y, 1);
    }

}
