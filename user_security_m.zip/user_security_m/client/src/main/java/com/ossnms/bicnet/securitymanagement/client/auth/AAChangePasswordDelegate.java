/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-Feb-2005	Muyeen Munaver	CF001435 - Trace parameters for function calls at all places
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.auth;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.auth.AAChangePasswordDetails;
import com.ossnms.bicnet.securitymanagement.common.auth.AAUserMessages;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityAuthenticationPrivateFacade;
import com.ossnms.bicnet.util.encode.HashEncode;
import org.apache.log4j.Logger;

/**
 * This is the main business delegate component which controls the change
 * password operation on the client side to delegate server side. It provides decoupling beween
 * server and client components changes 
*/
public class AAChangePasswordDelegate {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(AAChangePasswordDelegate.class);

    /**
     * Default constructor
     */
    public AAChangePasswordDelegate() {
		LOGGER.debug(" AAChangePasswordDelegate() 	Entry");
		//m_usmAuthentication = getAuthenticationBean();
		LOGGER.debug(" AAChangePasswordDelegate() 	Exit");
	}

	/**
		 * It calls to remote interface to retrieve the all general setting data
		 *
		 * @param  userDetails
		 * @return GSGeneralSettingData
	*/
	public USMMessage changePassword(AAChangePasswordDetails userDetails)
		throws BcbSecurityException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("changePassword(" + userDetails + ") Entry");
		}
		ISessionContext objSessionContextImpl =
			USMUtility.getInstance().getSessionContext();
		//Fault ID- 34 -Throwing exception on pressing ok in change password view
		final ISecurityAuthenticationPrivateFacade usmAuthentication =
			AALoginBusinessDelegate.getPrivateFacade();
		//	getAuthenticationBean();
		USMMessage msg = null;
		
		
		//EncodePassword
		if (usmAuthentication != null) {
			final byte [] salt = usmAuthentication.getUserPasswordSalt(userDetails.getUserName());
			String oldPasswordEncoded = HashEncode.encodePassword(userDetails.getOldPassword(), salt);
			String newPasswordEncoded = HashEncode.encodePassword(userDetails.getNewPassword(), salt);

			userDetails.setOldPassword(oldPasswordEncoded);
			userDetails.setNewPassword(newPasswordEncoded);

			msg = usmAuthentication.changePassword(
					objSessionContextImpl,
					userDetails);
			
			updateReloginController(msg, newPasswordEncoded);
		}
		LOGGER.debug("changePassword Exit");
		return msg;
	}

	private void updateReloginController(USMMessage msg, String newPasswordEncoded) {
		Integer passwordChangeResultCode = msg.copy().popInteger();
		if (AAUserMessages.AA_NO_ERROR.equals(passwordChangeResultCode)) {
			ReloginController.getInstance().passwordChanged(newPasswordEncoded);
		}
	}
}