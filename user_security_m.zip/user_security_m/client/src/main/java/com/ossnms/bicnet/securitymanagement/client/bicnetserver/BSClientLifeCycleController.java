/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	BSClientLifeCycleController
 * Author      	Muyeen M
 * Substitute	Asifulla Khan
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_OBJECTS
 *       : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_ACL 
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.VIEW
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.SYNCH_SECURITY
 * 		 : TNMS.DX2.SM.APPLICATION_SERVER.INSERT
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 16-02-2005	Muyeen Munaver  CF000060-01   CF USM GUI Requirements
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.bicnetserver;

import com.ossnms.bicnet.securitymanagement.client.basic.USMClientLifeCycleControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.bicnetserver.configuration.BSCFCommand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class is responsible for the initialization and cleanup activities to be
 * performed by the subsystem BS. These activities are performed at the start of
 * the Client process and at the closure of the Client process. This
 * class is responsible for registering the Commands. It
 * has to register 2 Commands -
 * 
 * 1. BSCFCommand
 * 2. BSCFPropertiesCommand
 * 
 */
public final class BSClientLifeCycleController implements USMClientLifeCycleControllerIfc {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(BSClientLifeCycleController.class);

	/**
	 * Static data member to hold the static data object
	 */
	private static BSClientLifeCycleController theInstance = new BSClientLifeCycleController();

	/**
	 * Constructor
	 */
	private BSClientLifeCycleController() {
		LOGGER.debug("Entering constructor");
		LOGGER.debug("Exiting constructor");
	}

	/**
	 * This method is invoked to initialize the BS subsystem in the Client start up flow.
	 * The initialization includes -
	 * Creation and registration of the different Commands that are associated with
	 * the subsystem BS. These include  -
	 * 1. BSAppServerCommand
	 * 2. BSServerPropertiesCommand
	 * 
	 * @return boolean Indicates whether to proceed or not. True indicates error
	 * free initialization.
	 */
	@Override
    public boolean initialize() {
		LOGGER.debug("Entering initialize");

		BSCFCommand cmdCF = new BSCFCommand();
		boolean bCFInitialized = cmdCF.isCmdHndlrRegistered();

		LOGGER.debug("Exiting initialize. Result of BSCFCommand registration : {}", bCFInitialized);
		return bCFInitialized;
	}

	/**
	 * This method is invoked to cleanup the BS subsystem in the Client shut down flow. 
	 * 
	 * @return boolean Indicates whether the cleanup was done or not. True indicates
	 * successful cleanup.
	 */
	@Override
    public boolean cleanup() {
		LOGGER.debug("Entering cleanup");
		LOGGER.debug("Exiting cleanup. Returning : " + false);
		return false;
	}

	/**
	 * Static function to retrieve the singleton instance of the
	 * BSClientLifeCycleController.
	 * 
	 * @return BSClientLifeCycleController The singleton object.
	 */
	public static BSClientLifeCycleController getInstance() {
		return theInstance;
	}
}
