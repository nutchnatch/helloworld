/*
 * Copyright Coriant 2013
 * The reproduction, transmission or use of this document or its contents
 * is not permitted without express written authorization.
 * Offenders will be liable for damages.
 * All rights, including rights created by patent grant or
 * registration of a utility model or design, are reserved.
 * Modifications made to this document are restricted to authorized personnel only.
 * Technical specifications and features are binding only when specifically
 * and expressly agreed upon in a written contract.
 *
 */
package com.ossnms.tnms.securitymanagement.client.settings;

import com.coriant.widgets.spinner.SpinnerIntegerModel;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientLogEntry;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientLogSeverity;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPageSite;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSettingsPropertyPage;
import com.ossnms.bicnet.bcb.plugin.DefaultPluginClientLogEntry;
import com.ossnms.bicnet.framework.client.notificationpopup.NotificationPopupDetails;
import com.ossnms.bicnet.framework.client.notificationpopup.NotificationPopupDetails.OpStatus;
import com.ossnms.bicnet.framework.client.notificationpopup.NotificationPopupManager;
import com.ossnms.bicnet.securitymanagement.client.SMSettingsProperties;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.client.common.USMTextField;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.general.GSConstants;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.bicnet.securitymanagement.common.general.ResponseMessage;
import com.ossnms.bicnet.securitymanagement.common.general.sso.SSOConfigurationData;
import com.ossnms.tnms.securitymanagement.client.util.USMMessages;
import com.ossnms.tnms.securitymanagement.client.util.USMResourceBundleConstants;
import com.ossnms.tools.jfx.JfxCheckBoxTitlePanel;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxCheckBox;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxSpinner;
import org.apache.commons.validator.routines.IntegerValidator;
import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class SecuritySSOPropertyPage extends JPanel implements ISecurityPropertyPage {

    private static final long serialVersionUID = -2161787957134798085L;

    private static final Logger LOGGER = Logger.getLogger(SecuritySSOPropertyPage.class);

    private final JfxLabel domainNameLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_DOMAIN_NAME);

    private final JfxLabel domainNameServerLabel = new JfxLabel(USMStringTable.IDS_AA_WINDOW_CONTROL_DOMAIN_NAME_SERVER);

    private final JfxLabel activeDirectoryLDAPPortLabel = new JfxLabel(USMStringTable.IDS_SS_AD_LDAP_PORT_LABEL);

    private final JfxLabel activeDirectoryLDAPPortRange = new JfxLabel();

    private final SecuritySettingsDocument doc;

    private BiCNetPluginPropertyPageSite propertyPageSite;

    private JfxCheckBoxTitlePanel enableSSOCheckbox;

    private USMTextField domainNameField;

    private USMTextField domainNameServerField;

    private JfxCheckBox activeDirectoryLDAPPortCheckbox;

    private JfxSpinner activeDirectoryLDAPPortSpinner;

    private JPanel ssoPanel;

    private SpinnerIntegerModel activeDirectoryLDAPPortSpinnerModel;

    private JfxButton defaultButton = new JfxButton(JfxStringTable.IDS_Default);

    private final List<ChangeListener> changeListeners = new ArrayList<>();

    private boolean requiredUpdate;

    public SecuritySSOPropertyPage(SecuritySettingsDocument doc) {
        this.doc = doc;
        initLayout();
        initListeners();

        enableSSO(ssoPanel, enableSSOCheckbox.isSelected());

        setGuiNames();
    }

    private void initListeners() {
        enableSSOCheckbox.addActionListener(e -> SecuritySSOPropertyPage.this.stateChanged(new ChangeEvent(enableSSOCheckbox)));

        activeDirectoryLDAPPortCheckbox.addActionListener(e -> SecuritySSOPropertyPage.this.stateChanged(new ChangeEvent(activeDirectoryLDAPPortCheckbox)));

        activeDirectoryLDAPPortSpinner.addChangeListener(this);
        DocumentListener documentListener = new SSODocumentListener();
        domainNameField.addDocumentListener(documentListener);
        domainNameServerField.addDocumentListener(documentListener);

        defaultButton.addActionListener(e -> {
            enableSSOCheckbox.setSelected(false);
            activeDirectoryLDAPPortCheckbox.setSelected(true);
            activeDirectoryLDAPPortSpinner.setValue(GSConstants.S_AD_LDAP_PORT);
            domainNameField.setText("");
            domainNameServerField.setText("");

            enableSSO(ssoPanel, enableSSOCheckbox.isSelected());

            if (propertyPageSite != null) {
                propertyPageSite.eventPageStatusChanged(SecuritySSOPropertyPage.this);
            }
        });
    }

    private void initLayout() {
        setLayout(new GridBagLayout());
        setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);

        createSsoPanel();

        enableSSOCheckbox = new JfxCheckBoxTitlePanel(USMStringTable.IDS_SS_AD_LDAP_ENABLE_SSO_CHECKBOX, ssoPanel);

        add(enableSSOCheckbox, new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        add(defaultButton, new GridBagConstraints(0, 1, 1, 1, 0.0, 1.0, GridBagConstraints.SOUTHWEST, GridBagConstraints.NONE, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0), 0, 0));
    }


    private JPanel createSsoPanel() {
        ssoPanel = new JPanel(new GridBagLayout());

        int row = 0;
        initAndAddDomainName(ssoPanel, row++);
        initAndAddNameServer(ssoPanel, row++);
        initAndAddLDAPPort(ssoPanel, row++);

        ssoPanel.add(createLdapPanel(),
                new GridBagConstraints(0, row, GridBagConstraints.REMAINDER, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, JfxUtils.FIELD_INDENTATION, 0, 0), 0, 0));

        return ssoPanel;
    }

    protected void enableSSO(Object object, boolean enableSSO) {
        if (object instanceof Container) {
            Container c = (Container) object;
            Component[] components = c.getComponents();
            for (Component component : components) {
                enableSSO(component, enableSSO);
                component.setEnabled(enableSSO);
            }
        } else {
            if (object instanceof Component) {
                Component component = (Component) object;
                component.setEnabled(enableSSO);
            }
        }
        if (enableSSO) {
            validateLDAPPort(this.activeDirectoryLDAPPortCheckbox.isSelected());
        }
    }

    private void validateLDAPPort(boolean checked) {
        activeDirectoryLDAPPortSpinnerModel.setMinimum(checked ? GSConstants.S_AD_LDAP_PORT : GSConstants.S_AD_LDAP_PORT_MIN);
        activeDirectoryLDAPPortSpinner.setEnabled(!checked);
        
        if(checked){
        	activeDirectoryLDAPPortSpinner.setValue(Integer.valueOf(GSConstants.S_AD_LDAP_PORT));	
        }
        
    }

    private void initAndAddLDAPPort(JPanel panel, int row) {
        activeDirectoryLDAPPortCheckbox = new JfxCheckBox(USMStringTable.IDS_SS_AD_LDAP_PORT_CHECKBOX);
        activeDirectoryLDAPPortCheckbox.setSelected(true);
        activeDirectoryLDAPPortCheckbox.setMnemonic(USMStringTable.IDS_SS_AD_LDAP_PORT_CHECKBOX.getMnemonic());
        panel.add(activeDirectoryLDAPPortCheckbox, new GridBagConstraints(0, row, GridBagConstraints.REMAINDER, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    }

    private void initAndAddNameServer(JPanel panel, int row) {
        domainNameServerField = new USMTextField();
        domainNameServerLabel.setLabelAndMnemonicFor(domainNameServerField);
        domainNameServerField.setToolTipText(USMStringTable.IDS_AA_WINDOW_CONTROL_TOOLTIP_DOMAINNAMESERVER);
        domainNameServerField.setMandatoryEntry(true);
        panel.add(domainNameServerLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.DEFAULT_MARGIN), 0, 0));
        panel.add(domainNameServerField, new GridBagConstraints(1, row, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
    }

    private void initAndAddDomainName(JPanel panel, int row) {
        domainNameField = new USMTextField();
        domainNameLabel.setLabelAndMnemonicFor(domainNameField);
        domainNameField.setToolTipText(USMStringTable.IDS_AA_WINDOW_CONTROL_TOOLTIP_DOMAINNAME);
        domainNameField.setMandatoryEntry(true);
        panel.add(domainNameLabel, new GridBagConstraints(0, row, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.DEFAULT_MARGIN), 0, 0));
        panel.add(domainNameField, new GridBagConstraints(1, row, 1, 1, 1.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0), 0, 0));
    }

    private JPanel createLdapPanel() {
        JPanel ldapPortPanel = new JPanel(new GridBagLayout());

        activeDirectoryLDAPPortSpinnerModel = new SpinnerIntegerModel(GSConstants.S_AD_LDAP_PORT, GSConstants.S_AD_LDAP_PORT, GSConstants.S_AD_LDAP_PORT_MAX, 1);
        activeDirectoryLDAPPortSpinner = new JfxSpinner(activeDirectoryLDAPPortSpinnerModel);
        activeDirectoryLDAPPortLabel.setLabelAndMnemonicFor(activeDirectoryLDAPPortSpinner);
        activeDirectoryLDAPPortSpinner.setToolTipText(USMStringTable.IDS_AA_WINDOW_CONTROL_TOOLTIP_AD_LDAP_PORT);
        activeDirectoryLDAPPortRange.setText(USMMessages.getInstance().getFormatedString(USMResourceBundleConstants.SECURITY_SETTINGS_RANGE, new Object[] { String.valueOf(GSConstants.S_AD_LDAP_PORT_MIN), String.valueOf(GSConstants.S_AD_LDAP_PORT_MAX) }));

        ldapPortPanel.add(activeDirectoryLDAPPortLabel, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.NONE, new Insets(0, 0, 0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD), 0, 0));
        ldapPortPanel.add(activeDirectoryLDAPPortSpinner, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
        ldapPortPanel.add(activeDirectoryLDAPPortRange, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0, GridBagConstraints.BASELINE_LEADING, GridBagConstraints.HORIZONTAL, new Insets(0, JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_CAPTION_AND_FIELD, 0, 0), 0, 0));
        return ldapPortPanel;
    }

    /**
     * Helper function that is used to set the Names of all the editable
     * components within the Window.
     *
     * Strings in this function are not to be Internationalized.
     */
    private void setGuiNames() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setGuiNames() Entry");
        }

        this.enableSSOCheckbox.setName("SSO Panel");
        this.enableSSOCheckbox.getCheckBox().setName("Enable");      
        this.domainNameField.setName("DomainName");
        this.domainNameServerField.setName("DomainNameServer");
        this.activeDirectoryLDAPPortSpinner.setName("Port");

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("setGuiNames() Exit");
        }
    }

    @Override
    public void actionApply() {
        // Do nothing
    }

    @Override
    public void actionCancel() {
        // Do nothing
    }

    @Override
    public void eventClosing() {
        // Do nothing
    }

    @Override
    public void eventOpened() {
        // Do nothing
    }

    @Override
    public JComponent getComponent() {
        return this;
    }

    @Override
    public String getID() {
        return USMCommandID.S_UI_ID_SECURITY_SETTINGS_SSO.getMenuString();
    }

    @Override
    public String getTitle() {
        return USMStringTable.IDS_AA_SSO_CONFIGURATION_GROUP_LABEL.toString();
    }

    @Override
    public boolean isPageDirty() {
        GSGeneralSettingData savedSettings = doc.getGeneralSettingsData();

        boolean retValue = (savedSettings == null);
        retValue = retValue || (savedSettings.getSSOConfigurationData() == null);
        retValue = retValue || (savedSettings.getSSOConfigurationData().isEnabled() != enableSSOCheckbox.isSelected());
        retValue = retValue || (enableSSOCheckbox.isSelected() && areSSOSettingsDirty(savedSettings.getSSOConfigurationData()));

        return retValue;
    }

    private boolean areSSOSettingsDirty(SSOConfigurationData ssoConfigData) {
        if (!ssoConfigData.getDomainName().equals(domainNameField.getText())) {
            return true;
        }
        if (!ssoConfigData.getDomainServer().equals(domainNameServerField.getText())) {
            return true;
        }
        if (!ssoConfigData.getLdapTcpPort().equals(String.valueOf(activeDirectoryLDAPPortSpinner.getValue()))) {
            return true;
        }

        return false;
    }

    @Override
    public void setObjects(IManagedObjectMarkable[] objects) {
        // Do nothing
    }

    @Override
    public void setPageSite(BiCNetPluginPropertyPageSite site) {
        this.propertyPageSite = site;
    }

    @Override
    public void setReadOnly(boolean arg0) {
        // Do nothing
    }

    @Override
    public void update() {
    }

    @Override
    public void validateInput() throws BiCNetPluginException {
        String domainName = domainNameField.getText();
        String domainServer = domainNameServerField.getText();
        String ldapPort = String.valueOf(activeDirectoryLDAPPortSpinner.getValue());
        boolean ssoCheckboxSelected = enableSSOCheckbox.isSelected();

        if (ssoCheckboxSelected && (domainServer.isEmpty() || domainName.isEmpty() || ldapPort.isEmpty())) {
            throw new BiCNetPluginException(USMStringTable.IDS_AA_DIALOG_MESSAGE_EMPTY_SSO_CONFIG.getText());
        }
    }

    @Override
    public BiCNetPluginSettingsPropertyPage[] getChildPages() {
        return null;
    }

    @Override
    public boolean isEnabled(IManagedObject[] arg0) {
        return USMUtility.getInstance().checkIfOperatorHasPermission(USMCommandID.S_UI_ID_GENERAL_SECURITY_SETTINGS.getMenuString());
    }

    /**
     * ***********************************************************************
     * Sets the interface of the enclosing frame provided by the application.
     * This method is called before the view is displayed. The view should store
     * the given reference for later use.
     *
     * @param frame
     *            Reference to plug-in frame. *
     * ***********************************************************************
     */
    @Override
    public void setFrame(BiCNetPluginFrame frame) {

    }

    @Override
    public void updateData(Object key) {
        if (key instanceof GSGeneralSettingData) {
            GSGeneralSettingData data = (GSGeneralSettingData) key;

            SSOConfigurationData ssoData = data.getSSOConfigurationData();

            if (!ssoData.getDomainName().startsWith("<")) {
                domainNameField.setText(ssoData.getDomainName());
                domainNameField.setUnmodifiedValue(ssoData.getDomainName());

                domainNameServerField.setText(ssoData.getDomainServer());
                domainNameServerField.setUnmodifiedValue(ssoData.getDomainServer());
            }
            Integer ldapPort = IntegerValidator.getInstance().validate(ssoData.getLdapTcpPort());
            if (ldapPort == null) {
                ldapPort = GSConstants.S_AD_LDAP_PORT;
            }

            boolean flag = ldapPort == GSConstants.S_AD_LDAP_PORT;

            activeDirectoryLDAPPortCheckbox.setSelected(flag);
            activeDirectoryLDAPPortCheckbox.setUnmodifiedValue(flag);

            activeDirectoryLDAPPortSpinner.setEnabled(!flag);
           
            activeDirectoryLDAPPortSpinner.setValue(ldapPort);
            activeDirectoryLDAPPortSpinner.setUnmodifiedValue(ldapPort);
            
            activeDirectoryLDAPPortSpinnerModel.setValue(ldapPort);

            enableSSOCheckbox.setSelected(ssoData.isEnabled());
            enableSSOCheckbox.setUnmodifiedValue(ssoData.isEnabled());

            enableSSO(ssoPanel, ssoData.isEnabled());

        } else if (key instanceof ResponseMessage) {
            handleResponseMessage((ResponseMessage) key);
        }
    }

    /**
     *
     * @param msg message
     */
    private void handleResponseMessage(ResponseMessage msg) {
        if (this.enableSSOCheckbox.isSelected() && requiredUpdate) {

            OpStatus status;
            BiCNetPluginClientLogSeverity severity;

            switch (msg.getType()) {
                case ERROR_MESSAGE:
                    status = OpStatus.FAILED;
                    severity = BiCNetPluginClientLogSeverity.ERROR;
                    break;
                case WARNING_MESSAGE:
                    status = OpStatus.WITH_WARNINGS;
                    severity = BiCNetPluginClientLogSeverity.WARNING;
                    break;
                default:
                    status = OpStatus.SUCCESSFUL;
                    severity = BiCNetPluginClientLogSeverity.INFORMATION;
                    break;
            }

            String msgText = USMCommonStrings.IDS_AA_DIALOG_MESSAGE_SSO_CONFIG_SAVED;
            NotificationPopupDetails popupDetails = new NotificationPopupDetails(status, msgText, BiCNetComponentType.SECURITY_MANAGER, "");
            popupDetails.setTitle(USMStringTable.IDS_AA_WINDOW_SSO_SETTINGS.toString());
            NotificationPopupManager.getInstance().showPopup(popupDetails);

            BiCNetPluginClientLogEntry entry = new DefaultPluginClientLogEntry(severity, getTitle(), msgText);
            try {
                USMUtility.getInstance().getCfPluginSite().addClientLogEntry(entry);
            } catch (BiCNetPluginException e) {
                LOGGER.error("Unable to write to client log", e);
            }
        }
    }

    @Override
    public void saveData(SecuritySettingsData data) {
        String domainName = domainNameField.getText();
        String domainServer = domainNameServerField.getText();
        String ldapPort = String.valueOf(activeDirectoryLDAPPortSpinner.getValue());
        String tnmsPrincipalName = SMSettingsProperties.getTnmsPrincipalName();
        boolean ssoCheckboxSelected = enableSSOCheckbox.isSelected();

        SSOConfigurationData ssoConfigData = new SSOConfigurationData(domainName, domainServer, ldapPort, tnmsPrincipalName, ssoCheckboxSelected);
        data.getData().setSSOConfigurationData(ssoConfigData);
    }

    /**
     * Add listener to listener list.
     *
     * @param listener
     *            listener
     */
    public void addChangeListener(ChangeListener listener) {
        changeListeners.add(listener);
    }

    @Override
    public void stateChanged(ChangeEvent e) {
        if (e != null) {
            if (e.getSource().equals(enableSSOCheckbox)) {
                enableSSO(ssoPanel, enableSSOCheckbox.isSelected());
            } else if (e.getSource().equals(activeDirectoryLDAPPortCheckbox)) {
                validateLDAPPort(activeDirectoryLDAPPortCheckbox.isSelected());
            }
        }

        requiredUpdate = isPageDirty();

        if (propertyPageSite != null) {
            propertyPageSite.eventPageStatusChanged(this);
        }

        for (ChangeListener listener : changeListeners) {
            listener.stateChanged(null);
        }
    }

    private final class SSODocumentListener implements DocumentListener {

        @Override
        public void removeUpdate(DocumentEvent e) {
            stateChanged(null);
        }

        @Override
        public void insertUpdate(DocumentEvent e) {
            stateChanged(null);
        }

        @Override
        public void changedUpdate(DocumentEvent e) {
            stateChanged(null);
        }
    }
}