package com.ossnms.bicnet.securitymanagement.client.policy.jobs;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.policy.PABusinessDelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.policy.PAMessageType;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import org.apache.log4j.Logger;

import java.rmi.RemoteException;

/**
 *
 */
public class PAJobGetPermissionsForPolicy extends USMJob{

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER =
            Logger.getLogger(PAJobGetPermissionsForPolicy.class);

    /**
     * Data member hold the Policy object for which the menus are to be retrieved
     */
    private PAPolicyId policy;
    /**
     * Constructor
     *
     * @param jobOwner
     *      The Controller which is the owner of this Job
     * @param policy
     *      The Policy for which the menu's are to be retrieved
     */
    public PAJobGetPermissionsForPolicy(USMControllerIfc jobOwner, PAPolicyId policy) {

        super(
            PAMessageType.S_PA_REQ_GET_ALL_PERMISSIONS_FOR_POLICY,
            USMCommonStrings.EMPTY,
            USMCommonStrings.EMPTY,
            jobOwner);

        Object[] arr = { policy };
        //FIXME Change IDS_PA_JOB_RETRIEVE_MENU_FOR_POLICY to IDS_PA_JOB_RETRIEVE_PERMISSIONS_FOR_POLICY
        String str = USMStringTable.IDS_PA_JOB_RETRIEVE_PERMISSIONS_FOR_POLICY.getFormatedMessage(arr);
        setName(str);

        this.policy = policy;
        LOGGER.debug("PAJobGetAllPermissionsForPolicy() in the constructor");
    }

    @Override
    public USMMessage executeJob() throws BcbSecurityException {
        USMMessage msg = null;
        LOGGER.debug("executeJob()in the method");
        LOGGER.info("executeJob()in the method.. calling delegate");

        try {
            msg = new PABusinessDelegate().getPermissionsForPolicy(policy);
        }catch (RemoteException e) {
            LOGGER.error("executeJob() error in getting response");
        }
        return msg;
    }
}
