/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 11-Jan-2005	Jogi			CF000060 - CF USM GUI Requirements
 * 18-Jan-2005	Muyeen Munaver	CF00702 - The "OK" could became Grey in the "New User" window
 * 09-02-2005	Babu B          CF000060-01   CF USM GUI Requirements
 * 14-Feb-2005  Babu B          CF001293   Columns in security windows 
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.domain.mappings;

import com.coriant.widgets.table.PComboBoxRenderer;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.framework.client.jfx.FrameworkDialogApp;
import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMHelp;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.bicnet.securitymanagement.client.useradministration.usergroup.common.UAUserGroupDomainMappingProxy;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMenuNameList;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainData;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserGroup;
import com.ossnms.tools.jfx.JfxFormPanel;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.table.JfxTable;
import org.apache.log4j.Logger;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * This class acts as a user interface to view all the mappings
 */
public class DCDomainMappingView extends USMBaseViewWithButtons {

    /**
     * Generated Serial version id
     */
    private static final long serialVersionUID = 8273381713161881064L;

    /**
	 * Stores the list of policy id name
	 */
	private List lstPolicyIDToName = null;

	/**
	 * Hash map of policy id to policy name
	 */
	private Map mapPolicyIdToPolicyName;

	/**
	 * To make the second column a combo box
	 */
	private JComboBox policyComboBox;

	/**
	 * Model which holds the mapping for the current mappings
	 */
	private DCDomainMappingModel modelRights;

	/**
	 * Table to hold the mappings. Jfx helps in sorting and filtering
	 */
	private JfxTable tblRights;

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(DCDomainMappingView.class);

	/**
	 * This represents the domain object
	 */
	private DCDomainData domain;

	/**
	 * String for displaying NONE, otherwise, i have to keep calling this function
	 */
	public static final String NOACCESS = JfxStringTable.getString(USMStringTable.IDS_DC_NOACCESS);
	public static final String NOVISIBILITY = JfxStringTable.getString(USMStringTable.IDS_DC_NOVISIBILITY);

	private static final String mStrProfileName = "Assign Policy Window Settings";

	/**
	 * This is the constructor
	 * 
	 * @param p_domain -
	 *            Domain object to be displayed
	 */
	public DCDomainMappingView(DCDomainData p_domain) {

        super(null, getCommitButtons(), null,
                "com.ossnms.bicnet.securitymanagement.client.domain.mappings.DCDomainMappingView", JfxStringTable
                        .getString(USMStringTable.IDS_DC_MAPPING_TITLE) + " " + p_domain.getDomainName(), true, false,
                USMHelp.HID_ASSIGN_MAPPINGS);

        LOGGER.debug("DCDomainMappingView() - Enter");

		domain = p_domain;
		mapPolicyIdToPolicyName = new HashMap();

		initComponents();
		setNamesForTesting();

	//	m_AssocaitedClientController = new UAUserGroupDomainMappingProxy(this);
		//Create the controller and fetch the mappings for this domain
        //((UAUserGroupDomainMappingProxy) m_AssocaitedClientController).getMappingsForDomain(domain);

		LOGGER.debug("DCDomainMappingView() - Enter");
	}

    /**
     * Helper function that is used to set the Names of all the editable components within the Window.
     * Strings in this function are not to be Internationalized.
     */
    private void setNamesForTesting() {
        tblRights.setName("AssignPolicyForDomain");
    }

	/**
	 * Helper method to get the icons which need to be displayed
	 * @return Vector of icons for the domain mapping window
	 */
	private static List<USMButtonType> getCommitButtons() {

        // Static helper method, no state change, so no tracing entry currently
        List<USMButtonType> icons = new ArrayList<USMButtonType>();

        // Fault ID 43 - Provide Button Level Authorization for Domain Windows - Begin
        USMButtonType ok =
                new USMButtonType(USMButtonTypeEnum.BTN_TYPE_OK, USMMenuNameList.OPERATION_DOMAIN_ASSIGN_MAPPINGS_APPLY,
                        USMStringTable.IDS_DC_TOOLTIP_ASSIGN_POLICY_APPLY, true);
        icons.add(ok);
        // Fault ID 43 - Provide Button Level Authorization for Domain Windows - End
        icons.add(USMButtonType.BTN_TYPE_CANCEL);

        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Number of icons are " + icons.size());
        }
        return icons;
	}

    /**
     * Function to return the Icon that is associated with this View.
     * 
     * @return Icon The Icon that should be used
     */
    @Override
    public Icon getIcon() {
        return ResourcesIconFactory.ICON_TOOL_ASSIGN_16;
    }

	/**
	 * This method initializes the window
	 */
	private void initComponents() {

		LOGGER.debug("initComponents() - Enter");
		JfxFormPanel centerPanel = getPanelForPlacingDerviedControls();
		modelRights = new DCDomainMappingModel();
		tblRights = new JfxTable(modelRights);

		tblRights.setSortable(true);
		tblRights.setFilterable(false);
		tblRights.setHeaderToolTipsEnabled(true);

		tblRights.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		JScrollPane scrPaneRights = new javax.swing.JScrollPane(tblRights);
		scrPaneRights.setPreferredSize(new Dimension(250, 200));
		setPreferredSize(new Dimension(350, 320));

		centerPanel.add(scrPaneRights);

        setUpPolicyColumnCombo(tblRights.getColumnModel().getColumn(1), mapPolicyIdToPolicyName);

		// Allow horizontal scrollbar
		tblRights.setAutoResizeMode(JfxTable.AUTO_RESIZE_OFF);

		LOGGER.debug("initComponents() - Exit");
	}

	/**
	 * Initializes the window with the domain mappings fetched initially.
	 * @param p_mappings  The list of domain mappings.
	 * @param pLstPolicyIDToName  The list of policy id versus the policy name.
	 */
	public void populateMappings(
		List p_mappings,
		List pLstPolicyIDToName) {

		LOGGER.debug("populateMappings() - Enter");

		lstPolicyIDToName = pLstPolicyIDToName;
		mapPolicyIdToPolicyName = createMapOfPolicyIDToPolicyName(lstPolicyIDToName);

		List arrDisplay = getDisplayableArrayList(p_mappings);

		modelRights.data.addAll(arrDisplay);
        setUpPolicyColumnCombo(tblRights.getColumnModel().getColumn(1), mapPolicyIdToPolicyName);

		modelRights.fireTableDataChanged();

		LOGGER.debug("populateMappings() - Exit");
	}

	/**
	 * This function is responsible to convert the data that has been passed
	 * consisting of Domain Mappings and the hashMap containing the Policy ID
	 * to Policy Name, into the Displayable Data.
	 * @param p_mappings  The mappings which has to be displayed.
	 * @return Returns a list of DCDomainMappingTableData for display.
	 */
	private List getDisplayableArrayList(List p_mappings) {

		LOGGER.debug("getDisplayableArrayList() - Enter");

		List arrTableData = new ArrayList();
        // We shall iterate throught the Mappings. Picking only those that are for this domain and nothing else. 
		// Any other mappings is flagged as an error
        int nWindowDomainID = domain.getDomainID();
        for (int index = 0; index < p_mappings.size(); index++) {
            DCDomainMapping mapping = (DCDomainMapping) p_mappings.get(index);
            if (mapping.getDomainID() == nWindowDomainID) {
                String strUserGroup = mapping.getUserGroup();
                Integer nPolicyID = mapping.getPolicyID();
                String strPolicy = (String) mapPolicyIdToPolicyName.get(nPolicyID);
                if (null != strPolicy) {
                    DCDomainMappingTableData tableData = new DCDomainMappingTableData(strUserGroup, strPolicy);
                    arrTableData.add(tableData);
                }
            }
        }

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("The number of displayable entities are " + arrTableData);
		}
		LOGGER.debug("getDisplayableArrayList() - Exit");
		return arrTableData;
	}

	/**
	 * This function will create a HashMap. The Key to the Map is the ID of the
	 * policy and the Value is the Name of the policy
	 * @param pLstPolicyIDToName  List of PAPolicyNameAndID.
	 * @return Returns the hashmap created of policy id versus the name.
	 */
	private Map createMapOfPolicyIDToPolicyName(List pLstPolicyIDToName) {

		LOGGER.debug("createMapOfPolicyIDToPolicyName() - Entry");

		Map map = new HashMap();
		for (int index = 0; index < pLstPolicyIDToName.size(); index++) {
			PAPolicyId policy = (PAPolicyId) pLstPolicyIDToName.get(index);
			Integer key = policy.getPolicyID();
			String value = policy.getPolicyName();
			map.put(key, value);
		}
		// Now after having done this. We shall add a new entry -1 -> None into the
		// Map this will help us in isolating the code that we write for No mapping
		map.put(-2, NOVISIBILITY);
		map.put(-1, NOACCESS);

		LOGGER.debug("createMapOfPolicyIDToPolicyName() - Exit");

		return map;
	}

	/**
	 * This is a helper method to set up the entries of the combo.
	 * @param policyColumn  The column where in the combo is to be displayed.
	 * @param mapPolicies  Map of policy id versus the policy name.
	 */
    private void setUpPolicyColumnCombo(TableColumn policyColumn, Map mapPolicies) {

		LOGGER.debug("setUpPolicyColumnCombo() - Entry");
		//Set up the editor for the Policy cells.
		policyComboBox = new JComboBox();
		//m_policyComboBox .showPopup();
		Iterator itKeys = mapPolicies.keySet().iterator();
		while (itKeys.hasNext()) {
			String strPolicy = (String) mapPolicies.get(itKeys.next());
			// This is to make sure that None is the Last entry in the Combo Box The user can create a policy named as none. 
			// If he is not supposed to then, this will add an additional check if uncommented
			if (strPolicy.compareTo(NOACCESS) != 0 && strPolicy.compareTo(NOVISIBILITY) != 0) {
				policyComboBox.addItem(strPolicy);
			}

		}
		policyComboBox.addItem(NOVISIBILITY);
		policyComboBox.addItem(NOACCESS);
		policyColumn.setCellEditor(new DefaultCellEditor(policyComboBox));
		policyColumn.setCellRenderer(new PComboBoxRenderer());

		LOGGER.debug("setUpPolicyColumnCombo() - Exit");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView_BtnPnl_StatusBar#handleButtonClick(com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType)
	 */
	// Fault ID 43 - Provide Button Level Authorization for Domain Windows - Begin
	@Override
    public void handleButtonClick(USMButtonTypeEnum type) {
		LOGGER.debug("handleButtonClick() - Entry");

		if (type.equals(USMButtonTypeEnum.BTN_TYPE_OK)) {
			onApply();
		} else if (type.equals(USMButtonTypeEnum.BTN_TYPE_CANCEL)) {
			closeWindow();
		}

		LOGGER.debug("handleButtonClick() - Exit");

	}
	// Fault ID 43 - Provide Button Level Authorization for Domain Windows - End

	/**
	 * This handles policy creation. A new policy key gets added in the Vector and should be displayed in the combo
	 * 
	 * @param policy
	 *            The newly created policy.
	 *  
	 */
	public void policyCreated(PAPolicyId policy) {

		Integer nPolicyID = policy.getPolicyID();
		boolean bAlreadyAvailable =
			mapPolicyIdToPolicyName.containsKey(nPolicyID);

		if (bAlreadyAvailable == true) {
			// Trace out an error. Since we are getting a Policy creation for an already existing Policy ID
            LOGGER.warn("policyCreated() - Policy creation coming twice for  " + policy);
		} else {
			String strName = policy.getPolicyName();
			// Put it in the Map, array and JCombo
			mapPolicyIdToPolicyName.put(nPolicyID, strName);
			lstPolicyIDToName.add(policy);
			int nNoOfElms = policyComboBox.getItemCount();
			// We want to make sure that the Last is None. Therefore add to one above that.
			policyComboBox.insertItemAt(strName, (nNoOfElms - 1));
		}

	}

	/**
	 * This handles the notification of a policy being deleted, in which case
	 * the policy has to be removed from the combo.
	 * 
	 * @param p_policy
	 *            The policy which got deleted.
	 *  
	 */
	public void policyDeleted(PAPolicyId p_policy) {

		Integer nPolicyID = p_policy.getPolicyID();
		boolean bAvailable = mapPolicyIdToPolicyName.containsKey(nPolicyID);

		if (bAvailable) {
			// Remove it from the Map, array and JCombo
            String strName = (String) mapPolicyIdToPolicyName.remove(nPolicyID);
			lstPolicyIDToName.remove(p_policy);
			policyComboBox.removeItem(strName);
			modelRights.policyDeleted(strName);

		}
	}

	/**
	 * This handles the domain deleted notification. The window has to be
	 * closed in case if this is the affected domain.
	 * 
	 * @param p_domain -
	 *            The domain which has been deleted.
	 *  
	 */
	public void domainDeleted(DCDomainData p_domain) {
		if (domain.equals(p_domain)) {
			closeWindowOnObjectDeletion();
		}
	}

	/**
	 * This handles the notification of mappings being created. It adds the
	 * created mappings in the window.
	 * 
	 * @param mappings -
	 *            List of mappings that were created.
	 *  
	 */
	public void mappingsChanged(List mappings) {
		List arrDisplay = getDisplayableArrayList(mappings);
		modelRights.mappingsChanged(arrDisplay);
	}

	/**
	 * This handles the notification of mappings being created. It adds the
	 * created mappings in the window.
	 * 
	 * @param mappings -
	 *            List of mappings that were created.
	 * @param policies -
	 *            Policy object that was changed.
	 */
    public void mappingsChanged(List mappings, PAPolicyId policies) {
    }

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getComponent()
	 */
	@Override
    public JComponent getComponent() {
		return this;
	}

	/**
	 * This method gets called when the OK button is clicked. The policy which has
	 * been assigned to the user group is sent to the server.
	 */
	private void onApply() {
		LOGGER.debug("onApply() - Entry");

		List arrTableData = modelRights.data;
		Map mapPolNameToID = createMapOfPolicyNameToPolicyID(lstPolicyIDToName);

		List arrCreatedMappings = new ArrayList();
		List arrDeletedMappings = new ArrayList();
		List arrModifiedMappings = new ArrayList();

		int nDomID = domain.getDomainID();
		for (int index = 0; index < arrTableData.size(); index++) {
			DCDomainMappingTableData table_data = (DCDomainMappingTableData) arrTableData.get(index);
			String strUserGroup = table_data.mStrUserGroup;
			String strInitialString = table_data.mStrInitiallyAssigned;
			String strFinalString = table_data.mStrFinalAssignment;
			Integer nPolicyID = (Integer) mapPolNameToID.get(strFinalString);
			DCDomainMapping data = new DCDomainMapping(nDomID, strUserGroup, nPolicyID.intValue());

			if (strInitialString.compareTo(NOACCESS) == 0) {
				//Mapping created
				arrCreatedMappings.add(data);
			} else if (strFinalString.compareTo(NOACCESS) == 0) {
				//Mapping deleted
				arrDeletedMappings.add(data);
			} else if (strInitialString.compareTo(strFinalString) != 0){
				//Mapping modified
				arrModifiedMappings.add(data);
			}

		}
		List changedMappings = new ArrayList();
		changedMappings.addAll(arrCreatedMappings);
		changedMappings.addAll(arrModifiedMappings);
		changedMappings.addAll(arrDeletedMappings);
		((UAUserGroupDomainMappingProxy) associatedClientController).assignMappings(domain, changedMappings);

		LOGGER.debug("handleButtonClick() - Exit");

	}

	/**
	 * This function will create a HashMap. The Key to the Map is the Policy Name
	 * and the Value is the ID of the policy.
	 * @param lstPolicyIDToName  List of PAPolicyNameAndID.
	 * @return Map  Returns the map of policy name versus the policy id.
	 */
	private Map createMapOfPolicyNameToPolicyID(List lstPolicyIDToName) {
		LOGGER.debug("createMapOfPolicyNameToPolicyID() - Entry");

		Map map = new HashMap();
		for (int index = 0; index < lstPolicyIDToName.size(); index++) {
			PAPolicyId policy = (PAPolicyId) lstPolicyIDToName.get(index);
			Integer value = policy.getPolicyID();
			String key = policy.getPolicyName();
			map.put(key, value);
		}
		// Now add the one for the None.
		map.put(NOVISIBILITY, -2);
		map.put(NOACCESS, -1);

		LOGGER.debug("createMapOfPolicyNameToPolicyID() - Exit");

		return map;
	}

	/**
	 * @param errId
	 */
	public void showMessage(String p_msg) {
		bringToFront();
		JfxOptionPane.showMessageBox(this, p_msg);
	}

	/**
	 * Data model class for mappings of a domain
	 *
	 */
	class DCDomainMappingModel extends AbstractTableModel {

		private static final long serialVersionUID = -331224121661329410L;

		/**
		 * The title of the columns, two columns
		 */
        private String columns[] = { JfxStringTable.getString(USMStringTable.IDS_DC_USER_GROUPS), JfxStringTable.getString(USMStringTable.IDS_DC_ASSIGNED_POLICY) };

		/**
		 * Holds the data for this window
		 */
		private List data = new ArrayList();

		/**
		 * This method is used to find if a particular cell is editable or not.
		 * @param row  The row index of the cell.
		 * @param col  The column index of the cell.
		 * @return Returns true if the cell is editable.
		 */
		@Override
        public boolean isCellEditable(int row, int col) {
			boolean bEditable = false;
			if (1 == col) {
				bEditable = true;
			}
			return bEditable;
		}

		/**
		 * Get the column header name to be displayed.
		 * @param column  The column index of the cell.
		 */
		@Override
        public String getColumnName(int column) {
			return columns[column];
		}

		/* (non-Javadoc)
		 * @see javax.swing.table.TableModel#getColumnCount()
		 */
		@Override
        public int getColumnCount() {
			return columns.length;
		}

		/* (non-Javadoc)
		 * @see javax.swing.table.TableModel#getRowCount()
		 */
		@Override
        public int getRowCount() {
			return data.size();
		}

		/**
		 * This method handles the changes in the mappings data.
		 * @param changedMappings  The changed mapping data.
		 */
		public void mappingsChanged(List changedMappings) {
            for (int nOuterIndex = 0; nOuterIndex < data.size(); nOuterIndex++) {
                // We shall iterate over the whole of the data that we have
                DCDomainMappingTableData savedData = (DCDomainMappingTableData) data.get(nOuterIndex);
                for (int nInnerIndex = 0; nInnerIndex < changedMappings.size(); nInnerIndex++) {
                    DCDomainMappingTableData changedData = (DCDomainMappingTableData) changedMappings.get(nInnerIndex);
                    if (changedData.equals(savedData)) {
                        savedData.mStrInitiallyAssigned = changedData.mStrFinalAssignment;
                        savedData.mStrFinalAssignment = changedData.mStrFinalAssignment;
                        break;
                    }
                }
			}
			fireTableDataChanged();
		}

		/* (non-Javadoc)
		 * @see javax.swing.table.TableModel#getValueAt(int, int)
		 */
		@Override
        public Object getValueAt(int rowIndex, int columnIndex) {
			Object returnValue = null;
			DCDomainMappingTableData objData = (DCDomainMappingTableData) data.get(rowIndex);
			switch (columnIndex) {
				case 0 :
					{
						returnValue = objData.mStrUserGroup;
						break;
					}
				case 1 :
					{
						returnValue = objData.mStrFinalAssignment;
						break;
					}
				default :
				    {
				        LOGGER.debug("We reached a point we should never have got to using value columnIndex=" + columnIndex);
				        break;
				    }
			}
			return returnValue;

		}

		/**
		 * Sets the value of the object
		 * @param p_value  The value, which has to be set.
		 * @param p_row  The row index, where value has to be set.
		 * @param p_col  The column index, where value has to be set.
		 */
		@Override
        public void setValueAt(Object p_value, int p_row, int p_col) {
			DCDomainMappingTableData objData = (DCDomainMappingTableData) data.get(p_row);
			objData.mStrFinalAssignment = (String) p_value;
			fireTableCellUpdated(p_row, p_col);
		}

		/**
		 * This method handles policy deleted. It removes that policy from the combo.
		 * @param p_PolicyName  The policy name which has been deleted.
		 */
		public void policyDeleted(String p_PolicyName) {
			for (int index = 0; index < data.size(); index++) {
				DCDomainMappingTableData objData = (DCDomainMappingTableData) data.get(index);
				if (objData.mStrFinalAssignment.compareTo(p_PolicyName) == 0) {
					// This means that for this mapping, the policy selected has been deleted. 
				    // Therefore we shall revert this to the Initial one that was set when the window was open. If even this is None
					objData.mStrFinalAssignment = objData.mStrInitiallyAssigned;
				}
			}
			fireTableDataChanged();
		}
	}

	/**
	 * This class holds the mapping data in a readable format. Domain mappings
	 * have policy and domain id only. These are later resolved and stored in this structure.
	 */
	class DCDomainMappingTableData {

		/**
		 * For User group
		 */
		String mStrUserGroup;

		/**
		 * For Initial Assigned Policy
		 */
		String mStrInitiallyAssigned;

		/**
		 * For Assignment by operator
		 */
		String mStrFinalAssignment;

		/**
		 * Constructor which takes a user group and assigned policy.
		 * @param p_userGroup  The user group of the mapping.
		 * @param p_policyAssigned  The policy assigned to this mapping.
		 */
		DCDomainMappingTableData(String p_userGroup, String p_policyAssigned) {
			this.mStrUserGroup = p_userGroup;
			this.mStrInitiallyAssigned = p_policyAssigned;
			this.mStrFinalAssignment = p_policyAssigned;
		}

		@Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + getOuterType().hashCode();
            result = prime * result + ((mStrUserGroup == null) ? 0 : mStrUserGroup.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            DCDomainMappingTableData other = (DCDomainMappingTableData) obj;
            if (!getOuterType().equals(other.getOuterType())) {
                return false;
            }
            if (mStrUserGroup == null) {
                if (other.mStrUserGroup != null) {
                    return false;
                }
            } else if (!mStrUserGroup.equals(other.mStrUserGroup)) {
                return false;
            }
            return true;
        }

        /**
		 * Overridden toString method
		 * @return java.lang.String  Returns the user group + policy initially assigned + policy assigned
		 */
		@Override
        public String toString() {
            return (mStrUserGroup + " : " + mStrInitiallyAssigned + " : " + mStrFinalAssignment);
		}

        private DCDomainMappingView getOuterType() {
            return DCDomainMappingView.this;
        }
	}

	/**
	 * 
	 */
	public void closeWindow() {
		close();

	}

	/**
	 * @param userGrp
	 */
	public void userGroupCreated(UAUserGroup userGrp) {

		DCDomainMappingTableData mappingRowData = null;
		mappingRowData = new DCDomainMappingTableData((userGrp.getName()), NOACCESS);

		modelRights.data.add(mappingRowData);
		modelRights.fireTableDataChanged();
	}

	/**
	 * @param grps
	 */
	public void userGroupsDeleted(UAUserGroup p_grp) {
		String grp = p_grp.getName();
		for (int i = 0; i < modelRights.data.size(); ++i) {
            if (0 == grp.compareToIgnoreCase(((DCDomainMappingTableData) modelRights.data.get(i)).mStrUserGroup)) {
				modelRights.data.remove(i);
				break;
			}

		}
		modelRights.fireTableDataChanged();
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView_BtnPnl_StatusBar#enableBtnsAfterLongOperationCompleted()
	 */
	@Override
    protected void enableDisableControls() {
		enableAllButtons();
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#eventClosing()
	 */
	@Override
    public void eventClosing() {
		// Save table's properties
		saveProperties(tblRights, 0, mStrProfileName);

		super.eventClosing();
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#eventOpened()
	 */
	@Override
    public void eventOpened() {
		super.eventOpened();
		// Load table's properties
		loadProperties(tblRights, 0, mStrProfileName);
	}

	/* (non-Javadoc)
	 * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#setFrame(com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame)
	 */
	@Override
    public void setFrame(BiCNetPluginFrame frame) {
		super.setFrame(frame);
		tblRights.setDialogApp(new FrameworkDialogApp(getFrame()));
	}

    @Override
    public boolean isDockable() {    
        return true;
    }
}