package com.ossnms.bicnet.securitymanagement.client.auth;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;
import java.io.IOException;

/**
 * ***************************************************************************
 * Kerberos callback login
 *
 * This class is used instead of the AACallbackHandler.
 * ****************************************************************************
 */
public class KerberosCallbackHandler implements CallbackHandler {
    private final String username;
    private final String password;

    public KerberosCallbackHandler(String user, String pass) {
        this.username = user;
        this.password = pass;
    }

    @Override
    public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
        for (Callback callback : callbacks) {
            if (callback instanceof NameCallback) {
                // prompt the user for a username
                NameCallback nc = (NameCallback) callback;
                nc.setName(this.username);
            }
            if (callback instanceof PasswordCallback) {
                // prompt the user for sensitive information
                PasswordCallback pc = (PasswordCallback) callback;
                pc.setPassword(this.password.toCharArray());
            }
        }
    }
}
