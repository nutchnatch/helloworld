/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMNotificationRegistrar
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.notification;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;

import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * It is still not clear, if the Controllers should register directly
 * to the topic, or should a single controller register with the topic
 * and then delegate the notification to the other controllers.
 * 
 * In case the choice is that only a single controller should register,
 * this class will perform the role of a Registrar, where the controllers
 * can register with the notification's that they are interested in. This
 * class will then be used by the class for delegation of the notifications.
 *  
 */
public final class USMNotificationRegistrar {
	/**
	 * Data member to hold the singleton instance of the class
	 */
	private static USMNotificationRegistrar instance = new USMNotificationRegistrar();

	/**
	 * Data member to hold the mapping of the type of message to the set of
	 * controllers who are interested in the message
	 */
	private Map<USMBaseMsgType, Set<USMControllerIfc>> tblMsgTypeToSetOfCtls = new Hashtable<USMBaseMsgType, Set<USMControllerIfc>>();

	/**
	 * Private constructor to help in singleton implementation
	 */
	private USMNotificationRegistrar() {
	}

	/**
	 * Static function to return the singleton instance of the class
	 * 
	 * @return USMNotificationRegistrar - The singleton instance of the class
	 */
	public static USMNotificationRegistrar getInstance() {
		return instance;
	}

	/**
	 * Helper function provided to register a controller object with the
	 * message type that the controller is interested in.
	 * 
	 * @param msgTypes -
	 *            The List of Message types that the controller is interested
	 *            in.
	 * @param ctl -
	 *            The Controller object which is to be registered.
	 */
	public void register(List<USMBaseMsgType> msgTypes, USMControllerIfc ctl) {
		for (USMBaseMsgType msgType : msgTypes) {
			Set<USMControllerIfc> stCtls = tblMsgTypeToSetOfCtls.get(msgType);
			if (stCtls == null) {
				stCtls = new HashSet<USMControllerIfc>();
				tblMsgTypeToSetOfCtls.put(msgType, stCtls);
			}
			stCtls.add(ctl);
		}
	}

	/**
	 * Helper function to de-register a controller object which has been
	 * previously registered. This is needed when the view which is responsible
	 * for the controller is closed. The View has to cleanup the controller so
	 * that the load on the system can be reduced.
	 * 
	 * @param msgTypes -
	 *            The List of Message types that the controller was interested
	 *            in.
	 * @param ctl -
	 *            The Controller object which is to be de-registered.
	 */
	// Fault ID 61 - Wrong "Policy has been Deleted" message
	public void deRegister(List<USMBaseMsgType> msgTypes, USMControllerIfc ctl) {
		for (USMBaseMsgType msgType : msgTypes) {
			Set<USMControllerIfc> stCtls = tblMsgTypeToSetOfCtls.get(msgType);
			if (stCtls != null) {
				stCtls.remove(ctl);
			}
		}
	}

	/**
	 * Function to return the Set of client controller objects which are
	 * interested in the notification.
	 * 
	 * @param msgType -
	 *            This is the message type which has been sent by the server
	 * 
	 * @return Set - A set of controllers that are registered for the type of
	 *         message
	 */
	public Set<USMControllerIfc> getRegisteredCtls(USMBaseMsgType msgType) {
		return tblMsgTypeToSetOfCtls.get(msgType);
	}
}