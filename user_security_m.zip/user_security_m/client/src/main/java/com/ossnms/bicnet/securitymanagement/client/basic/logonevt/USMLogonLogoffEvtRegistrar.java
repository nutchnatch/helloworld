/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMLogonLogoffEvtRegistrar
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 19-Jan-2005  Babu B          CF000041-08 Storage off Client specifc setting
 * 
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.logonevt;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.framework.client.listeners.FrameworkAbstractLogonListener;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import org.apache.log4j.Logger;

import java.security.InvalidParameterException;
import java.util.HashSet;
import java.util.Set;

/**
 * This is the singleton instance of the class which is to be invoked when the
 * user logs on and logs off.
 * 
 * This class is then responsible to notify the registered classes about the
 * logging in and logging out of the operator
 */
public final class USMLogonLogoffEvtRegistrar extends FrameworkAbstractLogonListener {
    /**
     * Data member for the Logging of the class.
     */
	private static final Logger LOGGER = Logger.getLogger(USMLogonLogoffEvtRegistrar.class);

    /**
     * Data member to hold the singleton instance of the class
     */
    private static USMLogonLogoffEvtRegistrar instance = new USMLogonLogoffEvtRegistrar();

    /**
     * Data member to hold a set of objects
     */
    private Set<USMLogonLogoffEventIfc> setObjects;

    /**
     * Constructor being made private to support singleton pattern
     */
    private USMLogonLogoffEvtRegistrar() {
        LOGGER.debug("Entering USMLogonLogoffEvtRegistrar constructor");

        setObjects = new HashSet<>();

        LOGGER.debug("Exiting USMLogonLogoffEvtRegistrar constructor");
    }

    /**
     * Static function to retireve the singleton instance of the class
     * 
     * @return USMLogonLogoffEvtRegistrar - The singleton instance of the class.
     */
    public static USMLogonLogoffEvtRegistrar getInstance() {
        LOGGER.debug("Called getInstance");
        return instance;
    }

    /**
     * Function so that other objects can be registered with the Registrar for
     * listening of the events.
     * 
     * @param obj - The Object which wants to be registered for the event.
     * @return boolean - Indicates whether it was possible to register or not for the
     *         event.
     */
    public boolean register(USMLogonLogoffEventIfc obj) {
        LOGGER.debug("Entering register");
        boolean bRegistered = false;

        if (obj == null) {
            LOGGER.error("The Object being passed is null");
            throw new InvalidParameterException();
        }

        if (null != setObjects) {
            bRegistered = setObjects.add(obj);
        } else {
            LOGGER.error("The m_setObjects is null");
        }

        LOGGER.debug("Exiting register");
        return bRegistered;
    }

    /**
     * Function that should be called when a operator logs on successfully
     */
    @Override
    protected void eventUserLoggedOn(ISessionContext sessionContext) {
        LOGGER.debug("Entering function operatorLoggedOn");

        USMUtility.getInstance().operatorLoggedOn(sessionContext);

        if (null != setObjects) {
        	for (USMLogonLogoffEventIfc obj : setObjects) {
                obj.operatorLoggedOn(sessionContext);
            }
        } else {
            LOGGER.error("The Object m_setObjects is null");
        }

        LOGGER.debug("Exiting function operatorLoggedOn");
    }

    /**
     * Function that should be called when a operator logs off
     */
    @Override
    protected void eventUserLoggedOff(ISessionContext sessionContext) {
        LOGGER.debug("Entering function operatorLoggedOff");

        if (null != setObjects) {
        	for (USMLogonLogoffEventIfc obj : setObjects) {
                obj.operatorLoggedOff(sessionContext);
            }
        } else {
            LOGGER.error("The Object m_setObjects is null");
        }

        // USMUtility is treated specially ... 
        USMUtility.getInstance().operatorLoggedOff(sessionContext);

        LOGGER.debug("Exiting function operatorLoggedOff");
    }

    /**
     * Function that should be called when a operator is logging off
     */
    @Override
    protected void eventUserLoggingOff(ISessionContext sessionContext) {
        LOGGER.debug("Entering function operatorLoggingOff");

        if (null != setObjects) {
        	for (USMLogonLogoffEventIfc obj : setObjects) {
                obj.operatorLoggingOff(sessionContext);
            }
        } else {
            LOGGER.error("The Object m_setObjects is null");
        }
        
        // USMUtility is treated specially ... 
        USMUtility.getInstance().operatorLoggingOff(sessionContext);

        LOGGER.debug("Exiting function operatorLoggingOff");
    }

	@Override
	protected BiCNetPluginSite getPluginSite() {
		return USMUtility.getInstance().getCfPluginSite();
	}
}
