package com.ossnms.tnms.securitymanagement.client.jobs;

import com.ossnms.bicnet.framework.client.helpers.FrameworkFetchJob;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDocument;
import com.ossnms.bicnet.framework.client.utils.FrameworkException;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.bicnet.securitymanagement.server.interfaces.ISecurityGeneralSettingPrivateFacade;
import com.ossnms.bicnet.securitymanagement.server.servicelocator.USMServiceLocator;
import org.apache.log4j.Logger;

public class SecuritySettingsJob extends FrameworkFetchJob {

    private static final String id = "com.ossnms.tnms.securitymanagement.client.jobs.SecuritySettingsJob";
    private static final String name = "SecuritySettingsJob";
    private static final String additionalInfo = "Job to send data to server";
    private static final Logger LOGGER = Logger.getLogger(SecuritySettingsJob.class);

    private GSGeneralSettingData gsData;

    public SecuritySettingsJob(IFrameworkDocument jobOwner) {
        super(id, name, additionalInfo, jobOwner);
    }

    @Override
    public Object execute(Object obj) throws FrameworkException {
        try {
            ISecurityGeneralSettingPrivateFacade fcd = USMServiceLocator.getInstance().getSecurityGeneralSettingsPrivateFacade();
            return fcd.setGeneralSettingData(USMUtility.getInstance().getSessionContext(), this.gsData);
        } catch (Exception e) {
            LOGGER.error("Error retreiving data from server", e);
        }
        return null;
    }

    public void setConfigData(GSGeneralSettingData gsData) {
        this.gsData = gsData;
    }

}
