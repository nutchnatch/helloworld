/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Author:      Vinay Purohit
 * Substitute	Babu B
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER.VIEW
 *       : TNMS.DX2.SM.USER.CREATE
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.useradministration.job;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.useradministration.UADelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import org.apache.log4j.Logger;

import java.rmi.RemoteException;

/**
 * This class represents the job that is responsible for getting all the
 * assigned and unassigned user groups
 */
public class UAJobGetAllAssignedAndUnAssignedUsergroups extends USMJob {
	/**
		 * Data member contains user id of the user.
		 */
	String mUser = null;

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(UAJobGetAllAssignedAndUnAssignedUsergroups.class);

	/**
	 * This is the constructor
	 * 
	 * @param pJobOwner -
	 *            The controller that is associated with the job
	 */
	public UAJobGetAllAssignedAndUnAssignedUsergroups(
		USMControllerIfc pJobOwner,
		String pUser) {
		super(
			UAMessageType.S_UA_NOT_MODIFY_USER,
			USMCommonStrings.EMPTY,
			USMCommonStrings.EMPTY,
			pJobOwner);

		Object[] arr = { pUser };
		String str =
			USMStringTable
				.IDS_UA_JOB_ASSIGNED_UNASSIGNED_USERGROUPS_FOR_USER
				.getFormatedMessage(arr);
		setName(str);

		mUser = pUser;
	}

	/**
	 * Executes the given job
	 *
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob#executeJob()
	 */
	public USMMessage executeJob() throws BcbSecurityException {
		LOGGER.debug("executeJob()in the method");
		USMMessage msg = null;
		try {
			msg = new UADelegate().getAllAssignedAndUnassignedUserGroups(mUser);
		} catch (RemoteException e) {
			LOGGER.error("executeJob()   error in getting AllAssignedAndUnassignedUserGroups ");
		}
		return msg;
	}
}