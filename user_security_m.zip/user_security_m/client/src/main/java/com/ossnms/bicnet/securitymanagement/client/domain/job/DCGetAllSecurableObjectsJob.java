package com.ossnms.bicnet.securitymanagement.client.domain.job;

import org.apache.log4j.Logger;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.domain.DCBusinessDelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;

public class DCGetAllSecurableObjectsJob  extends USMJob {
	
	private static final Logger LOGGER = Logger.getLogger(DCGetAllSecurableObjectsJob.class);

	public DCGetAllSecurableObjectsJob(USMBaseMsgType msgTypeId, USMControllerIfc jobOwner) {
		super(msgTypeId, USMCommonStrings.EMPTY, USMCommonStrings.EMPTY, jobOwner);

		String strMsg = USMStringTable.IDS_DC_JOB_GET_ALL_SEC_OBJECTS_FROM_SERVER.toString();
		setName(strMsg);
	}

	@Override
	public USMMessage executeJob() throws BcbSecurityException {
		LOGGER.debug("executeJob() - Enter");
		DCBusinessDelegate delegate = new DCBusinessDelegate();
		USMMessage msg = delegate.getAllSecurableObject();
		LOGGER.debug("executeJob() - Exits");
		return msg;
	}
}
