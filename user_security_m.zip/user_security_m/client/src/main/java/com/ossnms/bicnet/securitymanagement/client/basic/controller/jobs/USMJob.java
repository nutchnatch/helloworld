/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMJob
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 * 06-May-2009  Nagaraddi S S    TD004578 - RQT-STDERR errors instead log4j's
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginRunnableStopListener;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginServerAccessController;
import com.ossnms.bicnet.framework.client.jfx.FrameworkRunnableBaseImpl;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.basic.USMTimeTracer;
import org.apache.log4j.Logger;

import java.security.InvalidParameterException;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;

/**
 * This is the single class within USM that should inherit from
 * BiCNetPluginRunnableBaseImpl directly.
 * <p>
 * All other Jobs should derive from this class.
 */
public abstract class USMJob
        extends FrameworkRunnableBaseImpl
        implements BiCNetPluginRunnableStopListener {
    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(USMJob.class);
    /**
     * Data member to hold the identifier of the job. Needed for getting back to
     * the controller when the job is complete.
     */
    protected USMBaseMsgType id;
    /**
     * Data member to hold the name that is displayed in the Queuable job
     * window.
     */
    protected String name;
    /**
     * Data member to hold additional information that is displayed in the
     * Queuable job window
     */
    protected String additionalInfo;
    /**
     * Data member to hold information about the owner of the job
     */
    protected USMControllerIfc jobOwner;
    /**
     * Data member to hold the Time Tracker
     */
    private USMTimeTracer timeTracker = null;

    /**
     * Constructor
     *
     * @param id             -
     *                       The identifier for this job
     * @param name           -
     *                       The name for the job. This String could be displayed in the
     *                       list of Jobs. So take care of Internationalization
     * @param additionalInfo -
     *                       Additional information for the job. This String could be
     *                       displayed in the list of Jobs. So take care of
     *                       Internationalization
     * @param jobOwner       -
     *                       Owner of the Job
     */
    protected USMJob(
            USMBaseMsgType id,
            String name,
            String additionalInfo,
            USMControllerIfc jobOwner) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "USMJob being created with the value USMBaseMsgType : "
                            + id
                            + " Name : "
                            + name
                            + " Additional info : "
                            + additionalInfo
                            + " Controller Int : "
                            + jobOwner);
        }

        if ((null == id)
                || (null == name)
                || (null == additionalInfo)
                || (null == jobOwner)) {
            LOGGER.error("One of the parameters for the USMJob is null");
            throw new InvalidParameterException("Parameter being passed is null");
        }

        this.name = name;
        this.additionalInfo = additionalInfo;
        this.jobOwner = jobOwner;
        this.id = id;
        setStopListener(this);
        timeTracker = new USMTimeTracer();
    }

    /**
     * Helper function to register a Job being added to the Queue.
     */
    public void registerJobAddedToQueue() {
        timeTracker.registerJobAddedToQueue();
        if (LOGGER.isDebugEnabled()) {
            long timeForClientOpBeforeAdd =
                    timeTracker.getTimeForStartOfJob();
            LOGGER.debug(
                    "Time taken for Job : "
                            + toString()
                            + " to be added to Queue : "
                            + timeForClientOpBeforeAdd);
        }
    }

    /**
     * Helper function to register a Job being added to the Queue.
     */
    public void registerGUIUpdateStarted() {
        timeTracker.registerGUIUpdateStarted();
        if (LOGGER.isDebugEnabled()) {
            long timeForSwingWait =
                    timeTracker.getTimeForWaitingForSwingUpdate();
            LOGGER.debug(
                    "Time taken for Job : "
                            + toString()
                            + " waiting for Swing Update is : "
                            + timeForSwingWait);
        }
    }

    /**
     * Helper function to register a Job being added to the Queue.
     */
    public void registerGUIUpdateComplete() {
        timeTracker.registerGUIUpdateCompleted();
        if (LOGGER.isDebugEnabled()) {
            long timeForGUIUpdateComplete = timeTracker.getTimeForGUIUpdate();
            LOGGER.debug(
                    "Time taken for Job : "
                            + toString()
                            + " to update GUI : "
                            + timeForGUIUpdateComplete);
        }

        long timeForComplete = timeTracker.getTimeForCompleteJob();
        LOGGER.info(
                "Time taken for Job : "
                        + toString()
                        + " to complete : "
                        + timeForComplete);
    }

    /*
     * (non-Javadoc)
     *
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginRunnableStopListener#stopping()
     */
    @Override
    public void stopping() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Stopping called for job : " + this);
        }
        jobOwner.endJob(this);
    }

    /*
     * (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginRunnable#run()
     */
    @Override
    public void run() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Run called for the Job : " + this);
        }
        try {
            final USMJob executingJob = this;
            USMMessage msg =
                    (USMMessage) BiCNetPluginServerAccessController.doPrivileged(this, new PrivilegedExceptionAction<USMMessage>() {

                        @Override
                        public USMMessage run() {
                            USMMessage result = null;
                            try {
                                timeTracker.registerExecuteJobStarted();
                                if (LOGGER.isDebugEnabled()) {
                                    long timeForWaitInPool =
                                            timeTracker.getTimeForWaitingInPool();
                                    LOGGER.debug(
                                            "Time taken for Job : "
                                                    + executingJob
                                                    + " to wait in Pool : "
                                                    + timeForWaitInPool);
                                }

                                result = executeJob();
                            } catch (BcbSecurityException e) {
                                LOGGER.error("Exception :", e);
                                jobOwner.handleBcbSecurityException(
                                        executingJob,
                                        e);
                            }
                            timeTracker.registerExecuteJobComplete();

                            long timeForServerProcessing =
                                    timeTracker.getTimeForServerProcessing();
                            LOGGER.info(
                                    "Time taken for Job : "
                                            + executingJob
                                            + " in the Server : "
                                            + timeForServerProcessing);

                            return result;
                        }
                    });

            LOGGER.debug(
                    "Message retrieved from the Server is : " + msg);
            if (null != msg) {
                if (LOGGER.isDebugEnabled()) {
                    LOGGER.debug(
                            "Message retrieved from the Server is : " + msg);
                }
            } else {
                msg = new USMMessage(
                        USMMessage.ERROR_MSG_TYPE,
                        USMMessage.USMMESSAGE_RESPONSE);
            }
            jobOwner.setResult(this, msg);

        } catch (PrivilegedActionException | ClassCastException e) {
            LOGGER.error(e);
        }
    }

    /**
     * This is the abstract function that should be implemented by all concrete
     * jobs. The call to the Business Delegate has to be done here in this
     * method.
     *
     * @return Object - The result of the operation.
     */
    public abstract USMMessage executeJob() throws BcbSecurityException;

    /**
     * Function to return the Additional information
     *
     * @return String - The additional information about the job
     */
    public String getAdditionalInfo() {
        return additionalInfo;
    }

    /**
     * Function to return the Identifier
     *
     * @return USMBaseMsgType - The identifier for the job
     */
    public USMBaseMsgType getID() {
        return id;
    }

    /**
     * Function to return the name of the job
     *
     * @return String - The name of the job
     */
    public String getName() {
        return name;
    }

    /**
     * Function to set the name of the job
     */
    protected final void setName(String strName) {
        name = strName;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append(id);
        sb.append(" : ");
        sb.append(name);
        sb.append(" : ");
        sb.append(additionalInfo);
        return sb.toString();
    }

    /**
     * Function to return the Owner of the Job
     *
     * @return USMControllerIfc Owner of the Job
     */
    public USMControllerIfc getJobOwner() {
        return jobOwner;
    }

}
