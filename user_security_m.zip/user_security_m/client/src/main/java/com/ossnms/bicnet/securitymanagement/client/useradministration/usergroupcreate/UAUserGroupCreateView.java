/*
 * ------------------------History-------------------------
 * <date>       <author>        <reason(s) of change>
 * 18-Jan-2005	Muyeen Munaver	CF00702 - The "OK" could became Grey in the "New User" window
 * 09-02-2005	Babu B          CF000060-01   CF USM GUI Requirements
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration.usergroupcreate;

import java.awt.Component;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;

import org.apache.log4j.Logger;

import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMHelp;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonType;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum;
import com.ossnms.bicnet.securitymanagement.client.useradministration.usergroup.common.UAUserGroupCreateModifyBaseView;
import com.ossnms.bicnet.securitymanagement.common.domain.DCDomainMapping;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserGroup;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAUserNameAndID;
import com.ossnms.tools.jfx.JfxOptionPane;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxText;

/**
 * This is a user interface class which displays the user group create view
 */
public class UAUserGroupCreateView extends UAUserGroupCreateModifyBaseView {
    private static final long serialVersionUID = -5745593797516841393L;

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = Logger.getLogger(UAUserGroupCreateView.class);

    /**
     * Data member to hold title for the window
     */
    private static final String UG_TITLE_USER_GROUP_CREATE_WINDOW = JfxStringTable.getString(USMStringTable.IDS_UG_TITLE_USER_GROUP_CREATE_WINDOW);
    private static final String UG_MSG_USER_GROUP_NAME_NOT_VALID = JfxStringTable.getString(USMStringTable.IDS_UG_MSG_USER_GROUP_NAME_NOT_VALID);
    private static final String UG_MSG_USER_GROUP_DESC_NOT_VALID = JfxStringTable.getString(USMStringTable.IDS_UG_MSG_USER_GROUP_DESC_NOT_VALID);

    /**
     * Default Constructor
     */
    public UAUserGroupCreateView() {
        super(null, getButtons(), null, "UAUserGroupCreateView.com.ossnms.bicnet.securitymanagement.client.UAUserGroupCreateView",
                UG_TITLE_USER_GROUP_CREATE_WINDOW, true, USMHelp.HID_CREATE_USERGROUP);
        LOGGER.debug("UAUserGroupCreateView() Enter");
        associatedClientController = new UAUserGroupCreateClientController(this);
        LOGGER.info("getting users");
        ((UAUserGroupCreateClientController) associatedClientController).sendReqToGetAllUserNames();
        LOGGER.debug("UAUserGroupCreateView() Exit");
    }

    /**
     * Function to return the Buttons that should be added
     * @return List containing the Buttons to be added to the View
     */
    private static List<USMButtonType> getButtons() {
        LOGGER.debug("getButtons() Enter");
        List<USMButtonType> buttons = new ArrayList<USMButtonType>();
        USMButtonType ok = new USMButtonType(USMButtonTypeEnum.BTN_TYPE_OK, null, new JfxText("Create User Group"), true);
        buttons.add(ok);
        buttons.add(USMButtonType.BTN_TYPE_CANCEL);
        LOGGER.debug("getButtons() Exit");
        return buttons;
    }

    /**
     * Function that is called by this class when the window is opened for the create user group and operator has
     * pressed APPLY.
     */
    private void createUserGroup() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("createUserGroup()     Enter");
        }

        String groupName = tabGroup.getGeneralPane().getNameTextField().getText();
        String groupDesc = tabGroup.getGeneralPane().getDescriptionTextField().getText();
        groupName = groupName.trim();
        // Checking for user group name is null
        if (checkAndDisplayMessageForValidName(groupName, groupDesc)) {
            // Creating UAUserGroup object
            UAUserGroup dataUserGroup = new UAUserGroup(groupName, groupDesc, "");

            // Creating list of assigned users
            int assignedUserLen = tabGroup.getGeneralPane().getAssignedUserListModel().size();
            List<String> userList = new ArrayList<String>(assignedUserLen);
            for (int index = 0; index < assignedUserLen; index++) {
                UAUserNameAndID dataUser = (UAUserNameAndID) tabGroup.getGeneralPane().getAssignedUserListModel().elementAt(index);
                LOGGER.debug(dataUser.getCommonName());
                LOGGER.debug(dataUser.getUserId());
                userList.add(dataUser.getUserId());
            }
            
            // Getting List of mappings to assign to the user group
            List<DCDomainMapping> mappingsForUserGroup = new ArrayList<DCDomainMapping>();
            tabGroup.getDomainsPoliciesPane().getMappingsForAssignment(groupName, mappingsForUserGroup);
            
            UAUserGroupCreateClientController ctl = (UAUserGroupCreateClientController) associatedClientController;
            ctl.sendRequestToCreateUserGroup(dataUserGroup, userList, mappingsForUserGroup);
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("createUserGroup() Exit");
        }
    }

    /**
     * Helper function to check if the passed name for the user group is correct. It also checks if user group
     * description was given.
     * 
     * @param strUGName
     *            The User group name which has to be checked.
     * @param groupDesc
     *            The User group description.
     * 
     * @return boolean Indicates the correctness of the name. True indicates success.
     */
    private boolean checkAndDisplayMessageForValidName(String strUGName, String groupDesc) {
        String regExpInvalid = "+=\\;\"/<>,#";
        boolean valid = true;

        if (strUGName.length() == 0) {
            valid = false;
        }

        for (int i = 0; (i < regExpInvalid.length() && (valid)); i++) {
            if (-1 != strUGName.indexOf((regExpInvalid.charAt(i)))) {
                valid = false;
            }
        }

        if (!valid) {
            JfxOptionPane.showMessageBox(this, UG_MSG_USER_GROUP_NAME_NOT_VALID, JOptionPane.CLOSED_OPTION, JOptionPane.ERROR_MESSAGE);
        } else if ("".equals(groupDesc)) {
            valid = false;
            JfxOptionPane.showMessageBox(this, UG_MSG_USER_GROUP_DESC_NOT_VALID, JOptionPane.CLOSED_OPTION, JOptionPane.ERROR_MESSAGE);
        }

        return valid;
    }

    /**
     * Handler for buttons in button bar. Called by USM framework, when a button is clicked
     * Delegates to appropriate helper method
     * 
     * @param type
     *            Identifier for the button that was clicked
     * 
     * @see com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseViewWithButtons#handleButtonClick(com.ossnms.bicnet.securitymanagement.client.basic.view.USMButtonTypeEnum)
     */
    @Override
    public void handleButtonClick(USMButtonTypeEnum type) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleButtonClick(" + type + ") Enter");
        }
        if ((USMButtonTypeEnum.BTN_TYPE_OK).equals(type)) {
            createUserGroup();
        } else if ((USMButtonTypeEnum.BTN_TYPE_CANCEL).equals(type)) {
            close();

        } else {
            LOGGER.info("unexpected..."); //$NON-NLS-1$
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("handleButtonClick(" + type + ") Exit");
        }
    }

    /**
     * Overridden method to return the component to be embedded in the view
     * 
     * @return the view itself
     * 
     * @see com.ossnms.bicnet.bcb.plugin.BiCNetPluginView#getComponent()
     */
    @Override
    public JComponent getComponent() {
        return this;
    }

    /**
     * Function to show a message to the user
     * 
     * @param parComp
     *            The Component which is the parent window.
     * @param message
     *            The Text that should be displayed
     */
    public void showMessage(final Component parComp, String message) {
        JfxOptionPane.showMessageBox(this, message);
    }

    @Override
    protected void enableDisableControls() {
        enableAllButtons();
    }
    
    @Override
    public boolean isDockable() {
        return false;
    }
    
    @Override
    public Icon getIcon() {
        return ResourcesIconFactory.ICON_LIST_USER_GROUP_16;
    }

}