package com.ossnms.bicnet.securitymanagement.client.useradministration.usergroup.common;

import javax.swing.JTabbedPane;

import org.apache.log4j.Logger;

import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;

/**
 * This class groups the tabs for the User Group creation/modification 
 *
 */
public class UAUserGroupDetailsTabGroup extends JTabbedPane{

    private static final long serialVersionUID = -4874869904491800659L;

    private static final Logger LOGGER = Logger.getLogger(UAUserGroupDetailsTabGroup.class);
    
    /**
     * Data member which hold string for general settings and user assignment to this group.
     */
    private static final String GENERAL_DATA = USMStringTable.getString(USMStringTable.IDS_UG_TAB_GENERAL_DATA);
    
    /**
     * To be used for the second Pane, containing the mapping between domains and policies
     */
    private static final String DOMAINS_AND_POLICIES_DATA = USMStringTable.getString(USMStringTable.IDS_UG_TAB_DOMAINS_AND_POLICIES_DATA);

    private UAUserGroupGeneralPane generalPane = null;
    
    private UAUserGroupDomainsAndPoliciesPane domainsPoliciesPane = null;
    
    UAUserGroupDetailsTabGroup(){
        init();
    }
    
    /**
     * Initializes the view by creating / placing all required controls
     */
    private void init() {
        LOGGER.debug("init() Entry");

        generalPane = new UAUserGroupGeneralPane();
        add(GENERAL_DATA, generalPane);
        
        domainsPoliciesPane = new UAUserGroupDomainsAndPoliciesPane();
        add(DOMAINS_AND_POLICIES_DATA, domainsPoliciesPane);
        
        LOGGER.debug("init() Exit");
    }
    
    public UAUserGroupGeneralPane getGeneralPane(){
        return generalPane;
    }

    public UAUserGroupDomainsAndPoliciesPane getDomainsPoliciesPane() {
    	return domainsPoliciesPane;
    }
}
