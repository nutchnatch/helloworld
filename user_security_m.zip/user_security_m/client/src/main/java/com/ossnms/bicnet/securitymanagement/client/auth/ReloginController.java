package com.ossnms.bicnet.securitymanagement.client.auth;

import com.coriant.bicnet.util.fsm.AbstractFsmAction;
import com.coriant.bicnet.util.fsm.Fsm;
import com.coriant.bicnet.util.fsm.FsmAction;
import com.coriant.bicnet.util.fsm.FsmTableBuilder;
import com.ossnms.bicnet.bcb.plugin.BiCNetPlugin;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientProperties;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrameType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginLoaderListener;
import com.ossnms.bicnet.bcb.plugin.scs.BiCNetPluginScsProvider.StandbyServerEventListener;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.tools.jfx.JfxOptionPane;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public final class ReloginController implements StandbyServerEventListener, BiCNetPluginLoaderListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(ReloginController.class);

    private static ReloginController instance = new ReloginController();

    private volatile ReloginData reloginInfo;
    private Fsm<State, Event> stateMachine;
    private FsmTableBuilder<State, Event> stateTransitions;

    private ReloginController() {
        initStateMachine();
    }

    public static ReloginController getInstance() {
        return instance;
    }

    public void loggedOn(String activeServer, String user, String password, boolean sso) {
        resetStateMachine();
        reloginInfo = new ReloginData(activeServer, user, password, sso, null);
    }

    public void passwordChanged(String newPassword) {
        reloginInfo.setPassword(newPassword);
    }

    public void loggedOff(String oldServerId) {
        handleLogoffReason(oldServerId);
    }

    private void handleLogoffReason(final String oldServerId) {
        final String logoffMessage = USMUtility.getInstance().getLogoffMessage();
        final boolean shouldClientReLogin = USMUtility.getInstance().shouldClientReLogin();

        SwingUtilities.invokeLater(() -> {
            final String formattedMessage = USMStringTable.IDS_LOGGED_OFF_MESSAGE.getFormatedMessage(oldServerId, logoffMessage);

            if (shouldClientReLogin) {
                openReloginView(formattedMessage, logoffMessage);

            } else if (logoffMessage != null) {
                showLogoffMessage(formattedMessage);
            }
        });
    }

    private void openReloginView(String logoffMessage, String logoffReasonMessage) {
        try {
            ReloginView view = new ReloginView(logoffMessage, logoffReasonMessage, reloginInfo);
            BiCNetPluginFrame frame = USMUtility.getInstance().getSecuritySite().createFrame(view, BiCNetPluginFrameType.MODAL);
            frame.showFrame();

        } catch (BiCNetPluginException e) {
            LOGGER.error("Failed to open ReLogin view");
            showLogoffMessage(logoffMessage);
        }
    }

    private void showLogoffMessage(String logoffMessage) {
        String title = USMUtility.getInstance().getSecuritySite().getClientProperty(BiCNetPluginClientProperties.CLIENT_NAME, null);
        JfxOptionPane.showMessageBox(null, title, logoffMessage, JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE);
    }

    @Override
    public void standbyServerAssigned(String standbyServerAddress) {
        stateMachine.putTransientUserData(standbyServerAddress, String.class);
        stateMachine.processEvent(Event.ASSIGNED);
    }

    @Override
    public void standbyServerUnassigned() {
        stateMachine.processEvent(Event.UNASSIGNED);
    }

    @Override
    public void shutdownDueToFailoverScheduled(String standbyServerAddress) {
        stateMachine.putTransientUserData(standbyServerAddress, String.class);
        stateMachine.processEvent(Event.SHUTDOWN_SCHEDULED);
    }

    @Override
    public void shutdownDueToFailoverCancelled() {
        stateMachine.processEvent(Event.SHUTDOWN_CANCELED);
    }

    private void registerStandbyListener() {
        try {
            USMUtility.getInstance().getSecuritySite().getScsProvider().addStandbyServerEventListener(this);
        } catch (BiCNetPluginException e) {
            LOGGER.error("Unable to register standby server listener", e);
        }
    }

    private void unregisterStandbyListener() {
        try {
            USMUtility.getInstance().getSecuritySite().getScsProvider().removeStandbyServerEventListener(this);
        } catch (BiCNetPluginException e) {
            LOGGER.error("Unable to register standby server listener", e);
        }

    }

    public void init() {
        USMUtility.getInstance().getSecuritySite().addLoaderListener(this);
    }

    public void destroy() {
        unregisterStandbyListener();
    }

    @Override
    public void eventPluginLoaded(String strID, BiCNetPlugin plugin) {
    }

    @Override
    public void eventPluginLoadedAll() {
        registerStandbyListener();
    }


    private enum State {
        STANDALONE,
        ASSIGNED,
        ASSIGNED_WAITING_SHUTDOWN,
        STANDALONE_WAITING_SHUTDOWN
    }

    private enum Event {
        ASSIGNED,
        UNASSIGNED,
        SHUTDOWN_SCHEDULED,
        SHUTDOWN_CANCELED
    }


    private class SaveStandbyServer extends AbstractFsmAction<Event> {
        public SaveStandbyServer() {
            super(Event.class);
        }

        @Override
        public void run() {
            String standbyServer = getContext().getTransientUserData(String.class);
            reloginInfo.setStandbyServer(standbyServer);
        }
    }

    private class ClearStandbyServer implements FsmAction {
        @Override
        public void run() {
            reloginInfo.setStandbyServer(null);
        }
    }

    /**
     * When saving the active and standby servers in the list specifies
     * which server will be left on top of the list.
     */
    private enum TopInHistory {
        ACTIVE, STANDBY
    }

    /**
     * When saving the active and standby servers in the list specifies
     * if the Active and Standby server labels will be added or not.
     */
    private enum ServerLabels {
        INCLUDE, EXCLUDE
    }

    /**
     * This action saves the active and standby server addresses in the logon history.
     * Its behaviour may be customized by specifying which server will be left on top and
     * if active and standby server labels should be also added or not.
     */
    private class SaveLogonHistory extends AbstractFsmAction<Event> {
        private final TopInHistory topInHistory;
        private final ServerLabels serverLabels;

        public SaveLogonHistory(TopInHistory topInHistory, ServerLabels serverLabels) {
            super(Event.class);
            this.topInHistory = topInHistory;
            this.serverLabels = serverLabels;
        }

        @Override
        public void run() {
            String standbyServer = getContext().getTransientUserData(String.class);

            LogonHistoryEntry standbyServerEntry = new LogonHistoryEntry(standbyServer, serverLabels == ServerLabels.INCLUDE ? LogonHistoryEntry.ServerLabel.STANDBY : null);
            LogonHistoryEntry activeServerEntry = new LogonHistoryEntry(reloginInfo.getActiveServer(), serverLabels == ServerLabels.INCLUDE ? LogonHistoryEntry.ServerLabel.ACTIVE : null);

            if (topInHistory == TopInHistory.ACTIVE) {
                AALogonHistoryController.getInstance().saveServersInHistory(standbyServerEntry, activeServerEntry);
            } else {
                AALogonHistoryController.getInstance().saveServersInHistory(activeServerEntry, standbyServerEntry);
            }
        }
    }

    private void initStateMachine() {
        stateTransitions = new FsmTableBuilder<>(State.class, Event.class);
        stateTransitions.whenIn(State.STANDALONE).onEvent(Event.ASSIGNED).goTo(State.ASSIGNED);
        stateTransitions.whenIn(State.STANDALONE).onEvent(Event.SHUTDOWN_SCHEDULED).goTo(State.STANDALONE_WAITING_SHUTDOWN);
        stateTransitions.whenIn(State.ASSIGNED).onEvent(Event.UNASSIGNED).goTo(State.STANDALONE);
        stateTransitions.whenIn(State.ASSIGNED).onEvent(Event.SHUTDOWN_SCHEDULED).goTo(State.ASSIGNED_WAITING_SHUTDOWN);
        stateTransitions.whenIn(State.ASSIGNED_WAITING_SHUTDOWN).onEvent(Event.SHUTDOWN_CANCELED).goTo(State.ASSIGNED);
        stateTransitions.whenIn(State.ASSIGNED_WAITING_SHUTDOWN).onEvent(Event.UNASSIGNED).goTo(State.STANDALONE_WAITING_SHUTDOWN);
        stateTransitions.whenIn(State.STANDALONE_WAITING_SHUTDOWN).onEvent(Event.SHUTDOWN_CANCELED).goTo(State.STANDALONE);

        stateTransitions.whenIn(State.STANDALONE)
                .execute(new ClearStandbyServer())
                .execute(new SaveLogonHistory(TopInHistory.ACTIVE, ServerLabels.EXCLUDE));
        stateTransitions.whenIn(State.ASSIGNED)
                .execute(new SaveStandbyServer())
                .execute(new SaveLogonHistory(TopInHistory.ACTIVE, ServerLabels.INCLUDE));
        stateTransitions.whenIn(State.ASSIGNED_WAITING_SHUTDOWN)
                .execute(new SaveLogonHistory(TopInHistory.STANDBY, ServerLabels.INCLUDE));
        stateTransitions.whenIn(State.STANDALONE_WAITING_SHUTDOWN)
                .execute(new SaveStandbyServer())
                .execute(new SaveLogonHistory(TopInHistory.STANDBY, ServerLabels.INCLUDE));

        resetStateMachine();
    }

    private void resetStateMachine() {
        stateMachine = new Fsm<>(LOGGER, State.STANDALONE, stateTransitions.build(), FsmAction::run);
    }
}
