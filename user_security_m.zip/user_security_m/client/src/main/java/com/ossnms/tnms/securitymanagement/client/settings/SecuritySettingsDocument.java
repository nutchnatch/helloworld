package com.ossnms.tnms.securitymanagement.client.settings;

import org.apache.log4j.Logger;

import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDataChangeListener;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkJob;
import com.ossnms.bicnet.securitymanagement.client.SecurityInactivityClientCtl;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.tnms.securitymanagement.client.jobs.SecuritySettingsFetchJob;
import com.ossnms.tnms.securitymanagement.client.jobs.SecuritySettingsJob;

public class SecuritySettingsDocument extends FrameworkDocument {


    private static final Logger LOGGER = Logger.getLogger(SecuritySettingsDocument.class);

    private IFrameworkDataChangeListener generalSettingsDataChangeListener;

    private boolean isLDAPEnabled;
    private boolean isRadiusEnabled;
    
    public SecuritySettingsDocument() {
        super(USMUtility.getInstance());
    }

    @Override
    public void init() {
        super.init();

        SecuritySettingsFetchJob job = new SecuritySettingsFetchJob(this);
        this.addAndExecuteJob(job);
    }

    @Override
    public void setResult(IFrameworkJob job, Object result) {
        if(job instanceof SecuritySettingsFetchJob && result != null) {
            SecuritySettingsManager.getInstance().setGeneralSettingsData((GSGeneralSettingData) result);
            SecurityInactivityClientCtl.getInstance().handleNotification((GSGeneralSettingData) result);

            this.isLDAPEnabled = ((GSGeneralSettingData) result).getLdapConfigurationData().isEnabled();
            this.isRadiusEnabled = ((GSGeneralSettingData) result).getRadiusConfigurationData().isEnabled();

            this.dataChanged(SecuritySettingsManager.getInstance().getGeneralSettingsData());
        } else if(job instanceof SecuritySettingsJob && result != null) {
            this.dataChanged(result);
        } else {
            LOGGER.error("Received an invalid job or the result value is null");
        }

    }

    @Override
    public Object getObject(Object obj) {
        if(obj instanceof GSGeneralSettingData) {
            return SecuritySettingsManager.getInstance().getGeneralSettingsData();
        } else {
            return null;
        }
    }

    private void dataChanged(Object obj) {
        if(this.generalSettingsDataChangeListener != null) {
            this.generalSettingsDataChangeListener.updateData(obj);
        }
    }

    @Override
    public void setDataChangeListener(IFrameworkDataChangeListener listener) {
        super.setDataChangeListener(listener);
        this.generalSettingsDataChangeListener = listener;
    }

    public void setSecuritySettingsData(GSGeneralSettingData data) {
        SecuritySettingsManager.getInstance().setGeneralSettingsData(data);
        SecuritySettingsJob job = new SecuritySettingsJob(this);
        job.setConfigData(data);
        this.addAndExecuteJob(job);
    }

    public GSGeneralSettingData getGeneralSettingsData() {
        return SecuritySettingsManager.getInstance().getGeneralSettingsData();
    }

    /**
     *
     * @param LDAPEnabled
     */
    public void setLDAPEnabled(boolean LDAPEnabled) {
        isLDAPEnabled = LDAPEnabled;
        dataChanged(null);
    }

    /**
     *
     * @param radiusEnabled
     */
    public void setRadiusEnabled(boolean radiusEnabled) {
        isRadiusEnabled = radiusEnabled;
        dataChanged(null);
    }

    /**
     *
     * @return
     */
    public boolean isLDAPEnabled() {
        return isLDAPEnabled;
    }

    /**
     *
     * @return
     */
    public boolean isRadiusEnabled() {
        return isRadiusEnabled;
    }
}
