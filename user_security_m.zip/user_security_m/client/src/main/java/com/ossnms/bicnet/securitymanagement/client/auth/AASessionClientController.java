package com.ossnms.bicnet.securitymanagement.client.auth;

import com.ossnms.bicnet.bcb.facade.security.IEnhancedSessionContext;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginRunnable;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginRunnableStopListener;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSite;
import com.ossnms.bicnet.bcb.plugin.security.IPluginSecurityProvider;
import com.ossnms.bicnet.securitymanagement.client.SecurityPlugin;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMBaseController;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.logonevt.USMLogonLogoffEvtRegistrar;
import com.ossnms.bicnet.securitymanagement.client.basic.notification.USMNotificationRegistrar;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;
import com.ossnms.bicnet.securitymanagement.common.auth.AAMessageType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonHelper;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.bicnetserver.BSMessageType;
import com.ossnms.bicnet.securitymanagement.common.domain.DCMessageType;
import com.ossnms.bicnet.securitymanagement.common.policy.PAMessageType;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
* This is the main client interactor component which controls the session
* on the client side. 
* This class instance will be created on successful login and register for interested notification.
* Whenever Mapping or policy changes notification comes, it will get new security data cache from the server.  
*/
public final class AASessionClientController extends USMBaseController {

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(AASessionClientController.class);

	/**
	 * Data member for the singleton instance.
	 */
	private static AASessionClientController self = new AASessionClientController();

	/**
	 * Helper function to set the value of the associated view.
	 * @param view View which is associated with this controller.
	 */
	public void setAssociatedView(USMBaseView view) {
		associatedView = view;
	}

	/**
		* Static AASessionClientController to retrieve the static instance of the
		* AASessionClientController's instance
		*
		* @return AASessionClientController The singleton object.
		*/
	public static synchronized AASessionClientController getInstance() {
		return self;
	}

	/**
	 * It is Default constructor to register notification for security data cache to be rebuilt    
	 */
	//Fault ID 30
	private AASessionClientController() {
		super();

		//Policy or Mapping changes notification is subscribed for this handler
		List<USMBaseMsgType> lstInterestingNotifications = new ArrayList<>();

		// Domain Notifications
		lstInterestingNotifications.add(DCMessageType.DC_NOT_DOMAIN_CREATED);
		lstInterestingNotifications.add(DCMessageType.DC_NOT_DOMAIN_MODIFIED);
		lstInterestingNotifications.add(DCMessageType.DC_NOT_DOMAIN_DELETED);

		// Mappings Notifications
		lstInterestingNotifications.add(DCMessageType.DC_NOT_MAPPINGS_MODIFIED);

		// Policy Notifications        
		lstInterestingNotifications.add(PAMessageType.S_PA_NOT_POLICY_CREATED);
		lstInterestingNotifications.add(PAMessageType.S_PA_NOT_POLICY_MODIFIED);
		lstInterestingNotifications.add(PAMessageType.S_PA_NOT_POLICY_DELETED);

		// ACL Notifications
		lstInterestingNotifications.add(
			BSMessageType.BS_NOT_SEC_OBJS_ASSIGNED_TO_DOMAINS);
		lstInterestingNotifications.add(
			BSMessageType.BS_NOT_SEC_OBJS_UNASSIGNED_FROM_DOMAINS);

		// Securable Object Notifications
		lstInterestingNotifications.add(
			BSMessageType.BS_NOT_NEW_SEC_OBJ_REGISTERED);
		lstInterestingNotifications.add(
			BSMessageType.BS_NOT_SEC_OBJ_UNREGISTERED);

		//Added for force log out
		lstInterestingNotifications.add(AAMessageType.AA_NOTIFICATION_USER_FORCE_LOGOUT);
		
		//Added for force log out due to Trial Expired
		lstInterestingNotifications.add(
			AAMessageType.AA_NOTIFICATION_USER_FORCE_LOGOUT_TRIAL_EXPIRED);
		

		//Added for profile notification
		lstInterestingNotifications.add(AAMessageType.AA_NOT_PROFILE_UPDATED);

		//Added for profile deletion
		lstInterestingNotifications.add(AAMessageType.AA_NOT_PROFILE_DELETED);

		//Added for profile notification
		lstInterestingNotifications.add(
			AAMessageType.AA_NOTIFICATION_SERVER_SHUTDOWN);

		USMNotificationRegistrar.getInstance().register(
			lstInterestingNotifications,
			this);

		boolean bSecurityChkDisabled =
			USMCommonHelper.isSecurityCheckDisabled();

		if (!bSecurityChkDisabled) {
			// Only if the security check is disabled should
			// we check if password is to be changed or not.
			USMLogonLogoffEvtRegistrar.getInstance().register(
				new AALogonListener());
		}
	}

	/**
	 * Handles notification received from the server. 
	 *
	 * @param  notifMsg - Message received from the server wrapped in USMMessage
	 */
	@Override
    public void handleNotification(USMMessage notifMsg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handleNotification Entry. " + notifMsg);
		}
		USMBaseMsgType type = notifMsg.getMessageType();
		if (type.equals(AAMessageType.AA_NOTIFICATION_USER_FORCE_LOGOUT)) {
			handleUserLoggedOut(notifMsg);
		} else if (type.equals(AAMessageType.AA_NOTIFICATION_USER_FORCE_LOGOUT_TRIAL_EXPIRED)) {	
			// GUI message for users that were forcefully logged off: "Your are logged out forcefully due to trial mode expiration".
			handleUserLoggedOutTrialExpired(notifMsg);
		} else if (type.equals(AAMessageType.AA_NOT_PROFILE_UPDATED)) {
			//Profile data is retrieved from server & profile cache is rebuilt.
			AAUserProfileCache instProfileCache =
				AAUserProfileCache.getInstance();
			instProfileCache.handleNotification(notifMsg);

		}else if (type.equals(AAMessageType.AA_NOT_PROFILE_DELETED)) {
			//Profile data is retrieved from server & profile cache is rebuilt.
			AAUserProfileCache instProfileCache =
				AAUserProfileCache.getInstance();
			instProfileCache.handleNotification(notifMsg);

		} 
		else if (
			type.equals(AAMessageType.AA_NOTIFICATION_SERVER_SHUTDOWN)) {
			// Server has been shut down. So cleanup
			handleServerShutDown(notifMsg);
		} else {
			//Here security data is retrieved from server & cache is rebuilt.
			AAClientCache instClientCache = AAClientCache.getInstance();
			boolean bDataModified =
				instClientCache.handleNotification(notifMsg);

			if (bDataModified) {
				fireUserPermissionsChanged();
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handleNotification Exit. " + notifMsg);
		}

	}

	/**
	 * Function to handle Notification received for user logged of due to trial expired.
	 * @param notifMsg Message which contains information about the user logging off.
	 */
	private void handleUserLoggedOutTrialExpired(USMMessage notifMsg) {
				
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handleUserLoggedOutTrialExpired Entry. " + notifMsg);
		}
		
		try {
			USMUtility util = USMUtility.getInstance();
			IPluginSecurityProvider provider = util.getSecuritySite().getSecurityProvider();
			
			// Locate ISessionContext of logged out user
//            IEnhancedSessionContext ctxLoggedOutUser = AASessionContext.popMe(msg);
            IEnhancedSessionContext ctxLoggedOutUser = (IEnhancedSessionContext) notifMsg.popObject();
			
			// Locate ISessionContext of current user
			ISessionContext ctxCurrentUser = util.getSessionContext();
			if (ctxLoggedOutUser.equals(ctxCurrentUser)) {
				// Log off the user
				provider.logoff(provider.getClientSession(ctxCurrentUser), IPluginSecurityProvider.LogoffReason.TRIAL_EXPIRED);
			}

		} catch (BiCNetPluginException ex) {
			LOGGER.error("Exception raised.", ex);
		}
		
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handleUserLoggedOutTrialExpired Exit. " + notifMsg);
		}
		
		
	}

	/**
	 * Notify all plugins in case of permissions changed on the client.
	 */
	public void fireUserPermissionsChanged() {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("fireUserPermissionsChanged Entry. ");
		}
		try {
			SecurityPlugin plugin = USMUtility.getInstance().getSecurityPlugin();
			plugin.fireUserPermissionsChanged();
		} catch (Exception e1) {
			LOGGER.error("Exception raised. ", e1);
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("fireUserPermissionsChanged Entry. ");
		}
	}

	/**
	 * Function to handle Notification received for user logged off.
	 * @param msg Message which contains information about the user logging off.
	 */
	private void handleUserLoggedOut(final USMMessage msg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handleUserLoggedOut Entry. " + msg);
		}

		try {
			USMUtility util = USMUtility.getInstance();
			util.getSecuritySite().queueJob("UserLoggedOut", "", new LogOutRunnable(msg));
		} catch (BiCNetPluginException e) {
			LOGGER.error("Could not queue job for user logout. Message: " + e.getMessage());
		}finally {
			LOGGER.debug("handleUserLoggedOut Exit. " + msg);
		}

	}

	/**
	 * Function to handle Notification received for server shutdown.
	 * @param msg Message which contains information about the server.
	 */
	private void handleServerShutDown(USMMessage msg) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handleUserLoggedOut Entry. " + msg);
		}
		try {
			USMUtility util = USMUtility.getInstance();
			IPluginSecurityProvider provider =
				util.getSecuritySite().getSecurityProvider();
			// Get the Server Name. Currently we do nothing coz the
			// name of the server could be in some format not understandable
			// by client.
			msg.popString(); //server name

			provider.logoff(util.getSecureClientSession(), IPluginSecurityProvider.LogoffReason.SERVER_SHUTDOWN);

		} catch (BiCNetPluginException ex) {
			LOGGER.error("Exception raised.", ex);
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("handleUserLoggedOut Exit. " + msg);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
    public void resultAvailable(USMJob job, USMMessage result) {

	}

	/**
	 * Private class which implements the operation for user logout, to be used with
	 * {@link BiCNetPluginSite#queueJob(String, String, BiCNetPluginRunnable)}
	 */
	private static class LogOutRunnable implements BiCNetPluginRunnable {

		private USMMessage message;

		public LogOutRunnable(USMMessage msg) {
			this.message = msg;
		}

		/**
		 * The implementation of the plugin action's job. This method will be
		 * called from within the PluginSite's thread pool.
		 * <p/>
		 * During long time execution (e.g. when multiple server calls or time
		 * consuming calculations are made) the implementation of this method
		 * should repeatedly use the shouldStop check method to evtl. stop
		 * earlier.
		 * <p/>
		 * Note: this method's implementation should be thread safe, of course.
		 *
		 * @throws BiCNetPluginException in case of failure.
		 */
		@Override
		public void run() throws BiCNetPluginException {
			try {
				USMUtility utility = USMUtility.getInstance();
				IPluginSecurityProvider provider = USMUtility.getInstance().getSecuritySite().getSecurityProvider();
				IEnhancedSessionContext ctxLoggedOutUser = (IEnhancedSessionContext) message.popObject();

				// Locate ISessionContext of current user
				ISessionContext ctxCurrentUser = utility.getSessionContext();
				if (ctxLoggedOutUser.getUniqId() == ctxCurrentUser.getUniqId()) {
					// Log off the user
					provider.logoff(provider.getClientSession(ctxCurrentUser), IPluginSecurityProvider.LogoffReason.ADMIN_FORCED_LOGOFF);
				}
			} catch (BiCNetPluginException ex) {
				LOGGER.error("Exception raised.", ex);
			}
		}

		/**
		 * Used to link a party interested in the start of the 'stopping' phase.
		 * <p/>
		 * BiCNetPluginSite.queueJob will call this method internally, so the
		 * listener will be set after the queueJob call (before run or stop are
		 * called).
		 * <p/>
		 * Please note: this method is meant for ClientFrame internal usage, the
		 * strongly recommended BiCNetPluginRunnableBaseImpl will
		 * implement it in a way allowing only one 'subscriber', so
		 * this method should never be called by any plugin!
		 *
		 * @param listener listener for the stop operation
		 */
		@Override
		public void setStopListener(BiCNetPluginRunnableStopListener listener) {
		}

		/**
		 * Can be called by the plugin to cancel not yet started jobs or to abort
		 * already running jobs (e.g. when the user closes a window whose update is
		 * still running). PluginSite may also call this method if the job is to be
		 * canceled for any other reason.
		 * <p/>
		 * Note: this method's implementation should be thread safe.
		 */
		@Override
		public void stop() {
		}

		/**
		 * Estimates if further processing should be done on the job. Should be
		 * used by the implementation of the run method to periodically check the
		 * abort criteria. If shouldStop returns true, the run method should be
		 * exited asap (immediately if possible).
		 *
		 * @return true if job execution should be canceled asap
		 */
		@Override
		public boolean shouldStop() {
			return false;
		}
	}

}