package com.ossnms.bicnet.securitymanagement.client.settings.radius.document;

import com.ossnms.bicnet.framework.client.helpers.FrameworkDocument;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.client.settings.radius.job.RadiusServerStatusJob;
import com.ossnms.bicnet.securitymanagement.common.general.radius.status.RadiusServerStatus;
import com.ossnms.bicnet.securitymanagement.common.general.radius.status.RadiusTestConfigurationData;

/**
 *
 */
public class RadiusServerStatusDocument extends FrameworkDocument {

    /**
     *
     */
    public RadiusServerStatusDocument() {
        super(USMUtility.getInstance());
    }

    @Override
    public Object getObject(Object key) {
        if(key instanceof RadiusServerStatus) {
            return key;
        } else {
            return null;
        }
    }

    /**
     *
     * @param job
     * @param result
     */
    @Override
    public void setResult(IFrameworkJob job, Object result) {
        if(job instanceof RadiusServerStatusJob) {
            this.updateData(result);
        }
    }

    /**
     *
     * @param configurationData
     */
    public void testServer(RadiusTestConfigurationData configurationData) {
        RadiusServerStatusJob job = new RadiusServerStatusJob(this, configurationData);
        this.addAndExecuteJob(job);
    }
}
