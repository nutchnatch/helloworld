/*
 * Project		BiCNET Common Functions
 *
 * Component	CF:USM
 * Class Name  	USMClientLifeCycleControllerIfc
 * Author      	Muyeen M
 * Substitute	Asif Khan R
 * Created on	06-08-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 *   
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.basic;

/**
 * This is the base interface for all the Client side Life cycle controllers.
 * Methods like initialize and cleanup are defined in this interface
 */
public interface USMClientLifeCycleControllerIfc {

	/**
	 * Method which gets called when the subsystem is getting intialized. 
	 * All subsystem initialization are done here. This is a single point of entry for 
	 * subsystems.
	 * @return boolean  Subsystem should return true when successfully initialized
	 */
	boolean initialize();

	/**
	 * Method which gets called when the subsystem has to be 
	 * cleaned up. All subsystem cleanup are done here.
	 * @return boolean  Subsystem should return true after a successful cleanup
	 */
	boolean cleanup();

}
