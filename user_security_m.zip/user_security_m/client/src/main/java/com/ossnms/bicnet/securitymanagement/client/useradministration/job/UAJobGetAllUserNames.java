/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Class Name   UAJobGetAllUser
 * Author:      Jogender
 * Substitute	Babu B
 * Created on	12-09-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : TNMS.DX2.SM.USER_GROUP.CONFIGURE
         : TNMS.DX2.SM.USER_GROUP.CREATE
         : TNMS.DX2.SM.USER_GROUP.ASSIGN       
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 *
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.useradministration.job;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.useradministration.UADelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import org.apache.log4j.Logger;
/**
 * This class represents the job responsible for getting necessary data for user creation,
 * namely all the user names, all default domain mappings, all domains and all policies
 */
public class UAJobGetAllUserNames extends USMJob {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(UAJobGetAllUserNames.class);

	/**
	 * This is the constructor
	 * 
	 * @param pId -
	 *            This is the type of message
	 * @param pJobOwner -
	 *            The controller associated with the job
	 */
	public UAJobGetAllUserNames(USMControllerIfc pJobOwner) {
		super(
			UAMessageType.S_UA_REQ_GET_ALL_USERS,
			USMStringTable
				.IDS_UG_JOB_RET_USERS_FOR_CREATE_USER_GROUPS
				.toString(),
			USMCommonStrings.EMPTY,
			pJobOwner);
	}

	/**
	 * Executes the given job
	 *
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob#executeJob()
	 */
	@Override
    public USMMessage executeJob() {
		LOGGER.debug("executeJob()in the method");
		USMMessage msg = new UADelegate().getAllUserNameAndID();
		LOGGER.debug("executeJob()   exit from the method");
		return msg;
	}

}
