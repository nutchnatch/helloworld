/*
 * --------------------------------------------------------
 *
 * Project:	TNMS DX2
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * --------------------------------------------------------
 *
 * Component:   CF:USM
 * Author:      Vinay Purohit
 * Substitute	Babu B
 * Created on	12-07-2004
 *
 * --------------------------------------------------------
 *
 * Copyright (C)        Coriant 2013
 * All Rights reserved.
 * ReqID : 
 *       : 
 * 		 : 
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 *
 * --------------------------------------------------------
 */

package com.ossnms.bicnet.securitymanagement.client.useradministration.job;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.useradministration.UADelegate;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.useradministration.UAMessageType;
import org.apache.log4j.Logger;

import java.rmi.RemoteException;

public class UAJobCheckUsergroupContainsUser extends USMJob {

	private String user;

	private String ugrp;

	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER =
		Logger.getLogger(UAJobCheckUsergroupContainsUser.class);

	/**
	 * This is the constructor
	 * 
	 * @param p_UserGroup -
	 *            The user group object that is to be modified
	 * @param pJobOwner -
	 *            The controller associated with the job
	 */
	public UAJobCheckUsergroupContainsUser(
		String p_UserGroup,
		String p_user,
		USMControllerIfc pJobOwner) {
		super(
			UAMessageType.S_UG_NOT_CREATE_USER_GROUP,
			UAJobCheckUsergroupContainsUser.class.getName(),
			"UAJobCheckUsergroupContainsUser",
			pJobOwner);
		ugrp = p_UserGroup;
		user = p_user;
	}

	/**
	 * Executes the given job
	 *
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob#executeJob()
	 */
	public USMMessage executeJob() throws BcbSecurityException {
		LOGGER.debug("executeJob()in the method");
		USMMessage msg = null;
		try {
			msg = new UADelegate().checkUserGroupContainsUser(ugrp, user);
		} catch (RemoteException e) {
			LOGGER.debug("executeJob() error in checking");
		}
		LOGGER.debug("executeJob()   exit from the method");
		return msg;
	}

}
