package com.ossnms.bicnet.securitymanagement.client.policy.views.administration;

import com.ossnms.bicnet.securitymanagement.client.basic.controller.USMBaseController;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.policy.jobs.PAJobDeletePolicies;
import com.ossnms.bicnet.securitymanagement.client.policy.jobs.PAJobGetAllConfiguredPolicies;
import com.ossnms.bicnet.securitymanagement.client.policy.jobs.PAJobGetPermissionsForPolicy;
import com.ossnms.bicnet.securitymanagement.client.policy.views.base.PAUpdateHint;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.policy.PAMessageType;
import com.ossnms.bicnet.securitymanagement.common.policy.PAPolicyId;
import com.ossnms.bicnet.securitymanagement.common.policy.PAStatus;
import com.ossnms.tools.jfx.JfxStringTable;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * This Client Controller is responsible for interacting with the Server for
 * operations like 
 * 1. View All Configured Policies. 
 * 2. View All Configured menu options of Policy. 
 * 3. Delete a Configured Policy.
 */
public class PAPolicyAdminClientController extends USMBaseController {
	/**
	 * Data member for the Logging of the class.
	 */
	private static final Logger LOGGER = Logger.getLogger(PAPolicyAdminClientController.class);
	private static final String METHOD_RESULT_AVAILABLE = "resultAvailable()";

	/**
	 * Data member to hold the Window class that is associated with this
	 * Interactor
	 */
	private PAPolicyAdminView policyAdminWdw = null;
	private static final String METHOD_HANDLE_RES_FETCH_ALL_POLICIES = "handleResponseForFetchAllPolicies()";
	private static final String METHOD_HANDLE_RES_FETCH_PERMISSIONS_POLICY = "handleResponseForFetchPermissionsForPolicy()";

	/**
	 * Constructor
	 * 
	 * @param pView -
	 * 			View which is responsible for the creation of this Controller
	 */
	PAPolicyAdminClientController(PAPolicyAdminView pView) {
		super(pView);
		policyAdminWdw = pView;
		registerInterestedNotificationIds(getInterestedNotifications());
	}

	/**
	 * Function to return a Vector which contains the list of types that this controller is interested in.
	 * 
	 * @return The List which contains the notification the controller is interested in.
	 */
	private List<USMBaseMsgType> getInterestedNotifications() {
		LOGGER.debug("getInterestedNotifications() in the method");

		List<USMBaseMsgType> vectorForNotification = new ArrayList<>();
		vectorForNotification.add(PAMessageType.S_PA_NOT_POLICY_CREATED);
		vectorForNotification.add(PAMessageType.S_PA_NOT_POLICY_DELETED);
		vectorForNotification.add(PAMessageType.S_PA_NOT_POLICY_MODIFIED);

		LOGGER.debug("getInterestedNotifications() exit");
		return vectorForNotification;
	}

	/**
	 * This method initiates the fetching of all the Policy Names to be displayed in the Policy Administration
	 * Window. Sends the Request Message with Primitive PA_REQ_GET_POLICY_LIST
	 * 
	 * @return Indicates whether it was possible to send the request or not.
	 */
	boolean sendRequestToFetchAllPolicies() {
		PAJobGetAllConfiguredPolicies objJobGetAllPolicy = new PAJobGetAllConfiguredPolicies(this);
		return queueJob(objJobGetAllPolicy);
	}

	/**
	 *
	 * @param policy
	 * @return
	 */
	boolean sendRequestToFetchPermissionsForPolicy(PAPolicyId policy) {
		LOGGER.debug("sendRequestToFetchMenusForPolicy() fetch menu options .. in the controller");

		PAJobGetPermissionsForPolicy objJob = new PAJobGetPermissionsForPolicy(this, policy);
		return queueJob(objJob);
	}

	/**
	 * Function called by the Window, when the operator selects some Policies
	 * and presses the "Delete" button.
	 *  @param policiesForDeletion
	 *            The List of Policies that are to be removed from USM.
	 */
	boolean sendRequestToDeletePolicies(List policiesForDeletion) {
		LOGGER.debug("deletePolicy()");
		PAJobDeletePolicies objJob = new PAJobDeletePolicies(this, policiesForDeletion);
		return queueJob(objJob);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc#resultAvailable(com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob,
	 *      java.lang.Object)
	 */
	@Override
	public void resultAvailable(USMJob pJob, USMMessage result) {
		USMBaseMsgType msgObj = result.getMessageType();
		LOGGER.info(METHOD_RESULT_AVAILABLE + " MESSAGE SIZE  getting result from message" + result.getMessageType());
		if(msgObj.equals(PAMessageType.S_PA_RES_ALL_PERMISSION_POLICY_RECEIVED)){
			LOGGER.info(METHOD_RESULT_AVAILABLE + "   getting  permissions from message.");
			handleResponseForFetchPermissionsForPolicy(result);
		} else if (msgObj.equals(PAMessageType.S_PA_RES_POLICY_RECEIVED)) {
			LOGGER.info(METHOD_RESULT_AVAILABLE + "   getting  policies from message.");
			handleResponseForFetchAllPolicies(result);
		} else if (msgObj.equals(PAMessageType.S_PA_RES_POLICY_DELETED)) {
			handleResponseForDeletePolicies(result);
		} else {
			LOGGER.warn(METHOD_RESULT_AVAILABLE + " : Message could not be handled");
		}
		LOGGER.info(METHOD_RESULT_AVAILABLE + " exit");
	}

	/**
	 * This method is the handler for the Response : PA_RES_GET_POLICY_LIST.
	 * 
	 * @param message The message which contains the List of Policies that are available within USM.
	 */
	private void handleResponseForFetchAllPolicies(USMMessage message) {
		LOGGER.debug(METHOD_HANDLE_RES_FETCH_ALL_POLICIES + " ENTERING THE FUNCTION");

		boolean bOp = true;
		try {
			PAStatus statusObject = PAStatus.pop(message);

			if (statusObject == PAStatus.S_SUCCESS) {
				if (!policyAdminWdw.updateDataModel(message, new PAUpdateHint(PAUpdateHint.POLICY_LIST_FETCHED))) {
					bOp = false;
					LOGGER.debug(METHOD_HANDLE_RES_FETCH_ALL_POLICIES + "Failed to update Data Structure with the Policy List fetched.");
				}
			} else {
				bOp = false;
				LOGGER.debug(METHOD_HANDLE_RES_FETCH_ALL_POLICIES + "Server returned Error Result");
			}
		} catch (Exception ex) {
			bOp = false;
			LOGGER.debug(METHOD_HANDLE_RES_FETCH_ALL_POLICIES + "EXCEPTION: " + ex.getClass() + "Message : " + ex.getMessage());
		}

		if (!bOp) {
			policyAdminWdw.showMessage(policyAdminWdw, USMStringTable.getString(USMStringTable.IDS_PA_ERROR_POLICY_MESSAGE));
		}
	}

	/**
	 *
	 * @param message
	 */
	private void handleResponseForFetchPermissionsForPolicy(USMMessage message) {
		LOGGER.debug(METHOD_HANDLE_RES_FETCH_PERMISSIONS_POLICY + " ENTER_FUNCTION");
		boolean bOp = true;
		try {
			PAStatus statusObject = PAStatus.pop(message);
			if (statusObject == PAStatus.S_SUCCESS) {
				LOGGER.info(METHOD_HANDLE_RES_FETCH_PERMISSIONS_POLICY + "update view with the menu List fetched.");
				if (!policyAdminWdw.updateDataModel(message, new PAUpdateHint(PAUpdateHint.POLICY_DATA_FETCHED))) {
					bOp = false;
					LOGGER.info(METHOD_HANDLE_RES_FETCH_PERMISSIONS_POLICY + "Failed to update Data Structure with the menu List fetched.");
				}
			} else {
				bOp = false;
				LOGGER.info(METHOD_HANDLE_RES_FETCH_PERMISSIONS_POLICY + "Server returned Error Result");
			}
		} catch (Exception ex) {
			bOp = false;
			LOGGER.error(METHOD_HANDLE_RES_FETCH_PERMISSIONS_POLICY + "EXCEPTION: " + ex.getClass() + "Message : " + ex.getMessage());
		}

		if (!bOp) {
			LOGGER.info("Failed to Fetch Configured Permissions of selected Policy - Internal Processing Error ");
			policyAdminWdw.showMessage(policyAdminWdw, "Failed to Fetch Configured Permissions of selected Policy - Internal Processing Error ");
		}

		LOGGER.info(METHOD_HANDLE_RES_FETCH_PERMISSIONS_POLICY + " EXIT_FUNCTION ");
	}

	/**
	 * This method is the handler for the Response : PA_RES_DELETE_POLICY.
	 * 
	 * @param message The message which contains information about the status of the deletion of the Policy.
	 */
	private void handleResponseForDeletePolicies(USMMessage message) {
		final String functionName = "handleResponseForDeletePolicies ()";
		LOGGER.debug(functionName + " ENTER_FUNCTION");

		boolean showErrorMessage = false;
		StringBuilder errorMessage =
			new StringBuilder(
				JfxStringTable.getString(
					USMStringTable.IDS_PA_DELETE_MESSAGE_FOR_POLICY));
		PAStatus generalOperationStatus = PAStatus.pop(message);
		if (generalOperationStatus == PAStatus.S_SUCCESS) {
			int nPolicies = message.popInteger();
			for (int i = 0; i < nPolicies; ++i) {
				PAStatus individualOperationStatus = PAStatus.pop(message);
				PAPolicyId deletedPolicy = new PAPolicyId();
				deletedPolicy.popMe(message);
				if (individualOperationStatus == PAStatus.S_POLICY_DOES_NOT_EXIST) {
					showErrorMessage = true;
					errorMessage.append("\n");
					errorMessage.append(deletedPolicy.getPolicyName());
					errorMessage.append(" - The policy does not exist");
				} else if (individualOperationStatus == PAStatus.S_POLICY_CANNOT_BE_DELETED_SINCE_MAPPED) {
					showErrorMessage = true;
					errorMessage.append("\n");
					errorMessage.append(deletedPolicy.getPolicyName());
					errorMessage.append(" - The policy is included in one or more mapping");
				} else if (individualOperationStatus == PAStatus.S_PERSISTENCE_ERROR) {
					showErrorMessage = true;
					errorMessage.append("\n");
					errorMessage.append(deletedPolicy.getPolicyName());
					errorMessage.append(" - The policy could not be deleted from the LDAP directory server");
				} else if (individualOperationStatus != PAStatus.S_SUCCESS){
					showErrorMessage = true;
					errorMessage.append("\n");
					errorMessage.append(deletedPolicy.getPolicyName());
					errorMessage.append(" - Internal processing error");
					LOGGER.info(functionName + "Server returned Error Result");
				}
			}
		} else {
			showErrorMessage = true;
            errorMessage = new StringBuilder("Failed to delete the selected policy(s) - General Error");
		}

		if (showErrorMessage) {
			policyAdminWdw.showMessage(policyAdminWdw, errorMessage.toString());
		}

		LOGGER.debug(functionName + " EXIT_FUNCTION");

	}




	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ossnms.bicnet.securitymanagement.client.basic.controller.USMControllerIfc#handleNotification(com.ossnms.bicnet.securitymanagement.common.basic.USMMessage)
	 */
	@Override
    public void handleNotification(USMMessage message) {
		USMBaseMsgType type = message.getMessageType();
		if (type.equals(PAMessageType.S_PA_NOT_POLICY_CREATED)) {
			handleNotificationPolicyCreated(message);
		} else if (type.equals(PAMessageType.S_PA_NOT_POLICY_DELETED)) {
			handleNotificationPolicyDeleted(message);
		} else if (type.equals(PAMessageType.S_PA_NOT_POLICY_MODIFIED)) {
			handleNotificationPolicyModified(message);
		}
	}

	/**
	 * This method is the handler for the Notification :
	 * PA_NOTIFY
	 * POLICY_CREATED
	 * 
	 * @param message The message which contains information about the created Policy.
	 */
	private void handleNotificationPolicyCreated(USMMessage message) {
		((PAPolicyAdminView) associatedView).updateDataModel(message,	new PAUpdateHint(PAUpdateHint.POLICY_CREATED));
	}

	/**
	 * This method is the handler for the Notification : PA_NOTIFY
	 * POLICY_DELETED
	 * 
	 * @param message The message which contains the information about the deleted Policy.
	 */
	private void handleNotificationPolicyDeleted(USMMessage message) {
		((PAPolicyAdminView) associatedView).updateDataModel(message, new PAUpdateHint(PAUpdateHint.POLICY_DELETED));
	}

	/**
	 * This method is the handler for the Notification : PA_NOTIFY
	 * POLICY_MODIFIED
	 * 
	 * @param message The message which contains information about the modified Policy.
	 */
	private void handleNotificationPolicyModified(USMMessage message) {
		((PAPolicyAdminView) associatedView).updateDataModel(message,	new PAUpdateHint(PAUpdateHint.POLICY_MODIFIED));
	}

}