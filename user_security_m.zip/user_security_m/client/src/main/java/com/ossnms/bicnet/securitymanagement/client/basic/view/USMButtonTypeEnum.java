/*
 * -------------------------History-------------------------
 * 
 * created:  09-06-2004
 * first version completed: 18-06-2004
 * Fault ID 42, 43, 44, 76 - Provide Button Level Authorization for XX Windows - Begin (XX is for AA, PA, DC and BS)
 *
 * <date>       <author>        <reason(s) of change>
 * 09-02-2005   Babu B          CF000060-01   CF USM GUI Requirements
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.view;

import com.ossnms.bicnet.resources.ResourcesIconFactory;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.tools.jfx.JfxIconImpl;
import com.ossnms.tools.jfx.JfxText;

/**
 * Class which represents the enum for the Button Types.
 */
public final class USMButtonTypeEnum {
    /**
     * This is the object which represents the OK Button
     */
    public static final USMButtonTypeEnum BTN_TYPE_OK = new USMButtonTypeEnum(USMStringTable.IDS_BUTTON_OK, ResourcesIconFactory.ICON_TOOL_OK_16);

    /**
     * This is the object which represents the Cancel Button
     */
    public static final USMButtonTypeEnum BTN_TYPE_CANCEL = new USMButtonTypeEnum(USMStringTable.IDS_BUTTON_CANCEL, ResourcesIconFactory.ICON_TOOL_CANCEL_16);

    /**
     * This is the object which represents the Apply Button
     */
    public static final USMButtonTypeEnum BTN_TYPE_APPLY = new USMButtonTypeEnum(USMStringTable.IDS_Apply, ResourcesIconFactory.ICON_TOOL_APPLY_16);

    /**
     * This is the object which represents the Close Button
     */
    public static final USMButtonTypeEnum BTN_TYPE_CLOSE = new USMButtonTypeEnum(USMStringTable.IDS_Close, ResourcesIconFactory.ICON_TOOL_CLOSE_16);

    /**
     * This is the object which represents the Help Button
     */
    public static final USMButtonTypeEnum BTN_TYPE_HELP = new USMButtonTypeEnum(USMStringTable.IDS_Help, ResourcesIconFactory.ICON_TOOL_ONLHELP_16);

    /**
     * This is the object which represents the Properties Button
     */
    public static final USMButtonTypeEnum BTN_TYPE_PROPERTIES = new USMButtonTypeEnum(USMStringTable.IDS_PROPERTIES, ResourcesIconFactory.ICON_TOOL_PROPERTIES_16);

    /**
     * This is the object which represents the Remove Button
     */
    public static final USMButtonTypeEnum BTN_TYPE_REMOVE = new USMButtonTypeEnum(USMStringTable.IDS_REMOVE, ResourcesIconFactory.ICON_TOOL_REMOVE_16);

    /**
     * This is the object which represents the Sync NE Button
     */
    public static final USMButtonTypeEnum BTN_TYPE_SYNC_NE = new USMButtonTypeEnum(USMStringTable.IDS_SYNC_NE, ResourcesIconFactory.ICON_TOOL_SYNC_NE_16);

    /**
     * This is the object which represents the Sync ACL Button
     */
    public static final USMButtonTypeEnum BTN_TYPE_SYNC_ACL = new USMButtonTypeEnum(USMStringTable.IDS_SYNC_ACL, ResourcesIconFactory.ICON_TOOL_SYNC_ACL_16);

    /**
     * This is the object which represents the Sync Security Data Button
     */
    public static final USMButtonTypeEnum BTN_TYPE_SYNC_SEC_DATA = new USMButtonTypeEnum(USMStringTable.IDS_SYNC_SECURITY_DATA, ResourcesIconFactory.ICON_TOOL_SYNC_SD_16);

    /**
     * This is the object which represents the Create Button
     */
    public static final USMButtonTypeEnum BTN_TYPE_NEW = new USMButtonTypeEnum(USMStringTable.IDS_NEW, ResourcesIconFactory.ICON_TOOL_NEW_16);

    /**
     * This is the object which represents the Delete Button
     */
    public static final USMButtonTypeEnum BTN_TYPE_DELETE = new USMButtonTypeEnum(USMStringTable.IDS_Delete, ResourcesIconFactory.ICON_TOOL_DELETE_16);

    /**
     * This is the object which represents the Assign policy Button
     */
    public static final USMButtonTypeEnum BTN_TYPE_ASSIGN_POLICY = new USMButtonTypeEnum(USMStringTable.IDS_ASSIGN_POLICY, ResourcesIconFactory.ICON_TOOL_ASSIGN_16);

    /**
     * This is the object which represents the Import Button
     */
    public static final USMButtonTypeEnum BTN_TYPE_MODIFY = new USMButtonTypeEnum(USMStringTable.IDS_SYNC_MODIFY, ResourcesIconFactory.ICON_TOOL_MOD_16);

    /**
     * This is the object which represents the Force Logoff Button
     */
    public static final USMButtonTypeEnum BTN_TYPE_FORCE_LOGOFF = new USMButtonTypeEnum(USMStringTable.IDS_UA_BUTTON_FORCE_LOGOFF, ResourcesIconFactory.ICON_TOOL_FORCELOGOFF_16);

    /**
     * This is the object which represents the Unlock User Button
     */
    public static final USMButtonTypeEnum BTN_TYPE_UNLOCK = new USMButtonTypeEnum(USMStringTable.IDS_UA_BUTTON_UNLOCK, ResourcesIconFactory.ICON_TOOL_UNLOCK_USER_16);

    /**
     * This is the object which represents the Activate User Button
     */
    public static final USMButtonTypeEnum BTN_TYPE_ACTIVATE = new USMButtonTypeEnum(USMStringTable.IDS_UA_BUTTON_ACTIVATE, ResourcesIconFactory.ICON_TOOL_ACTIVATE_USER_16);

    /**
     * This is the object which represents the Deactivate User Button
     */
    public static final USMButtonTypeEnum BTN_TYPE_DEACTIVATE = new USMButtonTypeEnum(USMStringTable.IDS_UA_BUTTON_DEACTIVATE, ResourcesIconFactory.ICON_TOOL_DEACTIVATE_USER_16);
    
    /**
     * This is the object which represents the Button Separator
     */
    public static final USMButtonTypeEnum BTN_SEPARATOR = new USMButtonTypeEnum();

    private USMButtonTypeEnum() {
    }

    /**
     * Text that is associated with the Button
     */
    private JfxText buttonName;

    /**
     * The icon that is associated with this Button type.
     */
    private javax.swing.Icon icon;

    /**
     * The Constructor has been made as private to make sure that new instances of this class are not created. 
     * Only the instances that are defined within this class shall be used.
     * 
     * @param p_Type -
     *            This indicates the exact type of the button that this class is supposed to represent.
     * @param p_strURLIcon -
     *            This is the relative URL that should be used to specify the file to be loaded.
     */
    private USMButtonTypeEnum(JfxText textName, JfxIconImpl iconID) {
        icon = iconID;
        buttonName = textName;
    }

    /**
     * Returns the Name of the Button
     * @return
     * 		String which represents the name of the button
     */
    JfxText getButtonName() {
        return buttonName;
    }

    /**
     * Function to return the Icon that is associated with this button
     * 
     * @return javax.swing.ImageIcon - The icon that is associated with this
     *         button
     */
    javax.swing.Icon getIcon() {
        return icon;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        boolean bEquals = false;
        if ((obj instanceof USMButtonTypeEnum) && (null != obj)) {
            USMButtonTypeEnum usmObject = (USMButtonTypeEnum) obj;
            bEquals = (usmObject.buttonName == buttonName) ? true : false;
        }
        return bEquals;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        return icon.hashCode();
    }
}