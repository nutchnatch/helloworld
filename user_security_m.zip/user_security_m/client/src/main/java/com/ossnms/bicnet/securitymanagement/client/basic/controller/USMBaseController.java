/*
 * ------------------------History-------------------------
 *
 * <date>       <author>        <reason(s) of change>
 * 15-Mar-2005  Babu B          CF001663 - Handle login in separate Thread
 * 26-May-2005  Muyeen Munaver  CF002321 - Client Message Flow Control
 * 26-May-2005  Muyeen Munaver  CF002360 - Improve "TMN Application Server Administration" window - server no securable obj
 * 06-May-2009  Nagaraddi S S    TD004578 - RQT-STDERR errors instead log4j's
 * --------------------------------------------------------
 */
package com.ossnms.bicnet.securitymanagement.client.basic.controller;

import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.securitymanagement.client.basic.controller.jobs.USMJob;
import com.ossnms.bicnet.securitymanagement.client.basic.notification.USMNotificationRegistrar;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.client.basic.view.USMBaseView;
import com.ossnms.bicnet.securitymanagement.common.basic.USMBaseMsgType;
import com.ossnms.bicnet.securitymanagement.common.basic.USMMessage;
import com.ossnms.bicnet.securitymanagement.common.basic.USMTimeTracer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This class is the base class for all the controllers within the common
 * function User and Security Management.
 * 
 * This class has the following responsibilties - 1) Keep tab of the Jobs that
 * are currently available. 2) Provides mechanisms for the concrete classes to
 * register with the topic, for listening to notifications. 3) Queueing of jobs
 * so that they can be executed by the client frame. 4) The most important of
 * the function is that it provides mechanism by which the result of the bean
 * operation is invoked or run on the event dispatching thread.
 */
public abstract class USMBaseController implements USMControllerIfc {
    /**
     * Data member to hold a map of jobs
     */
    protected final Map<USMBaseMsgType, USMJob> jobs;

    /**
     * Data member to hold the View object that is associated with this
     * controller.
     */
    protected USMBaseView associatedView;

    /**
     * Data member for the Logging of the class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(USMBaseController.class);

    // Fault ID 61 - Wrong "Policy has been Deleted" message
    /**
     * Data member to hold the Interested Notification Ids.
     */
    private List<USMBaseMsgType> lstInterestedNotification;
    
    /**
     * Data member to hold the Wait String
     */
    private static final String WAIT = USMStringTable.IDS_PLZ_WAIT.toString();

    /**
     * Data member to hold the Ready String
     */
    private static final String READY = USMStringTable.IDS_READY.toString();

    /**
     * This is the Constructor
     * 
     * @param view -
     *            This is the view associated with the controller.
     */
    protected USMBaseController(USMBaseView view) {
        LOGGER.debug("Entering the constructor. View being passed is : " + view);

        if (null == view) {
            LOGGER.error("The View cannot be sent as null");
            throw new InvalidParameterException();
        }

        jobs = new HashMap<>();
        associatedView = view;
    }

    /**
     * This is the Constructor
     * 		This has been added in case of controllers which have no views
     * but are required to update the cache on the client side on notifications
     * Eg. Authorization.
     */
    // Fault ID 6 - USMBaseController should have a no parameter constructor
    protected USMBaseController() {
        jobs = new HashMap<>();
    }

    /**
     * This registers the notification Ids with the registrar.
     * 
     * @param listToReg -
     *            The list of notification Ids to be registered.
     */
    protected final void registerInterestedNotificationIds(List<USMBaseMsgType> listToReg) {
        LOGGER.debug("Entering the registerInterestedNotificationIds. Notification IDs are : " + listToReg);

        if (null == listToReg) {
            LOGGER.warn("The list of notification ids cannot be null. Setting it to empty");
            listToReg = new ArrayList<>();
        }

        lstInterestedNotification = listToReg;
        USMNotificationRegistrar.getInstance().register(lstInterestedNotification,this);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void addJob(USMJob job) {
            LOGGER.debug("Entering the addJob. Adding Job : " + job);

        if (null == job) {
            LOGGER.error("Job passed cannot be null.");
            return;
        }

        synchronized (jobs) {
            job.registerJobAddedToQueue();
            jobs.put(job.getID(), job);
        }

        // Since there is a Job it means that we have to wait for some
        // response.
        if (associatedView != null) {
            associatedView.setWaitCursor();
            String str = WAIT + job.getName();
            checkAndDisplayStatusMessage(str);
       }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void endJob(USMJob job) {
        LOGGER.debug("Entering the endJob. Adding Job : " + job);

        if (null == job) {
            LOGGER.error("Job passed cannot be null.");
            return;
        }
        boolean bFlagSetNormalCursor;

        synchronized (jobs) {
            jobs.remove(job.getID());
            bFlagSetNormalCursor = (jobs.size() == 0);
        }

        if (bFlagSetNormalCursor) {
            // Now we have recieved all the responses for the requests. So
            // we can remove the cursor.
            if (associatedView != null) {
                associatedView.setNormalCursor();
                checkAndDisplayStatusMessage(READY);
            }
        } else {
            // Now we are not sure what message to display, coz one job has completed,
            // but there are some more jobs. So best display "Please wait".
            checkAndDisplayStatusMessage(WAIT);
        }
    }

    /**
     * Helper function which checks if the associated view has a status bar.
     * If it does have a status bar, then the message passed is displayed
     * 
     * @param str Message to be displayed
     */
    private void checkAndDisplayStatusMessage(String str) {
        LOGGER.debug("checkAndDisplayStatusMessage :: {}", str);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean queueJob(USMJob job) {
        boolean bQueued = false;

        try {
            addJob(job);
            USMUtility.getInstance().getSecuritySite().queueJob(job.getName(), job.getAdditionalInfo(), job);
            bQueued = true;
        } catch (BiCNetPluginException e) {
        	LOGGER.error("Exception :", e);
        }
        return bQueued;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void initialize() {
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void cleanup() {
        LOGGER.debug("Entering cleanup.");

        USMNotificationRegistrar.getInstance().deRegister(lstInterestedNotification,this);
        if (lstInterestedNotification != null) {
            lstInterestedNotification.clear();
        }
        lstInterestedNotification = null;

        if (associatedView != null) {
            associatedView = null;
        }

        LOGGER.debug("Exiting cleanup.");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final void setResult(final USMJob job, final USMMessage msg) {
        LOGGER.debug("Inside the setResult. USMJob is : " + job + " Message recieved is : " + msg);

        if ((null == job) || (null == msg)) {
            LOGGER.error("Null parameter recieved. USMJob is : " + job + " Message received is : " + msg);
            throw new InvalidParameterException();
        }

        SwingUtilities.invokeLater(() -> {
            job.registerGUIUpdateStarted();
            resultAvailable(job, msg);
            job.registerGUIUpdateComplete();
        });

        endJob(job);

        LOGGER.debug("Exiting setResult");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final void notificationReceived(final USMMessage msg) {
        LOGGER.debug("Inside the notificationReceived. Message received is : " + msg);

        if (null == msg) {
            LOGGER.error("Inside notificationReceived. Message received is null");
            throw new InvalidParameterException();
        }

        USMTimeTracer timer = new USMTimeTracer();
        handleNotification(msg);
        timer.registerFinish();

        LOGGER.debug("Time taken for handleNotification is : " + timer.getTimeForCompleteJob());
        LOGGER.debug("Exiting notificationReceived");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void handleBcbSecurityException(USMJob job, BcbSecurityException excp) {
        LOGGER.debug("Entering handleBcbSecurityException. Exception raised is : " + excp);

        endJob(job);

        if (null != associatedView) {
            associatedView.handleBcbSecurityException(excp);
        }

        LOGGER.debug("Exiting handleBcbSecurityException.");
    }
}