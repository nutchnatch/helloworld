package com.ossnms.tnms.securitymanagement.client.settings;

import com.coriant.widgets.icons.CommonIcons;
import com.coriant.widgets.spinner.SpinnerIntegerModel;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientLogEntry;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientLogSeverity;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginException;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginFrame;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginPropertyPageSite;
import com.ossnms.bicnet.bcb.plugin.BiCNetPluginSettingsPropertyPage;
import com.ossnms.bicnet.bcb.plugin.DefaultPluginClientLogEntry;
import com.ossnms.bicnet.framework.client.helpers.interfaces.IFrameworkDataChangeListener;
import com.ossnms.bicnet.framework.client.notificationpopup.NotificationPopupDetails;
import com.ossnms.bicnet.framework.client.notificationpopup.NotificationPopupManager;
import com.ossnms.bicnet.securitymanagement.client.basic.command.USMCommandID;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMStringTable;
import com.ossnms.bicnet.securitymanagement.client.basic.utils.USMUtility;
import com.ossnms.bicnet.securitymanagement.client.common.USMTextField;
import com.ossnms.bicnet.securitymanagement.client.settings.radius.document.RadiusServerStatusDocument;
import com.ossnms.bicnet.securitymanagement.common.auth.RadiusUserGroupAttribute;
import com.ossnms.bicnet.securitymanagement.common.general.GSGeneralSettingData;
import com.ossnms.bicnet.securitymanagement.common.general.ResponseMessage;
import com.ossnms.bicnet.securitymanagement.common.general.ldap.LDAPConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.radius.configuration.RadiusConfigurationData;
import com.ossnms.bicnet.securitymanagement.common.general.radius.configuration.RadiusSettingsResponseMessage;
import com.ossnms.bicnet.securitymanagement.common.general.radius.status.RadiusServerStatus;
import com.ossnms.bicnet.securitymanagement.common.general.radius.status.RadiusTestConfigurationData;
import com.ossnms.tools.jfx.JfxCheckBoxTitlePanel;
import com.ossnms.tools.jfx.JfxStringTable;
import com.ossnms.tools.jfx.JfxText;
import com.ossnms.tools.jfx.JfxUtils;
import com.ossnms.tools.jfx.components.JfxButton;
import com.ossnms.tools.jfx.components.JfxComboBox;
import com.ossnms.tools.jfx.components.JfxComboBox.ItemData;
import com.ossnms.tools.jfx.components.JfxLabel;
import com.ossnms.tools.jfx.components.JfxPasswordField;
import com.ossnms.tools.jfx.components.JfxSpinner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import static com.ossnms.bicnet.bcb.plugin.BiCNetPluginClientLogSeverity.INFORMATION;
import static com.ossnms.bicnet.framework.client.notificationpopup.NotificationPopupDetails.OpStatus.FAILED;
import static com.ossnms.bicnet.framework.client.notificationpopup.NotificationPopupDetails.OpStatus.SUCCESSFUL;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.RANGE_PORT_DEFAULT;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.RANGE_PORT_MAX;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.RANGE_PORT_MIN;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.RANGE_PORT_STEP_SIZE;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.RANGE_RETRIES_DEFAULT;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.RANGE_RETRIES_MAX;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.RANGE_RETRIES_MIN;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.RANGE_RETRIES_STEP;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.RANGE_TIMEOUT_DEFAULT;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.RANGE_TIMEOUT_MAX;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.RANGE_TIMEOUT_MIN;
import static com.ossnms.bicnet.securitymanagement.api.common.USMConstants.RANGE_TIMEOUT_STEP;
import static com.ossnms.bicnet.securitymanagement.common.auth.RadiusUserGroupAttribute.FILTER_ID;
import static com.ossnms.bicnet.securitymanagement.common.auth.RadiusUserGroupAttribute.VENDOR_SPECIFIC;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.IDS_GS_RADIUS_TEST_AVAILABLE;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.IDS_GS_RADIUS_TEST_CONNECTION_FAILED;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.IDS_GS_RADIUS_TEST_FAILED;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.IDS_GS_RADIUS_TEST_REJECTED;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.RADIUS_TEXT_HOSTNAME;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.RADIUS_TEXT_PORT;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.RADIUS_TEXT_PORT_RANGE;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.RADIUS_TEXT_RETRIES;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.RADIUS_TEXT_RETRIES_RANGE;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.RADIUS_TEXT_RETRIES_UNIT;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.RADIUS_TEXT_SHARED_SECRET;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.RADIUS_TEXT_STATUS_NOT_CONFIGURED;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.RADIUS_TEXT_STATUS_TESTING;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.RADIUS_TEXT_TEST_CONNECTION;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.RADIUS_TEXT_TIMEOUT;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.RADIUS_TEXT_TIMEOUT_RANGE;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.RADIUS_TEXT_TIMEOUT_UNIT;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.RADIUS_TEXT_USER_GROUP_ATTRIBUTE;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.RADIUS_TITLE_ALT_SERVER_SETTINGS;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.RADIUS_TITLE_CLIENT_SETTINGS;
import static com.ossnms.bicnet.securitymanagement.common.basic.USMCommonStrings.RADIUS_TITLE_SERVER_SETTINGS;

/**
 * Property page implementation for RADIUS Authentication
 */
final class RadiusAuthenticationPropertyPage extends JPanel implements ISecurityPropertyPage {

    private static final Logger LOGGER = LoggerFactory.getLogger(RadiusAuthenticationPropertyPage.class);

    private static final long serialVersionUID = 1565479275560800615L;



    private static final String TEXT_TEST_PLACEHOLDER       = "  ";

    private static final int WIDTH_SERVER_TEST = 5;

    private static List<ItemData> userGroupAttributeItems = new ArrayList<>();

    // definition of the list of ItemData
    static {
        userGroupAttributeItems.add(toItemData(VENDOR_SPECIFIC));
        userGroupAttributeItems.add(toItemData(FILTER_ID));
    }

    private transient BiCNetPluginPropertyPageSite propertyPageSite;
    private final transient SecuritySettingsDocument document;

    private final transient RadiusServerStatusDocument serverStatusDocument;
    private final transient RadiusServerStatusDocument altServerStatusDocument;

    private final transient List<ChangeListener> changeListeners = new ArrayList<>();

    private JfxCheckBoxTitlePanel titlePanel;

    private JfxLabel serverHostnameLabel            = new JfxLabel(new JfxText(RADIUS_TEXT_HOSTNAME));
    private JfxLabel altServerHostnameLabel         = new JfxLabel(new JfxText(RADIUS_TEXT_HOSTNAME));
    private JfxLabel serverSharedSecretLabel        = new JfxLabel(new JfxText(RADIUS_TEXT_SHARED_SECRET));
    private JfxLabel altServerSharedSecretLabel     = new JfxLabel(new JfxText(RADIUS_TEXT_SHARED_SECRET));
    private JfxLabel serverPortLabel                = new JfxLabel(new JfxText(RADIUS_TEXT_PORT));
    private JfxLabel altServerPortLabel             = new JfxLabel(new JfxText(RADIUS_TEXT_PORT));
    private JfxLabel serverPortRangeLabel           = new JfxLabel(RADIUS_TEXT_PORT_RANGE);
    private JfxLabel altServerPortRangeLabel        = new JfxLabel(RADIUS_TEXT_PORT_RANGE);
    private JfxLabel serverTestStatusLabel          = new JfxLabel(TEXT_TEST_PLACEHOLDER);
    private JfxLabel altServerTestStatusLabel       = new JfxLabel(TEXT_TEST_PLACEHOLDER);
    private JfxLabel userGroupAttributeLabel        = new JfxLabel(new JfxText(RADIUS_TEXT_USER_GROUP_ATTRIBUTE));
    private JfxLabel timeoutLabel                   = new JfxLabel(new JfxText(RADIUS_TEXT_TIMEOUT));
    private JfxLabel retryLabel                     = new JfxLabel(new JfxText(RADIUS_TEXT_RETRIES));
    private JfxLabel timeoutRangeLabel              = new JfxLabel(RADIUS_TEXT_TIMEOUT_RANGE);
    private JfxLabel timeoutUnitLabel               = new JfxLabel(RADIUS_TEXT_TIMEOUT_UNIT);
    private JfxLabel retryRangeLabel                = new JfxLabel(RADIUS_TEXT_RETRIES_RANGE);
    private JfxLabel retryUnitLabel                 = new JfxLabel(RADIUS_TEXT_RETRIES_UNIT);

    private SpinnerIntegerModel serverPortSpinnerModel;
    private SpinnerIntegerModel altServerPortSpinnerModel;
    private SpinnerIntegerModel timeoutSpinnerModel;
    private SpinnerIntegerModel retrySpinnerModel;

    private JfxComboBox userGroupAttributeCombo;

    private USMTextField serverHostnameField;
    private USMTextField altServerHostnameField;

    private JfxPasswordField serverSharedSecretField;
    private JfxPasswordField altServerSharedSecretField;

    private JfxSpinner serverPortSpinner;
    private JfxSpinner altServerPortSpinner;
    private JfxSpinner timeoutSpinner;
    private JfxSpinner retrySpinner;

    private JfxButton serverTestButton;
    private JfxButton altServerTestButton;
    private JfxButton defaultButton;

    /**
     *
     * @param document
     */
    RadiusAuthenticationPropertyPage(SecuritySettingsDocument document) {
        this.document = document;

        this.serverStatusDocument = new RadiusServerStatusDocument();
        this.altServerStatusDocument = new RadiusServerStatusDocument();

        initLayout();
        initListeners();

        setUINames();
    }

    /**
     * Sets the ui names, need to identify elements by id when developing automated tests
     */
    private void setUINames() {
        LOGGER.debug("setUINames >>");

        titlePanel                  .setName("TitlePanel");
        timeoutSpinner              .setName("TimeoutSpinner");
        retrySpinner                .setName("RetrySpinner");
        userGroupAttributeCombo     .setName("UserGroupAttributeCombo");
        serverHostnameField         .setName("ServerHostnameField");
        altServerHostnameField      .setName("AltServerHostnameField");
        serverPortSpinner           .setName("ServerPortSpinner");
        altServerPortSpinner        .setName("AltServerPortSpinner");
        serverSharedSecretField     .setName("ServerSharedSecretField");
        altServerSharedSecretField  .setName("AltServerSharedSecretField");

        serverTestButton            .setName("ServerTestButton");
        altServerTestButton         .setName("AltServerTestButton");

        defaultButton               .setName("DefaultButton");
    }

    @Override
    public void saveData(SecuritySettingsData data) {
        RadiusConfigurationData configurationData = new RadiusConfigurationData();

        boolean isEnabled = titlePanel.isSelected();

        // check if the configuration data is enabled
        configurationData.setEnabled(isEnabled);

        configurationData.setTimeout((Integer) timeoutSpinnerModel.getValue());
        configurationData.setRetries((Integer) retrySpinnerModel.getValue());
        configurationData.setUserGroupAttribute((RadiusUserGroupAttribute) userGroupAttributeCombo.getSelectedObjectValue());

        configurationData.setServerHostname(serverHostnameField.getText());
        configurationData.setServerPort((Integer) serverPortSpinnerModel.getValue());
        configurationData.setServerSharedSecret(String.valueOf(serverSharedSecretField.getPassword()));

        configurationData.setAltServerHostname(altServerHostnameField.getText());
        configurationData.setAltServerPort((Integer) altServerPortSpinnerModel.getValue());
        configurationData.setAltServerSharedSecret(String.valueOf(altServerSharedSecretField.getPassword()));

        data.getData().setRadiusConfigurationData(configurationData);
    }

    @Override
    public void addChangeListener(ChangeListener listener) {
        changeListeners.add(listener);
    }

    @Override
    public BiCNetPluginSettingsPropertyPage[] getChildPages() {
        return new BiCNetPluginSettingsPropertyPage[0];
    }

    @Override
    public boolean isEnabled(IManagedObject[] iManagedObjects) {
        return USMUtility.getInstance().checkIfOperatorHasPermission(USMCommandID.S_UI_ID_GENERAL_SECURITY_SETTINGS.getMenuString());
    }

    @Override
    public void setFrame(BiCNetPluginFrame biCNetPluginFrame) {
        // do nothing
    }

    @Override
    public void setPageSite(BiCNetPluginPropertyPageSite biCNetPluginPropertyPageSite) {
        this.propertyPageSite = biCNetPluginPropertyPageSite;
    }

    @Override
    public String getID() {
        return USMCommandID.S_UI_ID_SECURITY_SETTINGS_RADIUS_AUTHENTICATION.getMenuString();
    }

    @Override
    public JComponent getComponent() {
        return this;
    }

    @Override
    public String getTitle() {
        return USMStringTable.IDS_AA_LABEL_RADIUS_AUTHENTICATION.toString();
    }

    @Override
    public void setObjects(IManagedObjectMarkable[] markables) {
        // do nothing
    }

    @Override
    public void update() {
        updateValues(document.getGeneralSettingsData());
    }

    @Override
    public void setReadOnly(boolean b) {
        // do nothing
    }


    @Override
    public void validateInput() throws BiCNetPluginException {
        LOGGER.debug("validate input");

        if(titlePanel.isSelected()){
            Integer timeout = (Integer) timeoutSpinnerModel.getValue();
            Integer retries = (Integer) retrySpinnerModel.getValue();

            String serverHostname = serverHostnameField.getText();
            Integer serverPort = (Integer) serverPortSpinnerModel.getValue();
            String serverSecret = String.valueOf(serverSharedSecretField.getPassword());

            if(timeout == null || retries == null || serverHostname == null || serverHostname.isEmpty()
                    || serverPort == null || serverSecret.isEmpty()) {
                throw new BiCNetPluginException(USMStringTable.IDS_AA_DIALOG_MESSAGE_EMPTY_RADIUS_AUTH_CONFIG.getText());
            }
        }
    }

    @Override
    public void actionApply() {
        // do nothing
    }

    @Override
    public void actionCancel() {
        // do nothing
    }

    @Override
    public void eventOpened() {
        // do nothing
    }

    @Override
    public void eventClosing() {
        // do nothing
    }

    @Override
    public void updateData(Object object) {
        if(object != null && object instanceof GSGeneralSettingData) {
            updateValues((GSGeneralSettingData) object);
        } else if (object instanceof ResponseMessage) {
            handleResponseMessage((ResponseMessage) object);
        } else {
            enableRadius();
        }
    }

    /**
     *
     */
    private void enableRadius() {
        titlePanel.setEnabled(!document.isLDAPEnabled());
        if(document.isLDAPEnabled()){
            titlePanel.getCheckBox().setToolTipText("RADIUS authentication is disabled since LDAP is enabled.");
        }
    }

    /**
     *
     * @param object
     */
    private void handleResponseMessage(ResponseMessage object) {
        for(ResponseMessage message : object.getResponseMessages(RadiusSettingsResponseMessage.class)){
            String msgText = message.getMessage();

            NotificationPopupDetails.OpStatus status;
            BiCNetPluginClientLogSeverity severity;

            switch (message.getType()) {
                case ERROR_MESSAGE:
                    status = FAILED;
                    severity = BiCNetPluginClientLogSeverity.ERROR;
                    break;
                default:
                    status = SUCCESSFUL;
                    severity = INFORMATION;
                    break;
            }

            // create the popup details
            NotificationPopupDetails popupDetails = new NotificationPopupDetails(status, msgText, BiCNetComponentType.SECURITY_MANAGER, "");
            popupDetails.setTitle(USMStringTable.IDS_AA_WINDOW_RADIUS_AUTH_SETTINGS.toString());
            // show popup
            NotificationPopupManager.getInstance().showPopup(popupDetails);
            BiCNetPluginClientLogEntry entry = new DefaultPluginClientLogEntry(severity, getTitle(), msgText);

            try {
                USMUtility.getInstance().getCfPluginSite().addClientLogEntry(entry);
            } catch (BiCNetPluginException e) {
                LOGGER.error("Unable to write to Client Log", e);
            }
        }
    }

    @Override
    public void stateChanged(ChangeEvent e) {
        eventPageStatusChanged(e);
    }

    @Override
    public boolean isPageDirty() {
        GSGeneralSettingData savedSettings = document.getGeneralSettingsData();

        if(savedSettings == null){
            return false;
        }

        RadiusConfigurationData configurationData = savedSettings.getRadiusConfigurationData();

        return configurationData == null                        ||
                isEnabledDirty(configurationData)               ||
                isTimeoutDirty(configurationData)               ||
                isRetryDirty(configurationData)                 ||
                isUserGroupAttributeDirty(configurationData)    ||
                isServerHostnameDirty(configurationData)        ||
                isAltServerHostnameDirty(configurationData)     ||
                isServerPortDirty(configurationData)            ||
                isAltServerPortDirty(configurationData)         ||
                isServerSharedSecretDirty(configurationData)    ||
                isAltServerSharedSecretDirty(configurationData);
    }

    /**
     *
     * @param configurationData
     * @return
     */
    private boolean isAltServerSharedSecretDirty(RadiusConfigurationData configurationData) {
        return isDirty(configurationData.getAltServerSharedSecret(), String.valueOf(altServerSharedSecretField.getPassword()));
    }

    /**
     *
     * @param configurationData
     * @return
     */
    private boolean isServerSharedSecretDirty(RadiusConfigurationData configurationData) {
        return isDirty(configurationData.getServerSharedSecret(),String.valueOf(serverSharedSecretField.getPassword()));
    }

    /**
     *
     * @param configurationData
     * @return
     */
    private boolean isAltServerPortDirty(RadiusConfigurationData configurationData) {
        return isDirty(altServerPortSpinnerModel.getValue(), configurationData.getAltServerPort());
    }

    /**
     *
     * @param configurationData
     * @return
     */
    private boolean isServerPortDirty(RadiusConfigurationData configurationData) {
        return isDirty(serverPortSpinnerModel.getValue(), configurationData.getServerPort());
    }

    /**
     *
     * @param configurationData
     * @return
     */
    private boolean isAltServerHostnameDirty(RadiusConfigurationData configurationData) {
        return isDirty(configurationData.getAltServerHostname(), altServerHostnameField.getText());
    }

    /**
     *
     * @param configurationData
     * @return
     */
    private boolean isServerHostnameDirty(RadiusConfigurationData configurationData) {
        return isDirty(configurationData.getServerHostname(), serverHostnameField.getText());
    }

    /**
     *
     * @param configurationData
     * @return
     */
    private boolean isUserGroupAttributeDirty(RadiusConfigurationData configurationData) {
        return isDirty(userGroupAttributeCombo.getSelectedObjectValue(),configurationData.getUserGroupAttribute());
    }

    /**
     *
     * @param configurationData
     * @return
     */
    private boolean isRetryDirty(RadiusConfigurationData configurationData) {
        return isDirty(retrySpinnerModel.getValue(), configurationData.getRetries());
    }

    /**
     *
     * @param configurationData
     * @return
     */
    private boolean isTimeoutDirty(RadiusConfigurationData configurationData) {
        return isDirty(timeoutSpinnerModel.getValue(), configurationData.getTimeout());
    }

    /**
     *
     * @param configurationData
     * @return
     */
    private boolean isEnabledDirty(RadiusConfigurationData configurationData) {
        return isDirty(configurationData.isEnabled(), titlePanel.isSelected());
    }


    /**
     *
     * @param userGroupAttribute
     * @return
     */
    private static ItemData toItemData(RadiusUserGroupAttribute userGroupAttribute) {
        return new ItemData(userGroupAttribute, userGroupAttribute);
    }

    /**
     *
     */
    private void initListeners() {
        titlePanel.addActionListener(e -> this.stateChanged(new ChangeEvent(titlePanel)));
        userGroupAttributeCombo.addActionListener(e -> this.stateChanged(new ChangeEvent(userGroupAttributeCombo)));

        serverPortSpinner.addChangeListener(this);
        altServerPortSpinner.addChangeListener(this);
        timeoutSpinner.addChangeListener(this);
        retrySpinner.addChangeListener(this);

        DocumentListener documentListener = new RadiusDocumentListener();

        serverHostnameField.addDocumentListener(documentListener);
        altServerHostnameField.addDocumentListener(documentListener);
        serverSharedSecretField.addDocumentListener(documentListener);
        altServerSharedSecretField.addDocumentListener(documentListener);

        defaultButton.addActionListener(getDefaultActionListener());

        serverTestButton.addActionListener(getServerActionListener());
        altServerTestButton.addActionListener(getAlternativeServerActionListener());

        serverStatusDocument.setDataChangeListener(getServerStatusListener(serverTestStatusLabel));
        altServerStatusDocument.setDataChangeListener(getServerStatusListener(altServerTestStatusLabel));
    }

    /**
     *
     * @param label
     * @return
     */
    private IFrameworkDataChangeListener getServerStatusListener(JfxLabel label) {
        return object -> {
            String message = IDS_GS_RADIUS_TEST_FAILED;
            ImageIcon icon = CommonIcons.getWarningIcon();

            if(object instanceof RadiusServerStatus){
                switch ((RadiusServerStatus) object){
                    case AVAILABLE:
                        message = IDS_GS_RADIUS_TEST_AVAILABLE;
                        icon = CommonIcons.getInfoIcon();
                        break;
                    case REJECTED:
                        message = IDS_GS_RADIUS_TEST_REJECTED;
                        icon = CommonIcons.getErrorIcon();
                        break;
                    case CONNECTION_FAILED:
                        message = IDS_GS_RADIUS_TEST_CONNECTION_FAILED;
                        icon = CommonIcons.getWarningIcon();
                        break;
                }
            }

            label.setIcon(icon);
            label.setText(message);
        };
    }

    /**
     *
     * @return
     */
    private ActionListener getDefaultActionListener() {
        return e -> {
            titlePanel.setSelected(false);

            timeoutSpinnerModel.setValue(RANGE_TIMEOUT_DEFAULT);
            retrySpinnerModel.setValue(RANGE_RETRIES_DEFAULT);
            userGroupAttributeCombo.setSelectedItem(VENDOR_SPECIFIC);

            serverHostnameField.setText("");
            altServerHostnameField.setText("");
            serverPortSpinnerModel.setValue(RANGE_PORT_DEFAULT);
            altServerPortSpinnerModel.setValue(RANGE_PORT_DEFAULT);
            serverSharedSecretField.setText("");
            altServerSharedSecretField.setText("");
            this.stateChanged(new ChangeEvent(titlePanel));
        };
    }

    /**
     *
     * @return
     */
    private ActionListener getAlternativeServerActionListener() {
        return e -> {

            if(!isAltServerConfigured()) {
                altServerTestStatusLabel.setText(RADIUS_TEXT_STATUS_NOT_CONFIGURED);
                altServerTestStatusLabel.setIcon(CommonIcons.getWarningIcon());
                return;
            }

            LOGGER.debug("Alternative Server test button pressed.");
            altServerTestStatusLabel.setText(RADIUS_TEXT_STATUS_TESTING);
            altServerTestStatusLabel.setIcon(CommonIcons.getRefreshIcon());

            RadiusTestConfigurationData configurationData = new RadiusTestConfigurationData();
            configurationData.setTimeout((Integer) timeoutSpinnerModel.getValue());
            configurationData.setRetries((Integer) retrySpinnerModel.getValue());
            configurationData.setServerHostname(altServerHostnameField.getText());
            configurationData.setServerPort((Integer) altServerPortSpinnerModel.getValue());
            configurationData.setServerSharedSecret(String.valueOf(altServerSharedSecretField.getPassword()));

            altServerStatusDocument.testServer(configurationData);
        };
    }

    /**
     *
     * @return
     */
    private ActionListener getServerActionListener() {
        return e -> {
            LOGGER.debug("Server test button pressed.");

            // if the server is not configured, we should show a message and the respective icon
            if(!isServerConfigured()) {
                serverTestStatusLabel.setText(RADIUS_TEXT_STATUS_NOT_CONFIGURED);
                serverTestStatusLabel.setIcon(CommonIcons.getWarningIcon());
                return;
            }

            serverTestStatusLabel.setText(RADIUS_TEXT_STATUS_TESTING);
            serverTestStatusLabel.setIcon(CommonIcons.getRefreshIcon());

            RadiusTestConfigurationData configurationData = new RadiusTestConfigurationData();
            configurationData.setTimeout((Integer) timeoutSpinnerModel.getValue());
            configurationData.setRetries((Integer) retrySpinnerModel.getValue());
            configurationData.setServerHostname(serverHostnameField.getText());
            configurationData.setServerPort((Integer) serverPortSpinnerModel.getValue());
            configurationData.setServerSharedSecret(String.valueOf(serverSharedSecretField.getPassword()));

            serverStatusDocument.testServer(configurationData);
        };
    }

    /**
     *
     * @return
     */
    private boolean isServerConfigured() {
        return !serverHostnameLabel.getText().isEmpty() && !String.valueOf(serverSharedSecretField.getPassword()).isEmpty();
    }

    /**
     *
     * @return
     */
    private boolean isAltServerConfigured() {
        return !altServerHostnameLabel.getText().isEmpty() && !String.valueOf(altServerSharedSecretField.getPassword()).isEmpty();
    }

    /**
     *
     */
    private void eventPageStatusChanged(ChangeEvent event) {
        if(event != null && event.getSource() != null && event.getSource().equals(titlePanel)) {
            document.setRadiusEnabled(titlePanel.isSelected());
        }

        if(propertyPageSite != null){
            propertyPageSite.eventPageStatusChanged(RadiusAuthenticationPropertyPage.this);
        }

        for(ChangeListener listener : changeListeners){
            listener.stateChanged(event);
        }
    }

    /**
     *
     */
    private void initLayout(){
        setLayout(new GridBagLayout());
        setBorder(JfxUtils.PANEL_OUTSIDE_BORDER);

        JPanel panel = new JPanel(new GridBagLayout());

        JPanel clientPanel = new JPanel(new GridBagLayout());
        clientPanel.setBorder(BorderFactory.createTitledBorder(RADIUS_TITLE_CLIENT_SETTINGS));

        JPanel serverPanel = new JPanel(new GridBagLayout());
        serverPanel.setBorder(BorderFactory.createTitledBorder(RADIUS_TITLE_SERVER_SETTINGS));

        JPanel altServerPanel = new JPanel(new GridBagLayout());
        altServerPanel.setBorder(BorderFactory.createTitledBorder(RADIUS_TITLE_ALT_SERVER_SETTINGS));

        panel.add(clientPanel,      getConstraints(0, 0, 1, true,  true));
        panel.add(serverPanel,      getConstraints(0, 1, 1, false, true));
        panel.add(altServerPanel,   getConstraints(0, 2, 1, false, true));

        int row = 0;
        // Timeout panel
        timeoutSpinnerPanel         (clientPanel, row++);
        retrySpinnerPanel           (clientPanel, row++);
        userGroupAttributeComboBox  (clientPanel, row);

        row = 0;
        serverHostname      (serverPanel, row);
        serverPort          (serverPanel, row++);
        serverSharedSecret  (serverPanel, row++);
        serverTestConnection(serverPanel, row);

        row = 0;
        altServerHostname      (altServerPanel, row);
        altServerPort          (altServerPanel, row++);
        altServerSharedSecret  (altServerPanel, row++);
        altServerTestConnection(altServerPanel, row);

        checkBoxTitlePanel(panel);
        defaultButton();

        add(titlePanel, new GridBagConstraints (
                0, 0, 1, 1, 1.0, 0.0,
                GridBagConstraints.BASELINE_LEADING,
                GridBagConstraints.HORIZONTAL,
                new Insets(0, 0, 0, 0),
                0, 0)
        );

        add(defaultButton, new GridBagConstraints (
                0, 1, 1, 1, 0.0, 1.0,
                GridBagConstraints.SOUTHWEST,
                GridBagConstraints.NONE,
                new Insets(JfxUtils.VIEW_MINIMUM_DISTANCE_BETWEEN_ROWS, 0, 0, 0),
                0, 0)
        );
    }

    /**
     *
     */
    private void updateValues(GSGeneralSettingData settings) {
        if(settings == null){
            return;
        }

        RadiusConfigurationData radiusConfigurationData = settings.getRadiusConfigurationData();

        if(radiusConfigurationData == null) {
            return;
        }

        boolean isRadiusEnabled = radiusConfigurationData.isEnabled();

        titlePanel.setSelected(isRadiusEnabled);
        enableRadius();
        titlePanel.setUnmodifiedValue(isRadiusEnabled);

        int timeout = radiusConfigurationData.getTimeout();
        timeoutSpinnerModel.setValue(timeout);
        timeoutSpinner.setUnmodifiedValue(timeout);

        int retries = radiusConfigurationData.getRetries();
        retrySpinnerModel.setValue(retries);
        retrySpinner.setUnmodifiedValue(retries);

        RadiusUserGroupAttribute userGroupAttribute = radiusConfigurationData.getUserGroupAttribute();
        userGroupAttributeCombo.setSelectedItemByKey(userGroupAttribute);
        userGroupAttributeCombo.setUnmodifiedValue(toItemData(userGroupAttribute));

        String serverHostname = radiusConfigurationData.getServerHostname();
        serverHostnameField.setText(serverHostname);
        serverHostnameField.setUnmodifiedValue(serverHostname);

        String altServerHostname = radiusConfigurationData.getAltServerHostname();
        altServerHostnameField.setText(altServerHostname);
        altServerHostnameField.setUnmodifiedValue(altServerHostname);

        int serverPort = radiusConfigurationData.getServerPort();
        serverPortSpinnerModel.setValue(serverPort);
        serverPortSpinner.setUnmodifiedValue(serverPort);

        int altServerPort = radiusConfigurationData.getAltServerPort();
        altServerPortSpinnerModel.setValue(altServerPort);
        altServerPortSpinner.setUnmodifiedValue(altServerPort);

        String serverSharedSecret = radiusConfigurationData.getServerSharedSecret();
        serverSharedSecretField.setText(serverSharedSecret);
        serverSharedSecretField.setUnmodifiedValue(serverSharedSecret);

        String altServerSharedSecret = radiusConfigurationData.getAltServerSharedSecret();
        altServerSharedSecretField.setText(altServerSharedSecret);
        altServerSharedSecretField.setUnmodifiedValue(altServerSharedSecret);
    }

    /**
     *
     * @param ldapConfiguration
     */
    private void updateValues(LDAPConfigurationData ldapConfiguration) {
        titlePanel.setEnabled(ldapConfiguration.isEnabled());
    }

    /**
     *
     */
    private void defaultButton() {
        defaultButton = new JfxButton(JfxStringTable.IDS_Default);
    }

    /**
     *
     * @param panel
     */
    private void checkBoxTitlePanel(JPanel panel) {
        titlePanel = new JfxCheckBoxTitlePanel(USMStringTable.IDS_SS_AD_RADIUS_AUTHENTICATION_CHECKBOX, panel, false);
    }

    /**
     *
     * @param panel
     * @param row
     */
    private void serverHostname(JPanel panel, int row){
        serverHostnameField = new USMTextField();
        serverHostnameField.setToolTipText(RADIUS_TEXT_HOSTNAME);
        serverHostnameField.setMandatoryEntry(true);

        serverHostnameLabel.setLabelAndMnemonicFor(serverHostnameField);

        panel.add(serverHostnameLabel, getConstraints(0, row, 1, true, false));
        panel.add(serverHostnameField, getConstraints(1, row, 1, true, true));
    }

    /**
     *
     * @param panel
     * @param row
     */
    private void serverPort(JPanel panel, int row){
        serverPortSpinnerModel = getServerPortSpinnerModel();
        serverPortSpinner = new JfxSpinner(serverPortSpinnerModel);
        serverPortSpinner.setToolTipText(RADIUS_TEXT_PORT);

        serverPortLabel.setLabelAndMnemonicFor(serverPortSpinner);

        panel.add(serverPortLabel     , getConstraints(2, row));
        panel.add(serverPortSpinner   , getConstraints(3, row));
        panel.add(serverPortRangeLabel, getConstraints(4, row, 1, false, false));
    }

    /**
     *
     * @param panel
     * @param row
     */
    private void serverSharedSecret(JPanel panel, int row){
        serverSharedSecretField = new JfxPasswordField();
        serverSharedSecretField.setToolTipText(RADIUS_TEXT_SHARED_SECRET);
        serverSharedSecretField.setMandatoryEntry(true);

        serverSharedSecretLabel.setLabelAndMnemonicFor(serverSharedSecretField);

        panel.add(serverSharedSecretLabel, getConstraints(0, row, 1, false, false));
        panel.add(serverSharedSecretField, getConstraints(1, row, 1, false, true));
    }

    /**
     *
     * @param panel
     * @param row
     */
    private void serverTestConnection(JPanel panel, int row){
        serverTestButton = new JfxButton(RADIUS_TEXT_TEST_CONNECTION);

        panel.add(serverTestButton     , getConstraints(0, row, true));
        panel.add(serverTestStatusLabel, getConstraints(1, row, WIDTH_SERVER_TEST, true));
    }

    /**
     *
     * @param panel
     * @param row
     */
    private void altServerHostname(JPanel panel, int row){
        altServerHostnameField = new USMTextField();
        altServerHostnameField.setToolTipText(RADIUS_TEXT_HOSTNAME);
        altServerHostnameField.setMandatoryEntry(false);

        altServerHostnameLabel.setLabelAndMnemonicFor(altServerHostnameField);

        panel.add(altServerHostnameLabel, getConstraints(0, row, 1, true, false));
        panel.add(altServerHostnameField, getConstraints(1, row, 1, true, true));
    }

    /**
     *
     * @param panel
     * @param row
     */
    private void altServerPort(JPanel panel, int row){
        altServerPortSpinnerModel = getServerPortSpinnerModel();
        altServerPortSpinner = new JfxSpinner(altServerPortSpinnerModel);
        altServerPortSpinner.setToolTipText(RADIUS_TEXT_PORT);

        altServerPortLabel.setLabelAndMnemonicFor(altServerPortSpinner);

        panel.add(altServerPortLabel        , getConstraints(2, row));
        panel.add(altServerPortSpinner      , getConstraints(3, row));
        panel.add(altServerPortRangeLabel   , getConstraints(4, row, 1, false, false));
    }

    /**
     *
     * @return
     */
    private SpinnerIntegerModel getServerPortSpinnerModel() {
        return new SpinnerIntegerModel(RANGE_PORT_DEFAULT, RANGE_PORT_MIN, RANGE_PORT_MAX, RANGE_PORT_STEP_SIZE);
    }

    /**
     *
     * @param panel
     * @param row
     */
    private void altServerSharedSecret(JPanel panel, int row){
        altServerSharedSecretField = new JfxPasswordField();
        altServerSharedSecretField.setToolTipText(RADIUS_TEXT_SHARED_SECRET);
        altServerSharedSecretField.setMandatoryEntry(false);

        altServerSharedSecretLabel.setLabelAndMnemonicFor(altServerSharedSecretField);

        panel.add(altServerSharedSecretLabel, getConstraints(0, row, 1, false, false));
        panel.add(altServerSharedSecretField, getConstraints(1, row, 1, false, true));
    }

    /**
     *
     * @param panel
     * @param row
     */
    private void altServerTestConnection(JPanel panel, int row){
        altServerTestButton = new JfxButton(RADIUS_TEXT_TEST_CONNECTION);

        panel.add(altServerTestButton     , getConstraints(0, row, true));
        panel.add(altServerTestStatusLabel, getConstraints(1, row, WIDTH_SERVER_TEST, true));
    }

    /**
     *
     * @param panel
     * @param row
     */
    private void userGroupAttributeComboBox(JPanel panel, int row) {
        userGroupAttributeCombo = new JfxComboBox(userGroupAttributeItems);

        userGroupAttributeLabel.setLabelAndMnemonicFor(userGroupAttributeCombo);

        panel.add(userGroupAttributeLabel, getConstraints(0, row));
        panel.add(userGroupAttributeCombo, getConstraints(1, row, 3, false, false));
    }

    /**
     *
     * @return
     */
    private void timeoutSpinnerPanel(JPanel panel, int row) {
        timeoutSpinnerModel = new SpinnerIntegerModel(
                RANGE_TIMEOUT_DEFAULT,
                RANGE_TIMEOUT_MIN,
                RANGE_TIMEOUT_MAX,
                RANGE_TIMEOUT_STEP
        );
        timeoutSpinner = new JfxSpinner(timeoutSpinnerModel);
        timeoutSpinner.setToolTipText(RADIUS_TEXT_TIMEOUT);

        timeoutLabel.setLabelAndMnemonicFor(timeoutSpinner);

        panel.add(timeoutLabel     , getConstraints(0, row));
        panel.add(timeoutSpinner   , getConstraints(1, row, true));
        panel.add(timeoutUnitLabel , getConstraints(2, row, 1, true, false));
        panel.add(timeoutRangeLabel, getConstraints(3, row, 1, true, true));
    }

    /**
     *
     * @return
     */
    private void retrySpinnerPanel(JPanel panel, int row) {
        retrySpinnerModel = new SpinnerIntegerModel(
                RANGE_RETRIES_DEFAULT,
                RANGE_RETRIES_MIN,
                RANGE_RETRIES_MAX,
                RANGE_RETRIES_STEP
        );
        retrySpinner = new JfxSpinner(retrySpinnerModel);
        retrySpinner.setToolTipText(RADIUS_TEXT_RETRIES);

        retryLabel.setLabelAndMnemonicFor(retrySpinner);

        panel.add(retryLabel      , getConstraints(0, row));
        panel.add(retrySpinner    , getConstraints(1, row));
        panel.add(retryUnitLabel  , getConstraints(2, row, 1, false, false));
        panel.add(retryRangeLabel , getConstraints(3, row, 1, false, true));
    }

    /**
     *
     * @param unmodified
     * @param value
     * @return
     */
    private boolean isDirty(Object unmodified, Object value) {
        return !(unmodified == null || value == null) && !unmodified.equals(value);
    }

    /**
     *
     */
    private final class RadiusDocumentListener implements DocumentListener {
        @Override
        public void removeUpdate(DocumentEvent e) {
            stateChanged(null);
        }
        @Override
        public void insertUpdate(DocumentEvent e) {
            stateChanged(null);
        }
        @Override
        public void changedUpdate(DocumentEvent e) {
            stateChanged(null);
        }
    }
}
