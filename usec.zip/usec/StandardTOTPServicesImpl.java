package com.bnppa.sesame.services.standard;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.BooleanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnppa.sesame.MessageDescriptionBuilder;
import com.bnppa.sesame.authaccount.AuthAccountEBO;
import com.bnppa.sesame.authaccount.AuthAccountSBO;
import com.bnppa.sesame.constants.AccountConstants;
import com.bnppa.sesame.constants.AuthAccountConstants;
import com.bnppa.sesame.constants.AuthenticationLevelConstants;
import com.bnppa.sesame.constants.CommonBOExceptionConstants;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.constants.TechnicalBOExceptionConstants;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.TechnicalBOException;
import com.bnppa.sesame.person.PersonSBO;
import com.bnppa.sesame.securityresponse.SecurityResponseEBO;
import com.bnppa.sesame.securityresponse.SecurityResponseSBO;
import com.bnppa.sesame.services.exception.FunctionalException;
import com.bnppa.sesame.services.exception.TechnicalException;
import com.bnppa.sesame.services.standard.mapper.GeneralExceptionMapper;
import com.bnppa.sesame.services.standard.model.v2.SecurityQuestionsResponses;
import com.bnppa.sesame.services.vo.EncodedSecret;
import com.bnppa.sesame.token.TokenEBO;
import com.bnppa.sesame.token.TokenSBO;
import com.bnppa.sesame.usersecret.UserSecretEBO;
import com.bnppa.sesame.usersecret.UserSecretSBO;
import com.bnppa.sesame.utils.security.SecurityHelper;
import org.springframework.transaction.annotation.Transactional;
import com.bnppa.sesame.utils.annot.Profiled;
import java.lang.Exception;
import com.bnppa.sesame.utils.annot.TokenControl;
import com.bnppa.sesame.utils.annot.Token;
import com.bnppa.sesame.utils.annot.RuntimeCatcher;
import com.bnppa.sesame.utils.annot.Audit;

public class StandardTOTPServicesImpl implements StandardTOTPServices {

	private static final Log logger	= LogFactory.getLog(StandardTOTPServicesImpl.class);

	private MessageDescriptionBuilder messageBuilder;
	private GeneralExceptionMapper exceptionMapper;
	private TokenSBO tokenSBO;
	private UserSecretSBO userSecretSBO;
	private AuthAccountSBO authAccountSBO;
	private SecurityResponseSBO securityResponseSBO;
	
	@Autowired
	private PersonSBO personSBO;

	/* 
	 * (non-Javadoc)
	 * @see com.bnppa.sesame.services.standard.StandardTOTPServices#setAuthenticationLevelWithTOTP(java.lang.String, java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = FunctionalException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-totp_std_v1-setAuthenticationLevelWithTOTP")
	@Transactional(rollbackFor = { Exception.class })
	public void setAuthenticationLevelWithTOTP(@Token String token, String otp)
		throws FunctionalException, TechnicalException {
			
		try {
						
			TokenEBO tokenEBO = getTokenSBO().find(token);
			AuthAccountEBO authAccountEBO = getTokenSBO().getAuthAccount(tokenEBO);

			// Sanity check
			checkAuthAccount(authAccountEBO);

			// Check account type
			checkAccountTypeIsUSER(authAccountEBO);
			
			// Sanity check
			if (StringUtils.isBlank(otp)) 
			{
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.TOTP_INVALID_PARAMETER,
								new String[] { "OTP" });
				logger.error(msg);
				throw new FunctionalException(msg);
			}
			
			// We need the login : used in the TAUSERSECRETS
			String login = authAccountEBO.getLogin();	

			// If the user is group then we have to load the authAccount with the following API
			// otherwise we will not load the right account data linked to the group user (login defined like l_uid_XXXX)
			// and we will not have the email address of the user for example
			if (authAccountEBO.getAuthType().equals(AuthAccountConstants.TYPE_GROUP))
			{
				authAccountEBO = authAccountSBO.findAccountTypeGroup(login);
			}			
			
			checkAuthAccount(authAccountEBO);
			
			login = authAccountEBO.getLogin();

			UserSecretEBO userSecretEBO = getUserSecretSBO().find(login);
			
			// The user secret has to exist, otherwise we can't do anything
			if(userSecretEBO == null)
			{
				String msg = getMessageBuilder()
				.build(
						InvalidParameterBOExceptionConstants.TOTP_USER_SECRET_NOT_FOUND,
						new String[] { login }); 
				logger.error(msg);
				throw new FunctionalException(msg);				
			}

			if(userSecretEBO.getActive() == null || userSecretEBO.getNbAttempts() == null
					|| userSecretEBO.getLastUpdate() == null 
					|| StringUtils.isBlank(userSecretEBO.getSecret()))
			{
				
				String msg = getMessageBuilder().build(
						TechnicalBOExceptionConstants.TECHNICAL_ERROR);
				logger.error(msg);
				msg = "Invalid secret => Problem with the data in database : active or nbAttempts or creationDate or lastUpdate or secret is/are null ";
				logger.error(msg);
				
				throw new TechnicalException(msg);	
			}
			
			// The user secret has to be active, otherwise we stop here the processing
			if(userSecretEBO.getActive() == null || BooleanUtils.isFalse(userSecretEBO.getActive()))
			{
				String msg = getMessageBuilder()
				.build(
						InvalidParameterBOExceptionConstants.TOTP_USER_SECRET_NOT_ACTIVE,
						new String[] { login }); 
				logger.error(msg);
				throw new FunctionalException(msg);				
			}
			
			// Functional checks
			/*
				First check, in case of the user has 2 tokens in 2 different browsers
				and we invalidate one of them, we need to invalid the second if he is trying 
				to upgrade his second token, of course if it is already upgraded we can't do anything
				
				TODO : Perhaps remove all occurences of the user token in the cache, not just the current
			*/
			
			/* Third parameter = true, because we want to increment the nb attempts in this case 
			   See SFO 1.5  2.18.8 ALTERNATE ALGORITHM 3
			*/
			checkUserSecretNbMaxAttempts(tokenEBO, authAccountEBO, true);
			
			boolean hasFailed = true;
			
			try
			{
				// Call the TOTP algorithm for checking the otp passed as paramter
				Hex hex = new Hex();
				byte[] hexSecret = hex.encode(getUserSecretSBO().getDecryptedSecret(userSecretEBO).getBytes("UTF-8"));
				if(SecurityHelper.verifyTOTP(otp, hexSecret, getUserSecretSBO().getSecretNbDigits())
				   )
				{
					hasFailed = false;
				}
				
			}
			catch(Exception e)
			{
				
				String msg = getMessageBuilder().build(
						TechnicalBOExceptionConstants.TECHNICAL_ERROR);
				logger.error(msg);
				msg = "Unable to perfom the action because of a fatal error [{VERIFY TOTP}].";
				logger.error(msg);
				
				throw new TechnicalException(msg);				
			}
			
			if(hasFailed)
			{
				if(userSecretEBO.getSecretLastUpdateAgeInSeconds() < authAccountEBO.getSecurityRulesStrategy().getAccountLockDuration() )
				{
					// Increment the nb attempts in order to block him when the max is reached laterly					
					getUserSecretSBO().incrementNbAttempts(login);				
				}
				else
				{
					// If the user come back after 1 hour blocking time and fails the otp we restart to 1
					// Otherwise he will be always blocked without his 3 attempts 
					getUserSecretSBO().updateNbAttempts(login, 1);
				}

				// We check the nb attempts in case we have reached the max allowed
				// and if needed we lock the account, we don't increment nb attempts because 
				// already done in the step before
				checkUserSecretNbMaxAttempts(tokenEBO, authAccountEBO, false);
				
				// If we are here, this means we have to warn the user that the OTP check has failed (invalid otp)
				String msg = getMessageBuilder()
				.build(
						InvalidParameterBOExceptionConstants.TOTP_IS_INVALID,
						new String[] { login }); 
				logger.error(msg);
				throw new FunctionalException(msg);				
			}
			else
			{
				// Everything is ok, reset the nb attempts
				getUserSecretSBO().updateNbAttempts(login, 0);
				// and upgrade the authentication level
				// WARNING : the method upgrade to TOTP only if the current level strength is lower than TOTP strength
				// otherwise the level is kept, we dont want to downgrade the token
				getTokenSBO().upgradeAuthenticationLevel(tokenEBO, AuthenticationLevelConstants.TOTP_LEVEL );
			}
		} catch (InvalidParameterBOException e) {
			throw getExceptionMapper().map(e, logger);
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(e, logger);
		}
	}
	
	/**
	 * Check and locks if needed the user account regarding the maximum number of attemps
	 * @param tokenEBO
	 * @param authAccountEBO
	 * @param incrementNbAttempts flag if it should increment the nb attempts in case of failure
	 * @throws InvalidParameterBOException
	 * @throws TechnicalBOException
	 * @throws FunctionalException
	 */
	private void checkUserSecretNbMaxAttempts(TokenEBO tokenEBO, AuthAccountEBO authAccountEBO, boolean incrementNbAttempts)
		throws InvalidParameterBOException, TechnicalBOException, FunctionalException
	{	
		String login = authAccountEBO.getLogin();
		// Sanity check
		if (StringUtils.isBlank(login)) 
		{
			String msg = getMessageBuilder()
					.build(
							InvalidParameterBOExceptionConstants.TOTP_INVALID_PARAMETER,
							new String[] { "LOGIN" });
			logger.error(msg);
			throw new InvalidParameterBOException(msg, logger);
		}
		
		// Sanity check
		if (tokenEBO == null || StringUtils.isBlank(tokenEBO.getId()) ) 
		{
			String msg = getMessageBuilder()
					.build(
							InvalidParameterBOExceptionConstants.TOTP_INVALID_PARAMETER,
							new String[] { "TOKEN" });
			logger.error(msg);
			throw new InvalidParameterBOException(msg, logger);
		}
		
		// Find the user secret
		UserSecretEBO userSecretEBO = getUserSecretSBO().find(login);
		
		/*
		 * Functional check
		 * 
		 * If the nb attempts of the user are reached or exceed the max allowed
		 * AND
		 * We are inside the window range of 1 hour
		 * THEN 
		 * We have to lock this account
		 * 
		 * If the age is greater than 1 hour, we do nothing here
		 * 
		 * This means that the user try again after 1 hour blocking time
		 * The main service will reset the nb attempts to 1 to let him try again his 3 attempts 
		 * 
		 * If the nb attempts is lower than the max, we dont block him
		 * He can continue to try
		 * 
		 */
		if(
			(userSecretEBO.getNbAttempts().intValue() >= getUserSecretSBO().getMaxNbFailedAttempts())
			&&
			(userSecretEBO.getSecretLastUpdateAgeInSeconds() < authAccountEBO.getSecurityRulesStrategy().getAccountLockDuration())
		)
		{
			// if the flag is set to true, then we increment the nb attempts
			// in some cases we dont need to do that because it is already done before calling this method
			if(incrementNbAttempts)
				getUserSecretSBO().incrementNbAttempts(login);
			
			// Lock the user, sorry man : remove the token from sesame cache + add the token
			// to the locked cache, so he cannot perform action like : login or loginInUserRef

			// Remove the token from the sesame cache
			getTokenSBO().delete(tokenEBO);
			
			//lock the account : put the login in the sesame LOCKED cache
			getAuthAccountSBO().lockInCache(login, AuthenticationLevelConstants.TOTP_LEVEL);
			
			// Warn the user
			String msg = getMessageBuilder()
			.build(
					InvalidParameterBOExceptionConstants.TOTP_USER_LOCKED_FOR_MANY_FAILED_ATTEMPTS,
					new String[] { login }); 
			logger.error(msg);
			throw new FunctionalException(msg);				
		}
				
	}

	/* (non-Javadoc)
	 * @see com.bnppa.sesame.services.standard.StandardTOTPServices#clearTOTPForAccount(java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = FunctionalException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-totp_std_v1-clearTOTPForAccount")
	@Transactional(readOnly = true)
	public void clearTOTPForAccount(@Token String token) throws FunctionalException, TechnicalException
	{
		try
		{
			TokenEBO tokenEBO = getTokenSBO().find(token);
			AuthAccountEBO authAccountEBO = getTokenSBO().getAuthAccount(tokenEBO);
	
			// Sanity check
			checkAuthAccount(authAccountEBO);
			
			// Check account type
			checkAccountTypeIsUSER(authAccountEBO);

			// We need the login : used in the TAUSERSECRETS
			String login = authAccountEBO.getLogin();		
			
			// If the user is group then we have to load the authAccount with the following API
			// otherwise we will not load the right account data linked to the group user (login defined like l_uid_XXXX)
			// and we will not have the email address of the user for example
			if (authAccountEBO.getAuthType().equals(AuthAccountConstants.TYPE_GROUP))
			{
				authAccountEBO = authAccountSBO.findAccountTypeGroup(login);
			}			
			
			checkAuthAccount(authAccountEBO);
			
			login = authAccountEBO.getLogin();
			
			UserSecretEBO userSecretEBO = getUserSecretSBO().find(login);
			
			if(userSecretEBO == null)
			{
				String msg = getMessageBuilder()
				.build(
						InvalidParameterBOExceptionConstants.TOTP_SECRET_CLEAR_NOT_EXISTS,
						new String[] { login }); 
				logger.error(msg);				
				throw new FunctionalException(msg);									
			}
			else
			{
				if(userSecretEBO.getCreationDate() == null)
				{
					String msg = getMessageBuilder().build(
							TechnicalBOExceptionConstants.TECHNICAL_ERROR);
					logger.error(msg);
					msg = "Invalid secret => Problem with the data in database : creationDate is null ";
					logger.error(msg);
					
					throw new TechnicalException(msg);			
				}

				// Avenant Console Lot3.2 / 2.8 : add control if not active, then deny
				if((userSecretEBO.getSecretCreationDateAgeInSeconds() 
									< getUserSecretSBO().getResetCreatedMaxAge())
						|| (userSecretEBO.getActive() != null && !userSecretEBO.getActive().booleanValue()))
				{
					String msg = getMessageBuilder()
					.build(
							InvalidParameterBOExceptionConstants.TOTP_RESET_NOT_AUTHORIZED,
							new String[] { login }); 
					logger.error(msg);				
					throw new FunctionalException(msg);					
				}
				
				getUserSecretSBO().delete(login);
			}			
		} catch (InvalidParameterBOException e) {
			throw getExceptionMapper().map(e, logger);
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(e, logger);
		}		
	}
	
	
	/* (non-Javadoc)
	 * @see com.bnppa.sesame.services.standard.StandardTOTPServices#validateSecret(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = FunctionalException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-totp_std_v1-validateSecret")
	@Transactional(readOnly = true)
	public void validateSecret(@Token String token, String firstOtp, String secondOtp)
		throws FunctionalException, TechnicalException
	{
		try
		{
			TokenEBO tokenEBO = getTokenSBO().find(token);
			AuthAccountEBO authAccountEBO = getTokenSBO().getAuthAccount(tokenEBO);

			// Sanity check
			checkAuthAccount(authAccountEBO);

			// Check account type
			checkAccountTypeIsUSER(authAccountEBO);

			// Sanity check
			if (StringUtils.isBlank(firstOtp)) 
			{
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.TOTP_VALIDATESECRET_INVALID_PARAMETER,
								new String[] { "FIRST OTP" });
				logger.error(msg);
				throw new FunctionalException(msg);
			}

			// SESAMECA-603 : second totp is optional
//			if (StringUtils.isBlank(secondOtp)) 
//			{
//				String msg = getMessageBuilder()
//						.build(
//								InvalidParameterBOExceptionConstants.TOTP_VALIDATESECRET_INVALID_PARAMETER,
//								new String[] { "SECOND OTP" });
//				logger.error(msg);
//				throw new FunctionalException(msg);
//			}

			// We need the login : used in the TAUSERSECRETS
			String login = authAccountEBO.getLogin();			

			// If the user is group then we have to load the authAccount with the following API
			// otherwise we will not load the right account data linked to the group user (login defined like l_uid_XXXX)
			// and we will not have the email address of the user for example
			if (authAccountEBO.getAuthType().equals(AuthAccountConstants.TYPE_GROUP))
			{
				authAccountEBO = authAccountSBO.findAccountTypeGroup(login);
			}			
			
			checkAuthAccount(authAccountEBO);
			
			login = authAccountEBO.getLogin();

			UserSecretEBO userSecretEBO = getUserSecretSBO().find(login);
			
			// The user secret has to exist, otherwise we can't do anything
			if(userSecretEBO == null)
			{
				String msg = getMessageBuilder()
				.build(
						InvalidParameterBOExceptionConstants.TOTP_USER_SECRET_NOT_FOUND,
						new String[] { login }); 
				logger.error(msg);
				throw new FunctionalException(msg);				
			}
			
			//Sanity checks
			if(userSecretEBO.getActive() == null || userSecretEBO.getNbAttempts() == null
					|| userSecretEBO.getCreationDate() == null 
					|| StringUtils.isBlank(userSecretEBO.getSecret()))
			{
				String msg = getMessageBuilder().build(
						TechnicalBOExceptionConstants.TECHNICAL_ERROR);
				logger.error(msg);
				msg = "Invalid secret => Problem with the data in database : active or nbAttempts or creationDate or lastUpdate or secret is/are null ";
				logger.error(msg);
				
				throw new TechnicalException(msg);	
			}

			// The user secret has to be inactive, otherwise it means it is already verified
			if( BooleanUtils.isTrue(userSecretEBO.getActive()) )
			{
				String msg = getMessageBuilder()
				.build(
						InvalidParameterBOExceptionConstants.TOTP_USER_SECRET_ALREADY_VERIFIED,
						new String[] { login }); 
				logger.error(msg);
				throw new FunctionalException(msg);				
			}

			// For security reasons, the user has a limited time for completing 
			// the verification process of his secret (default 30 mins)
			if(userSecretEBO.getSecretCreationDateAgeInSeconds() 
								> getUserSecretSBO().getVerifyCreatedMaxAge() )
			{
				String msg = getMessageBuilder()
				.build(
						InvalidParameterBOExceptionConstants.TOTP_USER_SECRET_VERIFY_EXPIRED,
						new String[] { login }); 
				logger.error(msg);
				throw new FunctionalException(msg);				
			}
			
			// if the user has reached the maximum number of failed attemps allowed then throw an exception
			if(BooleanUtils.isFalse(userSecretEBO.getActive()) 
					&& userSecretEBO.getNbAttempts().intValue() >=  getUserSecretSBO().getVerifyMaxNbFailedAttempts() )
			{
				String msg = getMessageBuilder()
				.build(
						InvalidParameterBOExceptionConstants.TOTP_USER_SECRET_VERIFY_MAX_FAILED_ATTEMPTS,
						new String[] { login }); 
				logger.error(msg);
				throw new FunctionalException(msg);				
			}
			
			boolean hasFailed = false;
			
			try
			{
				// Call the TOTP algorithm for checking the otps passed as parameter
				// last parameter is set to true because we want to check 2 steps before current time step
				// why ? because we have 2 otps
				Hex hex = new Hex();
				byte[] hexSecret = hex.encode(getUserSecretSBO().getDecryptedSecret(userSecretEBO).getBytes("UTF-8"));

				if (StringUtils.isNotEmpty(secondOtp)){				
					if(
						firstOtp.equalsIgnoreCase(secondOtp)
						||
						!SecurityHelper.verifyTOTP(firstOtp, hexSecret, getUserSecretSBO().getSecretNbDigits(), true) 
						||
						!SecurityHelper.verifyTOTP(secondOtp, hexSecret, getUserSecretSBO().getSecretNbDigits(), true)
					  )
					{
						hasFailed = true;
					}
				}else{
					if (!SecurityHelper.verifyTOTP(firstOtp, hexSecret, getUserSecretSBO().getSecretNbDigits(), true) ){
						hasFailed = true;
					}
				}				
			}
			catch(Exception e)
			{
				
				String msg = getMessageBuilder().build(
						TechnicalBOExceptionConstants.TECHNICAL_ERROR);
				logger.error(msg);
				msg = "Unable to perfom the action because of a fatal error [{VERIFY TOTP}].";
				logger.error(msg);
				
				throw new TechnicalException(msg);	
			}
			
			if(hasFailed)
			{
				// Failed attempt so we increment the nb attempts to block him later if max reached
				getUserSecretSBO().incrementNbAttempts(login);				

			
				// If we are here, this means we have to warn the user that the OTP check has failed (invalid otp)
				String msg = getMessageBuilder()
				.build(
						InvalidParameterBOExceptionConstants.TOTP_VALIDATESECRET_IS_INVALID,
						new String[] { login }); 
				logger.error(msg);
				throw new FunctionalException(msg);				
			}
			else
			{
				// If we are here, this means that everything is ok
				// So lets activated the user secret and reset the nb attempts to 0
				getUserSecretSBO().updateActiveWithNbAttemps(login, true, 0);
			}
		} catch (InvalidParameterBOException e) {
			throw getExceptionMapper().map(e, logger);
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(e, logger);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.bnppa.sesame.services.standard.StandardTOTPServices#generateAndAttachSecret(java.lang.String, com.bnppa.sesame.services.standard.model.v2.SecurityQuestionsResponses[])
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = FunctionalException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-totp_std_v1-generateAndAttachSecret")
	@Transactional(readOnly = true)
	public EncodedSecret generateAndAttachSecret(@Token String token, SecurityQuestionsResponses[] securityQuestionsResponses, String authenticatorSecretTitle)
		throws FunctionalException, TechnicalException
	{		
		EncodedSecret result =  null;
		
		try
		{
			TokenEBO tokenEBO = getTokenSBO().find(token);
			AuthAccountEBO authAccountEBO = getTokenSBO().getAuthAccount(tokenEBO);

			// Sanity check
			checkAuthAccount(authAccountEBO);

			// Check account type
			checkAccountTypeIsUSER(authAccountEBO);

			// Sanity check
			if (securityQuestionsResponses == null || securityQuestionsResponses.length == 0) 
			{
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.TOTP_INVALID_PARAMETER,
								new String[] { "SECURITY QUESTIONS RESPONSES" });
				logger.error(msg);
				throw new FunctionalException(msg);
			}

			// login used to login in sesame
			String login = authAccountEBO.getLogin();		
			
			// If the user is group then we have to load the authAccount with the following API
			// otherwise we will not load the right account data linked to the group user (login defined like l_uid_XXXX)
			// and we will not have the email address of the user for example
			if (authAccountEBO.getAuthType().equals(AuthAccountConstants.TYPE_GROUP))
			{
				authAccountEBO = authAccountSBO.findAccountTypeGroup(login);
			}			
			
			checkAuthAccount(authAccountEBO);			
			
			// if group we have to get the login again, because it is going to be like l_uid_xxxx
			login = authAccountEBO.getLogin();
			
			UserSecretEBO userSecretEBO = getUserSecretSBO().find(login);
			
			if(userSecretEBO != null)
			{
				//Sanity checks
				if(userSecretEBO.getActive() == null || userSecretEBO.getNbAttempts() == null
						|| userSecretEBO.getCreationDate() == null 
						|| StringUtils.isBlank(userSecretEBO.getSecret()))
				{
					String msg = getMessageBuilder().build(
							TechnicalBOExceptionConstants.TECHNICAL_ERROR);
					logger.error(msg);
					msg = "Invalid secret => Problem with the data in database : active or nbAttempts or creationDate or lastUpdate or secret is/are null ";
					logger.error(msg);
					
					throw new TechnicalException(msg);					
				}
				
				// Check that the secret is not already active
				if( BooleanUtils.isTrue(userSecretEBO.getActive()) )
				{
					String msg = getMessageBuilder()
					.build(
							InvalidParameterBOExceptionConstants.TOTP_USER_SECRET_GENERATE_ALREADY_ACTIVE,
							new String[] { login }); 
					logger.error(msg);
					throw new FunctionalException(msg);				
				}
				
				// Check that the user respects the minimum time for regenerating his secret
				// default 30 mins
				/* CHECK REMOVED - JIRA #1404
				if(userSecretEBO.getSecretCreationDateAgeInSeconds() 
						< getUserSecretSBO().getVerifyCreatedMaxAge() )
				{ 
					String msg = getMessageBuilder()
					.build(
							InvalidParameterBOExceptionConstants.TOTP_USER_SECRET_GENERATE_NOT_YET_ALLOWED,
							new String[] { login }); 
					logger.error(msg);
					throw new FunctionalException(msg);				
				}
				*/								
			}

			Set<?> emailAddresses = personSBO.findEmailAddresses(authAccountEBO.getAccount().getPerson());		

			// Check that the user has email addresses
			if(CollectionUtils.isEmpty(emailAddresses))
			{
				String msg = getMessageBuilder()
				.build(
						InvalidParameterBOExceptionConstants.TOTP_USER_SECRET_GENERATE_USER_EMAIL_NOT_FOUND,
						new String[] { login }); 
				logger.error(msg);
				throw new FunctionalException(msg);				
			}
			
			Set<SecurityResponseEBO> responses = new HashSet<>();
			
			// Tranform object to EBO objects
			for(int i = 0; i < securityQuestionsResponses.length; i++)
			{
				if(securityQuestionsResponses[i] != null)
					responses.add(new SecurityResponseEBO(login, 
							securityQuestionsResponses[i].getIdSecurityQuestion(),
							securityQuestionsResponses[i].getResponse()));
			}
			
			// Check that the questions and responses are corrects
			if(!getSecurityResponseSBO().isSecurityResponsesValid( 
					(SecurityResponseEBO[])responses.toArray(new SecurityResponseEBO[responses.size()])   
				)
			)
			{
				String msg = getMessageBuilder()
				.build(
						InvalidParameterBOExceptionConstants.TOTP_SECRET_QUESTIONS_NOT_CORRECT,
						new String[] { login }); 
				logger.error(msg);
				throw new FunctionalException(msg);				
			}
			
			// SESAMECA-609 : Add title for authenticator
			if (StringUtils.isNotEmpty(authenticatorSecretTitle)){
				authenticatorSecretTitle = authenticatorSecretTitle.replaceAll("|", "");
			}
			
			// return the encrypted value
			result =  getUserSecretSBO().generateAttachAndSendSecret(authAccountEBO, authenticatorSecretTitle);
			
		} catch (InvalidParameterBOException e) {
			throw getExceptionMapper().map(e, logger);
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(e, logger);
		}	
		
		return result;		
	}

	/*
	 * (non-Javadoc)
	 * @see com.bnppa.sesame.services.standard.StandardTOTPServices#isTOTPInitialized(java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = FunctionalException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-totp_std_v1-isTOTPInitialized")
	@Transactional(readOnly = true)
	public boolean isTOTPInitialized(@Token String token) throws FunctionalException, TechnicalException{
		try
		{
			TokenEBO tokenEBO = getTokenSBO().find(token);
			if (tokenEBO == null) {
				String msg = getMessageBuilder().build(InvalidParameterBOExceptionConstants.TOKEN_NOT_EXIST, new String[] { token });
				logger.error(msg);
				throw new FunctionalException(msg);
			}			
			AuthAccountEBO authAccountEBO = getTokenSBO().getAuthAccount(tokenEBO);
			
			// Sanity check
			checkAuthAccount(authAccountEBO);
			
			// Check account type
			checkAccountTypeIsUSER(authAccountEBO);

			// We need the login : used in the TAUSERSECRETS
			String login = authAccountEBO.getLogin();		
						
			// If the user is group then we have to load the authAccount with the following API
			// otherwise we will not load the right account data linked to the group user (login defined like l_uid_XXXX)
			// and we will not have the email address of the user for example
			if (authAccountEBO.getAuthType().equals(AuthAccountConstants.TYPE_GROUP))
			{
				authAccountEBO = authAccountSBO.findAccountTypeGroup(login);
			}			
			
			checkAuthAccount(authAccountEBO);
			
			login = authAccountEBO.getLogin();
			
			UserSecretEBO userSecretEBO = getUserSecretSBO().find(login);
			
			if(userSecretEBO == null)
			{
				return false;								
			}
			else
			{
				return userSecretEBO.getActive().booleanValue();
			}			
		} catch (InvalidParameterBOException e) {
			throw getExceptionMapper().map(e, logger);
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(e, logger);
		}		
	}
	
	/**
	 * Check authAccount is not null
	 * @param authAccountEBO
	 * @throws FunctionalException
	 */
	private void checkAuthAccount(AuthAccountEBO authAccountEBO) throws FunctionalException
	{
		if(authAccountEBO == null || StringUtils.isBlank(authAccountEBO.getLogin()))
		{
			String msg = getMessageBuilder()
			.build(
					InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_NOT_EXIST,
					new String[] { "" }); // Empty because authAccountEBO.getLogin() is null
			logger.error(msg);
			throw new FunctionalException(msg);
		}		
	}

	/**
	 * Check account type is user
	 * @param authAccountEBO
	 * @throws FunctionalException
	 */
	protected void checkAccountTypeIsUSER(AuthAccountEBO authAccountEBO) throws FunctionalException
	{
		if(authAccountEBO.getAccount()!=null && authAccountEBO.getAccount().getIdAccountType()!=null)
		{	
			if(!AccountConstants.TYPE_USER.equals(authAccountEBO.getAccount().getIdAccountType())
				      /*&& !AccountConstants.TYPE_MONITORING.equals(authAccountEBO.getAccount().getIdAccountType())*/)
		    {
				String msg = getMessageBuilder().build(
										CommonBOExceptionConstants.FORBID_ACCESS_SERVICE,
										new String[] { authAccountEBO.getAccount().getIdAccountType() });
				logger.error(msg);
				throw new FunctionalException(msg);
			}
		}		
	}
	
	/**
	 * @param messageBuilder
	 */
	public void setMessageBuilder(MessageDescriptionBuilder messageBuilder) {
		this.messageBuilder = messageBuilder;
	}

	/**
	 * @return messageBuilder
	 */
	private MessageDescriptionBuilder getMessageBuilder() {
		return messageBuilder;
	}

	/**
	 * @return the exceptionMapper
	 */
	private GeneralExceptionMapper getExceptionMapper() {
		return this.exceptionMapper;
	}

	/**
	 * @param exceptionMapper
	 *            the exceptionMapper to set
	 */
	public void setExceptionMapper(GeneralExceptionMapper exceptionMapper) {
		this.exceptionMapper = exceptionMapper;
	}
	
	/**
	 * @return Returns the tokenSBO.
	 */
	private TokenSBO getTokenSBO() {
		return tokenSBO;
	}

	/**
	 * @param tokenSBO
	 *            The tokenSBO to set.
	 */
	public void setTokenSBO(TokenSBO tokenSBO) {
		this.tokenSBO = tokenSBO;
	}	

	/**
	 * @return Returns the userSecretSBO.
	 */
	private UserSecretSBO getUserSecretSBO() {
		return userSecretSBO;
	}

	/**
	 * @param userSecretSBO
	 *            The userSecretSBO to set.
	 */
	public void setUserSecretSBO(UserSecretSBO userSecretSBO) {
		this.userSecretSBO = userSecretSBO;
	}
	
	/**
	 * @return Returns the tokenSBO.
	 */
	private AuthAccountSBO getAuthAccountSBO() {
		return authAccountSBO;
	}

	/**
	 * @param tokenSBO
	 *            The tokenSBO to set.
	 */
	public void setAuthAccountSBO(AuthAccountSBO authAccountSBO) {
		this.authAccountSBO = authAccountSBO;
	}
	
	/**
	 * @return Returns the securityResponseSBO.
	 */
	private SecurityResponseSBO getSecurityResponseSBO() {
		return securityResponseSBO;
	}

	/**
	 * @param securityResponseSBO
	 *            The securityResponseSBO to set.
	 */
	public void setSecurityResponseSBO(SecurityResponseSBO securityResponseSBO) {
		this.securityResponseSBO = securityResponseSBO;
	}
}
