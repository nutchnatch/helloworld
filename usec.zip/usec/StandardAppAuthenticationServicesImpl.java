package com.bnppa.sesame.services.standard;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnppa.sesame.authaccount.AuthAccountEBO;
import com.bnppa.sesame.authaccount.AuthAccountSBO;
import com.bnppa.sesame.constants.AccountConstants;
import com.bnppa.sesame.constants.AuthAccountConstants;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.exceptions.BadPasswordBOException;
import com.bnppa.sesame.exceptions.ExpiredPasswordBOException;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.LockedAccountBOException;
import com.bnppa.sesame.exceptions.LoginBOException;
import com.bnppa.sesame.exceptions.TechnicalBOException;
import com.bnppa.sesame.services.exception.FunctionalException;
import com.bnppa.sesame.services.exception.LoginException;
import com.bnppa.sesame.services.exception.TechnicalException;
import com.bnppa.sesame.services.standard.mapper.GeneralExceptionMapper;
import com.bnppa.sesame.token.TokenEBO;
import com.bnppa.sesame.token.TokenSBO;
import com.bnppa.sesame.utils.annot.Audit;
import com.bnppa.sesame.utils.annot.AuditHide;
import com.bnppa.sesame.utils.annot.Login;
import com.bnppa.sesame.utils.annot.Profiled;
import com.bnppa.sesame.utils.annot.RuntimeCatcher;

public class StandardAppAuthenticationServicesImpl implements StandardAppAuthenticationServices {
	
	private static final Log logger = LogFactory.getLog(StandardAppAuthenticationServicesImpl.class);
	
	private AuthAccountSBO authAccountSBO; 
	
	private TokenSBO tokenSBO;
	
	private GeneralExceptionMapper exceptionMapper;
	
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@Profiled(name = "in-soap-app_authent_v1-loginForApplication")
	@Transactional(noRollbackFor = { LoginException.class }, propagation=Propagation.REQUIRES_NEW)
	public String loginForApplication(@Login String login, @AuditHide String password, String applicationId) throws FunctionalException, TechnicalException {
		try {
			AuthAccountEBO authAccountEBO = getAuthAccountSBO().find(login, AuthAccountConstants.SYST_SESAME, AuthAccountConstants.TYPE_TIERS);
			if (authAccountEBO == null) {
				throw new InvalidParameterBOException(
						InvalidParameterBOExceptionConstants.ACCOUNT_NOT_EXIST,
						new String[] { login }, logger);
			}
			
			if (!AccountConstants.TYPE_APPLICATION.equals(authAccountEBO.getAccount().getIdAccountType())) {
				throw new InvalidParameterBOException(
						InvalidParameterBOExceptionConstants.ACCOUNT_ID_MUST_BE_APPLICATION,
						new String[] { login }, logger);
			}
			
			authAccountSBO.login(authAccountEBO, password);

			TokenEBO tokenEBO = getTokenSBO().create(authAccountEBO, applicationId);
			
			return tokenEBO.getId();
		} catch (InvalidParameterBOException e) {
			throw getExceptionMapper().map(e, logger);
		} catch (LoginBOException e) {
			throw getExceptionMapper().map(e, logger);
		} catch (BadPasswordBOException e) {
			throw getExceptionMapper().map(e, logger);
		} catch (ExpiredPasswordBOException e) {
			throw getExceptionMapper().map(e, logger);
		} catch (LockedAccountBOException e) {
			throw getExceptionMapper().map(e, logger);
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(e, logger);
		}
	}

	/**
	 * @return authAccountSBO
	 */
	public AuthAccountSBO getAuthAccountSBO() {
		return authAccountSBO;
	}

	/**
	 * @param authAccountSBO authAccountSBO � d�finir
	 */
	public void setAuthAccountSBO(AuthAccountSBO authAccountSBO) {
		this.authAccountSBO = authAccountSBO;
	}

	/**
	 * @return tokenSBO
	 */
	public TokenSBO getTokenSBO() {
		return tokenSBO;
	}

	/**
	 * @param tokenSBO tokenSBO � d�finir
	 */
	public void setTokenSBO(TokenSBO tokenSBO) {
		this.tokenSBO = tokenSBO;
	}

	/**
	 * @return exceptionMapper
	 */
	public GeneralExceptionMapper getExceptionMapper() {
		return exceptionMapper;
	}

	/**
	 * @param exceptionMapper exceptionMapper � d�finir
	 */
	public void setExceptionMapper(GeneralExceptionMapper exceptionMapper) {
		this.exceptionMapper = exceptionMapper;
	}

}
