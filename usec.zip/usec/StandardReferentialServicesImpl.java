/**
 * 
 */
package com.bnppa.sesame.services.standard;

import gencl.sesame.services.standard.proxy.ArrayOfTns2NillableSecretQuestion;
import gencl.sesame.services.standard.proxy.ReferentialServicesWSP;
import gencl.sesame.services.standard.proxy.TechnicalException;
import gencl.sesame.services.vo.SecretQuestion;

import java.util.Collection;
import java.util.Iterator;

import com.bnppa.sesame.MessageDescriptionBuilder;
import com.bnppa.sesame.secretquestion.SecretQuestionEBO;
import com.bnppa.sesame.secretquestion.SecretQuestionSBO;
import org.springframework.transaction.annotation.Transactional;
import com.bnppa.sesame.utils.annot.Profiled;
import com.bnppa.sesame.utils.annot.RuntimeCatcher;
import com.bnppa.sesame.utils.annot.Audit;

/**
 * @author rochinaen
 * @author bellidori
 * @version Sep 14, 2009
 * @version 24/08/10
 * 
 */
public class StandardReferentialServicesImpl implements ReferentialServicesWSP {

	/**
	 * Exceptions messages builder
	 */
	private MessageDescriptionBuilder messageBuilder;

	private SecretQuestionSBO secretQuestionSBO;

	/**
	 * 
	 * @return secretQuestionSBO
	 */
	private SecretQuestionSBO getSecretQuestionSBO() {
		return secretQuestionSBO;
	}

	/**
	 * 
	 * @param secretQuestionSBO
	 */
	public void setSecretQuestionSBO(SecretQuestionSBO secretQuestionSBO) {
		this.secretQuestionSBO = secretQuestionSBO;
	}

	/**
	 * @author rochinaen
	 * @author gilletmc
	 * @author bellidori
	 * @see com.bnppa.sesame.services.standard.ReferentialServices#getAllSecretQuestions()
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@Profiled(name = "in-soap-referential_v1-getAllSecretQuestions")
	@Transactional(readOnly = true)
	public ArrayOfTns2NillableSecretQuestion getAllSecretQuestions() throws TechnicalException {

		Collection questionEBOs = getSecretQuestionSBO().findSortedSet();

		if (questionEBOs == null) {
			return null;
		}
		SecretQuestion[] questions = new SecretQuestion[questionEBOs.size()];

		int i = 0;
		for (Iterator iter = questionEBOs.iterator(); iter.hasNext();) {
			SecretQuestionEBO secretQuestionEBO = (SecretQuestionEBO) iter
					.next();

			SecretQuestion sq = new SecretQuestion();
			sq.setId(secretQuestionEBO.getLabel());
			sq.setLanguageId(secretQuestionEBO.getLanguage());
			questions[i++] = sq;
			iter.remove();
		}

		ArrayOfTns2NillableSecretQuestion container = new ArrayOfTns2NillableSecretQuestion();
		container.setSecretQuestion(questions);
		
		return container;

	}

	/**
	 * 
	 * @return messageBuilder
	 */
	private MessageDescriptionBuilder getMessageBuilder() {
		return messageBuilder;
	}

	/**
	 * 
	 * @param messageBuilder
	 */
	public void setMessageBuilder(MessageDescriptionBuilder messageBuilder) {
		this.messageBuilder = messageBuilder;
	}

}
