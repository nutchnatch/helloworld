/*
 * Created on Sep 30, 2009
 */
package com.bnppa.sesame.services.standard;

import gencl.sesame.services.common.model.KeyValue;
import gencl.sesame.services.common.model.UserExtendedIdentity;
import gencl.sesame.services.common.model.UserIdentity;
import gencl.sesame.services.standard.proxy.ArrayOfTns3NillableKeyValue;
import gencl.sesame.services.standard.proxy.InvalidParameterException;
import gencl.sesame.services.standard.proxy.InvalidTokenException;
import gencl.sesame.services.standard.proxy.TechnicalException;
import gencl.sesame.services.standard.proxy.IdentityServicesWSP;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bnppa.sesame.MessageDescriptionBuilder;
import com.bnppa.sesame.authaccount.AuthAccountEBO;
import com.bnppa.sesame.authaccount.AuthAccountSBO;
import com.bnppa.sesame.authaccount.AuthAccountSBOImpl;
import com.bnppa.sesame.constants.AccountConstants;
import com.bnppa.sesame.constants.CommonBOExceptionConstants;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.TechnicalBOException;
import com.bnppa.sesame.exceptions.UnAuthorizedActionBOException;
import com.bnppa.sesame.services.standard.mapper.MapperBO;
import com.bnppa.sesame.services.standard.mapper.StandardExceptionMapper;
import com.bnppa.sesame.token.TokenEBO;
import com.bnppa.sesame.token.TokenSBO;
import com.bnppa.sesame.utils.WebFaultFactory;
import org.springframework.transaction.annotation.Transactional;
import java.lang.Exception;
import com.bnppa.sesame.utils.annot.Profiled;
import com.bnppa.sesame.utils.annot.TokenControl;
import com.bnppa.sesame.utils.annot.Token;
import com.bnppa.sesame.utils.annot.RuntimeCatcher;
import com.bnppa.sesame.utils.annot.Audit;

/**
 * @author behatemo
 * @author bellidori
 * @version Sep 30, 2009
 * @version 28/08/10
 */
public class StandardIdentityServicesImpl implements IdentityServicesWSP {

	private static final Log			logger	= LogFactory
														.getLog(StandardAuthorizationServicesImpl.class);

	/**
	 * Exceptions messages builder
	 */
	private MessageDescriptionBuilder	messageBuilder;

	/**
	 * Exception mapper.
	 */
	private StandardExceptionMapper				exceptionMapper;

	/**
	 * Session business object of authentication account
	 */
	private AuthAccountSBO				authAccountSBO;

	/**
	 * session business object of token
	 */
	private TokenSBO					tokenSBO;

	private MapperBO					userIdentityMapper;

	private MapperBO					extendedAttributesMapper;

	private MapperBO					userExtendedIdentityMapper;

	/**
	 * @author behatemo
	 * @version Sep 30, 2009
	 * @see com.bnppa.sesame.services.standard.IdentityServices#changeLogin(java.lang.String,
	 *      java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = InvalidTokenException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-identity_std_v1-changeLogin")
	@Transactional(rollbackFor = { Exception.class })
	public void changeLogin(@Token String token, String newLogin)
			throws InvalidParameterException, InvalidTokenException,
			TechnicalException {

		try {

			TokenEBO tokenEBO = getTokenSBO().find(token);

			/* NOT NEED TO DO THAT BECAUSE AN ASPECT VERIFY THAT THE TOKEN IS NOT NULL */
//			if (tokenEBO == null) {
//				String msg = getMessageBuilder().build(
//						InvalidParameterBOExceptionConstants.TOKEN_NOT_EXIST);
//				if (logger.isInfoEnabled()) {
//					logger.info(new StringBuffer(msg).append(" : ").append(
//							token).toString());
//				}
//				throw new InvalidTokenException(msg);
//			}
						
			if(AccountConstants.TYPE_APPLICATION.equals(tokenEBO.getIdAccountType()))
			{
					String msg = getMessageBuilder().build(
									CommonBOExceptionConstants.FORBID_ACCESS_SERVICE,
									new String[] {AccountConstants.TYPE_APPLICATION});
					logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			AuthAccountEBO authAccountEBO = getTokenSBO().getAuthAccount(
					tokenEBO);
			
			authAccountSBO.changeLogin(authAccountEBO, newLogin);

			getTokenSBO().update(tokenEBO, getAuthAccountSBO().find(newLogin));

		} catch (UnAuthorizedActionBOException e) {
			InvalidParameterException exc = WebFaultFactory.createInvalidParameterException(getMessageBuilder().build(e.getMessageCode(),
					e.getParameters()));
			logger.error(exc, e);
			throw exc;
		} catch (InvalidParameterBOException e) {
			throw getExceptionMapper().map(logger, e);
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}
	}

	/**
	 * @author behatemo
	 * @version Sep 30, 2009
	 * @see com.bnppa.sesame.services.standard.IdentityServices#getExtendedAttributes(java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = InvalidTokenException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-identity_std_v1-getExtendedAttributes")
	@Transactional(readOnly = true)
	public ArrayOfTns3NillableKeyValue getExtendedAttributes(@Token String token)
			throws InvalidTokenException, TechnicalException {

		try {
			TokenEBO tokenEBO = getTokenSBO().find(token);
			if (tokenEBO == null) {
				String msg = getMessageBuilder().build(
						InvalidParameterBOExceptionConstants.TOKEN_NOT_EXIST);
				logger.error(new StringBuffer(msg).append(" : ").append(token)
						.toString());
				throw WebFaultFactory.createInvalidTokenException(msg);
			}

			AuthAccountEBO authAccountEBO = getTokenSBO().getAuthAccount(tokenEBO);
			
			return getAttributes(authAccountEBO);

		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}
	}

	/**
	 * @author behatemo
	 * @author bellidori
	 * @see com.bnppa.sesame.services.standard.IdentityServices#getUserExtendedIdentity(java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = InvalidTokenException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-identity_std_v1-getUserExtendedIdentity")
	@Transactional(readOnly = true)
	public UserExtendedIdentity getUserExtendedIdentity(@Token String token)throws InvalidTokenException, TechnicalException {
		try {
			TokenEBO tokenEBO = getTokenSBO().find(token);
			if (tokenEBO == null) {
				String msg = getMessageBuilder().build(
						InvalidParameterBOExceptionConstants.TOKEN_NOT_EXIST);
				logger.error(new StringBuffer(msg).append(" : ").append(token)
						.toString());
				throw WebFaultFactory.createInvalidTokenException(msg);
			}

			AuthAccountEBO authAccountEBO = getTokenSBO().getAuthAccount(
					tokenEBO);

			return (UserExtendedIdentity) this.getUserExtendedIdentityMapper()
					.mapEBOtoVO(authAccountEBO);

		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}
	}

	/**
	 * @author behatemo
	 * @version Sep 30, 2009
	 * @see com.bnppa.sesame.services.standard.IdentityServices#getUserIdentity(java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = InvalidTokenException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-identity_std_v1-getUserIdentity")
	@Transactional(readOnly = true)
	public UserIdentity getUserIdentity(@Token String token) throws InvalidTokenException, TechnicalException {

		try {

			TokenEBO tokenEBO = getTokenSBO().find(token);

			if (tokenEBO == null) {
				String msg = getMessageBuilder().build(	InvalidParameterBOExceptionConstants.TOKEN_NOT_EXIST);
				logger.error(new StringBuffer(msg).append(" : ").append(token)
						.toString());
				throw WebFaultFactory.createInvalidTokenException(msg);
			}

			AuthAccountEBO authAccountEBO = getTokenSBO().getAuthAccount(
					tokenEBO);

			return getIdentity(authAccountEBO);

		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}
	}

	private UserIdentity getIdentity(AuthAccountEBO authAccountEBO)
			throws TechnicalBOException {

		return (UserIdentity) this.getUserIdentityMapper().mapEBOtoVO(
				authAccountEBO);

	}

	private ArrayOfTns3NillableKeyValue getAttributes(AuthAccountEBO authAccountEBO) {
		ArrayOfTns3NillableKeyValue container = new ArrayOfTns3NillableKeyValue();
		KeyValue[] keyvalues = (KeyValue[]) this.getExtendedAttributesMapper().mapEBOtoVO(authAccountEBO);
		container.setKeyValue(keyvalues);
		return container;

	}

	/**
	 * @return Returns the authAccountSBO.
	 */
	private AuthAccountSBO getAuthAccountSBO() {
		return authAccountSBO;
	}

	/**
	 * @param authAccountSBO
	 *            The authAccountSBO to set.
	 */
	public void setAuthAccountSBO(AuthAccountSBO authAccountSBO) {
		this.authAccountSBO = authAccountSBO;
	}

	/**
	 * @return Returns the tokenSBO.
	 */
	private TokenSBO getTokenSBO() {
		return tokenSBO;
	}

	/**
	 * @param tokenSBO
	 *            The tokenSBO to set.
	 */
	public void setTokenSBO(TokenSBO tokenSBO) {
		this.tokenSBO = tokenSBO;
	}

	/**
	 * @return messageBuilder
	 */
	private MessageDescriptionBuilder getMessageBuilder() {
		return messageBuilder;
	}

	/**
	 * @param messageBuilder
	 */
	public void setMessageBuilder(MessageDescriptionBuilder messageBuilder) {
		this.messageBuilder = messageBuilder;
	}

	/**
	 * @return the exceptionMapper
	 */
	private StandardExceptionMapper getExceptionMapper() {
		return this.exceptionMapper;
	}

	/**
	 * @param exceptionMapper
	 *            the exceptionMapper to set
	 */
	public void setExceptionMapper(StandardExceptionMapper exceptionMapper) {
		this.exceptionMapper = exceptionMapper;
	}

	/**
	 * @return extendedAttributesMapper
	 */
	public MapperBO getExtendedAttributesMapper() {
		return extendedAttributesMapper;
	}

	/**
	 * @param extendedAttributesMapper
	 *            extendedAttributesMapper � d�finir
	 */
	public void setExtendedAttributesMapper(MapperBO extendedAttributesMapper) {
		this.extendedAttributesMapper = extendedAttributesMapper;
	}

	/**
	 * @return userExtendedIdentityMapper
	 */
	public MapperBO getUserExtendedIdentityMapper() {
		return userExtendedIdentityMapper;
	}

	/**
	 * @param userExtendedIdentityMapper
	 *            userExtendedIdentityMapper � d�finir
	 */
	public void setUserExtendedIdentityMapper(
			MapperBO userExtendedIdentityMapper) {
		this.userExtendedIdentityMapper = userExtendedIdentityMapper;
	}

	/**
	 * @return userIdentityMapper
	 */
	public MapperBO getUserIdentityMapper() {
		return userIdentityMapper;
	}

	/**
	 * @param userIdentityMapper
	 *            userIdentityMapper � d�finir
	 */
	public void setUserIdentityMapper(MapperBO userIdentityMapper) {
		this.userIdentityMapper = userIdentityMapper;
	}

}
