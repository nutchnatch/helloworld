package com.bnppa.sesame.services.standard;

import com.bnppa.sesame.services.exception.FunctionalException;
import com.bnppa.sesame.services.exception.TechnicalException;

public interface StandardAppAuthenticationServices {

	/**
	 * Allows to connect according to the parameters. <br>
	 * The service searches for the existence of the user in every referential
	 * users in the following order : "TIERS", "CLIENT" and "GROUP" then
	 * authenticates the user with the referential. <br>
	 * Returns a technical identifier of session of connection.
	 * @param login login of the user
	 * @param password password of the user
	 * @param applicationId id of application
	 * @throws FunctionalException functional exception
	 * @throws TechnicalException technical exception
	 * @return a session token
	 */
	public String loginForApplication(String login, String password, String applicationId) throws FunctionalException, TechnicalException;
	
}
