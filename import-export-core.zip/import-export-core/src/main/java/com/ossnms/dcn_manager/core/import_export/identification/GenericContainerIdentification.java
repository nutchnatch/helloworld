package com.ossnms.dcn_manager.core.import_export.identification;

import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ContainerValueObject;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

public class GenericContainerIdentification implements Identification<ContainerValueObject, ContainerInfo> {

    private static final Logger LOGGER = LoggerFactory.getLogger(GenericContainerIdentification.class);
    private final ContainerRepository containerRepository;

    public GenericContainerIdentification(ContainerRepository containerRepository) {
        this.containerRepository = containerRepository;
    }

    @Override public Optional<ContainerInfo> tryIdentify(ContainerValueObject containerValueObject) {
        return findByName(containerValueObject);
    }

    private Optional<ContainerInfo> findByName(ContainerValueObject containerValueObject)  {
        try {
            return containerRepository.queryByName(containerValueObject.name());
        } catch (RepositoryException e) {
            LOGGER.error("Failed to fetch container", e);
            return Optional.empty();
        }
    }
}
