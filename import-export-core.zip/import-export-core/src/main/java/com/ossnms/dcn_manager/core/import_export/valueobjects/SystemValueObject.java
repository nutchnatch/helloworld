package com.ossnms.dcn_manager.core.import_export.valueobjects;

import org.immutables.value.Value.Immutable;
import org.immutables.value.Value.Parameter;

import java.util.List;
import java.util.Optional;

@Immutable public interface SystemValueObject {
    @Parameter String name();

    Optional<String> userText();

    Optional<String> description();

    List<AssignedContainer> assignedContainers();
}
