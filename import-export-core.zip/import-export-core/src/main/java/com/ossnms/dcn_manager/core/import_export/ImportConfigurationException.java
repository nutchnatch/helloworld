package com.ossnms.dcn_manager.core.import_export;

import com.ossnms.dcn_manager.exceptions.DcnManagerException;

/**
 * ImportConfigurationException thrown by #Importer when an error occurs.
 */
public class ImportConfigurationException extends DcnManagerException {

    private static final long serialVersionUID = -6927775173048496950L;

    /** @see DcnManagerException#DcnManagerException() */
    public ImportConfigurationException() {

    }

    /** @see DcnManagerException#DcnManagerException(String) */
    public ImportConfigurationException(final String message) {
        super(message);
    }

    /** @see DcnManagerException#DcnManagerException(Throwable) */
    public ImportConfigurationException(final Throwable cause) {
        super(cause);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable) */
    public ImportConfigurationException(final String message, final Throwable cause) {
        super(message, cause);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable,boolean,boolean) */
    public ImportConfigurationException(final String message, final Throwable cause, final boolean enableSuppression,
            final boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /** @see DcnManagerException#DcnManagerException(String, Object...) */
    public ImportConfigurationException(final String format, final Object... formatParameters) {
        super(format, formatParameters);
    }
}
