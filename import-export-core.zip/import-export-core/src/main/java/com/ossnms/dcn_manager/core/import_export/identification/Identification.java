package com.ossnms.dcn_manager.core.import_export.identification;

import java.util.Optional;

@FunctionalInterface public interface Identification<INPUT, DATA> {

    default boolean notExists(INPUT input) {
        return !exists(input);
    }

    default boolean exists(INPUT input) {
        return tryIdentify(input).isPresent();
    }

    Optional<DATA> tryIdentify(INPUT input);

}