package com.ossnms.dcn_manager.core.import_export.identification;

import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository.MediatorInfoRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Objects;
import java.util.Optional;

import static java.util.Optional.empty;
import static java.util.Optional.ofNullable;

public class MediatorIdentification implements Identification<MediatorValueObject, MediatorInfoData> {
    private static final Logger LOGGER = LoggerFactory.getLogger(MediatorIdentification.class);

    private final MediatorInfoRepository mediatorInfoRepository;
    private final Types<MediatorType> mediatorTypes;

    public MediatorIdentification(@Nonnull final Types<MediatorType> mediatorTypes,
                                  @Nonnull final MediatorInfoRepository mediatorInfoRepository) {
        this.mediatorTypes = mediatorTypes;
        this.mediatorInfoRepository = mediatorInfoRepository;
    }

    @Override
    public Optional<MediatorInfoData> tryIdentify(@Nonnull final MediatorValueObject mediator) {
        return findTypeOf(mediator)
                .map(this::identificationFromType)
                .flatMap(identification -> identification.tryIdentify(mediator));
    }

    private Identification<MediatorValueObject, MediatorInfoData> identificationFromType(MediatorType type) {
        return type.allowManyOnSameHost()
                ? this::findByNameAndType
                : this::findByHostAndType;
    }

    private Optional<MediatorType> findTypeOf(@Nonnull MediatorValueObject mediator) {
        return ofNullable(mediatorTypes.get(mediator.getType()));
    }

    private Optional<MediatorInfoData> findByNameAndType(@Nonnull MediatorValueObject mediator) {
        try {
            return ofNullable(mediatorInfoRepository
                    .query(mediator.getName()).orElse(null))
                    .filter(infoData -> Objects.equals(infoData.getTypeName(), mediator.getType()));
        } catch (RepositoryException e) {
            LOGGER.error("Repository is not available.", e);
            return empty();
        }
    }

    private Optional<MediatorInfoData> findByHostAndType(@Nonnull MediatorValueObject mediator) {
        try {
            return ofNullable(mediatorInfoRepository
                    .queryByHost(mediator.getType(), mediator.getHost()).orElse(null));
        } catch (RepositoryException e) {
            LOGGER.error("Repository is not available.", e);
            return empty();
        }
    }
}
