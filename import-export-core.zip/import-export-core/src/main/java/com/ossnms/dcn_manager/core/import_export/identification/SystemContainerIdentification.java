package com.ossnms.dcn_manager.core.import_export.identification;

import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.import_export.valueobjects.SystemValueObject;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

public class SystemContainerIdentification implements Identification<SystemValueObject, SystemInfo> {

    private static final Logger LOGGER = LoggerFactory.getLogger(SystemContainerIdentification.class);
    private final SystemRepository systemRepository;

    public SystemContainerIdentification(SystemRepository systemRepository) {
        this.systemRepository = systemRepository;
    }

    @Override public Optional<SystemInfo> tryIdentify(SystemValueObject systemValueObject) {
        return findByName(systemValueObject);
    }

    private Optional<SystemInfo> findByName(SystemValueObject systemValueObject)  {
        try {
            return systemRepository.queryByName(systemValueObject.name());
        } catch (RepositoryException e) {
            LOGGER.error("Failed to fetch system container", e);
            return Optional.empty();
        }
    }
}
