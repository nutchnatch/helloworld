package com.ossnms.dcn_manager.core.import_export.identification;

import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

public class NeIdentification implements Identification<NeValueObject, NeUserPreferencesData> {
    private static final Logger LOGGER = LoggerFactory.getLogger(NeIdentification.class);

    private final NeUserPreferencesRepository neRepository;

    public NeIdentification(@Nonnull final NeUserPreferencesRepository neRepository) {
        this.neRepository = neRepository;
    }
    
    @Override
    public Optional<NeUserPreferencesData> tryIdentify(@Nonnull final NeValueObject ne) {
        return tryFindByName(ne.getName());
    }

    public Optional<NeUserPreferencesData> tryFindByName(@Nonnull final String neName) {
        try {
            return neRepository.query(neName);
        } catch (final RepositoryException e) {
            LOGGER.error("Repository is not available.", e);
        }
        
        return Optional.empty();
    }
}
