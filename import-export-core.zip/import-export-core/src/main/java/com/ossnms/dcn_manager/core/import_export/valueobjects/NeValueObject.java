package com.ossnms.dcn_manager.core.import_export.valueobjects;

import org.immutables.value.Value.Immutable;
import org.immutables.value.Value.Parameter;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Optional;


@Immutable public interface NeValueObject extends Serializable {

    @Parameter String getName();

    @Parameter String getType();

    @Parameter String getChannel();

    Optional<Integer> getNeId();

    Optional<String> getFamilyLabel();

    Optional<String> getTypeLabel();

    Optional<String> getSubTypeLabel();

    Optional<String> getCoreId();

    Optional<String> getLocation();

    Map<String, String> getPropertyBag();

    List<String> getDomainNames();

    List<AssignedContainer> getAssignedContainers();
    
    Optional<String> systemContainer();
    
    Optional<NeAdditionalInfo> getNeAdditionalInfo();
}
