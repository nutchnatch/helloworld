package com.ossnms.dcn_manager.core.import_export.identification;

import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ChannelValueObject;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;

public class ChannelIdentification implements Identification<ChannelValueObject, ChannelUserPreferencesData> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChannelIdentification.class);
    
    private final ChannelEntityRepository channelRepository;

    public ChannelIdentification(@Nonnull final ChannelEntityRepository channelRepository) {
        this.channelRepository = channelRepository;
    }
    
    @Override
    public Optional<ChannelUserPreferencesData> tryIdentify(@Nonnull final ChannelValueObject channel) {
        return tryFindByName(channel.getName());                    
    }

    public Optional<ChannelUserPreferencesData> tryFindByName(@Nonnull final String channelName) {
        try {
            return channelRepository.getChannelUserPreferencesRepository().query(channelName);
        } catch (final RepositoryException e) {
            LOGGER.error("Repository is not available.", e);
        }
        
        return Optional.empty();
    }
}
