package com.ossnms.dcn_manager.core.import_export.valueobjects;

import org.immutables.value.Value.Immutable;
import org.immutables.value.Value.Parameter;

import java.util.Optional;

@Immutable public interface ContainerValueObject {
    @Parameter String name();

    Optional<String> userText();

    Optional<String> description();

    Optional<String> parent();
}
