package com.ossnms.dcn_manager.core.import_export.identification;

import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableSystemValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.SystemValueObject;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Test;

import java.util.Optional;

import static java.util.Optional.empty;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class SystemContainerIdentificationTest {

    @Test public void shouldResolveSystemByName() throws Exception {
        SystemInfo storedSystem = new SystemInfo(12, 1, "Some system");
        SystemValueObject requestedSystem = ImmutableSystemValueObject.of("Some system");

        SystemRepository systemRepository = mock(SystemRepository.class);
        when(systemRepository.queryByName("Some system")).thenReturn(Optional.of(storedSystem));


        Optional<SystemInfo> identifiedSystem = new SystemContainerIdentification(systemRepository).tryIdentify(requestedSystem);


        assertThat(identifiedSystem, is(Optional.of(storedSystem)));
    }

    @Test public void shouldNotResolveSystemIfNoMatchByName() throws Exception {
        SystemValueObject requestedSystem = ImmutableSystemValueObject.of("Some system");

        SystemRepository systemRepository = mock(SystemRepository.class);
        when(systemRepository.queryByName(any())).thenReturn(Optional.empty());


        Optional<SystemInfo> identifiedSystem = new SystemContainerIdentification(systemRepository).tryIdentify(requestedSystem);


        assertThat(identifiedSystem, is(empty()));
    }

    @Test public void shouldNotResolveSystemExceptionalCase() throws Exception {
        SystemValueObject requestedSystem = ImmutableSystemValueObject.of("Some system");

        SystemRepository systemRepository = mock(SystemRepository.class);
        when(systemRepository.queryByName(any())).thenThrow(new RepositoryException());


        Optional<SystemInfo> identifiedSystem = new SystemContainerIdentification(systemRepository).tryIdentify(requestedSystem);


        assertThat(identifiedSystem, is(empty()));
    }
}
