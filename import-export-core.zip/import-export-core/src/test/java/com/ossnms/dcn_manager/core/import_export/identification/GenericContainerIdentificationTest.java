package com.ossnms.dcn_manager.core.import_export.identification;

import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ContainerValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableContainerValueObject;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Test;

import java.util.Optional;

import static java.util.Optional.empty;
import static java.util.Optional.of;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class GenericContainerIdentificationTest {
    @Test public void shouldResolveSystemByName() throws Exception {
        ContainerInfo stored = new ContainerInfo(12, 1, "Some container");
        ContainerValueObject requested = ImmutableContainerValueObject.of("Some container");

        ContainerRepository containerRepository = mock(ContainerRepository.class);
        when(containerRepository.queryByName("Some container")).thenReturn(of(stored));


        Optional<ContainerInfo> identified = new GenericContainerIdentification(containerRepository).tryIdentify(requested);


        assertThat(identified, is(of(stored)));
    }

    @Test public void shouldNotResolveSystemIfNoMatchByName() throws Exception {
        ContainerValueObject requested = ImmutableContainerValueObject.of("Some container");
        
        ContainerRepository containerRepository = mock(ContainerRepository.class);
        when(containerRepository.queryByName(any())).thenReturn(empty());


        Optional<ContainerInfo> identified = new GenericContainerIdentification(containerRepository).tryIdentify(requested);


        assertThat(identified, is(empty()));
    }

    @Test public void shouldNotResolveSystemInExceptionalCase() throws Exception {
        ContainerValueObject requested = ImmutableContainerValueObject.of("Some container");

        ContainerRepository containerRepository = mock(ContainerRepository.class);
        when(containerRepository.queryByName(any())).thenThrow(new RepositoryException());


        Optional<ContainerInfo> identified = new GenericContainerIdentification(containerRepository).tryIdentify(requested);


        assertThat(identified, is(empty()));
    }
}