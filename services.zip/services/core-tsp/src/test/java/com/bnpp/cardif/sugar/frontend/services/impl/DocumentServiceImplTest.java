package com.bnpp.cardif.sugar.frontend.services.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.BuisnessRulesService;
import com.bnpp.cardif.sugar.frontend.services.DocumentFilesService;
import com.bnpp.cardif.sugar.frontend.services.model.PagingList;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.SugarDocumentFile;

import uk.co.jemos.podam.api.DataProviderStrategy;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class DocumentServiceImplTest extends FrontendGenericServiceTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    @Mock
    private BuisnessRulesService buisnessRulesService;

    @Mock
    private DocumentFilesService documentFilesService;

    @Mock
    private SugarDocument service;

    @Mock
    SugarDocumentFile sugarDocumentFileService;

    @InjectMocks
    private DocumentServiceImpl documentServiceImpl = new DocumentServiceImpl();

    @Before
    public void setUp() throws Exception {
        super.setUp();
        DataProviderStrategy strategy = factory.getStrategy();
        strategy.setDefaultNumberOfCollectionElements(2);
    }

    @Test
    public void testGetDocumentByID()
            throws FuncFaultMessage, TechFaultMessage, TechnicalException, FunctionalException {

        // input variable
        String id = "123";

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        Document finalResult = documentServiceImpl.getDocumentByID(id);

        // Validation
        verify(service).get(any(GetRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        assertNotNull(finalResult.getData());
        // check response content
        assertEquals(result.getDocument().get(0).getData().getName(), finalResult.getData().getName());
    }

    @Test
    public void testGetDocumentWithChildByID()
            throws TechnicalException, FunctionalException, FuncFaultMessage, TechFaultMessage {

        // input variable
        String id = "123";

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        Document finalResult = documentServiceImpl.getDocumentWithChildByID(id);

        // Validation
        verify(service).get(any(GetRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        assertNotNull(finalResult.getData());
        // check response content
        assertEquals(result.getDocument().get(0).getData().getName(), finalResult.getData().getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetDocumentByIDs()
            throws FuncFaultMessage, TechFaultMessage, TechnicalException, FunctionalException {

        // input variable
        List<String> ids = factory.manufacturePojo(List.class, String.class);

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<Document> finalResult = documentServiceImpl.getDocumentByIDs(ids);

        // Validation
        verify(service).get(any(GetRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        assertEquals(result.getDocument().size(), finalResult.size());
        assertNotNull(finalResult.get(0).getData());
        // check response content
        assertEquals(result.getDocument().get(0).getData().getName(), finalResult.get(0).getData().getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFindDocuments() throws TechnicalException, FunctionalException, FuncFaultMessage, TechFaultMessage {

        // input variable
        long start = 0L;
        long maximum = 10L;
        String quickSearchValue = "test";
        List<Criterion> criterionList = factory.manufacturePojo(List.class, Criterion.class);
        OrderClause orderClause = factory.manufacturePojo(OrderClause.class);

        // Moçked response
        FindResponse result = factory.manufacturePojo(FindResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentWSP()).thenReturn(service);
        when(service.find(any(FindRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        PagingList<Document> finalResult = documentServiceImpl.findDocuments(start, maximum, quickSearchValue,
                criterionList, orderClause);

        // Validation
        verify(service).find(any(FindRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        assertNotNull(finalResult.getItemList());
        assertEquals(result.getDocument().size(), finalResult.getItemList().size());
        // check response content
        assertEquals(result.getDocument().get(0).getData().getName(),
                finalResult.getItemList().get(0).getData().getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFindEnvelopes() throws TechnicalException, FunctionalException, FuncFaultMessage, TechFaultMessage {

        // input variable
        long start = 0L;
        long maximum = 10L;
        String quickSearchValue = "test";
        List<Criterion> criterionList = factory.manufacturePojo(List.class, Criterion.class);
        OrderClause orderClause = factory.manufacturePojo(OrderClause.class);

        // Moçked response
        FindResponse result = factory.manufacturePojo(FindResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentWSP()).thenReturn(service);
        when(service.find(any(FindRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        PagingList<Document> finalResult = documentServiceImpl.findEnvelopes(start, maximum, quickSearchValue,
                criterionList, orderClause);

        // Validation
        verify(service).find(any(FindRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        assertNotNull(finalResult.getItemList());
        assertEquals(result.getDocument().size(), finalResult.getItemList().size());
        // check response content
        assertEquals(result.getDocument().get(0).getData().getName(),
                finalResult.getItemList().get(0).getData().getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testReindexDocument()
            throws FuncFaultMessage, TechFaultMessage, FunctionalException, TechnicalException {

        // input variable
        List<Document> inputDocumentlist = factory.manufacturePojo(List.class, Document.class);

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        ReindexResponse result2 = factory.manufacturePojo(ReindexResponse.class);

        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);
        when(service.reindex(any(ReindexRequest.class), any(TokenType.class))).thenReturn(result2);

        // Execute the method being tested
        List<Document> finalResult = documentServiceImpl.reindexDocument(inputDocumentlist);

        // Validation
        verify(service).get(any(GetRequest.class), any(TokenType.class));
        verify(service).reindex(any(ReindexRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        assertEquals(result2.getDocument().size(), finalResult.size());
        assertNotNull(finalResult.get(0).getData());
        // check response content
        assertEquals(result2.getDocument().get(0).getData().getName(), finalResult.get(0).getData().getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testCreateEnvelopeWithFile()
            throws TechnicalException, FunctionalException, FuncFaultMessage, TechFaultMessage {

        // input variable
        List<DocumentFile> inputDocFileList = factory.manufacturePojo(List.class, DocumentFile.class);
        Document defaultEnvelope = factory.manufacturePojo(Document.class);
        List<Document> defaultDocumentList = factory.manufacturePojo(List.class, Document.class);

        // Moçked response
        List<DocumentFile> result = factory.manufacturePojo(List.class, DocumentFile.class);
        StoreResponse result2 = factory.manufacturePojo(StoreResponse.class);

        // Mockito expectations
        when(documentFilesService.createDocumentFiles(inputDocFileList)).thenReturn(result);
        when(sugarWebServiceClientFactory.getSugarDocumentWSP()).thenReturn(service);
        when(service.store(any(StoreRequest.class), any(TokenType.class))).thenReturn(result2);

        // Execute the method being tested
        List<Document> finalResult = documentServiceImpl.createEnvelopeWithFile(inputDocFileList, defaultEnvelope,
                defaultDocumentList);

        // Validation
        verify(documentFilesService).createDocumentFiles(inputDocFileList);
        verify(service).store(any(StoreRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        assertEquals(result2.getDocument().size(), finalResult.size());
        assertNotNull(finalResult.get(0).getData());
        // check response content
        assertEquals(result2.getDocument().get(0).getData().getName(), finalResult.get(0).getData().getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testAddFileToEnvelope()
            throws TechnicalException, FunctionalException, FuncFaultMessage, TechFaultMessage {

        // input variable
        List<DocumentFile> inputDocFileList = factory.manufacturePojo(List.class, DocumentFile.class);
        String envelopeId = "123";
        List<Document> defaultDocumentList = factory.manufacturePojo(List.class, Document.class);

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        result.getDocument().get(0).setCategory(Category.ENVELOPE);
        List<DocumentFile> result2 = factory.manufacturePojo(List.class, DocumentFile.class);
        ReindexResponse result3 = factory.manufacturePojo(ReindexResponse.class);

        final AddChildResponse response = new AddChildResponse();
        response.getDocument().addAll(defaultDocumentList);

        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);
        when(documentFilesService.createDocumentFiles(inputDocFileList)).thenReturn(result2);
        when(service.addChild(any(AddChildRequest.class), any(TokenType.class))).thenReturn(response);

        // Execute the method being tested
        List<Document> finalResult = documentServiceImpl.addFileToEnvelope(inputDocFileList, envelopeId,
                defaultDocumentList);

        // Validation
        verify(documentFilesService).createDocumentFiles(inputDocFileList);
        verify(service).get(any(GetRequest.class), any(TokenType.class));
        verify(service).addChild(any(AddChildRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        assertEquals(result3.getDocument().size(), finalResult.size());
        assertNotNull(finalResult.get(0).getData());
        // check response content
        assertEquals(response.getDocument().get(0).getData().getName(), finalResult.get(0).getData().getName());
    }

    @Test
    public void testGetDocumentsFromEnvelope()
            throws FunctionalException, TechnicalException, FuncFaultMessage, TechFaultMessage {

        // input variable
        String envelopeId = "123";

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        result.getDocument().get(0).setCategory(Category.ENVELOPE);

        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<Document> finalResult = documentServiceImpl.getDocumentsFromEnvelope(envelopeId);

        // Validation
        verify(service).get(any(GetRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        assertEquals(result.getDocument().get(0).getChildObject().getDocument().size(), finalResult.size());
        assertNotNull(finalResult.get(0).getData());
        // check response content
        assertEquals(result.getDocument().get(0).getChildObject().getDocument().get(0).getData().getName(),
                finalResult.get(0).getData().getName());
    }

    @Test
    public void testDeleteEnvelope()
            throws FunctionalException, TechnicalException, FuncFaultMessage, TechFaultMessage {

        // input variable
        String envelopeId = "123";

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        result.getDocument().get(0).setCategory(Category.ENVELOPE);

        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        documentServiceImpl.deleteEnvelope(envelopeId);

        // Validation
        verify(service).get(any(GetRequest.class), any(TokenType.class));
        verify(service).delete(any(DeleteRequest.class), any(TokenType.class));
        // check a response exist

    }

    @Test
    public void testDeleteDocument()
            throws FunctionalException, TechnicalException, FuncFaultMessage, TechFaultMessage {

        // input variable
        String documentId = "123";

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        result.getDocument().get(0).setCategory(Category.DOCUMENT);

        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        documentServiceImpl.deleteDocument(documentId);

        // Validation
        verify(service).get(any(GetRequest.class), any(TokenType.class));
        verify(service).delete(any(DeleteRequest.class), any(TokenType.class));
        // check a response exist

    }

}
