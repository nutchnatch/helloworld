/**
 * 
 */
package com.bnpp.cardif.sugar.frontend.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import com.bnpp.cardif.sugar.security.AuthenticatedUser;

/**
 * @author 831743
 *
 */
public class FrontendGenericServiceTest {

    protected String userName = "fake user";

    protected String password = "fake password";

    protected String fakeToken = "fake token";

    protected String firstName = "fake";

    protected String lastName = "user";
    
    protected String commercialVersion = "1.1.0.0";

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {

        // Expected objects
        AuthenticatedUser principal = createFakeUser(userName, password, fakeToken, firstName, lastName);
        String credentials = password;
        Authentication authentication = new UsernamePasswordAuthenticationToken(principal, credentials);

        // Mockito expectations
        SecurityContext securityContext = Mockito.mock(SecurityContext.class);
        Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void test() {
        // nothing it is just a super class for all controllers tests
    }

    private AuthenticatedUser createFakeUser(String userName, String password, String token, String firstName,
            String lastName) {
        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        grantedAuthorities.add(new SimpleGrantedAuthority("Role1"));
        grantedAuthorities.add(new SimpleGrantedAuthority("Role2"));
        AuthenticatedUser principal = new AuthenticatedUser(userName, password, token, firstName, lastName,
                grantedAuthorities, commercialVersion);
        List<String> businessScopes = new ArrayList<>();
        businessScopes.add("Syldavia");
        principal.setBusinessScopes(businessScopes);
        principal.setCommercialVersion(commercialVersion);
        principal.setCurrentBusinessScope("Syldavia");
        principal.setRequestId("reqid");
        principal.setTimeToSpentOnAuthentication(300);
        return principal;
    }

}
