package com.bnpp.cardif.sugar.frontend.services.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.DocumentFilesService;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.GetBySymbolicNameRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.GetBySymbolicNameResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.SugarBusinessScope;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.businessscope.v1.UpdateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class BusinessScopeServiceImplTest extends FrontendGenericServiceTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    @Mock
    private DocumentFilesService documentFilesService;

    @Mock
    private SugarBusinessScope service;

    @InjectMocks
    private BusinessScopeServiceImpl businessScopeServiceImpl;

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testGetBusinessScope()
            throws TechFaultMessage, FuncFaultMessage, TechnicalException, FunctionalException {

        // input variable

        // Moçked response
        GetBySymbolicNameResponse result = factory.manufacturePojo(GetBySymbolicNameResponse.class);
        result.getBusinessScope().get(0).getFileData().setURI("testUri");
        DocumentFile result2 = factory.manufacturePojo(DocumentFile.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarBusinessScopeWSP()).thenReturn(service);
        when(service.getBySymbolicName(any(GetBySymbolicNameRequest.class), any(TokenType.class))).thenReturn(result);
        when(documentFilesService.getDocumentFilesByID(any(String.class))).thenReturn(result2);

        // Execute the method being tested
        BusinessScope finalResult = businessScopeServiceImpl.getBusinessScope();

        // Validation
        verify(service).getBySymbolicName(any(GetBySymbolicNameRequest.class), any(TokenType.class));
        verify(documentFilesService).getDocumentFilesByID(any(String.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getBusinessScope().get(0).getSymbolicName(), finalResult.getSymbolicName());
    }

    @Test
    public void testUpdateBusinessScope()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        BusinessScope inputBS = factory.manufacturePojo(BusinessScope.class);

        // Moçked response
        UpdateResponse result = factory.manufacturePojo(UpdateResponse.class);
        result.getBusinessScope().get(0).getFileData().setURI("testUri");
        DocumentFile result2 = factory.manufacturePojo(DocumentFile.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarBusinessScopeWSP()).thenReturn(service);
        when(service.update(any(UpdateRequest.class), any(TokenType.class))).thenReturn(result);
        when(documentFilesService.getDocumentFilesByID(any(String.class))).thenReturn(result2);

        // Execute the method being tested
        BusinessScope finalResult = businessScopeServiceImpl.updateBusinessScope(inputBS);

        // Validation
        verify(service).update(any(UpdateRequest.class), any(TokenType.class));
        verify(documentFilesService).getDocumentFilesByID(any(String.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getBusinessScope().get(0).getSymbolicName(), finalResult.getSymbolicName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testUpdateRuleFile()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        DocumentFile inputDocFile = factory.manufacturePojo(DocumentFile.class);

        // Moçked response
        GetBySymbolicNameResponse result0 = factory.manufacturePojo(GetBySymbolicNameResponse.class);
        result0.getBusinessScope().get(0).getFileData().setURI("testUri");
        List<DocumentFile> result = factory.manufacturePojo(List.class, DocumentFile.class);
        UpdateResponse result2 = factory.manufacturePojo(UpdateResponse.class);
        result2.getBusinessScope().get(0).getFileData().setURI("testUri");
        DocumentFile result3 = factory.manufacturePojo(DocumentFile.class);
        // Mockito expectations
        when(service.getBySymbolicName(any(GetBySymbolicNameRequest.class), any(TokenType.class))).thenReturn(result0);
        when(documentFilesService.createDocumentFiles(any(List.class))).thenReturn(result);
        when(sugarWebServiceClientFactory.getSugarBusinessScopeWSP()).thenReturn(service);
        when(service.update(any(UpdateRequest.class), any(TokenType.class))).thenReturn(result2);
        when(documentFilesService.getDocumentFilesByID(any(String.class))).thenReturn(result3);

        // Execute the method being tested
        BusinessScope finalResult = businessScopeServiceImpl.updateRuleFile(inputDocFile);

        // Validation
        verify(documentFilesService).createDocumentFiles(any(List.class));
        verify(service).update(any(UpdateRequest.class), any(TokenType.class));
        verify(documentFilesService, times(2)).getDocumentFilesByID(any(String.class));
        verify(documentFilesService).deleteDocumentFilesByID(any(String.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result2.getBusinessScope().get(0).getSymbolicName(), finalResult.getSymbolicName());
    }

}
