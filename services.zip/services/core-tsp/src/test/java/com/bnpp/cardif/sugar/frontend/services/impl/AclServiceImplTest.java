package com.bnpp.cardif.sugar.frontend.services.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class AclServiceImplTest extends FrontendGenericServiceTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    @Mock
    private SugarAcl service;

    @InjectMocks
    private AclServiceImpl aclServiceImpl = new AclServiceImpl();

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testGetAllAclList() throws FuncFaultMessage, TechFaultMessage, TechnicalException, FunctionalException {

        // input variable

        // Moçked response
        GetAllResponse result = factory.manufacturePojo(GetAllResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarAclWSP()).thenReturn(service);
        when(service.getAll(any(GetAllRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<AccessControlList> finalResult = aclServiceImpl.getAllAclList();

        // Validation
        verify(service).getAll(any(GetAllRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getAccessControlList().size(), finalResult.size());
        assertEquals(result.getAccessControlList().get(0).getName(), finalResult.get(0).getName());
    }

    @Test
    public void testGetAclListByClassId()
            throws FuncFaultMessage, TechFaultMessage, TechnicalException, FunctionalException {

        // input variable
        String id = "123";
        int version = 1;
        boolean isInstanceValue = true;

        // Moçked response
        GetByClassIdResponse result = new GetByClassIdResponse();
        AccessControlList content = factory.manufacturePojo(AccessControlList.class);
        result.getAccessControlList().add(content);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarAclWSP()).thenReturn(service);
        when(service.getByClassId(any(GetByClassIdRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        AccessControlList finalResult = aclServiceImpl.getAclListByClassId(id, version, isInstanceValue);

        // Validation
        verify(service).getByClassId(any(GetByClassIdRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getAccessControlList().get(0).getName(), finalResult.getName());
    }

    @Test
    public void testGetAclListByBasketId()
            throws TechnicalException, FunctionalException, FuncFaultMessage, TechFaultMessage {

        // input variable
        String id = "123";

        // Moçked response
        GetByBasketIdResponse result = new GetByBasketIdResponse();
        AccessControlList content = factory.manufacturePojo(AccessControlList.class);
        result.getAccessControlList().add(content);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarAclWSP()).thenReturn(service);
        when(service.getByBasketId(any(GetByBasketIdRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        AccessControlList finalResult = aclServiceImpl.getAclListByBasketId(id);

        // Validation
        verify(service).getByBasketId(any(GetByBasketIdRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getAccessControlList().get(0).getName(), finalResult.getName());
    }

    @Test
    public void testGetDefaultAclByBuisnessScope()
            throws FuncFaultMessage, TechFaultMessage, TechnicalException, FunctionalException {

        // input variable

        // Moçked response
        GetDefaultResponse result = factory.manufacturePojo(GetDefaultResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarAclWSP()).thenReturn(service);
        when(service.getDefault(any(GetDefaultRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        AccessControlList finalResult = aclServiceImpl.getDefaultAclByBuisnessScope();

        // Validation
        verify(service).getDefault(any(GetDefaultRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getAccessControlList().getName(), finalResult.getName());
    }

    @Test
    public void testAssignAclToClassId()
            throws TechnicalException, FunctionalException, FuncFaultMessage, TechFaultMessage {

        // input variable
        String inputAclId = "123";
        String inputClassId = "456";
        int inputClassVersion = 1;
        boolean isInstanceValue = true;

        // Moçked response
        AssignToClassResponse result = factory.manufacturePojo(AssignToClassResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarAclWSP()).thenReturn(service);
        when(service.assignToClass(any(AssignToClassRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        AccessControlList finalResult = aclServiceImpl.assignAclToClassId(inputAclId, inputClassId, inputClassVersion,
                isInstanceValue);

        // Validation
        verify(service).assignToClass(any(AssignToClassRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getAccessControlList().getName(), finalResult.getName());
    }

    @Test
    public void testAssignAclToBasketId()
            throws TechnicalException, FunctionalException, FuncFaultMessage, TechFaultMessage {

        // input variable
        String inputAclId = "123";
        String inputBasketId = "456";

        // Moçked response
        AssignToBasketResponse result = factory.manufacturePojo(AssignToBasketResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarAclWSP()).thenReturn(service);
        when(service.assignToBasket(any(AssignToBasketRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        AccessControlList finalResult = aclServiceImpl.assignAclToBasketId(inputAclId, inputBasketId);

        // Validation
        verify(service).assignToBasket(any(AssignToBasketRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getAccessControlList().getName(), finalResult.getName());
    }

    @Test
    public void testAssignBusinessScopeAcl()
            throws TechFaultMessage, FuncFaultMessage, TechnicalException, FunctionalException {

        ChangeDefaultAclResponse response = factory.manufacturePojo(ChangeDefaultAclResponse.class);
        when(sugarWebServiceClientFactory.getSugarAclWSP()).thenReturn(service);
        when(service.changeDefaultAcl(any(ChangeDefaultAclRequest.class), any(TokenType.class))).thenReturn(response);

        AccessControlList signedAcl = aclServiceImpl.assignBusinessScopeACL("thisScope", "1212-4343-1212");

        verify(service).changeDefaultAcl(any(ChangeDefaultAclRequest.class), any(TokenType.class));
        assertNotNull(signedAcl);
        assertEquals(response.getAccessControlList().getName(), signedAcl.getName());
    }
}
