package com.bnpp.cardif.sugar.frontend.services.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.TagsService;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.CreateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.GetAllRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.GetAllResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.SetActiveRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.SetActiveResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.SugarFolderClass;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.UpdateResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class FolderTypeServiceImplTest extends FrontendGenericServiceTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    @Mock
    private TagsService tagsService;

    @Mock
    private SugarFolderClass service;

    @InjectMocks
    private FolderTypeServiceImpl folderTypeServiceImpl;

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testGetFolderTypeByID()
            throws TechFaultMessage, FuncFaultMessage, TechnicalException, FunctionalException {

        // input variable
        String id = "123";
        int version = 1;

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarFolderClassWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        FolderClass finalResult = folderTypeServiceImpl.getFolderTypeByID(id, version);

        // Validation
        verify(service).get(any(GetRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getFolderClass().get(0).getLongLabel(), finalResult.getLongLabel());
    }

    @Test
    public void testGetAllFolderType()
            throws TechFaultMessage, FuncFaultMessage, TechnicalException, FunctionalException {

        // input variable

        // Moçked response
        GetAllResponse result = factory.manufacturePojo(GetAllResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarFolderClassWSP()).thenReturn(service);
        when(service.getAll(any(GetAllRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<FolderClass> finalResult = folderTypeServiceImpl.getAllFolderType();

        // Validation
        verify(service).getAll(any(GetAllRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        assertNotNull(finalResult.get(0));
        // check response content
        assertEquals(result.getFolderClass().get(0).getLongLabel(), finalResult.get(0).getLongLabel());
    }

    @Test
    public void testGetAllFolderTypeWithInactive()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable

        // Moçked response
        GetAllResponse result = factory.manufacturePojo(GetAllResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarFolderClassWSP()).thenReturn(service);
        when(service.getAll(any(GetAllRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<FolderClass> finalResult = folderTypeServiceImpl.getAllFolderTypeWithInactive();

        // Validation
        verify(service).getAll(any(GetAllRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        assertNotNull(finalResult.get(0));
        // check response content
        assertEquals(result.getFolderClass().get(0).getLongLabel(), finalResult.get(0).getLongLabel());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetFolderTypeTags()
            throws TechFaultMessage, FuncFaultMessage, TechnicalException, FunctionalException {

        // input variable
        String id = "123";
        int version = 1;

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        List<TagClass> result2 = factory.manufacturePojo(List.class, TagClass.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarFolderClassWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);
        when(tagsService.getTagListBySymbolicName(any(List.class))).thenReturn(result2);

        // Execute the method being tested
        List<TagClass> finalResult = folderTypeServiceImpl.getFolderTypeTags(id, version);

        // Validation
        verify(service).get(any(GetRequest.class), any(TokenType.class));
        verify(tagsService).getTagListBySymbolicName(any(List.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result2.size(), finalResult.size());
        assertEquals(result2.get(0), finalResult.get(0));
    }

    @Test
    public void testCreateFolderType()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        FolderClass input = factory.manufacturePojo(FolderClass.class);

        // Moçked response
        CreateResponse result = factory.manufacturePojo(CreateResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarFolderClassWSP()).thenReturn(service);
        when(service.create(any(CreateRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        FolderClass finalResult = folderTypeServiceImpl.createFolderType(input);

        // Validation
        verify(service).create(any(CreateRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getFolderClass().get(0).getLongLabel(), finalResult.getLongLabel());
    }

    @Test
    public void testUpdateFolderType()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        FolderClass input = factory.manufacturePojo(FolderClass.class);

        // Moçked response
        UpdateResponse result = factory.manufacturePojo(UpdateResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarFolderClassWSP()).thenReturn(service);
        when(service.update(any(UpdateRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        FolderClass finalResult = folderTypeServiceImpl.updateFolderType(input);

        // Validation
        verify(service).update(any(UpdateRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getFolderClass().get(0).getLongLabel(), finalResult.getLongLabel());
    }

    @Test
    public void testActivateFolderType()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        String id = "123";
        int version = 1;

        // Moçked response
        SetActiveResponse result = factory.manufacturePojo(SetActiveResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarFolderClassWSP()).thenReturn(service);
        when(service.setActive(any(SetActiveRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        folderTypeServiceImpl.activateFolderType(id, version);

        // Validation
        verify(service).setActive(any(SetActiveRequest.class), any(TokenType.class));
        // check a response exist

        // check response content
    }

    @Test
    public void testDeactivateFolderType()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        String id = "123";
        int version = 1;

        // Moçked response
        SetActiveResponse result = factory.manufacturePojo(SetActiveResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarFolderClassWSP()).thenReturn(service);
        when(service.setActive(any(SetActiveRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        folderTypeServiceImpl.deactivateFolderType(id, version);

        // Validation
        verify(service).setActive(any(SetActiveRequest.class), any(TokenType.class));
        // check a response exist

        // check response content
    }

}
