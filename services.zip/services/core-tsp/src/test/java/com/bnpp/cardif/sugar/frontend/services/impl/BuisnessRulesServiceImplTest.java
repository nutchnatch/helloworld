package com.bnpp.cardif.sugar.frontend.services.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.DocumentTypeService;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

import uk.co.jemos.podam.api.DataProviderStrategy;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class BuisnessRulesServiceImplTest extends FrontendGenericServiceTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private DocumentTypeService documentTypeService;

    @InjectMocks
    private BuisnessRulesServiceImpl buisnessRulesServiceImpl = new BuisnessRulesServiceImpl();

    @Before
    public void setUp() throws Exception {
        super.setUp();
        DataProviderStrategy strategy = factory.getStrategy();
        strategy.setDefaultNumberOfCollectionElements(2);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testComputeValidityCode() throws TechnicalException, FunctionalException {

        // input variable
        Document testedDocument = factory.manufacturePojo(Document.class);
        testedDocument.getData().setValidityCode(ValdtyCode.INVALID);

        // Moçked response
        List<DocumentClass> result = factory.manufacturePojo(List.class, DocumentClass.class);
        // Mockito expectations
        when(documentTypeService.getAllDocumentType(any(Category.class), eq(true))).thenReturn(result);

        // Execute the method being tested
        ValdtyCode finalResult = buisnessRulesServiceImpl.computeValidityCode(testedDocument);

        // Validation
        verify(documentTypeService).getAllDocumentType(any(Category.class), eq(true));
        // check a response exist
        assertNotNull(finalResult);
        // check response content

    }

}
