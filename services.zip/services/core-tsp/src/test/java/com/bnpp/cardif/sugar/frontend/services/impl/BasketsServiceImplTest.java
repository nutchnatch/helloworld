package com.bnpp.cardif.sugar.frontend.services.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.CreateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.DeleteRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.DeleteResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.GetAllRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.GetAllResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.SugarBasket;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.basket.v1.UpdateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class BasketsServiceImplTest extends FrontendGenericServiceTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    @Mock
    private SugarBasket service;

    @InjectMocks
    private BasketsServiceImpl basketsServiceImpl = new BasketsServiceImpl();

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testGetAllBasketList()
            throws TechnicalException, FunctionalException, FuncFaultMessage, TechFaultMessage {

        // input variable

        // Moçked response
        GetAllResponse result = factory.manufacturePojo(GetAllResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarBasketWSP()).thenReturn(service);
        when(service.getAll(any(GetAllRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<Basket> finalResult = basketsServiceImpl.getAllBasketList();

        // Validation
        verify(service).getAll(any(GetAllRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getBasket().size(), finalResult.size());
        assertEquals(result.getBasket().get(0).getSymbolicName(), finalResult.get(0).getSymbolicName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetBasketListByIds()
            throws TechnicalException, FunctionalException, FuncFaultMessage, TechFaultMessage {

        // input variable
        List<String> idList = factory.manufacturePojo(List.class, String.class);

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarBasketWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<Basket> finalResult = basketsServiceImpl.getBasketListByIds(idList);

        // Validation
        verify(service).get(any(GetRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getBasket().size(), finalResult.size());
        assertEquals(result.getBasket().get(0).getSymbolicName(), finalResult.get(0).getSymbolicName());
    }

    @Test
    public void testGetBasketByID() throws FuncFaultMessage, TechFaultMessage, TechnicalException, FunctionalException {

        // input variable
        String id = "123";

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarBasketWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        Basket finalResult = basketsServiceImpl.getBasketByID(id);

        // Validation
        verify(service).get(any(GetRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getBasket().get(0).getSymbolicName(), finalResult.getSymbolicName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testCreateBaskets() throws FuncFaultMessage, TechFaultMessage, FunctionalException, TechnicalException {

        // input variable
        List<Basket> basketList = factory.manufacturePojo(List.class, Basket.class);

        // Moçked response
        CreateResponse result = factory.manufacturePojo(CreateResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarBasketWSP()).thenReturn(service);
        when(service.create(any(CreateRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<Basket> finalResult = basketsServiceImpl.createBaskets(basketList);

        // Validation
        verify(service).create(any(CreateRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getBasket().size(), finalResult.size());
        assertEquals(result.getBasket().get(0).getSymbolicName(), finalResult.get(0).getSymbolicName());
    }

    @Test
    public void testCreateBasket() throws TechnicalException, FunctionalException, FuncFaultMessage, TechFaultMessage {

        // input variable
        Basket inputBasket = factory.manufacturePojo(Basket.class);

        // Moçked response
        CreateResponse result = factory.manufacturePojo(CreateResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarBasketWSP()).thenReturn(service);
        when(service.create(any(CreateRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        Basket finalResult = basketsServiceImpl.createBasket(inputBasket);

        // Validation
        verify(service).create(any(CreateRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getBasket().get(0).getSymbolicName(), finalResult.getSymbolicName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testUpdateBaskets() throws FuncFaultMessage, TechFaultMessage, FunctionalException, TechnicalException {

        // input variable
        List<Basket> basketList = factory.manufacturePojo(List.class, Basket.class);

        // Moçked response
        UpdateResponse result = factory.manufacturePojo(UpdateResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarBasketWSP()).thenReturn(service);
        when(service.update(any(UpdateRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<Basket> finalResult = basketsServiceImpl.updateBaskets(basketList);

        // Validation
        verify(service).update(any(UpdateRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        assertEquals(result.getBasket().size(), finalResult.size());
        // check response content
        assertEquals(result.getBasket().get(0).getSymbolicName(), finalResult.get(0).getSymbolicName());
    }

    @Test
    public void testUpdateBasket() throws TechnicalException, FunctionalException, FuncFaultMessage, TechFaultMessage {

        // input variable
        Basket inputBasket = factory.manufacturePojo(Basket.class);

        // Moçked response
        UpdateResponse result = factory.manufacturePojo(UpdateResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarBasketWSP()).thenReturn(service);
        when(service.update(any(UpdateRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        Basket finalResult = basketsServiceImpl.updateBasket(inputBasket);

        // Validation
        verify(service).update(any(UpdateRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getBasket().get(0).getSymbolicName(), finalResult.getSymbolicName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testDeleteBaskets() throws FuncFaultMessage, TechFaultMessage, FunctionalException, TechnicalException {

        // input variable
        List<String> idList = factory.manufacturePojo(List.class, String.class);

        // Moçked response
        DeleteResponse result = factory.manufacturePojo(DeleteResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarBasketWSP()).thenReturn(service);
        when(service.delete(any(DeleteRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        basketsServiceImpl.deleteBaskets(idList);

        // Validation
        verify(service).delete(any(DeleteRequest.class), any(TokenType.class));
        // check a response exist

        // check response content

    }

    @Test
    public void testDeleteBasket() throws TechnicalException, FunctionalException, FuncFaultMessage, TechFaultMessage {

        // input variable
        String id = "123";

        // Moçked response
        DeleteResponse result = factory.manufacturePojo(DeleteResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarBasketWSP()).thenReturn(service);
        when(service.delete(any(DeleteRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        basketsServiceImpl.deleteBasket(id);

        // Validation
        verify(service).delete(any(DeleteRequest.class), any(TokenType.class));
        // check a response exist

        // check response content

    }

}
