package com.bnpp.cardif.sugar.frontend.services.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.CreateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetAllRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetAllResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetBySymbolicNameRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetBySymbolicNameResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.SugarTagClass;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.UpdateResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class TagsServiceImplTest extends FrontendGenericServiceTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    @Mock
    private SugarTagClass service;

    @InjectMocks
    private TagsServiceImpl tagsServiceImpl;

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testGetAllTagList() throws TechFaultMessage, FuncFaultMessage, TechnicalException, FunctionalException {

        // input variable

        // Moçked response
        GetAllResponse result = factory.manufacturePojo(GetAllResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarTagClassWSP()).thenReturn(service);
        when(service.getAll(any(GetAllRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<TagClass> finalResult = tagsServiceImpl.getAllTagList();

        // Validation
        verify(service).getAll(any(GetAllRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getTagClass().size(), finalResult.size());
        assertEquals(result.getTagClass().get(0).getSymbolicName(), finalResult.get(0).getSymbolicName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetTagListBySymbolicName()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        List<String> symbolicNames = factory.manufacturePojo(List.class, String.class);

        // Moçked response
        GetBySymbolicNameResponse result = factory.manufacturePojo(GetBySymbolicNameResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarTagClassWSP()).thenReturn(service);
        when(service.getBySymbolicName(any(GetBySymbolicNameRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<TagClass> finalResult = tagsServiceImpl.getTagListBySymbolicName(symbolicNames);

        // Validation
        verify(service).getBySymbolicName(any(GetBySymbolicNameRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getTagClass().size(), finalResult.size());
        assertEquals(result.getTagClass().get(0).getSymbolicName(), finalResult.get(0).getSymbolicName());
    }

    @Test
    public void testCreateTag() throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        TagClass inputTagClass = factory.manufacturePojo(TagClass.class);

        // Moçked response
        CreateResponse result = factory.manufacturePojo(CreateResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarTagClassWSP()).thenReturn(service);
        when(service.create(any(CreateRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        TagClass finalResult = tagsServiceImpl.createTag(inputTagClass);

        // Validation
        verify(service).create(any(CreateRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getTagClass().get(0).getSymbolicName(), finalResult.getSymbolicName());
    }

    @Test
    public void testUpdateTag() throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        TagClass inputTagClass = factory.manufacturePojo(TagClass.class);

        // Moçked response
        UpdateResponse result = factory.manufacturePojo(UpdateResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarTagClassWSP()).thenReturn(service);
        when(service.update(any(UpdateRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        TagClass finalResult = tagsServiceImpl.updateTag(inputTagClass);

        // Validation
        verify(service).update(any(UpdateRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getTagClass().get(0).getSymbolicName(), finalResult.getSymbolicName());
    }

}
