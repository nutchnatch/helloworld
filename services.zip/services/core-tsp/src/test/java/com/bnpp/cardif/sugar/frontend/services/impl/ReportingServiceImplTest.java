package com.bnpp.cardif.sugar.frontend.services.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.File;
import java.time.LocalDateTime;
import java.util.List;

import com.bnpparibas.assurance.sugar.internal.service.app.track.v1.SearchRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.track.v1.SearchResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.track.v1.SugarTrack;
import com.bnpparibas.assurance.sugar.internal.service.app.track.v1.Track;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.BasketRatio;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.DocumentStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.EnvelopeFlows;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.FolderStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.Summary;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetBasketRatioRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetBasketRatioResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetDocumentStockIndicatorRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetDocumentStockIndicatorResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetEnvelopeFlowsRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetEnvelopeFlowsResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetFolderStockIndicatorRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetFolderStockIndicatorResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetReportingSummaryRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetReportingSummaryResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.SugarReporting;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ReportingServiceImplTest extends FrontendGenericServiceTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    @Mock
    private SugarReporting service;

    @Mock
    private SugarTrack trackService;

    @InjectMocks
    private ReportingServiceImpl reportingServiceImpl;

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testGetBasketRatioIndicators()
            throws TechFaultMessage, FuncFaultMessage, TechnicalException, FunctionalException {

        // input variable
        String startingDate = "2000-10-31";
        String endingDate = "2001-10-31";

        // Moçked response
        GetBasketRatioResponse result = factory.manufacturePojo(GetBasketRatioResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarReportingWSP()).thenReturn(service);
        when(service.getBasketRatioIndicators(any(GetBasketRatioRequest.class), any(TokenType.class)))
                .thenReturn(result);

        // Execute the method being tested
        List<BasketRatio> finalResult = reportingServiceImpl.getBasketRatioIndicators(startingDate, endingDate);

        // Validation
        verify(service).getBasketRatioIndicators(any(GetBasketRatioRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getBasketRatio().size(), finalResult.size());
        assertEquals(result.getBasketRatio().get(0).getNumberOfOpened(), finalResult.get(0).getNumberOfOpened());
    }

    @Test
    public void testGetDocumentStockIndicators()
            throws TechFaultMessage, FuncFaultMessage, TechnicalException, FunctionalException {

        // input variable
        String startingDate = "2000-10-31";
        String endingDate = "2001-10-31";

        // Moçked response
        GetDocumentStockIndicatorResponse result = factory.manufacturePojo(GetDocumentStockIndicatorResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarReportingWSP()).thenReturn(service);
        when(service.getDocumentStockIndicators(any(GetDocumentStockIndicatorRequest.class), any(TokenType.class)))
                .thenReturn(result);

        // Execute the method being tested
        List<DocumentStock> finalResult = reportingServiceImpl.getDocumentStockIndicators(startingDate, endingDate);

        // Validation
        verify(service).getDocumentStockIndicators(any(GetDocumentStockIndicatorRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getDocumentStock().size(), finalResult.size());
        assertEquals(result.getDocumentStock().get(0).getNumberOfDocuments(),
                finalResult.get(0).getNumberOfDocuments());
    }

    @Test
    public void testGetEnvelopeFlowsIndicators()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        String startingDate = "2000-10-31";
        String endingDate = "2001-10-31";

        // Moçked response
        GetEnvelopeFlowsResponse result = factory.manufacturePojo(GetEnvelopeFlowsResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarReportingWSP()).thenReturn(service);
        when(service.getEnvelopeFlowsIndicators(any(GetEnvelopeFlowsRequest.class), any(TokenType.class)))
                .thenReturn(result);

        // Execute the method being tested
        List<EnvelopeFlows> finalResult = reportingServiceImpl.getEnvelopeFlowsIndicators(startingDate, endingDate);

        // Validation
        verify(service).getEnvelopeFlowsIndicators(any(GetEnvelopeFlowsRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getEnvelopeFlows().size(), finalResult.size());
        assertEquals(result.getEnvelopeFlows().get(0).getNumberOfDocuments(),
                finalResult.get(0).getNumberOfDocuments());
    }

    @Test
    public void testGetFolderStockIndicators()
            throws TechFaultMessage, FuncFaultMessage, TechnicalException, FunctionalException {

        // input variable
        String startingDate = "2000-10-31";
        String endingDate = "2001-10-31";

        // Moçked response
        GetFolderStockIndicatorResponse result = factory.manufacturePojo(GetFolderStockIndicatorResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarReportingWSP()).thenReturn(service);
        when(service.getFolderStockIndicators(any(GetFolderStockIndicatorRequest.class), any(TokenType.class)))
                .thenReturn(result);

        // Execute the method being tested
        List<FolderStock> finalResult = reportingServiceImpl.getFolderStockIndicators(startingDate, endingDate);

        // Validation
        verify(service).getFolderStockIndicators(any(GetFolderStockIndicatorRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getFolderStock().size(), finalResult.size());
        assertEquals(result.getFolderStock().get(0).getNumberOfFolders(), finalResult.get(0).getNumberOfFolders());
    }

    @Test
    public void testGetReportingSummary()
            throws TechFaultMessage, FuncFaultMessage, TechnicalException, FunctionalException {

        // input variable

        // Moçked response
        GetReportingSummaryResponse result = factory.manufacturePojo(GetReportingSummaryResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarReportingWSP()).thenReturn(service);
        when(service.getReportingSummary(any(GetReportingSummaryRequest.class), any(TokenType.class)))
                .thenReturn(result);

        // Execute the method being tested
        Summary finalResult = reportingServiceImpl.getReportingSummary();

        // Validation
        verify(service).getReportingSummary(any(GetReportingSummaryRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getSummary().getNumbereOfEnvelopes(), finalResult.getNumbereOfEnvelopes());
    }



    @Test
    public void testGetTraceLogEntries()
            throws TechFaultMessage, FuncFaultMessage, TechnicalException, FunctionalException {

        // input variable

        // Moçked response
        final SearchResponse result = factory.manufacturePojo(SearchResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarTrackWSP()).thenReturn(trackService);
        when(trackService.search(any(SearchRequest.class), any(TokenType.class)))
                .thenReturn(result);

        final LocalDateTime startDateTime = LocalDateTime.now();
        final LocalDateTime endDateTime = LocalDateTime.now();
        final String objectId = "objectId";
        final String userId = "userId";

        // Execute the method being tested
        String finalResult = reportingServiceImpl.getTraceLogFile(startDateTime, endDateTime, objectId, userId);

        // Validation
        verify(trackService).search(any(SearchRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        //assertEquals(result.getTrackReport(), finalResult);
    }

}
