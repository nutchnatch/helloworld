package com.bnpp.cardif.sugar.frontend.services.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.TagsService;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.AddRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.AddResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SearchRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SearchResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SetActiveRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SetActiveResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SugarDocumentClass;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.UpdateResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class DocumentTypeServiceImplTest extends FrontendGenericServiceTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    @Mock
    private TagsService tagsService;

    @Mock
    private SugarDocumentClass service;

    @InjectMocks
    private DocumentTypeServiceImpl documentTypeServiceImpl;

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testGetDocumentTypeByID()
            throws TechFaultMessage, FuncFaultMessage, TechnicalException, FunctionalException {

        // input variable
        String id = "123";
        int version = 1;

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentClassWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        DocumentClass finalResult = documentTypeServiceImpl.getDocumentTypeByID(id, version);

        // Validation
        verify(service).get(any(GetRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getDocumentClass().get(0).getLongLabel(), finalResult.getLongLabel());
    }

    @Test
    public void testGetAllDocumentType()
            throws TechFaultMessage, FuncFaultMessage, TechnicalException, FunctionalException {

        // input variable

        // Moçked response
        SearchResponse result = factory.manufacturePojo(SearchResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentClassWSP()).thenReturn(service);
        when(service.search(any(SearchRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<DocumentClass> finalResult = documentTypeServiceImpl.getAllDocumentType();

        // Validation
        verify(service).search(any(SearchRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        assertNotNull(finalResult.get(0));
        // check response content
        assertEquals(result.getDocumentClasses().getDocumentClass().get(0).getLongLabel(),
                finalResult.get(0).getLongLabel());
    }

    @Test
    public void testGetAllDocumentTypeWithInactives()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable

        // Moçked response
        SearchResponse result = factory.manufacturePojo(SearchResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentClassWSP()).thenReturn(service);
        when(service.search(any(SearchRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<DocumentClass> finalResult = documentTypeServiceImpl.getAllDocumentTypeWithInactives();

        // Validation
        verify(service).search(any(SearchRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        assertNotNull(finalResult.get(0));
        // check response content
        assertEquals(result.getDocumentClasses().getDocumentClass().get(0).getLongLabel(),
                finalResult.get(0).getLongLabel());
    }

    @Test
    public void testGetAllEnvelopeType()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable

        // Moçked response
        SearchResponse result = factory.manufacturePojo(SearchResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentClassWSP()).thenReturn(service);
        when(service.search(any(SearchRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<DocumentClass> finalResult = documentTypeServiceImpl.getAllEnvelopeType();

        // Validation
        verify(service).search(any(SearchRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        assertNotNull(finalResult.get(0));
        // check response content
        assertEquals(result.getDocumentClasses().getDocumentClass().get(0).getLongLabel(),
                finalResult.get(0).getLongLabel());
    }

    @Test
    public void testGetAllEnvelopeTypeWithInactive()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable

        // Moçked response
        SearchResponse result = factory.manufacturePojo(SearchResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentClassWSP()).thenReturn(service);
        when(service.search(any(SearchRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<DocumentClass> finalResult = documentTypeServiceImpl.getAllEnvelopeTypeWithInactive();

        // Validation
        verify(service).search(any(SearchRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        assertNotNull(finalResult.get(0));
        // check response content
        assertEquals(result.getDocumentClasses().getDocumentClass().get(0).getLongLabel(),
                finalResult.get(0).getLongLabel());
    }

    @Test
    public void testGetAllDocumentTypeCategoryBoolean()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        Category category = Category.ENVELOPE;
        boolean activeOnly = false;

        // Moçked response
        SearchResponse result = factory.manufacturePojo(SearchResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentClassWSP()).thenReturn(service);
        when(service.search(any(SearchRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<DocumentClass> finalResult = documentTypeServiceImpl.getAllDocumentType(category, activeOnly);

        // Validation
        verify(service).search(any(SearchRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        assertNotNull(finalResult.get(0));
        // check response content
        assertEquals(result.getDocumentClasses().getDocumentClass().get(0).getLongLabel(),
                finalResult.get(0).getLongLabel());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetDocumentTypeTags()
            throws TechFaultMessage, FuncFaultMessage, TechnicalException, FunctionalException {

        // input variable
        String id = "123";
        int version = 1;

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        List<TagClass> result2 = factory.manufacturePojo(List.class, TagClass.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentClassWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);
        when(tagsService.getTagListBySymbolicName(any(List.class))).thenReturn(result2);

        // Execute the method being tested
        List<TagClass> finalResult = documentTypeServiceImpl.getDocumentTypeTags(id, version);

        // Validation
        verify(service).get(any(GetRequest.class), any(TokenType.class));
        verify(tagsService).getTagListBySymbolicName(any(List.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result2.size(), finalResult.size());
        assertEquals(result2.get(0), finalResult.get(0));
    }

    @Test
    public void testCreateDocumentType()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        DocumentClass input = factory.manufacturePojo(DocumentClass.class);

        // Moçked response
        AddResponse result = factory.manufacturePojo(AddResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentClassWSP()).thenReturn(service);
        when(service.add(any(AddRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        DocumentClass finalResult = documentTypeServiceImpl.createDocumentType(input);

        // Validation
        verify(service).add(any(AddRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getDocumentClass().get(0).getLongLabel(), finalResult.getLongLabel());
    }

    @Test
    public void testCreateEnvelopeType()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        DocumentClass input = factory.manufacturePojo(DocumentClass.class);

        // Moçked response
        AddResponse result = factory.manufacturePojo(AddResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentClassWSP()).thenReturn(service);
        when(service.add(any(AddRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        DocumentClass finalResult = documentTypeServiceImpl.createEnvelopeType(input);

        // Validation
        verify(service).add(any(AddRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getDocumentClass().get(0).getLongLabel(), finalResult.getLongLabel());
    }

    @Test
    public void testUpdateDocumentType()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        DocumentClass input = factory.manufacturePojo(DocumentClass.class);

        // Moçked response
        UpdateResponse result = factory.manufacturePojo(UpdateResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentClassWSP()).thenReturn(service);
        when(service.update(any(UpdateRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        DocumentClass finalResult = documentTypeServiceImpl.updateDocumentType(input);

        // Validation
        verify(service).update(any(UpdateRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getDocumentClass().get(0).getLongLabel(), finalResult.getLongLabel());
    }

    @Test
    public void testUpdateEnvelopeType()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        DocumentClass input = factory.manufacturePojo(DocumentClass.class);

        // Moçked response
        UpdateResponse result = factory.manufacturePojo(UpdateResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentClassWSP()).thenReturn(service);
        when(service.update(any(UpdateRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        DocumentClass finalResult = documentTypeServiceImpl.updateEnvelopeType(input);

        // Validation
        verify(service).update(any(UpdateRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getDocumentClass().get(0).getLongLabel(), finalResult.getLongLabel());
    }

    @Test
    public void testActivateDocumentType()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        String documentTypeId = "123";
        int version = 1;

        // Moçked response
        SetActiveResponse result = factory.manufacturePojo(SetActiveResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentClassWSP()).thenReturn(service);
        when(service.setActive(any(SetActiveRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        documentTypeServiceImpl.activateDocumentType(documentTypeId, version);

        // Validation
        verify(service).setActive(any(SetActiveRequest.class), any(TokenType.class));
        // check a response exist

        // check response content
    }

    @Test
    public void testDeactivateDocumentType()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        String documentTypeId = "123";
        int version = 1;

        // Moçked response
        SetActiveResponse result = factory.manufacturePojo(SetActiveResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentClassWSP()).thenReturn(service);
        when(service.setActive(any(SetActiveRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        documentTypeServiceImpl.deactivateDocumentType(documentTypeId, version);

        // Validation
        verify(service).setActive(any(SetActiveRequest.class), any(TokenType.class));
        // check a response exist

        // check response content
    }

    @Test
    public void testActivateEnvelopeType()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        String documentTypeId = "123";
        int version = 1;

        // Moçked response
        SetActiveResponse result = factory.manufacturePojo(SetActiveResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentClassWSP()).thenReturn(service);
        when(service.setActive(any(SetActiveRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        documentTypeServiceImpl.activateEnvelopeType(documentTypeId, version);

        // Validation
        verify(service).setActive(any(SetActiveRequest.class), any(TokenType.class));
        // check a response exist

        // check response content
    }

    @Test
    public void testDeactivateEnvelopeType()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        String documentTypeId = "123";
        int version = 1;

        // Moçked response
        SetActiveResponse result = factory.manufacturePojo(SetActiveResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentClassWSP()).thenReturn(service);
        when(service.setActive(any(SetActiveRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        documentTypeServiceImpl.deactivateEnvelopeType(documentTypeId, version);

        // Validation
        verify(service).setActive(any(SetActiveRequest.class), any(TokenType.class));
        // check a response exist

        // check response content
    }

}
