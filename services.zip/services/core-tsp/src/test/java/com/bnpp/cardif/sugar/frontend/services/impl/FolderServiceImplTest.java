package com.bnpp.cardif.sugar.frontend.services.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.DocumentService;
import com.bnpp.cardif.sugar.frontend.services.model.PagingList;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderStatusCodeType;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.CreateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.FindRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.FindResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.SugarFolder;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folder.v1.UpdateResponse;

import uk.co.jemos.podam.api.DataProviderStrategy;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class FolderServiceImplTest extends FrontendGenericServiceTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    @Mock
    private DocumentService documentService;

    @Mock
    private SugarFolder service;

    @InjectMocks
    private FolderServiceImpl folderServiceImpl;

    @Before
    public void setUp() throws Exception {
        super.setUp();
        DataProviderStrategy strategy = factory.getStrategy();
        strategy.setDefaultNumberOfCollectionElements(2);
    }

    @Test
    public void testGetFolderByID() throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        String id = "123";

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarFolderWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        Folder finalResult = folderServiceImpl.getFolderByID(id);

        // Validation
        verify(service).get(any(GetRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getFolder().get(0).getData().getName(), finalResult.getData().getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testFindFolders() throws TechFaultMessage, FuncFaultMessage, TechnicalException, FunctionalException {

        // input variable
        long start = 0L;
        long maximum = 20L;
        String quickSearchValue = "test";
        List<Criterion> criterionList = factory.manufacturePojo(List.class, Criterion.class);
        OrderClause orderClause = factory.manufacturePojo(OrderClause.class);
        boolean includeChild = false;

        // Moçked response
        FindResponse result = factory.manufacturePojo(FindResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarFolderWSP()).thenReturn(service);
        when(service.find(any(FindRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        PagingList<Folder> finalResult = folderServiceImpl.findFolders(start, maximum, quickSearchValue, criterionList,
                orderClause, includeChild);

        // Validation
        verify(service).find(any(FindRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getFolder().size(), finalResult.getItemList().size());
        assertEquals(result.getFolder().get(0).getData().getName(),
                finalResult.getItemList().get(0).getData().getName());
    }

    @Test
    public void testGetFoldersByDocumentId()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        String documentId = "123";

        // Moçked response
        FindResponse result = factory.manufacturePojo(FindResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarFolderWSP()).thenReturn(service);
        when(service.find(any(FindRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<Folder> finalResult = folderServiceImpl.getFoldersByDocumentId(documentId);

        // Validation
        verify(service).find(any(FindRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getFolder().size(), finalResult.size());
        assertEquals(result.getFolder().get(0).getData().getName(), finalResult.get(0).getData().getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testCreateFolders() throws FunctionalException, TechnicalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        List<Folder> folderList = factory.manufacturePojo(List.class, Folder.class);

        // Moçked response
        CreateResponse result = factory.manufacturePojo(CreateResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarFolderWSP()).thenReturn(service);
        when(service.create(any(CreateRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<Folder> finalResult = folderServiceImpl.createFolders(folderList);

        // Validation
        verify(service).create(any(CreateRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getFolder().size(), finalResult.size());
        assertEquals(result.getFolder().get(0).getData().getName(), finalResult.get(0).getData().getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testUpdateFolders() throws FunctionalException, TechnicalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        List<Folder> folderList = factory.manufacturePojo(List.class, Folder.class);

        // Moçked response
        UpdateResponse result = factory.manufacturePojo(UpdateResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarFolderWSP()).thenReturn(service);
        when(service.update(any(UpdateRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<Folder> finalResult = folderServiceImpl.updateFolders(folderList);

        // Validation
        verify(service).update(any(UpdateRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getFolder().size(), finalResult.size());
        assertEquals(result.getFolder().get(0).getData().getName(), finalResult.get(0).getData().getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testAttachDocumentToFolder()
            throws TechFaultMessage, FuncFaultMessage, FunctionalException, TechnicalException {

        // input variable
        String folderId = "123";
        List<String> documentIdlist = factory.manufacturePojo(List.class, String.class);

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        result.getFolder().get(0).getData().setStatusCode(FolderStatusCodeType.OPEN);
        UpdateResponse result2 = factory.manufacturePojo(UpdateResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarFolderWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);
        when(service.update(any(UpdateRequest.class), any(TokenType.class))).thenReturn(result2);

        // Execute the method being tested
        Folder finalResult = folderServiceImpl.attachDocumentToFolder(folderId, documentIdlist);

        // Validation
        verify(service).update(any(UpdateRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result2.getFolder().get(0).getData().getName(), finalResult.getData().getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testDetachDocumentFromFolder()
            throws FunctionalException, TechnicalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        String folderId = "123";
        List<String> documentIdlist = factory.manufacturePojo(List.class, String.class);

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        result.getFolder().get(0).getData().setStatusCode(FolderStatusCodeType.OPEN);
        List<Id> idList = result.getFolder().get(0).getChildComponents().getId();
        idList.clear();
        for (String documentId : documentIdlist) {
            Id id = new Id(documentId, "CARDIF", "Sugar");
            idList.add(id);
        }
        UpdateResponse result2 = factory.manufacturePojo(UpdateResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarFolderWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);
        when(service.update(any(UpdateRequest.class), any(TokenType.class))).thenReturn(result2);

        // Execute the method being tested
        Folder finalResult = folderServiceImpl.detachDocumentFromFolder(folderId, documentIdlist);

        // Validation
        verify(service).update(any(UpdateRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result2.getFolder().get(0).getData().getName(), finalResult.getData().getName());
    }

}
