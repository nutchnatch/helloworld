package com.bnpp.cardif.sugar.frontend.services.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.model.PagingList;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetBySymbolicNameRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetBySymbolicNameResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.GetAllInBasketRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.GetAllInBasketResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.LockRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.LockResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.SugarTask;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.TransferRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.TransferResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.UnlockRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.UnlockResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.UpdateStatusRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.task.v1.UpdateStatusResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class TasksServiceImplTest extends FrontendGenericServiceTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    @Mock
    private SugarTask service;

    @InjectMocks
    private TasksServiceImpl tasksServiceImpl;

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testGetTaskListByBasket()
            throws TechFaultMessage, FuncFaultMessage, TechnicalException, FunctionalException {

        // input variable
        String basketIdValue = "123";
        long start = 0L;
        long maximum = 20L;

        // Moçked response
        GetAllInBasketResponse result = factory.manufacturePojo(GetAllInBasketResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarTaskWSP()).thenReturn(service);
        when(service.getAllInBasket(any(GetAllInBasketRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        PagingList<Task> finalResult = tasksServiceImpl.getTaskListByBasket(basketIdValue, start, maximum);

        // Validation
        verify(service).getAllInBasket(any(GetAllInBasketRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getTask().size(), finalResult.getItemList().size());
        assertEquals(result.getTask().get(0).getName(), finalResult.getItemList().get(0).getName());
    }

    @Test
    public void testGetTaskByID() throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        String taskIdValue = "123";

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarTaskWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        Task finalResult = tasksServiceImpl.getTaskByID(taskIdValue);

        // Validation
        verify(service).get(any(GetRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getTask().get(0).getName(), finalResult.getName());
    }

    @Test
    public void testTransferTask() throws TechFaultMessage, FuncFaultMessage, TechnicalException, FunctionalException {

        // input variable
        String taskIdValue = "123";
        String basketIdValue = "456";

        // Moçked response
        TransferResponse result = factory.manufacturePojo(TransferResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarTaskWSP()).thenReturn(service);
        when(service.transfer(any(TransferRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        String finalResult = tasksServiceImpl.transferTask(taskIdValue, basketIdValue);

        // Validation
        verify(service).transfer(any(TransferRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getTaskId().get(0).getValue(), finalResult);
    }

    @Test
    public void testLockTask() throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        String taskIdValue = "123";

        // Moçked response
        LockResponse result = factory.manufacturePojo(LockResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarTaskWSP()).thenReturn(service);
        when(service.lock(any(LockRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        String finalResult = tasksServiceImpl.lockTask(taskIdValue);

        // Validation
        verify(service).lock(any(LockRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getTaskId().get(0).getValue(), finalResult);
    }

    @Test
    public void testUnlockTask() throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        String taskIdValue = "123";

        // Moçked response
        UnlockResponse result = factory.manufacturePojo(UnlockResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarTaskWSP()).thenReturn(service);
        when(service.unlock(any(UnlockRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        String finalResult = tasksServiceImpl.unlockTask(taskIdValue);

        // Validation
        verify(service).unlock(any(UnlockRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getTaskId().get(0).getValue(), finalResult);
    }

    @Test
    public void testUpdateTaskStatus()
            throws TechnicalException, FunctionalException, TechFaultMessage, FuncFaultMessage {

        // input variable
        String taskIdValue = "123";
        String statusValue = "NEW";

        // Moçked response
        UpdateStatusResponse result = factory.manufacturePojo(UpdateStatusResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarTaskWSP()).thenReturn(service);
        when(service.updateStatus(any(UpdateStatusRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        String finalResult = tasksServiceImpl.updateTaskStatus(taskIdValue, statusValue);

        // Validation
        verify(service).updateStatus(any(UpdateStatusRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getStatus(), finalResult);
    }

}
