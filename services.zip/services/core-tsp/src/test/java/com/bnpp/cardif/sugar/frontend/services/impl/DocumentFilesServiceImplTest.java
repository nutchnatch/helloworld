package com.bnpp.cardif.sugar.frontend.services.impl;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.AddRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.AddResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.DeleteRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.DeleteResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.SugarDocumentFile;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class DocumentFilesServiceImplTest extends FrontendGenericServiceTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    @Mock
    private SugarDocumentFile service;

    @InjectMocks
    private DocumentFilesServiceImpl documentFilesServiceImpl = new DocumentFilesServiceImpl();

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetDocumentFilesByIDs()
            throws FuncFaultMessage, TechFaultMessage, TechnicalException, FunctionalException {

        // input variable
        List<String> ids = factory.manufacturePojo(List.class, String.class);

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentFileWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<DocumentFile> finalResult = documentFilesServiceImpl.getDocumentFilesByIDs(ids);

        // Validation
        verify(service).get(any(GetRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getDocumentFile().size(), finalResult.size());
        assertEquals(result.getDocumentFile().get(0).getName(), finalResult.get(0).getName());
    }

    @Test
    public void testGetDocumentFilesByID()
            throws FuncFaultMessage, TechFaultMessage, TechnicalException, FunctionalException {

        // input variable
        String id = "123";

        // Moçked response
        GetResponse result = factory.manufacturePojo(GetResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentFileWSP()).thenReturn(service);
        when(service.get(any(GetRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        DocumentFile finalResult = documentFilesServiceImpl.getDocumentFilesByID(id);

        // Validation
        verify(service).get(any(GetRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getDocumentFile().get(0).getName(), finalResult.getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testCreateDocumentFiles()
            throws FuncFaultMessage, TechFaultMessage, TechnicalException, FunctionalException {

        // input variable
        List<DocumentFile> inputDocFileList = factory.manufacturePojo(List.class, DocumentFile.class);

        // Moçked response
        AddResponse result = factory.manufacturePojo(AddResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentFileWSP()).thenReturn(service);
        when(service.add(any(AddRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<DocumentFile> finalResult = documentFilesServiceImpl.createDocumentFiles(inputDocFileList);

        // Validation
        verify(service).add(any(AddRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getDocumentFile().size(), finalResult.size());
        assertEquals(result.getDocumentFile().get(0).getName(), finalResult.get(0).getName());
    }

    @Test
    public void testCreateDocumentFile()
            throws TechnicalException, FunctionalException, FuncFaultMessage, TechFaultMessage {

        // input variable
        DocumentFile inputDocFile = factory.manufacturePojo(DocumentFile.class);

        // Moçked response
        AddResponse result = factory.manufacturePojo(AddResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentFileWSP()).thenReturn(service);
        when(service.add(any(AddRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        DocumentFile finalResult = documentFilesServiceImpl.createDocumentFile(inputDocFile);

        // Validation
        verify(service).add(any(AddRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getDocumentFile().get(0).getName(), finalResult.getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testDeleteDocumentFilesByIDs()
            throws FuncFaultMessage, TechFaultMessage, TechnicalException, FunctionalException {

        // input variable
        List<String> ids = factory.manufacturePojo(List.class, String.class);

        // Moçked response
        DeleteResponse result = factory.manufacturePojo(DeleteResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentFileWSP()).thenReturn(service);
        when(service.delete(any(DeleteRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<Boolean> finalResult = documentFilesServiceImpl.deleteDocumentFilesByIDs(ids);

        // Validation
        verify(service).delete(any(DeleteRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getDeleted().size(), finalResult.size());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testDeleteDocumentFiles()
            throws TechnicalException, FunctionalException, FuncFaultMessage, TechFaultMessage {

        // input variable
        List<DocumentFile> documentFileList = factory.manufacturePojo(List.class, DocumentFile.class);
        documentFileList.get(0).setURI("testUri");
        // Moçked response
        DeleteResponse result = factory.manufacturePojo(DeleteResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentFileWSP()).thenReturn(service);
        when(service.delete(any(DeleteRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        List<Boolean> finalResult = documentFilesServiceImpl.deleteDocumentFiles(documentFileList);

        // Validation
        verify(service).delete(any(DeleteRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content
        assertEquals(result.getDeleted().size(), finalResult.size());
    }

    @Test
    public void testDeleteDocumentFilesByID()
            throws TechnicalException, FunctionalException, FuncFaultMessage, TechFaultMessage {

        // input variable
        String id = "123";

        // Moçked response
        DeleteResponse result = factory.manufacturePojo(DeleteResponse.class);
        // Mockito expectations
        when(sugarWebServiceClientFactory.getSugarDocumentFileWSP()).thenReturn(service);
        when(service.delete(any(DeleteRequest.class), any(TokenType.class))).thenReturn(result);

        // Execute the method being tested
        Boolean finalResult = documentFilesServiceImpl.deleteDocumentFilesByID(id);

        // Validation
        verify(service).delete(any(DeleteRequest.class), any(TokenType.class));
        // check a response exist
        assertNotNull(finalResult);
        // check response content

    }

}
