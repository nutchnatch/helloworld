package com.bnpp.cardif.sugar.frontend.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenCreator;
import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.DocumentTypeService;
import com.bnpp.cardif.sugar.frontend.services.TagsService;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOTagReference;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.AddRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.AddResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SearchRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SearchResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SearchResponse.DocumentClasses;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SetActiveRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SetActiveResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SugarDocumentClass;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.UpdateResponse;

/**
 * 
 * @author 831743
 *
 */
@Service("documentTypeService")
@Scope("singleton")
public class DocumentTypeServiceImpl extends FrontendGenericServiceImpl implements DocumentTypeService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentTypeServiceImpl.class);

    @Autowired
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    @Autowired
    private TagsService tagsService;

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentTypeService#
     * getDocumentTypeByID(java.lang.String, int)
     */
    public DocumentClass getDocumentTypeByID(String id, int version) throws TechnicalException, FunctionalException {

        LOGGER.debug("getDocumentTypeByID called");
        // validate input
        this.validateInputDocumentClassById(id, version);
        // create Input
        List<ClassId> ids = new ArrayList<>();
        ClassId classId = new ClassId(id, ISSUER, version);
        ids.add(classId);
        // call
        List<DocumentClass> documentClassList = this.getDocumentTypeByIDs(ids);
        if (documentClassList.isEmpty()) {
            // error 1 documentClass expected 0 are returned.
            throw new TechnicalException(ErrorCode.TE002);
        }
        // extract result
        LOGGER.debug("getDocumentTypeByID end");
        return documentClassList.get(0);
    }

    private void validateInputDocumentClassById(String id, int version) throws InvalidInputException {
        if (id == null || id.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "ID");
        }
        if (version < 0) {
            throw new InvalidInputException(ErrorCode.IIE006.getCode(), ErrorCode.IIE006.getMessage() + "version");
        }
    }

    private List<DocumentClass> getDocumentTypeByIDs(final List<ClassId> ids)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("getDocumentTypeByIDs called");
        List<DocumentClass> documentClassList = new ArrayList<>();
        // validate input
        this.validateInputDocumentTypeByIds(ids);
        // call webService
        SugarDocumentClass service = sugarWebServiceClientFactory.getSugarDocumentClassWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        GetRequest parameters = new GetRequest();
        parameters.setScope(getScope());
        List<ClassId> classIdList = parameters.getClassId();
        if (classIdList == null) {
            classIdList = new ArrayList<>();
        }
        classIdList.addAll(ids);
        try {
            GetResponse result = service.get(parameters, securityToken);
            documentClassList = result.getDocumentClass();
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("getDocumentTypeByIDs end");
        return documentClassList;
    }

    private void validateInputDocumentTypeByIds(final List<ClassId> ids) throws InvalidInputException {
        if (ids == null || ids.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "ClassIds");
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentTypeService#
     * getAllDocumentType()
     */
    public List<DocumentClass> getAllDocumentType() throws TechnicalException, FunctionalException {
        return this.getAllDocumentType(Category.DOCUMENT, true);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentTypeService#
     * getAllDocumentTypeWithInactives()
     */
    public List<DocumentClass> getAllDocumentTypeWithInactives() throws TechnicalException, FunctionalException {
        return this.getAllDocumentType(Category.DOCUMENT, false);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentTypeService#
     * getAllEnvelopeType()
     */
    public List<DocumentClass> getAllEnvelopeType() throws TechnicalException, FunctionalException {
        return this.getAllDocumentType(Category.ENVELOPE, true);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentTypeService#
     * getAllEnvelopeTypeWithInactive()
     */
    public List<DocumentClass> getAllEnvelopeTypeWithInactive() throws TechnicalException, FunctionalException {
        return this.getAllDocumentType(Category.ENVELOPE, false);
    }

     /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentTypeService#
     * getAllDocumentType(com.bnpparibas.assurance.ea.internal.schema.mco.common
     * .v1.Category, boolean)
     */
    public List<DocumentClass> getAllDocumentType(final Category category, final boolean activeOnly)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("getAllDocumentType called");
        List<DocumentClass> documentClassList = new ArrayList<>();
        // validate input
        this.validateInputAllDocumentTypes(category);
        // call webService
        SugarDocumentClass service = sugarWebServiceClientFactory.getSugarDocumentClassWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        SearchRequest parameters = new SearchRequest();
        parameters.setScope(getScope());
        parameters.setCategory(category);
        parameters.setActiveOnly(activeOnly);
        try {
            SearchResponse result = service.search(parameters, securityToken);
            DocumentClasses documentClasses = result.getDocumentClasses();
            if (documentClasses != null) {
                documentClassList = documentClasses.getDocumentClass();
            }
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("getAllDocumentType end");
        return documentClassList;
    }

    private void validateInputAllDocumentTypes(Category category) throws InvalidInputException {
        if (category == null) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "category");
        }
    }

    public List<TagClass> getDocumentTypeTags(String id, int version) throws TechnicalException, FunctionalException {

        // get the document Type
        DocumentClass documentClass = this.getDocumentTypeByID(id, version);
        // build the list of Tags symbolic Names
        List<String> symbolicNames = new ArrayList<>();
        List<MCOTagReference> tagList = documentClass.getTagReference();
        if (tagList != null) {
            for (MCOTagReference mcoTagReference : tagList) {
                symbolicNames.add(mcoTagReference.getSymbolicName());
            }
        }
        // get the tags by symbolicNames
        return tagsService.getTagListBySymbolicName(symbolicNames);
    }

    private List<DocumentClass> createDocumentClasses(final List<DocumentClass> inputList, final Category category)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("createDocumentClasses called");
        List<DocumentClass> documentClassList = new ArrayList<>();
        // validate input
        if (inputList == null || inputList.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "inputList");
        }
        // apply category to input DocumentClass
        for (DocumentClass documentClass : inputList) {
            documentClass.setCategory(category);
        }
        // call webService
        SugarDocumentClass service = sugarWebServiceClientFactory.getSugarDocumentClassWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        AddRequest parameters = new AddRequest();
        List<DocumentClass> docClassList = parameters.getDocumentClass();
        docClassList.addAll(inputList);
        try {
            AddResponse result = service.add(parameters, securityToken);
            documentClassList = result.getDocumentClass();
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("createDocumentClasses end");
        return documentClassList;
    }

    private DocumentClass createDocumentClass(DocumentClass input, final Category category)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("createDocumentClass called");
        // validate input
        if (input == null) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "input");
        }
        // create Input
        List<DocumentClass> inputList = new ArrayList<>();
        inputList.add(input);
        // call
        List<DocumentClass> documentClassList = this.createDocumentClasses(inputList, category);
        if (documentClassList.isEmpty()) {
            // error 1 documentClass expected 0 are returned.
            throw new TechnicalException(ErrorCode.TE002);
        }
        // extract result
        LOGGER.debug("createDocumentClass end");
        return documentClassList.get(0);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentTypeService#
     * createDocumentType(com.bnpparibas.assurance.ea.internal.schema.mco.
     * documentclass.v1.DocumentClass)
     */
    public DocumentClass createDocumentType(DocumentClass input) throws TechnicalException, FunctionalException {

        return this.createDocumentClass(input, Category.DOCUMENT);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentTypeService#
     * createEnvelopeType(com.bnpparibas.assurance.ea.internal.schema.mco.
     * documentclass.v1.DocumentClass)
     */
    public DocumentClass createEnvelopeType(DocumentClass input) throws TechnicalException, FunctionalException {

        return this.createDocumentClass(input, Category.ENVELOPE);
    }

    private List<DocumentClass> updateDocumentClasses(final List<DocumentClass> inputList, final Category category)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("updateDocumentClasses called");
        List<DocumentClass> documentClassList = new ArrayList<>();
        // validate input
        if (inputList == null || inputList.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "inputList");
        }
        // apply category to input DocumentClass
        for (DocumentClass documentClass : inputList) {
            documentClass.setCategory(category);
        }
        // call webService
        SugarDocumentClass service = sugarWebServiceClientFactory.getSugarDocumentClassWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        UpdateRequest parameters = new UpdateRequest();
        List<DocumentClass> docClassList = parameters.getDocumentClass();
        parameters.setCreateNewVersion(true);
        docClassList.addAll(inputList);
        try {
            UpdateResponse result = service.update(parameters, securityToken);
            documentClassList = result.getDocumentClass();
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("updateDocumentClasses end");
        return documentClassList;
    }

    private DocumentClass updateDocumentClass(DocumentClass input, final Category category)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("updateDocumentClass called");
        // validate input
        if (input == null) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "input");
        }
        // create Input
        List<DocumentClass> inputList = new ArrayList<>();
        inputList.add(input);
        // call
        List<DocumentClass> documentClassList = this.updateDocumentClasses(inputList, category);
        if (documentClassList.isEmpty()) {
            // error 1 documentClass expected 0 are returned.
            throw new TechnicalException(ErrorCode.TE002);
        }
        // extract result
        LOGGER.debug("updateDocumentClass end");
        return documentClassList.get(0);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentTypeService#
     * updateDocumentType(com.bnpparibas.assurance.ea.internal.schema.mco.
     * documentclass.v1.DocumentClass)
     */
    public DocumentClass updateDocumentType(DocumentClass input) throws TechnicalException, FunctionalException {

        return this.updateDocumentClass(input, Category.DOCUMENT);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentTypeService#
     * updateEnvelopeType(com.bnpparibas.assurance.ea.internal.schema.mco.
     * documentclass.v1.DocumentClass)
     */
    public DocumentClass updateEnvelopeType(DocumentClass input) throws TechnicalException, FunctionalException {

        return this.updateDocumentClass(input, Category.ENVELOPE);
    }

    private void activateDocumentClasses(final List<ClassId> inputDocClassList, final boolean isactive)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("activateDocumentClasses called");
        // validate input
        if (inputDocClassList == null || inputDocClassList.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + "inputDocClassList");
        }
        // call webService
        SugarDocumentClass service = sugarWebServiceClientFactory.getSugarDocumentClassWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        SetActiveRequest parameters = new SetActiveRequest();
        List<ClassId> docClassList = parameters.getClassId();
        docClassList.addAll(inputDocClassList);
        parameters.setActivate(isactive);
        parameters.setScope(getScope());
        try {
            SetActiveResponse result = service.setActive(parameters, securityToken);
            if (result == null) {
                // error 1 response expected 0 are returned.
                throw new TechnicalException(ErrorCode.TE002);
            }
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("activateDocumentClasses end");
    }

    private void activateDocumentClass(String documentTypeId, int version, final boolean isactive)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("activateDocumentClass called");
        // validate input
        if (documentTypeId == null || documentTypeId.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + "documentTypeId");
        }
        // create Input
        List<ClassId> inputList = new ArrayList<>();
        ClassId classId = new ClassId(documentTypeId, ISSUER, version);
        inputList.add(classId);
        // call
        this.activateDocumentClasses(inputList, isactive);
        // extract result
        LOGGER.debug("activateDocumentClass end");
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentTypeService#
     * activateDocumentType(java.lang.String, int)
     */
    public void activateDocumentType(String documentTypeId, int version)
            throws TechnicalException, FunctionalException {

        this.activateDocumentClass(documentTypeId, version, true);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentTypeService#
     * deactivateDocumentType(java.lang.String, int)
     */
    public void deactivateDocumentType(String documentTypeId, int version)
            throws TechnicalException, FunctionalException {

        this.activateDocumentClass(documentTypeId, version, false);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentTypeService#
     * activateEnvelopeType(java.lang.String, int)
     */
    public void activateEnvelopeType(String documentTypeId, int version)
            throws TechnicalException, FunctionalException {

        this.activateDocumentClass(documentTypeId, version, true);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentTypeService#
     * deactivateEnvelopeType(java.lang.String, int)
     */
    public void deactivateEnvelopeType(String documentTypeId, int version)
            throws TechnicalException, FunctionalException {

        this.activateDocumentClass(documentTypeId, version, false);
    }

}
