/**
 * 
 */
package com.bnpp.cardif.sugar.frontend.services.impl;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.SesameWebServiceFactory;
import com.bnpp.cardif.sesame.security.soap.TokenCreator;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.ResourcesService;
import com.bnpp.cardif.sugar.security.AuthenticatedUser;
import com.bnppa.sesame.services.standard.proxy.AuthenticationServicesWSP;
import com.bnppa.sesame.services.standard.proxy.InvalidTokenException;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;

/**
 * @author 831743
 *
 */
@Service("resourcesService")
@Scope("singleton")
public class ResourcesServiceImpl extends FrontendGenericServiceImpl implements ResourcesService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ResourcesServiceImpl.class);

    @Autowired
    private SesameWebServiceFactory sesameWebServiceFactory;

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.ResourcesService#getUser()
     */
    @Override
    public AuthenticatedUser getUser() throws TechnicalException {
        return this.getCurrentUser();
    }

    /**
     * Set the business scope.
     *
     * @param scope
     * @return AuthenticatedUser
     * @throws TechnicalException
     */
    @Override
    public void setBusinessScope(String scope) throws TechnicalException {
        this.setScope(scope);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.ResourcesService#logout(javax.
     * servlet.http.HttpSession)
     */
    public void logout(HttpSession httpSession)
            throws InvalidTokenException, com.bnppa.sesame.services.standard.proxy.TechnicalException {

        LOGGER.debug("logout called");
        // sending logout request to sesame to invalidate the current token.
        TokenType securityToken = TokenCreator.getTokenType();
        if (securityToken != null) {
            AuthenticationServicesWSP service = sesameWebServiceFactory.getAuthenticationServicesWSP();
            try {
                service.logout(securityToken.getToken());
            }
            catch (final Exception e) {
                LOGGER.warn("Problem performing the logout", e);
            }
        }
        // perform the spring security logout
        SecurityContext context = SecurityContextHolder.getContext();
        Authentication auth = context.getAuthentication();
        LOGGER.debug("Authentication: {}", auth);
        if (auth != null) {
            Object principal = auth.getPrincipal();
            LOGGER.debug("principal: {}", principal);
            LOGGER.debug("httpSession: {}", httpSession);
            if (httpSession != null) {
                LOGGER.debug("Invalidating session: {}", httpSession.getId());
                httpSession.invalidate();
            }
            LOGGER.debug("Removing authentication from context.");
            context.setAuthentication(null);
        }
        LOGGER.debug("Clear context from holder.");
        SecurityContextHolder.clearContext();
        LOGGER.debug("logout end");
    }

}
