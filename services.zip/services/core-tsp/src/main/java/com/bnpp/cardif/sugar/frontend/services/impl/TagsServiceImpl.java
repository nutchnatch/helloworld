package com.bnpp.cardif.sugar.frontend.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenCreator;
import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.TagsService;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.CreateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetAllRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetAllResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetBySymbolicNameRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.GetBySymbolicNameResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.SugarTagClass;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.tagclass.v1.UpdateResponse;

/**
 * 
 * @author 831743
 *
 */
@Service("tagsService")
@Scope("singleton")
public class TagsServiceImpl extends FrontendGenericServiceImpl implements TagsService {

    private static final Logger LOGGER = LoggerFactory.getLogger(TagsServiceImpl.class);

    @Autowired
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.TagsService#getAllTagList()
     */
    public List<TagClass> getAllTagList() throws TechnicalException, FunctionalException {

        LOGGER.debug("getAllTagList called");
        List<TagClass> tagList = null;
        // call webService
        try {
            SugarTagClass service = sugarWebServiceClientFactory.getSugarTagClassWSP();
            TokenType securityToken = TokenCreator.getTokenType();
            GetAllRequest request = new GetAllRequest();
            request.setScope(this.getScope());
            GetAllResponse result = service.getAll(request, securityToken);
            if (result != null) {
                tagList = result.getTagClass();
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("getAllTagList end");
        return tagList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.TagsService#
     * getTagListBySymbolicName(java.util.List)
     */
    public List<TagClass> getTagListBySymbolicName(List<String> symbolicNames)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("getTagListBySymbolicName called");
        List<TagClass> tagList = null;
        // call webService
        try {
            SugarTagClass service = sugarWebServiceClientFactory.getSugarTagClassWSP();
            TokenType securityToken = TokenCreator.getTokenType();
            GetBySymbolicNameRequest request = new GetBySymbolicNameRequest();
            request.setScope(this.getScope());
            request.getSymbolicNames().addAll(symbolicNames);
            GetBySymbolicNameResponse result = service.getBySymbolicName(request, securityToken);
            if (result != null) {
                tagList = result.getTagClass();
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("getTagListBySymbolicName end");
        return tagList;
    }

    private List<TagClass> createTagList(List<TagClass> inputTagClasses)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("createTagList called");
        List<TagClass> tagList = new ArrayList<>();
        // validate input
        if (inputTagClasses == null || inputTagClasses.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + "inputTagClasses");
        }
        // call webService
        try {
            SugarTagClass service = sugarWebServiceClientFactory.getSugarTagClassWSP();
            TokenType securityToken = TokenCreator.getTokenType();
            CreateRequest parameters = new CreateRequest();
            List<TagClass> tagClassList = parameters.getTagClass();
            tagClassList.addAll(inputTagClasses);
            CreateResponse result = service.create(parameters, securityToken);
            if (result != null) {
                tagList = result.getTagClass();
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("createTagList end");
        return tagList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.TagsService#createTag(com.
     * bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass)
     */
    public TagClass createTag(TagClass inputTagClass) throws TechnicalException, FunctionalException {

        LOGGER.debug("createTag called");
        // validate input
        if (inputTagClass == null) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + "inputTagClass");
        }
        // create Input
        List<TagClass> inputList = new ArrayList<>();
        inputList.add(inputTagClass);
        // call
        List<TagClass> tagClassList = this.createTagList(inputList);
        if (tagClassList.isEmpty()) {
            // error 1 FolderClass expected 0 are returned.
            throw new TechnicalException(ErrorCode.TE002);
        }
        // extract result
        LOGGER.debug("createTag end");
        return tagClassList.get(0);
    }

    private List<TagClass> updateTagList(List<TagClass> inputTagClasses)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("updateTagList called");
        List<TagClass> tagList = new ArrayList<>();
        // validate input
        if (inputTagClasses == null || inputTagClasses.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + "inputTagClasses");
        }
        // call webService
        try {
            SugarTagClass service = sugarWebServiceClientFactory.getSugarTagClassWSP();
            TokenType securityToken = TokenCreator.getTokenType();
            UpdateRequest parameters = new UpdateRequest();
            List<TagClass> tagClassList = parameters.getTagClass();
            tagClassList.addAll(inputTagClasses);
            UpdateResponse result = service.update(parameters, securityToken);
            if (result != null) {
                tagList = result.getTagClass();
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("updateTagList end");
        return tagList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.TagsService#updateTag(com.
     * bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass)
     */
    public TagClass updateTag(TagClass inputTagClass) throws TechnicalException, FunctionalException {

        LOGGER.debug("updateTag called");
        // validate input
        if (inputTagClass == null) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + "inputTagClass");
        }
        // create Input
        List<TagClass> inputList = new ArrayList<>();
        inputList.add(inputTagClass);
        // call
        List<TagClass> tagClassList = this.updateTagList(inputList);
        if (tagClassList.isEmpty()) {
            // error 1 FolderClass expected 0 are returned.
            throw new TechnicalException(ErrorCode.TE002);
        }
        // extract result
        LOGGER.debug("updateTag end");
        return tagClassList.get(0);
    }
    
    

}
