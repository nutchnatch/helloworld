package com.bnpp.cardif.sugar.frontend.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenCreator;
import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.FolderTypeService;
import com.bnpp.cardif.sugar.frontend.services.TagsService;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOTagReference;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.CreateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.CreateResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.GetAllRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.GetAllResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.SetActiveRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.SetActiveResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.SugarFolderClass;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.UpdateRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.folderclass.v1.UpdateResponse;

/**
 * 
 * @author 831743
 *
 */
@Service("folderTypeService")
@Scope("singleton")
public class FolderTypeServiceImpl extends FrontendGenericServiceImpl implements FolderTypeService {

    private static final Logger LOGGER = LoggerFactory.getLogger(FolderTypeServiceImpl.class);

    @Autowired
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    @Autowired
    private TagsService tagsService;

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.FolderTypeService#
     * getFolderTypeByID(java.lang.String, int)
     */
    public FolderClass getFolderTypeByID(String id, int version) throws TechnicalException, FunctionalException {

        LOGGER.debug("getFolderTypeByID called");
        // validate input
        this.validateInputFolderClassById(id, version);
        // create Input
        List<ClassId> ids = new ArrayList<>();
        ClassId classId = new ClassId(id, ISSUER, version);
        ids.add(classId);
        // call
        List<FolderClass> folderClassList = this.getFolderTypeByIDs(ids);
        if (folderClassList.isEmpty()) {
            // error 1 documentClass expected 0 are returned.
            throw new TechnicalException(ErrorCode.TE002);
        }
        // extract result
        LOGGER.debug("getFolderTypeByID end");
        return folderClassList.get(0);
    }

    private void validateInputFolderClassById(String id, int version) throws InvalidInputException {
        if (id == null || id.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "ID");
        }
        if (version < 0) {
            throw new InvalidInputException(ErrorCode.IIE006.getCode(), ErrorCode.IIE006.getMessage() + "version");
        }
    }

    private List<FolderClass> getFolderTypeByIDs(final List<ClassId> ids)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("getFolderTypeByIDs called");
        List<FolderClass> folderClassList = new ArrayList<>();
        // validate input
        this.validateInputFolderTypeByIds(ids);
        // call webService
        SugarFolderClass service = sugarWebServiceClientFactory.getSugarFolderClassWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        GetRequest parameters = new GetRequest();
        parameters.setScope(getScope());
        List<ClassId> classIdList = parameters.getClassId();
        if (classIdList == null) {
            classIdList = new ArrayList<>();
        }
        classIdList.addAll(ids);
        try {

            GetResponse result = service.get(parameters, securityToken);
            folderClassList = result.getFolderClass();
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("getFolderTypeByIDs end");
        return folderClassList;
    }

    private void validateInputFolderTypeByIds(List<ClassId> ids) throws InvalidInputException {
        if (ids == null || ids.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "ClassIds");
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.FolderTypeService#
     * getAllFolderType()
     */
    public List<FolderClass> getAllFolderType() throws TechnicalException, FunctionalException {
        return this.getAllFolderType(true);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.FolderTypeService#
     * getAllFolderTypeWithInactive()
     */
    public List<FolderClass> getAllFolderTypeWithInactive() throws TechnicalException, FunctionalException {
        return this.getAllFolderType(false);
    }

    private List<FolderClass> getAllFolderType(final boolean activeOnly)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("getAllFolderType called");
        List<FolderClass> folderClassList = new ArrayList<>();
        // call webService
        SugarFolderClass service = sugarWebServiceClientFactory.getSugarFolderClassWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        GetAllRequest parameters = new GetAllRequest();
        parameters.setActiveOnly(activeOnly);
        parameters.setScope(getScope());
        try {
            GetAllResponse result = service.getAll(parameters, securityToken);
            if (result != null) {
                folderClassList = result.getFolderClass();
            }
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("getAllFolderType end");
        return folderClassList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.FolderTypeService#
     * getFolderTypeTags(java.lang.String, int)
     */
    public List<TagClass> getFolderTypeTags(String id, int version) throws TechnicalException, FunctionalException {

        // get the document Type
        FolderClass folderClass = this.getFolderTypeByID(id, version);
        // build the list of Tags symbolic Names
        List<String> symbolicNames = new ArrayList<>();
        List<MCOTagReference> tagList = folderClass.getTagReference();
        if (tagList != null) {
            for (MCOTagReference mcoTagReference : tagList) {
                symbolicNames.add(mcoTagReference.getSymbolicName());
            }
        }
        // get the tags by symbolicNames
        return tagsService.getTagListBySymbolicName(symbolicNames);
    }

    private List<FolderClass> createFolderClasses(final List<FolderClass> inputList)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("createFolderClasses called");
        List<FolderClass> folderClassList = new ArrayList<>();
        // validate input
        if (inputList == null || inputList.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "inputList");
        }
        // call webService
        SugarFolderClass service = sugarWebServiceClientFactory.getSugarFolderClassWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        CreateRequest parameters = new CreateRequest();
        List<FolderClass> foldClassList = parameters.getFolderClass();
        foldClassList.addAll(inputList);
        try {
            CreateResponse result = service.create(parameters, securityToken);
            folderClassList = result.getFolderClass();
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("createFolderClasses end");
        return folderClassList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.FolderTypeService#
     * createFolderClass(com.bnpparibas.assurance.ea.internal.schema.mco.
     * casefolderclass.v1.FolderClass)
     */
    public FolderClass createFolderType(FolderClass input) throws TechnicalException, FunctionalException {

        LOGGER.debug("createFolderClass called");
        // validate input
        if (input == null) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "input");
        }
        // create Input
        List<FolderClass> inputList = new ArrayList<>();
        inputList.add(input);
        // call
        List<FolderClass> folderClassList = this.createFolderClasses(inputList);
        if (folderClassList.isEmpty()) {
            // error 1 FolderClass expected 0 are returned.
            throw new TechnicalException(ErrorCode.TE002);
        }
        // extract result
        LOGGER.debug("createFolderClass end");
        return folderClassList.get(0);
    }

    private List<FolderClass> updateFolderClasses(final List<FolderClass> inputList)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("updateFolderClasses called");
        List<FolderClass> folderClassList = new ArrayList<>();
        // validate input
        if (inputList == null || inputList.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "inputList");
        }
        // call webService
        SugarFolderClass service = sugarWebServiceClientFactory.getSugarFolderClassWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        UpdateRequest parameters = new UpdateRequest();
        List<FolderClass> foldClassList = parameters.getFolderClass();
        parameters.setCreateNewVersion(true);
        foldClassList.addAll(inputList);
        try {
            UpdateResponse result = service.update(parameters, securityToken);
            folderClassList = result.getFolderClass();
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("updateFolderClasses end");
        return folderClassList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.FolderTypeService#
     * updateFolderClass(com.bnpparibas.assurance.ea.internal.schema.mco.
     * casefolderclass.v1.FolderClass)
     */
    public FolderClass updateFolderType(FolderClass input) throws TechnicalException, FunctionalException {

        LOGGER.debug("updateFolderClass called");
        // validate input
        if (input == null) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "input");
        }
        // create Input
        List<FolderClass> inputList = new ArrayList<>();
        inputList.add(input);
        // call
        List<FolderClass> folderClassList = this.updateFolderClasses(inputList);
        if (folderClassList.isEmpty()) {
            // error 1 FolderClass expected 0 are returned.
            throw new TechnicalException(ErrorCode.TE002);
        }
        // extract result
        LOGGER.debug("updateFolderClass end");
        return folderClassList.get(0);
    }

    private void activateFolderClasses(final List<ClassId> inputFolderClassList, final boolean isactive)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("activateFolderClasses called");
        // validate input
        if (inputFolderClassList == null || inputFolderClassList.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + "inputFolderClassList");
        }
        // call webService
        SugarFolderClass service = sugarWebServiceClientFactory.getSugarFolderClassWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        SetActiveRequest parameters = new SetActiveRequest();
        List<ClassId> docClassList = parameters.getClassId();
        docClassList.addAll(inputFolderClassList);
        parameters.setActive(isactive);
        parameters.setScope(getScope());
        try {
            SetActiveResponse result = service.setActive(parameters, securityToken);
            if (result == null) {
                // error 1 response expected 0 are returned.
                throw new TechnicalException(ErrorCode.TE002);
            }
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("activateFolderClasses end");
    }

    private void activateFolderClass(String folderTypeId, int version, final boolean isactive)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("activateFolderClass called");
        // validate input
        if (folderTypeId == null || folderTypeId.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + "documentTypeId");
        }
        // create Input
        List<ClassId> inputList = new ArrayList<>();
        ClassId classId = new ClassId(folderTypeId, ISSUER, version);
        inputList.add(classId);
        // call
        this.activateFolderClasses(inputList, isactive);
        // extract result
        LOGGER.debug("activateFolderClass end");
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.FolderTypeService#
     * activateFolderClass(java.lang.String, int)
     */
    public void activateFolderType(String folderTypeId, int version) throws TechnicalException, FunctionalException {

        this.activateFolderClass(folderTypeId, version, true);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.FolderTypeService#
     * deactivateFolderClass(java.lang.String, int)
     */
    public void deactivateFolderType(String folderTypeId, int version) throws TechnicalException, FunctionalException {

        this.activateFolderClass(folderTypeId, version, false);
    }

}
