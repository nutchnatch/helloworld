/**
 * 
 */
package com.bnpp.cardif.sugar.frontend.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenCreator;
import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.DocumentFilesService;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.URI;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.AddRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.AddResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.DeleteRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.DeleteResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.documentfile.v1.SugarDocumentFile;

/**
 * @author 831743
 *
 */
@Service("documentFilesService")
@Scope("singleton")
public class DocumentFilesServiceImpl extends FrontendGenericServiceImpl implements DocumentFilesService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentFilesServiceImpl.class);

    @Autowired
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentFilesService#
     * getDocumentFilesByIDs(java.util.List)
     */
    public List<DocumentFile> getDocumentFilesByIDs(final List<String> ids)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("getDocumentFilesByIDs called");
        List<DocumentFile> documentFileList = new ArrayList<>();
        // validate input
        if (ids == null || ids.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "IDs");
        }
        // call webService
        SugarDocumentFile service = sugarWebServiceClientFactory.getSugarDocumentFileWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        GetRequest parameters = new GetRequest();
        parameters.setScope(getScope());
        List<URI> idList = parameters.getURI();
        if (idList == null) {
            idList = new ArrayList<>();
        }
        for (String id : ids) {
            URI documentFileURI = new URI(id);
            idList.add(documentFileURI);
        }
        try {
            GetResponse result = service.get(parameters, securityToken);
            documentFileList = result.getDocumentFile();
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("getDocumentFilesByIDs end");
        return documentFileList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentFilesService#
     * getDocumentFilesByID(java.lang.String)
     */
    public DocumentFile getDocumentFilesByID(final String id) throws TechnicalException, FunctionalException {

        LOGGER.debug("getDocumentFilesByID called");
        // validate input
        if (id == null || id.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "id");
        }
        List<String> ids = new ArrayList<>();
        ids.add(id);
        List<DocumentFile> documentFileList = this.getDocumentFilesByIDs(ids);
        if (documentFileList.isEmpty()) {
            // error 1 documentFile expected 0 are returned.
            throw new TechnicalException(ErrorCode.TE002);
        }
        // extract result
        DocumentFile documentFile = documentFileList.get(0);
        LOGGER.debug("getDocumentFilesByID end");
        return documentFile;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentFilesService#
     * createDocumentFiles(java.util.List)
     */
    public List<DocumentFile> createDocumentFiles(List<DocumentFile> inputDocFileList)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("createDocumentFiles called");
        List<DocumentFile> documentFileList = new ArrayList<>();
        // validate input
        if (inputDocFileList == null || inputDocFileList.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + "inputDocFileList");
        }
        else {
            for (DocumentFile inputDocFile : documentFileList) {
                if (inputDocFile.getURI() != null && !inputDocFile.getURI().isEmpty()) {
                    throw new InvalidInputException(ErrorCode.IIE008);
                }
            }
        }
        SugarDocumentFile service = sugarWebServiceClientFactory.getSugarDocumentFileWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        AddRequest parameters = new AddRequest();
        List<DocumentFile> documentFileListParam = parameters.getDocumentFile();
        documentFileListParam.addAll(inputDocFileList);
        try {
            AddResponse result = service.add(parameters, securityToken);
            documentFileList = result.getDocumentFile();
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("createDocumentFiles end");
        return documentFileList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentFilesService#
     * createDocumentFile(com.bnpparibas.assurance.ea.internal.schema.mco.
     * documentfile.v1.DocumentFile)
     */
    public DocumentFile createDocumentFile(DocumentFile inputDocFile) throws TechnicalException, FunctionalException {

        LOGGER.debug("createDocumentFile called");
        // validate input
        if (inputDocFile == null) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "inputDocFile");
        }
        List<DocumentFile> inputDocFileList = new ArrayList<>();
        inputDocFileList.add(inputDocFile);
        List<DocumentFile> documentFileList = this.createDocumentFiles(inputDocFileList);
        if (documentFileList.isEmpty()) {
            // error 1 documentFile expected 0 are returned.
            throw new TechnicalException(ErrorCode.TE002);
        }
        // extract result
        DocumentFile documentFile = documentFileList.get(0);
        LOGGER.debug("createDocumentFile end");
        return documentFile;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentFilesService#
     * deleteDocumentFilesByIDs(java.util.List)
     */
    public List<Boolean> deleteDocumentFilesByIDs(final List<String> ids)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("deleteDocumentFilesByIDs called");
        List<Boolean> deletedList = new ArrayList<>();
        // validate input
        if (ids == null || ids.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "IDs");
        }
        // call webService
        SugarDocumentFile service = sugarWebServiceClientFactory.getSugarDocumentFileWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        DeleteRequest parameters = new DeleteRequest();
        parameters.setScope(getScope());
        List<URI> idList = parameters.getURI();
        if (idList == null) {
            idList = new ArrayList<>();
        }
        for (String id : ids) {
            URI documentFileURI = new URI(id);
            idList.add(documentFileURI);
        }
        try {
            DeleteResponse result = service.delete(parameters, securityToken);
            deletedList = result.getDeleted();
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("deleteDocumentFilesByIDs end");
        return deletedList;
    }

    public List<Boolean> deleteDocumentFiles(final List<DocumentFile> documentFileList)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("deleteDocumentFiles called");
        List<Boolean> deletedList = new ArrayList<>();
        if (documentFileList != null && !documentFileList.isEmpty()) {
            List<String> ids = new ArrayList<>();
            for (DocumentFile documentFile : documentFileList) {
                if (documentFile != null && documentFile.getURI() != null && !documentFile.getURI().isEmpty()) {
                    ids.add(documentFile.getURI());
                }
            }
            deletedList = this.deleteDocumentFilesByIDs(ids);
        }
        LOGGER.debug("deleteDocumentFiles end");
        return deletedList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentFilesService#
     * deleteDocumentFilesByID(java.lang.String)
     */
    public Boolean deleteDocumentFilesByID(final String id) throws TechnicalException, FunctionalException {

        LOGGER.debug("deleteDocumentFilesByID called");
        // validate input
        if (id == null || id.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "id");
        }
        List<String> ids = new ArrayList<>();
        ids.add(id);
        List<Boolean> deleteList = this.deleteDocumentFilesByIDs(ids);
        if (deleteList.isEmpty()) {
            // error 1 documentFile expected 0 are returned.
            throw new TechnicalException(ErrorCode.TE002);
        }
        // extract result
        Boolean deleted = deleteList.get(0);
        LOGGER.debug("deleteDocumentFilesByID end");
        return deleted;
    }

}
