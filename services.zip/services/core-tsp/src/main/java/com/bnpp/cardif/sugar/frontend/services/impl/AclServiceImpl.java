package com.bnpp.cardif.sugar.frontend.services.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.bnpparibas.assurance.sugar.internal.service.app.acl.v1.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenCreator;
import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.AclService;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;

import javax.annotation.Nonnull;

/**
 * 
 * @author 831743
 *
 */
@Service("aclService")
@Scope("singleton")
public class AclServiceImpl extends FrontendGenericServiceImpl implements AclService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AclServiceImpl.class);

    private static final String ACL_ISSUER = "Arondor";

    private static final String ACL_SCHEME = "DefaultScheme";

    @Autowired
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.AclService#getAllAclList()
     */
    public List<AccessControlList> getAllAclList() throws TechnicalException, FunctionalException {

        LOGGER.debug("getAllAclList called");
        List<AccessControlList> aclList = null;
        // call webService
        try {
            SugarAcl service = sugarWebServiceClientFactory.getSugarAclWSP();
            TokenType securityToken = TokenCreator.getTokenType();
            GetAllRequest parameters = new GetAllRequest();
            parameters.setScope(this.getScope());
            GetAllResponse result = service.getAll(parameters, securityToken);
            if (result != null) {
                aclList = result.getAccessControlList();
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("getAllAclList end");
        return aclList;
    }

    private List<AccessControlList> getAclListByClassIds(List<ClassId> idList, boolean isInstanceValue)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("getAclListByClassIds called");
        List<AccessControlList> aclList = null;
        if (idList == null || idList.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "idList");
        }
        // call webService
        SugarAcl service = sugarWebServiceClientFactory.getSugarAclWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        try {
            GetByClassIdRequest parameters = new GetByClassIdRequest();
            parameters.setScope(this.getScope());
            parameters.setIsInstanceValue(isInstanceValue);
            List<ClassId> classIds = parameters.getClassId();
            classIds.addAll(idList);
            GetByClassIdResponse result = service.getByClassId(parameters, securityToken);
            if (result != null) {
                aclList = result.getAccessControlList();
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("getAclListByClassIds end");
        return aclList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.AclService#getAclListByClassId(
     * java.lang.String, int)
     */
    public AccessControlList getAclListByClassId(String id, int version, boolean isInstanceValue)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("getAclListByClassId called");
        if (id == null || id.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "id");
        }
        // build ClassId list
        List<ClassId> classIds = new ArrayList<>();
        ClassId classId = new ClassId(id, ISSUER, version);
        classIds.add(classId);
        List<AccessControlList> aclList = this.getAclListByClassIds(classIds, isInstanceValue);
        if (aclList == null || aclList.isEmpty()) {
            // error 1 acl expected 0 are returned.
            throw new TechnicalException(ErrorCode.TE002);
        }
        if (aclList.size() > 1) {
            // error 1 acl expected many are returned.
            throw new TechnicalException(ErrorCode.TE001);
        }
        LOGGER.debug("getAclListByClassId end");
        return aclList.get(0);
    }

    private List<AccessControlList> getAclListByBasketIds(List<BasketId> idList)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("getAclListByBasketIds called");
        List<AccessControlList> aclList = null;
        if (idList == null || idList.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "idList");
        }
        // call webService
        SugarAcl service = sugarWebServiceClientFactory.getSugarAclWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        try {
            GetByBasketIdRequest parameters = new GetByBasketIdRequest();
            parameters.setScope(this.getScope());
            List<BasketId> classIds = parameters.getBasketId();
            classIds.addAll(idList);
            GetByBasketIdResponse result = service.getByBasketId(parameters, securityToken);
            if (result != null) {
                aclList = result.getAccessControlList();
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("getAclListByBasketIds end");
        return aclList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.AclService#getAclListByBasketId(
     * java.lang.String)
     */
    public AccessControlList getAclListByBasketId(String id) throws TechnicalException, FunctionalException {

        LOGGER.debug("getAclListByBasketId called");
        if (id == null || id.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "id");
        }
        // build ClassId list
        List<BasketId> basketIds = new ArrayList<>();
        BasketId basketId = new BasketId(id, ISSUER, SCHEME);
        basketIds.add(basketId);
        List<AccessControlList> aclList = this.getAclListByBasketIds(basketIds);
        if (aclList == null || aclList.isEmpty()) {
            // error 1 acl expected 0 are returned.
            throw new TechnicalException(ErrorCode.TE002);
        }
        if (aclList.size() > 1) {
            // error 1 acl expected many are returned.
            throw new TechnicalException(ErrorCode.TE001);
        }
        LOGGER.debug("getAclListByBasketId end");
        return aclList.get(0);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.AclService#getAclByBuisnessScope(
     * )
     */
    public AccessControlList getDefaultAclByBuisnessScope() throws TechnicalException, FunctionalException {

        LOGGER.debug("getDefaultAclByBuisnessScope called");
        AccessControlList aclValue = null;
        // call webService
        SugarAcl service = sugarWebServiceClientFactory.getSugarAclWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        try {
            GetDefaultRequest parameters = new GetDefaultRequest();
            parameters.setScope(this.getScope());
            GetDefaultResponse result = service.getDefault(parameters, securityToken);
            if (result != null) {
                aclValue = result.getAccessControlList();
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("getDefaultAclByBuisnessScope end");
        return aclValue;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.AclService#assignAclToClassId(
     * java.lang.String, java.lang.String, int, boolean)
     */
    public AccessControlList assignAclToClassId(String inputAclId, String inputClassId, int inputClassVersion,
            boolean isInstanceValue) throws TechnicalException, FunctionalException {

        LOGGER.debug("assignAclToClassId called");
        AccessControlList assignedAcl = null;
        if (inputAclId == null || inputAclId.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "inputAclId");
        }
        if (inputClassId == null || inputClassId.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "inputClassId");
        }
        // call webService
        SugarAcl service = sugarWebServiceClientFactory.getSugarAclWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        try {
            AssignToClassRequest parameters = new AssignToClassRequest();
            parameters.setScope(this.getScope());
            parameters.setIsInstanceValue(isInstanceValue);
            AclId aclId = new AclId(inputAclId, ACL_ISSUER, ACL_SCHEME);
            parameters.setAclId(aclId);
            ClassId classId = new ClassId(inputClassId, ISSUER, inputClassVersion);
            parameters.setClassId(classId);
            AssignToClassResponse result = service.assignToClass(parameters, securityToken);
            if (result != null) {
                assignedAcl = result.getAccessControlList();
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("assignAclToClassId end");
        return assignedAcl;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.AclService#assignAclToBasketId(
     * java.lang.String, java.lang.String)
     */
    public AccessControlList assignAclToBasketId(String inputAclId, String inputBasketId)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("assignAclToBasketId called");
        AccessControlList assignedAcl = null;
        if (inputAclId == null || inputAclId.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "inputAclId");
        }
        if (inputBasketId == null || inputBasketId.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + "inputBasketId");
        }
        // call webService
        SugarAcl service = sugarWebServiceClientFactory.getSugarAclWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        try {
            AssignToBasketRequest parameters = new AssignToBasketRequest();
            parameters.setScope(this.getScope());
            parameters.setIsInstanceValue(false);
            AclId aclId = new AclId(inputAclId, ACL_ISSUER, ACL_SCHEME);
            parameters.setAclId(aclId);
            BasketId basketId = new BasketId(inputBasketId, ISSUER, SCHEME);
            parameters.setBasketId(basketId);
            AssignToBasketResponse result = service.assignToBasket(parameters, securityToken);
            if (result != null) {
                assignedAcl = result.getAccessControlList();
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("assignAclToBasketId end");
        return assignedAcl;
    }

    @Override public AccessControlList assignBusinessScopeACL(@Nonnull String scope, @Nonnull String aclId)
            throws TechnicalException, FunctionalException {

        SugarAcl service = sugarWebServiceClientFactory.getSugarAclWSP();
        TokenType securityToken = TokenCreator.getTokenType();
        ChangeDefaultAclRequest parameters = new ChangeDefaultAclRequest();
        parameters.setScope(scope);
        parameters.setAclId(new AclId(aclId, ACL_ISSUER, ACL_SCHEME));
        AccessControlList assignedAcl = null;
        try {
            Optional<ChangeDefaultAclResponse> response = Optional.ofNullable(service.changeDefaultAcl(parameters, securityToken));
            assignedAcl = response.isPresent() ? response.get().getAccessControlList() : null;
        }
        catch (TechFaultMessage techFaultMessage) {
            generateTechnicalException(techFaultMessage);
        }
        catch (FuncFaultMessage funcFaultMessage) {
            generateFunctionalException(funcFaultMessage);
        }
        return assignedAcl;
    }
}
