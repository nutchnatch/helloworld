package com.bnpp.cardif.sugar.frontend.services.impl;

import java.time.LocalDateTime;
import java.util.List;

import com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode;
import com.bnpp.cardif.sugar.utils.DateUtils;
import com.bnpparibas.assurance.sugar.internal.service.app.track.v1.SearchRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.track.v1.SearchResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.track.v1.SugarTrack;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenCreator;
import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.ReportingService;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.BasketRatio;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.DocumentStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.EnvelopeFlows;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.FolderStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.Summary;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetBasketRatioRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetBasketRatioResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetDocumentStockIndicatorRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetDocumentStockIndicatorResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetEnvelopeFlowsRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetEnvelopeFlowsResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetFolderStockIndicatorRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetFolderStockIndicatorResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetReportingSummaryRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.GetReportingSummaryResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.reporting.v1.SugarReporting;
import org.springframework.web.client.RestTemplate;

import javax.xml.datatype.DatatypeConfigurationException;

/**
 * 
 * @author 831743
 *
 */
@Service("reportingService")
@Scope("singleton")
public class ReportingServiceImpl extends FrontendGenericServiceImpl implements ReportingService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ReportingServiceImpl.class);

    private static final String STARTING_DATE = "startingDate";

    private static final String ENDING_DATE = "endingDate";

    @Autowired
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    @Autowired
    private RestTemplate restTemplate;

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.ReportingService#
     * getBasketRatioIndicators(java.lang.String, java.lang.String)
     */
    public List<BasketRatio> getBasketRatioIndicators(String startingDate, String endingDate)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("getBasketRatioIndicators called");
        List<BasketRatio> basketRatioList = null;
        if (startingDate == null || startingDate.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + STARTING_DATE);
        }
        if (endingDate == null || endingDate.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + ENDING_DATE);
        }
        // call webService
        try {
            SugarReporting service = sugarWebServiceClientFactory.getSugarReportingWSP();
            TokenType securityToken = TokenCreator.getTokenType();
            GetBasketRatioRequest parameters = new GetBasketRatioRequest();
            parameters.setScope(this.getScope());
            parameters.setStartingDate(startingDate);
            parameters.setEndingDate(endingDate);
            GetBasketRatioResponse result = service.getBasketRatioIndicators(parameters, securityToken);
            if (result != null) {
                basketRatioList = result.getBasketRatio();
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("getBasketRatioIndicators end");
        return basketRatioList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.ReportingService#
     * getDocumentStockIndicators(java.lang.String, java.lang.String)
     */
    public List<DocumentStock> getDocumentStockIndicators(String startingDate, String endingDate)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("getDocumentStockIndicators called");
        List<DocumentStock> documentStockList = null;
        if (startingDate == null || startingDate.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + STARTING_DATE);
        }
        if (endingDate == null || endingDate.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + ENDING_DATE);
        }
        // call webService
        try {
            SugarReporting service = sugarWebServiceClientFactory.getSugarReportingWSP();
            TokenType securityToken = TokenCreator.getTokenType();
            GetDocumentStockIndicatorRequest parameters = new GetDocumentStockIndicatorRequest();
            parameters.setScope(this.getScope());
            parameters.setStartingDate(startingDate);
            parameters.setEndingDate(endingDate);
            GetDocumentStockIndicatorResponse result = service.getDocumentStockIndicators(parameters, securityToken);
            if (result != null) {
                documentStockList = result.getDocumentStock();
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("getDocumentStockIndicators end");
        return documentStockList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.ReportingService#
     * getEnvelopeFlowsIndicators(java.lang.String, java.lang.String)
     */
    public List<EnvelopeFlows> getEnvelopeFlowsIndicators(String startingDate, String endingDate)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("getEnvelopeFlowsIndicators called");
        List<EnvelopeFlows> envelopeFlowsList = null;
        if (startingDate == null || startingDate.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + STARTING_DATE);
        }
        if (endingDate == null || endingDate.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + ENDING_DATE);
        }
        // call webService
        try {
            SugarReporting service = sugarWebServiceClientFactory.getSugarReportingWSP();
            TokenType securityToken = TokenCreator.getTokenType();
            GetEnvelopeFlowsRequest parameters = new GetEnvelopeFlowsRequest();
            parameters.setScope(this.getScope());
            parameters.setStartingDate(startingDate);
            parameters.setEndingDate(endingDate);
            GetEnvelopeFlowsResponse result = service.getEnvelopeFlowsIndicators(parameters, securityToken);
            if (result != null) {
                envelopeFlowsList = result.getEnvelopeFlows();
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("getEnvelopeFlowsIndicators end");
        return envelopeFlowsList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.ReportingService#
     * getFolderStockIndicators(java.lang.String, java.lang.String)
     */
    public List<FolderStock> getFolderStockIndicators(String startingDate, String endingDate)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("getFolderStockIndicators called");
        List<FolderStock> folderStockList = null;
        if (startingDate == null || startingDate.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + STARTING_DATE);
        }
        if (endingDate == null || endingDate.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + ENDING_DATE);
        }
        // call webService
        try {
            SugarReporting service = sugarWebServiceClientFactory.getSugarReportingWSP();
            TokenType securityToken = TokenCreator.getTokenType();
            GetFolderStockIndicatorRequest parameters = new GetFolderStockIndicatorRequest();
            parameters.setScope(this.getScope());
            parameters.setStartingDate(startingDate);
            parameters.setEndingDate(endingDate);
            GetFolderStockIndicatorResponse result = service.getFolderStockIndicators(parameters, securityToken);
            if (result != null) {
                folderStockList = result.getFolderStock();
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("getFolderStockIndicators end");
        return folderStockList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.ReportingService#
     * getReportingSummary()
     */
    public Summary getReportingSummary() throws TechnicalException, FunctionalException {

        LOGGER.debug("getReportingSummary called");
        Summary summary = null;
        // call webService
        try {
            SugarReporting service = sugarWebServiceClientFactory.getSugarReportingWSP();
            TokenType securityToken = TokenCreator.getTokenType();
            GetReportingSummaryRequest parameters = new GetReportingSummaryRequest();
            parameters.setScope(this.getScope());
            GetReportingSummaryResponse result = service.getReportingSummary(parameters, securityToken);
            if (result != null) {
                summary = result.getSummary();
            }
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        LOGGER.debug("getReportingSummary end");
        return summary;
    }

    @Override
    public String getTraceLogFile(final LocalDateTime startDateTime, final LocalDateTime endDateTime, final String objectId, final String userId) throws TechnicalException, FunctionalException {

        LOGGER.debug("getTraceLogEntries called");
        // call webService
        try {
            final SugarTrack service = sugarWebServiceClientFactory.getSugarTrackWSP();
            final TokenType securityToken = TokenCreator.getTokenType();
            final SearchRequest request = new SearchRequest();
            request.setScope(this.getScope());
            request.setUserId(userId);
            request.setObjectId(objectId);
            request.setStartDate(DateUtils.toXmlGregorianCalendar(startDateTime));
            request.setEndDate(DateUtils.toXmlGregorianCalendar(endDateTime));

            final SearchResponse response = service.search(request, securityToken);

            if (response != null)
            {
                return response.getTrackReport();
            }
        }
        catch (final TechFaultMessage e) {
            generateTechnicalException(e);
        }
        catch (final FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (final DatatypeConfigurationException e) {
            throw new TechnicalException(TechnicalErrorCode.T01101.name(), "Unable to convert the date", e);
        }
        LOGGER.debug("getTraceLogEntries end");
        return "";
    }

}
