package com.bnpp.cardif.sugar.frontend.services.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.bnpp.cardif.sesame.security.soap.TokenCreator;
import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.BuisnessRulesService;
import com.bnpp.cardif.sugar.frontend.services.DocumentFilesService;
import com.bnpp.cardif.sugar.frontend.services.DocumentService;
import com.bnpp.cardif.sugar.frontend.services.model.PagingList;
import com.bnpp.cardif.sugar.security.AuthenticatedUser;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DocumentStatusType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ElectronicDocumentDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tags;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.ChildObject;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.FileData;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Item;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.FuncFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.AddChildRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.AddChildResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.DeleteRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.FindRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.FindResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.GetRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.GetResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.ReindexRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.ReindexResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.StoreRequest;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.StoreResponse;
import com.bnpparibas.assurance.sugar.internal.service.app.document.v1.SugarDocument;

/**
 * 
 * @author 831743
 *
 */
@Service("documentService")
@Scope("singleton")
public class DocumentServiceImpl extends FrontendGenericServiceImpl implements DocumentService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentServiceImpl.class);

    @Autowired
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    @Autowired
    private BuisnessRulesService buisnessRulesService;

    @Autowired
    private DocumentFilesService documentFilesService;

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.DocumentService#getDocumentByID(
     * java.lang.String, java.lang.String, java.lang.String)
     */
    public Document getDocumentByID(final String id) throws TechnicalException, FunctionalException {
        return this.getDocumentByID(id, false);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentService#
     * getDocumentWithChildByID(java.lang.String)
     */
    public Document getDocumentWithChildByID(final String id) throws TechnicalException, FunctionalException {
        return this.getDocumentByID(id, true);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.DocumentService#getDocumentByIDs(
     * java.util.List)
     */
    public List<Document> getDocumentByIDs(final List<String> ids) throws TechnicalException, FunctionalException {
        return this.getDocumentByIDs(ids, false);
    }

    private Document getDocumentByID(final String id, final boolean includeChild)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("getDocumentByID called");
        // validate input
        this.validateInputDocumentById(id);
        // create Input
        List<String> ids = new ArrayList<>();
        ids.add(id);
        // call
        List<Document> documentList = this.getDocumentByIDs(ids, includeChild);
        if (documentList == null || documentList.isEmpty()) {
            // error 1 document expected 0 are returned.
            throw new TechnicalException(ErrorCode.TE002);
        }
        // extract result
        Document document = documentList.get(0);
        LOGGER.debug("getDocumentByID end");
        return document;
    }

    private List<Document> getDocumentByIDs(final List<String> ids, final boolean includeChild)
            throws TechnicalException, FunctionalException {

        LOGGER.debug("getDocumentByIDs called with values : {}", ids);
        List<Document> documentList = new ArrayList<>();
        // validate input
        validateInputDocumentByIds(ids);
        // call webService
        SugarDocument service = sugarWebServiceClientFactory.getSugarDocumentWSP();
        GetRequest parameters = new GetRequest();
        parameters.setIncludeChild(includeChild);
        parameters.setIncludeFile(false);
        parameters.setScope(getScope());
        List<Id> idList = parameters.getId();
        if (idList == null) {
            idList = new ArrayList<>();
        }
        for (String id : ids) {
            Id documentId = new Id(id, ISSUER, SCHEME);
            idList.add(documentId);
        }
        TokenType securityToken = TokenCreator.getTokenType();
        try {
            GetResponse result = service.get(parameters, securityToken);
            documentList = result.getDocument();
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("getDocumentByIDs end");
        return documentList;
    }

    private void validateInputDocumentByIds(final List<String> ids) throws InvalidInputException {
        if (ids == null || ids.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "IDs");
        }
    }

    private void validateInputDocumentById(final String id) throws InvalidInputException {
        if (id == null || id.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "ID");
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.DocumentService#findDocuments(
     * long, long, java.lang.String, java.util.List,
     * com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause)
     */
    public PagingList<Document> findDocuments(long start, long maximum, String quickSearchValue,
            List<Criterion> criterionList, OrderClause orderClause) throws TechnicalException, FunctionalException {
        return this.findDocuments(start, maximum, quickSearchValue, criterionList, orderClause, false, Item.DOCUMENT);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.DocumentService#findEnvelopes(
     * long, long, java.lang.String, java.util.List,
     * com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause)
     */
    public PagingList<Document> findEnvelopes(long start, long maximum, String quickSearchValue,
            List<Criterion> criterionList, OrderClause orderClause) throws TechnicalException, FunctionalException {
        return this.findDocuments(start, maximum, quickSearchValue, criterionList, orderClause, true, Item.ENVELOPE);
    }

    private PagingList<Document> findDocuments(long start, long maximum, String quickSearchValue,
            List<Criterion> criterionList, OrderClause orderClause, boolean includeChild, Item doctype)
            throws TechnicalException, FunctionalException {

        PagingList<Document> documentList = null;
        List<Criterion> searchCriterionList = new ArrayList<>();
        // validate input
        this.validateInputFindDocuments(start, maximum, doctype);
        // call web service
        try {
            TokenType securityToken = TokenCreator.getTokenType();
            SugarDocument service = sugarWebServiceClientFactory.getSugarDocumentWSP();
            FindRequest requestParam = new FindRequest();
            requestParam.setIncludeChild(includeChild);
            requestParam.setIncludeFiles(false);
            // paging
            requestParam.setStart(start);
            requestParam.setMax(maximum);
            buildSearchCriteria(quickSearchValue, criterionList, searchCriterionList);
            // search criteria
            Criteria searchCriteria = new Criteria(searchCriterionList, doctype, false);
            requestParam.setCriteria(searchCriteria);
            // ordering
            if (orderClause == null) {
                orderClause = generateDefaultOrderClause();
            }
            requestParam.setOrder(orderClause);
            LOGGER.info("findDocuments Starting search for {} documents and criteria {} with order {}", maximum - start,
                    searchCriteria, orderClause);
            FindResponse result = service.find(requestParam, securityToken);
            if (result != null && result.getDocument() != null) {
                documentList = new PagingList<>();
                documentList.setItemList(result.getDocument());
                documentList.setItemMax(result.getMaxSearch());
                documentList.setItemNumber(result.getFound());
            }
            else {
                documentList = new PagingList<>();
            }
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        return documentList;
    }

    private void validateInputFindDocuments(long start, long maximum, Item doctype) throws InvalidInputException {
        if (start < 0) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "start");
        }
        if (maximum < 1) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "maximum");
        }
        if (doctype == null) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "doctype");
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.DocumentService#reindexDocument(
     * java.util.List)
     */
    public List<Document> reindexDocument(List<Document> inputDocumentlist)
            throws FunctionalException, TechnicalException {

        LOGGER.debug("reindexDocument called with values : {}", inputDocumentlist);
        List<Document> outPutDocumentList = null;
        // validate input
        this.validateInput4ReindexDocument(inputDocumentlist);
        AuthenticatedUser currentUser = this.getCurrentUser();
        // first we get the existing documents (including child docs)
        List<String> ids = extractDocIds(inputDocumentlist);
        List<Document> initialDocumentList = this.getDocumentByIDs(ids);
        if (initialDocumentList != null && !initialDocumentList.isEmpty()) {
            // Now update the existing documents using the passed data.
            for (Document existingDocument : initialDocumentList) {
                String existingDocId = existingDocument.getId().getValue();
                for (Document newDocument : inputDocumentlist) {
                    // find the matching "new document"
                    if (newDocument != null && newDocument.getId() != null && newDocument.getId().getValue() != null
                            && newDocument.getId().getValue().equals(existingDocId)) {
                        // document found : updating
                        updateDocumentData(existingDocument, newDocument, currentUser);
                        updateDocumentStatus(existingDocument, newDocument);
                        updateDocumentTags(existingDocument, newDocument);
                        updateDocumentComputedFields(existingDocument);
                    }
                }
            }
            // call service for document update.
            outPutDocumentList = this.callReindexDocument(initialDocumentList);
        } else {
            throw new FunctionalException(ErrorCode.FE007);
        }
        LOGGER.debug("reindexDocument end");
        return outPutDocumentList;
    }

    private void updateDocumentComputedFields(Document existingDocument)
            throws FunctionalException, TechnicalException {

        // computed update
        ElectronicDocumentDataType existingDocData = existingDocument.getData();
        if (existingDocData != null) {

            // check childObject validityCode
            ValdtyCode childValidityCode = checkChildObjectValidity(existingDocument);
            // if child object validity code is not valid, then apply it to main
            // object.
            ValdtyCode newValidityCode = null;
            if (!ValdtyCode.VALID.equals(childValidityCode)) {
                newValidityCode = childValidityCode;
            }
            else {
                // compute code for main object
                newValidityCode = buisnessRulesService.computeValidityCode(existingDocument);
            }
            // cannot invalidate a document
            if (ValdtyCode.VALID.equals(existingDocData.getValidityCode())
                    && !ValdtyCode.VALID.equals(newValidityCode)) {
                throw new FunctionalException(ErrorCode.FE001);
            }
            existingDocData.setValidityCode(newValidityCode);
        }
        else {
            throw new FunctionalException(ErrorCode.FE002);
        }
        // RetentionEndDate is computed at backend level.
    }

    private ValdtyCode checkChildObjectValidity(Document existingDocument)
            throws TechnicalException, FunctionalException {

        ValdtyCode childValidityCode = ValdtyCode.VALID;
        ChildObject childObject = existingDocument.getChildObject();
        if (childObject != null) {
            List<Id> childDocIdlist = childObject.getId();
            if (childDocIdlist != null && !childDocIdlist.isEmpty()) {
                List<String> childDocIds = new ArrayList<>();
                for (Id id : childDocIdlist) {
                    childDocIds.add(id.getValue());
                }
                childValidityCode = checkChildObjectValidity(childValidityCode, childDocIds);
            }
        }
        return childValidityCode;
    }

    private ValdtyCode checkChildObjectValidity(ValdtyCode childValidityCode, List<String> childDocIds)
            throws TechnicalException, FunctionalException {

        List<Document> childDocList = this.getDocumentByIDs(childDocIds);
        for (Document document : childDocList) {
            ValdtyCode currentValidityCode = document.getData().getValidityCode();
            if (ValdtyCode.UNDER_CONSTRUCTION.equals(currentValidityCode) || currentValidityCode == null) {
                childValidityCode = ValdtyCode.UNDER_CONSTRUCTION;
                break;
            }
            else if (!ValdtyCode.VALID.equals(currentValidityCode)) {
                childValidityCode = ValdtyCode.INVALID;
            }
        }
        return childValidityCode;
    }

    private void updateDocumentTags(Document existingDocument, Document newDocument) {

        Tags existingTags = existingDocument.getTags();
        if (existingTags != null) {
            List<Tag> existingTagList = existingTags.getTag();
            // clear the existing tag list
            existingTagList.clear();
        }
        else {
            existingTags = new Tags();
            existingDocument.setTags(existingTags);
        }
        if (newDocument.getTags() != null && newDocument.getTags().getTag() != null) {
            LOGGER.debug("new tag list : {}", newDocument.getTags().getTag());
            List<Tag> existingTagList = existingTags.getTag();
            LOGGER.debug("existing tag list : {}", existingTagList);
            existingTagList.addAll(newDocument.getTags().getTag());
        }
    }

    private void updateDocumentStatus(Document existingDocument, Document newDocument) {

        DocumentStatusType existingStatusData = existingDocument.getStatus();
        DocumentStatusType newStatusData = newDocument.getStatus();
        // if the status has changed
        if (newStatusData != null && newStatusData.getCode() != null
                && !newStatusData.getCode().equals(existingStatusData.getCode())) {
            // save the previous status
            existingStatusData.setPrevStatus(existingStatusData.getCode());
            // set the new value
            existingStatusData.setCode(newStatusData.getCode());
            // set the change date
            if (existingStatusData.getEffctveDate() != null) {
                existingStatusData.setPrevStatusEffctveDate(existingStatusData.getEffctveDate());
            }
            existingStatusData.setEffctveDate(new Date());
            // set the reason
            existingStatusData.setChngeReasn(newStatusData.getChngeReasn());
        }
    }

    private void updateDocumentData(Document existingDocument, Document newDocument, AuthenticatedUser currentUser) {

        ElectronicDocumentDataType existingDocData = existingDocument.getData();
        ElectronicDocumentDataType newDocData = newDocument.getData();
        if (newDocData != null && existingDocData != null) {
            // Update docuyment class if needed
            ClassId existingClassId = existingDocData.getClassId();
            ClassId newClassId = newDocData.getClassId();
            if (newClassId != null && !newClassId.equals(existingClassId)) {
                existingDocData.setClassId(newClassId);
            }
            // update data
            existingDocData.setConfdntltyLvl(newDocData.getConfdntltyLvl());
            existingDocData.setDirectionCode(newDocData.getDirectionCode());
            existingDocData.setLangCode(newDocData.getLangCode());
            existingDocData.setName(newDocData.getName());
            existingDocData.setPageCount(newDocData.getPageCount());
            existingDocData.setReciptDate(newDocData.getReciptDate());
            existingDocData.setRetentionStartDate(newDocData.getRetentionStartDate());
            existingDocData.setSndngDate(newDocData.getSndngDate());
            existingDocData.setValdtyEndDate(newDocData.getValdtyEndDate());
            // static update
            existingDocData.setLastModifier(currentUser.getUsername());
        }
        else {
            LOGGER.warn("No updateDocumentData one of the data object is null");
        }
    }

    private List<String> extractDocIds(List<Document> inputDocumentlist) {

        List<String> ids = new ArrayList<>();
        for (Document document : inputDocumentlist) {
            if (document != null && document.getId() != null) {
                ids.add(document.getId().getValue());
            }
        }
        return ids;
    }

    private void validateInput4ReindexDocument(List<Document> inputDocumentlist) throws InvalidInputException {
        if (inputDocumentlist == null || inputDocumentlist.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + "inputDocumentlist");
        }
    }

    private void applyDefaultValues(AuthenticatedUser currentUser, Document newDocument) {
        if (newDocument != null) {
            // document found : updating
            createDocumentData(newDocument);
            createDocumentStatus(newDocument);
            createDocumentComputedFields(newDocument);
            createChildData(newDocument, currentUser);
        }
    }

    private void createChildData(Document newDocument, AuthenticatedUser currentUser) {
        ChildObject docChildObject = newDocument.getChildObject();
        if (docChildObject == null) {
            docChildObject = new ChildObject();
            newDocument.setChildObject(docChildObject);
        }
        else {
            List<Document> childDocumentList = docChildObject.getDocument();
            for (Document document : childDocumentList) {
                // recursive call on the child documents
                applyDefaultValues(currentUser, document);
            }
        }
    }

    private void createDocumentComputedFields(Document newDocument) {
        ElectronicDocumentDataType docData = newDocument.getData();
        if(docData.getValidityCode() == null) {
            docData.setValidityCode(ValdtyCode.UNDER_CONSTRUCTION);
        }
    }

    private void createDocumentStatus(Document newDocument) {
        DocumentStatusType docStatus = newDocument.getStatus();
        if (docStatus == null) {
            docStatus = new DocumentStatusType();
            newDocument.setStatus(docStatus);
        }
    }

    private void createDocumentData(Document newDocument) {
        ElectronicDocumentDataType docData = newDocument.getData();
        if (docData == null) {
            docData = new ElectronicDocumentDataType();
            newDocument.setData(docData);
        }
    }

    private List<Document> storeEnvelope(Document envelope, List<Document> documentList,
            List<DocumentFile> documentFileList) throws TechnicalException {

        List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> result = null;
        if (documentList.size() != documentFileList.size()) {
            // Document and DocumentFile lists do not have the same size, it is
            // inconsistent
            throw new TechnicalException(ErrorCode.TE003.getCode(),
                    "Document and DocumentFile lists do not have the same size, it is inconsistent");
        }
        try {
            AuthenticatedUser currentUser = this.getCurrentUser();
            // Now create the list of documents with the files
            for (int i = 0; i < documentList.size(); i++) {
                Document currentDoc = documentList.get(i);
                DocumentFile documentFile = documentFileList.get(i);
                // attach the file to doc
                this.attachFileToDoc(documentFile, currentDoc);
            }
            // add the document into the envelope
            this.addDocumentToEnvelope(envelope, documentList);
            // add the default values on envelope and child documents
            applyDefaultValues(currentUser, envelope);
            // store everything
            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> inputDocumentlist = new ArrayList<>();
            inputDocumentlist.add(envelope);
            result = this.callStoreDocuments(inputDocumentlist);
        }
        catch (Exception e) {
            // in case of error during envelope creation we delete the
            // document file
            try {
                documentFilesService.deleteDocumentFiles(documentFileList);
            }
            catch (Exception ex) {
                LOGGER.error("Error deleting the documentFileList", ex);
            }
            throw new TechnicalException(ErrorCode.TE003.getCode(), "Error creating the envelope in database.", e);
        }
        return result;
    }

    private void addDocumentToEnvelope(Document envelope, List<Document> inputDocumentList) {

        ChildObject childObject = envelope.getChildObject();
        if (childObject == null) {
            childObject = new ChildObject();
            envelope.setChildObject(childObject);
        }
        List<Document> documentList = childObject.getDocument();
        documentList.addAll(inputDocumentList);
    }

    private void attachFileToDoc(DocumentFile documentFile, Document backendDoc) {

        if (documentFile != null && backendDoc != null) {
            // attach the matching documentFile to the document
            FileData fileData = new FileData();
            List<String> fileURIList = fileData.getURI();
            if (fileURIList == null) {
                fileURIList = new ArrayList<>();
            }
            fileURIList.add(documentFile.getURI());
            backendDoc.setFileData(fileData);
        }
    }

    private List<Document> callStoreDocuments(List<Document> inputDocumentlist)
            throws FunctionalException, TechnicalException {

        LOGGER.debug("storeDocuments called");
        List<Document> outPutDocumentList = new ArrayList<>();
        // call web service
        try {
            TokenType securityToken = TokenCreator.getTokenType();
            SugarDocument service = sugarWebServiceClientFactory.getSugarDocumentWSP();
            // Create the documents using the passed data.
            StoreRequest parameters = new StoreRequest();
            List<Document> documentList = parameters.getDocument();
            documentList.addAll(inputDocumentlist);
            StoreResponse result = service.store(parameters, securityToken);
            outPutDocumentList = result.getDocument();
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("storeDocuments end");
        return outPutDocumentList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentService#
     * createEnvelopeWithFile(com.bnpparibas.assurance.ea.internal.schema.mco.
     * documentfile.v1.DocumentFile,
     * com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document,
     * com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document)
     */
    public List<Document> createEnvelopeWithFile(List<DocumentFile> inputDocFileList, Document defaultEnvelope,
            List<Document> defaultDocumentList) throws TechnicalException, FunctionalException {

        List<Document> backendDocList = null;
        // Creating the document file
        List<DocumentFile> documentFileList = documentFilesService.createDocumentFiles(inputDocFileList);
        if (documentFileList != null && !documentFileList.isEmpty() && documentFileList.get(0) != null) {
            backendDocList = this.storeEnvelope(defaultEnvelope, defaultDocumentList, documentFileList);
        }
        else {
            throw new TechnicalException(ErrorCode.TE002.getCode(),
                    "Error, DocumentFile creation should return the created object.");
        }
        return backendDocList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.frontend.services.DocumentService#addFileToEnvelope
     * (com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.
     * DocumentFile, java.lang.String,
     * com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document)
     */
    public List<Document> addFileToEnvelope(List<DocumentFile> inputDocFileList, String envelopeId,
            List<Document> defaultDocumentList) throws TechnicalException, FunctionalException {

        List<Document> backendDocList = null;
        // get the existing envelope
        Document existingEnvelope = this.getDocumentByID(envelopeId, true);
        // test an envelope is found
        if (existingEnvelope == null) {
            throw new FunctionalException(ErrorCode.IIE009.getCode(),
                    "addFileToEnvelope : No envelope found with the passed ID.");
        }
        // test the existing document is an envelope
        if (!Category.ENVELOPE.equals(existingEnvelope.getCategory())) {
            throw new FunctionalException(ErrorCode.IIE009.getCode(),
                    "addFileToEnvelope : The passed ID is a document ID not an envelope one.");
        }
        // Creating the document file
        List<DocumentFile> documentFileList = documentFilesService.createDocumentFiles(inputDocFileList);
        if (documentFileList != null && !documentFileList.isEmpty() && documentFileList.get(0) != null) {
            backendDocList = this.updateEnvelope(existingEnvelope, defaultDocumentList, documentFileList);
        }
        else {
            throw new TechnicalException(ErrorCode.TE002.getCode(),
                    "Error, DocumentFile creation should return the created object.");
        }
        return backendDocList;
    }

    private List<Document> updateEnvelope(Document envelope, List<Document> documentList,
            List<DocumentFile> documentFileList) throws TechnicalException {

        List<Document> result = null;
        if (documentList.size() != documentFileList.size()) {
            // Document and DocumentFile lists do not have the same size, it is
            // inconsistent
            throw new TechnicalException(ErrorCode.TE003.getCode(),
                    "Document and DocumentFile lists do not have the same size, it is inconsistent");
        }
        try {
            AuthenticatedUser currentUser = this.getCurrentUser();
            // Now create the list of documents with the files
            for (int i = 0; i < documentList.size(); i++) {
                Document currentDoc = documentList.get(i);
                DocumentFile documentFile = documentFileList.get(i);
                // attach the file to doc
                this.attachFileToDoc(documentFile, currentDoc);
                // add the default values on the new document
                applyDefaultValues(currentUser, currentDoc);
            }
            // add the document into the envelope
            this.addDocumentToEnvelope(envelope, documentList);
            // update envelope to save the new document
            List<Document> inputDocumentlist = new ArrayList<>();
            inputDocumentlist.add(envelope);
            result = this.callAddChildToDocument(inputDocumentlist);
        }
        catch (Exception e) {
            // in case of error during envelope creation we delete the
            // document file
            try {
                documentFilesService.deleteDocumentFiles(documentFileList);
            }
            catch (Exception ex) {
                LOGGER.error("Error deleting the documentFileList", ex);
            }
            throw new TechnicalException(ErrorCode.TE003.getCode(), "Error creating the envelope in database.", e);
        }
        return result;
    }
    
    private List<Document> callAddChildToDocument(List<Document> inputDocumentlist)
            throws FunctionalException, TechnicalException {

        LOGGER.debug("addChildToDocument called");
        List<Document> outPutDocumentList = new ArrayList<>();
        // call web service
        try {
            TokenType securityToken = TokenCreator.getTokenType();
            SugarDocument service = sugarWebServiceClientFactory.getSugarDocumentWSP();
            // Create the documents using the passed data.
            AddChildRequest parameters = new AddChildRequest();
            List<Document> documentList = parameters.getDocument();
            documentList.addAll(inputDocumentlist);
            AddChildResponse result = service.addChild(parameters, securityToken);
            outPutDocumentList = result.getDocument();
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("addChildToDocument end");
        return outPutDocumentList;
    }

    private List<Document> callReindexDocument(List<Document> inputDocumentlist)
            throws FunctionalException, TechnicalException {

        LOGGER.debug("reindexDocuments called");
        List<Document> outPutDocumentList = new ArrayList<>();
        // call web service
        try {
            TokenType securityToken = TokenCreator.getTokenType();
            SugarDocument service = sugarWebServiceClientFactory.getSugarDocumentWSP();
            // Create the documents using the passed data.
            ReindexRequest parameters = new ReindexRequest();
            List<Document> documentList = parameters.getDocument();
            documentList.addAll(inputDocumentlist);
            ReindexResponse result = service.reindex(parameters, securityToken);
            outPutDocumentList = result.getDocument();
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
        LOGGER.debug("reindexDocuments end");
        return outPutDocumentList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.bnpp.cardif.sugar.frontend.services.DocumentService#
     * getDocumentsFromEnvelope(java.lang.String)
     */
    public List<Document> getDocumentsFromEnvelope(String envelopeId) throws FunctionalException, TechnicalException {

        List<Document> backendDocList = null;
        // get the existing envelope
        Document existingEnvelope = this.getDocumentByID(envelopeId, true);
        // test an envelope is found
        if (existingEnvelope == null) {
            throw new FunctionalException(ErrorCode.IIE009.getCode(), "No envelope found with the passed ID.");
        }
        // test the existing document is an envelope
        if (!Category.ENVELOPE.equals(existingEnvelope.getCategory())) {
            throw new FunctionalException(ErrorCode.IIE009.getCode(),
                    "The passed ID is a document ID not an envelope one.");
        }
        if (existingEnvelope.getChildObject() != null) {
            backendDocList = existingEnvelope.getChildObject().getDocument();
        }
        return backendDocList;
    }

    public void deleteEnvelope(String envelopeId) throws FunctionalException, TechnicalException {

        // get the existing envelope
        Document existingEnvelope = this.getDocumentByID(envelopeId, true);
        // test an envelope is found
        if (existingEnvelope == null) {
            throw new FunctionalException(ErrorCode.IIE009.getCode(),
                    "deleteEnvelope : No envelope found with the passed ID.");
        }
        // test the existing document is an envelope
        if (!Category.ENVELOPE.equals(existingEnvelope.getCategory())) {
            throw new FunctionalException(ErrorCode.IIE009.getCode(),
                    "deleteEnvelope : The passed ID is a document ID not an envelope one.");
        }
        deleteDocumentContent(envelopeId);
    }

    private void deleteDocumentContent(String documentId)
            throws FunctionalException, TechnicalException {
        try {
            TokenType securityToken = TokenCreator.getTokenType();
            // delete the envelope
            SugarDocument documentService = sugarWebServiceClientFactory.getSugarDocumentWSP();
            DeleteRequest parameters = new DeleteRequest();
            parameters.setScope(getScope());
            List<Id> idList = parameters.getId();
            idList.add(new Id(documentId, ISSUER, SCHEME));
            documentService.delete(parameters, securityToken);
        }
        catch (FuncFaultMessage e) {
            generateFunctionalException(e);
        }
        catch (TechFaultMessage e) {
            generateTechnicalException(e);
        }
    }

    public void deleteDocument(String documentId) throws FunctionalException, TechnicalException {

        // get the existing envelope
        Document existingDocument = this.getDocumentByID(documentId, true);
        // test an envelope is found
        if (existingDocument == null) {
            throw new FunctionalException(ErrorCode.IIE009.getCode(),
                    "deleteDocument : No document found with the passed ID.");
        }
        // test the existing document is an envelope
        if (!Category.DOCUMENT.equals(existingDocument.getCategory())) {
            throw new FunctionalException(ErrorCode.IIE009.getCode(),
                    "deleteDocument : The passed ID is an envelope ID not a document one.");
        }
        deleteDocumentContent(documentId);
    }
}
