package com.ossnms.web.api.common.context;

import javax.ws.rs.core.SecurityContext;
import java.security.Principal;

/**
 * OSSNMS Web API Common implementation of the {@link SecurityContext} interface
 */
public final class SessionBasedSecurityContext implements SecurityContext {
    private SessionBasedUserPrincipal principal;


    public SessionBasedSecurityContext(SessionBasedUserPrincipal principal){
        this.principal = principal;
    }

    /**
     * {@inheritDoc}
     */
    public Principal getUserPrincipal() {
        return principal;
    }

    /**
     * {@inheritDoc}
     */
    public boolean isUserInRole(String role) {
        // no roles have been implemented just yet.
        return true;
    }

    /**
     * {@inheritDoc}
     */
    public boolean isSecure() {
        return false;
    }

    /**
     * {@inheritDoc}
     */
    public String getAuthenticationScheme() {
        return null;
    }
}
