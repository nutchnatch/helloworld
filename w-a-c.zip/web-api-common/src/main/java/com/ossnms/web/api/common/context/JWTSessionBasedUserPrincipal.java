package com.ossnms.web.api.common.context;

import com.ossnms.web.provider.common.api.security.SecurityToken;

/**
 *
 */
public final class JWTSessionBasedUserPrincipal extends SessionBasedUserPrincipal {

    private final String jwtToken;

    /**
     * Constructor
     *
     * @param username      the username which identifies the user
     * @param securityToken the security token which transports session information
     */
    public JWTSessionBasedUserPrincipal(String username, SecurityToken securityToken, String jwtToken) {
        super(username, securityToken);
        this.jwtToken = jwtToken;
    }

    /**
     *
     */
    public String getJwtToken() {
        return jwtToken;
    }
}
