package com.ossnms.web.api.common.context;


import com.ossnms.web.provider.common.api.security.SecurityToken;

import java.security.Principal;

/**
 * Extension class of {@link Principal}, which includes a Security Token
 */
public class SessionBasedUserPrincipal implements Principal {

    private String username;
    private SecurityToken securityToken;

    /**
     * Constructor
     *
     * @param username the username which identifies the user
     * @param securityToken the security token which transports session information
     */
    public SessionBasedUserPrincipal(String username, SecurityToken securityToken) {
        this.username = username;
        this.securityToken = securityToken;
    }

    /**
     * {@inheritDoc}
     */
    public String getName() {
        return username;
    }

    /**
     * Returns the security token contained in this Principal
     *
     * @return an instances of {@link SecurityToken}
     */
    public SecurityToken getSecurityToken() {
        return securityToken;
    }
}
