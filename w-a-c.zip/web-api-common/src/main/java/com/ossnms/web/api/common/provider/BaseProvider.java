package com.ossnms.web.api.common.provider;

import com.ossnms.web.api.common.context.SessionBasedUserPrincipal;
import com.ossnms.web.provider.common.api.security.SecurityToken;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.SecurityContext;

/**
 * Base class to be extended in order to provide access to the JAX-RS {@link SecurityToken}
 */
public class BaseProvider {

    @Context
    private SecurityContext securityContext;

    /**
     * @return the current Security Context
     */
    public SecurityContext getSecurityContext() {
        return securityContext;
    }

    /**
     * Gathers the current {@link SecurityToken} from the security token.
     *
     * @return if the security context is valid, returns the security context; otherwise, returns null;
     */
    public SecurityToken getSecurityToken(){
        if(securityContext.getUserPrincipal() instanceof SessionBasedUserPrincipal){
            return ((SessionBasedUserPrincipal) securityContext.getUserPrincipal()).getSecurityToken();
        }

        return null;
    }
}
