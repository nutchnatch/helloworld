package com.bnpp.cardif.yourapplication.backend.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * This class configure the Spring MVC controller context for the application.
 * 
 * This context should include all the Spring MVC controllers that will handle
 * the requests to the application.
 * 
 * The @ComponentScan is loading all configuration within the same package (and
 * child packages) as WebMvcConfiguration.
 * 
 * @author 831743
 *
 */
@EnableWebMvc
@Configuration
// in this component scan annotation, set all the packages that contains your
// MVC controllers classes.
@ComponentScan(basePackages = { "com.bnpp.cardif.yourapplication.backend.web" })
public class WebMvcConfiguration extends WebMvcConfigurerAdapter
{
    private static final Logger LOGGER = LoggerFactory.getLogger(WebMvcConfiguration.class);

    /**
     * Add handlers to serve static resources such as images, js, and, css files
     * from specific locations under web application root, the classpath, and
     * others.
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry)
    {
        LOGGER.debug("addResourceHandlers");
        // normally no static resources into backend application.
        // registry.addResourceHandler("/static/**").addResourceLocations("/static/").setCachePeriod(cachePeriod);
    }

    /**
     * Configure a handler to delegate unhandled requests by forwarding to the
     * Servlet container's "default" servlet. A common use case for this is when
     * the DispatcherServlet is mapped to "/" thus overriding the Servlet
     * container's default handling of static resources. Set default servlet
     * handler, this is the same as <mvc:default-servlet-handler/>
     */
    @Override
    public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer)
    {
        LOGGER.debug("configureDefaultServletHandling");
    }

}
