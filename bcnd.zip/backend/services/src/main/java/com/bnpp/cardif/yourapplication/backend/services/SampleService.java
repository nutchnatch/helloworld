package com.bnpp.cardif.yourapplication.backend.services;

import com.bnpp.cardif.yourapplication.beans.Sample;

/**
 * Interface for the service related to Sample Entities.
 * 
 * @author 831743
 *
 */
public interface SampleService extends BaseService<Sample>
{

}
