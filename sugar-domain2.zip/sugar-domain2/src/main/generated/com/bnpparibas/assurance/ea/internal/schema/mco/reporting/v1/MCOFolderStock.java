
package com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.google.common.base.Objects;


/**
 * <p>Java class for MCOFolderStock complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCOFolderStock"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClassId"/&gt;
 *         &lt;element name="numberOfFolders" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCOFolderStock", propOrder = {
    "classId",
    "numberOfFolders"
})
@XmlSeeAlso({
    FolderStock.class
})
public class MCOFolderStock implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ClassId", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1", required = true)
    protected ClassId classId;
    protected long numberOfFolders;

    /**
     * Default no-arg constructor
     * 
     */
    public MCOFolderStock() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MCOFolderStock(final ClassId classId, final long numberOfFolders) {
        this.classId = classId;
        this.numberOfFolders = numberOfFolders;
    }

    /**
     * Gets the value of the classId property.
     * 
     * @return
     *     possible object is
     *     {@link ClassId }
     *     
     */
    public ClassId getClassId() {
        return classId;
    }

    /**
     * Sets the value of the classId property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassId }
     *     
     */
    public void setClassId(ClassId value) {
        this.classId = value;
    }

    public boolean isSetClassId() {
        return (this.classId!= null);
    }

    /**
     * Gets the value of the numberOfFolders property.
     * 
     */
    public long getNumberOfFolders() {
        return numberOfFolders;
    }

    /**
     * Sets the value of the numberOfFolders property.
     * 
     */
    public void setNumberOfFolders(long value) {
        this.numberOfFolders = value;
    }

    public boolean isSetNumberOfFolders() {
        return true;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("classId", classId).add("numberOfFolders", numberOfFolders).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(classId, numberOfFolders);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MCOFolderStock o = ((MCOFolderStock) other);
        return (Objects.equal(classId, o.classId)&&Objects.equal(numberOfFolders, o.numberOfFolders));
    }

}
