
package com.bnpparibas.assurance.ea.internal.schema.mco.search.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for Criterion complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Criterion"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Level" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/search/v1}Levels"/&gt;
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="Operator" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/search/v1}Operators"/&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/search/v1}Types"/&gt;
 *         &lt;element name="Values" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Criterion", propOrder = {
    "level",
    "name",
    "operator",
    "type",
    "values"
})
public class Criterion implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Level", required = true)
    @XmlSchemaType(name = "string")
    protected Levels level;
    @XmlElement(name = "Name", required = true)
    protected String name;
    @XmlElement(name = "Operator", required = true)
    @XmlSchemaType(name = "string")
    protected Operators operator;
    @XmlElement(name = "Type", required = true)
    @XmlSchemaType(name = "string")
    protected Types type;
    @XmlElement(name = "Values", required = true)
    protected List<String> values;

    /**
     * Default no-arg constructor
     * 
     */
    public Criterion() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public Criterion(final Levels level, final String name, final Operators operator, final Types type, final List<String> values) {
        this.level = level;
        this.name = name;
        this.operator = operator;
        this.type = type;
        this.values = values;
    }

    /**
     * Gets the value of the level property.
     * 
     * @return
     *     possible object is
     *     {@link Levels }
     *     
     */
    public Levels getLevel() {
        return level;
    }

    /**
     * Sets the value of the level property.
     * 
     * @param value
     *     allowed object is
     *     {@link Levels }
     *     
     */
    public void setLevel(Levels value) {
        this.level = value;
    }

    public boolean isSetLevel() {
        return (this.level!= null);
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the operator property.
     * 
     * @return
     *     possible object is
     *     {@link Operators }
     *     
     */
    public Operators getOperator() {
        return operator;
    }

    /**
     * Sets the value of the operator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Operators }
     *     
     */
    public void setOperator(Operators value) {
        this.operator = value;
    }

    public boolean isSetOperator() {
        return (this.operator!= null);
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link Types }
     *     
     */
    public Types getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link Types }
     *     
     */
    public void setType(Types value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the values property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the values property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getValues().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getValues() {
        if (values == null) {
            values = new ArrayList<String>();
        }
        return this.values;
    }

    public boolean isSetValues() {
        return ((this.values!= null)&&(!this.values.isEmpty()));
    }

    public void unsetValues() {
        this.values = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("level", level).add("name", name).add("operator", operator).add("type", type).add("values", values).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(level, name, operator, type, values);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final Criterion o = ((Criterion) other);
        return ((((Objects.equal(level, o.level)&&Objects.equal(name, o.name))&&Objects.equal(operator, o.operator))&&Objects.equal(type, o.type))&&Objects.equal(values, o.values));
    }

}
