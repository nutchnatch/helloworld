
package com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ElectronicDocumentFileDataType;


/**
 * File description
 * 
 * <p>Java class for MCODocumentFileType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCODocumentFileType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ElectronicDocumentFileDataType"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCODocumentFileType")
@XmlSeeAlso({
    DocumentFile.class
})
public class MCODocumentFileType
    extends ElectronicDocumentFileDataType
    implements Serializable
{

    private final static long serialVersionUID = 1L;

}
