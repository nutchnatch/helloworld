
package com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.google.common.base.Objects;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://ea.assurance.bnpparibas.com/internal/schema/mco/reporting/v1}MCOEnvelopeFlows"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "EnvelopeFlows")
public class EnvelopeFlows
    extends MCOEnvelopeFlows
    implements Serializable
{

    private final static long serialVersionUID = 1L;

    /**
     * Default no-arg constructor
     * 
     */
    public EnvelopeFlows() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public EnvelopeFlows(final String directionCode, final ClassId classId, final long numberOfEnvelopes, final long numberOfDocuments, final long sizeOfDocuments) {
        super(directionCode, classId, numberOfEnvelopes, numberOfDocuments, sizeOfDocuments);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("directionCode", directionCode).add("classId", classId).add("numberOfEnvelopes", numberOfEnvelopes).add("numberOfDocuments", numberOfDocuments).add("sizeOfDocuments", sizeOfDocuments).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(directionCode, classId, numberOfEnvelopes, numberOfDocuments, sizeOfDocuments);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final EnvelopeFlows o = ((EnvelopeFlows) other);
        return ((((Objects.equal(directionCode, o.directionCode)&&Objects.equal(classId, o.classId))&&Objects.equal(numberOfEnvelopes, o.numberOfEnvelopes))&&Objects.equal(numberOfDocuments, o.numberOfDocuments))&&Objects.equal(sizeOfDocuments, o.sizeOfDocuments));
    }

}
