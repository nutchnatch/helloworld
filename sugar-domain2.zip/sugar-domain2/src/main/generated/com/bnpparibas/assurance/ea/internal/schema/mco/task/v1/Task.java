
package com.bnpparibas.assurance.ea.internal.schema.mco.task.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.google.common.base.Objects;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1}MCOTask"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "Task")
public class Task
    extends MCOTask
    implements Serializable
{

    private final static long serialVersionUID = 1L;

    /**
     * Default no-arg constructor
     * 
     */
    public Task() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public Task(final TaskId taskId, final BasketId basketId, final MCOTask.DocID docID, final String lockerName, final String status, final Date creatnDate, final Date updtDate, final String name, final String scope) {
        super(taskId, basketId, docID, lockerName, status, creatnDate, updtDate, name, scope);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("taskId", taskId).add("basketId", basketId).add("docID", docID).add("lockerName", lockerName).add("status", status).add("creatnDate", creatnDate).add("updtDate", updtDate).add("name", name).add("scope", scope).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(taskId, basketId, docID, lockerName, status, creatnDate, updtDate, name, scope);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final Task o = ((Task) other);
        return ((((((((Objects.equal(taskId, o.taskId)&&Objects.equal(basketId, o.basketId))&&Objects.equal(docID, o.docID))&&Objects.equal(lockerName, o.lockerName))&&Objects.equal(status, o.status))&&Objects.equal(creatnDate, o.creatnDate))&&Objects.equal(updtDate, o.updtDate))&&Objects.equal(name, o.name))&&Objects.equal(scope, o.scope));
    }

}
