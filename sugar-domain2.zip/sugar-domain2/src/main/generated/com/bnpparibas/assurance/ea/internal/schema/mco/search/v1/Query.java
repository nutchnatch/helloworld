
package com.bnpparibas.assurance.ea.internal.schema.mco.search.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://ea.assurance.bnpparibas.com/internal/schema/mco/search/v1}QueryType"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "Query")
public class Query
    extends QueryType
    implements Serializable
{

    private final static long serialVersionUID = 1L;

    /**
     * Default no-arg constructor
     * 
     */
    public Query() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public Query(final FilterType filter, final OrderType order, final String scope, final int pageStart, final int pageSize, final Long maxLimitSearch, final String lang) {
        super(filter, order, scope, pageStart, pageSize, maxLimitSearch, lang);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("filter", filter).add("order", order).add("scope", scope).add("pageStart", pageStart).add("pageSize", pageSize).add("maxLimitSearch", maxLimitSearch).add("lang", lang).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(filter, order, scope, pageStart, pageSize, maxLimitSearch, lang);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final Query o = ((Query) other);
        return ((((((Objects.equal(filter, o.filter)&&Objects.equal(order, o.order))&&Objects.equal(scope, o.scope))&&Objects.equal(pageStart, o.pageStart))&&Objects.equal(pageSize, o.pageSize))&&Objects.equal(maxLimitSearch, o.maxLimitSearch))&&Objects.equal(lang, o.lang));
    }

}
