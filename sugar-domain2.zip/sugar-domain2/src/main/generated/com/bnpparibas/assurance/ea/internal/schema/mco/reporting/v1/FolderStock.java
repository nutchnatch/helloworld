
package com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.google.common.base.Objects;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://ea.assurance.bnpparibas.com/internal/schema/mco/reporting/v1}MCOFolderStock"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "FolderStock")
public class FolderStock
    extends MCOFolderStock
    implements Serializable
{

    private final static long serialVersionUID = 1L;

    /**
     * Default no-arg constructor
     * 
     */
    public FolderStock() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FolderStock(final ClassId classId, final long numberOfFolders) {
        super(classId, numberOfFolders);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("classId", classId).add("numberOfFolders", numberOfFolders).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(classId, numberOfFolders);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FolderStock o = ((FolderStock) other);
        return (Objects.equal(classId, o.classId)&&Objects.equal(numberOfFolders, o.numberOfFolders));
    }

}
