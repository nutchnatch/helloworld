
package com.bnpparibas.assurance.ea.internal.schema.mco.search.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for Criteria complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Criteria"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CriterionList" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/search/v1}Criterion" maxOccurs="unbounded"/&gt;
 *         &lt;element name="Item" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/search/v1}Item"/&gt;
 *         &lt;element name="any" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Criteria", propOrder = {
    "criterionList",
    "item",
    "any"
})
@XmlSeeAlso({
    Search.class
})
public class Criteria implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CriterionList", required = true)
    protected List<Criterion> criterionList;
    @XmlElement(name = "Item", required = true)
    @XmlSchemaType(name = "string")
    protected Item item;
    protected boolean any;

    /**
     * Default no-arg constructor
     * 
     */
    public Criteria() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public Criteria(final List<Criterion> criterionList, final Item item, final boolean any) {
        this.criterionList = criterionList;
        this.item = item;
        this.any = any;
    }

    /**
     * The list of criterion
     * 							Gets the value of the criterionList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the criterionList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCriterionList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Criterion }
     * 
     * 
     */
    public List<Criterion> getCriterionList() {
        if (criterionList == null) {
            criterionList = new ArrayList<Criterion>();
        }
        return this.criterionList;
    }

    public boolean isSetCriterionList() {
        return ((this.criterionList!= null)&&(!this.criterionList.isEmpty()));
    }

    public void unsetCriterionList() {
        this.criterionList = null;
    }

    /**
     * The item type on which the criteria should be
     * 								applied
     * 							
     * 
     * @return
     *     possible object is
     *     {@link Item }
     *     
     */
    public Item getItem() {
        return item;
    }

    /**
     * Sets the value of the item property.
     * 
     * @param value
     *     allowed object is
     *     {@link Item }
     *     
     */
    public void setItem(Item value) {
        this.item = value;
    }

    public boolean isSetItem() {
        return (this.item!= null);
    }

    /**
     * Determines if all criteria are required or any one.
     * 							
     * 
     */
    public boolean isAny() {
        return any;
    }

    /**
     * Sets the value of the any property.
     * 
     */
    public void setAny(boolean value) {
        this.any = value;
    }

    public boolean isSetAny() {
        return true;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("criterionList", criterionList).add("item", item).add("any", any).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(criterionList, item, any);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final Criteria o = ((Criteria) other);
        return ((Objects.equal(criterionList, o.criterionList)&&Objects.equal(item, o.item))&&Objects.equal(any, o.any));
    }

}
