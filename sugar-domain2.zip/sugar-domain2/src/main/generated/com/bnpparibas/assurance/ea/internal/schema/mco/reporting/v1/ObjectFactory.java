
package com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link EnvelopeFlows }
     * 
     */
    public EnvelopeFlows createEnvelopeFlows() {
        return new EnvelopeFlows();
    }

    /**
     * Create an instance of {@link MCOEnvelopeFlows }
     * 
     */
    public MCOEnvelopeFlows createMCOEnvelopeFlows() {
        return new MCOEnvelopeFlows();
    }

    /**
     * Create an instance of {@link BasketRatio }
     * 
     */
    public BasketRatio createBasketRatio() {
        return new BasketRatio();
    }

    /**
     * Create an instance of {@link MCOBasketRatio }
     * 
     */
    public MCOBasketRatio createMCOBasketRatio() {
        return new MCOBasketRatio();
    }

    /**
     * Create an instance of {@link DocumentStock }
     * 
     */
    public DocumentStock createDocumentStock() {
        return new DocumentStock();
    }

    /**
     * Create an instance of {@link MCODocumentStock }
     * 
     */
    public MCODocumentStock createMCODocumentStock() {
        return new MCODocumentStock();
    }

    /**
     * Create an instance of {@link FolderStock }
     * 
     */
    public FolderStock createFolderStock() {
        return new FolderStock();
    }

    /**
     * Create an instance of {@link MCOFolderStock }
     * 
     */
    public MCOFolderStock createMCOFolderStock() {
        return new MCOFolderStock();
    }

    /**
     * Create an instance of {@link Summary }
     * 
     */
    public Summary createSummary() {
        return new Summary();
    }

    /**
     * Create an instance of {@link MCOSummary }
     * 
     */
    public MCOSummary createMCOSummary() {
        return new MCOSummary();
    }

}
