
package com.bnpparibas.assurance.ea.internal.schema.mco.search.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for OrderClause complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OrderClause"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Level" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/search/v1}Levels"/&gt;
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/search/v1}Types"/&gt;
 *         &lt;element name="Ascending" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrderClause", propOrder = {
    "level",
    "name",
    "type",
    "ascending"
})
public class OrderClause implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Level", required = true)
    @XmlSchemaType(name = "string")
    protected Levels level;
    @XmlElement(name = "Name", required = true)
    protected String name;
    @XmlElement(name = "Type", required = true)
    @XmlSchemaType(name = "string")
    protected Types type;
    @XmlElement(name = "Ascending")
    protected boolean ascending;

    /**
     * Default no-arg constructor
     * 
     */
    public OrderClause() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public OrderClause(final Levels level, final String name, final Types type, final boolean ascending) {
        this.level = level;
        this.name = name;
        this.type = type;
        this.ascending = ascending;
    }

    /**
     * Gets the value of the level property.
     * 
     * @return
     *     possible object is
     *     {@link Levels }
     *     
     */
    public Levels getLevel() {
        return level;
    }

    /**
     * Sets the value of the level property.
     * 
     * @param value
     *     allowed object is
     *     {@link Levels }
     *     
     */
    public void setLevel(Levels value) {
        this.level = value;
    }

    public boolean isSetLevel() {
        return (this.level!= null);
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link Types }
     *     
     */
    public Types getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link Types }
     *     
     */
    public void setType(Types value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the ascending property.
     * 
     */
    public boolean isAscending() {
        return ascending;
    }

    /**
     * Sets the value of the ascending property.
     * 
     */
    public void setAscending(boolean value) {
        this.ascending = value;
    }

    public boolean isSetAscending() {
        return true;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("level", level).add("name", name).add("type", type).add("ascending", ascending).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(level, name, type, ascending);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final OrderClause o = ((OrderClause) other);
        return (((Objects.equal(level, o.level)&&Objects.equal(name, o.name))&&Objects.equal(type, o.type))&&Objects.equal(ascending, o.ascending));
    }

}
