
package com.bnpparibas.assurance.ea.internal.schema.mco.search.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for FilterType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FilterType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="filter" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/search/v1}FilterType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="path" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="operator" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="operand" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/search/v1}OperandType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="logicalOperator" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/search/v1}LogicalOperators" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FilterType", propOrder = {
    "filter",
    "path",
    "operator",
    "operand"
})
public class FilterType implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected List<FilterType> filter;
    protected String path;
    @XmlElement(required = true)
    protected String operator;
    protected OperandType operand;
    @XmlAttribute(name = "logicalOperator")
    protected LogicalOperators logicalOperator;

    /**
     * Default no-arg constructor
     * 
     */
    public FilterType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FilterType(final List<FilterType> filter, final String path, final String operator, final OperandType operand, final LogicalOperators logicalOperator) {
        this.filter = filter;
        this.path = path;
        this.operator = operator;
        this.operand = operand;
        this.logicalOperator = logicalOperator;
    }

    /**
     * Gets the value of the filter property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the filter property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFilter().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FilterType }
     * 
     * 
     */
    public List<FilterType> getFilter() {
        if (filter == null) {
            filter = new ArrayList<FilterType>();
        }
        return this.filter;
    }

    public boolean isSetFilter() {
        return ((this.filter!= null)&&(!this.filter.isEmpty()));
    }

    public void unsetFilter() {
        this.filter = null;
    }

    /**
     * Gets the value of the path property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPath() {
        return path;
    }

    /**
     * Sets the value of the path property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPath(String value) {
        this.path = value;
    }

    public boolean isSetPath() {
        return (this.path!= null);
    }

    /**
     * Gets the value of the operator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperator() {
        return operator;
    }

    /**
     * Sets the value of the operator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperator(String value) {
        this.operator = value;
    }

    public boolean isSetOperator() {
        return (this.operator!= null);
    }

    /**
     * Gets the value of the operand property.
     * 
     * @return
     *     possible object is
     *     {@link OperandType }
     *     
     */
    public OperandType getOperand() {
        return operand;
    }

    /**
     * Sets the value of the operand property.
     * 
     * @param value
     *     allowed object is
     *     {@link OperandType }
     *     
     */
    public void setOperand(OperandType value) {
        this.operand = value;
    }

    public boolean isSetOperand() {
        return (this.operand!= null);
    }

    /**
     * Gets the value of the logicalOperator property.
     * 
     * @return
     *     possible object is
     *     {@link LogicalOperators }
     *     
     */
    public LogicalOperators getLogicalOperator() {
        return logicalOperator;
    }

    /**
     * Sets the value of the logicalOperator property.
     * 
     * @param value
     *     allowed object is
     *     {@link LogicalOperators }
     *     
     */
    public void setLogicalOperator(LogicalOperators value) {
        this.logicalOperator = value;
    }

    public boolean isSetLogicalOperator() {
        return (this.logicalOperator!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("filter", filter).add("path", path).add("operator", operator).add("operand", operand).add("logicalOperator", logicalOperator).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(filter, path, operator, operand, logicalOperator);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FilterType o = ((FilterType) other);
        return ((((Objects.equal(filter, o.filter)&&Objects.equal(path, o.path))&&Objects.equal(operator, o.operator))&&Objects.equal(operand, o.operand))&&Objects.equal(logicalOperator, o.logicalOperator));
    }

}
