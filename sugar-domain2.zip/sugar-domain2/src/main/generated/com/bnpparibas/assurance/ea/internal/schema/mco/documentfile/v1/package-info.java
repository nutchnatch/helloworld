@javax.xml.bind.annotation.XmlSchema(namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/documentfile/v1")
package com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1;
