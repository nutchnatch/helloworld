
package com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.google.common.base.Objects;


/**
 * <p>Java class for MCOTagClass complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCOTagClass"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClassId"/&gt;
 *         &lt;element name="Scope" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="IsSearchable" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="Label" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1}MCOI18NLabel" maxOccurs="unbounded"/&gt;
 *         &lt;element name="TagType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/tagclass/v1}TagValueType"/&gt;
 *         &lt;element name="AllowedValue" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/tagclass/v1}MCOAllowedValue" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Pattern" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="SymbolicName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCOTagClass", propOrder = {
    "classId",
    "scope",
    "isSearchable",
    "label",
    "tagType",
    "allowedValue",
    "pattern"
})
@XmlSeeAlso({
    TagClass.class
})
public class MCOTagClass implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ClassId", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1", required = true)
    protected ClassId classId;
    @XmlElement(name = "Scope", required = true)
    protected String scope;
    @XmlElement(name = "IsSearchable")
    protected boolean isSearchable;
    @XmlElement(name = "Label", required = true)
    protected List<MCOI18NLabel> label;
    @XmlElement(name = "TagType", required = true)
    @XmlSchemaType(name = "string")
    protected TagValueType tagType;
    @XmlElement(name = "AllowedValue")
    protected List<MCOAllowedValue> allowedValue;
    @XmlElement(name = "Pattern")
    protected String pattern;
    @XmlAttribute(name = "SymbolicName")
    protected String symbolicName;

    /**
     * Default no-arg constructor
     * 
     */
    public MCOTagClass() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MCOTagClass(final ClassId classId, final String scope, final boolean isSearchable, final List<MCOI18NLabel> label, final TagValueType tagType, final List<MCOAllowedValue> allowedValue, final String pattern, final String symbolicName) {
        this.classId = classId;
        this.scope = scope;
        this.isSearchable = isSearchable;
        this.label = label;
        this.tagType = tagType;
        this.allowedValue = allowedValue;
        this.pattern = pattern;
        this.symbolicName = symbolicName;
    }

    /**
     * Identification of the document class
     * 					
     * 
     * @return
     *     possible object is
     *     {@link ClassId }
     *     
     */
    public ClassId getClassId() {
        return classId;
    }

    /**
     * Sets the value of the classId property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassId }
     *     
     */
    public void setClassId(ClassId value) {
        this.classId = value;
    }

    public boolean isSetClassId() {
        return (this.classId!= null);
    }

    /**
     * Gets the value of the scope property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScope() {
        return scope;
    }

    /**
     * Sets the value of the scope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScope(String value) {
        this.scope = value;
    }

    public boolean isSetScope() {
        return (this.scope!= null);
    }

    /**
     * Gets the value of the isSearchable property.
     * 
     */
    public boolean isIsSearchable() {
        return isSearchable;
    }

    /**
     * Sets the value of the isSearchable property.
     * 
     */
    public void setIsSearchable(boolean value) {
        this.isSearchable = value;
    }

    public boolean isSetIsSearchable() {
        return true;
    }

    /**
     * Gets the value of the label property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the label property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLabel().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MCOI18NLabel }
     * 
     * 
     */
    public List<MCOI18NLabel> getLabel() {
        if (label == null) {
            label = new ArrayList<MCOI18NLabel>();
        }
        return this.label;
    }

    public boolean isSetLabel() {
        return ((this.label!= null)&&(!this.label.isEmpty()));
    }

    public void unsetLabel() {
        this.label = null;
    }

    /**
     * Gets the value of the tagType property.
     * 
     * @return
     *     possible object is
     *     {@link TagValueType }
     *     
     */
    public TagValueType getTagType() {
        return tagType;
    }

    /**
     * Sets the value of the tagType property.
     * 
     * @param value
     *     allowed object is
     *     {@link TagValueType }
     *     
     */
    public void setTagType(TagValueType value) {
        this.tagType = value;
    }

    public boolean isSetTagType() {
        return (this.tagType!= null);
    }

    /**
     * Gets the value of the allowedValue property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the allowedValue property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAllowedValue().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MCOAllowedValue }
     * 
     * 
     */
    public List<MCOAllowedValue> getAllowedValue() {
        if (allowedValue == null) {
            allowedValue = new ArrayList<MCOAllowedValue>();
        }
        return this.allowedValue;
    }

    public boolean isSetAllowedValue() {
        return ((this.allowedValue!= null)&&(!this.allowedValue.isEmpty()));
    }

    public void unsetAllowedValue() {
        this.allowedValue = null;
    }

    /**
     * Gets the value of the pattern property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPattern() {
        return pattern;
    }

    /**
     * Sets the value of the pattern property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPattern(String value) {
        this.pattern = value;
    }

    public boolean isSetPattern() {
        return (this.pattern!= null);
    }

    /**
     * Gets the value of the symbolicName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSymbolicName() {
        return symbolicName;
    }

    /**
     * Sets the value of the symbolicName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSymbolicName(String value) {
        this.symbolicName = value;
    }

    public boolean isSetSymbolicName() {
        return (this.symbolicName!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("classId", classId).add("scope", scope).add("isSearchable", isSearchable).add("label", label).add("tagType", tagType).add("allowedValue", allowedValue).add("pattern", pattern).add("symbolicName", symbolicName).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(classId, scope, isSearchable, label, tagType, allowedValue, pattern, symbolicName);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MCOTagClass o = ((MCOTagClass) other);
        return (((((((Objects.equal(classId, o.classId)&&Objects.equal(scope, o.scope))&&Objects.equal(isSearchable, o.isSearchable))&&Objects.equal(label, o.label))&&Objects.equal(tagType, o.tagType))&&Objects.equal(allowedValue, o.allowedValue))&&Objects.equal(pattern, o.pattern))&&Objects.equal(symbolicName, o.symbolicName));
    }

}
