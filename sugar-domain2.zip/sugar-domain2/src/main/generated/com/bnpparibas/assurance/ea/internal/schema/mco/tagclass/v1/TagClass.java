
package com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1;

import java.io.Serializable;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.google.common.base.Objects;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://ea.assurance.bnpparibas.com/internal/schema/mco/tagclass/v1}MCOTagClass"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "TagClass")
public class TagClass
    extends MCOTagClass
    implements Serializable
{

    private final static long serialVersionUID = 1L;

    /**
     * Default no-arg constructor
     * 
     */
    public TagClass() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public TagClass(final ClassId classId, final String scope, final boolean isSearchable, final List<MCOI18NLabel> label, final TagValueType tagType, final List<MCOAllowedValue> allowedValue, final String pattern, final String symbolicName) {
        super(classId, scope, isSearchable, label, tagType, allowedValue, pattern, symbolicName);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("classId", classId).add("scope", scope).add("isSearchable", isSearchable).add("label", label).add("tagType", tagType).add("allowedValue", allowedValue).add("pattern", pattern).add("symbolicName", symbolicName).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(classId, scope, isSearchable, label, tagType, allowedValue, pattern, symbolicName);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final TagClass o = ((TagClass) other);
        return (((((((Objects.equal(classId, o.classId)&&Objects.equal(scope, o.scope))&&Objects.equal(isSearchable, o.isSearchable))&&Objects.equal(label, o.label))&&Objects.equal(tagType, o.tagType))&&Objects.equal(allowedValue, o.allowedValue))&&Objects.equal(pattern, o.pattern))&&Objects.equal(symbolicName, o.symbolicName));
    }

}
