
package com.bnpparibas.assurance.ea.internal.schema.mco.task.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * <p>Java class for MCOTask complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCOTask"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1}TaskId"/&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1}BasketId"/&gt;
 *         &lt;element name="DocID"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1}Id"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="LockerName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1}LockerName"/&gt;
 *         &lt;element name="Status" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1}Status"/&gt;
 *         &lt;element name="CreatnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="UpdtDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="Name"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="Scope" use="required"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;maxLength value="20"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCOTask", propOrder = {
    "taskId",
    "basketId",
    "docID",
    "lockerName",
    "status",
    "creatnDate",
    "updtDate"
})
@XmlSeeAlso({
    Task.class
})
public class MCOTask implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "TaskId", required = true)
    protected TaskId taskId;
    @XmlElement(name = "BasketId", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1", required = true)
    protected BasketId basketId;
    @XmlElement(name = "DocID", required = true)
    protected MCOTask.DocID docID;
    @XmlElement(name = "LockerName", required = true)
    protected String lockerName;
    @XmlElement(name = "Status", required = true)
    protected String status;
    @XmlElement(name = "CreatnDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date creatnDate;
    @XmlElement(name = "UpdtDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date updtDate;
    @XmlAttribute(name = "Name")
    protected String name;
    @XmlAttribute(name = "Scope", required = true)
    protected String scope;

    /**
     * Default no-arg constructor
     * 
     */
    public MCOTask() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MCOTask(final TaskId taskId, final BasketId basketId, final MCOTask.DocID docID, final String lockerName, final String status, final Date creatnDate, final Date updtDate, final String name, final String scope) {
        this.taskId = taskId;
        this.basketId = basketId;
        this.docID = docID;
        this.lockerName = lockerName;
        this.status = status;
        this.creatnDate = creatnDate;
        this.updtDate = updtDate;
        this.name = name;
        this.scope = scope;
    }

    /**
     * Gets the value of the taskId property.
     * 
     * @return
     *     possible object is
     *     {@link TaskId }
     *     
     */
    public TaskId getTaskId() {
        return taskId;
    }

    /**
     * Sets the value of the taskId property.
     * 
     * @param value
     *     allowed object is
     *     {@link TaskId }
     *     
     */
    public void setTaskId(TaskId value) {
        this.taskId = value;
    }

    public boolean isSetTaskId() {
        return (this.taskId!= null);
    }

    /**
     * Gets the value of the basketId property.
     * 
     * @return
     *     possible object is
     *     {@link BasketId }
     *     
     */
    public BasketId getBasketId() {
        return basketId;
    }

    /**
     * Sets the value of the basketId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasketId }
     *     
     */
    public void setBasketId(BasketId value) {
        this.basketId = value;
    }

    public boolean isSetBasketId() {
        return (this.basketId!= null);
    }

    /**
     * Gets the value of the docID property.
     * 
     * @return
     *     possible object is
     *     {@link MCOTask.DocID }
     *     
     */
    public MCOTask.DocID getDocID() {
        return docID;
    }

    /**
     * Sets the value of the docID property.
     * 
     * @param value
     *     allowed object is
     *     {@link MCOTask.DocID }
     *     
     */
    public void setDocID(MCOTask.DocID value) {
        this.docID = value;
    }

    public boolean isSetDocID() {
        return (this.docID!= null);
    }

    /**
     * Gets the value of the lockerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLockerName() {
        return lockerName;
    }

    /**
     * Sets the value of the lockerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLockerName(String value) {
        this.lockerName = value;
    }

    public boolean isSetLockerName() {
        return (this.lockerName!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    /**
     * Gets the value of the creatnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCreatnDate() {
        return creatnDate;
    }

    /**
     * Sets the value of the creatnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatnDate(Date value) {
        this.creatnDate = value;
    }

    public boolean isSetCreatnDate() {
        return (this.creatnDate!= null);
    }

    /**
     * Gets the value of the updtDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getUpdtDate() {
        return updtDate;
    }

    /**
     * Sets the value of the updtDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdtDate(Date value) {
        this.updtDate = value;
    }

    public boolean isSetUpdtDate() {
        return (this.updtDate!= null);
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the scope property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScope() {
        return scope;
    }

    /**
     * Sets the value of the scope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScope(String value) {
        this.scope = value;
    }

    public boolean isSetScope() {
        return (this.scope!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("taskId", taskId).add("basketId", basketId).add("docID", docID).add("lockerName", lockerName).add("status", status).add("creatnDate", creatnDate).add("updtDate", updtDate).add("name", name).add("scope", scope).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(taskId, basketId, docID, lockerName, status, creatnDate, updtDate, name, scope);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MCOTask o = ((MCOTask) other);
        return ((((((((Objects.equal(taskId, o.taskId)&&Objects.equal(basketId, o.basketId))&&Objects.equal(docID, o.docID))&&Objects.equal(lockerName, o.lockerName))&&Objects.equal(status, o.status))&&Objects.equal(creatnDate, o.creatnDate))&&Objects.equal(updtDate, o.updtDate))&&Objects.equal(name, o.name))&&Objects.equal(scope, o.scope));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1}Id"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "id"
    })
    public static class DocID implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Id", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1", required = true)
        protected Id id;

        /**
         * Default no-arg constructor
         * 
         */
        public DocID() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public DocID(final Id id) {
            this.id = id;
        }

        /**
         * Gets the value of the id property.
         * 
         * @return
         *     possible object is
         *     {@link Id }
         *     
         */
        public Id getId() {
            return id;
        }

        /**
         * Sets the value of the id property.
         * 
         * @param value
         *     allowed object is
         *     {@link Id }
         *     
         */
        public void setId(Id value) {
            this.id = value;
        }

        public boolean isSetId() {
            return (this.id!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("id", id).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(id);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final MCOTask.DocID o = ((MCOTask.DocID) other);
            return Objects.equal(id, o.id);
        }

    }

}
