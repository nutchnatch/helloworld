
package com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1;

import java.io.Serializable;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1}MCOAccessControlEntry"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "AccessControlEntry")
public class AccessControlEntry
    extends MCOAccessControlEntry
    implements Serializable
{

    private final static long serialVersionUID = 1L;

    /**
     * Default no-arg constructor
     * 
     */
    public AccessControlEntry() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public AccessControlEntry(final List<String> principal, final String permission, final GrantType grant) {
        super(principal, permission, grant);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("principal", principal).add("permission", permission).add("grant", grant).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(principal, permission, grant);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final AccessControlEntry o = ((AccessControlEntry) other);
        return ((Objects.equal(principal, o.principal)&&Objects.equal(permission, o.permission))&&Objects.equal(grant, o.grant));
    }

}
