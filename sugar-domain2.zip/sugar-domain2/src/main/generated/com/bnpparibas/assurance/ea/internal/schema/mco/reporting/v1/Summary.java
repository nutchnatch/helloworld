
package com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://ea.assurance.bnpparibas.com/internal/schema/mco/reporting/v1}MCOSummary"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "Summary")
public class Summary
    extends MCOSummary
    implements Serializable
{

    private final static long serialVersionUID = 1L;

    /**
     * Default no-arg constructor
     * 
     */
    public Summary() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public Summary(final long numberOfDocuments, final long numbereOfEnvelopes, final long numbereOfFolders, final long numberOfTasks) {
        super(numberOfDocuments, numbereOfEnvelopes, numbereOfFolders, numberOfTasks);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("numberOfDocuments", numberOfDocuments).add("numbereOfEnvelopes", numbereOfEnvelopes).add("numbereOfFolders", numbereOfFolders).add("numberOfTasks", numberOfTasks).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(numberOfDocuments, numbereOfEnvelopes, numbereOfFolders, numberOfTasks);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final Summary o = ((Summary) other);
        return (((Objects.equal(numberOfDocuments, o.numberOfDocuments)&&Objects.equal(numbereOfEnvelopes, o.numbereOfEnvelopes))&&Objects.equal(numbereOfFolders, o.numbereOfFolders))&&Objects.equal(numberOfTasks, o.numberOfTasks));
    }

}
