
package com.bnpparibas.assurance.ea.internal.schema.mco.document.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DocumentStatusType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ElectronicDocumentDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.IdentificationType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tags;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.google.common.base.Objects;


/**
 * Document description
 * 			
 * 
 * <p>Java class for MCODocumentType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCODocumentType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1}Id"/&gt;
 *         &lt;element name="Status" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentStatusType" minOccurs="0"/&gt;
 *         &lt;element name="ParentId" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1}Id"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="AddId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentificationType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Data" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ElectronicDocumentDataType"/&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}Tags" minOccurs="0"/&gt;
 *         &lt;element name="FileData"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/documentfile/v1}DocumentFile" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                   &lt;element name="URI" type="{http://www.w3.org/2001/XMLSchema}anyURI" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ChildObject"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1}Document" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                   &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1}Id" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="Scope" use="required"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;maxLength value="20"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="Category" use="required" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}Category" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCODocumentType", propOrder = {
    "id",
    "status",
    "parentId",
    "addId",
    "data",
    "tags",
    "fileData",
    "childObject"
})
@XmlSeeAlso({
    Document.class
})
public class MCODocumentType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Id", required = true)
    protected Id id;
    @XmlElement(name = "Status")
    protected DocumentStatusType status;
    @XmlElement(name = "ParentId")
    protected MCODocumentType.ParentId parentId;
    @XmlElement(name = "AddId")
    protected List<IdentificationType> addId;
    @XmlElement(name = "Data", required = true)
    protected ElectronicDocumentDataType data;
    @XmlElement(name = "Tags", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1", nillable = true)
    protected Tags tags;
    @XmlElement(name = "FileData", required = true)
    protected MCODocumentType.FileData fileData;
    @XmlElement(name = "ChildObject", required = true)
    protected MCODocumentType.ChildObject childObject;
    @XmlAttribute(name = "Scope", required = true)
    protected String scope;
    @XmlAttribute(name = "Category", required = true)
    protected Category category;

    /**
     * Default no-arg constructor
     * 
     */
    public MCODocumentType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MCODocumentType(final Id id, final DocumentStatusType status, final MCODocumentType.ParentId parentId, final List<IdentificationType> addId, final ElectronicDocumentDataType data, final Tags tags, final MCODocumentType.FileData fileData, final MCODocumentType.ChildObject childObject, final String scope, final Category category) {
        this.id = id;
        this.status = status;
        this.parentId = parentId;
        this.addId = addId;
        this.data = data;
        this.tags = tags;
        this.fileData = fileData;
        this.childObject = childObject;
        this.scope = scope;
        this.category = category;
    }

    /**
     * Principal identifier of the document/envelope
     * 						generated by the Master Document Management System. It can be
     * 						SUGAR or another system. The identifier is generated by the MDMS
     * 						as a result of a storage document request. The id and the scheme
     * 						are optional for a storage request; only the issuer is mandatory.
     * 						The MDMS fulfills the identifier and the scheme after the storage
     * 						of a document
     * 					
     * 
     * @return
     *     possible object is
     *     {@link Id }
     *     
     */
    public Id getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link Id }
     *     
     */
    public void setId(Id value) {
        this.id = value;
    }

    public boolean isSetId() {
        return (this.id!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link DocumentStatusType }
     *     
     */
    public DocumentStatusType getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentStatusType }
     *     
     */
    public void setStatus(DocumentStatusType value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    /**
     * Gets the value of the parentId property.
     * 
     * @return
     *     possible object is
     *     {@link MCODocumentType.ParentId }
     *     
     */
    public MCODocumentType.ParentId getParentId() {
        return parentId;
    }

    /**
     * Sets the value of the parentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link MCODocumentType.ParentId }
     *     
     */
    public void setParentId(MCODocumentType.ParentId value) {
        this.parentId = value;
    }

    public boolean isSetParentId() {
        return (this.parentId!= null);
    }

    /**
     * Gets the value of the addId property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addId property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddId().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IdentificationType }
     * 
     * 
     */
    public List<IdentificationType> getAddId() {
        if (addId == null) {
            addId = new ArrayList<IdentificationType>();
        }
        return this.addId;
    }

    public boolean isSetAddId() {
        return ((this.addId!= null)&&(!this.addId.isEmpty()));
    }

    public void unsetAddId() {
        this.addId = null;
    }

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     {@link ElectronicDocumentDataType }
     *     
     */
    public ElectronicDocumentDataType getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     {@link ElectronicDocumentDataType }
     *     
     */
    public void setData(ElectronicDocumentDataType value) {
        this.data = value;
    }

    public boolean isSetData() {
        return (this.data!= null);
    }

    /**
     * For Both document and
     * 						Envelope. Extension buckets allowing for extensibility and act as
     * 						a container for adding elements used for the indexation of
     * 						documents: docuemnt type and other elementst that can defined in
     * 						another schema
     * 					
     * 
     * @return
     *     possible object is
     *     {@link Tags }
     *     
     */
    public Tags getTags() {
        return tags;
    }

    /**
     * Sets the value of the tags property.
     * 
     * @param value
     *     allowed object is
     *     {@link Tags }
     *     
     */
    public void setTags(Tags value) {
        this.tags = value;
    }

    public boolean isSetTags() {
        return (this.tags!= null);
    }

    /**
     * Gets the value of the fileData property.
     * 
     * @return
     *     possible object is
     *     {@link MCODocumentType.FileData }
     *     
     */
    public MCODocumentType.FileData getFileData() {
        return fileData;
    }

    /**
     * Sets the value of the fileData property.
     * 
     * @param value
     *     allowed object is
     *     {@link MCODocumentType.FileData }
     *     
     */
    public void setFileData(MCODocumentType.FileData value) {
        this.fileData = value;
    }

    public boolean isSetFileData() {
        return (this.fileData!= null);
    }

    /**
     * Gets the value of the childObject property.
     * 
     * @return
     *     possible object is
     *     {@link MCODocumentType.ChildObject }
     *     
     */
    public MCODocumentType.ChildObject getChildObject() {
        return childObject;
    }

    /**
     * Sets the value of the childObject property.
     * 
     * @param value
     *     allowed object is
     *     {@link MCODocumentType.ChildObject }
     *     
     */
    public void setChildObject(MCODocumentType.ChildObject value) {
        this.childObject = value;
    }

    public boolean isSetChildObject() {
        return (this.childObject!= null);
    }

    /**
     * Gets the value of the scope property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScope() {
        return scope;
    }

    /**
     * Sets the value of the scope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScope(String value) {
        this.scope = value;
    }

    public boolean isSetScope() {
        return (this.scope!= null);
    }

    /**
     * Gets the value of the category property.
     * 
     * @return
     *     possible object is
     *     {@link Category }
     *     
     */
    public Category getCategory() {
        return category;
    }

    /**
     * Sets the value of the category property.
     * 
     * @param value
     *     allowed object is
     *     {@link Category }
     *     
     */
    public void setCategory(Category value) {
        this.category = value;
    }

    public boolean isSetCategory() {
        return (this.category!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("id", id).add("status", status).add("parentId", parentId).add("addId", addId).add("data", data).add("tags", tags).add("fileData", fileData).add("childObject", childObject).add("scope", scope).add("category", category).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, status, parentId, addId, data, tags, fileData, childObject, scope, category);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MCODocumentType o = ((MCODocumentType) other);
        return (((((((((Objects.equal(id, o.id)&&Objects.equal(status, o.status))&&Objects.equal(parentId, o.parentId))&&Objects.equal(addId, o.addId))&&Objects.equal(data, o.data))&&Objects.equal(tags, o.tags))&&Objects.equal(fileData, o.fileData))&&Objects.equal(childObject, o.childObject))&&Objects.equal(scope, o.scope))&&Objects.equal(category, o.category));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1}Document" maxOccurs="unbounded" minOccurs="0"/&gt;
     *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1}Id" maxOccurs="unbounded" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "document",
        "id"
    })
    public static class ChildObject implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Document")
        protected List<Document> document;
        @XmlElement(name = "Id")
        protected List<Id> id;

        /**
         * Default no-arg constructor
         * 
         */
        public ChildObject() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public ChildObject(final List<Document> document, final List<Id> id) {
            this.document = document;
            this.id = id;
        }

        /**
         * To manag relationships between : envelope and
         * 									document, beteween envelopes (physical envelope - and logical
         * 									envelope, between two documents)
         * 								Gets the value of the document property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the document property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDocument().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Document }
         * 
         * 
         */
        public List<Document> getDocument() {
            if (document == null) {
                document = new ArrayList<Document>();
            }
            return this.document;
        }

        public boolean isSetDocument() {
            return ((this.document!= null)&&(!this.document.isEmpty()));
        }

        public void unsetDocument() {
            this.document = null;
        }

        /**
         * Principal identifer of the document/envelope
         * 									generated by the Master Document Management System. I
         * 								Gets the value of the id property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the id property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getId().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Id }
         * 
         * 
         */
        public List<Id> getId() {
            if (id == null) {
                id = new ArrayList<Id>();
            }
            return this.id;
        }

        public boolean isSetId() {
            return ((this.id!= null)&&(!this.id.isEmpty()));
        }

        public void unsetId() {
            this.id = null;
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("document", document).add("id", id).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(document, id);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final MCODocumentType.ChildObject o = ((MCODocumentType.ChildObject) other);
            return (Objects.equal(document, o.document)&&Objects.equal(id, o.id));
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/documentfile/v1}DocumentFile" maxOccurs="unbounded" minOccurs="0"/&gt;
     *         &lt;element name="URI" type="{http://www.w3.org/2001/XMLSchema}anyURI" maxOccurs="unbounded" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "documentFile",
        "uri"
    })
    public static class FileData implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "DocumentFile", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/documentfile/v1")
        protected List<DocumentFile> documentFile;
        @XmlElement(name = "URI")
        @XmlSchemaType(name = "anyURI")
        protected List<String> uri;

        /**
         * Default no-arg constructor
         * 
         */
        public FileData() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public FileData(final List<DocumentFile> documentFile, final List<String> uri) {
            this.documentFile = documentFile;
            this.uri = uri;
        }

        /**
         * To manage information on the physical files
         * 									that are part of an object.
         * 									A physical file is linked to one and
         * 									only one component but a
         * 									document can have several physical
         * 									files.
         * 								Gets the value of the documentFile property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the documentFile property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDocumentFile().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DocumentFile }
         * 
         * 
         */
        public List<DocumentFile> getDocumentFile() {
            if (documentFile == null) {
                documentFile = new ArrayList<DocumentFile>();
            }
            return this.documentFile;
        }

        public boolean isSetDocumentFile() {
            return ((this.documentFile!= null)&&(!this.documentFile.isEmpty()));
        }

        public void unsetDocumentFile() {
            this.documentFile = null;
        }

        /**
         * Gets the value of the uri property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the uri property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getURI().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getURI() {
            if (uri == null) {
                uri = new ArrayList<String>();
            }
            return this.uri;
        }

        public boolean isSetURI() {
            return ((this.uri!= null)&&(!this.uri.isEmpty()));
        }

        public void unsetURI() {
            this.uri = null;
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("documentFile", documentFile).add("uri", uri).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(documentFile, uri);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final MCODocumentType.FileData o = ((MCODocumentType.FileData) other);
            return (Objects.equal(documentFile, o.documentFile)&&Objects.equal(uri, o.uri));
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1}Id"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "id"
    })
    public static class ParentId implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Id", required = true)
        protected Id id;

        /**
         * Default no-arg constructor
         * 
         */
        public ParentId() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public ParentId(final Id id) {
            this.id = id;
        }

        /**
         * Gets the value of the id property.
         * 
         * @return
         *     possible object is
         *     {@link Id }
         *     
         */
        public Id getId() {
            return id;
        }

        /**
         * Sets the value of the id property.
         * 
         * @param value
         *     allowed object is
         *     {@link Id }
         *     
         */
        public void setId(Id value) {
            this.id = value;
        }

        public boolean isSetId() {
            return (this.id!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("id", id).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(id);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final MCODocumentType.ParentId o = ((MCODocumentType.ParentId) other);
            return Objects.equal(id, o.id);
        }

    }

}
