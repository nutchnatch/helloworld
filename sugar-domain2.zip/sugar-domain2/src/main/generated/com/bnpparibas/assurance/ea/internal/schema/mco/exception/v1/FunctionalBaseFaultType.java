
package com.bnpparibas.assurance.ea.internal.schema.mco.exception.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Fonctional exception type
 * 			
 * 
 * <p>Java class for FunctionalBaseFaultType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FunctionalBaseFaultType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://ea.assurance.bnpparibas.com/internal/schema/mco/exception/v1}AbstractBaseFaultType"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FunctionalBaseFaultType")
public class FunctionalBaseFaultType
    extends AbstractBaseFaultType
    implements Serializable
{

    private final static long serialVersionUID = 1L;

    /**
     * Default no-arg constructor
     * 
     */
    public FunctionalBaseFaultType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FunctionalBaseFaultType(final String code, final String severity, final Date timestamp, final String actor, final String description, final String detail, final String lang, final AbstractBaseFaultType.Reasons reasons) {
        super(code, severity, timestamp, actor, description, detail, lang, reasons);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("code", code).add("severity", severity).add("timestamp", timestamp).add("actor", actor).add("description", description).add("detail", detail).add("lang", lang).add("reasons", reasons).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(code, severity, timestamp, actor, description, detail, lang, reasons);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FunctionalBaseFaultType o = ((FunctionalBaseFaultType) other);
        return (((((((Objects.equal(code, o.code)&&Objects.equal(severity, o.severity))&&Objects.equal(timestamp, o.timestamp))&&Objects.equal(actor, o.actor))&&Objects.equal(description, o.description))&&Objects.equal(detail, o.detail))&&Objects.equal(lang, o.lang))&&Objects.equal(reasons, o.reasons));
    }

}
