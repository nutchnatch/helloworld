
package com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.google.common.base.Objects;


/**
 * <p>Java class for MCOAllowedValue complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCOAllowedValue"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Label" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1}MCOI18NLabel" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="SymbolicName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCOAllowedValue", propOrder = {
    "label"
})
public class MCOAllowedValue implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Label", required = true)
    protected List<MCOI18NLabel> label;
    @XmlAttribute(name = "SymbolicName")
    protected String symbolicName;

    /**
     * Default no-arg constructor
     * 
     */
    public MCOAllowedValue() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MCOAllowedValue(final List<MCOI18NLabel> label, final String symbolicName) {
        this.label = label;
        this.symbolicName = symbolicName;
    }

    /**
     * Gets the value of the label property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the label property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLabel().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MCOI18NLabel }
     * 
     * 
     */
    public List<MCOI18NLabel> getLabel() {
        if (label == null) {
            label = new ArrayList<MCOI18NLabel>();
        }
        return this.label;
    }

    public boolean isSetLabel() {
        return ((this.label!= null)&&(!this.label.isEmpty()));
    }

    public void unsetLabel() {
        this.label = null;
    }

    /**
     * Gets the value of the symbolicName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSymbolicName() {
        return symbolicName;
    }

    /**
     * Sets the value of the symbolicName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSymbolicName(String value) {
        this.symbolicName = value;
    }

    public boolean isSetSymbolicName() {
        return (this.symbolicName!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("label", label).add("symbolicName", symbolicName).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(label, symbolicName);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MCOAllowedValue o = ((MCOAllowedValue) other);
        return (Objects.equal(label, o.label)&&Objects.equal(symbolicName, o.symbolicName));
    }

}
