
package com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TagValueType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="TagValueType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="STRING"/&gt;
 *     &lt;enumeration value="INT"/&gt;
 *     &lt;enumeration value="BOOLEAN"/&gt;
 *     &lt;enumeration value="DATE"/&gt;
 *     &lt;enumeration value="FLOAT"/&gt;
 *     &lt;enumeration value="CHOICELIST"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "TagValueType")
@XmlEnum
public enum TagValueType {

    STRING,
    INT,
    BOOLEAN,
    DATE,
    FLOAT,
    CHOICELIST;

    public String value() {
        return name();
    }

    public static TagValueType fromValue(String v) {
        return valueOf(v);
    }

}
