
package com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.google.common.base.Objects;


/**
 * <p>Java class for MCODocumentStock complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCODocumentStock"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClassId"/&gt;
 *         &lt;element name="numberOfDocuments" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="sizeOfFiles" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCODocumentStock", propOrder = {
    "classId",
    "numberOfDocuments",
    "sizeOfFiles"
})
@XmlSeeAlso({
    DocumentStock.class
})
public class MCODocumentStock implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ClassId", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1", required = true)
    protected ClassId classId;
    protected long numberOfDocuments;
    protected long sizeOfFiles;

    /**
     * Default no-arg constructor
     * 
     */
    public MCODocumentStock() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MCODocumentStock(final ClassId classId, final long numberOfDocuments, final long sizeOfFiles) {
        this.classId = classId;
        this.numberOfDocuments = numberOfDocuments;
        this.sizeOfFiles = sizeOfFiles;
    }

    /**
     * Gets the value of the classId property.
     * 
     * @return
     *     possible object is
     *     {@link ClassId }
     *     
     */
    public ClassId getClassId() {
        return classId;
    }

    /**
     * Sets the value of the classId property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassId }
     *     
     */
    public void setClassId(ClassId value) {
        this.classId = value;
    }

    public boolean isSetClassId() {
        return (this.classId!= null);
    }

    /**
     * Gets the value of the numberOfDocuments property.
     * 
     */
    public long getNumberOfDocuments() {
        return numberOfDocuments;
    }

    /**
     * Sets the value of the numberOfDocuments property.
     * 
     */
    public void setNumberOfDocuments(long value) {
        this.numberOfDocuments = value;
    }

    public boolean isSetNumberOfDocuments() {
        return true;
    }

    /**
     * Gets the value of the sizeOfFiles property.
     * 
     */
    public long getSizeOfFiles() {
        return sizeOfFiles;
    }

    /**
     * Sets the value of the sizeOfFiles property.
     * 
     */
    public void setSizeOfFiles(long value) {
        this.sizeOfFiles = value;
    }

    public boolean isSetSizeOfFiles() {
        return true;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("classId", classId).add("numberOfDocuments", numberOfDocuments).add("sizeOfFiles", sizeOfFiles).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(classId, numberOfDocuments, sizeOfFiles);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MCODocumentStock o = ((MCODocumentStock) other);
        return ((Objects.equal(classId, o.classId)&&Objects.equal(numberOfDocuments, o.numberOfDocuments))&&Objects.equal(sizeOfFiles, o.sizeOfFiles));
    }

}
