
package com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DefaultRetentionStartDateValue;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * <p>Java class for MCOBusinessScope complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCOBusinessScope"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/businessscope/v1}BusinessScopeId"/&gt;
 *         &lt;element name="OrganisationalUnit" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="DisplayName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1}MCOI18NLabel" maxOccurs="unbounded"/&gt;
 *         &lt;element name="Languages" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded"/&gt;
 *         &lt;element name="PreferedLanguages" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1}MCOI18NLabel" maxOccurs="5" minOccurs="5"/&gt;
 *         &lt;element name="DefaultEnvelopClass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DefaultDocumentClass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DefaultFolderClass" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="CreationDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType"/&gt;
 *         &lt;element name="updateDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType"/&gt;
 *         &lt;element name="DefaultRetentionStartDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DefaultRetentionStartDateValue" minOccurs="0"/&gt;
 *         &lt;element name="EncryptionIdentifier" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="FileData" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/documentfile/v1}DocumentFile"/&gt;
 *                   &lt;element name="URI" type="{http://www.w3.org/2001/XMLSchema}anyURI"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="SymbolicName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCOBusinessScope", propOrder = {
    "businessScopeId",
    "organisationalUnit",
    "description",
    "displayName",
    "languages",
    "preferedLanguages",
    "defaultEnvelopClass",
    "defaultDocumentClass",
    "defaultFolderClass",
    "creationDate",
    "updateDate",
    "defaultRetentionStartDate",
    "encryptionIdentifier",
    "fileData"
})
@XmlSeeAlso({
    BusinessScope.class
})
public class MCOBusinessScope implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "BusinessScopeId", required = true)
    protected BusinessScopeId businessScopeId;
    @XmlElement(name = "OrganisationalUnit", required = true)
    protected String organisationalUnit;
    @XmlElement(name = "Description", required = true)
    protected String description;
    @XmlElement(name = "DisplayName", required = true)
    protected List<MCOI18NLabel> displayName;
    @XmlElement(name = "Languages", required = true)
    protected List<String> languages;
    @XmlElement(name = "PreferedLanguages", required = true)
    protected List<MCOI18NLabel> preferedLanguages;
    @XmlElement(name = "DefaultEnvelopClass")
    protected String defaultEnvelopClass;
    @XmlElement(name = "DefaultDocumentClass")
    protected String defaultDocumentClass;
    @XmlElement(name = "DefaultFolderClass")
    protected String defaultFolderClass;
    @XmlElement(name = "CreationDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date creationDate;
    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date updateDate;
    @XmlElement(name = "DefaultRetentionStartDate")
    @XmlSchemaType(name = "string")
    protected DefaultRetentionStartDateValue defaultRetentionStartDate;
    @XmlElement(name = "EncryptionIdentifier", required = true)
    protected String encryptionIdentifier;
    @XmlElement(name = "FileData")
    protected MCOBusinessScope.FileData fileData;
    @XmlAttribute(name = "SymbolicName")
    protected String symbolicName;

    /**
     * Default no-arg constructor
     * 
     */
    public MCOBusinessScope() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MCOBusinessScope(final BusinessScopeId businessScopeId, final String organisationalUnit, final String description, final List<MCOI18NLabel> displayName, final List<String> languages, final List<MCOI18NLabel> preferedLanguages, final String defaultEnvelopClass, final String defaultDocumentClass, final String defaultFolderClass, final Date creationDate, final Date updateDate, final DefaultRetentionStartDateValue defaultRetentionStartDate, final String encryptionIdentifier, final MCOBusinessScope.FileData fileData, final String symbolicName) {
        this.businessScopeId = businessScopeId;
        this.organisationalUnit = organisationalUnit;
        this.description = description;
        this.displayName = displayName;
        this.languages = languages;
        this.preferedLanguages = preferedLanguages;
        this.defaultEnvelopClass = defaultEnvelopClass;
        this.defaultDocumentClass = defaultDocumentClass;
        this.defaultFolderClass = defaultFolderClass;
        this.creationDate = creationDate;
        this.updateDate = updateDate;
        this.defaultRetentionStartDate = defaultRetentionStartDate;
        this.encryptionIdentifier = encryptionIdentifier;
        this.fileData = fileData;
        this.symbolicName = symbolicName;
    }

    /**
     * Principal Identifier of the Folder
     * 					
     * 
     * @return
     *     possible object is
     *     {@link BusinessScopeId }
     *     
     */
    public BusinessScopeId getBusinessScopeId() {
        return businessScopeId;
    }

    /**
     * Sets the value of the businessScopeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BusinessScopeId }
     *     
     */
    public void setBusinessScopeId(BusinessScopeId value) {
        this.businessScopeId = value;
    }

    public boolean isSetBusinessScopeId() {
        return (this.businessScopeId!= null);
    }

    /**
     * Gets the value of the organisationalUnit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrganisationalUnit() {
        return organisationalUnit;
    }

    /**
     * Sets the value of the organisationalUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrganisationalUnit(String value) {
        this.organisationalUnit = value;
    }

    public boolean isSetOrganisationalUnit() {
        return (this.organisationalUnit!= null);
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    public boolean isSetDescription() {
        return (this.description!= null);
    }

    /**
     * Gets the value of the displayName property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the displayName property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDisplayName().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MCOI18NLabel }
     * 
     * 
     */
    public List<MCOI18NLabel> getDisplayName() {
        if (displayName == null) {
            displayName = new ArrayList<MCOI18NLabel>();
        }
        return this.displayName;
    }

    public boolean isSetDisplayName() {
        return ((this.displayName!= null)&&(!this.displayName.isEmpty()));
    }

    public void unsetDisplayName() {
        this.displayName = null;
    }

    /**
     * Gets the value of the languages property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the languages property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLanguages().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getLanguages() {
        if (languages == null) {
            languages = new ArrayList<String>();
        }
        return this.languages;
    }

    public boolean isSetLanguages() {
        return ((this.languages!= null)&&(!this.languages.isEmpty()));
    }

    public void unsetLanguages() {
        this.languages = null;
    }

    /**
     * Gets the value of the preferedLanguages property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the preferedLanguages property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPreferedLanguages().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MCOI18NLabel }
     * 
     * 
     */
    public List<MCOI18NLabel> getPreferedLanguages() {
        if (preferedLanguages == null) {
            preferedLanguages = new ArrayList<MCOI18NLabel>();
        }
        return this.preferedLanguages;
    }

    public boolean isSetPreferedLanguages() {
        return ((this.preferedLanguages!= null)&&(!this.preferedLanguages.isEmpty()));
    }

    public void unsetPreferedLanguages() {
        this.preferedLanguages = null;
    }

    /**
     * Gets the value of the defaultEnvelopClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultEnvelopClass() {
        return defaultEnvelopClass;
    }

    /**
     * Sets the value of the defaultEnvelopClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultEnvelopClass(String value) {
        this.defaultEnvelopClass = value;
    }

    public boolean isSetDefaultEnvelopClass() {
        return (this.defaultEnvelopClass!= null);
    }

    /**
     * Gets the value of the defaultDocumentClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultDocumentClass() {
        return defaultDocumentClass;
    }

    /**
     * Sets the value of the defaultDocumentClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultDocumentClass(String value) {
        this.defaultDocumentClass = value;
    }

    public boolean isSetDefaultDocumentClass() {
        return (this.defaultDocumentClass!= null);
    }

    /**
     * Gets the value of the defaultFolderClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDefaultFolderClass() {
        return defaultFolderClass;
    }

    /**
     * Sets the value of the defaultFolderClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDefaultFolderClass(String value) {
        this.defaultFolderClass = value;
    }

    public boolean isSetDefaultFolderClass() {
        return (this.defaultFolderClass!= null);
    }

    /**
     * Gets the value of the creationDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCreationDate() {
        return creationDate;
    }

    /**
     * Sets the value of the creationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreationDate(Date value) {
        this.creationDate = value;
    }

    public boolean isSetCreationDate() {
        return (this.creationDate!= null);
    }

    /**
     * Gets the value of the updateDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getUpdateDate() {
        return updateDate;
    }

    /**
     * Sets the value of the updateDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdateDate(Date value) {
        this.updateDate = value;
    }

    public boolean isSetUpdateDate() {
        return (this.updateDate!= null);
    }

    /**
     * Gets the value of the defaultRetentionStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link DefaultRetentionStartDateValue }
     *     
     */
    public DefaultRetentionStartDateValue getDefaultRetentionStartDate() {
        return defaultRetentionStartDate;
    }

    /**
     * Sets the value of the defaultRetentionStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link DefaultRetentionStartDateValue }
     *     
     */
    public void setDefaultRetentionStartDate(DefaultRetentionStartDateValue value) {
        this.defaultRetentionStartDate = value;
    }

    public boolean isSetDefaultRetentionStartDate() {
        return (this.defaultRetentionStartDate!= null);
    }

    /**
     * Gets the value of the encryptionIdentifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEncryptionIdentifier() {
        return encryptionIdentifier;
    }

    /**
     * Sets the value of the encryptionIdentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEncryptionIdentifier(String value) {
        this.encryptionIdentifier = value;
    }

    public boolean isSetEncryptionIdentifier() {
        return (this.encryptionIdentifier!= null);
    }

    /**
     * Gets the value of the fileData property.
     * 
     * @return
     *     possible object is
     *     {@link MCOBusinessScope.FileData }
     *     
     */
    public MCOBusinessScope.FileData getFileData() {
        return fileData;
    }

    /**
     * Sets the value of the fileData property.
     * 
     * @param value
     *     allowed object is
     *     {@link MCOBusinessScope.FileData }
     *     
     */
    public void setFileData(MCOBusinessScope.FileData value) {
        this.fileData = value;
    }

    public boolean isSetFileData() {
        return (this.fileData!= null);
    }

    /**
     * Gets the value of the symbolicName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSymbolicName() {
        return symbolicName;
    }

    /**
     * Sets the value of the symbolicName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSymbolicName(String value) {
        this.symbolicName = value;
    }

    public boolean isSetSymbolicName() {
        return (this.symbolicName!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("businessScopeId", businessScopeId).add("organisationalUnit", organisationalUnit).add("description", description).add("displayName", displayName).add("languages", languages).add("preferedLanguages", preferedLanguages).add("defaultEnvelopClass", defaultEnvelopClass).add("defaultDocumentClass", defaultDocumentClass).add("defaultFolderClass", defaultFolderClass).add("creationDate", creationDate).add("updateDate", updateDate).add("defaultRetentionStartDate", defaultRetentionStartDate).add("encryptionIdentifier", encryptionIdentifier).add("fileData", fileData).add("symbolicName", symbolicName).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(businessScopeId, organisationalUnit, description, displayName, languages, preferedLanguages, defaultEnvelopClass, defaultDocumentClass, defaultFolderClass, creationDate, updateDate, defaultRetentionStartDate, encryptionIdentifier, fileData, symbolicName);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MCOBusinessScope o = ((MCOBusinessScope) other);
        return ((((((((((((((Objects.equal(businessScopeId, o.businessScopeId)&&Objects.equal(organisationalUnit, o.organisationalUnit))&&Objects.equal(description, o.description))&&Objects.equal(displayName, o.displayName))&&Objects.equal(languages, o.languages))&&Objects.equal(preferedLanguages, o.preferedLanguages))&&Objects.equal(defaultEnvelopClass, o.defaultEnvelopClass))&&Objects.equal(defaultDocumentClass, o.defaultDocumentClass))&&Objects.equal(defaultFolderClass, o.defaultFolderClass))&&Objects.equal(creationDate, o.creationDate))&&Objects.equal(updateDate, o.updateDate))&&Objects.equal(defaultRetentionStartDate, o.defaultRetentionStartDate))&&Objects.equal(encryptionIdentifier, o.encryptionIdentifier))&&Objects.equal(fileData, o.fileData))&&Objects.equal(symbolicName, o.symbolicName));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/documentfile/v1}DocumentFile"/&gt;
     *         &lt;element name="URI" type="{http://www.w3.org/2001/XMLSchema}anyURI"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "documentFile",
        "uri"
    })
    public static class FileData implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "DocumentFile", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/documentfile/v1", required = true)
        protected DocumentFile documentFile;
        @XmlElement(name = "URI", required = true)
        @XmlSchemaType(name = "anyURI")
        protected String uri;

        /**
         * Default no-arg constructor
         * 
         */
        public FileData() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public FileData(final DocumentFile documentFile, final String uri) {
            this.documentFile = documentFile;
            this.uri = uri;
        }

        /**
         * To manage information on the physical files
         * 									that are part of an object.
         * 									This physical file is describing
         * 									rules between document
         * 									classes and tasks. It is an Excel File.
         * 								
         * 
         * @return
         *     possible object is
         *     {@link DocumentFile }
         *     
         */
        public DocumentFile getDocumentFile() {
            return documentFile;
        }

        /**
         * Sets the value of the documentFile property.
         * 
         * @param value
         *     allowed object is
         *     {@link DocumentFile }
         *     
         */
        public void setDocumentFile(DocumentFile value) {
            this.documentFile = value;
        }

        public boolean isSetDocumentFile() {
            return (this.documentFile!= null);
        }

        /**
         * Gets the value of the uri property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getURI() {
            return uri;
        }

        /**
         * Sets the value of the uri property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setURI(String value) {
            this.uri = value;
        }

        public boolean isSetURI() {
            return (this.uri!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("documentFile", documentFile).add("uri", uri).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(documentFile, uri);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final MCOBusinessScope.FileData o = ((MCOBusinessScope.FileData) other);
            return (Objects.equal(documentFile, o.documentFile)&&Objects.equal(uri, o.uri));
        }

    }

}
