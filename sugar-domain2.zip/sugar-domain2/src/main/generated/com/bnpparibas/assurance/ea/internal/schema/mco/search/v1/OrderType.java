
package com.bnpparibas.assurance.ea.internal.schema.mco.search.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import com.google.common.base.Objects;


/**
 * <p>Java class for OrderType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OrderType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="orderKey" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;simpleContent&gt;
 *               &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;string"&gt;
 *                 &lt;attribute name="direction" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/search/v1}directions" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/simpleContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrderType", propOrder = {
    "orderKey"
})
public class OrderType implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected List<OrderType.OrderKey> orderKey;

    /**
     * Default no-arg constructor
     * 
     */
    public OrderType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public OrderType(final List<OrderType.OrderKey> orderKey) {
        this.orderKey = orderKey;
    }

    /**
     * Gets the value of the orderKey property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the orderKey property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOrderKey().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OrderType.OrderKey }
     * 
     * 
     */
    public List<OrderType.OrderKey> getOrderKey() {
        if (orderKey == null) {
            orderKey = new ArrayList<OrderType.OrderKey>();
        }
        return this.orderKey;
    }

    public boolean isSetOrderKey() {
        return ((this.orderKey!= null)&&(!this.orderKey.isEmpty()));
    }

    public void unsetOrderKey() {
        this.orderKey = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("orderKey", orderKey).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(orderKey);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final OrderType o = ((OrderType) other);
        return Objects.equal(orderKey, o.orderKey);
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;simpleContent&gt;
     *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema&gt;string"&gt;
     *       &lt;attribute name="direction" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/search/v1}directions" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/simpleContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "value"
    })
    public static class OrderKey implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlValue
        protected String value;
        @XmlAttribute(name = "direction")
        protected Directions direction;

        /**
         * Default no-arg constructor
         * 
         */
        public OrderKey() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public OrderKey(final String value, final Directions direction) {
            this.value = value;
            this.direction = direction;
        }

        /**
         * Gets the value of the value property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getValue() {
            return value;
        }

        /**
         * Sets the value of the value property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setValue(String value) {
            this.value = value;
        }

        public boolean isSetValue() {
            return (this.value!= null);
        }

        /**
         * Gets the value of the direction property.
         * 
         * @return
         *     possible object is
         *     {@link Directions }
         *     
         */
        public Directions getDirection() {
            return direction;
        }

        /**
         * Sets the value of the direction property.
         * 
         * @param value
         *     allowed object is
         *     {@link Directions }
         *     
         */
        public void setDirection(Directions value) {
            this.direction = value;
        }

        public boolean isSetDirection() {
            return (this.direction!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("value", value).add("direction", direction).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(value, direction);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final OrderType.OrderKey o = ((OrderType.OrderKey) other);
            return (Objects.equal(value, o.value)&&Objects.equal(direction, o.direction));
        }

    }

}
