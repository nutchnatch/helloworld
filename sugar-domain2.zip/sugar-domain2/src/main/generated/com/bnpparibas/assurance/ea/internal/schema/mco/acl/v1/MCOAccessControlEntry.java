
package com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for MCOAccessControlEntry complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCOAccessControlEntry"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Principal" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded"/&gt;
 *         &lt;element name="Permission" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="Grant" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1}GrantType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCOAccessControlEntry", propOrder = {
    "principal",
    "permission",
    "grant"
})
@XmlSeeAlso({
    AccessControlEntry.class
})
public class MCOAccessControlEntry implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Principal", required = true)
    protected List<String> principal;
    @XmlElement(name = "Permission", required = true)
    protected String permission;
    @XmlElement(name = "Grant", required = true)
    @XmlSchemaType(name = "string")
    protected GrantType grant;

    /**
     * Default no-arg constructor
     * 
     */
    public MCOAccessControlEntry() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MCOAccessControlEntry(final List<String> principal, final String permission, final GrantType grant) {
        this.principal = principal;
        this.permission = permission;
        this.grant = grant;
    }

    /**
     * Gets the value of the principal property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the principal property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPrincipal().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getPrincipal() {
        if (principal == null) {
            principal = new ArrayList<String>();
        }
        return this.principal;
    }

    public boolean isSetPrincipal() {
        return ((this.principal!= null)&&(!this.principal.isEmpty()));
    }

    public void unsetPrincipal() {
        this.principal = null;
    }

    /**
     * Gets the value of the permission property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPermission() {
        return permission;
    }

    /**
     * Sets the value of the permission property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPermission(String value) {
        this.permission = value;
    }

    public boolean isSetPermission() {
        return (this.permission!= null);
    }

    /**
     * Gets the value of the grant property.
     * 
     * @return
     *     possible object is
     *     {@link GrantType }
     *     
     */
    public GrantType getGrant() {
        return grant;
    }

    /**
     * Sets the value of the grant property.
     * 
     * @param value
     *     allowed object is
     *     {@link GrantType }
     *     
     */
    public void setGrant(GrantType value) {
        this.grant = value;
    }

    public boolean isSetGrant() {
        return (this.grant!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("principal", principal).add("permission", permission).add("grant", grant).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(principal, permission, grant);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MCOAccessControlEntry o = ((MCOAccessControlEntry) other);
        return ((Objects.equal(principal, o.principal)&&Objects.equal(permission, o.permission))&&Objects.equal(grant, o.grant));
    }

}
