
package com.bnpparibas.assurance.ea.internal.schema.mco.search.v1;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Operators.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="Operators"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="NOT_EQUALS_TO"/&gt;
 *     &lt;enumeration value="EQUALS_TO"/&gt;
 *     &lt;enumeration value="CONTAINS"/&gt;
 *     &lt;enumeration value="LESS_THAN"/&gt;
 *     &lt;enumeration value="GREATER_THAN"/&gt;
 *     &lt;enumeration value="STARTS_WITH"/&gt;
 *     &lt;enumeration value="ENDS_WITH"/&gt;
 *     &lt;enumeration value="DISPLAY"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "Operators")
@XmlEnum
public enum Operators {

    NOT_EQUALS_TO,
    EQUALS_TO,
    CONTAINS,
    LESS_THAN,
    GREATER_THAN,
    STARTS_WITH,
    ENDS_WITH,
    DISPLAY;

    public String value() {
        return name();
    }

    public static Operators fromValue(String v) {
        return valueOf(v);
    }

}
