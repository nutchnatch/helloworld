
package com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.google.common.base.Objects;


/**
 * <p>Java class for MCOBasketRatio complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCOBasketRatio"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1}BasketId"/&gt;
 *         &lt;element name="numberOfOpened" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="numberOfClosed" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCOBasketRatio", propOrder = {
    "basketId",
    "numberOfOpened",
    "numberOfClosed"
})
@XmlSeeAlso({
    BasketRatio.class
})
public class MCOBasketRatio implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "BasketId", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1", required = true)
    protected BasketId basketId;
    protected long numberOfOpened;
    protected long numberOfClosed;

    /**
     * Default no-arg constructor
     * 
     */
    public MCOBasketRatio() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MCOBasketRatio(final BasketId basketId, final long numberOfOpened, final long numberOfClosed) {
        this.basketId = basketId;
        this.numberOfOpened = numberOfOpened;
        this.numberOfClosed = numberOfClosed;
    }

    /**
     * Gets the value of the basketId property.
     * 
     * @return
     *     possible object is
     *     {@link BasketId }
     *     
     */
    public BasketId getBasketId() {
        return basketId;
    }

    /**
     * Sets the value of the basketId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasketId }
     *     
     */
    public void setBasketId(BasketId value) {
        this.basketId = value;
    }

    public boolean isSetBasketId() {
        return (this.basketId!= null);
    }

    /**
     * Gets the value of the numberOfOpened property.
     * 
     */
    public long getNumberOfOpened() {
        return numberOfOpened;
    }

    /**
     * Sets the value of the numberOfOpened property.
     * 
     */
    public void setNumberOfOpened(long value) {
        this.numberOfOpened = value;
    }

    public boolean isSetNumberOfOpened() {
        return true;
    }

    /**
     * Gets the value of the numberOfClosed property.
     * 
     */
    public long getNumberOfClosed() {
        return numberOfClosed;
    }

    /**
     * Sets the value of the numberOfClosed property.
     * 
     */
    public void setNumberOfClosed(long value) {
        this.numberOfClosed = value;
    }

    public boolean isSetNumberOfClosed() {
        return true;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("basketId", basketId).add("numberOfOpened", numberOfOpened).add("numberOfClosed", numberOfClosed).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(basketId, numberOfOpened, numberOfClosed);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MCOBasketRatio o = ((MCOBasketRatio) other);
        return ((Objects.equal(basketId, o.basketId)&&Objects.equal(numberOfOpened, o.numberOfOpened))&&Objects.equal(numberOfClosed, o.numberOfClosed));
    }

}
