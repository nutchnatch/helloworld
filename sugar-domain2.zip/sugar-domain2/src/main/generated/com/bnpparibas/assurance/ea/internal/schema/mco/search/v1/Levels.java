
package com.bnpparibas.assurance.ea.internal.schema.mco.search.v1;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Levels.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="Levels"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="TAG"/&gt;
 *     &lt;enumeration value="DATA"/&gt;
 *     &lt;enumeration value="CHILD"/&gt;
 *     &lt;enumeration value="ATTRIBUTE"/&gt;
 *     &lt;enumeration value="QUICK"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "Levels")
@XmlEnum
public enum Levels {

    TAG,
    DATA,
    CHILD,
    ATTRIBUTE,
    QUICK;

    public String value() {
        return name();
    }

    public static Levels fromValue(String v) {
        return valueOf(v);
    }

}
