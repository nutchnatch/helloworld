
package com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tags;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.google.common.base.Objects;


/**
 * Document annotation
 * 				description
 * 			
 * 
 * <p>Java class for MCOFolderType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCOFolderType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolder/v1}FolderId"/&gt;
 *         &lt;element name="Data" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FolderDataType"/&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}Tags" minOccurs="0"/&gt;
 *         &lt;element name="ChildComponents"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1}Document" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                   &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1}Id" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="Scope" use="required"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;maxLength value="20"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCOFolderType", propOrder = {
    "folderId",
    "data",
    "tags",
    "childComponents"
})
@XmlSeeAlso({
    Folder.class
})
public class MCOFolderType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "FolderId", required = true)
    protected FolderId folderId;
    @XmlElement(name = "Data", required = true)
    protected FolderDataType data;
    @XmlElement(name = "Tags", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1", nillable = true)
    protected Tags tags;
    @XmlElement(name = "ChildComponents", required = true)
    protected MCOFolderType.ChildComponents childComponents;
    @XmlAttribute(name = "Scope", required = true)
    protected String scope;

    /**
     * Default no-arg constructor
     * 
     */
    public MCOFolderType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MCOFolderType(final FolderId folderId, final FolderDataType data, final Tags tags, final MCOFolderType.ChildComponents childComponents, final String scope) {
        this.folderId = folderId;
        this.data = data;
        this.tags = tags;
        this.childComponents = childComponents;
        this.scope = scope;
    }

    /**
     * Principal Identifier of the Folder
     * 					
     * 
     * @return
     *     possible object is
     *     {@link FolderId }
     *     
     */
    public FolderId getFolderId() {
        return folderId;
    }

    /**
     * Sets the value of the folderId property.
     * 
     * @param value
     *     allowed object is
     *     {@link FolderId }
     *     
     */
    public void setFolderId(FolderId value) {
        this.folderId = value;
    }

    public boolean isSetFolderId() {
        return (this.folderId!= null);
    }

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     {@link FolderDataType }
     *     
     */
    public FolderDataType getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     {@link FolderDataType }
     *     
     */
    public void setData(FolderDataType value) {
        this.data = value;
    }

    public boolean isSetData() {
        return (this.data!= null);
    }

    /**
     * Extension buckets
     * 						allowing for extensibility and act as
     * 						a container for adding
     * 						elements used for the indexation of
     * 						folders: folder type and other
     * 						elements that can defined in
     * 						another schema
     * 					
     * 
     * @return
     *     possible object is
     *     {@link Tags }
     *     
     */
    public Tags getTags() {
        return tags;
    }

    /**
     * Sets the value of the tags property.
     * 
     * @param value
     *     allowed object is
     *     {@link Tags }
     *     
     */
    public void setTags(Tags value) {
        this.tags = value;
    }

    public boolean isSetTags() {
        return (this.tags!= null);
    }

    /**
     * Gets the value of the childComponents property.
     * 
     * @return
     *     possible object is
     *     {@link MCOFolderType.ChildComponents }
     *     
     */
    public MCOFolderType.ChildComponents getChildComponents() {
        return childComponents;
    }

    /**
     * Sets the value of the childComponents property.
     * 
     * @param value
     *     allowed object is
     *     {@link MCOFolderType.ChildComponents }
     *     
     */
    public void setChildComponents(MCOFolderType.ChildComponents value) {
        this.childComponents = value;
    }

    public boolean isSetChildComponents() {
        return (this.childComponents!= null);
    }

    /**
     * Gets the value of the scope property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScope() {
        return scope;
    }

    /**
     * Sets the value of the scope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScope(String value) {
        this.scope = value;
    }

    public boolean isSetScope() {
        return (this.scope!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("folderId", folderId).add("data", data).add("tags", tags).add("childComponents", childComponents).add("scope", scope).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(folderId, data, tags, childComponents, scope);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MCOFolderType o = ((MCOFolderType) other);
        return ((((Objects.equal(folderId, o.folderId)&&Objects.equal(data, o.data))&&Objects.equal(tags, o.tags))&&Objects.equal(childComponents, o.childComponents))&&Objects.equal(scope, o.scope));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1}Document" maxOccurs="unbounded" minOccurs="0"/&gt;
     *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1}Id" maxOccurs="unbounded" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "document",
        "id"
    })
    public static class ChildComponents implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Document", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1")
        protected List<Document> document;
        @XmlElement(name = "Id", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1")
        protected List<Id> id;

        /**
         * Default no-arg constructor
         * 
         */
        public ChildComponents() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public ChildComponents(final List<Document> document, final List<Id> id) {
            this.document = document;
            this.id = id;
        }

        /**
         * To manag relationships between : component and
         * 									folder
         * 								Gets the value of the document property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the document property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDocument().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Document }
         * 
         * 
         */
        public List<Document> getDocument() {
            if (document == null) {
                document = new ArrayList<Document>();
            }
            return this.document;
        }

        public boolean isSetDocument() {
            return ((this.document!= null)&&(!this.document.isEmpty()));
        }

        public void unsetDocument() {
            this.document = null;
        }

        /**
         * Principal identifer of the document/envelope
         * 									generated by the Master Document Management System. I
         * 								Gets the value of the id property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the id property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getId().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Id }
         * 
         * 
         */
        public List<Id> getId() {
            if (id == null) {
                id = new ArrayList<Id>();
            }
            return this.id;
        }

        public boolean isSetId() {
            return ((this.id!= null)&&(!this.id.isEmpty()));
        }

        public void unsetId() {
            this.id = null;
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("document", document).add("id", id).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(document, id);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final MCOFolderType.ChildComponents o = ((MCOFolderType.ChildComponents) other);
            return (Objects.equal(document, o.document)&&Objects.equal(id, o.id));
        }

    }

}
