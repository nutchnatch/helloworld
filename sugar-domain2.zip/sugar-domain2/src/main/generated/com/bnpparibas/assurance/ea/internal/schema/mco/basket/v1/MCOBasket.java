
package com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.google.common.base.Objects;


/**
 * <p>Java class for MCOBasket complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCOBasket"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1}BasketId"/&gt;
 *         &lt;element name="DisplayName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1}MCOI18NLabel" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="SymbolicName"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="Scope" use="required"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;maxLength value="20"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCOBasket", propOrder = {
    "basketId",
    "displayName"
})
@XmlSeeAlso({
    Basket.class
})
public class MCOBasket implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "BasketId", required = true)
    protected BasketId basketId;
    @XmlElement(name = "DisplayName", required = true)
    protected List<MCOI18NLabel> displayName;
    @XmlAttribute(name = "SymbolicName")
    protected String symbolicName;
    @XmlAttribute(name = "Scope", required = true)
    protected String scope;

    /**
     * Default no-arg constructor
     * 
     */
    public MCOBasket() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MCOBasket(final BasketId basketId, final List<MCOI18NLabel> displayName, final String symbolicName, final String scope) {
        this.basketId = basketId;
        this.displayName = displayName;
        this.symbolicName = symbolicName;
        this.scope = scope;
    }

    /**
     * Gets the value of the basketId property.
     * 
     * @return
     *     possible object is
     *     {@link BasketId }
     *     
     */
    public BasketId getBasketId() {
        return basketId;
    }

    /**
     * Sets the value of the basketId property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasketId }
     *     
     */
    public void setBasketId(BasketId value) {
        this.basketId = value;
    }

    public boolean isSetBasketId() {
        return (this.basketId!= null);
    }

    /**
     * Gets the value of the displayName property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the displayName property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDisplayName().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MCOI18NLabel }
     * 
     * 
     */
    public List<MCOI18NLabel> getDisplayName() {
        if (displayName == null) {
            displayName = new ArrayList<MCOI18NLabel>();
        }
        return this.displayName;
    }

    public boolean isSetDisplayName() {
        return ((this.displayName!= null)&&(!this.displayName.isEmpty()));
    }

    public void unsetDisplayName() {
        this.displayName = null;
    }

    /**
     * Gets the value of the symbolicName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSymbolicName() {
        return symbolicName;
    }

    /**
     * Sets the value of the symbolicName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSymbolicName(String value) {
        this.symbolicName = value;
    }

    public boolean isSetSymbolicName() {
        return (this.symbolicName!= null);
    }

    /**
     * Gets the value of the scope property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScope() {
        return scope;
    }

    /**
     * Sets the value of the scope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScope(String value) {
        this.scope = value;
    }

    public boolean isSetScope() {
        return (this.scope!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("basketId", basketId).add("displayName", displayName).add("symbolicName", symbolicName).add("scope", scope).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(basketId, displayName, symbolicName, scope);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MCOBasket o = ((MCOBasket) other);
        return (((Objects.equal(basketId, o.basketId)&&Objects.equal(displayName, o.displayName))&&Objects.equal(symbolicName, o.symbolicName))&&Objects.equal(scope, o.scope));
    }

}
