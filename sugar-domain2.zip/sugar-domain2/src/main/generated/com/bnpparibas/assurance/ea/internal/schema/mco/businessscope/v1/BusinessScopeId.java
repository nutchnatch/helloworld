
package com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.EDMS2IdentificationType;
import com.google.common.base.Objects;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1&gt;EDMS2IdentificationType"&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "BusinessScopeId")
public class BusinessScopeId
    extends EDMS2IdentificationType
    implements Serializable
{

    private final static long serialVersionUID = 1L;

    /**
     * Default no-arg constructor
     * 
     */
    public BusinessScopeId() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public BusinessScopeId(final String value, final String issuer, final String scheme) {
        super(value, issuer, scheme);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("value", value).add("issuer", issuer).add("scheme", scheme).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(value, issuer, scheme);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final BusinessScopeId o = ((BusinessScopeId) other);
        return ((Objects.equal(value, o.value)&&Objects.equal(issuer, o.issuer))&&Objects.equal(scheme, o.scheme));
    }

}
