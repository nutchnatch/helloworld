
package com.bnpparibas.assurance.ea.internal.schema.mco.search.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for QueryType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="QueryType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="filter" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/search/v1}FilterType" minOccurs="0"/&gt;
 *         &lt;element name="order" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/search/v1}OrderType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="scope" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="pageStart" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="pageSize" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="maxLimitSearch" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="lang" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "QueryType", propOrder = {
    "filter",
    "order"
})
@XmlSeeAlso({
    Query.class
})
public class QueryType implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected FilterType filter;
    protected OrderType order;
    @XmlAttribute(name = "scope", required = true)
    protected String scope;
    @XmlAttribute(name = "pageStart", required = true)
    protected int pageStart;
    @XmlAttribute(name = "pageSize", required = true)
    protected int pageSize;
    @XmlAttribute(name = "maxLimitSearch")
    protected Long maxLimitSearch;
    @XmlAttribute(name = "lang")
    protected String lang;

    /**
     * Default no-arg constructor
     * 
     */
    public QueryType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public QueryType(final FilterType filter, final OrderType order, final String scope, final int pageStart, final int pageSize, final Long maxLimitSearch, final String lang) {
        this.filter = filter;
        this.order = order;
        this.scope = scope;
        this.pageStart = pageStart;
        this.pageSize = pageSize;
        this.maxLimitSearch = maxLimitSearch;
        this.lang = lang;
    }

    /**
     * Gets the value of the filter property.
     * 
     * @return
     *     possible object is
     *     {@link FilterType }
     *     
     */
    public FilterType getFilter() {
        return filter;
    }

    /**
     * Sets the value of the filter property.
     * 
     * @param value
     *     allowed object is
     *     {@link FilterType }
     *     
     */
    public void setFilter(FilterType value) {
        this.filter = value;
    }

    public boolean isSetFilter() {
        return (this.filter!= null);
    }

    /**
     * Gets the value of the order property.
     * 
     * @return
     *     possible object is
     *     {@link OrderType }
     *     
     */
    public OrderType getOrder() {
        return order;
    }

    /**
     * Sets the value of the order property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrderType }
     *     
     */
    public void setOrder(OrderType value) {
        this.order = value;
    }

    public boolean isSetOrder() {
        return (this.order!= null);
    }

    /**
     * Gets the value of the scope property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScope() {
        return scope;
    }

    /**
     * Sets the value of the scope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScope(String value) {
        this.scope = value;
    }

    public boolean isSetScope() {
        return (this.scope!= null);
    }

    /**
     * Gets the value of the pageStart property.
     * 
     */
    public int getPageStart() {
        return pageStart;
    }

    /**
     * Sets the value of the pageStart property.
     * 
     */
    public void setPageStart(int value) {
        this.pageStart = value;
    }

    public boolean isSetPageStart() {
        return true;
    }

    /**
     * Gets the value of the pageSize property.
     * 
     */
    public int getPageSize() {
        return pageSize;
    }

    /**
     * Sets the value of the pageSize property.
     * 
     */
    public void setPageSize(int value) {
        this.pageSize = value;
    }

    public boolean isSetPageSize() {
        return true;
    }

    /**
     * Gets the value of the maxLimitSearch property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public long getMaxLimitSearch() {
        return maxLimitSearch;
    }

    /**
     * Sets the value of the maxLimitSearch property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setMaxLimitSearch(long value) {
        this.maxLimitSearch = value;
    }

    public boolean isSetMaxLimitSearch() {
        return (this.maxLimitSearch!= null);
    }

    public void unsetMaxLimitSearch() {
        this.maxLimitSearch = null;
    }

    /**
     * Gets the value of the lang property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * Sets the value of the lang property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

    public boolean isSetLang() {
        return (this.lang!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("filter", filter).add("order", order).add("scope", scope).add("pageStart", pageStart).add("pageSize", pageSize).add("maxLimitSearch", maxLimitSearch).add("lang", lang).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(filter, order, scope, pageStart, pageSize, maxLimitSearch, lang);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final QueryType o = ((QueryType) other);
        return ((((((Objects.equal(filter, o.filter)&&Objects.equal(order, o.order))&&Objects.equal(scope, o.scope))&&Objects.equal(pageStart, o.pageStart))&&Objects.equal(pageSize, o.pageSize))&&Objects.equal(maxLimitSearch, o.maxLimitSearch))&&Objects.equal(lang, o.lang));
    }

}
