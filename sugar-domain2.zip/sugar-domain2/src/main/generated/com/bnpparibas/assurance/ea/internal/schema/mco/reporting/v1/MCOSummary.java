
package com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for MCOSummary complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCOSummary"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="numberOfDocuments" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="numbereOfEnvelopes" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="numbereOfFolders" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="numberOfTasks" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCOSummary", propOrder = {
    "numberOfDocuments",
    "numbereOfEnvelopes",
    "numbereOfFolders",
    "numberOfTasks"
})
@XmlSeeAlso({
    Summary.class
})
public class MCOSummary implements Serializable
{

    private final static long serialVersionUID = 1L;
    protected long numberOfDocuments;
    protected long numbereOfEnvelopes;
    protected long numbereOfFolders;
    protected long numberOfTasks;

    /**
     * Default no-arg constructor
     * 
     */
    public MCOSummary() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MCOSummary(final long numberOfDocuments, final long numbereOfEnvelopes, final long numbereOfFolders, final long numberOfTasks) {
        this.numberOfDocuments = numberOfDocuments;
        this.numbereOfEnvelopes = numbereOfEnvelopes;
        this.numbereOfFolders = numbereOfFolders;
        this.numberOfTasks = numberOfTasks;
    }

    /**
     * Gets the value of the numberOfDocuments property.
     * 
     */
    public long getNumberOfDocuments() {
        return numberOfDocuments;
    }

    /**
     * Sets the value of the numberOfDocuments property.
     * 
     */
    public void setNumberOfDocuments(long value) {
        this.numberOfDocuments = value;
    }

    public boolean isSetNumberOfDocuments() {
        return true;
    }

    /**
     * Gets the value of the numbereOfEnvelopes property.
     * 
     */
    public long getNumbereOfEnvelopes() {
        return numbereOfEnvelopes;
    }

    /**
     * Sets the value of the numbereOfEnvelopes property.
     * 
     */
    public void setNumbereOfEnvelopes(long value) {
        this.numbereOfEnvelopes = value;
    }

    public boolean isSetNumbereOfEnvelopes() {
        return true;
    }

    /**
     * Gets the value of the numbereOfFolders property.
     * 
     */
    public long getNumbereOfFolders() {
        return numbereOfFolders;
    }

    /**
     * Sets the value of the numbereOfFolders property.
     * 
     */
    public void setNumbereOfFolders(long value) {
        this.numbereOfFolders = value;
    }

    public boolean isSetNumbereOfFolders() {
        return true;
    }

    /**
     * Gets the value of the numberOfTasks property.
     * 
     */
    public long getNumberOfTasks() {
        return numberOfTasks;
    }

    /**
     * Sets the value of the numberOfTasks property.
     * 
     */
    public void setNumberOfTasks(long value) {
        this.numberOfTasks = value;
    }

    public boolean isSetNumberOfTasks() {
        return true;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("numberOfDocuments", numberOfDocuments).add("numbereOfEnvelopes", numbereOfEnvelopes).add("numbereOfFolders", numbereOfFolders).add("numberOfTasks", numberOfTasks).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(numberOfDocuments, numbereOfEnvelopes, numbereOfFolders, numberOfTasks);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MCOSummary o = ((MCOSummary) other);
        return (((Objects.equal(numberOfDocuments, o.numberOfDocuments)&&Objects.equal(numbereOfEnvelopes, o.numbereOfEnvelopes))&&Objects.equal(numbereOfFolders, o.numbereOfFolders))&&Objects.equal(numberOfTasks, o.numberOfTasks));
    }

}
