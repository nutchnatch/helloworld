
package com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1;

import java.io.Serializable;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.google.common.base.Objects;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1}MCOBasket"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "Basket")
public class Basket
    extends MCOBasket
    implements Serializable
{

    private final static long serialVersionUID = 1L;

    /**
     * Default no-arg constructor
     * 
     */
    public Basket() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public Basket(final BasketId basketId, final List<MCOI18NLabel> displayName, final String symbolicName, final String scope) {
        super(basketId, displayName, symbolicName, scope);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("basketId", basketId).add("displayName", displayName).add("symbolicName", symbolicName).add("scope", scope).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(basketId, displayName, symbolicName, scope);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final Basket o = ((Basket) other);
        return (((Objects.equal(basketId, o.basketId)&&Objects.equal(displayName, o.displayName))&&Objects.equal(symbolicName, o.symbolicName))&&Objects.equal(scope, o.scope));
    }

}
