
package com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DurationType;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOTagReference;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * <p>Java class for MCODocumentClassType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCODocumentClassType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClassId"/&gt;
 *         &lt;element name="ShortLabel" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1}MCOI18NLabel" maxOccurs="unbounded"/&gt;
 *         &lt;element name="LongLabel" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="Scope"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="20"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Active" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="Category" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}Category"/&gt;
 *         &lt;element name="Status" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Code"&gt;
 *                     &lt;simpleType&gt;
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                         &lt;maxLength value="50"/&gt;
 *                       &lt;/restriction&gt;
 *                     &lt;/simpleType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="EffectiveDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RetentionDuration" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="CreateDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="LastUpdateDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="TagReference" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/tagclass/v1}MCOTagReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="AllowedChildren" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClassId"/&gt;
 *                   &lt;element name="SymbolicName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FirstLevel" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCODocumentClassType", propOrder = {
    "classId",
    "shortLabel",
    "longLabel",
    "scope",
    "active",
    "category",
    "status",
    "retentionDuration",
    "createDate",
    "lastUpdateDate",
    "tagReference",
    "allowedChildren",
    "firstLevel"
})
@XmlSeeAlso({
    DocumentClass.class
})
public class MCODocumentClassType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ClassId", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1", required = true)
    protected ClassId classId;
    @XmlElement(name = "ShortLabel", required = true)
    protected List<MCOI18NLabel> shortLabel;
    @XmlElement(name = "LongLabel", required = true)
    protected String longLabel;
    @XmlElement(name = "Scope", required = true)
    protected String scope;
    @XmlElement(name = "Active")
    protected boolean active;
    @XmlElement(name = "Category", required = true)
    @XmlSchemaType(name = "string")
    protected Category category;
    @XmlElement(name = "Status")
    protected MCODocumentClassType.Status status;
    @XmlElement(name = "RetentionDuration")
    protected DurationType retentionDuration;
    @XmlElement(name = "CreateDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date createDate;
    @XmlElement(name = "LastUpdateDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date lastUpdateDate;
    @XmlElement(name = "TagReference")
    protected List<MCOTagReference> tagReference;
    @XmlElement(name = "AllowedChildren")
    protected List<MCODocumentClassType.AllowedChildren> allowedChildren;
    @XmlElement(name = "FirstLevel")
    protected boolean firstLevel;

    /**
     * Default no-arg constructor
     * 
     */
    public MCODocumentClassType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MCODocumentClassType(final ClassId classId, final List<MCOI18NLabel> shortLabel, final String longLabel, final String scope, final boolean active, final Category category, final MCODocumentClassType.Status status, final DurationType retentionDuration, final Date createDate, final Date lastUpdateDate, final List<MCOTagReference> tagReference, final List<MCODocumentClassType.AllowedChildren> allowedChildren, final boolean firstLevel) {
        this.classId = classId;
        this.shortLabel = shortLabel;
        this.longLabel = longLabel;
        this.scope = scope;
        this.active = active;
        this.category = category;
        this.status = status;
        this.retentionDuration = retentionDuration;
        this.createDate = createDate;
        this.lastUpdateDate = lastUpdateDate;
        this.tagReference = tagReference;
        this.allowedChildren = allowedChildren;
        this.firstLevel = firstLevel;
    }

    /**
     * Identification of the document class
     * 					
     * 
     * @return
     *     possible object is
     *     {@link ClassId }
     *     
     */
    public ClassId getClassId() {
        return classId;
    }

    /**
     * Sets the value of the classId property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassId }
     *     
     */
    public void setClassId(ClassId value) {
        this.classId = value;
    }

    public boolean isSetClassId() {
        return (this.classId!= null);
    }

    /**
     * Gets the value of the shortLabel property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the shortLabel property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getShortLabel().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MCOI18NLabel }
     * 
     * 
     */
    public List<MCOI18NLabel> getShortLabel() {
        if (shortLabel == null) {
            shortLabel = new ArrayList<MCOI18NLabel>();
        }
        return this.shortLabel;
    }

    public boolean isSetShortLabel() {
        return ((this.shortLabel!= null)&&(!this.shortLabel.isEmpty()));
    }

    public void unsetShortLabel() {
        this.shortLabel = null;
    }

    /**
     * Gets the value of the longLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLongLabel() {
        return longLabel;
    }

    /**
     * Sets the value of the longLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLongLabel(String value) {
        this.longLabel = value;
    }

    public boolean isSetLongLabel() {
        return (this.longLabel!= null);
    }

    /**
     * Gets the value of the scope property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScope() {
        return scope;
    }

    /**
     * Sets the value of the scope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScope(String value) {
        this.scope = value;
    }

    public boolean isSetScope() {
        return (this.scope!= null);
    }

    /**
     * Gets the value of the active property.
     * 
     */
    public boolean isActive() {
        return active;
    }

    /**
     * Sets the value of the active property.
     * 
     */
    public void setActive(boolean value) {
        this.active = value;
    }

    public boolean isSetActive() {
        return true;
    }

    /**
     * Gets the value of the category property.
     * 
     * @return
     *     possible object is
     *     {@link Category }
     *     
     */
    public Category getCategory() {
        return category;
    }

    /**
     * Sets the value of the category property.
     * 
     * @param value
     *     allowed object is
     *     {@link Category }
     *     
     */
    public void setCategory(Category value) {
        this.category = value;
    }

    public boolean isSetCategory() {
        return (this.category!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link MCODocumentClassType.Status }
     *     
     */
    public MCODocumentClassType.Status getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link MCODocumentClassType.Status }
     *     
     */
    public void setStatus(MCODocumentClassType.Status value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    /**
     * Gets the value of the retentionDuration property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getRetentionDuration() {
        return retentionDuration;
    }

    /**
     * Sets the value of the retentionDuration property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setRetentionDuration(DurationType value) {
        this.retentionDuration = value;
    }

    public boolean isSetRetentionDuration() {
        return (this.retentionDuration!= null);
    }

    /**
     * Gets the value of the createDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * Sets the value of the createDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreateDate(Date value) {
        this.createDate = value;
    }

    public boolean isSetCreateDate() {
        return (this.createDate!= null);
    }

    /**
     * Gets the value of the lastUpdateDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    /**
     * Sets the value of the lastUpdateDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastUpdateDate(Date value) {
        this.lastUpdateDate = value;
    }

    public boolean isSetLastUpdateDate() {
        return (this.lastUpdateDate!= null);
    }

    /**
     * Gets the value of the tagReference property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tagReference property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTagReference().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MCOTagReference }
     * 
     * 
     */
    public List<MCOTagReference> getTagReference() {
        if (tagReference == null) {
            tagReference = new ArrayList<MCOTagReference>();
        }
        return this.tagReference;
    }

    public boolean isSetTagReference() {
        return ((this.tagReference!= null)&&(!this.tagReference.isEmpty()));
    }

    public void unsetTagReference() {
        this.tagReference = null;
    }

    /**
     * Gets the value of the allowedChildren property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the allowedChildren property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAllowedChildren().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MCODocumentClassType.AllowedChildren }
     * 
     * 
     */
    public List<MCODocumentClassType.AllowedChildren> getAllowedChildren() {
        if (allowedChildren == null) {
            allowedChildren = new ArrayList<MCODocumentClassType.AllowedChildren>();
        }
        return this.allowedChildren;
    }

    public boolean isSetAllowedChildren() {
        return ((this.allowedChildren!= null)&&(!this.allowedChildren.isEmpty()));
    }

    public void unsetAllowedChildren() {
        this.allowedChildren = null;
    }

    /**
     * Gets the value of the firstLevel property.
     * 
     */
    public boolean isFirstLevel() {
        return firstLevel;
    }

    /**
     * Sets the value of the firstLevel property.
     * 
     */
    public void setFirstLevel(boolean value) {
        this.firstLevel = value;
    }

    public boolean isSetFirstLevel() {
        return true;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("classId", classId).add("shortLabel", shortLabel).add("longLabel", longLabel).add("scope", scope).add("active", active).add("category", category).add("status", status).add("retentionDuration", retentionDuration).add("createDate", createDate).add("lastUpdateDate", lastUpdateDate).add("tagReference", tagReference).add("allowedChildren", allowedChildren).add("firstLevel", firstLevel).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(classId, shortLabel, longLabel, scope, active, category, status, retentionDuration, createDate, lastUpdateDate, tagReference, allowedChildren, firstLevel);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MCODocumentClassType o = ((MCODocumentClassType) other);
        return ((((((((((((Objects.equal(classId, o.classId)&&Objects.equal(shortLabel, o.shortLabel))&&Objects.equal(longLabel, o.longLabel))&&Objects.equal(scope, o.scope))&&Objects.equal(active, o.active))&&Objects.equal(category, o.category))&&Objects.equal(status, o.status))&&Objects.equal(retentionDuration, o.retentionDuration))&&Objects.equal(createDate, o.createDate))&&Objects.equal(lastUpdateDate, o.lastUpdateDate))&&Objects.equal(tagReference, o.tagReference))&&Objects.equal(allowedChildren, o.allowedChildren))&&Objects.equal(firstLevel, o.firstLevel));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClassId"/&gt;
     *         &lt;element name="SymbolicName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "classId",
        "symbolicName"
    })
    public static class AllowedChildren implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "ClassId", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1", required = true)
        protected ClassId classId;
        @XmlElement(name = "SymbolicName", required = true)
        protected String symbolicName;

        /**
         * Default no-arg constructor
         * 
         */
        public AllowedChildren() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public AllowedChildren(final ClassId classId, final String symbolicName) {
            this.classId = classId;
            this.symbolicName = symbolicName;
        }

        /**
         * Gets the value of the classId property.
         * 
         * @return
         *     possible object is
         *     {@link ClassId }
         *     
         */
        public ClassId getClassId() {
            return classId;
        }

        /**
         * Sets the value of the classId property.
         * 
         * @param value
         *     allowed object is
         *     {@link ClassId }
         *     
         */
        public void setClassId(ClassId value) {
            this.classId = value;
        }

        public boolean isSetClassId() {
            return (this.classId!= null);
        }

        /**
         * Gets the value of the symbolicName property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSymbolicName() {
            return symbolicName;
        }

        /**
         * Sets the value of the symbolicName property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSymbolicName(String value) {
            this.symbolicName = value;
        }

        public boolean isSetSymbolicName() {
            return (this.symbolicName!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("classId", classId).add("symbolicName", symbolicName).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(classId, symbolicName);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final MCODocumentClassType.AllowedChildren o = ((MCODocumentClassType.AllowedChildren) other);
            return (Objects.equal(classId, o.classId)&&Objects.equal(symbolicName, o.symbolicName));
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Code"&gt;
     *           &lt;simpleType&gt;
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *               &lt;maxLength value="50"/&gt;
     *             &lt;/restriction&gt;
     *           &lt;/simpleType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="EffectiveDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "code",
        "effectiveDate"
    })
    public static class Status implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Code", required = true)
        protected String code;
        @XmlElement(name = "EffectiveDate", required = true, type = String.class)
        @XmlJavaTypeAdapter(Adapter1 .class)
        @XmlSchemaType(name = "dateTime")
        protected Date effectiveDate;

        /**
         * Default no-arg constructor
         * 
         */
        public Status() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public Status(final String code, final Date effectiveDate) {
            this.code = code;
            this.effectiveDate = effectiveDate;
        }

        /**
         * Gets the value of the code property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCode() {
            return code;
        }

        /**
         * Sets the value of the code property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCode(String value) {
            this.code = value;
        }

        public boolean isSetCode() {
            return (this.code!= null);
        }

        /**
         * Gets the value of the effectiveDate property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public Date getEffectiveDate() {
            return effectiveDate;
        }

        /**
         * Sets the value of the effectiveDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setEffectiveDate(Date value) {
            this.effectiveDate = value;
        }

        public boolean isSetEffectiveDate() {
            return (this.effectiveDate!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("code", code).add("effectiveDate", effectiveDate).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(code, effectiveDate);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final MCODocumentClassType.Status o = ((MCODocumentClassType.Status) other);
            return (Objects.equal(code, o.code)&&Objects.equal(effectiveDate, o.effectiveDate));
        }

    }

}
