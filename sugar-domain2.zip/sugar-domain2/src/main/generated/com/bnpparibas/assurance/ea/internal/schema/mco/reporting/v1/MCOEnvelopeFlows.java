
package com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.google.common.base.Objects;


/**
 * <p>Java class for MCOEnvelopeFlows complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCOEnvelopeFlows"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="directionCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClassId"/&gt;
 *         &lt;element name="numberOfEnvelopes" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="numberOfDocuments" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *         &lt;element name="sizeOfDocuments" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCOEnvelopeFlows", propOrder = {
    "directionCode",
    "classId",
    "numberOfEnvelopes",
    "numberOfDocuments",
    "sizeOfDocuments"
})
@XmlSeeAlso({
    EnvelopeFlows.class
})
public class MCOEnvelopeFlows implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(required = true)
    protected String directionCode;
    @XmlElement(name = "ClassId", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1", required = true)
    protected ClassId classId;
    protected long numberOfEnvelopes;
    protected long numberOfDocuments;
    protected long sizeOfDocuments;

    /**
     * Default no-arg constructor
     * 
     */
    public MCOEnvelopeFlows() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MCOEnvelopeFlows(final String directionCode, final ClassId classId, final long numberOfEnvelopes, final long numberOfDocuments, final long sizeOfDocuments) {
        this.directionCode = directionCode;
        this.classId = classId;
        this.numberOfEnvelopes = numberOfEnvelopes;
        this.numberOfDocuments = numberOfDocuments;
        this.sizeOfDocuments = sizeOfDocuments;
    }

    /**
     * Gets the value of the directionCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDirectionCode() {
        return directionCode;
    }

    /**
     * Sets the value of the directionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDirectionCode(String value) {
        this.directionCode = value;
    }

    public boolean isSetDirectionCode() {
        return (this.directionCode!= null);
    }

    /**
     * Gets the value of the classId property.
     * 
     * @return
     *     possible object is
     *     {@link ClassId }
     *     
     */
    public ClassId getClassId() {
        return classId;
    }

    /**
     * Sets the value of the classId property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassId }
     *     
     */
    public void setClassId(ClassId value) {
        this.classId = value;
    }

    public boolean isSetClassId() {
        return (this.classId!= null);
    }

    /**
     * Gets the value of the numberOfEnvelopes property.
     * 
     */
    public long getNumberOfEnvelopes() {
        return numberOfEnvelopes;
    }

    /**
     * Sets the value of the numberOfEnvelopes property.
     * 
     */
    public void setNumberOfEnvelopes(long value) {
        this.numberOfEnvelopes = value;
    }

    public boolean isSetNumberOfEnvelopes() {
        return true;
    }

    /**
     * Gets the value of the numberOfDocuments property.
     * 
     */
    public long getNumberOfDocuments() {
        return numberOfDocuments;
    }

    /**
     * Sets the value of the numberOfDocuments property.
     * 
     */
    public void setNumberOfDocuments(long value) {
        this.numberOfDocuments = value;
    }

    public boolean isSetNumberOfDocuments() {
        return true;
    }

    /**
     * Gets the value of the sizeOfDocuments property.
     * 
     */
    public long getSizeOfDocuments() {
        return sizeOfDocuments;
    }

    /**
     * Sets the value of the sizeOfDocuments property.
     * 
     */
    public void setSizeOfDocuments(long value) {
        this.sizeOfDocuments = value;
    }

    public boolean isSetSizeOfDocuments() {
        return true;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("directionCode", directionCode).add("classId", classId).add("numberOfEnvelopes", numberOfEnvelopes).add("numberOfDocuments", numberOfDocuments).add("sizeOfDocuments", sizeOfDocuments).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(directionCode, classId, numberOfEnvelopes, numberOfDocuments, sizeOfDocuments);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MCOEnvelopeFlows o = ((MCOEnvelopeFlows) other);
        return ((((Objects.equal(directionCode, o.directionCode)&&Objects.equal(classId, o.classId))&&Objects.equal(numberOfEnvelopes, o.numberOfEnvelopes))&&Objects.equal(numberOfDocuments, o.numberOfDocuments))&&Objects.equal(sizeOfDocuments, o.sizeOfDocuments));
    }

}
