
package com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DurationType;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOTagReference;
import com.google.common.base.Objects;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolderclass/v1}MCOFolderTypeClass"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "FolderClass")
public class FolderClass
    extends MCOFolderTypeClass
    implements Serializable
{

    private final static long serialVersionUID = 1L;

    /**
     * Default no-arg constructor
     * 
     */
    public FolderClass() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FolderClass(final ClassId classId, final String type, final List<MCOI18NLabel> shortLabel, final String longLabel, final DurationType retentionDuration, final Date creationDate, final Date updateDate, final boolean active, final List<MCOTagReference> tagReference, final String scope) {
        super(classId, type, shortLabel, longLabel, retentionDuration, creationDate, updateDate, active, tagReference, scope);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("classId", classId).add("type", type).add("shortLabel", shortLabel).add("longLabel", longLabel).add("retentionDuration", retentionDuration).add("creationDate", creationDate).add("updateDate", updateDate).add("active", active).add("tagReference", tagReference).add("scope", scope).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(classId, type, shortLabel, longLabel, retentionDuration, creationDate, updateDate, active, tagReference, scope);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FolderClass o = ((FolderClass) other);
        return (((((((((Objects.equal(classId, o.classId)&&Objects.equal(type, o.type))&&Objects.equal(shortLabel, o.shortLabel))&&Objects.equal(longLabel, o.longLabel))&&Objects.equal(retentionDuration, o.retentionDuration))&&Objects.equal(creationDate, o.creationDate))&&Objects.equal(updateDate, o.updateDate))&&Objects.equal(active, o.active))&&Objects.equal(tagReference, o.tagReference))&&Objects.equal(scope, o.scope));
    }

}
