
package com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Reference to a usage of this Tag in a DocuemntClass or FolderClass 
 * 			
 * 
 * <p>Java class for MCOTagReference complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCOTagReference"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;attribute name="symbolicName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="mandatory" type="{http://www.w3.org/2001/XMLSchema}boolean" /&gt;
 *       &lt;attribute name="multivalued" type="{http://www.w3.org/2001/XMLSchema}boolean" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCOTagReference")
public class MCOTagReference implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlAttribute(name = "symbolicName")
    protected String symbolicName;
    @XmlAttribute(name = "mandatory")
    protected Boolean mandatory;
    @XmlAttribute(name = "multivalued")
    protected Boolean multivalued;

    /**
     * Default no-arg constructor
     * 
     */
    public MCOTagReference() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MCOTagReference(final String symbolicName, final Boolean mandatory, final Boolean multivalued) {
        this.symbolicName = symbolicName;
        this.mandatory = mandatory;
        this.multivalued = multivalued;
    }

    /**
     * Gets the value of the symbolicName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSymbolicName() {
        return symbolicName;
    }

    /**
     * Sets the value of the symbolicName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSymbolicName(String value) {
        this.symbolicName = value;
    }

    public boolean isSetSymbolicName() {
        return (this.symbolicName!= null);
    }

    /**
     * Gets the value of the mandatory property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isMandatory() {
        return mandatory;
    }

    /**
     * Sets the value of the mandatory property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMandatory(boolean value) {
        this.mandatory = value;
    }

    public boolean isSetMandatory() {
        return (this.mandatory!= null);
    }

    public void unsetMandatory() {
        this.mandatory = null;
    }

    /**
     * Gets the value of the multivalued property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public boolean isMultivalued() {
        return multivalued;
    }

    /**
     * Sets the value of the multivalued property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMultivalued(boolean value) {
        this.multivalued = value;
    }

    public boolean isSetMultivalued() {
        return (this.multivalued!= null);
    }

    public void unsetMultivalued() {
        this.multivalued = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("symbolicName", symbolicName).add("mandatory", mandatory).add("multivalued", multivalued).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(symbolicName, mandatory, multivalued);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MCOTagReference o = ((MCOTagReference) other);
        return ((Objects.equal(symbolicName, o.symbolicName)&&Objects.equal(mandatory, o.mandatory))&&Objects.equal(multivalued, o.multivalued));
    }

}
