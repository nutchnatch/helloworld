
package com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1}MCOAccessControlList"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "AccessControlList")
public class AccessControlList
    extends MCOAccessControlList
    implements Serializable
{

    private final static long serialVersionUID = 1L;

    /**
     * Default no-arg constructor
     * 
     */
    public AccessControlList() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public AccessControlList(final AclId aclId, final Date creatnDate, final List<AccessControlEntry> accessControlEntry, final String name, final String scope) {
        super(aclId, creatnDate, accessControlEntry, name, scope);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("aclId", aclId).add("creatnDate", creatnDate).add("accessControlEntry", accessControlEntry).add("name", name).add("scope", scope).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(aclId, creatnDate, accessControlEntry, name, scope);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final AccessControlList o = ((AccessControlList) other);
        return ((((Objects.equal(aclId, o.aclId)&&Objects.equal(creatnDate, o.creatnDate))&&Objects.equal(accessControlEntry, o.accessControlEntry))&&Objects.equal(name, o.name))&&Objects.equal(scope, o.scope));
    }

}
