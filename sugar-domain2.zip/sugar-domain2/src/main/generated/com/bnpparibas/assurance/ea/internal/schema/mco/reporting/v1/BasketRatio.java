
package com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.google.common.base.Objects;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://ea.assurance.bnpparibas.com/internal/schema/mco/reporting/v1}MCOBasketRatio"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "BasketRatio")
public class BasketRatio
    extends MCOBasketRatio
    implements Serializable
{

    private final static long serialVersionUID = 1L;

    /**
     * Default no-arg constructor
     * 
     */
    public BasketRatio() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public BasketRatio(final BasketId basketId, final long numberOfOpened, final long numberOfClosed) {
        super(basketId, numberOfOpened, numberOfClosed);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("basketId", basketId).add("numberOfOpened", numberOfOpened).add("numberOfClosed", numberOfClosed).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(basketId, numberOfOpened, numberOfClosed);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final BasketRatio o = ((BasketRatio) other);
        return ((Objects.equal(basketId, o.basketId)&&Objects.equal(numberOfOpened, o.numberOfOpened))&&Objects.equal(numberOfClosed, o.numberOfClosed));
    }

}
