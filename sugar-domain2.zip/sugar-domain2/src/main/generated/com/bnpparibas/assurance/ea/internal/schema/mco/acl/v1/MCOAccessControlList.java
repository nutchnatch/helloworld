
package com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * <p>Java class for MCOAccessControlList complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCOAccessControlList"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1}AclId"/&gt;
 *         &lt;element name="CreatnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1}AccessControlEntry" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="Name"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *       &lt;attribute name="Scope" use="required"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;maxLength value="20"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCOAccessControlList", propOrder = {
    "aclId",
    "creatnDate",
    "accessControlEntry"
})
@XmlSeeAlso({
    AccessControlList.class
})
public class MCOAccessControlList implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "AclId", required = true)
    protected AclId aclId;
    @XmlElement(name = "CreatnDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date creatnDate;
    @XmlElement(name = "AccessControlEntry")
    protected List<AccessControlEntry> accessControlEntry;
    @XmlAttribute(name = "Name")
    protected String name;
    @XmlAttribute(name = "Scope", required = true)
    protected String scope;

    /**
     * Default no-arg constructor
     * 
     */
    public MCOAccessControlList() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MCOAccessControlList(final AclId aclId, final Date creatnDate, final List<AccessControlEntry> accessControlEntry, final String name, final String scope) {
        this.aclId = aclId;
        this.creatnDate = creatnDate;
        this.accessControlEntry = accessControlEntry;
        this.name = name;
        this.scope = scope;
    }

    /**
     * Gets the value of the aclId property.
     * 
     * @return
     *     possible object is
     *     {@link AclId }
     *     
     */
    public AclId getAclId() {
        return aclId;
    }

    /**
     * Sets the value of the aclId property.
     * 
     * @param value
     *     allowed object is
     *     {@link AclId }
     *     
     */
    public void setAclId(AclId value) {
        this.aclId = value;
    }

    public boolean isSetAclId() {
        return (this.aclId!= null);
    }

    /**
     * Gets the value of the creatnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCreatnDate() {
        return creatnDate;
    }

    /**
     * Sets the value of the creatnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatnDate(Date value) {
        this.creatnDate = value;
    }

    public boolean isSetCreatnDate() {
        return (this.creatnDate!= null);
    }

    /**
     * Gets the value of the accessControlEntry property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the accessControlEntry property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAccessControlEntry().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AccessControlEntry }
     * 
     * 
     */
    public List<AccessControlEntry> getAccessControlEntry() {
        if (accessControlEntry == null) {
            accessControlEntry = new ArrayList<AccessControlEntry>();
        }
        return this.accessControlEntry;
    }

    public boolean isSetAccessControlEntry() {
        return ((this.accessControlEntry!= null)&&(!this.accessControlEntry.isEmpty()));
    }

    public void unsetAccessControlEntry() {
        this.accessControlEntry = null;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the scope property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScope() {
        return scope;
    }

    /**
     * Sets the value of the scope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScope(String value) {
        this.scope = value;
    }

    public boolean isSetScope() {
        return (this.scope!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("aclId", aclId).add("creatnDate", creatnDate).add("accessControlEntry", accessControlEntry).add("name", name).add("scope", scope).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(aclId, creatnDate, accessControlEntry, name, scope);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MCOAccessControlList o = ((MCOAccessControlList) other);
        return ((((Objects.equal(aclId, o.aclId)&&Objects.equal(creatnDate, o.creatnDate))&&Objects.equal(accessControlEntry, o.accessControlEntry))&&Objects.equal(name, o.name))&&Objects.equal(scope, o.scope));
    }

}
