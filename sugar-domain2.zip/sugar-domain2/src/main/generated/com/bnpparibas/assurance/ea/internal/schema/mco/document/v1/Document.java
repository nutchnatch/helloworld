
package com.bnpparibas.assurance.ea.internal.schema.mco.document.v1;

import java.io.Serializable;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DocumentStatusType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ElectronicDocumentDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.IdentificationType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tags;
import com.google.common.base.Objects;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1}MCODocumentType"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "Document")
public class Document
    extends MCODocumentType
    implements Serializable
{

    private final static long serialVersionUID = 1L;

    /**
     * Default no-arg constructor
     * 
     */
    public Document() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public Document(final Id id, final DocumentStatusType status, final MCODocumentType.ParentId parentId, final List<IdentificationType> addId, final ElectronicDocumentDataType data, final Tags tags, final MCODocumentType.FileData fileData, final MCODocumentType.ChildObject childObject, final String scope, final Category category) {
        super(id, status, parentId, addId, data, tags, fileData, childObject, scope, category);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("id", id).add("status", status).add("parentId", parentId).add("addId", addId).add("data", data).add("tags", tags).add("fileData", fileData).add("childObject", childObject).add("scope", scope).add("category", category).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, status, parentId, addId, data, tags, fileData, childObject, scope, category);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final Document o = ((Document) other);
        return (((((((((Objects.equal(id, o.id)&&Objects.equal(status, o.status))&&Objects.equal(parentId, o.parentId))&&Objects.equal(addId, o.addId))&&Objects.equal(data, o.data))&&Objects.equal(tags, o.tags))&&Objects.equal(fileData, o.fileData))&&Objects.equal(childObject, o.childObject))&&Objects.equal(scope, o.scope))&&Objects.equal(category, o.category));
    }

}
