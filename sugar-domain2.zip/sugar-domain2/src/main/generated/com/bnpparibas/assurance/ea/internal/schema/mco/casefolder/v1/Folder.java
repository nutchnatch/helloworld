
package com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tags;
import com.google.common.base.Objects;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolder/v1}MCOFolderType"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "Folder")
public class Folder
    extends MCOFolderType
    implements Serializable
{

    private final static long serialVersionUID = 1L;

    /**
     * Default no-arg constructor
     * 
     */
    public Folder() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public Folder(final FolderId folderId, final FolderDataType data, final Tags tags, final MCOFolderType.ChildComponents childComponents, final String scope) {
        super(folderId, data, tags, childComponents, scope);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("folderId", folderId).add("data", data).add("tags", tags).add("childComponents", childComponents).add("scope", scope).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(folderId, data, tags, childComponents, scope);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final Folder o = ((Folder) other);
        return ((((Objects.equal(folderId, o.folderId)&&Objects.equal(data, o.data))&&Objects.equal(tags, o.tags))&&Objects.equal(childComponents, o.childComponents))&&Objects.equal(scope, o.scope));
    }

}
