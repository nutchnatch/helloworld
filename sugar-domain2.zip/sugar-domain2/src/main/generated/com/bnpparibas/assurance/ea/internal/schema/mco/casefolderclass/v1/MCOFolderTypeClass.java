
package com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DurationType;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOTagReference;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * Folder class allows to
 * 				define a finite list of classes to which can be associated one or
 * 				several tags
 * 			
 * 
 * <p>Java class for MCOFolderTypeClass complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCOFolderTypeClass"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClassId"/&gt;
 *         &lt;element name="Type" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="ShortLabel" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1}MCOI18NLabel" maxOccurs="unbounded"/&gt;
 *         &lt;element name="LongLabel" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="RetentionDuration" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="CreationDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType"/&gt;
 *         &lt;element name="UpdateDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType"/&gt;
 *         &lt;element name="active" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="TagReference" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/tagclass/v1}MCOTagReference" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="Scope" use="required"&gt;
 *         &lt;simpleType&gt;
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *             &lt;maxLength value="20"/&gt;
 *           &lt;/restriction&gt;
 *         &lt;/simpleType&gt;
 *       &lt;/attribute&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCOFolderTypeClass", propOrder = {
    "classId",
    "type",
    "shortLabel",
    "longLabel",
    "retentionDuration",
    "creationDate",
    "updateDate",
    "active",
    "tagReference"
})
@XmlSeeAlso({
    FolderClass.class
})
public class MCOFolderTypeClass implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ClassId", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1", required = true)
    protected ClassId classId;
    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "ShortLabel", required = true)
    protected List<MCOI18NLabel> shortLabel;
    @XmlElement(name = "LongLabel", required = true)
    protected String longLabel;
    @XmlElement(name = "RetentionDuration")
    protected DurationType retentionDuration;
    @XmlElement(name = "CreationDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date creationDate;
    @XmlElement(name = "UpdateDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date updateDate;
    protected boolean active;
    @XmlElement(name = "TagReference")
    protected List<MCOTagReference> tagReference;
    @XmlAttribute(name = "Scope", required = true)
    protected String scope;

    /**
     * Default no-arg constructor
     * 
     */
    public MCOFolderTypeClass() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MCOFolderTypeClass(final ClassId classId, final String type, final List<MCOI18NLabel> shortLabel, final String longLabel, final DurationType retentionDuration, final Date creationDate, final Date updateDate, final boolean active, final List<MCOTagReference> tagReference, final String scope) {
        this.classId = classId;
        this.type = type;
        this.shortLabel = shortLabel;
        this.longLabel = longLabel;
        this.retentionDuration = retentionDuration;
        this.creationDate = creationDate;
        this.updateDate = updateDate;
        this.active = active;
        this.tagReference = tagReference;
        this.scope = scope;
    }

    /**
     * Identification of the document class
     * 					
     * 
     * @return
     *     possible object is
     *     {@link ClassId }
     *     
     */
    public ClassId getClassId() {
        return classId;
    }

    /**
     * Sets the value of the classId property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassId }
     *     
     */
    public void setClassId(ClassId value) {
        this.classId = value;
    }

    public boolean isSetClassId() {
        return (this.classId!= null);
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the shortLabel property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the shortLabel property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getShortLabel().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MCOI18NLabel }
     * 
     * 
     */
    public List<MCOI18NLabel> getShortLabel() {
        if (shortLabel == null) {
            shortLabel = new ArrayList<MCOI18NLabel>();
        }
        return this.shortLabel;
    }

    public boolean isSetShortLabel() {
        return ((this.shortLabel!= null)&&(!this.shortLabel.isEmpty()));
    }

    public void unsetShortLabel() {
        this.shortLabel = null;
    }

    /**
     * Gets the value of the longLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLongLabel() {
        return longLabel;
    }

    /**
     * Sets the value of the longLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLongLabel(String value) {
        this.longLabel = value;
    }

    public boolean isSetLongLabel() {
        return (this.longLabel!= null);
    }

    /**
     * Gets the value of the retentionDuration property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getRetentionDuration() {
        return retentionDuration;
    }

    /**
     * Sets the value of the retentionDuration property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setRetentionDuration(DurationType value) {
        this.retentionDuration = value;
    }

    public boolean isSetRetentionDuration() {
        return (this.retentionDuration!= null);
    }

    /**
     * Gets the value of the creationDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCreationDate() {
        return creationDate;
    }

    /**
     * Sets the value of the creationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreationDate(Date value) {
        this.creationDate = value;
    }

    public boolean isSetCreationDate() {
        return (this.creationDate!= null);
    }

    /**
     * Gets the value of the updateDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getUpdateDate() {
        return updateDate;
    }

    /**
     * Sets the value of the updateDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdateDate(Date value) {
        this.updateDate = value;
    }

    public boolean isSetUpdateDate() {
        return (this.updateDate!= null);
    }

    /**
     * Gets the value of the active property.
     * 
     */
    public boolean isActive() {
        return active;
    }

    /**
     * Sets the value of the active property.
     * 
     */
    public void setActive(boolean value) {
        this.active = value;
    }

    public boolean isSetActive() {
        return true;
    }

    /**
     * Gets the value of the tagReference property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the tagReference property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTagReference().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MCOTagReference }
     * 
     * 
     */
    public List<MCOTagReference> getTagReference() {
        if (tagReference == null) {
            tagReference = new ArrayList<MCOTagReference>();
        }
        return this.tagReference;
    }

    public boolean isSetTagReference() {
        return ((this.tagReference!= null)&&(!this.tagReference.isEmpty()));
    }

    public void unsetTagReference() {
        this.tagReference = null;
    }

    /**
     * Gets the value of the scope property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScope() {
        return scope;
    }

    /**
     * Sets the value of the scope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScope(String value) {
        this.scope = value;
    }

    public boolean isSetScope() {
        return (this.scope!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("classId", classId).add("type", type).add("shortLabel", shortLabel).add("longLabel", longLabel).add("retentionDuration", retentionDuration).add("creationDate", creationDate).add("updateDate", updateDate).add("active", active).add("tagReference", tagReference).add("scope", scope).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(classId, type, shortLabel, longLabel, retentionDuration, creationDate, updateDate, active, tagReference, scope);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MCOFolderTypeClass o = ((MCOFolderTypeClass) other);
        return (((((((((Objects.equal(classId, o.classId)&&Objects.equal(type, o.type))&&Objects.equal(shortLabel, o.shortLabel))&&Objects.equal(longLabel, o.longLabel))&&Objects.equal(retentionDuration, o.retentionDuration))&&Objects.equal(creationDate, o.creationDate))&&Objects.equal(updateDate, o.updateDate))&&Objects.equal(active, o.active))&&Objects.equal(tagReference, o.tagReference))&&Objects.equal(scope, o.scope));
    }

}
