
package com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DurationType;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOTagReference;
import com.google.common.base.Objects;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://ea.assurance.bnpparibas.com/internal/schema/mco/documentclass/v1}MCODocumentClassType"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "DocumentClass")
public class DocumentClass
    extends MCODocumentClassType
    implements Serializable
{

    private final static long serialVersionUID = 1L;

    /**
     * Default no-arg constructor
     * 
     */
    public DocumentClass() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public DocumentClass(final ClassId classId, final List<MCOI18NLabel> shortLabel, final String longLabel, final String scope, final boolean active, final Category category, final MCODocumentClassType.Status status, final DurationType retentionDuration, final Date createDate, final Date lastUpdateDate, final List<MCOTagReference> tagReference, final List<MCODocumentClassType.AllowedChildren> allowedChildren, final boolean firstLevel) {
        super(classId, shortLabel, longLabel, scope, active, category, status, retentionDuration, createDate, lastUpdateDate, tagReference, allowedChildren, firstLevel);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("classId", classId).add("shortLabel", shortLabel).add("longLabel", longLabel).add("scope", scope).add("active", active).add("category", category).add("status", status).add("retentionDuration", retentionDuration).add("createDate", createDate).add("lastUpdateDate", lastUpdateDate).add("tagReference", tagReference).add("allowedChildren", allowedChildren).add("firstLevel", firstLevel).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(classId, shortLabel, longLabel, scope, active, category, status, retentionDuration, createDate, lastUpdateDate, tagReference, allowedChildren, firstLevel);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final DocumentClass o = ((DocumentClass) other);
        return ((((((((((((Objects.equal(classId, o.classId)&&Objects.equal(shortLabel, o.shortLabel))&&Objects.equal(longLabel, o.longLabel))&&Objects.equal(scope, o.scope))&&Objects.equal(active, o.active))&&Objects.equal(category, o.category))&&Objects.equal(status, o.status))&&Objects.equal(retentionDuration, o.retentionDuration))&&Objects.equal(createDate, o.createDate))&&Objects.equal(lastUpdateDate, o.lastUpdateDate))&&Objects.equal(tagReference, o.tagReference))&&Objects.equal(allowedChildren, o.allowedChildren))&&Objects.equal(firstLevel, o.firstLevel));
    }

}
