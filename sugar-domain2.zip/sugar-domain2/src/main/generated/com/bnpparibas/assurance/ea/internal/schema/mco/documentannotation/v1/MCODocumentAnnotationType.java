
package com.bnpparibas.assurance.ea.internal.schema.mco.documentannotation.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DocumentAnnotationDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FreeExtentionPointType;
import com.google.common.base.Objects;


/**
 * Document annotation description
 * 
 * <p>Java class for MCODocumentAnnotationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MCODocumentAnnotationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/documentannotation/v1}Id"/&gt;
 *         &lt;element name="Data" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentAnnotationDataType"/&gt;
 *         &lt;element name="AddData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FreeExtentionPointType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MCODocumentAnnotationType", propOrder = {
    "id",
    "data",
    "addData"
})
@XmlSeeAlso({
    DocumentAnnotation.class
})
public class MCODocumentAnnotationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Id", required = true)
    protected Id id;
    @XmlElement(name = "Data", required = true)
    protected DocumentAnnotationDataType data;
    @XmlElement(name = "AddData")
    protected FreeExtentionPointType addData;

    /**
     * Default no-arg constructor
     * 
     */
    public MCODocumentAnnotationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MCODocumentAnnotationType(final Id id, final DocumentAnnotationDataType data, final FreeExtentionPointType addData) {
        this.id = id;
        this.data = data;
        this.addData = addData;
    }

    /**
     * Principal identifier of the Annotation 
     * 
     * @return
     *     possible object is
     *     {@link Id }
     *     
     */
    public Id getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link Id }
     *     
     */
    public void setId(Id value) {
        this.id = value;
    }

    public boolean isSetId() {
        return (this.id!= null);
    }

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     {@link DocumentAnnotationDataType }
     *     
     */
    public DocumentAnnotationDataType getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentAnnotationDataType }
     *     
     */
    public void setData(DocumentAnnotationDataType value) {
        this.data = value;
    }

    public boolean isSetData() {
        return (this.data!= null);
    }

    /**
     * Gets the value of the addData property.
     * 
     * @return
     *     possible object is
     *     {@link FreeExtentionPointType }
     *     
     */
    public FreeExtentionPointType getAddData() {
        return addData;
    }

    /**
     * Sets the value of the addData property.
     * 
     * @param value
     *     allowed object is
     *     {@link FreeExtentionPointType }
     *     
     */
    public void setAddData(FreeExtentionPointType value) {
        this.addData = value;
    }

    public boolean isSetAddData() {
        return (this.addData!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("id", id).add("data", data).add("addData", addData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, data, addData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MCODocumentAnnotationType o = ((MCODocumentAnnotationType) other);
        return ((Objects.equal(id, o.id)&&Objects.equal(data, o.data))&&Objects.equal(addData, o.addData));
    }

}
