
package com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DefaultRetentionStartDateValue;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.google.common.base.Objects;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://ea.assurance.bnpparibas.com/internal/schema/mco/businessscope/v1}MCOBusinessScope"&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "BusinessScope")
public class BusinessScope
    extends MCOBusinessScope
    implements Serializable
{

    private final static long serialVersionUID = 1L;

    /**
     * Default no-arg constructor
     * 
     */
    public BusinessScope() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public BusinessScope(final BusinessScopeId businessScopeId, final String organisationalUnit, final String description, final List<MCOI18NLabel> displayName, final List<String> languages, final List<MCOI18NLabel> preferedLanguages, final String defaultEnvelopClass, final String defaultDocumentClass, final String defaultFolderClass, final Date creationDate, final Date updateDate, final DefaultRetentionStartDateValue defaultRetentionStartDate, final String encryptionIdentifier, final MCOBusinessScope.FileData fileData, final String symbolicName) {
        super(businessScopeId, organisationalUnit, description, displayName, languages, preferedLanguages, defaultEnvelopClass, defaultDocumentClass, defaultFolderClass, creationDate, updateDate, defaultRetentionStartDate, encryptionIdentifier, fileData, symbolicName);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("businessScopeId", businessScopeId).add("organisationalUnit", organisationalUnit).add("description", description).add("displayName", displayName).add("languages", languages).add("preferedLanguages", preferedLanguages).add("defaultEnvelopClass", defaultEnvelopClass).add("defaultDocumentClass", defaultDocumentClass).add("defaultFolderClass", defaultFolderClass).add("creationDate", creationDate).add("updateDate", updateDate).add("defaultRetentionStartDate", defaultRetentionStartDate).add("encryptionIdentifier", encryptionIdentifier).add("fileData", fileData).add("symbolicName", symbolicName).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(businessScopeId, organisationalUnit, description, displayName, languages, preferedLanguages, defaultEnvelopClass, defaultDocumentClass, defaultFolderClass, creationDate, updateDate, defaultRetentionStartDate, encryptionIdentifier, fileData, symbolicName);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final BusinessScope o = ((BusinessScope) other);
        return ((((((((((((((Objects.equal(businessScopeId, o.businessScopeId)&&Objects.equal(organisationalUnit, o.organisationalUnit))&&Objects.equal(description, o.description))&&Objects.equal(displayName, o.displayName))&&Objects.equal(languages, o.languages))&&Objects.equal(preferedLanguages, o.preferedLanguages))&&Objects.equal(defaultEnvelopClass, o.defaultEnvelopClass))&&Objects.equal(defaultDocumentClass, o.defaultDocumentClass))&&Objects.equal(defaultFolderClass, o.defaultFolderClass))&&Objects.equal(creationDate, o.creationDate))&&Objects.equal(updateDate, o.updateDate))&&Objects.equal(defaultRetentionStartDate, o.defaultRetentionStartDate))&&Objects.equal(encryptionIdentifier, o.encryptionIdentifier))&&Objects.equal(fileData, o.fileData))&&Objects.equal(symbolicName, o.symbolicName));
    }

}
