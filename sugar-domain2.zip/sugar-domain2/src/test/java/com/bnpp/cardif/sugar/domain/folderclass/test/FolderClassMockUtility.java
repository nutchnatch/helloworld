package com.bnpp.cardif.sugar.domain.folderclass.test;

import java.util.Date;
import java.util.UUID;

import com.arondor.flower.model.i18n.Language;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;

/**
 * Utility class allowing to generate folder classes for test purposes
 * 
 * @author Romain
 * 
 */
public class FolderClassMockUtility {
    public static final String SCOPE = "Syldavia";

    /**
     * Build a folder class
     * 
     * @return the built folder class
     */
    public static FolderClass buildFolderClassContractManagement() {
        FolderClass folderClass = new FolderClass();
        ClassId id = buildFolderClassId();
        folderClass.setClassId(id);
        folderClass.setScope(SCOPE);
        folderClass.setActive(false);
        folderClass.setCreationDate(new Date());
        folderClass.setUpdateDate(new Date());
        folderClass.setType("folderClassType");
        MCOI18NLabel i18nLabel = new MCOI18NLabel();
        i18nLabel.setLanguage(Language.EN.getLanguage());
        i18nLabel.setValue("FolderClassTest");
        folderClass.getShortLabel().add(i18nLabel);
        folderClass.setLongLabel("Contract Management");

        folderClass.setRetentionDuration(null);

        return folderClass;
    }

    public static ClassId buildFolderClassId() {
        ClassId id = new ClassId();
        id.setValue(UUID.randomUUID().toString());
        id.setIssuer("CARDIF");
        id.setVersId(0);
        return id;
    }
}
