package com.bnpp.cardif.sugar.domain.jaxb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.Date;

import org.junit.Test;

public class DateAdapterTest {
    @Test
    public void testParseDateTime() throws Exception {
        Date parseDateTime = DateAdapter.parseDateTime("2014-03-31 15:16:10.800 +0200");
        assertEquals(1396271770800l, parseDateTime.getTime());
    }

    @Test
    public void testParseNullDateTime() throws Exception {
        assertNull(DateAdapter.parseDateTime(null));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidParseDateTime() throws Exception {
        DateAdapter.parseDateTime("2014-03-31 15:16:10.TOTO");
    }

    @Test
    public void testPrintDateTime() throws Exception {
        Date input = new Date(1396271770800l);
        String printDateTime = DateAdapter.printDateTime(input);
        assertEquals(input, DateAdapter.parseDateTime(printDateTime));
    }

    @Test
    public void testPrintNullDateTime() throws Exception {
        assertNull(DateAdapter.printDateTime(null));
    }
}
