package com.bnpp.cardif.sugar.domain.test;

import java.util.Date;
import java.util.UUID;

import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ElectronicDocumentDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tags;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.ChildObject;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.FileData;

/**
 * Utility class allowing to generate documents for test purposes
 * 
 * @author Christopher Laszczuk
 * 
 */
public class DocumentClassMockUtility {
    public static Document buildClaimDocument() {
        Document document = new Document();
        document.setScope("Syldavia");
        document.setCategory(Category.DOCUMENT);

        Id id = new Id();
        id.setIssuer("CARDIF");
        id.setScheme("Sugar");
        id.setValue(UUID.randomUUID().toString());
        document.setId(id);

        ElectronicDocumentDataType data = new ElectronicDocumentDataType();
        ClassId clazz = new ClassId();
        clazz.setValue("71c3c79f-c7fd-48bb-a4e8-6a335698ea81");
        clazz.setIssuer("CARDIF");
        data.setClassId(clazz);
        data.setCreatnDate(new Date());
        data.setName("Auto generated claim");
        data.setValidityCode(ValdtyCode.INVALID);
        document.setData(data);

        FileData fileData = new FileData();
        fileData.getURI().add("my fiel.txt");
        document.setFileData(fileData);

        Tags tags = new Tags();
        Tag policyid = new Tag();
        policyid.setName("PolicyId");
        policyid.setValue("ref6859");
        tags.getTag().add(policyid);
        Tag subscriberName = new Tag();
        subscriberName.setName("SubscriberName");
        subscriberName.setValue("Mr Smith");
        tags.getTag().add(subscriberName);
        document.setTags(tags);
        return document;
    }

    public static Document buildMedicalReportWithoutId() {
        Document document = new Document();
        document.setScope("Syldavia");
        document.setCategory(Category.DOCUMENT);

        ElectronicDocumentDataType data = new ElectronicDocumentDataType();
        ClassId clazz = new ClassId();
        clazz.setValue("c67c3811-1459-483d-b907-a701ebf47bed");
        clazz.setIssuer("CARDIF");
        data.setClassId(clazz);
        data.setValidityCode(ValdtyCode.INVALID);
        // data.setCreatnDate(new Date());
        document.setData(data);

        FileData fileData = new FileData();
        fileData.getURI().add("my fiel.txt");
        document.setFileData(fileData);

        Tags tags = new Tags();
        Tag policyId = new Tag();
        policyId.setName("PolicyId");
        policyId.setValue("P9344E46431");
        tags.getTag().add(policyId);
        Tag contractType = new Tag();
        contractType.setName("ContractType");
        contractType.setValue("life");
        tags.getTag().add(contractType);
        document.setTags(tags);

        return document;
    }

    public static Document buildEnvelope() {
        Document envelope = new Document();
        Id id = new Id();
        id.setValue(UUID.randomUUID().toString());
        id.setIssuer("CARDIF");
        id.setScheme("Sugar");
        envelope.setId(id);
        ElectronicDocumentDataType data = new ElectronicDocumentDataType();
        ClassId clazz = new ClassId();
        clazz.setValue("b21ba156-f5be-407e-a0b5-6c74aedea9ee");
        clazz.setIssuer("CARDIF");
        data.setClassId(clazz);
        data.setValidityCode(ValdtyCode.INVALID);
        envelope.setCategory(Category.ENVELOPE);
        envelope.setData(data);
        envelope.setChildObject(new ChildObject());
        envelope.setScope("Syldavia");
        return envelope;
    }
}
