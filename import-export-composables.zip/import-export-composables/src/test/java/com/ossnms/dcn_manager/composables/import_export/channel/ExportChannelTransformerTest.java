package com.ossnms.dcn_manager.composables.import_export.channel;

import com.ossnms.dcn_manager.composables.import_export.EntitiesCreatorForTest;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ChannelValueObject;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository.MediatorInfoRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static java.util.Optional.empty;
import static java.util.Optional.ofNullable;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ExportChannelTransformerTest extends EntitiesCreatorForTest {
    
    private ChannelType type;
    private MediatorEntityRepository mediatorRepository;
    private MediatorInstanceEntityRepository instanceEntityRepository;
    private MediatorInfoRepository mediatorInfoRepository;

    @Before
    public void setup() throws RepositoryException {
        type = mock(ChannelType.class);
        mediatorRepository = mock(MediatorEntityRepository.class);
        
        instanceEntityRepository = mock(MediatorInstanceEntityRepository.class);
        when(instanceEntityRepository.queryAll(MEDIATOR_ID)).thenReturn(buildMediatorInstances());
        
        when(type.getName()).thenReturn("typeName");
        when(type.getDefaultIcon()).thenReturn("");

        MediatorInfoData mediatorInfoData = buildMediatorEntity().getInfo();
        when(mediatorRepository.queryMediatorName(MEDIATOR_ID)).thenReturn(Optional.of(mediatorInfoData.getName()));

        mediatorInfoRepository = mock(MediatorInfoRepository.class);
        when(mediatorRepository.getMediatorInfoRepository()).thenReturn(mediatorInfoRepository);
        when(mediatorInfoRepository.query(MEDIATOR_ID)).thenReturn(Optional.of(mediatorInfoData));
        
    }
    
    @Test public void testApply() {
        final ChannelEntity entity = buildChannelEntity(type);
        final Optional<ChannelValueObject> channel = new ExportChannelTransformer(mediatorRepository,
                instanceEntityRepository).apply(entity);

        assertThat(channel.isPresent(), is(true));
        ChannelUserPreferencesData userPreferences = entity.getUserPreferences();
        assertThat(channel.get().getName(), is(userPreferences.getName()));
        assertThat(channel.get().getType(), is(entity.getInfo().getType()));
        assertThat(channel.get().getConcurrentActivationsLimited(), is(ofNullable(userPreferences.isConcurrentActivationsLimited())));
        assertThat(channel.get().getConcurrentActivationsLimit(), is(ofNullable(userPreferences.getConcurrentActivationsLimit())));
        assertThat(channel.get().getPropertyBag().size(), is(entity.getAllOpaqueProperties().size()));

        for (final String key : channel.get().getPropertyBag().keySet()) {
            assertTrue(entity.getAllOpaqueProperties().containsKey(key));
        }
    }
    
    @Test(expected=NullPointerException.class)
    public void testApply_error() {
        new ExportChannelTransformer(mediatorRepository, instanceEntityRepository).apply(null);
    }
    
    @Test
    public void testApply_error_repo() throws RepositoryException {
        doThrow(RepositoryException.class).when(mediatorInfoRepository).query(MEDIATOR_ID);
        
        final ChannelEntity entity = buildChannelEntity(type);
        assertFalse(new ExportChannelTransformer(mediatorRepository, instanceEntityRepository).apply(entity).isPresent());
    }
    
    @Test
    public void testApply_error_not_found() throws RepositoryException {
        when(mediatorInfoRepository.query(MEDIATOR_ID)).thenReturn(empty());
        
        final ChannelEntity entity = buildChannelEntity(type);
        assertFalse(new ExportChannelTransformer(mediatorRepository, instanceEntityRepository).apply(entity).isPresent());
    }    
}
