package com.ossnms.dcn_manager.composables.import_export.system;

import com.ossnms.dcn_manager.core.entities.container.system.SystemCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.import_export.identification.Identification;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableSystemValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.SystemValueObject;
import org.junit.Test;

import java.util.Optional;

import static java.util.Optional.empty;
import static java.util.Optional.of;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;

public class ImportSystemTransformerTest {

    @Test public void shouldNotCreateDescriptorForExistingSystem() throws Exception {
        Identification<SystemValueObject, SystemInfo> identification = in -> of(new SystemInfo(2, 1, "System Container"));
        SystemValueObject system = ImmutableSystemValueObject.of("System Container");

        Optional<SystemCreationDescriptor> descriptor = new ImportSystemTransformer(identification).apply(system);

        assertThat(descriptor, is(empty()));
    }

    @Test public void shouldCreateDescriptionWithAllFields() throws Exception {
        Identification<SystemValueObject, SystemInfo> identification = in -> empty();
        SystemValueObject system = ImmutableSystemValueObject.of("System Container")
                .withUserText("User Text")
                .withDescription("Description");

        Optional<SystemCreationDescriptor> descriptor = new ImportSystemTransformer(identification).apply(system);

        assertThat(descriptor, is(not(empty())));
        assertThat(descriptor.get().getName(), is("System Container"));
        assertThat(descriptor.get().getUserText(), is(of("User Text")));
        assertThat(descriptor.get().getDescription(), is(of("Description")));
    }
}