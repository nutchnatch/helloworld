package com.ossnms.dcn_manager.composables.import_export.ne;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.composables.import_export.EntitiesCreatorForTest;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableAssignedContainer;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableNeAdditionalInfo;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeAdditionalInfo;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerAssignmentRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeGatewayRoutesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeOperationRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType.LOGICAL;
import static com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType.PRIMARY;
import static java.util.Arrays.asList;
import static java.util.Optional.of;
import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ExportNeTransformerTest extends EntitiesCreatorForTest {

    @Mock private ChannelType emtype;
    @Mock private NeType neType;
    @Mock private Types<NeType> neTypes;
    @Mock private ChannelEntityRepository channelRepository;
    @Mock private NeGatewayRoutesRepository routesRepository;
    @Mock private StaticConfiguration configuration;
    @Mock private NeEntityRepository neRepository;
    @Mock private NeOperationRepository operationRepository;
    @Mock private DomainRepository domainRepository;
    @Mock private ContainerAssignmentRepository assignmentRepository;
    @Mock private SystemRepository systemRepository;

    private Optional<ChannelEntity> channelEntity;
    private Map<Integer, NeAdditionalInfo> neInfoMap;

    @Before
    public void setup() throws RepositoryException {
        when(emtype.getName()).thenReturn("typeName");
        when(emtype.getDefaultIcon()).thenReturn("");

        when(neType.getName()).thenReturn("type");
        when(neType.getSupportedPropertyDefaultValues()).thenReturn(ImmutableMap.of());
        when(neType.getTypeProperties()).thenReturn(ImmutableMap.of());
        when(neType.mapOutgoingPropertyName(anyString())).thenReturn(KEY1);
        when(neTypes.get(NE_TYPE)).thenReturn(neType);

        channelEntity = of(buildChannelEntity(emtype));
        when(configuration.getNeTypes()).thenReturn(neTypes);
        when(channelRepository.queryChannelName(CHANNEL_ID)).thenReturn(of(channelEntity.get().getUserPreferences().getName()));

        when(neRepository.getNeGatewayRoutesRepository()).thenReturn(routesRepository);
        when(neRepository.getNeOperationRepository()).thenReturn(operationRepository);

        when(operationRepository.query(anyInt())).thenReturn(Optional.empty());

        when(domainRepository.queryAllForNE(NE_ID)).thenReturn(ImmutableList.of(new DomainInfoData(1, 1, "domainName")));

        when(routesRepository.queryRoutes(anyInt())).thenReturn(ImmutableList.of());

        when(assignmentRepository.queryAllByNE(NE_ID)).thenReturn(Collections.emptyList());

        when(systemRepository.query(anyInt())).thenReturn(Optional.empty());
        
        buildNeAdditionalInfoMap();
    }

    @Test
    public void testApply() throws RepositoryException {
        ExportNeTransformer exportNeTransformer = new ExportNeTransformer(channelRepository, neRepository, domainRepository, configuration, assignmentRepository, systemRepository, neInfoMap);
        final NeEntity entity = buildNeEntity();


        final NeValueObject ne = exportNeTransformer.apply(entity).orElseThrow(() -> new AssertionError("Object should be present"));


        assertThat(ne.getName(), is(entity.getPreferences().getName()));
        assertThat(ne.getType(), is(entity.getInfo().getProxyType()));
        assertThat(ne.getChannel(), is(channelEntity.get().getUserPreferences().getName()));
        assertThat(ne.getDomainNames(), hasItem("domainName"));
        for (final String key : entity.getAllOpaqueProperties().keySet()) {
            assertTrue(ne.getPropertyBag().containsKey(key));
        }
        assertThat(ne.getNeAdditionalInfo().get().getLocalInterface(), is(neInfoMap.get(NE_ID).getLocalInterface()));
        assertThat(ne.getNeAdditionalInfo().get().getNeSwVersion(), is(neInfoMap.get(NE_ID).getNeSwVersion()));
        assertThat(ne.getNeAdditionalInfo().get().getMountMode(), is(neInfoMap.get(NE_ID).getMountMode()));
    }

    @Test public void shouldContainAssignedContainers() throws Exception {
        final NeEntity entity = buildNeEntity();
        when(assignmentRepository.queryAllByNE(NE_ID)).thenReturn(asList(
                new NeAssignmentData(new ContainerInfo(1, 1, "Primary Container"), NE_ID, PRIMARY),
                new NeAssignmentData(new ContainerInfo(2, 1, "Logical Container"), NE_ID, LOGICAL)
        ));
        ExportNeTransformer exportNeTransformer = new ExportNeTransformer(channelRepository, neRepository, domainRepository, configuration, assignmentRepository, systemRepository, neInfoMap);


        NeValueObject ne = exportNeTransformer.apply(entity).orElseThrow(() -> new AssertionError("Object should be present"));


        assertThat(ne.getAssignedContainers(), containsInAnyOrder(
                ImmutableAssignedContainer.of("Primary Container", true),
                ImmutableAssignedContainer.of("Logical Container", false)));
    }

    @Test public void shouldExportSystem() throws Exception {
        final NeEntity entity = buildNeEntity();
        when(systemRepository.query(SYSTEM_ID)).thenReturn(of(new SystemInfo(SYSTEM_ID, 1, "System Container Name")));
        ExportNeTransformer exportNeTransformer = new ExportNeTransformer(channelRepository, neRepository, domainRepository, configuration, assignmentRepository, systemRepository, neInfoMap);


        NeValueObject ne = exportNeTransformer.apply(entity).orElseThrow(() -> new AssertionError("Object should be present"));


        assertThat(ne.systemContainer(), is(of("System Container Name")));
    }

    @Test(expected = NullPointerException.class)
    public void testApply_error() {
        new ExportNeTransformer(channelRepository, neRepository, domainRepository, configuration, assignmentRepository, systemRepository, neInfoMap).apply(null);
    }
    
    private void buildNeAdditionalInfoMap() {
    	NeAdditionalInfo neInfo = ImmutableNeAdditionalInfo.builder()
    			.eonType("PRNE")
    			.localInterface("10.46.88.100")
    			.localInterfaceMask("255.255.255.255")
    			.neSwVersion("FP10.1.3 FF101")
    			.mountMode("horizontal").build();
    	neInfoMap = new HashMap<>();
    	neInfoMap.put(NE_ID, neInfo);
    }
}
