package com.ossnms.dcn_manager.composables.import_export.system;

import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableAssignedContainer;
import com.ossnms.dcn_manager.core.import_export.valueobjects.SystemValueObject;
import com.ossnms.dcn_manager.core.storage.container.ContainerAssignmentRepository;
import org.junit.Test;

import java.util.List;
import java.util.Optional;

import static com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType.LOGICAL;
import static com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType.PRIMARY;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Optional.of;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ExportSystemTransformerTest {

    @Test public void shouldExportNameDescriptionAndUserText() throws Exception {
        SystemInfo systemInfo = new SystemInfo(1, 1, "System name", Optional.of("Some description"), Optional.of("User label"));
        ExportSystemTransformer transformer = new ExportSystemTransformer(assignments(1, emptyList()));

        SystemValueObject systemValue = transformer.apply(systemInfo);

        assertThat(systemValue.name(), is("System name"));
        assertThat(systemValue.description(), is(of("Some description")));
        assertThat(systemValue.userText(), is(of("User label")));
    }

    @Test public void shouldExportAssignments() throws Exception {
        SystemInfo systemInfo = new SystemInfo(1, 1, "name");
        ExportSystemTransformer transformer = new ExportSystemTransformer(assignments(1, asList(
                new SystemAssignmentData(new ContainerInfo(1, 1, "Primary container"), 1, PRIMARY),
                new SystemAssignmentData(new ContainerInfo(2, 1, "Secondary container"), 1, LOGICAL))));

        SystemValueObject systemValue = transformer.apply(systemInfo);

        assertThat(systemValue.assignedContainers(), containsInAnyOrder(
                ImmutableAssignedContainer.of("Primary container", true),
                ImmutableAssignedContainer.of("Secondary container", false)));
    }

    private ContainerAssignmentRepository assignments(int systemContainerId, List<SystemAssignmentData> assignmentData) {
        ContainerAssignmentRepository assignmentRepository = mock(ContainerAssignmentRepository.class);
        when(assignmentRepository.queryAllBySystem(systemContainerId)).thenReturn(assignmentData);
        return assignmentRepository;
    }
}