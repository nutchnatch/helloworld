package com.ossnms.dcn_manager.composables.import_export.domain;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collection;

import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.composables.import_export.EntitiesCreatorForTest;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;

public class DomainNamesBuilderTest extends EntitiesCreatorForTest {

    private DomainRepository domainRepository;
    
    @Before
    public void setup() {
        domainRepository = mock(DomainRepository.class);

        when(domainRepository.queryAllForNE(NE_ID)).thenReturn(ImmutableList.of(new DomainInfoData(1, 1, "domainName")));
    }
    
    @Test
    public void testBuild() {
        final Collection<String> domainNames = new DomainNamesBuilder(NE_ID, domainRepository).build();
        
        assertNotNull(domainNames);
        assertThat(domainNames, hasItem("domainName"));
    }
}
