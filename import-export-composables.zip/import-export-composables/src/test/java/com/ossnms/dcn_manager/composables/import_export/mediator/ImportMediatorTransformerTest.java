package com.ossnms.dcn_manager.composables.import_export.mediator;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableMediatorValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;
import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;
import java.util.Optional;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ImportMediatorTransformerTest {

    private static final String VALUE = "value";
    private static final String KEY = "key";
    @Mock private StaticConfiguration configuration;
    @Mock private Types<MediatorType> mediatorTypes;
    @Mock private MediatorType mediatorType;
    @Mock private CallContext context;
    @Mock private LoggerManager<CallContext> loggerManager;
    private MediatorValueObject input;

    @Before
    public void setup() {
        when(configuration.getMediatorTypes()).thenReturn(mediatorTypes);
        when(mediatorTypes.get("type")).thenReturn(mediatorType);
        when(mediatorType.getName()).thenReturn("type");
        when(mediatorType.getSupportedPropertyDefaultValues()).thenReturn(ImmutableMap.of());
        when(mediatorType.getTypeProperties()).thenReturn(ImmutableMap.of());
        when(mediatorType.mapIncomingPropertyName(KEY)).thenReturn(KEY);

        input = ImmutableMediatorValueObject.builder()
                .mediatorId(1)
                .name("name").type("type").host("host").mediatorInstances(Collections.emptyList())
                .propertyBag(ImmutableMap.of(KEY, VALUE))
                .reconnectInterval(2).build();
    }

    @Test
    public void testApply() {
        final Optional<MediatorCreateDescriptor> descriptor = new ImportMediatorTransformer(configuration).apply(input).getRight();

        assertTrue(descriptor.isPresent());
        assertThat(descriptor.get().getInfoInitialData().getName(), CoreMatchers.is("name"));
        assertThat(descriptor.get().getType(), CoreMatchers.is("type"));

        final MediatorInfoData infoData = new MediatorInfoData(1, 1, descriptor.get().getInfoInitialData());

        assertThat(infoData.getConcurrentActivationsLimit(), CoreMatchers.is(20));
        assertThat(infoData.getReconnectAttemptInterval(), CoreMatchers.is(2));
        assertThat(infoData.isConcurrentActivationsLimited(), CoreMatchers.is(true));
        assertThat(infoData.getAllOpaqueProperties().get(KEY), CoreMatchers.is(VALUE));
    }

    @Test(expected = NullPointerException.class)
    public void testApply_input_null() {
        new ImportMediatorTransformer(configuration).apply(null);
    }

    @Test
    public void testApply_mediator_not_supported() {
        when(mediatorTypes.get("type")).thenReturn(null);

        final Optional<MediatorCreateDescriptor> descriptor = new ImportMediatorTransformer(configuration).apply(input).getRight();

        assertFalse(descriptor.isPresent());
    }
}
