package com.ossnms.dcn_manager.composables.import_export;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;

import java.util.Collection;
import java.util.Optional;

import static com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance.PRIMARY_PRIORITY_LEVEL;

public abstract class EntitiesCreatorForTest {

    protected static final String GW_DOMAIN = "gw_domain";
    protected static final int GW_PRIO = 2;
    protected static final int GW_COST = 1;
    protected static final String CHANNEL_NAME = "channel name";
    protected static final String GW_KEY = "gw-key";
    protected static final String VALUE2 = "value2";
    protected static final String KEY2 = "key2";
    protected static final String VALUE1 = "value1";
    protected static final String KEY1 = "key1";
    protected static final boolean SORTING_MODE = true;
    protected static final String MEDIATOR_NAME = "name";
    protected static final String MEDIATOR_HOST = "127.0.0.1";
    protected static final String NE_TYPE = "type";
    protected static final boolean USES_GNE = true;
    protected static final String USER_NAME = "user-name";
    protected static final String PWD = "pwd";
    protected static final String DESCRIPTION = "description";
    protected static final int MEDIATOR_ID = 42;
    protected static final int CHANNEL_ID = 32;
    protected static final int RECONNECT_INTERVAL = 60;
    protected static final int CONCURRENT_LIMIT = 10;
    protected static final boolean CONCURRENT_LIMITED = true;
    protected static final int VERSION = 1;
    protected static final int NE_ID = 21;
    protected static final int DOMAIN_ID = 22;
    protected static final int SYSTEM_ID = 42;
    


    protected ChannelEntity buildChannelEntity(final ChannelType type) {
        return new ChannelEntity(
               new ChannelInfoBuilder().setType(type.getName()).setActivationRequired(false).build(CHANNEL_ID, VERSION, MEDIATOR_ID),
               new ChannelConnectionBuilder().build(CHANNEL_ID, VERSION),
               new ChannelUserPreferencesBuilder().setReconnectInterval(RECONNECT_INTERVAL).setName(CHANNEL_NAME).build(CHANNEL_ID, VERSION));
    }

    protected NeEntity buildNeEntity() {

        return new NeEntity(
               new NeConnectionBuilder().setActivationState(ActualActivationState.DISCONNECTED).build(NE_ID, VERSION),
               new NeOperationBuilder().build(NE_ID, VERSION),
               new NeInfoBuilder().setProxyType(NE_TYPE).build(NE_ID, CHANNEL_ID, VERSION),
               new NeSynchronizationBuilder().build(NE_ID, VERSION),
               new NeUserPreferencesBuilder().setName(MEDIATOR_NAME).setContainerId(Optional.of(SYSTEM_ID)).build(NE_ID, VERSION));
    }

    protected MediatorEntity buildMediatorEntity() {
        return new MediatorEntity(
                newInfo(false),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));
    }

    protected MediatorInfoData newInfo(final boolean activationRequired) {
        return new MediatorInfoBuilder()
            .setName(MEDIATOR_NAME)
            .setTypeName(NE_TYPE)
            .setDescription(Optional.of(DESCRIPTION))
            .setConcurrentActivationsLimited(CONCURRENT_LIMITED)
            .setActivationRequired(activationRequired)
            .setReconnectAttemptInterval(RECONNECT_INTERVAL)
            .setConcurrentActivationsLimit(CONCURRENT_LIMIT)
            .setProperties(ImmutableMap.of(KEY1,VALUE1,KEY2,VALUE2))
            .build(MEDIATOR_ID, VERSION);
    }

    protected Collection<MediatorInstance> buildMediatorInstances() {
        MediatorInstance mediatorInstance1 = new MediatorInstance(
                new MediatorPhysicalDataBuilder()
                        .setHost("host1")
                        .setPriority(PRIMARY_PRIORITY_LEVEL).build(1, 1, 1),
                new MediatorPhysicalConnectionBuilder().build(1, 1, 1));

        MediatorInstance mediatorInstance2 = new MediatorInstance(
                new MediatorPhysicalDataBuilder()
                        .setHost("host2")
                        .setPriority(2).build(2, 2, 2),
                new MediatorPhysicalConnectionBuilder().build(2, 2, 2));

        return ImmutableList.of(mediatorInstance1, mediatorInstance2);
    }

}
