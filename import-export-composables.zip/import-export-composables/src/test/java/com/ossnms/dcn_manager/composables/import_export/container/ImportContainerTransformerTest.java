package com.ossnms.dcn_manager.composables.import_export.container;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.import_export.identification.Identification;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ContainerValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableContainerValueObject;
import org.junit.Test;

import java.util.Map;
import java.util.Optional;

import static java.util.Optional.empty;
import static java.util.Optional.ofNullable;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;

public class ImportContainerTransformerTest {
    @Test public void shouldNotCreateDescriptorForRootContainer() throws Exception {
        ContainerValueObject rootContainer = ImmutableContainerValueObject.of("Root Container"); //without parent

        Optional<ContainerCreationDescriptor> descriptor = new ImportContainerTransformer(containerValueObject -> empty()).apply(rootContainer);

        assertThat(descriptor, is(empty()));
    }

    @Test public void shouldNotCreateDescriptorForExistingContainer() throws Exception {
        ContainerValueObject container = ImmutableContainerValueObject.of("Container")
                .withParent("Root Container");

        Map<ContainerValueObject, ContainerInfo> containers = ImmutableMap.of(container, new ContainerInfo(2, 1, "Container"));
        Identification<ContainerValueObject, ContainerInfo> identification = vo -> ofNullable(containers.get(vo));

        Optional<ContainerCreationDescriptor> descriptor = new ImportContainerTransformer(identification).apply(container);

        assertThat(descriptor, is(empty()));
    }

    @Test public void shouldNotCreateDescriptorIfParentDoesNotExist() throws Exception {
        ContainerValueObject container = ImmutableContainerValueObject.of("Container")
                .withParent("Root Container");
        Identification<ContainerValueObject, ContainerInfo> identification = vo -> empty();

        Optional<ContainerCreationDescriptor> descriptor = new ImportContainerTransformer(identification).apply(container);

        assertThat(descriptor, is(empty()));
    }

    @Test public void shouldCreateDescriptorWithAllFields() throws Exception {
        ContainerValueObject container = ImmutableContainerValueObject.of("Container")
                .withParent("Parent Container")
                .withUserText("User text")
                .withDescription("Description");

        Map<ContainerValueObject, ContainerInfo> containers = ImmutableMap.of(
                ImmutableContainerValueObject.of("Parent Container"), new ContainerInfo(42, 1, "Parent Container"));
        Identification<ContainerValueObject, ContainerInfo> identification = vo -> ofNullable(containers.get(vo));


        Optional<ContainerCreationDescriptor> descriptor = new ImportContainerTransformer(identification).apply(container);


        assertThat(descriptor, is(not(empty())));
        assertThat(descriptor.get().getName(), is("Container"));
        assertThat(descriptor.get().getParentIdentifier(), is(Optional.of(42)));
        assertThat(descriptor.get().getUserText(), is(Optional.of("User text")));
        assertThat(descriptor.get().getDescription(), is(Optional.of("Description")));
    }
}