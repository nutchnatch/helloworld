package com.ossnms.dcn_manager.composables.import_export.container;

import com.ossnms.dcn_manager.core.entities.container.ContainerInfoBase;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ContainerValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableContainerValueObject;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.function.Function;

import static com.google.common.base.Preconditions.checkNotNull;
import static java.util.Optional.empty;

/**
 * Transforms the {@link ContainerInfo} to {@link ContainerValueObject}
 */
public class ExportContainerTransformer implements Function<ContainerInfo, ContainerValueObject> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExportContainerTransformer.class);
    private final ContainerRepository containerRepository;

    public ExportContainerTransformer(ContainerRepository containerRepository) {

        this.containerRepository = containerRepository;
    }

    @Override
    public ContainerValueObject apply(@Nonnull ContainerInfo input) {
        checkNotNull(input, "The ContainerInfo cannot be null");
        return ImmutableContainerValueObject.builder()
                .name(input.getName())
                .userText(input.getUserText())
                .description(input.getDescription())
                .parent(input.getParentId().flatMap(this::fetchParentName))
                .build();
    }

    private Optional<String> fetchParentName(Integer parentId) {
        try {
            return containerRepository.query(parentId).map(ContainerInfoBase::getName);
        } catch (RepositoryException e) {
            LOGGER.error("Failed to fetch parent container", e);
            return empty();
        }
    }

}