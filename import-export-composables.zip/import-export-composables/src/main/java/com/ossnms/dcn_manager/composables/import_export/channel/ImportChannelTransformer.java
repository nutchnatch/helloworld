package com.ossnms.dcn_manager.composables.import_export.channel;

import com.ossnms.dcn_manager.composables.import_export.Either;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesInitialData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.import_export.identification.MediatorIdentification;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ChannelValueObject;
import com.ossnms.dcn_manager.core.properties.channel.ChannelProperties;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.function.Function;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.ossnms.dcn_manager.composables.import_export.Either.left;
import static com.ossnms.dcn_manager.composables.import_export.Either.right;
import static com.ossnms.dcn_manager.i18n.T.tr;

public class ImportChannelTransformer implements Function<ChannelValueObject, Either<LoggerItem, ChannelCreateDescriptor>> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ImportChannelTransformer.class);

    private final MediatorIdentification mediatorIdentification;
    private final StaticConfiguration configuration;

    public ImportChannelTransformer(
            final StaticConfiguration configuration,
            final MediatorIdentification mediatorIdentification) {
        this.configuration = configuration;
        this.mediatorIdentification = mediatorIdentification;
    }

    @Override
    public Either<LoggerItem, ChannelCreateDescriptor> apply(@Nonnull final ChannelValueObject input) {
        checkNotNull(input);
        
        try {        
            final Optional<ChannelType> channelType = Optional.ofNullable(configuration.getChannelTypes().get(input.getType()));
            final Optional<MediatorInfoData> mediator = mediatorIdentification.tryIdentify(input.getMediator());

            if (!channelType.isPresent()) {
                return left(new LoggerItemChannel(input.getName(),
                        tr(Message.CHANNEL_UNKNOWN_TYPE, input.getType()), MessageSeverity.ERROR));
            }

            if (!mediator.isPresent()) {
                return left(new LoggerItemChannel(input.getName(),
                        tr(Message.MEDIATOR_DOES_NOT_EXIST, input.getMediator().getName()), MessageSeverity.ERROR));
            }

            final ChannelCreateDescriptor createDescriptor = new ChannelCreateDescriptor(channelType.get(), mediator.get().getId());
            ChannelUserPreferencesInitialData preferencesInitialData = createDescriptor.getPreferencesInitialData();
            preferencesInitialData.setName(input.getName());
            
            final ChannelProperties channelProperties = new ChannelProperties();
            applyDefaultChannelProperties(channelProperties, channelType.get(), preferencesInitialData);
            
            input.getConcurrentActivationsLimit().ifPresent(preferencesInitialData::setConcurrentActivationsLimit);
            input.getConcurrentActivationsLimited().ifPresent(preferencesInitialData::setConcurrentActivationsLimited);
            if (!input.getPropertyBag().isEmpty()) {
                channelProperties.setProperties(channelType.get(), preferencesInitialData, input.getPropertyBag());
            }
            
            return right(createDescriptor);        
        } catch (final InvalidMutationException e) {
            LOGGER.error("Critical error when trying to transform channel", e);
            return left(new LoggerItemChannel(input.getName(),
                    tr(Message.CHANNEL_INVALID_PROPERTIES, input.getName()), MessageSeverity.ERROR));
        }
    }

    /* Apply default property values to the newly created instance */
    private void applyDefaultChannelProperties(final ChannelProperties channelProperties, final ChannelType type, ChannelUserPreferencesInitialData preferencesInitialData) {
        for (final Entry<String, String> entry : type.getSupportedPropertyDefaultValues().entrySet()) {
            try {
                channelProperties.setProperty(type, preferencesInitialData, entry.getKey(), entry.getValue());
            } catch (final InvalidMutationException e) {
                LOGGER.warn("Default property ('{}','{}') could not be applied on new channel: {}", entry.getKey(), entry.getValue(), e.getMessage());
            }
        }
    }
}
