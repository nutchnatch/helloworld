package com.ossnms.dcn_manager.composables.import_export;

import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Stream;


// Consider to use http://javaslang.com after release of V2.0


public interface Either<L, R> {

    /**
     * @return true if this is Right
     */
    boolean isRight();

    /**
     * @return true if this is Left
     */
    boolean isLeft();

    /**
     * FlatMap over Right value
     */
    <T> Either<L, T> flatMap(Function<R, Either<L, T>> mapping);

    /**
     * Map over right value
     */
    <T> Either<L, T> mapRight(Function<R, T> mapping);

    /**
     * Map over left value
     */
    <T> Either<T, R> mapLeft(Function<L, T> mapping);

    /**
     * Constructs Left with value
     */
    static <L, R> Either<L, R> left(L value) {
        return new Left<>(value);
    }

    /**
     * Constructs Right with value
     */
    static <L, R> Either<L, R> right(R value) {
        return new Right<>(value);
    }

    /**
     * Consumes value if this is Left
     */
    void ifLeft(Consumer<L> consumer);

    /**
     * Consumes value if this is Right
     */
    void ifRight(Consumer<R> consumer);

    /**
     * Consumes either Left or Right value
     */
    default void consume(Consumer<L> leftConsumer, Consumer<R> rightConsumer) {
        ifLeft(leftConsumer);
        ifRight(rightConsumer);
    }

    /**
     * Provides value if this is Left or empty
     */
    Optional<L> getLeft();

    /**
     * Provides value if this is Right or empty
     */
    Optional<R> getRight();

    /**
     * Stream of value if this is Left or empty Stream
     */
    Stream<L> leftStream();

    /**
     * Stream of value if this is Right or empty Stream
     */
    Stream<R> rightStream();


    /**
     * Either value from Optional parameter or left value if absent 
     */
    static <L,R> Either<L,R> fromOption(Optional<R> option, L leftValue){
        return option.isPresent() ? right(option.get()) : left(leftValue);
    }

    class Left<L, R> implements Either<L, R> {

        private final L value;

        Left(L value) {
            this.value = value;
        }

        @Override public boolean isRight() {
            return false;
        }

        @Override public boolean isLeft() {
            return true;
        }

        @Override public <T> Either<L, T> flatMap(Function<R, Either<L, T>> mapping) {
            return Either.left(value);
        }

        @Override public <T> Either<L, T> mapRight(Function<R, T> mapping) {
            return Either.left(value);
        }

        @Override public <T> Either<T, R> mapLeft(Function<L, T> mapping) {
            return Either.left(mapping.apply(value));
        }

        @Override public void ifLeft(Consumer<L> consumer) {
            consumer.accept(value);
        }

        @Override public void ifRight(Consumer<R> consumer) {
        }

        @Override public Optional<L> getLeft() {
            return Optional.of(value);
        }

        @Override public Optional<R> getRight() {
            return Optional.empty();
        }

        @Override public Stream<L> leftStream() {
            return Stream.of(value);
        }

        @Override public Stream<R> rightStream() {
            return Stream.empty();
        }


    }

    class Right<L, R> implements Either<L, R> {

        private final R value;

        Right(R value) {
            this.value = value;
        }

        @Override public boolean isRight() {
            return true;
        }

        @Override public boolean isLeft() {
            return false;
        }

        @Override public <T> Either<L, T> flatMap(Function<R, Either<L, T>> mapping) {
            return mapping.apply(value);
        }

        @Override public <T> Either<L, T> mapRight(Function<R, T> mapping) {
            return Either.right(mapping.apply(value));
        }

        @Override public <T> Either<T, R> mapLeft(Function<L, T> mapping) {
            return Either.right(value);
        }

        @Override public void ifLeft(Consumer<L> consumer) {
        }

        @Override public void ifRight(Consumer<R> consumer) {
            consumer.accept(value);
        }

        @Override public Optional<L> getLeft() {
            return Optional.empty();
        }

        @Override public Optional<R> getRight() {
            return Optional.of(value);
        }

        @Override public Stream<L> leftStream() {
            return Stream.empty();
        }

        @Override public Stream<R> rightStream() {
            return Stream.of(value);
        }
    }
}


