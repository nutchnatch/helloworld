package com.ossnms.dcn_manager.composables.import_export.system;

import com.ossnms.dcn_manager.core.entities.container.system.SystemCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.import_export.identification.Identification;
import com.ossnms.dcn_manager.core.import_export.valueobjects.SystemValueObject;

import java.util.Optional;
import java.util.function.Function;

public class ImportSystemTransformer implements Function<SystemValueObject, Optional<SystemCreationDescriptor>> {

    private final Identification<SystemValueObject, SystemInfo> identification;

    public ImportSystemTransformer(Identification<SystemValueObject, SystemInfo> identification) {
        this.identification = identification;
    }

    @Override public Optional<SystemCreationDescriptor> apply(SystemValueObject system) {
        if (identification.tryIdentify(system).isPresent()) {
            return Optional.empty(); // system already exists
        }

        return Optional.of(descriptor(system));
    }

    private SystemCreationDescriptor descriptor(SystemValueObject system) {
        SystemCreationDescriptor descriptor = new SystemCreationDescriptor(system.name());
        descriptor.setDescription(system.description());
        descriptor.setUserText(system.userText());
        return descriptor;
    }

}
