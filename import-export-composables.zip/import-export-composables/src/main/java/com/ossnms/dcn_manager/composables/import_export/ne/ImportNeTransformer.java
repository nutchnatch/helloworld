package com.ossnms.dcn_manager.composables.import_export.ne;

import com.ossnms.dcn_manager.composables.import_export.Either;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoInitialData;
import com.ossnms.dcn_manager.core.import_export.identification.ChannelIdentification;
import com.ossnms.dcn_manager.core.import_export.identification.Identification;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableSystemValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.SystemValueObject;
import com.ossnms.dcn_manager.core.properties.ne.NeDirectRouteProperties;
import com.ossnms.dcn_manager.core.properties.ne.NeGatewayRouteProperties;
import com.ossnms.dcn_manager.core.properties.ne.NeOperationalProperties;
import com.ossnms.dcn_manager.core.properties.ne.NeProperties;
import com.ossnms.dcn_manager.core.properties.ne.NePropertyUtils;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.ossnms.dcn_manager.composables.import_export.Either.left;
import static com.ossnms.dcn_manager.composables.import_export.Either.right;
import static com.ossnms.dcn_manager.i18n.T.tr;

public class ImportNeTransformer implements Function<NeValueObject, Either<LoggerItem, NeCreateDescriptor>> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ImportNeTransformer.class);

    private final ChannelIdentification channelIdentification;
    private final Identification<SystemValueObject, SystemInfo> systemContainerIdentification;
    private final StaticConfiguration configuration;

    public ImportNeTransformer(
            @Nonnull final ChannelIdentification channelIdentification,
            @Nonnull final Identification<SystemValueObject, SystemInfo> systemContainerIdentification,
            @Nonnull final StaticConfiguration configuration) {
        this.channelIdentification = channelIdentification;
        this.systemContainerIdentification = systemContainerIdentification;
        this.configuration = configuration;
    }

    @Override
    public Either<LoggerItem, NeCreateDescriptor> apply(@Nonnull final NeValueObject input) {
        try {
            checkNotNull(input);

            final Optional<NeType> neType = Optional.ofNullable(configuration.getNeTypes().get(input.getType()));
            if (!neType.isPresent()) {
                return left(new LoggerItemNe(input.getName(),
                        tr(Message.NE_UNKNOWN_TYPE, input.getName(), input.getType()), -1, MessageSeverity.ERROR));
            }

            final Optional<ChannelUserPreferencesData> channel = channelIdentification.tryFindByName(input.getChannel());
            if (!channel.isPresent()) {
                return left(new LoggerItemNe(input.getName(),
                        tr(Message.CHANNEL_DOES_NOT_EXIST, input.getChannel()), -1, MessageSeverity.ERROR));
            }

            final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(channel.get().getId(), neType.get());

            final NeProperties properties = new NeProperties();
            final NeDirectRouteProperties routeProperties = new NeDirectRouteProperties();
            final NeOperationalProperties neOperationalProperties = new NeOperationalProperties();
            
            NePropertyUtils.applyDefaultProperties(createDescriptor, properties, routeProperties);
            
            NeInfoInitialData info = createDescriptor.getInfo();
            info.setCoreId(input.getCoreId());
            info.setProxyType(input.getType());
            createDescriptor.getPreferences().setName(input.getName());

            resolveSystemId(input).ifPresent(systemId ->
                    createDescriptor.getPreferences().setContainerId(Optional.of(systemId)));

            if (!input.getPropertyBag().isEmpty()) {
                applyProperties(input.getPropertyBag(), createDescriptor, properties, routeProperties);
                NePropertyUtils.applyAdditionalControlProperties(createDescriptor, neOperationalProperties, input.getPropertyBag());
            }

            return right(createDescriptor);
        } catch (final InvalidMutationException e) {
            LOGGER.error("Critical error when trying to transform NE", e);
            return left(new LoggerItemNe(input.getName(),
                    tr(Message.NE_INVALID_PROPERTIES, input.getName()), -1, MessageSeverity.ERROR));
        }
    }

    private Optional<Integer> resolveSystemId(@Nonnull NeValueObject ne) {
        return ne.systemContainer()
                .map(ImmutableSystemValueObject::of)
                .flatMap(systemContainerIdentification::tryIdentify)
                .map(BusinessObjectData::getId);
    }

    private void applyProperties(final Map<String, String> map, final NeCreateDescriptor createDescriptor, final NeProperties properties,
                                 final NeDirectRouteProperties routeProperties) throws InvalidMutationException {

        final NeType neType = createDescriptor.getType();

        // Order is important. We allow Route properties to depend on NE properties so the latter must be set first.
        properties.setProperties(neType, createDescriptor.getPreferences(), map);
        routeProperties.set(neType, createDescriptor, createDescriptor.getPreferences(), map);
        createDescriptor.putGatewayRoutes(new NeGatewayRouteProperties(neType).parseProperties(map, createDescriptor));

    }
    
}
