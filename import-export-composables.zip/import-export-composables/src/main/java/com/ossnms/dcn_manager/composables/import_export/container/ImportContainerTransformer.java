package com.ossnms.dcn_manager.composables.import_export.container;

import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.import_export.identification.Identification;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ContainerValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableContainerValueObject;

import java.util.Optional;
import java.util.function.Function;

public class ImportContainerTransformer implements Function<ContainerValueObject, Optional<ContainerCreationDescriptor>> {

    private final Identification<ContainerValueObject, ContainerInfo> identification;

    public ImportContainerTransformer(Identification<ContainerValueObject, ContainerInfo> identification) {
        this.identification = identification;
    }

    @Override public Optional<ContainerCreationDescriptor> apply(ContainerValueObject container) {
        if (!container.parent().isPresent()) {
            return Optional.empty(); // this is a root container. It is always present in system
        }

        if (identification.tryIdentify(container).isPresent()) {
            return Optional.empty(); // container already exists
        }

        Optional<ContainerInfo> parentContainer = container.parent()
                .map(ImmutableContainerValueObject::of)
                .flatMap(identification::tryIdentify);

        return parentContainer.map(BusinessObjectData::getId)
                .map(parentId -> descriptor(parentId, container));
    }

    private ContainerCreationDescriptor descriptor(int parentId, ContainerValueObject container) {
        ContainerCreationDescriptor descriptor = new ContainerCreationDescriptor(parentId, container.name());
        descriptor.setDescription(container.description());
        descriptor.setUserText(container.userText());
        return descriptor;
    }

}
