package com.ossnms.web.api.oif.proxy.impl.network;

import com.ossnms.web.api.oif.proxy.arquillian.ArquillianTestBase;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.filter.FilterOperation;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.common.api.result.ProcessableResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.sdn.model.call.CallField;
import com.ossnms.web.provider.sdn.model.call.CallID;
import com.ossnms.web.provider.sdn.model.call.CallSummary;
import com.ossnms.web.provider.sdn.model.common.enumerable.ErrorCode;
import com.ossnms.web.provider.sdn.model.network.Network;
import com.ossnms.web.provider.sdn.model.network.NetworkField;
import com.ossnms.web.provider.sdn.model.network.NetworkID;
import com.ossnms.web.provider.sdn.model.network.NetworkSummary;
import com.ossnms.web.provider.sdn.operations.network.NetworkEntityOperations;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.arquillian.junit.InSequence;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import static org.junit.Assert.*;
import static org.junit.Assert.assertFalse;

/**
 *
 */
@RunWith( Arquillian.class )
public class NetworkOperationsProxyImplTest extends ArquillianTestBase {

    private final static Logger LOGGER = LoggerFactory.getLogger(NetworkOperationsProxyImplTest.class);

    @Inject
    private NetworkEntityOperations networkOperations;

    private static final SecurityToken secToken = new SecurityToken.Builder( "username", "passw" /*"myCuteBearerToken!"*/ ).build();

    @Test
    @InSequence( 1 )
    public void shouldNotBeNull() {
        assertNotNull( networkOperations );
    }

    @Test(expected = RuntimeException.class)
    @InSequence( 2 )
    public void shouldNotDelete() {
        networkOperations.delete( secToken, new NetworkID.Builder( "1" ).build() );

        Network details = networkOperations.getDetails( secToken, new NetworkID.Builder("1").build() );
        assertNull(details);
    }


    @Test
    @InSequence( 10 )
    public void shouldGetNoneAtAll() {

        OperationResult<Network, NetworkField> domains = networkOperations.getAll( secToken, Collections.emptyList(), null, null );

        assertEquals( 0, domains.getTotalElements() );
        assertTrue( domains.getResultCollection().isEmpty() );
    }

    @Test
    @InSequence( 11 )
    public void shouldNotGetDetailsById() {
        Network domain = networkOperations.getDetails( secToken, new NetworkID.Builder( "1" ).build() );
        assertNull( domain );
    }

    @Test
    @InSequence( 12 )
    public void shouldGetCreated() {

        Network domain =
            new Network.Builder( null )
            .setName( "GreatNameForDomain" )
            .setProtocols( new String[] { "SIMPLIFIED", "RESTCONF" } )
            .setTopologyType( "FULL" )
            .build();

        NetworkID createdDomainId = networkOperations.insert( secToken, domain );

        assertNotNull( createdDomainId );
        assertEquals( createdDomainId.getID(), "1" );

        Network createdDomain = networkOperations.getDetails( secToken, createdDomainId );

        assertNotNull( createdDomain );

        assertEquals( createdDomain.getID(), createdDomainId );
        assertEquals( createdDomain.getName(), domain.getName() );
        assertArrayEquals( createdDomain.getProtocols(), domain.getProtocols() );
        assertEquals( createdDomain.getTopologyType(), domain.getTopologyType() );
    }


    @Test
    @InSequence( 13 )
    public void shouldNotGetCreatedBecauseMalformed() {

        Network domain =
            new Network.Builder( null )
                .setName( "GreatNameForDomain" )
                .setProtocols( new String[] { "SIMPLIFIED", "RESTCONF" } )
                .setTopologyType( "FULL" )
                .setUserDomain( "field not accepted in creation" )
                .build();

        NetworkID createdDomainId = networkOperations.insert( secToken, domain );

        assertNull( createdDomainId );

        domain =
            new Network.Builder( new NetworkID.Builder( "1" ).build() )
                .setName( "GreatNameForDomain" )
                .setProtocols( new String[] { "SIMPLIFIED", "RESTCONF" } )
                .setTopologyType( "FULL" )
                .build();

        createdDomainId = networkOperations.insert( secToken, domain );

        assertNull( createdDomainId );
    }


    @Test
    @InSequence( 14 )
    public void shouldNotGetUpdatedBecauseMalformed() {

        Network domain =
            new Network.Builder( new NetworkID.Builder( "1" ).build() )
                .setName( "JustChanged" )
                .setProtocols( new String[] { "SIMPLIFIED" } )
                .setTopologyType( "field not accepted in creation" )
                .build();

        NetworkID updatedDomainId = networkOperations.update( secToken, domain );

        assertNull( updatedDomainId );


        domain =
            new Network.Builder( new NetworkID.Builder( "1" ).build() )
                .setName( "JustChanged" )
                .setProtocols( new String[] { "SIMPLIFIED" } )
                .setUserDomain( "field not accepted in creation" )
                .build();

        updatedDomainId = networkOperations.insert( secToken, domain );

        assertNull( updatedDomainId );

        domain =
            new Network.Builder( new NetworkID.Builder( "1" ).build() )
                .setName( "JustChanged" )
                .setProtocols( new String[] { "SIMPLIFIED" } )
                .setSecure( true ) // field not accepted in creation!
                .build();

        updatedDomainId = networkOperations.insert( secToken, domain );

        assertNull( updatedDomainId );
    }


    @Test
    @InSequence( 15 )
    public void shouldGetUpdated() {

        Network domain =
            new Network.Builder( new NetworkID.Builder( "1" ).build() )
                .setName( "JustChanged" )
                .setProtocols( new String[] { "SIMPLIFIED" } )
                .build();

        NetworkID updatedDomainId = networkOperations.update( secToken, domain );

        assertNotNull( updatedDomainId );
        assertEquals( "1", updatedDomainId.getID() );

        Network updatedDomain = networkOperations.getDetails( secToken, updatedDomainId );

        assertNotNull( updatedDomain );

        assertEquals( updatedDomain.getID(), updatedDomainId );
        assertEquals( updatedDomain.getName(), domain.getName() );
        assertArrayEquals( updatedDomain.getProtocols(), domain.getProtocols() );
        assertEquals( "FULL", updatedDomain.getTopologyType() ); // Currently 1 is FULL (above when created)
    }


    @Test
    @InSequence( 16 )
    public void shouldDelete() {

        NetworkID domainId = new NetworkID.Builder( "1" ).build();

        networkOperations.delete( secToken, domainId );

        Network domain = networkOperations.getDetails( secToken, domainId );

        assertNull( domain );
    }


    @Test
    @InSequence( 21 )
    public void shouldGetAll() {

        OperationResult<Network, NetworkField> all = networkOperations.getAll( secToken, null, null, null );

        assertNotNull( all );
        assertTrue( all.getResultCollection().isEmpty() );

        createDomains( 17 );

        all = networkOperations.getAll( secToken, null, null, null );

        assertNotNull( all );
        assertEquals( 17, all.getResultCollection().size() );

        Iterator<Network> it = all.getResultCollection().iterator();

        for ( int i = 1 ; it.hasNext() ; i++ ) {
            Network domain = it.next();

            assertNotNull( domain );
            assertEquals( "domain-" + i, domain.getName() );
            assertEquals( String.valueOf( i ), domain.getID().getID() );
        }
    }

    @Test
    @InSequence( 22 )
    public void shouldGetById() {

        NetworkSummary domainSummary = networkOperations.getSummary( secToken, new NetworkID.Builder( "3" ).build() );

        assertNotNull( domainSummary );
        assertEquals( "3", domainSummary.getID().getID() );
        assertEquals( "domain-3", domainSummary.getName() );
        assertEquals( "SIMPLIFIED", domainSummary.getTopologyType() );
        assertArrayEquals( new String[] { "SIMPLIFIED", "RESTCONF" }, domainSummary.getProtocols() );

        Network domain = networkOperations.getDetails( secToken, new NetworkID.Builder( "3" ).build() );

        assertNotNull( domain );
        assertEquals( "3", domain.getID().getID() );
        assertEquals( "domain-3", domain.getName() );
        assertEquals( "SIMPLIFIED", domain.getTopologyType() );
        assertArrayEquals( new String[] { "SIMPLIFIED", "RESTCONF" }, domain.getProtocols() );
        assertNotNull( domain.getUserDomain() );
    }


    @Test
    @InSequence( 23 )
    public void shouldGetByName() {
        Filter<NetworkField> filterByName = new Filter.Builder<>( NetworkField.NAME, FilterOperation.EQUALS, "domain-3" ).build();
        OperationResult<Network, NetworkField> all = networkOperations.getAll( secToken, Collections.singleton( filterByName ), null, null );

        assertNotNull( all );
        assertEquals( 1, all.getResultCollection().size() );
        assertEquals( 1, all.getTotalElements() );

        Network domain = all.getResultCollection().iterator().next();

        assertNotNull( domain );
        assertEquals( "3", domain.getID().getID() );
        assertEquals( "domain-3", domain.getName() );
        assertEquals( "SIMPLIFIED", domain.getTopologyType() );
        assertArrayEquals( new String[] { "SIMPLIFIED", "RESTCONF" }, domain.getProtocols() );
        assertNotNull( domain.getUserDomain() );
    }


    @Test
    @InSequence( 24 )
    public void shouldNotGetByName() {

        Filter<NetworkField> filterByName = new Filter.Builder<>( NetworkField.NAME, FilterOperation.EQUALS, "domain-999" ).build();

        OperationResult<Network, NetworkField> all = networkOperations.getAll( secToken, Collections.singleton( filterByName ), null, null );

        assertNotNull( all );
        assertEquals( 0, all.getTotalElements() );
    }


    @Test
    @InSequence( 25 )
    public void shouldGetByIds() {

        List<NetworkID> filterByIds = new ArrayList<>( 3 );

        filterByIds.add( new NetworkID.Builder( "3" ).build() );
        filterByIds.add( new NetworkID.Builder( "6" ).build() );
        filterByIds.add( new NetworkID.Builder( "9" ).build() );

        OperationResult<Network, NetworkField> all = networkOperations.getAll( secToken, filterByIds );

        assertNotNull( all );
        assertEquals( 3, all.getTotalElements() );
    }

    @Test
    @InSequence( 26 )
    public void shouldNotGetByIds() {
        List<NetworkID> filterByIds = new ArrayList<>( 3 );

        filterByIds.add( new NetworkID.Builder( "999" ).build() );
        filterByIds.add( new NetworkID.Builder( "998" ).build() );
        filterByIds.add( new NetworkID.Builder( "997" ).build() );

        OperationResult<Network, NetworkField> all = networkOperations.getAll( secToken, filterByIds );

        assertNotNull( all );
        assertEquals( 3, all.getTotalElements() );

        Iterator it = all.getResultCollection().iterator();

        assertNull( it.next() );
        assertNull( it.next() );
        assertNull( it.next() );
    }

    @Test
    @InSequence(27)
    public void shouldGetAllSummury() {

        OperationResult<NetworkSummary, NetworkField> allSummary = networkOperations.getAllSummary(secToken, null, null, null);

        assertNotNull(allSummary);
        assertFalse(allSummary.getResultCollection().isEmpty());

        allSummary = networkOperations.getAllSummary(secToken,Collections.emptyList());

        assertNotNull(allSummary);
        assertFalse(allSummary.getResultCollection().isEmpty());
    }

    /**
     *
     * @param totalDomainsToBeCreated
     */
    private void createDomains( int totalDomainsToBeCreated ) {
        for ( int i = 0; i < totalDomainsToBeCreated; i++ ) {

            String topologyType;
            String[] protocols;

            if ( i % 2 == 0 ) {
                topologyType = "SIMPLIFIED";
                protocols = new String[]{ "SIMPLIFIED", "RESTCONF" };
            } else {
                topologyType = "FULL";
                protocols = new String[]{ "SIMPLIFIED" };
            }

            Network domain = new Network.Builder( null )
                    .setName( "domain-" + (i + 1) )
                    .setProtocols( protocols )
                    .setTopologyType( topologyType )
                    .build();

            NetworkID createdDomainId = networkOperations.insert( secToken, domain );
            assertNotNull( createdDomainId );
        }
    }
}