package com.ossnms.web.api.oif.proxy.arquillian;

import com.ossnms.web.api.common.context.JWTSessionBasedUserPrincipal;
import com.ossnms.web.api.common.context.SessionBasedSecurityContext;
import com.ossnms.web.api.common.context.SessionBasedUserPrincipal;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.test.api.ArquillianResource;
import org.jboss.resteasy.spi.ResteasyProviderFactory;
import org.jboss.shrinkwrap.api.Archive;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.junit.Before;
import org.junit.BeforeClass;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.SecurityContext;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

/**
 *
 */
public abstract class ArquillianTestBase {

    protected static final String SYS_PROPERTY_OIF_LOCATION = "oif.location";
    protected static final String SYS_PROPERTY_OIF_LOCATION_PORT = "oif.location.port";

    private static Set<Class<?>> classes;
    static {
        classes = new HashSet<>();
        // resource classes
        classes.add(NetworkMockService.class);
        classes.add(CallMockService.class);
        classes.add(VertexMockService.class);
        classes.add(EndpointMockService.class);
        classes.add(EndMockService.class);
        classes.add(EdgeMockService.class);
        classes.add(ConnectionMockService.class);
    }

    /**
     * Method the will return the test version of the Customer Portal Rest API.
     *
     * @return
     */
    @Deployment
    public static Archive<?> createArchive(){
        return ShrinkWrap.create(WebArchive.class, "arquillian.war")
            .addClass(BaseApplication.class)
            // add required packages
            .addPackages(true, "com.ossnms.web.api.oif.proxy")
            // add resources
            .addAsWebInfResource("web.xml")
            .addAsWebInfResource("beans.xml")
            .addAsResource("log4j.xml");
    }
    /**
     * URL that holds the base address where the API was deployed
     */
    @ArquillianResource
    protected static URL webAppUrl;

    /**
     *
     */
    @ApplicationPath("")
    public static class BaseApplication extends Application {
        @Override
        public Set<Class<?>> getClasses() {
            return classes;
        }
    }

    /**
     *
     */
    @Before
    public void beforeTest() {
        System.setProperty(SYS_PROPERTY_OIF_LOCATION, webAppUrl.toString());
        System.setProperty(SYS_PROPERTY_OIF_LOCATION_PORT, Integer.toString(webAppUrl.getPort()));
    }

    /**
     *
     */
    @BeforeClass
    public static void beforeClass() {
        ResteasyProviderFactory.pushContext(SecurityContext.class, getSecurityContext());

        // since the data set for the NetworkMockService is static, we can instantiate a new object and reset it
        new NetworkMockService().reset();
    }

    /**
     *
     */
    private static SessionBasedSecurityContext getSecurityContext() {
        SecurityToken securityToken = new SecurityToken.Builder("username1", "test-token").build();
        SessionBasedUserPrincipal userPrincipal = new JWTSessionBasedUserPrincipal("username1", securityToken, "test-token");
        return new SessionBasedSecurityContext(userPrincipal);
    }
}
