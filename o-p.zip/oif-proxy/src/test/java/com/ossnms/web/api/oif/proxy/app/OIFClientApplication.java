package com.ossnms.web.api.oif.proxy.app;

import com.ossnms.web.api.oif.proxy.api.client.call.CallNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.common.AuthorizationHeaderFilter;
import com.ossnms.web.api.oif.proxy.api.client.connection.ConnectionNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.edge.EdgeNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.end.EndNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.endpoint.EndpointNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.network.NetworkNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.network.NetworkObject;
import com.ossnms.web.api.oif.proxy.api.client.network.NetworkObjectList;
import com.ossnms.web.api.oif.proxy.api.client.vertex.VertexNDMClient;
import com.ossnms.web.api.oif.proxy.api.common.util.SdnUtils;
import com.ossnms.web.api.oif.proxy.api.producer.ProxyProducer;
import com.ossnms.web.api.oif.proxy.impl.call.CallOperationsProxyImpl;
import com.ossnms.web.api.oif.proxy.impl.endpoint.EndpointOperationsProxyImpl;
import com.ossnms.web.provider.common.api.result.ProcessableResult;
import com.ossnms.web.provider.sdn.model.call.Call;
import com.ossnms.web.provider.sdn.model.call.CallField;
import com.ossnms.web.provider.sdn.model.call.CallID;
import com.ossnms.web.provider.sdn.model.call.CallSummary;
import com.ossnms.web.provider.sdn.model.common.enumerable.ErrorCode;
import com.ossnms.web.provider.sdn.operations.call.ProcessableCallEntityOperations;
import com.ossnms.web.provider.sdn.operations.endpoint.EndpointEntityOperations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.Response;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

/**
 *
 */
public class OIFClientApplication {

    private static final Logger LOGGER = LoggerFactory.getLogger( OIFClientApplication.class );
    private static final String URL = "https://ptlisvlsdn009.dci.co-int.net:8443";
    private static final AuthorizationHeaderFilter AUTH_FILTER = new AuthorizationHeaderFilter("Administrator", "123QWEasd");
    private static final ProcessableCallEntityOperations CALL_OPERATION_PROXY = getCallOperationProxy(URL, AUTH_FILTER);

    public static void main( String[] args ) {

//        playWithDomains(URL, AUTH_FILTER);
        playWithServices();
//        getCallDetails();
//        getCallSummary();
//        getAllSummaryFromCalls();
//        verifyAllSummary();
//        endpointTest( URL, AUTH_FILTER );
    }

    private static void playWithServices() {

        ProcessableResult<CallID, CallField, ErrorCode> allIds = getAllCallIds();

        assertNotNull(allIds);
        int nOfServices = allIds.getResultCollection().size();

        checkAllSummaryMatchesAllIds(nOfServices);

        checkNoSummaryForEmptyList( nOfServices );

        ProcessableResult<CallSummary, CallField, ErrorCode> summaryThroughCallIds = checkSummaryWithCallIds(allIds, nOfServices);

        summaryThroughCallIds.getResultCollection()
            .forEach( call -> logDebugService( call ) );

        checkDetailsMatchesAllIds(nOfServices);

        checkNoDetailsWithEmptyList( nOfServices );

        ProcessableResult<Call, CallField, ErrorCode> allDetailsFromCallIds = checkDetailsMatchesAllIds(allIds, nOfServices);

        allDetailsFromCallIds.getResultCollection()
            .forEach( call -> logDebugService( call ) );
    }

    private static void logDebugService( CallSummary call ) {

        LOGGER.debug( call.getID().getDomainId() + "-" + call.getID().getID() + ": { " + call.getName() + ": " + call.getAEnd().getVertex().getName() + " -> " + call.getZEnd().getVertex().getName() + " }" );
    }

    private static ProcessableResult<Call, CallField, ErrorCode> checkDetailsMatchesAllIds(ProcessableResult<CallID, CallField, ErrorCode> allIds, int nOfServices) {
        ProcessableResult<Call, CallField, ErrorCode> allDetailsFromCallIds = CALL_OPERATION_PROXY.getAll(null, allIds.getResultCollection());
        assertNotNull(allDetailsFromCallIds);
        assertEquals(allDetailsFromCallIds.getResultCollection().size(), nOfServices);
        return allDetailsFromCallIds;
    }

    private static void checkNoDetailsWithEmptyList( int nOfServices ) {
        ProcessableResult<Call, CallField, ErrorCode> allDetailsFromEmptyList = CALL_OPERATION_PROXY.getAll(null, Collections.emptyList());
        assertNotNull(allDetailsFromEmptyList);
        assertThat( allDetailsFromEmptyList.getResultCollection().size(), is( nOfServices ) );
    }

    private static void checkDetailsMatchesAllIds(int nOfServices) {
        ProcessableResult<Call, CallField, ErrorCode> allDetails = CALL_OPERATION_PROXY.getAll( null, null, null, null );
        assertNotNull(allDetails);
        assertEquals(allDetails.getResultCollection().size(), nOfServices);
    }

    private static ProcessableResult<CallSummary, CallField, ErrorCode> checkSummaryWithCallIds(ProcessableResult<CallID, CallField, ErrorCode> allIds, int nOfServices) {
        ProcessableResult<CallSummary, CallField, ErrorCode> summaryThroughCallIds = CALL_OPERATION_PROXY.getAllSummary(null, allIds.getResultCollection());
        assertNotNull(summaryThroughCallIds);
        assertEquals(summaryThroughCallIds.getResultCollection().size(), nOfServices);
        return summaryThroughCallIds;
    }

    private static void checkNoSummaryForEmptyList( int nOfServices ) {
        ProcessableResult<CallSummary, CallField, ErrorCode> summaryWithEmptyist = CALL_OPERATION_PROXY.getAllSummary(null, Collections.emptyList());
        assertNotNull(summaryWithEmptyist);
        assertThat( summaryWithEmptyist.getResultCollection().size(), is( nOfServices ) );
    }

    private static void checkAllSummaryMatchesAllIds(int nOfServices) {
        ProcessableResult<CallSummary, CallField, ErrorCode> allSummary = getAllSummary();
        assertNotNull(allSummary);
        assertEquals(allSummary.getResultCollection().size(), nOfServices);
    }

    private static ProcessableCallEntityOperations getCallOperationProxy(String url, AuthorizationHeaderFilter authFilter) {

        VertexNDMClient vertexProxy = ProxyProducer.getProxy(
            VertexNDMClient.class,
            url,
            authFilter
        );

        EndNDMClient edgeEndProxy = ProxyProducer.getProxy(
            EndNDMClient.class,
            url,
            authFilter
        );

        EdgeNDMClient edgeProxy = ProxyProducer.getProxy(
            EdgeNDMClient.class,
            url,
            authFilter
        );

        EndpointNDMClient endpointProxy = ProxyProducer.getProxy(
            EndpointNDMClient.class,
            url,
            authFilter
        );

        CallNDMClient proxy = ProxyProducer.getProxy(
            CallNDMClient.class,
            url,
            authFilter
        );

        ConnectionNDMClient connectionProxy = ProxyProducer.getProxy(
            ConnectionNDMClient.class,
            url,
            authFilter
        );

        return new CallOperationsProxyImpl(
            proxy,
            vertexProxy,
            edgeEndProxy,
            edgeProxy,
            endpointProxy,
            connectionProxy
        );
    }

    private static ProcessableResult<CallID, CallField, ErrorCode> getAllCallIds() {
        return CALL_OPERATION_PROXY.getAllIds(null, null, null, null);
    }

    private static ProcessableResult<CallSummary, CallField, ErrorCode> getAllSummary() {
        return CALL_OPERATION_PROXY.getAllSummary(null, null, null, null);
    }

    private static void getCallDetails() {
        getAllCallIds().getResultCollection().stream()
            .map(callID -> {
                    Call call = CALL_OPERATION_PROXY.getDetails(null, callID).getEntity();
                    checkDetailsDefaultAttributes(call);
                return call;
            }).collect(Collectors.toList());
    }

    private static void getCallSummary() {
        getAllCallIds().getResultCollection().stream()
            .map(callID -> {
                CallSummary callSummary = CALL_OPERATION_PROXY.getSummary(null, callID).getEntity();
                return checkSummaryDefaultAttributes(callSummary);
            }).collect(Collectors.toList());
    }

    private static void getAllSummaryFromCalls() {
        CALL_OPERATION_PROXY.getAllSummary(null, getAllCallIds().getResultCollection()).getResultCollection().stream()
                .map(OIFClientApplication::checkSummaryDefaultAttributes).collect(Collectors.toList());
    }

    private static void verifyAllSummary() {
        getAllSummary().getResultCollection().stream()
            .map(OIFClientApplication::checkSummaryDefaultAttributes).collect(Collectors.toList());
    }

    private static CallSummary checkSummaryDefaultAttributes(CallSummary summary) {
        assertNotNull(summary.getID());
        assertNotNull(summary.getName());
        assertNotNull(summary.getAEnd());
        assertNotNull(summary.getZEnd());
        assertNotNull(summary.getOperStatus());
        return summary;
    }

    private static void checkDetailsDefaultAttributes(Call call) {
        assertNull(call.getPathRequestId());
        assertNotNull(call.getAdminStatus(), notNullValue());
        assertNotNull(call.getCallProvisioningStatus(), notNullValue());
        assertNotNull(call.getCallConfigStatus(), notNullValue());
        assertNotNull(call.getNetworkSyncStatus(), notNullValue());
        assertNotNull(call.getCallLatency());
        assertNotNull(call.getSwitchingType());
        assertNotNull(call.getEncoding());
        assertNotNull(call.getDirectionality());
        assertNotNull(call.getServiceLatency());
        assertFalse(call.getRoutingOverEnabledResourcesOnly());
        assertFalse(call.getRoutingOverEnabledResourcesOnly());
        assertFalse(call.getRoutingOverNotReservedResourcesOnly());
        assertNull(call.getOrderNumber());
        assertFalse(call.isRestorable());
        assertNotNull(call.getID());
        assertNotNull(call.getName());
        assertNotNull(call.getAEnd());
        assertNotNull(call.getZEnd());
        assertNotNull(call.getOperStatus());
    }

    private static void playWithDomains( String url, AuthorizationHeaderFilter authFilter ) {

        NetworkNDMClient proxy = ProxyProducer.getProxy(
            NetworkNDMClient.class,
            url,
            authFilter
        );

        Response response = proxy.getAll(null);
        NetworkObjectList networkIDResponseObject = response.readEntity( NetworkObjectList.class );

        List<NetworkObject> collect = Arrays.stream( networkIDResponseObject.id )
            .map( id -> {
                String domainId = SdnUtils.extractId( id );
                if ( domainId != null ) {
                    return proxy.get( domainId ).readEntity( NetworkObject.class );
                }
                else {
                    return null;
                }
            } )
            .collect( Collectors.toList() );

        LOGGER.debug( String.valueOf( collect.size() ) );

        for ( NetworkObject domain : collect ) {
            LOGGER.debug( domain.toString() );
        }

        NetworkObject newDomain = new NetworkObject();

        newDomain.name = "Olaricas!";
        newDomain.topologyType = "FULL";
        newDomain.protocols = new String[]{ "SIMPLIFIED" };

        response = proxy.create( newDomain );

        LOGGER.debug( String.valueOf( response.getStatusInfo().getStatusCode() ) );
    }

    /**
     * @param url
     * @param authFilter
     */
    private static void endpointTest( String url, AuthorizationHeaderFilter authFilter ) {

        EndpointNDMClient endpointProxy = ProxyProducer.getProxy(
            EndpointNDMClient.class,
            url,
            authFilter
        );

        EndpointEntityOperations endpointEntityOperations = new EndpointOperationsProxyImpl(
            new InstanceImpl<>( endpointProxy )
        );

        endpointEntityOperations.getAllIds( null, null, null, null );
    }
}