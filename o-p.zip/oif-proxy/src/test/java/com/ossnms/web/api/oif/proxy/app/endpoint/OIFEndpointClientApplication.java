package com.ossnms.web.api.oif.proxy.app.endpoint;

import com.ossnms.web.api.oif.proxy.api.client.common.AuthorizationHeaderFilter;
import com.ossnms.web.api.oif.proxy.api.client.endpoint.EndpointNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.endpoint.EndpointObject;
import com.ossnms.web.api.oif.proxy.api.client.endpoint.EndpointObjectList;
import com.ossnms.web.api.oif.proxy.api.client.endpoint.EndpointWorker;
import com.ossnms.web.api.oif.proxy.api.common.result.GenericErrorCode;
import com.ossnms.web.api.oif.proxy.api.producer.ProxyProducer;
import com.ossnms.web.provider.common.api.result.ProcessableSingleResult;

import javax.ws.rs.core.Response;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 */
public class OIFEndpointClientApplication {

    private static final String URL = "https://ptlisvlsdn009.dci.co-int.net:8443";
    private static final AuthorizationHeaderFilter AUTH_FILTER = new AuthorizationHeaderFilter( "Administrator", "123QWEasd" );

    private static final String DOMAIN_ID = "*";
    private static final String DOMAIN_ID_PROVIDER = "1";

    /**
     * @param args
     */
    public static void main( String[] args ) {

    	EndpointNDMClient proxy = ProxyProducer.getProxy(
    	    EndpointNDMClient.class,
            URL,
            AUTH_FILTER
        );

        Response response = proxy.getAll(DOMAIN_ID, null);
        EndpointObjectList endpointObjectList = response.readEntity(EndpointObjectList.class);

        assert endpointObjectList != null;

        List<ProcessableSingleResult<EndpointObject, GenericErrorCode>> collect = endpointObjectList.getEndpoints()
            .stream()
            .map(EndpointWorker.fromURIFunction(proxy))
            .collect(Collectors.toList());

        assert collect != null;
    }
}
