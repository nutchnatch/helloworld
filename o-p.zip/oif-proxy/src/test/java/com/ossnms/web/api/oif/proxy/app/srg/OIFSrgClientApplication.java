package com.ossnms.web.api.oif.proxy.app.srg;

import com.ossnms.web.api.oif.proxy.api.client.common.AuthorizationHeaderFilter;
import com.ossnms.web.api.oif.proxy.api.client.srg.SrgNDMCLient;
import com.ossnms.web.api.oif.proxy.api.client.srg.SrgObject;
import com.ossnms.web.api.oif.proxy.api.client.srg.SrgObjectList;
import com.ossnms.web.api.oif.proxy.api.client.srg.SrgWorker;
import com.ossnms.web.api.oif.proxy.api.common.result.GenericErrorCode;
import com.ossnms.web.api.oif.proxy.api.producer.ProxyProducer;
import com.ossnms.web.provider.common.api.result.ProcessableSingleResult;

import javax.ws.rs.core.Response;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

/**
 *
 */
public class OIFSrgClientApplication {

    private static final String URL = "https://ptlisvlsdn009.dci.co-int.net:8443";
    private static final AuthorizationHeaderFilter AUTH_FILTER = new AuthorizationHeaderFilter( "Administrator", "123QWEasd" );

    private static final String NETWORK_ID = "*";
    private static final String NETWORK_ID_PROVIDER = "1";

    /**
     * @param args
     */
    public static void main( String[] args ) throws ExecutionException, InterruptedException {

        SrgNDMCLient proxy = ProxyProducer.getProxy(
            SrgNDMCLient.class,
            URL,
            AUTH_FILTER
        );

        Response response = proxy.getAll(NETWORK_ID_PROVIDER, null);
        SrgObjectList srgObjectList = response.readEntity(SrgObjectList.class);

        assert srgObjectList != null;

        long time = System.currentTimeMillis();
        List<ProcessableSingleResult<SrgObject, GenericErrorCode>> collect = srgObjectList.getSrgs()
            .stream()
            .skip(10)
            .limit(10)
            .map(SrgWorker.fromURIFunction(proxy))
            .collect(Collectors.toList());
        time = System.currentTimeMillis() - time;

        System.out.println("Obtained " + collect.size() + " SRG objects in " + time/1000 + " seconds.");
    }
}
