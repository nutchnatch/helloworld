package com.ossnms.web.api.oif.proxy.arquillian;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ossnms.web.api.oif.proxy.api.client.common.CommonWorker;
import com.ossnms.web.api.oif.proxy.api.client.edge.EdgeNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.edge.EdgeObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import java.io.File;
import java.io.IOException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import static com.ossnms.web.api.oif.proxy.api.common.util.SdnUtils.buildUri;
import static com.ossnms.web.api.oif.proxy.api.common.util.SdnUtils.extractId;

/**
 *
 */
public class EdgeMockService implements EdgeNDMClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(EdgeMockService.class);

    private static Map<String, EdgeObject> edgeObjects = new HashMap<>();

    private static Comparator<EdgeObject> edgeObjectComparator = Comparator.comparingLong(e -> Long.parseLong(extractId(e.getId())));

    public EdgeMockService() {
        createEdgeObjects();
    }

    private void createEdgeObjects() {

        ObjectMapper objectMapper = new ObjectMapper();

        JsonFactory f = new JsonFactory();
        JsonParser jp = null;

        try {
            jp = f.createParser(new File("src/test/resources/jsonData/edges.json"));
            // advance stream to START_ARRAY first:
            jp.nextToken();
            // and then each time, advance to opening START_OBJECT
            while (jp.nextToken() == JsonToken.START_OBJECT){
                EdgeObject edgeObject = objectMapper.readValue(jp, EdgeObject.class);

                String domainId = CommonWorker.toDomainId(edgeObject.getId());
                String id = CommonWorker.toId(edgeObject.getId());
                String topologyId = CommonWorker.toTopologyId(edgeObject.getId());

                edgeObjects.put(urify(domainId,topologyId,id) , edgeObject);
            }
        } catch (IOException e) {
            LOGGER.error(e.toString());
        }
    }



    @Override
    public Response getAll(@PathParam("networkId") String networkId, @PathParam("topologyId") String topologyId) {
        return null;
    }

    @Override
    public Response getAll(@PathParam("networkId") String networkId, @PathParam("topologyId") String topologyId, @QueryParam("name") String filterByName) {
        return null;
    }

    @Override
    public Response get(@PathParam("networkId") String networkId, @PathParam("topologyId") String topologyId, @PathParam("id") String id) {
        EdgeObject edgeObject = edgeObjects.get(urify(networkId,topologyId, id));
        if (edgeObject == null) {
            return Response.status(Response.Status.NOT_FOUND)
                // Added html content to simulate current SDN (wrong) behavior
                .entity("<html><body><h1>Whitelabel Error Page</h1><p>This application has no explicit mapping for /error, so you are seeing this as a fallback.</p><div id='created'>Mon Oct 24 19:27:31 WEST 2016</div><div>There was an unexpected error (type=Not Found, status=404).</div><div>Not Found</div></body></html>")
                .build();
        } else {
            // Special case for PROVIDER domain ...
            return Response.ok(edgeObject).build();
        }
    }

    @Override
    public Response create(@PathParam("networkId") String networkId, @PathParam("topologyId") String topologyId, EdgeObject entity) {
        return null;
    }

    @Override
    public Response update(@PathParam("networkId") String networkId, @PathParam("topologyId") String topologyId, @PathParam("id") String id, EdgeObject entity) {
        return null;
    }

    @Override
    public Response delete(@PathParam("networkId") String networkId, @PathParam("topologyId") String topologyId, @PathParam("id") String id) {
        return null;
    }

    /**
     * @param id
     * @return
     */
    private static String urify(String domainId, String topologyId, String id) {
        return buildUri(domainId, topologyId, id, "edge");
    }
}
