package com.ossnms.web.api.oif.proxy.arquillian;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ossnms.web.api.oif.proxy.api.client.call.CallNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.call.CallObject;
import com.ossnms.web.api.oif.proxy.api.client.call.CallObjectList;
import com.ossnms.web.api.oif.proxy.api.client.call.EnforceResponseObject;
import com.ossnms.web.api.oif.proxy.api.client.common.CommonWorker;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import java.io.File;
import java.io.IOException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import static com.ossnms.web.api.oif.proxy.api.common.util.SdnUtils.buildUri;
import static com.ossnms.web.api.oif.proxy.api.common.util.SdnUtils.extractId;

/**
 *
 */
public class CallMockService implements CallNDMClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(CallMockService.class);

    private static Map<String, CallObject> callObjects = new HashMap<>();

    private static Comparator<CallObject> callObjectComparator = Comparator.comparingLong(e -> Long.parseLong(extractId(e.getId())));


    public CallMockService() {
        createCallObjects();
    }

    private void createCallObjects() {
        ObjectMapper objectMapper = new ObjectMapper();

        JsonFactory f = new JsonFactory();
        JsonParser jp = null;

        try {
            jp = f.createParser(new File("src/test/resources/jsonData/calls.json"));
            // advance stream to START_ARRAY first:
            jp.nextToken();
            // and then each time, advance to opening START_OBJECT
            while (jp.nextToken() == JsonToken.START_OBJECT) {
                CallObject callObject = objectMapper.readValue(jp, CallObject.class);

                String domainId = CommonWorker.toDomainId(callObject.getId());
                String id = CommonWorker.toId(callObject.getId());

                callObjects.put(urify(domainId, id), callObject);
            }
        } catch (IOException e) {
            LOGGER.error(e.toString());
        }
    }

    @Override
    public Response getAll(@PathParam("callId") String callId, @QueryParam("name") String filterByName) {

        CallObjectList list = new CallObjectList();

        LOGGER.debug("FILTER BY NAME - {}", filterByName);

        list.setId(callObjects.values()
            .stream()
            .sorted(callObjectComparator)
            .filter(item -> filterByName == null || filterByName.isEmpty() || filterByName.equals(item.getName()))
            .map(item -> item.getId())
            .collect(Collectors.toList())
        );

        int totalFiltered = list.getId().size();

        return Response.ok(totalFiltered == 0 ? null : list)
            .header("Content-range", (totalFiltered == 0 ? "0-0/0" : "0-" + (totalFiltered - 1) + "/" + totalFiltered))
            .build();
    }

    @Override
    public Response get(@PathParam("networkId") String networkId, @PathParam("id") String id) {

        CallObject callObject = callObjects.get(urify(networkId, id));
        if (callObject == null) {
            return Response.status(Response.Status.NOT_FOUND)
                // Added html content to simulate current SDN (wrong) behavior
                .entity("<html><body><h1>Whitelabel Error Page</h1><p>This application has no explicit mapping for /error, so you are seeing this as a fallback.</p><div id='created'>Mon Oct 24 19:27:31 WEST 2016</div><div>There was an unexpected error (type=Not Found, status=404).</div><div>Not Found</div></body></html>")
                .build();
        } else {
            // Special case for PROVIDER domain ...
            return Response.ok(callObject).build();
        }
    }

    @Override
    public Response create( @PathParam( "networkId" ) String networkId, CallObject entity ) {

        if ( entity.getId() != null || entity.getName() == null ) {

            return Response.status( Response.Status.BAD_REQUEST ).build();
        }

        boolean badRequest = false;

        if ( entity == null || entity.getName() == null || entity.getId() != null ) {

            badRequest = true;
        }
        else {

            badRequest =
                callObjects.values().stream()
                    .filter( item -> item.getName().equals( entity.getName() ) )
                    .count() > 0;
        }

        if ( badRequest ) {

            return Response.status( Response.Status.BAD_REQUEST )
                // Added html content to simulate current SDN (wrong) behavior
                .build();
        }

        long nextId = callObjects.values()
            .stream().max( callObjectComparator )
            .map( item -> Long.parseLong( extractId( item.getId() ) ) + 1L )
            .orElse( 1L );

        CallObject created = new CallObject();

        try {

            BeanUtils.copyProperties( created, entity );
        }
        catch ( ReflectiveOperationException e ) {

            e.printStackTrace();

            return Response.status( Response.Status.INTERNAL_SERVER_ERROR ).build();
        }

        created.setDomainId( null );
        created.setId( urify( networkId, String.valueOf( nextId ) ) );

        callObjects.put( urify( networkId, created.getId() ), created );

        debug( "CREATE CALL|Total Calls: " + callObjects.values().size() );

        return Response.ok( created )
            .build();
    }

    @Override
    public Response update( @PathParam( "networkId" ) String networkId, @PathParam( "id" ) String id, CallObject entity ) {

        CallObject callObject = callObjects.get( urify( networkId, id ) );

        if ( callObject == null ) {

            return Response.status( Response.Status.NOT_FOUND )
                // Added html content to simulate current SDN (wrong) behavior
                .entity( "<html><body><h1>Whitelabel Error Page</h1><p>This application has no explicit mapping for /error, so you are seeing this as a fallback.</p><div id='created'>Mon Oct 24 19:27:31 WEST 2016</div><div>There was an unexpected error (type=Not Found, status=404).</div><div>Not Found</div></body></html>" )
                .build();
        }
        else {

            if ( entity.getName() == null ) {

                return Response.status( Response.Status.BAD_REQUEST ).build();
            }

            callObjects.put( urify( networkId, id ), entity );

            return Response.ok( entity ).build();
        }
    }

    @Override
    public Response delete( @PathParam( "networkId" ) String networkId, @PathParam( "id" ) String id ) {

        CallObject callObject = callObjects.get( urify( networkId, id ) );

        if ( callObject == null ) {

            return Response.status( Response.Status.NOT_FOUND )
                // Added html content to simulate current SDN (wrong) behavior
                .entity( "<html><body><h1>Whitelabel Error Page</h1><p>This application has no explicit mapping for /error, so you are seeing this as a fallback.</p><div id='created'>Mon Oct 24 19:27:31 WEST 2016</div><div>There was an unexpected error (type=Not Found, status=404).</div><div>Not Found</div></body></html>" )
                .build();
        }
        else {

            callObjects.remove( urify( networkId, id ) );

            return Response.ok().build();
        }
    }


    /**
     * @param id
     * @return
     */
    private static String urify( String domainId, String id ) {

        return buildUri( domainId, id, "call" );
    }

    /**
     *
     * @param msg
     */
    private void debug( String msg ) {

        LOGGER.debug( "OIF Mock|{}", msg );
    }


    @Override
    public Response enforce(@PathParam("networkId") String networkId, @PathParam("id") String id) {

        CallObject callObject = callObjects.get(urify(networkId, id));
        if (callObject == null) {
            return Response.status(Response.Status.NOT_FOUND)
                // Added html content to simulate current SDN (wrong) behavior
                .entity("<html><body><h1>Whitelabel Error Page</h1><p>This application has no explicit mapping for /error, so you are seeing this as a fallback.</p><div id='created'>Mon Oct 24 19:27:31 WEST 2016</div><div>There was an unexpected error (type=Not Found, status=404).</div><div>Not Found</div></body></html>")
                .build();
        } else {
            // Special case for PROVIDER domain ...
            return Response.ok(new EnforceResponseObject()).build();
        }


    }
}