package com.ossnms.web.api.oif.proxy.arquillian;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ossnms.web.api.oif.proxy.api.client.common.CommonWorker;
import com.ossnms.web.api.oif.proxy.api.client.end.EndNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.end.EndObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import java.io.File;
import java.io.IOException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import static com.ossnms.web.api.oif.proxy.api.common.util.SdnUtils.buildUri;
import static com.ossnms.web.api.oif.proxy.api.common.util.SdnUtils.extractId;

/**
 *
 */
public class EndMockService implements EndNDMClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(EndMockService.class);

    private static Map<String, EndObject> endObjects = new HashMap<>();

    private static Comparator<EndObject> endObjectComparator = Comparator.comparingLong(e -> Long.parseLong(extractId(e.getId())));

    public EndMockService() {
        createEndObjects();
    }

    private void createEndObjects() {

        ObjectMapper objectMapper = new ObjectMapper();

        JsonFactory f = new JsonFactory();
        JsonParser jp = null;

        try {
            jp = f.createParser(new File("src/test/resources/jsonData/ends.json"));
            // advance stream to START_ARRAY first:
            jp.nextToken();
            // and then each time, advance to opening START_OBJECT
            while (jp.nextToken() == JsonToken.START_OBJECT){
                EndObject endObject = objectMapper.readValue(jp, EndObject.class);

                String domainId = CommonWorker.toDomainId(endObject.getId());
                String id = CommonWorker.toId(endObject.getId());
                String topologyId = CommonWorker.toTopologyId(endObject.getId());
                String vertexId = CommonWorker.toVertexId(endObject.getId());

                endObjects.put(urify(domainId,topologyId,vertexId,id) , endObject);
            }
        } catch (IOException e) {
            LOGGER.error(e.toString());
        }
    }


    @Override
    public Response getAll(@PathParam("networkId") String networkId, @PathParam("topologyId") String topologyId, @PathParam("vertexId") String vertexId, @QueryParam("name") String filterByName) {
        return null;
    }

    @Override
    public Response get(@PathParam("networkId") String networkId, @PathParam("topologyId") String topologyId, @PathParam("vertexId") String vertexId, @PathParam("id") String id) {

        EndObject endObject = endObjects.get(urify(networkId, topologyId,vertexId,id));
        if (endObject == null) {
            return Response.status(Response.Status.NOT_FOUND)
                // Added html content to simulate current SDN (wrong) behavior
                .entity("<html><body><h1>Whitelabel Error Page</h1><p>This application has no explicit mapping for /error, so you are seeing this as a fallback.</p><div id='created'>Mon Oct 24 19:27:31 WEST 2016</div><div>There was an unexpected error (type=Not Found, status=404).</div><div>Not Found</div></body></html>")
                .build();
        } else {
            // Special case for PROVIDER domain ...
            return Response.ok(endObject).build();
        }
    }

    @Override
    public Response create(@PathParam("networkId") String networkId, @PathParam("topologyId") String topologyId, @PathParam("vertexId") String vertexId, EndObject endObject) {
        return null;
    }

    @Override
    public Response update(@PathParam("networkId") String networkId, @PathParam("topologyId") String topologyId, @PathParam("vertexId") String vertexId, @PathParam("id") String id, EndObject endObject) {
        return null;
    }

    @Override
    public Response delete(@PathParam("networkId") String networkId, @PathParam("topologyId") String topologyId, @PathParam("vertexId") String vertexId, @PathParam("id") String id) {
        return null;
    }

    /**
     * @param id
     * @return
     */
    private static String urify(String domainId, String topologyId, String vertexId, String id) {
        return buildUri(domainId, topologyId, vertexId, id, "end");
    }
}
