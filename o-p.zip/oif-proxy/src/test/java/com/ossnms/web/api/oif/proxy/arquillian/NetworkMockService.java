package com.ossnms.web.api.oif.proxy.arquillian;

import com.ossnms.web.api.oif.proxy.api.client.network.NetworkNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.network.NetworkObject;
import com.ossnms.web.api.oif.proxy.api.client.network.NetworkObjectList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.ossnms.web.api.oif.proxy.api.common.util.SdnUtils.buildUri;
import static com.ossnms.web.api.oif.proxy.api.common.util.SdnUtils.extractId;


/**
 *
 */
public class NetworkMockService implements NetworkNDMClient {

    private static final Logger LOGGER = LoggerFactory.getLogger( NetworkMockService.class );

    private static Map<String, NetworkObject> networkObjects = new HashMap<>();

    private static Comparator<NetworkObject> networkObjectComparator = Comparator.comparingInt(e -> Integer.parseInt(extractId(e.id)));

    @Override
    public Response getAll( @QueryParam( "name" ) String filterByName ) {
        NetworkObjectList list = new NetworkObjectList();

        LOGGER.debug("FILTER BY NAME - {}", filterByName);

        list.id = networkObjects.values()
            .stream()
            .sorted( networkObjectComparator )
            .filter( item -> filterByName == null || filterByName.isEmpty() || filterByName.equals( item.name ) )
            .map( item -> item.id )
            .collect( Collectors.toList() )
            .toArray( new String[]{} );

        int totalFiltered = list.id.length;

        return Response.ok( totalFiltered == 0 ? null : list )
                .header( "Content-range", ( totalFiltered == 0 ? "0-0/0" : "0-" + (totalFiltered-1) + "/" + totalFiltered ) )
                .build();
    }

    @Override
    public Response get( @PathParam( "id" ) String id ) {
        NetworkObject networkObject = networkObjects.get( urify( id ) );
        if ( networkObject == null ) {
            return Response.status( Response.Status.NOT_FOUND )
                    // Added html content to simulate current SDN (wrong) behavior
                    .entity( "<html><body><h1>Whitelabel Error Page</h1><p>This application has no explicit mapping for /error, so you are seeing this as a fallback.</p><div id='created'>Mon Oct 24 19:27:31 WEST 2016</div><div>There was an unexpected error (type=Not Found, status=404).</div><div>Not Found</div></body></html>" )
                    .build();
        } else {
            // Special case for PROVIDER domain ...
            if ( "1".equals( extractId( id ) ) ) {
                networkObject.name = null;
                networkObject.topologyType = null;
                networkObject.secure = null;
                networkObject.userDomain = null;
            }

            return Response.ok( networkObject ).build();
        }
    }

    @Override
    public Response create( NetworkObject entity ) {
        boolean badRequest = false;
        if ( entity == null || entity.name == null || entity.id != null || entity.userDomain != null ) {
            badRequest = true;
        } else {
            boolean domainAlreadyExistsWithSameName =
                networkObjects.values().stream()
                    .filter( item -> item.name.equals( entity.name ) )
                    .count() > 0;

            if ( domainAlreadyExistsWithSameName ) {
                badRequest = true;
            }
        }

        if ( badRequest ) {
            return Response.status( Response.Status.BAD_REQUEST )
                    // Added html content to simulate current SDN (wrong) behavior
                    .entity( "<html><body><h1>Whitelabel Error Page</h1><p>This application has no explicit mapping for /error, so you are seeing this as a fallback.</p><div id='created'>Mon Oct 24 19:27:31 WEST 2016</div><div>There was an unexpected error (type=Not Found, status=404).</div><div>Not Found</div></body></html>" )
                    .build();
        }

        Optional<NetworkObject> maxFromMock = networkObjects.values()
            .stream().max(networkObjectComparator);

        int nextId = 1;

        if ( maxFromMock.isPresent() ) {
            nextId = Integer.parseInt( extractId( maxFromMock.get().id ) ) + 1;
        }

        NetworkObject created = new NetworkObject( entity );

        created.id = urify( String.valueOf( nextId ) );
        created.userDomain = buildUri( created.id );
        created.secure = Boolean.TRUE;

        networkObjects.put( created.id, created );

        debug( "CREATE DOMAIN|Total Domains: " + networkObjects.values().size() );

        return Response.status( Response.Status.CREATED )
                .entity( created )
                .build();
    }

    @Override
    public Response update( @PathParam( "id" ) String uri, NetworkObject entity ) {
        NetworkObject networkObject = networkObjects.get( urify( uri ) );

        if ( networkObject == null ) {
            return Response.status( Response.Status.NOT_FOUND )
                    // Added html content to simulate current SDN (wrong) behavior
                    .entity( "<html><body><h1>Whitelabel Error Page</h1><p>This application has no explicit mapping for /error, so you are seeing this as a fallback.</p><div id='created'>Mon Oct 24 19:27:31 WEST 2016</div><div>There was an unexpected error (type=Not Found, status=404).</div><div>Not Found</div></body></html>" )
                    .build();
        } else {
            if ( entity.id != null || entity.userDomain != null || entity.topologyType != null || entity.secure != null ) {
                return Response.status( Response.Status.BAD_REQUEST )
                        // Added html content to simulate current SDN (wrong) behavior
                        .entity( "<html><body><h1>Whitelabel Error Page</h1><p>This application has no explicit mapping for /error, so you are seeing this as a fallback.</p><div id='created'>Mon Oct 24 19:27:31 WEST 2016</div><div>There was an unexpected error (type=Not Found, status=404).</div><div>Not Found</div></body></html>" )
                        .build();
            } else {
                NetworkObject updated = new NetworkObject( networkObject );

                if ( entity.name != null ) {
                    updated.name = entity.name;
                }

                if ( entity.protocols != null ) {
                    updated.protocols = entity.protocols;
                }

                networkObjects.put( updated.id, updated );

                return Response.ok( networkObject )
                        .entity( updated )
                        .build();
            }
        }
    }

    @Override
    public Response delete( String id ) {
        NetworkObject networkObject = networkObjects.get( urify( id ) );
        if ( networkObject == null ) {
            return Response.status( Response.Status.NOT_FOUND )
                    // Added html content to simulate current SDN (wrong) behavior
                    .entity( "<html><body><h1>Whitelabel Error Page</h1><p>This application has no explicit mapping for /error, so you are seeing this as a fallback.</p><div id='created'>Mon Oct 24 19:27:31 WEST 2016</div><div>There was an unexpected error (type=Not Found, status=404).</div><div>Not Found</div></body></html>" )
                    .build();
        } else {
            networkObjects.remove( urify( id ) );
            return Response.status( Response.Status.NO_CONTENT ).build();
        }
    }

    /**
     * We'll use this to reset the data structure
     */
    public void reset() {
        networkObjects.clear();
    }


    /**
     *
     * @param id
     * @return
     */
    private static String urify( String id ) {
        return buildUri( id );
    }

    /**
     *
     * @param msg
     */
    private void debug( String msg ) {
        LOGGER.debug( "OIF Mock|{}", msg );
    }
}