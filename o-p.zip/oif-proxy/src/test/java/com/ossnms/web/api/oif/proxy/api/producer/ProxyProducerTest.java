package com.ossnms.web.api.oif.proxy.api.producer;

import com.ossnms.web.api.oif.proxy.api.client.connection.ConnectionNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.srg.SrgNDMCLient;
import com.ossnms.web.api.oif.proxy.arquillian.ArquillianTestBase;
import com.ossnms.web.provider.sdn.api.annotation.Proxy;
import org.jboss.arquillian.junit.Arquillian;
import org.junit.Test;
import org.junit.runner.RunWith;

import javax.inject.Inject;
import javax.ws.rs.core.Response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 *
 */
@RunWith(Arquillian.class)
public class ProxyProducerTest extends ArquillianTestBase {

    @Inject
    @Proxy
    SrgNDMCLient client;

    @Test
    public void shouldReturnEmptyImplementationProxy() {
        Response response = client.get("1", "1");
        assertEquals(503, response.getStatus());
    }
}
