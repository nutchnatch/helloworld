package com.ossnms.web.api.oif.proxy.impl.vertex;

import com.ossnms.web.api.oif.proxy.arquillian.ArquillianTestBase;
import com.ossnms.web.provider.sdn.operations.vertex.VertexEntityOperations;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.arquillian.junit.InSequence;
import org.junit.Test;
import org.junit.runner.RunWith;

import javax.inject.Inject;

import static org.junit.Assert.assertNotNull;

/**
 *
 */
@RunWith( Arquillian.class )
public class VertexOperationsProxyImplTest extends ArquillianTestBase {

    @Inject
    private VertexEntityOperations vertexOperations;

    @Test
    @InSequence( 1 )
    public void shouldNotBeNull() {
        assertNotNull( vertexOperations );
    }

}
