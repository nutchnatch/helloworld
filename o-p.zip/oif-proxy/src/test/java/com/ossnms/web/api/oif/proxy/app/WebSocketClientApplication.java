package com.ossnms.web.api.oif.proxy.app;

import com.ossnms.web.api.oif.proxy.notification.WebSocketClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;

/**
 *
 */
public class WebSocketClientApplication {

    private static final Logger LOGGER = LoggerFactory.getLogger(WebSocketClientApplication.class);

    /**
     *
     * @param args
     */
    public static void main(String[] args) {

        // initiate the websocket client
        WebSocketClient client = new WebSocketClient()
            .setSecure(true)
            .setHostname("vmtnmsft289.dci.co-int.net")
            .setPort("9443")
            .setEndpoint("/sdn/com.oiforum.json/ndm/network/1/notifications")
            .setAuthorization("Bearer eyJhbGciOiJIUzUxMiJ9.eyJpYXQiOjE0ODEzMDA4MjMsImp0aSI6IjQ1Iiwic3ViIjoiQWRtaW5pc3RyYXRvciIsImlzcyI6Im9zc25tcy5zZWN1cml0eU1hbmFnZXIiLCJzZWNUb2tlbiI6InJPMEFCWE55QUVCamIyMHViM056Ym0xekxtSnBZMjVsZEM1aVkySXVabUZqWVdSbExuTmxZM1Z5YVhSNUxrVnVhR0Z1WTJWa1UyVnpjMmx2YmtOdmJuUmxlSFJKZEdWdFByd3gzYUliNVhvQ0FBWktBQVoxYm1seFNXUk1BQTlqYkdsbGJuUkpjRUZrWkhKbGMzTjBBQkpNYW1GMllTOXNZVzVuTDFOMGNtbHVaenRNQUJGamJHbGxiblJOWVdOb2FXNWxUbUZ0WlhFQWZnQUJUQUFLYzJWeWRtVnlUbUZ0WlhFQWZnQUJUQUFKZFhObGNrZHliM1Z3ZEFBUVRHcGhkbUV2ZFhScGJDOU1hWE4wTzB3QUNIVnpaWEpPWVcxbGNRQitBQUY0Y0FBQUFBQUFBQUF0ZEFBWVYyVmlMVU5zYVdWdWRFQXhNQzR4TXpBdU1UZ3VNVGt6Y1FCK0FBUjBBQXQyYlhSdWJYTm1kREk0T1hOeUFCTnFZWFpoTG5WMGFXd3VRWEp5WVhsTWFYTjBlSUhTSFpuSFlaMERBQUZKQUFSemFYcGxlSEFBQUFBQmR3UUFBQUFCZEFBT1FXUnRhVzVwYzNSeVlYUnZjbk40ZEFBTlFXUnRhVzVwYzNSeVlYUnZjZz09IiwiZXhwIjoxNDgxMzE1MjIzfQ.RyW8eogEsWg1odxD8u0qTec3CuqjS9hX4SllbJi5W9-iK4QMDTMQuY581LYLwhZYqlY7v1EX4ed22YxL6tVfZQ")
            .initiate();

        // keep it opened for some time
        long now = new Date().getTime();
        LOGGER.info(">>>>>     RUNNING");
        while(now + 20000 > new Date().getTime() && client.isActive()) {
        }

        client.shutdown();
    }
}
