package com.ossnms.web.api.oif.proxy.app.end;

import com.ossnms.web.api.oif.proxy.api.client.common.AuthorizationHeaderFilter;
import com.ossnms.web.api.oif.proxy.api.client.end.EndNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.end.EndObject;
import com.ossnms.web.api.oif.proxy.api.client.end.EndObjectList;
import com.ossnms.web.api.oif.proxy.api.client.end.EndWorker;
import com.ossnms.web.api.oif.proxy.api.common.result.GenericErrorCode;
import com.ossnms.web.api.oif.proxy.api.producer.ProxyProducer;
import com.ossnms.web.provider.common.api.result.ProcessableSingleResult;

import javax.ws.rs.core.Response;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 */
public class OIFEndClientApplication {

    private static final String URL = "https://ptlisvlsdn009.dci.co-int.net:8443";
    private static final AuthorizationHeaderFilter AUTH_FILTER = new AuthorizationHeaderFilter( "Administrator", "123QWEasd" );

    private static final String DOMAIN_ID = "1";
    private static final String TOPOLOGY_ID = "1";
    private static final String VERTEX_ID = "7";


    /**
     * @param args
     */
    public static void main( String[] args ) {

        EndNDMClient proxy = ProxyProducer.getProxy(
            EndNDMClient.class,
            URL,
            AUTH_FILTER
        );

        Response response = proxy.getAll(DOMAIN_ID, TOPOLOGY_ID, VERTEX_ID, null);
        EndObjectList endList = response.readEntity(EndObjectList.class);

        assert endList != null;

        List<ProcessableSingleResult<EndObject, GenericErrorCode>> collect = endList.getEnds()
            .stream()
            .map(EndWorker.fromURIFunction(proxy))
            .collect(Collectors.toList());

        System.out.println("Obtained " + collect.size() + " END objects" );
    }

}
