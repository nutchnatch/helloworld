package com.ossnms.web.api.oif.proxy.app.vertex;

import com.ossnms.web.api.oif.proxy.api.client.common.AuthorizationHeaderFilter;
import com.ossnms.web.api.oif.proxy.api.client.vertex.VertexNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.vertex.VertexObject;
import com.ossnms.web.api.oif.proxy.api.client.vertex.VertexObjectList;
import com.ossnms.web.api.oif.proxy.api.client.vertex.VertexWorker;
import com.ossnms.web.api.oif.proxy.api.common.result.GenericErrorCode;
import com.ossnms.web.api.oif.proxy.api.producer.ProxyProducer;
import com.ossnms.web.provider.common.api.result.ProcessableSingleResult;

import javax.ws.rs.core.Response;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 */
public class OIFVertexClientApplication {

    private static final String URL = "https://ptlisvlsdn009.dci.co-int.net:8443";
    private static final AuthorizationHeaderFilter AUTH_FILTER = new AuthorizationHeaderFilter( "Administrator", "123QWEasd" );

    private static final String NETWORK_ID = "*";
    private static final String NETWORK_ID_PROVIDER = "1";

    private static final String TOPOLOGY_ID_PROVIDER = "1";

    /**
     * @param args
     */
    public static void main( String[] args ) {

        VertexNDMClient proxy = ProxyProducer.getProxy(
            VertexNDMClient.class,
            URL,
            AUTH_FILTER
        );

        Response response = proxy.getAll(NETWORK_ID_PROVIDER, TOPOLOGY_ID_PROVIDER);
        VertexObjectList vertexObjectList = response.readEntity(VertexObjectList.class);

        assert vertexObjectList != null;

        List<ProcessableSingleResult<VertexObject, GenericErrorCode>> objectCollection = vertexObjectList.getVertexes()
            .stream()
            .map(VertexWorker.fromURIFunction(proxy))
            .collect(Collectors.toList());

        System.out.println(objectCollection.size());
    }
}
