package com.ossnms.web.api.oif.proxy.impl.connection;

import com.ossnms.web.api.oif.proxy.api.client.common.AuthorizationHeaderFilter;
import com.ossnms.web.api.oif.proxy.api.client.connection.ConnectionNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.connection.ConnectionObjectList;
import com.ossnms.web.api.oif.proxy.api.producer.ProxyProducer;
import com.ossnms.web.api.oif.proxy.arquillian.ArquillianTestBase;
import org.jboss.arquillian.junit.Arquillian;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;

import javax.ws.rs.core.Response;

/**
 *
 */
@Ignore
@RunWith( Arquillian.class )
public class ConnectionProxyImplTest extends ArquillianTestBase {

    private static final String URL = "https://ptlisvlsdn009.dci.co-int.net:8443";
    private static final AuthorizationHeaderFilter AUTH_FILTER = new AuthorizationHeaderFilter( "Administrator", "123QWEasd" );

    private ConnectionNDMClient connectionNDMClient;

    @Before
    public void beforeTest() {
        connectionNDMClient = ProxyProducer.getProxy(
            ConnectionNDMClient.class,
            URL,
            AUTH_FILTER
        );
    }

    @Test
    public void shouldTestConnectionClient() {
        Response response = connectionNDMClient.getAll("*", null);
        ConnectionObjectList connectionObjectList = response.readEntity(ConnectionObjectList.class);

        assert connectionObjectList != null;
    }

}
