package com.ossnms.web.api.oif.proxy.impl.call;

import com.ossnms.web.api.oif.proxy.arquillian.ArquillianTestBase;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.filter.FilterOperation;
import com.ossnms.web.provider.common.api.result.ProcessableResult;
import com.ossnms.web.provider.common.api.result.ProcessableSingleResult;
import com.ossnms.web.provider.common.api.result.enumerable.Status;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.sdn.model.call.Call;
import com.ossnms.web.provider.sdn.model.call.CallField;
import com.ossnms.web.provider.sdn.model.call.CallID;
import com.ossnms.web.provider.sdn.model.call.CallSummary;
import com.ossnms.web.provider.sdn.model.call.SLA;
import com.ossnms.web.provider.sdn.model.common.enumerable.ErrorCode;
import com.ossnms.web.provider.sdn.operations.call.ProcessableCallEntityOperations;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.arquillian.junit.InSequence;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

/**
 *
 *
 */
@RunWith(Arquillian.class)
public class CallOperationsProxyImplTest extends ArquillianTestBase {

    private final static Logger LOGGER = LoggerFactory.getLogger(CallOperationsProxyImplTest.class);

    private static final String CALL_DOMAIN_ID = "1";
    private static final String CALL_ID = "493768843925104";
    private static final String CALL_NAME = "cuteName!";


    @Inject
    private ProcessableCallEntityOperations callOperations;

    private static final SecurityToken secToken = new SecurityToken.Builder("username", "passw" /*"myCuteBearerToken!"*/).build();

    @Test
    @InSequence(1)
    public void shouldNotBeNull() {
        assertNotNull(callOperations);
    }

    @Test
    @InSequence(2)
    public void shouldGetNoneAtAll() {
        Filter<CallField> nameFilter = new Filter.Builder<>(CallField.NAME, FilterOperation.EQUALS, "bogusValue").build();

        ProcessableResult<Call, CallField, ErrorCode> calls = callOperations.getAll(secToken, Collections.singletonList(nameFilter), null, null);
        assertEquals(0, calls.getTotalElements());
        assertTrue(calls.getResultCollection().isEmpty());
    }

    @Test
    @InSequence(3)
    public void shouldNotGetDetailsById() {
        ProcessableSingleResult<Call, ErrorCode> call = callOperations.getDetails(secToken, new CallID.Builder(CALL_DOMAIN_ID, CALL_ID).build());
        assertNotNull(call);
        assertNotNull(call.getEntity());

        assertEquals(call.getEntity().getID().getDomainId(), CALL_DOMAIN_ID);
        assertEquals(call.getEntity().getID().getID(), CALL_ID);
    }

    @Test
    @InSequence(4)
    public void shouldGetAll() {
        ProcessableResult<Call, CallField, ErrorCode> all = callOperations.getAll(secToken, null, null, null);

        assertNotNull(all);
        assertFalse(all.getResultCollection().isEmpty());

        all = callOperations.getAll(secToken, Collections.emptyList());

        assertNotNull(all);
        assertFalse(all.getResultCollection().isEmpty());
    }


    @Test
    @InSequence(5)
    public void shouldGetAllSummary() {

        ProcessableResult<CallSummary, CallField, ErrorCode> allSummary = callOperations.getAllSummary(secToken, null, null, null);

        assertNotNull(allSummary);
        assertFalse(allSummary.getResultCollection().isEmpty());

        allSummary = callOperations.getAllSummary(secToken, Collections.emptyList());

        assertNotNull(allSummary);
        assertFalse(allSummary.getResultCollection().isEmpty());
    }

    @Test
    @InSequence(6)
    public void shouldGetSummaryById() {

        ProcessableResult<CallSummary, CallField, ErrorCode> allSummary = callOperations.getAllSummary(secToken, Collections.singletonList(new CallID.Builder(CALL_DOMAIN_ID, CALL_ID).build()));

        assertNotNull(allSummary);
        assertFalse(allSummary.getResultCollection().isEmpty());
    }


    @Test
    @InSequence(7)
    public void shouldnotGetSummaryById() {

        ProcessableSingleResult<CallSummary, ErrorCode> summary = callOperations.getSummary(secToken, new CallID.Builder(CALL_DOMAIN_ID, CALL_ID).build());

        assertNotNull(summary);
        assertNotNull(summary.getEntity());
    }

    @Test
    @InSequence(8)
    public void shouldNotGetSummaryById() {

        ProcessableSingleResult<CallSummary, ErrorCode> summary = callOperations.getSummary(secToken, null);

        assertNotNull(summary);
        assertNull(summary.getEntity());
    }


    @Test
    @InSequence(9)
    public void shouldNotUpdate() {

        Call.Builder b =
            new Call.Builder(new CallID.Builder("999", "999").build());

        b.setName(CALL_NAME);

        ProcessableSingleResult<Call, ErrorCode> updateResponse = callOperations.update(secToken, b.build());

        assertNotNull(updateResponse);
        assertNull(updateResponse.getEntity());
        assertEquals(Status.NOT_FOUND, updateResponse.getOperationStatus());
    }


    @Test
    @InSequence(10)
    public void shouldUpdate() {

        CallID callId = new CallID.Builder(CALL_DOMAIN_ID, CALL_ID).build();
        Call.Builder b = new Call.Builder(callId);

        b.setName(CALL_NAME);

        b.setAdminStatus("true");
        b.setCallConfigStatus("true");
        b.setSla(new SLA.Builder().setSLAMonitoring(true).build());
        b.setRestorable(false);

        ProcessableSingleResult<Call, ErrorCode> updateResponse = callOperations.update(secToken, b.build());

        assertNotNull(updateResponse);
        assertNotNull(updateResponse.getEntity());
        assertEquals(Status.OK, updateResponse.getOperationStatus());
        assertEquals(CALL_DOMAIN_ID, updateResponse.getEntity().getID().getDomainId());
        assertEquals(CALL_ID, updateResponse.getEntity().getID().getID());
        assertEquals(CALL_NAME, updateResponse.getEntity().getName());

    }


    @Test
    @InSequence(11)
    public void shouldNotDelete() {

        ProcessableSingleResult<CallID, ErrorCode> deleteResponse = callOperations.delete(secToken, null);

        assertNotNull(deleteResponse);
        assertNull(deleteResponse.getEntity());
        assertEquals(Status.BAD_REQUEST, deleteResponse.getOperationStatus());

        deleteResponse = callOperations.delete(secToken, new CallID.Builder("999", "999").build());

        assertNotNull(deleteResponse);
        assertNull(deleteResponse.getEntity());
        assertEquals(Status.NOT_FOUND, deleteResponse.getOperationStatus());
    }

    @Test
    @InSequence(12)
    public void shouldDelete() {

        CallID callId = new CallID.Builder(CALL_DOMAIN_ID, CALL_ID).build();

        ProcessableSingleResult<CallID, ErrorCode> deleteResponse = callOperations.delete(secToken, callId);

        assertNotNull(deleteResponse);
        assertNotNull(deleteResponse.getEntity());
        assertEquals(callId, deleteResponse.getEntity());
        assertEquals(Status.OK, deleteResponse.getOperationStatus());
    }


    @Test
    @InSequence(13)
    public void shouldNotCreate() {

        ProcessableSingleResult<Call, ErrorCode> insertResponse = callOperations.insert(secToken, null);

        assertNotNull(insertResponse);
        assertNull(insertResponse.getEntity());
        assertEquals(Status.BAD_REQUEST, insertResponse.getOperationStatus());

        Call.Builder b =
            new Call.Builder(null);

        b.setName("ANewServiceNotToBeCreated");

        insertResponse = callOperations.insert(secToken, b.build());

        assertNotNull(insertResponse);
        assertNull(insertResponse.getEntity());
        assertEquals(Status.BAD_REQUEST, insertResponse.getOperationStatus());

        b = new Call.Builder(new CallID.Builder(null, "123").build());

        insertResponse = callOperations.insert(secToken, b.build());

        assertNotNull(insertResponse);
        assertNull(insertResponse.getEntity());
        assertEquals(Status.BAD_REQUEST, insertResponse.getOperationStatus());

        b = new Call.Builder(new CallID.Builder("123", "123").build());

        insertResponse = callOperations.insert(secToken, b.build());

        assertNotNull(insertResponse);
        assertNull(insertResponse.getEntity());
        assertEquals(Status.BAD_REQUEST, insertResponse.getOperationStatus());
    }


    @Test
    @InSequence(14)
    public void shouldCreate() {

        CallID callID = new CallID.Builder("456", null).build();
        Call.Builder b = new Call.Builder(callID);

        b.setName("ANewServiceNotToBeCreated");

        ProcessableSingleResult<Call, ErrorCode> insertResponse = callOperations.insert(secToken, b.build());

        assertNotNull(insertResponse);
        assertNotNull(insertResponse.getEntity());
        assertEquals(Status.OK, insertResponse.getOperationStatus());
        assertEquals(callID.getDomainId(), insertResponse.getEntity().getID().getDomainId());
        assertNotNull(insertResponse.getEntity().getID());
        assertEquals(b.build().getName(), insertResponse.getEntity().getName());
    }

    @Test
    @InSequence(15)
    public void shouldEnforce() {

        CallID callID = new CallID.Builder("1", "493768843925104").build();

        ProcessableSingleResult<CallID, ErrorCode> enforceResponse = callOperations.enforce(secToken, callID);

        assertNotNull(enforceResponse);
        assertNotNull(enforceResponse.getEntity());
        assertEquals(Status.OK, enforceResponse.getOperationStatus());
        assertNotNull(enforceResponse.getEntity().getID());

    }


    @Test
    @InSequence(16)
    public void shouldNotEnforce() {

        CallID callID = new CallID.Builder("11111", "1111").build();

        ProcessableSingleResult<CallID, ErrorCode> enforceResponse = callOperations.enforce(secToken, callID);

        assertNotNull(enforceResponse);
        assertEquals(Status.NOT_FOUND, enforceResponse.getOperationStatus());

    }
}