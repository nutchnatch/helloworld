package com.ossnms.web.api.oif.proxy.arquillian;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ossnms.web.api.oif.proxy.api.client.common.CommonWorker;
import com.ossnms.web.api.oif.proxy.api.client.endpoint.EndpointNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.endpoint.EndpointObject;
import com.ossnms.web.api.oif.proxy.api.client.endpoint.EndpointObjectList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import java.io.File;
import java.io.IOException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import static com.ossnms.web.api.oif.proxy.api.common.util.SdnUtils.buildUri;
import static com.ossnms.web.api.oif.proxy.api.common.util.SdnUtils.extractId;

/**
 *
 */
public class EndpointMockService implements EndpointNDMClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(CallMockService.class);

    private static Map<String, EndpointObject> endpointObjects = new HashMap<>();

    private static Comparator<EndpointObject> endpointObjectComparator = Comparator.comparingLong(e -> Long.parseLong(extractId(e.getId())));

    public EndpointMockService() {
        createEndpointObjects();
    }

    private void createEndpointObjects() {

        ObjectMapper objectMapper = new ObjectMapper();

        JsonFactory f = new JsonFactory();
        JsonParser jp = null;

        try {
            jp = f.createParser(new File("src/test/resources/jsonData/endpoints.json"));
            // advance stream to START_ARRAY first:
            jp.nextToken();
            // and then each time, advance to opening START_OBJECT
            while (jp.nextToken() == JsonToken.START_OBJECT){
                EndpointObject endpointObject = objectMapper.readValue(jp, EndpointObject.class);
                endpointObjects.put(urify(CommonWorker.toDomainId(endpointObject.getId()), extractId(endpointObject.getId())), endpointObject);
            }
        } catch (IOException e) {
            LOGGER.error(e.toString());
        }
    }


    @Override
    public Response getAll(@PathParam("networkId") String networkId, @QueryParam("name") String filterByName) {
        EndpointObjectList list = new EndpointObjectList();

        LOGGER.debug("FILTER BY NAME - {}", filterByName);

        list.setEndpoints(endpointObjects.values()
            .stream()
            .sorted(endpointObjectComparator)
            .filter(item -> filterByName == null || filterByName.isEmpty() || filterByName.equals(item.getName()))
            .map(item -> item.getName())
            .collect(Collectors.toList()));

        int totalFiltered = list.getEndpoints().size();

        return Response.ok(totalFiltered == 0 ? null : list)
            .header("Content-range", (totalFiltered == 0 ? "0-0/0" : "0-" + (totalFiltered - 1) + "/" + totalFiltered))
            .build();
    }

    @Override
    public Response get(@PathParam("networkId") String networkId, @PathParam("id") String id) {

        EndpointObject endpointObject = endpointObjects.get(urify( networkId , id));
        if (endpointObject == null) {
            return Response.status(Response.Status.NOT_FOUND)
                // Added html content to simulate current SDN (wrong) behavior
                .entity("<html><body><h1>Whitelabel Error Page</h1><p>This application has no explicit mapping for /error, so you are seeing this as a fallback.</p><div id='created'>Mon Oct 24 19:27:31 WEST 2016</div><div>There was an unexpected error (type=Not Found, status=404).</div><div>Not Found</div></body></html>")
                .build();
        } else {
            // Special case for PROVIDER domain ...
            return Response.ok(endpointObject).build();
        }
    }

    @Override
    public Response create(@PathParam("networkId") String networkId, EndpointObject entity) {
        return null;
    }

    @Override
    public Response update(@PathParam("networkId") String networkId, @PathParam("id") String id, EndpointObject entity) {
        return null;
    }

    @Override
    public Response delete(@PathParam("networkId") String networkId, @PathParam("id") String id) {
        return null;
    }

    /**
     * @param id
     * @return
     */
    private static String urify(String domainId, String id) {
        return buildUri(domainId, id, "endpoint");
    }
}
