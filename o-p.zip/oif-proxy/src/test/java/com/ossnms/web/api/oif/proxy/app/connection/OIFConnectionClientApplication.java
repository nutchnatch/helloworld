package com.ossnms.web.api.oif.proxy.app.connection;

import com.ossnms.web.api.oif.proxy.api.client.common.AuthorizationHeaderFilter;
import com.ossnms.web.api.oif.proxy.api.client.connection.ConnectionNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.connection.ConnectionObject;
import com.ossnms.web.api.oif.proxy.api.client.connection.ConnectionObjectList;
import com.ossnms.web.api.oif.proxy.api.client.connection.ConnectionWorker;
import com.ossnms.web.api.oif.proxy.api.common.result.GenericErrorCode;
import com.ossnms.web.api.oif.proxy.api.producer.ProxyProducer;
import com.ossnms.web.provider.common.api.result.ProcessableSingleResult;

import javax.ws.rs.core.Response;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 */
public class OIFConnectionClientApplication {

    private static final String URL = "https://ptlisvlsdn009.dci.co-int.net:8443";
    private static final AuthorizationHeaderFilter AUTH_FILTER = new AuthorizationHeaderFilter( "Administrator", "123QWEasd" );

    private static final String NETWORK_ID = "*";
    private static final String NETWORK_ID_PROVIDER = "1";

    /**
     * @param args
     */
    public static void main( String[] args ) {

        ConnectionNDMClient proxy = ProxyProducer.getProxy(
            ConnectionNDMClient.class,
            URL,
            AUTH_FILTER
        );

        Response response = proxy.getAll(NETWORK_ID, null);
        ConnectionObjectList connectionObjectList = response.readEntity(ConnectionObjectList.class);

        assert connectionObjectList != null;

        List<ProcessableSingleResult<ConnectionObject, GenericErrorCode>> objects = connectionObjectList.getConnections()
            .stream()
            .map(ConnectionWorker.fromURIFunction(proxy))
            .collect(Collectors.toList());

        System.out.println("Obtained " + objects.size() + " connection objects");
    }
}
