package com.ossnms.web.api.oif.proxy.impl.endpoint;

import com.ossnms.web.api.oif.proxy.arquillian.ArquillianTestBase;
import com.ossnms.web.api.oif.proxy.impl.network.NetworkOperationsProxyImplTest;
import com.ossnms.web.provider.common.api.result.ProcessableResult;
import com.ossnms.web.provider.common.api.result.ProcessableSingleResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.sdn.model.call.Call;
import com.ossnms.web.provider.sdn.model.call.CallField;
import com.ossnms.web.provider.sdn.model.call.CallID;
import com.ossnms.web.provider.sdn.model.call.CallSummary;
import com.ossnms.web.provider.sdn.model.common.enumerable.ErrorCode;
import com.ossnms.web.provider.sdn.operations.call.ProcessableCallEntityOperations;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.arquillian.junit.InSequence;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.Collections;

import static org.junit.Assert.*;

/**
 *
 *
 */
@RunWith(Arquillian.class)
public class EndpointOperationsProxyImplTest extends ArquillianTestBase {

    private final static Logger LOGGER = LoggerFactory.getLogger(NetworkOperationsProxyImplTest.class);

    @Inject
    private ProcessableCallEntityOperations callOperations;

    private static final SecurityToken secToken = new SecurityToken.Builder("username", "passw" /*"myCuteBearerToken!"*/).build();

    @Test
    @InSequence( 1 )
    public void shouldNotBeNull() {
        assertNotNull( callOperations );
    }


}
