package com.ossnms.web.api.oif.proxy.api.client.call;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 *
 */
public class DiverseObject implements BaseObject {

    private static final long serialVersionUID = 9101371348912418363L;

    @JsonProperty( "call" )
    public String[] call;

    @JsonProperty( "coriant.riskClassRelax" )
    private List<String> riskClassRelax;

    @JsonProperty( "coriant.riskClassStrict" )
    private List<String> riskClassStrict;

    /**
     *
     */
    public String[] getCall() {
        return call;
    }

    public DiverseObject setCall(String[] call) {
        this.call = call;
        return this;
    }

    /**
     *
     */
    public List<String> getRiskClassRelax() {
        return riskClassRelax;
    }

    public DiverseObject setRiskClassRelax(List<String> riskClassRelax) {
        this.riskClassRelax = riskClassRelax;
        return this;
    }

    /**
     *
     */
    public List<String> getRiskClassStrict() {
        return riskClassStrict;
    }

    public DiverseObject setRiskClassStrict(List<String> riskClassStrict) {
        this.riskClassStrict = riskClassStrict;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        DiverseObject that = (DiverseObject) o;
        return Arrays.equals(getCall(), that.getCall()) &&
            Objects.equals(getRiskClassRelax(), that.getRiskClassRelax()) &&
            Objects.equals(getRiskClassStrict(), that.getRiskClassStrict());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCall(), getRiskClassRelax(), getRiskClassStrict());
    }
}
