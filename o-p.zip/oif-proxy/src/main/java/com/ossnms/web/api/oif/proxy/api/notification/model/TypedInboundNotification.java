package com.ossnms.web.api.oif.proxy.api.notification.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class TypedInboundNotification<E extends BaseObject> extends InboundNotification {

    @JsonProperty(value = "body")
    private E body;

    /**
     *
     */
    public E getBody() {
        return body;
    }

    public TypedInboundNotification setBody(E body) {
        this.body = body;
        return this;
    }
}
