package com.ossnms.web.api.oif.proxy.api.client.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.Objects;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class ActualLayerObject implements BaseObject {

    private static final long serialVersionUID = -6105178977680590659L;

    @JsonProperty(value="coriant.layerId", required = true)
    private Long layerId;

    @JsonProperty(value="coriant.minBitrate", required = true)
    private Long minBitrate;

    @JsonProperty(value="coriant.maxBitrate", required = true)
    private Long maxBitrate;

    /**
     *
     */
    public Long getLayerId() {
        return layerId;
    }

    public ActualLayerObject setLayerId(Long layerId) {
        this.layerId = layerId;
        return this;
    }

    /**
     *
     */
    public Long getMinBitrate() {
        return minBitrate;
    }

    public ActualLayerObject setMinBitrate(Long minBitrate) {
        this.minBitrate = minBitrate;
        return this;
    }

    /**
     *
     */
    public Long getMaxBitrate() {
        return maxBitrate;
    }

    public ActualLayerObject setMaxBitrate(Long maxBitrate) {
        this.maxBitrate = maxBitrate;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        ActualLayerObject that = (ActualLayerObject) o;
        return Objects.equals(getLayerId(), that.getLayerId()) &&
            Objects.equals(getMinBitrate(), that.getMinBitrate()) &&
            Objects.equals(getMaxBitrate(), that.getMaxBitrate());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getLayerId(), getMinBitrate(), getMaxBitrate());
    }
}
