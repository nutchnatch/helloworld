package com.ossnms.web.api.oif.proxy.impl.vertex;

import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.sdn.model.vertex.Vertex;
import com.ossnms.web.provider.sdn.model.vertex.VertexField;
import com.ossnms.web.provider.sdn.model.vertex.VertexID;
import com.ossnms.web.provider.sdn.model.vertex.VertexSummary;
import com.ossnms.web.provider.sdn.operations.vertex.VertexEntityOperations;

import javax.enterprise.context.RequestScoped;
import java.util.Collection;

/**
 *
 */
@RequestScoped
public class VertexOperationsProxyImpl implements VertexEntityOperations {

//    private static final Logger LOGGER = LoggerFactory.getLogger(VertexOperationsProxyImpl.class);

    /**
     * {@inheritDoc}
     */
    @Override
    public VertexID insert(SecurityToken securityToken, Vertex entity) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public VertexID update(SecurityToken securityToken, Vertex entity) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void delete(SecurityToken securityToken, VertexID id) {

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public VertexSummary getSummary(SecurityToken securityToken, VertexID id) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Vertex getDetails(SecurityToken securityToken, VertexID id) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<VertexSummary, VertexField> getAllSummary(SecurityToken securityToken, Collection<VertexID> ids) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<VertexSummary, VertexField> getAllSummary(SecurityToken securityToken, Collection<Filter<VertexField>> filterBy, Sort<VertexField> sortBy, Page page) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<Vertex, VertexField> getAll(SecurityToken securityToken, Collection<VertexID> ids) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<Vertex, VertexField> getAll(SecurityToken securityToken, Collection<Filter<VertexField>> filterBy, Sort<VertexField> sortBy, Page page) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<VertexID, VertexField> getAllIds(SecurityToken securityToken, Collection<Filter<VertexField>> filterBy, Sort<VertexField> sortBy, Page page) {
        return null;
    }
}
