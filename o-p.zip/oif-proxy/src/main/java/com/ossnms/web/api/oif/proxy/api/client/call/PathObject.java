package com.ossnms.web.api.oif.proxy.api.client.call;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.List;

/**
 *
 */
public class PathObject implements BaseObject {

    private static final long serialVersionUID = 5112563672811586301L;

    @JsonProperty( "coriant.componentPath" )
    private List<String> componentPath;

    /**
     *
     * @return
     */
    public List<String> getComponentPath() {

        return componentPath;
    }

    /**
     *
     * @param componentPath
     * @return
     */
    public PathObject setComponentPath( List<String> componentPath ) {

        this.componentPath = componentPath;
        return this;
    }
}