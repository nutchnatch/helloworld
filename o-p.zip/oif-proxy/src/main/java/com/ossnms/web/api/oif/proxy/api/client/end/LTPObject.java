package com.ossnms.web.api.oif.proxy.api.client.end;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class LTPObject implements BaseObject {

    private static final long serialVersionUID = -3688490527551278195L;

    @JsonProperty( "onfOtwgIm.operationalState" )
    private String operationalState;

    /**
     *
     * @return
     */
    public String getOperationalState() {

        return operationalState;
    }

    /**
     *
     * @param operationalState
     * @return
     */
    public LTPObject setOperationalState( String operationalState ) {

        this.operationalState = operationalState;
        return this;
    }
}