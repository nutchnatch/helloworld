package com.ossnms.web.api.oif.proxy.impl.network;

import com.ossnms.web.provider.sdn.api.annotation.Proxy;
import com.ossnms.web.api.oif.proxy.api.client.network.NetworkNDMClient;
import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.result.ProcessableResult;
import com.ossnms.web.provider.common.api.result.ProcessableSingleResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.sdn.model.common.enumerable.ErrorCode;
import com.ossnms.web.provider.sdn.model.network.Network;
import com.ossnms.web.provider.sdn.model.network.NetworkField;
import com.ossnms.web.provider.sdn.model.network.NetworkID;
import com.ossnms.web.provider.sdn.model.network.NetworkSummary;
import com.ossnms.web.provider.sdn.operations.network.ProcessableNetworkEntityOperations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import java.util.Collection;

/**
 *
 */
@RequestScoped
public class ProcessableNetworkOperationsProxyImpl implements ProcessableNetworkEntityOperations {

    /**
     *
     */
    private static final Logger LOGGER = LoggerFactory.getLogger( ProcessableNetworkOperationsProxyImpl.class );

    private Instance<NetworkNDMClient> instance;

    /**
     * Default no-args constructor
     */
    public ProcessableNetworkOperationsProxyImpl() {}

    @Inject
    public ProcessableNetworkOperationsProxyImpl( @Proxy Instance<NetworkNDMClient> instance ) {
        this.instance = instance;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableSingleResult<Network, ErrorCode> insert(SecurityToken securityToken, Network entity) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableSingleResult<Network, ErrorCode> update(SecurityToken securityToken, Network entity) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableSingleResult<NetworkID, ErrorCode> delete(SecurityToken securityToken, NetworkID id) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableSingleResult<NetworkSummary, ErrorCode> getSummary(SecurityToken securityToken, NetworkID id) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableSingleResult<Network, ErrorCode> getDetails(SecurityToken securityToken, NetworkID id) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableResult<NetworkSummary, NetworkField, ErrorCode> getAllSummary(SecurityToken securityToken, Collection<NetworkID> ids) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableResult<NetworkSummary, NetworkField, ErrorCode> getAllSummary(SecurityToken securityToken, Collection<Filter<NetworkField>> filterBy, Sort<NetworkField> sortBy, Page page) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableResult<Network, NetworkField, ErrorCode> getAll(SecurityToken securityToken, Collection<NetworkID> ids) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableResult<Network, NetworkField, ErrorCode> getAll(SecurityToken securityToken, Collection<Filter<NetworkField>> filterBy, Sort<NetworkField> sortBy, Page page) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableResult<NetworkID, NetworkField, ErrorCode> getAllIds(SecurityToken securityToken, Collection<Filter<NetworkField>> filterBy, Sort<NetworkField> sortBy, Page page) {
        return null;
    }
}