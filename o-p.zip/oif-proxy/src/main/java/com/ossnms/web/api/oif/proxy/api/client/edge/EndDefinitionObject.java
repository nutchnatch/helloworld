package com.ossnms.web.api.oif.proxy.api.client.edge;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.Objects;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class EndDefinitionObject implements BaseObject {

    private static final long serialVersionUID = -6965680571469017228L;

    @JsonProperty(value = "vertex", required = true)
    private String vertex;

    @JsonProperty(value = "end", required = true)
    private String end;

    /**
     *
     */
    public String getVertex() {
        return vertex;
    }

    public EndDefinitionObject setVertex(String vertex) {
        this.vertex = vertex;
        return this;
    }

    /**
     *
     */
    public String getEnd() {
        return end;
    }

    public EndDefinitionObject setEnd(String end) {
        this.end = end;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        EndDefinitionObject that = (EndDefinitionObject) o;
        return Objects.equals(getVertex(), that.getVertex()) &&
            Objects.equals(getEnd(), that.getEnd());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getVertex(), getEnd());
    }
}
