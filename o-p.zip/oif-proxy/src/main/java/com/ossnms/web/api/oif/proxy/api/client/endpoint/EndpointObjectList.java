package com.ossnms.web.api.oif.proxy.api.client.endpoint;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Objects;


/**
 *
 */
@JsonInclude( JsonInclude.Include.NON_NULL )
public class EndpointObjectList {

    @JsonProperty(value = "id", required = true)
    private List<String> endpoints;

    /**
     *
     */
    public List<String> getEndpoints() {
        return endpoints;
    }

    /**
     *
     * @param endpoints
     * @return
     */
    public EndpointObjectList setEndpoints(List<String> endpoints) {
        this.endpoints = endpoints;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        EndpointObjectList that = (EndpointObjectList) o;
        return Objects.equals(getEndpoints(), that.getEndpoints());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getEndpoints());
    }
}