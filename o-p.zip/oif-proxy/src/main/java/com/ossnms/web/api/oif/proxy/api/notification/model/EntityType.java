package com.ossnms.web.api.oif.proxy.api.notification.model;

/**
 *
 */
public enum EntityType {
    /**
     *
     */
    END,

    /**
     *
     */
    EDGE,

    /**
     *
     */
    VERTEX,

    /**
     * No mapping
     */
    NONE_3,

    /**
     * No mapping
     */
    NONE_4,

    /**
     * No mapping
     */
    NONE_5,

    /**
     *
     */
    CALL,

    /**
     *
     */
    PATH_REQUEST,

    /**
     * No mapping
     */
    NONE_8,

    /**
     *
     */
    CONNECTION,

    /**
     * No mapping
     */
    NONE_10,

    /**
     *
     */
    ENDPOINT,

    /**
     *
     */
    ENFORCE,

    /**
     *
     */
    SRG,

    /**
     *
     */
    DOMAIN,

    /**
     *
     */
    SEGMENT,

    /**
     *
     */
    PROTECTION_ACTION

}
