package com.ossnms.web.api.oif.proxy.api.common.util.backoff;

/**
 *
 */
@FunctionalInterface
public interface ExponentialBackOffRunnable {

    /**
     *
     * @return
     */
    void execute() throws ExponentialBackOffException;
}
