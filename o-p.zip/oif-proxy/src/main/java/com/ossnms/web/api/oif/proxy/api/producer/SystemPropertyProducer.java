package com.ossnms.web.api.oif.proxy.api.producer;

import com.ossnms.web.api.oif.proxy.api.annotation.SystemProperty;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 */
public class SystemPropertyProducer {

    /**
     * Default no-args constructor
     */
    public SystemPropertyProducer() {}

    /**
     *
     * @param ip the injection point
     * @return returns the string with the value of the specified system property
     */
    @Produces
    @SystemProperty("")
    public String findProperty(InjectionPoint ip) {
        SystemProperty annotation = ip.getAnnotated().getAnnotation(SystemProperty.class);

        String name = annotation.value();
        String property = System.getProperty(name);
        if (property == null) {
            return "";
        }
        return property;
    }


}
