package com.ossnms.web.api.oif.proxy.api.client.edge;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.List;
import java.util.Objects;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class EdgeObjectList implements BaseObject {

    private static final long serialVersionUID = -2151671671190147183L;

    @JsonProperty(value = "id", required = true)
    private List<String> edges;

    /**
     *
     */
    public List<String> getEdges() {
        return edges;
    }

    public EdgeObjectList setEdges(List<String> edges) {
        this.edges = edges;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        EdgeObjectList that = (EdgeObjectList) o;
        return Objects.equals(getEdges(), that.getEdges());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getEdges());
    }
}
