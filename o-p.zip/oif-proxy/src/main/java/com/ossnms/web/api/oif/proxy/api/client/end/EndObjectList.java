package com.ossnms.web.api.oif.proxy.api.client.end;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.List;
import java.util.Objects;

/**
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EndObjectList implements BaseObject {

    private static final long serialVersionUID = -6921646340583880802L;

    @JsonProperty(value = "id", required = true)
    private List<String> ends;

    /**
     *
     */
    public List<String> getEnds() {
        return ends;
    }

    public EndObjectList setEnds(List<String> ends) {
        this.ends = ends;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        EndObjectList that = (EndObjectList) o;
        return Objects.equals(getEnds(), that.getEnds());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getEnds());
    }
}
