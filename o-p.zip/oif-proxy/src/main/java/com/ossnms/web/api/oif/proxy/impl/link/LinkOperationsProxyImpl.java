package com.ossnms.web.api.oif.proxy.impl.link;

import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.sdn.model.link.Link;
import com.ossnms.web.provider.sdn.model.link.LinkField;
import com.ossnms.web.provider.sdn.model.link.LinkID;
import com.ossnms.web.provider.sdn.model.link.LinkSummary;
import com.ossnms.web.provider.sdn.operations.link.LinkEntityOperations;

import java.util.Collection;

/**
 *
 */
public class LinkOperationsProxyImpl implements LinkEntityOperations {

//    private static final Logger LOGGER = LoggerFactory.getLogger(LinkOperationsProxyImpl.class);

    /**
     * {@inheritDoc}
     */
    @Override
    public LinkID insert(SecurityToken securityToken, Link entity) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public LinkID update(SecurityToken securityToken, Link entity) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void delete(SecurityToken securityToken, LinkID id) {

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public LinkSummary getSummary(SecurityToken securityToken, LinkID id) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Link getDetails(SecurityToken securityToken, LinkID id) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<LinkSummary, LinkField> getAllSummary(SecurityToken securityToken, Collection<LinkID> ids) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<LinkSummary, LinkField> getAllSummary(SecurityToken securityToken, Collection<Filter<LinkField>> filterBy, Sort<LinkField> sortBy, Page page) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<Link, LinkField> getAll(SecurityToken securityToken, Collection<LinkID> ids) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<Link, LinkField> getAll(SecurityToken securityToken, Collection<Filter<LinkField>> filterBy, Sort<LinkField> sortBy, Page page) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<LinkID, LinkField> getAllIds(SecurityToken securityToken, Collection<Filter<LinkField>> filterBy, Sort<LinkField> sortBy, Page page) {
        return null;
    }
}
