package com.ossnms.web.api.oif.proxy.impl.call;

import com.ossnms.web.api.oif.proxy.api.client.call.CallObject;
import com.ossnms.web.api.oif.proxy.api.client.call.IetfASONConnectionIDsObject;
import com.ossnms.web.api.oif.proxy.api.client.call.PathObject;
import com.ossnms.web.api.oif.proxy.api.client.call.ProtectionGroupObject;
import com.ossnms.web.api.oif.proxy.api.client.call.RoutingFailureDetailObject;
import com.ossnms.web.api.oif.proxy.api.client.call.SLAObject;
import com.ossnms.web.api.oif.proxy.api.client.common.CommonWorker;
import com.ossnms.web.api.oif.proxy.api.client.common.RiskObject;
import com.ossnms.web.api.oif.proxy.api.client.common.SrgDetailObject;
import com.ossnms.web.api.oif.proxy.api.client.common.TrafficParamObject;
import com.ossnms.web.api.oif.proxy.api.client.connection.ConnectionNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.connection.ConnectionObject;
import com.ossnms.web.api.oif.proxy.api.client.connection.ConnectionWorker;
import com.ossnms.web.api.oif.proxy.api.client.connection.TopoComponentObject;
import com.ossnms.web.api.oif.proxy.api.client.edge.EdgeNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.edge.EdgeObject;
import com.ossnms.web.api.oif.proxy.api.client.edge.EdgeWorker;
import com.ossnms.web.api.oif.proxy.api.client.end.EndNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.end.EndObject;
import com.ossnms.web.api.oif.proxy.api.client.end.EndWorker;
import com.ossnms.web.api.oif.proxy.api.client.endpoint.EndpointNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.endpoint.EndpointObject;
import com.ossnms.web.api.oif.proxy.api.client.endpoint.EndpointWorker;
import com.ossnms.web.api.oif.proxy.api.client.vertex.VertexNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.vertex.VertexObject;
import com.ossnms.web.api.oif.proxy.api.client.vertex.VertexWorker;
import com.ossnms.web.api.oif.proxy.api.common.result.GenericErrorCode;
import com.ossnms.web.provider.common.api.result.ProcessableSingleResult;
import com.ossnms.web.provider.common.api.result.enumerable.Status;
import com.ossnms.web.provider.sdn.model.call.Call;
import com.ossnms.web.provider.sdn.model.call.CallSummaryPrototype;
import com.ossnms.web.provider.sdn.model.call.Connection;
import com.ossnms.web.provider.sdn.model.call.ConnectionID;
import com.ossnms.web.provider.sdn.model.call.ConnectionTopoComponent;
import com.ossnms.web.provider.sdn.model.call.ProtectionGroup;
import com.ossnms.web.provider.sdn.model.call.RoutingFailureDetail;
import com.ossnms.web.provider.sdn.model.call.SLA;
import com.ossnms.web.provider.sdn.model.common.attributes.Risk;
import com.ossnms.web.provider.sdn.model.common.attributes.SrgDetail;
import com.ossnms.web.provider.sdn.model.common.attributes.TrafficParam;
import com.ossnms.web.provider.sdn.model.edge.EdgeID;
import com.ossnms.web.provider.sdn.model.edge.EdgeSummary;
import com.ossnms.web.provider.sdn.model.edge.end.EdgeEndID;
import com.ossnms.web.provider.sdn.model.edge.end.EdgeEndSummary;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointID;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointSummary;
import com.ossnms.web.provider.sdn.model.vertex.VertexID;
import com.ossnms.web.provider.sdn.model.vertex.VertexSummary;
import com.ossnms.web.provider.sdn.model.vertex.attribute.VertexIdentifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static com.ossnms.web.provider.common.api.result.enumerable.Status.OK;

/**
 *
 */
public final class CallBuilder {

    private static final Logger LOGGER = LoggerFactory.getLogger( CallBuilder.class );

    /**
     * Hidden constructor
     */
    private CallBuilder() {}

    /**
     *
     * @param call
     * @param builder
     * @param vertexProxy
     * @param endpointProxy
     */
    static void toCallSummary( CallObject call, CallSummaryPrototype<?> builder, VertexNDMClient vertexProxy, EndpointNDMClient endpointProxy ) {

        builder.setName( call.getName() );
        builder.setOperStatus( call.getCallOperStatus() );

        if ( vertexProxy != null && endpointProxy != null ) {

            String aEndUri = call.getaEnd().length > 0 ? call.getaEnd()[ 0 ] : null;

            if ( aEndUri != null ) {
                ProcessableSingleResult<EndpointObject, GenericErrorCode> aEndDetails =
                    EndpointWorker.fromURIFunction( endpointProxy ).apply( aEndUri );

                if ( aEndDetails.getOperationStatus() == OK ) {
                    builder.setAEnd( buildEndpointSummary( aEndDetails.getEntity(), vertexProxy ) );
                }
                else {
                    logError(
                        "endpoint",
                        aEndUri,
                        aEndDetails.getOperationStatus(),
                        aEndDetails.getErrorCode(),
                        aEndDetails.getErrorMessage()
                    );
                }
            }

            String zEndUri = call.getzEnd().length > 0 ? call.getzEnd()[ 0 ] : null;

            if ( zEndUri != null ) {

                ProcessableSingleResult<EndpointObject, GenericErrorCode> zEndDetails =
                    EndpointWorker.fromURIFunction( endpointProxy ).apply( zEndUri );

                if ( zEndDetails.getOperationStatus() == OK ) {

                    builder.setZEnd( buildEndpointSummary( zEndDetails.getEntity(), vertexProxy ) );
                }
                else {

                    logError(
                        "endpoint",
                        zEndUri,
                        zEndDetails.getOperationStatus(),
                        zEndDetails.getErrorCode(),
                        zEndDetails.getErrorMessage()
                    );
                }
            }
        }
    }


    /**
     *
     * @param call
     * @param builder
     * @param vertexProxy
     * @param endpointProxy
     */
    static void toCall( CallObject call,
                        Call.Builder builder,
                        VertexNDMClient vertexProxy,
                        EndNDMClient edgeEndProxy,
                        EdgeNDMClient edgeProxy,
                        EndpointNDMClient endpointProxy,
                        ConnectionNDMClient connectionProxy ) {

        toCallSummary( call, builder, vertexProxy, endpointProxy );

        builder.setPathRequestId( call.getPathRequestId() );

        builder.setTrafficParam( buildTrafficParam( call.getTrafficParam() ) );

        builder.setAdminStatus( call.getAdminStatus() );

        builder.setCallProvisioningStatus( call.getCallProvisioningStatus() );
        builder.setCallConfigStatus( call.getCallConfigStatus() );
        builder.setNetworkSyncStatus( call.getNetworkSyncStatus() );
        builder.setCallLatency( call.getCallLatency() );

        builder.setRoutingFailureDetail( buildRoutingFailureDetail( call.getRoutingFailureDetail() ) );

        builder.setSwitchingType( call.getSwitchingType() );
        builder.setEncoding( call.getEncoding() );
        builder.setDirectionality( call.getDirectionality() );

        builder.addConnections( buildConnections( call.getConnectionIDs(), vertexProxy, edgeEndProxy, connectionProxy ) );

        if ( call.getPath() != null && ! call.getPath().isEmpty() ) {

            builder.addPath( buildPath( call.getPath().get( 0 ), vertexProxy, edgeEndProxy, edgeProxy ) );
        }

        // b.setConstraints

        builder.setServiceLatency( call.getServiceLatency() );

        builder.setRoutingOverExistingServicesOnly( call.isRoutingOverExistingServicesOnly() );
        builder.setRoutingOverEnabledResourcesOnly( call.isRoutingOverEnabledResourcesOnly() );
        builder.setRoutingOverNotReservedResourcesOnly( call.isRoutingOverNotReservedResourcesOnly() );

        builder.setOrderNumber( call.getOrderNumber() );

        builder.setSla( buildSLA( call.getSla() ) );

        builder.addSrgDetails( buildSrgDetails( call.getSrgDetails() ) );

        // b.setSchedule

        builder.setRestorable( call.isRestorable() );

        builder.addProtectionGroups( buildProtectionGroups( call.getProtectionGroups() ) );
    }

    /**
     *
     * @param protectionGroups
     * @return
     */
    private static List<ProtectionGroup> buildProtectionGroups( List<ProtectionGroupObject> protectionGroups ) {

        if ( protectionGroups == null ) {

            return Collections.emptyList();
        }

        return protectionGroups.stream()
                    .map( item -> new ProtectionGroup.Builder()
                                    .setId( item.getId() )
                                    .setProtectionMode( item.getProtectionMode() )
                                    .setProtectionType( item.getProtectionType() )
                                    .setProtectionState( item.getProtectionState() )
                                    .setRestorationGate( item.getRestorationGate() )
                                    .build() )
                    .collect( Collectors.toList() );
    }

    /**
     *
     * @param connectionIDs
     * @param connectionProxy
     * @return
     */
    private static List<Connection> buildConnections( List<IetfASONConnectionIDsObject> connectionIDs, VertexNDMClient vertexProxy, EndNDMClient edgeEndProxy, ConnectionNDMClient connectionProxy ) {

        List<Connection> connections = new ArrayList<>();

        if ( connectionIDs != null && ! connectionIDs.isEmpty() && connectionIDs.get( 0 ).getComponentConnections() != null ) {

            for ( String connectionUri : connectionIDs.get( 0 ).getComponentConnections() ) {

                connections.add( buildConnection( connectionUri, vertexProxy, edgeEndProxy, connectionProxy ) );
            }
        }

        return connections;
    }

    /**
     *
     * @param connectionUri
     * @param connectionProxy
     * @return
     */
    private static Connection buildConnection( String connectionUri, VertexNDMClient vertexProxy, EndNDMClient edgeEndProxy, ConnectionNDMClient connectionProxy ) {

        if ( connectionUri == null ) {

            return null;
        }

        ProcessableSingleResult<ConnectionObject,GenericErrorCode> connDetails =
            ConnectionWorker.fromURIFunction( connectionProxy ).apply( connectionUri );

        if ( connDetails.getOperationStatus() == OK ) {

            ConnectionObject connObj = connDetails.getEntity();

            String domainId = CommonWorker.toDomainId( connectionUri );
            String id = CommonWorker.toId( connectionUri );

            TrafficParam.Builder tfpBuilder = new TrafficParam.Builder();

            if ( connObj.getTrafficParam() != null ) {

                tfpBuilder.setSigType( connObj.getTrafficParam().getSigType() );
                tfpBuilder.setMultiplier( connObj.getTrafficParam().getMultiplier() );
                tfpBuilder.setBandwidth( connObj.getTrafficParam().getBandwidth() );
            }

            return
                new Connection.Builder( new ConnectionID.Builder( domainId, id ).build() )
                .setName( connObj.getName() )
                .setAdminStatus( connObj.getAdminStatus() )
                .setOperStatus( connObj.getOperStatus() )
                .setProvisioningStatus( connObj.getProvisioningStatus() )
                .setNetworkSyncStatus( connObj.getNetworkSyncStatus() )
                .setAEnd( buildEdgeEndSummary( connObj.getAEnd(), vertexProxy, edgeEndProxy ) )
                .setZEnd( buildEdgeEndSummary( connObj.getZEnd(), vertexProxy, edgeEndProxy ) )
                .setDirectionality( connObj.getDirectionality() )
                .setEncoding( connObj.getEncoding() )
                .setFrequency( connObj.getFrequency() )
                .setFreqSlotWidth( connObj.getFreqSlotWidth() )
                .setSwitchingType( connObj.getSwitchingType() )
                .setTrafficParam( tfpBuilder.build() )
                .setTopoComponent( buildConnectionTopoComponent( connObj.getPath() ) )
                .addSrgDetails( buildSrgDetails( connObj.getSrgDetails() ) )
                .build();
        }
        else {

            logError(
                "connection",
                connectionUri,
                connDetails.getOperationStatus(),
                connDetails.getErrorCode(),
                connDetails.getErrorMessage()
            );
        }

        return null;
    }

    private static ConnectionTopoComponent buildConnectionTopoComponent( List<TopoComponentObject> path ) {

        if ( path == null || path.isEmpty() || path.get( 0 ).getTopoComponent() == null ) {

            return null;
        }

        String uri = path.get( 0 ).getTopoComponent();
        String domainId = CommonWorker.toDomainId( uri );
        String connId = CommonWorker.toConnectionId( uri );

        ConnectionTopoComponent connectionTopoComponent;

        if ( connId != null ) {

            connectionTopoComponent =
                new ConnectionTopoComponent.Builder(
                    new ConnectionID.Builder( domainId, connId ).build()
                ).build();
        }
        else {

            connectionTopoComponent =
                new ConnectionTopoComponent.Builder(
                    new EdgeID.Builder( domainId, CommonWorker.toId( uri ) ).build()
                ).build();
        }

        return connectionTopoComponent;
    }

    /**
     *
     * @param srgDetails
     * @return
     */
    private static List<SrgDetail> buildSrgDetails( List<SrgDetailObject> srgDetails ) {

        List<SrgDetail> srgs = new ArrayList<>();

        if ( srgDetails != null ) {

            for ( SrgDetailObject srgDetail : srgDetails ) {

                List<Risk> riskObjs = new ArrayList<>();

                for ( RiskObject riskDetail : srgDetail.getRisks() ) {

                    Risk risk =
                        new Risk.Builder()
                            .setId( CommonWorker.toId( riskDetail.getId() ) )
                            .setDomainId( riskDetail.getDomainId() )
                            .setName( riskDetail.getName() )
                            .build();

                    riskObjs.add( risk );
                }

                SrgDetail srg =
                    new SrgDetail.Builder()
                    .setRiskClass( srgDetail.getRiskClass() )
                    .setRiskStartTime( srgDetail.getRiskStartTime() )
                    .setRiskStopTime( srgDetail.getRiskStopTime() )
                    .addRisks( riskObjs )
                    .build();

                srgs.add( srg );
            }
        }

        return srgs;
    }

    /**
     *
     * @param path
     * @return
     */
    private static List<EdgeSummary> buildPath( PathObject path, VertexNDMClient vertexProxy, EndNDMClient edgeEndProxy, EdgeNDMClient edgeProxy ) {

        List<EdgeSummary> newPath = new ArrayList<>();

        if ( path != null ) {

            for ( String edgeUri : path.getComponentPath() ) {

                ProcessableSingleResult<EdgeObject, GenericErrorCode> edgeDetails =
                    EdgeWorker.fromURIFunction( edgeProxy ).apply( edgeUri );

                if ( edgeDetails.getOperationStatus() == OK ) {

                    newPath.add( buildEdgeSummary( CommonWorker.toDomainId( edgeUri ), edgeDetails.getEntity(), vertexProxy, edgeEndProxy ) );
                }
                else {

                    logError(
                        "edge",
                        edgeUri,
                        edgeDetails.getOperationStatus(),
                        edgeDetails.getErrorCode(),
                        edgeDetails.getErrorMessage()
                    );
                }
            }
        }

        return newPath;
    }

    /**
     *
     * @param sla
     * @return
     */
    private static SLA buildSLA( SLAObject sla ) {

        SLA.Builder builder = new SLA.Builder();

        if ( sla != null ) {

            builder
                .setSLAMonitoring( sla.SLAMonitoring )
                .setCallImpairmentStatus( sla.callImpairmentStatus )
                .setCallLastImpairmentStatusTimestamp( sla.callLastImpairmentStatusTimestamp )
                .setThroughput( sla.throughput );
        }

        return builder.build();
    }

    /**
     *
     * @param routingFailureDetail
     * @return
     */
    private static RoutingFailureDetail buildRoutingFailureDetail( RoutingFailureDetailObject routingFailureDetail ) {

        RoutingFailureDetail.Builder builder = new RoutingFailureDetail.Builder();

        if ( routingFailureDetail != null ) {

            builder
                .setFailureCode( routingFailureDetail.getFailureCode() )
                .setFailureDescription( routingFailureDetail.getFailureDescription() );
        }

        return builder.build();
    }

    /**
     *
     * @param endpoint
     * @param vertexProxy
     * @return
     */
    private static EndpointSummary buildEndpointSummary( EndpointObject endpoint, VertexNDMClient vertexProxy ) {

        String vertexUri = CommonWorker.toVertexUri( endpoint.getTopoComponent() );

        ProcessableSingleResult<VertexObject, GenericErrorCode> nodeDetails =
            VertexWorker.fromURIFunction( vertexProxy ).apply( vertexUri );

        EndpointSummary.Builder endpBuilder =
            new EndpointSummary.Builder( new EndpointID.Builder( CommonWorker.toDomainId( endpoint.getId() ), CommonWorker.toId( endpoint.getId() ) ).build() )
                .setName( endpoint.getName() )
                .setEdgeEndID( new EdgeEndID.Builder(
                        CommonWorker.toDomainId( endpoint.getTopoComponent() ),
                        CommonWorker.toId( vertexUri ),
                        CommonWorker.toId( endpoint.getTopoComponent() ) )
                    .build()
                );

        if ( nodeDetails.getOperationStatus() == OK ) {

            endpBuilder.setVertex( buildVertexSummary( CommonWorker.toDomainId( endpoint.getTopoComponent() ), nodeDetails.getEntity() ) );
        }
        else {

            logError(
                "vertex",
                vertexUri,
                nodeDetails.getOperationStatus(),
                nodeDetails.getErrorCode(),
                nodeDetails.getErrorMessage()
            );
        }

        return endpBuilder.build();
    }

    /**
     *
     * @param domainId
     * @param edge
     * @param edgeEndProxy
     * @return
     */
    private static EdgeSummary buildEdgeSummary( String domainId, EdgeObject edge, VertexNDMClient vertexProxy, EndNDMClient edgeEndProxy ) {

        EdgeSummary.Builder builder = new EdgeSummary.Builder( new EdgeID.Builder( domainId, CommonWorker.toId( edge.getId() ) ).build() );

        builder.setName( edge.getName() );

        if ( edge.getAEnd() != null ) {

            builder.setAEnd( buildEdgeEndSummary( edge.getAEnd().getEnd(), vertexProxy,  edgeEndProxy ) );
        }

        if ( edge.getZEnd() != null ) {

            builder.setZEnd( buildEdgeEndSummary( edge.getZEnd().getEnd(), vertexProxy, edgeEndProxy ) );
        }

        return builder.build();
    }

    /**
     *
     * @param edgeEndUri
     * @param edgeEndProxy
     * @return
     */
    private static EdgeEndSummary buildEdgeEndSummary( String edgeEndUri, VertexNDMClient vertexProxy, EndNDMClient edgeEndProxy ) {

        if ( edgeEndUri == null ) {

            return null;
        }

        ProcessableSingleResult<EndObject, GenericErrorCode> edgeEndDetails =
            EndWorker.fromURIFunction( edgeEndProxy ).apply( edgeEndUri );

        if ( edgeEndDetails.getOperationStatus() == OK ) {

            String domainId = CommonWorker.toDomainId( edgeEndUri );

            EdgeEndID edgeEndID = new EdgeEndID.Builder( domainId, CommonWorker.toVertexId( edgeEndUri ), CommonWorker.toId( edgeEndUri ) ).build();

            EndObject edgeEndObject = edgeEndDetails.getEntity();

            return new EdgeEndSummary.Builder( edgeEndID )
                .setName( edgeEndObject.getName() )
                .setOwnership( edgeEndObject.getOwnership() )
                .setOperState( edgeEndObject.getLTP().getOperationalState() )
                .setVertex( buildVertexSummary( edgeEndObject.getVertex(), vertexProxy ) )
                .build();
        }
        else {

            logError(
                "edgeEnd",
                edgeEndUri,
                edgeEndDetails.getOperationStatus(),
                edgeEndDetails.getErrorCode(),
                edgeEndDetails.getErrorMessage()
            );
        }

        return null;
    }


    /**
     *
     * @param vertexUri
     * @param vertexProxy
     * @return
     */
    private static VertexSummary buildVertexSummary( String vertexUri, VertexNDMClient vertexProxy ) {

        if ( vertexUri == null ) {

            return null;
        }

        ProcessableSingleResult<VertexObject,GenericErrorCode> vertexDetails =
            VertexWorker.fromURIFunction( vertexProxy ).apply( vertexUri );

        if ( vertexDetails.getOperationStatus() == OK ) {

            String domainId = CommonWorker.toDomainId( vertexUri );

            return buildVertexSummary( domainId, vertexDetails.getEntity() );
        }
        else {

            logError(
                "vertex",
                vertexUri,
                vertexDetails.getOperationStatus(),
                vertexDetails.getErrorCode(),
                vertexDetails.getErrorMessage()
            );
        }

        return null;
    }

    /**
     *
     * @param domainId
     * @param node
     * @return
     */
    private static VertexSummary buildVertexSummary( String domainId, VertexObject node ) {

        VertexIdentifier.Builder vertexIdentifierBuilder = new VertexIdentifier.Builder();

        if ( node.getVertexIdentifier() != null ) {

            vertexIdentifierBuilder.setCoriantCoordLatitude( node.getVertexIdentifier().getCoordLatitude() );
            vertexIdentifierBuilder.setCoriantCoordLongitude( node.getVertexIdentifier().getCoordLongitude() );
            vertexIdentifierBuilder.setCoriantNodeType( node.getVertexIdentifier().getNodeType() );
        }

        return new VertexSummary.Builder( new VertexID.Builder( domainId, CommonWorker.toId( node.getId() ) ).build() )
            .setName( node.getName() )
            .setCoriantEmsName( node.getEmsName() )
            .setCoriantVertexIdentifier( vertexIdentifierBuilder.build() )
            .build();
    }


    /**
     *
     * @param trafficParam
     * @return
     */
    private static TrafficParam buildTrafficParam( TrafficParamObject trafficParam ) {

        TrafficParam.Builder trafficParamBuilder = new TrafficParam.Builder();

        if ( trafficParam != null ) {

            trafficParamBuilder
                .setSigType( trafficParam.getSigType() )
                .setMultiplier( trafficParam.getMultiplier() )
                .setBandwidth( trafficParam.getBandwidth() );
        }

        return trafficParamBuilder.build();
    }

    /**
     *
     * @param entityName
     * @param uri
     * @param operationStatus
     * @param errorCode
     * @param errorMessage
     */
    private static void logError( String entityName, String uri, Status operationStatus, GenericErrorCode errorCode, String errorMessage ) {

        LOGGER.error(
            "Could not load %s: %s | Status: %s | Error code: %s | Error msg.: %s",
            entityName, uri, operationStatus, errorCode, errorMessage
        );
    }
}