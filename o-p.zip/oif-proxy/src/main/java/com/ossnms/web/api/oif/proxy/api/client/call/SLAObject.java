package com.ossnms.web.api.oif.proxy.api.client.call;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class SLAObject implements BaseObject {

    private static final long serialVersionUID = 4252425499554637457L;

    @JsonProperty( "coriant.SLAMonitoring" )
    public Boolean SLAMonitoring;

    @JsonProperty( "coriant.throughput" )
    public Double throughput;

    @JsonProperty( "coriant.callImpairmentStatus" )
    public String callImpairmentStatus;

    @JsonProperty( "coriant.callLastImpairmentStatusTimestamp" )
    public String callLastImpairmentStatusTimestamp;


    // Deprecated: coriant.SLA_coriant.impairmentStatus
    // Deprecated: coriant.SLA_coriant.lastImpairmentStatusTimestamp
}