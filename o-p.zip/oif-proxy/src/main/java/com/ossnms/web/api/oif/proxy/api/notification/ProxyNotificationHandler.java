package com.ossnms.web.api.oif.proxy.api.notification;

import com.ossnms.web.api.oif.proxy.api.notification.model.InboundNotification;
import com.ossnms.web.provider.common.api.notification.NotificationHandlerException;

import java.io.IOException;

/**
 *
 */
@FunctionalInterface
public interface ProxyNotificationHandler {
    void handle(InboundNotification notification, String message) throws IOException, NotificationHandlerException;
}
