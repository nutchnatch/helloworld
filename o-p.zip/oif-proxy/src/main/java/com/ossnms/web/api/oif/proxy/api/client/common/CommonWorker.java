package com.ossnms.web.api.oif.proxy.api.client.common;

import com.ossnms.web.api.oif.proxy.api.common.BaseObject;
import com.ossnms.web.api.oif.proxy.api.common.network.NetworkBaseClient;
import com.ossnms.web.api.oif.proxy.api.common.result.GenericErrorCode;
import com.ossnms.web.api.oif.proxy.api.common.topology.TopologyBaseClient;
import com.ossnms.web.api.oif.proxy.api.common.vertex.VertexBaseClient;
import com.ossnms.web.provider.common.api.result.ProcessableSingleResult;
import com.ossnms.web.provider.common.api.result.enumerable.Status;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.core.Response;
import java.io.Serializable;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 */
public final class CommonWorker {

    private static final int STATUS_OK = 200;
    private static final int STATUS_OK_CREATED = 201;
    private static final int STATUS_OK_ACCEPTED = 202;
    private static final int STATUS_OK_NO_CONTENT = 204;
    private static final int STATUS_NOT_FOUND = 404;

    private static final String PATTERN_DOMAIN = "network/([^\\/]*)";
    private static final String PATTERN_TOPOLOGY = "topology/(.*?)/vertex";
    private static final String PATTERN_VERTEX = "vertex/(.*?)/";
    private static final String PATTERN_VERTEX_URI_FROM_END = "(.*?)/end/(.*?)";
    private static final String PATTERN_CONNECTION = "connection/([^\\/]*)";

    private static final String SPLIT_ID = "/";
    private static final String EMPTY_ID = "1";

    private static final Logger LOGGER = LoggerFactory.getLogger( CommonWorker.class );

    /**
     * Hidden constructor
     */
    private CommonWorker() {}

    /**
     *
     * @param uri
     * @return
     */
    public static String toId(String uri) {
        String[] split = uri.split(SPLIT_ID);

        if(split.length > 0) {
            return split[split.length-1];
        }

        return "";
    }

    /**
     *
     * @param uri
     * @return
     */
    public static String getFromPattern(String strPattern, String uri) {
        Pattern pattern = Pattern.compile(strPattern);
        Matcher matcher = pattern.matcher(uri);
        if (matcher.find()) {
            return matcher.group(1);
        }

        return EMPTY_ID;
    }


    /**
     *
     * @param uri
     * @return
     */
    public static String toDomainId( String uri ) { return getFromPattern( PATTERN_DOMAIN, uri ); }

    /**
     *
     * @param uri
     * @return
     */
    public static String toTopologyId( String uri ) { return getFromPattern( PATTERN_TOPOLOGY, uri ); }

    /**
     *
     * @param uri
     * @return
     */
    public static String toConnectionId( String uri ) { return getFromPattern( PATTERN_CONNECTION, uri ); }

    /**
     *
     * @param uri
     * @return
     */
    public static String toVertexId( String uri ) {
        return getFromPattern( PATTERN_VERTEX, uri );
    }

    /**
     *
     * @param uri
     * @return
     */
    public static String toVertexUri( String uri ) {
        return getFromPattern( PATTERN_VERTEX_URI_FROM_END, uri );
    }

    /**
     *
     * @param proxy
     * @param function
     * @param <E>
     * @return
     */
    public static <E extends BaseObject> Function<String, ProcessableSingleResult<E, GenericErrorCode>> fromNetworkURIFunction(
        NetworkBaseClient<E> proxy,
        Function<Response, ProcessableSingleResult<E, GenericErrorCode>> function
    ) {
        return uri -> {
            // obtain parameters from uri
            String id = CommonWorker.toId(uri);
            String networkId = CommonWorker.toDomainId(uri);
            // request vertex from proxy
            Response response = proxy.get(networkId, id);
            return function.apply(response);
        };
    }

    /**
     *
     * @param proxy
     * @param function
     * @param <E>
     * @return
     */
    public static <E extends BaseObject> Function<String, ProcessableSingleResult<E, GenericErrorCode>> fromTopologyURIFunction(
        TopologyBaseClient<E> proxy,
        Function<Response, ProcessableSingleResult<E, GenericErrorCode>> function
    ) {
        return uri -> {
            // obtain parameters from uri
            String id = CommonWorker.toId(uri);
            String networkId = CommonWorker.toDomainId(uri);
            String topologyId = CommonWorker.toTopologyId(uri);
            // request vertex from proxy
            Response response = proxy.get(networkId, topologyId, id);
            return function.apply(response);
        };
    }

    /**
     *
     * @param proxy
     * @param function
     * @param <E>
     * @return
     */
    public static <E extends BaseObject> Function<String, ProcessableSingleResult<E, GenericErrorCode>> fromVertexURIFunction(
        VertexBaseClient<E> proxy,
        Function<Response, ProcessableSingleResult<E, GenericErrorCode>> function
    ) {
        return uri -> {
            // obtain parameters from uri
            String id = CommonWorker.toId(uri);
            String networkId = CommonWorker.toDomainId(uri);
            String topologyId = CommonWorker.toTopologyId(uri);
            String vertexId = CommonWorker.toVertexId(uri);
            // request vertex from proxy
            Response response = proxy.get(networkId, topologyId, vertexId, id);
            return function.apply(response);
        };
    }



    /**
     *
     * @return
     */
    public static <E extends BaseObject> Function<Response, ProcessableSingleResult<E, GenericErrorCode>> fromResponse(Class<E> type) {
        return response -> {
            switch (response.getStatus()){
                case STATUS_OK:
                case STATUS_OK_ACCEPTED:
                case STATUS_OK_CREATED:
                    E object = response.readEntity(type);
                    return new ProcessableSingleResult.Builder<E, GenericErrorCode>()
                        .ok(object)
                        .build();

                case STATUS_OK_NO_CONTENT:
                    return new ProcessableSingleResult.Builder<E, GenericErrorCode>()
                        .ok( null )
                        .build();

                case STATUS_NOT_FOUND:
                    return new ProcessableSingleResult.Builder<E, GenericErrorCode>()
                        .errorCode(GenericErrorCode.GENERIC)
                        .operationStatus(Status.NOT_FOUND)
                        .errorMessage("Entity not found.")
                        .build();

                default:
                    String errMsg = "Entity could not be retrieved.";

                    try {

                        SdnRestErrorObject err = response.readEntity( SdnRestErrorObject.class );

                        errMsg = err.getErrorDescription();
                    }
                    catch( Exception e ) {

                        LOGGER.error( "SDN error response format not recognised. " );
                        LOGGER.error( e.getMessage(), e );
                    }

                    return new ProcessableSingleResult.Builder<E, GenericErrorCode>()
                        .errorCode( GenericErrorCode.GENERIC )
                        .operationStatus( Status.SERVER_ERROR )
                        .errorMessage( errMsg )
                        .build();
            }
        };
    }

    /**
     *
     * @return
     */
    public static Function<Response, ProcessableSingleResult<Serializable, GenericErrorCode>> proccessDelete() {

        return response -> {
            switch ( response.getStatus() ) {

                case STATUS_OK:
                case STATUS_OK_ACCEPTED:
                    return new ProcessableSingleResult.Builder<Serializable, GenericErrorCode>()
                        .ok( null )
                        .build();

                case STATUS_NOT_FOUND:
                    return new ProcessableSingleResult.Builder<Serializable, GenericErrorCode>()
                        .errorCode( GenericErrorCode.GENERIC )
                        .operationStatus( Status.NOT_FOUND )
                        .errorMessage( "Entity not found." )
                        .build();

                default:
                    String errMsg = "Entity could not be retrieved.";

                    try {

                        SdnRestErrorObject err = response.readEntity( SdnRestErrorObject.class );

                        errMsg = err.getErrorDescription();
                    }
                    catch( Exception e ) {

                        LOGGER.error( "SDN error response format not recognised. " );
                        LOGGER.error( e.getMessage(), e );
                    }
                    return new ProcessableSingleResult.Builder<Serializable, GenericErrorCode>()
                        .errorCode( GenericErrorCode.GENERIC )
                        .operationStatus( Status.SERVER_ERROR )
                        .errorMessage( errMsg )
                        .build();
            }
        };
    }
}