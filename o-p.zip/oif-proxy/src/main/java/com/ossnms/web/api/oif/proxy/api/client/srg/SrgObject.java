package com.ossnms.web.api.oif.proxy.api.client.srg;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.Objects;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class SrgObject implements BaseObject {

    private static final long serialVersionUID = -1553936487394064191L;

    @JsonProperty(value = "id", required = true)
    private String id;

    @JsonProperty(value = "name", required = true)
    private String name;

    @JsonProperty(value = "coriant.riskClass", required = true)
    private String riskClass;

    @JsonProperty(value = "coriant.riskDefSource", required = true)
    private String riskDefSource;

    @JsonProperty(value = "coriant.riskId", required = true)
    private Long riskId;

    /**
     *
     */
    public String getId() {
        return id;
    }

    public SrgObject setId(String id) {
        this.id = id;
        return this;
    }

    /**
     *
     */
    public String getName() {
        return name;
    }

    public SrgObject setName(String name) {
        this.name = name;
        return this;
    }

    /**
     *
     */
    public String getRiskClass() {
        return riskClass;
    }

    public SrgObject setRiskClass(String riskClass) {
        this.riskClass = riskClass;
        return this;
    }

    /**
     *
     */
    public String getRiskDefSource() {
        return riskDefSource;
    }

    public SrgObject setRiskDefSource(String riskDefSource) {
        this.riskDefSource = riskDefSource;
        return this;
    }

    /**
     *
     */
    public Long getRiskId() {
        return riskId;
    }

    public SrgObject setRiskId(Long riskId) {
        this.riskId = riskId;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SrgObject srgObject = (SrgObject) o;
        return Objects.equals(getId(), srgObject.getId()) &&
            Objects.equals(getName(), srgObject.getName()) &&
            Objects.equals(getRiskClass(), srgObject.getRiskClass()) &&
            Objects.equals(getRiskDefSource(), srgObject.getRiskDefSource()) &&
            Objects.equals(getRiskId(), srgObject.getRiskId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getName(), getRiskClass(), getRiskDefSource(), getRiskId());
    }
}
