package com.ossnms.web.api.oif.proxy.api.client.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class TrafficParamObject implements BaseObject {

    private static final long serialVersionUID = -5662199222424502090L;

    //trafficParam_ietfIntServ.tokenRate
    //trafficParam_ietfIntServ.tokenSize
    //trafficParam_ietfIntServ.peekBw
    //trafficParam_ietfIntServ.minPolicedUnit
    //trafficParam_ietfIntServ.maxPacketSize

    @JsonProperty( "ietfGMPLS.sigType" )
    private String sigType;

    //trafficParam_ietfGMPLS.nmc
    //trafficParam_ietfGMPLS.nvc

    @JsonProperty( "ietfGMPLS.multiplier" )
    private String multiplier;

    @JsonProperty( "ietfGMPLS.bandwidth" )
    private String bandwidth;

    //trafficParam_ogfNsi.symmetricPath
    //trafficParam_ogfNsi.parameterList
    //trafficParam_callDiversity
    //trafficParam_routeGroupInfoList_connId
    //trafficParam_routeGroupInfoList_routeGroupLabel
    //trafficParam_connectionRouteReArrangementAllowed
    //trafficParam_routeGroupsNumber

    /**
     *
     * @return
     */
    public String getSigType() {

        return sigType;
    }

    /**
     *
     * @param sigType
     * @return
     */
    public TrafficParamObject setSigType( String sigType ) {

        this.sigType = sigType;
        return this;
    }

    /**
     *
     * @return
     */
    public String getMultiplier() {

        return multiplier;
    }

    /**
     *
     * @param multiplier
     * @return
     */
    public TrafficParamObject setMultiplier( String multiplier ) {

        this.multiplier = multiplier;
        return this;
    }

    /**
     *
     * @return
     */
    public String getBandwidth() {

        return bandwidth;
    }

    /**
     *
     * @param bandwidth
     * @return
     */
    public TrafficParamObject setBandwidth( String bandwidth ) {

        this.bandwidth = bandwidth;
        return this;
    }
}