package com.ossnms.web.api.oif.proxy.api.client.call;

import com.ossnms.web.api.oif.proxy.api.common.util.SdnUtils;
import com.ossnms.web.provider.sdn.model.call.Call;
import com.ossnms.web.provider.sdn.model.call.CallID;
import com.ossnms.web.provider.sdn.model.call.ProtectionGroup;
import com.ossnms.web.provider.sdn.model.call.SLA;

import java.util.Arrays;
import java.util.List;

/**
 * Created by 68500245 on 10-01-2017.
 */
public final class CallObjectFactory {

    private static final String RESTORATION = "Restoration";

    private CallObject callObject = new CallObject();

    /**
     * @return
     */
    public CallObject build() {

        return callObject;
    }



    /**
     * @param callID
     * @return
     */
    public CallObjectFactory from( CallID callID ) {

        if ( callID != null ) {

            callObject.setDomainId( callID.getDomainId() );
            callObject.setId( callID.getID() );
        }

        return this;
    }

    /**
     * @param call
     * @return
     */
    public CallObjectFactory fromForUpdate( Call call ) {

        from( call.getID() );

        callObject.setName( call.getName() );

        callObject.setAdminStatus( call.getAdminStatus() );
        callObject.setCallConfigStatus( call.getCallConfigStatus() );

        setSLAAttributes( call );

        // callObject.setSchedule

        setRestorationAttributes( call );

        return this;
    }

    /**
     * @param call
     * @return
     */
    public CallObjectFactory fromForCreate( Call call ) {

        callObject.setName( call.getName() );

        callObject.setPathRequestId( call.getPathRequestId() );

        if ( call.getAEnd() != null ) {

            callObject.setaEnd( new String[]{ SdnUtils.buildEndpointUri( call.getAEnd().getID().getDomainId(), call.getAEnd().getID().getID() ) } );
        }
        if ( call.getZEnd() != null  ) {

            callObject.setzEnd( new String[]{ SdnUtils.buildEndpointUri( call.getZEnd().getID().getDomainId(), call.getZEnd().getID().getID() ) } );
        }

        callObject.setAdminStatus( call.getAdminStatus() );
        callObject.setCallConfigStatus( call.getCallConfigStatus() );

        callObject.setDirectionality( call.getDirectionality() );

        // callObject.setConstraints
        callObject.setRoutingOverEnabledResourcesOnly( call.getRoutingOverEnabledResourcesOnly() );
        callObject.setRoutingOverExistingServicesOnly( call.getRoutingOverExistingServicesOnly() );
        callObject.setRoutingOverNotReservedResourcesOnly( call.getRoutingOverNotReservedResourcesOnly() );

        callObject.setOrderNumber( call.getOrderNumber() );

        setSLAAttributes( call );

        // callObject.setSchedule

        setRestorationAttributes( call  );

        return this;
    }

    /**
     *
     * @param protectionGroups
     * @return
     */
    private static ProtectionGroupObject buildRestorationProtectionGroupFrom( List<ProtectionGroup> protectionGroups ) {

        return protectionGroups.stream()
            .filter( item -> RESTORATION.equalsIgnoreCase( item.getProtectionType() ) )
            .map( item -> {

                ProtectionGroupObject protectionGroup = new ProtectionGroupObject();

                protectionGroup.setProtectionMode( item.getProtectionMode() );
                protectionGroup.setRestorationGate( item.getRestorationGate() );

                return protectionGroup;
            } )
            .findFirst()
            .orElse( null );
    }

    /**
     *
     * @param call
     */
    private void setSLAAttributes( Call call ) {

        SLA callSLA = call.getSla();

        if ( callSLA != null  ) {

            SLAObject sla = new SLAObject();

            sla.SLAMonitoring = call.getSla().isSLAMonitoring();
            sla.throughput = call.getSla().getThroughput();
            callObject.setSla( sla );
        }
    }

    /**
     *
     * @param call
     */
    private void setRestorationAttributes( Call call ) {

        callObject.setRestorable( call.isRestorable() );

        if ( call.isRestorable() != null && call.isRestorable() && call.getProtectionGroups() != null ) {

            ProtectionGroupObject restoration = buildRestorationProtectionGroupFrom( call.getProtectionGroups() );

            if ( restoration != null ) {

                callObject.setProtectionGroups( Arrays.asList( new ProtectionGroupObject[] { restoration } ) );
            }
        }
    }
}