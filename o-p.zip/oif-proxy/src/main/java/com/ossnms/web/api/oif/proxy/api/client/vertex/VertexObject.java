package com.ossnms.web.api.oif.proxy.api.client.vertex;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.Objects;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class VertexObject implements BaseObject {

    private static final long serialVersionUID = -8109319753217206253L;

    @JsonProperty(value = "id", required = true)
    private String id;

    @JsonProperty(value = "name", required = true)
    private String name;

    @JsonProperty(value = "coriant.emsName", required = true)
    private String emsName;

    @JsonProperty(value = "coriant.VertexIdentifiers", required = true)
    private VertexIdentifierObject vertexIdentifier;

    /**
     *
     */
    public String getId() {
        return id;
    }

    public VertexObject setId(String id) {
        this.id = id;
        return this;
    }

    /**
     *
     */
    public String getName() {
        return name;
    }

    public VertexObject setName(String name) {
        this.name = name;
        return this;
    }

    /**
     *
     */
    public String getEmsName() {
        return emsName;
    }

    public VertexObject setEmsName(String emsName) {
        this.emsName = emsName;
        return this;
    }

    /**
     *
     */
    public VertexIdentifierObject getVertexIdentifier() {
        return vertexIdentifier;
    }

    public VertexObject setVertexIdentifier(VertexIdentifierObject vertexIdentifier) {
        this.vertexIdentifier = vertexIdentifier;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        VertexObject that = (VertexObject) o;
        return Objects.equals(getId(), that.getId()) &&
            Objects.equals(getName(), that.getName()) &&
            Objects.equals(getEmsName(), that.getEmsName()) &&
            Objects.equals(getVertexIdentifier(), that.getVertexIdentifier());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getName(), getEmsName(), getVertexIdentifier());
    }
}
