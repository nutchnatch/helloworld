package com.ossnms.web.api.oif.proxy.api.client.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.Objects;

/**
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LayerAttributeObject implements BaseObject {

    private static final long serialVersionUID = -2050035812421700422L;

    @JsonProperty("ietfGMPLS.switchingType")
	private int switchingType;

	@JsonProperty("ietfGMPLS.encoding")
	private int encoding;

	@JsonProperty("ietfASON.sigType")
	private int sigType;

	@JsonProperty("ietfASON.adaptation")
	private int adaptation;

	@JsonProperty("coriant.portMode")
	private String portMode;

	@JsonProperty("coriant.layerId")
	private int layerId;

	@JsonProperty("ietfGMPLS.bandwidth")
	private int bandwidth;

    @JsonProperty("coriant.minBitrate")
    private Long minBitrate;

    @JsonProperty("coriant.maxBitrate")
    private Long maxBitrate;

    @JsonProperty("coriant.currentConfiguration")
    private Boolean currentConfiguration;

    @JsonProperty("coriant.endPoint")
    private String endPoint;

    /**
     *
     */
    public int getSwitchingType() {
        return switchingType;
    }

    public LayerAttributeObject setSwitchingType(int switchingType) {
        this.switchingType = switchingType;
        return this;
    }

    /**
     *
     */
    public int getEncoding() {
        return encoding;
    }

    public LayerAttributeObject setEncoding(int encoding) {
        this.encoding = encoding;
        return this;
    }

    /**
     *
     */
    public int getSigType() {
        return sigType;
    }

    public LayerAttributeObject setSigType(int sigType) {
        this.sigType = sigType;
        return this;
    }

    /**
     *
     */
    public int getAdaptation() {
        return adaptation;
    }

    public LayerAttributeObject setAdaptation(int adaptation) {
        this.adaptation = adaptation;
        return this;
    }

    /**
     *
     */
    public String getPortMode() {
        return portMode;
    }

    public LayerAttributeObject setPortMode(String portMode) {
        this.portMode = portMode;
        return this;
    }

    /**
     *
     */
    public int getLayerId() {
        return layerId;
    }

    public LayerAttributeObject setLayerId(int layerId) {
        this.layerId = layerId;
        return this;
    }

    /**
     *
     */
    public int getBandwidth() {
        return bandwidth;
    }

    public LayerAttributeObject setBandwidth(int bandwidth) {
        this.bandwidth = bandwidth;
        return this;
    }

    /**
     *
     */
    public Long getMinBitrate() {
        return minBitrate;
    }

    public LayerAttributeObject setMinBitrate(Long minBitrate) {
        this.minBitrate = minBitrate;
        return this;
    }

    /**
     *
     */
    public Long getMaxBitrate() {
        return maxBitrate;
    }

    public LayerAttributeObject setMaxBitrate(Long maxBitrate) {
        this.maxBitrate = maxBitrate;
        return this;
    }

    /**
     *
     */
    public Boolean getCurrentConfiguration() {
        return currentConfiguration;
    }

    public LayerAttributeObject setCurrentConfiguration(Boolean currentConfiguration) {
        this.currentConfiguration = currentConfiguration;
        return this;
    }

    /**
     *
     */
    public String getEndPoint() {
        return endPoint;
    }

    public LayerAttributeObject setEndPoint(String endPoint) {
        this.endPoint = endPoint;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        LayerAttributeObject that = (LayerAttributeObject) o;
        return getSwitchingType() == that.getSwitchingType() &&
            getEncoding() == that.getEncoding() &&
            getSigType() == that.getSigType() &&
            getAdaptation() == that.getAdaptation() &&
            getLayerId() == that.getLayerId() &&
            getBandwidth() == that.getBandwidth() &&
            Objects.equals(getPortMode(), that.getPortMode()) &&
            Objects.equals(getMinBitrate(), that.getMinBitrate()) &&
            Objects.equals(getMaxBitrate(), that.getMaxBitrate()) &&
            Objects.equals(getCurrentConfiguration(), that.getCurrentConfiguration()) &&
            Objects.equals(getEndPoint(), that.getEndPoint());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getSwitchingType(), getEncoding(), getSigType(), getAdaptation(), getPortMode(), getLayerId(), getBandwidth(), getMinBitrate(), getMaxBitrate(), getCurrentConfiguration(), getEndPoint());
    }
}