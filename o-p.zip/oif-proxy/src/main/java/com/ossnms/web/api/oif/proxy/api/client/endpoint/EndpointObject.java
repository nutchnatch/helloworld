package com.ossnms.web.api.oif.proxy.api.client.endpoint;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.client.common.EndIdentifierObject;
import com.ossnms.web.api.oif.proxy.api.client.common.LayerAttributeObject;
import com.ossnms.web.api.oif.proxy.api.client.common.SrgDetailObject;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.List;
import java.util.Objects;


/**
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EndpointObject implements BaseObject {

    private static final long serialVersionUID = 883987648050340763L;

    @JsonProperty(value = "id", required = true)
	private String id;

	@JsonProperty(value = "name", required = true)
	private String name;

	@JsonProperty(value = "topoComponent", required = true)
	private String topoComponent;

	@JsonProperty(value = "coriant.EndIdentifiers", required = true)
	private EndIdentifierObject endIdentifierObject;

	@JsonProperty(value = "coriant.srgDetail", required = true)
	private List<SrgDetailObject> srgDetailObjects;

	@JsonProperty(value = "coriant.provisioningStatus", required = true)
	private String provisioningStatus;

	@JsonProperty(value = "coriant.networkSyncStatus", required = true)
	private String networkSyncStatus;

	@JsonProperty(value = "oifENNIv2.layerAttrib", required = true)
	private LayerAttributeObject layerAttributeObject;

    /**
     *
     * @return
     */
	public String getId() {
		return id;
	}

    /**
     *
     * @param id
     */
	public void setId(String id) {
		this.id = id;
	}

    /**
     *
     * @return
     */
	public String getName() {
		return name;
	}

    /**
     *
     * @param name
     */
	public void setName(String name) {
		this.name = name;
	}

    /**
     *
     * @return
     */
	public String getTopoComponent() {
		return topoComponent;
	}

    /**
     *
     * @param topoComponent
     */
	public void setTopoComponent(String topoComponent) {
		this.topoComponent = topoComponent;
	}

    /**
     *
     * @return
     */
	public EndIdentifierObject getEndIdentifierObject() {
		return endIdentifierObject;
	}

    /**
     *
     * @param endIdentifierObject
     */
	public void setEndIdentifierObject(EndIdentifierObject endIdentifierObject) {
		this.endIdentifierObject = endIdentifierObject;
	}

    /**
     *
     * @return
     */
	public List<SrgDetailObject> getSrgDetailObjects() {
		return srgDetailObjects;
	}

    /**
     *
     * @param srgDetailObjects
     */
	public void setSrgDetailObjects(List<SrgDetailObject> srgDetailObjects) {
		this.srgDetailObjects = srgDetailObjects;
	}

    /**
     *
     * @return
     */
	public String getProvisioningStatus() {
		return provisioningStatus;
	}

    /**
     *
     * @param provisioningStatus
     */
	public void setProvisioningStatus(String provisioningStatus) {
		this.provisioningStatus = provisioningStatus;
	}

    /**
     *
     * @return
     */
	public String getNetworkSyncStatus() {
		return networkSyncStatus;
	}

    /**
     *
     * @param networkSyncStatus
     */
	public void setNetworkSyncStatus(String networkSyncStatus) {
		this.networkSyncStatus = networkSyncStatus;
	}

    /**
     *
     * @return
     */
	public LayerAttributeObject getLayerAttributeObject() {
		return layerAttributeObject;
	}

    /**
     *
     * @param layerAttributeObject
     */
	public void setLayerAttributeObject(LayerAttributeObject layerAttributeObject) {
		this.layerAttributeObject = layerAttributeObject;
	}

	@Override
	public String toString() {
		return "EndpointObject [id=" + id + ", name=" + name + ", topoComponent=" + topoComponent
				+ ", endIdentifierObject=" + endIdentifierObject + ", srgDetailObjects=" + srgDetailObjects
				+ ", provisioningStatus=" + provisioningStatus + ", networkSyncStatus=" + networkSyncStatus
				+ ", layerAttributeObject=" + layerAttributeObject + "]";
	}

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        EndpointObject that = (EndpointObject) o;
        return Objects.equals(getId(), that.getId()) &&
            Objects.equals(getName(), that.getName()) &&
            Objects.equals(getTopoComponent(), that.getTopoComponent()) &&
            Objects.equals(getEndIdentifierObject(), that.getEndIdentifierObject()) &&
            Objects.equals(getSrgDetailObjects(), that.getSrgDetailObjects()) &&
            Objects.equals(getProvisioningStatus(), that.getProvisioningStatus()) &&
            Objects.equals(getNetworkSyncStatus(), that.getNetworkSyncStatus()) &&
            Objects.equals(getLayerAttributeObject(), that.getLayerAttributeObject());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getName(), getTopoComponent(), getEndIdentifierObject(), getSrgDetailObjects(), getProvisioningStatus(), getNetworkSyncStatus(), getLayerAttributeObject());
    }
}