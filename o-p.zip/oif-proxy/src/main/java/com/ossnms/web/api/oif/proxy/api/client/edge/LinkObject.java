package com.ossnms.web.api.oif.proxy.api.client.edge;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.List;
import java.util.Objects;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class LinkObject implements BaseObject {

    private static final long serialVersionUID = 1887996945391020892L;

    @JsonProperty(value = "onfOtwgIm.layerList", required = true)
    private List<String> layerList;

    /**
     *
     */
    public List<String> getLayerList() {
        return layerList;
    }

    public LinkObject setLayerList(List<String> layerList) {
        this.layerList = layerList;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LinkObject that = (LinkObject) o;
        return Objects.equals(getLayerList(), that.getLayerList());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getLayerList());
    }
}
