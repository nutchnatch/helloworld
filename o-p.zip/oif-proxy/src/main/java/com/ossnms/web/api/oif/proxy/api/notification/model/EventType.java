package com.ossnms.web.api.oif.proxy.api.notification.model;

/**
 *
 */
public enum EventType {
    CREATE,
    MODIFY,
    DELETE,
    PRE_CONDITION_FAILURE,
    CREATE_BULK,
    MODIFY_BULK,
    DELETE_BULK
}
