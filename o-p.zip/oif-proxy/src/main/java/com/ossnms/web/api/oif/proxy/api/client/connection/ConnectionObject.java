package com.ossnms.web.api.oif.proxy.api.client.connection;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.client.common.SrgDetailObject;
import com.ossnms.web.api.oif.proxy.api.client.common.TrafficParamObject;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.List;
import java.util.Objects;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class ConnectionObject implements BaseObject {

    private static final long serialVersionUID = 8746844849155966690L;

    @JsonProperty(value = "id")
    private String id;

    @JsonProperty(value = "name")
    private String name;

    @JsonProperty(value = "adminStatus")
    private String adminStatus;

    @JsonProperty(value = "operStatus")
    private String operStatus;

    @JsonProperty(value = "trafficParam")
    private TrafficParamObject trafficParam;

    @JsonProperty(value="coriant.provisioningStatus")
    private String provisioningStatus;

    @JsonProperty(value="coriant.frequency")
    private Long frequency;

    @JsonProperty(value="coriant.freqSlotWidth")
    private Long freqSlotWidth;

    @JsonProperty(value="coriant.networkSyncStatus")
    private String networkSyncStatus;

    @JsonProperty(value="ietfGMPLS.switchingType")
    private Integer switchingType;

    @JsonProperty(value="ietfGMPLS.encoding")
    private Integer encoding;

    @JsonProperty(value="ietfGMPLS.directionality")
    private String directionality;

    @JsonProperty(value="coriant.srgDetail")
    private List<SrgDetailObject> srgDetails;

    @JsonProperty(value = "aEnd")
    private String aEnd;

    @JsonProperty(value = "zEnd")
    private String zEnd;

    @JsonProperty(value = "path")
    private List<TopoComponentObject> path;


    /**
     *
     * @return
     */
    public String getId() {

        return id;
    }

    /**
     *
     * @param id
     */
    public void setId( String id ) {

        this.id = id;
    }

    /**
     *
     * @return
     */
    public String getName() {

        return name;
    }

    /**
     *
     * @param name
     */
    public void setName( String name ) {

        this.name = name;
    }

    /**
     *
     * @return
     */
    public String getAdminStatus() {

        return adminStatus;
    }

    /**
     *
     * @param adminStatus
     */
    public void setAdminStatus( String adminStatus ) {

        this.adminStatus = adminStatus;
    }

    /**
     *
     * @return
     */
    public String getOperStatus() {

        return operStatus;
    }

    /**
     *
     * @param operStatus
     */
    public void setOperStatus( String operStatus ) {

        this.operStatus = operStatus;
    }

    /**
     *
     * @return
     */
    public TrafficParamObject getTrafficParam() {

        return trafficParam;
    }

    /**
     *
     * @param trafficParam
     */
    public void setTrafficParam( TrafficParamObject trafficParam ) {

        this.trafficParam = trafficParam;
    }

    /**
     *
     * @return
     */
    public String getProvisioningStatus() {

        return provisioningStatus;
    }

    /**
     *
     * @param provisioningStatus
     */
    public void setProvisioningStatus( String provisioningStatus ) {

        this.provisioningStatus = provisioningStatus;
    }

    /**
     *
     * @return
     */
    public Long getFrequency() {

        return frequency;
    }

    /**
     *
     * @param frequency
     */
    public void setFrequency( Long frequency ) {

        this.frequency = frequency;
    }

    /**
     *
     * @return
     */
    public Long getFreqSlotWidth() {

        return freqSlotWidth;
    }

    /**
     *
     * @param freqSlotWidth
     */
    public void setFreqSlotWidth( Long freqSlotWidth ) {

        this.freqSlotWidth = freqSlotWidth;
    }

    /**
     *
     * @return
     */
    public String getNetworkSyncStatus() {

        return networkSyncStatus;
    }

    /**
     *
     * @param networkSyncStatus
     */
    public void setNetworkSyncStatus( String networkSyncStatus ) {

        this.networkSyncStatus = networkSyncStatus;
    }

    /**
     *
     * @return
     */
    public Integer getSwitchingType() {

        return switchingType;
    }

    /**
     *
     * @param switchingType
     */
    public void setSwitchingType( Integer switchingType ) {

        this.switchingType = switchingType;
    }

    /**
     *
     * @return
     */
    public Integer getEncoding() {

        return encoding;
    }

    /**
     *
     * @param encoding
     */
    public void setEncoding( Integer encoding ) {

        this.encoding = encoding;
    }

    /**
     *
     * @return
     */
    public String getDirectionality() {

        return directionality;
    }

    /**
     *
     * @param directionality
     */
    public void setDirectionality( String directionality ) {

        this.directionality = directionality;
    }

    /**
     *
     * @return
     */
    public List<SrgDetailObject> getSrgDetails() {

        return srgDetails;
    }

    /**
     *
     * @param srgDetails
     */
    public void setSrgDetails( List<SrgDetailObject> srgDetails ) {

        this.srgDetails = srgDetails;
    }

    /**
     *
     * @return
     */
    public String getAEnd() {

        return aEnd;
    }

    /**
     *
     * @param aEnd
     */
    public void setAEnd( String aEnd ) {

        this.aEnd = aEnd;
    }

    /**
     *
     * @return
     */
    public String getZEnd() {

        return zEnd;
    }

    /**
     *
     * @param zEnd
     */
    public void setZEnd( String zEnd ) {

        this.zEnd = zEnd;
    }

    /**
     *
     * @return
     */
    public List<TopoComponentObject> getPath() {

        return path;
    }

    /**
     *
     * @param path
     */
    public void setPath( List<TopoComponentObject> path ) {

        this.path = path;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        ConnectionObject that = (ConnectionObject) o;
        return Objects.equals(getId(), that.getId()) &&
               Objects.equals(getAdminStatus(), that.getAdminStatus()) &&
               Objects.equals(getOperStatus(), that.getOperStatus()) &&
               Objects.equals(getTrafficParam(), that.getTrafficParam()) &&
               Objects.equals(getProvisioningStatus(), that.getProvisioningStatus()) &&
               Objects.equals(getFrequency(), that.getFrequency()) &&
               Objects.equals(getFreqSlotWidth(), that.getFreqSlotWidth()) &&
               Objects.equals(getNetworkSyncStatus(), that.getNetworkSyncStatus()) &&
               Objects.equals(getSwitchingType(), that.getSwitchingType()) &&
               Objects.equals(getEncoding(), that.getEncoding()) &&
               Objects.equals(getDirectionality(), that.getDirectionality()) &&
               Objects.equals( getSrgDetails(), that.getSrgDetails()) &&
               Objects.equals( aEnd, that.aEnd ) &&
               Objects.equals( zEnd, that.zEnd );
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getAdminStatus(), getOperStatus(), getTrafficParam(), getProvisioningStatus(), getFrequency(), getFreqSlotWidth(), getNetworkSyncStatus(), getSwitchingType(), getEncoding(), getDirectionality(), getSrgDetails(), aEnd, zEnd );
    }
}