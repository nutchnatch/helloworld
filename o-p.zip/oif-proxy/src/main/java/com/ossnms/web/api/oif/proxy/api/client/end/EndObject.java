package com.ossnms.web.api.oif.proxy.api.client.end;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.client.common.ActualLayerObject;
import com.ossnms.web.api.oif.proxy.api.client.common.EndIdentifierObject;
import com.ossnms.web.api.oif.proxy.api.client.common.LayerAttributeObject;
import com.ossnms.web.api.oif.proxy.api.client.common.SrgDetailObject;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.List;
import java.util.Objects;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class EndObject implements BaseObject{

    private static final long serialVersionUID = 512859536741477676L;

    @JsonProperty(value = "id", required = true)
    private String id;

    @JsonProperty(value = "name", required = true)
    private String name;

    @JsonProperty(value = "vertex", required = true)
    private String vertex;

    @JsonProperty(value = "coriant.EndIdentifiers", required = true)
    private EndIdentifierObject endIdentifierObject;

    @JsonProperty(value = "coriant.ownership", required = true)
    private String ownership;

    @JsonProperty(value = "coriant.srgDetail", required = true)
    private List<SrgDetailObject> srgDetailObjects;

    @JsonProperty(value = "onfOtwgIm.LTP", required = true)
    private LTPObject LTP;

    @JsonProperty(value = "coriant.networkSyncStatus", required = true)
    private String networkSyncStatus;

    @JsonProperty(value = "coriant.actualLayer", required = true)
    private List<ActualLayerObject> actualLayerObjects;

    @JsonProperty(value = "oifENNIv2.layerAttrib", required = true)
    private List<LayerAttributeObject> layerAttributeObjects;

    @JsonProperty(value = "edge", required = true)
    private List<String> edgeIds;

    /**
     *
     */
    public String getId() {
        return id;
    }

    public EndObject setId(String id) {
        this.id = id;
        return this;
    }

    /**
     *
     */
    public String getName() {
        return name;
    }

    public EndObject setName(String name) {
        this.name = name;
        return this;
    }

    /**
     *
     */
    public String getVertex() {
        return vertex;
    }

    public EndObject setVertex(String vertex) {
        this.vertex = vertex;
        return this;
    }

    /**
     *
     */
    public EndIdentifierObject getEndIdentifierObject() {
        return endIdentifierObject;
    }

    public EndObject setEndIdentifierObject(EndIdentifierObject endIdentifierObject) {
        this.endIdentifierObject = endIdentifierObject;
        return this;
    }

    /**
     *
     */
    public String getOwnership() {
        return ownership;
    }

    public EndObject setOwnership(String ownership) {
        this.ownership = ownership;
        return this;
    }

    /**
     *
     */
    public List<SrgDetailObject> getSrgDetailObjects() {
        return srgDetailObjects;
    }

    public EndObject setSrgDetailObjects(List<SrgDetailObject> srgDetailObjects) {
        this.srgDetailObjects = srgDetailObjects;
        return this;
    }

    /**
     *
     */
    public String getNetworkSyncStatus() {
        return networkSyncStatus;
    }

    public EndObject setNetworkSyncStatus(String networkSyncStatus) {
        this.networkSyncStatus = networkSyncStatus;
        return this;
    }

    /**
     *
     */
    public List<ActualLayerObject> getActualLayerObjects() {
        return actualLayerObjects;
    }

    public EndObject setActualLayerObjects(List<ActualLayerObject> actualLayerObjects) {
        this.actualLayerObjects = actualLayerObjects;
        return this;
    }

    /**
     *
     */
    public List<LayerAttributeObject> getLayerAttributeObjects() {
        return layerAttributeObjects;
    }

    public EndObject setLayerAttributeObjects(List<LayerAttributeObject> layerAttributeObjects) {
        this.layerAttributeObjects = layerAttributeObjects;
        return this;
    }

    /**
     *
     */
    public List<String> getEdgeIds() {
        return edgeIds;
    }

    public EndObject setEdgeIds(List<String> edgeIds) {
        this.edgeIds = edgeIds;
        return this;
    }

    /**
     *
     * @return
     */
    public LTPObject getLTP() {

        return LTP;
    }

    /**
     *
     * @param LTP
     * @return
     */
    public EndObject setLTP( LTPObject LTP ) {

        this.LTP = LTP;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        EndObject endObject = (EndObject) o;
        return Objects.equals(getId(), endObject.getId()) &&
            Objects.equals(getName(), endObject.getName()) &&
            Objects.equals(getVertex(), endObject.getVertex()) &&
            Objects.equals(getEndIdentifierObject(), endObject.getEndIdentifierObject()) &&
            Objects.equals(getOwnership(), endObject.getOwnership()) &&
            Objects.equals(getSrgDetailObjects(), endObject.getSrgDetailObjects()) &&
            Objects.equals(getNetworkSyncStatus(), endObject.getNetworkSyncStatus()) &&
            Objects.equals(getActualLayerObjects(), endObject.getActualLayerObjects()) &&
            Objects.equals(getLayerAttributeObjects(), endObject.getLayerAttributeObjects()) &&
            Objects.equals(getEdgeIds(), endObject.getEdgeIds()) &&
            Objects.equals(getLTP(), endObject.getLTP());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getName(), getVertex(), getEndIdentifierObject(), getOwnership(), getSrgDetailObjects(), getNetworkSyncStatus(), getActualLayerObjects(), getLayerAttributeObjects(), getEdgeIds(), getLTP());
    }

    @Override
    public String toString() {
        return "EndObject{" +
            "name='" + name + '\'' +
            '}';
    }
}