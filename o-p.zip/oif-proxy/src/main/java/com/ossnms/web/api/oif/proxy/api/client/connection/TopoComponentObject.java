package com.ossnms.web.api.oif.proxy.api.client.connection;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.Objects;

/**
 *
 */
public class TopoComponentObject implements BaseObject {

    private static final long serialVersionUID = -7654831307925847266L;

    @JsonProperty(value = "topoComponent", required = true)
    private String topoComponent;

    /**
     *
     * @return
     */
    public String getTopoComponent() {

        return topoComponent;
    }

    /**
     *
     * @param topoComponent
     */
    public void setTopoComponent( String topoComponent ) {

        this.topoComponent = topoComponent;
    }

    @Override
    public boolean equals( Object o ) {

        if ( this == o ) {
            return true;
        }
        if ( o == null || getClass() != o.getClass() ) {
            return false;
        }
        TopoComponentObject that = (TopoComponentObject) o;
        return Objects.equals( topoComponent, that.topoComponent );
    }

    @Override
    public int hashCode() {

        return Objects.hash( topoComponent );
    }
}