package com.ossnms.web.api.oif.proxy.api.client.call;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.Objects;

/**
 * Created by 68500245 on 31-01-2017.
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class ProtectionGroupObject implements BaseObject {

    private static final long serialVersionUID = -2437896493336863131L;


    @JsonProperty
    private String id;

    @JsonProperty( "coriant.protectionMode" )
    private String protectionMode;

    @JsonProperty( "coriant.protectionState" )
    private String protectionState;

    @JsonProperty( "coriant.protectionType" )
    private String protectionType;

    @JsonProperty( "coriant.restorationGate" )
    private String restorationGate;


    /**
     *
     * @return
     */
    public String getId() {

        return id;
    }

    /**
     *
     * @param id
     */
    public void setId( String id ) {

        this.id = id;
    }

    /**
     *
     * @return
     */
    public String getProtectionMode() {

        return protectionMode;
    }

    /**
     *
     * @param protectionMode
     */
    public void setProtectionMode( String protectionMode ) {

        this.protectionMode = protectionMode;
    }

    /**
     *
     * @return
     */
    public String getProtectionState() {

        return protectionState;
    }

    /**
     *
     * @param protectionState
     */
    public void setProtectionState( String protectionState ) {

        this.protectionState = protectionState;
    }

    /**
     *
     * @return
     */
    public String getProtectionType() {

        return protectionType;
    }

    /**
     *
     * @param protectionType
     */
    public void setProtectionType( String protectionType ) {

        this.protectionType = protectionType;
    }

    /**
     *
     * @return
     */
    public String getRestorationGate() {

        return restorationGate;
    }

    /**
     *
     * @param restorationGate
     */
    public void setRestorationGate( String restorationGate ) {

        this.restorationGate = restorationGate;
    }

    /**
     *
     * @param o
     * @return
     */
    @Override
    public boolean equals( Object o ) {

        if ( this == o ) {
            return true;
        }
        if ( o == null || getClass() != o.getClass() ) {
            return false;
        }
        ProtectionGroupObject that = (ProtectionGroupObject) o;
        return Objects.equals( id, that.id ) &&
               Objects.equals( protectionMode, that.protectionMode ) &&
               Objects.equals( protectionState, that.protectionState ) &&
               Objects.equals( protectionType, that.protectionType ) &&
               Objects.equals( restorationGate, that.restorationGate );
    }

    /**
     *
     * @return
     */
    @Override
    public int hashCode() {

        return Objects.hash( id, protectionMode, protectionState, protectionType, restorationGate );
    }
}