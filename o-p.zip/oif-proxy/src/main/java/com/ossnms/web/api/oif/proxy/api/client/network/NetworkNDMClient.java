package com.ossnms.web.api.oif.proxy.api.client.network;

import com.ossnms.web.api.oif.proxy.api.common.BaseClient;

import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import static com.ossnms.web.api.oif.proxy.api.common.OIFProxyConstant.URL_NDM_NETWORK;

/**
 *
 */
@Path(URL_NDM_NETWORK)
@Consumes("application/json")
@Produces("application/json")
public interface NetworkNDMClient extends BaseClient<NetworkObject> {

}
