package com.ossnms.web.api.oif.proxy.api.notification.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class InboundNotification {

    @JsonProperty(value = "eventType")
    private EventType eventType;

    @JsonProperty(value = "entityType")
    private EntityType entityType;

    /**
     *
     */
    public EventType getEventType() {
        return eventType;
    }

    public InboundNotification setEventType(EventType eventType) {
        this.eventType = eventType;
        return this;
    }

    /**
     *
     */
    public EntityType getEntityType() {
        return entityType;
    }

    public InboundNotification setEntityType(EntityType entityType) {
        this.entityType = entityType;
        return this;
    }

    @Override
    public String toString() {
        return "InboundNotification{" +
            "eventType=" + eventType +
            ", entityType=" + entityType +
            '}';
    }
}
