package com.ossnms.web.api.oif.proxy.impl.network;

import com.ossnms.web.api.oif.proxy.api.client.network.NetworkNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.network.NetworkObject;
import com.ossnms.web.api.oif.proxy.api.client.network.NetworkObjectList;
import com.ossnms.web.api.oif.proxy.api.common.util.SdnUtils;
import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.filter.FilterOperation;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.sdn.api.annotation.Proxy;
import com.ossnms.web.provider.sdn.model.network.Network;
import com.ossnms.web.provider.sdn.model.network.NetworkField;
import com.ossnms.web.provider.sdn.model.network.NetworkID;
import com.ossnms.web.provider.sdn.model.network.NetworkSummary;
import com.ossnms.web.provider.sdn.operations.network.NetworkEntityOperations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.ProcessingException;
import javax.ws.rs.core.Response;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import static javax.ws.rs.core.Response.Status.CREATED;
import static javax.ws.rs.core.Response.Status.NO_CONTENT;
import static javax.ws.rs.core.Response.Status.OK;

/**
 *
 */
@RequestScoped
public class NetworkOperationsProxyImpl implements NetworkEntityOperations {

    private static final Logger LOGGER = LoggerFactory.getLogger(NetworkOperationsProxyImpl.class);

    private NetworkNDMClient instance;

    /**
     * Default no-args constructor
     */
    public NetworkOperationsProxyImpl() {
    }

    @Inject
    public NetworkOperationsProxyImpl(@Proxy NetworkNDMClient instance) {
        this.instance = instance;
    }

    /**
     * @param id
     * @return
     */
    private NetworkObject getNetworkObject(NetworkID id) {
        Response response = instance.get(id.getID());

        if (response.getStatus() == OK.getStatusCode()) {
            NetworkObject domain = response.readEntity(NetworkObject.class);
            domain.id = SdnUtils.extractId(domain.id);
            return domain;
        }

        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NetworkID insert(SecurityToken securityToken, Network entity) {
        NetworkObject newDomain = new NetworkObject();

        newDomain.id = entity.getID() != null ? entity.getID().getID() : null;
        newDomain.name = entity.getName();
        newDomain.userDomain = entity.getUserDomain();
        newDomain.topologyType = entity.getTopologyType();
        newDomain.protocols = entity.getProtocols();
        // NOT valid in creation! <= newDomain.secure = entity.isSecure();

        Response response = instance.create(newDomain);
        if (response.getStatus() == CREATED.getStatusCode()) {
            NetworkObject created = response.readEntity(NetworkObject.class);
            return new NetworkID.Builder(SdnUtils.extractId(created.id)).build();
        }

        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NetworkID update(SecurityToken securityToken, Network entity) {
        NetworkObject updatedDomain = new NetworkObject();

        updatedDomain.name = entity.getName();
        updatedDomain.userDomain = entity.getUserDomain();
        updatedDomain.topologyType = entity.getTopologyType();
        updatedDomain.protocols = entity.getProtocols();
        // NOT yet updateable! <= updatedDomain.secure = entity.isSecure();

        Response response = instance.update(entity.getID().getID(), updatedDomain);
        if (response.getStatus() == OK.getStatusCode()) {
            NetworkObject updated = response.readEntity(NetworkObject.class);
            return new NetworkID.Builder(SdnUtils.extractId(updated.id)).build();
        }

        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void delete(SecurityToken securityToken, NetworkID id) {
        Response response = instance.delete(id.getID());

        if (response != null && response.getStatus() != NO_CONTENT.getStatusCode()) {
            throw new RuntimeException("Could not delete network domain: " + id.getID());
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NetworkSummary getSummary(SecurityToken securityToken, NetworkID id) {
        if (id != null && id.getID() != null) {
            NetworkObject domain = getNetworkObject(id);
            NetworkSummary.Builder builder = new NetworkSummary.Builder(id);

            // affect the builder with summary details
            NetworkObjectHandler.toNetworkSummary(domain, builder);

            return builder.build();
        }

        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Network getDetails(SecurityToken securityToken, NetworkID id) {
        Network networkItem = null;
        if (id != null && id.getID() != null) {
            NetworkObject domain = getNetworkObject(id);
            if (domain != null) {
                Network.Builder b = new Network.Builder(id);
                // affect the builder with summary details
                NetworkObjectHandler.toNetwork(domain, b);
                networkItem = b.build();
            }
        }

        return networkItem;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<NetworkSummary, NetworkField> getAllSummary(SecurityToken securityToken, Collection<NetworkID> ids) {
        Collection<NetworkID> identifiers = ids;
        // if the list of ids is null or empty, we interpret as the need to retrieve all the Network items
        if (ids == null || ids.isEmpty()) {
            OperationResult<NetworkID, NetworkField> allIds = getAllIds(securityToken, null, null, null);
            identifiers = allIds.getResultCollection();
        }

        List<NetworkSummary> collection = identifiers.stream()
            .map(id -> getSummary(securityToken, id))
            .collect(Collectors.toList());

        return new OperationResult.Builder<NetworkSummary, NetworkField>(collection, collection.size()).build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<NetworkSummary, NetworkField> getAllSummary(SecurityToken securityToken, Collection<Filter<NetworkField>> filterBy, Sort<NetworkField> sortBy, Page page) {
        OperationResult<NetworkID, NetworkField> allIds = getAllIds(securityToken, filterBy, sortBy, page);

        List<NetworkSummary> collection = allIds.getResultCollection().stream()
            .map(id -> getSummary(securityToken, new NetworkID.Builder(id.getID()).build()))
            .collect(Collectors.toList());

        return new OperationResult.Builder<NetworkSummary, NetworkField>(collection, collection.size()).build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<Network, NetworkField> getAll(SecurityToken securityToken, Collection<NetworkID> ids) {
        Collection<NetworkID> identifiers = ids;
        // if the list of ids is null or empty, we interpret as the need to retrieve all the Network items
        if (ids == null || ids.isEmpty()) {
            OperationResult<NetworkID, NetworkField> allIds = getAllIds(securityToken, null, null, null);
            identifiers = allIds.getResultCollection();
        }

        List<Network> collection = identifiers.stream()
            .map(id -> getDetails(securityToken, id))
            .collect(Collectors.toList());

        return new OperationResult.Builder<Network, NetworkField>(collection, collection.size()).build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<Network, NetworkField> getAll(SecurityToken securityToken, Collection<Filter<NetworkField>> filterBy, Sort<NetworkField> sortBy, Page page) {
        OperationResult<NetworkID, NetworkField> allIds = getAllIds(securityToken, filterBy, sortBy, page);

        List<Network> collection = allIds.getResultCollection().stream()
            .map(id -> getDetails(securityToken, new NetworkID.Builder(id.getID()).build()))
            .collect(Collectors.toList());

        return new OperationResult.Builder<Network, NetworkField>(collection, collection.size()).build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<NetworkID, NetworkField> getAllIds(SecurityToken securityToken, Collection<Filter<NetworkField>> filterBy, Sort<NetworkField> sortBy, Page page) {
        // since we only support filter by name, extract such a value
        String filterByName = extractNameFilterValue(filterBy);

        LOGGER.debug("FILTER BY NAME IS {}", filterByName);
        Response response = instance.getAll(filterByName);
        NetworkObjectList networkIDResponseObject;

        try {
            networkIDResponseObject = response.readEntity(NetworkObjectList.class);
        } catch (ProcessingException e) {
            // Currently SDN returns {} instead of { id: [] }
            networkIDResponseObject = new NetworkObjectList();
        }

        if (networkIDResponseObject.id == null) {
            networkIDResponseObject.id = new String[]{};
        }

        List<NetworkID> collection = Arrays.stream(networkIDResponseObject.id)
            .map(id -> new NetworkID.Builder(SdnUtils.extractId(id)).build())
            .collect(Collectors.toList());

        Integer total = SdnUtils.extractTotal(response, collection);

        return new OperationResult.Builder<NetworkID, NetworkField>(collection, total).build();
    }

    /**
     * @param filterBy
     * @return
     */
    private String extractNameFilterValue(Collection<Filter<NetworkField>> filterBy) {
        String filterByName = null;

        if (filterBy != null) {
            filterByName = filterBy.stream()
                // find filters applied to NAME field
                .filter(item -> NetworkField.NAME.equals(item.getField()) && FilterOperation.EQUALS.equals(item.getOperation()))
                // only one is supported, so return the first
                .findFirst()
                // get the value
                .map(Filter::getValue)
                // return that value or null
                .orElse(null);
        }
        return filterByName;
    }
}