package com.ossnms.web.api.oif.proxy.api.client.call;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.client.common.SrgDetailObject;
import com.ossnms.web.api.oif.proxy.api.client.common.TrafficParamObject;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.List;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class CallObject implements BaseObject {

    private static final long serialVersionUID = -5914027194094207909L;

    @JsonIgnore
    private String domainId;

    @JsonProperty( "id" )
    private String id;
    @JsonProperty( "name" )
    private String name;

    @JsonProperty( "pathRequestId" )
    private String pathRequestId;

    @JsonProperty( "aEnd" )
    private String[] aEnd;
    @JsonProperty( "zEnd" )
    private String[] zEnd;

    private TrafficParamObject trafficParam;

    @JsonProperty( "adminStatus" )
    private String adminStatus;

    @JsonProperty( "coriant.callOperStatus" )
    private String callOperStatus;
    @JsonProperty( "coriant.callProvisioningStatus" )
    private String callProvisioningStatus;
    @JsonProperty( "coriant.callConfigStatus" )
    private String callConfigStatus;
    @JsonProperty( "coriant.networkSyncStatus" )
    private String networkSyncStatus;
    @JsonProperty( "coriant.callLatency" )
    private Integer callLatency;

    private RoutingFailureDetailObject routingFailureDetail;

    // Deprecated: operStatus
    // Deprecated: coriant.provisioningStatus

    //ietfTE.attributes_ietfTE.setupPrio
    //ietfTE.attributes_ietfTE.holdPrio
    //ietfTE.attributes_ietfTE.sessionName

    @JsonProperty( "ietfGMPLS.switchingType" )
    private Integer switchingType;
    @JsonProperty( "ietfGMPLS.encoding" )
    private Integer encoding;
    //ietfGMPLS.GPID
    @JsonProperty( "ietfGMPLS.directionality" )
    private String directionality;

    //ietf.trafficparam_ietfEnet.profile
    //ietf.trafficparam_ietfEnet.index
    //ietf.trafficparam_ietfEnet.cir
    //ietf.trafficparam_ietfEnet.cbs
    //ietf.trafficparam_ietfEnet.eir
    //ietf.trafficparam_ietfEnet.ebs

    @JsonProperty( "ietfASON.ConnectionIDs" )
    private List<IetfASONConnectionIDsObject> connectionIDs;

    //oifUNI.callId
    //oifUNI.serviceLevel
    //oifUNI.egressLabel
    //oifENNIv2.aEndNcc_oifENNI.nccPcId
    //oifENNIv2.aEndNcc_oifENNI.nccPcIdType
    //oifENNIv2.zEndNcc_oifENNI.nccPcId
    //oifENNIv2.zEndNcc_oifENNI.nccPcIdType
    //oifUNI.spcLabel
    //ogfNsi.schedule_startTime
    //ogfNsi.schedule_endTime

    @JsonProperty( "coriant.PMPData" )
    private PMPDataObject[] pmpData;

    //coriant.OFCookie

    @JsonProperty( "coriant.path" )
    private List<PathObject> path;

    @JsonProperty( "coriant.constraints" )
    private ConstraintsObject constraints;

    @JsonProperty( "coriant.servicelatency" )
    private List<Long> serviceLatency;

    @JsonProperty( "coriant.routingOverExistingServicesOnly" )
    private Boolean routingOverExistingServicesOnly;
    @JsonProperty( "coriant.routingOverEnabledResourcesOnly" )
    private Boolean routingOverEnabledResourcesOnly;
    @JsonProperty( "coriant.routingOverNotReservedResourcesOnly" )
    private Boolean routingOverNotReservedResourcesOnly;

    @JsonProperty( "coriant.orderNumber" )
    private String orderNumber;

    @JsonProperty( "coriant.SLA" )
    private SLAObject sla;

    @JsonProperty( "coriant.srgDetail" )
    private List<SrgDetailObject> srgDetails;

    @JsonProperty( "coriant.schedule" )
    private List<ScheduleObject> schedules;


    // ABOUT TO BE CHANGED IN SDN: restoration and protection groups
    @JsonProperty( "coriant.restorable" )
    private Boolean restorable;

    // Protection groups for OFC
    @JsonProperty( "coriant.protectionGroup" )
    private List<ProtectionGroupObject> protectionGroups;

    // Post OFC:
    //coriant.protectionGroup[]
    //coriant.protectionGroup_coriant.groupId
    //coriant.protectionGroup_coriant.protectionType
    //coriant.protectionGroup_coriant.protectionMode
    //coriant.protectionGroup_coriant.protectionState
    //coriant.protectionGroup_coriant.restorationGate
    //coriant.protectionGroup_coriant.waitToRestoreTime
    //coriant.protectionGroup_coriant.selectedSegment
    //coriant.protectionGroup_coriant.activeSegment
    //coriant.protectionGroup_coriant.idleSegment []
    //coriant.protectionGroup_coriant.nominalSegment
    //coriant.protectionGroup_coriant.backupSegment []
    //coriant.protectionGroup_coriant.segments []
    //coriant.protectionGroup_coriant.segments_id
    //coriant.protectionGroup_coriant.segments_coriant.priority
    //coriant.protectionGroup_coriant.segments_adminStatus


    @Override
    public String toString() {

        return
            String.format( "Service {%s/%s}: %s",
                domainId,
                id,
                name
            );
    }


    /**
     *
     * @return
     */
    public TrafficParamObject getTrafficParam() {

        return trafficParam;
    }

    /**
     *
     * @param trafficParam
     */
    public void setTrafficParam( TrafficParamObject trafficParam ) {

        this.trafficParam = trafficParam;
    }

    /**
     *
     * @return
     */
    public RoutingFailureDetailObject getRoutingFailureDetail() {

        return routingFailureDetail;
    }

    /**
     *
     * @param routingFailureDetail
     */
    public void setRoutingFailureDetail( RoutingFailureDetailObject routingFailureDetail ) {

        this.routingFailureDetail = routingFailureDetail;
    }

    /**
     *
     * @return
     */
    public List<PathObject> getPath() {

        return path;
    }

    /**
     *
     * @param path
     */
    public void setPath( List<PathObject> path ) {

        this.path = path;
    }

    /**
     *
     * @return
     */
    public SLAObject getSla() {

        return sla;
    }

    /**
     *
     * @param sla
     */
    public void setSla( SLAObject sla ) {

        this.sla = sla;
    }

    /**
     *
     * @return
     */
    public String getDomainId() {
        return domainId;
    }

    /**
     *
     * @param domainId
     */
    public void setDomainId(String domainId) {
        this.domainId = domainId;
    }

    /**
     *
     * @return
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return
     */
    public String getPathRequestId() {
        return pathRequestId;
    }

    /**
     *
     * @param pathRequestId
     */
    public void setPathRequestId(String pathRequestId) {
        this.pathRequestId = pathRequestId;
    }

    /**
     *
     * @return
     */
    public String[] getaEnd() {
        return aEnd;
    }

    /**
     *
     * @param aEnd
     */
    public void setaEnd( String[] aEnd) {
        this.aEnd = aEnd;
    }

    /**
     *
     * @return
     */
    public String[] getzEnd() {
        return zEnd;
    }

    /**
     *
     * @param zEnd
     */
    public void setzEnd( String[] zEnd) {
        this.zEnd = zEnd;
    }

    /**
     *
     * @return
     */
    public String getAdminStatus() {
        return adminStatus;
    }

    /**
     *
     * @param adminStatus
     */
    public void setAdminStatus(String adminStatus) {
        this.adminStatus = adminStatus;
    }

    /**
     *
     * @return
     */
    public String getCallOperStatus() {
        return callOperStatus;
    }

    /**
     *
     * @param callOperStatus
     */
    public void setCallOperStatus(String callOperStatus) {
        this.callOperStatus = callOperStatus;
    }

    /**
     *
     * @return
     */
    public String getCallProvisioningStatus() {
        return callProvisioningStatus;
    }

    /**
     *
     * @param callProvisioningStatus
     */
    public void setCallProvisioningStatus(String callProvisioningStatus) {
        this.callProvisioningStatus = callProvisioningStatus;
    }

    /**
     *
     * @return
     */
    public String getCallConfigStatus() {
        return callConfigStatus;
    }

    /**
     *
     * @param callConfigStatus
     */
    public void setCallConfigStatus(String callConfigStatus) {
        this.callConfigStatus = callConfigStatus;
    }

    /**
     *
     * @return
     */
    public String getNetworkSyncStatus() {
        return networkSyncStatus;
    }

    /**
     *
     * @param networkSyncStatus
     */
    public void setNetworkSyncStatus(String networkSyncStatus) {
        this.networkSyncStatus = networkSyncStatus;
    }

    /**
     *
     * @return
     */
    public Integer getCallLatency() {
        return callLatency;
    }

    /**
     *
     * @param callLatency
     */
    public void setCallLatency(Integer callLatency) {
        this.callLatency = callLatency;
    }

    /**
     *
     * @return
     */
    public Integer getSwitchingType() {
        return switchingType;
    }

    /**
     *
     * @param switchingType
     */
    public void setSwitchingType(Integer switchingType) {
        this.switchingType = switchingType;
    }

    /**
     *
     * @return
     */
    public Integer getEncoding() {
        return encoding;
    }

    /**
     *
     * @param encoding
     */
    public void setEncoding(Integer encoding) {
        this.encoding = encoding;
    }

    /**
     *
     * @return
     */
    public String getDirectionality() {
        return directionality;
    }

    /**
     *
     * @param directionality
     */
    public void setDirectionality(String directionality) {
        this.directionality = directionality;
    }

    /**
     *
     * @return
     */
    public PMPDataObject[] getPmpData() {
        return pmpData;
    }

    /**
     *
     * @param pmpData
     */
    public void setPmpData(PMPDataObject[] pmpData) {
        this.pmpData = pmpData;
    }

    /**
     *
     * @return
     */
    public ConstraintsObject getConstraints() {
        return constraints;
    }

    /**
     *
     * @param constraints
     */
    public void setConstraints(ConstraintsObject constraints) {
        this.constraints = constraints;
    }

    /**
     *
     * @return
     */
    public List<Long> getServiceLatency() {
        return serviceLatency;
    }

    /**
     *
     * @param serviceLatency
     */
    public void setServiceLatency(List<Long> serviceLatency) {
        this.serviceLatency = serviceLatency;
    }

    /**
     *
     * @return
     */
    public Boolean isRoutingOverExistingServicesOnly() {
        return routingOverExistingServicesOnly;
    }

    /**
     *
     * @param routingOverExistingServicesOnly
     */
    public void setRoutingOverExistingServicesOnly(Boolean routingOverExistingServicesOnly) {
        this.routingOverExistingServicesOnly = routingOverExistingServicesOnly;
    }

    /**
     *
     * @return
     */
    public Boolean isRoutingOverEnabledResourcesOnly() {
        return routingOverEnabledResourcesOnly;
    }

    /**
     *
     * @param routingOverEnabledResourcesOnly
     */
    public void setRoutingOverEnabledResourcesOnly(Boolean routingOverEnabledResourcesOnly) {
        this.routingOverEnabledResourcesOnly = routingOverEnabledResourcesOnly;
    }

    /**
     *
     * @return
     */
    public Boolean isRoutingOverNotReservedResourcesOnly() {
        return routingOverNotReservedResourcesOnly;
    }

    /**
     *
     * @param routingOverNotReservedResourcesOnly
     */
    public void setRoutingOverNotReservedResourcesOnly(Boolean routingOverNotReservedResourcesOnly) {
        this.routingOverNotReservedResourcesOnly = routingOverNotReservedResourcesOnly;
    }

    /**
     *
     * @return
     */
    public String getOrderNumber() {
        return orderNumber;
    }

    /**
     *
     * @param orderNumber
     */
    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    /**
     *
     * @return
     */
    public List<SrgDetailObject> getSrgDetails() {

        return srgDetails;
    }

    /**
     *
     * @param srgDetails
     */
    public void setSrgDetails( List<SrgDetailObject> srgDetails ) {

        this.srgDetails = srgDetails;
    }

    /**
     *
     * @return
     */
    public Boolean isRestorable() {
        return restorable;
    }

    /**
     *
     * @param restorable
     */
    public void setRestorable(Boolean restorable) {
        this.restorable = restorable;
    }

    /**
     *
     * @return
     */
    public List<IetfASONConnectionIDsObject> getConnectionIDs() {

        return connectionIDs;
    }

    /**
     *
     * @param connectionIDs
     */
    public void setConnectionIDs( List<IetfASONConnectionIDsObject> connectionIDs ) {

        this.connectionIDs = connectionIDs;
    }

    /**
     *
     * @return
     */
    public List<ProtectionGroupObject> getProtectionGroups() {

        return protectionGroups;
    }

    /**
     *
     * @param protectionGroups
     */
    public void setProtectionGroups( List<ProtectionGroupObject> protectionGroups ) {

        this.protectionGroups = protectionGroups;
    }
}