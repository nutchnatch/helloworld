package com.ossnms.web.api.oif.proxy.api.client.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.Objects;

/**
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EndIdentifierObject implements BaseObject{

    private static final long serialVersionUID = 8970498971688226716L;

    @JsonProperty("coriant.coordLatitude")
	private float coordLatitude;

	@JsonProperty("coriant.coordLongitude")
	private float coordLongitude;

    /**
     *
     */
    public float getCoordLatitude() {
        return coordLatitude;
    }

    public EndIdentifierObject setCoordLatitude(float coordLatitude) {
        this.coordLatitude = coordLatitude;
        return this;
    }

    /**
     *
     */
    public float getCoordLongitude() {
        return coordLongitude;
    }

    public EndIdentifierObject setCoordLongitude(float coordLongitude) {
        this.coordLongitude = coordLongitude;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        EndIdentifierObject that = (EndIdentifierObject) o;
        return Float.compare(that.getCoordLatitude(), getCoordLatitude()) == 0 &&
            Float.compare(that.getCoordLongitude(), getCoordLongitude()) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCoordLatitude(), getCoordLongitude());
    }
}