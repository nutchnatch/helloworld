package com.ossnms.web.api.oif.proxy.api.client.network;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

/**
 *
 */
@JsonInclude( JsonInclude.Include.NON_NULL )
public class NetworkObjectList implements BaseObject {

    private static final long serialVersionUID = 4331136881693455487L;

    public String[] id;
}
