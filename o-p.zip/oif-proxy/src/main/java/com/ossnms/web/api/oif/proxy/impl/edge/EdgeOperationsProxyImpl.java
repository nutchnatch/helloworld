package com.ossnms.web.api.oif.proxy.impl.edge;

import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.sdn.model.edge.Edge;
import com.ossnms.web.provider.sdn.model.edge.EdgeField;
import com.ossnms.web.provider.sdn.model.edge.EdgeID;
import com.ossnms.web.provider.sdn.model.edge.EdgeSummary;
import com.ossnms.web.provider.sdn.operations.edge.EdgeEntityOperations;

import javax.enterprise.context.RequestScoped;
import java.util.Collection;

/**
 *
 */
@RequestScoped
public class EdgeOperationsProxyImpl implements EdgeEntityOperations {

//    private static final Logger LOGGER = LoggerFactory.getLogger(EdgeOperationsProxyImpl.class);

    /**
     * {@inheritDoc}
     */
    @Override
    public EdgeID insert(SecurityToken securityToken, Edge entity) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public EdgeID update(SecurityToken securityToken, Edge entity) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void delete(SecurityToken securityToken, EdgeID id) {

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public EdgeSummary getSummary(SecurityToken securityToken, EdgeID id) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Edge getDetails(SecurityToken securityToken, EdgeID id) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<EdgeSummary, EdgeField> getAllSummary(SecurityToken securityToken, Collection<EdgeID> ids) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<EdgeSummary, EdgeField> getAllSummary(SecurityToken securityToken, Collection<Filter<EdgeField>> filterBy, Sort<EdgeField> sortBy, Page page) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<Edge, EdgeField> getAll(SecurityToken securityToken, Collection<EdgeID> ids) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<Edge, EdgeField> getAll(SecurityToken securityToken, Collection<Filter<EdgeField>> filterBy, Sort<EdgeField> sortBy, Page page) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<EdgeID, EdgeField> getAllIds(SecurityToken securityToken, Collection<Filter<EdgeField>> filterBy, Sort<EdgeField> sortBy, Page page) {
        return null;
    }
}
