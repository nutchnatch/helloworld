package com.ossnms.web.api.oif.proxy.api.client.call;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.List;


/**
 *
 */
@JsonInclude( JsonInclude.Include.NON_NULL )
public class CallObjectList implements BaseObject {

    private static final long serialVersionUID = 2295557528351525436L;

    private List<String> id;

    /**
     *
     * @return
     */
    public List<String> getId() {

        return id;
    }

    /**
     *
     * @param id
     */
    public void setId( List<String> id ) {

        this.id = id;
    }
}