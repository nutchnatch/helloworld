package com.ossnms.web.api.oif.proxy.api.client.call;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class ConstraintsObject implements BaseObject {

    private static final long serialVersionUID = 900887742260422558L;

    @JsonProperty( "coriant.include" )
    public IncludeObject include;

    @JsonProperty( "coriant.exclude" )
    public ExcludeObject exclude;

    @JsonProperty( "coriant.corouted" )
    public String corouted;

    @JsonProperty( "coriant.diverse" )
    public DiverseObject diverse;

    @JsonProperty( "coriant.relaxedConstraintClass" )
    public String[] relaxedConstraintClass;

    @JsonProperty( "coriant.requiredlatency" )
    public Integer requiredlatency;
}