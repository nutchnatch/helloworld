package com.ossnms.web.api.oif.proxy.api.client.srg;

import com.ossnms.web.api.oif.proxy.api.common.network.NetworkBaseClient;

import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import static com.ossnms.web.api.oif.proxy.api.common.OIFProxyConstant.URL_NDM_SRG;

/**
 *
 */
@Path(URL_NDM_SRG)
@Consumes("application/json")
@Produces("application/json")
public interface SrgNDMCLient extends NetworkBaseClient<SrgObject> {
}
