package com.ossnms.web.api.oif.proxy.api.client.vertex;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.Objects;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class VertexIdentifierObject implements BaseObject{

    private static final long serialVersionUID = -216618679700792773L;

    @JsonProperty(value = "coriant.coordLatitude")
    private String coordLatitude;

    @JsonProperty(value = "coriant.coordLongitude")
    private String coordLongitude;

    @JsonProperty(value = "coriant.nodeType")
    private String nodeType;

    /**
     *
     */
    public String getCoordLatitude() {
        return coordLatitude;
    }

    public VertexIdentifierObject setCoordLatitude(String coordLatitude) {
        this.coordLatitude = coordLatitude;
        return this;
    }

    /**
     *
     */
    public String getCoordLongitude() {
        return coordLongitude;
    }

    public VertexIdentifierObject setCoordLongitude(String coordLongitude) {
        this.coordLongitude = coordLongitude;
        return this;
    }

    /**
     *
     */
    public String getNodeType() {
        return nodeType;
    }

    public VertexIdentifierObject setNodeType(String nodeType) {
        this.nodeType = nodeType;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        VertexIdentifierObject that = (VertexIdentifierObject) o;
        return Objects.equals(getCoordLatitude(), that.getCoordLatitude()) &&
            Objects.equals(getCoordLongitude(), that.getCoordLongitude()) &&
            Objects.equals(getNodeType(), that.getNodeType());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getCoordLatitude(), getCoordLongitude(), getNodeType());
    }
}
