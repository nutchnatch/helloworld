package com.ossnms.web.api.oif.proxy.api.client.end;

import com.ossnms.web.api.oif.proxy.api.common.vertex.VertexBaseClient;

import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import static com.ossnms.web.api.oif.proxy.api.common.OIFProxyConstant.URL_NDM_END;

/**
 *
 */
@Path(URL_NDM_END)
@Consumes("application/json")
@Produces("application/json")
public interface EndNDMClient extends VertexBaseClient<EndObject> {
}
