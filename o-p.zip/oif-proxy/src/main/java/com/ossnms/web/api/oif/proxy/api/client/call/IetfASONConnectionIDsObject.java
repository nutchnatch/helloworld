package com.ossnms.web.api.oif.proxy.api.client.call;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.List;

/**
 *
 */
@JsonInclude( JsonInclude.Include.NON_NULL )
public class IetfASONConnectionIDsObject implements BaseObject {

    private static final long serialVersionUID = 9036755781215303898L;

    @JsonProperty( "coriant.componentConnections" )
    private List<String> componentConnections;


    /**
     *
     * @return
     */
    public List<String> getComponentConnections() {

        return componentConnections;
    }

    /**
     *
     * @param componentConnections
     * @return
     */
    public IetfASONConnectionIDsObject setComponentConnections( List<String> componentConnections ) {

        this.componentConnections = componentConnections;
        return this;
    }
}