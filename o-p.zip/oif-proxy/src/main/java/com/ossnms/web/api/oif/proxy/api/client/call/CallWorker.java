package com.ossnms.web.api.oif.proxy.api.client.call;

import com.ossnms.web.api.oif.proxy.api.client.common.CommonWorker;
import com.ossnms.web.api.oif.proxy.api.common.result.GenericErrorCode;
import com.ossnms.web.provider.common.api.result.ProcessableSingleResult;

import java.util.function.Function;

/**
 *
 */
public final class CallWorker {

    /**
     * Hidden constructor
     */
    private CallWorker() {}

    public static Function<String, ProcessableSingleResult<CallObject, GenericErrorCode>> fromURIFunction(CallNDMClient proxy) {
        return CommonWorker.fromNetworkURIFunction(
            proxy,
            CommonWorker.fromResponse(CallObject.class)
        );
    }
}