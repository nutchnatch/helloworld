package com.ossnms.web.api.oif.proxy.api.common.network;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

/**
 * Classes implementing this interface should start with a path which provides the networkId
 * <p>
 * E.g. @Path("/com.oiforum.json/ndm/network/{networkId}/call")
 */
public interface NetworkBaseClient<E> {

    /**
     * @param networkId
     * @param filterByName
     * @return
     */
    @GET
    @Path( "" )
    Response getAll( @PathParam( "networkId" ) String networkId, @QueryParam( "name" ) String filterByName );

    /**
     * @param networkId
     * @param id
     * @return
     */
    @GET
    @Path( "/{id}" )
    Response get( @PathParam( "networkId" ) String networkId, @PathParam( "id" ) String id );

    /**
     * @param networkId
     * @param entity
     * @return
     */
    @POST
    @Path( "" )
    Response create( @PathParam( "networkId" ) String networkId, E entity );

    /**
     * @param networkId
     * @param id
     * @param entity
     * @return
     */
    @PUT
    @Path( "/{id}" )
    Response update( @PathParam( "networkId" ) String networkId, @PathParam( "id" ) String id, E entity );

    /**
     * @param networkId
     * @param id
     * @return
     */
    @DELETE
    @Path( "/{id}" )
    Response delete( @PathParam( "networkId" ) String networkId, @PathParam( "id" ) String id );
}
