package com.ossnms.web.api.oif.proxy.api.client.call;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

/**
 *
 */
@JsonInclude( JsonInclude.Include.NON_NULL )
public class RoutingFailureDetailObject implements BaseObject {

    private static final long serialVersionUID = -9165565120573646069L;

    @JsonProperty( "coriant.failureCode" )
    private String failureCode;
    @JsonProperty( "coriant.failureDescription" )
    private String failureDescription;

    /**
     *
     * @return
     */
    public String getFailureCode() {

        return failureCode;
    }

    /**
     *
     * @param failureCode
     * @return
     */
    public RoutingFailureDetailObject setFailureCode( String failureCode ) {

        this.failureCode = failureCode;
        return this;
    }

    /**
     *
     * @return
     */
    public String getFailureDescription() {

        return failureDescription;
    }

    /**
     *
     * @param failureDescription
     * @return
     */
    public RoutingFailureDetailObject setFailureDescription( String failureDescription ) {

        this.failureDescription = failureDescription;
        return this;
    }
}