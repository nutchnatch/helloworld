package com.ossnms.web.api.oif.proxy.notification;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ning.http.client.AsyncHttpClient;
import com.ning.http.client.AsyncHttpClientConfig;
import com.ning.http.client.providers.netty.NettyAsyncHttpProvider;
import com.ossnms.web.api.oif.proxy.api.notification.ProxyNotificationHandler;
import com.ossnms.web.api.oif.proxy.api.notification.model.InboundNotification;
import com.ossnms.web.provider.common.api.notification.NotificationHandlerException;
import org.atmosphere.wasync.ClientFactory;
import org.atmosphere.wasync.Function;
import org.atmosphere.wasync.Request;
import org.atmosphere.wasync.RequestBuilder;
import org.atmosphere.wasync.Socket;
import org.atmosphere.wasync.impl.AtmosphereClient;
import org.atmosphere.wasync.impl.DefaultOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

import static org.atmosphere.wasync.Event.CLOSE;
import static org.atmosphere.wasync.Event.ERROR;
import static org.atmosphere.wasync.Event.HEADERS;
import static org.atmosphere.wasync.Event.MESSAGE;
import static org.atmosphere.wasync.Event.OPEN;
import static org.atmosphere.wasync.Event.TRANSPORT;
import static org.atmosphere.wasync.Request.METHOD.GET;

/**
 *
 */
public class WebSocketClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(WebSocketClient.class);
    private static final String FORMAT_URL_NOTIFICATIONS = "%s://%s:%s%s";

    private static final String HEADER_AUTHORIZATION = "Authorization";
    private static final String HEADER_CONNECTION = "Connection";
    private static final String HEADER_UPGRADE = "Upgrade";

    private static final String VALUE_CONNECTION = "Upgrade";
    private static final String VALUE_UPGRADE = "Websocket";

    private static final String PROTOCOL_HTTPS = "https";
    private static final String PROTOCOL_HTTP = "http";

    private boolean secure;
    private String hostname;
    private String port;
    private String endpoint;
    private String authorization;
    private ProxyNotificationHandler notificationHandler;
    private Socket socket;
    private boolean active = false;

    /**
     * Defines the type of connection to be used. Either secure (https) or unsecure (http)
     *
     * @param secure boolean to define the protocol
     * @return the same instance we are affecting
     */
    public WebSocketClient setSecure(boolean secure) {
        this.secure = secure;
        return this;
    }

    /**
     *
     * @param authorization
     */
    public WebSocketClient setAuthorization(String authorization) {
        this.authorization = authorization;
        return this;
    }

    /**
     *
     * @param handler
     */
    public WebSocketClient setNotificationHandler(ProxyNotificationHandler handler) {
        this.notificationHandler = handler;
        return this;
    }

    /**
     *
     * @param endpoint
     * @return
     */
    public WebSocketClient setEndpoint(String endpoint) {
        this.endpoint = endpoint;
        return this;
    }

    /**
     *
     * @param hostname
     * @return
     */
    public WebSocketClient setHostname(String hostname) {
        this.hostname = hostname;
        return this;
    }

    /**
     *
     * @param port
     * @return
     */
    public WebSocketClient setPort(String port) {
        this.port = port;
        return this;
    }

    /**
     *
     */
    public WebSocketClient initiate() {
        if(assertConnectionParameters()) {
            throw new IllegalArgumentException("Obligatory parameters were not defined");
        }

        AtmosphereClient client = ClientFactory.getDefault().newClient(AtmosphereClient.class);

        // request builder
        RequestBuilder transport = client.newRequestBuilder()
            .method(GET)
            // set uri
            .uri(getNotificationsUri())
            // set required headers
            .header(HEADER_CONNECTION,      VALUE_CONNECTION)
            .header(HEADER_UPGRADE,         VALUE_UPGRADE)
            // set transport types
            .transport(Request.TRANSPORT.WEBSOCKET)
            .enableProtocol(false);

        // define the runtime, so that configurations can be made
        AsyncHttpClient asyncHttpClient = new AsyncHttpClient(
            new NettyAsyncHttpProvider(
                new AsyncHttpClientConfig.Builder()
                    .setAcceptAnyCertificate(true)
                    .build()
            )
        );

        // set the desired runtime and other additional options
        DefaultOptions options = client.newOptionsBuilder()
            .runtime(asyncHttpClient, false)
            .reconnectAttempts(2)
            .reconnect(true)
            .pauseBeforeReconnectInSeconds(2)
            .build();

        try {
            // create the socket, given the additional options
            socket = client.create(options);

            // register event handlers
            socket.on(OPEN,         onOpen()        );
            socket.on(MESSAGE,      onMessage()     );
            socket.on(CLOSE,        onClose()       );
            socket.on(ERROR,        onError()       );
            socket.on(HEADERS,      onHeaders()     );
            socket.on(TRANSPORT,    onTransport()   );

            socket.open(transport.build());
            active = true;
        } catch (IOException e) {
            LOGGER.error("Client Websocket connection could not be created due to an exception", e.getMessage());
            LOGGER.debug(" >> Stacktrace", e);
            socket.close();
        }

        return this;
    }

    private boolean assertConnectionParameters() {
        return this.hostname == null
            || this.port == null
            || this.endpoint == null;
    }

    /**
     *
     * @return
     */
    private String getNotificationsUri() {
        return String.format(FORMAT_URL_NOTIFICATIONS,
            secure ? PROTOCOL_HTTPS : PROTOCOL_HTTP,
            hostname,
            port,
            endpoint
        );
    }

    /**
     *
     * @return
     */
    private Function<String> onOpen() {
        return s -> LOGGER.debug("OPEN >> endpoint:{}", endpoint);
    }

    /**
     *
     * @return
     */
    private Function<String> onTransport() {
        return s -> LOGGER.debug("TRANSPORT >> transport:{} >> endpoint:{}", s, endpoint);
    }

    /**
     *
     * @return
     */
    private Function<String> onHeaders() {
        return s -> LOGGER.debug("HEADERS >> endpoint:{} >> headers:{}", endpoint, s);
    }

    /**
     *
     * @return
     */
    private Function<String> onError() {
        return s -> LOGGER.error("ERROR >> endpoint:{} >> error:{}", endpoint, s);
    }

    /**
     *
     * @return
     */
    private Function<String> onClose() {
        return s -> LOGGER.debug("CLOSE >> endpoint:{}, message:{}", endpoint, s);
    }

    /**
     *
     * @return
     */
    private Function<String> onMessage() {
        return message -> {
            LOGGER.debug("\n    MESSAGE  : {}\n    ENDPOINT : {}", message, endpoint);
            if(message.startsWith("<http>")) {
                LOGGER.error("Invalid message detected. Will discard.");
                return;
            }

            try {
                ObjectMapper mapper = new ObjectMapper();
                InboundNotification inboundNotification = mapper.readValue(message, InboundNotification.class);
                notificationHandler.handle(inboundNotification, message);
            } catch (IOException | NotificationHandlerException e) {
                LOGGER.error("Failure when mapping JSON value to object", e);
            }
        };
    }

    /**
     *
     */
    public void shutdown() {
        LOGGER.debug("SHUTDOWN >> Shutting down the client >> {}", endpoint);
        if(socket != null && active){
            socket.close();
            socket = null;
            active = false;
        }
    }

    /**
     *
     * @return
     */
    public boolean isActive() {
        return active;
    }
}
