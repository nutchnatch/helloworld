package com.ossnms.web.api.oif.proxy.impl.edge.end;

import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.sdn.model.edge.end.EdgeEnd;
import com.ossnms.web.provider.sdn.model.edge.end.EdgeEndField;
import com.ossnms.web.provider.sdn.model.edge.end.EdgeEndID;
import com.ossnms.web.provider.sdn.model.edge.end.EdgeEndSummary;
import com.ossnms.web.provider.sdn.operations.edge.end.EdgeEndEntityOperations;

import javax.enterprise.context.RequestScoped;
import java.util.Collection;

/**
 *
 */
@RequestScoped
public class EdgeEndOperationsProxyImpl implements EdgeEndEntityOperations {

//    private static final Logger LOGGER = LoggerFactory.getLogger(EdgeEndOperationsProxyImpl.class);

    /**
     * {@inheritDoc}
     */
    @Override
    public EdgeEndID insert(SecurityToken securityToken, EdgeEnd entity) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public EdgeEndID update(SecurityToken securityToken, EdgeEnd entity) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void delete(SecurityToken securityToken, EdgeEndID id) {

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public EdgeEndSummary getSummary(SecurityToken securityToken, EdgeEndID id) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public EdgeEnd getDetails(SecurityToken securityToken, EdgeEndID id) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<EdgeEndSummary, EdgeEndField> getAllSummary(SecurityToken securityToken, Collection<EdgeEndID> ids) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<EdgeEndSummary, EdgeEndField> getAllSummary(SecurityToken securityToken, Collection<Filter<EdgeEndField>> filterBy, Sort<EdgeEndField> sortBy, Page page) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<EdgeEnd, EdgeEndField> getAll(SecurityToken securityToken, Collection<EdgeEndID> ids) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<EdgeEnd, EdgeEndField> getAll(SecurityToken securityToken, Collection<Filter<EdgeEndField>> filterBy, Sort<EdgeEndField> sortBy, Page page) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<EdgeEndID, EdgeEndField> getAllIds(SecurityToken securityToken, Collection<Filter<EdgeEndField>> filterBy, Sort<EdgeEndField> sortBy, Page page) {
        return null;
    }
}
