package com.ossnms.web.api.oif.proxy.api.client.vertex;

import com.ossnms.web.api.oif.proxy.api.client.common.CommonWorker;
import com.ossnms.web.api.oif.proxy.api.common.result.GenericErrorCode;
import com.ossnms.web.provider.common.api.result.ProcessableSingleResult;

import java.util.function.Function;

/**
 *
 */
public final class VertexWorker {

    /**
     *
     */
    private VertexWorker() {}

    /**
     *
     * @param proxy a valid proxy instance to be able to request the object from
     * @return a function that allows an uri to be parsed into a vertex. Will return null if the object was not found
     * or if an error occurs
     */
    public static Function<String, ProcessableSingleResult<VertexObject, GenericErrorCode>> fromURIFunction(VertexNDMClient proxy) {
        return CommonWorker.fromTopologyURIFunction(
            proxy,
            CommonWorker.fromResponse(VertexObject.class)
        );
    }
}
