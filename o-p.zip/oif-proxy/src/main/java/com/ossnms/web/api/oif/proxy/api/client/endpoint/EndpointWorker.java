package com.ossnms.web.api.oif.proxy.api.client.endpoint;

import com.ossnms.web.api.oif.proxy.api.client.common.CommonWorker;
import com.ossnms.web.api.oif.proxy.api.common.result.GenericErrorCode;
import com.ossnms.web.provider.common.api.result.ProcessableSingleResult;

import java.util.function.Function;

/**
 *
 */
public final class EndpointWorker {

    /**
     * Hidden constructor
     */
    private EndpointWorker() {}

    /**
     *
     * @param proxy a valid proxy instance to be able to request the object from
     * @return a function that allows an uri to be parsed into a vertex. Will return null if the object was not found
     * or if an error occurs
     */
    public static Function<String, ProcessableSingleResult<EndpointObject, GenericErrorCode>> fromURIFunction(EndpointNDMClient proxy) {
        return CommonWorker.fromNetworkURIFunction(
            proxy,
            CommonWorker.fromResponse(EndpointObject.class)
        );
    }
}
