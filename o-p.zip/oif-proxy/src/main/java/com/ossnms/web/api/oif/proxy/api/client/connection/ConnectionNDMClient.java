package com.ossnms.web.api.oif.proxy.api.client.connection;

import com.ossnms.web.api.oif.proxy.api.common.network.NetworkBaseClient;

import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import static com.ossnms.web.api.oif.proxy.api.common.OIFProxyConstant.URL_NDM_CONNECTION;

/**
 *
 */
@Path( URL_NDM_CONNECTION )
@Consumes( "application/json" )
@Produces( "application/json" )
public interface ConnectionNDMClient extends NetworkBaseClient<ConnectionObject> {
}
