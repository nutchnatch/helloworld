package com.ossnms.web.api.oif.proxy.api.client.edge;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.Objects;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class EdgeObject implements BaseObject {

    private static final long serialVersionUID = 6402448691543947598L;

    @JsonProperty(value = "id", required = true)
    private String id;

    @JsonProperty(value = "name", required = true)
    private String name;

    @JsonProperty(value="coriant.latency")
    private Long latency;

    @JsonProperty(value="coriant.networkSyncStatus")
    private String networkSyncStatus;

    @JsonProperty(value="onfOtwgIm.link")
    private LinkObject link;

    @JsonProperty(value="aEnd")
    private EndDefinitionObject aEnd;

    @JsonProperty(value="zEnd")
    private EndDefinitionObject zEnd;

    /**
     *
     */
    public String getId() {
        return id;
    }

    public EdgeObject setId(String id) {
        this.id = id;
        return this;
    }

    /**
     *
     */
    public String getName() {
        return name;
    }

    public EdgeObject setName(String name) {
        this.name = name;
        return this;
    }

    /**
     *
     */
    public Long getLatency() {
        return latency;
    }

    public EdgeObject setLatency(Long latency) {
        this.latency = latency;
        return this;
    }

    /**
     *
     */
    public String getNetworkSyncStatus() {
        return networkSyncStatus;
    }

    public EdgeObject setNetworkSyncStatus(String networkSyncStatus) {
        this.networkSyncStatus = networkSyncStatus;
        return this;
    }

    /**
     *
     */
    public LinkObject getLink() {
        return link;
    }

    public EdgeObject setLink(LinkObject link) {
        this.link = link;
        return this;
    }

    /**
     *
     */
    public EndDefinitionObject getAEnd() {
        return aEnd;
    }

    public EdgeObject setAEnd(EndDefinitionObject aEnd) {
        this.aEnd = aEnd;
        return this;
    }

    /**
     *
     */
    public EndDefinitionObject getZEnd() {
        return zEnd;
    }

    public EdgeObject setZEnd(EndDefinitionObject zEnd) {
        this.zEnd = zEnd;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        EdgeObject that = (EdgeObject) o;
        return Objects.equals(getId(), that.getId()) &&
            Objects.equals(getName(), that.getName()) &&
            Objects.equals(getLatency(), that.getLatency()) &&
            Objects.equals(getNetworkSyncStatus(), that.getNetworkSyncStatus()) &&
            Objects.equals(getLink(), that.getLink()) &&
            Objects.equals(aEnd, that.aEnd) &&
            Objects.equals(zEnd, that.zEnd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getName(), getLatency(), getNetworkSyncStatus(), getLink(), aEnd, zEnd);
    }
}
