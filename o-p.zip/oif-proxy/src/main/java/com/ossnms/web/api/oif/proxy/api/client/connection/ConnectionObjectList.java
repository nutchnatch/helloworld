package com.ossnms.web.api.oif.proxy.api.client.connection;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.List;
import java.util.Objects;

/**
 *
 */
@JsonInclude( JsonInclude.Include.NON_NULL )
public class ConnectionObjectList implements BaseObject {

    private static final long serialVersionUID = -5583000173277895640L;

    @JsonProperty(value = "id", required = true)
    private List<String> connections;

    /**
     *
     */
    public List<String> getConnections() {
        return connections;
    }

    public ConnectionObjectList setConnections(List<String> connections) {
        this.connections = connections;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        ConnectionObjectList that = (ConnectionObjectList) o;
        return Objects.equals(getConnections(), that.getConnections());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getConnections());
    }
}
