package com.ossnms.web.api.oif.proxy.api.common;

/**
 *
 */
public final class OIFProxyConstant {

    public static final String URL_BASE_OIF = "/com.oiforum.json";

    public static final String URL_BASE_NDM = URL_BASE_OIF + "/ndm";
    public static final String URL_NDM_NETWORK = URL_BASE_NDM + "/network";
    public static final String URL_NDM_ENDPOINT = URL_NDM_NETWORK + "/{networkId}/endpoint";
    public static final String URL_NDM_CALL = URL_NDM_NETWORK + "/{networkId}/call";
    public static final String URL_NDM_CONNECTION = URL_NDM_NETWORK + "/{networkId}/connection";
    public static final String URL_NDM_SRG = URL_NDM_NETWORK + "/{networkId}/srg";

    public static final String URL_BASE_TOPOLOGY = URL_NDM_NETWORK + "/{networkId}/topology";
    public static final String URL_NDM_VERTEX = URL_BASE_TOPOLOGY + "/{topologyId}/vertex";
    public static final String URL_NDM_EDGE = URL_BASE_TOPOLOGY + "/{topologyId}/edge";

    public static final String URL_BASE_VERTEX = URL_NDM_VERTEX + "/{vertexId}";
    public static final String URL_NDM_END = URL_BASE_VERTEX + "/end";

    /**
     * Hidden utility class constructor
     */
    private OIFProxyConstant() {}
}