package com.ossnms.web.api.oif.proxy.api.common.result;

/**
 *
 */
public enum GenericErrorCode {
    GENERIC
}
