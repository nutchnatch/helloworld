package com.ossnms.web.api.oif.proxy.api.common.vertex;

import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

/**
 *
 */
public interface VertexBaseClient <ENTITY extends BaseObject> {

    /**
     * @param networkId
     * @param filterByName
     * @return
     */
    @GET
    @Path("")
    Response getAll(
        @PathParam  ("networkId")   String networkId,
        @PathParam  ("topologyId")  String topologyId,
        @PathParam  ("vertexId")    String vertexId,
        @QueryParam ("name")        String filterByName
    );

    /**
     * @param networkId
     * @param id
     * @return
     */
    @GET
    @Path("/{id}")
    Response get(
        @PathParam("networkId")     String networkId,
        @PathParam("topologyId")    String topologyId,
        @PathParam("vertexId")      String vertexId,
        @PathParam("id")            String id
    );

    /**
     * @param networkId
     * @param entity
     * @return
     */
    @POST
    @Path("")
    Response create(
        @PathParam  ("networkId")   String networkId,
        @PathParam  ("topologyId")  String topologyId,
        @PathParam  ("vertexId")    String vertexId,
                                    ENTITY entity
    );

    /**
     * @param networkId
     * @param id
     * @param entity
     * @return
     */
    @PUT
    @Path("/{id}")
    Response update(
        @PathParam("networkId")     String networkId,
        @PathParam("topologyId")    String topologyId,
        @PathParam("vertexId")      String vertexId,
        @PathParam("id")            String id,
                                    ENTITY entity
    );

    /**
     * @param networkId
     * @param id
     * @return
     */
    @DELETE
    @Path( "/{id}" )
    Response delete(
        @PathParam("networkId")     String networkId,
        @PathParam("topologyId")    String topologyId,
        @PathParam("vertexId")      String vertexId,
        @PathParam( "id" )          String id
    );
}
