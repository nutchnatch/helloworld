package com.ossnms.web.api.oif.proxy.api.client.call;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class PMPDataObject implements BaseObject {

    private static final long serialVersionUID = -6077442772568473408L;

    //TODO: PMP!
    //@JsonProperty( "coriant.aEndTDTN_layer" )
    //public String aEndTDTN_layer;

    //coriant.PMPData_coriant.aEndTDTN_Pmdata.current_Pmdata.timestamp
    //coriant.PMPData_coriant.aEndTDTN_Pmdata.current_Pmdata.identifiers
    //coriant.PMPData_coriant.aEndTDTN_Pmdata.current_Pmdata.values
    //coriant.PMPData_coriant.aEndTDTN_PMdata.historic_PMdata.timestamp
    //coriant.PMPData_coriant.aEndTDTN_PMdata.historic_PMdata.parameters*
    //coriant.PMPData_coriant.aEndTDTN_PMdata.historic_PMdata.parameters_name
    //coriant.PMPData_coriant.aEndTDTN_PMdata.historic_PMdata.parameters_value

    //@JsonProperty( "coriant.zEndTDTN_layer" )
    //public String zEndTDTN_layer;
    //coriant.PMPData_coriant.zEndTDTN_Pmdata.current_Pmdata.timestamp
    //coriant.PMPData_coriant.zEndTDTN_Pmdata.current_Pmdata.identifiers
    //coriant.PMPData_coriant.zEndTDTN_Pmdata.current_Pmdata.values
    //coriant.PMPData_coriant.zEndTDTN_PMdata.historic_PMdata.timestamp
    //coriant.PMPData_coriant.zEndTDTN_PMdata.historic_PMdata.parameters*
    //coriant.PMPData_coriant.zEndTDTN_PMdata.historic_PMdata.parameters_name
    //coriant.PMPData_coriant.zEndTDTN_PMdata.historic_PMdata.parameters_value
}