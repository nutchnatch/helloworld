package com.ossnms.web.api.oif.proxy.api.client.common;

import org.apache.commons.codec.binary.Base64;

import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 *
 */
public class AuthorizationHeaderFilter implements ClientRequestFilter {

    public static final String HEADER_AUTHORIZATION = "Authorization";
    public static final String AUTH_BASIC = "Basic ";
    public static final String AUTH_BEARER = "Bearer ";
    private final String username;
    private final String password;

    private final String bearer;

    /**
     *
     * @param username
     * @param password
     */
    public AuthorizationHeaderFilter(String username, String password) {
        this.username = username;
        this.password = password;

        this.bearer = null;
    }

    /**
     *
     * @param bearer
     */
    public AuthorizationHeaderFilter(String bearer) {
        this.username = null;
        this.password = null;

        this.bearer = bearer;
    }

    @Override
    public void filter(ClientRequestContext requestContext) throws IOException {
        if(bearer == null) {
            String token = username + ":" + password;
            String base64Token = Base64.encodeBase64String(token.getBytes(StandardCharsets.UTF_8));
            requestContext.getHeaders().add(HEADER_AUTHORIZATION, AUTH_BASIC + base64Token);
        } else {
            requestContext.getHeaders().add(HEADER_AUTHORIZATION, AUTH_BEARER + bearer);
        }
    }
}
