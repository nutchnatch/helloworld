package com.ossnms.web.api.oif.proxy.api.client.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.Objects;

/**
 * Created by 68500245 on 19-01-2017.
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
final public class SdnRestErrorObject implements Serializable {

    @JsonProperty
    private String errorCode;

    @JsonProperty
    private String errorDescription;

    /**
     * @return
     */
    public String getErrorCode() {

        return errorCode;
    }

    /**
     * @param errorCode
     */
    public void setErrorCode( String errorCode ) {

        this.errorCode = errorCode;
    }

    public String getErrorDescription() {

        return errorDescription;
    }

    /**
     * @param errorDescription
     */
    public void setErrorDescription( String errorDescription ) {

        this.errorDescription = errorDescription;
    }

    /**
     * @inheritDoc
     */
    @Override
    public boolean equals( Object o ) {

        if ( this == o ) {
            return true;
        }
        if ( o == null || getClass() != o.getClass() ) {
            return false;
        }
        SdnRestErrorObject that = (SdnRestErrorObject) o;
        return Objects.equals( errorCode, that.errorCode ) &&
            Objects.equals( errorDescription, that.errorDescription );
    }
    
    /**
     * @inheritDoc
     */
    @Override
    public int hashCode() {

        return Objects.hash( errorCode, errorDescription );
    }
}