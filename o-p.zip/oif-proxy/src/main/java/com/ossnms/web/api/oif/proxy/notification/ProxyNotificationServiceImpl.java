package com.ossnms.web.api.oif.proxy.notification;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ossnms.web.api.oif.proxy.api.annotation.SystemProperty;
import com.ossnms.web.api.oif.proxy.api.client.call.CallObject;
import com.ossnms.web.api.oif.proxy.api.client.common.CommonWorker;
import com.ossnms.web.api.oif.proxy.api.client.network.NetworkNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.network.NetworkObject;
import com.ossnms.web.api.oif.proxy.api.client.network.NetworkObjectList;
import com.ossnms.web.api.oif.proxy.api.common.util.backoff.ExponentialBackOff;
import com.ossnms.web.api.oif.proxy.api.common.util.backoff.ExponentialBackOffException;
import com.ossnms.web.api.oif.proxy.api.notification.ProxyNotificationHandler;
import com.ossnms.web.api.oif.proxy.api.notification.model.EventType;
import com.ossnms.web.api.oif.proxy.api.notification.model.InboundNotification;
import com.ossnms.web.api.oif.proxy.api.notification.model.TypedInboundNotification;
import com.ossnms.web.api.oif.proxy.api.producer.ProxyProducer;
import com.ossnms.web.api.oif.proxy.impl.call.CallObjectHandler;
import com.ossnms.web.api.oif.proxy.impl.network.NetworkObjectHandler;
import com.ossnms.web.provider.common.api.notification.NotificationChannel;
import com.ossnms.web.provider.common.api.notification.NotificationHandler;
import com.ossnms.web.provider.common.api.notification.NotificationHandlerException;
import com.ossnms.web.provider.common.api.notification.NotificationService;
import com.ossnms.web.provider.sdn.api.annotation.Proxy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.context.Destroyed;
import javax.enterprise.context.Initialized;
import javax.enterprise.event.Observes;
import javax.inject.Inject;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static com.ossnms.web.api.oif.proxy.api.notification.model.EntityType.CALL;
import static com.ossnms.web.api.oif.proxy.api.notification.model.EntityType.DOMAIN;
import static java.lang.String.format;

/**
 * This notification service has the responsability to initialize the Websocket clients for the configured (if any)
 * OIF instance
 */
@Proxy
@ApplicationScoped
public class ProxyNotificationServiceImpl implements NotificationService, ProxyNotificationHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProxyNotificationServiceImpl.class);

    private static final String HOST_LOCAL = "localhost";
    private static final String PORT_LOCAL = "9444";

    private static final String FORMAT_OIF_ENDPOINT_BASE = "https://%s:%s";
    private static final String FORMAT_OIF_ENDPOINT_MUTUAL = "/sdn-mutual";
    private static final String FORMAT_OIF_ENDPOINT_NOTIFICATIONS = "/com.oiforum.json/ndm/network/%s/notifications";

    @Inject
    private ExponentialBackOff exponentialBackOff;

    /**
     *
     */
    private static final AtomicLong counter = new AtomicLong(0);

    /**
     *
     */
    private static final AtomicBoolean isInitialized = new AtomicBoolean(false);

    /**
     *
     */
    private static Map<String, WebSocketClient> clientMap = new ConcurrentHashMap<>();

    /**
     *
     */
    private NotificationHandler notificationHandler;

    /**
     *
     */
    private String oifLocation;

    /**
     * Default constructor
     */
    public ProxyNotificationServiceImpl(){}

    /**
     * CDI enabled constructor
     *
     * @param oifLocation configured server location for OIF Interface
     */
    @Inject
    public ProxyNotificationServiceImpl(@SystemProperty("oif.location") String oifLocation) {
        this.oifLocation = oifLocation;
    }

    /**
     *
     * @param init
     */
    public void init(@Observes @Initialized(ApplicationScoped.class) Object init) {
        if(!isInitialized.getAndSet(true)) {
            long start = System.currentTimeMillis();
            LOGGER.info("START >> Initialization of Notification Service :: Registering Clients");
            // get all the domains and create a notification client for each one
            registerClients();
            LOGGER.info("END   >> Initialization of Notification Service :: Registering Clients :: Took {} milliseconds", System.currentTimeMillis() - start);
        }
    }

    /**
     *
     * @param destroy
     */
    public void destroy(@Observes @Destroyed(ApplicationScoped.class) Object destroy) {
        if(isInitialized.getAndSet(false)) {
            long start = System.currentTimeMillis();
            LOGGER.info("START >> Destruction of Notification Service :: Destroying Clients");
            shutdownClients();
            LOGGER.info("END   >> Destruction of Notification Service :: Destroying Clients :: Took {} milliseconds", System.currentTimeMillis() - start);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void subscribe(NotificationChannel channel, NotificationHandler handler) {
        if(this.notificationHandler == null) {
            this.notificationHandler = handler;
        }
        // increment the counter of subscriptions
        long l = counter.incrementAndGet();
        LOGGER.info("Subscription counter >> {}", l);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void unsubscribe(NotificationChannel channel, NotificationHandler handler) {
        // decrement the counter of subscriptions
        long l = counter.decrementAndGet();
        LOGGER.info("Subscription counter >> {}", l);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void subscribe(Collection<NotificationChannel> channels, NotificationHandler handler) {
        throw new UnsupportedOperationException();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void unsubscribe(Collection<NotificationChannel> channels, NotificationHandler handler) {
        throw new UnsupportedOperationException();
    }

    /**
     *
     */
    private void registerClients() {
        if(oifLocation != null && !oifLocation.isEmpty()) {
            exponentialBackOff.execute(
                5,2,10,() -> {
                    // get all the domains and create a notification client for each one
                    getAllAvailableDomains()
                        .map(CommonWorker::toId)
                        .forEach(addClient());
                }
            );
        }
    }



    /**
     *
     */
    private void shutdownClients() {
        // remove all the clients
        clientMap.forEach(removeClientConsumer());
    }

    /**
     *
     * @return
     */
    private Consumer<String> addClient() {
        return id -> {
            LOGGER.info("       Notification Service registering Web Socket client for id {}", id);
            clientMap.computeIfAbsent(id, this::generateWebSocketClient);
        };
    }

    /**
     *
     * @return
     */
    private BiFunction<String, WebSocketClient, WebSocketClient> removeClientFunction() {
        return (domainId, webSocketClient) -> {
            removeClientConsumer().accept(domainId, webSocketClient);
            return null;
        };
    }

    /**
     *
     * @return
     */
    private BiConsumer<String, WebSocketClient> removeClientConsumer() {
        return (domainId, webSocketClient) -> {
            LOGGER.info("       Notification Service removing Web Socket Client for id {}", domainId);
            webSocketClient.shutdown();
        };
    }

    /**
     *
     * @return
     */
    private Stream<String> getAllAvailableDomains() throws ExponentialBackOffException {
        // produce a proxy to network objects
        // this proxy will use the reverse-proxy endpoint configured to be used with Mutual-Authentication
        NetworkNDMClient proxy = ProxyProducer.getProxy(
            NetworkNDMClient.class,
            getHostname(),
            PORT_LOCAL
        );

        // get all the domains, without filter
        Response response = proxy.getAll(null);
        if(response.getStatus() == 200) {
            NetworkObjectList networkObjectList = response.readEntity(NetworkObjectList.class);
            return Arrays.stream(networkObjectList.id);
        } else {
            throw new ExponentialBackOffException("Could not get the domains from the OIF Rest");
        }
    }

    /**
     *
     */
    private String getHostname() {
        return format(FORMAT_OIF_ENDPOINT_BASE + FORMAT_OIF_ENDPOINT_MUTUAL, HOST_LOCAL, PORT_LOCAL);
    }

    /**
     *
     * @param id
     * @return
     */
    private WebSocketClient generateWebSocketClient(String id) {
        WebSocketClient client = new WebSocketClient()
            .setSecure(true)
            .setHostname(HOST_LOCAL)
            .setPort(PORT_LOCAL)
            .setEndpoint(format(FORMAT_OIF_ENDPOINT_MUTUAL.concat(FORMAT_OIF_ENDPOINT_NOTIFICATIONS), id))
            .setNotificationHandler(this)
            .initiate();

        return client.isActive() ? client : null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void handle(InboundNotification notification, String message) throws IOException, NotificationHandlerException {
        if (notification.getEntityType() == DOMAIN) {
            handleDomainNotification(message);
        } else if (notification.getEntityType() == CALL) {
            handleCallNotification(message);
        } else {
            LOGGER.warn("Received unsupported entity type. Notification discarded.");
        }
    }

    /**
     *
     * @param message
     */
    private void handleCallNotification(String message) throws IOException, NotificationHandlerException {
        TypedInboundNotification<CallObject> typedNotification = new ObjectMapper().readValue(message, new TypeReference<TypedInboundNotification<CallObject>>() {});
        // issue the notification
        CallObjectHandler.issueNotification(typedNotification, notificationHandler);
    }

    /**
     * Handles the domain notification. Parses the inbound notification and further processes it. In this case,
     * creations or deletions of domains must result in an update to the map of subscribed domains
     *
     * @param message the message received
     * @throws NotificationHandlerException if the handling of this notification could not be performed
     * @throws IOException
     */
    private void handleDomainNotification(String message) throws NotificationHandlerException, IOException {
        TypedInboundNotification<NetworkObject> typedNotification = new ObjectMapper().readValue(message, new TypeReference<TypedInboundNotification<NetworkObject>>() {});

        // get the domain id
        String id = typedNotification.getBody().id;
        id = CommonWorker.toId(id);

        // get and process the event type
        EventType eventType = typedNotification.getEventType();

        // it is required that creation and deletion events update the list of websocket clients
        switch (eventType) {
            case CREATE:
                // add a new client
                LOGGER.debug("\n     CREATE >> {}", id);
                clientMap.putIfAbsent(id, generateWebSocketClient(id));
                break;
            case DELETE:
                // remove the client
                LOGGER.debug("\n     DELETE >> {}", id);
                clientMap.computeIfPresent(id, removeClientFunction());
                break;
            default:
                LOGGER.debug("NotificationService was not altered based on notification of type {} for domain {}", eventType, id);
        }

        // issue the notification
        NetworkObjectHandler.issueNotification(typedNotification, notificationHandler);
    }
}
