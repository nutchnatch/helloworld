package com.ossnms.web.api.oif.proxy.api.client.call;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Objects;

/**
 *
 */
public class ExcludeObject extends IncludeObject {

    private static final long serialVersionUID = -5244948632524358777L;

    @JsonProperty( "coriant.constraintClassRelax" )
    private List<String> constraintClassRelax;

    @JsonProperty( "coriant.constraintClassStrict" )
    private List<String> constraintClassStrict;

    /**
     *
     */
    public List<String> getConstraintClassRelax() {
        return constraintClassRelax;
    }

    public ExcludeObject setConstraintClassRelax(List<String> constraintClassRelax) {
        this.constraintClassRelax = constraintClassRelax;
        return this;
    }

    /**
     *
     */
    public List<String> getConstraintClassStrict() {
        return constraintClassStrict;
    }

    public ExcludeObject setConstraintClassStrict(List<String> constraintClassStrict) {
        this.constraintClassStrict = constraintClassStrict;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        ExcludeObject that = (ExcludeObject) o;
        return Objects.equals(getConstraintClassRelax(), that.getConstraintClassRelax()) &&
            Objects.equals(getConstraintClassStrict(), that.getConstraintClassStrict());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getConstraintClassRelax(), getConstraintClassStrict());
    }
}
