package com.ossnms.web.api.oif.proxy.api.client.common;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class RiskObject implements BaseObject {

    private static final long serialVersionUID = -2914288820296346564L;

    @JsonIgnore
    private String domainId;

    @JsonProperty( "coriant.riskId" )
    private String id;

    @JsonProperty( "coriant.riskName" )
    private String name;


    /**
     * @return
     */
    public String getId() {

        return id;
    }

    /**
     * @param id
     * @return
     */
    public RiskObject setId( String id ) {

        this.id = id;
        return this;
    }

    /**
     * @return
     */
    public String getDomainId() {

        return domainId;
    }

    /**
     * @param domainId
     * @return
     */
    public RiskObject setDomainId( String domainId ) {

        this.domainId = domainId;
        return this;
    }

    /**
     * @return
     */
    public String getName() {

        return name;
    }

    /**
     * @param name
     * @return
     */
    public RiskObject setName( String name ) {

        this.name = name;
        return this;
    }
}