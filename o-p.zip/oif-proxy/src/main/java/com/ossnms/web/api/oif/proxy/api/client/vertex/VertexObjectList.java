package com.ossnms.web.api.oif.proxy.api.client.vertex;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.List;
import java.util.Objects;

/**
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VertexObjectList implements BaseObject {

    private static final long serialVersionUID = 8032488872936440545L;

    @JsonProperty(value = "id", required = true)
    private List<String> vertexes;

    /**
     *
     */
    public List<String> getVertexes() {
        return vertexes;
    }

    /**
     *
     * @param vertexes
     * @return
     */
    public VertexObjectList setVertexes(List<String> vertexes) {
        this.vertexes = vertexes;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        VertexObjectList that = (VertexObjectList) o;
        return Objects.equals(getVertexes(), that.getVertexes());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getVertexes());
    }
}
