package com.ossnms.web.api.oif.proxy.api.common.util.backoff;

/**
 *
 */
public class ExponentialBackOffException extends Exception {

    /**
     * {@inheritDoc}
     */
    public ExponentialBackOffException() {
    }

    /**
     * {@inheritDoc}
     */
    public ExponentialBackOffException(String message) {
        super(message);
    }

    /**
     * {@inheritDoc}
     */
    public ExponentialBackOffException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * {@inheritDoc}
     */
    public ExponentialBackOffException(Throwable cause) {
        super(cause);
    }

    /**
     * {@inheritDoc}
     */
    public ExponentialBackOffException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
