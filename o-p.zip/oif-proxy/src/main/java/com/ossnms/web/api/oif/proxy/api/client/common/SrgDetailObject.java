package com.ossnms.web.api.oif.proxy.api.client.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.ArrayList;
import java.util.List;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class SrgDetailObject implements BaseObject {

    private static final long serialVersionUID = -2767120046264686510L;

    @JsonProperty( "coriant.riskClass" )
    private String riskClass;

    @JsonProperty( "coriant.riskStartTime" )
    private String riskStartTime;

    @JsonProperty( "coriant.riskStopTime" )
    private String riskStopTime;

    @JsonProperty( "coriant.risks" )
    private List<RiskObject> risks;


    /**
     * Default constructor
     */
    public SrgDetailObject() {

        this.risks = new ArrayList<>();
    }

    /**
     *
     * @return
     */
    public String getRiskClass() {

        return riskClass;
    }

    /**
     *
     * @param riskClass
     * @return
     */
    public SrgDetailObject setRiskClass( String riskClass ) {

        this.riskClass = riskClass;
        return this;
    }

    /**
     *
     * @return
     */
    public String getRiskStartTime() {

        return riskStartTime;
    }

    /**
     *
     * @param riskStartTime
     * @return
     */
    public SrgDetailObject setRiskStartTime( String riskStartTime ) {

        this.riskStartTime = riskStartTime;
        return this;
    }

    /**
     *
     * @return
     */
    public String getRiskStopTime() {

        return riskStopTime;
    }

    /**
     *
     * @param riskStopTime
     * @return
     */
    public SrgDetailObject setRiskStopTime( String riskStopTime ) {

        this.riskStopTime = riskStopTime;
        return this;
    }

    /**
     *
     * @return
     */
    public List<RiskObject> getRisks() {

        return risks;
    }

    /**
     *
     * @param risks
     * @return
     */
    public SrgDetailObject setRisks( List<RiskObject> risks ) {

        this.risks = risks;
        return this;
    }
}
