package com.ossnms.web.api.oif.proxy.api.executor;

import com.ossnms.web.provider.sdn.api.annotation.Proxy;

import javax.annotation.Resource;
import javax.enterprise.concurrent.ManagedScheduledExecutorService;
import javax.enterprise.inject.Produces;
import javax.inject.Singleton;
import java.util.concurrent.ScheduledExecutorService;

/**
 *
 */
@Singleton
public class ExecutorServiceManager {

    @Resource
    private ManagedScheduledExecutorService managedScheduledExecutorService;

    @Produces
    @Proxy
    public ScheduledExecutorService scheduledExecutorService() {
        return managedScheduledExecutorService;
    }
}
