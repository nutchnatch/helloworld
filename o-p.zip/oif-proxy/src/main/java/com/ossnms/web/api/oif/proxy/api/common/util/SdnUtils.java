package com.ossnms.web.api.oif.proxy.api.common.util;

import com.ossnms.web.api.oif.proxy.api.common.OIFProxyConstant;

import javax.ws.rs.core.Response;
import java.util.Collection;
import java.util.regex.PatternSyntaxException;

/**
 *
 */
public final class SdnUtils {

    private static final String CONTENT_RANGE_HEADER = "Content-range";
    private static final String CALL_URI_LITERAL = "call";
    private static final String ENDPOINT_URI_LITERAL = "endpoint";

    /**
     * Hidden utility class constructor
     */
    private SdnUtils() {}


    /**
     *
     * @param restEntityUri
     * @return
     */
    public static String extractId( String restEntityUri ) {

        String id = null;

        if ( restEntityUri != null ) {

            String[] parts = extractUriParts( restEntityUri );

            if ( parts.length > 1 ) {

                id = parts[ parts.length - 1 ];
            }
        }

        return id;
    }

    /**
     *
     * @param sdnCallUri
     * @return
     */
    public static String extractCallDomainId( String sdnCallUri ) {

        String domainId = null;

        if ( sdnCallUri != null ) {

            String[] parts = extractUriParts( sdnCallUri );

            if ( parts.length > 4 && CALL_URI_LITERAL.equals( parts[ parts.length-2 ] ) ) {

                domainId = parts[ parts.length - 3 ];
            }
        }

        return domainId;
    }


    /**
     *
     * @param restEntityUri
     * @return
     */
    private static String[] extractUriParts( String restEntityUri ) {

        return restEntityUri.split( "/" );
    }


    /**
     *
     * @param response
     * @return
     */
    public static Integer extractTotal( Response response ) {

        String contentRange = response.getHeaderString( CONTENT_RANGE_HEADER );

        if ( contentRange == null ) {

            return null;
        }

        try {

            String[] parts = extractUriParts( contentRange );

            if ( parts.length == 2 ) {

                return Integer.parseInt( parts[ 1 ] );
            }
            else {

                return null;
            }
        }
        catch ( PatternSyntaxException|NumberFormatException e ) {

            return null;
        }
    }


    /**
     *
     * @param response
     * @param collection
     * @return
     */
    public static Integer extractTotal( Response response, Collection<?> collection ) {

        Integer total = extractTotal( response );

        if ( total != null ) {

            return total;
        }
        else {

            return collection.size();
        }
    }


    /**
     *
     * @param id
     * @return
     */
    public static String buildUri( String id ) {

        return OIFProxyConstant.URL_NDM_NETWORK + ( id == null || id.isEmpty() ? "" : "/" + id );
    }

    /**
     *
     * @param domainId
     * @param id
     * @param restEntityName
     * @return
     */
    public static String buildUri( String domainId , String id, String restEntityName ) {

        return OIFProxyConstant.URL_NDM_NETWORK + "/" + domainId + "/" + restEntityName + ( id == null || id.isEmpty() ? "" : "/" + id );
    }

    /**
     *
     * @param domainId
     * @param topologyId
     * @param id
     * @param restEntityName
     * @return
     */
    public static String buildUri( String domainId , String topologyId, String id,  String restEntityName ) {

        return OIFProxyConstant.URL_NDM_NETWORK + "/" + domainId + "/topology/" + topologyId + "/" + restEntityName + ( id == null || id.isEmpty() ? "" : "/" + id );
    }

    /**
     *
     * @param domainId
     * @param topologyId
     * @param vertexId
     * @param id
     * @param restEntityName
     * @return
     */
    public static String buildUri( String domainId , String topologyId, String vertexId, String id,  String restEntityName ) {

        return OIFProxyConstant.URL_NDM_NETWORK + "/" + domainId + "/topology/" + topologyId + "/vertexId/" + vertexId + "/" + restEntityName + ( id == null || id.isEmpty() ? "" : "/" + id );
    }

    /**
     *
     * @param domainId
     * @param endpId
     * @return
     */
    public static String buildEndpointUri( String domainId , String endpId ) {

        return buildUri( domainId, endpId, ENDPOINT_URI_LITERAL );
    }
}