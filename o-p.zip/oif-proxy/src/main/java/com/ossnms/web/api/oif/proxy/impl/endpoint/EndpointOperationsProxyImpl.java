package com.ossnms.web.api.oif.proxy.impl.endpoint;

import com.ossnms.web.provider.sdn.api.annotation.Proxy;
import com.ossnms.web.api.oif.proxy.api.client.endpoint.EndpointNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.endpoint.EndpointObjectList;
import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.sdn.model.endpoint.Endpoint;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointField;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointID;
import com.ossnms.web.provider.sdn.model.endpoint.EndpointSummary;
import com.ossnms.web.provider.sdn.operations.endpoint.EndpointEntityOperations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.ws.rs.core.Response;
import java.util.Collection;

/**
 *
 */
@RequestScoped
public class EndpointOperationsProxyImpl implements EndpointEntityOperations {

    private static final Logger LOGGER = LoggerFactory.getLogger(EndpointOperationsProxyImpl.class);

    private Instance<EndpointNDMClient> endpointNDMClientInstance;

    /**
     * no-args default
     */
    public EndpointOperationsProxyImpl() {
    }

    @Inject
    public EndpointOperationsProxyImpl(@Proxy Instance<EndpointNDMClient> endpointNDMClientInstance) {
        this.endpointNDMClientInstance = endpointNDMClientInstance;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public EndpointID insert(SecurityToken securityToken, Endpoint entity) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public EndpointID update(SecurityToken securityToken, Endpoint entity) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void delete(SecurityToken securityToken, EndpointID id) {

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public EndpointSummary getSummary(SecurityToken securityToken, EndpointID id) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Endpoint getDetails(SecurityToken securityToken, EndpointID id) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<EndpointSummary, EndpointField> getAllSummary(SecurityToken securityToken, Collection<EndpointID> ids) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<EndpointSummary, EndpointField> getAllSummary(SecurityToken securityToken, Collection<Filter<EndpointField>> filterBy, Sort<EndpointField> sortBy, Page page) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<Endpoint, EndpointField> getAll(SecurityToken securityToken, Collection<EndpointID> ids) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<Endpoint, EndpointField> getAll(SecurityToken securityToken, Collection<Filter<EndpointField>> filterBy, Sort<EndpointField> sortBy, Page page) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<EndpointID, EndpointField> getAllIds(SecurityToken securityToken, Collection<Filter<EndpointField>> filterBy, Sort<EndpointField> sortBy, Page page) {

        Response response = endpointNDMClientInstance.get().getAll("*", null);
        EndpointObjectList endpointObjectList = response.readEntity(EndpointObjectList.class);

        assert endpointObjectList != null;

        return null;
    }
}
