package com.ossnms.web.api.oif.proxy.api.client.call;

import com.ossnms.web.api.oif.proxy.api.common.network.NetworkBaseClient;

import javax.ws.rs.*;
import javax.ws.rs.core.Response;

import static com.ossnms.web.api.oif.proxy.api.common.OIFProxyConstant.URL_NDM_CALL;

/**
 *
 */
@Path( URL_NDM_CALL )
@Consumes( "application/json" )
@Produces( "application/json" )
public interface CallNDMClient extends NetworkBaseClient<CallObject> {


    /**
     * @param networkId
     * @return
     */
    @POST
    @Path( "/{id}/enforce" )
    Response enforce( @PathParam( "networkId" ) String networkId, @PathParam( "id" ) String id );
}