package com.ossnms.web.api.oif.proxy.impl.call;

import com.ossnms.web.api.oif.proxy.api.client.call.CallNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.call.CallObject;
import com.ossnms.web.api.oif.proxy.api.client.call.CallObjectFactory;
import com.ossnms.web.api.oif.proxy.api.client.call.CallObjectList;
import com.ossnms.web.api.oif.proxy.api.client.call.EnforceResponseObject;
import com.ossnms.web.api.oif.proxy.api.client.common.CommonWorker;
import com.ossnms.web.api.oif.proxy.api.client.connection.ConnectionNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.edge.EdgeNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.end.EndNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.endpoint.EndpointNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.vertex.VertexNDMClient;
import com.ossnms.web.api.oif.proxy.api.common.result.GenericErrorCode;
import com.ossnms.web.api.oif.proxy.api.common.util.SdnUtils;
import com.ossnms.web.provider.common.api.model.EntityBase;
import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.filter.FilterOperation;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.result.ProcessableResult;
import com.ossnms.web.provider.common.api.result.ProcessableSingleResult;
import com.ossnms.web.provider.common.api.result.enumerable.Status;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.sdn.api.annotation.Proxy;
import com.ossnms.web.provider.sdn.model.call.Call;
import com.ossnms.web.provider.sdn.model.call.CallField;
import com.ossnms.web.provider.sdn.model.call.CallID;
import com.ossnms.web.provider.sdn.model.call.CallSummary;
import com.ossnms.web.provider.sdn.model.common.enumerable.ErrorCode;
import com.ossnms.web.provider.sdn.operations.call.ProcessableCallEntityOperations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.ProcessingException;
import javax.ws.rs.core.Response;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static com.ossnms.web.provider.common.api.result.enumerable.Status.OK;

/**
 *
 */
@RequestScoped
public class CallOperationsProxyImpl implements ProcessableCallEntityOperations {

    private static final Logger LOGGER = LoggerFactory.getLogger(CallOperationsProxyImpl.class);

    private static final String CALL_IS_NULL_MSG = "Call is null!";
    private static final String CALLID_IS_NULL_MSG = "CallID is null!";
    private static final String GIVEN_CALLID_IS_INVALID_MSG = "Given call ID is invalid!";

    private CallNDMClient callClientInstance;
    private VertexNDMClient vertexNDMClientInstance;
    private EndNDMClient edgeEndNDMClientInstance;
    private EdgeNDMClient edgeNDMClientInstance;
    private EndpointNDMClient endpointNDMClientInstance;
    private ConnectionNDMClient connectionNDMClientInstance;

    /**
     * Default no-args constructor
     */
    public CallOperationsProxyImpl() {
    }

    @Inject
    public CallOperationsProxyImpl(
        @Proxy CallNDMClient callClientInstance,
        @Proxy VertexNDMClient vertexNDMClientInstance,
        @Proxy EndNDMClient edgeEndNDMClientInstance,
        @Proxy EdgeNDMClient edgeNDMClientInstance,
        @Proxy EndpointNDMClient endpointNDMClientInstance,
        @Proxy ConnectionNDMClient connectionNDMClientInstance
    ) {
        this.callClientInstance = callClientInstance;
        this.vertexNDMClientInstance = vertexNDMClientInstance;
        this.edgeNDMClientInstance = edgeNDMClientInstance;
        this.edgeEndNDMClientInstance = edgeEndNDMClientInstance;
        this.endpointNDMClientInstance = endpointNDMClientInstance;
        this.connectionNDMClientInstance = connectionNDMClientInstance;
    }

    private static int callIDObjectComparator(CallID e1, CallID e2) {
        int compareByDomain = Long.compare(
            Long.parseLong(e1.getDomainId()),
            Long.parseLong(e2.getDomainId())
        );

        if (compareByDomain == 0) {
            return Long.compare(
                Long.parseLong(e1.getID()),
                Long.parseLong(e2.getID())
            );
        } else {
            return compareByDomain;
        }
    }

    /**
     * @param errMsg
     * @return
     */
    private static ProcessableResult<CallID, CallField, ErrorCode> genericServerSideError(String errMsg) {

        return
            new ProcessableResult.Builder<CallID, CallField, ErrorCode>(Collections.emptyList(), 0)
                .setOperationStatus(Status.SERVER_ERROR)
                .setErrorCode(ErrorCode.GENERIC)
                .setErrorMessage(errMsg)
                .build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableSingleResult<CallSummary, ErrorCode> getSummary(SecurityToken securityToken, CallID id) {

        if (id != null && id.getID() != null) {

            Response response = callClientInstance.get(id.getDomainId(), id.getID());

            ProcessableSingleResult<CallObject, GenericErrorCode> callDetails =
                CommonWorker.fromResponse(CallObject.class).apply(response);

            switch (callDetails.getOperationStatus()) {

                case OK:

                    CallSummary.Builder b = new CallSummary.Builder(id);

                    CallBuilder.toCallSummary(
                        callDetails.getEntity(),
                        b,
                        vertexNDMClientInstance,
                        endpointNDMClientInstance
                    );

                    return new ProcessableSingleResult.Builder<CallSummary, ErrorCode>()
                        .ok(b.build())
                        .build();


                default:
                    return propagateErrorResultFrom(callDetails);
            }
        }

        return buildErrorResult(Status.BAD_REQUEST, ErrorCode.GENERIC, CALLID_IS_NULL_MSG);
    }

    /**
     * @param status
     * @param errorCode
     * @param errorMsg
     * @param <T>
     * @return
     */
    private <T extends EntityBase> ProcessableSingleResult<T, ErrorCode> buildErrorResult(Status status, ErrorCode errorCode, String errorMsg) {

        return new ProcessableSingleResult.Builder<T, ErrorCode>()
            .operationStatus(status)
            .errorMessage(errorMsg)
            .build();
    }

    /**
     * @param callDetails
     * @param <T>
     * @return
     */
    private <T extends EntityBase> ProcessableSingleResult<T, ErrorCode> propagateErrorResultFrom(ProcessableSingleResult<?, GenericErrorCode> callDetails) {

        return new ProcessableSingleResult.Builder<T, ErrorCode>()
            .operationStatus(callDetails.getOperationStatus())
            .errorMessage(callDetails.getErrorMessage())
            .build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableSingleResult<Call, ErrorCode> insert(SecurityToken securityToken, Call entity) {

        if (entity == null) {

            return buildErrorResult(Status.BAD_REQUEST, ErrorCode.GENERIC, CALLID_IS_NULL_MSG);
        }

        CallID callID = entity.getID();

        if (callID == null || callID.getDomainId() == null || callID.getID() != null) {

            return buildErrorResult(Status.BAD_REQUEST, ErrorCode.GENERIC, GIVEN_CALLID_IS_INVALID_MSG);
        }

        CallObject callToCreate = new CallObjectFactory().fromForCreate(entity).build();

        Response response = callClientInstance.create(entity.getID().getDomainId(), callToCreate);

        ProcessableSingleResult<CallObject, GenericErrorCode> callDetails =
            CommonWorker.fromResponse(CallObject.class).apply(response);

        switch (callDetails.getOperationStatus()) {

            case OK:

                Call.Builder b = new Call.Builder(
                    new CallID.Builder(entity.getID().getDomainId(), CommonWorker.toId( callDetails.getEntity().getId() ) )
                        .build()
                );

                CallBuilder.toCall(
                    callDetails.getEntity(),
                    b,
                    vertexNDMClientInstance,
                    edgeEndNDMClientInstance,
                    edgeNDMClientInstance,
                    endpointNDMClientInstance,
                    connectionNDMClientInstance
                );

                return new ProcessableSingleResult.Builder<Call, ErrorCode>()
                    .ok(b.build())
                    .build();


            default:

                return propagateErrorResultFrom(callDetails);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableSingleResult<Call, ErrorCode> update(SecurityToken securityToken, Call entity) {

        if (entity == null) {

            return buildErrorResult(Status.BAD_REQUEST, ErrorCode.GENERIC, CALL_IS_NULL_MSG);
        }

        CallObject callToUpdate = new CallObjectFactory().fromForUpdate(entity).build();

        Response response = callClientInstance.update(entity.getID().getDomainId(), entity.getID().getID(), callToUpdate);

        ProcessableSingleResult<CallObject, GenericErrorCode> callDetails =
            CommonWorker.fromResponse(CallObject.class).apply(response);

        switch (callDetails.getOperationStatus()) {

            case OK:

                CallObject updatedCall = callDetails.getEntity();

                return new ProcessableSingleResult.Builder<Call, ErrorCode>()
                    .ok(entity)
                    .build();


            default:

                return propagateErrorResultFrom(callDetails);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableSingleResult<CallID, ErrorCode> delete(SecurityToken securityToken, CallID id) {

        if (id == null) {

            return buildErrorResult(Status.BAD_REQUEST, ErrorCode.GENERIC, CALLID_IS_NULL_MSG);
        }

        Response response = callClientInstance.delete(id.getDomainId(), id.getID());

        ProcessableSingleResult<Serializable, GenericErrorCode> deleteResponse =
            CommonWorker.proccessDelete().apply(response);

        switch (deleteResponse.getOperationStatus()) {

            case OK:

                return new ProcessableSingleResult.Builder<CallID, ErrorCode>()
                    .ok(id)
                    .build();


            default:

                return propagateErrorResultFrom(deleteResponse);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableSingleResult<Call, ErrorCode> getDetails(SecurityToken securityToken, CallID id) {

        if (id != null && id.getID() != null) {

            Response response = callClientInstance.get(id.getDomainId(), id.getID());

            ProcessableSingleResult<CallObject, GenericErrorCode> callDetails =
                CommonWorker.fromResponse(CallObject.class).apply(response);

            switch (callDetails.getOperationStatus()) {

                case OK:

                    Call.Builder b = new Call.Builder(id);

                    CallBuilder.toCall(
                        callDetails.getEntity(),
                        b,
                        vertexNDMClientInstance,
                        edgeEndNDMClientInstance,
                        edgeNDMClientInstance,
                        endpointNDMClientInstance,
                        connectionNDMClientInstance
                    );

                    return new ProcessableSingleResult.Builder<Call, ErrorCode>()
                        .ok(b.build())
                        .build();


                default:

                    return propagateErrorResultFrom(callDetails);
            }
        }

        return buildErrorResult(Status.BAD_REQUEST, ErrorCode.GENERIC, CALLID_IS_NULL_MSG);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableResult<CallSummary, CallField, ErrorCode> getAllSummary(SecurityToken securityToken, Collection<CallID> ids) {

        Collection<CallID> idsToIterate = ids;

        if (ids == null || ids.isEmpty()) {

            idsToIterate = getAllIds(securityToken, Collections.emptyList(), null, null).getResultCollection();
        }

        List<ProcessableSingleResult<CallSummary, ErrorCode>> summaryResults =
            idsToIterate.stream()
                .map(id -> getSummary(securityToken, id))
                .collect(Collectors.toList());

        List<CallSummary> calls = summaryResults.stream()
            .filter(item -> OK.equals(item.getOperationStatus()))
            .map(ProcessableSingleResult::getEntity)
            .collect(Collectors.toList());

        ProcessableResult.Builder<CallSummary, CallField, ErrorCode> result =
            new ProcessableResult.Builder<>(calls, calls.size());

        if (summaryResults.size() == calls.size()) {

            result.setOperationStatus(OK);
        } else {

            for (ProcessableSingleResult<CallSummary, ErrorCode> detail : summaryResults) {

                if (!OK.equals(detail.getOperationStatus())) {

                    result.setErrorCode(detail.getErrorCode())
                        .setErrorMessage(detail.getErrorMessage())
                        .setOperationStatus(detail.getOperationStatus());

                    break;
                }
            }
        }

        return result.build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableResult<CallSummary, CallField, ErrorCode> getAllSummary(SecurityToken securityToken, Collection<Filter<CallField>> filterBy, Sort<CallField> sortBy, Page page) {

        ProcessableResult<CallID, CallField, ErrorCode> allIds = getAllIds(securityToken, filterBy, sortBy, page);

        List<ProcessableSingleResult<CallSummary, ErrorCode>> summaryResults =
            allIds.getResultCollection().stream()
                .map(id -> getSummary(securityToken, id))
                .collect(Collectors.toList());

        List<CallSummary> calls = summaryResults.stream()
            .filter(item -> OK.equals(item.getOperationStatus()))
            .map(ProcessableSingleResult::getEntity)
            .collect(Collectors.toList());

        ProcessableResult.Builder<CallSummary, CallField, ErrorCode> result =
            new ProcessableResult.Builder<>(calls, calls.size());

        if (allIds.getResultCollection().size() == calls.size()) {

            result.setOperationStatus(OK);
        } else {

            for (ProcessableSingleResult<CallSummary, ErrorCode> detail : summaryResults) {

                if (!OK.equals(detail.getOperationStatus())) {

                    result.setErrorCode(detail.getErrorCode())
                        .setErrorMessage(detail.getErrorMessage())
                        .setOperationStatus(detail.getOperationStatus());

                    break;
                }
            }
        }

        return result.build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableResult<Call, CallField, ErrorCode> getAll(SecurityToken securityToken, Collection<CallID> ids) {

        Collection<CallID> idsToIterate = ids;

        if (ids == null || ids.isEmpty()) {

            idsToIterate = getAllIds(securityToken, Collections.emptyList(), null, null).getResultCollection();
        }

        List<ProcessableSingleResult<Call, ErrorCode>> detailsResults =
            idsToIterate.stream()
                .map(id -> getDetails(securityToken, id))
                .collect(Collectors.toList());

        List<Call> calls = detailsResults.stream()
            .filter(item -> OK.equals(item.getOperationStatus()))
            .map(ProcessableSingleResult::getEntity)
            .collect(Collectors.toList());

        ProcessableResult.Builder<Call, CallField, ErrorCode> result =
            new ProcessableResult.Builder<>(calls, calls.size());

        if (detailsResults.size() == calls.size()) {
            result.setOperationStatus(OK);
        } else {

            for (ProcessableSingleResult<Call, ErrorCode> detail : detailsResults) {

                if (!OK.equals(detail.getOperationStatus())) {

                    result.setErrorCode(detail.getErrorCode())
                        .setErrorMessage(detail.getErrorMessage())
                        .setOperationStatus(detail.getOperationStatus());

                    break;
                }
            }
        }

        return result.build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableResult<Call, CallField, ErrorCode> getAll(SecurityToken securityToken, Collection<Filter<CallField>> filterBy, Sort<CallField> sortBy, Page page) {

        ProcessableResult<CallID, CallField, ErrorCode> allIds = getAllIds(securityToken, filterBy, sortBy, page);

        List<ProcessableSingleResult<Call, ErrorCode>> detailsResults =
            allIds.getResultCollection().stream()
                .map(id -> getDetails(securityToken, id))
                .collect(Collectors.toList());

        List<Call> calls = detailsResults.stream()
            .filter(item -> OK.equals(item.getOperationStatus()))
            .map(ProcessableSingleResult::getEntity)
            .collect(Collectors.toList());

        ProcessableResult.Builder<Call, CallField, ErrorCode> result =
            new ProcessableResult.Builder<>(calls, calls.size());

        if (detailsResults.size() == calls.size()) {

            result.setOperationStatus(OK);
        } else {

            for (ProcessableSingleResult<Call, ErrorCode> detail : detailsResults) {

                if (!OK.equals(detail.getOperationStatus())) {

                    result.setErrorCode(detail.getErrorCode())
                        .setErrorMessage(detail.getErrorMessage())
                        .setOperationStatus(detail.getOperationStatus());

                    break;
                }
            }
        }

        return result.build();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ProcessableResult<CallID, CallField, ErrorCode> getAllIds(SecurityToken securityToken, Collection<Filter<CallField>> filterBy, Sort<CallField> sortBy, Page page) {

        Collection<Filter<CallField>> filters = (filterBy == null ? Collections.emptyList() : filterBy);

        // Ignoring sortBy and page because OIF doesn't support those mechanisms
        List<Filter> nameFilterIfPresent =
            filters.stream()
                .filter(item -> CallField.NAME.equals(item.getField()) && FilterOperation.EQUALS.equals(item.getOperation()))
                .collect(Collectors.toList());

        String filterByName = null;

        if (!nameFilterIfPresent.isEmpty()) {
            filterByName = nameFilterIfPresent.get(0).getValue();
        }

        Response response = callClientInstance.getAll("*", filterByName);
        CallObjectList callIDResponseObject;

        callIDResponseObject = parseResponseCallID(response);

        List<CallID> collection =
            callIDResponseObject.getId().stream()
                .map(id -> new CallID.Builder(SdnUtils.extractCallDomainId(id), SdnUtils.extractId(id)).build())
                .sorted(CallOperationsProxyImpl::callIDObjectComparator)
                .collect(Collectors.toList());

        Integer total = SdnUtils.extractTotal(response, collection);

        return
            new ProcessableResult.Builder<CallID, CallField, ErrorCode>(collection, total)
                .setOperationStatus(OK)
                .build();

    }

    /**
     * @param response
     * @return
     */
    private CallObjectList parseResponseCallID(Response response) {

        CallObjectList callIDResponseObject;

        try {

            callIDResponseObject = response.readEntity(CallObjectList.class);
        } catch (ProcessingException e) {

            // Currently SDN returns {} instead of { id: [] }
            callIDResponseObject = new CallObjectList();
        }

        if (callIDResponseObject.getId() == null) {

            callIDResponseObject.setId(new ArrayList<>());
        }

        return callIDResponseObject;
    }

    @Override
    public ProcessableSingleResult<CallID, ErrorCode> enforce(SecurityToken securityToken, CallID id) {

        if (id == null) {

            return buildErrorResult(Status.BAD_REQUEST, ErrorCode.GENERIC, CALLID_IS_NULL_MSG);
        }

        Response response = callClientInstance.enforce( id.getDomainId(), id.getID() );

        ProcessableSingleResult<EnforceResponseObject, GenericErrorCode> enforceDetails =
            CommonWorker.fromResponse(EnforceResponseObject.class).apply(response);

        switch (enforceDetails.getOperationStatus()) {

            case OK:

                return new ProcessableSingleResult.Builder<CallID, ErrorCode>()
                    .ok(id)
                    .build();
            default:
                return propagateErrorResultFrom(enforceDetails);
        }
    }
}