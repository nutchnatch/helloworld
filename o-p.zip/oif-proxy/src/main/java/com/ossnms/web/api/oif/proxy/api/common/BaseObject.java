package com.ossnms.web.api.oif.proxy.api.common;

import java.io.Serializable;

/**
 *
 */
public interface BaseObject extends Serializable {
}
