package com.ossnms.web.api.oif.proxy.api.client.call;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class ScheduleObject implements BaseObject {

    private static final long serialVersionUID = -8572235078788857149L;

    @JsonProperty( "coriant.scheduleIName" )
    public String name;
    @JsonProperty( "coriant.scheduleDescription" )
    public String description;
    @JsonProperty( "coriant.scheduleAction" )
    public String action;
    @JsonProperty( "coriant.scheduleYears" )
    public String years;
    @JsonProperty( "coriant.scheduleMonths" )
    public String months;
    @JsonProperty( "coriant.scheduleDaysOfMonth" )
    public String daysOfMonths;
    @JsonProperty( "coriant.scheduleDaysOfWeek" )
    public String daysOfWeek;
    @JsonProperty( "coriant.scheduleHours" )
    public String hours;
    @JsonProperty( "coriant.scheduleMinutes" )
    public String minutes;
}