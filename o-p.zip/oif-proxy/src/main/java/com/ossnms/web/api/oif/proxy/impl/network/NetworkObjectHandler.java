package com.ossnms.web.api.oif.proxy.impl.network;

import com.ossnms.web.api.oif.proxy.api.client.common.CommonWorker;
import com.ossnms.web.api.oif.proxy.api.client.network.NetworkObject;
import com.ossnms.web.api.oif.proxy.api.notification.model.EventType;
import com.ossnms.web.api.oif.proxy.api.notification.model.InboundNotification;
import com.ossnms.web.api.oif.proxy.api.notification.model.TypedInboundNotification;
import com.ossnms.web.provider.common.api.notification.Notification;
import com.ossnms.web.provider.common.api.notification.NotificationChannel;
import com.ossnms.web.provider.common.api.notification.NotificationHandler;
import com.ossnms.web.provider.common.api.notification.NotificationHandlerException;
import com.ossnms.web.provider.common.api.notification.NotificationType;
import com.ossnms.web.provider.sdn.model.network.Network;
import com.ossnms.web.provider.sdn.model.network.NetworkID;
import com.ossnms.web.provider.sdn.model.network.NetworkSummary;
import com.ossnms.web.provider.sdn.model.network.NetworkSummaryPrototype;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 *
 */
public final class NetworkObjectHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(NetworkObjectHandler.class);

    private static final String CHANNEL_ID_NETWORK = "network";

    /**
     *
     */
    private NetworkObjectHandler(){}

    /**
     *
     * @param object
     * @return
     */
    public static void toNetworkSummary(NetworkObject object, NetworkSummaryPrototype<?> builder) {
        builder.setName(object.name)
            .setTopologyType(object.topologyType)
            .setProtocols(object.protocols);
    }

    /**
     *
     * @param object
     * @return
     */
    public static void toNetwork(NetworkObject object, Network.Builder builder){
        toNetworkSummary(object, builder);

        builder.setUserDomain( object.userDomain );
        builder.setSecure( object.secure );
    }

    /**
     *
     * @param inboundNotification
     */
    public static void issueNotification(TypedInboundNotification<NetworkObject> inboundNotification, NotificationHandler handler) throws NotificationHandlerException, IOException {
        if(handler != null) {
            NetworkObject body = inboundNotification.getBody();

            NetworkID id = new NetworkID.Builder(body.id).build();
            NetworkSummary.Builder builder = new NetworkSummary.Builder(id);
            NetworkObjectHandler.toNetworkSummary(body, builder);

            Notification.NotificationBuilder notificationBuilder = new Notification.NotificationBuilder();
            notificationBuilder.setNotificationType(extractNotificationType(inboundNotification));
            notificationBuilder.setChannel(new NotificationChannel(CHANNEL_ID_NETWORK));
            notificationBuilder.setEntitySupplier(builder::build);

            Notification notification = notificationBuilder.build();

            LOGGER.debug("Issuing notification :: {}", notification);
            handler.handle(notification);

            if(inboundNotification.getEventType().equals(EventType.MODIFY)) {
                String identifier = CommonWorker.toId(body.id);
                notificationBuilder.setChannel(new NotificationChannel(CHANNEL_ID_NETWORK + "/SDN-" + identifier));

                LOGGER.debug("Issuing notification :: {}", notification);
                handler.handle(notificationBuilder.build());
            }
        } else {
            LOGGER.debug("Handler was null. Notification discarded");
        }
    }

    /**
     *
     * @param inboundNotification
     * @return
     */
    private static NotificationType extractNotificationType(InboundNotification inboundNotification) {
        switch(inboundNotification.getEventType()) {
            case CREATE:
                return NotificationType.CREATION;
            case DELETE:
                return NotificationType.DELETION;
            case MODIFY:
                return NotificationType.CHANGE;
        }
        // default type
        return NotificationType.RESYNC;
    }
}
