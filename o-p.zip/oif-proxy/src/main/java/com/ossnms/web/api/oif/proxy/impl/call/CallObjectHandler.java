package com.ossnms.web.api.oif.proxy.impl.call;

import com.ossnms.web.api.oif.proxy.api.client.call.CallObject;
import com.ossnms.web.api.oif.proxy.api.client.common.CommonWorker;
import com.ossnms.web.api.oif.proxy.api.notification.model.EventType;
import com.ossnms.web.api.oif.proxy.api.notification.model.InboundNotification;
import com.ossnms.web.api.oif.proxy.api.notification.model.TypedInboundNotification;
import com.ossnms.web.provider.common.api.notification.Notification;
import com.ossnms.web.provider.common.api.notification.NotificationChannel;
import com.ossnms.web.provider.common.api.notification.NotificationHandler;
import com.ossnms.web.provider.common.api.notification.NotificationHandlerException;
import com.ossnms.web.provider.common.api.notification.NotificationType;
import com.ossnms.web.provider.sdn.model.call.CallID;
import com.ossnms.web.provider.sdn.model.call.CallSummary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

import static com.ossnms.web.api.oif.proxy.impl.call.CallBuilder.toCallSummary;

/**
 *
 */
public final class CallObjectHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(CallObjectHandler.class);
    public static final String CHANNEL_ID_SERVICE = "service";

    private CallObjectHandler() {}

    /**
     *
     * @param inboundNotification
     * @param handler
     * @throws NotificationHandlerException
     * @throws IOException
     */
    public static void issueNotification(TypedInboundNotification<CallObject> inboundNotification, NotificationHandler handler) throws NotificationHandlerException, IOException {
        if(handler != null) {
            CallObject body = inboundNotification.getBody();

            CallID callID = new CallID.Builder(
                CommonWorker.toDomainId(body.getId()),
                CommonWorker.toId(body.getId())
            ).build();
            CallSummary.Builder builder = new CallSummary.Builder(callID);
            toCallSummary(body, builder, null, null);

            Notification.NotificationBuilder notificationBuilder = new Notification.NotificationBuilder();
            notificationBuilder.setNotificationType(extractNotificationType(inboundNotification));
            notificationBuilder.setChannel(new NotificationChannel(CHANNEL_ID_SERVICE));
            notificationBuilder.setEntitySupplier(builder::build);

            Notification notification = notificationBuilder.build();
            LOGGER.debug("Issuing notification :: {}", notification);
            handler.handle(notification);

            // if the event type is of type modification, we issue a notification for the specific service identifier
            if(EventType.MODIFY.equals(inboundNotification.getEventType())) {
                String identifier = body.getName(); // the name should be the identifier of the service
                String channelID = String.format(CHANNEL_ID_SERVICE + "/%s", identifier);
                notificationBuilder.setChannel(new NotificationChannel(channelID));
                LOGGER.debug("Issuing notification :: {}", notification);
                handler.handle(notificationBuilder.build());
            }
        } else {
            LOGGER.debug("Handler was null. Notification discarded");
        }
    }

    /**
     *
     * @param inboundNotification
     * @return
     */
    private static NotificationType extractNotificationType(InboundNotification inboundNotification) {
        switch(inboundNotification.getEventType()) {
            case CREATE:
                return NotificationType.CREATION;
            case DELETE:
                return NotificationType.DELETION;
            case MODIFY:
                return NotificationType.CHANGE;
        }
        // default type
        return NotificationType.RESYNC;
    }

}
