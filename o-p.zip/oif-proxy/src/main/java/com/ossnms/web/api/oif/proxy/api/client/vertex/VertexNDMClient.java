package com.ossnms.web.api.oif.proxy.api.client.vertex;

import com.ossnms.web.api.oif.proxy.api.common.topology.TopologyBaseClient;

import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import static com.ossnms.web.api.oif.proxy.api.common.OIFProxyConstant.URL_NDM_VERTEX;

/**
 *
 */
@Path(URL_NDM_VERTEX)
@Consumes("application/json")
@Produces("application/json")
public interface VertexNDMClient extends TopologyBaseClient<VertexObject> {
}
