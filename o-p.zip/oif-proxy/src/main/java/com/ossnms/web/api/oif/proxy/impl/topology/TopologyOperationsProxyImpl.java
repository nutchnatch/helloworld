package com.ossnms.web.api.oif.proxy.impl.topology;

import com.ossnms.web.provider.common.api.params.Page;
import com.ossnms.web.provider.common.api.params.filter.Filter;
import com.ossnms.web.provider.common.api.params.sort.Sort;
import com.ossnms.web.provider.common.api.result.OperationResult;
import com.ossnms.web.provider.common.api.security.SecurityToken;
import com.ossnms.web.provider.sdn.model.topology.Topology;
import com.ossnms.web.provider.sdn.model.topology.TopologyField;
import com.ossnms.web.provider.sdn.model.topology.TopologyID;
import com.ossnms.web.provider.sdn.model.topology.TopologySummary;
import com.ossnms.web.provider.sdn.operations.topology.TopologyEntityOperations;

import javax.enterprise.context.RequestScoped;
import java.util.Collection;

/**
 *
 */
@RequestScoped
public class TopologyOperationsProxyImpl implements TopologyEntityOperations {

//    private static final Logger LOGGER = LoggerFactory.getLogger(TopologyOperationsProxyImpl.class);

    /**
     * {@inheritDoc}
     */
    @Override
    public TopologySummary getSummary(SecurityToken securityToken, TopologyID id) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Topology getDetails(SecurityToken securityToken, TopologyID id) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<TopologySummary, TopologyField> getAllSummary(SecurityToken securityToken, Collection<TopologyID> ids) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<TopologySummary, TopologyField> getAllSummary(SecurityToken securityToken, Collection<Filter<TopologyField>> filterBy, Sort<TopologyField> sortBy, Page page) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<Topology, TopologyField> getAll(SecurityToken securityToken, Collection<TopologyID> ids) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<Topology, TopologyField> getAll(SecurityToken securityToken, Collection<Filter<TopologyField>> filterBy, Sort<TopologyField> sortBy, Page page) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public OperationResult<TopologyID, TopologyField> getAllIds(SecurityToken securityToken, Collection<Filter<TopologyField>> filterBy, Sort<TopologyField> sortBy, Page page) {
        return null;
    }
}
