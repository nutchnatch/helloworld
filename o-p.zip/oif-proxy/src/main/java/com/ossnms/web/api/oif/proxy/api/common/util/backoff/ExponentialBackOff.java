package com.ossnms.web.api.oif.proxy.api.common.util.backoff;

import com.ossnms.web.provider.sdn.api.annotation.Proxy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 *
 */
public class ExponentialBackOff {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExponentialBackOff.class);

    @Inject
    @Proxy
    private ScheduledExecutorService scheduledExecutorService;

    public ExponentialBackOff(){}

    /**
     *
     * @param delaySeconds
     * @param multiplier
     * @param retries
     * @param runnable
     */
    public void execute(int delaySeconds, int multiplier, int retries, ExponentialBackOffRunnable runnable) {
        if(retries != 0) {
            scheduledExecutorService.schedule(() -> {
                try {
                    runnable.execute();
                } catch (ExponentialBackOffException e) {
                    int delay = delaySeconds * multiplier;
                    LOGGER.warn("An error occurred, scheduling new execution with {} seconds delay. {}", delay, e.getMessage());
                    // redefine the new delay
                    execute(delay, multiplier, retries - 1, runnable);
                }
            }, delaySeconds, TimeUnit.SECONDS);
        } else {
            LOGGER.warn("Retries used. Operation failed.");
        }
    }
}
