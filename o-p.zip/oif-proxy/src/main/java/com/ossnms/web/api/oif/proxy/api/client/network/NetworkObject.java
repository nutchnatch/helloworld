package com.ossnms.web.api.oif.proxy.api.client.network;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;
import com.ossnms.web.api.oif.proxy.api.common.util.SdnUtils;

import java.util.Arrays;

/**
 *
 */
@JsonIgnoreProperties( ignoreUnknown = true )
@JsonInclude( JsonInclude.Include.NON_NULL )
public class NetworkObject implements BaseObject {

    private static final long serialVersionUID = 10130304485859623L;

    public String id;
    public String name;
    public String userDomain;
    public String topologyType;
    public String[] protocols;
    public Boolean secure;


    public NetworkObject() {

        id = null;
        name = null;
        userDomain = null;
        topologyType = null;
        protocols = null;
        secure = null;
    }

    public NetworkObject( NetworkObject original ) {

        id = original.id;
        name = original.name;
        userDomain = original.userDomain;
        topologyType = original.topologyType;
        protocols = original.protocols;
        secure = original.secure;
    }

    @Override
    public String toString() {

        String domainName = name;
        String topology = topologyType;
        String domainUri = userDomain;

        if ( "1".equals( SdnUtils.extractId( id ) ) ) {

            domainName = "PROVIDER";
            topology = "FULL";
            domainUri = id;
        }

        return
            String.format( "Domain %s: { %s %s %s %s %s }",
                domainName,
                SdnUtils.extractId( id ),
                topology,
                Arrays.toString( protocols ),
                domainUri,
                secure
            );
    }
}
