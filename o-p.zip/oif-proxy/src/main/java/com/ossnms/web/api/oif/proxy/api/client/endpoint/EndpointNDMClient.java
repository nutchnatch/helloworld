package com.ossnms.web.api.oif.proxy.api.client.endpoint;

import com.ossnms.web.api.oif.proxy.api.common.network.NetworkBaseClient;

import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import static com.ossnms.web.api.oif.proxy.api.common.OIFProxyConstant.URL_NDM_ENDPOINT;

/**
 *
 */
@Path( URL_NDM_ENDPOINT )
@Consumes( "application/json" )
@Produces( "application/json" )
public interface EndpointNDMClient extends NetworkBaseClient<EndpointObject> {
}
