package com.ossnms.web.api.oif.proxy.api.producer;

import com.ossnms.web.api.common.context.JWTSessionBasedUserPrincipal;
import com.ossnms.web.api.common.provider.BaseProvider;
import com.ossnms.web.api.oif.proxy.api.annotation.SystemProperty;
import com.ossnms.web.api.oif.proxy.api.client.call.CallNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.common.AuthorizationHeaderFilter;
import com.ossnms.web.api.oif.proxy.api.client.connection.ConnectionNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.edge.EdgeNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.end.EndNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.endpoint.EndpointNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.network.NetworkNDMClient;
import com.ossnms.web.api.oif.proxy.api.client.srg.SrgNDMCLient;
import com.ossnms.web.api.oif.proxy.api.client.vertex.VertexNDMClient;
import com.ossnms.web.provider.sdn.api.annotation.Proxy;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.jboss.resteasy.client.jaxrs.ResteasyClient;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;
import org.jboss.resteasy.client.jaxrs.engines.ApacheHttpClient4Engine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.ext.Provider;
import java.security.GeneralSecurityException;

/**
 *
 */
@Provider
@RequestScoped
public class ProxyProducer extends BaseProvider {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProxyProducer.class);

    private static final int PORT_HTTP = 8080;
    private static final int PORT_HTTPS = 8443;
    private static final int INT_MAX = 1000;

    /**
     *
     */
    private String oifLocation;

    /**
     *
     */
    private String oifLocationPort;

    /**
     * Default no args constructor
     */
    public ProxyProducer(){}

    /**
     *
     * @param oifLocation
     */
    @Inject
    public ProxyProducer(
        @SystemProperty("oif.location") String oifLocation,
        @SystemProperty("oif.location.port") String oifLocationPort){
        LOGGER.debug("ProxyProducer initialized with oif.location = {}, oif.location.port = {}", oifLocation, oifLocationPort);
        this.oifLocation = oifLocation;
        this.oifLocationPort = oifLocationPort;
    }

    /**
     * @return
     */
    @Produces
    @Proxy
    public NetworkNDMClient getNetworkNDMClientProxy() {
        return getProxy( NetworkNDMClient.class, getTargetHost());
    }

    /**
     * @return
     */
    @Produces
    @Proxy
    public CallNDMClient getCallNDMClientProxy() {
        return getProxy( CallNDMClient.class, getTargetHost());
    }

    /**
     *
     * @return
     */
    @Produces
    @Proxy
    public EndNDMClient getEndNDMClientProxy() {
        return getProxy( EndNDMClient.class, getTargetHost());
    }

    /**
     *
     * @return
     */
    @Produces
    @Proxy
    public EdgeNDMClient getEdgeNDMClientProxy() {
        return getProxy( EdgeNDMClient.class, getTargetHost());
    }

    /**
     *
     * @return
     */
    @Produces
    @Proxy
    public EndpointNDMClient getEndpointNDMClientProxy() {
        return getProxy( EndpointNDMClient.class, getTargetHost());
    }

    @Produces
    @Proxy
    public ConnectionNDMClient getConnectionNDMClient() {
        return getProxy( ConnectionNDMClient.class, getTargetHost());
    }

    @Produces
    @Proxy
    public SrgNDMCLient getSRGNDMClient() {
        return getProxy( SrgNDMCLient.class, getTargetHost());
    }

    @Produces
    @Proxy
    public VertexNDMClient getVertexNDMClient() {
        return getProxy( VertexNDMClient.class, getTargetHost());
    }

    /**
     *
     * @return
     */
    private String getTargetHost() {
        if ( oifLocation.startsWith( "http" ) ) {
            return oifLocation;
        }

        return "https://" + oifLocation + ":" + oifLocationPort;
    }

    /**
     *
     * @param <T>
     * @param type
     * @return
     */
    public <T> T getProxy(Class<T> type, String hostname) {
        String token = null;
        SecurityContext context = getSecurityContext();

        if(context != null && context.getUserPrincipal() instanceof JWTSessionBasedUserPrincipal) {
            token = ((JWTSessionBasedUserPrincipal) context.getUserPrincipal()).getJwtToken();
            LOGGER.debug("Obtained JWT Session token from application context.");
        }

        return getProxy(type, hostname, oifLocationPort, new AuthorizationHeaderFilter( token ));
    }

    /**
     *
     * @param type
     * @param hostname
     * @param authenticationHeaderFilter
     * @param <T>
     * @return
     */
    public static <T> T getProxy(Class<T> type, String hostname, AuthorizationHeaderFilter authenticationHeaderFilter) {
        return getProxy(type, hostname, String.valueOf(PORT_HTTPS), authenticationHeaderFilter);
    }

    /**
     *
     * @param <T>
     * @param type
     * @return
     */
    public static <T> T getProxy(Class<T> type, String hostname, String port) {
        return getProxy(type, hostname, port, null);
    }

    /**
     *
     * @param <T>
     * @param type
     * @return
     */
    public static <T> T getProxy(Class<T> type, String hostname, String port, AuthorizationHeaderFilter authenticationHeaderFilter) {
        if(hostname == null || hostname.isEmpty() || port == null || port.isEmpty()) {
            return issueEmptyImplementation(type);
        }

        return issueResteasyClient(type, hostname, port, authenticationHeaderFilter);
    }

    /**
     *
     * @param type
     * @param <T>
     * @return
     */
    private static <T> T issueEmptyImplementation(Class<T> type) {
        // empty instance proxy instance
        return (T) java.lang.reflect.Proxy.newProxyInstance(
            type.getClassLoader(),
            new Class[]{type},
            (proxy, method, args) -> {
                // every implementation of a client proxy should return a response object
                LOGGER.warn("Unauthorized call to the client proxy. Interface {}, Method {}", type.getName(), method.getName());
                return Response.status(Response.Status.SERVICE_UNAVAILABLE).build();
            });
    }

    /**
     *
     * @param type
     * @param hostname
     * @param port
     * @param authenticationHeaderFilter
     * @param <T>
     * @return
     */
    private static <T> T issueResteasyClient(Class<T> type, String hostname, String port, AuthorizationHeaderFilter authenticationHeaderFilter) {
        ResteasyClient client;
        try{
            ApacheHttpClient4Engine engine = new ApacheHttpClient4Engine(createAllTrustingClient(port));
            client = new ResteasyClientBuilder().httpEngine(engine).build();
        } catch (GeneralSecurityException e) {
            LOGGER.error("Could not create an all trusting client. Depending on truststore...", e);
            client = new ResteasyClientBuilder().build();
        }
        if(authenticationHeaderFilter != null) {
            // register filter
            client.register(authenticationHeaderFilter);
        }
        // create a web target
        ResteasyWebTarget target = client.target(hostname);
        // create proxy
        return target.proxy(type);
    }

    /**
     *
     * @return
     * @throws GeneralSecurityException
     */
    private static DefaultHttpClient createAllTrustingClient(String httpsPort) throws GeneralSecurityException {
        SchemeRegistry registry = new SchemeRegistry();
        registry.register(new Scheme("http", PORT_HTTP, PlainSocketFactory.getSocketFactory()));

        TrustStrategy trustStrategy = (chain, authType) -> true;

        SSLSocketFactory factory = new SSLSocketFactory(trustStrategy, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER );
        registry.register(new Scheme("https", Integer.valueOf(httpsPort), factory));

        PoolingClientConnectionManager mgr = new PoolingClientConnectionManager(registry);
        mgr.setMaxTotal(INT_MAX);
        mgr.setDefaultMaxPerRoute(INT_MAX);

        return new DefaultHttpClient(mgr, new DefaultHttpClient().getParams());
    }
}
