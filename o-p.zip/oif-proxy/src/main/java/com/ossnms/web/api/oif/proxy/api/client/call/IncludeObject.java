package com.ossnms.web.api.oif.proxy.api.client.call;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ossnms.web.api.oif.proxy.api.common.BaseObject;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 *
 */
public class IncludeObject implements BaseObject {

    private static final long serialVersionUID = 6486695604892699858L;

    public String[] vertex;

    public String[] edge;

    @JsonProperty(value = "risk")
    private List<String> risks;

    /**
     *
     */
    public String[] getVertex() {
        return vertex;
    }

    public IncludeObject setVertex(String[] vertex) {
        this.vertex = vertex;
        return this;
    }

    /**
     *
     */
    public String[] getEdge() {
        return edge;
    }

    public IncludeObject setEdge(String[] edge) {
        this.edge = edge;
        return this;
    }

    /**
     *
     */
    public List<String> getRisks() {
        return risks;
    }

    public IncludeObject setRisks(List<String> risks) {
        this.risks = risks;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        IncludeObject that = (IncludeObject) o;
        return Arrays.equals(getVertex(), that.getVertex()) &&
            Arrays.equals(getEdge(), that.getEdge()) &&
            Objects.equals(getRisks(), that.getRisks());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getVertex(), getEdge(), getRisks());
    }
}
