package com.bnpp.cardif.sugar.frontend.security;

import org.opensaml.common.SAMLException;
import org.opensaml.common.SAMLObject;
import org.opensaml.saml2.core.Response;
import org.opensaml.xml.encryption.DecryptionException;
import org.opensaml.xml.security.SecurityException;
import org.opensaml.xml.validation.ValidationException;
import org.springframework.security.saml.SAMLCredential;
import org.springframework.security.saml.context.SAMLMessageContext;
import org.springframework.security.saml.websso.WebSSOProfileConsumerImpl;

/**
 * Customized version of WebSSOProfileConsumerImpl to add specific behavior: For
 * Sesame Identity provider we don't authorize non encrypted assertions.
 * 
 * @author 831743
 *
 */
public class SesameWebSSOProfileConsumerImpl extends WebSSOProfileConsumerImpl
{
    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.security.saml.websso.WebSSOProfileConsumerImpl#
     * processAuthenticationResponse
     * (org.springframework.security.saml.context.SAMLMessageContext)
     */
    @Override
    public SAMLCredential processAuthenticationResponse(SAMLMessageContext context) throws SAMLException, SecurityException, ValidationException,
            DecryptionException
    {

        SAMLObject message = context.getInboundSAMLMessage();
        // Verify type
        if (!(message instanceof Response))
        {
            throw new SAMLException("Message is not of a Response object type");
        }
        Response response = (Response) message;
        if (response.getAssertions() != null && !response.getAssertions().isEmpty())
        {
            throw new SecurityException("Only encrypted assertions are allowed in this application.");
        }
        return super.processAuthenticationResponse(context);
    }

}
