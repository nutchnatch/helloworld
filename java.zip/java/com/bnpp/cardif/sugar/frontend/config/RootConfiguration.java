package com.bnpp.cardif.sugar.frontend.config;

import org.apache.coyote.http11.AbstractHttp11Protocol;
import org.springframework.boot.context.embedded.tomcat.TomcatConnectorCustomizer;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.web.filter.CharacterEncodingFilter;

/**
 * This class configure the Root Spring context for the application.
 * 
 * This context should include all the application beans except the Spring MVC
 * controllers that will be loaded into the WebMvcConfiguration
 * 
 * The @ComponentScan is loading all configuration within the same package (and
 * child packages) as RootConfiguration. Since SecurityConfig is in this
 * package, it will be loaded with our existing setup.
 * 
 * @author 831743
 *
 */
@Configuration
// In this component scan annotation, set all the packages that contains your
// security, utility, DAO and services classes.
@ComponentScan(basePackages = { "com.bnpp.cardif.sesame.security", "com.bnpp.cardif.sugar.frontend.security",
        "com.bnpp.cardif.sugar.frontend.services", "com.bnpp.cardif.sugar.api" })
public class RootConfiguration {

    // To resolve ${} in @Value
    @Bean
    public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    /**
     * Configure maxSwallowSize in embedded Tomcat
     * 
     * @return
     */
    @Bean
    public TomcatEmbeddedServletContainerFactory tomcatEmbedded() {
        TomcatEmbeddedServletContainerFactory tomcat = new TomcatEmbeddedServletContainerFactory();
        tomcat.addConnectorCustomizers((TomcatConnectorCustomizer) connector -> {
            // connector other settings...
            // configure maxSwallowSize
            if ((connector.getProtocolHandler() instanceof AbstractHttp11Protocol<?>)) {
                // -1 means unlimited, accept bytes
                ((AbstractHttp11Protocol<?>) connector.getProtocolHandler()).setMaxSwallowSize(-1);
            }
        });
        return tomcat;
    }

    /**
     * Add encoding filter
     * 
     * @return
     */
    @Bean
    public FilterRegistrationBean filterRegistrationBean() {
        FilterRegistrationBean registrationBean = new FilterRegistrationBean();
        // Add encoding filter
        CharacterEncodingFilter characterEncodingFilter = new CharacterEncodingFilter();
        characterEncodingFilter.setForceEncoding(true);
        characterEncodingFilter.setEncoding("UTF-8");
        registrationBean.setFilter(characterEncodingFilter);
        return registrationBean;
    }
}
