package com.bnpp.cardif.sugar.frontend.config;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.ZonedDateTimeSerializer;

/**
 * This class configure the Spring MVC controller context for the application.
 * 
 * This context should include all the Spring MVC controllers that will handle
 * the requests to the application.
 * 
 * The @ComponentScan is loading all configuration within the same package (and
 * child packages) as WebMvcConfiguration.
 * 
 * @author 831743
 *
 */
@Configuration
// in this component scan annotation, set all the packages that contains your
// MVC controllers classes.
@ComponentScan(basePackages = { "com.bnpp.cardif.sugar.rest.ui", "com.bnpp.cardif.sugar.frontend.web" })
public class WebMvcConfiguration {

    private static final Logger LOGGER = LoggerFactory.getLogger(WebMvcConfiguration.class);

    /**
     * Configure the date format when map Object->Json and Json->Object
     * 
     * @return Jackson2ObjectMapperBuilderCustomizer
     */
    @SuppressWarnings("squid:S1604")
    @Bean
    public Jackson2ObjectMapperBuilderCustomizer jackson2ObjectMapperBuilderCustomizer() {

        return new Jackson2ObjectMapperBuilderCustomizer() {

            @Override
            public void customize(Jackson2ObjectMapperBuilder jacksonObjectMapperBuilder) {
                // Serializers
                jacksonObjectMapperBuilder
                        .serializers(new ZonedDateTimeSerializer(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
                jacksonObjectMapperBuilder
                        .serializers(new LocalDateTimeSerializer(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
                jacksonObjectMapperBuilder.serializers(new LocalDateSerializer(DateTimeFormatter.ISO_LOCAL_DATE));
                // Deserializers
                jacksonObjectMapperBuilder
                        .deserializers(new LocalDateTimeDeserializer(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
                jacksonObjectMapperBuilder.deserializers(new LocalDateDeserializer(DateTimeFormatter.ISO_LOCAL_DATE));
            }

        };
    }

    @Bean
    public WebMvcConfigurer mvcConfigurer() {

        return new WebMvcConfigurerAdapter() {

            /**
             * Specify the cache period for the resources served by the resource
             * handler, in seconds. The default is to not send any cache headers
             * but to rely on last-modified timestamps only. Set to 0 in order
             * to send cache headers that prevent caching, or to a positive
             * number of seconds to send cache headers with the given max-age
             * value.
             */
            private int cachePeriod = 60;

            /**
             * Add handlers to serve static resources such as images, js, and,
             * css files from specific locations under web application root, the
             * classpath, and others.
             */
            @SuppressWarnings("squid:S1192")
            @Override
            public void addResourceHandlers(ResourceHandlerRegistry registry) {
                LOGGER.debug("addResourceHandlers");
                String staticDir = "/static/";
                String indexPage = "/index.html";
                registry.addResourceHandler("/static/assets/**").addResourceLocations("/static/assets/")
                        .setCachePeriod(cachePeriod).resourceChain(true);
                registry.addResourceHandler("/static/*.html").addResourceLocations(staticDir)
                        .setCachePeriod(cachePeriod).resourceChain(true);
                registry.addResourceHandler("/static/*.js").addResourceLocations(staticDir).setCachePeriod(cachePeriod)
                        .resourceChain(true);
                registry.addResourceHandler("/static/*.map").addResourceLocations(staticDir).setCachePeriod(cachePeriod)
                        .resourceChain(true);
                registry.addResourceHandler("/static/*.css").addResourceLocations(staticDir).setCachePeriod(cachePeriod)
                        .resourceChain(true);
                registry.addResourceHandler("/static/*.ico").addResourceLocations(staticDir).setCachePeriod(cachePeriod)
                        .resourceChain(true);
                registry.addResourceHandler("/static/*.eot").addResourceLocations(staticDir).setCachePeriod(cachePeriod)
                        .resourceChain(true);
                registry.addResourceHandler("/static/*.svg").addResourceLocations(staticDir).setCachePeriod(cachePeriod)
                        .resourceChain(true);
                registry.addResourceHandler("/static/*.ttf").addResourceLocations(staticDir).setCachePeriod(cachePeriod)
                        .resourceChain(true);
                registry.addResourceHandler("/static/*.woff").addResourceLocations(staticDir)
                        .setCachePeriod(cachePeriod).resourceChain(true);
                registry.addResourceHandler("/static/*.woff2").addResourceLocations(staticDir)
                        .setCachePeriod(cachePeriod).resourceChain(true);
                registry.addResourceHandler("/").addResourceLocations(indexPage).setCachePeriod(cachePeriod)
                        .resourceChain(true);
                registry.addResourceHandler(indexPage).addResourceLocations(indexPage).setCachePeriod(cachePeriod)
                        .resourceChain(true);
                registry.addResourceHandler("/logout.html").addResourceLocations("/logout.html")
                        .setCachePeriod(cachePeriod).resourceChain(true);
            }

            @Bean
            public CommonsMultipartResolver multipartResolver() {
                CommonsMultipartResolver resolver = new CommonsMultipartResolver();
                resolver.setDefaultEncoding("utf-8");
                return resolver;
            }

            /**
             * Spring will no longer use the file extension to override the
             * accepts mediaType of the request.
             */
            @Override
            public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
                configurer.favorPathExtension(false);
                configurer.defaultContentType(MediaType.APPLICATION_JSON);
            }

            @Override
            public void extendMessageConverters(List<HttpMessageConverter<?>> converters) {
                for (HttpMessageConverter<?> converter : converters) {
                    if (converter instanceof MappingJackson2HttpMessageConverter) {
                        MappingJackson2HttpMessageConverter jsonMessageConverter = (MappingJackson2HttpMessageConverter) converter;
                        ObjectMapper objectMapper = jsonMessageConverter.getObjectMapper();
                        JavaTimeModule javaTimeModule = new JavaTimeModule();
                        javaTimeModule.addSerializer(ZonedDateTime.class,
                                new ZonedDateTimeSerializer(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
                        javaTimeModule.addSerializer(LocalDateTime.class,
                                new LocalDateTimeSerializer(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
                        javaTimeModule.addDeserializer(LocalDateTime.class,
                                new LocalDateTimeDeserializer(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
                        javaTimeModule.addSerializer(LocalDate.class,
                                new LocalDateSerializer(DateTimeFormatter.ISO_LOCAL_DATE));
                        javaTimeModule.addDeserializer(LocalDate.class,
                                new LocalDateDeserializer(DateTimeFormatter.ISO_LOCAL_DATE));
                        objectMapper.registerModule(javaTimeModule);
                    }
                }
            }

        };

    }

    @Bean
    public RestTemplate restTemplate() {
        RestTemplate restTemplate = new RestTemplate();
        ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setConnectTimeout(15000);
        ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setReadTimeout(15000);

        return restTemplate;
    }
}
