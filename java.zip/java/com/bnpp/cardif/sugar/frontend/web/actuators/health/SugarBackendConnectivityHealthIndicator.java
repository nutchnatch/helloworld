package com.bnpp.cardif.sugar.frontend.web.actuators.health;

import com.bnpp.cardif.sugar.api.SugarWebServiceClientFactory;
import com.bnpparibas.assurance.ea.internal.schema.mco.security.v1.TokenType;
import com.bnpparibas.assurance.sugar.internal.service.app.common.v1.TechFaultMessage;
import com.bnpparibas.assurance.sugar.internal.service.app.documentclass.v1.SearchRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

/**
 *
 * Verifies the connection with sugar backend.
 * @see HealthIndicator
 *
 * @author a20257
 * @since 1.1.0
 */
@Component("SugarBackendConnectivity")
public class SugarBackendConnectivityHealthIndicator implements HealthIndicator {

    /**
     * Sugar backend WSDL endpoint.
     */
    @Autowired
    private SugarWebServiceClientFactory sugarWebServiceClientFactory;

    @Override
    public Health health() {
        try {
            sugarWebServiceClientFactory.getSugarDocumentClassWSP().search(new SearchRequest(), new TokenType());
            return Health.up().build();
        } catch (final TechFaultMessage tfm) {
            return Health.up().build();
        } catch (final Exception exception) {
            return  Health.down().withException(exception).build();
        }
    }
}
