package com.bnpp.cardif.sugar.frontend.web.actuators.health;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * Abstract remote health checker. It call a remote URL for health check waiting for a json detail response in
 * the format
 *
 * <code>
 *  {
 *    "status":"DOWN",
 *    "ArenderServer":{
 *       "status":"DOWN",
 *       "SugarBackendConnectivity":{
 *          "status":"DOWN",
 *          "error":"Connection refused: connect"
 *       }
 *    }
 *  }
 *
 * </code>
 *
 * @author a20257
 * @since 1.1.0
 */
public abstract class AbstractRemoteHealthIndicator implements HealthIndicator {

    @Override
    public Health health() {
        try {
            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<Object> response = restTemplate.getForEntity(getRemoteHealthUrl(), Object.class);
            if (!HttpStatus.OK.equals(response.getStatusCode())) {
                return Health.down().withDetail(response.getBody().toString(), null).build();
            }
            Map<String, Object> result = (Map)response.getBody();
            final Health.Builder builder = Health.up();
            result.forEach((o, o2) -> {
                if (!"status".equalsIgnoreCase(o)) {
                    builder.withDetail(o, o2);
                }
            });
            return builder.build();
        } catch (final HttpServerErrorException se) {
            Map<String, Object> result = null;
            try {
                result = new ObjectMapper().readValue(se.getResponseBodyAsString(), HashMap.class);
                final Health.Builder builder = Health.down();
                result.forEach((o, o2) -> {
                    if (!"status".equalsIgnoreCase(o)) {
                        builder.withDetail(o, o2);
                    }
                });
                return builder.build();
            }
            catch (IOException e) {
                return Health.down().withException(e).build();
            }
        } catch (final Exception exception) {
            return  Health.down().withException(exception).build();
        }
    }

    /**
     * Gets the remote health URL to be called.
     * @return  The remote health url
     */
    public abstract String getRemoteHealthUrl();
}
