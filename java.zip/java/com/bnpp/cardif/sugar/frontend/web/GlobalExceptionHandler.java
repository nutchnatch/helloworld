package com.bnpp.cardif.sugar.frontend.web;

import java.time.ZonedDateTime;

import javax.servlet.http.HttpServletRequest;

import org.apache.tomcat.util.http.fileupload.FileUploadBase.FileSizeLimitExceededException;
import org.apache.tomcat.util.http.fileupload.FileUploadBase.SizeLimitExceededException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.NoHandlerFoundException;

import com.bnpp.cardif.sugar.rest.ui.model.ErrorCause;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;

/**
 * Class that handle exception from all the MVC controllers.
 * 
 * @author 831743
 *
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    private static final String MULTIPART_EXCEPTION_UNKNOWN_ERROR = "MultipartException Unknown error";

    private static final String REST_RESPONSE_FORMAT = "%s : %s";

    @ExceptionHandler(NoHandlerFoundException.class)
    @ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "Requested URL not found")
    public ModelAndView handleError404(HttpServletRequest request, Exception e) {
        // log the error
        LOGGER.error("Request: {} raised {}", request.getRequestURL(), e);
        // then return 404 content
        ModelAndView model = new ModelAndView("404");
        model.addObject("exception", e);
        return model;
    }

    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<RestResponse<String>> handleHttpMediaTypeNotSupportedException(HttpServletRequest request,
            Exception e) {
        // log the error
        LOGGER.error("Request: {}  raised {}", request.getRequestURL(), e);
        // then return 415 content

        return getRestResponseResponseEntity(
                HttpStatus.UNSUPPORTED_MEDIA_TYPE,
                String.format(REST_RESPONSE_FORMAT, HttpStatus.UNSUPPORTED_MEDIA_TYPE.getReasonPhrase(), e.getMessage()));
    }

    @ExceptionHandler(MultipartException.class)
    public ResponseEntity<RestResponse<String>> handleMultipartException(HttpServletRequest request, Exception cause) {
        // log the error
        LOGGER.error("Request: {}  raised {}", request.getRequestURL(), cause);
        if (cause != null)
        {
            Throwable errorCauseThrowable = cause.getCause();
            if (IllegalStateException.class.equals(errorCauseThrowable.getClass()))
            {
                Throwable errorCauseThrowable2 = errorCauseThrowable.getCause();
                if (SizeLimitExceededException.class.equals(errorCauseThrowable2.getClass())
                    || FileSizeLimitExceededException.class.equals(errorCauseThrowable2.getClass()))
                {
                    return getRestResponseResponseEntity(
                        HttpStatus.PAYLOAD_TOO_LARGE,
                        String.format(REST_RESPONSE_FORMAT, HttpStatus.PAYLOAD_TOO_LARGE.getReasonPhrase(), cause.getMessage()));
                }
            }
            return getRestResponseResponseEntity(
                    HttpStatus.BAD_REQUEST,
                    String.format(REST_RESPONSE_FORMAT, MULTIPART_EXCEPTION_UNKNOWN_ERROR, cause.getMessage()));
        }
        return getRestResponseResponseEntity(
                HttpStatus.BAD_REQUEST, MULTIPART_EXCEPTION_UNKNOWN_ERROR);
    }

    private ResponseEntity<RestResponse<String>> getRestResponseResponseEntity(HttpStatus httpStatus, String errorMessage)
    {
        RestResponse<String> restResponse = new RestResponse<>();
        restResponse.setStatus(false);

        ErrorCause errorCause = new ErrorCause();
        errorCause.setCode("" + httpStatus.value());
        errorCause.setErrorDate(ZonedDateTime.now());
        errorCause.setMessage(errorMessage);
        restResponse.setError(errorCause);

        return ResponseEntity.status(httpStatus).body(restResponse);
    }
}
