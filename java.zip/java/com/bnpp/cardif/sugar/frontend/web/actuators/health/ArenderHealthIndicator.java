package com.bnpp.cardif.sugar.frontend.web.actuators.health;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 *
 * Verifies the atender (it calls the arender health checker).
 * @see AbstractRemoteHealthIndicator
 *
 * @author a20257
 * @since 1.1.0
 */
@Component("Arender")
public class ArenderHealthIndicator extends AbstractRemoteHealthIndicator{

    /**
     * The backend health actuator url.
     */
    @Value("${sugar.arender.health.url}")
    private String arenderHealthUrl;

    /**
     * Gets the remote health URL to be called.
     *
     * @return The remote health url
     */
    @Override
    public String getRemoteHealthUrl() {
        return arenderHealthUrl;
    }
}
