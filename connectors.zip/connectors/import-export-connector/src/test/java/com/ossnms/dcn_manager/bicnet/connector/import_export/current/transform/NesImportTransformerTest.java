package com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.ContainerAssignment;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.NetworkElement;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.Property;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableAssignedContainer;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;
import org.junit.Test;

import java.util.Optional;

import static java.util.Arrays.asList;
import static java.util.Optional.empty;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class NesImportTransformerTest {

    @Test public void shouldImportSystemContainer() throws Exception {
        String type = "some type";
        NetworkElement ne = ne(type);
        ne.setSystemContainer("System Container");

        NeValueObject neValueObject = new NesImportTransformer(false, configuration(type)).apply(ne);

        assertThat(neValueObject.systemContainer(), is(Optional.of("System Container")));
    }

    @Test public void shouldImportAssociatedContainers() throws Exception {
        String type = "some type";
        NetworkElement ne = ne(type);
        ne.getAssignedContainer().addAll(asList(assignment("Primary one", true), assignment("Secondary one", false)));

        NeValueObject neValueObject = new NesImportTransformer(false, configuration(type)).apply(ne);

        assertThat(neValueObject.getAssignedContainers(), containsInAnyOrder(
                ImmutableAssignedContainer.of("Primary one", true),
                ImmutableAssignedContainer.of("Secondary one", false)));
    }

    @Test public void shouldNotImportLocation() throws Exception {
        Property location = new Property();
        location.setName("NE_LOCATION");
        location.setValue("somewhere");
        NetworkElement ne = ne("");
        ne.getProperty().add(location);

        NeValueObject neValueObject = new NesImportTransformer(false, configuration("")).apply(ne);

        assertThat(neValueObject.getLocation(), is(empty()));
    }

    private NetworkElement ne(String type) {
        NetworkElement ne = new NetworkElement();
        ne.setIDName("NE name");
        ne.setParentEM("EM");
        ne.setType(type);
        return ne;
    }

    private ContainerAssignment assignment(String name, boolean isPrimary) {
        ContainerAssignment assignment = new ContainerAssignment();
        assignment.setIDName(name);
        assignment.setIsPrimary(isPrimary);
        return assignment;
    }

    private StaticConfiguration configuration(String type) {
        NeType neType = mock(NeType.class);
        when(neType.getName()).thenReturn(type);
        Types<NeType> types = Types.from(asList(neType));

        StaticConfiguration configuration = mock(StaticConfiguration.class);
        when(configuration.getNeTypes()).thenReturn(types);
        return configuration;
    }

}