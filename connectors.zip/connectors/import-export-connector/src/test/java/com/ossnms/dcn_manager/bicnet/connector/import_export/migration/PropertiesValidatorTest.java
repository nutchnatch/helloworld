package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import org.junit.Test;

import java.util.Map;
import java.util.function.Predicate;

import static com.google.common.collect.ImmutableMap.of;
import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;

public class PropertiesValidatorTest {
    @Test public void shouldRemoveInvalidEntry() throws Exception {
        Map<String, String> input = of("key", "value");
        Map<String, Predicate<String>> validators = of("key", this::invalid);

        Map<String, String> result = new PropertiesValidator(validators).apply(input);

        assertThat(result, not(hasKey("key")));
    }

    @Test public void shouldKeepValidEntry() throws Exception {
        Map<String, String> input = of("key", "value");
        Map<String, Predicate<String>> validators = of("key", this::valid);

        Map<String, String> result = new PropertiesValidator(validators).apply(input);

        assertThat(result, hasKey("key"));
    }

    @Test public void shouldApplyAllValidators() throws Exception {
        Map<String, String> input = of("key", "value", "anotherKey", "anotherValue");
        Map<String, Predicate<String>> validators = of("key", this::valid, "anotherKey", this::invalid, "someKey", this::invalid);

        Map<String, String> result = new PropertiesValidator(validators).apply(input);

        assertThat(result, hasKey("key"));
    }

    private boolean valid(String value) {
        return true;
    }

    private boolean invalid(String value) {
        return false;
    }
}