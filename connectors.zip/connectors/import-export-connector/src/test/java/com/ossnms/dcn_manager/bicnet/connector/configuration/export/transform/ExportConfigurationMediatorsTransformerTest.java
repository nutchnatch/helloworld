package com.ossnms.dcn_manager.bicnet.connector.configuration.export.transform;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ExportMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorPhysicalInstance;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import static java.util.Arrays.asList;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.Assert.assertThat;

public class ExportConfigurationMediatorsTransformerTest {

    private static final int MEDIATOR_ID = 1;
    private static final int VERSION = 0;

    private MediatorEntity mediatorEntity;
    private MediatorInstance primary;
    private MediatorInstance secondary;

    @Before public void setUp() throws Exception {
        mediatorEntity = new MediatorEntity(
                new MediatorInfoBuilder()
                        .setProperty("bag_id", "bag_value")
                        .setName("name")
                        .setDescription(Optional.of("description"))
                        .setConcurrentActivationsLimited(true).setReconnectAttemptInterval(10)
                        .setConcurrentActivationsLimit(11).setTypeName("type").build(MEDIATOR_ID, VERSION),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, VERSION));

        final MediatorPhysicalData primaryInfo = new MediatorPhysicalDataBuilder().setHost("host_primary")
                .setPriority(MediatorInstance.PRIMARY_PRIORITY_LEVEL).build(2, MEDIATOR_ID, VERSION);

        final MediatorPhysicalData secondaryInfo = new MediatorPhysicalDataBuilder().setHost("host_secondary")
                .setPriority(1).build(3, MEDIATOR_ID, VERSION);

        final MediatorPhysicalConnectionData connectionData = new MediatorPhysicalConnectionBuilder()
                .build(1, MEDIATOR_ID, VERSION);

        primary = new MediatorInstance(primaryInfo, connectionData);
        secondary = new MediatorInstance(secondaryInfo, connectionData);
    }

    @Test public void transform_only_primary_instance() throws Exception {
        final Pair<MediatorEntity, Iterable<MediatorInstance>> mediatorPair = ImmutablePair
                .of(mediatorEntity, Collections.singletonList(primary));

        final ExportMediator transform = ExportConfigurationMediatorsTransformer.transform(mediatorPair);

        assertThat(transform.getMediatorId(), is(mediatorEntity.getInfo().getId()));
        assertThat(transform.getConcurrentActivationsLimited(),is(mediatorEntity.getInfo().isConcurrentActivationsLimited()));
        assertThat(transform.getConcurrentActivationsLimit(),is("11"));
        assertThat(transform.getReconnectInterval(), is("10"));
        assertThat(transform.getIdName(), is(mediatorEntity.getInfo().getName()));
        assertThat(transform.getType(), is(mediatorEntity.getInfo().getTypeName()));
        assertThat(transform.getHost(), is("host_primary"));
        assertThat(transform.getDescription(), is(mediatorEntity.getInfo().getDescription().orElse(null)));
        assertThat(asList(transform.getProperties()), contains(new Property("bag_id","bag_value")));

        assertThat(ArrayUtils.isEmpty(transform.getPhysicalInstance()), is(true));
    }

    @Test public void transform_only_with_secondaries_instances() throws Exception {
        final Pair<MediatorEntity, Iterable<MediatorInstance>> mediatorPair = ImmutablePair
                .of(mediatorEntity, ImmutableList.of(primary, secondary));

        final ExportMediator transform = ExportConfigurationMediatorsTransformer.transform(mediatorPair);

        assertThat(transform.getMediatorId(), is(mediatorEntity.getInfo().getId()));
        assertThat(transform.getConcurrentActivationsLimited(),is(mediatorEntity.getInfo().isConcurrentActivationsLimited()));
        assertThat(transform.getConcurrentActivationsLimit(),is("11"));
        assertThat(transform.getReconnectInterval(), is("10"));
        assertThat(transform.getIdName(), is(mediatorEntity.getInfo().getName()));
        assertThat(transform.getType(), is(mediatorEntity.getInfo().getTypeName()));
        assertThat(transform.getHost(), is("host_primary"));
        assertThat(transform.getDescription(), is(mediatorEntity.getInfo().getDescription().orElse(null)));
        assertThat(asList(transform.getProperties()), contains(new Property("bag_id","bag_value")));

        assertThat(Arrays.asList(transform.getPhysicalInstance()),
                containsInAnyOrder(new MediatorPhysicalInstance("host_secondary", 1)));
    }

}