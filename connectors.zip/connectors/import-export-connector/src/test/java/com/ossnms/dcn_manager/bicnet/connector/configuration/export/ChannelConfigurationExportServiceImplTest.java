package com.ossnms.dcn_manager.bicnet.connector.configuration.export;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ChannelsReply;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaChannelRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaMediatorRepositoryBean;
import com.ossnms.dcn_manager.connector.jpa.JpaCloseableQuery;
import com.ossnms.dcn_manager.connector.storage.channel.entities.ChannelEntityDb;
import com.ossnms.dcn_manager.connector.storage.channel.entities.QChannelEntityDb;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ChannelConfigurationExportServiceImplTest {
    private static final int CHANNEL_ID = 1;
    private static final int VERSION = 0;
    private static final int MEDIATOR_ID = 2;

    @Mock private ISessionContext sessionContext;
    @Mock private JpaCloseableQuery query;
    @Mock private Function<ChannelEntityDb, Optional<ChannelEntity>> function;
    @Mock private ChannelEntityDb channelEntityDb;
    @Mock private JpaMediatorRepositoryBean mediatorRepository;
    @Mock private JpaChannelRepositoryBean channelRepository;

    @InjectMocks private ChannelConfigurationExportServiceImpl service;

    @Before public void setUp() throws Exception {
        final ChannelEntity entity = new ChannelEntity(
                new ChannelInfoBuilder().setType("type")
                        .build(CHANNEL_ID, VERSION, MEDIATOR_ID),
                new ChannelConnectionBuilder().setAdditionalInfo("info")
                        .build(CHANNEL_ID, VERSION),
                new ChannelUserPreferencesBuilder().setConcurrentActivationsLimit(10)
                        .setConcurrentActivationsLimited(true).setName("name").setReconnectInterval(11)
                        .setProperty("bag_id", "bag_value")
                        .build(CHANNEL_ID, VERSION));

        when(channelRepository.query(QChannelEntityDb.channelEntityDb)).thenReturn(query);
        when(query.stream(QChannelEntityDb.channelEntityDb)).thenReturn(Lists.newArrayList(channelEntityDb).stream());

        when(channelRepository.getEntityTransformer()).thenReturn(function);
        when(function.apply(channelEntityDb)).thenReturn(Optional.of(entity));
        when(mediatorRepository.queryMediatorName(MEDIATOR_ID)).thenReturn(Optional.of("mediator_name"));
    }

    @Test public void export_none() throws Exception {
        final ChannelsReply export = service.export(sessionContext, 0, 0);

        assertThat(export.getEof(), is(true));
        assertThat(export.getData().length, is(0));
    }

    @Test public void export_all() throws Exception {
        final ChannelsReply export = service.export(sessionContext, 0, -1);

        assertThat(export.getEof(), is(true));
        assertThat(export.getData().length, is(1));
    }
}
