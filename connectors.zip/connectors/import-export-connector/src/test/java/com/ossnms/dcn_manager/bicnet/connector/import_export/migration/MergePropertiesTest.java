package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import org.junit.Test;

import java.util.Collection;
import java.util.Map;

import static com.google.common.collect.ImmutableMap.of;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyMap;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class MergePropertiesTest {
    @Test public void shouldJoinPropertiesUnderNewKey() throws Exception {
        Map<String, String> properties = of("key", "value", "key2", "value2");
        Map<String, Collection<String>> mapping = of("joined key", asList("key", "key2"));

        Map<String, String> merged = new MergeProperties(mapping, 100).apply(properties);

        assertThat(merged, is(of("joined key", "value, value2")));
    }

    @Test public void shouldJoinPropertiesUnderExistingKey() throws Exception {
        Map<String, String> properties = of("key", "value", "key2", "value2");
        Map<String, Collection<String>> mapping = of("key", asList("key", "key2"));

        Map<String, String> merged = new MergeProperties(mapping, 100).apply(properties);

        assertThat(merged, is(of("key", "value, value2")));
    }
    
    @Test public void shouldLimitLengthOfJoinedValue() throws Exception {
        Map<String, String> properties = of("key", "0123456789", "key2", "0123456789");
        Map<String, Collection<String>> mapping = of("key", asList("key", "key2"));

        Map<String, String> merged = new MergeProperties(mapping, 15).apply(properties);

        assertThat(merged, is(of("key", "0123456789, 012")));
    }

    @Test public void shouldIgnoreMissingJoiningKeys() throws Exception {
        Map<String, String> properties = of("key", "value", "key3", "value 3");
        Map<String, Collection<String>> mapping = of("key", asList("key", "missing key", "key3"));

        Map<String, String> merged = new MergeProperties(mapping, 100).apply(properties);

        assertThat(merged, is(of("key", "value, value 3")));
    }

    @Test public void shouldNotCreateEmptyPropertyForMissingJoinedValue() throws Exception {
        Map<String, String> properties = of("some key", "some value");
        Map<String, Collection<String>> mapping = of("key", asList("missing key"));

        Map<String, String> merged = new MergeProperties(mapping, 100).apply(properties);

        assertThat(merged, is(properties));
    }

    @Test public void shouldNotAffectOtherValues() throws Exception {
        Map<String, String> properties = of("key", "value", "key2", "value2", "other key", "other value");
        Map<String, Collection<String>> mapping = of("key", asList("key", "key2"));

        Map<String, String> merged = new MergeProperties(mapping, 100).apply(properties);

        assertThat(merged, is(of("key", "value, value2", "other key", "other value")));
    }

    @Test public void shouldNotAffectPropertiesOnEmptyMappings() throws Exception {
        Map<String, String> properties = of("key", "value");
        Map<String, Collection<String>> mapping = emptyMap();

        Map<String, String> merged = new MergeProperties(mapping, 100).apply(properties);

        assertThat(merged, is(properties));
    }
    
    @Test public void shouldSkipEmptyResult() throws Exception {
        Map<String, String> properties = of("key", "", "key2", "");
        Map<String, Collection<String>> mapping = of("key", asList("key", "key2"));

        Map<String, String> merged = new MergeProperties(mapping, 100).apply(properties);

        assertThat(merged, is(emptyMap()));
    }

    @Test public void shouldSkipEmptyValues() throws Exception {
        Map<String, String> properties = of("key", "a", "key2", "");
        Map<String, Collection<String>> mapping = of("key", asList("key", "key2"));

        Map<String, String> merged = new MergeProperties(mapping, 100).apply(properties);

        assertThat(merged, is(of("key", "a")));
    }
}