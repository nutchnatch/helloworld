package com.ossnms.dcn_manager.bicnet.connector.import_export.legacy.transform;

import org.hamcrest.CoreMatchers;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertThat;

public class ReadWriteCommunityMigrationTest {

    public static final String READ_COMMUNITY = "BD4B7A2F-1406-4617-B163-39D1AF00EF03/Read community";
    public static final String WRITE_COMMUNITY = "BD4B7A2F-1406-4617-B163-39D1AF00EF03/Write community";

    @Test public void testMigrate() throws Exception {
        Map<String, String> properties = new HashMap<>();
        properties.put(READ_COMMUNITY,"76E6EF6378A3771B");
        properties.put(WRITE_COMMUNITY,"6E89894C901D3426");
        properties.put("key", "value");

        Map<String, String> transformed =  ReadWriteCommunityMigration.transform(properties);

        assertThat(transformed.get(READ_COMMUNITY), CoreMatchers.is("public"));
        assertThat(transformed.get(WRITE_COMMUNITY), CoreMatchers.is("private"));
        assertThat(transformed.get("key"), CoreMatchers.is("value"));
        assertThat(transformed.size(), CoreMatchers.is(3));
    }

    @Test public void testMigrate_no_community_keys() throws Exception {
        Map<String, String> properties = new HashMap<>();
        properties.put("key", "value");

        Map<String, String> transformed =  ReadWriteCommunityMigration.transform(properties);

        assertThat(transformed.containsKey(READ_COMMUNITY), CoreMatchers.is(false));
        assertThat(transformed.containsKey(WRITE_COMMUNITY), CoreMatchers.is(false));
        assertThat(transformed.get("key"), CoreMatchers.is("value"));
        assertThat(transformed.size(), CoreMatchers.is(1));
    }
}