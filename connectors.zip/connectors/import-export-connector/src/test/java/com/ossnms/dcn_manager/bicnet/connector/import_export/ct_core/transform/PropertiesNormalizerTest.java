package com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.Property;
import org.junit.Test;

import static com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.PropertiesNormalizer.normalizedValue;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.PropertyBuilder.property;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class PropertiesNormalizerTest {

    @Test public void shouldNotChangeVT_BSTR() throws Exception {
        Property property = property("name", "Value", "VT_BSTR");

        String value = normalizedValue(property);

        assertThat(value, is("Value"));
    }

    @Test public void shouldLowercaseVT_BOOL() throws Exception {
        Property property1 = property("name", "False", "VT_BOOL");
        Property property2 = property("name", "True", "VT_BOOL");

        String value1 = normalizedValue(property1);
        String value2 = normalizedValue(property2);

        assertThat(value1, is("false"));
        assertThat(value2, is("true"));
    }

    @Test public void shouldDecodeFromHexToDec_VT_UI4() throws Exception {
        Property property1 = property("name", "10", "VT_UI4");
        Property property2 = property("name", "ffffffff", "VT_UI4");

        String value1 = normalizedValue(property1);
        String value2 = normalizedValue(property2);

        assertThat(value1, is("16"));
        assertThat(value2, is("-1"));
    }
}