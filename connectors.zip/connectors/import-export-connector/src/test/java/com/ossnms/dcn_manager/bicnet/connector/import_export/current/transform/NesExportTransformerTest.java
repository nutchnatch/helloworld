package com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.NetworkElement;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.Property;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableAssignedContainer;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableNeValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;
import org.junit.Test;

import java.util.Optional;

import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

public class NesExportTransformerTest {

    @Test public void shouldExportAssignment() throws Exception {
        NeValueObject neValue = ImmutableNeValueObject.of("NE Name", "NE Type", "Parent Channel")
                .withAssignedContainers(asList(
                        ImmutableAssignedContainer.of("Primary Container", true),
                        ImmutableAssignedContainer.of("Secondary Container", false)));

        NetworkElement exportedNE = new NesExportTransformer().apply(neValue);

        assertThat(exportedNE.getAssignedContainer(), hasSize(2));
    }

    @Test public void shouldExportSystemContainer() throws Exception {
        NeValueObject neValue = ImmutableNeValueObject.of("NE Name", "NE Type", "Parent Channel")
                .withSystemContainer("System Container");

        NetworkElement exportedNE = new NesExportTransformer().apply(neValue);

        assertThat(exportedNE.getSystemContainer(), is("System Container"));
    }

    @Test public void shouldNotExportSystemContainerIfAbsent() throws Exception {
        NeValueObject neValue = ImmutableNeValueObject.of("NE Name", "NE Type", "Parent Channel")
                .withSystemContainer(Optional.empty());

        NetworkElement exportedNE = new NesExportTransformer().apply(neValue);

        assertThat(exportedNE.getSystemContainer(), nullValue());
    }
    
    @Test public void shouldExportLocation() throws Exception {
        NeValueObject neValue = ImmutableNeValueObject.of("NE Name", "NE Type", "Parent Channel")
                .withLocation("somewhere");

        NetworkElement exportedNE = new NesExportTransformer().apply(neValue);

        Optional<String> ne_location = exportedNE.getProperty().stream()
                .filter(p -> "NE_LOCATION".equals(p.getName()))
                .map(Property::getValue).findFirst();
        assertThat(ne_location, is(Optional.of("somewhere")));
    }
}