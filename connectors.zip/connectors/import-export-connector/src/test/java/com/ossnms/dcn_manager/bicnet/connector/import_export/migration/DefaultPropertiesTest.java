package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import org.junit.Test;

import java.util.Map;

import static com.google.common.collect.ImmutableMap.of;
import static java.util.Collections.emptyMap;
import static org.hamcrest.Matchers.hasEntry;
import static org.junit.Assert.assertThat;

public class DefaultPropertiesTest {

    @Test public void shouldAddIfAbsent() throws Exception {
        Map<String, String> params = emptyMap();
        Map<String, String> defaults = of("key", "value");

        Map<String, String> result = new DefaultProperties(defaults).apply(params);

        assertThat(result, hasEntry("key", "value"));
    }

    @Test public void shouldReplaceIfEmptyString() throws Exception {
        Map<String, String> params = of("key", "");
        Map<String, String> defaults = of("key", "value");

        Map<String, String> result = new DefaultProperties(defaults).apply(params);

        assertThat(result, hasEntry("key", "value"));
    }

    @Test public void shouldNotChangeIfPresentValue() throws Exception {
        Map<String, String> params = of("key", "another value");
        Map<String, String> defaults = of("key", "value");

        Map<String, String> result = new DefaultProperties(defaults).apply(params);

        assertThat(result, hasEntry("key", "another value"));
    }
}