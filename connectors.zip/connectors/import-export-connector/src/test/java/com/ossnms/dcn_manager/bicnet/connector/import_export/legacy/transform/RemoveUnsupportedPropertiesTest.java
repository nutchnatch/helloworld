package com.ossnms.dcn_manager.bicnet.connector.import_export.legacy.transform;

import org.hamcrest.CoreMatchers;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertThat;

public class RemoveUnsupportedPropertiesTest {

    private static final String OLD_PASSWORD_STR = "0EB12480-EC8A-11D4-9D9C-00105AF68EBA/OLD_PASSWORD_STR";
    private static final String NEW_PASSWORD_STR = "0EB12480-EC8A-11D4-9D9C-00105AF68EBA/NEW_PASSWORD_STR";
    private final Map<String, String> properties = new HashMap<>();

    @Before
    public void setup() {
        properties.put(OLD_PASSWORD_STR,"old_pass");
        properties.put(NEW_PASSWORD_STR,"new_pass");
        properties.put("key", "value");
    }

    @After
    public void cleanup() {
        properties.clear();
    }

    @Test public void testApply() throws Exception {
        Map<String, String> transformed = new RemoveUnsupportedProperties().apply(properties);
        assertThat(transformed.containsKey(OLD_PASSWORD_STR), CoreMatchers.is(false));
        assertThat(transformed.containsKey(NEW_PASSWORD_STR), CoreMatchers.is(false));
    }

    @Test public void testTransform() throws Exception {
        Map<String, String> transformed =  RemoveUnsupportedProperties.transform(properties);

        assertThat(transformed.containsKey(OLD_PASSWORD_STR), CoreMatchers.is(false));
        assertThat(transformed.containsKey(NEW_PASSWORD_STR), CoreMatchers.is(false));
        assertThat(transformed.get("key"), CoreMatchers.is("value"));
        assertThat(transformed.size(), CoreMatchers.is(1));
    }
}