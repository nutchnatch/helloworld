package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import org.junit.Test;

import java.util.Map;

import static com.google.common.collect.ImmutableMap.of;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class AddressSplitTest {
    @Test public void shouldSplitAddressIntoIpPort() throws Exception {
        Map<String, String> prefixes = of("ADDRESS", "PORT");
        Map<String, String> properties = of(
                "ADDRESS_000", "127.0.0.1:123",
                "ADDRESS_001", "10.10.10.10:321"
        );

        Map<String, String> mapped = new AddressSplit(prefixes).apply(properties);

        assertThat(mapped, is(of(
                "ADDRESS_000", "127.0.0.1", "PORT_000", "123",
                "ADDRESS_001", "10.10.10.10", "PORT_001", "321"
        )));
    }

    @Test public void shouldNotAffectOtherProperties() throws Exception {
        Map<String, String> prefixes = of("ADDRESS", "PORT");
        Map<String, String> properties = of(
                "key1", "value1",
                "key2", "value2"
        );

        Map<String, String> mapped = new AddressSplit(prefixes).apply(properties);

        assertThat(mapped, is(properties));
    }

    @Test public void shouldAddDefaultPortWhenMissing() throws Exception {
        Map<String, String> prefixes = of("ADDRESS", "PORT");
        Map<String, String> properties = of(
                "ADDRESS_000", "127.0.0.1",
                "ADDRESS_001", "10.10.10.10"
        );

        Map<String, String> mapped = new AddressSplit(prefixes).apply(properties);

        assertThat(mapped, is(of(
                "ADDRESS_000", "127.0.0.1", "PORT_000", "161",
                "ADDRESS_001", "10.10.10.10", "PORT_001", "161"
        )));
    }

    @Test public void shouldHandleMultiplePrefixes() throws Exception {
        Map<String, String> prefixes = of(
                "ADDRESS", "PORT",
                "NSAP", "NSAP_PORT"
        );
        Map<String, String> properties = of(
                "ADDRESS_000", "127.0.0.1:123",
                "NSAP_000", "10.10.10.10:321"
        );

        Map<String, String> mapped = new AddressSplit(prefixes).apply(properties);

        assertThat(mapped, is(of(
                "ADDRESS_000", "127.0.0.1", "PORT_000", "123",
                "NSAP_000", "10.10.10.10", "NSAP_PORT_000", "321"
        )));
    }
}