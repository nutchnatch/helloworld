package com.ossnms.dcn_manager.bicnet.connector.configuration.export.transform;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ExportNE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.TaxonomyNeType;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableNeValueObject.of;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.arrayContainingInAnyOrder;
import static org.hamcrest.Matchers.emptyArray;
import static org.junit.Assert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class ExportNesTransformerTest {

    @Test public void transform() throws Exception {
        NeValueObject neValue = of("name", "proxy_type", "channel_name")
                .withNeId(1)
                .withFamilyLabel("family")
                .withSubTypeLabel("subtype")
                .withTypeLabel("type_label")
                .withDomainNames("domain1", "domain2")
                .withLocation("location")
                .withPropertyBag(ImmutableMap.of("bag_id", "bag_value"));


        final ExportNE transform = ExportNesTransformer.transform(neValue);

        assertThat(transform.getIdName(), is("name"));
        assertThat(transform.getType(), is("proxy_type"));
        assertThat(transform.getChannel(), is("channel_name"));
        assertThat(transform.getNeId(), is(1));
        assertThat(transform.getNeTypeTaxonomy(), is(new TaxonomyNeType("family", "type_label", "subtype")));
        assertThat(transform.getParentAS(), arrayContainingInAnyOrder("domain1", "domain2"));
        assertThat(transform.getProperties(), arrayContainingInAnyOrder(
                new Property("bag_id", "bag_value"), new Property("NE_LOCATION", "location")));
    }

    @Test public void transform_no_domains() throws Exception {
        NeValueObject neValue = of("name", "proxy_type", "channel_name");

        final ExportNE transform = ExportNesTransformer.transform(neValue);

        assertThat(transform.getParentAS(), is(emptyArray()));
    }

    @Test public void transform_no_ne_taxonomy() throws Exception {
        NeValueObject neValue = of("name", "proxy_type", "channel_name");

        final ExportNE transform = ExportNesTransformer.transform(neValue);

        assertThat(transform.getNeTypeTaxonomy(), is(new TaxonomyNeType(null, null, null)));
    }
}