package com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.ContainerAssignment;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.SystemContainer;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableAssignedContainer;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableSystemValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.SystemValueObject;
import org.junit.Test;

import static java.util.Arrays.asList;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class SystemsTransformerTest {

    private static final String NAME = "System Container";

    @Test public void shouldExportNameDescriptionAndUserText() throws Exception {
        SystemValueObject systemValueObject = ImmutableSystemValueObject.of("System Name")
                .withUserText("User text")
                .withDescription("Description");

        SystemContainer systemContainer = SystemsTransformer.fromValue(systemValueObject);

        assertThat(systemContainer.getIDName(), is("System Name"));
        assertThat(systemContainer.getUserText(), is("User text"));
        assertThat(systemContainer.getDescription(), is("Description"));
    }

    @Test public void shouldExportContainerAssignments() throws Exception {
        SystemValueObject systemValueObject = ImmutableSystemValueObject.of("System Name")
                .withAssignedContainers(asList(
                        ImmutableAssignedContainer.of("Primary container", true),
                        ImmutableAssignedContainer.of("Secondary container", false)));

        SystemContainer systemContainer = SystemsTransformer.fromValue(systemValueObject);

        assertThat(systemContainer.getAssignedContainer(), hasSize(2));
    }

    @Test public void shouldImportName() throws Exception {
        SystemContainer systemContainer = emptySystem(NAME);

        SystemValueObject value = SystemsTransformer.toValue(systemContainer);

        assertThat(value, is(ImmutableSystemValueObject.of(NAME)));
    }

    @Test public void shouldImportTexts() throws Exception {
        SystemContainer withValues = emptySystem(NAME);
        withValues.setDescription("Description");
        withValues.setUserText("User text");

        SystemValueObject empty = SystemsTransformer.toValue(emptySystem(NAME));
        SystemValueObject values = SystemsTransformer.toValue(withValues);

        assertThat(empty, is(ImmutableSystemValueObject.of(NAME)));
        assertThat(values, is(ImmutableSystemValueObject.of(NAME)
                .withDescription("Description")
                .withUserText("User text")));
    }

    @Test public void shouldImportAssignments() throws Exception {
        SystemContainer withValues = emptySystem(NAME);
        withValues.getAssignedContainer().add(assignment(true, "Primary Container"));
        withValues.getAssignedContainer().add(assignment(false, "Secondary Container"));

        SystemValueObject empty = SystemsTransformer.toValue(emptySystem(NAME));
        SystemValueObject values = SystemsTransformer.toValue(withValues);

        assertThat(empty, is(ImmutableSystemValueObject.of(NAME)));
        assertThat(values, is(ImmutableSystemValueObject.of(NAME).withAssignedContainers(
                ImmutableAssignedContainer.of("Primary Container", true),
                ImmutableAssignedContainer.of("Secondary Container", false))));
    }

    private ContainerAssignment assignment(boolean isPrimary, String name) {
        ContainerAssignment assignment = new ContainerAssignment();
        assignment.setIDName(name);
        assignment.setIsPrimary(isPrimary);
        return assignment;
    }

    private SystemContainer emptySystem(String name) {
        SystemContainer systemContainer = new SystemContainer();
        systemContainer.setIDName(name);
        return systemContainer;
    }
}