package com.ossnms.dcn_manager.bicnet.connector.import_export.legacy.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.legacy.Properties.Property;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Map;
import java.util.function.Function;

import static java.util.stream.Collectors.toMap;

class TransformProperties implements Function<Collection<Property>, Map<String,String>> {

    @Override public Map<String, String> apply(@Nonnull final Collection<Property> input) {
        return transform(input);
    }

    public static Map<String, String> transform(@Nonnull final Collection<Property> input) {
        return input.stream()
                    .collect(toMap(Property::getName, Property::getValue));
    }
}
