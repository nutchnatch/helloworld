package com.ossnms.dcn_manager.bicnet.connector.configuration.export.transform;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ExportNE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.TaxonomyNeType;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;

import javax.annotation.Nonnull;

import java.util.function.Function;

import static com.ossnms.dcn_manager.bicnet.connector.configuration.export.transform.PropertiesTransformer.properties;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform.NesExportTransformer.withExportOnlyProperties;

public final class ExportNesTransformer implements Function<NeValueObject, ExportNE> {

    @Override public ExportNE apply(NeValueObject neValueObject) {
        return transform(neValueObject);
    }

    public static ExportNE transform(@Nonnull final NeValueObject ne) {
        ExportNE networkElement = new ExportNE();
        networkElement.setNeId(ne.getNeId().orElse(0));
        networkElement.setIdName(ne.getName());
        networkElement.setType(ne.getType());
        networkElement.setChannel(ne.getChannel());
        networkElement.setNeTypeTaxonomy(getTypeTaxonomy(ne));
        networkElement.setProperties(properties(withExportOnlyProperties(ne)));
        networkElement.setParentAS(ne.getDomainNames().stream().toArray(String[]::new));
        return networkElement;
    }

    private static TaxonomyNeType getTypeTaxonomy(@Nonnull final NeValueObject ne) {
        TaxonomyNeType taxonomy = new TaxonomyNeType();
        taxonomy.setNeFamilyLabel(ne.getFamilyLabel().orElse(null));
        taxonomy.setNeSubTypeLabel(ne.getSubTypeLabel().orElse(null));
        taxonomy.setNeTypeLabel(ne.getTypeLabel().orElse(null));
        return taxonomy;
    }
}
