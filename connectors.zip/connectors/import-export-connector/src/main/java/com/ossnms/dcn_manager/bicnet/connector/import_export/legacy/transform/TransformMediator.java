package com.ossnms.dcn_manager.bicnet.connector.import_export.legacy.transform;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.dcn.configuration.jaxb.legacy.Mediator;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableMediatorInstanceValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableMediatorValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorInstanceValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Collections;
import java.util.function.Function;

import static com.google.common.base.Strings.isNullOrEmpty;

public class TransformMediator implements Function<Mediator, MediatorValueObject> {

    @Override
    public MediatorValueObject apply(@Nonnull final Mediator mediator) {
        return ImmutableMediatorValueObject.of(
                mediator.getName(),
                mediator.getType(),
                mediator.getHost(),
                transform(mediator.getHostStandBy()));
    }

    private Collection<MediatorInstanceValueObject> transform(String host) {
        if (!isNullOrEmpty(host)) {
            return ImmutableList.of(ImmutableMediatorInstanceValueObject.builder()
                    .host(host)
                    .priority(1)
                    .build());
        }

        return Collections.emptyList();
    }
}
