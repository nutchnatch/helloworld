package com.ossnms.dcn_manager.bicnet.connector.configuration.export.transform;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ExportMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorPhysicalInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Optional;
import java.util.stream.StreamSupport;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.ossnms.dcn_manager.bicnet.connector.configuration.export.transform.PropertiesTransformer.properties;
import static com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance.PRIMARY_PRIORITY_LEVEL;
import static java.lang.String.valueOf;

public final class ExportConfigurationMediatorsTransformer {

    private ExportConfigurationMediatorsTransformer() {
    }

    public static ExportMediator transform(Pair<MediatorEntity, Iterable<MediatorInstance>> mediatorPair) {
        checkNotNull(mediatorPair.getLeft(), "The Mediator Entity cannot be null");

        final MediatorInfoData info = mediatorPair.getLeft().getInfo();

        final Optional<String> primaryHost = getPrimaryPhysicalInfo(mediatorPair.getRight());

        ExportMediator mediator = new ExportMediator();

        mediator.setMediatorId(info.getId());
        mediator.setIdName(info.getName());
        mediator.setHost(primaryHost.orElse(""));
        mediator.setType(info.getTypeName());

        mediator.setReconnectInterval(valueOf(info.getReconnectAttemptInterval()));
        mediator.setConcurrentActivationsLimit(valueOf(info.getConcurrentActivationsLimit()));
        mediator.setDescription(info.getDescription().orElse(null));
        mediator.setConcurrentActivationsLimited(info.isConcurrentActivationsLimited());

        mediator.setPhysicalInstance(getSecondariesPhysicalInfo(mediatorPair.getRight()));

        mediator.setProperties(properties(mediatorPair.getLeft().getAllOpaqueProperties()));

        return mediator;
    }

    private static Optional<String> getPrimaryPhysicalInfo(Iterable<MediatorInstance> mediatorInstances) {
        return StreamSupport.stream(mediatorInstances.spliterator(), false)
                .filter(primary -> primary.getPhysicalInfo().getPriority() == PRIMARY_PRIORITY_LEVEL)
                .map(primary -> primary.getPhysicalInfo().getHost()).findFirst();
    }

    private static MediatorPhysicalInstance[] getSecondariesPhysicalInfo(Iterable<MediatorInstance> mediatorInstances) {
        return StreamSupport.stream(mediatorInstances.spliterator(), false)
                .filter(secondary -> secondary.getPhysicalInfo().getPriority() != PRIMARY_PRIORITY_LEVEL)
                .map(secondary -> {
                    MediatorPhysicalInstance instance = new MediatorPhysicalInstance();
                    instance.setHost(secondary.getPhysicalInfo().getHost());
                    instance.setPriority(secondary.getPhysicalInfo().getPriority());
                    return instance;
                }).toArray(MediatorPhysicalInstance[]::new);

    }
}
