package com.ossnms.dcn_manager.bicnet.connector.configuration.export;

import com.mysema.query.BooleanBuilder;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ChannelsReply;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ExportChannel;
import com.ossnms.dcn_manager.bicnet.configuration.export.ChannelConfigurationExportService;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaChannelRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaMediatorRepositoryBean;
import com.ossnms.dcn_manager.connector.jpa.JpaCloseableQuery;
import com.ossnms.dcn_manager.connector.storage.channel.entities.QChannelEntityDb;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;

import javax.inject.Inject;

import java.util.Optional;

import static com.mysema.util.ArrayUtils.isEmpty;
import static com.ossnms.dcn_manager.bicnet.connector.configuration.export.transform.ExportConfigurationChannelsTransformer.transform;
import static com.ossnms.dcn_manager.bicnet.connector.facade.util.Exceptions.logAndRethrowAsBcb;
import static java.util.Objects.requireNonNull;
import static org.slf4j.LoggerFactory.getLogger;

public class ChannelConfigurationExportServiceImpl implements ChannelConfigurationExportService {

    private static final Logger LOGGER = getLogger(ChannelConfigurationExportServiceImpl.class);

    @Inject @DcnManager private JpaMediatorRepositoryBean mediatorRepository;
    @Inject @DcnManager private JpaChannelRepositoryBean channelRepository;

    /**
     * @see  ChannelConfigurationExportService#export(ISessionContext, int, int)
     */
    @Override public ChannelsReply export(ISessionContext sessionContext, int startIndex, int howMany)
            throws BcbException {
        requireNonNull(sessionContext);

        final QChannelEntityDb channel = QChannelEntityDb.channelEntityDb;
        try (final JpaCloseableQuery query = buildQueryExpression(startIndex, channel)) {

            final ExportChannel[] channels = query.stream(channel)
                    .map(channelDb -> channelRepository.getEntityTransformer().apply(channelDb))
                    .filter(Optional::isPresent)
                    .map(channelOptional -> transform(channelOptional.get(), mediatorRepository))
                    .limit(howMany >= 0 ? howMany : Integer.MAX_VALUE)
                    .toArray(ExportChannel[]::new);

            // Working with the worse case. If the page size is the same length of the last objects size,
            // that implies a new call with empty collection
            final boolean isEof = howMany < 0 || isEmpty(channels) || channels.length < howMany;

            return new ChannelsReply(isEof, channels);
        } catch (RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    private JpaCloseableQuery buildQueryExpression(final int startAfter, final QChannelEntityDb channel) {
        final JpaCloseableQuery query = channelRepository.query(channel);
        final BooleanBuilder predicateBuilder = new BooleanBuilder();

        if (startAfter >= 0) {
            predicateBuilder.and(channel.info.channelId.gt(startAfter));
        }
        if (predicateBuilder.hasValue()) {
            query.where(predicateBuilder);
        }
        query.orderBy(channel.info.channelId.asc());
        return query;
    }
}
