package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

public class DefaultProperties implements Function<Map<String, String>, Map<String, String>> {
    private final Map<String, String> defaults;

    public DefaultProperties(Map<String, String> defaults) {
        this.defaults = defaults;
    }

    /**
     * Adds missing default values to provided map of properties 
     */
    @Override public Map<String, String> apply(Map<String, String> props) {
        Map<String, String> result = new HashMap<>(props);
        defaults.forEach((key, value) -> 
                result.merge(key, value, StringUtils::defaultIfEmpty));
        return result;
    }
}
