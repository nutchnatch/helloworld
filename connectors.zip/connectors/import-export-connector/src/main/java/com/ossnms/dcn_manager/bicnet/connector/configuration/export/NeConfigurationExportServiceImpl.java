package com.ossnms.dcn_manager.bicnet.connector.configuration.export;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ExportNE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NesReply;
import com.ossnms.dcn_manager.bicnet.configuration.export.NeConfigurationExportService;
import com.ossnms.dcn_manager.bicnet.connector.configuration.export.transform.ExportNesTransformer;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaChannelRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaDomainRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.composables.import_export.ne.ExportNeTransformer;
import com.ossnms.dcn_manager.connector.jpa.JpaCloseableQuery;
import com.ossnms.dcn_manager.connector.storage.ne.entities.QNeEntityDb;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;

import javax.inject.Inject;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.bicnet.connector.facade.util.Exceptions.logAndRethrowAsBcb;
import static java.util.Collections.emptyMap;
import static java.util.Objects.requireNonNull;
import static org.slf4j.LoggerFactory.getLogger;

public class NeConfigurationExportServiceImpl implements NeConfigurationExportService {
    private static final Logger LOGGER = getLogger(NeConfigurationExportServiceImpl.class);

    @Inject @DcnManager private JpaChannelRepositoryBean channelRepository;
    @Inject @DcnManager private JpaNetworkElementRepositoryBean neRepository;
    @Inject @DcnManager private JpaDomainRepositoryBean domainRepository;
    @Inject @DcnManager private JpaContainerRepositoryBean containerRepository;
    @Inject @DcnManager private JpaSystemRepositoryBean systemRepository;
    @Inject private StaticConfiguration configuration;

    @Override public NesReply export(ISessionContext sessionContext, int lastNE, int howMany) throws BcbException {
        requireNonNull(sessionContext);

        Function<NeEntity, Optional<NeValueObject>> toValue = new ExportNeTransformer(
                channelRepository, neRepository, domainRepository,
                configuration, containerRepository, systemRepository,
                emptyMap());

        Function<NeValueObject, ExportNE> toExport = new ExportNesTransformer();
        
        ExportNE[] nes = exportNEs(lastNE, howMany, toValue, toExport);
        boolean eof = isEof(howMany, nes.length);
        return new NesReply(eof, nes);
    }

    private ExportNE[] exportNEs(int lastNE, int howMany, Function<NeEntity, Optional<NeValueObject>> toValue, Function<NeValueObject, ExportNE> toExport) throws BcbException {
        QNeEntityDb entity = QNeEntityDb.neEntityDb;
        try (JpaCloseableQuery query = neRepository.query(entity)) {
            return fetchNEs(lastNE, entity, query)
                    .map(toValue).flatMap(this::stream)
                    .map(toExport)
                    .limit(safeLimit(howMany))
                    .toArray(ExportNE[]::new);
        } catch (RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    private Stream<NeEntity> fetchNEs(int lastNE, QNeEntityDb entity, JpaCloseableQuery query) {
        return startAfter(lastNE, entity, query)
                .orderBy(entity.info.neId.asc())
                .stream(entity)
                .map(neRepository.getEntityTransformer()::apply)
                .flatMap(this::stream);
    }

    private JpaCloseableQuery startAfter(int lastNE, QNeEntityDb ne, JpaCloseableQuery query) {
        return lastNE >= 0 ? query.where(ne.info.neId.gt(lastNE)) : query;
    }

    private boolean isEof(int howMany, int length) {
        return howMany < 0 || length == 0 || length < howMany;
    }

    private <T> Stream<T> stream(Optional<T> op) {
        return op.map(Stream::of).orElseGet(Stream::empty);
    }

    private int safeLimit(int limit) {
        return limit >= 0 ? limit : Integer.MAX_VALUE;
    }
}
