package com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core;

import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.Channel;
import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.Mediator;
import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.NE;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.import_export.identification.MediatorIdentification;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ChannelValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity.WARNING;
import static com.ossnms.dcn_manager.i18n.Message.NE_UNKNOWN_TYPE;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static java.util.stream.Collectors.toList;

public class Process {
    private final BicnetCallContext callContext;
    private final Transformations transformations;
    private final LoggerManagerImpl loggerManager;
    private final Command<MediatorValueObject> importMediators;
    private final Command<ChannelValueObject> importChannels;
    private final Command<NeValueObject> importNes;
    private final MediatorIdentification mediatorIdentification;

    /**
     * Import from CT/CORE is different because those system have less types of channels.
     * In order to put NEs under proper channel in TNMS we need to resolve channel type using current configuration.
     * And because we create new channels we need to create also mediators for them.
     * <p>
     * What is expected here is that some NEs from SNMP channels will be put under new GM channels
     */
    public Process(Transformations transformations, BicnetCallContext callContext,
                   LoggerManagerImpl loggerManager, MediatorIdentification mediatorIdentification,
                   Command<NeValueObject> importNes, Command<ChannelValueObject> importChannels, Command<MediatorValueObject> importMediators) {
        this.callContext = callContext;
        this.transformations = transformations;
        this.loggerManager = loggerManager;
        this.importMediators = importMediators;
        this.importChannels = importChannels;
        this.importNes = importNes;
        this.mediatorIdentification = mediatorIdentification;
    }

    public Collection<String> performImport(Collection<NE> neTOs, Channel channelTO, Mediator mediatorTO) {
        Collection<NeValueObject> partialNes = transformations.produceNEs(neTOs);
        Collection<NE> unsupportedNes = transformations.unsupportedNes(neTOs);
        Set<String> actualChannelTypes = transformations.actualChannelTypesOf(partialNes);
        Collection<MediatorValueObject> mediators = transformations.produceMediators(mediatorTO, actualChannelTypes);
        Collection<ChannelValueObject> channels = transformations.produceChannels(channelTO, actualChannelTypes, mediators);
        final Collection<NeValueObject> nes = transformations.finishNesWithChannel(partialNes, channels);

        List<MediatorValueObject> uniqueMediators = mediators.stream().filter(mediatorIdentification::notExists).collect(toList());

        return joinResults(
                importMediators.apply(callContext, uniqueMediators),
                importChannels.apply(callContext, channels),
                importNes.apply(callContext, nes),
                reportInvalidNes(unsupportedNes));
    }


    @SafeVarargs private final Collection<String> joinResults(Collection<String>... collections) {
        return Stream.of(collections).flatMap(Collection::stream).collect(toList());
    }

    private Collection<String> reportInvalidNes(Collection<NE> invalidNes) {
        return invalidNes.stream()
                .map(ne -> new LoggerItemNe(ne.getIDName(), tr(NE_UNKNOWN_TYPE, ne.getIDName(), ""), -1, WARNING))
                .peek(loggerItem -> loggerManager.createSystemEventLog(callContext, loggerItem))
                .map(LoggerItem::getMessage)
                .collect(toList());
    }


    public interface Command<ITEM> extends BiFunction<BicnetCallContext, Collection<ITEM>, Collection<String>> {
    }
    
}
