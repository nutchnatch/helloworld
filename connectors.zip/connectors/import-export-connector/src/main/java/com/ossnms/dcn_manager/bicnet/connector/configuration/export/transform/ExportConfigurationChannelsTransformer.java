package com.ossnms.dcn_manager.bicnet.connector.configuration.export.transform;

import com.ossnms.bicnet.bcb.model.emObjMgmt.ExportChannel;
import com.ossnms.dcn_manager.connector.storage.mediator.MediatorRepository;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.connector.configuration.export.transform.PropertiesTransformer.properties;
import static java.lang.String.valueOf;
import static org.slf4j.LoggerFactory.getLogger;

public final class ExportConfigurationChannelsTransformer {
    private static final Logger LOGGER = getLogger(ExportConfigurationChannelsTransformer.class);

    private ExportConfigurationChannelsTransformer() {
    }

    public static ExportChannel transform(@Nonnull final ChannelEntity channelEntity,
            @Nonnull final MediatorRepository mediatorRepository) {
        ExportChannel exportChannel = new ExportChannel();

        exportChannel.setChannelId(channelEntity.getInfo().getId());
        exportChannel.setType(channelEntity.getInfo().getType());
        exportChannel.setIdName(channelEntity.getUserPreferences().getName());

        exportChannel.setConcurrentActivationsLimit(valueOf(channelEntity.getUserPreferences().getConcurrentActivationsLimit()));
        exportChannel.setConcurrentActivationsLimited(channelEntity.getUserPreferences().isConcurrentActivationsLimited());

        getMediatorName(channelEntity.getInfo().getMediatorId(), mediatorRepository).ifPresent(exportChannel::setMediator);

        exportChannel.setProperties(properties(channelEntity.getAllOpaqueProperties()));

        return exportChannel;
    }

    private static Optional<String> getMediatorName(int mediatorId, MediatorRepository mediatorRepository) {
        try {
            return mediatorRepository.queryMediatorName(mediatorId);
        } catch (RepositoryException e) {
            LOGGER.error("Error fetch mediator", e);
            return Optional.empty();
        }
    }
}
