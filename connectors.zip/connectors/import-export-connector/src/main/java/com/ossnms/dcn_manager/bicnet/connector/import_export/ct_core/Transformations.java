package com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core;

import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.Channel;
import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.Mediator;
import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.NE;
import com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.NeTransformer;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ChannelValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.ChannelTransformer.toChannelVO;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.MediatorTransformer.toMediatorVO;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.testing;
import static com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableNeValueObject.copyOf;
import static java.util.function.Predicate.isEqual;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;
import static java.util.stream.Collectors.toSet;


public class Transformations {

    private final Map<String, String> neTypeToChannelType;
    private final Map<String, String> channelTypeToMediatorType;
    private final NeTransformer toNe;

    public Transformations(StaticConfiguration configuration, NeTransformer toNe) {
        neTypeToChannelType = configuration.getChannelTypes().values().stream()
                .flatMap(channelType -> channelType.getSupportedNeTypes().stream()
                        .map(neType -> Pair.of(neType.getName(), channelType.getName())))
                .collect(toMap(Entry::getKey, Entry::getValue));

        channelTypeToMediatorType = configuration.getMediatorTypes().values().stream()
                .flatMap(mediatorType -> mediatorType.getSupportedChannelTypes().stream()
                        .map(channelType -> Pair.of(channelType.getName(), mediatorType.getName())))
                .collect(toMap(Entry::getKey, Entry::getValue));

        this.toNe = toNe;
    }


    List<NeValueObject> produceNEs(Collection<NE> nes) {
        return nes.stream().map(toNe)
                .flatMap(op -> op.map(Stream::of).orElseGet(Stream::empty))
                .collect(toList());
    }

    Collection<NE> unsupportedNes(Collection<NE> nes) {
        return nes.stream().filter(ne -> !toNe.apply(ne).isPresent()).collect(toList());
    }

    /**
     * In TNMS we have more channel types so for given NEs we can get more than channel type
     */
    Set<String> actualChannelTypesOf(Collection<NeValueObject> nes) {
        return nes.stream()
                .map(NeValueObject::getType)
                .map(this::resolveChannelType)
                .collect(toSet());
    }

    private String resolveChannelType(String neType) {
        return neTypeToChannelType.get(neType);
    }


    private String resolveMediatorType(String channelType) {
        return channelTypeToMediatorType.get(channelType);
    }

    /**
     * Create a channel for each channel type using input channel as a template
     */
    List<ChannelValueObject> produceChannels(Channel channel, Set<String> actualChannelTypes, Collection<MediatorValueObject> mediators) {
        return mediators.stream()
                .flatMap(mediator -> channelTypesFor(mediator.getType(), actualChannelTypes)
                        .map(channelType -> toChannelVO(mediator, channel, channelType)))
                .collect(toList());
    }

    private Stream<String> channelTypesFor(String mediatorType, Collection<String> channelTypes) {
        return channelTypes.stream().filter(testing(this::resolveMediatorType, isEqual(mediatorType)));
    }

    /**
     * Create a mediator for each channel type using input mediator as a template
     */
    List<MediatorValueObject> produceMediators(Mediator mediator, Collection<String> actualChannelTypes) {
        return actualMediatorTypes(actualChannelTypes)
                .map(mediatorType -> toMediatorVO(mediator, mediatorType))
                .collect(toList());
    }

    private Stream<String> actualMediatorTypes(Collection<String> actualChannelTypes) {
        return actualChannelTypes.stream().map(this::resolveMediatorType).distinct();
    }

    private Map<String, List<NeValueObject>> groupByCurrentChannelType(Collection<NeValueObject> nes) {
        return nes.stream()
                .filter(ne -> neTypeToChannelType.containsKey(ne.getType()))
                .collect(groupingBy(ne -> neTypeToChannelType.get(ne.getType())));
    }

    Collection<NeValueObject> finishNesWithChannel(Collection<NeValueObject> partialNes, Collection<ChannelValueObject> channels) {
        final Map<String, List<NeValueObject>> nesByChannelType = groupByCurrentChannelType(partialNes);

        return channels.stream()
                .flatMap(channel -> nesByChannelType
                        .get(channel.getType()).stream()
                        .map(ne -> copyOf(ne).withChannel(channel.getName())))
                .collect(toList());
    }
}
