package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import com.google.common.collect.ImmutableMap;

import javax.annotation.Nonnull;
import java.util.Map;

import static java.util.Collections.emptyMap;

/**
 * Migrates NE property ID changes.
 */
public class NePropertyMigration extends PropertiesKeysMapper {

    private static final Map<String, String> PROPERTIES = ImmutableMap.<String, String>builder()
            .put("TL1_FTP_IP_ADDRESS", "TL1_SFTP_IP_ADDRESS")
            .put("TL1_FTP_USERNAME", "TL1_SFTP_USERNAME")
            .put("TL1_FTP_PASSWORD", "TL1_SFTP_PASSWORD")
            .put("TL1_FTP_UPLOADPATH", "TL1_SFTP_UPLOADPATH")
            .build();

    private static final Map<String, Map<String, String>> FOR_TYPES = ImmutableMap.<String, Map<String, String>>builder()
            .put("7100 PICO FP11.x", PROPERTIES)
            .put("7100 PICO FP12.x", PROPERTIES)
            .build();

    public NePropertyMigration(@Nonnull final String type) {
        super(FOR_TYPES.getOrDefault(type, emptyMap()));
    }
}
