package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;

import static java.util.stream.Collectors.toMap;
import static org.apache.commons.lang3.tuple.Pair.of;

public enum Util {
    ;

    private static final Logger LOGGER = LoggerFactory.getLogger(Util.class);

    public static Optional<Integer> parseInt(String number) {
        try {
            return Optional.of(Integer.valueOf(number));
        } catch (NumberFormatException ignored) {
            LOGGER.debug("Failed to parse integer from number {}", number);
            return Optional.empty();
        }
    }

    /**
     * For given bifunction return function from map entry to result
     */
    public static <K, V, R> Function<Entry<K, V>, R> mappingEntry(BiFunction<K, V, R> mapping) {
        return entry -> mapping.apply(entry.getKey(), entry.getValue());
    }

    /**
     * Function from entry to entry that transform only key
     */
    public static <K, V, R> Function<Entry<K, V>, Entry<R, V>> mappingKey(Function<K, R> keyMapping) {
        return mappingEntry((key, value) -> of(keyMapping.apply(key), value));
    }

    /**
     * Function from entry to entry that transform only value
     */
    public static <K, V, R> Function<Entry<K, V>, Entry<K, R>> mappingValue(Function<V, R> valueMapping) {
        return mappingEntry((key, value) -> of(key, valueMapping.apply(value)));
    }

    /**
     * Predicate for map entry that test only key part 
     */
    public static <K, V> Predicate<Entry<K, V>> testingKey(Predicate<K> keyPredicate) {
        return testing(Entry::getKey, keyPredicate);
    }

    /**
     * Predicate for map entry that test only value part 
     */
    public static <K, V> Predicate<Entry<K, V>> testingValue(Predicate<V> valuePredicate) {
        return testing(Entry::getValue, valuePredicate);
    }

    /**
     * @see java.util.Comparator#comparing(Function, java.util.Comparator)
     */
    public static <VALUE, KEY> Predicate<VALUE> testing(Function<VALUE, KEY> keyExtractor, Predicate<KEY> keyPredicate) {
        return value -> keyPredicate.test(keyExtractor.apply(value));
    }

    /**
     * @return map without entries that satisfy predicate
     */
    public static <K, V> Map<K, V> filterOut(Map<K, V> map, Predicate<Entry<K, V>> entryPredicate) {
        return map.entrySet().stream()
                .filter(entryPredicate.negate())
                .collect(toMap(Entry::getKey, Entry::getValue));
    }
}
