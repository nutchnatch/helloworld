package com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.Mediator;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.MediatorPhysicalInstance;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableMediatorInstanceValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableMediatorValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorInstanceValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.parseInt;
import static java.util.Optional.ofNullable;

public final class Mediators {

    private Mediators() {}

    public static Mediator transform(MediatorValueObject mediatorValue) {
        Mediator mediator = new Mediator();

        mediator.setIDName(mediatorValue.getName());
        mediator.setHost(mediatorValue.getHost());
        mediator.setType(mediatorValue.getType());

        mediatorValue.getReconnectInterval().map(Object::toString).ifPresent(mediator::setReconnectInterval);
        mediatorValue.getConcurrentActivationsLimit().map(Object::toString).ifPresent(mediator::setConcurrentActivationsLimit);
        mediatorValue.getConcurrentActivationsLimited().ifPresent(mediator::setConcurrentActivationsLimited);
        mediatorValue.getDescription().ifPresent(mediator::setDescription);

        mediator.getPhysicalInstance().addAll(transform(mediatorValue.getMediatorInstances()));
        mediator.getProperty().addAll(PropertiesTransformer.transform(mediatorValue.getPropertyBag()));

        return mediator;
    }

    public static MediatorValueObject transform(Mediator mediator) {
        return ImmutableMediatorValueObject.builder()

                .name(mediator.getIDName())
                .type(mediator.getType())
                .host(mediator.getHost())

                .reconnectInterval(parseInt(mediator.getReconnectInterval()))
                .description(ofNullable(mediator.getDescription()))
                .concurrentActivationsLimit(parseInt(mediator.getConcurrentActivationsLimit()))
                .concurrentActivationsLimited(ofNullable(mediator.isConcurrentActivationsLimited()))
                .mediatorInstances(transform(mediator.getPhysicalInstance()))
                .propertyBag(PropertiesTransformer.transform(mediator.getProperty()))

                .build();
    }

    public static List<MediatorPhysicalInstance> transform(Collection<MediatorInstanceValueObject> mediatorInstances) {
        return mediatorInstances.stream()
                .map((m) -> {
                    MediatorPhysicalInstance physicalInstance = new MediatorPhysicalInstance();
                    physicalInstance.setHost(m.getHost());
                    physicalInstance.setPriority(m.getPriority());
                    return physicalInstance;
                }).collect(Collectors.toList());
    }

    public static Collection<MediatorInstanceValueObject> transform(List<MediatorPhysicalInstance> physicalInstances) {
        return physicalInstances.stream()
                .map(m -> ImmutableMediatorInstanceValueObject.builder()
                        .host(m.getHost())
                        .priority(m.getPriority())
                        .build())
                .collect(Collectors.toList());
    }
}
