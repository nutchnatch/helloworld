package com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.NE;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.AddressSplit;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.DataTransferSettingsMigration;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.DefaultProperties;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.MergeProperties;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.PasswordMigration;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.PropertiesKeysMapper;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.PropertyRemover;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;

import static com.google.common.collect.ImmutableMap.of;
import static com.google.common.collect.ImmutableSet.copyOf;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.KeysMapping.NE_KEYS;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.DataTransferSettingsMigration.ftpKeys;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.PasswordMigration.MAPPINGS_ENCTYPT;
import static com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames.USER_TEXT;
import static com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableNeValueObject.builder;
import static java.util.Arrays.asList;
import static java.util.Optional.ofNullable;

public class NeTransformerCore implements NeTransformer {
    private static final int LIMIT = 255;

    private static final Set<String> ADDRESS_PROPERTIES = copyOf(new String[]{
            "BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP",
            "com.ossnms.mvm.hit7090.ip",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP",
            "E02A2D18-CAF9-48FB-8B1E-E2F5D16BEF87/NSAP"});

    private static final List<String> USE_GNE = asList(
            "BD4B7A2F-1406-4617-B163-39D1AF00EF03/USE_GNE",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/USE_GNE");

    private static final Map<String, String> DEFAULTS = of("BD4B7A2F-1406-4617-B163-39D1AF00EF03/ContextName", "tnms");

    private static final Set<String> PROPERTIES_TO_BE_REMOVED = copyOf(new String[]{
            "C334FAA5-9F77-48D3-AF63-428F31718B35/FTP_IP_ADDRESS",
            "C334FAA5-9F77-48D3-AF63-428F31718B35/FTP_PORT",
            "38250635-F75A-4F6B-8D66-50A014D40A55/GlobalNeIdentifier",
            "0EB12480-EC8A-11D4-9D9C-00105AF68EBA/OLD_PASSWORD_STR",
            "0EB12480-EC8A-11D4-9D9C-00105AF68EBA/NEW_PASSWORD_STR",
            "0EB12480-EC8A-11D4-9D9C-00105AF68EBA/NEW_PASSWORD_SWITCH",
            "0EB12480-EC8A-11D4-9D9C-00105AF68EBA/SET_NE_PW_SUPPORTED"
    });

    private static final Set<String> ROUTE_PROPERTIES = copyOf(new String[]{
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/ACTIVE_GNE",
            "ACTIVE_GNE",
            "ADDRESS_000", "ADDRESS_001", "ADDRESS_002", "ADDRESS_003", "ADDRESS_004",
            "ADDRESS_005", "ADDRESS_006", "ADDRESS_007", "ADDRESS_008", "ADDRESS_009",
            "SYSNAME_000", "SYSNAME_001", "SYSNAME_002", "SYSNAME_003", "SYSNAME_004",
            "SYSNAME_005", "SYSNAME_006", "SYSNAME_007", "SYSNAME_008", "SYSNAME_009",
            "PORT_000", "PORT_001", "PORT_002", "PORT_003", "PORT_004",
            "PORT_005", "PORT_006", "PORT_007", "PORT_008", "PORT_009",
            "PRIO_000", "PRIO_001", "PRIO_002", "PRIO_003", "PRIO_004",
            "PRIO_005", "PRIO_006", "PRIO_007", "PRIO_008", "PRIO_009",
            "USED_000", "USED_001", "USED_002", "USED_003", "USED_004",
            "USED_005", "USED_006", "USED_007", "USED_008", "USED_009",
            "COST_000", "COST_001", "COST_002", "COST_003", "COST_004",
            "COST_005", "COST_006", "COST_007", "COST_008", "COST_009",
            "FTP_000", "FTP_001", "FTP_002", "FTP_003", "FTP_004",
            "FTP_005", "FTP_006", "FTP_007", "FTP_008", "FTP_009",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/PRIO_000",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/PRIO_001",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/PRIO_002",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/PRIO_003",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/PRIO_004",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/PRIO_005",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/PRIO_006",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/PRIO_007",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/PRIO_008",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/PRIO_009",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_COST_000",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_COST_001",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_COST_002",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_COST_003",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_COST_004",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_COST_005",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_COST_006",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_COST_007",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_COST_008",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_COST_009",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_000",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_001",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_002",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_003",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_004",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_005",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_006",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_007",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_008",
            "369AB9C2-B597-49BA-9190-7D1CEA0C924F/NSAP_009",
            "BD4B7A2F-1406-4617-B163-39D1AF00EF03/ADDRESS IP VERSION_000",
            "BD4B7A2F-1406-4617-B163-39D1AF00EF03/ADDRESS IP VERSION_001",
            "BD4B7A2F-1406-4617-B163-39D1AF00EF03/ADDRESS IP VERSION_002",
            "BD4B7A2F-1406-4617-B163-39D1AF00EF03/ADDRESS IP VERSION_003",
            "BD4B7A2F-1406-4617-B163-39D1AF00EF03/ADDRESS IP VERSION_004",
            "BD4B7A2F-1406-4617-B163-39D1AF00EF03/ADDRESS IP VERSION_005",
            "BD4B7A2F-1406-4617-B163-39D1AF00EF03/ADDRESS IP VERSION_006",
            "BD4B7A2F-1406-4617-B163-39D1AF00EF03/ADDRESS IP VERSION_007",
            "BD4B7A2F-1406-4617-B163-39D1AF00EF03/ADDRESS IP VERSION_008",
            "BD4B7A2F-1406-4617-B163-39D1AF00EF03/ADDRESS IP VERSION_009"});

    private static final Map<String, String> ADDRESS_PORT_PREFIX = of(
            "ACTIVE_GNE", "ACTIVE_GNE_PORT",
            "ADDRESS", "PORT",
            "BD4B7A2F-1406-4617-B163-39D1AF00EF03/IP", "snmpPort"
    );
    private static final Map<String, Collection<String>> JOIN_USER_TEXT = of(USER_TEXT, asList(USER_TEXT, "43047833-19CA-42DD-944C-DC1BDF786649/UserText2"));

    private final StaticConfiguration configuration;
    private final boolean importSftp;
    private final NeTypeResolver neTypeResolver;

    public NeTransformerCore(StaticConfiguration configuration, boolean importSftp) {
        this.configuration = configuration;
        this.importSftp = importSftp;
        neTypeResolver = new NeTypeResolver(configuration.getNeTypes());
    }

    @Override public Optional<NeValueObject> apply(NE ne) {
        return transform(ne);
    }

    public Optional<NeValueObject> transform(NE ne) {
        Map<String, String> properties = new PropertiesTransformer()
                .andThen(new PropertiesKeysMapper(NE_KEYS))
                .andThen(removeConnectionProperties())
                .andThen(new PropertyRemover(PROPERTIES_TO_BE_REMOVED))
                .andThen(new DefaultProperties(DEFAULTS))
                .andThen(new AddressSplit(ADDRESS_PORT_PREFIX))
                .andThen(encryptPasswords())
                .andThen(importSftp())
                .andThen(new MergeProperties(JOIN_USER_TEXT, LIMIT))
                .apply(ne.getPropContainer());

        return ofNullable(neTypeResolver.neTypeFrom(properties))
                .map(type -> neFrom(ne, properties, type));
    }

    private Function<Map<String, String>, Map<String, String>> importSftp() {
        return map -> ofNullable(neTypeResolver.neTypeFrom(map))
                .map(type -> new DataTransferSettingsMigration(importSftp, ftpKeys(type, configuration)))
                .map(migration -> migration.apply(map))
                .orElse(map);
    }

    private Function<Map<String, String>, Map<String, String>> encryptPasswords() {
        return properties -> new PasswordMigration(MAPPINGS_ENCTYPT, neTypeResolver.neTypeFrom(properties), configuration).apply(properties);
    }

    private NeValueObject neFrom(NE ne, Map<String, String> properties, String type) {
        return builder()
                .name(ne.getIDName())
                .type(type)
                .channel("") // channel is resolved later
                .coreId(ofNullable(ne.getCOREId()))
                .propertyBag(properties)
                .build();
    }

    private Function<Map<String, String>, Map<String, String>> removeConnectionProperties() {
        return props -> new PropertyRemover(connectionPropertiesToRemove(props)).apply(props);
    }

    /**
     * remove the routes when use_gne is false: CORE does not validate duplicate routes,
     * so the import of NEs with duplicated routes that do not have this flag enabled, shall not fail
     */
    private Set<String> connectionPropertiesToRemove(Map<String, String> props) {
        return usesGne(props) ? ADDRESS_PROPERTIES : ROUTE_PROPERTIES;
    }

    private boolean usesGne(Map<String, String> props) {
        String useGne = USE_GNE.stream().map(props::get).filter(Objects::nonNull).findFirst().orElse("false");
        return "true".equalsIgnoreCase(useGne);
    }
}
