package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import com.google.common.base.Throwables;
import com.ossnms.bicnet.util.crypt.DESEncrypterDecrypter;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.migration.jaxb.passwordproperties.Password;
import com.ossnms.dcn_manager.migration.jaxb.passwordproperties.Properties;

import javax.xml.bind.DatatypeConverter;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Stream;

import static com.google.common.collect.ImmutableMap.of;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.testing;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.testingKey;
import static com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames.USER_PASSWORD;
import static java.util.Optional.ofNullable;
import static javax.xml.bind.DatatypeConverter.printHexBinary;

public class PasswordMigration implements Function<Map<String, String>, Map<String, String>> {

    public static final Map<String, PropertyMapping> MAPPINGS_RECRYPT = of(
            "", PasswordMigration::identity,
            "md5", PasswordMigration::recrypt);

    public static final Map<String, PropertyMapping> MAPPINGS_ENCTYPT = of(
            "", PasswordMigration::encrypt,
            "md5", PasswordMigration::encryptMd5);

    private final StaticConfiguration configuration;
    private final Optional<NeType> neTypeOpt;
    private final Map<String, PropertyMapping> mappings;

    /**
     * @param mappings configuration of function to perform for each password type
     * @param neType type of 
     * @param configuration configuration to resolve NE Type and password properties
     */
    public PasswordMigration(Map<String, PropertyMapping> mappings, String neType, StaticConfiguration configuration) {
        this.mappings = mappings;
        this.configuration = configuration;
        neTypeOpt = ofNullable(configuration.getNeTypes().get(neType));
    }

    private static String identity(String key, String value) {
        return value;
    }
    
    private static String recrypt(String key, String value) {
        DESEncrypterDecrypter des = des();
        byte[] original = DatatypeConverter.parseHexBinary(des.decryptData(value));
        return printHexBinary(des.encryptData(original));
    }

    private static String encryptMd5(String key, String value) {
        byte[] original = DatatypeConverter.parseHexBinary(value);
        return printHexBinary(des().encryptData(original));
    }

    private static String encrypt(String key, String value) {
        return des().encryptData(value);
    }

    /**
     * @return An instance of {@link DESEncrypterDecrypter}.
     * @throws RuntimeException If it was not possible to create the object instance.
     */
    private static DESEncrypterDecrypter des() {
        try {
            return new DESEncrypterDecrypter();
        } catch (InvalidKeyException | InvalidAlgorithmParameterException e) {
            throw Throwables.propagate(e);
        }
    }

    /**
     * For given properties migrate passwords values to DCN Manager format
     */
    public Map<String, String> migrate(Map<String, String> properties) {
        return neTypeOpt
                .map(neType -> updatePasswords(properties, neType))
                .orElse(properties);
    }

    private Map<String, String> updatePasswords(Map<String, String> properties, NeType neType) {
        Password password = passwordCoding(neType);
        PropertyMapping mapping = mappings.getOrDefault(password.getCoding(), PasswordMigration::identity);
        properties.computeIfPresent(password.getName(), mapping);
        return properties;
    }

    private Password passwordCoding(NeType neType) {
        String passwordField = neType.mapOutgoingPropertyName(USER_PASSWORD);
        Collection<String> propertyFiles = neType.getSupportedPropertyFileNames();
        return findPasswordProperties(passwordField, propertyFiles);
    }

    private Password findPasswordProperties(String passwordField, Collection<String> fileNames) {
        Collection<String> files = new HashSet<>(fileNames);
        Stream<Properties> passwordProperties = configuration.getPasswordPropertyMetadata()
                .entrySet().stream()
                .filter(testingKey(files::contains))
                .map(Entry::getValue);

        Stream<Password> passwords = passwordProperties
                .flatMap(properties -> properties.getPassword().stream());

        return passwords
                .filter(testing(Password::getName, passwordField::equals))
                .findAny().orElse(new Password());
    }

    @Override public Map<String, String> apply(Map<String, String> map) {
        return migrate(map);
    }

    @FunctionalInterface private interface PropertyMapping extends BiFunction<String, String, String> {
    }
}
