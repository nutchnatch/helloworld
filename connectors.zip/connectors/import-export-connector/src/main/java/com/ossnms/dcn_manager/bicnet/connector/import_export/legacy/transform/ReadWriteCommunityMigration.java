package com.ossnms.dcn_manager.bicnet.connector.import_export.legacy.transform;

import com.google.common.base.Throwables;
import com.ossnms.bicnet.util.crypt.DESEncrypterDecrypter;

import javax.annotation.Nonnull;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;

import static com.google.common.collect.ImmutableList.of;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.mappingValue;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.testingKey;
import static java.util.stream.Collectors.toMap;

/**
 * Migrates the Read/Write Community, decrypting the values when present.
 */
class ReadWriteCommunityMigration implements Function<Map<String, String>, Map<String, String>> {

    private static final Collection<String> RW_COMMUNITY_MAPPINGS = of(
            "BD4B7A2F-1406-4617-B163-39D1AF00EF03/Read community",
            "BD4B7A2F-1406-4617-B163-39D1AF00EF03/Write community");

    /**
     * @param properties
     * @return The all properties values, if the Read/Write Community is present, those values will be decrypted.
     */
    @Override
    public Map<String, String> apply(@Nonnull final Map<String, String> properties) {
        return transform(properties);
    }

    public static Map<String, String> transform(@Nonnull final Map<String, String> properties) {
        properties.putAll(
                properties.entrySet().stream()
                        .filter(testingKey(RW_COMMUNITY_MAPPINGS::contains))
                        .map(mappingValue(des()::decryptData))
                        .collect(toMap(Entry::getKey, Entry::getValue))
        );

        return properties;
    }

    /**
     * @return An instance of {@link DESEncrypterDecrypter}.
     * @throws RuntimeException If it was not possible to create the object instance.
     */
    private static DESEncrypterDecrypter des() {
        try {
            return new DESEncrypterDecrypter();
        } catch (InvalidKeyException | InvalidAlgorithmParameterException e) {
            throw Throwables.propagate(e);
        }
    }
}
