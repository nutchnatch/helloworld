package com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.SystemContainer;
import com.ossnms.dcn_manager.core.import_export.valueobjects.SystemValueObject;

import static com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableSystemValueObject.builder;
import static java.util.Optional.ofNullable;

public final class SystemsTransformer {


    private SystemsTransformer() {
    }

    public static SystemContainer fromValue(SystemValueObject system) {
        SystemContainer systemContainer = new SystemContainer();

        systemContainer.setIDName(system.name());
        systemContainer.setUserText(system.userText().orElse(null));
        systemContainer.setDescription(system.description().orElse(null));
        systemContainer.getAssignedContainer().addAll(AssignmentsTransformer.fromValue(system.assignedContainers()));

        return systemContainer;
    }

    public static SystemValueObject toValue(SystemContainer systemContainer) {
        return builder()
                .name(systemContainer.getIDName())
                .userText(ofNullable(systemContainer.getUserText()))
                .description(ofNullable(systemContainer.getDescription()))
                .assignedContainers(AssignmentsTransformer.toValue(systemContainer.getAssignedContainer()))
                .build();
    }
}
