package com.ossnms.dcn_manager.bicnet.connector.import_export.migration;

import com.google.common.collect.ImmutableMap;

import java.util.List;
import java.util.Map;
import java.util.function.Function;

import static com.google.common.collect.ImmutableMap.of;
import static java.util.Arrays.asList;

/**
 * Migrates NE type for NEs that changed type name between releases.
 * The goal is to be able import NEs with old type names.
 * <p>
 * Supports sequence of migrations: <br/>
 * For example if between v15 and v16 type changed `type1` to `type2` and then during v16 -> v17 `type2` changed to `type3`
 * then migration will return `type3` for both `type1` and `type2` input
 * <p>
 * {@code migrate(type1) == type3}<br/>
 * {@code migrate(type2) == type3}<br/>
 */
public class NeTypeMigration implements Function<String, String> {

    // Types renamed between v15 and V16
    private static final Map<String, String> V15_V16 = ImmutableMap.<String, String>builder()
            // Upgrade NANO and MTERA type
            .put("7100 NANO FP9.x", "7100 NANO FP10.x")
            .put("MTERA FP1.x", "MTERA FP2.x")
            // Upgrade Juniper type
            .put("MX240 13.2", "MX 240/480/960")
            .put("MX480 13.2", "MX 240/480/960")
            .put("MX960 13.2", "MX 240/480/960")
            .put("MX2010 13.2", "MX 2010/2020")
            .put("MX2020 13.2", "MX 2010/2020")
            .put("PTX3000 13.2", "PTX3000")
            .put("PTX3000 14.1", "PTX3000")
            .put("PTX5000 13.2", "PTX5000")
            .put("7090-15 CE FP3.x", "7090-5/7/15 CE FP3.x")
            .build();

    // Placeholder for future migrations
    private static final Map<String, String> V16_V17 = of();

    private final List<Map<String, String>> migrationsSequence;

    public NeTypeMigration() {
        // Note migrations are applied in order
        this(V15_V16, V16_V17);
    }

    /**
     * @param migrations array of type changes between different versions
     */
    NeTypeMigration(Map<String, String>... migrations) {
        migrationsSequence = asList(migrations);
    }

    /**
     * Apply type renaming
     *
     * @param type ne type
     * @return migrated ne type or original if no migrations
     */
    public String migrate(String type) {
        return migrationsSequence.stream()
                .sequential() //mappings should be applied in order
                .reduce(type, this::migrate, (oldValue, newValue) -> newValue);
    }

    private String migrate(String type, Map<String, String> migrationMapping) {
        return migrationMapping.getOrDefault(type, type);
    }

    @Override public String apply(String type) {
        return migrate(type);
    }
}
