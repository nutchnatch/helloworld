package com.ossnms.dcn_manager.bicnet.connector.import_export;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.Channel;
import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.Mediator;
import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.NE;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ImportCtService;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.Process;
import com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.Transformations;
import com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.NeTransformerCT;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSettingsRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.commands.import_export.ImportChannels;
import com.ossnms.dcn_manager.commands.import_export.ImportMediators;
import com.ossnms.dcn_manager.commands.import_export.ImportNEs;
import com.ossnms.dcn_manager.composables.channel.ChannelCreationBase;
import com.ossnms.dcn_manager.composables.container.ContainersNeAssignmentUpdater;
import com.ossnms.dcn_manager.composables.import_export.channel.ImportChannelTransformer;
import com.ossnms.dcn_manager.composables.import_export.mediator.ImportMediatorTransformer;
import com.ossnms.dcn_manager.composables.import_export.ne.ImportNeTransformer;
import com.ossnms.dcn_manager.composables.mediator.MediatorCreationBase;
import com.ossnms.dcn_manager.composables.ne.NeCreationBase;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.import_export.identification.ChannelIdentification;
import com.ossnms.dcn_manager.core.import_export.identification.GenericContainerIdentification;
import com.ossnms.dcn_manager.core.import_export.identification.MediatorIdentification;
import com.ossnms.dcn_manager.core.import_export.identification.NeIdentification;
import com.ossnms.dcn_manager.core.import_export.identification.SystemContainerIdentification;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ChannelValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelSchedulingConfiguration;
import com.ossnms.dcn_manager.core.policies.MediatorSchedulingConfiguration;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import java.util.Collection;

import static java.util.Objects.requireNonNull;

@Stateless(name = "ImportCtServiceBean")
@Local(ImportCtService.class)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class ImportCtServiceBean implements ImportCtService {

    @Inject private MediatorManagers mediatorManagers;
    @Inject private StaticConfiguration configuration;
    @Inject private LoggerManagerImpl loggerManager;
    @Inject private ChannelManagers channelManagers;
    @Inject private NetworkElementManagers neManagers;
    @Inject private ContainerNotifications containerNotifications;

    @Inject @DcnManager private JpaContainerRepositoryBean containerRepository;
    @Inject @DcnManager private JpaSettingsRepositoryBean settingsRepository;
    @Inject @DcnManager private ChannelSchedulingConfiguration channelScheduling;
    @Inject @DcnManager private MediatorSchedulingConfiguration mediatorScheduling;
    @Inject @DcnManager private JpaSystemRepositoryBean systemRepository;

    @Override
    public Collection<String> importChannel(ISessionContext context, Mediator mediator, Channel channel, Collection<NE> nes, boolean importSftp) {
        requireNonNull(context);
        requireNonNull(mediator);
        requireNonNull(channel);
        requireNonNull(nes);

        MediatorIdentification mediatorId = new MediatorIdentification(
                configuration.getMediatorTypes(), mediatorManagers.getMediatorRepository().getMediatorInfoRepository());
        Transformations transformations = new Transformations(configuration, new NeTransformerCT(configuration, importSftp));
        Process process = new Process(transformations, new BicnetCallContext(context), loggerManager, mediatorId,
                this::importNes, this::importChannels, this::importMediators);

        return process.performImport(nes, channel, mediator);
    }

    private Collection<String> importNes(BicnetCallContext context, Collection<NeValueObject> nes) {
        return new ImportNEs<>(context, nes,
                loggerManager,
                new ContainersNeAssignmentUpdater<>(
                        settingsRepository,
                        containerRepository,
                        systemRepository,
                        containerNotifications,
                        loggerManager,
                        context),
                new NeIdentification(neManagers.getNeRepository().getNeUserPreferencesRepository()),
                new GenericContainerIdentification(containerRepository),
                new ImportNeTransformer(
                        new ChannelIdentification(channelManagers.getChannelRepository()),
                        new SystemContainerIdentification(systemRepository),
                        configuration),
                new NeCreationBase<>(
                        context,
                        neManagers.getNeRepository(),
                        neManagers.getNeInstanceRepository(),
                        neManagers.getNeNotifications(),
                        channelManagers.getChannelRepository(),
                        systemRepository,
                        channelManagers.getChannelInstanceConnections(),
                        loggerManager
                )
        ).call();
    }

    private Collection<String> importChannels(BicnetCallContext context, Collection<ChannelValueObject> channels) {
        return new ImportChannels<>(
                context,
                channels,
                loggerManager,
                new ChannelIdentification(
                        channelManagers.getChannelRepository()),
                new ChannelCreationBase<>(
                        context,
                        channelManagers.getChannelRepository(),
                        channelManagers.getChannelNotifications(),
                        channelManagers.getChannelInstanceConnections(),
                        channelScheduling,
                        mediatorManagers.getMediatorRepository(),
                        mediatorManagers.getMediatorInstanceRepository(),
                        loggerManager),
                new ImportChannelTransformer(
                        configuration,
                        new MediatorIdentification(
                                configuration.getMediatorTypes(),
                                mediatorManagers.getMediatorRepository().getMediatorInfoRepository()))
        ).call();
    }

    private Collection<String> importMediators(BicnetCallContext context, Collection<MediatorValueObject> mediators) {
        return new ImportMediators<>(
                context,
                mediators,
                loggerManager,
                new ImportMediatorTransformer(configuration),
                new MediatorCreationBase<>(
                        context,
                        mediatorManagers.getMediatorRepository(),
                        mediatorManagers.getMediatorInstanceRepository(),
                        mediatorManagers.getMediatorNotifications(),
                        configuration,
                        mediatorScheduling,
                        loggerManager),
                new MediatorIdentification(
                        configuration.getMediatorTypes(),
                        mediatorManagers.getMediatorRepository().getMediatorInfoRepository())
        ).call();
    }
}