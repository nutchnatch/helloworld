package com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.Property;

import static java.lang.Integer.parseInt;
import static java.lang.String.valueOf;
import static org.apache.commons.lang3.StringUtils.lowerCase;

final class PropertiesNormalizer {

    private static final int HEXADECIMAL = 16;

    private PropertiesNormalizer() {
    }

    /**
     * Given Core/CT property entry returns value converted to normal type
     */
    static String normalizedValue(Property property) {
        String value = property.getContent();
        switch (property.getType()) {
            case "VT_UI4":
                return hexToDec(value);
            case "VT_BOOL":
                return lowerCase(value);
        }
        return value;
    }

    private static String hexToDec(String value) {
        if ("ffffffff".equals(value)) {
            return "-1";
        }
        return valueOf(parseInt(value, HEXADECIMAL));
    }
}
