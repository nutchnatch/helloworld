package com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.NE;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;

import java.util.Optional;
import java.util.function.Function;

public interface NeTransformer extends Function<NE, Optional<NeValueObject>> {

}
