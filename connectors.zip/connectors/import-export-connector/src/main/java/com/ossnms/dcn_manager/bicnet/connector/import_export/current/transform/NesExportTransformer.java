package com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.DcnAttributes;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.NeTypeTaxonomy;
import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.NetworkElement;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeAdditionalInfo;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeValueObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;

import static com.google.common.collect.ImmutableMap.of;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform.PropertiesTransformer.transform;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.mappingValue;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.testingValue;

public class NesExportTransformer implements Function<NeValueObject, NetworkElement> {

    static final Map<String, Function<NeValueObject, String>> EXPORT_ONLY_PROPERTIES = of(
            "NE_LOCATION", ne -> ne.getLocation().orElse(null));

    private static NetworkElement fromValue(NeValueObject ne) {
        NetworkElement networkElement = new NetworkElement();
        networkElement.setIDName(ne.getName());
        networkElement.setType(ne.getType());
        networkElement.setParentEM(ne.getChannel());
        networkElement.setNeTypeTaxonomy(newTypeTaxonomy(ne));
        networkElement.getParentAS().addAll(Domains.transform(ne.getDomainNames()));
        networkElement.getProperty().addAll(transform(withExportOnlyProperties(ne)));
        networkElement.getAssignedContainer().addAll(AssignmentsTransformer.fromValue(ne.getAssignedContainers()));
        networkElement.setSystemContainer(ne.systemContainer().orElse(null));
        networkElement.setDcnAttributes(dcnAttributes(ne));
        networkElement.setMountMode(mountMode(ne));
        networkElement.setNeSoftwareVersion(swVersion(ne));
        return networkElement;
    }

    private static NeTypeTaxonomy newTypeTaxonomy(NeValueObject ne) {
        NeTypeTaxonomy taxonomy = new NeTypeTaxonomy();
        ne.getFamilyLabel().ifPresent(taxonomy::setNeFamilyLabel);
        ne.getTypeLabel().ifPresent(taxonomy::setNeTypeLabel);
        ne.getSubTypeLabel().ifPresent(taxonomy::setNeSubTypeLabel);
        return taxonomy;
    }

    private static DcnAttributes dcnAttributes(NeValueObject ne) {
        return ne.getNeAdditionalInfo().map(NesExportTransformer::dcnAttributes).orElseGet(DcnAttributes::new);
    }

    private static DcnAttributes dcnAttributes(NeAdditionalInfo neInfo) {
        DcnAttributes dcnAttributes = new DcnAttributes();
        dcnAttributes.setLocalInterface(neInfo.getLocalInterface().orElse(""));
        dcnAttributes.setLocalInterfaceMask(neInfo.getLocalInterfaceMask().orElse(""));
        dcnAttributes.setRouterInterface(neInfo.getRouterInterface().orElse(""));
        dcnAttributes.setRouterInterfaceMask(neInfo.getRouterInterfaceMask().orElse(""));
        dcnAttributes.setDcnInterface(neInfo.getDcnInterface().orElse(""));
        dcnAttributes.setDcnInterfaceMask(neInfo.getDcnInterfaceMask().orElse(""));
        dcnAttributes.setManagementInterface(neInfo.getManagementInterface().orElse(""));
        dcnAttributes.setManagementInterfaceMask(neInfo.getManagementInterfaceMask().orElse(""));
        dcnAttributes.setEonType(neInfo.getEonType().orElse(""));
        dcnAttributes.setGateway(neInfo.getGateway().orElse(""));
        return dcnAttributes;
    }

    private static String mountMode(NeValueObject ne) {
        return ne.getNeAdditionalInfo().flatMap(NeAdditionalInfo::getMountMode).orElse("");
    }

    private static String swVersion(NeValueObject ne) {
        return ne.getNeAdditionalInfo().flatMap(NeAdditionalInfo::getNeSwVersion).orElse("");
    }

    @Override

    public NetworkElement apply(NeValueObject neValueObject) {
        return fromValue(neValueObject);
    }

     public static Map<String, String> withExportOnlyProperties(NeValueObject ne) {
         Map<String, String> result = new HashMap<>(ne.getPropertyBag());
         
        EXPORT_ONLY_PROPERTIES.entrySet().stream()
                .map(mappingValue(getter -> getter.apply(ne)))
                .filter(testingValue(Objects::nonNull))
                .forEach(e -> result.put(e.getKey(), e.getValue()));

         return result;
    }
}
