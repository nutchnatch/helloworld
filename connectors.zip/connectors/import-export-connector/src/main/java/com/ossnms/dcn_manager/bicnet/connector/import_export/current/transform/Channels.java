package com.ossnms.dcn_manager.bicnet.connector.import_export.current.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager.Channel;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ChannelValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableChannelValueObject;

import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.parseInt;
import static java.util.Optional.ofNullable;

public final class Channels {

    private Channels() {
    }

    public static Channel transform(ChannelValueObject channelValue) {
        Channel channel = new Channel();

        channel.setIDName(channelValue.getName());
        channel.setType(channelValue.getType());
        channelValue.getConcurrentActivationsLimit().map(String::valueOf).ifPresent(channel::setConcurrentActivationsLimit);
        channelValue.getConcurrentActivationsLimited().ifPresent(channel::setConcurrentActivationsLimited);
        channel.setMediator(Mediators.transform(channelValue.getMediator()));

        channel.getProperty().addAll(PropertiesTransformer.transform(channelValue.getPropertyBag()));

        return channel;
    }

    public static ChannelValueObject transform(Channel channel) {
        return ImmutableChannelValueObject.builder()
                .name(channel.getIDName())
                .type(channel.getType())
                .concurrentActivationsLimit(parseInt(channel.getConcurrentActivationsLimit()))
                .concurrentActivationsLimited(ofNullable(channel.isConcurrentActivationsLimited()))
                .mediator(Mediators.transform(channel.getMediator()))
                .propertyBag(PropertiesTransformer.transform(channel.getProperty()))
                .build();
    }
}
