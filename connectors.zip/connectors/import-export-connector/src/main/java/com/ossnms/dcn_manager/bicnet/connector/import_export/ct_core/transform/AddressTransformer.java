package com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetAddress;
import java.net.UnknownHostException;

import static java.net.InetAddress.getByName;
import static java.net.InetAddress.getLoopbackAddress;

final class AddressTransformer {

    private static final Logger LOGGER = LoggerFactory.getLogger(AddressTransformer.class);

    private AddressTransformer() {
    }

    /**
     * Given address value tries to resolve IP 
     * @return resolved IP or 127.0.0.1 if couldn't
     */
    static String ipFor(String host) {
        return addressOf(host).getHostAddress();
    }

    private static InetAddress addressOf(String host) {
        try {
            return getByName(host);
        } catch (UnknownHostException e) {
            LOGGER.warn("Cannot resolve address for host {}", host, e);
            return getLoopbackAddress();
        }
    }
}
