package com.ossnms.dcn_manager.bicnet.connector.import_export;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.dcn.configuration.jaxb.legacy.Channel;
import com.ossnms.bicnet.dcn.configuration.jaxb.legacy.Mediator;
import com.ossnms.bicnet.dcn.configuration.jaxb.legacy.NE;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ImportLegacyService;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.import_export.legacy.transform.TransformChannel;
import com.ossnms.dcn_manager.bicnet.connector.import_export.legacy.transform.TransformMediator;
import com.ossnms.dcn_manager.bicnet.connector.import_export.legacy.transform.TransformNE;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSettingsRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.commands.import_export.ImportChannels;
import com.ossnms.dcn_manager.commands.import_export.ImportMediators;
import com.ossnms.dcn_manager.commands.import_export.ImportNEs;
import com.ossnms.dcn_manager.composables.channel.ChannelCreationBase;
import com.ossnms.dcn_manager.composables.container.ContainersNeAssignmentUpdater;
import com.ossnms.dcn_manager.composables.import_export.channel.ImportChannelTransformer;
import com.ossnms.dcn_manager.composables.import_export.mediator.ImportMediatorTransformer;
import com.ossnms.dcn_manager.composables.import_export.ne.ImportNeTransformer;
import com.ossnms.dcn_manager.composables.mediator.MediatorCreationBase;
import com.ossnms.dcn_manager.composables.ne.NeCreationBase;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.import_export.identification.ChannelIdentification;
import com.ossnms.dcn_manager.core.import_export.identification.GenericContainerIdentification;
import com.ossnms.dcn_manager.core.import_export.identification.MediatorIdentification;
import com.ossnms.dcn_manager.core.import_export.identification.NeIdentification;
import com.ossnms.dcn_manager.core.import_export.identification.SystemContainerIdentification;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelSchedulingConfiguration;
import com.ossnms.dcn_manager.core.policies.MediatorSchedulingConfiguration;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import java.util.Collection;
import java.util.function.Function;

import static com.ossnms.dcn_manager.bicnet.connector.facade.util.Exceptions.logAndRethrowAsBcb;
import static java.util.Objects.requireNonNull;
import static java.util.stream.Collectors.toList;

@Stateless(name = "ImportLegacyServiceBean")
@Local(ImportLegacyService.class)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class ImportLegacyServiceBean implements ImportLegacyService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ImportLegacyServiceBean.class);

    @Inject private StaticConfiguration configuration;
    @Inject private ChannelManagers channelManagers;
    @Inject private MediatorManagers mediatorManagers;
    @Inject private NetworkElementManagers neManagers;
    @Inject private ContainerNotifications containerNotifications;

    @Inject @DcnManager private JpaContainerRepositoryBean containerRepository;
    @Inject @DcnManager private JpaSettingsRepositoryBean settingsRepository;
    @Inject @DcnManager private ChannelSchedulingConfiguration channelScheduling;
    @Inject @DcnManager private MediatorSchedulingConfiguration mediatorScheduling;
    @Inject @DcnManager private JpaSystemRepositoryBean systemRepository;

    @Inject private LoggerManagerImpl loggerManager;

    @Override
    public Collection<String> importMediators(
            @Nonnull final ISessionContext sessionContext, @Nonnull final Collection<Mediator> mediators)
            throws BcbException {
        requireNonNull(sessionContext);
        requireNonNull(mediators);

        try {
            BicnetCallContext callContext = new BicnetCallContext(sessionContext);
            return new ImportMediators<>(
                    callContext,
                    forAll(mediators, new TransformMediator()),
                    loggerManager,
                    new ImportMediatorTransformer(configuration),
                    new MediatorCreationBase<>(
                            callContext,
                            mediatorManagers.getMediatorRepository(),
                            mediatorManagers.getMediatorInstanceRepository(),
                            mediatorManagers.getMediatorNotifications(),
                            configuration,
                            mediatorScheduling,
                            loggerManager),
                    new MediatorIdentification(
                            configuration.getMediatorTypes(),
                            mediatorManagers.getMediatorRepository().getMediatorInfoRepository())
            ).call();
        } catch (final Exception e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public Collection<String> importChannels(
            @Nonnull final ISessionContext sessionContext,
            @Nonnull final Mediator mediator, @Nonnull final Collection<Channel> channels)
            throws BcbException {
        requireNonNull(sessionContext);
        requireNonNull(mediator);
        requireNonNull(channels);

        try {
            final MediatorValueObject mediatorValueObject = new TransformMediator().apply(mediator);

            BicnetCallContext callContext = new BicnetCallContext(sessionContext);
            return new ImportChannels<>(
                    callContext,
                    forAll(channels, new TransformChannel(mediatorValueObject)),
                    loggerManager,
                    new ChannelIdentification(
                            channelManagers.getChannelRepository()),
                    new ChannelCreationBase<>(
                            callContext,
                            channelManagers.getChannelRepository(),
                            channelManagers.getChannelNotifications(),
                            channelManagers.getChannelInstanceConnections(),
                            channelScheduling,
                            mediatorManagers.getMediatorRepository(),
                            mediatorManagers.getMediatorInstanceRepository(),
                            loggerManager),
                    new ImportChannelTransformer(
                            configuration,
                            new MediatorIdentification(
                                    configuration.getMediatorTypes(),
                                    mediatorManagers.getMediatorRepository().getMediatorInfoRepository()))
            ).call();
        } catch (final Exception e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public Collection<String> importNEs(
            @Nonnull final ISessionContext sessionContext, @Nonnull final Collection<NE> nes, boolean importSftp)
            throws BcbException {
        requireNonNull(sessionContext);
        requireNonNull(nes);

        try {
            final BicnetCallContext bicnetCallContext = new BicnetCallContext(sessionContext);
            return new ImportNEs<>(
                    bicnetCallContext,
                    forAll(nes, new TransformNE(configuration, importSftp)),
                    loggerManager,
                    new ContainersNeAssignmentUpdater<>(
                            settingsRepository,
                            containerRepository,
                            systemRepository,
                            containerNotifications,
                            loggerManager,
                            bicnetCallContext),
                    new NeIdentification(neManagers.getNeRepository().getNeUserPreferencesRepository()),
                    new GenericContainerIdentification(containerRepository),
                    new ImportNeTransformer(
                            new ChannelIdentification(channelManagers.getChannelRepository()),
                            new SystemContainerIdentification(systemRepository), configuration),
                    new NeCreationBase<>(
                            bicnetCallContext,
                            neManagers.getNeRepository(),
                            neManagers.getNeInstanceRepository(),
                            neManagers.getNeNotifications(),
                            channelManagers.getChannelRepository(),
                            systemRepository,
                            channelManagers.getChannelInstanceConnections(),
                            loggerManager
                    )
            ).call();
        } catch (final Exception e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    private <S, R> Collection<R> forAll(Collection<S> items, Function<S, R> transformation) {
        return items.stream().map(transformation).collect(toList());
    }
}
