package com.ossnms.dcn_manager.bicnet.connector.import_export.legacy.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.legacy.Channel;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ChannelValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableChannelValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;

import javax.annotation.Nonnull;
import java.util.function.Function;

public class TransformChannel implements Function<Channel, ChannelValueObject> {

    private final MediatorValueObject mediator;

    public TransformChannel(@Nonnull final MediatorValueObject mediator) {
        this.mediator = mediator;
    }

    @Override
    public ChannelValueObject apply(@Nonnull final Channel channel) {
        return ImmutableChannelValueObject.builder()
                .name(channel.getIDName())
                .type(channel.getType())
                .mediator(mediator)
                .propertyBag(TransformProperties.transform(channel.getProperty()))
                .build();
    }
}
