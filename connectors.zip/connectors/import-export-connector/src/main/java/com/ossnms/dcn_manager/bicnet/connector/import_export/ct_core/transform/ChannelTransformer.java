package com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform;

import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.Channel;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.PropertiesKeysMapper;
import com.ossnms.dcn_manager.bicnet.connector.import_export.migration.PropertiesValidator;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ChannelValueObject;
import com.ossnms.dcn_manager.core.import_export.valueobjects.MediatorValueObject;

import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;

import static com.google.common.collect.ImmutableMap.of;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.KeysMapping.CHANNEL_KEYS;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.ct_core.transform.KeysMapping.EM_TYPE;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.parseInt;
import static com.ossnms.dcn_manager.core.configuration.properties.WellKnownChannelPropertyNames.CONCURRENT_ACTIVATIONS_LIMIT;
import static com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableChannelValueObject.builder;
import static java.lang.String.join;
import static java.util.Collections.emptyMap;

public final class ChannelTransformer {

    private static final Map<String, Predicate<String>> VALIDATORS = 
            of(CONCURRENT_ACTIVATIONS_LIMIT, ChannelTransformer::isGreaterThanZero);

    private ChannelTransformer() {
    }

    public static ChannelValueObject toChannelVO(MediatorValueObject mediator, Channel channel, String channelType) {
        Map<String, String> bag = new PropertiesTransformer()
                .andThen(new PropertiesKeysMapper(CHANNEL_KEYS))
                .andThen(validateBelongsTo(channelType))
                .andThen(new PropertiesValidator(VALIDATORS))
                .apply(channel.getPropContainer());

        Optional<Integer> concurrentActivationsLimit = parseInt(bag.get(CONCURRENT_ACTIVATIONS_LIMIT));
        return builder()
                .channelId(1)
                .name(join("_", channel.getIDName(), channelType))
                .type(channelType)
                .mediator(mediator)
                .concurrentActivationsLimit(concurrentActivationsLimit)
                .concurrentActivationsLimited(concurrentActivationsLimit.isPresent())
                .propertyBag(bag)
                .build();
    }

    private static boolean isGreaterThanZero(String value) {
        return parseInt(value).map(v -> v > 0).orElse(false);
    }

    /**
     * When channel type is different from one in properties bag then properties are not valid
     */
    private static Function<Map<String, String>, Map<String, String>> validateBelongsTo(String channelType) {
        return map -> channelType.equals(map.get(EM_TYPE))
                        ? map
                        : emptyMap();
    }
}
