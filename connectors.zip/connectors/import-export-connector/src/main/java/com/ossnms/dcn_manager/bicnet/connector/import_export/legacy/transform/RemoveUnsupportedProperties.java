package com.ossnms.dcn_manager.bicnet.connector.import_export.legacy.transform;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Map;
import java.util.function.Function;

import static com.google.common.collect.ImmutableList.of;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.filterOut;
import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.testingKey;

/**
 * Migrates the Read/Write Community, decrypting the values when present.
 */
class RemoveUnsupportedProperties implements Function<Map<String, String>, Map<String, String>> {

    private static final Collection<String> NOT_SUPPORTED_ON_MIGRATION = of(
            "0EB12480-EC8A-11D4-9D9C-00105AF68EBA/OLD_PASSWORD_STR",
            "0EB12480-EC8A-11D4-9D9C-00105AF68EBA/NEW_PASSWORD_STR",
            "NE_RECONNECT_INTERVAL"
    );

    /**
     * @param properties
     * @return The all properties that supports migration.
     */
    @Override
    public Map<String, String> apply(@Nonnull final Map<String, String> properties) {
        return transform(properties);
    }

    public static Map<String, String> transform(@Nonnull final Map<String, String> properties) {
        return filterOut(properties, testingKey(NOT_SUPPORTED_ON_MIGRATION::contains));
    }
}
