package com.ossnms.dcn_manager.bicnet.connector.import_export.outbound;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementItem;
import com.ossnms.bicnet.bcb.facade.ndm.INetworkDataManagerFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.elementMgmt.ApsDescription;
import com.ossnms.bicnet.bcb.model.elementMgmt.ApsDetails;
import com.ossnms.bicnet.bcb.model.elementMgmt.IMTera7100NetworkPropertiesFacet;
import com.ossnms.bicnet.bcb.model.elementMgmt.IManagementInterfaceFacet;
import com.ossnms.bicnet.bcb.model.elementMgmt.IMountDetailsPkg;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElement;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.ISoftwareManager;
import com.ossnms.bicnet.bcb.model.elementMgmt.IpNetworkAddress;
import com.ossnms.bicnet.bcb.model.elementMgmt.MemoryBankDetails;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableNeAdditionalInfo;
import com.ossnms.dcn_manager.core.import_export.valueobjects.ImmutableNeAdditionalInfo.Builder;
import com.ossnms.dcn_manager.core.import_export.valueobjects.NeAdditionalInfo;

public final class ExportNeAdditionalInfo {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExportNeAdditionalInfo.class);

	@Inject
	@DcnManager
	private INetworkDataManagerFacade ndmFacade;

	/**
	 * Get a map containing NE Id and a network element additional information to be added in export XML.
	 * @param sessionContext
	 * @param nes
	 * @return map with NE Id as key and NE additional info as value.
	 */
	public Map<Integer, NeAdditionalInfo> getExportNeAdditionalInfo(ISessionContext sessionContext, Collection<INE> nes) {
		if (nes.isEmpty()) {
			return Collections.emptyMap();
		}
		
		INetworkElementMarkable[] filter = nes.stream().map(ne -> {
			INetworkElementMarkable markable = NetworkElementItem.markableNetworkElement(null);
			markable.setNeId(ne.getId());
			return markable;
		}).toArray(INetworkElementMarkable[]::new);

		try {
			INetworkElement[] networkElements = ndmFacade.getNetworkElementList(sessionContext, null, filter, -1)
					.getData();

			return Stream.of(networkElements)
					.filter(ExportNeAdditionalInfo::hasAdditionalInfoFacets)
					.collect(Collectors.toMap(INetworkElement::getNeId, ExportNeAdditionalInfo::buildNeAdditionalInfo));
		} catch (BcbException ex) {
			LOGGER.warn("Not possible to get NEs from network data manager therefore NE additional info was not exported", ex);
		}
		
		return Collections.emptyMap();
	}

	private static boolean hasAdditionalInfoFacets(INetworkElement ne) {
		return ne.hasFacette(IMTera7100NetworkPropertiesFacet.class) || ne.hasFacette(IManagementInterfaceFacet.class)
				|| ne.hasFacette(IMountDetailsPkg.class) || ne.hasFacette(ISoftwareManager.class);
	}

	private static NeAdditionalInfo buildNeAdditionalInfo(INetworkElement ne) {
		Builder neAdditionalInfo = ImmutableNeAdditionalInfo.builder();

		Optional.ofNullable(ne.getFacette(IMTera7100NetworkPropertiesFacet.class))
        .map(IMTera7100NetworkPropertiesFacet.class::cast)
        .ifPresent(facet -> {
        	Optional.ofNullable(facet.getEonType()).ifPresent(eonType -> neAdditionalInfo.eonType(eonType.name()));
			Optional.ofNullable(facet.getLocalInterface()).ifPresent(ip -> setLocalInterface(neAdditionalInfo, ip));
			Optional.ofNullable(facet.getRouterInterface()).ifPresent(ip -> setRouterInterface(neAdditionalInfo, ip));
			Optional.ofNullable(facet.getDcnInterface()).ifPresent(ip -> setDcnInterface(neAdditionalInfo, ip));
			Optional.ofNullable(facet.getGateway()).ifPresent(neAdditionalInfo::gateway);
        });
		
		Optional.ofNullable(ne.getFacette(IManagementInterfaceFacet.class))
        .map(IManagementInterfaceFacet.class::cast)
        .map(IManagementInterfaceFacet::getManagementInterface)
        .ifPresent(ip -> setManagementInterface(neAdditionalInfo, ip));

		Optional.ofNullable(ne.getFacette(IMountDetailsPkg.class))
        .map(IMountDetailsPkg.class::cast)
        .map(IMountDetailsPkg::getDirection)
        .ifPresent(dir -> neAdditionalInfo.mountMode(dir.name()));

		Optional.ofNullable(ne.getFacette(ISoftwareManager.class))
        .map(ISoftwareManager.class::cast)
        .map(ISoftwareManager::getApsList)
        .ifPresent(apsList -> {
			if (apsList.length > 0) {
				setNeSwVersion(neAdditionalInfo, apsList[0]);
			}
		});

		return neAdditionalInfo.build();
	}
	
	private static void setLocalInterface(Builder builder, IpNetworkAddress ipAddress) {
		Optional.ofNullable(ipAddress.getAddress()).ifPresent(builder::localInterface);
		Optional.ofNullable(ipAddress.getMask()).ifPresent(builder::localInterfaceMask);
	}
	
	private static void setManagementInterface(Builder builder, IpNetworkAddress ipAddress) {
		Optional.ofNullable(ipAddress.getAddress()).ifPresent(builder::managementInterface);
		Optional.ofNullable(ipAddress.getMask()).ifPresent(builder::managementInterfaceMask);
	}
	
	private static void setRouterInterface(Builder builder, IpNetworkAddress ipAddress) {
		Optional.ofNullable(ipAddress.getAddress()).ifPresent(builder::routerInterface);
		Optional.ofNullable(ipAddress.getMask()).ifPresent(builder::routerInterfaceMask);
	}
	
	private static void setDcnInterface(Builder builder, IpNetworkAddress ipAddress) {
		Optional.ofNullable(ipAddress.getAddress()).ifPresent(builder::dcnInterface);
		Optional.ofNullable(ipAddress.getMask()).ifPresent(builder::dcnInterfaceMask);
	}
	
	private static void setNeSwVersion(Builder builder, ApsDetails aps) {
		Optional.ofNullable(aps.getMemoryBank())
        .map(MemoryBankDetails::getApsDescription)
        .map(ApsDescription::getVersion)
        .ifPresent(builder::neSwVersion);
	}
}
