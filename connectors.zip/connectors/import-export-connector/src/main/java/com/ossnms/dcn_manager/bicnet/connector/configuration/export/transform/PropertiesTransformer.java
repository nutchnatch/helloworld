package com.ossnms.dcn_manager.bicnet.connector.configuration.export.transform;

import com.ossnms.bicnet.bcb.model.common.Property;

import java.util.Collection;
import java.util.Map;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.bicnet.connector.import_export.migration.Util.mappingEntry;

final class PropertiesTransformer {

    private PropertiesTransformer() {
    }

    public static Property[] properties(Map<String, String> ... bags) {
        return Stream.of(bags)
                .map(Map::entrySet).flatMap(Collection::stream)
                .map(mappingEntry(PropertiesTransformer::property))
                .distinct()
                .toArray(Property[]::new);
    }

    private static Property property(String name, String value) {
        Property property = new Property();
        property.setName(name);
        property.setValue(value);
        return property;
    }
}
