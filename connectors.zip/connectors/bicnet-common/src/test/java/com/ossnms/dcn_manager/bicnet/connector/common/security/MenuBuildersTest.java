package com.ossnms.dcn_manager.bicnet.connector.common.security;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.ossnms.dcn_manager.bicnet.connector.common.security.Action;
import com.ossnms.dcn_manager.bicnet.connector.common.security.Menu;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecurableNames;

public class MenuBuildersTest {

    @Test
    public void testFullMenuBuild() {
        final String identifier = Menu.menu(SecurableNames.ADMINISTRATION).subMenu(SecurableNames.DCN).action("GO").toString();
        assertThat(identifier, is("Administration->DCN->GO"));
    }

    @Test
    public void testActionBuild() {
        final String identifier = Action.action("blah").toString();
        assertThat(identifier, is("blah"));
    }
}
