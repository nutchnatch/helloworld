package com.ossnms.dcn_manager.bicnet.connector.common.interfaces;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.IGenericContainerFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;

import java.util.Collection;

/**
 * Temporary access point to what will become part of the public facade
 * in what concerns DCN Container management.
 */
public interface ContainerService extends IGenericContainerFacade {

    /**
     * Delete zero or more DCN containers in one swoop.
     *
     * @param sessionContext BiCNet session context.
     * @param genericContainerIds All {@link IGenericContainerId} instances representing
     *  DCN Containers to delete.
     * @throws BcbException
     */
    void deleteGenericContainers(ISessionContext sessionContext, Iterable<IGenericContainerId> genericContainerIds)
            throws BcbException;

    Collection<INeGenericContainerAssignment> getNeContainerAssignments(ISessionContext sessionContext) throws BcbException;

    Collection<ISystemGenericContainerAssignment> getSystemContainerAssignments(ISessionContext sessionContext) throws BcbException;

    /**
     * Change parent of containers to the new one
     */
    void moveToContainer(ISessionContext sessionContext, Collection<IGenericContainerId> containers, IGenericContainerId containerId) throws BcbException;
}
