package com.ossnms.dcn_manager.bicnet.connector.common.entities;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import java.io.Serializable;

/**
 * Aggregator of all NE information. Used to reduce the number of requests
 * issued by the GUI client.
 */
public final class FullNeData implements Serializable {

    private static final long serialVersionUID = 5366088605858037614L;

    private final INE ne;
    private final NeInfo info;
    private final ScsSynchronizationState synchronizationState;
    private final NeStatusInfo neStatusInfo;

    /**
     * Creates a new object.
     * @param ne Public BCB NE data.
     * @param info Private NE information.
     * @param synchronizationState SCS synchronization state.
     */
    public FullNeData(@Nonnull INE ne, @Nonnull NeInfo info, @Nonnull ScsSynchronizationState synchronizationState) {
        this.ne = ne;
        this.info = info;
        this.synchronizationState = synchronizationState;
        this.neStatusInfo = new NeStatusInfo(this);
    }

    /**
     * @return Public BCB NE data.
     */
    public INE getNe() {
        return ne;
    }

    /**
     * @return Private NE information.
     */
    public NeInfo getInfo() {
        return info;
    }

    /**
     * @return the Ne Name.
     */
    public String getIdName() {
        return ne.getIdName();
    }

    /**
     * @return Latest known SCS synchronization state.
     */
    public ScsSynchronizationState getSynchronizationState() {
        return synchronizationState;
    }

    /**
     * @return Latest NE Status Info.
     */
    public NeStatusInfo getNeStatusInfo() {
        return neStatusInfo;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("ne", ne)
                .append("info", info)
                .append("synchronizationState", synchronizationState)
                .append("neStatusInfo", neStatusInfo)
                .toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) { return true; }
        if (o == null || getClass() != o.getClass()) { return false; }

        FullNeData that = (FullNeData) o;

        return ne.equals(that.ne);

    }

    @Override
    public int hashCode() {
        return ne.hashCode();
    }
}
