package com.ossnms.dcn_manager.bicnet.connector.common.entities;

import com.google.common.base.Objects;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.Immutable;
import java.io.Serializable;
import java.util.Optional;

/**
 * Contains the latest synchronization state data received from SCS regarding a specific NE.
 */
@Immutable
public final class ScsSynchronizationState implements Serializable {

    private static final long serialVersionUID = 2516245151386703478L;

    private final int neId;
    private final ScsSyncState state;
    private final String info;

    /**
     * Creates a new instance.
     *  @param neId NE identifier.
     * @param syncState SCS synchronization state against the NE.
     * @param syncInfo Human-readable information about the current SCS synchronization state.
     */
    public ScsSynchronizationState(int neId, @Nonnull ScsSyncState syncState, @Nullable String syncInfo) {
        this.neId = neId;
        state = syncState;
        info = syncInfo;
    }

    /**
     * Creates a new instance.
     *
     * @param neId NE identifier.
     * @param syncState SCS synchronization state against the NE.
     */
    public ScsSynchronizationState(int neId, @Nonnull ScsSyncState syncState) {
        this(neId, syncState, null);
    }

    /**
     * @return SCS synchronization state against the NE.
     */
    public ScsSyncState getState() {
        return state;
    }

    /**
     * @return Human-readable information about the current SCS synchronization state.
     */
    public Optional<String> getInfo() {
        return Optional.ofNullable(info);
    }

    /**
     * @return NE identifier.
     */
    public int getNeId() {
        return neId;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        return Objects.hashCode(neId, state, info);
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || getClass() != obj.getClass()) {
            return false;
        }
        final ScsSynchronizationState rhs = (ScsSynchronizationState) obj;
        return neId == rhs.neId && Objects.equal(state, rhs.state) && Objects.equal(info, rhs.info);
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("neId", neId)
                .append("state", state)
                .append("info", info)
                .toString();
    }

}
