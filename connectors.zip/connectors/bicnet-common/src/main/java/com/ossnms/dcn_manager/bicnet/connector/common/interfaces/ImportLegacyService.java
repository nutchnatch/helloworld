package com.ossnms.dcn_manager.bicnet.connector.common.interfaces;

import com.ossnms.bicnet.bcb.facade.IFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.dcn.configuration.jaxb.legacy.Channel;
import com.ossnms.bicnet.dcn.configuration.jaxb.legacy.Mediator;
import com.ossnms.bicnet.dcn.configuration.jaxb.legacy.NE;

import java.util.Collection;

/**
 * Facade for import operations from legacy EM/NE (v15.x)
 */
public interface ImportLegacyService extends IFacade {

    /**
     * Create new mediators
     *
     * @param sessionContext user session
     * @param mediators      collection of new mediators
     * @throws BcbException
     */
    Collection<String> importMediators(ISessionContext sessionContext, Collection<Mediator> mediators) throws BcbException;

    /**
     * Create new channels
     *
     * @param sessionContext user session
     * @param mediator       parent mediator
     * @param ems            collection of new channels
     * @throws BcbException
     */
    Collection<String> importChannels(ISessionContext sessionContext, Mediator mediator, Collection<Channel> ems) throws BcbException;

    /**
     * Create new network elements
     *
     * @param sessionContext user session
     * @param nes            collection of new NEs
     * @param importSftp
     * @throws BcbException
     */
    Collection<String> importNEs(ISessionContext sessionContext, Collection<NE> nes, boolean importSftp) throws BcbException;
}
