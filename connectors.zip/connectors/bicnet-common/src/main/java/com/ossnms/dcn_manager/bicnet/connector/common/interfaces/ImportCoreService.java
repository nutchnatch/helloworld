package com.ossnms.dcn_manager.bicnet.connector.common.interfaces;

import com.ossnms.bicnet.bcb.facade.IFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.Channel;
import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.Mediator;
import com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct.NE;

import java.util.Collection;

public interface ImportCoreService extends IFacade {

    /**
     * Imports configuration related to channel
     *
     * @param mediator   parent mediator of channel
     * @param nes        child network elements of channel
     * @param importSftp flag whether to import SFTP/FTP setting of NE
     * @return collection of messages for user (warnings, errors)
     */
    Collection<String> importChannel(ISessionContext context, Mediator mediator, Channel channel, Collection<NE> nes, boolean importSftp);
}
