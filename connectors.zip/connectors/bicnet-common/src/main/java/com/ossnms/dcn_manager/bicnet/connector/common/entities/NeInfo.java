package com.ossnms.dcn_manager.bicnet.connector.common.entities;

import com.google.common.base.Objects;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.Optional;
import java.util.Set;

/**
 * Contains GUI NE Information.
 */
public final class NeInfo extends GuiInfo<NeInfo> implements Serializable {

    private static final long serialVersionUID = -7371921266572393502L;

    private final int neId;
    private Set<NeRouteInfo> neRouteInfo;
    private String additionalTypeInfo;

    @Override
    protected NeInfo self() {
        return this;
    }

    /**
     * @param neId Identifier of the NE that owns this information.
     */
    public NeInfo(int neId) {
        this.neId = neId;
    }

    public int getNeId() {
        return neId;
    }

    /**
     * Empty Set represents: All routes for that NE was unconfigured.
     * Empty Optional represents: No changes on Routes for that NE.
     */
    public Optional<Set<NeRouteInfo>> getNeRouteInfo() {
        return Optional.ofNullable(neRouteInfo);
    }

    public NeInfo setNeRouteInfo(Set<NeRouteInfo> neRouteInfo) {
        this.neRouteInfo = neRouteInfo;
        return this;
    }

    public Optional<String> getAdditionalTypeInfo() {
        return Optional.ofNullable(additionalTypeInfo);
    }

    public NeInfo setAdditionalTypeInfo(String additionalTypeInfo) {
        this.additionalTypeInfo = additionalTypeInfo;
        return this;
    }
    
    @Override
    public int hashCode() {
        return Objects.hashCode(neId, super.hashCode());
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || getClass() != obj.getClass()) {
            return false;
        }
        final NeInfo rhs = (NeInfo) obj;
        return neId == rhs.neId &&
                super.equals(obj);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("neId", neId)
                .append("additionalTypeInfo", additionalTypeInfo)
                .appendSuper(super.toString())
                .toString();
    }
}
