package com.ossnms.dcn_manager.bicnet.connector.common.interfaces;

import com.ossnms.bicnet.bcb.facade.IFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;

import java.util.Map;

/**
 * Contract for "private" facades providing Configuration services.
 */
public interface ConfigurationService extends IFacade {

    /**
     * @return The Global Settings in Map format.
     */
    Map<String, String> getGlobalSettings(ISessionContext context) throws BcbException;

    /**
     * Updates the Global Settings.
     */
    void updateGlobalSettings(ISessionContext context, Map<String, String> updatedProperties) throws BcbException;

    boolean isNodeManagerSelected();
}
