package com.ossnms.dcn_manager.bicnet.connector.common.servicelocator;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.servicelocator.AbstractPropertyBasedCFServiceLocator;
import com.ossnms.bicnet.util.ApplicationProperties;
import com.ossnms.bicnet.util.UnexpectedException;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ChannelService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ConfigurationService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ContainerService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.DomainService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ImportCoreService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ImportCtService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ImportExportService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ImportLegacyService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.MediatorService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.NeService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.SystemContainerService;

import javax.annotation.Nonnull;

/**
 * This approach follow the BICNET Service Locator architecture, and will be used at client and server side.
 * <p>
 * The instance of this class will be cached in class {@link com.ossnms.bicnet.servicelocator.BiCNetServiceLocator},
 * through method  #BiCNetServiceLocator.registerServiceLocator(BiCNetComponentType,AbstractCFServiceLocator). *
 * After registration of the EM/NE Service locator, the public facade will be available to be used for others BICNET
 * components, through BiCNetServiceLocator class.
 */
public final class ServiceLocator extends AbstractPropertyBasedCFServiceLocator {

    private static final ServiceLocator INSTANCE = new ServiceLocator();

    private ServiceLocator() {
        super();
    }

    public static ServiceLocator getInstance() {
        return INSTANCE;
    }

    /**
     * {@inheritDoc}
     */
    @Override public void init() throws UnexpectedException {
        final ApplicationProperties serviceProperties = ConfigurationFiles.getServicesProperties();
        final ApplicationProperties callStyleProperties = ConfigurationFiles.getCallStyleProperties();

        initFromProperties(serviceProperties, callStyleProperties);
    }

    /**
     * {@inheritDoc}
     */
    @Override @Nonnull public Class<?> loadClass(@Nonnull final String clazz) throws ClassNotFoundException {
        return Class.forName(clazz);
    }

    /**
     * Returns the appropriate BCB public Facade implementation for CF EM-NE-Object Management (an instance implementing
     * IEMObjectMgrFacade) as defined by the call style set-up for a call into this CF from the calling
     * BiCNetComponentType/CF.
     *
     * @param callingCF the BiCNetComponentType instance representing the calling CF
     * @return an object implementing IEMObjectMgrFacade: the BCB public Facade interface of CF EM-NE-Object Management
     * @throws UnexpectedException in case of an unexpected (technical or configuration) error
     **/
    @Nonnull public IEMObjectMgrFacade getPublicService(@Nonnull final BiCNetComponentType callingCF)
            throws UnexpectedException {
        return (IEMObjectMgrFacade) getPublicFacade(callingCF);
    }

    /**
     * @return The NE Service Facade
     * @throws UnexpectedException
     */
    @Nonnull public NeService getNeService() throws UnexpectedException {
        return getPrivateFacade(NeService.class);
    }

    /**
     * @return The CONTAINER Service Facade
     * @throws UnexpectedException "I know nothing!"
     */
    @Nonnull public ContainerService getContainerService() throws UnexpectedException {
        return getPrivateFacade(ContainerService.class);
    }

    /**
     * @return The SYSTEM CONTAINER Service Facade
     * @throws UnexpectedException "I know nothing!"
     */
    @Nonnull public SystemContainerService getSystemContainerService() throws UnexpectedException {
        return getPrivateFacade(SystemContainerService.class);
    }

    /**
     * @return The MEDIATOR Service Facade
     * @throws UnexpectedException
     */
    @Nonnull public MediatorService getMediatorService() throws UnexpectedException {
        return getPrivateFacade(MediatorService.class);
    }

    /**
     * @return The EM Service Facade
     * @throws UnexpectedException
     */
    @Nonnull public ChannelService getChannelService() throws UnexpectedException {
        return getPrivateFacade(ChannelService.class);
    }

    /**
     * @return The Domain Service Facade
     * @throws UnexpectedException
     */
    @Nonnull public DomainService getDomainService() throws UnexpectedException {
        return getPrivateFacade(DomainService.class);
    }

    /**
     * @return The Configuration Service Facade
     * @throws UnexpectedException
     */
    @Nonnull public ConfigurationService getConfigurationService() throws UnexpectedException {
        return getPrivateFacade(ConfigurationService.class);
    }

    /**
     * @return The Import/Export Service Facade
     */
    @Nonnull public ImportExportService getImportExportService() {
        return getPrivateFacade(ImportExportService.class);
    }

    /**
     * @return The Import Legacy Service Facade
     */
    @Nonnull public ImportLegacyService getImportLegacyService() {
        return getPrivateFacade(ImportLegacyService.class);
    }

    /**
     * @return The Import CT Service Facade
     */
    @Nonnull public ImportCtService getImportCtService() {
        return getPrivateFacade(ImportCtService.class);
    }

    /**
     * @return The Import Core Service Facade
     */
    @Nonnull public ImportCoreService getImportCoreService() {
        return getPrivateFacade(ImportCoreService.class);
    }
}
