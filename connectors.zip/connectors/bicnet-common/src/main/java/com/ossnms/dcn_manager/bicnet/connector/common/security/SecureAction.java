package com.ossnms.dcn_manager.bicnet.connector.common.security;

import static com.ossnms.dcn_manager.bicnet.connector.common.security.Action.action;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.Menu.menu;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecurableNames.ACCESS_CONTROL;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecurableNames.ADMINISTRATION;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecurableNames.DCN;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecurableNames.EXPORT_CONFIGURATION;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecurableNames.FILE;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecurableNames.IMPORT_CONFIGURATION;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecurableNames.IMPORT_FROM_CORE;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecurableNames.MAINTENANCE_MODE;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecurableNames.NETWORK;
import static com.ossnms.dcn_manager.bicnet.connector.common.security.SecurableNames.OBJECT_CONTEXT_MENU;

/**
 * Lists all securable action identifiers in EM/NE.
 * Also known in TNMS as secure operations.
 *
 * NOTE: This permissions Constants are strongly coupled with data base script
 * dcn-manager_permissions.sql on Server Connector Storage.
 */
public enum SecureAction {

    // Main items in client frame menu "Configuration" :
    OPEN_MANAGEMENT_VIEW_SAN(menu(NETWORK).subMenu(DCN).action("Management")),
    OPEN_STATE_STATISTIC_SAN(menu(NETWORK).subMenu(DCN).action("State Summary")),
    OPEN_FIND_DIALOG_SAN(menu(NETWORK).subMenu(DCN).action("Find")),
    OPEN_DCN_LIST_VIEW_SAN(menu(NETWORK).subMenu(DCN).action("Table View")),

    // Main items in client frame menu "Administration" :
    OP_SCHEDULE_IMPORT_CONF_SAN(menu(ADMINISTRATION).subMenu(IMPORT_FROM_CORE).action("Scheduled DCN")),

    // Main items in client frame menu "View" :

    // Menu items in NE-Object-Management-Window :
    // Toolbar :
    OP_PROPERTIES_SERVER_SAN(menu(NETWORK).subMenu(DCN).action("Server Properties")),
    OP_PROPERTIES_MEDIATOR_SAN(menu(NETWORK).subMenu(DCN).action("Mediator Properties")),
    OP_PROPERTIES_CHANNEL_SAN(menu(NETWORK).subMenu(DCN).action("EM Properties")),
    OP_PROPERTIES_CONTAINER_SAN(menu(NETWORK).subMenu(DCN).action("Container Properties")),
    OP_PROPERTIES_NE_SAN(menu(NETWORK).subMenu(DCN).action("Properties")),
    OP_NEW_MEDIATOR_SAN(menu(NETWORK).subMenu(DCN).action("New (Mediator)")),
    OP_NEW_CHANNEL_SAN(menu(NETWORK).subMenu(DCN).action("New (EM)")),
    OP_NEW_NE_SAN(menu(NETWORK).subMenu(DCN).action("New (NE)")),
    OP_NEW_AS_SAN(menu(NETWORK).subMenu(DCN).action("New (AS)")),
    OP_NEW_NE_CONTAINER_SAN(menu(NETWORK).subMenu(DCN).action("New (NE Container)")),
    OP_NEW_SYSTEM_CONTAINER_SAN(menu(NETWORK).subMenu(DCN).action("New (SC)")),
    OP_DELETE_SAN(menu(NETWORK).subMenu(DCN).action("Delete")),
    OP_DUPLICATE_SAN(menu(NETWORK).subMenu(DCN).action("Duplicate")),

    OP_CUT_SAN(menu(NETWORK).subMenu(DCN).action("Cut (and Paste)")),
    OP_RESCAN_SAN(menu(NETWORK).subMenu(DCN).action("Rescan")),
    OP_COPY_NE_NAME_TO_ID_NAME_SAN(menu(NETWORK).subMenu(DCN).action("Copy NE Name into ID Name")),
    OP_RESYNCHRONIZE_DATA_SAN(menu(NETWORK).subMenu(DCN).action("Resynchronize Data")),

    DRAG_NE_SAN(menu(NETWORK).subMenu(DCN).action("Drag NE")),
    MOVE_NE_SAN(menu(NETWORK).subMenu(DCN).action("Move NE")),
    MOVE_CHANNEL_SAN(menu(NETWORK).subMenu(DCN).action("Move Channel")),
    MOVE_SYSTEM_SAN(menu(NETWORK).subMenu(DCN).action("Move System Container")),
    MOVE_CONTAINER_SAN(menu(NETWORK).subMenu(DCN).action("Move NE Container")),

    // Open Properties - Read only
    OP_PROPERTIES_MEDIATOR_RO_SAN(menu(NETWORK).subMenu(DCN).action("Mediator Properties - Read Only")),
    OP_PROPERTIES_CHANNEL_RO_SAN(menu(NETWORK).subMenu(DCN).action("EM Properties - Read Only")),
    OP_PROPERTIES_CONTAINER_RO_SAN(menu(NETWORK).subMenu(DCN).action("Container Properties - Read Only")),
    OP_PROPERTIES_NE_RO_SAN(menu(NETWORK).subMenu(DCN).action("Properties - Read Only")),

    // Menu items in the object context menu offered by EM/NE-Object-Management-Plugin :
    OP_MOGCM_CONNECT_SAN(menu(OBJECT_CONTEXT_MENU).subMenu(ACCESS_CONTROL).action("Connect")),
    OP_MOGCM_DISCONN_SAN(menu(OBJECT_CONTEXT_MENU).subMenu(ACCESS_CONTROL).action("Disconnect")),
    OP_MOGCM_REQ_WRITE_ACC_SAN(menu(OBJECT_CONTEXT_MENU).subMenu(ACCESS_CONTROL).action("Request Write Access")),
    OP_MOGCM_REL_WRITE_ACC_SAN(menu(OBJECT_CONTEXT_MENU).subMenu(ACCESS_CONTROL).action("Release Write Access")),
    OP_MOGCM_ENF_WRITE_ACC_SAN(menu(OBJECT_CONTEXT_MENU).subMenu(ACCESS_CONTROL).action("Enforce Write Access")),
    OP_MOGCM_RESYNC_DATA_SAN(menu(OBJECT_CONTEXT_MENU).action("Resyncronize Data")),

    // Ne context for Maintenance State
    OP_MOGCM_MAINTENANCE_SAN(menu(OBJECT_CONTEXT_MENU).subMenu(MAINTENANCE_MODE).action("Maintenance")),
    OP_MOGCM_OPERATIONAL_SAN(menu(OBJECT_CONTEXT_MENU).subMenu(MAINTENANCE_MODE).action("Operation")),

    // NE context for NE state
    OP_MOGCM_ACTIVE_SAN(menu(OBJECT_CONTEXT_MENU).action("Set to Active Mode")),

    // Tool bar button Find NE on Map :
    OPEN_FIND_NE_ON_MAP_SAN(menu(NETWORK).subMenu(DCN).action("Find")),

    // Import/Export
    IMPORT_EM_NE_OBJECTS_SAN(menu(FILE).subMenu(IMPORT_CONFIGURATION).action("EM/NE Objects")),
    EXPORT_EM_NE_OBJECTS_SAN(menu(FILE).subMenu(EXPORT_CONFIGURATION).action("EM/NE Objects")),

    // server side public facade operations
    SERVER_PUBLIC_INIT(action("initialize EM/NE")),
    SERVER_PUBLIC_SHUTDOWN(action("initialize EM/NE")),
    SERVER_PUBLIC_ADD_USAGE(action("add usage")),
    SERVER_PUBLIC_RELEASE_USAGE(action("release usage")),
    SERVER_PUBLIC_DO_SYNCH(action("start synchronization")),
    SERVER_PUBLIC_MODIFY_NE(action("modify network element settings")),
    SERVER_PUBLIC_MODIFY_CHANNEL(action("modify element manager settings")),

    // DHCP Domain Context menu
    OP_MOGCM_DOMAIN_DISCOVERY_PERMITTED(menu(OBJECT_CONTEXT_MENU).action("Discovery Permitted")),

    //EM / NE Object (De)Activation
    OP_ACTIVATE_MEDIATORS_SAN(menu(NETWORK).subMenu(DCN).action("Activate Mediators")),
    OP_DEACTIVATE_MEDIATORS_SAN(menu(NETWORK).subMenu(DCN).action("Deactivate Mediators")),
    OP_ACTIVATE_CHANNELS_SAN(menu(NETWORK).subMenu(DCN).action("Activate EMs")),
    OP_DEACTIVATE_CHANNELS_SAN(menu(NETWORK).subMenu(DCN).action("Deactivate EMs")),
    OP_ACTIVATE_NES_SAN(menu(NETWORK).subMenu(DCN).action("Activate NEs")),
    OP_DEACTIVATE_NES_SAN(menu(NETWORK).subMenu(DCN).action("Deactivate NEs")),
    OP_ACTIVATE_ALL_NES_SAN(menu(NETWORK).subMenu(DCN).action("Activate All NEs in EM")),
    OP_DEACTIVATE_ALL_NES_SAN(menu(NETWORK).subMenu(DCN).action("Deactivate All NEs in EM")),

    EMNE_EXPORT_SETTINGS(menu(FILE).subMenu(EXPORT_CONFIGURATION).action("Settings")),
    SYSTEM_PREFERENCES(action("DCN-Manager->System Preferences"));


    private final String identifier;

    SecureAction(Item menuOrAction) {
        identifier = menuOrAction.toString();
    }

    public String getIdentifier() {
        return identifier;
    }

    /**
     * @return An array with all action identifiers in this enum.
     */
    public static String[] getIdentifiers() {
        final SecureAction[] values = values();
        final String[] identifiers = new String[values.length];
        for (int i = 0; i < values.length; ++i) {
            identifiers[i] = values[i].getIdentifier();
        }
        return identifiers;
    }
}
