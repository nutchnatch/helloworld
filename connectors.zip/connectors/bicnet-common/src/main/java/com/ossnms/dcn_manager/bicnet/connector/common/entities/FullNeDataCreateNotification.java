package com.ossnms.dcn_manager.bicnet.connector.common.entities;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IVisitable;
import com.ossnms.bicnet.bcb.model.platform.Notification;

import javax.annotation.Nonnull;
import java.util.Date;
import java.util.Objects;

/**
 * BCB notification class used to forward NE Information updates to listeners.
 */
public final class FullNeDataCreateNotification extends Notification implements IVisitable {

    private static final long serialVersionUID = -6441909422073635210L;

    /**
     * Implementation of our specific visitor pattern.
     */
    public interface IVisitor extends com.ossnms.bicnet.bcb.model.IVisitor
    {
        /**
         * Allows specific processing of FullNeDataCreateNotification instances.
         * @param arg {@link FullNeDataCreateNotification} object to be processed.
         * @return Whether the Notification has been processed.
         */
        boolean onFullNeDataCreation(FullNeDataCreateNotification arg) throws BcbException;
    }

    /**
     * Performs specific processing of FullNeDataCreateNotification instances
     * by delegating to the given visitor interface.
     */
    @Override
    public boolean dispatch(com.ossnms.bicnet.bcb.model.IVisitor visitor) throws BcbException
    {
        return visitor instanceof IVisitor
                ? ((IVisitor)visitor).onFullNeDataCreation(this)
                : super.dispatch(visitor);
    }

    private final FullNeData fullNeData;

    public FullNeDataCreateNotification(@Nonnull FullNeData fullNeData) {
        super(new Date());
        this.fullNeData = fullNeData;
    }

    /**
     * Obtains the BCB identifier of the Channel associated with the information in transit.
     * @return An instance of a Channel identifier.
     */
    @Override
    public IManagedObjectId affectedMO() {
        return new NEIdItem(fullNeData.getInfo().getNeId());
    }

    /**
     * @return The Channel information instance contained in this notification.
     */
    public FullNeData getFullNeData() {
        return fullNeData;
    }

    @Override
    public String toString() {
        return "<" + com.ossnms.bicnet.bcb.model.platform.Notification.toString(this)
                + "fullNeData=" + fullNeData.toString() + ">";
    }

    /* (non-Javadoc)
         * @see com.ossnms.bicnet.bcb.model.platform.Notification#equals(java.lang.Object)
         */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final FullNeDataCreateNotification rhs = (FullNeDataCreateNotification) obj;
        return Objects.equals(getTimestamp(), rhs.getTimestamp()) &&
                fullNeData.equals(rhs.fullNeData);
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.model.platform.Notification#hashCode()
     */
    @Override
    public int hashCode() {
        return Objects.hash(getTimestamp(), fullNeData);
    }
}
