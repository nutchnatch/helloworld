package com.ossnms.dcn_manager.bicnet.connector.common.entities;

import com.google.common.base.Objects;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;

/**
 * Contains GUI Channel Information.
 */
public final class ChannelInfo extends GuiInfo<ChannelInfo> implements Serializable {

    private static final long serialVersionUID = -3952935487369527932L;

    private final int channelId;

    /**
     * @param channelId Identifier of the Channel that owns this information.
     */
    public ChannelInfo(int channelId) {
        this.channelId = channelId;
    }

    @Override
    protected ChannelInfo self() {
        return this;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(channelId, super.hashCode());
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || getClass() != obj.getClass()) {
            return false;
        }
        final ChannelInfo rhs = (ChannelInfo) obj;
        return channelId == rhs.channelId &&
                super.equals(obj);
    }

    /**
     * @return The Channel identifier.
     */
    public int getChannelId() {
        return channelId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("channelId", channelId)
                .appendSuper(super.toString())
                .toString();
    }

}
