package com.ossnms.dcn_manager.bicnet.connector.common.entities;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IVisitable;
import com.ossnms.bicnet.bcb.model.platform.Notification;

import javax.annotation.Nonnull;
import java.util.Date;
import java.util.Objects;

/**
 * BCB notification class used to forward Mediator Information updates to listeners.
 */
public final class MediatorInfoNotification extends Notification implements IVisitable {

    private static final long serialVersionUID = -4254899218649777587L;

    /**
     * Implementation of our specific visitor pattern.
     */
    public interface IVisitor extends com.ossnms.bicnet.bcb.model.IVisitor
    {
        /**
         * Allows specific processing of MediatorInfoNotification instances.
         * @param arg {@link MediatorInfoNotification} object to be processed.
         * @return Whether the Notification has been processed.
         */
        boolean onMediatorInfoNotification(MediatorInfoNotification arg) throws BcbException;
    }

    /**
     * Performs specific processing of MediatorInfoNotification instances
     * by delegating to the given visitor interface.
     */
    @Override
    public boolean dispatch(com.ossnms.bicnet.bcb.model.IVisitor visitor) throws BcbException
    {
        return visitor instanceof IVisitor
                ? ((IVisitor)visitor).onMediatorInfoNotification(this)
                : super.dispatch(visitor);
    }

    private final MediatorInfo mediatorInfo;

    public MediatorInfoNotification(@Nonnull MediatorInfo mediatorInfo) {
        super(new Date());
        this.mediatorInfo = mediatorInfo;
    }

    @Override
    public String toString() {
        return "<" + com.ossnms.bicnet.bcb.model.platform.Notification.toString(this)
                + "mediatorInfo=" + mediatorInfo.toString() + ">";
    }

    /**
     * Obtains the BCB identifier of the Mediator associated with the information in transit.
     * @return An instance of a Mediator identifier.
     */
    @Override
    public IManagedObjectId affectedMO() {
        return new MediatorIdItem(mediatorInfo.getMediatorId());
    }

    /**
     * @return The Mediator information instance contained in this notification.
     */
    public MediatorInfo getMediatorInfo() {
        return mediatorInfo;
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.model.platform.Notification#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final MediatorInfoNotification rhs = (MediatorInfoNotification) obj;
        return Objects.equals(getTimestamp(), rhs.getTimestamp()) &&
               mediatorInfo.equals(rhs.mediatorInfo);
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.bcb.model.platform.Notification#hashCode()
     */
    @Override
    public int hashCode() {
        return Objects.hash(getTimestamp(), mediatorInfo);
    }
}
