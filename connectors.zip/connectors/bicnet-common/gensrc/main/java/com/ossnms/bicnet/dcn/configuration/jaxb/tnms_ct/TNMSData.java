
package com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="NetServers" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="NetServer" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/tnms_ct}NetServer" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="DcnChannels" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="DcnChannel" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/tnms_ct}Channel" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="NEs" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="NE" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/tnms_ct}NE" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *       &lt;attribute name="Version" use="required" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/tnms_ct}Version" />
 *       &lt;attribute name="PWCHECK" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "netServers",
    "dcnChannels",
    "nEs"
})
@XmlRootElement(name = "TNMSData")
public class TNMSData
    implements Serializable
{

    private final static long serialVersionUID = -1L;
    @XmlElement(name = "NetServers")
    protected TNMSData.NetServers netServers;
    @XmlElement(name = "DcnChannels")
    protected TNMSData.DcnChannels dcnChannels;
    @XmlElement(name = "NEs")
    protected TNMSData.NEs nEs;
    @XmlAttribute(name = "Version", required = true)
    protected String version;
    @XmlAttribute(name = "PWCHECK")
    protected String pwcheck;

    /**
     * Gets the value of the netServers property.
     * 
     * @return
     *     possible object is
     *     {@link TNMSData.NetServers }
     *     
     */
    public TNMSData.NetServers getNetServers() {
        return netServers;
    }

    /**
     * Sets the value of the netServers property.
     * 
     * @param value
     *     allowed object is
     *     {@link TNMSData.NetServers }
     *     
     */
    public void setNetServers(TNMSData.NetServers value) {
        this.netServers = value;
    }

    /**
     * Gets the value of the dcnChannels property.
     * 
     * @return
     *     possible object is
     *     {@link TNMSData.DcnChannels }
     *     
     */
    public TNMSData.DcnChannels getDcnChannels() {
        return dcnChannels;
    }

    /**
     * Sets the value of the dcnChannels property.
     * 
     * @param value
     *     allowed object is
     *     {@link TNMSData.DcnChannels }
     *     
     */
    public void setDcnChannels(TNMSData.DcnChannels value) {
        this.dcnChannels = value;
    }

    /**
     * Gets the value of the nEs property.
     * 
     * @return
     *     possible object is
     *     {@link TNMSData.NEs }
     *     
     */
    public TNMSData.NEs getNEs() {
        return nEs;
    }

    /**
     * Sets the value of the nEs property.
     * 
     * @param value
     *     allowed object is
     *     {@link TNMSData.NEs }
     *     
     */
    public void setNEs(TNMSData.NEs value) {
        this.nEs = value;
    }

    /**
     * Gets the value of the version property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersion() {
        return version;
    }

    /**
     * Sets the value of the version property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersion(String value) {
        this.version = value;
    }

    /**
     * Gets the value of the pwcheck property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPWCHECK() {
        return pwcheck;
    }

    /**
     * Sets the value of the pwcheck property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPWCHECK(String value) {
        this.pwcheck = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="DcnChannel" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/tnms_ct}Channel" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "dcnChannel"
    })
    public static class DcnChannels
        implements Serializable
    {

        private final static long serialVersionUID = -1L;
        @XmlElement(name = "DcnChannel")
        protected List<Channel> dcnChannel;

        /**
         * Gets the value of the dcnChannel property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the dcnChannel property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDcnChannel().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Channel }
         * 
         * 
         */
        public List<Channel> getDcnChannel() {
            if (dcnChannel == null) {
                dcnChannel = new ArrayList<Channel>();
            }
            return this.dcnChannel;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="NE" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/tnms_ct}NE" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "ne"
    })
    public static class NEs
        implements Serializable
    {

        private final static long serialVersionUID = -1L;
        @XmlElement(name = "NE")
        protected List<NE> ne;

        /**
         * Gets the value of the ne property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the ne property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getNE().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link NE }
         * 
         * 
         */
        public List<NE> getNE() {
            if (ne == null) {
                ne = new ArrayList<NE>();
            }
            return this.ne;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="NetServer" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/tnms_ct}NetServer" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "netServer"
    })
    public static class NetServers
        implements Serializable
    {

        private final static long serialVersionUID = -1L;
        @XmlElement(name = "NetServer")
        protected List<NetServer> netServer;

        /**
         * Gets the value of the netServer property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the netServer property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getNetServer().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link NetServer }
         * 
         * 
         */
        public List<NetServer> getNetServer() {
            if (netServer == null) {
                netServer = new ArrayList<NetServer>();
            }
            return this.netServer;
        }

    }

}
