
package com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NetworkElements complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NetworkElements">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="NE" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager}NetworkElement" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NetworkElements", propOrder = {
    "ne"
})
public class NetworkElements
    implements Serializable
{

    private final static long serialVersionUID = -1L;
    @XmlElement(name = "NE", required = true)
    protected List<NetworkElement> ne;

    /**
     * Gets the value of the ne property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ne property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNE().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NetworkElement }
     * 
     * 
     */
    public List<NetworkElement> getNE() {
        if (ne == null) {
            ne = new ArrayList<NetworkElement>();
        }
        return this.ne;
    }

}
