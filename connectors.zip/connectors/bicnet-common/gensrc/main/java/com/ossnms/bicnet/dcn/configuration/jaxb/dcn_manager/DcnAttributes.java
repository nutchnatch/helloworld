
package com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DcnAttributes complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DcnAttributes">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="EonType" type="{http://www.w3.org/2001/XMLSchema}string" default="" />
 *       &lt;attribute name="LocalInterface" type="{http://www.w3.org/2001/XMLSchema}string" default="" />
 *       &lt;attribute name="LocalInterfaceMask" type="{http://www.w3.org/2001/XMLSchema}string" default="" />
 *       &lt;attribute name="ManagementInterface" type="{http://www.w3.org/2001/XMLSchema}string" default="" />
 *       &lt;attribute name="ManagementInterfaceMask" type="{http://www.w3.org/2001/XMLSchema}string" default="" />
 *       &lt;attribute name="RouterInterface" type="{http://www.w3.org/2001/XMLSchema}string" default="" />
 *       &lt;attribute name="RouterInterfaceMask" type="{http://www.w3.org/2001/XMLSchema}string" default="" />
 *       &lt;attribute name="DcnInterface" type="{http://www.w3.org/2001/XMLSchema}string" default="" />
 *       &lt;attribute name="DcnInterfaceMask" type="{http://www.w3.org/2001/XMLSchema}string" default="" />
 *       &lt;attribute name="Gateway" type="{http://www.w3.org/2001/XMLSchema}string" default="" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DcnAttributes")
public class DcnAttributes
    implements Serializable
{

    private final static long serialVersionUID = -1L;
    @XmlAttribute(name = "EonType")
    protected String eonType;
    @XmlAttribute(name = "LocalInterface")
    protected String localInterface;
    @XmlAttribute(name = "LocalInterfaceMask")
    protected String localInterfaceMask;
    @XmlAttribute(name = "ManagementInterface")
    protected String managementInterface;
    @XmlAttribute(name = "ManagementInterfaceMask")
    protected String managementInterfaceMask;
    @XmlAttribute(name = "RouterInterface")
    protected String routerInterface;
    @XmlAttribute(name = "RouterInterfaceMask")
    protected String routerInterfaceMask;
    @XmlAttribute(name = "DcnInterface")
    protected String dcnInterface;
    @XmlAttribute(name = "DcnInterfaceMask")
    protected String dcnInterfaceMask;
    @XmlAttribute(name = "Gateway")
    protected String gateway;

    /**
     * Gets the value of the eonType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEonType() {
        if (eonType == null) {
            return "";
        } else {
            return eonType;
        }
    }

    /**
     * Sets the value of the eonType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEonType(String value) {
        this.eonType = value;
    }

    /**
     * Gets the value of the localInterface property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalInterface() {
        if (localInterface == null) {
            return "";
        } else {
            return localInterface;
        }
    }

    /**
     * Sets the value of the localInterface property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalInterface(String value) {
        this.localInterface = value;
    }

    /**
     * Gets the value of the localInterfaceMask property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalInterfaceMask() {
        if (localInterfaceMask == null) {
            return "";
        } else {
            return localInterfaceMask;
        }
    }

    /**
     * Sets the value of the localInterfaceMask property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalInterfaceMask(String value) {
        this.localInterfaceMask = value;
    }

    /**
     * Gets the value of the managementInterface property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getManagementInterface() {
        if (managementInterface == null) {
            return "";
        } else {
            return managementInterface;
        }
    }

    /**
     * Sets the value of the managementInterface property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setManagementInterface(String value) {
        this.managementInterface = value;
    }

    /**
     * Gets the value of the managementInterfaceMask property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getManagementInterfaceMask() {
        if (managementInterfaceMask == null) {
            return "";
        } else {
            return managementInterfaceMask;
        }
    }

    /**
     * Sets the value of the managementInterfaceMask property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setManagementInterfaceMask(String value) {
        this.managementInterfaceMask = value;
    }

    /**
     * Gets the value of the routerInterface property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRouterInterface() {
        if (routerInterface == null) {
            return "";
        } else {
            return routerInterface;
        }
    }

    /**
     * Sets the value of the routerInterface property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRouterInterface(String value) {
        this.routerInterface = value;
    }

    /**
     * Gets the value of the routerInterfaceMask property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRouterInterfaceMask() {
        if (routerInterfaceMask == null) {
            return "";
        } else {
            return routerInterfaceMask;
        }
    }

    /**
     * Sets the value of the routerInterfaceMask property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRouterInterfaceMask(String value) {
        this.routerInterfaceMask = value;
    }

    /**
     * Gets the value of the dcnInterface property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDcnInterface() {
        if (dcnInterface == null) {
            return "";
        } else {
            return dcnInterface;
        }
    }

    /**
     * Sets the value of the dcnInterface property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDcnInterface(String value) {
        this.dcnInterface = value;
    }

    /**
     * Gets the value of the dcnInterfaceMask property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDcnInterfaceMask() {
        if (dcnInterfaceMask == null) {
            return "";
        } else {
            return dcnInterfaceMask;
        }
    }

    /**
     * Sets the value of the dcnInterfaceMask property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDcnInterfaceMask(String value) {
        this.dcnInterfaceMask = value;
    }

    /**
     * Gets the value of the gateway property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGateway() {
        if (gateway == null) {
            return "";
        } else {
            return gateway;
        }
    }

    /**
     * Sets the value of the gateway property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGateway(String value) {
        this.gateway = value;
    }

}
