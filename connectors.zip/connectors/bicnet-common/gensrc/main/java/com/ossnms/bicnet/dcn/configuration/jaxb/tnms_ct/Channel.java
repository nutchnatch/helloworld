
package com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Channel complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Channel">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DcnChannelType">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;attribute name="GUID" use="required" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/tnms_ct}GUID" />
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ParentID" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/tnms_ct}EID"/>
 *         &lt;element name="PropContainer" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/tnms_ct}PropContainer"/>
 *       &lt;/sequence>
 *       &lt;attribute name="IDName" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="COREId" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Channel", propOrder = {
    "dcnChannelType",
    "parentID",
    "propContainer"
})
public class Channel
    implements Serializable
{

    private final static long serialVersionUID = -1L;
    @XmlElement(name = "DcnChannelType", required = true)
    protected Channel.DcnChannelType dcnChannelType;
    @XmlElement(name = "ParentID", required = true)
    protected EID parentID;
    @XmlElement(name = "PropContainer", required = true)
    protected PropContainer propContainer;
    @XmlAttribute(name = "IDName", required = true)
    protected String idName;
    @XmlAttribute(name = "COREId")
    protected String coreId;

    /**
     * Gets the value of the dcnChannelType property.
     * 
     * @return
     *     possible object is
     *     {@link Channel.DcnChannelType }
     *     
     */
    public Channel.DcnChannelType getDcnChannelType() {
        return dcnChannelType;
    }

    /**
     * Sets the value of the dcnChannelType property.
     * 
     * @param value
     *     allowed object is
     *     {@link Channel.DcnChannelType }
     *     
     */
    public void setDcnChannelType(Channel.DcnChannelType value) {
        this.dcnChannelType = value;
    }

    /**
     * Gets the value of the parentID property.
     * 
     * @return
     *     possible object is
     *     {@link EID }
     *     
     */
    public EID getParentID() {
        return parentID;
    }

    /**
     * Sets the value of the parentID property.
     * 
     * @param value
     *     allowed object is
     *     {@link EID }
     *     
     */
    public void setParentID(EID value) {
        this.parentID = value;
    }

    /**
     * Gets the value of the propContainer property.
     * 
     * @return
     *     possible object is
     *     {@link PropContainer }
     *     
     */
    public PropContainer getPropContainer() {
        return propContainer;
    }

    /**
     * Sets the value of the propContainer property.
     * 
     * @param value
     *     allowed object is
     *     {@link PropContainer }
     *     
     */
    public void setPropContainer(PropContainer value) {
        this.propContainer = value;
    }

    /**
     * Gets the value of the idName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIDName() {
        return idName;
    }

    /**
     * Sets the value of the idName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIDName(String value) {
        this.idName = value;
    }

    /**
     * Gets the value of the coreId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOREId() {
        return coreId;
    }

    /**
     * Sets the value of the coreId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOREId(String value) {
        this.coreId = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;attribute name="GUID" use="required" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/tnms_ct}GUID" />
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class DcnChannelType
        implements Serializable
    {

        private final static long serialVersionUID = -1L;
        @XmlAttribute(name = "GUID", required = true)
        protected String guid;

        /**
         * Gets the value of the guid property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getGUID() {
            return guid;
        }

        /**
         * Sets the value of the guid property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setGUID(String value) {
            this.guid = value;
        }

    }

}
