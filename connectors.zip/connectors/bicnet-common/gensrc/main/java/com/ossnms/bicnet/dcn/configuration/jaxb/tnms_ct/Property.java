
package com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;


/**
 * <p>Java class for Property complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Property">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;attribute name="Name" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="Cypher" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="Type" use="required">
 *         &lt;simpleType>
 *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;enumeration value="VT_EMPTY"/>
 *             &lt;enumeration value="VT_BSTR"/>
 *             &lt;enumeration value="VT_BOOL"/>
 *             &lt;enumeration value="VT_UI1"/>
 *             &lt;enumeration value="VT_UI2"/>
 *             &lt;enumeration value="VT_UI4"/>
 *             &lt;enumeration value="VT_I1"/>
 *             &lt;enumeration value="VT_I2"/>
 *             &lt;enumeration value="VT_I4"/>
 *             &lt;enumeration value="VT_R4"/>
 *             &lt;enumeration value="VT_R8"/>
 *           &lt;/restriction>
 *         &lt;/simpleType>
 *       &lt;/attribute>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Property", propOrder = {
    "content"
})
public class Property
    implements Serializable
{

    private final static long serialVersionUID = -1L;
    @XmlValue
    protected String content;
    @XmlAttribute(name = "Name", required = true)
    protected String name;
    @XmlAttribute(name = "Cypher")
    protected String cypher;
    @XmlAttribute(name = "Type", required = true)
    protected String type;

    /**
     * Gets the value of the content property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContent() {
        return content;
    }

    /**
     * Sets the value of the content property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContent(String value) {
        this.content = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the cypher property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCypher() {
        return cypher;
    }

    /**
     * Sets the value of the cypher property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCypher(String value) {
        this.cypher = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

}
