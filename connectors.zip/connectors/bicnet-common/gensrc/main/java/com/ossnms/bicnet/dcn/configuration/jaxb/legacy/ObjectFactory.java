
package com.ossnms.bicnet.dcn.configuration.jaxb.legacy;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ossnms.bicnet.dcn.configuration.jaxb.legacy package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ossnms.bicnet.dcn.configuration.jaxb.legacy
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link BiCNetData }
     * 
     */
    public BiCNetData createBiCNetData() {
        return new BiCNetData();
    }

    /**
     * Create an instance of {@link Properties }
     * 
     */
    public Properties createProperties() {
        return new Properties();
    }

    /**
     * Create an instance of {@link NE }
     * 
     */
    public NE createNE() {
        return new NE();
    }

    /**
     * Create an instance of {@link AS }
     * 
     */
    public AS createAS() {
        return new AS();
    }

    /**
     * Create an instance of {@link BiCNetData.EMs }
     * 
     */
    public BiCNetData.EMs createBiCNetDataEMs() {
        return new BiCNetData.EMs();
    }

    /**
     * Create an instance of {@link BiCNetData.ASs }
     * 
     */
    public BiCNetData.ASs createBiCNetDataASs() {
        return new BiCNetData.ASs();
    }

    /**
     * Create an instance of {@link BiCNetData.NEs }
     * 
     */
    public BiCNetData.NEs createBiCNetDataNEs() {
        return new BiCNetData.NEs();
    }

    /**
     * Create an instance of {@link Channel }
     * 
     */
    public Channel createChannel() {
        return new Channel();
    }

    /**
     * Create an instance of {@link Mediator }
     * 
     */
    public Mediator createMediator() {
        return new Mediator();
    }

    /**
     * Create an instance of {@link Properties.Property }
     * 
     */
    public Properties.Property createPropertiesProperty() {
        return new Properties.Property();
    }

    /**
     * Create an instance of {@link NE.NeTypeTaxonomy }
     * 
     */
    public NE.NeTypeTaxonomy createNENeTypeTaxonomy() {
        return new NE.NeTypeTaxonomy();
    }

    /**
     * Create an instance of {@link NE.ParentAS }
     * 
     */
    public NE.ParentAS createNEParentAS() {
        return new NE.ParentAS();
    }

    /**
     * Create an instance of {@link AS.NEList }
     * 
     */
    public AS.NEList createASNEList() {
        return new AS.NEList();
    }

}
