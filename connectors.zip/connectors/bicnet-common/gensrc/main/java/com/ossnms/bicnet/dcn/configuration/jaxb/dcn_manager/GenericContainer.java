
package com.ossnms.bicnet.dcn.configuration.jaxb.dcn_manager;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GenericContainer complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GenericContainer">
 *   &lt;complexContent>
 *     &lt;extension base="{http://ossnms.com/bicnet/dcn/configuration/jaxb/dcn_manager}Container">
 *       &lt;attribute name="ParentContainer" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GenericContainer")
public class GenericContainer
    extends Container
    implements Serializable
{

    private final static long serialVersionUID = -1L;
    @XmlAttribute(name = "ParentContainer")
    protected String parentContainer;

    /**
     * Gets the value of the parentContainer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentContainer() {
        return parentContainer;
    }

    /**
     * Sets the value of the parentContainer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentContainer(String value) {
        this.parentContainer = value;
    }

}
