
package com.ossnms.bicnet.dcn.configuration.jaxb.tnms_ct;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NetServer complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NetServer">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ParentID" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/tnms_ct}EID" minOccurs="0"/>
 *         &lt;element name="PropContainer" type="{http://ossnms.com/bicnet/dcn/configuration/jaxb/tnms_ct}PropContainer"/>
 *       &lt;/sequence>
 *       &lt;attribute name="IDName" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="COREId" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NetServer", propOrder = {
    "parentID",
    "propContainer"
})
public class NetServer
    implements Serializable
{

    private final static long serialVersionUID = -1L;
    @XmlElement(name = "ParentID")
    protected EID parentID;
    @XmlElement(name = "PropContainer", required = true)
    protected PropContainer propContainer;
    @XmlAttribute(name = "IDName", required = true)
    protected String idName;
    @XmlAttribute(name = "COREId")
    protected String coreId;

    /**
     * Gets the value of the parentID property.
     * 
     * @return
     *     possible object is
     *     {@link EID }
     *     
     */
    public EID getParentID() {
        return parentID;
    }

    /**
     * Sets the value of the parentID property.
     * 
     * @param value
     *     allowed object is
     *     {@link EID }
     *     
     */
    public void setParentID(EID value) {
        this.parentID = value;
    }

    /**
     * Gets the value of the propContainer property.
     * 
     * @return
     *     possible object is
     *     {@link PropContainer }
     *     
     */
    public PropContainer getPropContainer() {
        return propContainer;
    }

    /**
     * Sets the value of the propContainer property.
     * 
     * @param value
     *     allowed object is
     *     {@link PropContainer }
     *     
     */
    public void setPropContainer(PropContainer value) {
        this.propContainer = value;
    }

    /**
     * Gets the value of the idName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIDName() {
        return idName;
    }

    /**
     * Sets the value of the idName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIDName(String value) {
        this.idName = value;
    }

    /**
     * Gets the value of the coreId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOREId() {
        return coreId;
    }

    /**
     * Sets the value of the coreId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOREId(String value) {
        this.coreId = value;
    }

}
