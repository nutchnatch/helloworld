package com.ossnms.dcn_manager.bicnet.connector.security;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import javax.annotation.Nullable;

import org.aspectj.lang.Aspects;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import com.ossnms.bicnet.bcb.facade.security.ISecureServerSession;
import com.ossnms.bicnet.bcb.facade.security.ISecurityMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.security.AuthorizationFailedException;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import com.ossnms.dcn_manager.bicnet.connector.factory.BicnetServiceManager;
import com.ossnms.dcn_manager.bicnet.connector.interfaces.BicnetServiceManagerFactory;

public class SecureActionValidationTest {

    private ISecureServerSession serverSession;
    private ISecurityMgrFacade securityManager;
    private BicnetServiceManagerFactory serviceManager;

    private ISessionContext context;

    private  ArgumentCaptor<IManagedObjectId[]> idCaptor;


    @Before
    public void setUp() throws Exception {
        context = mock(ISessionContext.class);
        serverSession = mock(ISecureServerSession.class);
        securityManager = mock(ISecurityMgrFacade.class);
        serviceManager = mock(BicnetServiceManager.class);

        idCaptor = ArgumentCaptor.forClass(IManagedObjectId[].class);

        final SecureActionValidation validation = Aspects.aspectOf(SecureActionValidation.class);
        validation.setServiceManager(serviceManager);

        when(securityManager.getServerSession(context)).thenReturn(serverSession);
        when(serviceManager.getSecurityManagerFacade()).thenReturn(securityManager);
    }

    @Securable(SecureAction.DRAG_NE_SAN)
    public void securedTestCallWithoutObjects(ISessionContext context) throws BcbException {

    }

    @Securable(SecureAction.DRAG_NE_SAN)
    public void securedTestCallWithSingleBaseObject(ISessionContext context, @SecuredObject IManagedObjectId id) throws BcbException {

    }

    @Securable(SecureAction.DRAG_NE_SAN) // also test multiple annotations in one parameter
    public void securedTestCallWithSingleDerivedObject(ISessionContext context, @Nullable @SecuredObject IEMId id, int dummyParam) throws BcbException {

    }

    @Securable(SecureAction.DRAG_NE_SAN)
    public void securedTestCallWithArrayOfBaseObjects(ISessionContext context, @SecuredObject IManagedObjectId[] id) throws BcbException {

    }

    @Securable(SecureAction.OP_ACTIVATE_CHANNELS_SAN)
    public void securedTestCallWithArrayOfDerivedObjects(ISessionContext context, @SecuredObject IEMId[] id) throws BcbException {

    }

    @Test
    public void testAllowedWithArrayOfDerivedObjects() throws BcbException {
        final IEMId[] id = new IEMId[0];

        when(serverSession.checkOperationPermission(eq(SecureAction.OP_ACTIVATE_CHANNELS_SAN.getIdentifier()))).thenReturn(true);

        securedTestCallWithArrayOfDerivedObjects(context, id);

        verify(serverSession).checkOperationPermission(eq(SecureAction.OP_ACTIVATE_CHANNELS_SAN.getIdentifier()));
    }

    @Test
    public void testAllowedWithArrayOfBaseObjects() throws BcbException {
        final IManagedObjectId[] id = new IManagedObjectId[0];

        when(serverSession.checkOperationPermission(
                eq(SecureAction.DRAG_NE_SAN.getIdentifier()),
                any(IManagedObjectId[].class)))
            .thenReturn(id);

        securedTestCallWithArrayOfBaseObjects(context, id);

        verify(serverSession).checkOperationPermission(eq(SecureAction.DRAG_NE_SAN.getIdentifier()), idCaptor.capture());
        assertThat(idCaptor.getValue(), is(id));
    }

    @Test
    public void testAllowedWithSingleDerivedObject() throws BcbException {
        final IEMId id = mock(IEMId.class);

        when(serverSession.checkOperationPermission(
                eq(SecureAction.DRAG_NE_SAN.getIdentifier()),
                any(IManagedObjectId[].class)))
            .thenReturn(new IManagedObjectId[] { id });

        securedTestCallWithSingleDerivedObject(context, id, 42);

        verify(serverSession).checkOperationPermission(eq(SecureAction.DRAG_NE_SAN.getIdentifier()), idCaptor.capture());
        assertThat(idCaptor.getValue()[0], is((IManagedObjectId) id));
    }

    @Test
    public void testAllowedWithSingleBaseObject() throws BcbException {
        final IManagedObjectId id = mock(IManagedObjectId.class);

        when(serverSession.checkOperationPermission(
                eq(SecureAction.DRAG_NE_SAN.getIdentifier()),
                any(IManagedObjectId[].class)))
            .thenReturn(new IManagedObjectId[] { id });

        securedTestCallWithSingleBaseObject(context, id);

        verify(serverSession).checkOperationPermission(eq(SecureAction.DRAG_NE_SAN.getIdentifier()), idCaptor.capture());
        assertThat(idCaptor.getValue()[0], is(id));
    }

    @Test(expected=AuthorizationFailedException.class)
    public void testDeniedByNullResultWithSingleBaseObject() throws BcbException {
        final IManagedObjectId id = mock(IManagedObjectId.class);

        when(serverSession.checkOperationPermission(
                eq(SecureAction.DRAG_NE_SAN.getIdentifier()),
                any(IManagedObjectId[].class)))
            .thenReturn(null);

        securedTestCallWithSingleBaseObject(context, id);
    }

    @Test(expected=AuthorizationFailedException.class)
    public void testDeniedByDifferentResultCountWithSingleBaseObject() throws BcbException {
        final IManagedObjectId id = mock(IManagedObjectId.class);

        when(serverSession.checkOperationPermission(
                eq(SecureAction.DRAG_NE_SAN.getIdentifier()),
                any(IManagedObjectId[].class)))
            .thenReturn(new IManagedObjectId[0]);

        securedTestCallWithSingleBaseObject(context, id);
    }

    @Test
    public void testAllowedWithoutObjects() throws BcbException {
        when(serverSession.checkOperationPermission(SecureAction.DRAG_NE_SAN.getIdentifier())).thenReturn(true);
        securedTestCallWithoutObjects(context);
    }

    @Test(expected=AuthorizationFailedException.class)
    public void testDeniedWithoutObjects() throws BcbException {
        when(serverSession.checkOperationPermission(SecureAction.DRAG_NE_SAN.getIdentifier())).thenReturn(false);
        securedTestCallWithoutObjects(context);
    }

    @Test(expected=AuthorizationFailedException.class)
    public void testErrorRetrievingServerSession() throws BcbException {
        when(securityManager.getServerSession(any(ISessionContext.class))).thenThrow(new BcbSecurityException());
        securedTestCallWithoutObjects(context);
    }

}
