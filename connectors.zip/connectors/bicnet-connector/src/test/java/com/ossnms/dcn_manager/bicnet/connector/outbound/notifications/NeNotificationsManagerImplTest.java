package com.ossnms.dcn_manager.bicnet.connector.outbound.notifications;

import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.composables.outbound.SecurityManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeConnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeConnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeDisconnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeDisconnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializingEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeShuttingDownEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeStartingUpEvent;
import com.ossnms.dcn_manager.core.events.ne.NeGatewayRoutesChangedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeShuttingDownEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeStartingUpEvent;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeGatewayRoutesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;
import java.util.NoSuchElementException;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb.describeEachStates;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class NeNotificationsManagerImplTest {

    private static final int NE_ID = 32;
    private static final String NE_NAME = "ne name";

    @Mock private StaticConfiguration configuration;
    @Mock private SecurityManager securityManager;
    @Mock private NeEntityRepository neRepository;
    @Mock private NeGatewayRoutesRepository routesRepository;
    @Mock private LoggerManagerImpl loggerManager;
    @Mock private BicnetCallContext systemContext;
    @Mock private IBiCNetMessageDispatcher messageDispatcher;
    @Mock private NePhysicalConnectionRepository nePhysicalConnectionRepository;
    @Mock private NeInfoRepository neInfoRepository;

    @InjectMocks private NeNotificationsManagerImpl neNotifications;

    private NeType type;
    @Mock private Types<NeType> types;
    private NeEntity neEntity;

    @Before
    public void setUp() throws RepositoryException {
        type = MockFactory.mockNeType();
        when(type.getDefaultIcon()).thenReturn("");
        when(types.get(anyString())).thenReturn(type);
        when(configuration.getNeTypes()).thenReturn(types);

        when(neRepository.queryNeName(NE_ID)).thenReturn(Optional.of(NE_NAME));
        when(neRepository.getNeGatewayRoutesRepository()).thenReturn(routesRepository);
        when(neRepository.getNeInfoRepository()).thenReturn(neInfoRepository);

        when(neInfoRepository.query(anyInt())).thenReturn(Optional.empty());

        neEntity = buildNeEntity();
    }

    private NeEntity buildNeEntity() {
        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(99, type);
        createDescriptor.getPreferences().setName("name");
        createDescriptor.getInfo().setIconId(Optional.of("neIconId"));
        return NeEntity.build(NE_ID, 1, createDescriptor);
    }

    @Test
    public void notificationLog_withRepoError_doesNotLog() throws RepositoryException {
        when(neRepository.queryNeName(NE_ID)).thenThrow(new RepositoryException());

        neNotifications.notifyChanges(new NeConnectedEvent(NE_ID));

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), anyBoolean());
        verify(loggerManager, never()).createSystemEventLog(any(BicnetCallContext.class), any(LoggerItem.class));
    }

    @Test
    public void notificationLog_withoutChannelName_doesNotLog() throws RepositoryException {
        when(neRepository.queryNeName(NE_ID)).thenReturn(Optional.empty());

        neNotifications.notifyChanges(new NeConnectedEvent(NE_ID));

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), anyBoolean());
        verify(loggerManager, never()).createSystemEventLog(any(BicnetCallContext.class), any(LoggerItem.class));
    }

    @Test
    public void notifyConnected() {
        neNotifications.notifyChanges(new NeConnectedEvent(NE_ID));

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), anyBoolean());
        verify(loggerManager).createSystemEventLog(systemContext,
            new LoggerItemNe(NE_NAME,
                    tr(Message.NE_STATE_CHANGED, describeEachStates(ActualActivationState.CONNECTED)) + " ",
                    NE_ID,
                    MessageSeverity.INFO));
    }

    @Test
    public void notifyConnecting() {
        neNotifications.notifyChanges(new NeConnectingEvent(NE_ID));

        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
        verify(loggerManager).createSystemEventLog(systemContext,
            new LoggerItemNe(NE_NAME,
                    tr(Message.NE_STATE_CHANGED, describeEachStates(ActualActivationState.CONNECTING)) + " ",
                    NE_ID,
                    MessageSeverity.INFO));
    }

    @Test
    public void notifyDisconnecting() {
        neNotifications.notifyChanges(new NeDisconnectingEvent(NE_ID));

        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
        verify(loggerManager).createSystemEventLog(systemContext,
            new LoggerItemNe(NE_NAME,
                    tr(Message.NE_STATE_CHANGED, describeEachStates(ActualActivationState.DISCONNECTING)) + " ",
                    NE_ID,
                    MessageSeverity.INFO));
    }

    @Test
    public void notifyDisconnected() {
        neNotifications.notifyChanges(new NeDisconnectedEvent(NE_ID));

        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
        verify(loggerManager).createSystemEventLog(systemContext,
            new LoggerItemNe(NE_NAME,
                    tr(Message.NE_STATE_CHANGED, describeEachStates(ActualActivationState.DISCONNECTED)) + " ",
                    NE_ID,
                    MessageSeverity.INFO));
    }

    @Test
    public void notifyInitialized() {
        neNotifications.notifyChanges(new NeInitializedEvent(NE_ID));

        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
        verify(loggerManager).createSystemEventLog(systemContext,
            new LoggerItemNe(NE_NAME,
                    tr(Message.NE_STATE_CHANGED, describeEachStates(ActualActivationState.INITIALIZED)) + " ",
                    NE_ID,
                    MessageSeverity.INFO));
    }

    @Test
    public void notifyInitializing() {
        neNotifications.notifyChanges(new NeInitializingEvent(NE_ID));

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), anyBoolean());
        verify(loggerManager).createSystemEventLog(systemContext,
            new LoggerItemNe(NE_NAME,
                    tr(Message.NE_STATE_CHANGED, describeEachStates(ActualActivationState.INITIALIZING)) + " ",
                    NE_ID,
                    MessageSeverity.INFO));
    }

    @Test
    public void notifyFailed() {
        neNotifications.notifyChanges(new NeActivationFailedEvent(NE_ID, "additional info"));

        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
        verify(loggerManager).createSystemEventLog(systemContext,
            new LoggerItemNe(NE_NAME,
                    tr(Message.NE_STATE_CHANGED, describeEachStates(ActualActivationState.FAILED)) + " additional info",
                    NE_ID,
                    MessageSeverity.INFO));
    }

    @Test
    public void notifyFailed_withoutMessage() {
        neNotifications.notifyChanges(new NeActivationFailedEvent(NE_ID));

        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
        verify(loggerManager).createSystemEventLog(systemContext,
            new LoggerItemNe(NE_NAME,
                    tr(Message.NE_STATE_CHANGED, describeEachStates(ActualActivationState.FAILED)) + " ",
                    NE_ID,
                    MessageSeverity.INFO));
    }

    @Test
    public void testNotifyDelete() {

        neNotifications.notifyDelete(neEntity);

        verify(securityManager).deleteNe(neEntity);
        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
    }

    @Test
    public void testNotifyCreate() throws RepositoryException {

        when(routesRepository.queryRoutes(NE_ID)).thenReturn(Collections.emptyList());
        when(nePhysicalConnectionRepository.queryAll(NE_ID)).thenReturn(Collections.emptyList());

        neNotifications.notifyCreate(neEntity);

        verify(securityManager).createNe(neEntity);
        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
    }

    @Test
    public void testNotifyUserPreferencesChanges() {

        final NeUserPreferencesMutationDescriptor descriptor = new NeUserPreferencesMutationDescriptor(neEntity.getPreferences());
        final NeUserPreferencesData preferences = descriptor.apply();

        neNotifications.notifyChanges(descriptor);

        verify(securityManager).updateNe(preferences);
        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
    }

    @Test(expected=NoSuchElementException.class)
    public void testNotifyUserPreferencesChanges_notApplied_throws() {

        final NeUserPreferencesMutationDescriptor descriptor = new NeUserPreferencesMutationDescriptor(neEntity.getPreferences());

        neNotifications.notifyChanges(descriptor);
    }

    @Test
    public void testNotifyInstanceCreate() throws Exception {

        final NePhysicalConnectionData conn = new NePhysicalConnectionBuilder()
                .build(1, 2, 3, 0);

        neNotifications.notifyCreateInstance(conn);

        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
    }

    @Test
    public void testNotifyInstanceDelete() throws Exception {

        neNotifications.notifyDeleteInstance(1, 2);

        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
    }

    @Test
    public void testNotifyStartingUp_activeInstance() throws Exception {

        neNotifications.notifyChanges(new NeStartingUpEvent(NE_ID,
                new PhysicalNeStartingUpEvent(2, NE_ID, true)));

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
    }

    @Test
    public void testNotifyStartingUp_inactiveInstance_sendsToClientOnly() throws Exception {

        neNotifications.notifyChanges(new NeStartingUpEvent(NE_ID,
                new PhysicalNeStartingUpEvent(2, NE_ID, false)));

        verify(messageDispatcher, never()).sendToSource(any(IBiCNetMessage.class), anyBoolean());
        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
    }

    @Test
    public void testNotifyShuttingDown_activeInstance() throws Exception {

        neNotifications.notifyChanges(new NeShuttingDownEvent(NE_ID,
                new PhysicalNeShuttingDownEvent(2, NE_ID, true)));

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
    }

    @Test
    public void testNotifyShuttingDown_inactiveInstance_sendsToClientOnly() throws Exception {

        neNotifications.notifyChanges(new NeShuttingDownEvent(NE_ID,
                new PhysicalNeShuttingDownEvent(2, NE_ID, false)));

        verify(messageDispatcher, never()).sendToSource(any(IBiCNetMessage.class), anyBoolean());
        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
    }

    @Test
    public void testNotifyNeGatewayRoutesChangedEvent() throws Exception {
        neNotifications.notifyChanges(new NeGatewayRoutesChangedEvent(NE_ID).setGatewayRoutes(
                Optional.of(Collections.emptyList())));
        verify(messageDispatcher, times(1)).sendToClient(isA(IBiCNetMessage.class));
    }

    @Test
    public void testNotifyNeGatewayRoutesChangedEvent_without_changes() throws Exception {
        neNotifications.notifyChanges(new NeGatewayRoutesChangedEvent(NE_ID).setGatewayRoutes(
                Optional.empty()));
        verify(messageDispatcher, never()).sendToClient(isA(IBiCNetMessage.class));
    }
}
