package com.ossnms.dcn_manager.bicnet.connector.outbound.connection;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.elementMgmt.*;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.platform.IMediationFacadeManager;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.bicnet.bcb.model.elementMgmt.*;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEMarkable;
import com.ossnms.bicnet.bcb.model.platform.PlatformException;
import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.messaging.ne.NeEventSource;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.*;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeConnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializingEvent;
import com.ossnms.dcn_manager.core.events.ne.NeSynchronizationEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.*;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.jaxb.netype.Attribute;
import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeGatewayRoutesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.*;
import static org.hamcrest.Matchers.hasItemInArray;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.*;

@SuppressWarnings("unchecked")
public class NeConnectionManagerImplTest {

    private static final int VERSION = 1;
    private static final int CHANNEL_ID = 43;
    private static final int CHANNEL_INSTANCE_ID = 4300;
    private static final int NE_ID = 21;
    private static final int NE_INSTANCE_ID = 2100;
    private static final int MEDIATOR_INSTANCE_ID = 76;

    private ISessionContext context;
    private IGctMgrFacade gctManager;
    private IMediationFacadeManager connectionManager;
    private NeEntityRepository neRepository;
    private NeGatewayRoutesRepository routesRepository;
    private NeInfoRepository infoRepository;
    private NeUserPreferencesRepository preferencesRepository;
    private StaticConfigurationSingleton configuration;
    private LoggerManager<BicnetCallContext> loggerManager;
    private NeEventSource neEventSource;
    private NePhysicalConnectionRepository neInstancesRepository;
    private ChannelPhysicalConnectionRepository channelInstancesRepository;

    private Types<NeType> types;

    private IElementManagerFacade elementManager;
    private ICommunicationStatePkgFacade commState;
    private IInitStatePkgFacade initFacade;

    private NeConnectionManagerImpl neConnectionManagerImpl;
    private NePhysicalConnectionData neInstance;
    private ChannelPhysicalConnectionData channelInstance;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws RepositoryException {
        neRepository = mock(NeEntityRepository.class);
        infoRepository = mock(NeInfoRepository.class);
        preferencesRepository = mock(NeUserPreferencesRepository.class);
        routesRepository = mock(NeGatewayRoutesRepository.class);
        neInstancesRepository = mock(NePhysicalConnectionRepository.class);
        channelInstancesRepository = mock(ChannelPhysicalConnectionRepository.class);

        gctManager = mock(IGctMgrFacade.class);
        connectionManager = mock(IMediationFacadeManager.class);
        configuration = mock(StaticConfigurationSingleton.class);
        loggerManager = mock(LoggerManager.class);
        context = mock(ISessionContext.class);
        types = mock(Types.class);
        neEventSource = mock(NeEventSource.class);

        elementManager = mock(IElementManagerFacade.class);
        commState = mock(ICommunicationStatePkgFacade.class);
        initFacade = mock(IInitStatePkgFacade.class);

        when(neRepository.queryNeName(NE_ID)).thenReturn(Optional.of("name"));
        when(neRepository.getNeGatewayRoutesRepository()).thenReturn(routesRepository);
        when(neRepository.getNeInfoRepository()).thenReturn(infoRepository);
        when(neRepository.getNeUserPreferencesRepository()).thenReturn(preferencesRepository);

        neInstance = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.DISCONNECTED)
                .build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION);

        channelInstance = new ChannelPhysicalConnectionBuilder()
                .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.ACTIVE)
                .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION);

        neConnectionManagerImpl = new NeConnectionManagerImpl(
                new BicnetCallContext(context), configuration,
                gctManager, connectionManager,
                neRepository, neInstancesRepository, channelInstancesRepository, loggerManager, neEventSource);

        when(preferencesRepository.query(NE_ID)).thenReturn(Optional.of(
                new NeUserPreferencesBuilder().setName("name").build(NE_ID, 1)
            ));

        final NeGatewayRouteData gatewayRouteData = new NeGatewayRouteBuilder()
                .setCost(1)
                .setPriority(1)
                .setProperty("GW_PROP", "GW_VALUE")
                .setKey("key")
                .build(NE_ID, VERSION);
        when(routesRepository.queryRoutes(anyInt())).thenReturn(Collections.singletonList(gatewayRouteData));
    }

    @Test
    public void activate_neInstanceNotFound_logOnly() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.empty());

        neConnectionManagerImpl.activate(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), isA(LoggerItemNe.class));
        verify(neEventSource, never()).push(any(PhysicalNeActivationFailedEvent.class));
        verifyZeroInteractions(connectionManager);
    }

    @Test
    public void activate_channelInstanceNotFound_error() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.empty());

        neConnectionManagerImpl.activate(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), isA(LoggerItemNe.class));
        verify(neEventSource).push(any(PhysicalNeActivationFailedEvent.class));
        verifyZeroInteractions(connectionManager);
    }

    @Test
    public void activate_neNotFound_error() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.empty());

        neConnectionManagerImpl.activate(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), isA(LoggerItemNe.class));
        verify(neEventSource).push(any(NeActivationFailedEvent.class));
    }

    @Test
    public void activate_neTypeNotFound_error() throws Exception {
        final NeEntity neEntity = buildNeEntity();

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(null); // unnecessary, just to improve readability.

        neConnectionManagerImpl.activate(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(neEventSource, never()).push(isA(PhysicalNeConnectingEvent.class));
        verify(neEventSource).push(isA(PhysicalNeActivationFailedEvent.class));
    }

    @Test
    public void activate_exceptionOnGetElementManagerFacade_error() throws Exception {
        final NeEntity neEntity = buildNeEntity();
        final NeType neType = buildType();

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(neType);
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenThrow(new PlatformException());

        neConnectionManagerImpl.activate(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(neEventSource, never()).push(isA(PhysicalNeConnectingEvent.class));
        verify(neEventSource).push(isA(PhysicalNeActivationFailedEvent.class));
    }

    @Test
    public void activate_failedToGetElementManagerFacade_error() throws Exception {
        final NeEntity neEntity = buildNeEntity();
        final NeType neType = buildType();

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(neType);
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(null);

        neConnectionManagerImpl.activate(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(neEventSource, never()).push(isA(PhysicalNeConnectingEvent.class));
        verify(neEventSource).push(isA(PhysicalNeActivationFailedEvent.class));
    }

    @Test
    public void activate_exceptionOnGetCommunicationFacade_error() throws Exception {
        final NeEntity neEntity = buildNeEntity();
        final NeType neType = buildType();

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(neType);
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.COMMUNICATION_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenThrow(new PlatformException());

        neConnectionManagerImpl.activate(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(neEventSource, never()).push(isA(PhysicalNeConnectingEvent.class));
        verify(neEventSource).push(isA(PhysicalNeActivationFailedEvent.class));
    }

    @Test
    public void activate_exceptionOnActivateProxy_error() throws Exception {
        final NeEntity neEntity = buildNeEntity();
        final NeType neType = buildType();

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(neType);
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.COMMUNICATION_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(commState);

        when(elementManager.activateNetworkElementProxy(any(ISessionContext.class), any(IElementManagerId.class), any(INE.class), any(Property[].class)))
            .thenThrow(new BcbException());

        neConnectionManagerImpl.activate(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(neEventSource, never()).push(isA(PhysicalNeConnectingEvent.class));
        verify(neEventSource).push(isA(PhysicalNeActivationFailedEvent.class));
    }

    @Test
    public void activate() throws Exception {
        final INetworkElementProxy neProxy = buildProxy();
        final NeEntity neEntity = buildNeEntity();
        final NeType neType = buildType();

        final Attribute gwAttribute = new Attribute();
        gwAttribute.setName("GW_PROP");
        when(neType.getGatewayRouteAttributes()).thenReturn(
                ImmutableMap.of("GW_PROP", gwAttribute));

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(
                Optional.of(neInstance),
                Optional.of(new NePhysicalConnectionBuilder()
                        .setActivationState(ActualActivationState.STARTUP)
                        .build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)));

        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(neType);
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.COMMUNICATION_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(commState);

        when(elementManager.activateNetworkElementProxy(any(ISessionContext.class), any(IElementManagerId.class), any(INE.class), any(Property[].class)))
            .thenReturn(neProxy);

        when(infoRepository.tryUpdate(any(NeInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        neConnectionManagerImpl.activate(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(neEventSource).push(any(NeConnectingEvent.class));

        final ArgumentCaptor<INetworkElementProxyId> idCaptor = ArgumentCaptor.forClass(INetworkElementProxyId.class);
        verify(commState).connect(eq(context), idCaptor.capture());
        assertThat(idCaptor.getValue().getNeId(), is(NE_ID));

        // check that gateway route properties have been included
        final ArgumentCaptor<Property[]> propCaptor = ArgumentCaptor.forClass(Property[].class);
        verify(elementManager).activateNetworkElementProxy(any(ISessionContext.class), any(IElementManagerId.class), any(INE.class),
                propCaptor.capture());
        assertThat(propCaptor.getValue(), hasItemInArray(new Property("GW_PROP_000", "GW_VALUE")));
    }

    @Test
    public void activate_alreadyConnected_proxyTypeMismatch_fails() throws Exception {
        final INetworkElementProxy neProxy = buildProxy();
        final NeEntity neEntity = buildNeEntity();
        final NeType neType = buildType();

        neProxy.setType("Bad Type");
        neProxy.setCommunicationState(CommunicationState.CONNECTED);
        neProxy.setInitState(InitState.INITIALIZED);

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(
                Optional.of(neInstance),
                Optional.of(new NePhysicalConnectionBuilder()
                        .setActivationState(ActualActivationState.STARTUP)
                        .build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(neType);

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);

        when(elementManager.activateNetworkElementProxy(any(ISessionContext.class), any(IElementManagerId.class), any(INE.class), any(Property[].class)))
            .thenReturn(neProxy);

        when(infoRepository.tryUpdate(any(NeInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        neConnectionManagerImpl.activate(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(neEventSource).push(isA(PhysicalNeConnectingEvent.class));
        verify(neEventSource).push(isA(PhysicalNeActivationFailedEvent.class));

        verify(commState, never()).connect(eq(context), any(INetworkElementProxyId.class));
        verify(initFacade, never()).initialize(eq(context), any(INetworkElementProxyId.class), any(InitMode.class), any(InitScope.class));
    }

    @Test
    public void activate_alreadyConnectedAndInitialized() throws Exception {
        final INetworkElementProxy neProxy = buildProxy();
        final NeEntity neEntity = buildNeEntity();
        final NeType neType = buildType();

        neProxy.setCommunicationState(CommunicationState.CONNECTED);
        neProxy.setInitState(InitState.INITIALIZED);

        when(neType.getGatewayRouteAttributes()).thenReturn(ImmutableMap.of());

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(
                Optional.of(neInstance),
                Optional.of(new NePhysicalConnectionBuilder()
                        .setActivationState(ActualActivationState.STARTUP)
                        .build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(neType);
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.COMMUNICATION_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(commState);

        when(elementManager.activateNetworkElementProxy(any(ISessionContext.class), any(IElementManagerId.class), any(INE.class), any(Property[].class)))
            .thenReturn(neProxy);

        when(infoRepository.tryUpdate(any(NeInfoMutationDescriptor.class)))
            .thenReturn(
                Optional.of(neEntity.getInfo()) // update from proxy: return something to indicate success.
            );

        neConnectionManagerImpl.activate(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(neEventSource).push(isA(PhysicalNeConnectingEvent.class));
        verify(neEventSource).push(isA(PhysicalNeConnectedEvent.class));

        verify(neEventSource, never()).push(isA(PhysicalNeInitializingEvent.class)); // these should be fired on the Connected handler
        verify(neEventSource, never()).push(isA(PhysicalNeInitializedEvent.class));

        verify(neEventSource, never()).push(isA(PhysicalNeActivationFailedEvent.class));

        verify(commState, never()).connect(eq(context), any(INetworkElementProxyId.class));
        verify(initFacade, never()).initialize(eq(context), any(INetworkElementProxyId.class), any(InitMode.class), any(InitScope.class));
    }

    @Test
    public void activate_stateChangedBetweenActivateProxyAndConnect_aborts() throws Exception {
        final INetworkElementProxy neProxy = buildProxy();
        final NeEntity neEntity = buildNeEntity();
        final NeType neType = buildType();

        neProxy.setCommunicationState(CommunicationState.CONNECTED);
        neProxy.setInitState(InitState.INITIALIZED);

        when(neType.getGatewayRouteAttributes()).thenReturn(ImmutableMap.of());

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(
                Optional.of(neInstance),
                Optional.of(new NePhysicalConnectionBuilder()
                        .setActivationState(ActualActivationState.SHUTDOWN)
                        .build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(neType);
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
                .thenReturn(elementManager);
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.COMMUNICATION_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
                .thenReturn(commState);

        when(elementManager.activateNetworkElementProxy(any(ISessionContext.class), any(IElementManagerId.class), any(INE.class), any(Property[].class)))
                .thenReturn(neProxy);

        when(infoRepository.tryUpdate(any(NeInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        neConnectionManagerImpl.activate(new Activate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verifyZeroInteractions(neEventSource);

        verify(commState, never()).connect(eq(context), any(INetworkElementProxyId.class));
        verify(initFacade, never()).initialize(eq(context), any(INetworkElementProxyId.class), any(InitMode.class), any(InitScope.class));
    }

    @Test
    public void initialize_neInstanceNotFound_logsOnly() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.empty());

        neConnectionManagerImpl.lazyInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource, never()).push(any(NeActivationFailedEvent.class));
        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), isA(LoggerItemNe.class));
    }

    @Test
    public void initialize_channelInstanceNotFound_error() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.empty());

        neConnectionManagerImpl.lazyInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource).push(any(NeActivationFailedEvent.class));
        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), isA(LoggerItemNe.class));
    }

    @Test
    public void initialize_neNotFound_error() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.empty());

        neConnectionManagerImpl.lazyInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource).push(any(NeActivationFailedEvent.class));
        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), isA(LoggerItemNe.class));
    }

    @Test
    public void initialize_typeNotFound_error() throws Exception {
        final NeEntity neEntity = buildNeEntity(ActualActivationState.CONNECTED);

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(null);

        neConnectionManagerImpl.lazyInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource).push(any(NeActivationFailedEvent.class));
        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), isA(LoggerItemNe.class));
    }

    @Test
    public void initialize_exceptionOnElementManager_error() throws Exception {
        final NeEntity neEntity = buildNeEntity(ActualActivationState.CONNECTED);
        final NeType neType = buildType();

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(neType);

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenThrow(new PlatformException());

        neConnectionManagerImpl.lazyInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource).push(isA(PhysicalNeActivationFailedEvent.class));
    }

    @Test
    public void initialize_exceptionOnInitFacade_error() throws Exception {
        final NeEntity neEntity = buildNeEntity(ActualActivationState.CONNECTED);
        final NeType neType = buildType();

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(neType);

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.INIT_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenThrow(new PlatformException());

        neConnectionManagerImpl.lazyInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource).push(isA(PhysicalNeInitializingEvent.class));
        verify(neEventSource).push(isA(PhysicalNeActivationFailedEvent.class));
    }

    @Test
    public void initialize_exceptionOnActivateProxy_error() throws Exception {
        final NeEntity neEntity = buildNeEntity(ActualActivationState.CONNECTED);
        final NeType neType = buildType();

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(neType);

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.INIT_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(initFacade);

        when(elementManager.activateNetworkElementProxy(any(ISessionContext.class), any(IElementManagerId.class), any(INE.class), any(Property[].class)))
            .thenThrow(new BcbException());

        neConnectionManagerImpl.lazyInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource).push(isA(PhysicalNeActivationFailedEvent.class));
    }

    @Test
    public void initialize_exceptionOnInitialize_error() throws Exception {
        final INetworkElementProxy neProxy = buildProxy();
        final NeEntity neEntity = buildNeEntity(ActualActivationState.CONNECTED);
        final NeType neType = buildType();

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(neType);

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.INIT_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(initFacade);

        when(elementManager.activateNetworkElementProxy(any(ISessionContext.class), any(IElementManagerId.class), any(INE.class), any(Property[].class)))
            .thenReturn(neProxy);

        doThrow(new BcbException())
            .when(initFacade).initialize(eq(context), any(INetworkElementProxyId.class), eq(InitMode.INIT_FULL), eq(InitScope.INIT_ALL));

        neConnectionManagerImpl.lazyInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource).push(isA(PhysicalNeInitializingEvent.class));
        verify(neEventSource).push(isA(PhysicalNeActivationFailedEvent.class));
    }

    @Test
    public void initialize_standardMode() throws Exception {
        final INetworkElementProxy neProxy = buildProxy();
        final NeEntity neEntity = buildNeEntity(ActualActivationState.CONNECTED);
        final NeType neType = buildType();

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(neType);

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.INIT_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(initFacade);

        when(elementManager.activateNetworkElementProxy(any(ISessionContext.class), any(IElementManagerId.class), any(INE.class), any(Property[].class)))
            .thenReturn(neProxy);

        neConnectionManagerImpl.lazyInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource).push(any(NeInitializingEvent.class));

        final ArgumentCaptor<INetworkElementProxyId> idCaptor = ArgumentCaptor.forClass(INetworkElementProxyId.class);
        verify(initFacade).initialize(eq(context), idCaptor.capture(), eq(InitMode.INIT_FULL), eq(InitScope.INIT_ALL));
        assertThat(idCaptor.getValue().getNeId(), is(NE_ID));
    }

    @Test
    public void initialize_recoverMode() throws Exception {
        final INetworkElementProxy neProxy = buildProxy();
        final NeEntity neEntity = buildNeEntity(ActualActivationState.CONNECTED);
        final NeType neType = buildType();

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(
                new NePhysicalConnectionBuilder()
                        .setActivationState(ActualActivationState.DISCONNECTED)
                        .setActivationMode(ActualActivationMode.CONNECT_RECOVER)
                        .build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
        ));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(neType);

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
                .thenReturn(elementManager);
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.INIT_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
                .thenReturn(initFacade);

        when(elementManager.activateNetworkElementProxy(any(ISessionContext.class), any(IElementManagerId.class), any(INE.class), any(Property[].class)))
                .thenReturn(neProxy);

        neConnectionManagerImpl.lazyInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource).push(any(NeInitializingEvent.class));

        final ArgumentCaptor<INetworkElementProxyId> idCaptor = ArgumentCaptor.forClass(INetworkElementProxyId.class);
        verify(initFacade).initialize(eq(context), idCaptor.capture(), eq(InitMode.INIT_DELTA), eq(InitScope.INIT_ALL));
        assertThat(idCaptor.getValue().getNeId(), is(NE_ID));
    }

    @Test
    public void initialize_alreadyInitialized() throws Exception {
        final INetworkElementProxy neProxy = buildProxy();
        final NeEntity neEntity = buildNeEntity(ActualActivationState.CONNECTED);
        final NeType neType = buildType();

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(neType);

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);

        neProxy.setCommunicationState(CommunicationState.CONNECTED);
        neProxy.setInitState(InitState.INITIALIZED);
        when(elementManager.activateNetworkElementProxy(any(ISessionContext.class), any(IElementManagerId.class), any(INE.class), any(Property[].class)))
            .thenReturn(neProxy);

        neConnectionManagerImpl.lazyInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource).push(isA(PhysicalNeInitializingEvent.class));
        verify(neEventSource).push(isA(PhysicalNeInitializedEvent.class));

        verify(initFacade, never()).initialize(eq(context), any(INetworkElementProxyId.class), any(InitMode.class), any(InitScope.class));
    }

    @Test
    public void initialize_alreadyInitializing() throws Exception {
        final INetworkElementProxy neProxy = buildProxy();
        final NeEntity neEntity = buildNeEntity(ActualActivationState.CONNECTED);
        final NeType neType = buildType();

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(neType);

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
                .thenReturn(elementManager);

        neProxy.setCommunicationState(CommunicationState.CONNECTED);
        neProxy.setInitState(InitState.INITIALIZING);
        when(elementManager.activateNetworkElementProxy(any(ISessionContext.class), any(IElementManagerId.class), any(INE.class), any(Property[].class)))
                .thenReturn(neProxy);

        neConnectionManagerImpl.lazyInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource).push(isA(PhysicalNeInitializingEvent.class));
        verify(neEventSource, never()).push(isA(PhysicalNeInitializedEvent.class));

        verify(initFacade, never()).initialize(eq(context), any(INetworkElementProxyId.class), any(InitMode.class), any(InitScope.class));
    }

    @Test
    public void alwaysInitialize_neInstanceNotFound_logOnly() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.empty());

        neConnectionManagerImpl.alwaysInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource, never()).push(isA(PhysicalNeActivationFailedEvent.class));
        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), isA(LoggerItemNe.class));
    }

    @Test
    public void alwaysInitialize_channelInstanceNotFound_error() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.empty());

        neConnectionManagerImpl.alwaysInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource).push(isA(PhysicalNeActivationFailedEvent.class));
        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), isA(LoggerItemNe.class));
    }

    @Test
    public void alwaysInitialize_neNotFound_error() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.empty());

        neConnectionManagerImpl.alwaysInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource).push(isA(PhysicalNeActivationFailedEvent.class));
    }

    @Test
    public void alwaysInitialize_exceptionOnInitFacade_error() throws Exception {
        final NeEntity neEntity = buildNeEntity(ActualActivationState.CONNECTED);

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.INIT_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenThrow(new PlatformException());

        neConnectionManagerImpl.alwaysInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource, never()).push(isA(PhysicalNeInitializingEvent.class)); // we now rely on mediation to generate these.
        verify(neEventSource).push(isA(PhysicalNeActivationFailedEvent.class));
    }

    @Test
    public void alwaysInitialize_exceptionOnInitialize_error() throws Exception {
        final NeEntity neEntity = buildNeEntity(ActualActivationState.CONNECTED);

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.INIT_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(initFacade);

        doThrow(new BcbException())
            .when(initFacade).initialize(eq(context), any(INetworkElementProxyId.class), eq(InitMode.INIT_FULL), eq(InitScope.INIT_ALL));

        neConnectionManagerImpl.alwaysInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource, never()).push(isA(PhysicalNeInitializingEvent.class)); // we now rely on mediation to generate these.
        verify(neEventSource).push(isA(PhysicalNeActivationFailedEvent.class));
    }

    @Test
    public void alwaysInitialize() throws Exception {
        final NeEntity neEntity = buildNeEntity(ActualActivationState.CONNECTED);

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.INIT_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(initFacade);

        neConnectionManagerImpl.alwaysInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource, never()).push(any(NeInitializingEvent.class)); // we now rely on mediation to generate these.

        final ArgumentCaptor<INetworkElementProxyId> idCaptor = ArgumentCaptor.forClass(INetworkElementProxyId.class);
        verify(initFacade).initialize(eq(context), idCaptor.capture(), eq(InitMode.INIT_FULL), eq(InitScope.INIT_ALL));
        assertThat(idCaptor.getValue().getNeId(), is(NE_ID));
    }

    @Test
    public void alwaysInitialize_alreadyInitialized() throws Exception {
        final INetworkElementProxy neProxy = buildProxy();
        final NeEntity neEntity = buildNeEntity(ActualActivationState.CONNECTED);

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);

        neProxy.setCommunicationState(CommunicationState.CONNECTED);
        neProxy.setInitState(InitState.INITIALIZED);
        when(elementManager.activateNetworkElementProxy(any(ISessionContext.class), eq(new ElementManagerIdItem(CHANNEL_ID)), any(INE.class), any(Property[].class)))
            .thenReturn(neProxy);

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.INIT_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(initFacade);

        neConnectionManagerImpl.alwaysInitialize(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, true));

        verify(neEventSource, never()).push(isA(PhysicalNeInitializingEvent.class)); // we now rely on mediation to generate these.

        final ArgumentCaptor<INetworkElementProxyId> idCaptor = ArgumentCaptor.forClass(INetworkElementProxyId.class);
        verify(initFacade).initialize(eq(context), idCaptor.capture(), eq(InitMode.INIT_FULL), eq(InitScope.INIT_ALL));
        assertThat(idCaptor.getValue().getNeId(), is(NE_ID));
    }

    @Test
    public void deactivate_neInstanceNotFound_logOnly() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.empty());

        neConnectionManagerImpl.deactivate(new Deactivate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(neEventSource, never()).push(isA(PhysicalNeDisconnectedEvent.class));
        verify(neEventSource, never()).push(isA(PhysicalNeActivationFailedEvent.class));
        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), any(LoggerItemNe[].class));
    }

    @Test
    public void deactivate_channelInstanceNotFound_error() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.empty());

        neConnectionManagerImpl.deactivate(new Deactivate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(neEventSource).push(isA(PhysicalNeDisconnectedEvent.class));
        verify(neEventSource, never()).push(isA(PhysicalNeActivationFailedEvent.class));
        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), any(LoggerItemNe[].class));
    }

    @Test
    public void deactivate_exceptionOnElementManager_error() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenThrow(new PlatformException());

        neConnectionManagerImpl.deactivate(new Deactivate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(neEventSource).push(isA(PhysicalNeDisconnectedEvent.class));
        verify(neEventSource, never()).push(isA(PhysicalNeActivationFailedEvent.class));
        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), any(LoggerItemNe[].class));
    }

    @Test
    public void deactivate_exceptionOnDeactivate_error() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);

        doThrow(new BcbException())
            .when(elementManager).deactivateNetworkElementProxy(eq(context), any(IElementManagerId.class), any(INEId.class));

        neConnectionManagerImpl.deactivate(new Deactivate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(neEventSource).push(isA(PhysicalNeDisconnectedEvent.class));
        verify(neEventSource, never()).push(isA(PhysicalNeActivationFailedEvent.class));
        verify(loggerManager).createSystemEventLog(any(BicnetCallContext.class), any(LoggerItemNe[].class));
    }

    @Test
    public void deactivate_channelFailed_emitsEventAndDoesNotInvokeDeactivate() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(
                new ChannelPhysicalConnectionBuilder()
                        .setActivation(com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState.FAILED)
                        .build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, VERSION)
        ));
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);

        neConnectionManagerImpl.deactivate(new Deactivate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(neEventSource).push(isA(PhysicalNeDisconnectingEvent.class));
        verify(neEventSource).push(isA(PhysicalNeDisconnectedEvent.class));

        verify(elementManager, never()).deactivateNetworkElementProxy(context, new ElementManagerIdItem(CHANNEL_ID), new NEIdItem(NE_ID));
    }

    @Test
    public void deactivate() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
                .thenReturn(elementManager);

        neConnectionManagerImpl.deactivate(new Deactivate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(neEventSource).push(isA(PhysicalNeDisconnectingEvent.class));

        verifyZeroInteractions(gctManager); // the default instance created on set up is not the active instance.
        verify(elementManager).deactivateNetworkElementProxy(context, new ElementManagerIdItem(CHANNEL_ID), new NEIdItem(NE_ID));
    }

    @Test
    public void deactivate_activeInstance_callsGct() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(
                new NePhysicalConnectionBuilder()
                        .setActive(true)
                        .setActivationState(ActualActivationState.INITIALIZED)
                        .build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
        ));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
                .thenReturn(elementManager);

        neConnectionManagerImpl.deactivate(new Deactivate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(neEventSource).push(isA(PhysicalNeDisconnectingEvent.class));

        verify(gctManager).unadviseGctSession(context, NE_ID, null);
        verify(elementManager).deactivateNetworkElementProxy(context, new ElementManagerIdItem(CHANNEL_ID), new NEIdItem(NE_ID));
    }

    @Test
    public void deactivate_activeInstance_callsGctWithError_ignoresError() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(
                new NePhysicalConnectionBuilder()
                        .setActive(true)
                        .setActivationState(ActualActivationState.INITIALIZED)
                        .build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, VERSION)
        ));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
                .thenReturn(elementManager);

        when(gctManager.unadviseGctSession(any(ISessionContext.class), anyInt(), any())).thenThrow(new BcbException());

        neConnectionManagerImpl.deactivate(new Deactivate(NE_ID, CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, NE_INSTANCE_ID, true));

        verify(neEventSource).push(isA(PhysicalNeDisconnectingEvent.class));

        verify(gctManager).unadviseGctSession(context, NE_ID, null);
        verify(elementManager).deactivateNetworkElementProxy(context, new ElementManagerIdItem(CHANNEL_ID), new NEIdItem(NE_ID));
    }

    @Test
    public void updateProperties() throws Exception {
        final INetworkElementProxyFacade facade = mock(INetworkElementProxyFacade.class);
        final NeType neType = buildType();

        final Attribute gwAttribute = new Attribute();
        gwAttribute.setName("GW_PROP");
        when(neType.getGatewayRouteAttributes()).thenReturn(
                ImmutableMap.of("GW_PROP", gwAttribute));

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(neType);

        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.NE_PROXY_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(facade);

        final NeUserPreferencesMutationDescriptor prefsMutation = new NeUserPreferencesMutationDescriptor(
                new NeUserPreferencesBuilder().setName("name").build(NE_ID, VERSION));
        prefsMutation.setName("new name");

        neConnectionManagerImpl.updateNeProperties(buildNeEntity(), neInstance, prefsMutation, Collections.emptyMap());

        final ArgumentCaptor<INEMarkable> markableCaptor = ArgumentCaptor.forClass(INEMarkable.class);
        verify(facade).updateNE(eq(context), eq(new NetworkElementProxyIdItem(NE_ID)), markableCaptor.capture(), isA(Property[].class));

        assertThat(markableCaptor.getValue().getId(), is(NE_ID));
        assertThat(markableCaptor.getValue().getIdName(), is("new name"));
    }

    @Test(expected=ConnectException.class)
    public void updateProperties_exceptionOnFacade() throws Exception {
        final INetworkElementProxyFacade facade = mock(INetworkElementProxyFacade.class);
        final NeType neType = buildType();

        final Attribute gwAttribute = new Attribute();
        gwAttribute.setName("GW_PROP");
        when(neType.getGatewayRouteAttributes()).thenReturn(
                ImmutableMap.of("GW_PROP", gwAttribute));

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(configuration.getNeTypes()).thenReturn(types);
        when(types.get(any())).thenReturn(neType);

        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.NE_PROXY_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(facade);

        doThrow(new BcbException())
            .when(facade).updateNE(any(ISessionContext.class), any(INetworkElementProxyId.class), any(INEMarkable.class), any(Property[].class));

        final NeUserPreferencesMutationDescriptor prefsMutation = new NeUserPreferencesMutationDescriptor(
                new NeUserPreferencesBuilder().setName("name").build(NE_ID, VERSION));

        neConnectionManagerImpl.updateNeProperties(buildNeEntity(), neInstance, prefsMutation, Collections.emptyMap());
    }

    @Test
    public void getCurrentSynchronizationData_withoutFacade_returnsNothing() throws Exception {
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);
        when(elementManager.activateNetworkElementProxy(any(ISessionContext.class), any(IElementManagerId.class), any(INE.class), any(Property[].class)))
            .thenReturn(buildProxy());

        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));

        when(configuration.getNeTypes()).thenReturn(types);
        final NeType type = buildType();
        when(types.get(any())).thenReturn(type);

        final Optional<NeSynchronizationMutationDescriptor> data =
                neConnectionManagerImpl.getCurrentSynchronizationData(buildNeEntity(), neInstance);
        assertThat(data, is(absent()));
    }

    @Test(expected=ConnectException.class)
    public void getCurrentSynchronizationData_proxyActivationError_throws() throws Exception {
        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);
        when(elementManager.activateNetworkElementProxy(any(ISessionContext.class), any(IElementManagerId.class), any(INE.class), any(Property[].class)))
            .thenThrow(new BcbException());

        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));

        when(configuration.getNeTypes()).thenReturn(types);
        final NeType type = buildType();
        when(types.get(any())).thenReturn(type);

        neConnectionManagerImpl.getCurrentSynchronizationData(buildNeEntity(), neInstance);
    }

    @Test
    public void getCurrentSynchronizationData_onlyAllSet() throws Exception {
        final INetworkElementProxy proxy = buildProxy();
        proxy.addOptionalFacet(new NeConfigurationCounterPkgItem(1, -1, -1));

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);
        when(elementManager.activateNetworkElementProxy(any(ISessionContext.class), any(IElementManagerId.class), any(INE.class), any(Property[].class)))
            .thenReturn(proxy);

        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));

        when(configuration.getNeTypes()).thenReturn(types);
        final NeType type = buildType();
        when(types.get(any())).thenReturn(type);

        final Optional<NeSynchronizationMutationDescriptor> data =
                neConnectionManagerImpl.getCurrentSynchronizationData(buildNeEntity(), neInstance);
        assertThat(data, is(present()));
        assertThat(data.get().getAll(), hasValue(1L));
        assertThat(data.get().getAlarms(), is(absent()));
        assertThat(data.get().getPacket(), is(absent()));
    }

    @Test
    public void getCurrentSynchronizationData_onlyAlarmsSet() throws Exception {
        final INetworkElementProxy proxy = buildProxy();
        proxy.addOptionalFacet(new NeConfigurationCounterPkgItem(-1, 1, -1));

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);
        when(elementManager.activateNetworkElementProxy(any(ISessionContext.class), any(IElementManagerId.class), any(INE.class), any(Property[].class)))
            .thenReturn(proxy);

        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));

        when(configuration.getNeTypes()).thenReturn(types);
        final NeType type = buildType();
        when(types.get(any())).thenReturn(type);

        final Optional<NeSynchronizationMutationDescriptor> data =
                neConnectionManagerImpl.getCurrentSynchronizationData(buildNeEntity(), neInstance);
        assertThat(data, is(present()));
        assertThat(data.get().getAll(), is(absent()));
        assertThat(data.get().getAlarms(), hasValue(1L));
        assertThat(data.get().getPacket(), is(absent()));
    }

    @Test
    public void getCurrentSynchronizationData_onlyPacketSet() throws Exception {
        final INetworkElementProxy proxy = buildProxy();
        proxy.addOptionalFacet(new NeConfigurationCounterPkgItem(-1, -1, 1));

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);
        when(elementManager.activateNetworkElementProxy(any(ISessionContext.class), any(IElementManagerId.class), any(INE.class), any(Property[].class)))
            .thenReturn(proxy);

        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));

        when(configuration.getNeTypes()).thenReturn(types);
        final NeType type = buildType();
        when(types.get(any())).thenReturn(type);

        final Optional<NeSynchronizationMutationDescriptor> data =
                neConnectionManagerImpl.getCurrentSynchronizationData(buildNeEntity(), neInstance);
        assertThat(data, is(present()));
        assertThat(data.get().getAll(), is(absent()));
        assertThat(data.get().getAlarms(), is(absent()));
        assertThat(data.get().getPacket(), hasValue(1L));
    }

    @Test
    public void getCurrentSynchronizationData_allSet() throws Exception {
        final INetworkElementProxy proxy = buildProxy();
        proxy.addOptionalFacet(new NeConfigurationCounterPkgItem(1, 2, 3));

        when(connectionManager.getFacade(any(ISessionContext.class), eq(MediationFacade.ELEMENT_MANAGER_FACADE),
                eq(new MediatorIdItem(MEDIATOR_INSTANCE_ID)), eq(new EMIdItem(CHANNEL_ID))))
            .thenReturn(elementManager);
        when(elementManager.activateNetworkElementProxy(any(ISessionContext.class), any(IElementManagerId.class), any(INE.class), any(Property[].class)))
            .thenReturn(proxy);

        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));

        when(configuration.getNeTypes()).thenReturn(types);
        final NeType type = buildType();
        when(types.get(any())).thenReturn(type);

        final Optional<NeSynchronizationMutationDescriptor> data =
                neConnectionManagerImpl.getCurrentSynchronizationData(buildNeEntity(), neInstance);
        assertThat(data, is(present()));
        assertThat(data.get().getAll(), hasValue(1L));
        assertThat(data.get().getAlarms(), hasValue(2L));
        assertThat(data.get().getPacket(), hasValue(3L));
    }

    private INetworkElementProxy buildProxy() {
        final INetworkElementProxy neProxy = new NetworkElementProxyItem(null, NE_ID, CHANNEL_ID,
                "type",
                null, null,
                CommunicationState.DISCONNECTED, null,
                InitState.NOT_INITIALIZED, null,
                "icon_id",
                null);
        return neProxy;
    }

    private NeType buildType() {
        final NeType neType = MockFactory.mockNeType();
        when(neType.getDefaultIcon()).thenReturn("iconTypeId");
        return neType;
    }

    private NeEntity buildNeEntity() {
        return buildNeEntity(ActualActivationState.DISCONNECTED);
    }

    private NeEntity buildNeEntity(ActualActivationState activationState) {
        return new NeEntity(
                new NeConnectionBuilder().setActivationState(activationState).build(NE_ID, VERSION),
                new NeOperationBuilder().build(NE_ID, VERSION),
                new NeInfoBuilder().setProxyType("type").build(NE_ID, CHANNEL_ID, VERSION),
                new NeSynchronizationBuilder().build(NE_ID, VERSION),
                new NeUserPreferencesBuilder().setName("name").build(NE_ID, VERSION));
    }
}
