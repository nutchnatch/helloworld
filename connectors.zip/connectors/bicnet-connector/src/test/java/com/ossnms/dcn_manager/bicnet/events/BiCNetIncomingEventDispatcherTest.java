package com.ossnms.dcn_manager.bicnet.events;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.scs.IScsFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.IBiCNetComponentId;
import com.ossnms.bicnet.bcb.model.common.SyncCategory;
import com.ossnms.bicnet.bcb.model.elementMgmt.CategoryOutOfSync;
import com.ossnms.bicnet.bcb.model.platform.SynchNotification;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncMode;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationStateNotification;
import com.ossnms.dcn_manager.bicnet.connector.messaging.DecoratedNotification;
import com.ossnms.dcn_manager.bicnet.connector.storage.InMemoryNeSyncStateRepository;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import rx.Observable;

import java.util.Date;

import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;

public class BiCNetIncomingEventDispatcherTest {

    private static final int NE_ID = 5;

    private InMemoryNeSyncStateRepository stateRepo;
    private IScsFacade scs;
    private ISessionContext context;

    private IBiCNetMessageDispatcher messageDispatcher;
    private BiCNetIncomingEventDispatcher dispatcher;

    @Before
    public void setUp() {
        stateRepo = mock(InMemoryNeSyncStateRepository.class);
        messageDispatcher = mock(IBiCNetMessageDispatcher.class);
        scs = mock(IScsFacade.class);
        context = mock(ISessionContext.class);

        dispatcher = new BiCNetIncomingEventDispatcher(stateRepo, messageDispatcher, scs, context);
    }

    @Test
    public void nullScsSyncState_noAction() throws Exception {
        dispatcher.initialize(Observable.from(new DecoratedNotification[] {
            new DecoratedNotification(new SynchNotification())
        }));
        verifyZeroInteractions(stateRepo, messageDispatcher);
    }

    @Test
    public void scsSyncState_storedAndForwarded() throws Exception {
        final ArgumentCaptor<ScsSynchronizationState> stateCaptor = ArgumentCaptor.forClass(ScsSynchronizationState.class);
        final ArgumentCaptor<IBiCNetMessage> notifCaptor = ArgumentCaptor.forClass(IBiCNetMessage.class);

        dispatcher.initialize(Observable.from(new DecoratedNotification[] {
            new DecoratedNotification(new SynchNotification(new Date(), "information", ScsSyncState.SYNCHRONIZING, new NEIdItem(NE_ID)))
        }));

        verify(stateRepo).tryUpdate(stateCaptor.capture());
        verify(messageDispatcher).sendToClient(notifCaptor.capture());

        final ScsSynchronizationState state = stateCaptor.getValue();
        assertThat(state, is(new ScsSynchronizationState(NE_ID, ScsSyncState.SYNCHRONIZING, "information")));
        assertThat(notifCaptor.getValue().getObject(), is(instanceOf(ScsSynchronizationStateNotification.class)));
        final ScsSynchronizationStateNotification notification = (ScsSynchronizationStateNotification) notifCaptor.getValue().getObject();
        assertThat(notification.affectedMO(), is(new NEIdItem(NE_ID)));
        assertThat(notification.getSynchronizationState(), is(state));
    }

    @Test
    public void categoryOutOfSync_requestsFromScs() throws Exception {

        dispatcher.initialize(Observable.from(new DecoratedNotification[] {
                new DecoratedNotification(new CategoryOutOfSync(new Date(), NE_ID, SyncCategory.PACKET))
        }));

        verify(scs).triggerForcedSync(eq(context), isA(IBiCNetComponentId[].class), eq(ScsSyncMode.HARD_SYNC), eq(SyncCategory.PACKET));
    }

    @Test
    public void categoryOutOfSync_nullCategory_doesNotRequestFromScs() throws Exception {

        dispatcher.initialize(Observable.from(new DecoratedNotification[] {
                new DecoratedNotification(new CategoryOutOfSync(new Date(), NE_ID, null))
        }));

        verify(scs, never()).triggerForcedSync(isA(ISessionContext.class), isA(IBiCNetComponentId[].class), isA(ScsSyncMode.class), isA(SyncCategory.class));
    }

    @Test
    public void categoryOutOfSync_requestsFromScs_errorOnScs_ignores() throws Exception {

        doThrow(new BcbException())
                .when(scs).triggerForcedSync(isA(ISessionContext.class), isA(IBiCNetComponentId[].class), isA(ScsSyncMode.class), isA(SyncCategory.class));

        dispatcher.initialize(Observable.from(new DecoratedNotification[] {
                new DecoratedNotification(new CategoryOutOfSync(new Date(), NE_ID, SyncCategory.PACKET))
        }));

    }
}
