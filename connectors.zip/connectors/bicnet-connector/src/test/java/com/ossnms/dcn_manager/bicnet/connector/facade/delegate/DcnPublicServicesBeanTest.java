package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.security.ISecureServerSession;
import com.ossnms.bicnet.bcb.facade.security.ISecurityMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.security.BcbSecurityException;
import com.ossnms.dcn_manager.bicnet.connector.facade.DcnPublicServicesBean;
import com.ossnms.dcn_manager.bicnet.connector.interfaces.BicnetServiceManagerFactory;
import com.ossnms.dcn_manager.bicnet.connector.security.SecureActionValidation;
import org.aspectj.lang.Aspects;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DcnPublicServicesBeanTest {

    @Mock private ISessionContext context;
    @Mock private BicnetServiceManagerFactory serviceManager;
    @Mock private ISecurityMgrFacade securityMgrFacade;
    @Mock private ISecureServerSession secureServerSession;

    @Mock private MOHelper moHelper;

    @InjectMocks private DcnPublicServicesBean bean;

    @Before public void setUp() throws BcbSecurityException, UnsupportedOperationException {
        when(secureServerSession.checkOperationPermission(anyString())).thenReturn(true);
        when(securityMgrFacade.getServerSession(any(ISessionContext.class))).thenReturn(secureServerSession);
        when(serviceManager.getSecurityManagerFacade()).thenReturn(securityMgrFacade);

        Aspects.aspectOf(SecureActionValidation.class).setServiceManager(serviceManager);
    }

    @Test public void testAddUsage() throws BcbException {
        final NEIdItem id = new NEIdItem();

        whenCalledAllow(id);

        bean.addUsage(context, id, BiCNetComponentType.AP_CONNECTION_MANAGER);

        verify(moHelper).addUsage(context, id, BiCNetComponentType.AP_CONNECTION_MANAGER);
    }

    @Test public void testReleaseUsage() throws BcbException {
        final NEIdItem id = new NEIdItem();

        whenCalledAllow(id);

        bean.releaseUsage(context, id, BiCNetComponentType.AP_CONNECTION_MANAGER);

        verify(moHelper).releaseUsage(context, id, BiCNetComponentType.AP_CONNECTION_MANAGER);
    }

    private void whenCalledAllow(IManagedObjectId... ids) {
        when(secureServerSession.checkOperationPermission(anyString(), any(IManagedObjectId[].class))).thenReturn(ids);
    }

}
