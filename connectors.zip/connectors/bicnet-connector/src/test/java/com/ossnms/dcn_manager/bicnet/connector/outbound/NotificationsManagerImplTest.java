package com.ossnms.dcn_manager.bicnet.connector.outbound;

import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMMarkable;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.Notification;
import com.ossnms.bicnet.bcb.model.platform.NotificationType;
import com.ossnms.bicnet.bcb.model.platform.ObjectCreation;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.dcn_manager.bicnet.connector.outbound.notifications.ChannelNotificationsManagerImpl;
import com.ossnms.dcn_manager.composables.outbound.SecurityManager;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class NotificationsManagerImplTest {

    private static final int ID = 42;

	private static final int RECONNECT_INTERVAL = 60;

    @Mock private IBiCNetMessageDispatcher messageDispatcher;
    @Mock private StaticConfiguration configuration;
    @Mock private ChannelEntityRepository repository;
    @Mock private SecurityManager securityManager;
    @Mock private ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository;

    private ChannelEntity entity;
    @Captor private ArgumentCaptor<IBiCNetMessage> msgCaptor;

    @InjectMocks private ChannelNotificationsManagerImpl notifications;

    @Before
    public void setUp() throws Exception {

        final ChannelType type = mock(ChannelType.class);
        when(type.getName()).thenReturn("typeName");
        when(type.getDefaultIcon()).thenReturn("");

        final int VERSION = 1, MEDIATOR_ID = 2;
        entity = new ChannelEntity(
				new ChannelInfoBuilder()
				    .setType(type.getName())
				    .setType("typeName")
				    .setActivationRequired(false)
				    .build(ID, VERSION, MEDIATOR_ID),
        		new ChannelConnectionBuilder()
				    .build(ID, VERSION),
        		new ChannelUserPreferencesBuilder()
				    .setReconnectInterval(RECONNECT_INTERVAL)
				    .setName("The channel name")
				    .build(ID, VERSION));

        final Types<ChannelType> types = mock(Types.class);
        when(configuration.getChannelTypes()).thenReturn(types);

        when(types.get(any())).thenReturn(type);

        when(channelPhysicalConnectionRepository.queryAll(anyInt())).thenReturn(Collections.emptyList());
    }

    @Test
    public void testNotifyDelete() {
        notifications.notifyDelete(entity);

        verify(messageDispatcher).sendToSource(msgCaptor.capture(), eq(true));

        final IBiCNetMessage message = msgCaptor.getValue();
        assertThat(message.getIntProperty("NotificationType"), is(NotificationType.OBJECT_DELETION.getOrdinal()));
        final Notification[] notifs = (Notification[]) message.getObject();
        assertThat(notifs.length, not(is(0)));
        assertThat(notifs[0], is(instanceOf(ObjectDeletion.class)));

        final ObjectDeletion notif = (ObjectDeletion) notifs[0];
        assertThat(notif.getTimestamp(), is(notNullValue()));
        assertThat(notif.getDeletedObject(), is(instanceOf(IEMId.class)));
    }

    @Test
    public void testNotifyCreate() {
        notifications.notifyCreate(entity);

        verify(messageDispatcher).sendToSource(msgCaptor.capture(), eq(true));

        final IBiCNetMessage message = msgCaptor.getValue();
        assertThat(message.getIntProperty("NotificationType"), is(NotificationType.OBJECT_CREATION.getOrdinal()));
        final Notification[] notifs = (Notification[]) message.getObject();
        assertThat(notifs.length, not(is(0)));
        assertThat(notifs[0], is(instanceOf(ObjectCreation.class)));

        final ObjectCreation notif = (ObjectCreation) notifs[0];
        assertThat(notif.getTimestamp(), is(notNullValue()));
        assertThat(notif.getCreatedObject(), is(instanceOf(IEM.class)));
    }

    @Test
    public void testNotifyChanges() throws InvalidMutationException {
        final ChannelUserPreferencesMutationDescriptor mutation = new ChannelUserPreferencesMutationDescriptor(entity.getUserPreferences());
        mutation.setReconnectInterval(12);
        notifications.notifyChanges(mutation, entity.getInfo().getType());

        verify(messageDispatcher).sendToSource(msgCaptor.capture(), eq(true));

        verify(securityManager).updateChannel(isA(ChannelUserPreferencesData.class));

        final IBiCNetMessage message = msgCaptor.getValue();
        assertThat(message.getIntProperty("NotificationType"), is(NotificationType.ATTRIBUTE_VALUE_CHANGE.getOrdinal()));
        final Notification[] notifs = (Notification[]) message.getObject();
        assertThat(notifs.length, not(is(0)));
        assertThat(notifs[0], is(instanceOf(AttributeValueChange.class)));

        final AttributeValueChange notif = (AttributeValueChange) notifs[0];
        assertThat(notif.getTimestamp(), is(notNullValue()));
        assertThat(notif.getChangedObject(), is(instanceOf(IEMMarkable.class)));

        final IEMMarkable obj = (IEMMarkable) notif.getChangedObject();

        assertThat(obj.isMarkedIdName(), is(false));
        assertThat(obj.isMarkedReconnectInterval(), is(true));
        assertThat(obj.getReconnectInterval(), is(12));
    }

    @Test
    public void testNotifyNameChanges() throws InvalidMutationException, RepositoryException {
        final ChannelUserPreferencesMutationDescriptor mutation = new ChannelUserPreferencesMutationDescriptor(entity.getUserPreferences());
        mutation.setName("newName");

        final ChannelEntity changedEntity = new ChannelEntity(
                entity.getInfo(),
                entity.getConnectionState(),
                mutation.apply());

        when(repository.queryChannel(ID)).thenReturn(Optional.of(changedEntity));
        notifications.notifyChanges(mutation, entity.getInfo().getType());

        verify(securityManager).updateChannel(isA(ChannelUserPreferencesData.class));

        verify(messageDispatcher).sendToSource(msgCaptor.capture(), eq(true));

        final IBiCNetMessage message = msgCaptor.getValue();
        assertThat(message.getIntProperty("NotificationType"), is(NotificationType.ATTRIBUTE_VALUE_CHANGE.getOrdinal()));
        final Notification[] notifs = (Notification[]) message.getObject();
        assertThat(notifs.length, not(is(0)));
        assertThat(notifs[0], is(instanceOf(AttributeValueChange.class)));

        final AttributeValueChange notif = (AttributeValueChange) notifs[0];
        assertThat(notif.getTimestamp(), is(notNullValue()));
        assertThat(notif.getChangedObject(), is(instanceOf(IEMMarkable.class)));

        final IEMMarkable obj = (IEMMarkable) notif.getChangedObject();

        assertThat(obj.isMarkedAdditionalInfo(), is(false));
        assertThat(obj.isMarkedActivation(), is(false));
        assertThat(obj.isMarkedIdName(), is(true));
        assertThat(obj.getIdName(), is("newName"));
        assertThat(obj.isMarkedReconnectInterval(), is(false));
    }

}
