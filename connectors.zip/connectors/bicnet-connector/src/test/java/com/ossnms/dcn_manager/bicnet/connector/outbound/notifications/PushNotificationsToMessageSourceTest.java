package com.ossnms.dcn_manager.bicnet.connector.outbound.notifications;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

import org.junit.Test;

import com.ossnms.dcn_manager.bicnet.connector.messaging.MessageSourceImpl;
import com.ossnms.dcn_manager.core.events.Event;

public class PushNotificationsToMessageSourceTest {

    public static class TestTarget extends MessageSourceImpl<Event> {

        public void doTest(Event event) {

        }

    }

    @Test
    public void test() {

        final Event event = mock(Event.class);
        final TestTarget target = spy(new TestTarget());

        target.doTest(event);

        verify(target).push(event);
    }

}
