package com.ossnms.dcn_manager.bicnet.connector.outbound.notifications;

import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.composables.outbound.SecurityManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelDeactivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelShuttingDownEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelStartingUpEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelStartingUpEvent;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertCommunicationStateToString.communicationStateToString;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.anyBoolean;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ChannelNotificationsManagerImplTest {

    private static final int CHANNEL_ID = 12;
    private static final String CHANNEL_NAME = "name";
    private static final int INSTANCE_ID = 21;

    @Mock private StaticConfiguration configuration;
    @Mock private ChannelEntityRepository channelRepository;
    @Mock private LoggerManagerImpl loggerManager;
    @Mock private BicnetCallContext systemContext;
    @Mock private IBiCNetMessageDispatcher messageDispatcher;
    @Mock private SecurityManager securityManager;

    @InjectMocks private ChannelNotificationsManagerImpl notif;

    @Before
    public void setUp() throws RepositoryException {
        when(channelRepository.queryChannelName(CHANNEL_ID)).thenReturn(Optional.of(CHANNEL_NAME));
    }

    @Test
    public void notifyUpdate() throws Exception {
        final ChannelUserPreferencesMutationDescriptor descriptor = new ChannelUserPreferencesMutationDescriptor(
                new ChannelUserPreferencesBuilder().setName("ch").build(1, 1));
        descriptor.apply();

        notif.notifyChanges(descriptor, "type");

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(securityManager).updateChannel(descriptor.getResult());
    }

    @Test
    public void notificationLog_withRepoError_doesNotLog() throws RepositoryException {
        when(channelRepository.queryChannelName(CHANNEL_ID)).thenThrow(new RepositoryException());

        notif.notifyChanges(new ChannelActivatedEvent(CHANNEL_ID));

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(loggerManager, never()).createSystemEventLog(any(BicnetCallContext.class), any(LoggerItem.class));
    }

    @Test
    public void notificationLog_withoutChannelName_doesNotLog() throws RepositoryException {
        when(channelRepository.queryChannelName(CHANNEL_ID)).thenReturn(Optional.empty());

        notif.notifyChanges(new ChannelActivatedEvent(CHANNEL_ID));

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(loggerManager, never()).createSystemEventLog(any(BicnetCallContext.class), any(LoggerItem.class));
    }

    @Test
    public void notifyConnected_internal_notifiesSystem() {
        notif.notifyChanges(new ChannelActivatedEvent(CHANNEL_ID));
        verifySystemNotified(CommunicationState.CONNECTED);
    }

    @Test
    public void notifyConnected_inactiveInstance_notifiesClient() {
        notif.notifyChanges(new ChannelActivatedEvent(CHANNEL_ID,
                new PhysicalChannelActivatedEvent(INSTANCE_ID, CHANNEL_ID, false)));
        verifyClientNotified(CommunicationState.CONNECTED);
    }

    @Test
    public void notifyConnected_activeInstance_isDropped() {
        notif.notifyChanges(new ChannelActivatedEvent(CHANNEL_ID,
                new PhysicalChannelActivatedEvent(INSTANCE_ID, CHANNEL_ID, true)));
        verifyNotificationDropped();
    }

    @Test
    public void notifyConnecting_internal_notifiesSystem() {
        notif.notifyChanges(new ChannelActivatingEvent(CHANNEL_ID));
        verifySystemNotified(CommunicationState.CONNECTING);
    }

    @Test
    public void notifyConnecting_inactiveInstance_notifiesClient() {
        notif.notifyChanges(new ChannelActivatingEvent(CHANNEL_ID,
                new PhysicalChannelActivatingEvent(INSTANCE_ID, CHANNEL_ID, false)));
        verifyClientNotified(CommunicationState.CONNECTING);
    }

    @Test
    public void notifyConnecting_activeInstance_isDropped() {
        notif.notifyChanges(new ChannelActivatingEvent(CHANNEL_ID,
                new PhysicalChannelActivatingEvent(INSTANCE_ID, CHANNEL_ID, true)));
        verifyNotificationDropped();
    }

    @Test
    public void notifyDisconnected_internal_notifiesSystem() {
        notif.notifyChanges(new ChannelDeactivatedEvent(CHANNEL_ID));
        verifySystemNotified(CommunicationState.DISCONNECTED);
    }

    @Test
    public void notifyDisconnected_inactiveInstance_notifiesClient() {
        notif.notifyChanges(new ChannelDeactivatedEvent(CHANNEL_ID,
                new PhysicalChannelDeactivatedEvent(INSTANCE_ID, CHANNEL_ID, false)));
        verifyClientNotified(CommunicationState.DISCONNECTED);
    }

    @Test
    public void notifyDisconnected_activeInstance_isDropped() {
        notif.notifyChanges(new ChannelDeactivatedEvent(CHANNEL_ID,
                new PhysicalChannelDeactivatedEvent(INSTANCE_ID, CHANNEL_ID, true)));
        verifyNotificationDropped();
    }

    @Test
    public void notifyDisconnecting_internal_notifiesSystem() {
        notif.notifyChanges(new ChannelDeactivatingEvent(CHANNEL_ID));
        verifySystemNotified(CommunicationState.DISCONNECTING);
    }

    @Test
    public void notifyDisconnecting_inactiveInstance_notifiesClient() {
        notif.notifyChanges(new ChannelDeactivatingEvent(CHANNEL_ID,
                new PhysicalChannelDeactivatingEvent(INSTANCE_ID, CHANNEL_ID, false)));
        verifyClientNotified(CommunicationState.DISCONNECTING);
    }

    @Test
    public void notifyDisconnecting_activeInstance_isDropped() {
        notif.notifyChanges(new ChannelDeactivatingEvent(CHANNEL_ID,
                new PhysicalChannelDeactivatingEvent(INSTANCE_ID, CHANNEL_ID, true)));
        verifyNotificationDropped();
    }

    @Test
    public void notifyStartingUp_internal_activeNotifiesSystem() {
        notif.notifyChanges(new ChannelStartingUpEvent(CHANNEL_ID, new PhysicalChannelStartingUpEvent(INSTANCE_ID, CHANNEL_ID, true)));
        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
    }

    @Test
    public void notifyStartingUp_internal_inactiveNotifiesClient() {
        notif.notifyChanges(new ChannelStartingUpEvent(CHANNEL_ID, new PhysicalChannelStartingUpEvent(INSTANCE_ID, CHANNEL_ID, false)));
        verify(messageDispatcher, never()).sendToSource(isA(IBiCNetMessage.class), anyBoolean());
        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
    }

    @Test
    public void notifyShuttingDown_internal_activeNotifiesSystem() {
        notif.notifyChanges(new ChannelShuttingDownEvent(CHANNEL_ID, new PhysicalChannelStartingUpEvent(INSTANCE_ID, CHANNEL_ID, true)));
        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
    }

    @Test
    public void notifyShuttingDown_internal_inactiveNotifiesClient() {
        notif.notifyChanges(new ChannelShuttingDownEvent(CHANNEL_ID, new PhysicalChannelStartingUpEvent(INSTANCE_ID, CHANNEL_ID, false)));
        verify(messageDispatcher, never()).sendToSource(isA(IBiCNetMessage.class), anyBoolean());
        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
    }

    @Test
    public void notifyFailed() {
        notif.notifyChanges(new ChannelActivationFailedEvent(CHANNEL_ID, "additional info"));

        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(loggerManager).createSystemEventLog(systemContext,
                new LoggerItemChannel(CHANNEL_NAME,
                        tr(Message.CHANNEL_STATE_CHANGED, communicationStateToString(CommunicationState.FAILED)) + " additional info",
                        MessageSeverity.INFO));
    }

    @Test
    public void testNotifyInstanceCreated() throws Exception {

        final ChannelPhysicalConnectionData conn = new ChannelPhysicalConnectionBuilder()
                .build(1, 2, 3, 0);

        notif.notifyCreateInstance(conn);

        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
    }

    @Test
    public void testNotifyInstanceDeleted() throws Exception {

        notif.notifyDeleteInstance(1, 2);

        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
    }

    private void verifyNotificationDropped() {
        verifyZeroInteractions(messageDispatcher, loggerManager);
    }

    private void verifySystemNotified(CommunicationState commState) {
        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
        verify(loggerManager).createSystemEventLog(systemContext,
            new LoggerItemChannel(CHANNEL_NAME,
                    tr(Message.CHANNEL_STATE_CHANGED, communicationStateToString(commState)) + " ",
                    MessageSeverity.INFO));
    }

    private void verifyClientNotified(CommunicationState commState) {
        verify(messageDispatcher, never()).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
        verify(loggerManager).createSystemEventLog(systemContext,
            new LoggerItemChannel(CHANNEL_NAME,
                    tr(Message.CHANNEL_STATE_CHANGED, communicationStateToString(commState)) + "  (standby)",
                    MessageSeverity.INFO));
    }
}
