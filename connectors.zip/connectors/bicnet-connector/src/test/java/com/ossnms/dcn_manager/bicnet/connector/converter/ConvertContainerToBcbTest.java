package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

public class ConvertContainerToBcbTest {

    private static final String CONTAINER_DESCRIPTION = "test container";
    private static final String CONTAINER_USER_TEXT= "test userText";
    private static final String CONTAINER_NAME = "container";
    private static final int PARENT_ID = 3;
    private static final int CONTAINER_ID = 1;

    @Test
    public void convertFull() throws Exception {
        final IGenericContainer GenericContainer = ConvertContainerToBcb.convert(
                new ContainerInfo(CONTAINER_ID, 2, Optional.of(PARENT_ID), CONTAINER_NAME, Optional.of(CONTAINER_DESCRIPTION), Optional.of(CONTAINER_USER_TEXT)));

        assertThat(GenericContainer.getDescription(), is(CONTAINER_DESCRIPTION));
        assertThat(GenericContainer.getUserLabel(), is(CONTAINER_USER_TEXT));
        assertThat(GenericContainer.getId(), is(CONTAINER_ID));
        assertThat(GenericContainer.getIdName(), is(CONTAINER_NAME));
        assertThat(GenericContainer.getParentId(), is(PARENT_ID));
    }

    @Test
    public void convertMinimal() throws Exception {
        final IGenericContainer GenericContainer = ConvertContainerToBcb.convert(
                new ContainerInfo(CONTAINER_ID, 2, CONTAINER_NAME));

        assertThat(GenericContainer.getDescription(), is(nullValue()));
        assertThat(GenericContainer.getId(), is(CONTAINER_ID));
        assertThat(GenericContainer.getIdName(), is(CONTAINER_NAME));
        assertThat(GenericContainer.getParentId(), is(0));
    }

    @Test
    public void apply() throws Exception {
        final ConvertContainerToBcb convert = new ConvertContainerToBcb();

        assertThat(convert.apply(null), is(nullValue()));

        final IGenericContainer genericContainer = convert.apply(
                new ContainerInfo(CONTAINER_ID, 2, Optional.of(PARENT_ID), CONTAINER_NAME, Optional.of(CONTAINER_DESCRIPTION), Optional.of(CONTAINER_USER_TEXT)));

        assertNotNull(genericContainer);
        assertThat(genericContainer.getDescription(), is(CONTAINER_DESCRIPTION));
        assertThat(genericContainer.getUserLabel(), is(CONTAINER_USER_TEXT));
        assertThat(genericContainer.getId(), is(CONTAINER_ID));
        assertThat(genericContainer.getIdName(), is(CONTAINER_NAME));
        assertThat(genericContainer.getParentId(), is(PARENT_ID));
    }

}
