package com.ossnms.dcn_manager.bicnet.connector.facade;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdItem;
import com.ossnms.bicnet.bcb.facade.security.ISecureServerSession;
import com.ossnms.bicnet.bcb.facade.security.ISecurityMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationState;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.NeHelper;
import com.ossnms.dcn_manager.bicnet.connector.interfaces.BicnetServiceManagerFactory;
import com.ossnms.dcn_manager.bicnet.connector.security.SecureActionValidation;
import org.aspectj.lang.Aspects;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class NeServiceBeanTest {

    private static final INEId NE_ID = new NEIdItem(2);

    @Mock private NeHelper helper;
    @Mock private ISessionContext context;
    @Mock private ISecureServerSession serverSession;
    @Mock private ISecurityMgrFacade securityManager;
    @Mock private BicnetServiceManagerFactory serviceManager;

    @InjectMocks private NeServiceBean bean;

    @Before
    public void setUp() throws Exception {
        final SecureActionValidation validation = Aspects.aspectOf(SecureActionValidation.class);
        validation.setServiceManager(serviceManager);

        when(securityManager.getServerSession(context)).thenReturn(serverSession);
        when(serviceManager.getSecurityManagerFacade()).thenReturn(securityManager);
    }

    @Test
    public void getProperties() throws BcbException {
        bean.getProperties(context, NE_ID);

        verify(helper).getProperties(context, NE_ID);
    }

    @Test
    public void getSupportedNeTypes() throws BcbException {
        final String type = "type";

        bean.getSupportedNeTypes(context, type);

        verify(helper).getSupportedNeTypes(context, type);
    }

    @Test
    public void updateProperties() throws BcbException {
        final Map<String, String> props = Collections.emptyMap();

        bean.updateProperties(context, NE_ID, props);

        verify(helper).updateProperties(context, NE_ID, props);
    }

    @Test
    public void testSetToActiveStateMode() throws BcbException {
        when(serverSession.checkOperationPermission(SecureAction.OP_MOGCM_ACTIVE_SAN.getIdentifier())).thenReturn(true);

        bean.setToActiveStateMode(context, NE_ID);

        verify(helper).setToActiveStateMode(context, NE_ID);
    }

    @Test
    public void testSetToMaintenanceMode() throws BcbException {
        when(serverSession.checkOperationPermission(SecureAction.OP_MOGCM_MAINTENANCE_SAN.getIdentifier())).thenReturn(true);

        bean.setToMaintenanceMode(context, NE_ID);

        verify(helper).setToMaintenanceMode(context, NE_ID);
    }

    @Test
    public void testSetToOperationalMode() throws BcbException {
        when(serverSession.checkOperationPermission(SecureAction.OP_MOGCM_OPERATIONAL_SAN.getIdentifier())).thenReturn(true);

        bean.setToOperationalMode(context, NE_ID);

        verify(helper).setToOperationalMode(context, NE_ID);
    }

    @Test
    public void testWriteAccessRelease() throws BcbException {
        when(serverSession.checkOperationPermission(SecureAction.OP_MOGCM_REL_WRITE_ACC_SAN.getIdentifier())).thenReturn(true);

        bean.writeAccessRelease(context, NE_ID);

        verify(helper).writeAccessRelease(context, NE_ID);
    }

    @Test
    public void testWriteAccessRequest() throws BcbException {
        when(serverSession.checkOperationPermission(SecureAction.OP_MOGCM_REQ_WRITE_ACC_SAN.getIdentifier())).thenReturn(true);

        bean.writeAccessRequest(context, NE_ID);

        verify(helper).writeAccessRequest(context, NE_ID);
    }

    @Test
    public void testWriteAccessEnforce() throws BcbException {
        when(serverSession.checkOperationPermission(SecureAction.OP_MOGCM_ENF_WRITE_ACC_SAN.getIdentifier())).thenReturn(true);

        bean.writeAccessEnforce(context, NE_ID);

        verify(helper).writeAccessEnforce(context, NE_ID);
    }

    @Test
    public void testCopyNetworkNamesToNeNames() throws BcbException {
        when(serverSession.checkOperationPermission(SecureAction.OP_COPY_NE_NAME_TO_ID_NAME_SAN.getIdentifier())).thenReturn(true);

        final List<INEId> neIds = Collections.singletonList(NE_ID);

        bean.copyNetworkNamesToNeNames(context, neIds);

        verify(helper).copyNetworkNamesToNeNames(context, neIds);
    }

    @Test
    public void testMoveNeToAnotherChannel() throws BcbException {
        final EMIdItem targetChannelId = new EMIdItem(3);
        final Collection<INEId> neIds = Collections.singleton(NE_ID);

        bean.moveNesToAnotherChannel(context, neIds, targetChannelId);

        verify(helper).moveNesToAnotherChannel(context, neIds, targetChannelId);
    }

    @Test
    public void testGetScsSynchronizationStates() {
        final Iterable<ScsSynchronizationState> states = Collections.singletonList(
                new ScsSynchronizationState(1, ScsSyncState.SYNCHRONIZED));
        when(helper.getScsSynchronizationStates()).thenReturn(states);

        final Iterable<ScsSynchronizationState> exposedStates = bean.getScsSynchronizationStates();
        assertThat(exposedStates, is(states));
    }

    @Test
    public void testChangeContainerId() throws BcbException {
        final ImmutableMap<INEId, ISystemContainerId> associations =
                ImmutableMap.of(new NEIdItem(1), new SystemContainerIdItem(10));

        bean.changeSystemContainerId(context, associations);

        verify(helper).changeSystemContainerId(context, associations);
    }

    @Test(expected = BcbException.class)
    public void testGetFullNe_nullId_throws() throws Exception {
        bean.getFullNe(context, 0);
    }

    @Test(expected = BcbException.class)
    public void testGetProperties_nullId_throws() throws Exception {
        bean.getProperties(context, new NEIdItem(0));
    }

    @Test(expected = BcbException.class)
    public void testUpdateProperties_nullId_throws() throws Exception {
        bean.updateProperties(context, new NEIdItem(0), Collections.emptyMap());
    }

}
