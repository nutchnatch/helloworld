package com.ossnms.dcn_manager.bicnet.connector.messaging;

import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementDomainAssignmentIdItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementDomainAssignmentItem;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainParticipationId;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.IdentifierChange;
import com.ossnms.bicnet.bcb.model.platform.Notification;
import com.ossnms.bicnet.bcb.model.platform.ObjectCreation;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.outbound.notifications.DomainNotificationsManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.HelperItTestBase;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaDomainRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.SecurityManager;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeGatewayRoutesRepository;
import com.ossnms.dcn_manager.events.base.DomainManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.events.domain.DomainDispatcher;
import org.hamcrest.CustomMatcher;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.unitils.dbunit.annotation.DataSet;
import org.unitils.inject.util.InjectionUtils;
import org.unitils.inject.util.PropertyAccess;
import rx.subjects.PublishSubject;
import rx.subjects.SerializedSubject;

import java.util.Date;
import java.util.Optional;
import java.util.function.Predicate;

import static com.google.common.collect.FluentIterable.from;
import static com.google.common.collect.Iterables.transform;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@DataSet
public class DomainEventHandlingIT extends HelperItTestBase {

    private static final int NE_ID = 1;

    @Mock private BicnetCallContext ctx;
    @Mock private LoggerManager<BicnetCallContext> loggerManager;
    @Mock private StaticConfiguration configuration;
    @Mock private SecurityManager securityManager;
    @Mock private IBiCNetMessageDispatcher messageDispatcher;
    @Mock private SettingsRepository settings;

    @InjectMocks private JpaNetworkElementRepositoryBean neRepository;
    @InjectMocks private DomainNotificationsManagerImpl domainNotifications;
    @InjectMocks private JpaDomainRepositoryBean domainRepository;
    @InjectMocks private DomainEventSource source;

    private DomainDispatcher<BicnetCallContext> dispatcher; // keep this reference around during the test.
    private SerializedSubject<DecoratedNotification, DecoratedNotification> decoratedNotificationPublisher;

    @Override @Before
    public void setUp() throws Exception {
        super.setUp();

        neRepository.initialize();
        neRepository.start();

        InjectionUtils.injectIntoByType(domainRepository, DomainRepository.class, source, PropertyAccess.FIELD);
        InjectionUtils.injectIntoByType(domainRepository, DomainRepository.class, domainNotifications, PropertyAccess.FIELD);

        when(settings.getSettings()).thenReturn(GlobalSettings.build().toGlobalSettings(6, 0));

        dispatcher = new DomainDispatcher<>(ctx,
                new DomainManagers(domainRepository, domainNotifications),
                new NetworkElementManagers(neRepository, null, null, null, null),
                configuration, settings, loggerManager);

        decoratedNotificationPublisher = PublishSubject.<DecoratedNotification>create().toSerialized();
        source.subscribe(decoratedNotificationPublisher);
        dispatcher.initialize(source.observe());
    }

    @Test
    public void domainNameChanged() throws Exception {
        final NeGatewayRoutesRepository routesRepository = neRepository.getNeGatewayRoutesRepository();

        // sanity check
        assertThat(domainRepository.queryAllForNE(NE_ID), hasItems(
                new DomainInfoData(41, 1, "domain1", true),
                new DomainInfoData(42, 1, "original", true))
        );
        assertThat(from(routesRepository.queryRoutes(NE_ID))
                .transform(NeGatewayRouteData::getDomain).transform(Optional::get), hasItems("domain1"));

        decoratedNotificationPublisher.onNext(
                new DecoratedNotification(new IdentifierChange(new Date(),
                        new NetworkElementDomainAssignmentIdItem(NE_ID, "domain1"),
                        new NetworkElementDomainAssignmentIdItem(NE_ID, "new"))
                )
        );

        assertThat(domainRepository.queryAllForNE(NE_ID), hasItems(
                new DomainInfoData(41, 2, "new", true),
                new DomainInfoData(42, 1, "original", true))
        );
        assertThat(from(routesRepository.queryRoutes(NE_ID))
                .transform(NeGatewayRouteData::getDomain).transform(Optional::get), hasItems("new"));

        ArgumentCaptor<IBiCNetMessage> captor = ArgumentCaptor.forClass(IBiCNetMessage.class);
        verify(messageDispatcher, atLeastOnce()).sendToSource(captor.capture(), eq(true));
        assertThat(captor.getAllValues(), hasItem(
            new NotifMatcher<>(AttributeValueChange.class,
                avc -> avc.getChangedObject() instanceof INetworkDomainMarkable)));

        verify(securityManager).updateNe(NE_ID);
    }

    @Test
    public void domainNameRemoved() throws Exception {

        // sanity check
        assertThat(domainRepository.queryAllForNE(NE_ID), hasItems(
                new DomainInfoData(41, 1, "domain1", true),
                new DomainInfoData(42, 1, "original", true))
        );

        decoratedNotificationPublisher.onNext(
                new DecoratedNotification(new ObjectDeletion(new Date(),
                        new NetworkElementDomainAssignmentIdItem(NE_ID, "original")))
        );

        assertThat(domainRepository.queryAllForNE(NE_ID), hasItems(
                new DomainInfoData(41, 1, "domain1", true)
        ));
        assertThat(domainRepository.queryByName("original"), is(absent()));

        ArgumentCaptor<IBiCNetMessage> captor = ArgumentCaptor.forClass(IBiCNetMessage.class);
        verify(messageDispatcher, atLeastOnce()).sendToSource(captor.capture(), eq(true));
        assertThat(captor.getAllValues(), hasItems(
            new NotifMatcher<>(ObjectDeletion.class,
                    del -> del.getDeletedObject() instanceof INetworkDomainParticipationId),
            new NotifMatcher<>(ObjectDeletion.class, // the domain is deleted only because the last NE left.
                    del -> del.getDeletedObject() instanceof INetworkDomainId))
        );

        verify(securityManager).updateNe(NE_ID);
    }

    @Test
    public void domainNameAdded() throws Exception {

        // sanity check
        assertThat(domainRepository.queryAllForNE(NE_ID), hasItems(
                new DomainInfoData(41, 1, "domain1", true),
                new DomainInfoData(42, 1, "original", true))
        );

        decoratedNotificationPublisher.onNext(
                new DecoratedNotification(new ObjectCreation(new Date(),
                        new NetworkElementDomainAssignmentItem(null, NE_ID, "new")))
        );

        assertThat(transform(domainRepository.queryAllForNE(NE_ID), DomainInfoData::getName),
                hasItems("domain1", "original", "new")); // we check names because the new insertion has an unknown id
        assertThat(domainRepository.queryByName("new"), is(present()));

        ArgumentCaptor<IBiCNetMessage> captor = ArgumentCaptor.forClass(IBiCNetMessage.class);
        verify(messageDispatcher, atLeastOnce()).sendToSource(captor.capture(), eq(true));
        assertThat(captor.getAllValues(), hasItems(
                new NotifMatcher<>(ObjectCreation.class,
                        cr -> cr.getCreatedObject() instanceof INetworkDomainParticipationId),
                new NotifMatcher<>(ObjectCreation.class,
                        cr -> cr.getCreatedObject() instanceof INetworkDomainId))
        );

        verify(securityManager).updateNe(NE_ID);
    }

    private class NotifMatcher<N> extends CustomMatcher<IBiCNetMessage> {

        private final Class<N> notif;
        private final Predicate<N> check;

        private NotifMatcher(Class<N> notif, Predicate<N> check) {
            super("BiCNet Notification of type " + notif.getSimpleName());
            this.notif = notif;
            this.check = check;
        }

        @Override
        public boolean matches(Object item) {
            final IBiCNetMessage msg = (IBiCNetMessage) item;
            final Notification[] objects = (Notification[]) msg.getObject();
            return notif.isAssignableFrom(objects[0].getClass()) &&
                    check.test(notif.cast(objects[0]));
        }

    }

}
