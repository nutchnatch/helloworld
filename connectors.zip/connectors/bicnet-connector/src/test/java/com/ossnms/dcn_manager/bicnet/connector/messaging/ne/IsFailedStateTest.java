package com.ossnms.dcn_manager.bicnet.connector.messaging.ne;

import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementProxyItem;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementProxyMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.InitState;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class IsFailedStateTest {

    private final IsFailedState isFailed = new IsFailedState();

    @Test
    public void failed() {
        assertFalse(isFailed.call(buildMarkable(CommunicationState.CONNECTED, InitState.NOT_SYNCHRONIZED))); // this one has a specific use case
        assertTrue(isFailed.call(buildMarkable(CommunicationState.CONNECTED, InitState.FAILED)));
        assertTrue(isFailed.call(buildMarkable(CommunicationState.CONNECTING, InitState.FAILED)));
        assertTrue(isFailed.call(buildMarkable(CommunicationState.DISCONNECTED, InitState.FAILED)));
        assertTrue(isFailed.call(buildMarkable(CommunicationState.DISCONNECTING, InitState.FAILED)));
        assertTrue(isFailed.call(buildMarkable(CommunicationState.FAILED, InitState.FAILED)));
        assertTrue(isFailed.call(buildMarkable(CommunicationState.FAILED, InitState.NOT_SYNCHRONIZED)));
    }

    @Test
    public void unmarked_notFailed() {
        assertFalse(isFailed.call(buildUnmarked(CommunicationState.CONNECTED, InitState.NOT_SYNCHRONIZED)));
        assertFalse(isFailed.call(buildUnmarked(CommunicationState.CONNECTED, InitState.FAILED)));
        assertFalse(isFailed.call(buildUnmarked(CommunicationState.CONNECTING, InitState.FAILED)));
        assertFalse(isFailed.call(buildUnmarked(CommunicationState.DISCONNECTED, InitState.FAILED)));
        assertFalse(isFailed.call(buildUnmarked(CommunicationState.DISCONNECTING, InitState.FAILED)));
        assertFalse(isFailed.call(buildUnmarked(CommunicationState.FAILED, InitState.FAILED)));
    }

    @Test
    public void notFailed() {
        assertFalse(isFailed.call(buildMarkable(CommunicationState.DISCONNECTED, InitState.NOT_SYNCHRONIZED)));
        assertFalse(isFailed.call(buildMarkable(CommunicationState.DISCONNECTING, InitState.NOT_SYNCHRONIZED)));
        assertFalse(isFailed.call(buildMarkable(CommunicationState.CONNECTING, InitState.NOT_SYNCHRONIZED)));

        assertFalse(isFailed.call(buildMarkable(CommunicationState.CONNECTED, InitState.INITIALIZED)));
        assertFalse(isFailed.call(buildMarkable(CommunicationState.CONNECTED, InitState.INITIALIZING)));
        assertFalse(isFailed.call(buildMarkable(CommunicationState.CONNECTED, InitState.NOT_INITIALIZED)));
        assertFalse(isFailed.call(buildMarkable(CommunicationState.CONNECTED, InitState.SHUTTING_DOWN)));
    }

    private INetworkElementProxyMarkable buildMarkable(CommunicationState comm, InitState init) {
        final INetworkElementProxyMarkable nem = new NetworkElementProxyItem().toMarkableNetworkElementProxy();
        nem.setInitState(init);
        nem.setCommunicationState(comm);
        return nem;
    }

    private INetworkElementProxyMarkable buildUnmarked(CommunicationState comm, InitState init) {
        final NetworkElementProxyItem nep = new NetworkElementProxyItem();
        nep.setInitState(init);
        nep.setCommunicationState(comm);
        return nep.toMarkableNetworkElementProxy();
    }

}
