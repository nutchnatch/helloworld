package com.ossnms.dcn_manager.bicnet.connector.outbound.notifications;

import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.composables.outbound.SecurityManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemMediator;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorDeactivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorDeactivatingEvent;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MediatorNotificationsManagerImplTest {

    private static final int MEDIATOR_ID = 33;
    private static final String MEDIATOR_NAME = "mediator name";
    private static final int INSTANCE_ID = 99;

    @Mock private MediatorInstanceEntityRepository mediatorInstanceRepository;
    @Mock private MediatorEntityRepository mediatorRepository;
    @Mock private LoggerManagerImpl loggerManager;
    @Mock private BicnetCallContext systemContext;
    @Mock private IBiCNetMessageDispatcher messageDispatcher;
    @Mock private SecurityManager securityManager;

    @InjectMocks private MediatorNotificationsManagerImpl notif;

    @Before
    public void setUp() throws RepositoryException {
        when(mediatorRepository.queryMediatorName(MEDIATOR_ID)).thenReturn(Optional.of(MEDIATOR_NAME));
        when(mediatorInstanceRepository.queryAll(anyInt())).thenReturn(Collections.<MediatorInstance>emptyList());
    }

    @Test
    public void notifyUpdate() throws Exception {
        final MediatorInfoMutationDescriptor descriptor = new MediatorInfoMutationDescriptor(
            new MediatorInfoData.MediatorInfoBuilder().setName("md").setTypeName("mdtype").build(1, 1));
        descriptor.apply();

        notif.notifyUpdate(descriptor);

        verify(securityManager).updateMediator(descriptor.getResult());
        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
    }

    @Test
    public void notificationLog_withRepoError_doesNotLog() throws RepositoryException {
        when(mediatorRepository.queryMediatorName(MEDIATOR_ID)).thenThrow(new RepositoryException());

        notif.notifyChanges(new MediatorActivatedEvent(MEDIATOR_ID));

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(loggerManager, never()).createSystemEventLog(any(BicnetCallContext.class), any(LoggerItem.class));
    }

    @Test
    public void notificationLog_withoutChannelName_doesNotLog() throws RepositoryException {
        when(mediatorRepository.queryMediatorName(MEDIATOR_ID)).thenReturn(Optional.<String>empty());

        notif.notifyChanges(new MediatorActivatedEvent(MEDIATOR_ID));

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(loggerManager, never()).createSystemEventLog(any(BicnetCallContext.class), any(LoggerItem.class));
    }

    @Test
    public void notifyActivated_internalEvent_isProcessed() {
        notif.notifyChanges(new MediatorActivatedEvent(MEDIATOR_ID));

        verifySystemNotificationWithMessage(Message.ACTIVE);
    }

    @Test
    public void notifyActivated_physicalEvent_inactiveInstance_isProcessed() {
        notif.notifyChanges(new MediatorActivatedEvent(MEDIATOR_ID,
                new PhysicalMediatorActivatedEvent(INSTANCE_ID, MEDIATOR_ID, false)));

        verifyClientNotificationWithMessage(Message.ACTIVE);
    }

    @Test
    public void notifyActivated_physicalEvent_activeInstance_isDropped() {
        notif.notifyChanges(new MediatorActivatedEvent(MEDIATOR_ID,
                new PhysicalMediatorActivatedEvent(INSTANCE_ID, MEDIATOR_ID, true)));

        verifyNotificationDropped();
    }

    @Test
    public void notifyDeactivated_internalEvent_isProcessed() {
        notif.notifyChanges(new MediatorDeactivatedEvent(MEDIATOR_ID));

        verifySystemNotificationWithMessage(Message.INACTIVE);
    }

    @Test
    public void notifyDeactivated_physicalEvent_inactiveInstance_isProcessed() {
        notif.notifyChanges(new MediatorDeactivatedEvent(MEDIATOR_ID,
                new PhysicalMediatorDeactivatedEvent(INSTANCE_ID, MEDIATOR_ID, false)));

        verifyClientNotificationWithMessage(Message.INACTIVE);
    }

    @Test
    public void notifyDeactivated_physicalEvent_activeInstance_isDropped() {
        notif.notifyChanges(new MediatorDeactivatedEvent(MEDIATOR_ID,
                new PhysicalMediatorDeactivatedEvent(INSTANCE_ID, MEDIATOR_ID, true)));

        verifyNotificationDropped();
    }

    @Test
    public void notifyActivating_internalEvent_isProcessed() {
        notif.notifyChanges(new MediatorActivatingEvent(MEDIATOR_ID));

        verifySystemNotificationWithMessage(Message.ACTIVATING);
    }

    @Test
    public void notifyActivating_physicalEvent_inactiveInstance_isProcessed() {
        notif.notifyChanges(new MediatorActivatingEvent(MEDIATOR_ID,
                new PhysicalMediatorActivatingEvent(INSTANCE_ID, MEDIATOR_ID, false)));

        verifyClientNotificationWithMessage(Message.ACTIVATING);
    }

    @Test
    public void notifyActivating_physicalEvent_activeInstance_isDropped() {
        notif.notifyChanges(new MediatorActivatingEvent(MEDIATOR_ID,
                new PhysicalMediatorActivatingEvent(INSTANCE_ID, MEDIATOR_ID, true)));

        verifyNotificationDropped();
    }

    @Test
    public void notifyDeactivating_internalEvent_isProcessed() {
        notif.notifyChanges(new MediatorDeactivatingEvent(MEDIATOR_ID));

        verifySystemNotificationWithMessage(Message.DEACTIVATING);
    }

    @Test
    public void notifyDeactivating_physicalEvent_inactiveInstance_isProcessed() {
        notif.notifyChanges(new MediatorDeactivatingEvent(MEDIATOR_ID,
                new PhysicalMediatorDeactivatingEvent(INSTANCE_ID, MEDIATOR_ID, false)));

        verifyClientNotificationWithMessage(Message.DEACTIVATING);
    }

    @Test
    public void notifyDeactivating_physicalEvent_activeInstance_isDropped() {
        notif.notifyChanges(new MediatorDeactivatingEvent(MEDIATOR_ID,
                new PhysicalMediatorDeactivatingEvent(INSTANCE_ID, MEDIATOR_ID, true)));

        verifyNotificationDropped();
    }

    @Test
    public void notifyFailed() {
        notif.notifyChanges(new MediatorActivationFailedEvent(MEDIATOR_ID, "additional info"));

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(loggerManager).createSystemEventLog(systemContext,
            new LoggerItemMediator(MEDIATOR_NAME,
                    tr(Message.MEDIATOR_STATE_CHANGED, Message.FAILED) + " additional info",
                    MessageSeverity.INFO));
    }

    @Test
    public void notifyFailed_withoutMessage() {
        notif.notifyChanges(new MediatorActivationFailedEvent(MEDIATOR_ID));

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(loggerManager).createSystemEventLog(systemContext,
            new LoggerItemMediator(MEDIATOR_NAME,
                    tr(Message.MEDIATOR_STATE_CHANGED, Message.FAILED) + " ",
                    MessageSeverity.INFO));
    }

    @Test
    public void testCreateInstance() throws Exception {

        final MediatorInstance inst = new MediatorInstance(
                new MediatorPhysicalData.MediatorPhysicalDataBuilder().build(10, 1, 0),
                new MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder().setActive(false).build(10, 1, 0)
        );

        notif.notifyCreateInstance(inst);

        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
    }

    @Test
    public void testUpdateInstance_active() throws Exception {

        final MediatorInstance instance = new MediatorInstance(
                new MediatorPhysicalData.MediatorPhysicalDataBuilder().build(10, 1, 0),
                new MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder().setActive(true).build(10, 1, 0)
        );

        notif.notifyUpdateInstance(instance);

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
    }

    @Test
    public void testUpdateInstance_inactive() throws Exception {

        final MediatorInstance instance = new MediatorInstance(
                new MediatorPhysicalData.MediatorPhysicalDataBuilder().build(10, 1, 0),
                new MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder().setActive(false).build(10, 1, 0)
        );

        notif.notifyUpdateInstance(instance);

        verify(messageDispatcher, never()).sendToSource(isA(IBiCNetMessage.class), eq(false));
    }

    @Test
    public void testDeleteInstance() throws Exception {

        notif.notifyDeleteInstance(1, 10);

        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
    }

    private void verifySystemNotificationWithMessage(Message message) {
        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
        verify(loggerManager).createSystemEventLog(systemContext,
            new LoggerItemMediator(MEDIATOR_NAME,
                    tr(Message.MEDIATOR_STATE_CHANGED, message) + " ",
                    MessageSeverity.INFO));
    }

    private void verifyClientNotificationWithMessage(Message message) {
        verify(messageDispatcher).sendToClient(isA(IBiCNetMessage.class));
        verify(loggerManager).createSystemEventLog(systemContext,
            new LoggerItemMediator(MEDIATOR_NAME,
                    tr(Message.MEDIATOR_STATE_CHANGED, message) + "  (standby)",
                    MessageSeverity.INFO));
    }

    private void verifyNotificationDropped() {
        verify(messageDispatcher, never()).sendToSource(isA(IBiCNetMessage.class), anyBoolean());
        verify(messageDispatcher, never()).sendToClient(isA(IBiCNetMessage.class));
        verify(loggerManager, never()).createSystemEventLog(any(BicnetCallContext.class), isA(LoggerItemMediator.class));
    }

}
