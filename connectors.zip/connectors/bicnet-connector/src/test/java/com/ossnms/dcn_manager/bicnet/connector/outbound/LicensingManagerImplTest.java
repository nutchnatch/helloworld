package com.ossnms.dcn_manager.bicnet.connector.outbound;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.ossnms.bicnet.bcb.facade.licensing.ILicenseMgrFacade;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.platform.PlatformException;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LicensingManagerImpl;
import com.ossnms.dcn_manager.composables.outbound.exception.LicenseException;

public class LicensingManagerImplTest {
    
    private ILicenseMgrFacade licenseMgrFacade;
    private BicnetCallContext context;
    private LicensingManagerImpl licensingManager;
    
    @Before
    public void setup() throws PlatformException, UnsupportedOperationException {
        licenseMgrFacade = mock(ILicenseMgrFacade.class);
        context = mock(BicnetCallContext.class);

        licensingManager = new LicensingManagerImpl(licenseMgrFacade);
    }

    @Test
    public void testReleaseLicensePresent()  throws LicenseException, BcbException {
        licensingManager.releaseLicense(context, "mKey");
        
        verify(licenseMgrFacade, Mockito.times(1)).releaseLicense(context.getSessionContext(), "mKey");    
    }
    
    @Test(expected=LicenseException.class)
    public void testReleaseLicenseMoNull() throws LicenseException, BcbException {
        licensingManager.releaseLicense(context, null);
    }
}
