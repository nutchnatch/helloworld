package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommissioningStatusSummary;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.elementMgmt.InitState;
import com.ossnms.bicnet.bcb.model.elementMgmt.NeFamily;
import com.ossnms.bicnet.bcb.model.elementMgmt.NeSubType;
import com.ossnms.bicnet.bcb.model.elementMgmt.TpGroupMode;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeActivationState;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.ne.data.types.CommissioningMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.OperationalMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.TpGroupSettings;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.i18n.Message;
import org.junit.Test;

import java.util.Collections;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb.convertCommissioningMode;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb.convertNeFamily;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb.convertOperationalMode;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb.convertToNeSubType;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb.convertToNeType;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb.convertTpGroupSettings;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb.describe;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb.tryConvertToActualActivationState;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.isEmptyOrNullString;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class ConvertNeToBcbTest {

    @Test
    public void testDisplayStateFromActiveInstance() throws Exception {

        final NeType type = MockFactory.mockNeType();
        when(type.getDefaultIcon()).thenReturn("i");

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().setActivationState(ActualActivationState.DISCONNECTED).build(1, 1),
                new NeOperationBuilder().build(1, 1),
                new NeInfoBuilder().setProxyType("t").build(1, 10, 1),
                new NeSynchronizationBuilder().build(1, 1),
                new NeUserPreferencesBuilder().setName("n").setPassword(Optional.of("00010203")).build(1, 1));

        INE ine = ConvertNeToBcb.convert(type, entity, Collections.emptyList(), ImmutableList.of(
                new NePhysicalConnectionBuilder()
                    .setActivationState(ActualActivationState.STARTUP)
                    .setActive(true)
                    .build(1000, 1, 10, 0),
                new NePhysicalConnectionBuilder()
                    .setActivationState(ActualActivationState.INITIALIZED)
                    .setActive(false)
                    .build(2000, 1, 10, 0)
        ));
        assertThat(ine.getActualActivationState(), is(NeActivationState.INACTIVE));
        assertThat(ine.getDisplayState(), is(Message.STARTING_UP.toString()));
    }

    @Test
    public void testDisplayStateFromActiveInstance_noActiveInstance_useStateFromLogicalInstance() throws Exception {

        final NeType type = MockFactory.mockNeType();
        when(type.getDefaultIcon()).thenReturn("i");

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().setActivationState(ActualActivationState.DISCONNECTED).build(1, 1),
                new NeOperationBuilder().build(1, 1),
                new NeInfoBuilder().setProxyType("t").build(1, 10, 1),
                new NeSynchronizationBuilder().build(1, 1),
                new NeUserPreferencesBuilder().setName("n").setPassword(Optional.of("00010203")).build(1, 1));

        INE ine = ConvertNeToBcb.convert(type, entity, Collections.emptyList(), Collections.singleton(
                new NePhysicalConnectionBuilder()
                        .setActivationState(ActualActivationState.STARTUP)
                        .setActive(false)
                        .build(1000, 1, 10, 0)
        ));
        assertThat(ine.getActualActivationState(), is(NeActivationState.INACTIVE));
        assertThat(ine.getDisplayState(), is(Message.INACTIVE.toString()));
    }

    @Test
    public void testDisplayStateFromActiveInstance_noPhysicalInstances_useStateFromLogicalInstance() throws Exception {

        final NeType type = MockFactory.mockNeType();
        when(type.getDefaultIcon()).thenReturn("i");

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().setActivationState(ActualActivationState.DISCONNECTED).build(1, 1),
                new NeOperationBuilder().build(1, 1),
                new NeInfoBuilder().setProxyType("t").build(1, 10, 1),
                new NeSynchronizationBuilder().build(1, 1),
                new NeUserPreferencesBuilder().setName("n").setPassword(Optional.of("00010203")).build(1, 1));

        INE ine = ConvertNeToBcb.convert(type, entity, Collections.emptyList(), Collections.emptyList());
        assertThat(ine.getActualActivationState(), is(NeActivationState.INACTIVE));
        assertThat(ine.getDisplayState(), is(Message.INACTIVE.toString()));
    }

    @Test
    public void testLoginPasswordBinaryFormat() throws Exception {

        final NeType type = MockFactory.mockNeType();
        when(type.getDefaultIcon()).thenReturn("i");

        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().build(1, 1),
                new NeOperationBuilder().build(1, 1),
                new NeInfoBuilder().setProxyType("t").build(1, 10, 1),
                new NeSynchronizationBuilder().build(1, 1),
                new NeUserPreferencesBuilder().setName("n").setPassword(Optional.of("00010203")).build(1, 1));

        final INE ine = ConvertNeToBcb.convert(type, entity, Collections.emptyList());

        assertThat(ine.getLoginPasswordMd5(), is(new byte[] { 0, 1, 2, 3 }));
    }

    @Test
    public void testTryConvertToActualActivationState() {
        assertThat(tryConvertToActualActivationState(CommunicationState.CONNECTING, InitState.NOT_INITIALIZED), hasValue(ActualActivationState.CONNECTING));
        assertThat(tryConvertToActualActivationState(CommunicationState.CONNECTED, InitState.NOT_INITIALIZED), hasValue(ActualActivationState.CONNECTED));
        assertThat(tryConvertToActualActivationState(CommunicationState.CONNECTED, InitState.INITIALIZING), hasValue(ActualActivationState.INITIALIZING));
        assertThat(tryConvertToActualActivationState(CommunicationState.CONNECTED, InitState.INITIALIZED), hasValue(ActualActivationState.INITIALIZED));
        assertThat(tryConvertToActualActivationState(CommunicationState.DISCONNECTING, InitState.SHUTTING_DOWN), hasValue(ActualActivationState.DISCONNECTING));
        assertThat(tryConvertToActualActivationState(CommunicationState.DISCONNECTED, InitState.NOT_INITIALIZED), hasValue(ActualActivationState.DISCONNECTED));
        assertThat(tryConvertToActualActivationState(CommunicationState.FAILED, InitState.FAILED), hasValue(ActualActivationState.FAILED));

        // unsupported example
        assertThat(tryConvertToActualActivationState(CommunicationState.FAILED, InitState.INITIALIZED), is(absent()));
    }

    @Test
    public void testDescribe() {
        for (final ActualActivationState actualActivationState : ActualActivationState.values()) {
            assertThat(describe(actualActivationState), not(isEmptyOrNullString()));
        }
    }

    @Test
    public void testDescribe_activating() {
        assertThat(describe(ActualActivationState.INITIALIZING), is("Activating"));
        assertThat(describe(ActualActivationState.CONNECTING), is("Activating"));
        assertThat(describe(ActualActivationState.CONNECTED), is("Activating"));
    }

    @Test
    public void testDescribe_active() {
        assertThat(describe(ActualActivationState.INITIALIZED), is("Active"));
    }

    @Test
    public void testDescribe_inactive() {
        assertThat(describe(ActualActivationState.DISCONNECTED), is("Inactive"));
    }

    @Test
    public void testDescribe_Deactivating() {
        assertThat(describe(ActualActivationState.DISCONNECTING), is("Deactivating"));
    }

    @Test
    public void testDescribe_starting_up() {
        assertThat(describe(ActualActivationState.STARTUP), is("Activating"));
    }

    @Test
    public void testDescribe_shutting_down() {
        assertThat(describe(ActualActivationState.SHUTDOWN), is("Deactivating"));
    }

    @Test
    public void testConvertToNeSubType() {
        assertThat(convertToNeSubType(Optional.of("SBOADM_CH44_NANO")), is(NeSubType.SBOADM_CH44_NANO));
    }

    @Test
    public void testConvertToNeSubType_defaultValue() {
        assertThat(convertToNeSubType(Optional.empty()), is(NeSubType.NOT_APPLICABLE));
    }

    @Test
    public void testConvertToNeType() {
        assertThat(convertToNeType(Optional.of("_7050")), is(com.ossnms.bicnet.bcb.model.elementMgmt.NeType._7050));
    }

    @Test
    public void testConvertToNeType_defaultValue() {
        assertThat(convertToNeType(Optional.empty()), is(com.ossnms.bicnet.bcb.model.elementMgmt.NeType.NOT_APPLICABLE));
    }

    @Test
    public void testConvertNeFamily() {
        assertThat(convertNeFamily(Optional.of("hiT7300")), is(NeFamily.HI_T7300));
    }

    @Test
    public void testConvertNeFamily_defaultValue() {
        assertThat(convertNeFamily(Optional.empty()), is(NeFamily.NOT_APPLICABLE));
    }

    @Test
    public void testConvertOperationalMode() {
        assertThat(convertOperationalMode(Optional.of(OperationalMode.ENABLED)), is(OperationalState.ENABLED));
    }

    @Test
    public void testConvertOperationalMode_defaultValue() {
        assertThat(convertOperationalMode(Optional.empty()), is(OperationalState.NOT_APPLICABLE));
    }

    @Test
    public void testConvertCommissioningMode() {
        assertThat(convertCommissioningMode(Optional.of(CommissioningMode.NOT_COMMISSIONED)), is(CommissioningStatusSummary.NOT_COMMISSIONED));
    }

    @Test
    public void testConvertCommissioningMode_defaultValue() {
        assertThat(convertCommissioningMode(Optional.empty()), is(CommissioningStatusSummary.COMMISSIONED));
    }

    @Test
    public void testConvertTpGroupSettings() {
        final TpGroupMode mode = convertTpGroupSettings(Optional.of(new TpGroupSettings(true,true,true,true)));

        assertThat(mode.getAlwaysCompatible(), is(true));
        assertThat(mode.getMultipleGroupMembership(), is(true));
        assertThat(mode.getSubgroupsMustBeEqual(), is(true));
        assertThat(mode.getMultipleGroupMembership(), is(true));
    }

    @Test
    public void testConvertTpGroupSettings_defaultValue() {
        final TpGroupMode mode = convertTpGroupSettings(Optional.empty());

        assertThat(mode.getAlwaysCompatible(), is(true));
        assertThat(mode.getMultipleGroupMembership(), is(false));
        assertThat(mode.getSubgroupsMustBeEqual(), is(false));
        assertThat(mode.getMultipleGroupMembership(), is(false));
    }
}
