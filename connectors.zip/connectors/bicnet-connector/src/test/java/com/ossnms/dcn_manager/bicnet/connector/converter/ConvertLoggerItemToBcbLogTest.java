package com.ossnms.dcn_manager.bicnet.connector.converter;

import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToCommandLog.LOG_COMMAND_ID;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToImportHistory.LOG_IMPORT_ID;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToNetworkEventLog.LOG_EVENT_ID;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToNetworkResourceLog.LOG_RESOURCE_ID;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToSystemEventLog.LOG_SEL_ID;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertSeverityToBcb.convertSeverity;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import org.junit.Assert;

import org.junit.Before;
import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.logMgmt.CommandLogRecordItem;
import com.ossnms.bicnet.bcb.facade.logMgmt.ImportExportLogRecordItem;
import com.ossnms.bicnet.bcb.facade.logMgmt.NeEventLogRecordItem;
import com.ossnms.bicnet.bcb.facade.logMgmt.NeResourceEventLogRecordItem;
import com.ossnms.bicnet.bcb.facade.logMgmt.SystemEventLogRecordItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.logMgmt.LogSeverity;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToCommandLog;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToImportHistory;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToNetworkEventLog;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToNetworkResourceLog;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToSystemEventLog;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemImportHistory;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;

public class ConvertLoggerItemToBcbLogTest {
    private static final BiCNetComponentType COMPONENT_EMNE = BiCNetComponentType.DCN_MANAGER;

    private static final int AFFECTED_OBJECT_ID = 1;
    private static final String AFFECTED_OBJECT = "Name";
    private static final String MESSAGE = "Message";
    private static final String USER_NAME = "UserName";
        
    private ISessionContext context;
    
    @Before
    public void setup() {
        context = mock(ISessionContext.class);
        when(context.getUserName()).thenReturn(USER_NAME);        
    }

    @Test
    public void testToSystemEventLogItemNe() {
        final SystemEventLogRecordItem item = new ConvertLoggerToSystemEventLog(USER_NAME).convert(getLoggerItemNe());

        assertThat(item.getBelonging(), is(LOG_SEL_ID));
        assertThat(item.getBelongingName(), is(LOG_SEL_ID.getName()));
        
        assertThat(item.getAffectedObject(), containsString(AFFECTED_OBJECT));
        assertThat(item.getComponent(), is(COMPONENT_EMNE));
        assertThat(item.getUserName(), is(USER_NAME));
        assertThat(item.getDescription(), is(MESSAGE));
        
        assertThat(item.getSeverity(), is(LogSeverity.WARNING));
    }
    
    @Test
    public void testNullConvertLoggerToSystemEventLog() {
        final ConvertLoggerToSystemEventLog item = new ConvertLoggerToSystemEventLog(USER_NAME);       
        Assert.assertNull(item.apply(null));
    }

    @Test
    public void testToCommandLogItemNe() {
        final CommandLogRecordItem item = new ConvertLoggerToCommandLog(USER_NAME).convert(getLoggerItemNe());

        assertThat(item.getBelonging(), is(LOG_COMMAND_ID));
        assertThat(item.getBelongingName(), is(LOG_COMMAND_ID.getName()));
        
        assertThat(item.getAffectedObject(), containsString(AFFECTED_OBJECT));
        assertThat(item.getComponent(), is(COMPONENT_EMNE));        
        assertThat(item.getUserName(), is(USER_NAME));
        assertThat(item.getDescription(), is(MESSAGE));
    }
    
    @Test
    public void testNullConvertLoggerToCommandLog() {
        final ConvertLoggerToCommandLog item = new ConvertLoggerToCommandLog(USER_NAME);       
        Assert.assertNull(item.apply(null));
    }

    @Test
    public void testToNetworkEventLog() {
        final NeEventLogRecordItem item = new ConvertLoggerToNetworkEventLog(USER_NAME).convert(getLoggerItemNe());
        
        assertThat(item.getBelonging(), is(LOG_EVENT_ID));
        assertThat(item.getBelongingName(), is(LOG_EVENT_ID.getName()));
        
        assertThat(item.getAffectedNeName(), containsString(AFFECTED_OBJECT));
        assertThat(item.getAffectedNe(), is(AFFECTED_OBJECT_ID));
        
        assertThat(item.getUserName(), is(USER_NAME));
        assertThat(item.getDescription(), is(MESSAGE));               
    }
    
    @Test
    public void testNullConvertLoggerToNetworkEventLog() {
        final ConvertLoggerToNetworkEventLog item = new ConvertLoggerToNetworkEventLog(USER_NAME);       
        Assert.assertNull(item.apply(null));
    }
    
    @Test
    public void testToNetworkResourceLog() {
        final NeResourceEventLogRecordItem item = new ConvertLoggerToNetworkResourceLog(USER_NAME).convert(getLoggerItemNe());
        
        assertThat(item.getBelonging(), is(LOG_RESOURCE_ID));
        assertThat(item.getBelongingName(), is(LOG_RESOURCE_ID.getName()));
        
        assertThat(item.getAffectedObject(), containsString(AFFECTED_OBJECT));
        assertThat(item.getAffectedNeName(), containsString(AFFECTED_OBJECT));
        assertThat(item.getAffectedNe(), is(AFFECTED_OBJECT_ID));
        
        assertThat(item.getUserName(), is(USER_NAME));
        assertThat(item.getDescription(), is(MESSAGE));               
    }
    
    @Test
    public void testNullConvertLoggerToNetworkResourceLog() {
        final ConvertLoggerToNetworkResourceLog item = new ConvertLoggerToNetworkResourceLog(USER_NAME);       
        Assert.assertNull(item.apply(null));
    }
    
    @Test
    public void testToImportHistoryLog() {
        final ImportExportLogRecordItem item = ConvertLoggerToImportHistory.convert(getLoggerItemImportHistory());
        
        assertThat(item.getBelonging(), is(LOG_IMPORT_ID));
        assertThat(item.getBelongingName(), is(LOG_IMPORT_ID.getName()));
        assertThat(item.getComponent(), is(COMPONENT_EMNE)); 
        
        assertThat(item.getAffectedObject(), containsString(AFFECTED_OBJECT));        
        assertThat(item.getExecutionId(), is(AFFECTED_OBJECT_ID));
        assertThat(item.getDescription(), is(MESSAGE));
        
        assertThat(item.getSeverity(), is(LogSeverity.ERROR));
    }
    
    @Test
    public void testNullConvertLoggerToImportHistory() {
        final ConvertLoggerToImportHistory item = new ConvertLoggerToImportHistory();       
        Assert.assertNull(item.apply(null));
    }

    @Test
    public void testToLogSeverity() {        
        assertThat(convertSeverity(MessageSeverity.ERROR), is(LogSeverity.ERROR));
        assertThat(convertSeverity(MessageSeverity.WARNING), is(LogSeverity.WARNING));
        assertThat(convertSeverity(MessageSeverity.INFO), is(LogSeverity.INFO));
        assertThat(convertSeverity(MessageSeverity.MESSAGE), is(LogSeverity.MESSAGE));
    }
    
    private LoggerItemNe getLoggerItemNe() {
        return new LoggerItemNe(AFFECTED_OBJECT, MESSAGE, AFFECTED_OBJECT_ID,
                MessageSeverity.WARNING);
    }
    
    private LoggerItemImportHistory getLoggerItemImportHistory() {
        return new LoggerItemImportHistory(AFFECTED_OBJECT, MESSAGE, MessageSeverity.ERROR, AFFECTED_OBJECT_ID);
    }
}
