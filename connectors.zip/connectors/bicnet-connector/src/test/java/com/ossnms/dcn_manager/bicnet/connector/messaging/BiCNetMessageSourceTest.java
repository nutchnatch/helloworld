package com.ossnms.dcn_manager.bicnet.connector.messaging;

import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;
import com.codahale.metrics.Timer.Context;
import com.ossnms.bicnet.bcb.messaging.direct.IBiCNetDirectMessageDispatcher;
import com.ossnms.bicnet.bcb.messaging.direct.IBiCNetDirectMessageDispatcherFactory;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.Notification;
import com.ossnms.bicnet.messaging.util.BiCNetMessageBuilder;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;

import rx.Subscription;
import rx.functions.Action1;

@RunWith(MockitoJUnitRunner.class)
public class BiCNetMessageSourceTest {

    @Mock private MetricRegistry registry;
    @Mock private IBiCNetDirectMessageDispatcherFactory directMessageDispatcherFactory;
    @Mock private IBiCNetDirectMessageDispatcher directMessageDispatcher;

    @Mock private MediatorInstanceEntityRepository mediatorInstances;
    @Mock private NePhysicalConnectionRepository neInstances;
    @Mock private ChannelPhysicalConnectionRepository channelInstances;

    @InjectMocks private BiCNetMessageSource source;

    @Before
    public void setUp() {

        final Timer timer = mock(Timer.class);
        final Context timercontext = mock(Context.class);
        when(timer.time()).thenReturn(timercontext);

        when(registry.timer(anyString())).thenReturn(timer);

        when(directMessageDispatcherFactory.getDispatcher(BiCNetComponentType.DCN_MANAGER.toString()))
            .thenReturn(directMessageDispatcher);

        source.initialize();
    }

    @Test
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void testPushMessage_layeredDelivery() {

        final Notification notif = new AttributeValueChange(new Date(), null);
        final Action1 action = mock(Action1.class);

        source.observe()
            .subscribe(action);

        source.pushMessage(
                new BiCNetMessageBuilder().withPayload(new Notification[] { notif }).build());

        final ArgumentCaptor<DecoratedNotification> notifCaptor = ArgumentCaptor.forClass(DecoratedNotification.class);
        verify(action).call(notifCaptor.capture());
        assertThat(notifCaptor.getValue(), is(new DecoratedNotification(notif)));
    }

    @Test
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void testPushMessage_directDelivery() throws BcbException {

        final Notification notif = new AttributeValueChange(new Date(), null);
        final Action1 action = mock(Action1.class);

        source.observe()
            .subscribe(action);

        source.onMessage(null,
                new BiCNetMessageBuilder().withPayload(new Notification[] { notif }).build());

        final ArgumentCaptor<DecoratedNotification> notifCaptor = ArgumentCaptor.forClass(DecoratedNotification.class);
        verify(action).call(notifCaptor.capture());
        assertThat(notifCaptor.getValue(), is(new DecoratedNotification(notif)));

        verify(directMessageDispatcher).register(source);
    }

    @Test
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void testPushMessageArray() {

        final Notification notif1 = new AttributeValueChange(new Date(), null);
        final Notification notif2 = new AttributeValueChange(new Date(), null);
        final Action1 action = mock(Action1.class);

        source.observe()
            .subscribe(action);

        source.pushMessage(
                new BiCNetMessageBuilder().withPayload(new Notification[] { notif1, notif2 }).build());

        final ArgumentCaptor<DecoratedNotification> notifCaptor = ArgumentCaptor.forClass(DecoratedNotification.class);
        verify(action, times(2)).call(notifCaptor.capture());
        assertThat(notifCaptor.getAllValues(), hasItems(new DecoratedNotification(notif1), new DecoratedNotification(notif2)));
    }

    @Test
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void testUnsubscribe() {

        final Notification notif = new AttributeValueChange(new Date(), null);
        final Action1 action = mock(Action1.class);

        final Subscription subscription = source.observe()
            .subscribe(action);

        source.pushMessage(
                new BiCNetMessageBuilder().withPayload(new Notification[] { notif }).build());

        subscription.unsubscribe();

        source.pushMessage(
                new BiCNetMessageBuilder().withPayload(new Notification[] { notif }).build());

        verify(action).call(any());
    }

    @Test
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void testPushSomethingElse() {

        final Action1 action = mock(Action1.class);

        source.observe()
            .subscribe(action);

        source.pushMessage(
                new BiCNetMessageBuilder().withPayload("anything").build());

        verifyZeroInteractions(action);
    }

}
