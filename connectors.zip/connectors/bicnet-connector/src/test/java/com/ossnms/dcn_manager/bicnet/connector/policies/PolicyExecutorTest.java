package com.ossnms.dcn_manager.bicnet.connector.policies;

import com.ossnms.dcn_manager.core.test.RunRunnableAnswer;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.enterprise.concurrent.ManagedExecutorService;
import java.util.Observable;
import java.util.Observer;

import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PolicyExecutorTest {

    @Mock private ManagedExecutorService baseExecutor;

    @InjectMocks private PolicyExecutor executor;

    @Before
    public void setUp() throws Exception {
        doAnswer(new RunRunnableAnswer()).when(baseExecutor).execute(isA(Runnable.class));
        executor.initialize();
    }

    @Test
    public void execute() throws Exception {

        final Runnable task = mock(Runnable.class);
        executor.execute(task);

        verify(task).run();
    }

    @Test
    public void execute_andNotify() throws Exception {

        final Runnable task = mock(Runnable.class);
        final Observer observer = mock(Observer.class);

        executor.addObserver(observer);
        executor.execute(task);

        verify(task).run();
        verify(observer).update(isA(Observable.class), isNull());
    }

    @Test
    public void execute_removedObserver_doesNotNotify() throws Exception {

        final Runnable task = mock(Runnable.class);
        final Observer observer = mock(Observer.class);

        executor.addObserver(observer);
        executor.deleteObserver(observer);

        executor.execute(task);

        verify(task).run();
        verify(observer, never()).update(isA(Observable.class), isNull());
    }
}