package com.ossnms.dcn_manager.bicnet.connector.outbound.notifications;

import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.dcn_manager.composables.outbound.SecurityManager;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfoMutationDescriptor;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;

import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class SystemNotificationsManagerImplTest {

    private static final String NAME = "name";
    private static final int CONTAINER_ID = 1;

    @Mock private SecurityManager securityManager;

    @Mock private IBiCNetMessageDispatcher messageDispatcher;

    @InjectMocks private SystemNotificationsManagerImpl containerNotifications;

    @Test
    public void onCreate() throws Exception {
        containerNotifications.notifyCreate(new SystemInfo(CONTAINER_ID, 0, NAME));

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
    }

    @Test
    public void onDelete() throws Exception {
        containerNotifications.notifyDelete(new SystemInfo(CONTAINER_ID, 0, NAME));

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
    }

    @Test
    public void onUpdate() throws Exception {
        final SystemInfoMutationDescriptor mutation = new SystemInfoMutationDescriptor (
                new SystemInfo(CONTAINER_ID, 0, NAME)).setName("new name").setDescription(Optional.of("description"))
                .setUserText(Optional.of("userText")).setParentId(99);

        mutation.apply();

        containerNotifications.notifyChanges(mutation);

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(securityManager, times(1)).updateSystem(mutation.apply());
    }
}
