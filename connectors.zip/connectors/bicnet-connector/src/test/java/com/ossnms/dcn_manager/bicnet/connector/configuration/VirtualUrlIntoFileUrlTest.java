package com.ossnms.dcn_manager.bicnet.connector.configuration;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;

import org.junit.Test;

import com.ossnms.dcn_manager.bicnet.connector.configuration.VirtualUrlIntoFileUrl;

public class VirtualUrlIntoFileUrlTest {

    private static final String FILE = "/f";
    private static final String HOST = "h";

    private static final URLStreamHandler URL_HANDLER = new URLStreamHandler() {
        @Override
        protected URLConnection openConnection(URL u) throws IOException {
            return null;
        }
    };

    @Test
    public void testNullInput() {
        assertNull(new VirtualUrlIntoFileUrl().apply(null));
    }

    @Test
    public void testVfs() throws MalformedURLException {
        final URL result = new VirtualUrlIntoFileUrl().apply(buildUrl("vfs"));
        validateResultUrl(result);
    }

    @Test
    public void testVfsZip() throws MalformedURLException {
        final URL result = new VirtualUrlIntoFileUrl().apply(buildUrl("vfszip"));
        validateResultUrl(result);
    }

    @Test
    public void testVfsFile() throws MalformedURLException {
        final URL result = new VirtualUrlIntoFileUrl().apply(buildUrl("vfsfile"));
        validateResultUrl(result);
    }

    @Test
    public void testJarWithSlash() throws MalformedURLException {
        final URL result = new VirtualUrlIntoFileUrl().apply(new URL("vfsfile", HOST, -1, "/some.jar/", URL_HANDLER));
        assertThat(result.getProtocol(), is("file"));
        assertThat(result.getHost(), is(HOST));
        assertThat(result.getFile(), is("/some.jar!/"));
    }

    private void validateResultUrl(URL result) {
        assertThat(result.getProtocol(), is("file"));
        assertThat(result.getHost(), is(HOST));
        assertThat(result.getFile(), is(FILE));
    }

    private URL buildUrl(String protocol) throws MalformedURLException {
        return new URL(protocol, HOST, -1, FILE, URL_HANDLER);
    }

}
