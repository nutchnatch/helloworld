package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.dcn_manager.connector.storage.channel.InMemoryChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.connector.storage.ne.InMemoryNePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.List;

import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.emptyIterable;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.iterableWithSize;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class StandbyHelperTest {

    private MediatorEntityRepository mediatorRepository;
    private MediatorInstanceEntityRepository mediatorInstanceRepository;
    private ChannelEntityRepository channelRepository;
    private ChannelPhysicalConnectionRepository channelInstanceRepository;
    private NeEntityRepository neRepository;
    private NePhysicalConnectionRepository neInstanceRepository;

    private MediatorEntityRepository.MediatorInfoRepository mediatorInfoRepository;
    private ChannelEntityRepository.ChannelInfoRepository channelInfoRepository;
    private NeEntityRepository.NeInfoRepository neInfoRepository;
    private MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository mediatorPhysicalConnectionRepository;

    private ArgumentCaptor<MediatorPhysicalConnectionMutationDescriptor> mediatorPhysicalCaptor;

    private StandbyHelper helper;

    @Before
    public void setUp() throws Exception {
        mediatorRepository = mock(MediatorEntityRepository.class);
        mediatorInstanceRepository = mock(MediatorInstanceEntityRepository.class);
        channelRepository = mock(ChannelEntityRepository.class);
        channelInstanceRepository = new InMemoryChannelPhysicalConnectionRepository();
        neRepository = mock(NeEntityRepository.class);
        neInstanceRepository = new InMemoryNePhysicalConnectionRepository();

        mediatorInfoRepository = mock(MediatorEntityRepository.MediatorInfoRepository.class);
        channelInfoRepository = mock(ChannelEntityRepository.ChannelInfoRepository.class);
        neInfoRepository = mock(NeEntityRepository.NeInfoRepository.class);
        mediatorPhysicalConnectionRepository = mock(MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository.class);

        mediatorPhysicalCaptor = ArgumentCaptor.forClass(MediatorPhysicalConnectionMutationDescriptor.class);

        when(mediatorRepository.getMediatorInfoRepository()).thenReturn(mediatorInfoRepository);
        when(channelRepository.getChannelInfoRepository()).thenReturn(channelInfoRepository);
        when(neRepository.getNeInfoRepository()).thenReturn(neInfoRepository);
        when(mediatorInstanceRepository.getMediatorPhysicalConnectionRepository()).thenReturn(mediatorPhysicalConnectionRepository);

        helper = new StandbyHelper(mediatorRepository, mediatorInstanceRepository, channelRepository,
                channelInstanceRepository, neRepository, neInstanceRepository);

    }

    @Test(expected = BcbException.class)
    public void configurePrimary_repoError_propagates() throws Exception {

        when(channelInfoRepository.queryAll()).thenThrow(new RepositoryException());

        helper.configureStandbyMediatorInstances(MediatorInstance.PRIMARY_PRIORITY_LEVEL);
    }

    @Test
    public void configurePrimary_noMediators_doesNothing() throws Exception {

        when(mediatorInfoRepository.queryAll()).thenReturn(Collections.emptyList());
        when(channelInfoRepository.queryAll()).thenReturn(Collections.emptyList());
        when(neInfoRepository.queryAll()).thenReturn(Collections.emptyList());
        when(mediatorInstanceRepository.queryAll(1)).thenReturn(Collections.emptyList());

        helper.configureStandbyMediatorInstances(MediatorInstance.PRIMARY_PRIORITY_LEVEL);

        verify(mediatorPhysicalConnectionRepository, never()).tryUpdate(mediatorPhysicalCaptor.capture());
        assertThat(channelInstanceRepository.queryAll(), is(emptyIterable()));
        assertThat(neInstanceRepository.queryAll(), is(emptyIterable()));
    }

    @Test
    public void configureSecondary_noMediators_doesNothing() throws Exception {

        when(mediatorInfoRepository.queryAll()).thenReturn(Collections.emptyList());
        when(channelInfoRepository.queryAll()).thenReturn(Collections.emptyList());
        when(neInfoRepository.queryAll()).thenReturn(Collections.emptyList());
        when(mediatorInstanceRepository.queryAll(1)).thenReturn(Collections.emptyList());

        helper.configureStandbyMediatorInstances(MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1);

        verify(mediatorPhysicalConnectionRepository, never()).tryUpdate(mediatorPhysicalCaptor.capture());
        assertThat(channelInstanceRepository.queryAll(), is(emptyIterable()));
        assertThat(neInstanceRepository.queryAll(), is(emptyIterable()));
    }

    @Test
    public void configurePrimary_twoInstances_activatesPrimary() throws Exception {

        when(mediatorInfoRepository.queryAll()).thenReturn(Collections.singleton(buildMediatorInfo(1)));
        when(channelInfoRepository.queryAll()).thenReturn(Collections.singleton(buildChannelInfo(1, 1)));
        when(neInfoRepository.queryAll()).thenReturn(Collections.singleton(buildNeInfo(1, 1)));
        when(mediatorInstanceRepository.queryAll(1)).thenReturn(ImmutableList.of(
                buildMediatorInstance(1, 1, MediatorInstance.PRIMARY_PRIORITY_LEVEL),
                buildMediatorInstance(2, 1, MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1)
            ));

        when(mediatorPhysicalConnectionRepository.tryUpdate(any())).then(new MutationAnswer<>());

        helper.configureStandbyMediatorInstances(MediatorInstance.PRIMARY_PRIORITY_LEVEL);

        verify(mediatorPhysicalConnectionRepository, times(2)).tryUpdate(mediatorPhysicalCaptor.capture());

        final List<MediatorPhysicalConnectionMutationDescriptor> mediatorPhysicalConnections =
                mediatorPhysicalCaptor.getAllValues();
        assertThat(mediatorPhysicalConnections, hasSize(2));
        assertThat(mediatorPhysicalConnections.get(0).getResult().isActive(), is(true));
        assertThat(mediatorPhysicalConnections.get(0).getResult().getId(), is(1)); // sanity check
        assertThat(mediatorPhysicalConnections.get(1).getResult().isActive(), is(false));
        assertThat(mediatorPhysicalConnections.get(1).getResult().getId(), is(2)); // sanity check

        final Iterable<ChannelPhysicalConnectionData> channelConnections = channelInstanceRepository.queryAll();
        assertThat(channelConnections, is(iterableWithSize(2)));
        assertThat(channelConnections, hasItems( // we're relying on knowing about ID generation at the repo... not ideal but ok for the time being.
                new ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder()
                    .setActive(true).build(1, 1, 1, 0),
                new ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder()
                    .setActive(false).build(2, 1, 1, 0)
        ));

        final Iterable<NePhysicalConnectionData> neConnections = neInstanceRepository.queryAll();
        assertThat(neConnections, is(iterableWithSize(2)));
        assertThat(neConnections, hasItems(
                new NePhysicalConnectionData.NePhysicalConnectionBuilder()
                    .setActive(true).build(1, 1, 1, 0),
                new NePhysicalConnectionData.NePhysicalConnectionBuilder()
                    .setActive(false).build(2, 1, 2, 0)
        ));
    }

    @Test
    public void configureSecondary_twoInstances_activatesSecondary() throws Exception {

        when(mediatorInfoRepository.queryAll()).thenReturn(Collections.singleton(buildMediatorInfo(1)));
        when(channelInfoRepository.queryAll()).thenReturn(Collections.singleton(buildChannelInfo(1, 1)));
        when(neInfoRepository.queryAll()).thenReturn(Collections.singleton(buildNeInfo(1, 1)));
        when(mediatorInstanceRepository.queryAll(1)).thenReturn(ImmutableList.of(
                buildMediatorInstance(1, 1, MediatorInstance.PRIMARY_PRIORITY_LEVEL),
                buildMediatorInstance(2, 1, MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1)
        ));

        when(mediatorPhysicalConnectionRepository.tryUpdate(any())).then(new MutationAnswer<>());

        helper.configureStandbyMediatorInstances(MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1);

        verify(mediatorPhysicalConnectionRepository, times(2)).tryUpdate(mediatorPhysicalCaptor.capture());

        final List<MediatorPhysicalConnectionMutationDescriptor> mediatorPhysicalConnections =
                mediatorPhysicalCaptor.getAllValues();
        assertThat(mediatorPhysicalConnections, hasSize(2));
        assertThat(mediatorPhysicalConnections.get(0).getResult().isActive(), is(false));
        assertThat(mediatorPhysicalConnections.get(0).getResult().getId(), is(1)); // sanity check
        assertThat(mediatorPhysicalConnections.get(1).getResult().isActive(), is(true));
        assertThat(mediatorPhysicalConnections.get(1).getResult().getId(), is(2)); // sanity check

        final Iterable<ChannelPhysicalConnectionData> channelConnections = channelInstanceRepository.queryAll();
        assertThat(channelConnections, is(iterableWithSize(2)));
        assertThat(channelConnections, hasItems( // we're relying on knowing about ID generation at the repo... not ideal but ok for the time being.
                new ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder()
                        .setActive(false).build(1, 1, 1, 0),
                new ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder()
                        .setActive(true).build(2, 1, 1, 0)
        ));

        final Iterable<NePhysicalConnectionData> neConnections = neInstanceRepository.queryAll();
        assertThat(neConnections, is(iterableWithSize(2)));
        assertThat(neConnections, hasItems(
                new NePhysicalConnectionData.NePhysicalConnectionBuilder()
                        .setActive(false).build(1, 1, 1, 0),
                new NePhysicalConnectionData.NePhysicalConnectionBuilder()
                        .setActive(true).build(2, 1, 2, 0)
        ));
    }

    @Test
    public void configurePrimary_oneInstance_activatesPrimary() throws Exception {

        when(mediatorInfoRepository.queryAll()).thenReturn(Collections.singleton(buildMediatorInfo(1)));
        when(channelInfoRepository.queryAll()).thenReturn(Collections.singleton(buildChannelInfo(1, 1)));
        when(neInfoRepository.queryAll()).thenReturn(Collections.singleton(buildNeInfo(1, 1)));
        when(mediatorInstanceRepository.queryAll(1)).thenReturn(ImmutableList.of(
                buildMediatorInstance(1, 1, MediatorInstance.PRIMARY_PRIORITY_LEVEL)
        ));

        when(mediatorPhysicalConnectionRepository.tryUpdate(any())).then(new MutationAnswer<>());

        helper.configureStandbyMediatorInstances(MediatorInstance.PRIMARY_PRIORITY_LEVEL);

        verify(mediatorPhysicalConnectionRepository).tryUpdate(mediatorPhysicalCaptor.capture());

        final List<MediatorPhysicalConnectionMutationDescriptor> mediatorPhysicalConnections =
                mediatorPhysicalCaptor.getAllValues();
        assertThat(mediatorPhysicalConnections, hasSize(1));
        assertThat(mediatorPhysicalConnections.get(0).getResult().isActive(), is(true));
        assertThat(mediatorPhysicalConnections.get(0).getResult().getId(), is(1)); // sanity check

        final Iterable<ChannelPhysicalConnectionData> channelConnections = channelInstanceRepository.queryAll();
        assertThat(channelConnections, is(iterableWithSize(1)));
        assertThat(channelConnections, hasItem( // we're relying on knowing about ID generation at the repo... not ideal but ok for the time being.
                new ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder()
                        .setActive(true).build(1, 1, 1, 0)
        ));

        final Iterable<NePhysicalConnectionData> neConnections = neInstanceRepository.queryAll();
        assertThat(neConnections, is(iterableWithSize(1)));
        assertThat(neConnections, hasItem(
                new NePhysicalConnectionData.NePhysicalConnectionBuilder()
                        .setActive(true).build(1, 1, 1, 0)
        ));
    }

    @Test
    public void configureSecondary_oneInstance_activatesPrimary() throws Exception {

        when(mediatorInfoRepository.queryAll()).thenReturn(Collections.singleton(buildMediatorInfo(1)));
        when(channelInfoRepository.queryAll()).thenReturn(Collections.singleton(buildChannelInfo(1, 1)));
        when(neInfoRepository.queryAll()).thenReturn(Collections.singleton(buildNeInfo(1, 1)));
        when(mediatorInstanceRepository.queryAll(1)).thenReturn(ImmutableList.of(
                buildMediatorInstance(1, 1, MediatorInstance.PRIMARY_PRIORITY_LEVEL)
        ));

        when(mediatorPhysicalConnectionRepository.tryUpdate(any())).then(new MutationAnswer<>());

        helper.configureStandbyMediatorInstances(MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1);

        verify(mediatorPhysicalConnectionRepository).tryUpdate(mediatorPhysicalCaptor.capture());

        final List<MediatorPhysicalConnectionMutationDescriptor> mediatorPhysicalConnections =
                mediatorPhysicalCaptor.getAllValues();
        assertThat(mediatorPhysicalConnections, hasSize(1));
        assertThat(mediatorPhysicalConnections.get(0).getResult().isActive(), is(true));
        assertThat(mediatorPhysicalConnections.get(0).getResult().getId(), is(1)); // sanity check

        final Iterable<ChannelPhysicalConnectionData> channelConnections = channelInstanceRepository.queryAll();
        assertThat(channelConnections, is(iterableWithSize(1)));
        assertThat(channelConnections, hasItem( // we're relying on knowing about ID generation at the repo... not ideal but ok for the time being.
                new ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder()
                        .setActive(true).build(1, 1, 1, 0)
        ));

        final Iterable<NePhysicalConnectionData> neConnections = neInstanceRepository.queryAll();
        assertThat(neConnections, is(iterableWithSize(1)));
        assertThat(neConnections, hasItem(
                new NePhysicalConnectionData.NePhysicalConnectionBuilder()
                        .setActive(true).build(1, 1, 1, 0)
        ));
    }

    private MediatorInfoData buildMediatorInfo(int id) {
        return new MediatorInfoData.MediatorInfoBuilder()
                .setName("name")
                .setTypeName("type")
                .build(id, 0);
    }

    private ChannelInfoData buildChannelInfo(int id, int mediatorId) {
        return new ChannelInfoData.ChannelInfoBuilder()
                .setType("type")
                .build(id, 0, mediatorId);
    }

    private NeInfoData buildNeInfo(int id, int channel)  {
        return new NeInfoData.NeInfoBuilder()
                .setProxyType("type")
                .build(id, channel, 0);
    }

    private MediatorInstance buildMediatorInstance(int instanceId, int mediatorId, int priority) {
        return new MediatorInstance(
                new MediatorPhysicalData.MediatorPhysicalDataBuilder()
                    .setHost("host")
                    .setPriority(priority)
                    .build(instanceId, mediatorId, 0),
                new MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder()
                    .build(instanceId, mediatorId, 0)
        );
    }

}