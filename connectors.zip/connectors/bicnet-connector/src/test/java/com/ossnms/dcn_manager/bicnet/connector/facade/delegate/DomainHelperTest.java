package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.ASIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IASId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomain;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainId;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaDomainRepositoryBean;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemDomain;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.events.domain.DomainNeActivationPolicyChanged;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.Matchers.arrayWithSize;
import static org.hamcrest.Matchers.emptyIterableOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DomainHelperTest {

    private static final int VERSION = 1;
    private static final int CHANNEL_ID = 2;
    private static final int NE_ID = 123;
    private static final int DOMAIN_ID = 45;
    private static final String DOMAIN_NAME = "domainName";

    @Mock private JpaDomainRepositoryBean domainRepository;
    @Mock private DomainNotifications domainNotifications;
    @Mock private LoggerManagerImpl loggerManager;
    @Mock private NeEntityRepository neRepository;
    @Mock private StaticConfiguration configuration;
    @Mock private NePhysicalConnectionRepository neInstancesRepository;

    @Mock private NetworkElementInteractionManager neInteractionManager;
    @Mock private NetworkElementNotifications neNotifs;
    
    private NetworkElementManagers neManagers;
    
    @Mock private ChannelEntityRepository channelEntityRepository;
    @Mock private ChannelPhysicalConnectionRepository physicalChannelRepository;
    @Mock private ChannelNotifications channelNotifications;
    @Mock private ChannelInteractionManager channelInteractionManager;
    private ChannelManagers channelManagers;

    
    @InjectMocks private DomainHelper helper;

    @Before
    public void setUp() {
        
        neManagers = new NetworkElementManagers(neRepository, neInstancesRepository, neInteractionManager, neNotifs, null);
        channelManagers = new ChannelManagers(channelEntityRepository, physicalChannelRepository, channelNotifications, channelInteractionManager, null);
        
        helper.setNeManagers(neManagers);
        helper.setChannelManagers(channelManagers);
        
        when(domainRepository.queryChildrenNEs(anyInt())).thenReturn(Collections.emptyList());

        when(neInstancesRepository.queryAll(anyInt())).thenReturn(Collections.emptyList());
    }

    @Test
    public void getSingleNetworkDomain() throws Exception {

        final DomainInfoData domain = new DomainInfoData(1, 1, "name");

        when(domainRepository.query(1)).thenReturn(Optional.of(domain));

        final INetworkDomain networkDomain = helper.getSingleNetworkDomain(null, new NetworkDomainIdItem(1));

        assertThat(networkDomain, is(notNullValue()));
        assertThat(networkDomain.getIdName(), is(domain.getName()));
    }

    @Test
    public void getSingleNetworkDomain_noResult_returnsNull() throws Exception {

        when(domainRepository.query(1)).thenReturn(Optional.empty());

        final INetworkDomain networkDomain = helper.getSingleNetworkDomain(null, new NetworkDomainIdItem(1));

        assertThat(networkDomain, is(nullValue()));
    }

    @Test(expected=BcbException.class)
    public void getSingleNetworkDomain_exception_propagates() throws Exception {

        when(domainRepository.query(anyInt())).thenThrow(new RepositoryException());

        helper.getSingleNetworkDomain(null, new NetworkDomainIdItem(1));
    }

    @Test
    public void getDomain() throws Exception {

        final DomainInfoData domain = new DomainInfoData(1, 1, "name");

        when(domainRepository.query(1)).thenReturn(Optional.of(domain));

        final IAS as = helper.getDomain(null, new ASIdItem(1));

        assertThat(as, is(notNullValue()));
        assertThat(as.getIdName(), is(domain.getName()));
    }

    @Test
    public void getDomain_noResult_returnsNull() throws Exception {

        when(domainRepository.query(1)).thenReturn(Optional.empty());

        final IAS as = helper.getDomain(null, new ASIdItem(1));

        assertThat(as, is(nullValue()));
    }

    @Test(expected=BcbException.class)
    public void getDomain_exception_propagates() throws Exception {

        when(domainRepository.query(anyInt())).thenThrow(new RepositoryException());

        helper.getDomain(null, new ASIdItem(1));
    }

    @Test
    public void getDomains() throws Exception {

        final DomainInfoData domain = new DomainInfoData(1, 1, "name");

        when(domainRepository.queryAll()).thenReturn(Collections.singletonList(domain));

        final Iterable<IAS> list = helper.getDomains(null);

        assertThat(list, is(Matchers.iterableWithSize(1)));
        assertThat(list.iterator().next().getIdName(), is(domain.getName()));
    }

    @Test
    public void getDomains_exception_returnsEmptyIterable() throws Exception {

        when(domainRepository.queryAll()).thenThrow(new RepositoryException());

        final Iterable<IAS> list = helper.getDomains(null);

        assertThat(list, is(emptyIterableOf(IAS.class)));
    }

    @Test
    public void getNetworkDomainIdsForNE() throws BcbException {

        final DomainInfoData domain = new DomainInfoData(1, 1, "name");

        when(domainRepository.queryAllForNE(anyInt())).thenReturn(Collections.singletonList(domain));

        final INetworkDomainId[] list = helper.getNetworkDomainIdsForNE(null, new NEIdItem(NE_ID));

        assertArrayEquals(list, new INetworkDomainId[] { new NetworkDomainIdItem(1) });
    }

    @Test
    public void getNetworkDomainsForNE() throws BcbException {

        final DomainInfoData domain = new DomainInfoData(1, 1, "name");

        when(domainRepository.queryAllForNE(anyInt())).thenReturn(Collections.singletonList(domain));

        final INetworkDomain[] list = helper.getNetworkDomainsForNE(null, new NEIdItem(NE_ID));

        final NetworkDomainItem item = new NetworkDomainItem();
        item.setId(1);
        item.setIdName("name");
        assertArrayEquals(list, new INetworkDomain[] { item });
    }

    @Test
    public void getNEIdsInNetworkDomain() throws BcbException {

        when(domainRepository.queryChildrenNEs(anyInt())).thenReturn(Collections.singletonList(NE_ID));

        final INEId[] list = helper.getNEIdsInNetworkDomain(null, new NetworkDomainIdItem(DOMAIN_ID));

        assertArrayEquals(list, new INEId[] { new NEIdItem(NE_ID) });
    }

    @Test
    public void getDomainList() throws BcbException {

        final DomainInfoData domain = new DomainInfoData(1, 1, "name");

        when(domainRepository.queryAllForNE(anyInt())).thenReturn(Collections.singletonList(domain));

        final String[] list = helper.getDomainList(null, new NEIdItem(NE_ID));

        assertArrayEquals(list, new String[] { "name" });
    }

    @SuppressWarnings("unchecked")
    @Test
    public void getAllNEsFromAllDomainsByNE() {

        when(domainRepository.queryAllForNE(anyInt())).thenReturn(ImmutableList.of(
                new DomainInfoData(1, 1, "name1"),
                new DomainInfoData(2, 1, "name2")
            ));

        when(domainRepository.queryChildrenNEs(anyInt())).thenReturn(
                ImmutableList.of(NE_ID, 12),
                ImmutableList.of(NE_ID, 24)
            );

        final INEId[] ids = helper.getAllNEsFromAllDomainsByNE(null, new NEIdItem(NE_ID));

        assertArrayEquals(ids, new INEId[] {
            new NEIdItem(NE_ID), new NEIdItem(12), new NEIdItem(24)
        });
    }

    @Test
    public void getNesByDomain_domainRepoError_emptyResult() throws RepositoryException {
        when(domainRepository.queryByName(anyString())).thenThrow(new RepositoryException());

        final INE[] nes = helper.getNesByDomain(null, new String[] { "domain1", null, "domain2", "domain3" });

        assertThat(nes, is(arrayWithSize(0)));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void getNesByDomain() throws RepositoryException {
        final DomainInfoData domain1 = new DomainInfoData(1, 1, "domain1");
        final DomainInfoData domain3 = new DomainInfoData(3, 1, "domain3");

        final Types<NeType> neTypes = mock(Types.class);
        final NeType neType = MockFactory.mockNeType();

        when(neType.getDefaultIcon()).thenReturn("iconId");
        when(neTypes.get(any())).thenReturn(neType);
        when(configuration.getNeTypes()).thenReturn(neTypes);

        when(domainRepository.queryByName(anyString())).thenReturn(
                Optional.of(domain1),
                Optional.empty(),
                Optional.of(domain3)
            );

        when(domainRepository.queryChildrenNEs(anyInt())).thenReturn(
                ImmutableList.of(NE_ID, 12),
                ImmutableList.of(NE_ID, 24, 99)
            );

        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(buildNeEntity(NE_ID)));
        when(neRepository.queryNe(24)).thenReturn(Optional.of(buildNeEntity(24)));
        when(neRepository.queryNe(12)).thenReturn(Optional.empty());
        when(neRepository.queryNe(99)).thenThrow(new RepositoryException()); // should return absent

        final INE[] nes = helper.getNesByDomain(null, new String[] { "domain1", null, "domain2", "domain3" });

        assertThat(nes, is(arrayWithSize(2)));

        assertThat(nes[0].getId(), is(NE_ID));

        assertThat(nes[1].getId(), is(24));
    }

    @Test
    public void getNEsInNetworkDomain() throws Exception {

        final Types<NeType> neTypes = mock(Types.class);
        final NeType neType = MockFactory.mockNeType();

        when(neType.getDefaultIcon()).thenReturn("iconId");
        when(neTypes.get(any())).thenReturn(neType);
        when(configuration.getNeTypes()).thenReturn(neTypes);

        when(domainRepository.queryChildrenNEs(anyInt())).thenReturn(
                ImmutableList.of(NE_ID, 12, 24, 99)
            );

        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(buildNeEntity(NE_ID)));
        when(neRepository.queryNe(24)).thenReturn(Optional.of(buildNeEntity(24)));
        when(neRepository.queryNe(12)).thenReturn(Optional.empty());
        when(neRepository.queryNe(99)).thenThrow(new RepositoryException()); // should return absent

        final INE[] nes = helper.getNEsInNetworkDomain(null, new NetworkDomainIdItem(DOMAIN_ID));

        assertThat(nes, is(arrayWithSize(2)));

        assertThat(nes[0].getId(), is(NE_ID));

        assertThat(nes[1].getId(), is(24));
    }

    private NeEntity buildNeEntity(int neId) {
        return new NeEntity(
                new NeConnectionBuilder().build(neId, VERSION),
                new NeOperationBuilder().build(neId, VERSION),
                new NeInfoBuilder().setProxyType("type").build(neId, CHANNEL_ID, VERSION),
                new NeSynchronizationBuilder().build(neId, VERSION),
                new NeUserPreferencesBuilder().setName("name").build(neId, VERSION));
    }

    @Test
    public void updateDomainActivationPolicy() throws Exception {

        when(domainRepository.query(DOMAIN_ID)).thenReturn(Optional.of(new DomainInfoData(DOMAIN_ID, VERSION, DOMAIN_NAME, false)));
        when(domainRepository.tryUpdate(isA(DomainInfoMutationDescriptor.class))).then(new MutationAnswer<>());

        helper.setAutomaticNeActivationPolicy(null, new IASId[] { new ASIdItem(DOMAIN_ID) }, true);

        final ArgumentCaptor<DomainInfoMutationDescriptor> captor = ArgumentCaptor.forClass(DomainInfoMutationDescriptor.class);

        verify(domainRepository).tryUpdate(captor.capture());
        verify(domainNotifications).notifyChanges(new DomainNeActivationPolicyChanged(DOMAIN_ID, true));
        verify(loggerManager).createCommandLog(any(BicnetCallContext.class), isA(LoggerItemDomain.class));

        assertThat(captor.getValue().getTarget().getId(), is(DOMAIN_ID));
        assertThat(captor.getValue().getAutomaticNeActivationPermitted(), hasValue(true));
    }

    @Test(expected=BcbException.class)
    public void updateDomainActivationPolicy_fails_translatesException() throws Exception {

        when(domainRepository.query(DOMAIN_ID)).thenReturn(Optional.empty());

        helper.setAutomaticNeActivationPolicy(null, new IASId[] { new ASIdItem(DOMAIN_ID) }, true);
    }

    @Test
    public void updateDomainActivationPolicy_skipsNullIds() throws Exception {

        helper.setAutomaticNeActivationPolicy(null, new IASId[] { null }, true);

        verifyZeroInteractions(domainRepository, domainNotifications, loggerManager);
    }
}
