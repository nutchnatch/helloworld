package com.ossnms.dcn_manager.bicnet.connector.messaging.stream;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.ossnms.bicnet.bcb.facade.elementMgmt.NeConfigurationCounterPkgItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementProxyItem;
import com.ossnms.bicnet.bcb.model.IMoFacet;
import com.ossnms.bicnet.bcb.model.elementMgmt.INeConfigurationCounterPkgMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementProxyMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMMarkable;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.dcn_manager.bicnet.connector.messaging.stream.IsAvcAgainstType;

public class IsAvcAgainstTypeTest {

    @Test
    public void differentTypes() throws Exception {
        final INetworkElementProxyMarkable proxyMarkable = NetworkElementProxyItem.markableNetworkElementProxy(null);
        proxyMarkable.setNeId(1);

        final AttributeValueChange avc = new AttributeValueChange();
        avc.setChangedObject(proxyMarkable);

        assertThat(new IsAvcAgainstType(IEMMarkable.class).call(avc), is(false));
    }

    @Test
    public void sameType_noMarks() throws Exception {
        final INetworkElementProxyMarkable proxyMarkable = NetworkElementProxyItem.markableNetworkElementProxy(null);

        final AttributeValueChange avc = new AttributeValueChange();
        avc.setChangedObject(proxyMarkable);

        assertThat(new IsAvcAgainstType(INetworkElementProxyMarkable.class).call(avc), is(false));
    }

    @Test
    public void sameType() throws Exception {
        final INetworkElementProxyMarkable proxyMarkable = NetworkElementProxyItem.markableNetworkElementProxy(null);
        proxyMarkable.setNeId(3);

        final AttributeValueChange avc = new AttributeValueChange();
        avc.setChangedObject(proxyMarkable);

        assertThat(new IsAvcAgainstType(INetworkElementProxyMarkable.class).call(avc), is(true));
    }

    @Test
    public void sameType_marksOnFacetOnly() throws Exception {
        final INeConfigurationCounterPkgMarkable facet = NeConfigurationCounterPkgItem.markableNeConfigurationCounterPkg();
        facet.setAlarmsCategoryCounterHash(4);

        final INetworkElementProxyMarkable proxyMarkable = NetworkElementProxyItem.markableNetworkElementProxy(
            new IMoFacet[] { facet });

        final AttributeValueChange avc = new AttributeValueChange();
        avc.setChangedObject(proxyMarkable);

        assertThat(new IsAvcAgainstType(INetworkElementProxyMarkable.class).call(avc), is(true));
    }

}
