package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.connector.jpa.JpaCloseableQuery;
import com.ossnms.dcn_manager.connector.storage.container.entities.QSystemInfoDb;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.outbound.SystemNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;

import javax.persistence.PersistenceException;
import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SystemContainerHelperTest {

    private static final int SYSTEM_ID = 76;

    @Mock private JpaNetworkElementRepositoryBean networkElementRepository;
    @Mock private NeUserPreferencesRepository neUserPreferencesRepository;
    @Mock private SystemNotifications notifications;
    @Mock private LoggerManagerImpl loggerManager;
    @Mock private JpaSystemRepositoryBean repository;
    @Mock private JpaContainerRepositoryBean containerRepository;
    @Mock private ContainerNotifications containerNotifications;
    @Mock private SettingsRepository settingsRepository;

    @InjectMocks private SystemContainerHelper helper;

    @Before public void setUp() throws Exception {
        when(networkElementRepository.getNeUserPreferencesRepository()).thenReturn(neUserPreferencesRepository);
        when(containerRepository.queryByName(anyString())).thenReturn(Optional.empty());

        when(repository.queryByName(anyString())).thenReturn(Optional.empty());
        when(neUserPreferencesRepository.query(anyString())).thenReturn(Optional.empty());

        when(containerRepository.queryByName(anyString())).thenReturn(Optional.of(new ContainerInfo(1,1,"c")));
        when(settingsRepository.getSettings()).thenReturn(GlobalSettings.build().toGlobalSettings(1,1));
    }

    @Test
    public void deleteSystemContainer() throws RepositoryException, BcbException {

        when(repository.query(anyInt())).thenReturn(Optional.of(new SystemInfo(SYSTEM_ID, 1, "name")));

        helper.deleteSystemContainer(null, new SystemContainerIdItem(SYSTEM_ID));
    }

    @Test(expected=BcbException.class)
    public void deleteSystemContainer_repositoryError_throws() throws RepositoryException, BcbException {

        when(repository.query(anyInt())).thenThrow(new RepositoryException());

        helper.deleteSystemContainer(null, new SystemContainerIdItem(SYSTEM_ID));
    }

    @Test
    public void deleteSystemContainer_unknownId() throws RepositoryException, BcbException {

        when(repository.query(anyInt())).thenReturn(Optional.empty());

        helper.deleteSystemContainer(null, new SystemContainerIdItem(SYSTEM_ID));
    }

    @Test
    public void createSystemContainer() throws RepositoryException, BcbException {
        when(containerRepository.queryAllBySystem(SYSTEM_ID)).thenReturn(Collections.emptyList());
        when(containerRepository.queryByName("name")).thenReturn(Optional.empty());

        when(repository.create(any(SystemCreationDescriptor.class)))
                .then((Answer<SystemInfo>) invocation -> {
                    final SystemCreationDescriptor desc = (SystemCreationDescriptor) invocation.getArguments()[0];
                    return new SystemInfo(SYSTEM_ID, 1, desc.getName());
                });

        when(containerRepository.getRootContainer()).thenReturn(new ContainerInfo(0, 100, "Root"));

        final SystemContainerItem item = new SystemContainerItem();
        item.setIdName("name");
        final ISystemContainer systemContainer = helper.createSystemContainer(null, item);

        assertThat(systemContainer, is(notNullValue()));
        assertThat(systemContainer.getIdName(), is(item.getIdName()));
        assertThat(systemContainer.getId(), is(SYSTEM_ID));
    }

    @Test(expected=BcbException.class)
    public void createSystemContainer_repositoryError_throws() throws RepositoryException, BcbException {

        when(repository.create(any(SystemCreationDescriptor.class))).thenThrow(new RepositoryException());

        final SystemContainerItem item = new SystemContainerItem();
        item.setIdName("name");
        helper.createSystemContainer(null, item);
    }

    @Test(expected=BcbException.class)
    public void createSystemContainer_noName_throws() throws RepositoryException, BcbException {

        when(repository.create(any(SystemCreationDescriptor.class)))
                .then((Answer<SystemInfo>) invocation -> {
                    final SystemCreationDescriptor desc = (SystemCreationDescriptor) invocation.getArguments()[0];
                    return new SystemInfo(SYSTEM_ID, 1, desc.getName());
                });

        final SystemContainerItem item = new SystemContainerItem();
        item.setIdName("");
        final ISystemContainer systemContainer = helper.createSystemContainer(null, item);

        assertThat(systemContainer, is(notNullValue()));
        assertThat(systemContainer.getIdName(), is(item.getIdName()));
        assertThat(systemContainer.getId(), is(SYSTEM_ID));
    }

    @Test(expected=BcbException.class)
    public void getSingleSystemContainer_repositoryError_throws() throws RepositoryException, BcbException {
        when(repository.query(anyInt())).thenThrow(new RepositoryException());

        helper.getSingleSystemContainer(null, new SystemContainerIdItem(12));
    }

    @Test(expected=BcbException.class)
    public void getSystemContainerList_repositoryError_throws() throws RepositoryException, BcbException {
        final JpaCloseableQuery query = mock(JpaCloseableQuery.class);

        when(repository.query(any(QSystemInfoDb.class))).thenReturn(query);
        when(query.list(any(QSystemInfoDb.class))).thenThrow(new PersistenceException());

        helper.getSystemContainerList(null, null, null, -1);
    }

    @Test(expected=BcbException.class)
    public void getSystemContainerIdList_repositoryError_throws() throws RepositoryException, BcbException {
        final JpaCloseableQuery query = mock(JpaCloseableQuery.class);

        when(repository.query(any(QSystemInfoDb.class))).thenReturn(query);
        when(query.list(any(QSystemInfoDb.class))).thenThrow(new PersistenceException());

        helper.getSystemContainerIdList(null, null, null, -1);
    }

}
