package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentTypes;
import com.ossnms.dcn_manager.bicnet.connector.outbound.notifications.NeNotificationsManagerImpl;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class) // necessary due to mock injection below.
public class MOHelperTest {

    private static final int VERSION = 1;
    private static final int CHANNEL_ID = 2;
    private static final int NE_ID = 1;

    @Mock private NeEntityRepository repository;
    @Mock private NeInfoRepository infoRepository;
    @Mock private NeNotificationsManagerImpl notifications;
    @Mock private ISessionContext context;

    @InjectMocks private MOHelper helper;

    @Captor private ArgumentCaptor<NeInfoMutationDescriptor> mutationCaptor;

    @Before
    public void setUp() {
        when(repository.getNeInfoRepository()).thenReturn(infoRepository);
    }

    @Test(expected=BcbException.class)
    public void testAddUsage_notNeId_throws() throws BcbException {

        helper.addUsage(context, new EMIdItem(CHANNEL_ID), BiCNetComponentType.AP_CONNECTION_MANAGER);

    }

    @Test(expected=BcbException.class)
    public void testAddUsage_neNotFound_throws() throws Exception {

        when(infoRepository.query(NE_ID)).thenReturn(Optional.empty());

        helper.addUsage(context, new NEIdItem(NE_ID), BiCNetComponentType.AP_CONNECTION_MANAGER);

    }

    @Test(expected=BcbException.class)
    public void testAddUsage_updateFailed_throws() throws Exception {

        final NeInfoData info = new NeInfoBuilder()
            .setProxyType("type")
            .build(NE_ID, CHANNEL_ID, VERSION);

        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(info));
        when(infoRepository.tryUpdate(any(NeInfoMutationDescriptor.class))).thenReturn(Optional.empty());

        helper.addUsage(context, new NEIdItem(NE_ID), BiCNetComponentType.AP_CONNECTION_MANAGER);
    }

    @Test
    public void testAddUsage() throws Exception {

        final NeInfoData info = new NeInfoBuilder()
            .setProxyType("type")
            .build(NE_ID, CHANNEL_ID, VERSION);

        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(info));

        // return something just to signal success
        when(infoRepository.tryUpdate(any(NeInfoMutationDescriptor.class))).thenReturn(Optional.of(info));

        helper.addUsage(context, new NEIdItem(NE_ID), BiCNetComponentType.AP_CONNECTION_MANAGER);

        verify(infoRepository).tryUpdate(mutationCaptor.capture());
        verify(notifications).notifyChanges(mutationCaptor.getValue());

        assertThat(mutationCaptor.getValue().getUsedBy().get(),
                is(BiCNetComponentTypes.of(BiCNetComponentType.AP_CONNECTION_MANAGER).toDbString()));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testAddUsage_idempotent() throws Exception {

        final NeInfoData infoBefore = new NeInfoBuilder()
            .setProxyType("type")
            .build(NE_ID, CHANNEL_ID, VERSION);

        final NeInfoData infoAfter = new NeInfoBuilder()
            .setProxyType("type")
            .setUsedBy(Optional.of(BiCNetComponentTypes.of(BiCNetComponentType.AP_CONNECTION_MANAGER).toDbString()))
            .build(NE_ID, CHANNEL_ID, VERSION);

        when(infoRepository.query(NE_ID))
            .thenReturn(Optional.of(infoBefore), Optional.of(infoAfter));

        // return something just to signal success
        when(infoRepository.tryUpdate(any(NeInfoMutationDescriptor.class))).thenReturn(Optional.of(infoAfter));

        // two calls adding the same value
        helper.addUsage(context, new NEIdItem(NE_ID), BiCNetComponentType.AP_CONNECTION_MANAGER);
        helper.addUsage(context, new NEIdItem(NE_ID), BiCNetComponentType.AP_CONNECTION_MANAGER);

        verify(infoRepository).tryUpdate(mutationCaptor.capture());
        verify(notifications).notifyChanges(mutationCaptor.getValue());

        assertThat(mutationCaptor.getValue().getUsedBy().get(),
                is(BiCNetComponentTypes.of(BiCNetComponentType.AP_CONNECTION_MANAGER).toDbString()));
    }

    @Test(expected=BcbException.class)
    public void testRemoveUsage_notNeId_throws() throws BcbException {

        helper.releaseUsage(context, new EMIdItem(CHANNEL_ID), BiCNetComponentType.AP_CONNECTION_MANAGER);

    }

    @Test(expected=BcbException.class)
    public void testRemoveUsage_neNotFound_throws() throws Exception {

        when(infoRepository.query(NE_ID)).thenReturn(Optional.empty());

        helper.releaseUsage(context, new NEIdItem(NE_ID), BiCNetComponentType.AP_CONNECTION_MANAGER);

    }

    @Test(expected=BcbException.class)
    public void testRemoveUsage_updateFailed_throws() throws Exception {

        final NeInfoData info = new NeInfoBuilder()
            .setProxyType("type")
            .setUsedBy(Optional.of(BiCNetComponentTypes.of(BiCNetComponentType.AP_CONNECTION_MANAGER).toDbString()))
            .build(NE_ID, CHANNEL_ID, VERSION);

        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(info));
        when(infoRepository.tryUpdate(any(NeInfoMutationDescriptor.class))).thenReturn(Optional.empty());

        helper.releaseUsage(context, new NEIdItem(NE_ID), BiCNetComponentType.AP_CONNECTION_MANAGER);
    }

    @Test
    public void testRemoveUsage() throws Exception {

        final NeInfoData info = new NeInfoBuilder()
            .setProxyType("type")
            .setUsedBy(Optional.of(BiCNetComponentTypes.of(BiCNetComponentType.AP_CONNECTION_MANAGER).toDbString()))
            .build(NE_ID, CHANNEL_ID, VERSION);

        when(infoRepository.query(NE_ID)).thenReturn(Optional.of(info));

        // return something just to signal success
        when(infoRepository.tryUpdate(any(NeInfoMutationDescriptor.class))).thenReturn(Optional.of(info));

        helper.releaseUsage(context, new NEIdItem(NE_ID), BiCNetComponentType.AP_CONNECTION_MANAGER);

        verify(infoRepository).tryUpdate(mutationCaptor.capture());
        verify(notifications).notifyChanges(mutationCaptor.getValue());

        assertThat(mutationCaptor.getValue().getUsedBy().get(),
                is(BiCNetComponentTypes.none().toDbString()));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testRemoveUsage_idempotent() throws Exception {

        final NeInfoData infoBefore = new NeInfoBuilder()
            .setProxyType("type")
            .setUsedBy(Optional.of(BiCNetComponentTypes.of(BiCNetComponentType.AP_CONNECTION_MANAGER).toDbString()))
            .build(NE_ID, CHANNEL_ID, VERSION);

        final NeInfoData infoAfter = new NeInfoBuilder()
            .setProxyType("type")
            .setUsedBy(Optional.of(BiCNetComponentTypes.none().toDbString()))
            .build(NE_ID, CHANNEL_ID, VERSION);

        when(infoRepository.query(NE_ID))
            .thenReturn(Optional.of(infoBefore), Optional.of(infoAfter));

        // return something just to signal success
        when(infoRepository.tryUpdate(any(NeInfoMutationDescriptor.class))).thenReturn(Optional.of(infoAfter));

        // two calls removing the same value
        helper.releaseUsage(context, new NEIdItem(NE_ID), BiCNetComponentType.AP_CONNECTION_MANAGER);
        helper.releaseUsage(context, new NEIdItem(NE_ID), BiCNetComponentType.AP_CONNECTION_MANAGER);

        verify(infoRepository).tryUpdate(mutationCaptor.capture());
        verify(notifications).notifyChanges(mutationCaptor.getValue());

        assertThat(mutationCaptor.getValue().getUsedBy().get(),
                is(BiCNetComponentTypes.none().toDbString()));
    }

}
