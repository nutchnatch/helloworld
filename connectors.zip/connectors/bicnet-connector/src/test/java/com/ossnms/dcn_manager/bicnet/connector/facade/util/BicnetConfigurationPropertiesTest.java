package com.ossnms.dcn_manager.bicnet.connector.facade.util;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.composables.configuration.AppProperties;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class BicnetConfigurationPropertiesTest {

    @Test
    public void testGetProperties() throws Exception {
        AppProperties props = mock(AppProperties.class);

        when(props.isNodeManagerSelected()).thenReturn(true, false);

        assertThat(BicnetConfigurationProperties.getProperties(props),
                is(ImmutableMap.of("NODE_MANAGER_SELECTED", "true")));

        assertThat(BicnetConfigurationProperties.getProperties(props),
                is(ImmutableMap.of("NODE_MANAGER_SELECTED", "false")));
    }
}