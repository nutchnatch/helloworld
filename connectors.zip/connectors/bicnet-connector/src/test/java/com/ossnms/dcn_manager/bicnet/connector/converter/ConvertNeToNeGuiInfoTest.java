package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeRouteInfo;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import org.junit.Test;

import java.util.Collections;
import java.util.Optional;
import java.util.Set;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class ConvertNeToNeGuiInfoTest {
    private static final int NE_ID = 1;
    private static final int VERSION = 5;

    @Test
    public void testWithStandby() throws Exception {
        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().setActivationState(ActualActivationState.CONNECTED).build(NE_ID, VERSION),
                new NeOperationBuilder().build(NE_ID, VERSION),
                new NeInfoBuilder().setProxyType("t").build(NE_ID, 10, VERSION),
                new NeSynchronizationBuilder().build(NE_ID, VERSION),
                new NeUserPreferencesBuilder().setName("name").setUserText(Optional.of("test")).build(NE_ID, VERSION));

        final NePhysicalConnectionData standby = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.DISCONNECTED)
                .setActive(false)
                .build(10, 1, 20, VERSION);

        final NeInfo neInfo = ConvertNeToNeGuiInfo.build(entity, Collections.singleton(standby), Collections.emptyList());

        assertThat(neInfo.getGuiActiveActualActivationState().get(), is(GuiActualActivationState.ACTIVATING));
        assertThat(neInfo.getGuiStandbyActualActivationState().get(), is(GuiActualActivationState.INACTIVE));
        assertThat(neInfo.getStandbyDisplayState().get(), is("Inactive"));
        assertThat(neInfo.getUserText().get(), is("test"));
    }

    @Test
    public void testBasicInfo() throws Exception {
        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().setActivationState(ActualActivationState.CONNECTED).build(NE_ID, VERSION),
                new NeOperationBuilder().build(NE_ID, VERSION),
                new NeInfoBuilder().setProxyType("t").build(NE_ID, 10, VERSION),
                new NeSynchronizationBuilder().build(NE_ID, VERSION),
                new NeUserPreferencesBuilder().setName("name").setUserText(Optional.of("test")).build(NE_ID, VERSION));

        final NeInfo neInfo = ConvertNeToNeGuiInfo.build(entity, Collections.emptyList(), Collections.emptyList());

        assertThat(neInfo.getGuiActiveActualActivationState().get(), is(GuiActualActivationState.ACTIVATING));
        assertThat(neInfo.getGuiStandbyActualActivationState(), is(Optional.empty()));
        assertThat(neInfo.getStandbyDisplayState().get(), is(""));
        assertThat(neInfo.getUserText().get(), is("test"));
    }

    @Test public void testRoutes() throws Exception {
        final NeGatewayRouteData routeData1 = new NeGatewayRouteBuilder()
                .setKey("a").setDomain(Optional.of("domain1")).setCost(1).setGneName("gne1").build(NE_ID, VERSION);
        final NeGatewayRouteData routeData2 = new NeGatewayRouteBuilder()
                .setKey("a").setDomain(Optional.of("domain1")).setCost(2).setGneName("gne1").build(NE_ID, VERSION);
        final NeGatewayRouteData routeData3 = new NeGatewayRouteBuilder()
                .setKey("a").setDomain(Optional.of("domain2")).setCost(3).setGneName("gne1").build(NE_ID, VERSION);
        final NeGatewayRouteData routeData4 = new NeGatewayRouteBuilder()
                .setKey("a").setDomain(Optional.of("domain2")).setCost(0).setGneName("gne1").build(NE_ID, VERSION);

        Set<NeRouteInfo> neRouteInfos = ConvertNeToNeGuiInfo
                .convertRoutes(ImmutableList.of(routeData1, routeData2, routeData3, routeData4));

        assertThat(neRouteInfos.size(), is(2));
        assertThat(true, is(neRouteInfos.contains(new NeRouteInfo("domain1", 1, "gne1"))));
        assertThat(true, is(neRouteInfos.contains(new NeRouteInfo("domain2", 0, "gne1"))));
    }
}
