package com.ossnms.dcn_manager.bicnet.connector.outbound;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.security.ISecurityMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.SecurableObjectIdItem;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.security.ISecurableObject;
import com.ossnms.bicnet.bcb.model.security.ISecurableObjectContainer;
import com.ossnms.bicnet.bcb.model.security.ISecurableObjectContainerId;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelInfoRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository.MediatorInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;
import java.util.stream.Stream;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.arrayWithSize;
import static org.hamcrest.Matchers.instanceOf;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class SecurityManagerImplTest {

    private NeType type;
    private ISecurityMgrFacade securityManagerFacade;
    private DomainRepository domainRepository;
    private NeEntityRepository neRepository;
    private NeInfoRepository neInfoRepository;
    private NeUserPreferencesRepository nePreferencesRepository;
    private ChannelEntityRepository channelRepository;
    private ChannelInfoRepository channelInfoRepository;
    private MediatorEntityRepository mediatorRepository;
    private MediatorInfoRepository mediatorInfoRepository;
    private ContainerRepository containerRepository;
    private SystemRepository systemRepository;

    private SecurityManagerImpl securityManager;

    private ArgumentCaptor<ISecurableObject> securableCaptor;
    private ArgumentCaptor<ISecurableObjectContainer> securableContainerCaptor;

    @Before
    public void setUp() throws Exception {

        securityManagerFacade = mock(ISecurityMgrFacade.class);
        type = MockFactory.mockNeType();

        neRepository = mock(NeEntityRepository.class);
        neInfoRepository = mock(NeInfoRepository.class);
        nePreferencesRepository = mock(NeUserPreferencesRepository.class);
        when(neRepository.getNeInfoRepository()).thenReturn(neInfoRepository);
        when(neRepository.getNeUserPreferencesRepository()).thenReturn(nePreferencesRepository);

        domainRepository = mock(DomainRepository.class);

        channelRepository = mock(ChannelEntityRepository.class);
        channelInfoRepository = mock(ChannelInfoRepository.class);
        mediatorRepository = mock(MediatorEntityRepository.class);
        mediatorInfoRepository = mock(MediatorInfoRepository.class);

        containerRepository = mock(ContainerRepository.class);
        systemRepository = mock(SystemRepository.class);
        when(containerRepository.query(anyInt())).thenReturn(Optional.empty());
        when(containerRepository.queryAllByNE(anyInt())).thenReturn(Collections.emptyList());
        when(containerRepository.queryAllBySystem(anyInt())).thenReturn(Collections.emptyList());

        when(mediatorRepository.getMediatorInfoRepository()).thenReturn(mediatorInfoRepository);
        when(channelRepository.getChannelInfoRepository()).thenReturn(channelInfoRepository);

        securableCaptor = ArgumentCaptor.forClass(ISecurableObject.class);
        securableContainerCaptor = ArgumentCaptor.forClass(ISecurableObjectContainer.class);

        when(type.getDefaultIcon()).thenReturn("iconId");

        securityManager = new SecurityManagerImpl(securityManagerFacade, domainRepository, neRepository,
                channelRepository, mediatorRepository, containerRepository, systemRepository);
    }

    private NeEntity buildNeEntity_with_system() {
        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(99, type);
        createDescriptor.getPreferences().setName("name").setContainerId(Optional.of(1));
        createDescriptor.getInfo().setIconId(Optional.of("neIconId"));
        return NeEntity.build(1, 1, createDescriptor);
    }

    private NeEntity buildNeEntity() {
        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(99, type);
        createDescriptor.getPreferences().setName("name");
        createDescriptor.getInfo().setIconId(Optional.of("neIconId"));
        return NeEntity.build(1, 1, createDescriptor);
    }

    @Test
    public void createNe() throws RepositoryException {
        when(domainRepository.queryAllForNE(1)).thenReturn(
                ImmutableList.of(new DomainInfoData(10, 1, "d10"), new DomainInfoData(20, 1, "d20")));

        when(channelRepository.queryChannel(99)).thenReturn(Optional.of(
                new ChannelEntity(
                    new ChannelInfoBuilder().setType("chtype").build(99, 1, 3),
                    null,
                    new ChannelUserPreferencesBuilder().setName("ch").build(99, 1))
            ));

        when(mediatorInfoRepository.query(3)).thenReturn(Optional.of(
                new MediatorInfoBuilder().setName("md").setTypeName("mdtype").build(3, 1)
            ));

        when(systemRepository.query(1)).thenReturn(Optional.of(new SystemInfo(1,1,"system")));

        final NeEntity neEntity = buildNeEntity_with_system();

        securityManager.createNe(neEntity);

        verify(securityManagerFacade).registerObject(eq(BiCNetComponentType.DCN_MANAGER), securableCaptor.capture());

        final ISecurableObject securableObject = securableCaptor.getValue();
        assertThat(securableObject.key(), is("NE=1"));
        assertThat(securableObject.getNativeName(), is("name"));
        assertThat(securableObject.getObjectName(), is("name"));
        assertThat(securableObject.getIconIdId(), is("neIconId"));
        assertThat(securableObject.getIconIdContext(), is(BiCNetComponentType.DCN_MANAGER));

        final ISecurableObjectContainerId[] containerList = securableObject.getContainerList();
        assertThat(containerList, is(arrayWithSize(4)));
        assertThat(containerList[0].key(), is("NetworkDomain=10"));
        assertThat(containerList[0].getContainerName(), is("d10"));
        assertThat(containerList[1].key(), is("NetworkDomain=20"));
        assertThat(containerList[1].getContainerName(), is("d20"));
        assertThat(containerList[2].key(), is("EM=99"));
        assertThat(containerList[2].getContainerName(), is("ch"));
        assertThat(containerList[3].key(), is("SystemContainer=1"));
        assertThat(containerList[3].getContainerName(), is("system"));

        assertThat(containerList[2], is(instanceOf(ISecurableObjectContainer.class)));
        final ISecurableObjectContainer ch = (ISecurableObjectContainer) containerList[2];
        assertThat(ch.getContainerList()[0].key(), is("Mediator=3"));
        assertThat(ch.getContainerList()[0].getContainerName(), is("md"));

        assertThat(containerList[3], is(instanceOf(ISecurableObjectContainer.class)));
        final ISecurableObjectContainer container = (ISecurableObjectContainer) containerList[3];
        assertThat(container.getContainerList().length, is(0));
    }

    @Test
    public void createNe_channelRepoError_doesNotIncludeChannelAndMediator() throws RepositoryException {
        when(domainRepository.queryAllForNE(anyInt())).thenReturn(
                ImmutableList.of(new DomainInfoData(1, 1, "d1"), new DomainInfoData(2, 1, "d2")));

        when(channelRepository.queryChannel(anyInt())).thenThrow(new RepositoryException());

        final NeEntity neEntity = buildNeEntity();

        securityManager.createNe(neEntity);

        verify(securityManagerFacade).registerObject(eq(BiCNetComponentType.DCN_MANAGER), securableCaptor.capture());

        final ISecurableObject securableObject = securableCaptor.getValue();
        assertThat(securableObject.key(), is("NE=1"));
        assertThat(securableObject.getNativeName(), is("name"));
        assertThat(securableObject.getObjectName(), is("name"));
        assertThat(securableObject.getIconIdId(), is("neIconId"));
        assertThat(securableObject.getIconIdContext(), is(BiCNetComponentType.DCN_MANAGER));

        final ISecurableObjectContainerId[] containerList = securableObject.getContainerList();
        assertThat(containerList, is(arrayWithSize(2)));
        assertThat(containerList[0].key(), is("NetworkDomain=1"));
        assertThat(containerList[0].getContainerName(), is("d1"));
        assertThat(containerList[1].key(), is("NetworkDomain=2"));
        assertThat(containerList[1].getContainerName(), is("d2"));
    }

    @Test
    public void createNe_mediatorRepoError_doesNotIncludeMediator() throws RepositoryException {
        when(domainRepository.queryAllForNE(anyInt())).thenReturn(
                ImmutableList.of(new DomainInfoData(1, 1, "d1"), new DomainInfoData(2, 1, "d2")));

        when(channelRepository.queryChannel(anyInt())).thenReturn(Optional.of(
                new ChannelEntity(
                    new ChannelInfoBuilder().setType("chtype").build(1, 1, 1),
                    null,
                    new ChannelUserPreferencesBuilder().setName("ch").build(1, 1))
            ));

        when(mediatorInfoRepository.query(anyInt())).thenThrow(new RepositoryException());

        final ContainerInfo primary = new ContainerInfo(100, 1, "primary");
        final ContainerInfo logical = new ContainerInfo(200, 1, "logical");

        when(containerRepository.queryAllByNE(1)).thenReturn(ImmutableList
                .of(new NeAssignmentData(primary, 1, AssignmentType.PRIMARY),
                        new NeAssignmentData(logical, 1, AssignmentType.LOGICAL)));

        final NeEntity neEntity = buildNeEntity();

        securityManager.createNe(neEntity);

        verify(securityManagerFacade).registerObject(eq(BiCNetComponentType.DCN_MANAGER), securableCaptor.capture());

        final ISecurableObject securableObject = securableCaptor.getValue();
        assertThat(securableObject.key(), is("NE=1"));
        assertThat(securableObject.getNativeName(), is("name"));
        assertThat(securableObject.getObjectName(), is("name"));
        assertThat(securableObject.getIconIdId(), is("neIconId"));
        assertThat(securableObject.getIconIdContext(), is(BiCNetComponentType.DCN_MANAGER));

        final ISecurableObjectContainerId[] containerList = securableObject.getContainerList();
        assertThat(containerList, is(arrayWithSize(5)));
        assertThat(containerList[0].key(), is("NetworkDomain=1"));
        assertThat(containerList[0].getContainerName(), is("d1"));
        assertThat(containerList[1].key(), is("NetworkDomain=2"));
        assertThat(containerList[1].getContainerName(), is("d2"));
        assertThat(containerList[2].key(), is("EM=1"));
        assertThat(containerList[2].getContainerName(), is("ch"));
        assertThat(containerList[3].key(), is("GenericContainer=100"));
        assertThat(containerList[3].getContainerName(), is("primary"));
        assertThat(containerList[4].key(), is("GenericContainer=200"));
        assertThat(containerList[4].getContainerName(), is("logical"));

        assertThat(containerList[2], is(instanceOf(ISecurableObjectContainer.class)));
        final ISecurableObjectContainer ch = (ISecurableObjectContainer) containerList[2];
        assertThat(ch.getContainerList(), is(nullValue()));
    }

    @Test
    public void deleteNe() throws RepositoryException {
        when(domainRepository.queryAllForNE(anyInt())).thenReturn(Collections.emptyList());
        when(channelRepository.queryChannel(anyInt())).thenReturn(Optional.empty());
        when(mediatorInfoRepository.query(anyInt())).thenReturn(Optional.empty());

        final NeEntity neEntity = buildNeEntity();

        securityManager.deleteNe(neEntity);

        verify(securityManagerFacade).unregisterObject(eq(BiCNetComponentType.DCN_MANAGER), securableCaptor.capture());

        assertThat(securableCaptor.getValue().getSecurableObjectId(),
                is(new SecurableObjectIdItem(neEntity.getPreferences().getName())));
    }

    @Test
    public void updateNe_withFullEntity() throws RepositoryException {
        when(domainRepository.queryAllForNE(anyInt())).thenReturn(Collections.emptyList());
        when(channelRepository.queryChannel(anyInt())).thenReturn(Optional.empty());
        when(mediatorInfoRepository.query(anyInt())).thenReturn(Optional.empty());

        final NeEntity neEntity = buildNeEntity();

        securityManager.updateNe(neEntity);

        verify(securityManagerFacade).updateObject(eq(BiCNetComponentType.DCN_MANAGER), securableCaptor.capture());

        assertThat(securableCaptor.getValue().getSecurableObjectId(),
                is(new SecurableObjectIdItem(neEntity.getPreferences().getName())));
    }

    @Test
    public void updateNe_withId() throws RepositoryException {
        final NeEntity neEntity = buildNeEntity();

        when(nePreferencesRepository.query(neEntity.getInfo().getId())).thenReturn(Optional.of(neEntity.getPreferences()));
        when(neInfoRepository.query(neEntity.getInfo().getId())).thenReturn(Optional.of(neEntity.getInfo()));
        when(domainRepository.queryAllForNE(neEntity.getInfo().getId())).thenReturn(Collections.emptyList());
        when(channelRepository.queryChannel(anyInt())).thenReturn(Optional.empty());
        when(mediatorInfoRepository.query(anyInt())).thenReturn(Optional.empty());

        securityManager.updateNe(neEntity.getInfo().getId());

        verify(securityManagerFacade).updateObject(eq(BiCNetComponentType.DCN_MANAGER), securableCaptor.capture());

        final ISecurableObject value = securableCaptor.getValue();
        assertThat(value.getSecurableObjectId(),
                is(new SecurableObjectIdItem(neEntity.getPreferences().getName())));
        assertThat(value.getIconIdId(), is("neIconId"));
    }

    @Test
    public void updateNe_withId_neIdentifierNotFound_doesNothing() throws RepositoryException {
        final NeEntity neEntity = buildNeEntity();

        when(nePreferencesRepository.query(neEntity.getInfo().getId())).thenReturn(Optional.empty());

        securityManager.updateNe(neEntity.getInfo().getId());

        verify(securityManagerFacade, never()).updateObject(eq(BiCNetComponentType.DCN_MANAGER), any(ISecurableObject.class));
    }

    @Test
    public void updateNe_withId_repositoryError_doesNothing() throws RepositoryException {
        final NeEntity neEntity = buildNeEntity();

        when(nePreferencesRepository.query(neEntity.getInfo().getId())).thenThrow(new RepositoryException());

        securityManager.updateNe(neEntity.getInfo().getId());

        verify(securityManagerFacade, never()).updateObject(eq(BiCNetComponentType.DCN_MANAGER), any(ISecurableObject.class));
    }

    @Test
    public void updateNe_withPreferences() throws RepositoryException {
        final NeEntity neEntity = buildNeEntity();

        when(neInfoRepository.query(neEntity.getInfo().getId())).thenReturn(Optional.of(neEntity.getInfo()));
        when(domainRepository.queryAllForNE(neEntity.getInfo().getId())).thenReturn(Collections.emptyList());
        when(channelRepository.queryChannel(anyInt())).thenReturn(Optional.empty());
        when(mediatorInfoRepository.query(anyInt())).thenReturn(Optional.empty());

        securityManager.updateNe(neEntity.getPreferences());

        verify(securityManagerFacade).updateObject(eq(BiCNetComponentType.DCN_MANAGER), securableCaptor.capture());

        final ISecurableObject value = securableCaptor.getValue();
        assertThat(value.getSecurableObjectId(),
                is(new SecurableObjectIdItem(neEntity.getPreferences().getName())));
        assertThat(value.getIconIdId(), is("neIconId"));
    }

    @Test
    public void updateNe_withPreferences_infoNotFound_doesNothing() throws RepositoryException {
        final NeEntity neEntity = buildNeEntity();

        when(neInfoRepository.query(anyInt())).thenReturn(Optional.empty());

        securityManager.updateNe(neEntity.getPreferences());

        verify(securityManagerFacade, never()).updateObject(eq(BiCNetComponentType.DCN_MANAGER), isA(ISecurableObject.class));
    }

    @Test
    public void updateNe_withPreferences_repoError_doesNothing() throws RepositoryException {
        final NeEntity neEntity = buildNeEntity();

        when(neInfoRepository.query(anyInt())).thenThrow(new RepositoryException());

        securityManager.updateNe(neEntity.getPreferences());

        verify(securityManagerFacade, never()).updateObject(eq(BiCNetComponentType.DCN_MANAGER), isA(ISecurableObject.class));
    }

    @Test
    public void updateChannel_withEntity() throws RepositoryException {

        when(mediatorInfoRepository.query(anyInt())).thenReturn(Optional.of(
                new MediatorInfoBuilder().setName("md").setTypeName("mdtype").build(1, 1)
            ));

        final ChannelEntity entity = new ChannelEntity(
                new ChannelInfoBuilder().setType("chtype").build(1, 1, 1),
                null,
                new ChannelUserPreferencesBuilder().setName("ch").build(1, 1));

        securityManager.updateChannel(entity);

        verify(securityManagerFacade).updateObjectContainer(eq(BiCNetComponentType.DCN_MANAGER),
                securableContainerCaptor.capture());

        final ISecurableObjectContainer securableObject = securableContainerCaptor.getValue();
        assertThat(securableObject.key(), is("EM=1"));
        assertThat(securableObject.getNativeName(), is("ch"));

        final ISecurableObjectContainerId[] containerList = securableObject.getContainerList();
        assertThat(containerList, is(arrayWithSize(1)));
        assertThat(containerList[0].key(), is("Mediator=1"));
        assertThat(containerList[0].getContainerName(), is("md"));
    }

    @Test
    public void updateChannel_withPreferences() throws RepositoryException {

        when(channelInfoRepository.query(anyInt())).thenReturn(Optional.of(
                new ChannelInfoBuilder().setType("chtype").build(1, 1, 1)
            ));

        when(mediatorInfoRepository.query(anyInt())).thenReturn(Optional.of(
                new MediatorInfoBuilder().setName("md").setTypeName("mdtype").build(1, 1)
            ));

        securityManager.updateChannel(new ChannelUserPreferencesBuilder().setName("ch").build(1, 1));

        verify(securityManagerFacade).updateObjectContainer(eq(BiCNetComponentType.DCN_MANAGER),
                securableContainerCaptor.capture());

        final ISecurableObjectContainer securableObject = securableContainerCaptor.getValue();
        assertThat(securableObject.key(), is("EM=1"));
        assertThat(securableObject.getNativeName(), is("ch"));

        final ISecurableObjectContainerId[] containerList = securableObject.getContainerList();
        assertThat(containerList, is(arrayWithSize(1)));
        assertThat(containerList[0].key(), is("Mediator=1"));
        assertThat(containerList[0].getContainerName(), is("md"));
    }

    @Test
    public void updateMediator_withEntity() throws RepositoryException {

        securityManager.updateMediator(
                new MediatorEntity(new MediatorInfoBuilder().setName("md").setTypeName("mdtype").build(1, 1), null));

        verify(securityManagerFacade).updateObjectContainer(eq(BiCNetComponentType.DCN_MANAGER),
                securableContainerCaptor.capture());

        final ISecurableObjectContainer securableObject = securableContainerCaptor.getValue();
        assertThat(securableObject.key(), is("Mediator=1"));
        assertThat(securableObject.getNativeName(), is("md"));
        assertThat(securableObject.getContainerName(), is("md"));
    }

    @Test
    public void updateMediator_withInfo() throws RepositoryException {

        securityManager.updateMediator(
                new MediatorInfoBuilder().setName("md").setTypeName("mdtype").build(1, 1));

        verify(securityManagerFacade).updateObjectContainer(eq(BiCNetComponentType.DCN_MANAGER),
                securableContainerCaptor.capture());

        final ISecurableObjectContainer securableObject = securableContainerCaptor.getValue();
        assertThat(securableObject.key(), is("Mediator=1"));
        assertThat(securableObject.getNativeName(), is("md"));
    }

    @Test
    public void updateContainer_no_parent() throws RepositoryException {
        securityManager.updateContainer(new ContainerInfo(1,1,"container"));

        verify(securityManagerFacade).updateObjectContainer(eq(BiCNetComponentType.DCN_MANAGER),
                securableContainerCaptor.capture());

        verify(containerRepository, never()).query(anyInt());

        final ISecurableObjectContainer securableObject = securableContainerCaptor.getValue();
        assertThat(securableObject.key(), is("GenericContainer=1"));
        assertThat(securableObject.getContainerName(), is("container"));
    }

    @Test
    public void updateContainer_parent_present() throws RepositoryException {
        final ContainerInfo rootContainer = new ContainerInfo(0, 1, "root");

        when(containerRepository.query(0)).thenReturn(Optional.of(rootContainer));

        securityManager.updateContainer(
                new ContainerInfo(1, 1, Optional.of(0), "container", Optional.empty(), Optional.empty()));

        verify(securityManagerFacade).updateObjectContainer(eq(BiCNetComponentType.DCN_MANAGER),
                securableContainerCaptor.capture());

        final ISecurableObjectContainer securableObject = securableContainerCaptor.getValue();
        assertThat(securableObject.key(), is("GenericContainer=1"));
        assertThat(securableObject.getContainerName(), is("container"));
        assertThat(securableObject.getNativeName(), is("container"));

        assertNotNull(securableObject.getContainerList());
        assertThat(securableObject.getContainerList().length, is(1));
        assertThat(securableObject.getContainerList()[0].getContainerName(), is("root"));
    }

    @Test public void updateSystem() throws RepositoryException {
        final ContainerInfo primary = new ContainerInfo(100, 1, "primary");
        final ContainerInfo logical = new ContainerInfo(200, 1, "logical");

        when(containerRepository.queryAllBySystem(1)).thenReturn(ImmutableList
                .of(new SystemAssignmentData(primary, 1, AssignmentType.PRIMARY),
                        new SystemAssignmentData(logical, 1, AssignmentType.LOGICAL)));

        securityManager.updateSystem(new SystemInfo(1, 1, "container"));

        verify(securityManagerFacade)
                .updateObjectContainer(eq(BiCNetComponentType.DCN_MANAGER), securableContainerCaptor.capture());

        final ISecurableObjectContainer securableObject = securableContainerCaptor.getValue();
        assertThat(securableObject.key(), is("SystemContainer=1"));
        assertThat(securableObject.getContainerName(), is("container"));
        assertThat(securableObject.getNativeName(), is("container"));

        assertNotNull(securableObject.getContainerList());
        assertThat(securableObject.getContainerList().length, is(2));
        assertThat(Stream.of(securableObject.getContainerList())
                        .filter(o -> o.getContainerName().equals("primary") || o.getContainerName().equals("logical")).count(),
                is(2L));
    }
}
