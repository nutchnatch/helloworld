package com.ossnms.dcn_manager.bicnet.connector.outbound.notifications;

import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.dcn_manager.composables.outbound.SecurityManager;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentAddedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentRemovedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerNeAssignmentUpdatedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentAddedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentRemovedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentUpdatedEvent;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;

import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class) public class ContainerNotificationsManagerImplTest {

    private static final String NAME = "name";
    private static final int CONTAINER_ID = 1;
    private static final int NE_ID = 200;
    private static final int SYSTEM_ID = 300;

    @Mock private IBiCNetMessageDispatcher messageDispatcher;
    @Mock private SecurityManager securityManager;

    @InjectMocks private ContainerNotificationsManagerImpl containerNotifications;

    @Test public void onCreate() throws Exception {
        containerNotifications.notifyCreate(new ContainerInfo(CONTAINER_ID, 0, NAME));

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
    }

    @Test public void onDelete() throws Exception {
        containerNotifications.notifyDelete(new ContainerInfo(CONTAINER_ID, 0, NAME));

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
    }

    @Test public void onNotifyChanges() throws Exception {
        final ContainerInfoMutationDescriptor mutation = new ContainerInfoMutationDescriptor(
                new ContainerInfo(CONTAINER_ID, 0, NAME)).setName("new name").setDescription(Optional.of("description"))
                .setUserText(Optional.of("userText")).setParentId(99);
        mutation.apply();
        containerNotifications.notifyChanges(mutation);

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(securityManager, times(1)).updateContainer(mutation.apply());
    }

    @Test public void onNotifyNeAssignmentAdded() throws Exception {
        ContainerNeAssignmentAddedEvent event = new ContainerNeAssignmentAddedEvent(CONTAINER_ID, NE_ID,
                AssignmentType.PRIMARY);

        containerNotifications.notifyChanges(event);

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(securityManager, times(1)).updateNe(NE_ID);
    }

    @Test public void onNotifyNeAssignmentUpdated() throws Exception {
        ContainerNeAssignmentUpdatedEvent event = new ContainerNeAssignmentUpdatedEvent(CONTAINER_ID, NE_ID,
                AssignmentType.PRIMARY);

        containerNotifications.notifyChanges(event);

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(securityManager, times(1)).updateNe(NE_ID);
    }

    @Test public void onNotifyNeAssignmentRemoved() throws Exception {
        ContainerNeAssignmentRemovedEvent event = new ContainerNeAssignmentRemovedEvent(CONTAINER_ID, NE_ID);

        containerNotifications.notifyChanges(event);

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(securityManager, times(1)).updateNe(NE_ID);
    }

    @Test public void onNotifySystemAssignmentAdded() throws Exception {
        ContainerSystemAssignmentAddedEvent event = new ContainerSystemAssignmentAddedEvent(CONTAINER_ID, SYSTEM_ID,
                AssignmentType.PRIMARY);

        containerNotifications.notifyChanges(event);

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(securityManager, times(1)).updateSystem(SYSTEM_ID);
    }

    @Test public void onNotifySystemAssignmentUpdated() throws Exception {
        ContainerSystemAssignmentUpdatedEvent event = new ContainerSystemAssignmentUpdatedEvent(CONTAINER_ID, SYSTEM_ID,
                AssignmentType.PRIMARY);

        containerNotifications.notifyChanges(event);

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(securityManager, times(1)).updateSystem(SYSTEM_ID);
    }

    @Test public void onNotifySystemAssignmentRemoved() throws Exception {
        ContainerSystemAssignmentRemovedEvent event = new ContainerSystemAssignmentRemovedEvent(CONTAINER_ID,
                SYSTEM_ID);

        containerNotifications.notifyChanges(event);

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(securityManager, times(1)).updateSystem(SYSTEM_ID);
    }
}
