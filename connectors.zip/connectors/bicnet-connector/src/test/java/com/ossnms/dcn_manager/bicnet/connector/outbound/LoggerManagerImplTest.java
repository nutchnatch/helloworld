package com.ossnms.dcn_manager.bicnet.connector.outbound;

import static com.google.common.collect.Iterables.toArray;
import static com.google.common.collect.Iterables.transform;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import com.google.common.collect.ImmutableSet;
import com.ossnms.bicnet.bcb.facade.logMgmt.ILogMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecord;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToCommandLog;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToImportHistory;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToNetworkEventLog;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToNetworkResourceLog;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertLoggerToSystemEventLog;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemImportHistory;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;

public class LoggerManagerImplTest {

    private static final String USER_NAME = "UserName";

    private ILogMgrFacade logMgrFacade;
    private BicnetCallContext context;
    private ISessionContext sessionContext;

    private LoggerManagerImpl logManager;

    @Before
    public void setup() {
        logMgrFacade = mock(ILogMgrFacade.class);
        context = mock(BicnetCallContext.class);
        sessionContext = mock(ISessionContext.class);

        logManager = new LoggerManagerImpl(logMgrFacade);

        when(context.getSessionContext()).thenReturn(sessionContext);
        when(sessionContext.getUserName()).thenReturn(USER_NAME);
    }

    @Test
    public void testCreateSystemEventLog() throws BcbException {
        logManager.createSystemEventLog(context, getLoggerItemNe());

        final ILogRecord[] logRecords = toArray(
                transform(ImmutableSet.copyOf(getLoggerItemNe()), new ConvertLoggerToSystemEventLog(USER_NAME)),
                ILogRecord.class);

        verify(logMgrFacade, times(1)).createLogRecords(context.getSessionContext(), logRecords);
    }

    @Test
    public void testCreateCommandLog() throws BcbException {
        logManager.createCommandLog(context, getLoggerItemNe());

        final ILogRecord[] logRecords = toArray(
                transform(ImmutableSet.copyOf(getLoggerItemNe()), new ConvertLoggerToCommandLog(USER_NAME)),
                ILogRecord.class);

        verify(logMgrFacade, times(1)).createLogRecords(context.getSessionContext(), logRecords);
    }

    @Test
    public void testCreateNetworkResourceLog() throws BcbException {
        logManager.createNetworkResourceLog(context, getLoggerItemNe());

        final ILogRecord[] logRecords = toArray(
                transform(ImmutableSet.copyOf(getLoggerItemNe()), new ConvertLoggerToNetworkResourceLog(USER_NAME)),
                ILogRecord.class);

        verify(logMgrFacade, times(1)).createLogRecords(context.getSessionContext(), logRecords);
    }

    @Test
    public void testCreateNetworkEventLog() throws BcbException {
        logManager.createNetworkEventLog(context, getLoggerItemNe());

        final ILogRecord[] logRecords = toArray(
                transform(ImmutableSet.copyOf(getLoggerItemNe()), new ConvertLoggerToNetworkEventLog(USER_NAME)),
                ILogRecord.class);

        verify(logMgrFacade, times(1)).createLogRecords(context.getSessionContext(), logRecords);
    }

    @Test
    public void testCreateImportHistoryLog() throws BcbException {
        logManager.createImportHistoryLog(context, getLoggerItemImportHistory());

        final ILogRecord[] logRecords = toArray(
                transform(ImmutableSet.copyOf(getLoggerItemImportHistory()), new ConvertLoggerToImportHistory()),
                ILogRecord.class);

        verify(logMgrFacade, times(1)).createLogRecords(context.getSessionContext(), logRecords);
    }

    @Test
    public void testCreateLoggerItemsError() throws BcbException {        
        doThrow(new BcbException()).when(logMgrFacade).createLogRecords(Matchers.eq(sessionContext),
                Matchers.any(ILogRecord[].class));

        logManager.createImportHistoryLog(context, getLoggerItemImportHistory());
    }

    private LoggerItemNe[] getLoggerItemNe() {
        final ImmutableSet<LoggerItemNe> loggerItemNes = ImmutableSet.of(new LoggerItemNe("AffectedObject1",
                "message1", 1, MessageSeverity.WARNING), new LoggerItemNe("AffectedObject2", "message2", 1,
                MessageSeverity.ERROR));

        return toArray(loggerItemNes, LoggerItemNe.class);
    }

    private LoggerItemImportHistory[] getLoggerItemImportHistory() {
        final ImmutableSet<LoggerItemImportHistory> loggerItemsImportHistory = ImmutableSet.of(
                new LoggerItemImportHistory("AffectedObject1", "message1", MessageSeverity.WARNING, 1),
                new LoggerItemImportHistory("AffectedObject2", "message2", MessageSeverity.ERROR, 2));

        return toArray(loggerItemsImportHistory, LoggerItemImportHistory.class);
    }
}
