package com.ossnms.dcn_manager.bicnet.connector.converter;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.util.Map.Entry;

import org.junit.Test;

import com.google.common.collect.Maps;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertEntryToBcbProperty;

public class ConvertEntryToBcbPropertyTest {
    final Entry<String, String> entry = Maps.immutableEntry("k1", "v1");

    @Test
    public void testCovert() {
        final Property property = ConvertEntryToBcbProperty.convert(entry);

        assertThat(property.getName(), is("k1"));
        assertThat(property.getValue(), is("v1"));
    }

    @Test
    public void testApply() {
        final ConvertEntryToBcbProperty convert = new ConvertEntryToBcbProperty();
        assertNotNull(convert.apply(entry));
    }

    @Test
    public void testNullApply() {
        final ConvertEntryToBcbProperty convert = new ConvertEntryToBcbProperty();
        assertNull(convert.apply(null));
    }
     
}
