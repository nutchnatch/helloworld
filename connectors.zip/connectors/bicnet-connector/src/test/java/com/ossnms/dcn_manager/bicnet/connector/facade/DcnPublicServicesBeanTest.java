package com.ossnms.dcn_manager.bicnet.connector.facade;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainParticipationIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainParticipationItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainParticipationId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainParticipationMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.bicnet.bcb.model.networkMgmt.UnableToComplyException;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.MediatorService;
import com.ossnms.dcn_manager.bicnet.connector.configuration.ServiceConfiguration;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.AlarmHelper;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.ChannelHelper;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.DomainHelper;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.MOHelper;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.NeHelper;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.SecurityManagerHelper;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.ServiceControlHelper;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.SystemContainerHelper;
import org.apache.commons.lang3.ArrayUtils;
import org.hamcrest.CoreMatchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyMapOf;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DcnPublicServicesBeanTest {

    private static final int DOMAIN_ID = 4;
    private static final String ID_1 = "id1";
    private static final String VALUE_1 = "value1";
    private static final String ID_2 = "id2";
    private static final String VALUE_2 = "value2";
    private static final int MEDIATOR_ID = 0;

    @Mock private ServiceControlHelper serviceControlHelper;
    @Mock private SecurityManagerHelper securityManagerHelper;
    @Mock private MOHelper manageObjectHelper;
    @Mock private ChannelHelper channelHelper;
    @Mock private NeHelper neHelper;
    @Mock private DomainHelper domainHelper;
    @Mock private AlarmHelper alarmHelper;
    @Mock private ServiceConfiguration serviceConfiguration;
    @Mock private SystemContainerHelper systemContainer;
    @Mock private MediatorService mediatorService;

    @InjectMocks private DcnPublicServicesBean bean;

    @Mock private ISessionContext sessionContext;

    @Test
    public void testUpdateMediatorProperties() throws Exception {

        final IMediatorId id = new MediatorIdItem(1);

        bean.setProperties(sessionContext, id, new Property[0]);

        verify(mediatorService).updateProperties(eq(sessionContext), eq(id), anyMapOf(String.class, String.class));
    }

    @Test
    public void testUpdateChannelProperties() throws Exception {

        final IEMId id = new EMIdItem(1);

        bean.setProperties(sessionContext, id, new Property[0]);

        verify(channelHelper).updateProperties(eq(sessionContext), eq(id), anyMapOf(String.class, String.class));
    }

    @Test
    public void testUpdateNEProperties() throws Exception {
        final INEId id = new NEIdItem(1);

        bean.setProperties(sessionContext, id, new Property[0]);

        verify(neHelper).updateProperties(eq(sessionContext), eq(id), anyMapOf(String.class, String.class));
    }

    @Test
    public void testGetNePropertiesFiltered() throws Exception {
        final INEId id = new NEIdItem(1);
        final String[] filter = { ID_2 };
        final Map<String, String> properties = ImmutableMap.of(ID_1, VALUE_1, ID_2, VALUE_2);

        when(neHelper.getProperties(eq(sessionContext), eq(id))).thenReturn(properties);

        final Property[] filtered = bean.getProperties(sessionContext, id, filter);

        assertThat(filtered.length, CoreMatchers.is(1));
        assertThat(filtered[0].getName(), CoreMatchers.is(ID_2));
        assertThat(filtered[0].getValue(), CoreMatchers.is(VALUE_2));

        verify(neHelper).getProperties(eq(sessionContext), eq(id));
    }

    @Test
    public void testGetChannelPropertiesFiltered() throws Exception {
        final IEMId id = new EMIdItem(1);
        final String[] filter = { ID_2 };
        final Map<String, String> properties = ImmutableMap.of(ID_1, VALUE_1, ID_2, VALUE_2);

        when(channelHelper.getProperties(eq(sessionContext), eq(id))).thenReturn(properties);

        final Property[] filtered = bean.getProperties(sessionContext, id, filter);

        assertThat(filtered.length, CoreMatchers.is(1));
        assertThat(filtered[0].getName(), CoreMatchers.is(ID_2));
        assertThat(filtered[0].getValue(), CoreMatchers.is(VALUE_2));

        verify(channelHelper).getProperties(eq(sessionContext), eq(id));
    }

    @Test
    public void testGetNeProperties() throws Exception {
        final INEId id = new NEIdItem(1);
        final String[] filter = { ID_2 };
        final Map<String, String> properties = ImmutableMap.of(ID_1, VALUE_1, ID_2, VALUE_2);

        when(neHelper.getProperties(eq(sessionContext), eq(id))).thenReturn(properties);

        final Property[] allProperties = bean.getProperties(sessionContext, id);

        assertThat(allProperties.length, CoreMatchers.is(2));
        assertThat(ArrayUtils.contains(allProperties, new Property(ID_1, VALUE_1)), CoreMatchers.is(true));
        assertThat(ArrayUtils.contains(allProperties, new Property(ID_2, VALUE_2)), CoreMatchers.is(true));

        verify(neHelper).getProperties(eq(sessionContext), eq(id));
    }

    @Test
    public void testGetMediatorPropertiesFiltered() throws Exception {
        final IMediatorId id = new MediatorIdItem(1);
        final String[] filter = { ID_2 };
        final Map<String, String> properties = ImmutableMap.of(ID_1, VALUE_1, ID_2, VALUE_2);

        when(mediatorService.getProperties(eq(sessionContext), eq(id))).thenReturn(properties);

        final Property[] filtered = bean.getProperties(sessionContext, id, filter);

        assertThat(filtered.length, CoreMatchers.is(1));
        assertThat(filtered[0].getName(), CoreMatchers.is(ID_2));
        assertThat(filtered[0].getValue(), CoreMatchers.is(VALUE_2));

        verify(mediatorService).getProperties(eq(sessionContext), eq(id));
    }

    @Test
    public void testGetMediatorProperties() throws Exception {
        final IMediatorId id = new MediatorIdItem(1);
        final String[] filter = { ID_2 };
        final Map<String, String> properties = ImmutableMap.of(ID_1, VALUE_1, ID_2, VALUE_2);

        when(mediatorService.getProperties(eq(sessionContext), eq(id))).thenReturn(properties);

        final Property[] allProperties = bean.getProperties(sessionContext, id);

        assertThat(allProperties.length, CoreMatchers.is(2));
        assertThat(ArrayUtils.contains(allProperties, new Property(ID_1, VALUE_1)), CoreMatchers.is(true));
        assertThat(ArrayUtils.contains(allProperties, new Property(ID_2, VALUE_2)), CoreMatchers.is(true));

        verify(mediatorService).getProperties(eq(sessionContext), eq(id));
    }

    @Test(expected=UnableToComplyException.class)
    public void testName() throws Exception {
        bean.setProperties(sessionContext, new SystemContainerIdItem(), new Property[0]);
    }

    @Test
    public void testCreateNEISessionContextINE() throws BcbException {
        final INE ne = mock(INE.class);

        bean.createNE(sessionContext, ne);

        verify(neHelper).createNE(sessionContext, ne);
    }

    @Test
    public void testCreateNEISessionContextStringIEMIdINEIdStringPropertyArray() throws BcbException {

        final String neProxyType = "proxytype";
        final IEMId parentEmId = new EMIdItem(2);
        final INEId parentNeId = new NEIdItem(1);
        final String neIdName = "idName";
        final Property[] neProperties = new Property[0];

        bean.createNE(sessionContext, neProxyType, parentEmId, parentNeId, neIdName, neProperties);

        verify(neHelper).createNE(sessionContext, neProxyType, parentEmId, neIdName, neProperties);
    }

    @Test
    public void createSystemContainer() throws BcbException {
        final ISystemContainer container = mock(ISystemContainer.class);

        bean.createSystemContainer(sessionContext, container);

        verify(systemContainer).createSystemContainer(sessionContext, container);
    }

    @Test
    public void deleteSystemContainer() throws BcbException {
        final ISystemContainerId systemcontainerId = mock(ISystemContainerId.class);

        bean.deleteSystemContainer(sessionContext, systemcontainerId);

        verify(systemContainer).deleteSystemContainer(sessionContext, systemcontainerId);
    }

    @Test
    public void getAllRegisteredEMTypes() throws BcbException {
        bean.getRegisteredEmTypes(sessionContext);

        verify(channelHelper).getRegisteredEmTypes(sessionContext);
    }

    @Test
    public void resynchronizeNEs() throws BcbException {
        final INEId[] id = new INEId[] { new NEIdItem(2) };

        bean.resynchronizeNEs(sessionContext, id);

        verify(neHelper).resynchronizeNEs(sessionContext, id);
    }

    @Test
    public void getSingleNetworkDomain() throws BcbException {
        final INetworkDomainId domainId = new NetworkDomainIdItem(DOMAIN_ID);

        bean.getSingleNetworkDomain(sessionContext, domainId);

        verify(domainHelper).getSingleNetworkDomain(sessionContext, domainId);
    }

    @Test
    public void getNetworkDomainList() throws BcbException {
        final INetworkDomainId domainId = new NetworkDomainIdItem(DOMAIN_ID);
        final INetworkDomainMarkable[] markable =
            new INetworkDomainMarkable[] { NetworkDomainItem.markableNetworkDomain(null) };

        bean.getNetworkDomainList(sessionContext, domainId, markable, 4);

        verify(domainHelper).getNetworkDomainList(sessionContext, domainId, markable, 4);
    }

    @Test
    public void getNetworkDomainIdsForNE() throws BcbException {
        final INEId neId = new NEIdItem(2);

        bean.getNetworkDomainIdsForNE(sessionContext, neId);

        verify(domainHelper).getNetworkDomainIdsForNE(sessionContext, neId);
    }

    @Test
    public void getNetworkDomainsForNE() throws BcbException {
        final INEId neId = new NEIdItem(2);

        bean.getNetworkDomainsForNE(sessionContext, neId);

        verify(domainHelper).getNetworkDomainsForNE(sessionContext, neId);
    }

    @Test
    public void getNEIdsInNetworkDomain() throws BcbException {
        final INetworkDomainId domainId = new NetworkDomainIdItem(DOMAIN_ID);

        bean.getNEIdsInNetworkDomain(sessionContext, domainId);

        verify(domainHelper).getNEIdsInNetworkDomain(sessionContext, domainId);
    }

    @Test
    public void getNEsInNetworkDomain() throws BcbException {
        final INetworkDomainId domainId = new NetworkDomainIdItem(DOMAIN_ID);

        bean.getNEsInNetworkDomain(sessionContext, domainId);

        verify(domainHelper).getNEsInNetworkDomain(sessionContext, domainId);
    }

    @Test
    public void getNetworkDomainParticipationList() throws BcbException {
        final INetworkDomainParticipationId domainId = new NetworkDomainParticipationIdItem(6, 7);
        final INetworkDomainParticipationMarkable[] markable =
            new INetworkDomainParticipationMarkable[] { NetworkDomainParticipationItem.markableNetworkDomainParticipation(null) };

        bean.getNetworkDomainParticipationList(sessionContext, domainId, markable, 9);

        verify(domainHelper).getNetworkDomainParticipationList(sessionContext, domainId, markable, 9);
    }

    @Test
    public void getSingleMediator() throws BcbException {
        final IMediatorId mediatorId = new MediatorIdItem(MEDIATOR_ID);

        bean.getSingleMediator(sessionContext, mediatorId);

        verify(mediatorService).getSingleMediator(sessionContext, mediatorId);
    }

    @Test
    public void getMediatorList() throws BcbException {
        final IMediatorId startAfter = new MediatorIdItem(MEDIATOR_ID);;
        final IMediatorMarkable[] filter = new IMediatorMarkable[0];
        final int howMany = 9;

        bean.getMediatorList(sessionContext, startAfter, filter, howMany);

        verify(mediatorService).getMediatorList(sessionContext, startAfter, filter, howMany);
    }

    @Test
    public void getMediatorIdList() throws BcbException {
        final IMediatorId startAfter = new MediatorIdItem(MEDIATOR_ID);;
        final IMediatorMarkable[] filter = new IMediatorMarkable[0];
        final int howMany = 8;

        bean.getMediatorIdList(sessionContext, startAfter, filter, howMany);

        verify(mediatorService).getMediatorIdList(sessionContext, startAfter, filter, howMany);
    }

    @Test
    public void createMediator() throws BcbException {
        final IMediator mediator = new MediatorItem();

        bean.createMediator(sessionContext, mediator);

        verify(mediatorService).createMediator(sessionContext, mediator);
    }

    @Test
    public void deleteMediator() throws BcbException {
        final IMediatorId mediatorId = new MediatorIdItem(MEDIATOR_ID);

        bean.deleteMediator(sessionContext, mediatorId);

        verify(mediatorService).deleteMediator(sessionContext, mediatorId);
    }

    @Test
    public void modifyMediator() throws BcbException {

        final IMediatorMarkable mediator = MediatorItem.markableMediator(null);

        bean.modifyMediator(sessionContext, mediator);

        verify(mediatorService).modifyMediator(sessionContext, mediator);
    }

    @Test
    public void activateMediators() throws BcbException {
        final IMediatorId[] mediators = new IMediatorId[0];

        bean.activateMediators(sessionContext, mediators);

        verify(mediatorService).activateMediators(sessionContext, mediators);
    }

    @Test
    public void deactivateMediators() throws BcbException {
        final IMediatorId[] mediators = new IMediatorId[0];

        bean.deactivateMediators(sessionContext, mediators);

        verify(mediatorService).deactivateMediators(sessionContext, mediators);
    }

    @Test
    public void deactivateAllMediators() throws BcbException {
        bean.deactivateAllMediators(sessionContext);

        verify(mediatorService).deactivateAllMediators(sessionContext);
    }

    @Test
    public void createMediator_withProperties() throws BcbException {
        final Property[] properties = new Property[] { new Property("a", "b") };
        final IMediator mediator = new MediatorItem();

        bean.createMediator(sessionContext, mediator, properties);

        final Map<String, String> propertiesMap = new HashMap<>();
        propertiesMap.put("a", "b");
        verify(mediatorService).store(sessionContext, mediator, propertiesMap);
    }

}
