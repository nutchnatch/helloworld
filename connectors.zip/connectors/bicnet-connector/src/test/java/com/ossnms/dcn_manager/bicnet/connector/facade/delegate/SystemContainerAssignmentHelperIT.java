package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentMarkable;
import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.HelperItTestBase;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSettingsRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.composables.configuration.HardwareConfigurationType;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItem;
import com.ossnms.dcn_manager.core.entities.container.RootContainerId;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentAddedEvent;
import com.ossnms.dcn_manager.core.events.container.ContainerSystemAssignmentRemovedEvent;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.unitils.dbunit.annotation.DataSet;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.apache.commons.lang3.ArrayUtils.contains;
import static org.apache.commons.lang3.ArrayUtils.isEmpty;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@DataSet public class SystemContainerAssignmentHelperIT extends HelperItTestBase {
    /**
     * IDS for existing objects in resource: SystemContainerAssignmentHelperIT.xml
     * <p>
     * Assignments SYSTEM_1 x (CONTAINER_ROOT and CONTAINER_1)
     * Assignments SYSTEM_2 x CONTAINER_1
     */
    private static final int SYSTEM_1 = 61;
    private static final int SYSTEM_2 = 62;
    private static final int CONTAINER_ROOT = RootContainerId.ID.get();
    private static final int CONTAINER_1 = 1;
    private static final int All = -1;

    @Mock private ISessionContext sessionContext;
    @Mock private ContainerNotifications notifications;
    @Mock private LoggerManagerImpl loggerManager;
    @Mock private StaticConfigurationSingleton hwConfiguration;

    @InjectMocks private JpaSystemRepositoryBean systemRepository;
    @InjectMocks private JpaContainerRepositoryBean containerRepository;
    @InjectMocks private JpaSettingsRepositoryBean settingsRepository;

    private SystemContainerAssignmentHelper helper;

    @Override @Before public void setUp() throws Exception {
        super.setUp();

        helper = new SystemContainerAssignmentHelper();
        helper.setLoggerManager(loggerManager);
        helper.setNotifications(notifications);
        helper.setContainerRepository(containerRepository);
        helper.setSystemRepository(systemRepository);
        helper.setSettingsRepository(settingsRepository);

        when(hwConfiguration.getHWConfiguration()).thenReturn(HardwareConfigurationType.MED);
        
        settingsRepository.initialize();
        settingsRepository.start();
    }

    @Test public void getSingleSystemGenericContainerAssignment() throws Exception {
        ISystemGenericContainerAssignmentId assignmentId = new SystemGenericContainerAssignmentIdItem(SYSTEM_1,
                CONTAINER_ROOT);

        final ISystemGenericContainerAssignment systemAssignment = helper
                .getSingleSystemGenericContainerAssignment(sessionContext, assignmentId);

        assertThat(systemAssignment.getSystemContainerId(), is(SYSTEM_1));
        assertThat(systemAssignment.getGenericContainerId(), is(CONTAINER_ROOT));
        assertThat(systemAssignment.getPrimary(), is(true));
    }

    @Test public void getSingleSystemGenericContainerAssignment_not_exists_container() throws Exception {
        ISystemGenericContainerAssignmentId assignmentId = new SystemGenericContainerAssignmentIdItem(SYSTEM_1, 60000);

        final ISystemGenericContainerAssignment systemAssignment = helper
                .getSingleSystemGenericContainerAssignment(sessionContext, assignmentId);

        assertThat(systemAssignment, is(nullValue()));
    }

    @Test public void getSingleSystemGenericContainerAssignment_not_exists_system() throws Exception {
        ISystemGenericContainerAssignmentId assignmentId = new SystemGenericContainerAssignmentIdItem(600000,
                CONTAINER_ROOT);

        final ISystemGenericContainerAssignment systemAssignment = helper
                .getSingleSystemGenericContainerAssignment(sessionContext, assignmentId);

        assertThat(systemAssignment, is(nullValue()));
    }

    @Test public void createSystemGenericContainerAssignment() throws Exception {
        ISystemGenericContainerAssignment newAssignment = new SystemGenericContainerAssignmentItem();
        newAssignment.setPrimary(false);
        newAssignment.setGenericContainerId(CONTAINER_1);
        newAssignment.setSystemContainerId(SYSTEM_2);

        helper.createSystemGenericContainerAssignment(sessionContext, newAssignment);

        verify(notifications, atLeastOnce()).notifyChanges(isA(ContainerSystemAssignmentAddedEvent.class));
        verify(loggerManager, atLeastOnce()).createCommandLog(isA(BicnetCallContext.class), isA(LoggerItem.class));
    }

    @Test(expected = BcbException.class) public void createSystemGenericContainerAssignment_existing_assignment()
            throws Exception {
        ISystemGenericContainerAssignment newAssignment = new SystemGenericContainerAssignmentItem();
        newAssignment.setPrimary(false);
        newAssignment.setGenericContainerId(CONTAINER_ROOT);
        newAssignment.setSystemContainerId(SYSTEM_2);

        helper.createSystemGenericContainerAssignment(sessionContext, newAssignment);
    }

    @Test
    public void deleteSystemGenericContainerAssignment_primary() throws Exception {
        ISystemGenericContainerAssignmentId newAssignment = new SystemGenericContainerAssignmentIdItem();
        newAssignment.setGenericContainerId(CONTAINER_ROOT);
        newAssignment.setSystemContainerId(SYSTEM_1);

        helper.deleteSystemGenericContainerAssignment(sessionContext, newAssignment);

        verify(notifications, atLeastOnce()).notifyChanges(isA(ContainerSystemAssignmentRemovedEvent.class));
        verify(loggerManager, atLeastOnce()).createCommandLog(isA(BicnetCallContext.class), isA(LoggerItem.class));

        final ISystemGenericContainerAssignment systemAssignment = helper
                .getSingleSystemGenericContainerAssignment(sessionContext, newAssignment);

        assertThat(systemAssignment, is(nullValue()));

        // verify primary change
        ISystemGenericContainerAssignmentId newPrimaryAssignment = new SystemGenericContainerAssignmentIdItem();
        newPrimaryAssignment.setGenericContainerId(CONTAINER_1);
        newPrimaryAssignment.setSystemContainerId(SYSTEM_1);
        final ISystemGenericContainerAssignment modify = helper
                .getSingleSystemGenericContainerAssignment(sessionContext, newPrimaryAssignment);

        assertThat(modify.getPrimary(), is(true));
    }

    @Test public void modifySystemGenericContainerAssignment() throws Exception {
        ISystemGenericContainerAssignmentMarkable updateAssignment = SystemGenericContainerAssignmentItem
                .markableSystemGenericContainerAssignment(null);
        updateAssignment.setPrimary(false);
        updateAssignment.setGenericContainerId(CONTAINER_ROOT);
        updateAssignment.setSystemContainerId(SYSTEM_1);

        helper.modifySystemGenericContainerAssignment(sessionContext, updateAssignment);

        final ISystemGenericContainerAssignment systemAssignment = helper
                .getSingleSystemGenericContainerAssignment(sessionContext, updateAssignment);

        assertThat(systemAssignment.getSystemContainerId(), is(SYSTEM_1));
        assertThat(systemAssignment.getGenericContainerId(), is(CONTAINER_ROOT));
        assertThat(systemAssignment.getPrimary(), is(false));
    }

    @Test public void getSystemGenericContainerAssignmentList_all_items() throws Exception {
        final SystemGenericContainerAssignmentReply systemAssignmentReply = helper
                .getSystemGenericContainerAssignmentList(null, null, null, All);

        final ISystemGenericContainerAssignment[] assignments = systemAssignmentReply.getData();

        assertThat(isEmpty(assignments), is(false));

        final List<ISystemGenericContainerAssignmentId> assignmentIds = Stream.of(assignments)
                .map(ISystemGenericContainerAssignment::getSystemGenericContainerAssignmentId)
                .collect(Collectors.toList());

        assertThat(assignmentIds.size(), is(3));
        assertTrue(assignmentIds.contains(new SystemGenericContainerAssignmentIdItem(SYSTEM_1, CONTAINER_ROOT)));
        assertTrue(assignmentIds.contains(new SystemGenericContainerAssignmentIdItem(SYSTEM_1, CONTAINER_1)));
        assertTrue(assignmentIds.contains(new SystemGenericContainerAssignmentIdItem(SYSTEM_2, CONTAINER_ROOT)));
    }

    @Test public void getSystemGenericContainerAssignmentList_limit() throws Exception {
        final SystemGenericContainerAssignmentReply systemAssignmentReply = helper
                .getSystemGenericContainerAssignmentList(null, null, null, 1);

        final ISystemGenericContainerAssignment[] assignments = systemAssignmentReply.getData();

        assertThat(assignments.length, is(1));
    }

    @Test public void getSystemGenericContainerAssignmentList_all_primary() throws Exception {

        ISystemGenericContainerAssignmentMarkable filter = SystemGenericContainerAssignmentItem
                .markableSystemGenericContainerAssignment(null);

        filter.setPrimary(true);

        final SystemGenericContainerAssignmentReply systemAssignmentReply = helper
                .getSystemGenericContainerAssignmentList(sessionContext, null,
                        new ISystemGenericContainerAssignmentMarkable[] { filter }, All);

        final ISystemGenericContainerAssignment[] assignments = systemAssignmentReply.getData();

        assertThat(isEmpty(assignments), is(false));

        final List<ISystemGenericContainerAssignmentId> assignmentIds = Stream.of(assignments)
                .map(ISystemGenericContainerAssignment::getSystemGenericContainerAssignmentId)
                .collect(Collectors.toList());

        assertThat(assignmentIds.size(), is(2));
        assertTrue(assignmentIds.contains(new SystemGenericContainerAssignmentIdItem(SYSTEM_1, CONTAINER_ROOT)));
        assertTrue(assignmentIds.contains(new SystemGenericContainerAssignmentIdItem(SYSTEM_2, CONTAINER_ROOT)));
    }

    @Test public void getSystemGenericContainerAssignmentList_all_by_system() throws Exception {

        ISystemGenericContainerAssignmentMarkable filter = SystemGenericContainerAssignmentItem
                .markableSystemGenericContainerAssignment(null);

        filter.setSystemContainerId(SYSTEM_1);

        final SystemGenericContainerAssignmentReply systemAssignmentReply = helper
                .getSystemGenericContainerAssignmentList(sessionContext, null,
                        new ISystemGenericContainerAssignmentMarkable[] { filter }, All);

        final ISystemGenericContainerAssignment[] assignments = systemAssignmentReply.getData();

        assertThat(isEmpty(assignments), is(false));

        final List<ISystemGenericContainerAssignmentId> assignmentIds = Stream.of(assignments)
                .map(ISystemGenericContainerAssignment::getSystemGenericContainerAssignmentId)
                .collect(Collectors.toList());

        assertThat(assignmentIds.size(), is(2));
        assertTrue(assignmentIds.contains(new SystemGenericContainerAssignmentIdItem(SYSTEM_1, CONTAINER_ROOT)));
        assertTrue(assignmentIds.contains(new SystemGenericContainerAssignmentIdItem(SYSTEM_1, CONTAINER_1)));
    }

    @Test public void getSystemGenericContainerAssignmentList_all_by_container() throws Exception {

        ISystemGenericContainerAssignmentMarkable filter = SystemGenericContainerAssignmentItem
                .markableSystemGenericContainerAssignment(null);

        filter.setGenericContainerId(CONTAINER_ROOT);

        final SystemGenericContainerAssignmentReply systemAssignmentReply = helper
                .getSystemGenericContainerAssignmentList(sessionContext, null,
                        new ISystemGenericContainerAssignmentMarkable[] { filter }, All);

        final ISystemGenericContainerAssignment[] assignments = systemAssignmentReply.getData();

        assertThat(isEmpty(assignments), is(false));

        final List<ISystemGenericContainerAssignmentId> assignmentIds = Stream.of(assignments)
                .map(ISystemGenericContainerAssignment::getSystemGenericContainerAssignmentId)
                .collect(Collectors.toList());

        assertThat(assignmentIds.size(), is(2));
        assertTrue(assignmentIds.contains(new SystemGenericContainerAssignmentIdItem(SYSTEM_1, CONTAINER_ROOT)));
        assertTrue(assignmentIds.contains(new SystemGenericContainerAssignmentIdItem(SYSTEM_2, CONTAINER_ROOT)));
    }

    @Test public void getSystemGenericContainerAssignmentList_by_container_and_system() throws Exception {

        ISystemGenericContainerAssignmentMarkable filter = SystemGenericContainerAssignmentItem
                .markableSystemGenericContainerAssignment(null);

        filter.setGenericContainerId(CONTAINER_ROOT);
        filter.setSystemContainerId(SYSTEM_1);

        final SystemGenericContainerAssignmentReply systemAssignmentReply = helper
                .getSystemGenericContainerAssignmentList(sessionContext, null,
                        new ISystemGenericContainerAssignmentMarkable[] { filter }, All);

        final ISystemGenericContainerAssignment[] assignments = systemAssignmentReply.getData();

        assertThat(isEmpty(assignments), is(false));

        final List<ISystemGenericContainerAssignmentId> assignmentIds = Stream.of(assignments)
                .map(ISystemGenericContainerAssignment::getSystemGenericContainerAssignmentId)
                .collect(Collectors.toList());

        assertThat(assignmentIds.size(), is(1));
        assertTrue(assignmentIds.contains(new SystemGenericContainerAssignmentIdItem(SYSTEM_1, CONTAINER_ROOT)));
    }

    @Test public void getSystemGenericContainerAssignmentList_by_container_and_system_type() throws Exception {

        ISystemGenericContainerAssignmentMarkable filter = SystemGenericContainerAssignmentItem
                .markableSystemGenericContainerAssignment(null);

        filter.setGenericContainerId(CONTAINER_ROOT);
        filter.setSystemContainerId(SYSTEM_1);
        filter.setPrimary(true);

        final SystemGenericContainerAssignmentReply systemAssignmentReply = helper
                .getSystemGenericContainerAssignmentList(sessionContext, null,
                        new ISystemGenericContainerAssignmentMarkable[] { filter }, All);

        final ISystemGenericContainerAssignment[] assignments = systemAssignmentReply.getData();

        assertThat(isEmpty(assignments), is(false));

        final List<ISystemGenericContainerAssignmentId> assignmentIds = Stream.of(assignments)
                .map(ISystemGenericContainerAssignment::getSystemGenericContainerAssignmentId)
                .collect(Collectors.toList());

        assertThat(assignmentIds.size(), is(1));
        assertTrue(assignmentIds.contains(new SystemGenericContainerAssignmentIdItem(SYSTEM_1, CONTAINER_ROOT)));
    }

    @DataSet("SystemContainerAssignmentHelperIT.empty.xml") @Test public void getSystemGenericContainerAssignmentList_empty()
            throws Exception {
        final SystemGenericContainerAssignmentReply systemAssignmentReply = helper
                .getSystemGenericContainerAssignmentList(sessionContext, null, null, All);

        final ISystemGenericContainerAssignment[] assignments = systemAssignmentReply.getData();

        assertThat(isEmpty(assignments), is(true));
    }

    @Test public void getSystemGenericContainerAssignmentIdList_all_items() throws Exception {
        final SystemGenericContainerAssignmentIdReply systemAssignmentReply = helper
                .getSystemGenericContainerAssignmentIdList(null, null, null, All);

        final ISystemGenericContainerAssignmentId[] assignments = systemAssignmentReply.getData();

        assertThat(assignments.length, is(3));
        assertTrue(contains(assignments, new SystemGenericContainerAssignmentIdItem(SYSTEM_1, CONTAINER_ROOT)));
        assertTrue(contains(assignments, new SystemGenericContainerAssignmentIdItem(SYSTEM_1, CONTAINER_1)));
        assertTrue(contains(assignments, new SystemGenericContainerAssignmentIdItem(SYSTEM_2, CONTAINER_ROOT)));
    }
}
