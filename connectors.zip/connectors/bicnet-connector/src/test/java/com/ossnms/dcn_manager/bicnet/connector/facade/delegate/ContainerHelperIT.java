package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerReply;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerMarkable;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.HelperItTestBase;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.core.entities.container.RootContainerId;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.unitils.dbunit.annotation.DataSet;

import static org.hamcrest.Matchers.arrayWithSize;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.verify;

@DataSet
public class ContainerHelperIT extends HelperItTestBase {
    @Mock private ContainerNotifications notifications;
    @Mock private LoggerManagerImpl loggerManager;

    @InjectMocks private JpaContainerRepositoryBean repository;
    @InjectMocks private JpaSystemRepositoryBean systemRepository;

    private ContainerHelper helper;

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();

        helper = new ContainerHelper();
        helper.setLoggerManager(loggerManager);
        helper.setNotifications(notifications);
        helper.setContainerRepository(repository);
        helper.setSystemRepository(systemRepository);
    }

    @Test
    public void createThenDeleteTopLevelContainer() throws Exception {

        final GenericContainerItem newContainer = new GenericContainerItem();
        newContainer.setIdName("new-container");
        newContainer.setDescription("new-description");
        newContainer.setUserLabel("new-userText");

        final IGenericContainer container = helper.createGenericContainer(null, newContainer);

        verify(notifications).notifyCreate(isA(ContainerInfo.class));

        assertThat(container, is(notNullValue()));
        assertThat(container.getId(), is(greaterThan(0)));
        assertThat(container.getIdName(), is(newContainer.getIdName()));
        assertThat(container.getDescription(), is(newContainer.getDescription()));
        assertThat(container.getUserLabel(), is(newContainer.getUserLabel()));
        assertThat(container.getParentId(), is(0));

        final IGenericContainer containerRead = helper.getSingleGenericContainer(null, container.getGenericContainerId());
        assertThat(containerRead, is(container));

        helper.deleteGenericContainer(null, container.getGenericContainerId());
        final IGenericContainer containerDeleted = helper.getSingleGenericContainer(null, container.getGenericContainerId());
        assertThat(containerDeleted, is(nullValue()));
    }

    @Test
    public void createThenDeleteChildContainer() throws Exception {

        final GenericContainerItem newContainer = new GenericContainerItem();
        newContainer.setIdName("new-container");
        newContainer.setParentId(1);

        final IGenericContainer container = helper.createGenericContainer(null, newContainer);

        verify(notifications).notifyCreate(isA(ContainerInfo.class));

        assertThat(container, is(notNullValue()));
        assertThat(container.getId(), is(greaterThan(0)));
        assertThat(container.getIdName(), is(newContainer.getIdName()));
        assertThat(container.getParentId(), is(1));

        final IGenericContainer containerRead = helper.getSingleGenericContainer(null, container.getGenericContainerId());
        assertThat(containerRead, is(container));

        helper.deleteGenericContainer(null, container.getGenericContainerId());
        final IGenericContainer containerDeleted = helper.getSingleGenericContainer(null, container.getGenericContainerId());
        assertThat(containerDeleted, is(nullValue()));
    }

    @Test
    public void getGenericContainerList() throws RepositoryException, BcbException {

        IGenericContainerMarkable filter;
        GenericContainerReply list;
        IGenericContainer[] data;

        // Get all

        list = helper.getGenericContainerList(null, null, null, -1);

        assertThat(list, is(notNullValue()));
        data = list.getData();
        assertThat(data, is(arrayWithSize(4)));
        assertThat(data[0].getId(), is(0));
        assertThat(data[0].getIdName(), is("root"));
        assertThat(data[1].getId(), is(1));
        assertThat(data[1].getIdName(), is("container_1"));
        assertThat(data[2].getId(), is(2));
        assertThat(data[2].getIdName(), is("container_2"));
        assertThat(data[3].getId(), is(3));
        assertThat(data[3].getIdName(), is("container_3"));

        // Get by name

        filter = GenericContainerItem.markableGenericContainer(null);
        filter.setIdName("container_2");
        list = helper.getGenericContainerList(null, null, new IGenericContainerMarkable[] { filter }, -1);

        assertThat(list, is(notNullValue()));
        data = list.getData();
        assertThat(data, is(arrayWithSize(1)));
        assertThat(data[0].getId(), is(2));
        assertThat(data[0].getIdName(), is("container_2"));

        // Get by ID

        filter = GenericContainerItem.markableGenericContainer(null);
        filter.setId(1);
        list = helper.getGenericContainerList(null, null, new IGenericContainerMarkable[] { filter }, -1);

        assertThat(list, is(notNullValue()));
        data = list.getData();
        assertThat(data, is(arrayWithSize(1)));
        assertThat(data[0].getId(), is(1));
        assertThat(data[0].getIdName(), is("container_1"));

        // Get by Parent

        filter = GenericContainerItem.markableGenericContainer(null);
        filter.setParentId(1);
        list = helper.getGenericContainerList(null, null, new IGenericContainerMarkable[] { filter }, -1);

        assertThat(list, is(notNullValue()));
        data = list.getData();
        assertThat(data, is(arrayWithSize(1)));
        assertThat(data[0].getId(), is(3));
        assertThat(data[0].getIdName(), is("container_3"));

        // Get all after first

        list = helper.getGenericContainerList(null, new GenericContainerIdItem(1), null, -1);

        assertThat(list, is(notNullValue()));
        data = list.getData();
        assertThat(data, is(arrayWithSize(2)));
        assertThat(data[0].getId(), is(2));
        assertThat(data[0].getIdName(), is("container_2"));
        assertThat(data[1].getId(), is(3));
        assertThat(data[1].getIdName(), is("container_3"));

        // Get by name or ID

        final IGenericContainerMarkable[] filters = new IGenericContainerMarkable[] {
            GenericContainerItem.markableGenericContainer(null), GenericContainerItem.markableGenericContainer(null)
        };
        filters[0].setId(3);
        filters[1].setIdName("container_2");
        list = helper.getGenericContainerList(null, null, filters, -1);

        assertThat(list, is(notNullValue()));
        data = list.getData();
        assertThat(data, is(arrayWithSize(2)));
        assertThat(data[0].getId(), is(2));
        assertThat(data[0].getIdName(), is("container_2"));
        assertThat(data[1].getId(), is(3));
        assertThat(data[1].getIdName(), is("container_3"));
    }

    @Test
    public void getSingleGenericContainer() throws RepositoryException, BcbException {

        final IGenericContainer container = helper.getSingleGenericContainer(null, new GenericContainerIdItem(2));
        assertThat(container, is(notNullValue()));
        assertThat(container.getId(), is(2));
        assertThat(container.getIdName(), is("container_2"));
    }

    @Test
    public void getSingleGenericContainer_unknownContainer_emptyResponse() throws RepositoryException, BcbException {

        final IGenericContainer container = helper.getSingleGenericContainer(null, new GenericContainerIdItem(12));
        assertThat(container, is(nullValue()));
    }

    @Test
    public void getGenericContainerList_limited() throws RepositoryException, BcbException {

        final GenericContainerReply list = helper.getGenericContainerList(null, null, null, 1);
        assertThat(list, is(notNullValue()));
        final IGenericContainer[] data = list.getData();
        assertThat(data, is(arrayWithSize(1)));
        assertThat(data[0].getId(), is(0));
        assertThat(data[0].getIdName(), is("root"));
    }

    @Test
    @DataSet("ContainerHelperIT.empty.xml")
    public void getGenericContainerList_empty() throws RepositoryException, BcbException {

        final GenericContainerReply list = helper.getGenericContainerList(null, null, null, -1);
        assertThat(list, is(notNullValue()));
        final IGenericContainer[] data = list.getData();
        assertThat(data, is(arrayWithSize(0)));
    }

    @Test
    public void getGenericContainerIdList() throws RepositoryException, BcbException {

        final GenericContainerIdReply list = helper.getGenericContainerIdList(null, null, null, -1);
        assertThat(list, is(notNullValue()));
        final IGenericContainerId[] data = list.getData();
        assertThat(data, is(arrayWithSize(4)));
        assertThat(data[0].getId(), is(0));
        assertThat(data[1].getId(), is(1));
        assertThat(data[2].getId(), is(2));
        assertThat(data[3].getId(), is(3));
    }

    @Test
    public void getGenericContainerIdList_limited() throws RepositoryException, BcbException {

        final GenericContainerIdReply list = helper.getGenericContainerIdList(null, null, null, 1);
        assertThat(list, is(notNullValue()));
        final IGenericContainerId[] data = list.getData();
        assertThat(data, is(arrayWithSize(1)));
        assertThat(data[0].getId(), is(0));
    }

    @Test
    @DataSet("ContainerHelperIT.empty.xml")
    public void getGenericContainerIdList_empty() throws RepositoryException, BcbException {

        final GenericContainerIdReply list = helper.getGenericContainerIdList(null, null, null, -1);
        assertThat(list, is(notNullValue()));
        final IGenericContainerId[] data = list.getData();
        assertThat(data, is(arrayWithSize(0)));
    }

    @Test(expected = BcbException.class)
    public void deleteRootContainer() throws Exception {
        helper.deleteGenericContainer(null, new GenericContainerIdItem(RootContainerId.ID.get()));
    }
}
