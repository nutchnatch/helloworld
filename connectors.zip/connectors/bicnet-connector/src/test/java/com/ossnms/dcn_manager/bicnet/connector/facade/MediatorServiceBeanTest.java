package com.ossnms.dcn_manager.bicnet.connector.facade;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.Matchers.arrayWithSize;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.hasItemInArray;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.unitils.inject.util.InjectionUtils;
import org.unitils.inject.util.PropertyAccess;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorReply;
import com.ossnms.bicnet.bcb.facade.scs.ISystemControlEjbFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorMarkable;
import com.ossnms.bicnet.bcb.model.scs.ScsSiteConfiguration;
import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownMediatorPropertyNames;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorDeleteDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstanceCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalDataMutationDescriptor;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.mediator.MediatorEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.ActivateMediatorEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.DeactivateMediatorEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.outbound.MediatorConnectionManager;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.MediatorInteractionManager;
import com.ossnms.dcn_manager.core.policies.MediatorSchedulingConfiguration;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelInfoRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository.MediatorConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository.MediatorInfoRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository.MediatorPhysicalDataRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceUpdates;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

@RunWith(MockitoJUnitRunner.class)
public class MediatorServiceBeanTest {

    @Mock private ISessionContext context;
    @Mock private StaticConfigurationSingleton configuration;
    @Mock private MediatorInstanceEntityRepository mediatorInstanceRepository;
    @Mock private MediatorPhysicalDataRepository mediatorPhysicalDataRepository;
    @Mock private MediatorPhysicalConnectionRepository physicalConnectionRepository;
    @Mock private MediatorSchedulingConfiguration mediatorScheduling;
    @Mock private MediatorEntityRepository mediatorRepository;
    @Mock private MediatorInfoRepository mediatorInfoRepository;
    @Mock private MediatorNotifications mediatorNotifications;
    @Mock private LoggerManagerImpl loggerManager;
    @Mock private MediatorInteractionManager mediatorScheduler;
    @Mock private Types<MediatorType> types;
    @Mock private ChannelEntityRepository channelRepository;
    @Mock private ChannelInfoRepository channelInfoRepository;
    @Mock private MessageSource<MediatorEvent> mediatorEvents;
    @Mock private ISystemControlEjbFacade scsFacade;
    @Mock private ChannelPhysicalConnectionRepository physicalChannelRepository;
    @Mock private NePhysicalConnectionRepository physicalNeRepository;
    @Mock private ChannelEntityRepository channelEntityRepository;
    @Mock private NeEntityRepository neEntityRepository;
    @Mock private ChannelNotifications channelNotifications;
    @Mock private NetworkElementNotifications neNotifications;
    @Mock private MediatorConnectionManager mediatorConnectionManager;
    @Mock private MediatorConnectionRepository mediatorConnectionRepository;

    @InjectMocks MediatorServiceBean bean;

    @Before
    public void setUp() throws RepositoryException {
        final MediatorType type = MockFactory.mockMediatorType();

        final MediatorManagers mediatorManagers =
                new MediatorManagers(mediatorRepository, mediatorInstanceRepository, mediatorNotifications, mediatorScheduler, mediatorEvents);
        InjectionUtils.injectIntoByType(mediatorManagers, MediatorManagers.class, bean, PropertyAccess.FIELD);

        final ChannelManagers channelManagers =
                new ChannelManagers(channelRepository, physicalChannelRepository, channelNotifications, null, null);
        InjectionUtils.injectIntoByType(channelManagers, ChannelManagers.class, bean, PropertyAccess.FIELD);

        final NetworkElementManagers neManagers =
                new NetworkElementManagers(neEntityRepository, physicalNeRepository, null, neNotifications, null);
        InjectionUtils.injectIntoByType(neManagers, NetworkElementManagers.class, bean, PropertyAccess.FIELD);

        when(types.values()).thenReturn(ImmutableList.of(type));
        when(types.get(anyString())).thenReturn(type);

        when(configuration.getMediatorTypes()).thenReturn(types);

        when(mediatorInfoRepository.queryByHost(anyString(), anyString())).thenReturn(Optional.empty());
        when(mediatorInfoRepository.query(anyString())).thenReturn(Optional.empty());
        when(mediatorRepository.queryMediatorName(anyInt())).thenReturn(Optional.<String>empty());
        when(mediatorRepository.getMediatorInfoRepository()).thenReturn(mediatorInfoRepository);
        
        when(mediatorRepository.getMediatorConnectionRepository()).thenReturn(mediatorConnectionRepository);

        when(channelRepository.getChannelInfoRepository()).thenReturn(channelInfoRepository);
        when(channelRepository.queryActivationRequiredIs(anyInt(), anyBoolean())).thenReturn(Collections.emptySet());

        when(mediatorPhysicalDataRepository.queryAll()).thenReturn(Collections.emptyList());

        when(physicalConnectionRepository.queryAll(anyInt())).thenReturn(Collections.emptyList());
        when(physicalConnectionRepository.tryUpdate(any(MediatorPhysicalConnectionMutationDescriptor.class)))
                .thenAnswer(new MutationAnswer<>());

        when(mediatorInstanceRepository.updateInstance(anyInt(), anyListOf(MediatorPhysicalDataMutationDescriptor.class), anyListOf(MediatorInstanceCreateDescriptor.class)))
                .thenReturn(new MediatorInstanceUpdates(Collections.emptyList(), Collections.emptyList()));
        when(mediatorInstanceRepository.queryAll(anyInt())).thenReturn(Collections.emptyList());
        when(mediatorInstanceRepository.getMediatorPhysicalDataRepository()).thenReturn(mediatorPhysicalDataRepository);
        when(mediatorInstanceRepository.getMediatorPhysicalConnectionRepository()).thenReturn(physicalConnectionRepository);
        
        when(mediatorConnectionRepository.query(anyInt())).thenReturn(Optional.<MediatorConnectionData>empty());

       
    }

    private MediatorEntity buildEntity(final int id) {
        return buildEntity(id, false);
    }

    private MediatorEntity buildEntity(final int id, final boolean activationRequired) {
        return buildEntity(id, activationRequired, ActualActivationState.INACTIVE);
    }

    private MediatorEntity buildEntity(final int id, final boolean activationRequired, final ActualActivationState actualActivationState) {
        return new MediatorEntity(
                new MediatorInfoBuilder()
                    .setName("mediator#" + id)
                    .setTypeName("typeName")
                    .setActivationRequired(activationRequired)
                    .build(id, 1),
                new MediatorConnectionBuilder()
                    .setActualActivationState(actualActivationState)
                    .build(id, 1));
    }

    private void setupChildChannel(final int parentMediatorId) throws RepositoryException {
        when(channelInfoRepository.queryChannelIdsUnderMediator(parentMediatorId)).thenReturn(
            Collections.singleton(33)
        );
    }

    @Test
    public void getMediatorList() throws Exception {
        when(mediatorRepository.queryAll()).thenReturn(ImmutableList.of(
            buildEntity(1), buildEntity(2)));

        final MediatorReply reply = bean.getMediatorList(context, null, null, -1);

        assertThat(reply, is(notNullValue()));
        final IMediator[] mediators = reply.getData();
        assertThat(mediators, is(arrayWithSize(2)));
        assertThat(mediators[0].getId(), is(1)); assertThat(mediators[0].getIdName(), is("mediator#1"));
        assertThat(mediators[1].getId(), is(2)); assertThat(mediators[1].getIdName(), is("mediator#2"));
    }

    @Test
    public void getMediatorList_limited() throws Exception {
        when(mediatorRepository.queryAll()).thenReturn(ImmutableList.of(
            buildEntity(2), buildEntity(1)));

        final MediatorReply reply = bean.getMediatorList(context, null, null, 1);

        assertThat(reply, is(notNullValue()));
        final IMediator[] mediators = reply.getData();
        assertThat(mediators, is(arrayWithSize(1)));
        assertThat(mediators[0].getId(), is(1)); assertThat(mediators[0].getIdName(), is("mediator#1"));
    }

    @Test
    public void getMediatorList_filtered() throws Exception {
        when(mediatorRepository.queryAll()).thenReturn(ImmutableList.of(
            buildEntity(1), buildEntity(2)));

        final IMediatorMarkable filter = MediatorItem.markableMediator(null);
        filter.setIdName("mediator#2");

        final MediatorReply reply = bean.getMediatorList(context, null, new IMediatorMarkable[] { filter }, -1);

        assertThat(reply, is(notNullValue()));
        final IMediator[] mediators = reply.getData();
        assertThat(mediators, is(arrayWithSize(1)));
        assertThat(mediators[0].getId(), is(2)); assertThat(mediators[0].getIdName(), is("mediator#2"));
    }

    @Test(expected=BcbException.class)
    public void getMediatorList_repoError_throws() throws Exception {
        when(mediatorRepository.queryAll()).thenThrow(new RepositoryException());
        bean.getMediatorList(context, null, null, 1);
    }

    @Test
    public void getMediatorIdList() throws Exception {
        when(mediatorRepository.queryAll()).thenReturn(ImmutableList.of(
            buildEntity(1), buildEntity(2)));

        final MediatorIdReply reply = bean.getMediatorIdList(context, null, null, -1);

        assertThat(reply, is(notNullValue()));
        final IMediatorId[] mediators = reply.getData();
        assertThat(mediators, is(arrayWithSize(2)));
        assertThat(mediators[0].getId(), is(1));
        assertThat(mediators[1].getId(), is(2));
    }

    @Test
    public void getMediatorIdList_limited() throws Exception {
        when(mediatorRepository.queryAll()).thenReturn(ImmutableList.of(
            buildEntity(1), buildEntity(2)));

        final MediatorIdReply reply = bean.getMediatorIdList(context, null, null, 1);

        assertThat(reply, is(notNullValue()));
        final IMediatorId[] mediators = reply.getData();
        assertThat(mediators, is(arrayWithSize(1)));
        assertThat(mediators[0].getId(), is(1));
    }

    @Test
    public void getMediatorIdList_filtered() throws Exception {
        when(mediatorRepository.queryAll()).thenReturn(ImmutableList.of(
            buildEntity(1), buildEntity(2)));

        final IMediatorMarkable filter = MediatorItem.markableMediator(null);
        filter.setIdName("mediator#2");

        final MediatorIdReply reply = bean.getMediatorIdList(context, null, new IMediatorMarkable[] { filter }, -1);

        assertThat(reply, is(notNullValue()));
        final IMediatorId[] mediators = reply.getData();
        assertThat(mediators, is(arrayWithSize(1)));
        assertThat(mediators[0].getId(), is(2));
    }

    @Test(expected=BcbException.class)
    public void getMediatorIdList_repoError_throws() throws Exception {
        when(mediatorRepository.queryAll()).thenThrow(new RepositoryException());
        bean.getMediatorIdList(context, null, null, 1);
    }

    @Test
    public void getMediator() throws Exception {
        when(mediatorRepository.query(23)).thenReturn(Optional.of(buildEntity(23)));

        final IMediator reply = bean.getSingleMediator(context, new MediatorIdItem(23));

        assertThat(reply, is(notNullValue()));
        assertThat(reply.getId(), is(23));
        assertThat(reply.getIdName(), is("mediator#23"));
    }

    @Test
    public void getMediator_unknownId_returnsNull() throws Exception {
        when(mediatorRepository.query(23)).thenReturn(Optional.empty());

        final IMediator reply = bean.getSingleMediator(context, new MediatorIdItem(23));

        assertThat(reply, is(nullValue()));
    }

    @Test(expected=BcbException.class)
    public void getMediator_repoError_throws() throws Exception {
        when(mediatorRepository.query(23)).thenThrow(new RepositoryException());
        bean.getSingleMediator(context, new MediatorIdItem(23));
    }

    @Test
    public void getRegisteredMediatorTypes() throws BcbException {
        final String[] mediatorTypes = bean.getRegisteredMediatorTypes(context);
        assertThat(mediatorTypes, hasItemInArray("type_name"));
    }

    @Test
    public void getProperties() throws Exception {
        when(mediatorRepository.query(42)).thenReturn(Optional.of(buildEntity(42)));

        when(scsFacade.getSiteConfiguration(context)).thenReturn(ScsSiteConfiguration.PRIMARY);
        when(scsFacade.isStandbyConfigured(context)).thenReturn(true);

        final Map<String, String> properties = bean.getProperties(context, new MediatorIdItem(42));
        assertThat(properties, allOf(
                hasEntry("ReconnectInterval", "10"),
                hasEntry("ConcurrentActivationsLimit", "20"),
                hasEntry("ConcurrentActivationsLimited", "true"),
                hasEntry("BCB-Attribute/Mediator/idName", "mediator#42"),
                hasEntry("SITE_ROLE", "primary"),
                hasEntry("STANDBY_CONFIGURED", "true"),
                hasEntry("NODE_MANAGER_SELECTED", "false")
            ));
    }

    @Test
    public void getProperties_unknownId_returnsNull() throws Exception {
        when(mediatorRepository.query(42)).thenReturn(Optional.empty());

        final Map<String, String> properties = bean.getProperties(context, new MediatorIdItem(42));
        assertThat(properties, is(nullValue()));
    }

    @Test(expected=BcbException.class)
    public void getProperties_repoError_throws() throws Exception {
        when(mediatorRepository.query(42)).thenThrow(new RepositoryException());
        bean.getProperties(context, new MediatorIdItem(42));
    }

    @Test
    public void createMediator() throws Exception {
        final IMediator newMediator = new MediatorItem();
        newMediator.setMediatorHost("ip");
        newMediator.setIdName("name");
        newMediator.setMediatorType(com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType.MVM);
        newMediator.setReconnectInterval(13);

        when(types.containsKey("MVM")).thenReturn(true);

        when(mediatorRepository.create(any(MediatorCreateDescriptor.class))).then(new Answer<MediatorEntity>() {
            @Override
            public MediatorEntity answer(final InvocationOnMock invocation) throws Throwable {
                final int id = 9;
                final MediatorCreateDescriptor descr = (MediatorCreateDescriptor) invocation.getArguments()[0];
                return new MediatorEntity(
                        new MediatorInfoData(id, 1, descr.getInfoInitialData()),
                        new MediatorConnectionData(id, 1, descr.getConnectionInitialData()));
            }
        });

        when(mediatorInstanceRepository.queryAll(9)).thenReturn(Collections.singletonList(
                new MediatorInstance(
                    new MediatorPhysicalDataBuilder().setHost("ip").setPriority(0).build(999, 9, 0),
                    new MediatorPhysicalConnectionBuilder().setActive(true).build(999, 9, 0))
            ));

        final IMediator created = bean.createMediator(context, newMediator);
        assertThat(created, is(notNullValue()));
        assertThat(created.getId(), not(is(0)));
        assertThat(created.getMediatorHost(), is(newMediator.getMediatorHost()));
        assertThat(created.getIdName(), is(newMediator.getIdName()));
        assertThat(created.getMediatorType(), is(newMediator.getMediatorType()));
        assertThat(created.getReconnectInterval(), is(newMediator.getReconnectInterval()));

        verify(mediatorNotifications).notifyCreate(any(MediatorEntity.class));
        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(eq(999), anyInt());
    }

    @Test(expected=BcbException.class)
    public void createMediator_unknownType_throws() throws Exception {
        final IMediator newMediator = new MediatorItem();
        newMediator.setMediatorHost("ip");
        newMediator.setIdName("name");
        newMediator.setMediatorType(com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType.MVM);
        newMediator.setReconnectInterval(13);

        when(types.containsKey("MVM")).thenReturn(false);

        bean.createMediator(context, newMediator);
    }

    @Test(expected=BcbException.class)
    public void createMediator_nullType_throws() throws Exception {
        final IMediator newMediator = new MediatorItem();
        newMediator.setMediatorHost("ip");
        newMediator.setIdName("name");
        newMediator.setMediatorType(null);
        newMediator.setReconnectInterval(13);

        when(types.containsKey("MVM")).thenReturn(false);

        bean.createMediator(context, newMediator);
    }

    @Test(expected=BcbException.class)
    public void createMediator_nullIdentification_throws() throws Exception {
        final IMediator newMediator = new MediatorItem();
        newMediator.setMediatorType(com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType.MVM);
        bean.createMediator(context, newMediator);
    }

    @Test
    public void storeMediator() throws Exception {
        final IMediator newMediator = new MediatorItem();
        newMediator.setMediatorHost("ip");
        newMediator.setIdName("name");
        newMediator.setMediatorType(com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType.MVM);
        newMediator.setReconnectInterval(13);

        final Map<String, String> newProps = ImmutableMap.of(WellKnownMediatorPropertyNames.DESCRIPTION, "blah");

        when(types.containsKey("MVM")).thenReturn(true);

        when(mediatorRepository.create(any(MediatorCreateDescriptor.class))).then(new Answer<MediatorEntity>() {
            @Override
            public MediatorEntity answer(final InvocationOnMock invocation) throws Throwable {
                final int id = 9;
                final MediatorCreateDescriptor descr = (MediatorCreateDescriptor) invocation.getArguments()[0];
                final MediatorEntity entity = new MediatorEntity(
                        new MediatorInfoData(id, 1, descr.getInfoInitialData()),
                        new MediatorConnectionData(id, 1, descr.getConnectionInitialData()));
                assertThat(entity.getInfo().getDescription(), is(present()));
                assertThat(entity.getInfo().getDescription().get(), is("blah"));
                return entity;
            }
        });

        when(mediatorInstanceRepository.queryAll(9)).thenReturn(Collections.singletonList(
                new MediatorInstance(
                    new MediatorPhysicalDataBuilder().setHost("ip").setPriority(0).build(999, 9, 0),
                    new MediatorPhysicalConnectionBuilder().setActive(true).build(999, 9, 0))
            ));

        final IMediator created = bean.store(context, newMediator, newProps);
        assertThat(created, is(notNullValue()));
        assertThat(created.getId(), not(is(0)));
        assertThat(created.getMediatorHost(), is(newMediator.getMediatorHost()));
        assertThat(created.getIdName(), is(newMediator.getIdName()));
        assertThat(created.getMediatorType(), is(newMediator.getMediatorType()));
        assertThat(created.getReconnectInterval(), is(newMediator.getReconnectInterval()));

        verify(mediatorNotifications).notifyCreate(any(MediatorEntity.class));
        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(eq(999), anyInt());
    }

    @Test(expected=BcbException.class)
    public void storeMediator_badProperty_throws() throws Exception {
        final IMediator newMediator = new MediatorItem();
        newMediator.setMediatorHost("ip");
        newMediator.setIdName("name");
        newMediator.setMediatorType(com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType.MVM);
        newMediator.setReconnectInterval(13);

        final Map<String, String> newProps = ImmutableMap.of(WellKnownMediatorPropertyNames.CONCURRENT_ACTIVATIONS_LIMIT, "xyz");

        bean.store(context, newMediator, newProps);
    }

    @Test(expected=BcbException.class)
    public void storeMediator_unknownType_throws() throws Exception {
        final IMediator newMediator = new MediatorItem();
        newMediator.setMediatorHost("ip");
        newMediator.setIdName("name");
        newMediator.setMediatorType(com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType.MVM);
        newMediator.setReconnectInterval(13);

        when(types.containsKey("MVM")).thenReturn(false);

        bean.store(context, newMediator, Collections.emptyMap());
    }

    @Test(expected=BcbException.class)
    public void storeMediator_nullType_throws() throws Exception {
        final IMediator newMediator = new MediatorItem();
        newMediator.setMediatorHost("ip");
        newMediator.setIdName("name");
        newMediator.setMediatorType(null);
        newMediator.setReconnectInterval(13);

        when(types.containsKey("MVM")).thenReturn(false);

        bean.store(context, newMediator, Collections.emptyMap());
    }

    @Test(expected=BcbException.class)
    public void storeMediator_nullIdentification_throws() throws Exception {
        final IMediator newMediator = new MediatorItem();
        newMediator.setMediatorType(com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType.MVM);
        bean.store(context, newMediator, Collections.emptyMap());
    }

    @Test
    public void storeMediator_nullProperties_ignores() throws Exception {
        final IMediator newMediator = new MediatorItem();
        newMediator.setMediatorHost("ip");
        newMediator.setIdName("name");
        newMediator.setMediatorType(com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorType.MVM);
        newMediator.setReconnectInterval(13);

        when(types.containsKey("MVM")).thenReturn(true);

        when(mediatorRepository.create(any(MediatorCreateDescriptor.class))).then(new Answer<MediatorEntity>() {
            @Override
            public MediatorEntity answer(final InvocationOnMock invocation) throws Throwable {
                final int id = 9;
                final MediatorCreateDescriptor descr = (MediatorCreateDescriptor) invocation.getArguments()[0];
                return new MediatorEntity(
                        new MediatorInfoData(id, 1, descr.getInfoInitialData()),
                        new MediatorConnectionData(id, 1, descr.getConnectionInitialData()));
            }
        });

        when(mediatorInstanceRepository.queryAll(9)).thenReturn(Collections.singletonList(
                new MediatorInstance(
                    new MediatorPhysicalDataBuilder().setHost("ip").setPriority(0).build(999, 9, 0),
                    new MediatorPhysicalConnectionBuilder().setActive(true).build(999, 9, 0))
            ));

        final IMediator created = bean.store(context, newMediator, null);
        assertThat(created, is(notNullValue()));
        assertThat(created.getId(), not(is(0)));
        assertThat(created.getMediatorHost(), is(newMediator.getMediatorHost()));
        assertThat(created.getIdName(), is(newMediator.getIdName()));
        assertThat(created.getMediatorType(), is(newMediator.getMediatorType()));
        assertThat(created.getReconnectInterval(), is(newMediator.getReconnectInterval()));
    }

    @Test
    public void deleteMediator() throws Exception {

        when(mediatorRepository.query(1)).thenReturn(Optional.of(buildEntity(1)));
        when(mediatorInstanceRepository.queryAll(1)).thenReturn(Collections.singletonList(
                new MediatorInstance(
                    new MediatorPhysicalDataBuilder().setHost("ip").setPriority(0).build(999, 9, 0),
                    new MediatorPhysicalConnectionBuilder().setActive(true).build(999, 9, 0))
            ));

        setupChildChannel(987);

        bean.deleteMediator(context, new MediatorIdItem(1));

        final ArgumentCaptor<MediatorDeleteDescriptor> deleteCaptor = ArgumentCaptor.forClass(MediatorDeleteDescriptor.class);
        verify(mediatorRepository).delete(deleteCaptor.capture());

        assertThat(deleteCaptor.getValue().getId(), is(1));

        verify(mediatorNotifications).notifyDelete(any(MediatorEntity.class));
        verify(mediatorScheduling).onMediatorRemoved(999);
    }

    @Test
    public void deleteMediator_mediatorDoesNotExist_ignores() throws Exception {

        when(mediatorRepository.query(1)).thenReturn(Optional.empty());

        bean.deleteMediator(context, new MediatorIdItem(1));

        verify(mediatorRepository, never()).delete(any(MediatorDeleteDescriptor.class));
    }

    @Test(expected=BcbException.class)
    public void deleteMediator_repositoryError_throws() throws Exception {

        when(mediatorRepository.query(1)).thenReturn(Optional.of(buildEntity(1)));

        setupChildChannel(987);

        doThrow(new RepositoryException()).when(mediatorRepository).delete(any(MediatorDeleteDescriptor.class));

        bean.deleteMediator(context, new MediatorIdItem(1));
    }

    @Test(expected=BcbException.class)
    public void deleteMediator_mediatorHasChildren_throws() throws Exception {

        when(mediatorRepository.query(1)).thenReturn(Optional.of(buildEntity(1)));

        setupChildChannel(1);

        doThrow(new RepositoryException()).when(mediatorRepository).delete(any(MediatorDeleteDescriptor.class));

        bean.deleteMediator(context, new MediatorIdItem(1));
    }

    @Test
    public void updateProperties() throws Exception {

        final Map<String, String> newProps = ImmutableMap.of(WellKnownMediatorPropertyNames.CONCURRENT_ACTIVATIONS_LIMIT, "99");

        when(mediatorRepository.query(34)).thenReturn(Optional.of(buildEntity(34)));

        when(mediatorInstanceRepository.queryAll(34)).thenReturn(Collections.singletonList(
                new MediatorInstance(
                    new MediatorPhysicalDataBuilder().setHost("ip").setPriority(0).build(999, 9, 0),
                    new MediatorPhysicalConnectionBuilder().setActive(true).build(999, 9, 0))
            ));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class)))
            .then(new Answer<Optional<MediatorInfoData>>() {
                @Override
                public Optional<MediatorInfoData> answer(final InvocationOnMock invocation)
                        throws Throwable {
                    final MediatorInfoMutationDescriptor mutation = (MediatorInfoMutationDescriptor) invocation.getArguments()[0];
                    assertThat(mutation.getConcurrentActivationsLimit(), is(present()));
                    assertThat(mutation.getConcurrentActivationsLimit().get(), is(99));
                    final MediatorInfoData infoData = mutation.apply();
                    mutation.applied();
                    return Optional.of(infoData);
                }
            });

        
        when(mediatorPhysicalDataRepository.queryAll()).thenReturn(ImmutableList.of(
                new MediatorPhysicalDataBuilder().build(999, 9, 0),
                new MediatorPhysicalDataBuilder().build(9987, 8856, 0)
            ));


        final MediatorConnectionData mediatorConnectionData = new MediatorConnectionBuilder().setActualActivationState(ActualActivationState.ACTIVE).build(34, 0);

        when(mediatorConnectionRepository.query(34)).thenReturn(Optional.of(mediatorConnectionData));

        bean.updateProperties(context, new MediatorIdItem(34), newProps);

        verify(mediatorInfoRepository).tryUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorNotifications).notifyUpdate(any(MediatorInfoMutationDescriptor.class));
        verify(mediatorScheduling).setMaxOngoingMediatorJobCount(eq(999), anyInt());
    }

    @Test(expected=BcbException.class)
    public void updateProperties_unknownMediator_throws() throws Exception {

        when(mediatorRepository.query(anyInt())).thenReturn(Optional.empty());

        bean.updateProperties(context, new MediatorIdItem(34), Collections.emptyMap());
    }

    @Test(expected=BcbException.class)
    public void updateProperties_repoErrorOnQuery_throws() throws Exception {

        when(mediatorRepository.query(anyInt())).thenThrow(new RepositoryException());

        bean.updateProperties(context, new MediatorIdItem(34), Collections.emptyMap());
    }

    @Test(expected=BcbException.class)
    public void updateProperties_repoErrorOnUpdate_throws() throws Exception {

        final Map<String, String> newProps = ImmutableMap.of(WellKnownMediatorPropertyNames.CONCURRENT_ACTIVATIONS_LIMIT, "99");

        when(mediatorRepository.query(34)).thenReturn(Optional.of(buildEntity(34)));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class)))
            .thenThrow(new RepositoryException());

        bean.updateProperties(context, new MediatorIdItem(34), newProps);
    }

    @Test(expected=BcbException.class)
    public void updateProperties_badValue_throws() throws Exception {

        final Map<String, String> newProps = ImmutableMap.of(WellKnownMediatorPropertyNames.CONCURRENT_ACTIVATIONS_LIMIT, "xpto");

        when(mediatorRepository.query(34)).thenReturn(Optional.of(buildEntity(34)));

        bean.updateProperties(context, new MediatorIdItem(34), newProps);
    }

    @Test
    public void activateMediators_severalFromInactive() throws Exception {

        when(mediatorRepository.query(2)).thenReturn(Optional.of(buildEntity(2, false)));
        when(mediatorRepository.query(3)).thenReturn(Optional.of(buildEntity(3, false)));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class)))
            .then(new Answer<Optional<MediatorInfoData>>() {
                @Override
                public Optional<MediatorInfoData> answer(final InvocationOnMock invocation)
                        throws Throwable {
                    final MediatorInfoMutationDescriptor mutation = (MediatorInfoMutationDescriptor) invocation.getArguments()[0];
                    assertThat(mutation.getActivationRequired(), is(present()));
                    assertThat(mutation.getActivationRequired().get(), is(true));
                    final MediatorInfoData infoData = mutation.apply();
                    mutation.applied();
                    return Optional.of(infoData);
                }
            });

        when(physicalConnectionRepository.queryAll(2)).thenReturn(Collections.singleton(new MediatorPhysicalConnectionBuilder().
        		setActive(true).setActualActivationState(ActualActivationState.INACTIVE).build(22, 2, 0)));
        when(physicalConnectionRepository.queryAll(3)).thenReturn(Collections.singleton(new MediatorPhysicalConnectionBuilder().
                setActive(true).setActualActivationState(ActualActivationState.INACTIVE).build(33, 3, 0)));


        bean.activateMediators(context, new IMediatorId[] { new MediatorIdItem(2), new MediatorIdItem(3) });

        verify(mediatorNotifications, times(2)).notifyChanges(any(ActivateMediatorEvent.class));
        verify(mediatorInfoRepository, times(2)).tryUpdate(any(MediatorInfoMutationDescriptor.class));
    }

    @Test
    public void activateMediators_fromInactive() throws Exception {

        when(mediatorRepository.query(2)).thenReturn(Optional.of(buildEntity(2, false)));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class)))
            .then(new Answer<Optional<MediatorInfoData>>() {
                @Override
                public Optional<MediatorInfoData> answer(final InvocationOnMock invocation)
                        throws Throwable {
                    final MediatorInfoMutationDescriptor mutation = (MediatorInfoMutationDescriptor) invocation.getArguments()[0];
                    assertThat(mutation.getActivationRequired(), is(present()));
                    assertThat(mutation.getActivationRequired().get(), is(true));
                    final MediatorInfoData infoData = mutation.apply();
                    mutation.applied();
                    return Optional.of(infoData);
                }
            });

        when(physicalConnectionRepository.queryAll(2)).thenReturn(Collections.singleton(
            new MediatorPhysicalConnectionBuilder()
                .setActive(true)
        		.setActualActivationState(ActualActivationState.ACTIVE)
                .build(22, 2, 0)));

        bean.activateMediators(context, new IMediatorId[] { new MediatorIdItem(2) });

        verify(mediatorNotifications).notifyChanges(any(ActivateMediatorEvent.class));
        verify(mediatorInfoRepository).tryUpdate(any(MediatorInfoMutationDescriptor.class));
    }

    @Test(expected=BcbException.class)
    public void activateMediators_fromActive_throws() throws Exception {

        when(mediatorRepository.query(2)).thenReturn(Optional.of(buildEntity(2, true)));

        bean.activateMediators(context, new IMediatorId[] { new MediatorIdItem(2) });
    }

    @Test(expected=BcbException.class)
    public void activateMediators_unknownMediator_throws() throws Exception {

        when(mediatorRepository.query(anyInt())).thenReturn(Optional.empty());

        bean.activateMediators(context, new IMediatorId[] { new MediatorIdItem(989) });
    }

    @Test(expected=BcbException.class)
    public void activateMediators_repoError_throws() throws Exception {

        when(mediatorRepository.query(2)).thenThrow(new RepositoryException());

        bean.activateMediators(context, new IMediatorId[] { new MediatorIdItem(2) });
    }

    @Test(expected=BcbException.class)
    public void activateMediators_updateFailed_throws() throws Exception {

        when(mediatorRepository.query(2)).thenReturn(Optional.of(buildEntity(2, false)));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class)))
            .thenReturn(Optional.empty());

        bean.activateMediators(context, new IMediatorId[] { new MediatorIdItem(2) });
    }

    @Test
    public void deactivateMediators_severalFromAactive() throws Exception {

        when(mediatorRepository.query(2)).thenReturn(Optional.of(buildEntity(2, true)));
        when(mediatorRepository.query(3)).thenReturn(Optional.of(buildEntity(3, true)));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class)))
            .then(new Answer<Optional<MediatorInfoData>>() {
                @Override
                public Optional<MediatorInfoData> answer(final InvocationOnMock invocation)
                        throws Throwable {
                    final MediatorInfoMutationDescriptor mutation = (MediatorInfoMutationDescriptor) invocation.getArguments()[0];
                    assertThat(mutation.getActivationRequired(), is(present()));
                    assertThat(mutation.getActivationRequired().get(), is(false));
                    final MediatorInfoData infoData = mutation.apply();
                    mutation.applied();
                    return Optional.of(infoData);
                }
            });

        when(physicalConnectionRepository.queryAll(2)).thenReturn(Collections.singleton(new MediatorPhysicalConnectionBuilder().
        		setActualActivationState(ActualActivationState.ACTIVE).build(22, 2, 0)));
        when(physicalConnectionRepository.queryAll(3)).thenReturn(Collections.singleton(new MediatorPhysicalConnectionBuilder().
        		setActualActivationState(ActualActivationState.ACTIVE).build(33, 3, 0)));


        bean.deactivateMediators(context, new IMediatorId[] { new MediatorIdItem(2), new MediatorIdItem(3) });

        verify(mediatorNotifications, times(2)).notifyChanges(any(DeactivateMediatorEvent.class));
        verify(mediatorInfoRepository, times(2)).tryUpdate(any(MediatorInfoMutationDescriptor.class));
    }

    @Test
    public void deactivateMediators_fromActive() throws Exception {

        when(mediatorRepository.query(2)).thenReturn(Optional.of(buildEntity(2, true)));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class)))
            .then(new Answer<Optional<MediatorInfoData>>() {
                @Override
                public Optional<MediatorInfoData> answer(final InvocationOnMock invocation)
                        throws Throwable {
                    final MediatorInfoMutationDescriptor mutation = (MediatorInfoMutationDescriptor) invocation.getArguments()[0];
                    assertThat(mutation.getActivationRequired(), is(present()));
                    assertThat(mutation.getActivationRequired().get(), is(false));
                    final MediatorInfoData infoData = mutation.apply();
                    mutation.applied();
                    return Optional.of(infoData);
                }
            });

        when(physicalConnectionRepository.queryAll(2)).thenReturn(Collections.singleton(new MediatorPhysicalConnectionBuilder().
        		setActualActivationState(ActualActivationState.ACTIVE).build(22, 2, 0)));

        bean.deactivateMediators(context, new IMediatorId[] { new MediatorIdItem(2) });

        verify(mediatorNotifications).notifyChanges(any(DeactivateMediatorEvent.class));
        verify(mediatorInfoRepository).tryUpdate(any(MediatorInfoMutationDescriptor.class));
    }

    @Test
    public void deactivateMediators_fromInactive_ignores() throws Exception {

        when(mediatorRepository.query(2)).thenReturn(Optional.of(buildEntity(2, false)));

        when(physicalConnectionRepository.queryAll(2)).thenReturn(Collections.singleton(new MediatorPhysicalConnectionBuilder().
        		setActualActivationState(ActualActivationState.ACTIVE).build(22, 2, 0)));

        bean.deactivateMediators(context, new IMediatorId[] { new MediatorIdItem(2) });

        verify(mediatorNotifications, never()).notifyChanges(any(DeactivateMediatorEvent.class));
        verify(mediatorInfoRepository, never()).tryUpdate(any(MediatorInfoMutationDescriptor.class));
    }

    @Test(expected=BcbException.class)
    public void deactivateMediators_unknownMediator_throws() throws Exception {

        when(mediatorRepository.query(anyInt())).thenReturn(Optional.empty());

        when(physicalConnectionRepository.queryAll(anyInt())).thenReturn(Collections.emptyList());

        bean.deactivateMediators(context, new IMediatorId[] { new MediatorIdItem(989) });
    }

    @Test(expected=BcbException.class)
    public void deactivateMediators_repoError_throws() throws Exception {

        when(mediatorRepository.query(2)).thenThrow(new RepositoryException());

        when(physicalConnectionRepository.queryAll(2)).thenReturn(Collections.singleton(new MediatorPhysicalConnectionBuilder().
        		setActualActivationState(ActualActivationState.ACTIVE).build(22, 2, 0)));

        bean.deactivateMediators(context, new IMediatorId[] { new MediatorIdItem(2) });
    }

    @Test
    public void deactivateMediators_updateFailed_ignores() throws Exception {

        when(mediatorRepository.query(2)).thenReturn(Optional.of(buildEntity(2, false)));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class)))
            .thenReturn(Optional.empty());

        when(physicalConnectionRepository.queryAll(2)).thenReturn(Collections.singleton(new MediatorPhysicalConnectionBuilder().
        		setActualActivationState(ActualActivationState.ACTIVE).build(22, 2, 0)));

        bean.deactivateMediators(context, new IMediatorId[] { new MediatorIdItem(2) });

        verify(mediatorNotifications, never()).notifyChanges(any(DeactivateMediatorEvent.class));
    }

    @Test
    public void deactivateAllMediators() throws Exception {

        final MediatorEntity entity2 = buildEntity(2, true);
        final MediatorEntity entity3 = buildEntity(3, false);
        final MediatorEntity entity4 = buildEntity(4, true);

        when(mediatorRepository.query(2)).thenReturn(Optional.of(entity2));
        when(mediatorRepository.query(3)).thenReturn(Optional.of(entity3));
        when(mediatorRepository.query(4)).thenReturn(Optional.of(entity4));

        when(mediatorInfoRepository.queryAll()).thenReturn(
                ImmutableList.of(entity2.getInfo(), entity3.getInfo(), entity4.getInfo()));

        when(mediatorInfoRepository.tryUpdate(any(MediatorInfoMutationDescriptor.class)))
            .then(new Answer<Optional<MediatorInfoData>>() {
                @Override
                public Optional<MediatorInfoData> answer(final InvocationOnMock invocation)
                        throws Throwable {
                    final MediatorInfoMutationDescriptor mutation = (MediatorInfoMutationDescriptor) invocation.getArguments()[0];
                    assertThat(mutation.getActivationRequired(), is(present()));
                    assertThat(mutation.getActivationRequired().get(), is(false));
                    final MediatorInfoData infoData = mutation.apply();
                    mutation.applied();
                    return Optional.of(infoData);
                }
            });

        when(physicalConnectionRepository.queryAll(2)).thenReturn(Collections.singleton(new MediatorPhysicalConnectionBuilder().
        		setActualActivationState(ActualActivationState.ACTIVE).build(22, 2, 0)));

        when(physicalConnectionRepository.queryAll(3)).thenReturn(Collections.singleton(new MediatorPhysicalConnectionBuilder().
                setActualActivationState(ActualActivationState.INACTIVE).build(33, 3, 0)));

        when(physicalConnectionRepository.queryAll(4)).thenReturn(Collections.singleton(new MediatorPhysicalConnectionBuilder().
                setActualActivationState(ActualActivationState.ACTIVE).build(44, 4, 0)));

        bean.deactivateAllMediators(context);

        // note that these are called only twice although three entities were returned: only two were active.
        verify(mediatorNotifications, times(2)).notifyChanges(any(DeactivateMediatorEvent.class));
        verify(mediatorInfoRepository, times(2)).tryUpdate(any(MediatorInfoMutationDescriptor.class));
    }

    @Test(expected=BcbException.class)
    public void modifyMediator_notImplemented() throws BcbException {
        bean.modifyMediator(context, null);
    }
}
