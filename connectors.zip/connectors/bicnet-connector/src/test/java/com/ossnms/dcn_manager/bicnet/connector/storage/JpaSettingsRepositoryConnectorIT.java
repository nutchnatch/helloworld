package com.ossnms.dcn_manager.bicnet.connector.storage;

import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.composables.configuration.HardwareConfigurationType;
import com.ossnms.dcn_manager.core.entities.emne.DiscoveryPolicy;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettingsMutationDescriptor;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.unitils.dbunit.annotation.DataSet;

import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@DataSet
public class JpaSettingsRepositoryConnectorIT extends HelperItTestBase {

    @Mock private StaticConfigurationSingleton configuration;

    @InjectMocks private JpaSettingsRepositoryBean repositoryBean;
    

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();

        when(configuration.getHWConfiguration()).thenReturn(HardwareConfigurationType.DEV);
        repositoryBean.initialize();
    }

    @Test
    @DataSet(value="JpaSettingsRepositoryConnectorIT.empty.xml")
    public void start_withDefaults() throws Exception {
        final GlobalSettings defaultInstance = GlobalSettings.build().toGlobalSettings(6, 0);

        repositoryBean.start();

        assertThat(repositoryBean.getSettings(), is(defaultInstance));
    }

    @Test
    public void start_withExisting() throws Exception {
        final GlobalSettings existingInstance = GlobalSettings.build()
                .setMediatorRetries(100)
                .setChannelRetries(200)
                .setNeRetries(300)
                .setRetryInterval(10)
                .setScaledStartupLimit(20)
                .setEnableScheduledStartup(true)
                .setShowNativeNeNaming(true)
                .setDiscoveryPolicy(DiscoveryPolicy.DISCOVER_ALL_NETWORK)
                .setDefaultContainerName("Default Ne Container")
                .toGlobalSettings(6, 1);

        repositoryBean.start();

        assertThat(repositoryBean.getSettings(), is(existingInstance));
    }

    @Test
    public void updateSettings() throws Exception {

        repositoryBean.start();

        final GlobalSettings initialSettings = repositoryBean.getSettings();

        final GlobalSettingsMutationDescriptor mutation = new GlobalSettingsMutationDescriptor(initialSettings)
            .setChannelRetries(8765);

        final Optional<GlobalSettings> updatedSettings = repositoryBean.tryUpdateSettings(mutation);

        assertThat(updatedSettings, is(present()));

        final GlobalSettings newSettings = updatedSettings.get();
        assertThat(newSettings, not(is(initialSettings)));
        assertThat(newSettings, is(repositoryBean.getSettings()));

        // restart to reload information from the database.

        repositoryBean.start();

        assertThat(repositoryBean.getSettings(), is(newSettings));
    }

}
