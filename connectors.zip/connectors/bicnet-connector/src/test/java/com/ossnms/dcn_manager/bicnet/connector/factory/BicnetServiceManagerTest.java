package com.ossnms.dcn_manager.bicnet.connector.factory;

import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcherConfig;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcherFactory;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.messaging.BiCNetMessageDispatcherFactory;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.assertNotNull;

public class BicnetServiceManagerTest {
    
    private IBiCNetMessageDispatcher messageDispatcher;
    
    @Before
    public void setup() {
        messageDispatcher = Mockito.mock(IBiCNetMessageDispatcher.class);             
    }
    
    @Test
    public void testMessageDispatcher() {
        BiCNetMessageDispatcherFactory.setInstance(new IBiCNetMessageDispatcherFactory() {            
            @Override
            public IBiCNetMessageDispatcher getDispatcher(BiCNetComponentType type) {
                return messageDispatcher;
            }

            @Override public IBiCNetMessageDispatcherConfig getDispatcherConfig(BiCNetComponentType componentType) {
                return null;
            }
        });

        IBiCNetMessageDispatcher m =  new BicnetServiceManager().getBiCNetMessageDispatcher();
        
        assertNotNull(m);
    }    
}