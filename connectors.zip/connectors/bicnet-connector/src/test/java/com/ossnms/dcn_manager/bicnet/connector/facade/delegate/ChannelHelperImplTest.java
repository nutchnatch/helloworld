package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.scs.ISystemControlEjbFacade;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.bicnet.bcb.model.scs.ScsSiteConfiguration;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.outbound.connection.ChannelConnectionManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.outbound.notifications.ChannelNotificationsManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.policies.ChannelConnectionSchedulerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaChannelRepositoryBean;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownChannelPropertyNames;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelDeleteDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataBuilder;
import com.ossnms.dcn_manager.core.policies.ChannelSchedulingConfiguration;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelConnectionRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.unitils.inject.util.InjectionUtils;
import org.unitils.inject.util.PropertyAccess;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;

import static com.google.common.collect.Iterables.getOnlyElement;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.arrayWithSize;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.hasItemInArray;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ChannelHelperImplTest {

    private static final int MEDIATOR_ID = 87;
    protected static final int CHANNEL_ID = 42;
    private static final int MEDIATOR_INSTANCE_ID = 77;
    private static final int CHANNEL_INSTANCE_ID = 56;

    @Mock private StaticConfigurationSingleton configuration;
    @Mock private ChannelNotificationsManagerImpl notifications;
    @Mock private JpaChannelRepositoryBean channelRepository;
    @Mock private ChannelConnectionManagerImpl connectionManager;
    @Mock private ChannelConnectionSchedulerImpl connectionScheduler;
    @Mock private ChannelSchedulingConfiguration channelScheduling;
    @Mock private NeEntityRepository neRepository;
    @Mock private NeInfoRepository neInfoRepository;
    @Mock private MediatorEntityRepository mediatorRepository;
    @Mock private SettingsRepository settingsRepository;
    @Mock private LoggerManagerImpl loggerManager;
    @Mock private MediatorInstanceEntityRepository mediatorInstanceRepo;
    @Mock private ISystemControlEjbFacade scs;

    @InjectMocks
    ChannelHelper helper;

    private ChannelType type;
    @Mock private Types<ChannelType> types;
    @Mock private ChannelUserPreferencesRepository preferencesRepository;
    @Mock private ChannelConnectionRepository connectionRepository;
    @Mock private ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository;

    @Before
    public void setUp() throws RepositoryException {
        type = MockFactory.mockEmType();

        when(type.getDefaultIcon()).thenReturn("iconId");
        when(type.getName()).thenReturn("typeName");

        when(types.get("typeName")).thenReturn(type);

        when(configuration.getChannelTypes()).thenReturn(types);

        when(neRepository.getNeInfoRepository()).thenReturn(neInfoRepository);

        final ChannelManagers channelManagers = new ChannelManagers(channelRepository, channelPhysicalConnectionRepository, notifications, connectionScheduler, null);
        InjectionUtils.injectIntoByType(channelManagers, ChannelManagers.class, helper, PropertyAccess.FIELD);

        // setup required for CreateChannel and DeleteChannel commands to succeed
        when(mediatorRepository.query(MEDIATOR_ID)).thenReturn(Optional.of(buildMediator()));
        when(mediatorInstanceRepo.queryAll(MEDIATOR_ID)).thenReturn(Collections.singleton(buildMediatorInstance()));
        when(channelRepository.create(any(ChannelCreateDescriptor.class))).then(new Answer<ChannelEntity>() {
            @Override
            public ChannelEntity answer(InvocationOnMock invocation) throws Throwable {
                final ChannelCreateDescriptor descriptor = (ChannelCreateDescriptor)invocation.getArguments()[0];
                return new ChannelEntity(
                        new ChannelInfoData(CHANNEL_ID, 1, descriptor.getMediatorId(), descriptor.getInfoInitialData()),
                        new ChannelConnectionData(CHANNEL_ID, 1, descriptor.getConnectionInitialData()),
                        new ChannelUserPreferencesData(CHANNEL_ID, 1, descriptor.getPreferencesInitialData()));
            }
        });
        when(channelPhysicalConnectionRepository.insert(isA(ChannelConnectionInitialData.class), eq(CHANNEL_ID), eq(MEDIATOR_INSTANCE_ID)))
            .then(invocation -> new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, 0));
        when(channelPhysicalConnectionRepository.queryAll(CHANNEL_ID)).thenReturn(Collections.singleton(buildChannelInstance()));

        when(preferencesRepository.query(anyString())).thenReturn(
                Optional.empty()
        );
        when(channelRepository.getChannelUserPreferencesRepository()).thenReturn(preferencesRepository);
        when(channelRepository.getChannelConnectionRepository()).thenReturn(connectionRepository);
    }

    private MediatorEntity buildMediator() {
        return new MediatorEntity(
                new MediatorInfoBuilder().setName("name").setTypeName("type").build(MEDIATOR_ID, 1),
                new MediatorConnectionBuilder().build(MEDIATOR_ID, 1));
    }

    private MediatorInstance buildMediatorInstance() {
        return new MediatorInstance(
                new MediatorPhysicalDataBuilder().setHost("host").setPriority(MediatorInstance.PRIMARY_PRIORITY_LEVEL).build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, 1),
                new MediatorPhysicalConnectionBuilder().build(MEDIATOR_INSTANCE_ID, MEDIATOR_ID, 1));
    }

    private ChannelEntity buildChannel() {
        return new ChannelEntity(
            new ChannelInfoBuilder().setType("typeName").build(CHANNEL_ID, 1, 1),
            new ChannelConnectionBuilder().setActivation(ActualActivationState.INACTIVE).build(CHANNEL_ID, 1),
            new ChannelUserPreferencesBuilder().setName("name").setProperty("Custom", "Value")
                    .setUserText(Optional.of("text")).setReconnectInterval(345).build(CHANNEL_ID, 1));
    }

    @Test
    public void getFullChannelList() throws Exception {
        when(channelRepository.queryAll()).thenReturn(Collections.singleton(buildChannel()));

        final Iterable<FullChannelData> fullChannelList = helper.getFullChannelList(null);

        final FullChannelData channelData = getOnlyElement(fullChannelList);

        final IEM iem = channelData.getChannel();
        final ChannelInfo info = channelData.getInfo();

        assertThat(iem.getIdName(), is("name"));
        assertThat(iem.getReconnectInterval(), is(345));
        assertThat(iem.getId(), is(CHANNEL_ID));
        assertThat(iem.getAssociatedMediatorId(), is(1));

        assertThat(info.getChannelId(), is(CHANNEL_ID));
        assertThat(info.getGuiActiveActualActivationState(), is(Optional.of(GuiActualActivationState.INACTIVE)));
        assertThat(info.getUserText(), is(Optional.of("text")));
    }

    private ChannelPhysicalConnectionData buildChannelInstance() {
        return new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, 1, CHANNEL_ID, 0);
    }

    @Test
    public void deleteChannel() throws Exception {
        final ChannelEntity channel = buildChannel();
        final ArgumentCaptor<ChannelDeleteDescriptor> deleteDescriptorCaptor = ArgumentCaptor.forClass(ChannelDeleteDescriptor.class);

        when(channelRepository.queryChannel(CHANNEL_ID)).thenReturn(Optional.of(channel));

        when(neInfoRepository.queryAll(anyInt())).thenReturn(Collections.emptyList());

        helper.deleteEM(null, new EMIdItem(CHANNEL_ID));

        verify(channelRepository).delete(deleteDescriptorCaptor.capture());
        verify(notifications).notifyDelete(channel);

        assertThat(deleteDescriptorCaptor.getValue().getId(), is(CHANNEL_ID));
    }

    @Test(expected=BcbException.class)
    public void deleteChannel_commandError_throws() throws Exception {
        when(channelRepository.queryChannel(anyInt())).thenThrow(new RepositoryException());
        helper.deleteEM(null, new EMIdItem(CHANNEL_ID));
    }

    @Test
    public void getRegisteredEmTypes() throws BcbException {
        final MediatorType mediatorType = mock(MediatorType.class);
        final Types<MediatorType> mediatorTypes = mock(Types.class);
        final ChannelType type1 = mock(ChannelType.class);
        final ChannelType type2 = mock(ChannelType.class);
        final Collection<ChannelType> types = ImmutableList.of(type1, type2);

        when(type1.getName()).thenReturn("type1");
        when(type2.getName()).thenReturn("type2");

        when(mediatorType.getSupportedChannelTypes()).thenReturn(types);
        when(mediatorTypes.get(anyString())).thenReturn(mediatorType);

        when(configuration.getMediatorTypes()).thenReturn(mediatorTypes);

        final String[] registeredEmTypes = helper.getRegisteredEmTypes(null, "mediatorType");
        assertThat(registeredEmTypes, allOf(hasItemInArray("type1"), hasItemInArray("type2")));
    }

    @Test
    public void getRegisteredEmTypes_noTypes_emptyArray() throws BcbException {
        final MediatorType mediatorType = mock(MediatorType.class);
        final Types<MediatorType> mediatorTypes = mock(Types.class);

        when(mediatorType.getSupportedChannelTypes()).thenReturn(Collections.emptyList());
        when(mediatorTypes.get(anyString())).thenReturn(mediatorType);

        when(configuration.getMediatorTypes()).thenReturn(mediatorTypes);

        final String[] registeredEmTypes = helper.getRegisteredEmTypes(null, "mediatorType");
        assertThat(registeredEmTypes, is(arrayWithSize(0)));
    }

    @Test(expected=BcbException.class)
    public void getRegisteredEmTypes_unknownMediator_throws() throws BcbException {
        final Types<MediatorType> mediatorTypes = mock(Types.class);

        when(mediatorTypes.get(anyString())).thenReturn(null);

        when(configuration.getMediatorTypes()).thenReturn(mediatorTypes);

        helper.getRegisteredEmTypes(null, "mediatorType");
    }

    @Test
    public void getAllRegisteredEmTypes() throws BcbException {
        final MediatorType mediatorType = mock(MediatorType.class);
        final Types<MediatorType> mediatorTypes = mock(Types.class);
        final ChannelType type1 = mock(ChannelType.class);
        final ChannelType type2 = mock(ChannelType.class);
        final Collection<ChannelType> types = ImmutableList.of(type1, type2);

        when(type1.getName()).thenReturn("type1");
        when(type2.getName()).thenReturn("type2");

        when(mediatorType.getSupportedChannelTypes()).thenReturn(types);
        when(mediatorTypes.values()).thenReturn(Collections.singleton(mediatorType));

        when(configuration.getMediatorTypes()).thenReturn(mediatorTypes);

        final String[] registeredEmTypes = helper.getRegisteredEmTypes(null);
        assertThat(registeredEmTypes, allOf(hasItemInArray("type1"), hasItemInArray("type2")));
    }

    @Test
    public void getAllRegisteredEmTypes_noTypes_emptyArray() throws BcbException {
        final MediatorType mediatorType = mock(MediatorType.class);
        final Types<MediatorType> mediatorTypes = mock(Types.class);

        when(mediatorType.getSupportedChannelTypes()).thenReturn(Collections.emptyList());
        when(mediatorTypes.values()).thenReturn(Collections.singleton(mediatorType));

        when(configuration.getMediatorTypes()).thenReturn(mediatorTypes);

        final String[] registeredEmTypes = helper.getRegisteredEmTypes(null);
        assertThat(registeredEmTypes, is(arrayWithSize(0)));
    }

    @Test
    public void getProperties() throws Exception {
        when(channelRepository.queryChannel(CHANNEL_ID)).thenReturn(Optional.of(buildChannel()));

        when(scs.getSiteConfiguration(any())).thenReturn(ScsSiteConfiguration.PRIMARY);
        when(scs.isStandbyConfigured(any())).thenReturn(true);

        final Map<String, String> properties = helper.getProperties(null, new EMIdItem(CHANNEL_ID));
        assertThat(properties, is(notNullValue()));
        assertThat(properties, allOf(
                hasEntry("Custom", "Value"),
                hasEntry(WellKnownChannelPropertyNames.ID_NAME, "name"),
                hasEntry(WellKnownChannelPropertyNames.RECONNECT_INTERVAL, "345"),
                hasEntry("SITE_ROLE", "primary"),
                hasEntry("STANDBY_CONFIGURED", "true")
        ));
    }

    @Test
    public void getProperties_unknownChannel() throws Exception {
        when(channelRepository.queryChannel(anyInt())).thenReturn(Optional.empty());

        final Map<String, String> properties = helper.getProperties(null, new EMIdItem(CHANNEL_ID));
        assertThat(properties, is(notNullValue()));
        assertThat(properties.isEmpty(), is(true));
    }

    @Test(expected=BcbException.class)
    public void getProperties_commandError_throws() throws Exception {
        when(channelRepository.queryChannel(anyInt())).thenThrow(new RepositoryException());

        helper.getProperties(null, new EMIdItem(CHANNEL_ID));
    }

    @Test
    public void createEM_withoutProperties() throws BcbException {

        final Map<String, String> testProps = ImmutableMap.of(
                WellKnownChannelPropertyNames.ID_NAME, "Default Name",
                WellKnownChannelPropertyNames.RECONNECT_INTERVAL, "345");
        when(type.getSupportedPropertyDefaultValues()).thenReturn(testProps);

        final IEM initialEm = new EMItem();
        initialEm.setAssociatedMediatorId(MEDIATOR_ID);
        initialEm.setEmType("typeName");
        initialEm.setIdName("emName");

        final IEM iem = helper.createEM(null, initialEm);

        assertThat(iem.getIdName(), is("emName"));
        assertThat(iem.getReconnectInterval(), is(345));
        assertThat(iem.getId(), is(CHANNEL_ID));
        assertThat(iem.getAssociatedMediatorId(), is(MEDIATOR_ID));

        verify(notifications).notifyCreate(any(ChannelEntity.class));
    }

    @Test(expected=BcbException.class)
    public void createEM_withoutProperties_invalidType_throws() throws BcbException {

        when(type.getSupportedPropertyDefaultValues()).thenReturn(ImmutableMap.of());

        final IEM initialEm = new EMItem();
        initialEm.setAssociatedMediatorId(MEDIATOR_ID);
        initialEm.setEmType("blaaahhh");
        initialEm.setIdName("emName");

        helper.createEM(null, initialEm);
    }

    @Test(expected=BcbException.class)
    public void createEM_withoutProperties_noName_throws() throws BcbException {

        when(type.getSupportedPropertyDefaultValues()).thenReturn(ImmutableMap.of());

        final IEM initialEm = new EMItem();
        initialEm.setAssociatedMediatorId(MEDIATOR_ID);
        initialEm.setEmType("typeName");

        helper.createEM(null, initialEm);
    }

    @Test(expected=BcbException.class)
    public void createEM_withoutProperties_invalidMediator_throws() throws Exception {

        when(type.getSupportedPropertyDefaultValues()).thenReturn(ImmutableMap.of());
        when(mediatorRepository.query(anyInt())).thenReturn(Optional.empty());

        final IEM initialEm = new EMItem();
        initialEm.setAssociatedMediatorId(987);
        initialEm.setEmType("typeName");
        initialEm.setIdName("emName");

        helper.createEM(null, initialEm);
    }

    @Test
    public void createEM_withProperties() throws BcbException {

        final Map<String, String> testProps = ImmutableMap.of(
                WellKnownChannelPropertyNames.ID_NAME, "Default Name",
                WellKnownChannelPropertyNames.RECONNECT_INTERVAL, "345");
        when(type.getSupportedPropertyDefaultValues()).thenReturn(testProps);

        final IEM iem = helper.createEM(null, "typeName", "emName", new MediatorIdItem(MEDIATOR_ID), new Property[] {
            new Property(WellKnownChannelPropertyNames.RECONNECT_INTERVAL, "654")
        });

        assertThat(iem.getIdName(), is("emName"));
        assertThat(iem.getReconnectInterval(), is(654));
        assertThat(iem.getId(), is(CHANNEL_ID));
        assertThat(iem.getAssociatedMediatorId(), is(MEDIATOR_ID));

        verify(notifications).notifyCreate(any(ChannelEntity.class));
    }

    @Test
    public void createEM_withOverridingProperties() throws BcbException {

        /*
         * When using an immutable map builder for property bags that does not allow duplicates,
         * this fails because duplicate entries are then created for default and final property values.
         */
        final Map<String, String> testProps = ImmutableMap.of(
                "EnableSwitchBackTime", "false");
        when(type.getSupportedPropertyDefaultValues()).thenReturn(testProps);

        final IEM iem = helper.createEM(null, "typeName", "emName", new MediatorIdItem(MEDIATOR_ID), new Property[] {
            new Property("EnableSwitchBackTime", "true")
        });

        assertThat(iem.getIdName(), is("emName"));
        assertThat(iem.getId(), is(CHANNEL_ID));
        assertThat(iem.getAssociatedMediatorId(), is(MEDIATOR_ID));

        final ArgumentCaptor<ChannelEntity> entityCaptor = ArgumentCaptor.forClass(ChannelEntity.class);
        verify(notifications).notifyCreate(entityCaptor.capture());

        final Map<String, String> allOpaqueProperties = entityCaptor.getValue().getAllOpaqueProperties();
        assertThat(allOpaqueProperties, hasEntry("EnableSwitchBackTime", "true"));
        assertThat(allOpaqueProperties, not(hasEntry("EnableSwitchBackTime", "false")));
    }

    @Test(expected=BcbException.class)
    public void createEM_withProperties_invalidProperty_throws() throws BcbException {

        when(type.getSupportedPropertyDefaultValues()).thenReturn(ImmutableMap.of());

        helper.createEM(null, "typeName", "emName", new MediatorIdItem(MEDIATOR_ID), new Property[] {
            new Property(WellKnownChannelPropertyNames.RECONNECT_INTERVAL, "baaaadddd")
        });
    }

    @Test(expected=BcbException.class)
    public void createEM_withProperties_invalidMediator_throws() throws Exception {

        when(type.getSupportedPropertyDefaultValues()).thenReturn(ImmutableMap.of());
        when(mediatorRepository.query(anyInt())).thenReturn(Optional.empty());

        helper.createEM(null, "typeName", "emName", new MediatorIdItem(90909), new Property[0]);
    }

    @Test(expected=BcbException.class)
    public void createEM_withProperties_invalidType_throws() throws BcbException {

        when(type.getSupportedPropertyDefaultValues()).thenReturn(ImmutableMap.of());

        helper.createEM(null, "blaaaahhhh", "emName", new MediatorIdItem(90909), new Property[0]);
    }

    @Test(expected=BcbException.class)
    public void createEM_withProperties_noName_throws() throws BcbException {

        when(type.getSupportedPropertyDefaultValues()).thenReturn(ImmutableMap.of());

        helper.createEM(null, "typeName", "", new MediatorIdItem(90909), new Property[0]);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void updateProperties() throws Exception {

        final ChannelConnectionData connState = new ChannelConnectionBuilder().setActivation(ActualActivationState.ACTIVE).build(CHANNEL_ID, 1);

        final ChannelEntity entity = new ChannelEntity(
                new ChannelInfoBuilder().setType("MVM").build(CHANNEL_ID, 1, MEDIATOR_ID),
                new ChannelConnectionBuilder().build(CHANNEL_ID, 1),
                new ChannelUserPreferencesBuilder().setName("name").build(CHANNEL_ID, 1));

        when(types.get(anyString())).thenReturn(type);
        when(channelRepository.queryChannel(CHANNEL_ID)).thenReturn(Optional.of(entity));
        when(connectionRepository.query(CHANNEL_ID)).thenReturn(Optional.of(connState));
        when(preferencesRepository.tryUpdate(any(ChannelUserPreferencesMutationDescriptor.class))).then(new MutationAnswer<>());
        when(settingsRepository.getSettings()).thenReturn(GlobalSettings.build().toGlobalSettings(1,1));

        helper.updateProperties(null, new EMIdItem(CHANNEL_ID), ImmutableMap.of("A", "B"));

        verify(preferencesRepository).tryUpdate(any(ChannelUserPreferencesMutationDescriptor.class));
        verify(notifications).notifyChanges(any(ChannelUserPreferencesMutationDescriptor.class), any(String.class));
        verify(connectionManager).updateChannelProperties(eq(CHANNEL_ID), any(Map.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void updateProperties_empty_ignores() throws Exception {

        final ChannelConnectionData connState = new ChannelConnectionBuilder().setActivation(ActualActivationState.ACTIVE).build(CHANNEL_ID, 1);

        final ChannelEntity entity = new ChannelEntity(
                new ChannelInfoBuilder().setType("MVM").build(CHANNEL_ID, 1, MEDIATOR_ID),
                new ChannelConnectionBuilder().build(CHANNEL_ID, 1),
                new ChannelUserPreferencesBuilder().setName("name").build(CHANNEL_ID, 1));

        when(types.get(anyString())).thenReturn(type);
        when(channelRepository.queryChannel(CHANNEL_ID)).thenReturn(Optional.of(entity));
        when(connectionRepository.query(CHANNEL_ID)).thenReturn(Optional.of(connState));
        when(preferencesRepository.tryUpdate(any(ChannelUserPreferencesMutationDescriptor.class))).then(new MutationAnswer<>());
        when(settingsRepository.getSettings()).thenReturn(GlobalSettings.build().toGlobalSettings(1,1));

        helper.updateProperties(null, new EMIdItem(CHANNEL_ID), ImmutableMap.of());

        verify(preferencesRepository, never()).tryUpdate(any(ChannelUserPreferencesMutationDescriptor.class));
        verify(notifications, never()).notifyChanges(any(ChannelUserPreferencesMutationDescriptor.class), any(String.class));
        verify(connectionManager, never()).updateChannelProperties(eq(CHANNEL_ID), any(Map.class));
    }

    @Test(expected=BcbException.class)
    public void updateProperties_repoError_throws() throws Exception {

        when(channelRepository.queryChannel(CHANNEL_ID)).thenThrow(new RepositoryException());

        helper.updateProperties(null, new EMIdItem(CHANNEL_ID), ImmutableMap.of());
    }
}
