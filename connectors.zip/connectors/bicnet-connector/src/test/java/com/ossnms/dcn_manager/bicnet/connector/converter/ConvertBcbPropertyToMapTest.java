package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.model.common.Property;
import org.junit.Test;

import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.hasEntry;
import static org.junit.Assert.assertThat;

public class ConvertBcbPropertyToMapTest {

    @Test
    public void testConvert() {
        final Property[] properties = ImmutableList.of(new Property("k1","v1"), new Property("k2","v2")).toArray(new Property[2]);

        final Map<String, String> map = ConvertBcbPropertyToMap.convert(properties);

        assertThat(map.get("k1"), is("v1"));
        assertThat(map.get("k2"), is("v2"));
        assertThat(map.size(), is(2));
    }

    @Test
    public void testNullConvert() {

        final Map<String, String> map = ConvertBcbPropertyToMap.convert(null);

        assertThat(map.isEmpty(), is(true));
    }

    @Test
    public void testConvertNullPropertyValue() {

        final Property[] properties = ImmutableList.of(new Property("k1",null)).toArray(new Property[1]);

        final Map<String, String> map = ConvertBcbPropertyToMap.convert(properties);

        assertThat(map, hasEntry("k1", ""));
        assertThat(map.size(), is(1));
    }
}
