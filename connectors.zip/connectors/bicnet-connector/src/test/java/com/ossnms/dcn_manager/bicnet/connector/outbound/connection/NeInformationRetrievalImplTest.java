package com.ossnms.dcn_manager.bicnet.connector.outbound.connection;

import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.elementMgmt.CommissioningStatusSummaryPkgItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.GatewayConfigurationPkgItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.INetworkElementDomainAssignmentFacade;
import com.ossnms.bicnet.bcb.facade.elementMgmt.INetworkElementFacade;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementDomainAssignmentItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementDomainAssignmentReply;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.WriteAccessStatePkgItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.platform.IMediationFacadeManager;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.IMoFacet;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.common.GatewayRole;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommissioningStatusSummary;
import com.ossnms.bicnet.bcb.model.elementMgmt.ICommissioningStatusSummaryPkg;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElement;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementDomainAssignment;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementDomainAssignmentMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementId;
import com.ossnms.bicnet.bcb.model.elementMgmt.IWriteAccessStatePkg;
import com.ossnms.bicnet.bcb.model.elementMgmt.NeFamily;
import com.ossnms.bicnet.bcb.model.elementMgmt.NeSubType;
import com.ossnms.bicnet.bcb.model.elementMgmt.NeType;
import com.ossnms.bicnet.bcb.model.elementMgmt.TpGroupMode;
import com.ossnms.bicnet.bcb.model.elementMgmt.WriteAccessState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.platform.PlatformException;
import com.ossnms.dcn_manager.bicnet.connector.outbound.notifications.NeNotificationsManagerImpl;
import com.ossnms.dcn_manager.composables.configuration.AppProperties;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.domain.DomainCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.CommissioningMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.GatewayMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.OperationalMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.TpGroupSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.types.WriteAccessMode;
import com.ossnms.dcn_manager.core.events.domain.DomainChildrenChanged;
import com.ossnms.dcn_manager.core.events.domain.DomainParticipationAdded;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;
import com.ossnms.dcn_manager.core.outbound.exception.OutboundException;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeOperationRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeUserPreferencesRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.events.base.DomainManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownNetworkElementIdException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class NeInformationRetrievalImplTest {

    private static final int NE_ID = 1;
    private static final int CHANNEL_ID = 2;
    private static final int MEDIATOR_INSTANCE_ID = 3000;
    private static final int CHANNEL_INSTANCE_ID = 2000;
    private static final int NE_INSTANCE_ID = 1000;

    private static final String NE_FACADE = "elementMgmt.NetworkElement";
    private static final String DOMAIN_FACADE = "elementMgmt.NetworkElementDomainAssignment";

    private IMediationFacadeManager connectionManager;
    private NeEntityRepository neRepository;
    private NeInfoRepository infoRepository;
    private NeOperationRepository operationRepository;
    private NeUserPreferencesRepository preferencesRepository;
    private ISessionContext context;
    private NeNotificationsManagerImpl notifications;
    private INetworkElementFacade neFacade;
    private com.ossnms.dcn_manager.core.configuration.model.NeType type;
    private NePhysicalConnectionRepository neInstancesRepository;
    private ChannelPhysicalConnectionRepository channelInstancesRepository;
    private AppProperties appProperties;
    private INetworkElementDomainAssignmentFacade domainAssignmentFacade;

    private NeInformationRetrievalImpl nir;
    private NePhysicalConnectionData neInstance;
    private ChannelPhysicalConnectionData channelInstance;

    private DomainRepository domainRepository;
    private DomainNotifications domainNotifications;
    private SettingsRepository settings;
    private NeConnectionManager neConnectionManager;

    @Before
    public void setUp() throws PlatformException, UnsupportedOperationException, RepositoryException {
        type = MockFactory.mockNeType();
        neRepository = mock(NeEntityRepository.class);
        infoRepository = mock(NeInfoRepository.class);
        operationRepository = mock(NeOperationRepository.class);
        preferencesRepository = mock(NeUserPreferencesRepository.class);
        connectionManager = mock(IMediationFacadeManager.class);
        context = mock(ISessionContext.class);
        notifications = mock(NeNotificationsManagerImpl.class);
        neFacade = mock(INetworkElementFacade.class);
        final StaticConfiguration configuration = mock(StaticConfiguration.class);
        final Types<com.ossnms.dcn_manager.core.configuration.model.NeType> neTypes = mock(Types.class);
        final BiMap<String, String> neIdControlMap  = ImmutableBiMap.of(WellKnownNePropertyNames.NEIGHBOURHOOD_ID, WellKnownNePropertyNames.TL1_ID);
        final BiMap<String, String> neAdditionalTypeInfoControlMap  = ImmutableBiMap.of(WellKnownNePropertyNames.ADDITIONAL_TYPE_INFO, WellKnownNePropertyNames.TL1_NE_TYPE);
        neInstancesRepository = mock(NePhysicalConnectionRepository.class);
        channelInstancesRepository = mock(ChannelPhysicalConnectionRepository.class);
        appProperties = mock(AppProperties.class);
        domainRepository = mock(DomainRepository.class);
        domainNotifications = mock(DomainNotifications.class);
        settings = mock(SettingsRepository.class);
        domainAssignmentFacade = mock(INetworkElementDomainAssignmentFacade.class);
        neConnectionManager = mock(NeConnectionManager.class);

        when(neRepository.getNeInfoRepository()).thenReturn(infoRepository);
        when(neRepository.getNeOperationRepository()).thenReturn(operationRepository);
        when(neRepository.getNeUserPreferencesRepository()).thenReturn(preferencesRepository);

        when(domainRepository.queryNaturalDomainsForNE(anyInt())).thenReturn(Collections.emptyList());
        when(domainRepository.queryTransitiveDomainsForNE(anyInt())).thenReturn(Collections.emptyList());
        when(domainRepository.queryAllForNE(anyInt())).thenReturn(Collections.emptyList());
        when(domainRepository.queryByName(anyString())).thenReturn(Optional.empty());

        when(settings.getSettings()).thenReturn(GlobalSettings.build().toGlobalSettings(6, 0));

        when(connectionManager.getFacade(context, NE_FACADE, new MediatorIdItem(MEDIATOR_INSTANCE_ID), new EMIdItem(CHANNEL_ID)))
            .thenReturn(neFacade);

        when(configuration.getNeTypes()).thenReturn(neTypes);
        when(neTypes.get(anyString())).thenReturn(type);
        when(type.getIdentificationControlMap()).thenReturn(neIdControlMap);
        when(type.getAdditionalTypeInfoControlMap()).thenReturn(neAdditionalTypeInfoControlMap);

        neInstance = new NePhysicalConnectionBuilder().build(NE_INSTANCE_ID, NE_ID, CHANNEL_INSTANCE_ID, 0);
        channelInstance = new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, 0);

        final NetworkElementManagers networkElementManagers = new NetworkElementManagers(neRepository, neInstancesRepository,
                null, notifications, null);

        final DomainManagers domainManagers = new DomainManagers(domainRepository, domainNotifications);

        nir = new NeInformationRetrievalImpl(connectionManager, networkElementManagers,
                channelInstancesRepository, domainManagers, context, settings, configuration, appProperties, neConnectionManager);
    }

    @Test(expected=UnknownNetworkElementIdException.class)
    public void testUpdateNeDataFromMediator_noNeInstance_throws() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.empty());

        nir.updateNeDataFromMediator(NE_INSTANCE_ID);
    }

    @Test(expected=UnknownChannelIdException.class)
    public void testUpdateNeDataFromMediator_noChannelInstance_throws() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.empty());

        nir.updateNeDataFromMediator(NE_INSTANCE_ID);
    }

    @Test(expected=UnknownNetworkElementIdException.class)
    public void testUpdateNeDataFromMediator_noNeEntity_throws() throws Exception {

        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.empty());

        nir.updateNeDataFromMediator(NE_INSTANCE_ID);
    }

    @Test(expected=OutboundException.class)
    public void testUpdateNeDataFromMediator_daoThrowsPlatformException_throws() throws Exception {

        final NeEntity neEntity = buildNeEntity();
        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));

        when(connectionManager.getFacade(any(ISessionContext.class), anyString(), any(IMediatorId.class), any(IEMId.class)))
            .thenThrow(new PlatformException());

        nir.updateNeDataFromMediator(NE_INSTANCE_ID);
    }

    @Test(expected=OutboundException.class)
    public void testUpdateNeDataFromMediator_daoThrowsUnsupportedOperationException_throws() throws Exception {

        final NeEntity neEntity = buildNeEntity();
        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));

        when(connectionManager.getFacade(any(ISessionContext.class), anyString(), any(IMediatorId.class), any(IEMId.class)))
            .thenThrow(new UnsupportedOperationException());

        nir.updateNeDataFromMediator(NE_INSTANCE_ID);
    }

    @Test(expected=OutboundException.class)
    public void testUpdateNeDataFromMediator_noNetworkElement_throws() throws Exception {

        final NeEntity neEntity = buildNeEntity();
        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));

        when(neFacade.getSingleNetworkElement(any(ISessionContext.class), any(INetworkElementId.class)))
            .thenReturn(null);        // unnecessary: for readability only

        nir.updateNeDataFromMediator(NE_INSTANCE_ID);
    }

    @Test(expected=DataUpdateException.class)
    public void testUpdateNeDataFromMediator_updateOperationFailed_throws() throws Exception {

        final INetworkElement item = buildNetworkElement();

        final NeEntity neEntity = buildNeEntity();
        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));

        when(operationRepository.tryUpdate(any(NeOperationMutationDescriptor.class)))
            .thenReturn(Optional.empty());

        when(neFacade.getSingleNetworkElement(any(ISessionContext.class), any(INetworkElementId.class))).thenReturn(item);

        nir.updateNeDataFromMediator(NE_INSTANCE_ID);
    }

    @Test
    public void testUpdateNeDataFromMediator_noWriteAccessPkg() throws Exception {

        final INetworkElement item = buildNetworkElement();

        item.removeOptionalFacet(IWriteAccessStatePkg.class);

        when(neFacade.getSingleNetworkElement(any(ISessionContext.class), any(INetworkElementId.class)))
            .thenReturn(item);

        runFullUpdate();

        final ArgumentCaptor<NeOperationMutationDescriptor> operationMutationCaptor = ArgumentCaptor.forClass(NeOperationMutationDescriptor.class);

        verify(infoRepository, never()).tryUpdate(any(NeInfoMutationDescriptor.class));
        verify(operationRepository).tryUpdate(operationMutationCaptor.capture());
        verify(preferencesRepository, never()).tryUpdate(any(NeUserPreferencesMutationDescriptor.class));

        final NeOperationMutationDescriptor operationMutation = operationMutationCaptor.getValue();

        assertThat(operationMutation.getWriteAccess(), is(absent()));

    }

    @Test
    public void testUpdateNeDataFromMediator_noTpGroupMode() throws Exception {

        final INetworkElement item = buildNetworkElement();

        item.setTpGroupMode(null);

        when(neFacade.getSingleNetworkElement(any(ISessionContext.class), any(INetworkElementId.class)))
            .thenReturn(item);

        runFullUpdate();

        final ArgumentCaptor<NeOperationMutationDescriptor> operationMutationCaptor = ArgumentCaptor.forClass(NeOperationMutationDescriptor.class);

        verify(infoRepository, never()).tryUpdate(any(NeInfoMutationDescriptor.class));
        verify(operationRepository).tryUpdate(operationMutationCaptor.capture());
        verify(preferencesRepository, never()).tryUpdate(any(NeUserPreferencesMutationDescriptor.class));

        final NeOperationMutationDescriptor operationMutation = operationMutationCaptor.getValue();

        assertThat(operationMutation.getTpGroupMode(), is(absent()));

    }

    @Test
    public void testUpdateNeDataFromMediator_noCommissioningStatusSummaryPkg() throws Exception {

        final INetworkElement item = buildNetworkElement();

        item.removeOptionalFacet(ICommissioningStatusSummaryPkg.class);

        when(neFacade.getSingleNetworkElement(any(ISessionContext.class), any(INetworkElementId.class)))
            .thenReturn(item);

        runFullUpdate();

        final ArgumentCaptor<NeOperationMutationDescriptor> operationMutationCaptor = ArgumentCaptor.forClass(NeOperationMutationDescriptor.class);

        verify(infoRepository, never()).tryUpdate(any(NeInfoMutationDescriptor.class));
        verify(operationRepository).tryUpdate(operationMutationCaptor.capture());
        verify(preferencesRepository, never()).tryUpdate(any(NeUserPreferencesMutationDescriptor.class));

        final NeOperationMutationDescriptor operationMutation = operationMutationCaptor.getValue();

        assertThat(operationMutation.getCommissioning(), is(absent()));

    }

    @Test
    public void testUpdateNeDataFromMediator_withNetworkNameCopy() throws Exception {

        final INetworkElement item = buildNetworkElement();
        item.setName("network name");

        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(true);

        when(neFacade.getSingleNetworkElement(any(ISessionContext.class), any(INetworkElementId.class)))
                .thenReturn(item);

        when(preferencesRepository.tryUpdate(isA(NeUserPreferencesMutationDescriptor.class))).then(new MutationAnswer<>());

        runFullUpdate();

        final ArgumentCaptor<NeOperationMutationDescriptor> operationMutationCaptor = ArgumentCaptor.forClass(NeOperationMutationDescriptor.class);
        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> preferencesMutationCaptor = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);

        verify(infoRepository, never()).tryUpdate(any(NeInfoMutationDescriptor.class));
        verify(operationRepository).tryUpdate(operationMutationCaptor.capture());
        verify(preferencesRepository).tryUpdate(preferencesMutationCaptor.capture());

        final NeOperationMutationDescriptor operationMutation = operationMutationCaptor.getValue();
        assertThat(operationMutation.getRealNeName(), hasValue("network name"));

        final NeUserPreferencesMutationDescriptor preferencesMutation = preferencesMutationCaptor.getValue();
        assertThat(preferencesMutation.getName(), hasValue("network name"));

        verify(notifications, never()).notifyChanges(any(NeInfoMutationDescriptor.class));
        verify(notifications).notifyChanges(operationMutation);
        verify(notifications).notifyChanges(preferencesMutation);
    }

    @Test
    public void shouldNotifyMediatorOnNetworkNameCopy() throws Exception {

        final INetworkElement item = buildNetworkElement();
        item.setName("network name");

        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(true);

        when(neFacade.getSingleNetworkElement(any(ISessionContext.class), any(INetworkElementId.class)))
                .thenReturn(item);

        when(preferencesRepository.tryUpdate(isA(NeUserPreferencesMutationDescriptor.class))).then(new MutationAnswer<>());

        runFullUpdate();


        final ArgumentCaptor<NeUserPreferencesMutationDescriptor> preferencesMutationCaptor = ArgumentCaptor.forClass(NeUserPreferencesMutationDescriptor.class);
        verify(neConnectionManager).updateNeProperties(any(NeEntity.class), any(NePhysicalConnectionData.class), preferencesMutationCaptor.capture(), any(Map.class));
        assertThat(preferencesMutationCaptor.getValue().getName(), hasValue("network name"));

    }

    @Test
    public void testUpdateNeDataFromMediator_withNetworkNameCopy_noNameReceived_doesNotCopy() throws Exception {

        final INetworkElement item = buildNetworkElement();
        item.setName(null);

        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(true);

        when(neFacade.getSingleNetworkElement(any(ISessionContext.class), any(INetworkElementId.class)))
                .thenReturn(item);

        runFullUpdate();

        final ArgumentCaptor<NeOperationMutationDescriptor> operationMutationCaptor = ArgumentCaptor.forClass(NeOperationMutationDescriptor.class);

        verify(infoRepository, never()).tryUpdate(any(NeInfoMutationDescriptor.class));
        verify(operationRepository).tryUpdate(operationMutationCaptor.capture());
        verify(preferencesRepository, never()).tryUpdate(isA(NeUserPreferencesMutationDescriptor.class));

        final NeOperationMutationDescriptor operationMutation = operationMutationCaptor.getValue();
        assertThat(operationMutation.getRealNeName(), hasValue(""));

        verify(notifications, never()).notifyChanges(any(NeInfoMutationDescriptor.class));
        verify(notifications).notifyChanges(operationMutation);
        verify(notifications, never()).notifyChanges(isA(NeUserPreferencesMutationDescriptor.class));
    }

    @Test
    public void testUpdateNeDataFromMediator_withNetworkNameCopy_preferencesRepoError_ignoresError() throws Exception {

        final INetworkElement item = buildNetworkElement();
        item.setName("network name");

        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(true);

        when(neFacade.getSingleNetworkElement(any(ISessionContext.class), any(INetworkElementId.class)))
                .thenReturn(item);

        when(preferencesRepository.tryUpdate(isA(NeUserPreferencesMutationDescriptor.class))).thenThrow(new RepositoryException());

        runFullUpdate();

        verify(infoRepository, never()).tryUpdate(isA(NeInfoMutationDescriptor.class));
        verify(operationRepository).tryUpdate(isA(NeOperationMutationDescriptor.class));
        verify(preferencesRepository).tryUpdate(isA(NeUserPreferencesMutationDescriptor.class));

        verify(notifications, never()).notifyChanges(isA(NeInfoMutationDescriptor.class));
        verify(notifications).notifyChanges(isA(NeOperationMutationDescriptor.class));
        verify(notifications, never()).notifyChanges(isA(NeUserPreferencesMutationDescriptor.class));
    }

    @Test
    public void testUpdateNeDataFromMediator_withNetworkNameCopy_concurrentUpdateError_ignoresError() throws Exception {

        final INetworkElement item = buildNetworkElement();
        item.setName("network name");

        when(appProperties.isAutoCopyNeNameEnabled()).thenReturn(true);

        when(neFacade.getSingleNetworkElement(any(ISessionContext.class), any(INetworkElementId.class)))
                .thenReturn(item);

        when(preferencesRepository.tryUpdate(isA(NeUserPreferencesMutationDescriptor.class))).thenReturn(Optional.empty());

        runFullUpdate();

        verify(infoRepository, never()).tryUpdate(isA(NeInfoMutationDescriptor.class));
        verify(operationRepository).tryUpdate(isA(NeOperationMutationDescriptor.class));
        verify(preferencesRepository).tryUpdate(isA(NeUserPreferencesMutationDescriptor.class));

        verify(notifications, never()).notifyChanges(isA(NeInfoMutationDescriptor.class));
        verify(notifications).notifyChanges(isA(NeOperationMutationDescriptor.class));
        verify(notifications, never()).notifyChanges(isA(NeUserPreferencesMutationDescriptor.class));
    }

    @Test
    public void testUpdateNeDataFromMediator() throws Exception {

        final INetworkElement item = buildNetworkElement();

        when(connectionManager.getFacade(context, DOMAIN_FACADE, new MediatorIdItem(MEDIATOR_INSTANCE_ID), new EMIdItem(CHANNEL_ID)))
                .thenReturn(domainAssignmentFacade);

        INetworkElementDomainAssignmentMarkable desiredFilter = NetworkElementDomainAssignmentItem.markableNetworkElementDomainAssignment(null);
        desiredFilter.setNeId(NE_ID);
        when(domainAssignmentFacade.getNetworkElementDomainAssignmentList(context, null, new INetworkElementDomainAssignmentMarkable[]{ desiredFilter }, -1))
                .thenReturn(new NetworkElementDomainAssignmentReply(new INetworkElementDomainAssignment[]{
                        new NetworkElementDomainAssignmentItem(null, NE_ID, "domain1")
                }, true, null, 0L));

        when(domainRepository.tryCreate(isA(DomainCreationDescriptor.class)))
            .then(invocation -> Optional.of(
                new DomainInfoData(1, 0, ((DomainCreationDescriptor) invocation.getArguments()[0]).getName())));
        when(domainRepository.tryAddNaturalNE(anyInt(), anyInt())).thenReturn(true);
        when(domainRepository.queryAllForNE(NE_ID)).thenReturn(
                Collections.emptyList(), // before adding the natural domain
                Collections.singleton(new DomainInfoData(1, 0, "domain1")) // after adding the natural domain
        );
        when(domainRepository.queryChildrenNEs(1)).thenReturn(Collections.singleton(NE_ID)); // zafter adding the natural domain

        when(neFacade.getSingleNetworkElement(any(ISessionContext.class), any(INetworkElementId.class)))
            .thenReturn(item);

        runFullUpdate();

        final ArgumentCaptor<NeOperationMutationDescriptor> operationMutationCaptor = ArgumentCaptor.forClass(NeOperationMutationDescriptor.class);

        verify(infoRepository, never()).tryUpdate(any(NeInfoMutationDescriptor.class));
        verify(operationRepository).tryUpdate(operationMutationCaptor.capture());
        verify(preferencesRepository, never()).tryUpdate(any(NeUserPreferencesMutationDescriptor.class));
        verify(domainRepository).tryCreate(new DomainCreationDescriptor("domain1"));
        verify(domainRepository).tryAddNaturalNE(1, NE_ID);

        final NeOperationMutationDescriptor operationMutation = operationMutationCaptor.getValue();

        assertThat(operationMutation.getRealNeName().get(), is("ne_name"));
        assertThat(operationMutation.getNeighbourhoodId().get(), is("tid"));
        assertThat(operationMutation.isEventForwardingActive().get(), is(true));
        assertThat(operationMutation.getTpGroupMask().get(), is(1234L));
        assertThat(operationMutation.getTpGroupMode().get(), is(new TpGroupSettings(true, true, true, true)));
        assertThat(operationMutation.getFamily().get(), is(item.getNeFamily().name()));
        assertThat(operationMutation.getMainRelease().get(), is("main"));
        assertThat(operationMutation.getMaintenanceRelease().get(), is("maintenance"));
        assertThat(operationMutation.getNeSubType().get(), is(NeSubType.ADU.name()));
        assertThat(operationMutation.getNeType().get(), is(NeType._7090_240.name()));
        assertThat(operationMutation.getNeSpecificType().get(), is("specific"));
        assertThat(operationMutation.getOperationalMode().get(), is(OperationalMode.ENABLED));
        assertThat(operationMutation.getWriteAccess().get(), is(WriteAccessMode.NE_PROXY_AND_CLIENT_EM));
        assertThat(operationMutation.getCommissioning().get(), is(CommissioningMode.PARTIALLY_COMMISSIONED));
        assertThat(operationMutation.getGatewayMode().get(), is(GatewayMode.PRIMARY));

        verify(notifications, never()).notifyChanges(any(NeInfoMutationDescriptor.class));
        verify(notifications).notifyChanges(operationMutation);
        verify(notifications, never()).notifyChanges(any(NeUserPreferencesMutationDescriptor.class));

        verify(domainNotifications).notifyCreate(new DomainInfoData(1, 0, "domain1"));
        verify(domainNotifications).notifyChanges(new DomainChildrenChanged(new DomainInfoData(1, 0, "domain1"), ImmutableList.of(NE_ID)));
        verify(domainNotifications).notifyChanges(new DomainParticipationAdded(1, NE_ID));
    }

    @Test
    public void testUpdateNeDataFromMediator_nullTypes_ignored() throws Exception {

        final INetworkElement item = buildNetworkElement();
        item.setNeFamily(null);
        item.setNeType(null);
        item.setNeSubType(null);

        when(neFacade.getSingleNetworkElement(any(ISessionContext.class), any(INetworkElementId.class)))
            .thenReturn(item);

        runFullUpdate();

        final ArgumentCaptor<NeOperationMutationDescriptor> operationMutationCaptor = ArgumentCaptor.forClass(NeOperationMutationDescriptor.class);

        verify(infoRepository, never()).tryUpdate(any(NeInfoMutationDescriptor.class));
        verify(operationRepository).tryUpdate(operationMutationCaptor.capture());
        verify(preferencesRepository, never()).tryUpdate(any(NeUserPreferencesMutationDescriptor.class));

        final NeOperationMutationDescriptor operationMutation = operationMutationCaptor.getValue();

        assertThat(operationMutation.getFamily(), is(absent()));
        assertThat(operationMutation.getNeSubType(), is(absent()));
        assertThat(operationMutation.getNeType(), is(absent()));

        verify(notifications, never()).notifyChanges(any(NeInfoMutationDescriptor.class));
        verify(notifications).notifyChanges(operationMutation);
        verify(notifications, never()).notifyChanges(any(NeUserPreferencesMutationDescriptor.class));
    }

    private void runFullUpdate() throws Exception {

        final NeEntity neEntity = buildNeEntity();
        when(neInstancesRepository.query(NE_INSTANCE_ID)).thenReturn(Optional.of(neInstance));
        when(channelInstancesRepository.query(CHANNEL_INSTANCE_ID)).thenReturn(Optional.of(channelInstance));
        when(neRepository.queryNe(NE_ID)).thenReturn(Optional.of(neEntity));

        when(operationRepository.tryUpdate(any(NeOperationMutationDescriptor.class))).then(new MutationAnswer<NeOperationData>());

        when(connectionManager.getFacade(context, NE_FACADE, new MediatorIdItem(MEDIATOR_INSTANCE_ID), new EMIdItem(CHANNEL_ID)))
            .thenReturn(neFacade);

        nir.updateNeDataFromMediator(NE_INSTANCE_ID);
    }

    private NeEntity buildNeEntity() {
        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(CHANNEL_ID, type);
        createDescriptor.getPreferences().setName("type_name_" + NE_ID);
        return NeEntity.build(NE_ID, 0, createDescriptor);
    }

    private INetworkElement buildNetworkElement() {
        final INetworkElement item = new NetworkElementItem(new IMoFacet[] {
            new WriteAccessStatePkgItem(WriteAccessState.NE_PROXY_AND_CLIENT_EM),
            new CommissioningStatusSummaryPkgItem(CommissioningStatusSummary.PARTIALLY_COMMISSIONED),
            new GatewayConfigurationPkgItem(GatewayRole.PRIMARY)
        });
        item.setEventForwarding(EnableSwitch.ENABLED);
        item.setTpGroupMask(1234);
        item.setTpGroupMode(new TpGroupMode(true, true, true, true));
        item.setNeFamily(NeFamily._7090_M);
        item.setMainRelease("main");
        item.setMaintenanceRelease("maintenance");
        item.setNeType(NeType._7090_240);
        item.setNeSubType(NeSubType.ADU);
        item.setSpecificType("specific");
        item.setOperationalState(OperationalState.ENABLED);
        item.setName("ne_name");
        item.setTid("tid");
        return item;
    }

}
