package com.ossnms.dcn_manager.bicnet.connector.outbound;

import com.ossnms.bicnet.bcb.facade.platform.IConnectionManager;
import com.ossnms.bicnet.bcb.facade.platform.INotifyBeanFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.platform.PlatformException;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertIntegerToBcbEm;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertIntegerToBcbNe;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.mockito.Mockito.*;

public class SharedResourcesImplTest {

    private INotifyBeanFacade notifyFacade;
    private BicnetCallContext context;
    private SharedResourcesImpl sharedResourcesImpl;
    private ISessionContext sessionContext;
    private IConnectionManager connectionManagerFacade;

    @Before
    public void setup() throws PlatformException, UnsupportedOperationException {
        notifyFacade = mock(INotifyBeanFacade.class);
        context = mock(BicnetCallContext.class);
        sessionContext = mock(ISessionContext.class);
        connectionManagerFacade = mock(IConnectionManager.class);

        when(context.getSessionContext()).thenReturn(sessionContext);

        sharedResourcesImpl = new SharedResourcesImpl(notifyFacade, connectionManagerFacade);
    }

    @Test
    public void testAcquireNeResources() throws PlatformException {
        final INE bcbNe = ConvertIntegerToBcbNe.convert(1);
        final IEM bcbEm = ConvertIntegerToBcbEm.convert(2);

        sharedResourcesImpl.acquireNeResources(context, 1, 2);

        verify(connectionManagerFacade).assignNeToEm(sessionContext, bcbEm, bcbNe);
    }

    @Test
    public void testAcquireNeResources_errorOnAssign_continues() throws PlatformException {
        final INE bcbNe = ConvertIntegerToBcbNe.convert(1);
        final IEM bcbEm = ConvertIntegerToBcbEm.convert(2);

        doThrow(new PlatformException())
            .when(connectionManagerFacade).assignNeToEm(sessionContext, bcbEm, bcbNe);

        sharedResourcesImpl.acquireNeResources(context, 1, 2);

    }

    @Test
    public void testReleaseNeResources() throws BcbException {
        final INE bcbNe = ConvertIntegerToBcbNe.convert(1);

        sharedResourcesImpl.releaseNeResources(context, bcbNe.getId());

        verify(notifyFacade).releaseNe(sessionContext, bcbNe);
        verify(connectionManagerFacade).unassignNeFromEm(sessionContext, bcbNe);
    }

    @Test
    public void testReleaseNeResources_errorOnUnassign_continue() throws BcbException {
        final INE bcbNe = ConvertIntegerToBcbNe.convert(1);

        doThrow(new PlatformException())
            .when(connectionManagerFacade).unassignNeFromEm(sessionContext, bcbNe);

        sharedResourcesImpl.releaseNeResources(context, bcbNe.getId());

        verify(notifyFacade).releaseNe(sessionContext, bcbNe);
    }

    @Test
    public void testReleaseNeResources_errorOnRelease_continue() throws BcbException {
        final INE bcbNe = ConvertIntegerToBcbNe.convert(1);

        doThrow(new BcbException()).when(notifyFacade).releaseNe(sessionContext, bcbNe);

        sharedResourcesImpl.releaseNeResources(context, bcbNe.getId());

        verify(notifyFacade).releaseNe(sessionContext, bcbNe);
    }

    @Test
    public void testReleaseChannelResources() throws BcbException {
        final IEM bcbEm = ConvertIntegerToBcbEm.convert(1);

        sharedResourcesImpl.releaseChannelResources(context, bcbEm.getId());

        verify(notifyFacade, Mockito.times(1)).releaseEm(sessionContext, bcbEm);
    }

    @Test
    public void testReleaseChannelResourcesError() throws BcbException {
        final IEM bcbEm = ConvertIntegerToBcbEm.convert(1);

        doThrow(new BcbException()).when(notifyFacade).releaseEm(sessionContext, bcbEm);

        sharedResourcesImpl.releaseChannelResources(context, bcbEm.getId());

        verify(notifyFacade, Mockito.times(1)).releaseEm(sessionContext, bcbEm);
    }
}
