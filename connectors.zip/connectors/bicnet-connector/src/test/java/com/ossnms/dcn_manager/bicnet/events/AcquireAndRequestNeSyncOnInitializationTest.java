package com.ossnms.dcn_manager.bicnet.events;

import com.ossnms.bicnet.bcb.facade.scs.IScsFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.IBiCNetComponentId;
import com.ossnms.bicnet.bcb.model.common.SyncCategory;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncMode;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.composables.outbound.SharedResources;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializedEvent;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeInfoRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository.NeSynchronizationRepository;
import com.ossnms.dcn_manager.core.test.MutationAnswer;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class AcquireAndRequestNeSyncOnInitializationTest {

    private static final int CHANNEL_ID = 42;
    private static final int NE_ID = 21;
    private static final int CHANNEL_INSTANCE_ID = 4200;
    private static final int NE_INSTANCE_ID = 2100;

    private NeEntityRepository neRepository;
    private NeInfoRepository infoRepo;
    private NeSynchronizationRepository syncRepo;
    private IScsFacade scs;
    private ISessionContext systemContext;
    private SharedResources<BicnetCallContext> sharedResources;

    private AcquireAndRequestNeSyncOnInitialization worker;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() throws Exception {
        neRepository = mock(NeEntityRepository.class);
        infoRepo = mock(NeInfoRepository.class);
        syncRepo = mock(NeSynchronizationRepository.class);
        scs = mock(IScsFacade.class);
        systemContext = mock(ISessionContext.class);
        sharedResources = mock(SharedResources.class);

        when(neRepository.getNeInfoRepository()).thenReturn(infoRepo);
        when(neRepository.getNeSynchronizationRepository()).thenReturn(syncRepo);

        worker = new AcquireAndRequestNeSyncOnInitialization(neRepository, scs, sharedResources, systemContext);
    }

    private NeEntity buildEntity() {
        return new NeEntity(
                new NeConnectionBuilder().build(NE_ID, 1),
                new NeOperationBuilder().build(NE_ID, 1),
                new NeInfoBuilder().setProxyType("type").build(NE_ID, CHANNEL_ID, 1),
                new NeSynchronizationBuilder().build(NE_ID, 1),
                new NeUserPreferencesBuilder().setName("name").build(NE_ID, 1));
    }

    private void verifyComponentId(final ArgumentCaptor<IBiCNetComponentId[]> componentIdCaptor) {
        assertThat(componentIdCaptor.getValue()[0].getNeId(), is(NE_ID));
        assertThat(componentIdCaptor.getValue()[0].getEmId(), is(CHANNEL_ID));
        assertThat(componentIdCaptor.getValue()[0].getType(), is(BiCNetComponentType.ELEMENT_MANAGER));
    }

    @Test
    public void call_withoutSynchronizationData() throws Exception {
        final ArgumentCaptor<IBiCNetComponentId[]> componentIdCaptor = ArgumentCaptor.forClass(IBiCNetComponentId[].class);

        final NeEntity entity = buildEntity();

        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(syncRepo.query(NE_ID)).thenReturn(Optional.of(entity.getSync()));

        worker.call(new NeInitializedEvent(NE_ID));

        verify(sharedResources).acquireNeResources(any(BicnetCallContext.class), eq(NE_ID), eq(CHANNEL_ID));
        verify(scs).triggerForcedSync(eq(systemContext), componentIdCaptor.capture(), eq(ScsSyncMode.HARD_SYNC), eq(SyncCategory.ALL));
        verify(syncRepo, never()).tryUpdate(any(NeSynchronizationMutationDescriptor.class));
        verifyComponentId(componentIdCaptor);
    }

    @Test
    public void call_errorOnConnectionManager_initializesAndAcquires() throws Exception {
        final ArgumentCaptor<IBiCNetComponentId[]> componentIdCaptor = ArgumentCaptor.forClass(IBiCNetComponentId[].class);

        final NeEntity entity = buildEntity();

        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(syncRepo.query(NE_ID)).thenReturn(Optional.of(entity.getSync()));

        worker.call(new NeInitializedEvent(NE_ID));

        verify(sharedResources).acquireNeResources(any(BicnetCallContext.class), eq(NE_ID), eq(CHANNEL_ID));
        verify(scs).triggerForcedSync(eq(systemContext), componentIdCaptor.capture(), eq(ScsSyncMode.HARD_SYNC), eq(SyncCategory.ALL));
        verify(syncRepo, never()).tryUpdate(any(NeSynchronizationMutationDescriptor.class));
        verifyComponentId(componentIdCaptor);
    }

    @Test
    public void call_syncDataUnavailable_initializesAndAcquires() throws Exception {
        final ArgumentCaptor<IBiCNetComponentId[]> componentIdCaptor = ArgumentCaptor.forClass(IBiCNetComponentId[].class);

        final NeEntity entity = buildEntity();

        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(syncRepo.query(NE_ID)).thenReturn(Optional.of(entity.getSync()));

        worker.call(new NeInitializedEvent(NE_ID));

        verify(sharedResources).acquireNeResources(any(BicnetCallContext.class), eq(NE_ID), eq(CHANNEL_ID));
        verify(scs).triggerForcedSync(eq(systemContext), componentIdCaptor.capture(), eq(ScsSyncMode.HARD_SYNC), eq(SyncCategory.ALL));
        verify(syncRepo, never()).tryUpdate(any(NeSynchronizationMutationDescriptor.class));
        verifyComponentId(componentIdCaptor);
    }

    @Test
    public void call_syncCounterChangedForPacket_initializesAcquiresAndDoesNotStore() throws Exception {
        final ArgumentCaptor<IBiCNetComponentId[]> componentIdCaptor = ArgumentCaptor.forClass(IBiCNetComponentId[].class);
        final NeSynchronizationMutationDescriptor descriptor =
            new NeSynchronizationMutationDescriptor(new NeSynchronizationBuilder().build(NE_ID, 1))
                .setPacket(1);
        final NeSynchronizationData differences =
                new NeSynchronizationBuilder()
                        .setPacket(Optional.of(1L))
                        .build(NE_ID, 1);

        final NeEntity entity = buildEntity();

        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(syncRepo.query(NE_ID)).thenReturn(Optional.of(entity.getSync()));
        when(syncRepo.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());

        worker.call(new NeInitializedEvent(NE_ID, differences));

        verify(sharedResources).acquireNeResources(any(BicnetCallContext.class), eq(NE_ID), eq(CHANNEL_ID));
        verify(scs).triggerForcedSync(eq(systemContext), componentIdCaptor.capture(), eq(ScsSyncMode.HARD_SYNC), eq(SyncCategory.PACKET));
        verify(syncRepo, never()).tryUpdate(descriptor);
        verifyComponentId(componentIdCaptor);
    }

    @Test
    public void call_syncCounterChangedForAlarms_initializesAcquiresAndDoesNotStore() throws Exception {
        final ArgumentCaptor<IBiCNetComponentId[]> componentIdCaptor = ArgumentCaptor.forClass(IBiCNetComponentId[].class);
        final NeSynchronizationMutationDescriptor descriptor =
            new NeSynchronizationMutationDescriptor(new NeSynchronizationBuilder().build(NE_ID, 1))
                .setAlarms(1);
        final NeSynchronizationData differences =
                new NeSynchronizationBuilder()
                        .setAlarms(Optional.of(1L))
                        .build(NE_ID, 1);

        final NeEntity entity = buildEntity();

        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(syncRepo.query(NE_ID)).thenReturn(Optional.of(entity.getSync()));
        when(syncRepo.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());

        worker.call(new NeInitializedEvent(NE_ID, differences));

        verify(sharedResources).acquireNeResources(any(BicnetCallContext.class), eq(NE_ID), eq(CHANNEL_ID));
        verify(scs).triggerForcedSync(eq(systemContext), componentIdCaptor.capture(), eq(ScsSyncMode.HARD_SYNC), eq(SyncCategory.ALARMS));
        verify(syncRepo, never()).tryUpdate(descriptor);
        verifyComponentId(componentIdCaptor);
    }

    @Test
    public void call_syncCounterChangedForAll_initializesAcquiresAndDoesNotStore() throws Exception {
        final ArgumentCaptor<IBiCNetComponentId[]> componentIdCaptor = ArgumentCaptor.forClass(IBiCNetComponentId[].class);
        final NeSynchronizationMutationDescriptor descriptor =
                new NeSynchronizationMutationDescriptor(new NeSynchronizationBuilder().build(NE_ID, 1))
                        .setAll(1);
        final NeSynchronizationData differences = new NeSynchronizationBuilder()
                        .setAll(Optional.of(1L))
                        .build(NE_ID, 1);

        final NeEntity entity = buildEntity();

        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(syncRepo.query(NE_ID)).thenReturn(Optional.of(entity.getSync()));
        when(syncRepo.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());

        worker.call(new NeInitializedEvent(NE_ID, differences));

        verify(sharedResources).acquireNeResources(any(BicnetCallContext.class), eq(NE_ID), eq(CHANNEL_ID));
        verify(scs).triggerForcedSync(eq(systemContext), componentIdCaptor.capture(), eq(ScsSyncMode.HARD_SYNC), eq(SyncCategory.ALL));
        verify(syncRepo,never()).tryUpdate(descriptor);
        verifyComponentId(componentIdCaptor);
    }

    @Test
    public void call_syncCounterChangedForAlarmsAndPacket_forcesAll_initializesAcquiresAndDoesNotStore() throws Exception {
        final ArgumentCaptor<IBiCNetComponentId[]> componentIdCaptor = ArgumentCaptor.forClass(IBiCNetComponentId[].class);
        final NeSynchronizationMutationDescriptor descriptor =
            new NeSynchronizationMutationDescriptor(new NeSynchronizationBuilder().build(NE_ID, 1))
                .setAlarms(1)
                .setPacket(2);
        final NeSynchronizationData differences =
                new NeSynchronizationBuilder()
                        .setAlarms(Optional.of(1L))
                        .setPacket(Optional.of(2L))
                        .build(NE_ID, 1);

        final NeEntity entity = buildEntity();

        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(syncRepo.query(NE_ID)).thenReturn(Optional.of(entity.getSync()));
        when(syncRepo.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());

        worker.call(new NeInitializedEvent(NE_ID, differences));

        verify(sharedResources).acquireNeResources(any(BicnetCallContext.class), eq(NE_ID), eq(CHANNEL_ID));
        verify(scs).triggerForcedSync(eq(systemContext), componentIdCaptor.capture(), eq(ScsSyncMode.HARD_SYNC), eq(SyncCategory.ALL));
        verify(syncRepo, never()).tryUpdate(descriptor);
        verifyComponentId(componentIdCaptor);
    }

    @Test
    public void call_syncCounterChangedForEverything_forcesAll_initializesAcquiresAndDoesNotStore() throws Exception {
        final ArgumentCaptor<IBiCNetComponentId[]> componentIdCaptor = ArgumentCaptor.forClass(IBiCNetComponentId[].class);
        final NeSynchronizationMutationDescriptor descriptor =
            new NeSynchronizationMutationDescriptor(new NeSynchronizationBuilder().build(NE_ID, 1))
                .setAlarms(1)
                .setPacket(2)
                .setAll(3);
        final NeSynchronizationData differences =
                new NeSynchronizationBuilder()
                        .setAlarms(Optional.of(1L))
                        .setPacket(Optional.of(2L))
                        .setAll(Optional.of(3L))
                        .build(NE_ID, 1);

        final NeEntity entity = buildEntity();

        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(syncRepo.query(NE_ID)).thenReturn(Optional.of(entity.getSync()));
        when(syncRepo.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());

        worker.call(new NeInitializedEvent(NE_ID, differences));

        verify(sharedResources).acquireNeResources(any(BicnetCallContext.class), eq(NE_ID), eq(CHANNEL_ID));
        verify(scs).triggerForcedSync(eq(systemContext), componentIdCaptor.capture(), eq(ScsSyncMode.HARD_SYNC), eq(SyncCategory.ALL));
        verify(syncRepo, never()).tryUpdate(descriptor);
        verifyComponentId(componentIdCaptor);
    }

    @Test
    public void call_syncCounterChangedForEverything_zeroValues_forcesAll_initializesAcquiresAndDoesNotStore() throws Exception {
        final ArgumentCaptor<IBiCNetComponentId[]> componentIdCaptor = ArgumentCaptor.forClass(IBiCNetComponentId[].class);
        final NeSynchronizationMutationDescriptor descriptor =
                new NeSynchronizationMutationDescriptor(new NeSynchronizationBuilder().build(NE_ID, 1))
                        .setAlarms(0)
                        .setPacket(0)
                        .setAll(0);
        final NeSynchronizationData differences =
                new NeSynchronizationBuilder()
                        .setAlarms(Optional.of(0L))
                        .setPacket(Optional.of(0L))
                        .setAll(Optional.of(0L))
                        .build(NE_ID, 1);

        final NeEntity entity = buildEntity();

        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(syncRepo.query(NE_ID)).thenReturn(Optional.of(entity.getSync()));
        when(syncRepo.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());

        worker.call(new NeInitializedEvent(NE_ID, differences));

        verify(sharedResources).acquireNeResources(any(BicnetCallContext.class), eq(NE_ID), eq(CHANNEL_ID));
        verify(scs).triggerForcedSync(eq(systemContext), componentIdCaptor.capture(), eq(ScsSyncMode.HARD_SYNC), eq(SyncCategory.ALL));
        verify(syncRepo, never()).tryUpdate(descriptor);
        verifyComponentId(componentIdCaptor);
    }

    @Test
    public void call_syncCounterNotChanged_forcesNone_initializesAcquiresAndDoesNotStore() throws Exception {
        final ArgumentCaptor<IBiCNetComponentId[]> componentIdCaptor = ArgumentCaptor.forClass(IBiCNetComponentId[].class);
        final NeSynchronizationData originalData = new NeSynchronizationBuilder().build(NE_ID, 1);

        final NeEntity entity = buildEntity();

        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(syncRepo.query(NE_ID)).thenReturn(Optional.of(entity.getSync()));
        when(syncRepo.tryUpdate(isA(NeSynchronizationMutationDescriptor.class))).then(new MutationAnswer<>());

        worker.call(new NeInitializedEvent(NE_ID, originalData));

        verify(sharedResources).acquireNeResources(any(BicnetCallContext.class), eq(NE_ID), eq(CHANNEL_ID));
        verify(scs).triggerForcedSync(eq(systemContext), componentIdCaptor.capture(), eq(ScsSyncMode.HARD_SYNC), eq(SyncCategory.NONE));
        verifyComponentId(componentIdCaptor);

        verify(syncRepo, never()).tryUpdate(isA(NeSynchronizationMutationDescriptor.class));
    }

    @Test
    public void call_errorOnScs_onlyAcquires() throws Exception {

        final NeEntity entity = buildEntity();

        when(infoRepo.query(NE_ID)).thenReturn(Optional.of(entity.getInfo()));
        when(syncRepo.query(NE_ID)).thenReturn(Optional.of(entity.getSync()));

        doThrow(new BcbException())
            .when(scs)
                .triggerForcedSync(any(ISessionContext.class), any(IBiCNetComponentId[].class), any(ScsSyncMode.class), any(SyncCategory.class));

        worker.call(new NeInitializedEvent(NE_ID));

        verify(sharedResources).acquireNeResources(any(BicnetCallContext.class), eq(NE_ID), eq(CHANNEL_ID));
    }

    @Test
    public void call_infoNotFound_doesNothing() throws Exception {

        when(infoRepo.query(NE_ID))
            .thenReturn(Optional.empty());

        worker.call(new NeInitializedEvent(NE_ID));

        verifyZeroInteractions(scs, sharedResources);
        verify(syncRepo, never()).tryUpdate(any(NeSynchronizationMutationDescriptor.class));
    }

    @Test
    public void call_errorOnInfoQuery_doesNothing() throws Exception {

        when(infoRepo.query(NE_ID)).thenThrow(new RepositoryException());

        worker.call(new NeInitializedEvent(NE_ID));

        verifyZeroInteractions(scs, sharedResources);
        verify(syncRepo, never()).tryUpdate(any(NeSynchronizationMutationDescriptor.class));
    }

}
