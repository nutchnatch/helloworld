package com.ossnms.dcn_manager.bicnet.connector.messaging;

import java.util.Collections;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.elementMgmt.ElementManagerItem;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.elementMgmt.EmPropertiesChanged;
import com.ossnms.bicnet.bcb.model.elementMgmt.IElementManagerMarkable;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.SynchNotification;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.ChannelEvent;
import com.ossnms.dcn_manager.core.events.channel.ChannelPropertiesChangedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatingEvent;

import rx.Observable;
import rx.observers.TestSubscriber;

public class ChannelEventSourceTest {

    private static final int CHANNEL_ID = 55;
    private static final int CHANNEL_INSTANCE_ID = 5500;
    private static final int MEDIATOR_INSTANCE_ID = 6000;

    private ChannelEventSource source;
    private TestSubscriber<ChannelEvent> subscriber;

    @Before
    public void setUp() {
        source = new ChannelEventSource();

        subscriber = new TestSubscriber<>();
        source.observe().subscribe(subscriber);
    }

    @Test
    public void injectedEvent_isForwarded() throws Exception {

        final ChannelEvent event = new ChannelActivatingEvent(CHANNEL_ID);

        source.push(event);

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<ChannelEvent>singletonList(
                event));
    }

    @Test
    public void unkownEvent_isIgnored() throws Exception {

        source.subscribe(Observable.just(new DecoratedNotification(new SynchNotification())));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<ChannelEvent>emptyList());
    }

    @Test
    public void channelPropertiesChanged_activeInstance() throws Exception {

        final EmPropertiesChanged propsNotif = new EmPropertiesChanged(
            new Date(), CHANNEL_ID, new Property[] { new Property("a", "b") });

        source.subscribe(Observable.just(
            new DecoratedNotification(propsNotif)
                .setOriginatingPhysicalChannel(new ChannelPhysicalConnectionBuilder().setActive(true).build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, 0))));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<ChannelEvent>singletonList(
                new ChannelPropertiesChangedEvent(CHANNEL_ID, ImmutableMap.of("a", "b"))));
    }

    @Test
    public void channelPropertiesChanged_inactiveInstance() throws Exception {

        final EmPropertiesChanged propsNotif = new EmPropertiesChanged(
            new Date(), CHANNEL_ID, new Property[] { new Property("a", "b") });

        source.subscribe(Observable.just(
            new DecoratedNotification(propsNotif)
                .setOriginatingPhysicalChannel(new ChannelPhysicalConnectionBuilder().setActive(false).build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, 0))));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<ChannelEvent>emptyList());
    }

    @Test
    public void channelConnecting() throws Exception {
        final IElementManagerMarkable em = ElementManagerItem.markableElementManager(null);
        em.setEmId(CHANNEL_ID);
        em.setCommunicationState(CommunicationState.CONNECTING);

        source.subscribe(buildObservable(em));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<ChannelEvent>singletonList(
                new PhysicalChannelActivatingEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, true)));
    }

    @Test
    public void channelConnected() throws Exception {
        final IElementManagerMarkable em = ElementManagerItem.markableElementManager(null);
        em.setEmId(CHANNEL_ID);
        em.setCommunicationState(CommunicationState.CONNECTED);

        source.subscribe(buildObservable(em));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<ChannelEvent>singletonList(
                new PhysicalChannelActivatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, true)));
    }

    @Test
    public void channelDisconnecting() throws Exception {
        final IElementManagerMarkable em = ElementManagerItem.markableElementManager(null);
        em.setEmId(CHANNEL_ID);
        em.setCommunicationState(CommunicationState.DISCONNECTING);

        source.subscribe(buildObservable(em));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<ChannelEvent>singletonList(
                new PhysicalChannelDeactivatingEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, true)));
    }

    @Test
    public void channelDisconnected() throws Exception {
        final IElementManagerMarkable em = ElementManagerItem.markableElementManager(null);
        em.setEmId(CHANNEL_ID);
        em.setCommunicationState(CommunicationState.DISCONNECTED);

        source.subscribe(buildObservable(em));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<ChannelEvent>singletonList(
                new PhysicalChannelDeactivatedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, true)));
    }

    @Test
    public void channelError() throws Exception {
        final IElementManagerMarkable em = ElementManagerItem.markableElementManager(null);
        em.setEmId(CHANNEL_ID);
        em.setCommunicationState(CommunicationState.FAILED);
        em.setCommunicationStateAdditionalInfo("ooops");

        source.subscribe(buildObservable(em));

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.<ChannelEvent>singletonList(
                new PhysicalChannelActivationFailedEvent(CHANNEL_INSTANCE_ID, CHANNEL_ID, true, "ooops")));
    }

    private Observable<DecoratedNotification> buildObservable(IElementManagerMarkable markable) {
        final AttributeValueChange avc = new AttributeValueChange();
        avc.setChangedObject(markable);
        return Observable.just(new DecoratedNotification(avc).setOriginatingPhysicalChannel(
                new ChannelPhysicalConnectionBuilder().setActive(true).build(CHANNEL_INSTANCE_ID, MEDIATOR_INSTANCE_ID, CHANNEL_ID, 0)));
    }

}
