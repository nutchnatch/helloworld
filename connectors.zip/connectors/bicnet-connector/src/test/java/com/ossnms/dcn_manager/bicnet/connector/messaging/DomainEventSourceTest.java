package com.ossnms.dcn_manager.bicnet.connector.messaging;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementDomainAssignmentIdItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementDomainAssignmentItem;
import com.ossnms.bicnet.bcb.model.elementMgmt.EmPropertiesChanged;
import com.ossnms.bicnet.bcb.model.platform.IdentifierChange;
import com.ossnms.bicnet.bcb.model.platform.ObjectCreation;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.events.domain.DomainAdded;
import com.ossnms.dcn_manager.core.events.domain.DomainEvent;
import com.ossnms.dcn_manager.core.events.domain.DomainRemoved;
import com.ossnms.dcn_manager.core.events.domain.DomainRenamed;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import rx.Observable;
import rx.observers.TestSubscriber;

import java.util.Collections;
import java.util.Date;
import java.util.Optional;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DomainEventSourceTest {

    private static final int DOMAIN_ID = 2;
    private static final int NE_ID = 1;

    @Mock private DomainRepository domainRepository;
    @InjectMocks private DomainEventSource source;

    private TestSubscriber<DomainEvent> subscriber;

    @Before
    public void setUp() throws Exception {
        subscriber = new TestSubscriber<>();
    }

    @Test
    public void someOtherNotification_isDropped() throws Exception {

        source.subscribe(Observable.just(
                new DecoratedNotification(new EmPropertiesChanged(new Date(), 0, null))));
        source.observe().subscribe(subscriber);

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.emptyList());
    }

    @Test
    public void domainRenamed_unknownDomain_isDropped() throws Exception {

        when(domainRepository.queryByName(anyString())).thenReturn(Optional.empty());

        source.subscribe(Observable.just(
                new DecoratedNotification(new IdentifierChange(new Date(),
                        new NetworkElementDomainAssignmentIdItem(NE_ID, "original"),
                        new NetworkElementDomainAssignmentIdItem(NE_ID, "new"))
                )
        ));
        source.observe().subscribe(subscriber);

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.emptyList());
    }

    @Test
    public void domainRenamed_repoError_isDropped() throws Exception {

        when(domainRepository.queryByName(anyString())).thenThrow(new RepositoryException());

        source.subscribe(Observable.just(
                new DecoratedNotification(new IdentifierChange(new Date(),
                        new NetworkElementDomainAssignmentIdItem(NE_ID, "original"),
                        new NetworkElementDomainAssignmentIdItem(NE_ID, "new"))
                )
        ));
        source.observe().subscribe(subscriber);

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.emptyList());
    }

    @Test
    public void domainRemoved_unknownDomain_isDropped() throws Exception {

        when(domainRepository.queryByName(anyString())).thenReturn(Optional.empty());

        source.subscribe(Observable.just(
                new DecoratedNotification(new ObjectDeletion(new Date(), new NetworkElementDomainAssignmentIdItem(NE_ID, "original")))
        ));
        source.observe().subscribe(subscriber);

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.emptyList());
    }

    @Test
    public void domainRemoved_repoError_isDropped() throws Exception {

        when(domainRepository.queryByName(anyString())).thenThrow(new RepositoryException());

        source.subscribe(Observable.just(
                new DecoratedNotification(new ObjectDeletion(new Date(), new NetworkElementDomainAssignmentIdItem(NE_ID, "original")))
        ));
        source.observe().subscribe(subscriber);

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(Collections.emptyList());
    }

    @Test
    public void domainRenamed_emitsInternalEvent() throws Exception {

        when(domainRepository.queryByName("original")).thenReturn(
                Optional.of(new DomainInfoData(DOMAIN_ID, 0, "original")));

        source.subscribe(Observable.just(
                new DecoratedNotification(new IdentifierChange(new Date(),
                        new NetworkElementDomainAssignmentIdItem(NE_ID, "original"),
                        new NetworkElementDomainAssignmentIdItem(NE_ID, "new"))
                )
        ));
        source.observe().subscribe(subscriber);

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(ImmutableList.of(new DomainRenamed(DOMAIN_ID, "new")));
    }

    @Test
    public void domainRemoved_emitsInternalEvent() throws Exception {

        when(domainRepository.queryByName("original")).thenReturn(
                Optional.of(new DomainInfoData(DOMAIN_ID, 0, "original")));

        source.subscribe(Observable.just(
                new DecoratedNotification(new ObjectDeletion(new Date(), new NetworkElementDomainAssignmentIdItem(NE_ID, "original")))
        ));
        source.observe().subscribe(subscriber);

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(ImmutableList.of(new DomainRemoved(NE_ID, DOMAIN_ID, "original")));
    }

    @Test
    public void domainAdded_emitsInternalEvent() throws Exception {

        source.subscribe(Observable.just(
                new DecoratedNotification(new ObjectCreation(new Date(), new NetworkElementDomainAssignmentItem(null, NE_ID, "new")))
        ));
        source.observe().subscribe(subscriber);

        subscriber.assertNoErrors();
        subscriber.assertReceivedOnNext(ImmutableList.of(new DomainAdded(NE_ID, "new")));
    }
}