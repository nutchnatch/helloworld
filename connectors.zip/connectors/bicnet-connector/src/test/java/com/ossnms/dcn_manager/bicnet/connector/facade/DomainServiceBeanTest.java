package com.ossnms.dcn_manager.bicnet.connector.facade;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.ASIdItem;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IASId;
import com.ossnms.dcn_manager.bicnet.connector.facade.DomainServiceBean;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.DomainHelper;

@RunWith(MockitoJUnitRunner.class)
public class DomainServiceBeanTest {

    @Mock private ISessionContext sessionContext;
    @Mock private DomainHelper helper;

    @InjectMocks private DomainServiceBean bean;

    @Test
    public void testGetSingleAS() throws BcbException {
        final IAS as = mock(IAS.class);
        final IASId domainId = new ASIdItem(2);

        when(helper.getDomain(sessionContext, domainId)).thenReturn(as);

        final IAS singleAS = bean.getSingleAS(sessionContext, domainId);

        verify(helper).getDomain(sessionContext, domainId);

        assertThat(singleAS, is(as));
    }

    @Test
    public void testGetASList() throws BcbException {
        final IAS as = mock(IAS.class);

        when(helper.getDomains(sessionContext)).thenReturn(Collections.singleton(as));

        final IAS[] asArray = bean.getASList(sessionContext);

        verify(helper).getDomains(sessionContext);

        assertArrayEquals(new IAS[] { as }, asArray);
    }

    @Test
    public void testSetAutomaticNeActivationPolicy() throws Exception {

        final IASId[] as = new IASId[] { new ASIdItem(87) };

        bean.setAutomaticNeActivationPolicy(sessionContext, as, true);

        verify(helper).setAutomaticNeActivationPolicy(sessionContext, as, true);
    }
}
