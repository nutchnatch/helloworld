package com.ossnms.dcn_manager.bicnet.connector.outbound.notifications;

import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.dcn_manager.composables.outbound.SecurityManager;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.events.domain.DomainNeActivationPolicyChanged;
import com.ossnms.dcn_manager.core.events.domain.DomainParticipationAdded;
import com.ossnms.dcn_manager.core.events.domain.DomainParticipationDeleted;
import com.ossnms.dcn_manager.core.events.domain.DomainRenamed;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;

import static java.util.Collections.emptyList;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class DomainNotificationsManagerImplTest {

    private static final int DOMAIN_ID = 1;
    private static final String DOMAIN_NAME = "domain_name";
    private static final int NE_ID = 5;

    @Mock private DomainRepository domainRepository;
    @Mock private SecurityManager securityManager;
    @Mock private IBiCNetMessageDispatcher messageDispatcher;

    @InjectMocks private DomainNotificationsManagerImpl notif;

    @Before
    public void setUp() throws Exception {
        when(domainRepository.queryChildrenNEs(anyInt())).thenReturn(emptyList());
    }

    @Test
    public void testNotifyDelete() throws Exception {

        notif.notifyDelete(new DomainInfoData(DOMAIN_ID, 0, DOMAIN_NAME));

        verify(messageDispatcher, times(2)).sendToSource(isA(IBiCNetMessage.class), eq(true));
    }

    @Test
    public void testNotifyCreate() throws Exception {

        notif.notifyCreate(new DomainInfoData(DOMAIN_ID, 0, DOMAIN_NAME));

        verify(messageDispatcher, times(2)).sendToSource(isA(IBiCNetMessage.class), eq(true));
    }

    @Test
    public void testNotifyNeActivationPolicyChanges() throws Exception {

        notif.notifyChanges(new DomainNeActivationPolicyChanged(DOMAIN_ID, true));

        verify(messageDispatcher, times(2)).sendToSource(isA(IBiCNetMessage.class), eq(true));
    }

    @Test
    public void testNotifyDomainParticipationAdded() throws Exception {

        notif.notifyChanges(new DomainParticipationAdded(DOMAIN_ID, NE_ID));

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(securityManager).updateNe(NE_ID);
    }

    @Test
    public void testNotifyDomainParticipationDeleted() throws Exception {

        notif.notifyChanges(new DomainParticipationDeleted(DOMAIN_ID, NE_ID));

        verify(messageDispatcher).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(securityManager).updateNe(NE_ID);
    }

    @Test
    public void testNotifyDomainNameChanged() throws Exception {

        when(domainRepository.queryChildrenNEs(anyInt())).thenReturn(Collections.singleton(NE_ID));

        notif.notifyChanges(new DomainRenamed(DOMAIN_ID, "new name"));

        verify(messageDispatcher, times(2)).sendToSource(isA(IBiCNetMessage.class), eq(true));
        verify(securityManager).updateNe(NE_ID);
    }
}