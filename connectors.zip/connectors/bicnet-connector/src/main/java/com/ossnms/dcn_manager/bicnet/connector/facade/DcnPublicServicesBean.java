package com.ossnms.dcn_manager.bicnet.connector.facade;

import static org.apache.commons.lang3.ArrayUtils.nullToEmpty;
import static org.slf4j.LoggerFactory.getLogger;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.common.IconPairIdReply;
import com.ossnms.bicnet.bcb.facade.common.IconPairReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMObjectMgrFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainParticipationReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemGenericContainerAssignmentReply;
import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.ComponentVersionInformation;
import com.ossnms.bicnet.bcb.model.common.File;
import com.ossnms.bicnet.bcb.model.common.IBiCNetComponentId;
import com.ossnms.bicnet.bcb.model.common.IIconPair;
import com.ossnms.bicnet.bcb.model.common.IIconPairId;
import com.ossnms.bicnet.bcb.model.common.IIconPairMarkable;
import com.ossnms.bicnet.bcb.model.common.Log4jLevel;
import com.ossnms.bicnet.bcb.model.common.NeManagementState;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.bicnet.bcb.model.common.SyncCategory;
import com.ossnms.bicnet.bcb.model.common.TrafficDirection;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ChannelsReply;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeDataTransferSettings;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignmentMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomain;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainParticipationId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainParticipationMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkSettings;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignmentMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorsReply;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeCapability;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeGneCost;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NesReply;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmMaskConfiguration;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmId;
import com.ossnms.bicnet.bcb.model.networkMgmt.UnableToComplyException;
import com.ossnms.bicnet.bcb.model.scs.ScsComponentState;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncMode;
import com.ossnms.bicnet.bcb.model.security.ISecurableObject;
import com.ossnms.dcn_manager.bicnet.configuration.export.ChannelConfigurationExportService;
import com.ossnms.dcn_manager.bicnet.configuration.export.MediatorConfigurationExportService;
import com.ossnms.dcn_manager.bicnet.configuration.export.NeConfigurationExportService;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.MediatorService;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import com.ossnms.dcn_manager.bicnet.connector.configuration.ServiceConfiguration;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertBcbPropertyToMap;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.AlarmHelper;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.ChannelHelper;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.ContainerHelper;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.DomainHelper;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.MOHelper;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.NeContainerAssignmentHelper;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.NeHelper;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.SecurityManagerHelper;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.ServiceControlHelper;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.SystemContainerAssignmentHelper;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.SystemContainerHelper;
import com.ossnms.dcn_manager.bicnet.connector.facade.util.StartNotRequired;
import com.ossnms.dcn_manager.bicnet.connector.security.Securable;
import com.ossnms.dcn_manager.bicnet.connector.security.SecuredObject;

@Stateless(name = "DcnPublicServicesBean") @Local(IEMObjectMgrFacade.class) @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED) public class DcnPublicServicesBean
        implements IEMObjectMgrFacade {

    private static final Logger LOGGER = getLogger(DcnPublicServicesBean.class);

    @Inject private ServiceControlHelper serviceControlHelper;

    @Inject private SecurityManagerHelper securityManagerHelper;

    @Inject private MOHelper manageObjectHelper;

    @Inject private ChannelHelper channelHelper;

    @Inject private NeHelper neHelper;

    @Inject private DomainHelper domainHelper;

    @Inject private AlarmHelper alarmHelper;

    @Inject private MediatorService mediatorService;

    @Inject private ServiceConfiguration serviceConfiguration;

    @Inject private SystemContainerHelper systemContainer;

    @Inject private ContainerHelper containerHelper;

    @Inject private NeConfigurationExportService neConfigurationExportService;

    @Inject private MediatorConfigurationExportService mediatorConfigurationExportService;

    @Inject private ChannelConfigurationExportService channelConfigurationExportService;

    @Inject private SystemContainerAssignmentHelper systemAssignmentHelper;

    @Inject private NeContainerAssignmentHelper neAssignmentHelper;

    /**
     * Validates method calls against the current component life cycle stage.
     *
     * @param context Bean invocation context.
     * @return The result from the next call in the chain.
     * @throws IllegalStateException If the target method can only be called after
     *                               DCN Manager is started but we have not been started yet.
     * @throws Exception             When the next call in the chain throws an exception.
     */
    @AroundInvoke public Object initStateValidationInterceptor(final InvocationContext context)
            throws Exception { // NOPMD Standard way of declaring interceptors!
        final Method method = context.getMethod();
        final boolean startRequired = method.getAnnotation(StartNotRequired.class) == null;
        if (startRequired && !serviceControlHelper.isComponentStarted()) {
            LOGGER.error("DCN Manager must be started before calling {} !", method);
            throw new IllegalStateException("DCN Manager not started yet!");
        }
        return context.proceed();
    }

    /**
     * {@inheritDoc}
     */
    @Override @StartNotRequired @Securable(SecureAction.SERVER_PUBLIC_DO_SYNCH) public void init(
            final ISessionContext sessionContext) throws BcbException {
        serviceControlHelper.init(sessionContext);
    }

    /**
     * {@inheritDoc}
     */
    @Override @StartNotRequired public void start(final ISessionContext sessionContext) throws BcbException {
        serviceControlHelper.start(sessionContext);
    }

    /**
     * {@inheritDoc}
     */
    @Override @Securable(SecureAction.SERVER_PUBLIC_DO_SYNCH) public void doSync(final ISessionContext sessionContext,
            @SecuredObject final IBiCNetComponentId[] componentIds, final ScsSyncMode syncMode,
            final SyncCategory syncCategory) throws BcbException {
        serviceControlHelper.doSync(sessionContext, componentIds, syncMode, syncCategory);
    }

    /**
     * {@inheritDoc}
     */
    @Override @Securable(SecureAction.SERVER_PUBLIC_DO_SYNCH) public void doForcedSync(
            final ISessionContext sessionContext, @SecuredObject final IBiCNetComponentId[] componentIds,
            final ScsSyncMode scsSyncMode, final SyncCategory syncCategory) throws BcbException {
        serviceControlHelper.doForcedSync(sessionContext, componentIds, scsSyncMode, syncCategory);
    }

    /**
     * {@inheritDoc}
     */
    @Override @Securable(SecureAction.SERVER_PUBLIC_DO_SYNCH) public void doFullSync(
            final ISessionContext sessionContext) throws BcbException {
        serviceControlHelper.doFullSync(sessionContext);
    }

    /**
     * {@inheritDoc}
     */
    @Override @StartNotRequired public void shutDown(final ISessionContext sessionContext) throws BcbException {
        serviceControlHelper.shutDown(sessionContext);
    }

    /**
     * {@inheritDoc}
     */
    @Override public void stop(final ISessionContext sessionContext) throws BcbException {
        serviceControlHelper.stop(sessionContext);
    }

    /**
     * {@inheritDoc}
     */
    @Override @StartNotRequired public ScsComponentState getState(final ISessionContext sessionContext)
            throws BcbException {
        return serviceControlHelper.getState(sessionContext);
    }

    /**
     * {@inheritDoc}
     */
    @Override @StartNotRequired public boolean isStartSupported(final ISessionContext sessionContext)
            throws BcbException {
        return serviceControlHelper.isStartSupported(sessionContext);
    }

    /**
     * {@inheritDoc}
     */
    @Override @StartNotRequired public boolean isStopSupported(final ISessionContext sessionContext)
            throws BcbException {
        return serviceControlHelper.isStopSupported(sessionContext);
    }

    /**
     * {@inheritDoc}
     */
    @Override @StartNotRequired public boolean isSyncSupported(final ISessionContext sessionContext)
            throws BcbException {
        return serviceControlHelper.isSyncSupported(sessionContext);
    }

    /**
     * {@inheritDoc}
     */
    @Override public String[] getOperations() {
        return securityManagerHelper.getOperations();
    }

    /**
     * {@inheritDoc}
     */
    @Override public ISecurableObject[] getSecurableObjects() {
        return securityManagerHelper.getSecurableObjects();
    }

    /**
     * {@inheritDoc}
     */
    @Override public void collectTraceData(final ISessionContext sessionContext, final File destinationFolder)
            throws BcbException {
        serviceConfiguration.collectTraceData(sessionContext, destinationFolder);
    }

    /**
     * {@inheritDoc}
     */
    @Override @StartNotRequired public BiCNetComponentType getComponentType(final ISessionContext sessionContext)
            throws BcbException {
        return serviceConfiguration.getComponentType(sessionContext);
    }

    /**
     * {@inheritDoc}
     */
    @Override @StartNotRequired public String getDescription(final ISessionContext sessionContext) throws BcbException {
        return serviceConfiguration.getDescription(sessionContext);
    }

    /**
     * {@inheritDoc}
     */
    @Override @StartNotRequired public Log4jLevel getLog4JDefaultLevel(final ISessionContext sessionContext)
            throws BcbException {
        return serviceConfiguration.getLog4JDefaultLevel(sessionContext);
    }

    /**
     * {@inheritDoc}
     */
    @Override @StartNotRequired public String getName(final ISessionContext sessionContext) throws BcbException {
        return serviceConfiguration.getName(sessionContext);
    }

    /**
     * {@inheritDoc}
     */
    @Override @StartNotRequired public ComponentVersionInformation getVersion(final ISessionContext sessionContext)
            throws BcbException {
        return serviceConfiguration.getVersion(sessionContext);
    }

    /**
     * {@inheritDoc}
     */
    @Override @StartNotRequired public boolean isTraceDataCollectionSupported(final ISessionContext sessionContext)
            throws BcbException {
        return serviceConfiguration.isTraceDataCollectionSupported(sessionContext);
    }

    /**
     * {@inheritDoc}
     */
    @Override public Map<String, ?> getGlobalProperties() {
        return serviceConfiguration.getGlobalSettings();
    }

    /**
     * {@inheritDoc}
     */
    @Override public INeDataTransferSettings getNeDataTransferSettings(final ISessionContext sessionContext,
            final INEId neId) throws BcbException {
        return serviceConfiguration.getNeDataTransferSettings(sessionContext, neId);
    }

    /**
     * {@inheritDoc}
     */
    @Override @Securable(SecureAction.SERVER_PUBLIC_ADD_USAGE) public void addUsage(
            final ISessionContext sessionContext, @SecuredObject final IManagedObjectId managedObjectId,
            final BiCNetComponentType componentType) throws BcbException {
        manageObjectHelper.addUsage(sessionContext, managedObjectId, componentType);
    }

    /**
     * {@inheritDoc}
     */
    @Override @Securable(SecureAction.SERVER_PUBLIC_RELEASE_USAGE) public void releaseUsage(
            final ISessionContext sessionContext, @SecuredObject final IManagedObjectId managedObjectId,
            final BiCNetComponentType componentType) throws BcbException {
        manageObjectHelper.releaseUsage(sessionContext, managedObjectId, componentType);
    }

    /**
     * {@inheritDoc}
     */
    @Override public void deactivateAllEMs(final ISessionContext sessionContext) throws BcbException {
        channelHelper.deactivateAllEMs(sessionContext);
    }

    /**
     * {@inheritDoc}
     */
    @Override @Securable(SecureAction.OP_DEACTIVATE_NES_SAN) public void deactivateEMs(
            final ISessionContext sessionContext, @SecuredObject final IEMId[] emIds) throws BcbException {
        channelHelper.deactivateEMs(sessionContext, emIds);
    }

    /**
     * {@inheritDoc}
     */
    @Override public EMIdReply getEMIdList(final ISessionContext sessionContext, final IEMId emId,
            final IEMMarkable[] emMarkables, final int howMany) throws BcbException {
        return channelHelper.getEMIdList(sessionContext, emId, emMarkables, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override public EMReply getEMList(final ISessionContext sessionContext, final IEMId emId,
            final IEMMarkable[] emMarkables, final int howMany) throws BcbException {
        return channelHelper.getEMList(sessionContext, emId, emMarkables, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override public IEM getSingleEM(final ISessionContext sessionContext, final IEMId emId) throws BcbException {
        return channelHelper.getSingleEM(sessionContext, emId);
    }

    /**
     * {@inheritDoc}
     */
    @Override @Securable(SecureAction.OP_NEW_CHANNEL_SAN) public IEM createEM(final ISessionContext sessionContext,
            final IEM em) throws BcbException {
        return channelHelper.createEM(sessionContext, em);
    }

    /**
     * {@inheritDoc}
     */
    @Override @Securable(SecureAction.SERVER_PUBLIC_MODIFY_CHANNEL) public IEMMarkable modifyEM(
            final ISessionContext sessionContext, @SecuredObject final IEMMarkable em) throws BcbException {
        return channelHelper.modifyEM(sessionContext, em);
    }

    /**
     * {@inheritDoc}
     */
    @Override @Securable(SecureAction.SERVER_PUBLIC_MODIFY_CHANNEL) public IEMMarkable[] modifyEMs(
            final ISessionContext sessionContext, @SecuredObject final IEMMarkable[] ems) throws BcbException {
        return channelHelper.modifyEMs(sessionContext, ems);
    }

    /**
     * {@inheritDoc}
     */
    @Override @Securable(SecureAction.OP_DELETE_SAN) public void deleteEM(final ISessionContext sessionContext,
            @SecuredObject final IEMId emId) throws BcbException {
        channelHelper.deleteEM(sessionContext, emId);
    }

    /**
     * {@inheritDoc}
     */
    @Override @Securable(SecureAction.OP_ACTIVATE_CHANNELS_SAN) public void activateEMs(
            final ISessionContext sessionContext, @SecuredObject final IEMId[] emIds) throws BcbException {
        channelHelper.activateEMs(sessionContext, emIds);
    }

    /**
     * {@inheritDoc}
     */
    @Override public String[] getRegisteredEmTypes(final ISessionContext sessionContext) throws BcbException {
        return channelHelper.getRegisteredEmTypes(sessionContext);
    }

    /**
     * {@inheritDoc}
     */
    @Override public INEId[] getActivatedNEs(final ISessionContext sessionContext, final INEId[] neIds)
            throws BcbException {
        return neHelper.getActivatedNEs(sessionContext, neIds);
    }

    /**
     * {@inheritDoc}
     */
    @Override public NeGneCost[] getCostToGneMap(final ISessionContext sessionContext) throws BcbException {
        return neHelper.getCostToGneMap(sessionContext);
    }
    
    
    /**
     * {@inheritDoc}
     */
    @Override public NeGneCost getCostToGne(ISessionContext sessionContext, INEId neId) throws BcbException {
        return neHelper.getCostToGne(sessionContext, neId);
    }
    
    /**
     * {@inheritDoc}
     */
    @Override public NEIdReply getNEIdList(final ISessionContext sessionContext, final INEId neIds,
            final INEMarkable[] emMarkables, final int howMany) throws BcbException {
        return neHelper.getNEIdList(sessionContext, neIds, emMarkables, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override public NEReply getNEList(final ISessionContext sessionContext, final INEId neId,
            final INEMarkable[] neMarkables, final int howMany) throws BcbException {
        return neHelper.getNEList(sessionContext, neId, neMarkables, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override public NEReply getNEList(final ISessionContext sessionContext, final INEId neId,
            final INEMarkable[] neMarkables, final int howMany, final NeCapability capability) throws BcbException {
        return neHelper.getNEList(sessionContext, neId, neMarkables, howMany, capability);
    }

    /**
     * {@inheritDoc}
     */
    @Override public INE getSingleNE(final ISessionContext sessionContext, final INEId neId) throws BcbException {
        return neHelper.getSingleNE(sessionContext, neId);
    }

    /**
     * {@inheritDoc}
     */
    @Override @Securable(SecureAction.SERVER_PUBLIC_MODIFY_NE) public INEMarkable modifyNE(
            final ISessionContext sessionContext, @SecuredObject final INEMarkable ne) throws BcbException {
        return neHelper.modifyNE(sessionContext, ne);
    }

    /**
     * {@inheritDoc}
     */
    @Override @Securable(SecureAction.SERVER_PUBLIC_MODIFY_NE) public INEMarkable[] modifyNEs(
            final ISessionContext sessionContext, @SecuredObject final INEMarkable[] nes) throws BcbException {
        return neHelper.modifyNEs(sessionContext, nes);
    }

    /**
     * {@inheritDoc}
     */
    @Override public INEId[] getAllNEsFromAllDomainsByNE(final ISessionContext sessionContext, final INEId neId)
            throws BcbException {
        return domainHelper.getAllNEsFromAllDomainsByNE(sessionContext, neId);
    }

    /**
     * {@inheritDoc}
     */
    @Override public Property getNeTypeProperty(final ISessionContext sessionContext, final int neId,
            final String propertyName) throws IllegalArgumentException, UnsupportedOperationException {
        return neHelper.getNeTypeProperty(sessionContext, neId, propertyName);
    }

    /**
     * {@inheritDoc}
     */
    @Override public AlarmReply getAlarmList(final ISessionContext sessionContext, final IAlarmId alarmId,
            final IManagedObjectId[] managedObjectIds, final int howMany) throws BcbException {
        return alarmHelper.getAlarmList(sessionContext, alarmId, managedObjectIds, howMany);
    }

    /**
     * {@inheritDoc}
     */
    @Override public void enableAlarms(final ISessionContext sessionContext, final IManagedObjectId[] filter,
            final AlarmMaskConfiguration alarmMaskConf, final TrafficDirection trafficDirection,
            final boolean immediatelyReport) throws BcbException {
        alarmHelper.enableAlarms(sessionContext, filter, alarmMaskConf, trafficDirection, immediatelyReport);

    }

    /**
     * {@inheritDoc}
     */
    @Override public void disableAlarms(final ISessionContext sessionContext, final IManagedObjectId[] filter,
            final AlarmMaskConfiguration alarmMaskConf, final TrafficDirection trafficDirection) throws BcbException {
        alarmHelper.disableAlarms(sessionContext, filter, alarmMaskConf, trafficDirection);
    }

    /**
     * {@inheritDoc}
     */
    @Override public String[] getDomainList(final ISessionContext sessionContext, final INEId neId) {
        return domainHelper.getDomainList(sessionContext, neId);
    }

    /**
     * {@inheritDoc}
     */
    @Override public INE[] getNesByDomain(final ISessionContext sessionContext, final String[] domainIds) {
        return domainHelper.getNesByDomain(sessionContext, domainIds);
    }

    @Override public Property[] getProperties(final ISessionContext sessionContext,
            final IManagedObjectId managedObjectId, final String[] keys)
            throws IllegalArgumentException, UnsupportedOperationException {
        try {
            final Collection<String> filter = ImmutableList.copyOf(nullToEmpty(keys));
            final Set<Map.Entry<String, String>> properties;

            if (managedObjectId instanceof IEMId) {
                properties = channelHelper.getProperties(sessionContext, (IEMId) managedObjectId).entrySet();
            } else if (managedObjectId instanceof INEId) {
                properties = neHelper.getProperties(sessionContext, (INEId) managedObjectId).entrySet();
            } else if (managedObjectId instanceof IMediatorId) {
                properties = mediatorService.getProperties(sessionContext, (IMediatorId) managedObjectId).entrySet();
            } else {
                throw new UnableToComplyException("Object not supported.");
            }

            return properties.stream().filter(entry -> filter.isEmpty() || filter.contains(entry.getKey()))
                    .map(entry -> new Property(entry.getKey(), entry.getValue())).toArray(Property[]::new);
        } catch (final ClassCastException e) {
            throw new IllegalArgumentException(e);
        } catch (final BcbException e) {
            throw new UnsupportedOperationException(e);
        }
    }

    @Override public Map<IManagedObjectId, Property[]> getPropertiesMap(final ISessionContext sessionContext,
                                              final IManagedObjectId[] moIds, final String[] keys)
            throws IllegalArgumentException, UnsupportedOperationException {

        Map<IManagedObjectId, Property[]> propertiesMap = new HashMap<>();

        if (ArrayUtils.isNotEmpty(moIds)) {
            for (IManagedObjectId moId: moIds) {
                propertiesMap.put(moId, getProperties(sessionContext, moId, keys));
            }
        }
        return propertiesMap;
    }

    /**
     * @deprecated Not supported any more, to be removed.
     */
    @Deprecated @Override public IconPairIdReply getIconPairIdList(final ISessionContext sessionContext,
            final IIconPairId arg1, final IIconPairMarkable[] arg2, final int arg3) throws BcbException {
        throw new UnableToComplyException();
    }

    /**
     * @deprecated Not supported any more, to be removed.
     */
    @Deprecated @Override public IconPairReply getIconPairList(final ISessionContext sessionContext,
            final IIconPairId arg1, final IIconPairMarkable[] arg2, final int arg3) throws BcbException {
        throw new UnableToComplyException();
    }

    /**
     * @deprecated Not supported any more, to be removed.
     */
    @Deprecated @Override public IIconPair getSingleIconPair(final ISessionContext sessionContext,
            final IIconPairId arg1) throws BcbException {
        throw new UnableToComplyException();
    }

    @Override public INE createNE(final ISessionContext sessionContext, final INE ne) throws BcbException {
        return neHelper.createNE(sessionContext, ne);
    }

    @Override public void deleteNE(final ISessionContext sessionContext, final INEId neId) throws BcbException {
        neHelper.deleteNE(sessionContext, neId);
    }

    @Override public void activateNEs(final ISessionContext sessionContext, final INEId[] nes) throws BcbException {
        neHelper.activateNEs(sessionContext, nes);
    }

    @Override public void deactivateNEs(final ISessionContext sessionContext, final INEId[] nes) throws BcbException {
        neHelper.deactivateNEs(sessionContext, nes);
    }

    @Override public Property[] getProperties(final ISessionContext sessionContext,
            final IManagedObjectId managedObjectId) throws IllegalArgumentException, UnsupportedOperationException {
        return getProperties(sessionContext, managedObjectId, ArrayUtils.EMPTY_STRING_ARRAY);
    }

    @Override public Map<IManagedObjectId, Property[]> getPropertiesMap(final ISessionContext sessionContext,
                                              final IManagedObjectId[] moIds) throws IllegalArgumentException, UnsupportedOperationException {
        return getPropertiesMap(sessionContext, moIds, ArrayUtils.EMPTY_STRING_ARRAY);
    }

    /**
     * @deprecated Should be replaced by strongly typed methods instead.
     */
    @Deprecated @Override public void setProperties(final ISessionContext sessionContext, final IManagedObjectId moId,
            final Property[] properties) throws BcbException {
        final Map<String, String> propertyMap = ConvertBcbPropertyToMap.convert(properties);
        if (moId instanceof IEMId) {
            channelHelper.updateProperties(sessionContext, (IEMId) moId, propertyMap);
        } else if (moId instanceof INEId) {
            neHelper.updateProperties(sessionContext, (INEId) moId, propertyMap);
        } else if (moId instanceof IMediatorId) {
            mediatorService.updateProperties(sessionContext, (IMediatorId) moId, propertyMap);
        } else {
            throw new UnableToComplyException("Object not supported.");
        }
    }

    @Override public Property[] getMediatorProperties(ISessionContext sessionContext, INEId neId)
            throws IllegalArgumentException, UnsupportedOperationException {
        try {
            final Optional<IMediatorId> mediatorId = neHelper.getMediatorIdByNeId(neId);

            if (mediatorId.isPresent()) {
                return getProperties(sessionContext, mediatorId.get());
            }

            return null;
        } catch (final BcbException e) {
            throw new UnsupportedOperationException(e);
        }
    }

    @Override public void setNeDataTransferSettings(final ISessionContext sessionContext, final INEId neId,
            final INeDataTransferSettings neDataTransferSettings) throws BcbException {
        serviceConfiguration.setNeDataTransferSettings(sessionContext, neId, neDataTransferSettings);
    }

    @Override public INE createNE(final ISessionContext sessionContext, final String neProxyType,
            final IEMId parentEmId, final INEId parentNeId, final String neIdName, final Property[] neProperties)
            throws BcbException {
        return createNE(sessionContext, neProxyType, parentEmId, parentNeId, neIdName, NeManagementState.MANAGED, neProperties);
    }

    @Override public INE createNE(final ISessionContext sessionContext, final String neProxyType,
            final IEMId parentEmId, final INEId parentNeId, final String neIdName, NeManagementState neManagedState, final Property[] neProperties)
            throws BcbException {
        return neHelper.createNE(sessionContext, neProxyType, parentEmId, neIdName, neProperties);
    }


    @Override public IEM createEM(final ISessionContext sessionContext, final String emType, final String emIdName,
            final IMediatorId parentMediator, final Property[] emProperties) throws BcbException {
        return channelHelper.createEM(sessionContext, emType, emIdName, parentMediator, emProperties);
    }

    @Override public ISystemContainer getSingleSystemContainer(final ISessionContext sessionContext,
            final ISystemContainerId systemcontainerId) throws BcbException {
        return systemContainer.getSingleSystemContainer(sessionContext, systemcontainerId);
    }

    @Override public SystemContainerReply getSystemContainerList(final ISessionContext sessionContext,
            final ISystemContainerId startAfter, final ISystemContainerMarkable[] filter, final int howMany)
            throws BcbException {
        return systemContainer.getSystemContainerList(sessionContext, startAfter, filter, howMany);
    }

    @Override public SystemContainerIdReply getSystemContainerIdList(final ISessionContext sessionContext,
            final ISystemContainerId startAfter, final ISystemContainerMarkable[] filter, final int howMany)
            throws BcbException {
        return systemContainer.getSystemContainerIdList(sessionContext, startAfter, filter, howMany);
    }

    @Override public ISystemContainer createSystemContainer(final ISessionContext sessionContext,
            final ISystemContainer systemcontainer) throws BcbException {
        return systemContainer.createSystemContainer(sessionContext, systemcontainer);
    }

    @Override public void deleteSystemContainer(final ISessionContext sessionContext,
            final ISystemContainerId systemcontainerId) throws BcbException {
        systemContainer.deleteSystemContainer(sessionContext, systemcontainerId);
    }

    @Override public ISystemContainerMarkable modifySystemContainer(final ISessionContext sessionContext,
            final ISystemContainerMarkable systemcontainer) throws BcbException {
        return systemContainer.modifySystemContainer(sessionContext, systemcontainer);
    }

    @Override public ISystemContainerMarkable[] modifySystemContainers(final ISessionContext sessionContext,
            final ISystemContainerMarkable[] systemcontainers) throws BcbException {
        return systemContainer.modifySystemContainers(sessionContext, systemcontainers);
    }

    @Override public void resynchronizeNEs(final ISessionContext sessionContext, final INEId[] neIdentifiers)
            throws BcbException {
        neHelper.resynchronizeNEs(sessionContext, neIdentifiers);
    }

    @Override public INetworkSettings getTheNetworkSettings(final ISessionContext sessionContext) {
        return serviceConfiguration.getTheNetworkSettings(sessionContext);
    }

    @Override public INetworkDomain getSingleNetworkDomain(ISessionContext sessionContext,
            INetworkDomainId networkDomainId) throws BcbException {
        return domainHelper.getSingleNetworkDomain(sessionContext, networkDomainId);
    }

    @Override public NetworkDomainReply getNetworkDomainList(ISessionContext sessionContext,
            INetworkDomainId startAfter, INetworkDomainMarkable[] filter, int howMany) throws BcbException {
        return domainHelper.getNetworkDomainList(sessionContext, startAfter, filter, howMany);
    }

    @Override public INetworkDomainId[] getNetworkDomainIdsForNE(ISessionContext sessionContext, INEId neId)
            throws BcbException {
        return domainHelper.getNetworkDomainIdsForNE(sessionContext, neId);
    }

    @Override public INetworkDomain[] getNetworkDomainsForNE(ISessionContext sessionContext, INEId neId)
            throws BcbException {
        return domainHelper.getNetworkDomainsForNE(sessionContext, neId);
    }

    @Override public INEId[] getNEIdsInNetworkDomain(ISessionContext sessionContext, INetworkDomainId networkDomainId)
            throws BcbException {
        return domainHelper.getNEIdsInNetworkDomain(sessionContext, networkDomainId);
    }

    @Override public INE[] getNEsInNetworkDomain(ISessionContext sessionContext, INetworkDomainId networkDomainId)
            throws BcbException {
        return domainHelper.getNEsInNetworkDomain(sessionContext, networkDomainId);
    }

    @Override public NetworkDomainParticipationReply getNetworkDomainParticipationList(ISessionContext sessionContext,
            INetworkDomainParticipationId startAfter, INetworkDomainParticipationMarkable[] filter, int howMany)
            throws BcbException {
        return domainHelper.getNetworkDomainParticipationList(sessionContext, startAfter, filter, howMany);
    }

    @Override public IMediator getSingleMediator(ISessionContext sessionContext, IMediatorId mediatorId)
            throws BcbException {
        return mediatorService.getSingleMediator(sessionContext, mediatorId);
    }

    @Override public MediatorReply getMediatorList(ISessionContext sessionContext, IMediatorId startAfter,
            IMediatorMarkable[] filter, int howMany) throws BcbException {
        return mediatorService.getMediatorList(sessionContext, startAfter, filter, howMany);
    }

    @Override public MediatorIdReply getMediatorIdList(ISessionContext sessionContext, IMediatorId startAfter,
            IMediatorMarkable[] filter, int howMany) throws BcbException {
        return mediatorService.getMediatorIdList(sessionContext, startAfter, filter, howMany);
    }

    @Override public IMediator createMediator(ISessionContext sessionContext, IMediator mediator) throws BcbException {
        return mediatorService.createMediator(sessionContext, mediator);
    }

    @Override public void deleteMediator(ISessionContext sessionContext, IMediatorId mediatorId) throws BcbException {
        mediatorService.deleteMediator(sessionContext, mediatorId);
    }

    @Override public IMediatorMarkable modifyMediator(ISessionContext sessionContext, IMediatorMarkable mediator)
            throws BcbException {
        return mediatorService.modifyMediator(sessionContext, mediator);
    }

    @Override public void activateMediators(ISessionContext sessionContext, IMediatorId[] mediators)
            throws BcbException {
        mediatorService.activateMediators(sessionContext, mediators);
    }

    @Override public void deactivateMediators(ISessionContext sessionContext, IMediatorId[] mediators)
            throws BcbException {
        mediatorService.deactivateMediators(sessionContext, mediators);
    }

    @Override public void deactivateAllMediators(ISessionContext sessionContext) throws BcbException {
        mediatorService.deactivateAllMediators(sessionContext);
    }

    @Override public IMediator createMediator(ISessionContext context, IMediator mediator, Property[] properties)
            throws BcbException {
        return mediatorService.store(context, mediator, ConvertBcbPropertyToMap.convert(properties));
    }

    @Override public NesReply getExportNEs(ISessionContext sessionContext, int startIndex, int size)
            throws BcbException {
        return neConfigurationExportService.export(sessionContext, startIndex, size);
    }

    @Override public ChannelsReply getExportChannels(ISessionContext sessionContext, int startIndex, int size)
            throws BcbException {
        return channelConfigurationExportService.export(sessionContext, startIndex, size);
    }

    @Override public MediatorsReply getExportMediators(ISessionContext sessionContext, int startIndex, int size)
            throws BcbException {
        return mediatorConfigurationExportService.export(sessionContext, startIndex, size);
    }

    @Override public IGenericContainer getSingleGenericContainer(ISessionContext sessionContext,
            IGenericContainerId genericContainerId) throws BcbException {
        return containerHelper.getSingleGenericContainer(sessionContext, genericContainerId);
    }

    @Override public GenericContainerReply getGenericContainerList(ISessionContext sessionContext,
            IGenericContainerId startAfter, IGenericContainerMarkable[] filter, int howMany) throws BcbException {
        return containerHelper.getGenericContainerList(sessionContext, startAfter, filter, howMany);
    }

    @Override public GenericContainerIdReply getGenericContainerIdList(ISessionContext sessionContext,
            IGenericContainerId startAfter, IGenericContainerMarkable[] filter, int howMany) throws BcbException {
        return containerHelper.getGenericContainerIdList(sessionContext, startAfter, filter, howMany);
    }

    @Override public IGenericContainer createGenericContainer(ISessionContext sessionContext,
            IGenericContainer genericContainer) throws BcbException {
        return containerHelper.createGenericContainer(sessionContext, genericContainer);
    }

    @Override public void deleteGenericContainer(ISessionContext sessionContext, IGenericContainerId genericContainer)
            throws BcbException {
        containerHelper.deleteGenericContainer(sessionContext, genericContainer);
    }

    @Override public IGenericContainerMarkable modifyGenericContainer(ISessionContext sessionContext,
            IGenericContainerMarkable genericContainer) throws BcbException {
        return containerHelper.modifyGenericContainer(sessionContext, genericContainer);
    }

    @Override public IGenericContainerMarkable[] modifyGenericContainers(ISessionContext sessionContext,
            IGenericContainerMarkable[] genericContainers) throws BcbException {
        return containerHelper.modifyGenericContainers(sessionContext, genericContainers);
    }

    @Override public INeGenericContainerAssignment getSingleNeGenericContainerAssignment(ISessionContext sessionContext,
            INeGenericContainerAssignmentId neContainerAssignId) throws BcbException {
        return neAssignmentHelper.getSingleNeGenericContainerAssignment(sessionContext, neContainerAssignId);
    }

    @Override public NeGenericContainerAssignmentReply getNeGenericContainerAssignmentList(
            ISessionContext sessionContext, INeGenericContainerAssignmentId startAfter,
            INeGenericContainerAssignmentMarkable[] filter, int howMany) throws BcbException {
        return neAssignmentHelper.getNeGenericContainerAssignmentList(sessionContext, startAfter, filter, howMany);
    }

    @Override public NeGenericContainerAssignmentIdReply getNeGenericContainerAssignmentIdList(
            ISessionContext sessionContext, INeGenericContainerAssignmentId startAfter,
            INeGenericContainerAssignmentMarkable[] filter, int howMany) throws BcbException {
        return neAssignmentHelper.getNeGenericContainerAssignmentIdList(sessionContext, startAfter, filter, howMany);
    }

    @Override public INeGenericContainerAssignment createNeGenericContainerAssignment(ISessionContext sessionContext,
            INeGenericContainerAssignment neContainerAssign) throws BcbException {
        return neAssignmentHelper.createNeGenericContainerAssignment(sessionContext, neContainerAssign);
    }

    @Override public void deleteNeGenericContainerAssignment(ISessionContext sessionContext,
            INeGenericContainerAssignmentId neContainerAssignId) throws BcbException {
        neAssignmentHelper.deleteNeGenericContainerAssignment(sessionContext, neContainerAssignId);
    }

    @Override public INeGenericContainerAssignmentMarkable modifyNeGenericContainerAssignment(
            ISessionContext sessionContext, INeGenericContainerAssignmentMarkable neContainerAssign)
            throws BcbException {
        return neAssignmentHelper.modifyNeGenericContainerAssignment(sessionContext, neContainerAssign);
    }

    @Override public INeGenericContainerAssignmentMarkable[] modifyNeGenericContainerAssignments(
            ISessionContext sessionContext, INeGenericContainerAssignmentMarkable[] neContainerAssigns)
            throws BcbException {
        return neAssignmentHelper.modifyNeGenericContainerAssignments(sessionContext, neContainerAssigns);
    }

    @Override public void assignNe(ISessionContext sessionContext, INEId neId, IGenericContainerId primaryContainer,
            IGenericContainerId[] secondaryContainers) throws BcbException {
        neAssignmentHelper.assignNe(sessionContext, neId, primaryContainer, secondaryContainers);
    }

    @Override public void assignSystem(ISessionContext sessionContext, ISystemContainerId system,
            IGenericContainerId primaryContainer, IGenericContainerId[] secondaryContainers) throws BcbException {
        systemAssignmentHelper.assignSystem(sessionContext, system, primaryContainer, secondaryContainers);
    }

    @Override public ISystemGenericContainerAssignment getSingleSystemGenericContainerAssignment(
            ISessionContext sessionContext, ISystemGenericContainerAssignmentId systemGenericAssignId)
            throws BcbException {
        return systemAssignmentHelper.getSingleSystemGenericContainerAssignment(sessionContext, systemGenericAssignId);
    }

    @Override public SystemGenericContainerAssignmentReply getSystemGenericContainerAssignmentList(
            ISessionContext sessionContext, ISystemGenericContainerAssignmentId startAfter,
            ISystemGenericContainerAssignmentMarkable[] filter, int howMany) throws BcbException {
        return systemAssignmentHelper
                .getSystemGenericContainerAssignmentList(sessionContext, startAfter, filter, howMany);
    }

    @Override public SystemGenericContainerAssignmentIdReply getSystemGenericContainerAssignmentIdList(
            ISessionContext sessionContext, ISystemGenericContainerAssignmentId startAfter,
            ISystemGenericContainerAssignmentMarkable[] filter, int howMany) throws BcbException {
        return systemAssignmentHelper
                .getSystemGenericContainerAssignmentIdList(sessionContext, startAfter, filter, howMany);
    }

    @Override public ISystemGenericContainerAssignment createSystemGenericContainerAssignment(
            ISessionContext sessionContext, ISystemGenericContainerAssignment systemGenericAssign) throws BcbException {
        return systemAssignmentHelper.createSystemGenericContainerAssignment(sessionContext, systemGenericAssign);
    }

    @Override public void deleteSystemGenericContainerAssignment(ISessionContext sessionContext,
            ISystemGenericContainerAssignmentId systemGenericAssignId) throws BcbException {
        systemAssignmentHelper.deleteSystemGenericContainerAssignment(sessionContext, systemGenericAssignId);
    }

    @Override public ISystemGenericContainerAssignmentMarkable modifySystemGenericContainerAssignment(
            ISessionContext sessionContext, ISystemGenericContainerAssignmentMarkable systemGenericAssign)
            throws BcbException {
        return systemAssignmentHelper.modifySystemGenericContainerAssignment(sessionContext, systemGenericAssign);
    }

    @Override public ISystemGenericContainerAssignmentMarkable[] modifySystemGenericContainerAssignments(
            ISessionContext sessionContext, ISystemGenericContainerAssignmentMarkable[] systemGenericAssigns)
            throws BcbException {
        return systemAssignmentHelper.modifySystemGenericContainerAssignments(sessionContext, systemGenericAssigns);
    }

    @Override
    public void switchToNeManagementState(ISessionContext sessionContext, INEId neID, NeManagementState neManagementState)
            throws BcbException {
        // TODO Auto-generated method stub
        
    }
}
