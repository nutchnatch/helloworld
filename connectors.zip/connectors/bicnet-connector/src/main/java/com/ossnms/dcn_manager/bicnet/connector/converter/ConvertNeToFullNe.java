package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullNeData;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationState;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToFullNe.ConversionData;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;

import java.util.Optional;
import java.util.function.Function;

/**
 * Handles conversion of internal domain entities representing a NE to its
 * corresponding type in the Full object to GUI model.
 */
public class ConvertNeToFullNe implements Function<ConversionData, FullNeData> {

    @Override
    public FullNeData apply(ConversionData neInformation) {
        return neInformation != null
                ? convert(neInformation.type, neInformation.scsState, neInformation.entity,
                          neInformation.routes, neInformation.instances)
                : null;
    }

    /**
     * Converts a NE domain entity into a new {@link INE} BCB object.
     *
     * @param type NE type metadata.
     * @param scsSynchronizationState SCS synchronization, forwarded to the client.
     * @param ne NE instance that will be the source of data for the client and the server components.
     * @param routes NE gateway routes. Used to determine "connected via".
     * @param instances NE physical instances. Used to determine the "standby state".
     * @return A new instance of {@link FullNeData} filled with data.
     */
    public static FullNeData convert(NeType type, Optional<ScsSynchronizationState> scsSynchronizationState,
                                     NeEntity ne, Iterable<NeGatewayRouteData> routes,
                                     Iterable<NePhysicalConnectionData> instances) {
        final INE bcbNe = ConvertNeToBcb.convert(type, ne, routes, instances);
        final NeInfo info = ConvertNeToNeGuiInfo.build(ne, instances, routes);

        return new FullNeData(bcbNe, info, scsSynchronizationState.orElse(new ScsSynchronizationState(ne.getInfo().getNeId(), ScsSyncState.OUT_OF_SYNC)));
    }

    public static class ConversionData {

        private final NeType type;
        private final Optional<ScsSynchronizationState> scsState;
        private final NeEntity entity;
        private final Iterable<NePhysicalConnectionData> instances;
        private final Iterable<NeGatewayRouteData> routes;

        public ConversionData(NeType type, Optional<ScsSynchronizationState> scsState, NeEntity entity,
                              Iterable<NeGatewayRouteData> routes, Iterable<NePhysicalConnectionData> instances) {
            this.type = type;
            this.scsState = scsState;
            this.entity = entity;
            this.routes = routes;
            this.instances = instances;
        }
    }
}