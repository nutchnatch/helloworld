package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import org.apache.commons.lang3.tuple.Pair;

import javax.annotation.Nullable;
import java.util.function.Function;

public final class PairChannelWithType implements Function<ChannelEntity, Pair<ChannelType, ChannelEntity>> {

    private final StaticConfiguration configuration;

    public PairChannelWithType(StaticConfiguration configuration) {
        this.configuration = configuration;
    }

    public static Pair<ChannelType, ChannelEntity> pair(StaticConfiguration configuration,
            @Nullable ChannelEntity channel) {
        return null == channel ?
                null :
                Pair.of(configuration.getChannelTypes().get(channel.getInfo().getType()), channel);
    }

    @Override public Pair<ChannelType, ChannelEntity> apply(ChannelEntity channel) {
        return pair(configuration, channel);
    }
}