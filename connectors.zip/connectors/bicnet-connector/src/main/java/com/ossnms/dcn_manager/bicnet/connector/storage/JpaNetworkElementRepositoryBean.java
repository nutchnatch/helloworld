package com.ossnms.dcn_manager.bicnet.connector.storage;

import com.google.common.base.Function;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaCloseableQuery;
import com.ossnms.dcn_manager.connector.storage.StartableRepository;
import com.ossnms.dcn_manager.connector.storage.ne.NeRepository;
import com.ossnms.dcn_manager.connector.storage.ne.entities.NeEntityDb;
import com.ossnms.dcn_manager.connector.storage.ne.entities.QNeEntityDb;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Optional;

/**
 * <p>EJB that maintains an instance of a Network Element repository.</p>
 *
 * <p>It establishes all the wiring necessary to become an instance of {@link NeRepository}.
 * It also contains methods that are specific to BiCNet. These are not accessible to lower layers.</p>
 */
@DcnManager
@ApplicationScoped
public class JpaNetworkElementRepositoryBean extends NeRepository implements StartableRepository {

    private static final Logger LOGGER = LoggerFactory.getLogger(JpaNetworkElementRepositoryBean.class);

    @Inject
    private JpaRepositoryBean repositoryBean;

    private InMemoryNeSyncStateRepository neSyncStateRepo;

    @PostConstruct
    public void initialize() {
        neSyncStateRepo = new InMemoryNeSyncStateRepository();

        initialize(repositoryBean.getTransactionSupplier());
    }

    @Override
    protected CloseableEntityTransaction getTransaction() {
        return repositoryBean.getTransactionSupplier().get();
    }

    /**
     * Gets the repository for the domain object that represents the SCS Synchronization State against the entity.
     * @return The repository for the SCS Synchronization State domain objects.
     */
    public InMemoryNeSyncStateRepository getNeSyncStateRepository() {
        return neSyncStateRepo;
    }

    /**
     * Provides access to a DSL for building queries against NE Entities stored in the JPA database.
     * @param path Querydsl query type for the NE Entity. Usually a reference to {@code QNeEntityDb.neEntityDb}.
     * @return An instance of a Querydsl query building object.
     */
    public JpaCloseableQuery query(QNeEntityDb path) {
        return new JpaCloseableQuery(repositoryBean.getManagerSupplier().get(), path);
    }

    /**
     * @return A {@link Function} that converts a database NE entity into its domain object representation.
     */
    public Function<NeEntityDb, Optional<NeEntity>> getEntityTransformer() {
        return entityTransformer;
    }

    private final Function<NeEntityDb, Optional<NeEntity>> entityTransformer = input -> {
        try {
            return null != input ? fetchEntity(input) : Optional.empty();
        } catch (final RepositoryException e) {
            LOGGER.error("Error listing NE entities.", e);
            return Optional.empty();
        }
    };
}
