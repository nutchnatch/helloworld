package com.ossnms.dcn_manager.bicnet.connector.messaging.stream;

import javax.annotation.Nonnull;

import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.model.IMoFacet;
import com.ossnms.bicnet.bcb.model.IMoFacetMarkable;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;

import rx.functions.Func1;

/**
 * Determines whether the incoming {@link AttributeValueChange} contains changed
 * data and was issued against a specific type.
 */
public final class IsAvcAgainstType
        implements Func1<AttributeValueChange, Boolean> {

    private final Class<?> moType;

    /**
     * Creates a new object.
     * @param moType Desired target type for the AVC.
     */
    public IsAvcAgainstType(Class<?> moType) {
        this.moType = moType;
    }

    /**
     * Examines an {@link AttributeValueChange} notification.
     *
     * @param avc Incoming {@link AttributeValueChange} to examine.
     * @return True if the incoming {@link AttributeValueChange} contains changed
     * data and was issued against the type defined upon construction.
     */
    @Override
    public Boolean call(@Nonnull AttributeValueChange avc) {
        final IManagedObjectMarkable changedObject = avc.getChangedObject();
        return changedObject != null &&
                moType.isAssignableFrom(changedObject.getClass()) &&
                countAllMarks(changedObject) > 0;
    }

    private int countAllMarks(IManagedObjectMarkable mo) {
        int moMarks = mo.countMarks();
        final IMoFacet[] facets = mo.getOptionalFacets();
        if (null != facets) {
            for (final IMoFacet facet : facets) {
                if (facet instanceof IMoFacetMarkable) {
                    moMarks += ((IMoFacetMarkable) facet).countMarks();
                }
            }
        }
        return moMarks;
    }

}