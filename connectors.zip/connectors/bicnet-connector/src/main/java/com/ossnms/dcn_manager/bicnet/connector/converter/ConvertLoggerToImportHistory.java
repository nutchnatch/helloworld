package com.ossnms.dcn_manager.bicnet.connector.converter;

import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertSeverityToBcb.convertSeverity;

import java.util.Date;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.google.common.base.Function;
import com.ossnms.bicnet.bcb.facade.logMgmt.ImportExportLogRecordItem;
import com.ossnms.bicnet.bcb.facade.logMgmt.LogIdItem;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogId;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecord;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemImportHistory;

/**
 * Converts the {@link LoggerItemImportHistory} to BCB {@link ConvertLoggerToImportHistory}
 */
public class ConvertLoggerToImportHistory implements Function<LoggerItemImportHistory, ILogRecord> {

    protected static final ILogId LOG_IMPORT_ID = new LogIdItem("Import Export Log");

    public static ImportExportLogRecordItem convert(@Nonnull LoggerItemImportHistory input) {

        final ImportExportLogRecordItem logRecord = new ImportExportLogRecordItem();

        logRecord.setBelonging(LOG_IMPORT_ID);
        logRecord.setBelongingName(LOG_IMPORT_ID.getName());
        logRecord.setComponent(BiCNetComponentType.DCN_MANAGER);

        logRecord.setTimeStamp(new Date());

        logRecord.setSeverity(convertSeverity(input.getSeverity()));

        logRecord.setAffectedObject(input.getAffectedObject());
        logRecord.setDescription(input.getMessage());
        logRecord.setExecutionId(input.getExecutionId());

        return logRecord;
    }

    /**
     * @see Function#apply(Object)
     */
    @Override
    public ILogRecord apply(@Nullable LoggerItemImportHistory input) {
        return input == null ? null : convert(input);
    }
}
