package com.ossnms.dcn_manager.bicnet.connector.security;

import java.lang.annotation.Annotation;

import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import org.apache.commons.lang3.concurrent.AtomicSafeInitializer;
import org.apache.commons.lang3.concurrent.ConcurrentException;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ossnms.bicnet.bcb.facade.security.ISecureServerSession;
import com.ossnms.bicnet.bcb.facade.security.ISecurityMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.security.AuthorizationFailedException;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import com.ossnms.dcn_manager.bicnet.connector.interfaces.BicnetServiceManagerFactory;

/**
 * <p>Aspect responsible for asking the Security Manager for permission for
 * executing operations/actions.</p>
 * <p>These actions are methods marked with the {@link Securable} annotation.
 * Should any of these methods require authentication based on managed object
 * identifiers, they should be marked with the {@link SecuredObject} annotation.
 * These methods must also be declared as throwing {@link BcbException}</p>
 *
 *  <p>For example:</p>
 *
 *  <p><pre>
 *  {@literal @}Securable(SecureAction.OP_DELETE_SAN)
 *  public void deleteEM(ISessionContext sessionContext, @SecuredObject IEMId emId)
 *          throws BcbException {
 *      // (...)
 *  }
 *  </pre></p>
 */
@Aspect("issingleton()")
public class SecureActionValidation {

    private final class SecurityMgrFacadeInitializer extends
            AtomicSafeInitializer<ISecurityMgrFacade> {
        @Override
        protected ISecurityMgrFacade initialize() throws ConcurrentException {
            return serviceManager.getSecurityManagerFacade();
        }
    }

    private BicnetServiceManagerFactory serviceManager;
    private AtomicSafeInitializer<ISecurityMgrFacade> securityManager;

    /**
     * Matches any method in any class that is annotated with {@link Securable}.
     */
    @Pointcut("execution ( @Securable * *(..) )")
    public void beforeSecurableAction() { }

    /**
     * Extract information from method and parameter annotations and use it to
     * inquire Security Manager about permissions.
     *
     * @throws AuthorizationFailedException If the call under verification should not proceed.
     * @throws BcbException When an error occurs.
     */
    @Before("beforeSecurableAction() && target(targetObject) && args(sessionContext, ..)")
    public void beforeMethod(JoinPoint thisJoinPoint, ISessionContext sessionContext, Object targetObject) throws BcbException {
        final ISecurityMgrFacade security = getSecurityManager();
        final Logger logger = LoggerFactory.getLogger(targetObject.getClass());
        final MethodSignature signature = (MethodSignature) thisJoinPoint.getSignature();

        if (logger.isDebugEnabled()) {
            logger.debug("Validating secured call to {}", signature.toShortString());
        }

        if (null == security) {
            throw new AuthorizationFailedException("Security manager is unavailable. Secured call has been forbidden.");
        }

        final SecureAction action = signature.getMethod().getAnnotation(Securable.class).value();
        final Object[] arguments = thisJoinPoint.getArgs();
        final Annotation[][] argumentAnnotations = signature.getMethod().getParameterAnnotations();
        final IManagedObjectId[] securedObjects = getSecuredObjects(arguments, argumentAnnotations);

        final boolean allowed = callIsAllowed(logger, security, action, sessionContext, securedObjects);

        if (!allowed) {
            logger.info("Secured call to {} has been forbidden.", action.getIdentifier());
            throw new AuthorizationFailedException();
        }
    }

    /**
     * <p>Enquire Security Manager to find out if a given operation is allowed within the
     * current session context.</p>
     * <p>Operations (also known as actions or calls) have a string identifier. They
     * may also have a set of managed object identifiers referring to the objects the
     * operation will act upon. Security Manager will be enquired about permissions
     * for an operations over a set of objects.</p>
     * <p>Permission will be denied if:</p>
     * <ul><li>Security Manager denies it, when no managed objects are involved.</li>
     * <li>Security Manager reports a different set of authorized managed objects.</li>
     * <li>The Security Manager facade call throws an exception.</li>
     * </ul>
     * @param logger Logger instance for reporting security issues.
     * @param security Security Manager instance.
     * @param identifier Action/operation identifier.
     * @param sessionContext Current Bicnet session context.
     * @param ids Identifiers of managed objects affected by the operation.
     * @return True of the operation should proceed.
     */
    private boolean callIsAllowed(
            Logger logger, ISecurityMgrFacade security, SecureAction identifier,
            ISessionContext sessionContext, IManagedObjectId[] ids) {
        boolean allowed = false;
        try {
            final ISecureServerSession serverSession = security.getServerSession(sessionContext);
            if (null == ids || ids instanceof IEMId[]) {
                allowed = serverSession.checkOperationPermission(identifier.getIdentifier());
            } else {
                final IManagedObjectId[] allowedObjects = serverSession.checkOperationPermission(identifier.getIdentifier(), ids);
                allowed = null != allowedObjects && allowedObjects.length == ids.length;
                if (!allowed) {
                    logger.warn("Security issue: number of allowed objects is not equal to original objects.");
                }
            }
        } catch (final BcbException e) {
            logger.error("An error has occurred while validating permissions.", e);
        }
        return allowed;
    }

    private ISecurityMgrFacade getSecurityManager() throws BcbException {
        try {
            return securityManager.get();
        } catch (final ConcurrentException e) {
            // An error occurred during Security Manager instance initialization.
            throw new BcbException(e);
        }
    }

    /**
     * Given the set of method arguments and their annotations, find the managed
     * object IDs affected by the operation. These must be a method parameter
     * containing a single instance or an array of a type derived from
     * {@link IManagedObjectId} and annotated with {@link SecuredObject}.
     *
     * @param arguments Method call arguments, in declaration order.
     * @param argumentAnnotations Annotations applied to the arguments, in the same order.
     * @return An array of managed objects, or null if none were found.
     */
    private IManagedObjectId[] getSecuredObjects(Object[] arguments, Annotation[][] argumentAnnotations) {
        /*
         * We only support one secured object per call.
         * Either it is a single object or an array of objects.
         * In fact, facade calls require their identifiers to follow the same rule.
         */
        for (int i = 0; i < argumentAnnotations.length; i++) {
            if (isArgumentSecured(argumentAnnotations[i])) {
                final Object argument = arguments[i];
                if (argument instanceof IManagedObjectId) {
                    return new IManagedObjectId[] { (IManagedObjectId) argument };
                } else if (argument instanceof IManagedObjectId[]) {
                    return (IManagedObjectId[]) argument;
                }
            }
        }
        return null;
    }

    /**
     * @param annotations Annotations to verify.
     * @return True if the annotations array contains an instance of {@link SecuredObject}.
     */
    private boolean isArgumentSecured(Annotation[] annotations) {
        for (final Annotation annotation : annotations) {
            if (SecuredObject.class.isAssignableFrom(annotation.annotationType())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Used to initialize the aspect by setting the proper instance of BicnetServiceManager.
     * @param serviceManager The new Bicnet Service Manager instance to use.
     */
    public void setServiceManager(BicnetServiceManagerFactory serviceManager) {
        this.serviceManager = serviceManager;
        this.securityManager = new SecurityMgrFacadeInitializer();
    }
}
