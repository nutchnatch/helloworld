package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.google.common.base.Throwables;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.apache.commons.lang3.tuple.Triple;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Collections;
import java.util.function.Function;

import static org.slf4j.LoggerFactory.getLogger;

public final class PairMediatorWithTypeAndInstances implements
        Function<MediatorEntity, Triple<MediatorType, MediatorEntity, Iterable<MediatorInstance>>> {

    private static final Logger LOGGER = getLogger(PairMediatorWithTypeAndInstances.class);

    private final StaticConfiguration configuration;
    private final MediatorInstanceEntityRepository instanceRepository;

    public PairMediatorWithTypeAndInstances(@Nonnull StaticConfiguration configuration, @Nonnull MediatorInstanceEntityRepository instanceRepository) {
        this.configuration = configuration;
        this.instanceRepository = instanceRepository;
    }

    public static Triple<MediatorType, MediatorEntity, Iterable<MediatorInstance>> triple(
            StaticConfiguration configuration, @Nullable MediatorEntity mediator, @Nullable Iterable<MediatorInstance> instances) {
        return null == mediator
                ? null
                : Triple.of(
                        configuration.getMediatorTypes().get(mediator.getInfo().getTypeName()),
                        mediator,
                        instances != null ? instances : Collections.<MediatorInstance>emptyList());
    }

    private Iterable<MediatorInstance> getInstances(int mediatorId) {
        try {
            return instanceRepository.queryAll(mediatorId);
        } catch (final RepositoryException e) {
            LOGGER.warn("Failed to obtain mediator instances, returning empty list. {}", Throwables.getStackTraceAsString(e));
            return Collections.emptyList();
        }
    }

    @Override
    public Triple<MediatorType, MediatorEntity, Iterable<MediatorInstance>> apply(MediatorEntity mediator) {
        return triple(configuration, mediator, getInstances(mediator.getInfo().getId()));
    }
}