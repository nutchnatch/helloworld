package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationState;
import com.ossnms.dcn_manager.bicnet.connector.storage.InMemoryNeSyncStateRepository;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import org.apache.commons.lang3.tuple.Triple;

import javax.annotation.Nullable;
import java.util.Optional;
import java.util.function.Function;

public final class TripleNeWithType implements
        Function<NeEntity, Triple<NeType, Optional<ScsSynchronizationState>, NeEntity>> {

    private final StaticConfiguration configuration;
    private final InMemoryNeSyncStateRepository syncStateRepository;

    public TripleNeWithType(StaticConfiguration configuration, InMemoryNeSyncStateRepository syncStateRepository) {
        this.configuration = configuration;
        this.syncStateRepository = syncStateRepository;
    }

    public static Triple<NeType, Optional<ScsSynchronizationState>, NeEntity> triple(StaticConfiguration configuration,
            InMemoryNeSyncStateRepository syncStateRepository, @Nullable NeEntity ne) {
        return null == ne
                ? null
                : Triple.of(configuration.getNeTypes().get(ne.getInfo().getProxyType()),
                syncStateRepository.query(ne.getInfo().getId()), ne);
    }

    @Override
    public Triple<NeType, Optional<ScsSynchronizationState>, NeEntity> apply(NeEntity ne) {
        return triple(configuration, syncStateRepository, ne);
    }
}