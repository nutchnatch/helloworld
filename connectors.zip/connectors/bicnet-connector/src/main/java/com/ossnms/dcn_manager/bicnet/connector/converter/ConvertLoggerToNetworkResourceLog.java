package com.ossnms.dcn_manager.bicnet.connector.converter;

import java.util.Date;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.google.common.base.Function;
import com.ossnms.bicnet.bcb.facade.logMgmt.LogIdItem;
import com.ossnms.bicnet.bcb.facade.logMgmt.NeResourceEventLogRecordItem;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogId;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecord;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;

/**
 * Converts {@link LoggerItemNe} to BCB {@link NeResourceEventLogRecordItem}
 */
public class ConvertLoggerToNetworkResourceLog implements Function<LoggerItemNe, ILogRecord> {

    protected static final ILogId LOG_RESOURCE_ID = new LogIdItem("Network Resource Log");

    private final String userName;

    public ConvertLoggerToNetworkResourceLog(@Nullable String userName) {
        super();
        this.userName = userName;
    }

    public NeResourceEventLogRecordItem convert(@Nonnull final LoggerItemNe input) {
        final NeResourceEventLogRecordItem logRecord = new NeResourceEventLogRecordItem();

        logRecord.setBelonging(LOG_RESOURCE_ID);
        logRecord.setBelongingName(LOG_RESOURCE_ID.getName());

        logRecord.setTimeStamp(new Date());

        final String affectedObject = input.getAffectedObject();
        logRecord.setAffectedNeName(affectedObject);
        logRecord.setAffectedObject(affectedObject);

        logRecord.setAffectedNe(input.getAffectedObjectId());

        logRecord.setUserName(userName);
        logRecord.setDescription(input.getMessage());
        logRecord.setProjectId("");

        return logRecord;
    }

    /**
     * @see Function#apply(Object)
     */
    @Override
    public ILogRecord apply(@Nullable LoggerItemNe input) {
        return input == null ? null : convert(input);
    }
}
