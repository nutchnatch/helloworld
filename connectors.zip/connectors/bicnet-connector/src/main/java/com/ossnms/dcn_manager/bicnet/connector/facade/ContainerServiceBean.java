package com.ossnms.dcn_manager.bicnet.connector.facade;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ContainerService;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.ContainerHelper;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import java.util.Collection;

/**
 * The bean implementation simply forwards the call to the inner POJO.
 * Once in the public facade, this will be necessary to compose an enormous public
 * interface from a more manageable set of classes.
 */
@Stateless(name = "ContainerServiceBean")
@Local(ContainerService.class)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class ContainerServiceBean implements ContainerService {

    @Inject
    private ContainerHelper helper;

    @Override
    public IGenericContainer getSingleGenericContainer(final ISessionContext sessionContext,
            final IGenericContainerId containerContainerId) throws BcbException {
        return helper.getSingleGenericContainer(sessionContext, containerContainerId);
    }

    @Override
    public GenericContainerReply getGenericContainerList(final ISessionContext sessionContext,
            final IGenericContainerId startAfter, final IGenericContainerMarkable[] filter, final int howMany)
                    throws BcbException {
        return helper.getGenericContainerList(sessionContext, startAfter, filter, howMany);
    }

    @Override
    public GenericContainerIdReply getGenericContainerIdList(final ISessionContext sessionContext,
            final IGenericContainerId startAfter, final IGenericContainerMarkable[] filter, final int howMany)
                    throws BcbException {
        return helper.getGenericContainerIdList(sessionContext, startAfter, filter, howMany);
    }

    @Override
    public IGenericContainer createGenericContainer(final ISessionContext sessionContext, final IGenericContainer container)
            throws BcbException {
        return helper.createGenericContainer(sessionContext, container);
    }

    @Override
    public void deleteGenericContainer(final ISessionContext sessionContext,
            final IGenericContainerId containerContainerId) throws BcbException {
        helper.deleteGenericContainer(sessionContext, containerContainerId);
    }

    @Override
    public IGenericContainerMarkable modifyGenericContainer(final ISessionContext sessionContext,
            final IGenericContainerMarkable container) throws BcbException {
        return helper.modifyGenericContainer(sessionContext, container);
    }

    @Override
    public IGenericContainerMarkable[] modifyGenericContainers(final ISessionContext sessionContext,
            final IGenericContainerMarkable[] containerContainers) throws BcbException {
        return helper.modifyGenericContainers(sessionContext, containerContainers);
    }

    @Override
    public void deleteGenericContainers(final ISessionContext sessionContext,
            final Iterable<IGenericContainerId> genericContainerIds) throws BcbException {
        for (final IGenericContainerId containerId : genericContainerIds) {
            deleteGenericContainer(sessionContext, containerId);
        }
    }

    @Override
    public Collection<INeGenericContainerAssignment> getNeContainerAssignments(ISessionContext sessionContext) throws BcbException {
        return helper.getNeContainerAssignments(sessionContext);
    }

    @Override
    public Collection<ISystemGenericContainerAssignment> getSystemContainerAssignments(ISessionContext sessionContext) throws BcbException {
        return helper.getSystemContainerAssignments(sessionContext);
    }

    @Override
    public void moveToContainer(ISessionContext sessionContext, Collection<IGenericContainerId> containers, IGenericContainerId containerId) throws BcbException {
        helper.moveToContainer(sessionContext, containers, containerId);
    }
}
