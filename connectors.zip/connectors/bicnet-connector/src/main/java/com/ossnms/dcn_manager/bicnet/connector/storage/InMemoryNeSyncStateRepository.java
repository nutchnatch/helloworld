package com.ossnms.dcn_manager.bicnet.connector.storage;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationState;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * An in-memory implementation of a repository dedicated to storing the SCS Synchronization
 * State of Network Elements.
 */
public class InMemoryNeSyncStateRepository {

    private final Map<Integer, ScsSynchronizationState> neSyncStateRepo = new ConcurrentHashMap<>();

    /**
     * @return The entire collection of known SCS synchronization states.
     */
    public Iterable<ScsSynchronizationState> queryAll() {
        return ImmutableList.copyOf(neSyncStateRepo.values());
    }

    /**
     * Attempts to find the latest known SCS synchronization state for a specific NE.
     * @param neId NE identifier.
     * @return The latest known SCS synchronization state for the NE, if known.
     */
    public Optional<ScsSynchronizationState> query(int neId) {
        return Optional.ofNullable(neSyncStateRepo.get(neId));
    }

    /**
     * Updates the latest known SCS synchronization state for a specific NE.
     * @param state New SCS synchronizations state for an NE.
     * @return The updated state, if the update succeeded.
     */
    public Optional<ScsSynchronizationState> tryUpdate(@Nonnull ScsSynchronizationState state) {
        neSyncStateRepo.put(state.getNeId(), state);
        return Optional.of(state);
    }
}
