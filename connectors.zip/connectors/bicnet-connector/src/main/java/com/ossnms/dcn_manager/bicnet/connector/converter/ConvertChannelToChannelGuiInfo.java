package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.stream.StreamSupport;

/**
 * Handles conversion of internal domain entities representing a Channel to its
 * corresponding type containing only GUI information.
 */
public final class ConvertChannelToChannelGuiInfo {

    private ConvertChannelToChannelGuiInfo() {
    }

    /**
     * Builds an instance of {@link ChannelInfo} containing GUI information.
     * @param channel Channel entity.
     * @param instances Physical channel connections.
     * @return An instance of {@link ChannelInfo} containing GUI information.
     */
    public static ChannelInfo build(@Nonnull ChannelEntity channel, Iterable<ChannelPhysicalConnectionData> instances) {
        final Optional<ActualActivationState> standbyActualActivationState = findStandbyActualActivationState(instances);
        return new ChannelInfo(channel.getInfo().getId())
                .setGuiActualActivationState(convert(channel.getConnectionState().getActualActivationState()))
                .setUserText(channel.getUserPreferences().getUserText().orElse(null))
                .setGuiStandbyActualActivationState(standbyActualActivationState.map(ConvertChannelToChannelGuiInfo::convert).orElse(null))
                .setStandbyDisplayState(standbyActualActivationState.map(ConvertChannelToBcb::getActivationStateMessage).orElse(StringUtils.EMPTY));
    }

    private static Optional<ActualActivationState> findStandbyActualActivationState(Iterable<ChannelPhysicalConnectionData> instances) {
        return StreamSupport.stream(instances.spliterator(), false)
            .filter(instance -> !instance.isActive())
            .findFirst()
            .map(ChannelPhysicalConnectionData::getActualActivationState);
    }

    /**
     * Given the current connection state, obtain the corresponding state for displaying in the GUI.
     */
    public static GuiActualActivationState convert(@Nonnull final ActualActivationState activationState) {
        switch (activationState) {
            case ACTIVE:
                return GuiActualActivationState.ACTIVE;
            case STARTINGUP:
            case ACTIVATING:
            case CREATING:
                return GuiActualActivationState.ACTIVATING;
            case INACTIVE:
                return GuiActualActivationState.INACTIVE;
            case SHUTTINGDOWN:
            case DEACTIVATING:
                return GuiActualActivationState.DEACTIVATING;
            case FAILED:
                return GuiActualActivationState.FAILED;
            default:
                throw new IllegalStateException("Actual activation state without description: " + activationState);
        }
    }
}
