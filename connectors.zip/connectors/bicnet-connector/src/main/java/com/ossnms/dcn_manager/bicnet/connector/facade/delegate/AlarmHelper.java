package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmReply;
import com.ossnms.bicnet.bcb.facade.faultMgmt.IAlarmFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.TrafficDirection;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmMaskConfiguration;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmId;

public class AlarmHelper implements IAlarmFacade{

    /**
     * {@inheritDoc}
     */
    @Override
    public AlarmReply getAlarmList(ISessionContext sessionContext, IAlarmId startAfter, IManagedObjectId[] filter, int howMany) throws BcbException {
        // FIXME Auto-generated method stub
        return new AlarmReply(new AlarmItem[0], true, null);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void enableAlarms(ISessionContext sessionContext, IManagedObjectId[] filter, AlarmMaskConfiguration alarmMaskConf, TrafficDirection trafficDirection, boolean immediatelyReport) {
        throw new UnsupportedOperationException();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void disableAlarms(ISessionContext sessionContext, IManagedObjectId[] filter, AlarmMaskConfiguration alarmMaskConf, TrafficDirection trafficDirection)
            throws BcbException {
        throw new UnsupportedOperationException();
    }
}
