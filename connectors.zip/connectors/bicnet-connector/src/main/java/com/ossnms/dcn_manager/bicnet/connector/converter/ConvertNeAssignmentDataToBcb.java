package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.google.common.base.Function;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NeGenericContainerAssignmentItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;

import javax.annotation.Nonnull;

public class ConvertNeAssignmentDataToBcb implements Function<NeAssignmentData, INeGenericContainerAssignment> {

    @Override public INeGenericContainerAssignment apply(NeAssignmentData input) {
        return convert(input);
    }

    public static INeGenericContainerAssignment convert(NeAssignmentData input) {
        INeGenericContainerAssignment assignment = new NeGenericContainerAssignmentItem();

        assignment.setGenericContainer(new GenericContainerIdItem(input.getContainerInfo().getId()));
        assignment.setNetworkElement(new NEIdItem(input.getNeId()));
        assignment.setPrimary(input.getAssignmentType().toFlag());

        return assignment;
    }

    public static INeGenericContainerAssignment convert(final int neId, final int containerId, @Nonnull final AssignmentType assignmentType) {
        INeGenericContainerAssignment assignment = new NeGenericContainerAssignmentItem();

        assignment.setGenericContainer(new GenericContainerIdItem(containerId));
        assignment.setNetworkElement(new NEIdItem(neId));
        assignment.setPrimary(assignmentType.toFlag());

        return assignment;
    }
}
