package com.ossnms.dcn_manager.bicnet.connector.messaging;

import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementDomainAssignment;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementDomainAssignmentId;
import com.ossnms.bicnet.bcb.model.platform.IdentifierChange;
import com.ossnms.bicnet.bcb.model.platform.ObjectCreation;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.events.domain.DomainAdded;
import com.ossnms.dcn_manager.core.events.domain.DomainEvent;
import com.ossnms.dcn_manager.core.events.domain.DomainRemoved;
import com.ossnms.dcn_manager.core.events.domain.DomainRenamed;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import rx.Observable;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Optional;

import static com.google.common.base.Throwables.getStackTraceAsString;
import static com.ossnms.dcn_manager.bicnet.connector.messaging.ObservableTools.when;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Filtering, preprocessing and transformation of events relating to Domains.
 */
@ApplicationScoped
public class DomainEventSource implements EventSource<DomainEvent> {

    private static final Logger LOGGER = getLogger(DomainEventSource.class);

    private Observable<DomainEvent> events;

    @Inject @DcnManager
    private DomainRepository domainRepository;

    @Override
    public void subscribe(Observable<DecoratedNotification> notificationSource) {

        events = notificationSource
                .lift(when(this::isNetworkDomainRenamed).map(this::mapToDomainRenamedEvent))
                .lift(when(this::isNetworkDomainAdded).map(this::mapToDomainAddedEvent))
                .lift(when(this::isNetworkDomainRemoved).map(this::mapToDomainRemovedEvent))
                .ofType(DomainEvent.class);

    }

    @Override
    public Observable<DomainEvent> observe() {
        return events;
    }

    /*
     * Note that all predicates and transformation functions below handle the source object not as a DecoratedNotification
     * but rather as an Object. This is because we're lifting operators against the Observable that declare that they emit
     * objects of a different type.
     *
     * To continue processing regardless of the actual type of the object traveling on the Observable, we need to treat them
     * as Objects.
     *
     * The transformation functions also cast this argument blindly to a DecoratedNotification. They rely on the existence
     * of a predicate before them that guards their execution against objects that are not notifications.
     */

    private boolean isNetworkDomainRenamed(Object n) {
        return n instanceof DecoratedNotification &&
                ((DecoratedNotification) n).getNotification(IdentifierChange.class)
                        .map(idChange -> idChange.getOldId() instanceof INetworkElementDomainAssignmentId)
                        .orElse(false);
    }

    private boolean isNetworkDomainAdded(Object n) {
        return n instanceof DecoratedNotification &&
                ((DecoratedNotification) n).getNotification(ObjectCreation.class)
                        .map(creation -> creation.getCreatedObject() instanceof  INetworkElementDomainAssignment)
                        .orElse(false);
    }

    private boolean isNetworkDomainRemoved(Object n) {
        return n instanceof DecoratedNotification &&
                ((DecoratedNotification) n).getNotification(ObjectDeletion.class)
                        .map(deletion -> deletion.getDeletedObject() instanceof INetworkElementDomainAssignmentId)
                        .orElse(false);
    }

    private DomainRenamed mapToDomainRenamedEvent(Object decoratedNotification) {
        final IdentifierChange notification =
                ((DecoratedNotification) decoratedNotification).getNotification(IdentifierChange.class).get();
        final INetworkElementDomainAssignmentId oldId =
                (INetworkElementDomainAssignmentId) notification.getOldId();
        final INetworkElementDomainAssignmentId newId =
                (INetworkElementDomainAssignmentId) notification.getNewId();
        return getDomain(oldId.getDomainName())
                .map(domain -> new DomainRenamed(domain.getId(), newId.getDomainName()))
                .orElse(null);
    }

    private DomainAdded mapToDomainAddedEvent(Object decoratedNotification) {
        final ObjectCreation notification =
                ((DecoratedNotification) decoratedNotification).getNotification(ObjectCreation.class).get();
        final INetworkElementDomainAssignment newDomain =
                (INetworkElementDomainAssignment) notification.getCreatedObject();
        return new DomainAdded(newDomain.getNeId(), newDomain.getDomainName());
    }

    private DomainRemoved mapToDomainRemovedEvent(Object decoratedNotification) {
        final ObjectDeletion notification =
                ((DecoratedNotification) decoratedNotification).getNotification(ObjectDeletion.class).get();
        final INetworkElementDomainAssignmentId oldDomainId =
                (INetworkElementDomainAssignmentId) notification.getDeletedObject();
        return getDomain(oldDomainId.getDomainName())
                .map(domain -> new DomainRemoved(oldDomainId.getNeId(), domain.getId(), oldDomainId.getDomainName()))
                .orElse(null);
    }

    private Optional<DomainInfoData> getDomain(String domainName) {
        try {
            return domainRepository.queryByName(domainName);
        } catch (RepositoryException e) {
            LOGGER.warn("Could not query for domain '{}': {}", domainName, getStackTraceAsString(e));
            return Optional.empty();
        }
    }
}
