package com.ossnms.dcn_manager.bicnet.connector.policies;


import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.factory.Metrics;
import com.ossnms.dcn_manager.composables.metrics.PartitionedJobMetrics;
import com.ossnms.dcn_manager.composables.metrics.SystemJobMetrics;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent;
import com.ossnms.dcn_manager.core.events.ne.IdentifiedNeEvent;
import com.ossnms.dcn_manager.core.events.ne.NeSynchronizationEvent;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;
import com.ossnms.dcn_manager.core.policies.*;
import com.ossnms.dcn_manager.core.policies.common.ObservableExecutor;
import com.ossnms.dcn_manager.core.policies.common.PolicyJob;
import com.ossnms.dcn_manager.core.policies.impl.NetworkElementInteractionManagerImpl;
import com.ossnms.dcn_manager.core.policies.impl.NetworkElementInteractionManagerMediationStage;
import com.ossnms.dcn_manager.core.policies.impl.NetworkElementInteractionManagerSystemStage;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Iterator;
import java.util.Optional;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;
import java.util.function.Predicate;


import static org.slf4j.LoggerFactory.getLogger;

/**
 * Class that implements the connector responsible for binding the implementation of the NE interaction policy
 * (i.e. {@link NetworkElementInteractionManager) to the technological stack whose existence is presumed by this
 * connector (i.e. JBoss EJB container).
 *
 * Design decisions:
 * <ul>
 * <li> The implementation relies on delegation, instead of using inheritance, as depicted in the class diagram.
 * The goal is to segregate technology specific requirements (e.g. life-cycle management services that require
 * the use of proxies, and therefore a no-argument constructor) from the requirements pertaining to the problem
 * domain. </li>
 * <li> Because application scope is used, the class implementation is thread-safe by resorting to immutable state
 * and delegation: the field {@link #delegate} is final and the referenced object is thread-safe.
 * </ul>
 *
 * <p> <figure>
 * <img src="doc-files/ne_connection_scheduler_connector-class.png">
 * <figcaption>Class diagram of the implementation of the connector for NE interaction policy</figcaption>
 * </figure> </p>
 */
/*
 * @startuml doc-files/ne_connection_scheduler_connector-class.png

 * package emne.core.policies {
 *      interface NetworkElementInteractionManager {
 *          + scheduleActivation(ActivateNeEvent)
 *          + scheduleDeactivation(DeactivateNeEvent)
 *          + onMediatorInteractionEnded(ActualNeStateEvent)
 *          + getPendingJobCount() : int
 *          + getOngoingJobCount() : int
 *          + getMaxOngoingJobCount() : int
 *          + getPendingJobCount(channelId : int) : int
 *          + getOngoingJobCount(channelId : int) : int
 *          + getMaxOngoingJobCount(channelId : int) : int
 *          + setMaxOngoingJobCount(channelId : int, newMax : int)
 *      }
 *      package emne.core.policies.impl {
 *          class NetworkElementInteractionManagerImpl
 *      }
 * }
 * package emne.connector.jboss.policies {
 *      class NetworkElementConnectionSchedulerImpl << ApplicationScoped >>
 * }
 * NetworkElementInteractionManager <|.. NetworkElementConnectionSchedulerImpl
 * NetworkElementInteractionManager <|.. NetworkElementInteractionManagerImpl
 * NetworkElementConnectionSchedulerImpl *- NetworkElementInteractionManagerImpl : delegate
 * hide NetworkElementConnectionSchedulerImpl members
 * hide NetworkElementInteractionManagerImpl members
 * @enduml
 */
@ApplicationScoped
@DcnManager
public class NetworkElementConnectionSchedulerImpl
        implements NetworkElementInteractionManager,
            ChannelSchedulingConfiguration, MediatorSchedulingConfiguration, SystemSchedulingConfiguration {

    private static final Logger LOGGER = getLogger(NetworkElementConnectionSchedulerImpl.class);
    public static final String NE_INTERACTIONS = "ne-interactions";

    /** Holds the actual policy implementation. */
    private final NetworkElementInteractionManagerImpl delegate;
    private final NetworkElementInteractionManagerSystemStage systemStage;
    private final NetworkElementInteractionManagerMediationStage mediationStage;

    /** The default value for maximum allowed simultaneous interactions. */
    private static final int DEFAULT_MAX_ONGOING = 5;

    /** The executor instance to be used to schedule request servicing execution. */
    private Executor executionPolicy;

    /**
     * Initiates an instance with the required dependencies.
     * @param executionPolicy The executor instance to be used to schedule request servicing execution.
     * @param threadFactory The thread factory for supporting the fallback execution policy for high priority jobs.
     * @param connectionManager The instance used to interact with the solution's Connection Manager
     * (i.e. the out-bound abstraction).
     * @param metrics Used to publish metrics about request servicing.
     */
    @Inject
    public NetworkElementConnectionSchedulerImpl(
            @DcnManager ObservableExecutor executionPolicy,
            @DcnManager ThreadFactory threadFactory,
            NeConnectionManager connectionManager,
            Metrics metrics) {
        this.executionPolicy = executionPolicy;
        this.systemStage = new NetworkElementInteractionManagerSystemStage(
                DEFAULT_MAX_ONGOING, executionPolicy, threadFactory, this::getWorkForSystemStage);
        this.mediationStage = new NetworkElementInteractionManagerMediationStage(
                DEFAULT_MAX_ONGOING, systemStage, this::getWorkForMediationStage);
        this.delegate = new NetworkElementInteractionManagerImpl(
                DEFAULT_MAX_ONGOING,
                new NetworkElementInteractionManagerStage[] { mediationStage, systemStage },
                connectionManager);

        metrics.registerMetric(new SystemJobMetrics(this.systemStage, "System"),
                ImmutableMap.of("type", NE_INTERACTIONS, "a","SystemJobMetrics"));

        metrics.registerMetric(new PartitionedJobMetrics(this.mediationStage, "Mediations"),
                ImmutableMap.of("type", NE_INTERACTIONS, "a","MediationJobMetrics"));

        metrics.registerMetric(new PartitionedJobMetrics(this.delegate, "Channels"),
                ImmutableMap.of("type", NE_INTERACTIONS, "a","ChannelJobMetrics"));

    }

    private Optional<PolicyJob<? extends IdentifiedNeEvent>> getWorkForMediationStage(
            Predicate<PolicyJob<? extends IdentifiedNeEvent>> selector) {
        return delegate.getRetainedWorkForExecution(selector);
    }

    private Optional<PolicyJob<? extends IdentifiedNeEvent>> getWorkForSystemStage(
            Predicate<PolicyJob<? extends IdentifiedNeEvent>> selector) {
        return mediationStage.getRetainedWorkForExecution(selector);
    }


    /** Default constructor to make the class proxyable by Jboss. */
    protected NetworkElementConnectionSchedulerImpl() {
        // Proxies do not make use of the types' fields.
        delegate = null;
        systemStage = null;
        mediationStage = null;
        executionPolicy = null;
    }

    /** {@inheritDoc} */
    @Override
    public void scheduleActivation(@Nonnull final RequiredNeStateEvent.Activate event) {
        delegate.scheduleActivation(event);
    }

    /** {@inheritDoc} */
    @Override
    public void scheduleDeactivation(@Nonnull final RequiredNeStateEvent.Deactivate event) {
        delegate.scheduleDeactivation(event);
    }

    /** {@inheritDoc} */
    @Override
    public void scheduleSynchronization(@Nonnull final NeSynchronizationEvent event) {
        delegate.scheduleSynchronization(event);
    }

    /** {@inheritDoc} */
    @Override
    public void onNeInteractionEnded(@Nonnull final ActualNeStateEvent event) {
        delegate.onNeInteractionEnded(event);
    }

    /** {@inheritDoc} */
    @Override
    public void onNeConnected(@Nonnull NeSynchronizationEvent event) {
        delegate.onNeConnected(event);
    }

    /** {@inheritDoc} */
    @Override
    public void onNePropertiesUpdated(
            @Nonnull NeEntity ne, @Nonnull NePhysicalConnectionData neInstance,
            @Nonnull NeUserPreferencesMutationDescriptor newPreferences) {
        try {
            // try to schedule this update asynchronously.
            executionPolicy.execute(() -> delegate.onNePropertiesUpdated(ne, neInstance, newPreferences));
        } catch (RejectedExecutionException e) {
            // worst case scenario: the executor pool is full, so hijack the current thread.
            LOGGER.warn("Could not run NE property update on mediator asynchronously, running inline: {}",
                    e.getMessage());
            delegate.onNePropertiesUpdated(ne, neInstance, newPreferences);
        }
    }

    /** {@inheritDoc} */
    @Override
    public void cancelDeactivations(@Nonnull final RequiredNeStateEvent event) {
        delegate.cancelDeactivations(event);
    }

    /** {@inheritDoc} */
    @Override
    public void cancelActivations(@Nonnull final RequiredNeStateEvent event) {
        delegate.cancelActivations(event);
    }

    /** {@inheritDoc} */
    @Override
    public void cancelSynchronizations(@Nonnull final NeSynchronizationEvent event) {
        delegate.cancelSynchronizations(event);
    }

    @Override
    public Iterator<NetworkElementInteractionManagerStage> iterator() {
        return delegate.iterator();
    }

    @Override
    public int getPendingChannelJobCount() {
        return delegate.getPendingJobCount();
    }

    @Override
    public int getOngoingChannelJobCount() {
        return delegate.getOngoingJobCount();
    }

    @Override
    public void setMaxOngoingChannelJobCount(final int channelId, final int maximumOngoingJobCount) {
        LOGGER.info("Changing maximum ongoing channel {} job count to {}.", channelId, maximumOngoingJobCount);
        delegate.setMaxOngoingJobCount(channelId, maximumOngoingJobCount);
    }

    @Override
    public void onChannelRemoved(final int channelId) {
        LOGGER.info("Removing channel {} from scheduler.", channelId);
        delegate.removePartition(channelId);
    }

    @Override
    public int getPendingMediatorJobCount() {
        return mediationStage.getPendingJobCount();
    }

    @Override
    public int getOngoingMediatorJobCount() {
        return mediationStage.getOngoingJobCount();
    }

    @Override
    public void setMaxOngoingMediatorJobCount(final int mediatorId, final int maximumOngoingJobCount) {
        LOGGER.info("Changing maximum ongoing mediator {} job count to {}.", mediatorId, maximumOngoingJobCount);
        mediationStage.setMaxOngoingJobCount(mediatorId, maximumOngoingJobCount);
    }

    @Override
    public void onMediatorRemoved(final int mediatorId) {
        LOGGER.info("Removing mediator {} from scheduler.", mediatorId);
        mediationStage.removePartition(mediatorId);
    }

    @Override
    public int getPendingSystemJobCount() {
        return systemStage.getPendingJobCount();
    }

    @Override
    public int getOngoingSystemJobCount() {
        return systemStage.getOngoingJobCount();
    }

    @Override
    public void setMaxOngoingSystemJobCount(int maximumOngoingJobCount) {
        LOGGER.info("Changing maximum ongoing system job count to {}.", maximumOngoingJobCount);
        systemStage.setMaxOngoingJobCount(maximumOngoingJobCount);
    }
}
