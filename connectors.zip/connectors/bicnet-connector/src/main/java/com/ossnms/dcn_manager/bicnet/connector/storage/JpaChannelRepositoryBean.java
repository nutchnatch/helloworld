package com.ossnms.dcn_manager.bicnet.connector.storage;

import com.google.common.base.Function;
import com.google.common.base.Supplier;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaCloseableQuery;
import com.ossnms.dcn_manager.connector.storage.channel.ChannelRepository;
import com.ossnms.dcn_manager.connector.storage.channel.entities.ChannelEntityDb;
import com.ossnms.dcn_manager.connector.storage.channel.entities.QChannelEntityDb;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Optional;

/**
 * EJB that maintains an instance of a Channel repository.
 */
@DcnManager
@ApplicationScoped
public class JpaChannelRepositoryBean extends ChannelRepository {

    private static final Logger LOGGER = LoggerFactory.getLogger(JpaChannelRepositoryBean.class);

    @Inject
    private JpaRepositoryBean repositoryBean;

    @PostConstruct
    public void initialize() {
        final Supplier<CloseableEntityTransaction> transactionSupplier = repositoryBean.getTransactionSupplier();
        initialize(transactionSupplier);
    }

    @Override
    protected CloseableEntityTransaction getTransaction() {
        return repositoryBean.getTransactionSupplier().get();
    }

    public JpaCloseableQuery query(QChannelEntityDb path) {
        return new JpaCloseableQuery(repositoryBean.getManagerSupplier().get(), path);
    }

    public Function<ChannelEntityDb, Optional<ChannelEntity>> getEntityTransformer() {
        return entityTransformer;
    }

    private final Function<ChannelEntityDb, Optional<ChannelEntity>> entityTransformer = input -> {
        try {
            return null != input ? fetchEntity(input) : Optional.empty();
        } catch (final RepositoryException e) {
            LOGGER.error("Error listing channel entities.", e);
            return Optional.empty();
        }
    };
}
