package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.google.common.base.Function;
import com.google.common.base.Predicates;
import com.google.common.base.Throwables;
import com.google.common.collect.Collections2;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.ImmutableSet;
import com.mysema.query.BooleanBuilder;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.INetworkDomainFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.INetworkDomainParticipationFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainParticipationItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainParticipationReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IASId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomain;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainParticipation;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainParticipationId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainParticipationMarkable;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertDomainToBcb;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaDomainRepositoryBean;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.commands.domain.GetDomains;
import com.ossnms.dcn_manager.commands.domain.GetDomainsForNe;
import com.ossnms.dcn_manager.commands.domain.GetSingleDomain;
import com.ossnms.dcn_manager.commands.domain.SetAutomaticNeActivationDomainPolicy;
import com.ossnms.dcn_manager.connector.jpa.JpaCloseableQuery;
import com.ossnms.dcn_manager.connector.storage.domain.entities.DomainInfoDb;
import com.ossnms.dcn_manager.connector.storage.domain.entities.QDomainInfoDb;
import com.ossnms.dcn_manager.connector.storage.domain.entities.QDomainNeMembershipDb;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import javax.persistence.PersistenceException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import static com.google.common.collect.Iterables.transform;
import static com.ossnms.dcn_manager.bicnet.connector.facade.util.Exceptions.logAndRethrowAsBcb;

public class DomainHelper implements INetworkDomainFacade, INetworkDomainParticipationFacade {

    private static final Logger LOGGER = LoggerFactory.getLogger(DomainHelper.class);

    @Inject @DcnManager
    private JpaDomainRepositoryBean domainRepository;
    @Inject
    private DomainNotifications domainNotifications;
    @Inject
    private LoggerManagerImpl loggerManager;

    @Inject
    private StaticConfiguration configuration;
    
    private NetworkElementManagers neManagers;
    
    private ChannelManagers channelManagers;
        
    @Inject
    public void setNeManagers(NetworkElementManagers neManagers) {
        this.neManagers = neManagers;
    }

    @Inject
    public void setChannelManagers(ChannelManagers channelManagers) {
        this.channelManagers = channelManagers;
    }

    /**
     * Gets All domains.
     *
     * @param sessionContext
     * @return An array of domain names.
     */
    public Iterable<IAS> getDomains(ISessionContext sessionContext) {
        Iterable<IAS> result;
        try {
            final Iterable<DomainInfoData> domains =
                new GetDomains<>(new BicnetCallContext(sessionContext), domainRepository)
                    .call();
            result = transform(domains, new ConvertDomainToBcb(domainRepository));
        } catch (final RepositoryException e) {
            LOGGER.error("Could not obtain domains: {}, {}", e.getMessage(),
                    Throwables.getStackTraceAsString(e));
            result = Collections.emptyList();
        }
        return result;
    }

    /**
     * Finds and returns the Domain with the given <code>asId</code>.
     * @param sessionContext the session context is passed as 1st parameter in every facade method.
     * @param asId the identifier of the requested Domain instance.
     */
    public IAS getDomain(ISessionContext sessionContext, IASId asId) throws BcbException {
        try {
            final Optional<DomainInfoData> domain =
                new GetSingleDomain<>(new BicnetCallContext(sessionContext), domainRepository, asId.getId())
                    .call();
            return domain.map(new ConvertDomainToBcb(domainRepository)::apply).orElse(null);
        } catch (final RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }


    /**
     * Gets All domains by NE.
     *
     * @param sessionContext
     * @param neId
     * @return An array of domain names.
     */
    public String[] getDomainList(ISessionContext sessionContext, INEId neId) {
        final Iterable<DomainInfoData> domains =
            new GetDomainsForNe<>(new BicnetCallContext(sessionContext), domainRepository, neId.getId()).call();
        return FluentIterable.from(domains)
                .transform(DomainInfoData::getName)
                .toArray(String.class);
    }

    /**
     * Gets the NEs which participates in domains.
     *
     * @param sessionContext
     * @param domainIdNames
     * @return An array of {@link INE} instances.
     */
    public INE[] getNesByDomain(ISessionContext sessionContext, String[] domainIdNames) {
        /*
         * Build a set of NE identifiers from the collection of domain names we received
         * in order to ensure that there are no duplicate INEs in the output (an NE may
         * belong to more than one domain).
         */
        final ImmutableSet<Integer> neIds = FluentIterable.from(Arrays.asList(domainIdNames))
            .transform(this::tryFetchDomainWithName)
            .filter(Optional::isPresent).transform(Optional::get)
            .transformAndConcat(this::getNeIdsForDomain)
            .toSet();

        return getNesAsArray(neIds);
    }

    private INE[] getNesAsArray(Iterable<Integer> neIds) {
        return FluentIterable.from(neIds)
            .transform(this::tryFetchNeEntity)
            .filter(Optional::isPresent)
            .transform(this::convertNeEntityToBcb)
            .filter(Predicates.notNull())
            .toArray(INE.class);
    }

    /**
     * Gets All NEs which belongs the same Domains.
     *
     * @param sessionContext
     * @param neId
     * @return
     */
    public INEId[] getAllNEsFromAllDomainsByNE(ISessionContext sessionContext, INEId neId) {
        final ImmutableSet<Integer> neIds = FluentIterable
            .from(domainRepository.queryAllForNE(neId.getId()))
            .transformAndConcat(this::getNeIdsForDomain)
            .toSet();
        return Collections2.transform(neIds, NEIdItem::new)
            .toArray(new INEId[neIds.size()]);
    }

    /**
     * Changes whether newly discovered NEs within a domain are activated automatically,
     * when the global discovery policy is set to Domain.
     *
     * @param sessionContext the session context is passed as 1st parameter in every facade method.
     * @param domainIds the identifier of the affected Domain instances.
     * @param allow whether newly discovered NEs within the domains are activated automatically.
     */
    public void setAutomaticNeActivationPolicy(ISessionContext sessionContext, IASId[] domainIds, boolean allow)
            throws BcbException {
        final FluentIterable<Integer> domainIdentifiers = FluentIterable
                .from(Arrays.asList(domainIds))
                .filter(Predicates.notNull())
                .transform(new Function<IASId, Integer>() {
                    @Override
                    public Integer apply(@Nonnull IASId input) {
                        return input.getId();
                    }
                });
        try {
            new SetAutomaticNeActivationDomainPolicy<>(new BicnetCallContext(sessionContext),
                    neManagers,
                    channelManagers,
                    domainRepository, domainNotifications, loggerManager,
                    domainIdentifiers, allow)
                .call();
        } catch (final CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public INetworkDomain getSingleNetworkDomain(ISessionContext sessionContext, INetworkDomainId networkDomainId) throws BcbException {
        try {
            final Optional<DomainInfoData> domain =
                new GetSingleDomain<>(new BicnetCallContext(sessionContext), domainRepository, networkDomainId.getId())
                    .call();
            return domain.map(this::buildBcbDomain).orElse(null);
        } catch (final RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public NetworkDomainReply getNetworkDomainList(ISessionContext sessionContext,
            INetworkDomainId startAfter, INetworkDomainMarkable[] filter, int howMany) throws BcbException {

        final QDomainInfoDb domain = QDomainInfoDb.domainInfoDb;
        try (final JpaCloseableQuery query = buildQueryExpression(startAfter, filter, howMany, domain)) {
            final INetworkDomain[] domains = FluentIterable.from(query.list(domain))
                    .filter(Predicates.notNull())
                    .transform(DomainInfoDb::build)
                    .transform(this::buildBcbDomain)
                    .toArray(INetworkDomain.class);
            return new NetworkDomainReply(domains, true, null);
        } catch (final PersistenceException | RepositoryException exception) {
            throw logAndRethrowAsBcb(exception, LOGGER);
        }
    }

    @Override
    public INetworkDomainId[] getNetworkDomainIdsForNE(ISessionContext sessionContext, INEId neId) throws BcbException {

        return FluentIterable.from(domainRepository.queryAllForNE(neId.getId()))
            .transform(i -> (INetworkDomainId) new NetworkDomainIdItem(i.getId()))
            .toArray(INetworkDomainId.class);
    }

    @Override
    public INetworkDomain[] getNetworkDomainsForNE(ISessionContext sessionContext, INEId neId) throws BcbException {

        return FluentIterable.from(domainRepository.queryAllForNE(neId.getId()))
            .transform(this::buildBcbDomain)
            .toArray(INetworkDomain.class);
    }

    @Override
    public INEId[] getNEIdsInNetworkDomain(ISessionContext sessionContext, INetworkDomainId networkDomainId) throws BcbException {

        return FluentIterable.from(domainRepository.queryChildrenNEs(networkDomainId.getId()))
                .transform(NEIdItem::new)
                .toArray(NEIdItem.class);
    }

    @Override
    public INE[] getNEsInNetworkDomain(ISessionContext sessionContext, INetworkDomainId networkDomainId) throws BcbException {

        return getNesAsArray(domainRepository.queryChildrenNEs(networkDomainId.getId()));
    }

    @Override
    public NetworkDomainParticipationReply getNetworkDomainParticipationList(
            ISessionContext sessionContext, INetworkDomainParticipationId startAfter,
            INetworkDomainParticipationMarkable[] filter, int howMany) throws BcbException {

        final QDomainNeMembershipDb membership = QDomainNeMembershipDb.domainNeMembershipDb;
        try (final JpaCloseableQuery query = buildQueryExpression(startAfter, filter, howMany, membership)) {
            final INetworkDomainParticipation[] participations = FluentIterable.from(query.list(membership))
                    .filter(Predicates.notNull())
                    .transform(db -> new NetworkDomainParticipationItem(null,
                            db.getAssociationKey().getDomain().getDomainId(),
                            db.getAssociationKey().getNeId()))
                    .toArray(NetworkDomainParticipationItem.class);
            return new NetworkDomainParticipationReply(participations, true, null);
        } catch (final PersistenceException | RepositoryException exception) {
            throw logAndRethrowAsBcb(exception, LOGGER);
        }
    }

    private JpaCloseableQuery buildQueryExpression(INetworkDomainId startAfter, INetworkDomainMarkable[] filter,
            int howMany, QDomainInfoDb domain) throws RepositoryException {
        final JpaCloseableQuery query = domainRepository.query(domain);
        final BooleanBuilder predicateBuilder = buildQueryPredicate(domain, filter);
        if (startAfter != null) {
            predicateBuilder.and(domain.domainId.goe(startAfter.getId()));
        }
        if (predicateBuilder.hasValue()) {
            query.where(predicateBuilder);
        }
        if (howMany > -1) {
            query.limit(howMany);
        }
        query.orderBy(domain.domainId.asc());
        return query;
    }

    private JpaCloseableQuery buildQueryExpression(INetworkDomainParticipationId startAfter, INetworkDomainParticipationMarkable[] filter,
            int howMany, QDomainNeMembershipDb membership) throws RepositoryException {
        final JpaCloseableQuery query = domainRepository.query(membership);
        final BooleanBuilder predicateBuilder = buildQueryPredicate(membership, filter);
        if (startAfter != null) {
            predicateBuilder.and(membership.associationKey.domain.domainId.goe(startAfter.getNetworkDomainIdId()));
        }
        if (predicateBuilder.hasValue()) {
            query.where(predicateBuilder);
        }
        if (howMany > -1) {
            query.limit(howMany);
        }
        query.orderBy(membership.associationKey.domain.domainId.asc());
        return query;
    }

    private BooleanBuilder buildQueryPredicate(QDomainInfoDb domain, final INetworkDomainMarkable[] filter)
            throws RepositoryException {
        final BooleanBuilder predicateBuilder = new BooleanBuilder();
        if (filter != null) {
            final BooleanBuilder filterBuilder = new BooleanBuilder();
            for (final INetworkDomainMarkable markable : filter) {
                LOGGER.debug("Filtering Domain listing with: {}", markable.toStringOnlyMarkedAttributes());
                final BooleanBuilder markablePredicateBuilder = new BooleanBuilder();
                if (markable.isMarkedId()) {
                    markablePredicateBuilder.and(domain.domainId.eq(markable.getId()));
                    markable.markId(false);
                }
                if (markable.isMarkedIdName()) {
                    markablePredicateBuilder.and(domain.domainName.eq(markable.getIdName()));
                    markable.markIdName(false);
                }
                if (markable.countMarks() > 0) {
                    throw new RepositoryException("Unsupported query parameters: {}", markable.toStringOnlyMarkedAttributes());
                }
                filterBuilder.or(markablePredicateBuilder);
            }
            if (filterBuilder.hasValue()) {
                predicateBuilder.and(filterBuilder);
            }
        }
        return predicateBuilder;
    }

    private BooleanBuilder buildQueryPredicate(QDomainNeMembershipDb membership, final INetworkDomainParticipationMarkable[] filter)
            throws RepositoryException {
        final BooleanBuilder predicateBuilder = new BooleanBuilder();
        if (filter != null) {
            final BooleanBuilder filterBuilder = new BooleanBuilder();
            for (final INetworkDomainParticipationMarkable markable : filter) {
                LOGGER.debug("Filtering Domain Participations listing with: {}", markable.toStringOnlyMarkedAttributes());
                final BooleanBuilder markablePredicateBuilder = new BooleanBuilder();
                if (markable.isMarkedNetworkDomainIdId()) {
                    markablePredicateBuilder.and(membership.associationKey.domain.domainId.eq(markable.getNetworkDomainIdId()));
                    markable.markNetworkDomainIdId(false);
                }
                if (markable.isMarkedNeIdId()) {
                    markablePredicateBuilder.and(membership.associationKey.neId.eq(markable.getNeIdId()));
                    markable.markNeIdId(false);
                }
                if (markable.countMarks() > 0) {
                    throw new RepositoryException("Unsupported query parameters: {}", markable.toStringOnlyMarkedAttributes());
                }
                filterBuilder.or(markablePredicateBuilder);
            }
            if (filterBuilder.hasValue()) {
                predicateBuilder.and(filterBuilder);
            }
        }
        return predicateBuilder;
    }

    private INetworkDomain buildBcbDomain(DomainInfoData domainInfo) {
        final INetworkDomain domain = new NetworkDomainItem();
        domain.setId(domainInfo.getId());
        domain.setIdName(domainInfo.getName());
        domain.setDiscoveryPermited(domainInfo.isAutomaticNeActivationPermitted());
        return domain;
    }

    private INE convertNeEntityToBcb(@Nonnull Optional<NeEntity> input) {
        if(input.isPresent()) {
            final NeEntity ne = input.get();
            final NeType neType = configuration.getNeTypes().get(ne.getInfo().getProxyType());
            if (null != neType) {
                return ConvertNeToBcb.convert(neType, ne, neManagers.getNeInstanceRepository().queryAll(ne.getInfo().getNeId()));
            }
        }
        return null;
    }

    private Optional<NeEntity> tryFetchNeEntity(@Nonnull Integer input) {
        try {
            return neManagers.getNeRepository().queryNe(input);
        } catch (final RepositoryException e) {
            LOGGER.error("Could not search for NE #{} on repository. {} {}", input,
                e.getMessage(), Throwables.getStackTraceAsString(e));
            return Optional.empty();
        }
    }

    private Iterable<Integer> getNeIdsForDomain(@Nonnull DomainInfoData input) {
        return domainRepository.queryChildrenNEs(input.getId());
    }

    private Optional<DomainInfoData> tryFetchDomainWithName(String input) {
        try {
            return null != input ? domainRepository.queryByName(input) : Optional.empty();
        } catch (final RepositoryException e) {
            LOGGER.error("Failed to obtain domain with name '{}': {} {}", input, e.getMessage(),
                    Throwables.getStackTraceAsString(e));
            return Optional.empty();
        }
    }

}
