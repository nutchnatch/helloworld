package com.ossnms.dcn_manager.bicnet.connector.converter;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.ossnms.dcn_manager.i18n.T.tr;

import java.util.Map;

import javax.annotation.Nonnull;

import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.dcn_manager.i18n.Message;

/**
 * Encapsulates the logic necessary to obtain a user-friendly message
 * from an instance of a BCB communication state.
 */
public final class ConvertCommunicationStateToString {

    private ConvertCommunicationStateToString() {

    }

    private static final Map<CommunicationState, String> DESCRIPTIONS =
        ImmutableMap.<CommunicationState, String>builder()
            .put(CommunicationState.CONNECTED, tr(Message.ACTIVE))
            .put(CommunicationState.CONNECTING, tr(Message.ACTIVATING))
            .put(CommunicationState.DISCONNECTED, tr(Message.INACTIVE))
            .put(CommunicationState.DISCONNECTING, tr(Message.DEACTIVATING))
            .put(CommunicationState.FAILED, tr(Message.FAILED))
            .build();

    /**
     * Obtains a user-friendly message from an instance of a BCB communication state.
     *
     * @param state BCB communication state.
     * @return A description for the communication state.
     * @throws NullPointerException If the state provided does not have a description.
     */
    public static String communicationStateToString(@Nonnull CommunicationState state) {
        final String description = DESCRIPTIONS.get(state);
        checkNotNull(description, "CommunicationState '%s' not localized", state);
        return description;
    }
}
