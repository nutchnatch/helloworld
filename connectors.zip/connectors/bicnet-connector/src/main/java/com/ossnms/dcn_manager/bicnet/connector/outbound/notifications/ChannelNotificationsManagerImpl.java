package com.ossnms.dcn_manager.bicnet.connector.outbound.notifications;

import com.google.common.base.Throwables;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMMarkable;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ChannelInfoNotification;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelDataCreateNotification;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertChannelToBcb;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertChannelToFullChannel;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.factory.SystemContext;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.composables.outbound.SecurityManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelCreatingEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelDeactivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelShuttingDownEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelStartingUpEvent;
import com.ossnms.dcn_manager.core.events.channel.ChannelEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertCommunicationStateToString.communicationStateToString;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Implements the bridge between our core and the BiCNet notifications service.
 * Handles only notifications about changes to the state of Channels.
 */
@ApplicationScoped
public class ChannelNotificationsManagerImpl
        extends NotificationsManagerBase<ChannelEvent>
        implements ChannelNotifications {

    private static final Logger LOGGER = getLogger(ChannelNotificationsManagerImpl.class);

    @Inject
    private StaticConfiguration configuration;

    @Inject
    private SecurityManager securityManager;

    @Inject @DcnManager
    private ChannelEntityRepository channelRepository;

    @Inject @DcnManager
    private ChannelPhysicalConnectionRepository channelPhysicalConnectionRepository;

    @Inject
    private LoggerManagerImpl loggerManager;

    @Inject @DcnManager @SystemContext
    private BicnetCallContext systemContext;

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyCreate(ChannelEntity currentEntity) {
        final ChannelType type = configuration.getChannelTypes().get(currentEntity.getInfo().getType());

        sendObjectCreatedNotification(ConvertChannelToBcb.convert(type, currentEntity));
        sendCustomNotificationToClient(
            new FullChannelDataCreateNotification(
                ConvertChannelToFullChannel.convert(type, currentEntity, channelPhysicalConnectionRepository.queryAll(currentEntity.getInfo().getId()))));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyDelete(ChannelEntity channel) {
        sendObjectDeletedNotification(new EMIdItem(channel.getInfo().getId()));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyChanges(ChannelUserPreferencesMutationDescriptor mutation, String channelType) {

        final IEMMarkable markable = createChannelMarkable(mutation.getTarget().getId());
        recordChangesOnMarkable(markable, mutation);

        sendAttributeValueChangeNotification(markable);
        sendChannelGuiInfoChanges(mutation);

        securityManager.updateChannel(mutation.getTarget());
    }

    public void notifyChanges(ChannelInfoMutationDescriptor mutation){
        final IEMMarkable markable = createChannelMarkable(mutation.getTarget().getId());
        recordChangesOnMarkable(markable, mutation);

        sendAttributeValueChangeNotification(markable);
    }

    private IEMMarkable createChannelMarkable(int channelId) {
        final IEMMarkable markable = EMItem.markableEM(null);
        markable.setId(channelId);
        markable.setPropertiesValid(true);
        return markable;
    }

    private void recordChangesOnMarkable(IEMMarkable markable, ChannelUserPreferencesMutationDescriptor mutation) {
        if (mutation.getName().isPresent()) {
            markable.setIdName(mutation.getName().get());
        }
        if (mutation.getReconnectInterval().isPresent()) {
            markable.setReconnectInterval(mutation.getReconnectInterval().get());
        }
    }

    private void recordChangesOnMarkable(IEMMarkable markable, ChannelInfoMutationDescriptor mutation){
        if(mutation.getMediatorId().isPresent()){
            markable.setAssociatedMediatorId(mutation.getMediatorId().get());
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyChanges(Activate event) {
        final IEMMarkable markable = createChannelMarkable(event.getChannelId());
        markable.setActivation(EnableSwitch.ENABLED);
        sendAttributeValueChangeNotification(markable);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyChanges(Deactivate event) {
        final IEMMarkable markable = createChannelMarkable(event.getChannelId());
        markable.setActivation(EnableSwitch.DISABLED);
        sendAttributeValueChangeNotification(markable);
    }

    /**
     * {@inheritDoc}
     */
	@Override
	public void notifyChanges(ChannelCreatingEvent event) {
        final String message = ConvertChannelToBcb.getActivationStateMessage(ActualActivationState.ACTIVATING);
        final GuiActualActivationState guiState = GuiActualActivationState.ACTIVATING;
        notify(event, e -> notifySystemDisplayStateChange(e, message, guiState), e -> notifyClientDisplayStateChange(event, message));
	}

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyChanges(ChannelActivatedEvent event) {
        notifyStateChange(event, CommunicationState.CONNECTED, GuiActualActivationState.ACTIVE);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyChanges(ChannelDeactivatedEvent event) {
        notifyStateChange(event, CommunicationState.DISCONNECTED, GuiActualActivationState.INACTIVE);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyChanges(ChannelActivationFailedEvent event) {
        notifyStateChange(event, CommunicationState.FAILED, GuiActualActivationState.FAILED);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyChanges(ChannelActivatingEvent event) {
        notifyStateChange(event, CommunicationState.CONNECTING, GuiActualActivationState.ACTIVATING);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void notifyChanges(ChannelDeactivatingEvent event) {
        notifyStateChange(event, CommunicationState.DISCONNECTING, GuiActualActivationState.DEACTIVATING);
    }

    /**
     * {@inheritDoc}
     * <p>In this case we only want to change the display state string (it's an UI thing).</p>
     */
    @Override
    public void notifyChanges(ChannelStartingUpEvent event) {
        final String message = ConvertChannelToBcb.getActivationStateMessage(ActualActivationState.STARTINGUP);
        final GuiActualActivationState guiState = GuiActualActivationState.ACTIVATING;
        notifyPhysicalEvent(event, e -> notifySystemDisplayStateChange(e, message, guiState), e -> notifyClientDisplayStateChange(event, message));
    }

    /**
     * {@inheritDoc}
     * <p>In this case we only want to change the display state string (it's an UI thing).</p>
     */
    @Override
    public void notifyChanges(ChannelShuttingDownEvent event) {
        final String message = ConvertChannelToBcb.getActivationStateMessage(ActualActivationState.SHUTTINGDOWN);
        final GuiActualActivationState guiState = GuiActualActivationState.DEACTIVATING;
        notifyPhysicalEvent(event, e -> notifySystemDisplayStateChange(e, message, guiState), e -> notifyClientDisplayStateChange(event, message));
    }

    @Override
    public void notifyCreateInstance(@Nonnull ChannelPhysicalConnectionData physicalConnectionData) {

        sendCustomNotificationToClient(new ChannelInfoNotification(
                new ChannelInfo(physicalConnectionData.getLogicalChannelId())
                        .setGuiStandbyActualActivationState(GuiActualActivationState.INACTIVE)
                        .setStandbyDisplayState(communicationStateToString(CommunicationState.DISCONNECTED))
        ));

    }

    @Override
    public void notifyDeleteInstance(int logicalChannelId, int physicalChannelId) {

        sendCustomNotificationToClient(new ChannelInfoNotification(
                new ChannelInfo(logicalChannelId)
                        .setGuiStandbyActualActivationState(null)
                        .setStandbyDisplayState("")
        ));

    }

    private void notifyStateChange(ActualChannelStateEvent event, CommunicationState state, GuiActualActivationState guiActualActivationState) {
        notify(event, e -> notifySystemStateChange(e, state, guiActualActivationState), e -> notifyClientStateChange(e, state, guiActualActivationState));
    }

    @FunctionalInterface
    private interface NotifyChange {
        void notify(ActualChannelStateEvent event);
    }

    private void notify(ActualChannelStateEvent event, NotifyChange notifySystem, NotifyChange notifyClient) {
        if (event.getOriginatingPhysicalEvent().isPresent()) {
            final PhysicalChannelStateEvent physicalChannelStateEvent =
                    event.getOriginatingPhysicalEvent().get();
            if (!physicalChannelStateEvent.isInstanceActive()) {
                notifyClient.notify(event);
            }
        } else {
            notifySystem.notify(event);
        }
    }

    private void notifyPhysicalEvent(ActualChannelStateEvent event, NotifyChange notifySystem, NotifyChange notifyClient) {
        event.getOriginatingPhysicalEvent()
            .map(e -> e.isInstanceActive() ? notifySystem : notifyClient)
            .ifPresent(f -> f.notify(event));
    }

    private void notifySystemStateChange(ActualChannelStateEvent event, CommunicationState state, GuiActualActivationState guiActualActivationState) {
        final IEMMarkable markable = createChannelMarkable(event.getChannelId());
        markable.setCommunicationState(state);
        markable.setDisplayState(communicationStateToString(state));
        markable.setAdditionalInfo(event.getDetailedDescription());

        sendAttributeValueChangeNotification(markable);

        sendCustomNotificationToClient(new ChannelInfoNotification(
                new ChannelInfo(event.getChannelId())
                        .setGuiActualActivationState(guiActualActivationState)
        ));

        logStateChange(event, state);
    }

    private void notifyClientStateChange(ActualChannelStateEvent event, CommunicationState state, GuiActualActivationState guiActualActivationState) {

        sendCustomNotificationToClient(new ChannelInfoNotification(
                new ChannelInfo(event.getChannelId())
                        .setGuiStandbyActualActivationState(guiActualActivationState)
                        .setStandbyDisplayState(communicationStateToString(state))
                ));

        logStateChange(event, state);
    }

    private void notifySystemDisplayStateChange(ActualChannelStateEvent event, String message, GuiActualActivationState guiActualActivationState) {
        final IEMMarkable markable = createChannelMarkable(event.getChannelId());
        markable.setDisplayState(message);
        markable.setAdditionalInfo(event.getDetailedDescription());
        sendAttributeValueChangeNotification(markable);

        sendCustomNotificationToClient(new ChannelInfoNotification(
                new ChannelInfo(event.getChannelId())
                        .setGuiActualActivationState(guiActualActivationState)
        ));
    }

    private void notifyClientDisplayStateChange(ActualChannelStateEvent event, String message) {

        sendCustomNotificationToClient(new ChannelInfoNotification(
                new ChannelInfo(event.getChannelId())
                        .setStandbyDisplayState(message)
        ));

    }

    private void logStateChange(ActualChannelStateEvent event, CommunicationState state) {
        final int channelId = event.getChannelId();
        try {
            final Optional<String> channelName = channelRepository.queryChannelName(channelId);
            if (channelName.isPresent()) {
                loggerManager.createSystemEventLog(systemContext,
                    new LoggerItemChannel(
                        channelName.get(),
                        StringUtils.join(new String[] {
                            tr(Message.CHANNEL_STATE_CHANGED, communicationStateToString(state)),
                            event.getDetailedDescription(),
                            event.getOriginatingPhysicalEvent()
                                .filter(physical -> !physical.isInstanceActive())
                                .map(physical -> "(standby)")
                                .orElse(null)
                        }, ' '),
                        MessageSeverity.INFO));
            } else {
                LOGGER.warn("Failed to obtain channel {} name, no log entry will be emitted.", channelId);
            }
        } catch (final RepositoryException e) {
            LOGGER.warn("Failed to obtain channel {} name, no log entry will be emitted. {}", channelId,
                    Throwables.getStackTraceAsString(e));
        }
    }

    private void sendChannelGuiInfoChanges(ChannelUserPreferencesMutationDescriptor preferences) {
        if (preferences.getUserText().isPresent()) {
            sendCustomNotificationToClient(new ChannelInfoNotification(
                    new ChannelInfo(preferences.getTarget().getId())
                            .setUserText(preferences.getUserText().get())));
        }
    }
}
