package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.google.common.base.Function;
import com.google.common.base.Throwables;
import com.google.common.collect.FluentIterable;
import com.mysema.query.BooleanBuilder;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerMarkable;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.SystemContainerService;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertSystemContainerToBcb;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaContainerRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSystemRepositoryBean;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.commands.container.MoveSystemsToContainer;
import com.ossnms.dcn_manager.commands.container.assignment.CreateDefaultSystemAssignment;
import com.ossnms.dcn_manager.commands.container.assignment.CreateSingleSystemAssignment;
import com.ossnms.dcn_manager.commands.system.CreateSystem;
import com.ossnms.dcn_manager.commands.system.DeleteSystem;
import com.ossnms.dcn_manager.commands.system.GetSystem;
import com.ossnms.dcn_manager.commands.system.ModifySystems;
import com.ossnms.dcn_manager.connector.jpa.JpaCloseableQuery;
import com.ossnms.dcn_manager.connector.storage.container.entities.QSystemInfoDb;
import com.ossnms.dcn_manager.core.entities.container.system.SystemCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.outbound.ContainerNotifications;
import com.ossnms.dcn_manager.core.outbound.SystemNotifications;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.utils.Optionals;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownContainerIdException;
import com.ossnms.dcn_manager.exceptions.UnknownSystemIdException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import javax.persistence.PersistenceException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Optional;

import static com.google.common.base.Functions.compose;
import static com.ossnms.dcn_manager.bicnet.connector.facade.util.Exceptions.logAndRethrowAsBcb;

/**
 * Delegate class for matters related to System Containers.
 */
public class SystemContainerHelper implements SystemContainerService {

    private static final Logger LOGGER = LoggerFactory.getLogger(SystemContainerHelper.class);

    private JpaSystemRepositoryBean repository;
    private JpaNetworkElementRepositoryBean neRepository;
    private JpaContainerRepositoryBean containerRepository;
    private SystemNotifications notifications;
    private LoggerManagerImpl loggerManager;
    private ContainerNotifications containerNotifications;
    private SettingsRepository settingsRepository;

    /**
     *  Settings repository injection point.
     */
    @Inject
    public void setSettingsRepository(@DcnManager SettingsRepository settingsRepository) {
        this.settingsRepository = settingsRepository;
    }

    /**
     *  NE repository injection point.
     */
    @Inject public void setJpaNetworkElementRepositoryBean(@DcnManager JpaNetworkElementRepositoryBean neRepository) {
        this.neRepository = neRepository;
    }

    /**
     * Container Notifications injection point.
     */
    @Inject public void setContainerNotifications(ContainerNotifications containerNotifications) {
        this.containerNotifications = containerNotifications;
    }

    /**
     * System Repository injection point.
     */
    @Inject public void setRepository(@DcnManager JpaSystemRepositoryBean repository) {
        this.repository = repository;
    }

    /**
     * Container Repository injection point.
     */
    @Inject public void setContainerRepository(@DcnManager JpaContainerRepositoryBean containerRepository) {
        this.containerRepository = containerRepository;
    }

    /**
     * System Notifications Manager injection point.
     */
    @Inject public void setNotifications(SystemNotifications notifications) {
        this.notifications = notifications;
    }

    /**
     * Logger Manager injection point.
     */
    @Inject public void setLoggerManager(LoggerManagerImpl loggerManager) {
        this.loggerManager = loggerManager;
    }

    @Override public ISystemContainer getSingleSystemContainer(ISessionContext sessionContext,
            ISystemContainerId systemContainerId) throws BcbException {
        try {
            final SystemInfo info = new GetSystem<>(new BicnetCallContext(sessionContext), repository,
                    systemContainerId.getId()).call();
            return ConvertSystemContainerToBcb.convert(info);
        } catch (final RepositoryException e) {
            throw new BcbException("Error searching for System Container " + systemContainerId, e);
        } catch (final UnknownSystemIdException e) {
            LOGGER.info("Unknown system container {}", systemContainerId);
            return null;
        }
    }

    private JpaCloseableQuery buildQueryExpression(ISystemContainerId startAfter, ISystemContainerMarkable[] filter,
            int howMany, final QSystemInfoDb sysContainer) throws RepositoryException {
        final JpaCloseableQuery query = repository.query(sysContainer);
        final BooleanBuilder predicateBuilder = new BooleanBuilder();
        if (filter != null) {
            final BooleanBuilder filterBuilder = new BooleanBuilder();
            for (final ISystemContainerMarkable markable : filter) {
                LOGGER.debug("Filtering System Container listing with: {}", markable.toStringOnlyMarkedAttributes());
                final BooleanBuilder markablePredicateBuilder = new BooleanBuilder();
                if (markable.isMarkedId()) {
                    markablePredicateBuilder.and(sysContainer.containerId.eq(markable.getId()));
                    markable.markId(false);
                }
                if (markable.isMarkedIdName()) {
                    markablePredicateBuilder.and(sysContainer.containerName.eq(markable.getIdName()));
                    markable.markIdName(false);
                }
                if (markable.countMarks() > 0) {
                    throw new RepositoryException("Unsupported query parameters: {}",
                            markable.toStringOnlyMarkedAttributes());
                }
                filterBuilder.or(markablePredicateBuilder);
            }
            if (filterBuilder.hasValue()) {
                predicateBuilder.and(filterBuilder);
            }
        }
        if (startAfter != null) {
            predicateBuilder.and(sysContainer.containerId.gt(startAfter.getId()));
        }
        if (predicateBuilder.hasValue()) {
            query.where(predicateBuilder);
        }
        if (howMany > -1) {
            query.limit(howMany);
        }
        query.orderBy(sysContainer.containerId.asc());
        return query;
    }

    @Override public SystemContainerReply getSystemContainerList(ISessionContext sessionContext,
            ISystemContainerId startAfter, ISystemContainerMarkable[] filter, int howMany) throws BcbException {
        final QSystemInfoDb systemContainer = QSystemInfoDb.systemInfoDb;
        try (final JpaCloseableQuery query = buildQueryExpression(startAfter, filter, howMany, systemContainer)) {
            final ISystemContainer[] systems = query.list(systemContainer).stream()
                    .map(repository.getEntityTransformer()::apply).filter(Optional::isPresent)
                    .map(compose(new ConvertSystemContainerToBcb(), Optionals.dereference())::apply)
                    .toArray(ISystemContainer[]::new);
            return new SystemContainerReply(systems, true, null);
        } catch (final PersistenceException | RepositoryException e) {
            throw new BcbException("Error listing System Containers.", e);
        }
    }

    @Override public SystemContainerIdReply getSystemContainerIdList(ISessionContext sessionContext,
            ISystemContainerId startAfter, ISystemContainerMarkable[] filter, int howMany) throws BcbException {
        final QSystemInfoDb systemContainer = QSystemInfoDb.systemInfoDb;
        try (final JpaCloseableQuery query = buildQueryExpression(startAfter, filter, howMany, systemContainer)) {
            final ISystemContainerId[] systems = FluentIterable.from(query.list(systemContainer.containerId))
                    .transform((Function<Integer, ISystemContainerId>) SystemContainerIdItem::new)
                    .toArray(ISystemContainerId.class);
            return new SystemContainerIdReply(systems, true, null);
        } catch (final PersistenceException | RepositoryException e) {
            throw new BcbException("Error listing System Container IDs.", e);
        }
    }

    @Override public ISystemContainer createSystemContainer(ISessionContext sessionContext,
            ISystemContainer systemContainer) throws BcbException {
        try {
            final SystemCreationDescriptor creation = new SystemCreationDescriptor(systemContainer.getIdName())
                    .setDescription(Optional.ofNullable(systemContainer.getDescription()))
                    .setUserText(Optional.ofNullable(systemContainer.getUserLabel()));

            final BicnetCallContext context = new BicnetCallContext(sessionContext);

            final SystemInfo systemInfo = new CreateSystem<>(context, repository, containerRepository, neRepository.getNeUserPreferencesRepository(),
                    notifications, loggerManager, creation).call();

            new CreateDefaultSystemAssignment<>(context, containerRepository, repository, systemInfo, containerNotifications,
                    loggerManager, settingsRepository).call();

            return ConvertSystemContainerToBcb.convert(systemInfo);
        } catch (final IllegalArgumentException | CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override public ISystemContainer createSystemContainer(@Nonnull final ISessionContext sessionContext,
            @Nonnull final ISystemContainer systemContainer, @Nonnull final IGenericContainerId genericContainerId)
            throws BcbException {
        try {
            final SystemCreationDescriptor creation = new SystemCreationDescriptor(systemContainer.getIdName())
                    .setDescription(Optional.ofNullable(systemContainer.getDescription()))
                    .setUserText(Optional.ofNullable(systemContainer.getUserLabel()));

            final BicnetCallContext context = new BicnetCallContext(sessionContext);

            final SystemInfo systemInfo = new CreateSystem<>(context, repository, containerRepository, neRepository.getNeUserPreferencesRepository(),
                    notifications, loggerManager, creation).call();

            new CreateSingleSystemAssignment<>(context, containerRepository, repository, systemInfo, genericContainerId.getId(),
                    containerNotifications, loggerManager, settingsRepository).call();

            return ConvertSystemContainerToBcb.convert(systemInfo);
        } catch (final IllegalArgumentException | CommandException | UnknownContainerIdException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public void moveToContainers(ISessionContext sessionContext, Collection<ISystemContainerId> systems, IGenericContainerId primaryContainer, Collection<IGenericContainerId> containers) throws BcbException {
        try {
            new MoveSystemsToContainer<>(new BicnetCallContext(sessionContext), containerRepository, systems, primaryContainer, containers, containerNotifications, loggerManager, repository, settingsRepository).call();
        } catch (CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override public void deleteSystemContainer(ISessionContext sessionContext, ISystemContainerId systemContainerId)
            throws BcbException {

        try {
            new DeleteSystem<>(new BicnetCallContext(sessionContext), repository, notifications, loggerManager,
                    systemContainerId.getId()).call();
        } catch (UnknownSystemIdException | CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }

    }

    @Override public void deleteSystemContainers(@Nonnull ISessionContext sessionContext,
            @Nonnull Collection<ISystemContainerId> systemContainerIds) throws BcbException {
        for (ISystemContainerId systemContainerId : systemContainerIds) {
            try {
                new DeleteSystem<>(new BicnetCallContext(sessionContext), repository, notifications, loggerManager,
                        systemContainerId.getId()).call();
            } catch (UnknownSystemIdException | CommandException e) {
                throw logAndRethrowAsBcb(e, LOGGER);
            }
        }
    }

    @Override public ISystemContainerMarkable modifySystemContainer(ISessionContext sessionContext,
            ISystemContainerMarkable systemContainer) throws BcbException {
        return modifySystemContainers(sessionContext, new ISystemContainerMarkable[] { systemContainer })[0];
    }

    @Override public ISystemContainerMarkable[] modifySystemContainers(ISessionContext sessionContext,
            ISystemContainerMarkable[] systemContainers) throws BcbException {

        final FluentIterable<SystemInfoMutationDescriptor> mutations = FluentIterable
                .from(Arrays.asList(systemContainers))
                .transform((Function<ISystemContainerMarkable, Optional<SystemInfoMutationDescriptor>>) input -> {
                    try {
                        final Optional<SystemInfo> container = repository.query(input.getId());
                        if (container.isPresent()) {
                            final SystemContainerModification modification = new SystemContainerModification(
                                    container.get());
                            SystemContainerItem.update(modification, input);
                            return Optional.of(modification.toMutation());
                        } else {
                            LOGGER.warn("Could not find System Container for id:{}.", input.getId());
                        }
                    } catch (final RepositoryException e) {
                        LOGGER.error("Failed to obtain System Container for {}: {} {}", input, e.getMessage(),
                                Throwables.getStackTraceAsString(e));
                    }
                    return Optional.empty();
                }).filter(Optionals.isPresent()).transform(Optionals.dereference());

        try {
            new ModifySystems<>(new BicnetCallContext(sessionContext), repository, containerRepository, neRepository.getNeUserPreferencesRepository(),
                    notifications, loggerManager, mutations).call();
        } catch (final CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }

        return systemContainers;
    }

    private static final class SystemContainerModification extends SystemContainerItem {

        private static final long serialVersionUID = 1L;

        private final transient SystemInfoMutationDescriptor mutation;

        private SystemContainerModification(@Nonnull SystemInfo original) {
            mutation = new SystemInfoMutationDescriptor(original);
        }

        public SystemInfoMutationDescriptor toMutation() {
            return mutation;
        }

        @Override public void setIdName(String idName) {
            mutation.setName(idName);
        }

        @Override public void setDescription(String description) {
            mutation.setDescription(Optional.ofNullable(description));
        }

        @Override public void setUserLabel(String userLabel) {
            mutation.setUserText(Optional.ofNullable(userLabel));
        }
    }

}
