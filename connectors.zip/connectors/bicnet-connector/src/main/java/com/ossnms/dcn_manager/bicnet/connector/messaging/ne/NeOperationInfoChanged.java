package com.ossnms.dcn_manager.bicnet.connector.messaging.ne;

import com.google.common.base.Strings;
import com.google.common.collect.BiMap;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.common.GatewayRole;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommissioningStatusSummary;
import com.ossnms.bicnet.bcb.model.elementMgmt.ICommissioningStatusSummaryPkgMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.IGatewayConfigurationPkgMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.IWriteAccessStatePkgMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.WriteAccessState;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.OperationalMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.TpGroupSettings;
import com.ossnms.dcn_manager.core.events.ne.NeOperationInfoChangedEvent;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.functions.Func1;

import java.util.Optional;

final class NeOperationInfoChanged implements
        Func1<AttributeValueChange, NeOperationInfoChangedEvent> {

    private static final Logger LOGGER = LoggerFactory.getLogger(NeOperationInfoChanged.class);

    private JpaNetworkElementRepositoryBean neRepository;

    private StaticConfiguration configuration;

    public NeOperationInfoChanged(JpaNetworkElementRepositoryBean neRepository, StaticConfiguration configuration ) {
        this.neRepository = neRepository;
        this.configuration = configuration;
    }

    @Override
    public NeOperationInfoChangedEvent call(AttributeValueChange avc) {
        return buildEvent((INetworkElementMarkable) avc.getChangedObject());
    }

    private NeOperationInfoChangedEvent buildEvent(INetworkElementMarkable nem) {
        final NeOperationInfoChangedEvent event = new NeOperationInfoChangedEvent(nem.getNeId());

        LOGGER.debug("Processing Network element markable with marked: {}", nem.toStringOnlyMarkedAttributes());
        
        if (nem.isMarkedName()) {
            event.setRealNeName(Strings.nullToEmpty(nem.getName()));
        }

        updateGatewayConfig(nem, event);
        
        updateEventConfiguration(nem, event);

        updateEventTpGroups(nem, event);

        updateEventSoftwareVersions(nem, event);

        updateEventNeTypes(nem, event);

        updateEventWriteAccess(nem, event);

        updateEventCommissioning(nem, event);

        updateNeIdentificationControlData(nem, event);
        
        updateNeTypeGuiInfo(nem,event);

        return event;
    }

    private void updateGatewayConfig(INetworkElementMarkable nem,
            final NeOperationInfoChangedEvent event) {

        final IGatewayConfigurationPkgMarkable gatewayConfig = (IGatewayConfigurationPkgMarkable)
                nem.getFacette(IGatewayConfigurationPkgMarkable.class);
        if (null != gatewayConfig && gatewayConfig.isMarkedGatewayRole()) {
            final GatewayRole gatewayRole = gatewayConfig.getGatewayRole();
            event.setGatewayMode(ConvertNeToBcb.convertGatewayRole(gatewayRole));
        }
    }


    private void updateEventConfiguration(INetworkElementMarkable nem,
            final NeOperationInfoChangedEvent event) {
        if (nem.isMarkedEventForwarding()) {
            event.setEventForwardingActive(nem.getEventForwarding() == EnableSwitch.ENABLED);
        }
        if (nem.isMarkedOperationalState()) {
            event.setOperationalMode(nem.getOperationalState() == OperationalState.DISABLED
                    ? OperationalMode.DISABLED : OperationalMode.ENABLED);
        }
        if (nem.isMarkedLocation()) {
            event.setLocation(nem.getLocation());
        }
    }

    private void updateEventSoftwareVersions(INetworkElementMarkable nem,
            final NeOperationInfoChangedEvent event) {
        if (nem.isMarkedMainRelease()) {
            event.setMainRelease(Strings.nullToEmpty(nem.getMainRelease()));
        }
        if (nem.isMarkedMaintenanceRelease()) {
            event.setMaintenanceRelease(Strings.nullToEmpty(nem.getMaintenanceRelease()));
        }
    }

    private void updateEventTpGroups(INetworkElementMarkable nem,
            final NeOperationInfoChangedEvent event) {
        if (nem.isMarkedTpGroupMask()) {
            event.setTpGroupMask(nem.getTpGroupMask());
        }
        if (nem.isMarkedTpGroupMode() && null != nem.getTpGroupMode()) {
            event.setTpGroupMode(new TpGroupSettings(
                    nem.getTpGroupMode().getAlwaysCompatible(),
                    nem.getTpGroupMode().getMultipleGroupMembership(),
                    nem.getTpGroupMode().getSubgroupsMustBeEqual(),
                    nem.getTpGroupMode().getMultipleGroupMembership()));
        }
    }

    private void updateEventNeTypes(INetworkElementMarkable nem,
            final NeOperationInfoChangedEvent event) {
        if (nem.isMarkedNeFamily() && null != nem.getNeFamily()) {
            event.setFamily(nem.getNeFamily().name());
        }
        if (nem.isMarkedNeSubType() && null != nem.getNeSubType()) {
            event.setNeSubType(nem.getNeSubType().name());
        }
        if (nem.isMarkedNeType() && null != nem.getNeType()) {
            event.setNeType(nem.getNeType().name());
        }
        if (nem.isMarkedSpecificType()) {
            event.setNeSpecificType(nem.getSpecificType());
        }
    }

    private void updateEventCommissioning(INetworkElementMarkable nem,
            final NeOperationInfoChangedEvent event) {
        final ICommissioningStatusSummaryPkgMarkable commissioningStatus = (ICommissioningStatusSummaryPkgMarkable)
                nem.getFacette(ICommissioningStatusSummaryPkgMarkable.class);
        if (null != commissioningStatus && commissioningStatus.isMarkedCommissioningStatusSummary()) {
            final CommissioningStatusSummary status = commissioningStatus.getCommissioningStatusSummary();
            event.setCommissioning(ConvertNeToBcb.convertCommissioningStatusSummary(status));
        }
    }

    private void updateEventWriteAccess(INetworkElementMarkable nem,
            final NeOperationInfoChangedEvent event) {
        final IWriteAccessStatePkgMarkable writeAccess = (IWriteAccessStatePkgMarkable)
                nem.getFacette(IWriteAccessStatePkgMarkable.class);
        if (null != writeAccess && writeAccess.isMarkedWriteAccessState()) {
            final WriteAccessState writeAccessState = writeAccess.getWriteAccessState();
            event.setWriteAccess(ConvertNeToBcb.convertWriteAccessState(writeAccessState));
        }
    }

    /*
     * The Ne SubType Description is based on the NeSpecificType and NeProxyType.
     */
    private void updateNeTypeGuiInfo(INetworkElementMarkable nem, final NeOperationInfoChangedEvent event) {
        if (nem.isMarkedSpecificType() && null != nem.getSpecificType()) {
            event.setNeSubTypeDescription(nem.getSpecificType());
        } else if (nem.isMarkedType() && null != nem.getType()) {
            event.setNeSubTypeDescription(nem.getType());
        }
    }

    private void updateNeIdentificationControlData(INetworkElementMarkable nem,
                                                   final NeOperationInfoChangedEvent event) {
        // if NeIdentificationControl is set then choose which INetworkElement attribute should be used to populate neighbourhoodId

        Optional<NeInfoData> neInfoData = Optional.empty();
        try {
            neInfoData = neRepository.getNeInfoRepository().query(nem.getNeId());
        } catch (RepositoryException e) {
            LOGGER.error("Failed to update Ne identification control data for NE", e);
        }
        if(neInfoData.isPresent()) {

            final NeInfoData info = neInfoData.get();
            final NeType neType = configuration.getNeTypes().get(info.getProxyType());

            BiMap<String, String> idControlMap = neType.getIdentificationControlMap();
            if (null != idControlMap) {
                String sourcePropNameForNeighbourhoodId = idControlMap.get(WellKnownNePropertyNames.NEIGHBOURHOOD_ID);

                if (WellKnownNePropertyNames.SYSNAME.equals(sourcePropNameForNeighbourhoodId) && nem.isMarkedName()) {
                    event.setNeighbourhoodId(Strings.nullToEmpty(nem.getName()));

                } else if (WellKnownNePropertyNames.TL1_ID.equals(sourcePropNameForNeighbourhoodId) && nem.isMarkedTid()) {
                    event.setNeighbourhoodId(Strings.nullToEmpty(nem.getTid()));
                }
            }
        }
    }
}