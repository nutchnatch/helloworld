package com.ossnms.dcn_manager.bicnet.connector.interfaces;

import com.ossnms.bicnet.bcb.facade.elementMgmt.IGctMgrFacade;
import com.ossnms.bicnet.bcb.facade.faultMgmt.IFaultMgrFacade;
import com.ossnms.bicnet.bcb.facade.licensing.ILicenseMgrFacade;
import com.ossnms.bicnet.bcb.facade.logMgmt.ILogMgrFacade;
import com.ossnms.bicnet.bcb.facade.ndm.INetworkDataManagerFacade;
import com.ossnms.bicnet.bcb.facade.platform.IConnectionManager;
import com.ossnms.bicnet.bcb.facade.platform.INotifyBeanFacade;
import com.ossnms.bicnet.bcb.facade.platform.ISchedulerEjbFacade;
import com.ossnms.bicnet.bcb.facade.scs.ISystemControlEjbFacade;
import com.ossnms.bicnet.bcb.facade.security.ISecurityMgrFacade;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcherFactory;
import com.ossnms.bicnet.bcb.messaging.direct.IBiCNetDirectMessageDispatcherFactory;

public interface BicnetServiceManagerFactory {

    /**
     * @return An instance of {@link IBiCNetDirectMessageDispatcherFactory}.
     */
    IBiCNetDirectMessageDispatcherFactory getBiCNetDirectMessageDispatcherFactory();

    /**
     * @return An instance of {@link IBiCNetMessageDispatcherFactory}.
     */
    IBiCNetMessageDispatcherFactory getBiCNetMessageDispatcherFactory();

    /**
     * @return @see IBiCNetMessageDispatcher
     */
    IBiCNetMessageDispatcher getBiCNetMessageDispatcher();

    /**
     * @return @see IConnectionManager.
     */
    IConnectionManager getConnectionManagerAtpFacade();

    /**
     * @return @see ILogMgrFacade
     */
    ILogMgrFacade getLogManagerFacade();

    /**
     * @return @see ISchedulerEjbFacade
     */
    ISchedulerEjbFacade getSchedulerManagerFacade();

    /**
     * @return @see ISystemControlEjbFacade
     */
    ISystemControlEjbFacade getSystemControlManagerFacade();

    /**
     * @return @see IFaultMgrFacade
     */
    IFaultMgrFacade getFaultManager();

    /**
     * @return @see INotifyBeanFacade
     */
    INotifyBeanFacade getNotifyBeanFacade();

    /**
     * @return @see ILicenseMgrFacade
     */
    ILicenseMgrFacade getLicenseManagerFacade();

    /**
     * @return @see ISecurityMgrFacade
     */
    ISecurityMgrFacade getSecurityManagerFacade();

    /**
     * @return @see IGctMgrFacade
     */
    IGctMgrFacade getGctManagerFacade();
    
    /**
     * @return @see INetworkDataManagerFacade
     */
    INetworkDataManagerFacade getNetworkDataManager();
}