package com.ossnms.dcn_manager.bicnet.connector.factory;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;

import com.ossnms.dcn_manager.bicnet.connector.messaging.ChannelEventSource;
import com.ossnms.dcn_manager.bicnet.connector.messaging.MediatorEventSource;
import com.ossnms.dcn_manager.bicnet.connector.messaging.ne.NeEventSource;
import com.ossnms.dcn_manager.bicnet.connector.outbound.notifications.NeNotificationsManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.policies.MediatorConnectionSchedulerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.ChannelInstanceConnectionRepository;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaChannelRepositoryBean;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.DomainManagers;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;

/**
 * Factory that produces parameter objects for each managed entity.
 * Such parameter objects aggregate most services related to each entity, such
 * as repositories, behaviors, scheduling, events, etc.
 */
@ApplicationScoped
public class EntityManagers {

    @Inject @DcnManager private MediatorEntityRepository mediatorRepository;
    @Inject @DcnManager private MediatorInstanceEntityRepository mediatorInstanceRepository;
    @Inject @DcnManager private MediatorConnectionSchedulerImpl mediatorActivationManager;
    @Inject private MediatorNotifications mediatorNotifications;
    @Inject private MediatorEventSource mediatorEventSource;

    @Inject @DcnManager private JpaChannelRepositoryBean channelRepository;
    @Inject @DcnManager private ChannelInstanceConnectionRepository channelInstanceRepository;
    @Inject @DcnManager private ChannelInteractionManager channelActivationManager;
    @Inject private ChannelNotifications channelNotifications;
    @Inject private ChannelEventSource channelEventSource;

    @Inject @DcnManager private JpaNetworkElementRepositoryBean neRepository;
    @Inject @DcnManager private NetworkElementInteractionManager neActivationManager;
    @Inject @DcnManager private NePhysicalConnectionRepository neInstanceRepository;
    @Inject private NeNotificationsManagerImpl neNotifications;
    @Inject private NeEventSource neEventSource;

    @Inject @DcnManager private DomainRepository domainRepository;
    @Inject private DomainNotifications domainNotifications;

    private ChannelManagers channelManagers;
    private MediatorManagers mediatorManagers;
    private NetworkElementManagers networkElementManagers;
    private DomainManagers domainManagers;

    @PostConstruct
    public void initialize() {
        channelManagers = new ChannelManagers(channelRepository, channelInstanceRepository, channelNotifications, channelActivationManager, channelEventSource);
        mediatorManagers = new MediatorManagers(mediatorRepository, mediatorInstanceRepository, mediatorNotifications, mediatorActivationManager, mediatorEventSource);
        networkElementManagers = new NetworkElementManagers(neRepository, neInstanceRepository, neActivationManager, neNotifications, neEventSource);
        domainManagers = new DomainManagers(domainRepository, domainNotifications);
    }

    /**
     * @return Mediator management parameter object.
     */
    @Produces
    public MediatorManagers getMediatorManagers() {
        return mediatorManagers;
    }

    /**
     * @return Channel management parameter object.
     */
    @Produces
    public ChannelManagers getChannelManagers() {
        return channelManagers;
    }

    /**
     * @return NE management parameter object.
     */
    @Produces
    public NetworkElementManagers getNetworkElementManagers() {
        return networkElementManagers;
    }

    /**
     * @return Domain management parameter object.
     */
    @Produces
    public DomainManagers getDomainManagers() {
        return domainManagers;
    }

}
