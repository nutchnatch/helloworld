package com.ossnms.dcn_manager.bicnet.connector.configuration;

import com.google.common.collect.Lists;
import com.ossnms.bicnet.util.ApplicationProperties;
import com.ossnms.dcn_manager.composables.configuration.AppProperties;
import com.ossnms.dcn_manager.composables.configuration.HardwareConfigurationType;
import com.ossnms.dcn_manager.core.configuration.loaders.XmlConfigurationLoader;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.DefaultPropertyValues;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.PasswordPropertyMetadata;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.model.Types;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.inject.Singleton;
import java.io.IOException;
import java.net.URL;
import java.util.Collections;
import java.util.List;

/**
 * EJB wrapping the core static configuration. Also provides access to
 * Java resources managed by JBoss so that the server core can process
 * them at startup.
 */
@Singleton
public class StaticConfigurationSingleton implements StaticConfiguration, AppProperties {

    private static final Logger LOGGER = LoggerFactory.getLogger(StaticConfigurationSingleton.class);

    private static final String PROPERTIES_FILE_NAME = "/dcn-manager.properties";

    private static final String PROPERTY_SERVER_HOST = "server.ipaddress";
    private static final String PROPERTY_AUTO_COPY_NE_NAME = "enable.auto.copy.ne.name";
    private static final String PROPERTY_NODE_MANAGER_SELECTED = "node.manager.selected";
    private static final String PROPERTY_HW_CONFIGURATION = "configuration.type";

    private final StaticConfiguration configuration;
    private final ApplicationProperties applicationProperties;

    /**
     * Creates a new object.
     */
    public StaticConfigurationSingleton() {
        configuration = new XmlConfigurationLoader(getResourceURLs()).load();
        applicationProperties = ApplicationProperties.getInstance(PROPERTIES_FILE_NAME);
    }

    private List<URL> getResourceURLs() {
        try {
            return Lists.transform(
                    Collections.list(getClass().getClassLoader().getResources("/")),
                    new VirtualUrlIntoFileUrl());
        } catch (final IOException e) {
            LOGGER.warn("Failed to obtain all resources from our classloader.", e.getMessage());
            return Collections.emptyList();
        }
    }

    @Override
    public Types<NeType> getNeTypes() {
        return configuration.getNeTypes();
    }

    @Override
    public Types<ChannelType> getChannelTypes() {
        return configuration.getChannelTypes();
    }

    @Override
    public Types<MediatorType> getMediatorTypes() {
        return configuration.getMediatorTypes();
    }

    @Override
    public DefaultPropertyValues getDefaultPropertyValues() {
        return configuration.getDefaultPropertyValues();
    }

    @Override
    public PasswordPropertyMetadata getPasswordPropertyMetadata() {
        return configuration.getPasswordPropertyMetadata();
    }

    @Override @Nonnull
    public String getServerHost() {
        return applicationProperties.getProperty(PROPERTY_SERVER_HOST);
    }

    @Override @Nonnull
    public Boolean isAutoCopyNeNameEnabled() {
        return Boolean.valueOf(applicationProperties.getProperty(PROPERTY_AUTO_COPY_NE_NAME));
    }

    @Override @Nonnull
    public Boolean isNodeManagerSelected() {
        return BooleanUtils.toBoolean(
                NumberUtils.toInt(applicationProperties.getProperty(PROPERTY_NODE_MANAGER_SELECTED), 0));
    }
    
    @Override @Nonnull
    public HardwareConfigurationType getHWConfiguration() {
        return HardwareConfigurationType.from(applicationProperties.getProperty(PROPERTY_HW_CONFIGURATION));
    }
}
