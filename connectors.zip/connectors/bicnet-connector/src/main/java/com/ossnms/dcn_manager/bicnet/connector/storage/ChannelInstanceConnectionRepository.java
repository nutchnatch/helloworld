package com.ossnms.dcn_manager.bicnet.connector.storage;

import javax.enterprise.context.ApplicationScoped;

import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.connector.storage.channel.InMemoryChannelPhysicalConnectionRepository;

/**
 * <p>EJB that maintains an instance of a Physical Channel Connections repository.</p>
 */
@DcnManager
@ApplicationScoped
public class ChannelInstanceConnectionRepository
        extends InMemoryChannelPhysicalConnectionRepository {

}
