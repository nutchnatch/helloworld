package com.ossnms.dcn_manager.bicnet.connector.messaging;

import com.ossnms.bicnet.bcb.messaging.BiCNetMessageLayer;
import com.ossnms.bicnet.bcb.model.ManagedObjectType;
import com.ossnms.bicnet.bcb.model.platform.NotificationType;

import java.util.Map;
import java.util.Set;

import static com.google.common.collect.ImmutableMap.of;
import static com.ossnms.bicnet.bcb.messaging.BiCNetMessageLayer.ATP_SCHEDULER;
import static com.ossnms.bicnet.bcb.messaging.BiCNetMessageLayer.SOURCE;
import static com.ossnms.bicnet.bcb.model.ManagedObjectType.ELEMENT_MANAGER;
import static com.ossnms.bicnet.bcb.model.ManagedObjectType.NETWORK_ELEMENT;
import static com.ossnms.bicnet.bcb.model.ManagedObjectType.NETWORK_ELEMENT_DOMAIN_ASSIGNMENT;
import static com.ossnms.bicnet.bcb.model.ManagedObjectType.NETWORK_ELEMENT_PROXY;
import static com.ossnms.bicnet.bcb.model.ManagedObjectType.SCHEDULE;
import static com.ossnms.bicnet.bcb.model.platform.NotificationType.ATTRIBUTE_VALUE_CHANGE;
import static com.ossnms.bicnet.bcb.model.platform.NotificationType.CATEGORY_OUT_OF_SYNC;
import static com.ossnms.bicnet.bcb.model.platform.NotificationType.EM_PROPERTIES_CHANGED;
import static com.ossnms.bicnet.bcb.model.platform.NotificationType.IDENTIFIER_CHANGE;
import static com.ossnms.bicnet.bcb.model.platform.NotificationType.NETWORK_ELEMENT_DISCOVERED;
import static com.ossnms.bicnet.bcb.model.platform.NotificationType.NETWORK_ELEMENT_REMOVED;
import static com.ossnms.bicnet.bcb.model.platform.NotificationType.NE_PROPERTIES_CHANGED;
import static com.ossnms.bicnet.bcb.model.platform.NotificationType.OBJECT_CREATION;
import static com.ossnms.bicnet.bcb.model.platform.NotificationType.OBJECT_DELETION;
import static com.ossnms.bicnet.bcb.model.platform.NotificationType.SCHEDULE_EXECUTION;
import static com.ossnms.bicnet.bcb.model.platform.NotificationType.SYNCH_NOTIFICATION;
import static com.ossnms.bicnet.messaging.util.BiCNetNotificationTypeBuilder.builder;

public final class BiCNetMessageListenerConfiguration {

    private BiCNetMessageListenerConfiguration() {
    }

    /**
     * Subscription configuration for {@link BiCNetMessageListener}
     * @return map of each supported layer and notifications 
     */
    public static Map<BiCNetMessageLayer, Map<ManagedObjectType, Set<NotificationType>>> build() {
        return of(
                SOURCE, sourceNotifications(),
                ATP_SCHEDULER, schedulerNotifications());
    }

    /**
     * Notifications to subscribe on {@link BiCNetMessageLayer#SOURCE} layer 
     */
    private static Map<ManagedObjectType, Set<NotificationType>> sourceNotifications() {
        return builder()

                .forObject(ELEMENT_MANAGER).notif(OBJECT_CREATION)
                .forObject(ELEMENT_MANAGER).notif(OBJECT_DELETION)
                .forObject(ELEMENT_MANAGER).notif(ATTRIBUTE_VALUE_CHANGE)

                .forObject(NETWORK_ELEMENT_PROXY).notif(OBJECT_DELETION)
                .forObject(NETWORK_ELEMENT_PROXY).notif(ATTRIBUTE_VALUE_CHANGE)

                .forObject(NETWORK_ELEMENT).notif(ATTRIBUTE_VALUE_CHANGE)

                .forObject(NETWORK_ELEMENT_DOMAIN_ASSIGNMENT).notif(OBJECT_CREATION)
                .forObject(NETWORK_ELEMENT_DOMAIN_ASSIGNMENT).notif(OBJECT_DELETION)
                .forObject(NETWORK_ELEMENT_DOMAIN_ASSIGNMENT).notif(ATTRIBUTE_VALUE_CHANGE)
                .forObject(NETWORK_ELEMENT_DOMAIN_ASSIGNMENT).notif(IDENTIFIER_CHANGE)

                .forAnyObject().notif(SYNCH_NOTIFICATION)

                .forAnyObject().notif(NETWORK_ELEMENT_DISCOVERED)

                .forAnyObject().notif(NE_PROPERTIES_CHANGED)

                .forAnyObject().notif(EM_PROPERTIES_CHANGED)

                .forAnyObject().notif(NETWORK_ELEMENT_REMOVED)

                .forAnyObject().notif(CATEGORY_OUT_OF_SYNC)

                .build();
    }

    /**
     * Notifications to subscribe on {@link BiCNetMessageLayer#ATP_SCHEDULER} layer
     */
    private static Map<ManagedObjectType, Set<NotificationType>> schedulerNotifications() {
        return builder()
                .forObject(SCHEDULE).notif(SCHEDULE_EXECUTION)
                .build();
    }
}
