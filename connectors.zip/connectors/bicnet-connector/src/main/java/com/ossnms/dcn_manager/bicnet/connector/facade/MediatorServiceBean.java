package com.ossnms.dcn_manager.bicnet.connector.facade;

import com.google.common.collect.ImmutableList;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorReply;
import com.ossnms.bicnet.bcb.facade.scs.ISystemControlEjbFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediator;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorElements;
import com.ossnms.bicnet.bcb.model.scs.ScsSiteConfiguration;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullMediatorData;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.MediatorService;
import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertMediatorToBcb;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertMediatorToFullMediator;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.PairMediatorWithTypeAndInstances;
import com.ossnms.dcn_manager.bicnet.connector.facade.util.BicnetConfigurationProperties;
import com.ossnms.dcn_manager.bicnet.connector.facade.util.BicnetStandbyProperties;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.commands.mediator.ActivateStandbyMediator;
import com.ossnms.dcn_manager.commands.mediator.CreateMediator;
import com.ossnms.dcn_manager.commands.mediator.DeactivateStandbyMediator;
import com.ossnms.dcn_manager.commands.mediator.DeleteMediator;
import com.ossnms.dcn_manager.commands.mediator.GetAllMediators;
import com.ossnms.dcn_manager.commands.mediator.GetMediator;
import com.ossnms.dcn_manager.commands.mediator.internal.GetRegisteredMediators;
import com.ossnms.dcn_manager.commands.mediator.internal.MediatorActivationRequired;
import com.ossnms.dcn_manager.commands.mediator.internal.MediatorDeactivationRequired;
import com.ossnms.dcn_manager.commands.mediator.internal.UpdateMediatorProperties;
import com.ossnms.dcn_manager.commands.mediator.internal.UpdateMediatorProperties.Data;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.configuration.transformations.GetMediatorTypeName;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstanceCreateDescriptor;
import com.ossnms.dcn_manager.core.outbound.MediatorConnectionManager;
import com.ossnms.dcn_manager.core.policies.ChannelSchedulingConfiguration;
import com.ossnms.dcn_manager.core.policies.MediatorSchedulingConfiguration;
import com.ossnms.dcn_manager.core.properties.mediator.MediatorInstanceProperties;
import com.ossnms.dcn_manager.core.properties.mediator.MediatorProperties;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.MediatorManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.exceptions.DuplicatedHostException;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.IllegalChannelStateException;
import com.ossnms.dcn_manager.exceptions.IllegalMediatorStateException;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorTypeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static com.google.common.base.Strings.nullToEmpty;
import static com.ossnms.dcn_manager.bicnet.connector.facade.util.Exceptions.logAndRethrowAsBcb;
import static java.util.Comparator.comparing;

@Stateless(name = "MediatorServiceBean")
@Local(MediatorService.class)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class MediatorServiceBean implements MediatorService {

    private static final Logger LOGGER = LoggerFactory.getLogger(MediatorServiceBean.class);

    @Inject
    private StaticConfigurationSingleton configuration;

    @Inject @DcnManager
    private ChannelEntityRepository channelRepository;

    @Inject @DcnManager
    private MediatorInstanceEntityRepository mediatorInstanceRepository;

    @Inject @DcnManager
    private ChannelSchedulingConfiguration channelScheduling;

    @Inject @DcnManager
    private MediatorSchedulingConfiguration mediatorScheduling;

    @Inject
    private MediatorConnectionManager mediatorConnectionManager;

    @Inject
    private MediatorManagers mediatorManagers;

    @Inject
    private ChannelManagers channelManagers;

    @Inject
    private NetworkElementManagers neManagers;

    @Inject
    private LoggerManagerImpl loggerManager;

    @Inject @DcnManager
    private ISystemControlEjbFacade systemControlSupervision;
    
    @Inject @DcnManager
    private SettingsRepository settingsRepository;
    

    @Override
    public IMediator store(final ISessionContext context, final IMediator mediator, final Map<String, String> properties) throws BcbException {

        if (mediator.getMediatorType() == null) {
            throw new BcbException("Mediator type not set!");
        }

        try {
            final MediatorCreateDescriptor createDescriptor = buildMediatorCreateDescriptor(mediator);

            if (null != properties) {
                try {
                    final int activePriority = calculateActiveMediatorPriority(context);
                    final MediatorType type = findMediatorType(mediator);
                    new MediatorProperties().setProperties(type, createDescriptor.getInfoInitialData(), properties);
                    final MediatorInstanceProperties instanceProperties =
                            new MediatorInstanceProperties(Collections.emptyList(), activePriority);
                    for (Entry<String, String> entry : properties.entrySet()) {
                        instanceProperties.setProperty(entry.getKey(), entry.getValue());
                    }
                    createDescriptor.getInstanceCreateDescriptors().addAll(instanceProperties.getDataCreations());
                } catch (final InvalidMutationException | DataUpdateException e) {
                    throw logAndRethrowAsBcb(e, LOGGER);
                }
            }
            return createMediator(context, createDescriptor);

        } catch (final IllegalArgumentException e) { // thrown when mediator attributes are invalid
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    private int calculateActiveMediatorPriority(final ISessionContext context) throws BcbException {
        return systemControlSupervision.getSiteConfiguration(context) == ScsSiteConfiguration.SECONDARY
                ? MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1 : MediatorInstance.PRIMARY_PRIORITY_LEVEL;
    }

    private MediatorCreateDescriptor buildMediatorCreateDescriptor(IMediator mediator) {
        final String mediatorHost = nullToEmpty(mediator.getMediatorHost());
        final MediatorCreateDescriptor createDescriptor =
                new MediatorCreateDescriptor(
                        nullToEmpty(mediator.getIdName()),
                        mediator.getMediatorType().name());

        createDescriptor.getInfoInitialData().setReconnectAttemptInterval(mediator.getReconnectInterval());

        if (!mediatorHost.isEmpty()) {
            final MediatorInstanceCreateDescriptor primaryInstanceDescriptor = new MediatorInstanceCreateDescriptor(mediatorHost);
            primaryInstanceDescriptor.getConnectionInitialData().setActive(true);
            createDescriptor.getInstanceCreateDescriptors().add(primaryInstanceDescriptor);
        }
        return createDescriptor;
    }

    private MediatorType findMediatorType(IMediator mediator) throws BcbException {
        if (null == mediator.getMediatorType()) {
            throw new BcbException("No Mediator type specified.");
        }
        final String typeName = mediator.getMediatorType().name();
        final MediatorType type = configuration.getMediatorTypes().get(typeName);
        if (null == type) {
            throw new BcbException("Unknown Mediator type: " + typeName);
        }
        return type;
    }

    @Override
    public void updateProperties(final ISessionContext context, final IMediatorId mediatorId, final Map<String, String> changedProperties) throws BcbException {

        final int activePriority = calculateActiveMediatorPriority(context);
        String mediatorIdName;
        try {
            mediatorIdName = mediatorManagers.getMediatorRepository().queryMediatorName(mediatorId.getId()).orElse("Unknown");
        } catch (RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
        final UpdateMediatorProperties<BicnetCallContext> command =
                new UpdateMediatorProperties<>(new BicnetCallContext(context),
                        mediatorManagers, mediatorConnectionManager,
                        channelManagers, neManagers, 
                        mediatorScheduling, channelScheduling, 
                        configuration, loggerManager,
                        new Data(mediatorId.getId(), mediatorIdName, changedProperties, activePriority)
                );
        try {
            command.call();
        } catch (UnknownMediatorIdException | RepositoryException | UnknownMediatorTypeException
                | InvalidMutationException | DataUpdateException
                | DuplicatedObjectNameException | DuplicatedHostException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public Map<String, String> getProperties(final ISessionContext context, final IMediatorId mediatorId) throws BcbException {
        final GetMediator<BicnetCallContext> command =
                new GetMediator<>(new BicnetCallContext(context), mediatorManagers.getMediatorRepository(), mediatorId.getId());
        try {
            final MediatorEntity entity = command.call();
            final MediatorType type = configuration.getMediatorTypes().get(entity.getInfo().getTypeName());
            /*
             * We use streams here because there is no guarantee of mutability on maps returned by property APIs.
             * Hence we can't assume that we can merge one into the other. Another approach would be to create a
             * third mutable map and copy both into it, but this specific stream strategy will consider duplicate
             * property names as an error (as it should). Therefore the stream strategy was chosen.
             */
            return Stream.of(
                    new MediatorProperties().getProperties(type, entity),
                    MediatorInstanceProperties.getProperties(mediatorInstanceRepository.queryAll(entity.getInfo().getId())),
                    BicnetStandbyProperties.getProperties(context, systemControlSupervision),
                    BicnetConfigurationProperties.getProperties(configuration))
                    .map(Map::entrySet) // convert maps into entry sets
                    .flatMap(Collection::stream) // then each set into a stream and flatten all into a single stream.
                    .collect(Collectors.toMap(Entry::getKey, Entry::getValue)); // (throws an exception on duplicate keys)
        } catch (final UnknownMediatorIdException e) {
            LOGGER.warn("Requesting properties for unknown mediator ID {}", mediatorId);
            return null;
        } catch (final RepositoryException | IllegalStateException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public String[] getRegisteredMediatorTypes(final ISessionContext sessionContext) throws BcbException {
        final GetRegisteredMediators<BicnetCallContext> cmd = new GetRegisteredMediators<>(
                new BicnetCallContext(sessionContext), configuration);

        return cmd.call().stream()
                .map(new GetMediatorTypeName()::apply)
                .toArray(String[]::new);
    }

    @Override
    public IMediator getSingleMediator(final ISessionContext sessionContext, final IMediatorId mediatorId)
            throws BcbException {
        final GetMediator<BicnetCallContext> command =
                new GetMediator<>(new BicnetCallContext(sessionContext), mediatorManagers.getMediatorRepository(), mediatorId.getId());
        try {
            final MediatorEntity entity = command.call();
            final MediatorType type = configuration.getMediatorTypes().get(entity.getInfo().getTypeName());
            final Iterable<MediatorInstance> instances = mediatorInstanceRepository.queryAll(entity.getInfo().getId());
            return ConvertMediatorToBcb.convert(type, entity, instances);
        } catch (final UnknownMediatorIdException e) {
            LOGGER.warn("Requesting unknown mediator ID {}.", mediatorId);
            return null;
        } catch (final RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    private Stream<IMediator> getMediators(ISessionContext sessionContext, IMediatorId startAfter,
                                           IMediatorMarkable[] filter, int howMany) throws BcbException {
        final GetAllMediators<BicnetCallContext> command =
                new GetAllMediators<>(new BicnetCallContext(sessionContext), mediatorManagers.getMediatorRepository());
        try {
            return StreamSupport.stream(command.call().spliterator(), false)
                    .sorted(comparing(mediator -> mediator.getInfo().getId()))
                    .filter(m -> startAfter == null || m.getInfo().getId() > startAfter.getId())
                    .map(new PairMediatorWithTypeAndInstances(configuration, mediatorInstanceRepository))
                    .map(ConvertMediatorToBcb::convert)
                    .filter(mediator -> matchAny(mediator, filter))
                    .limit(howMany >= 0 ? howMany : Integer.MAX_VALUE);
        } catch (final RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    private boolean matchAny(IMediator mediator, IMediatorMarkable[] filter) {
        return filter == null || Stream.of(filter).anyMatch(markable -> MediatorElements.matchAll(mediator, markable));
    }

    @Override
    public Collection<FullMediatorData> getFullMediatorList(final ISessionContext sessionContext) throws BcbException {
        final GetAllMediators<BicnetCallContext> command =
                new GetAllMediators<>(new BicnetCallContext(sessionContext), mediatorManagers.getMediatorRepository());
        try {
            return toFullMediator(StreamSupport.stream(command.call().spliterator(), false))
                    .collect(Collectors.toList());
        } catch (final RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    public Stream<FullMediatorData> toFullMediator(Stream<MediatorEntity> mediators) {
        return mediators
                .map(new PairMediatorWithTypeAndInstances(configuration, mediatorInstanceRepository))
                .map(new ConvertMediatorToFullMediator());
    }

    @Override
    public FullMediatorData getFullMediator(ISessionContext sessionContext, Integer mediatorId) throws BcbException {
        GetMediator<BicnetCallContext> command = new GetMediator<>(new BicnetCallContext(sessionContext), mediatorManagers.getMediatorRepository(), mediatorId);
        try {
            MediatorEntity entity = command.call();
            return toFullMediator(entity == null ? Stream.empty() : Stream.of(entity))
                    .findAny().orElse(null);
        } catch (RepositoryException | UnknownMediatorIdException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public MediatorReply getMediatorList(final ISessionContext sessionContext, final IMediatorId startAfter,
                                         final IMediatorMarkable[] filter, final int howMany) throws BcbException {
        final Stream<IMediator> mediatorStream = getMediators(sessionContext, startAfter, filter, howMany);
        return new MediatorReply(mediatorStream.toArray(IMediator[]::new), true, null);
    }

    @Override
    public MediatorIdReply getMediatorIdList(final ISessionContext sessionContext,
                                             final IMediatorId startAfter, final IMediatorMarkable[] filter, final int howMany) throws BcbException {
        final Stream<IMediatorId> mediatorStream =
                getMediators(sessionContext, startAfter, filter, howMany)
                        .map(IMediator::getMediatorId);
        return new MediatorIdReply(mediatorStream.toArray(IMediatorId[]::new), true, null);

    }

    @Override
    public IMediator createMediator(final ISessionContext sessionContext, final IMediator mediator)
            throws BcbException {

        if (null == mediator.getMediatorType()) {
            throw new BcbException("A mediator must have a type!");
        }

        try {
            final MediatorCreateDescriptor createDescriptor = buildMediatorCreateDescriptor(mediator);
            return createMediator(sessionContext, createDescriptor);
        } catch (final IllegalArgumentException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    private IMediator createMediator(final ISessionContext sessionContext,
                                     final MediatorCreateDescriptor createDescriptor) throws BcbException {
        final CreateMediator<BicnetCallContext> command =
                new CreateMediator<>(new BicnetCallContext(sessionContext), mediatorManagers,
                        mediatorScheduling, configuration, loggerManager, createDescriptor);
        try {
            final MediatorEntity entity = command.call();
            final MediatorType type = configuration.getMediatorTypes().get(entity.getInfo().getTypeName());
            final Iterable<MediatorInstance> instances = mediatorInstanceRepository.queryAll(entity.getInfo().getId());
            return ConvertMediatorToBcb.convert(type, entity, instances);
        } catch (UnknownMediatorTypeException | CommandException | DuplicatedObjectNameException | DuplicatedHostException | RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public void deleteMediator(final ISessionContext sessionContext, final IMediatorId mediatorId) throws BcbException {
        deleteMediators(sessionContext, ImmutableList.of(mediatorId));
    }

    @Override
    public IMediatorMarkable modifyMediator(final ISessionContext sessionContext,
                                            final IMediatorMarkable mediator) throws BcbException {
        throw new BcbException("Not implemented");
    }

    @Override
    public void activateMediators(final ISessionContext sessionContext, final IMediatorId[] mediators)
            throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        for (final IMediatorId id : mediators) {
            final MediatorActivationRequired<BicnetCallContext> command =
                    new MediatorActivationRequired<>(context, id.getId(), mediatorManagers, loggerManager);
            try {
                command.call();
            } catch (IllegalMediatorStateException | UnknownMediatorIdException | RepositoryException e) {
                throw logAndRethrowAsBcb(e, LOGGER);
            }
        }
    }

    @Override
    public void deactivateMediators(final ISessionContext sessionContext, final IMediatorId[] mediators)
            throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        for (final IMediatorId id : mediators) {
            final MediatorDeactivationRequired<BicnetCallContext> command =
                    new MediatorDeactivationRequired<>(context, id.getId(), mediatorManagers, channelRepository, loggerManager);
            try {
                command.call();
            }
            catch (final IllegalMediatorStateException e) {
                // deactivation is idempotent
                LOGGER.warn("Deactivating already inactive Mediator with ID {}", id);
            } 
            catch (UnknownMediatorIdException | RepositoryException |  IllegalChannelStateException e) {
                throw logAndRethrowAsBcb(e, LOGGER);
            }
        }

    }

    @Override
    public void deactivateAllMediators(final ISessionContext sessionContext) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        for (final MediatorInfoData id : getAllMediatorInfo()) {
            final MediatorDeactivationRequired<BicnetCallContext> command =
                    new MediatorDeactivationRequired<>(context, id.getId(), mediatorManagers, channelRepository, loggerManager);
            try {
                command.call();
            } catch (final IllegalMediatorStateException ims) {
                // This mediator was already deactivated, which is a benign error that may result of a race condition.
                LOGGER.info("Illegal state on mediator {} while deactivating all mediators. {}",
                        id, ims.getMessage());
            } catch (UnknownMediatorIdException | IllegalChannelStateException | RepositoryException e) {
                throw logAndRethrowAsBcb(e, LOGGER);
            }
        }
    }

    private Iterable<MediatorInfoData> getAllMediatorInfo() throws BcbException {
        try {
            return mediatorManagers.getMediatorRepository().getMediatorInfoRepository().queryAll();
        } catch (final RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public void deleteMediators(final ISessionContext sessionContext, final Collection<IMediatorId> mediatorIds) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);

        for (final IMediatorId mediatorId : mediatorIds) {

            final DeleteMediator<BicnetCallContext> command = new DeleteMediator<>(context, mediatorManagers,
                    mediatorScheduling, channelRepository, loggerManager, mediatorId.getId());

            try {
                command.call();
            } catch (final UnknownMediatorIdException e) {
                LOGGER.warn("Trying to delete an unexistant Mediator with ID {}", mediatorId);
            } catch (RepositoryException | IllegalMediatorStateException e) {
                throw logAndRethrowAsBcb(e, LOGGER);
            }
        }
    }

    @Override
    public void activateMediatorsOnStandbyMediation(ISessionContext sessionContext, Collection<IMediatorId> mediatorIds) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);

        for (final IMediatorId mediatorId : mediatorIds) {

            final ActivateStandbyMediator<BicnetCallContext> command = new ActivateStandbyMediator<>(context, mediatorId.getId(), mediatorManagers, loggerManager, settingsRepository, configuration);

            try {
                command.call();
            } catch (final UnknownMediatorIdException e) {
                LOGGER.warn("Trying to activate an unexistant Mediator with ID {}", mediatorId);
            } catch (RepositoryException | IllegalMediatorStateException | CommandException e ) {
                throw logAndRethrowAsBcb(e, LOGGER);
            }

        }
    }

    @Override
    public void deactivateMediatorsOnStandbyMediation(ISessionContext sessionContext, Collection<IMediatorId> mediatorIds) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);

        for (final IMediatorId mediatorId : mediatorIds) {

            final DeactivateStandbyMediator<BicnetCallContext> command = new DeactivateStandbyMediator<>(context, mediatorId.getId(), mediatorManagers, loggerManager);

            try {
                command.call();
            } catch (final UnknownMediatorIdException e) {
                LOGGER.warn("Trying to deactivate an unexistant Mediator with ID {}", mediatorId);
            } catch (RepositoryException | IllegalMediatorStateException e) {
                throw logAndRethrowAsBcb(e, LOGGER);
            }

        }

    }
}
