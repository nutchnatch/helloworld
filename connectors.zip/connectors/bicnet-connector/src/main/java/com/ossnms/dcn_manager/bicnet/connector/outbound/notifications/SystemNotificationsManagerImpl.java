package com.ossnms.dcn_manager.bicnet.connector.outbound.notifications;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerMarkable;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertSystemContainerToBcb;
import com.ossnms.dcn_manager.composables.outbound.SecurityManager;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.events.system.SystemEvent;
import com.ossnms.dcn_manager.core.outbound.SystemNotifications;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

/**
 * Implements the bridge between our core and the BiCNet notifications service.
 * Handles only notifications about changes to the state of system containers.
 */
@ApplicationScoped public class SystemNotificationsManagerImpl extends NotificationsManagerBase<SystemEvent>
        implements SystemNotifications {

    @Inject private SecurityManager securityManager;

    @Override public void notifyDelete(SystemInfo system) {
        sendObjectDeletedNotification(new SystemContainerIdItem(system.getId()));
    }

    @Override public void notifyCreate(SystemInfo system) {
        sendObjectCreatedNotification(ConvertSystemContainerToBcb.convert(system));
    }

    @Override public void notifyChanges(SystemInfoMutationDescriptor changes) {
        final ISystemContainerMarkable markable = SystemContainerItem.markableSystemContainer(null);

        markable.setId(changes.getResult().getId());
        if (changes.getName().isPresent()) {
            markable.setIdName(changes.getName().get());
        }
        if (changes.getDescription().isPresent()) {
            markable.setDescription(changes.getDescription().get());
        }
        if (changes.getUserText().isPresent()) {
            markable.setUserLabel(changes.getUserText().get());
        }

        sendAttributeValueChangeNotification(markable);

        securityManager.updateSystem(changes.apply());
    }
}
