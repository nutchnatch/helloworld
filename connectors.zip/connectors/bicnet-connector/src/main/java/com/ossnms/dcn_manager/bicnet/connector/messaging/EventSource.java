package com.ossnms.dcn_manager.bicnet.connector.messaging;

import javax.ejb.Local;

import rx.Observable;

@Local
public interface EventSource<T> {

    void subscribe(Observable<DecoratedNotification> notificationSource);

    Observable<T> observe();

}