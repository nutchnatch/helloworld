package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.google.common.base.Predicate;
import com.google.common.base.Strings;
import com.ossnms.bicnet.bcb.model.common.Property;

/**
 * Filter for avoiding sending properties without values.
 */
public class NonEmptyBcbProperty implements Predicate<Property> {

    @Override
    public boolean apply(Property input) {
        return null != input && !Strings.isNullOrEmpty(input.getValue());
    }

}
