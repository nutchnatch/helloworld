package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.google.common.base.Function;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;

/**
 * Handles conversion of internal domain entities representing a System Container to its
 * corresponding type in the BCB object model.
 */
public class ConvertSystemContainerToBcb implements Function<SystemInfo, ISystemContainer> {

    /**
     * Converts internal domain entities representing a System Container to a
     * {@link ISystemContainer} BCB object.
     *
     * @param entity System Container entity instance that will be the source of data.
     * @return A new instance of {@link ISystemContainer} filled with data.
     */
    public static ISystemContainer convert(SystemInfo entity) {
        final ISystemContainer system = new SystemContainerItem();
        fillExisting(entity, system);
        return system;
    }

    /**
     * Fills an existing {@link ISystemContainer} BCB object with information from our domain entity.
     *
     * @param entity System Container entity instance that will be the source of data.
     * @param system An instance of {@link ISystemContainer} to be filled with data.
     */
    public static void fillExisting(SystemInfo entity, ISystemContainer system) {
        system.setId(entity.getId());
        system.setIdName(entity.getName());
        system.setDescription(entity.getDescription().orElse(null));
        system.setUserLabel(entity.getUserText().orElse(null));
    }

    @Override
    public ISystemContainer apply(SystemInfo input) {
        return null != input ? convert(input) : null;
    }

}
