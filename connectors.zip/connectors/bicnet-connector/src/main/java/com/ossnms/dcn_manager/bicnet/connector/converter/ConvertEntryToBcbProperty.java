package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.google.common.base.Function;
import com.ossnms.bicnet.bcb.model.common.Property;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Map.Entry;

/**
 * Converts Map.Entry to BCB Property.
 */
public class ConvertEntryToBcbProperty implements Function<Entry<String, String>, Property> {

    /**
     * @param input Map Entry
     * @return BCB Property class
     */
    public static Property convert(@Nonnull Entry<String, String> input) {
        return new Property(input.getKey(), input.getValue());
    }

    /**
     * @see Function#apply(Object)
     */
    @Override
    @Nullable
    public Property apply(@Nullable Entry<String, String> input) {
        return input == null ? null : convert(input);
    }
}
