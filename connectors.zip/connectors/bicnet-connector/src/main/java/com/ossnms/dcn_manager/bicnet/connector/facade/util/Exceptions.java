package com.ossnms.dcn_manager.bicnet.connector.facade.util;

import javax.annotation.Nonnull;

import org.slf4j.Logger;

import com.google.common.base.Throwables;
import com.ossnms.bicnet.bcb.model.BcbException;

/**
 * Contains utilities to deal with exceptions.
 */
public final class Exceptions {

    private Exceptions() {

    }

    /**
     * </p>Given an internal exception, throw a BCB Exception with the same stack trace and message
     * but without using it as a cause. Instead log that the BCB Exception cause was dropped.</p>
     *
     * <p>The rationale is that we can't propagate internal exception classes through the BCB bus.
     * Clients will be unable to deserialize the entire exception chain and error handling
     * will be impossible.</p>
     *
     * <p>Usage:</p>
     * <pre>
     * try {
     *
     * } catch (Exception e) {
     *     throw logAndRethrowAsBcb(e, logger);
     * }
     * </pre>
     *
     * @param original Original (cause) exception.
     * @param logger SLF4J logger that will report the dropped exception.
     * @return Nothing. The signature only declares a return value to make the Java compiler happy.
     * @throws BcbException Always, with the same message and stack trace as the original exception.
     */
    public static BcbException logAndRethrowAsBcb(@Nonnull Exception original, @Nonnull Logger logger) throws BcbException {
        final BcbException bcbException = new BcbException(original.getMessage());
        bcbException.setStackTrace(original.getStackTrace());
        logger.warn("Exception cause dropped [cause.class: {}; cause.message: \"{}\"] {}",
                original.getClass().getName(), original.getMessage(), Throwables.getStackTraceAsString(original));
        throw bcbException;
    }
}
