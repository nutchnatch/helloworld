package com.ossnms.dcn_manager.bicnet.connector.messaging.ne;

import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.elementMgmt.INeConfigurationCounterPkgMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementProxy;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementProxyId;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementProxyMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.InitState;
import com.ossnms.bicnet.bcb.model.elementMgmt.NePropertiesChanged;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.bicnet.bcb.model.platform.ObjectDeletion;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertBcbPropertyToMap;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.messaging.DecoratedNotification;
import com.ossnms.dcn_manager.bicnet.connector.messaging.EventSource;
import com.ossnms.dcn_manager.bicnet.connector.messaging.MessageSourceImpl;
import com.ossnms.dcn_manager.bicnet.connector.messaging.ObservableTools;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaNetworkElementRepositoryBean;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.events.ne.NeInfoDataChangedEvent;
import com.ossnms.dcn_manager.core.events.ne.NePhysicalSynchronizationCountersChangedEvent;
import com.ossnms.dcn_manager.core.events.ne.NePropertiesChangedEvent;
import com.ossnms.dcn_manager.core.events.ne.NeTypeChangedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeRestartRequestEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeConnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeConnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeDisconnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeDisconnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeInitializedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeInitializingEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeSynchronizationLostEvent;
import org.slf4j.Logger;
import rx.Observable;
import rx.Observable.Operator;
import rx.Subscriber;
import rx.functions.Func1;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.NotThreadSafe;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Stream;

import static org.slf4j.LoggerFactory.getLogger;

;

/**
 * Transforms AttributeValueChange notifications related to NEs into a stream
 * of DCN Manager core events.
 */
@ApplicationScoped
public class NeEventSource
    extends MessageSourceImpl<NeEvent>
    implements EventSource<NeEvent> {

    private static final Logger LOGGER = getLogger(NeEventSource.class);

    @Inject @DcnManager
    private JpaNetworkElementRepositoryBean neRepository;

    @Inject
    private StaticConfiguration configuration;

    /**
     * <p>Subscribes to a stream of BiCNet notifications. This stream is then transformed
     * into the corresponding NE Events that are supported by the DCN Manager Core.</p>
     *
     * <p>Not only event ordering is important, but it is also important to realize that
     * one Markable may generate more than one NE Event.</p>
     *
     * <p>The solution for the event ordering problem is identical to the one described
     * in {@link com.ossnms.dcn_manager.bicnet.connector.messaging.ChannelEventSource#subscribe(Observable)}.</p>
     *
     * <p>Because more than one NE Event may be generated from a single BiCNet notification,
     * we chose to create a data structure that is used throughout the stream transformation.
     * This data structure contains the original notification and the list of NE Events that it
     * originated. At the end of the stream transformation, a custom {@link Operator}
     * will emit the NE events. The wrapper and the original notification are thus discarded.</p>
     */
    @Override
    public void subscribe(@Nonnull Observable<DecoratedNotification> notificationSource) {

        LOGGER.debug("Initializing NE event subscriptions.");

        final Observable<NeEvent> neEvents =
            notificationSource
                .filter(this::filterOutNotificationsForInactiveNEs) // drop notifications for NE connections that are INACTIVE
                .map(NotificationWrapper::new)
                .lift(mapNeDeleted())
                .lift(mapNeOperationInfoChanged(neRepository, configuration))
                .lift(mapNePropertiesChanged())
                .lift(mapAvcIf(this::toPhysicalNeActivationFailedEvent, isFailedState()))
                .lift(mapAvcIf(this::toPhysicalNeSynchronizationLostEvent, initStateIs(InitState.NOT_SYNCHRONIZED)))
                .lift(mapAvcIf(this::toPhysicalNeConnectingEvent, connectionStateIs(CommunicationState.CONNECTING)))
                .lift(mapAvcIf(this::toPhysicalNeConnectedEvent, connectionStateIs(CommunicationState.CONNECTED)))
                .lift(mapAvcIf(this::toPhysicalNeDisconnectingEvent, connectionStateIs(CommunicationState.DISCONNECTING)))
                .lift(mapAvcIf(this::toPhysicalNeDisconnectedEvent, connectionStateIs(CommunicationState.DISCONNECTED)))
                .lift(mapAvcIf(this::toPhysicalNeInitializingEvent, initStateIs(InitState.INITIALIZING)))
                .lift(mapAvcIf(this::toPhysicalNeInitializedEvent, initStateIs(InitState.INITIALIZED)))
                    // leave NE Synchronization Counters events at the bottom of the chain so they will not
                    // cause side effects on the processing of initializations.
                .lift(mapAvcIf(this::toNeSynchronizationCountersChangedEvent, this::isConfigurationCounterAvc))
                .lift(mapNeTypeChanged())
                .lift(mapNeInfoDataChanged())
                .lift(mapNeRestartRequest())
                .lift(new EmitInnerEvents());

        chain(neEvents);
    }

    private boolean filterOutNotificationsForInactiveNEs(DecoratedNotification notification) {
        final boolean processNotification =
            notification.getOriginatingPhysicalNe()
                .map(physicalConnection -> physicalConnection.getActualActivationState() != ActualActivationState.DISCONNECTED)
                .orElse(false);
        if (!processNotification) {
            LOGGER.info("Dropping notification {} for inactive NE connection!", notification);
        }
        return processNotification;
    }

    private Optional<PhysicalNeSynchronizationLostEvent> toPhysicalNeSynchronizationLostEvent(DecoratedNotification n) {
        return n.getOriginatingPhysicalNe()
                .map(ne -> new PhysicalNeSynchronizationLostEvent(ne.getId(), ne.getLogicalNeId(), ne.isActive(), gatherSynchronizationCounters(n)));
    }

    /**
     * Generates a PhysicalNeActivationFailed event.
     */
    private Optional<PhysicalNeActivationFailedEvent> toPhysicalNeActivationFailedEvent(DecoratedNotification n) {
        return n.getOriginatingPhysicalNe()
                .map(ne -> new PhysicalNeActivationFailedEvent(ne.getId(), ne.getLogicalNeId(), ne.isActive(),
                        n.getAffectedObject(INetworkElementProxy.class)
                            .map(proxy -> Strings.nullToEmpty(proxy.getCommunicationStateAdditionalInfo()))
                            .orElse("")));
    }

    /**
     * Generates a PhysicalNeConnecting event.
     */
    private Optional<PhysicalNeConnectingEvent> toPhysicalNeConnectingEvent(DecoratedNotification n) {
        return n.getOriginatingPhysicalNe()
                .map(ne -> new PhysicalNeConnectingEvent(ne.getId(), ne.getLogicalNeId(), ne.isActive()));
    }

    /**
     * Generates a PhysicalNeConnected event.
     */
    private Optional<PhysicalNeConnectedEvent> toPhysicalNeConnectedEvent(DecoratedNotification n) {
        return n.getOriginatingPhysicalNe()
                .map(ne -> new PhysicalNeConnectedEvent(ne.getId(), ne.getLogicalNeId(), ne.isActive()));
    }

    /**
     * Generates a PhysicalNeDisconnecting event.
     */
    private Optional<PhysicalNeDisconnectingEvent> toPhysicalNeDisconnectingEvent(DecoratedNotification n) {
        return n.getOriginatingPhysicalNe()
                .map(ne -> new PhysicalNeDisconnectingEvent(ne.getId(), ne.getLogicalNeId(), ne.isActive()));
    }

    /**
     * Generates a PhysicalNeDisconnected event.
     */
    private Optional<PhysicalNeDisconnectedEvent> toPhysicalNeDisconnectedEvent(DecoratedNotification n) {
        return n.getOriginatingPhysicalNe()
                .map(ne -> new PhysicalNeDisconnectedEvent(ne.getId(), ne.getLogicalNeId(), ne.isActive()));
    }

    /**
     * Generates a PhysicalNeInitializing event.
     */
    private Optional<PhysicalNeInitializingEvent> toPhysicalNeInitializingEvent(DecoratedNotification n) {
        return n.getOriginatingPhysicalNe()
                .map(ne -> new PhysicalNeInitializingEvent(ne.getId(), ne.getLogicalNeId(), ne.isActive()));
    }

    /**
     * Generates a PhysicalNeInitialized event.
     */
    private Optional<PhysicalNeInitializedEvent> toPhysicalNeInitializedEvent(DecoratedNotification n) {
        return n.getOriginatingPhysicalNe()
                .map(ne -> new PhysicalNeInitializedEvent(ne.getId(), ne.getLogicalNeId(), ne.isActive(), gatherSynchronizationCounters(n)));
    }

    private NeSynchronizationData gatherSynchronizationCounters(DecoratedNotification n) {
        return n.getAffectedObject(INetworkElementProxy.class)
                .map(m -> (INeConfigurationCounterPkgMarkable) m.getFacette(INeConfigurationCounterPkgMarkable.class))
                .map(facette -> toNeSynchronizationData(n, facette))
                .orElse(null);
    }

    private NeSynchronizationData toNeSynchronizationData(DecoratedNotification n, INeConfigurationCounterPkgMarkable facette) {
        return new NeSynchronizationData.NeSynchronizationBuilder()
            .setAlarms(facette.isMarkedAlarmsCategoryCounterHash() ? map(facette.getAlarmsCategoryCounterHash()) : Optional.empty())
            .setAll(facette.isMarkedAllCategoryCounterHash() ? map(facette.getAllCategoryCounterHash()) : Optional.empty())
            .setPacket(facette.isMarkedPacketCategoryCounterHash() ? map(facette.getPacketCategoryCounterHash()) : Optional.empty())
            .build(n.getOriginatingPhysicalNe().map(NePhysicalConnectionData::getLogicalNeId).orElse(0), 0);
    }

    /**
     * If this is a BiCNet NePropertiesChanged event, append a NePropertiesChanged event to the notification wrapper.
     */
    private Operator<NotificationWrapper, NotificationWrapper> mapNePropertiesChanged() {
        return ObservableTools.<NotificationWrapper, NotificationWrapper>
        when(n -> n.getNotification().getNotification(NePropertiesChanged.class).isPresent())
            .and(this::isActiveNeInstance)
            .map(n -> appendEvent(n,
                    ne -> Optional.of(
                        new NePropertiesChangedEvent(ne.getLogicalNeId(),
                            ImmutableMap.copyOf(ConvertBcbPropertyToMap.convert(
                                    n.getNotification().getNotification(NePropertiesChanged.class)
                                        .map(NePropertiesChanged::getChangedProperties)
                                        .orElseGet(() -> new Property[0])))))));
    }

    /**
     * If this is a BiCNet NePropertiesChanged event with the special RESTART_NE property set, append a
     * NeRestartRequest event to the notification wrapper.
     */
    private Operator<NotificationWrapper, NotificationWrapper> mapNeRestartRequest() {
        return ObservableTools.<NotificationWrapper, NotificationWrapper>
                when(this::isRestartPropertyPresent)
                .map(n -> appendEvent(n, ne -> Optional.of(new PhysicalNeRestartRequestEvent(ne.getLogicalNeId(), ne.getId()))));
    }

    private boolean isRestartPropertyPresent(NotificationWrapper wrapper) {
        return wrapper.getNotification().getNotification(NePropertiesChanged.class)
                .map(NePropertiesChanged::getChangedProperties)
                .filter(props -> props != null)
                .map(Arrays::stream)
                .map(prefs -> prefs.filter(property -> WellKnownNePropertyNames.RESTART_NE.equals(property.getName()) && "RESTART".equals(property.getValue())))
                .map(Stream::findFirst)
                .map(Optional::isPresent)
                .orElse(false);
    }

    /**
     * If this is an AttributeValueChange against a NetworkElement, append a NeOperationInfoChanged event to the notification wrapper.
     */
    private Operator<NotificationWrapper, NotificationWrapper> mapNeOperationInfoChanged(JpaNetworkElementRepositoryBean neRepository, StaticConfiguration configuration ) {
        return ObservableTools.<NotificationWrapper, NotificationWrapper>
        when(this::isNeAvc)
            .and(this::isActiveNeInstance)
            .map(n -> appendEvent(n,
                    ne -> Optional.of(new NeOperationInfoChanged(neRepository, configuration).call(n.getNotification().getNotification(AttributeValueChange.class).get()))));
    }

    /**
     * If this is an ObjectDeletion against a NetworkElementProxy, append a NeDisconnected event to the notification wrapper.
     */
    private Operator<NotificationWrapper, NotificationWrapper> mapNeDeleted() {
        return ObservableTools.<NotificationWrapper, NotificationWrapper>
            when(n -> n.getNotification().getNotification(ObjectDeletion.class)
                    .map(od -> od.getDeletedObject() instanceof INetworkElementProxyId)
                    .orElse(false))
                .map(n -> appendEvent(n, ne -> Optional.of(new PhysicalNeDisconnectedEvent(ne.getId(), ne.getLogicalNeId(), ne.isActive()))));
    }

    private Operator<NotificationWrapper, NotificationWrapper> mapNeTypeChanged() {
        return ObservableTools.<NotificationWrapper, NotificationWrapper>
            when(this::isNeProxyAvc)
                .and(this::isActiveNeInstance)
                .and(this::isNeTypeAvc)
                .map(w -> appendEvent(w, ne ->
                    w.getNotification().getAffectedObject(INetworkElementProxyMarkable.class)
                        .map(m -> new NeTypeChangedEvent(ne.getLogicalNeId(), m.getType()))));
    }

    private Operator<NotificationWrapper, NotificationWrapper> mapNeInfoDataChanged(){
        return ObservableTools.<NotificationWrapper, NotificationWrapper>
            when(this::isNeProxyAvc)
                .and(this::isActiveNeInstance)
                .and(this::isIconTypeAvc)
                .map(w -> appendEvent(w, ne ->
                    w.getNotification().getAffectedObject(INetworkElementProxyMarkable.class)
                        .map(m -> new NeInfoDataChangedEvent(ne.getLogicalNeId(), m.getIconIdId()))));
    }

    /**
     * Predicate used to determine whether this is an Attribute Value Change against a Network Element object.
     */
    private boolean isNeAvc(NotificationWrapper wrapper) {
        return wrapper.getNotification().getNotification(AttributeValueChange.class)
                .map(n -> n.getChangedObject() instanceof INetworkElementMarkable)
                .orElse(false);
    }

    /**
     * Predicate used to determine whether this is an Attribute Value Change against a Network Element Proxy object.
     */
    private boolean isNeProxyAvc(NotificationWrapper wrapper) {
        return wrapper.getNotification().getNotification(AttributeValueChange.class)
                .map(n -> n.getChangedObject() instanceof INetworkElementProxyMarkable)
                .orElse(false);
    }

    /**
     * Predicate used to determine whether this event applies to an Active physical NE instance (in the context of standby).
     */
    private boolean isActiveNeInstance(NotificationWrapper wrapper) {
        return isActiveNeInstance(wrapper.getNotification());
    }

    /**
     * Predicate used to determine whether this event applies to an Active physical NE instance (in the context of standby).
     */
    private boolean isActiveNeInstance(DecoratedNotification notification) {
        return notification.getOriginatingPhysicalNe()
                .map(NePhysicalConnectionData::isActive)
                .orElse(false);
    }

    /**
     * Is this an Attribute Value Change against attributes in the INeConfigurationCounterPkgMarkable facette?
     */
    private boolean isConfigurationCounterAvc(INetworkElementProxyMarkable proxyMarkable) {
        final INeConfigurationCounterPkgMarkable facette =
                (INeConfigurationCounterPkgMarkable) proxyMarkable.getFacette(INeConfigurationCounterPkgMarkable.class);
        return facette != null &&
            (facette.isMarkedAlarmsCategoryCounterHash() || facette.isMarkedAllCategoryCounterHash() || facette.isMarkedPacketCategoryCounterHash());
    }

    /**
     * Is this an Attribute Value Change against the NE type?
     */
    private boolean isNeTypeAvc(NotificationWrapper w) {
        return w.getNotification().getAffectedObject(INetworkElementProxyMarkable.class)
                .map(t1 -> t1.isMarkedType() && null != t1.getType())
                .orElse(false);
    }

    /**
     * Check if this is an Attribute Value Change against IconId.
     * @param w notification wrapper
     * @return true if it is an Attribute Value Change against IconId, or false otherwise.
     */
    private boolean isIconTypeAvc(NotificationWrapper w) {
        return w.getNotification().getAffectedObject(INetworkElementProxyMarkable.class)
                .map(o1 -> o1.isMarkedIconIdId() && null != o1.getIconIdId())
                .orElse(false);
    }

    /**
     * Generates a NeSynchronizationCountersChanged event.
     */
    private Optional<NePhysicalSynchronizationCountersChangedEvent> toNeSynchronizationCountersChangedEvent(DecoratedNotification n) {
        if (!isActiveNeInstance(n)) {
            return Optional.empty();
        }
        return n.getAffectedObject(INetworkElementProxy.class)
            .map(m -> (INeConfigurationCounterPkgMarkable) m.getFacette(INeConfigurationCounterPkgMarkable.class))
            .flatMap(facette -> toNeSynchronizationCountersChangedEvent(n, facette));
    }

    private Optional<NePhysicalSynchronizationCountersChangedEvent> toNeSynchronizationCountersChangedEvent(DecoratedNotification n, INeConfigurationCounterPkgMarkable facette) {
        return n.getOriginatingPhysicalNe()
            .map(ne -> new NePhysicalSynchronizationCountersChangedEvent(ne.getId(), ne.getLogicalNeId(),
                    facette.isMarkedAllCategoryCounterHash() ? map(facette.getAllCategoryCounterHash()) : Optional.empty(),
                    facette.isMarkedAlarmsCategoryCounterHash() ? map(facette.getAlarmsCategoryCounterHash()) : Optional.empty(),
                    facette.isMarkedPacketCategoryCounterHash() ? map(facette.getPacketCategoryCounterHash()) : Optional.empty()));
    }

    private Optional<Long> map(long value) {
        return Optional.of(value);
    }

    private Operator<? extends NotificationWrapper, ? super NotificationWrapper> mapAvcIf(
            Function<DecoratedNotification, Optional<? extends NeEvent>> mapper, Func1<INetworkElementProxyMarkable, Boolean> predicate) {
        return ObservableTools.<NotificationWrapper, NotificationWrapper>
            when(this::isNeProxyAvc)
                .and(w -> w.getNotification().getAffectedObject(INetworkElementProxyMarkable.class).map(predicate::call).orElse(false))
                .map(w -> {
                    mapper.apply(w.getNotification()).ifPresent(w::addEvent);
                    return w;
                });
    }

    private static ConnectionStateIs connectionStateIs(CommunicationState desiredState) {
        return new ConnectionStateIs(desiredState);
    }

    private static InitializationStateIs initStateIs(InitState desiredState) {
        return new InitializationStateIs(desiredState);
    }

    private static IsFailedState isFailedState() {
        return new IsFailedState();
    }

    /**
     * Appends a new event to a notification wrapper.
     */
    private NotificationWrapper appendEvent(NotificationWrapper w, Function<NePhysicalConnectionData, Optional<NeEvent>> eventCreator) {
        w.getNotification().getOriginatingPhysicalNe()
            .ifPresent(ne -> eventCreator.apply(ne).ifPresent(w::addEvent));
        return w;
    }


    /**
     * <p>Notification handling data object, containing the original BiCNet notification
     * and a list of all internal events it has generated.</p>
     *
     * <p>Note that this is not thread safe. It relies on the general reactive contract,
     * according to which concurrent onNext() calls are forbidden. It also relies on the
     * fact that it is only used as an intermediate data structure within a
     */
    @NotThreadSafe
    private static final class NotificationWrapper {
        private static final int MAXIMUM_DERIVED_EVENTS_EXPECTED = 3;

        private final DecoratedNotification notification;
        private final List<NeEvent> events;

        private NotificationWrapper(DecoratedNotification notification) {
            this.notification = notification;
            this.events = new ArrayList<>(MAXIMUM_DERIVED_EVENTS_EXPECTED);
        }

        private DecoratedNotification getNotification() {
            return notification;
        }

        private List<NeEvent> getEvents() {
            return events;
        }

        private NotificationWrapper addEvent(NeEvent event) {
            events.add(event);
            return this;
        }
    }

    /**
     * Emits all internal events generated from a BiCNet notification.
     * Does not support backpressure.
     */
    private static final class EmitInnerEvents
            implements Operator<NeEvent, NotificationWrapper> {

        @Override
        public Subscriber<? super NotificationWrapper> call(final Subscriber<? super NeEvent> child) {
            return new InnerEventsSubscriber(child);
        }

        private static final class InnerEventsSubscriber extends Subscriber<NotificationWrapper> {

            private final Subscriber<? super NeEvent> child;

            private InnerEventsSubscriber(Subscriber<? super NeEvent> child) {
                this.child = child;
            }

            @Override
            public void onCompleted() {
                if (!child.isUnsubscribed()) {
                    child.onCompleted();
                }
            }

            @Override
            public void onError(Throwable e) {
                if (!child.isUnsubscribed()) {
                    child.onError(e);
                }
            }

            @Override
            public void onNext(NotificationWrapper wrapper) {
                for (final NeEvent event : wrapper.getEvents()) {
                    if (child.isUnsubscribed()) {
                        return;
                    }
                    child.onNext(event);
                }
            }
        }
    }
}
