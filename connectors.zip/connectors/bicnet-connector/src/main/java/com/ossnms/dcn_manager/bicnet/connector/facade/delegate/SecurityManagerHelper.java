package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.ossnms.bicnet.bcb.facade.security.ISecurityManageable;
import com.ossnms.bicnet.bcb.model.security.ISecurableObject;
import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.outbound.SecurityManagerImpl;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import java.util.stream.StreamSupport;

/**
 * Provides a list of secure operations and managed object identifiers
 * for security management.
 * @see ISecurityManageable
 */
public class SecurityManagerHelper implements ISecurityManageable {

    private static final Logger LOGGER = LoggerFactory.getLogger(SecurityManagerHelper.class);

    private final NeEntityRepository neRepository;
    private final SecurityManagerImpl securityManager;

    @Inject
    public SecurityManagerHelper(
            @DcnManager NeEntityRepository neRepository,
            SecurityManagerImpl securityManager) {
        this.neRepository = neRepository;
        this.securityManager = securityManager;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Nonnull
    public String[] getOperations() {
        return SecureAction.getIdentifiers();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ISecurableObject[] getSecurableObjects() {
        /*
         * Report NEs only.
         */
        try {
            return StreamSupport.stream(neRepository.queryAll().spliterator(), false)
                    .map(securityManager::buildSecurableObject).toArray(ISecurableObject[]::new);
        } catch (final RepositoryException e) {
            LOGGER.error("Failed to obtain a list of securable objects.", e);
            return new ISecurableObject[0];
        }
    }
}
