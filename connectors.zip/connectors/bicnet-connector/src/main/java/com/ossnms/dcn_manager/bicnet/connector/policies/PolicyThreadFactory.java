package com.ossnms.dcn_manager.bicnet.connector.policies;

import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;

import javax.annotation.Resource;
import javax.enterprise.concurrent.ManagedThreadFactory;
import java.util.concurrent.ThreadFactory;

/**
 * Class that implements a thread factory to be used for custom policies.
 *
 * Instances have the default scope (i.e. @Dependent).
 *
 * The current implementation simply forwards execution to a thread factory
 * managed by the application server.
 */
@DcnManager
public class PolicyThreadFactory implements ThreadFactory {

    /** The thread factory instance to be used to create new threads for custom execution policies. */
    @Resource(lookup = "java:jboss/ee/concurrency/factory/dcnManager")
    private ManagedThreadFactory managedThreadFactory;

    @Override
    public Thread newThread(Runnable r) {
        return managedThreadFactory.newThread(r);
    }
}
