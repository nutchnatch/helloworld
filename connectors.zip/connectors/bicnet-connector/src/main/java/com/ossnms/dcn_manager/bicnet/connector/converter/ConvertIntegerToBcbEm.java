package com.ossnms.dcn_manager.bicnet.connector.converter;

import javax.annotation.Nullable;

import com.google.common.base.Function;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;

/**
 * Converts a Channel Id to BCB IEM.
 */
public class ConvertIntegerToBcbEm implements Function<Integer, IEM> {

    /**
     * @param input The Channel Id.
     * @return IEM with only the key setted.
     */
    public static IEM convert(int input) {
        final IEM emItem = new EMItem();
        emItem.setId(input);
        
        return emItem;
    }
    
    /**
     * @see Function#apply(Object)
     */
    @Override
    public IEM apply(@Nullable Integer input) {
        return input == null ? null  : convert(input);
    }    
}