package com.ossnms.dcn_manager.bicnet.connector.converter;

import java.util.Date;

import javax.annotation.Nullable;

import com.google.common.base.Function;
import com.ossnms.bicnet.bcb.facade.logMgmt.LogIdItem;
import com.ossnms.bicnet.bcb.facade.logMgmt.NeEventLogRecordItem;
import com.ossnms.bicnet.bcb.model.elementMgmt.ObjectTemplate;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogId;
import com.ossnms.bicnet.bcb.model.logMgmt.ILogRecord;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;

/**
 * Converts the {@link LoggerItemNe} to BCB {@link NeEventLogRecordItem}
 */
public class ConvertLoggerToNetworkEventLog implements Function<LoggerItemNe, ILogRecord> {

    protected static final ILogId LOG_EVENT_ID = new LogIdItem("Network Event Log");
    private static final ObjectTemplate LOG_OBJ_TEMPLATE = ObjectTemplate.fromName("ne");

    private final String userName;

    public ConvertLoggerToNetworkEventLog(@Nullable String userName) {
        super();
        this.userName = userName;
    }

    public NeEventLogRecordItem convert(LoggerItemNe input) {

        final NeEventLogRecordItem logRecord = new NeEventLogRecordItem();

        logRecord.setBelonging(LOG_EVENT_ID);
        logRecord.setBelongingName(LOG_EVENT_ID.getName());
        logRecord.setAffectedObjectType(LOG_OBJ_TEMPLATE);

        logRecord.setTimeStamp(new Date());

        logRecord.setAffectedNe(input.getAffectedObjectId());
        logRecord.setAffectedNeName(input.getAffectedObject());

        logRecord.setUserName(userName);
        logRecord.setDescription(input.getMessage());

        return logRecord;
    }

    /**
     * @see Function#apply(Object)
     */
    @Override
    public ILogRecord apply(LoggerItemNe input) {
        return input == null ? null : convert(input);
    }
}
