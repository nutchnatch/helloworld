package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.ossnms.dcn_manager.core.events.Event;
import com.ossnms.dcn_manager.core.events.channel.ChannelEvent;
import com.ossnms.dcn_manager.core.events.domain.DomainEvent;
import com.ossnms.dcn_manager.core.events.mediator.MediatorEvent;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.events.periodic.PeriodicEvent;
import rx.Subscription;
import rx.observables.ConnectableObservable;

import javax.annotation.Nonnull;
import javax.enterprise.context.ApplicationScoped;
import java.util.ArrayList;
import java.util.List;

/**
 * Component life cycle information. Must be application scoped because it stores the current life cycle
 * stage and all data associated with it. Specifically, whether we are started and the event subscriptions.
 */
@ApplicationScoped
public class ServiceControlHelperData {

    private static final int SUBSCRIPTION_COUNT = 4;

    private ConnectableObservable<Event> discoveryEventSource;
    private ConnectableObservable<MediatorEvent> mediatorEventSource;
    private ConnectableObservable<ChannelEvent> channelEventSource;
    private ConnectableObservable<NeEvent> neEventSource;
    private ConnectableObservable<PeriodicEvent> periodicEventsSource;
    private ConnectableObservable<DomainEvent> domainEventsSource;

    private final List<Subscription> eventSubscriptions = new ArrayList<>(SUBSCRIPTION_COUNT);

    private volatile boolean componentStarted;


    /**
     * @param discoveryEventSource Source of internal NE Discovery events, converted from BiCNet messages. Created upon initialization.
     * @param mediatorEventSource Source of internal Mediator events, converted from BiCNet messages. Created upon initialization.
     * @param channelEventSource Source of internal Channel events, converted from BiCNet messages. Created upon initialization.
     * @param neEventSource Source of internal NE events, converted from BiCNet messages. Created upon initialization.
     * @param periodicEventsSource Source of periodic (timed) events. Created upon initialization.
     * @param domainEventsSource Source of internal domain events, converted from BiCNet messages. Created upon initialization.
     */
    public void setCoreEventSources(
            @Nonnull ConnectableObservable<Event> discoveryEventSource,
            @Nonnull ConnectableObservable<MediatorEvent> mediatorEventSource,
            @Nonnull ConnectableObservable<ChannelEvent> channelEventSource,
            @Nonnull ConnectableObservable<NeEvent> neEventSource,
            @Nonnull ConnectableObservable<PeriodicEvent> periodicEventsSource,
            @Nonnull ConnectableObservable<DomainEvent> domainEventsSource) {
        this.discoveryEventSource = discoveryEventSource;
        this.mediatorEventSource = mediatorEventSource;
        this.channelEventSource = channelEventSource;
        this.neEventSource = neEventSource;
        this.periodicEventsSource = periodicEventsSource;
        this.domainEventsSource = domainEventsSource;
    }
    /**
     * @return Whether start() has been called already.
     */
    public boolean isComponentStarted() {
        return componentStarted;
    }
    /**
     * @param componentStarted Whether start() has been called already.
     */
    public void setComponentStarted(boolean componentStarted) {
        this.componentStarted = componentStarted;
    }
    /**
     * Disconnects from the internal event source.
     */
    public void unsubscribeFromEvents() {
        eventSubscriptions.forEach(Subscription::unsubscribe);
        eventSubscriptions.clear();
    }
    /**
     * Subscription to internal events, created upon startup and disconnected upon shutdown.
     */
    public void subscribeToEvents() {
        eventSubscriptions.add(discoveryEventSource.connect());
        eventSubscriptions.add(mediatorEventSource.connect());
        eventSubscriptions.add(channelEventSource.connect());
        eventSubscriptions.add(neEventSource.connect());
        eventSubscriptions.add(periodicEventsSource.connect());
        eventSubscriptions.add(domainEventsSource.connect());
    }
    /**
     * @return Source of internal NE Discovery events, converted from BiCNet messages.
     * Set through {@link #setCoreEventSources(ConnectableObservable, ConnectableObservable, ConnectableObservable, ConnectableObservable, ConnectableObservable, ConnectableObservable)}.
     */
    public ConnectableObservable<Event> getDiscoveryEventSource() {
        return discoveryEventSource;
    }
    /**
     * @return Source of internal Mediator events, converted from BiCNet messages.
     * Set through {@link #setCoreEventSources(ConnectableObservable, ConnectableObservable, ConnectableObservable, ConnectableObservable, ConnectableObservable, ConnectableObservable)}.
     */
    public ConnectableObservable<MediatorEvent> getMediatorEventSource() {
        return mediatorEventSource;
    }
    /**
     * @return Source of internal Channel events, converted from BiCNet messages.
     * Set through {@link #setCoreEventSources(ConnectableObservable, ConnectableObservable, ConnectableObservable, ConnectableObservable, ConnectableObservable, ConnectableObservable)}.
     */
    public ConnectableObservable<ChannelEvent> getChannelEventSource() {
        return channelEventSource;
    }
    /**
     * @return Source of internal NE events, converted from BiCNet messages.
     * Set through {@link #setCoreEventSources(ConnectableObservable, ConnectableObservable, ConnectableObservable, ConnectableObservable, ConnectableObservable, ConnectableObservable)}.
     */
    public ConnectableObservable<NeEvent> getNeEventSource() {
        return neEventSource;
    }
    /**
     * @return Source of periodic (timed) events.
     * Set through {@link #setCoreEventSources(ConnectableObservable, ConnectableObservable, ConnectableObservable, ConnectableObservable, ConnectableObservable, ConnectableObservable)}.
     */
    public ConnectableObservable<PeriodicEvent> getPeriodicEventsSource() {
        return periodicEventsSource;
    }
    /**
     * @return Source of internal domain events, converted from BiCNet messages.
     * Set through {@link #setCoreEventSources(ConnectableObservable, ConnectableObservable, ConnectableObservable, ConnectableObservable, ConnectableObservable, ConnectableObservable)}.
     */
    public ConnectableObservable<DomainEvent> getDomainEventsSource() {
        return domainEventsSource;
    }
}
