package com.ossnms.dcn_manager.bicnet.connector.outbound.notifications;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.*;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IASMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomain;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INetworkDomainMarkable;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertDomainToBcb;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.composables.outbound.SecurityManager;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.events.domain.*;
import com.ossnms.dcn_manager.core.outbound.DomainNotifications;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;

import javax.annotation.Nonnull;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

/**
 * Implements the bridge between our core and the BiCNet notifications service.
 * Handles only notifications about changes to the state of domains.
 */
@ApplicationScoped
public class DomainNotificationsManagerImpl
        extends NotificationsManagerBase<DomainEvent>
        implements DomainNotifications {

    @Inject
    @DcnManager
    private DomainRepository domainRepository;

    @Inject
    private SecurityManager securityManager;

    @Override
    public void notifyDelete(@Nonnull DomainInfoData domain) {

        sendObjectDeletedNotification(new ASIdItem(domain.getId()));

        sendObjectDeletedNotification(new NetworkDomainIdItem(domain.getId()));
    }

    @Override
    public void notifyCreate(@Nonnull DomainInfoData domain) {

        final int id = domain.getId();
        final Iterable<Integer> domainNEs = domainRepository.queryChildrenNEs(id);

        sendObjectCreatedNotification(ConvertDomainToBcb.convert(domain, domainNEs)); // IAS

        sendObjectCreatedNotification(ConvertDomainToBcb.convert(domain)); // INetworkDomain
    }

    @Override
    public void notifyChanges(@Nonnull DomainChildrenChanged event) {

        final IAS as = new ASItem();
        as.setId(event.getDomain().getId());

        final IASMarkable markableAS = as.toMarkableAS(false);
        ConvertDomainToBcb.setNeList(markableAS, event.getChildrenIds());

        sendAttributeValueChangeNotification(markableAS);
    }

    @Override
    public void notifyChanges(@Nonnull DomainRenamed event) {

        final INetworkDomain domain = new NetworkDomainItem();
        domain.setId(event.getDomainId());

        final INetworkDomainMarkable markableDomain = domain.toMarkableNetworkDomain(false);
        markableDomain.setIdName(event.getNewName());

        sendAttributeValueChangeNotification(markableDomain);

        final IAS as = new ASItem();
        as.setId(event.getDomainId());

        final IASMarkable markableAS = as.toMarkableAS(false);

        markableAS.setIdName(event.getNewName());
        
        sendAttributeValueChangeNotification(markableAS);
        
        domainRepository.queryChildrenNEs(event.getDomainId())
                .forEach(securityManager::updateNe);
    }

    @Override
    public void notifyChanges(@Nonnull DomainParticipationAdded event) {

        sendObjectCreatedNotification(new NetworkDomainParticipationItem(null, event.getDomainId(), event.getNeId()));

        securityManager.updateNe(event.getNeId());
    }

    @Override
    public void notifyChanges(@Nonnull DomainParticipationDeleted event) {

        sendObjectDeletedNotification(new NetworkDomainParticipationItem(null, event.getDomainId(), event.getNeId()));

        securityManager.updateNe(event.getNeId());
    }

    @Override
    public void notifyChanges(@Nonnull DomainNeActivationPolicyChanged event) {

        final IAS as = new ASItem();
        as.setId(event.getDomainId());
        final IASMarkable markableAS = as.toMarkableAS(false);
        markableAS.setDiscoveryPermited(event.isAutomaticActivationPermitted());

        final NetworkDomainItem networkDomainItem = new NetworkDomainItem();
        networkDomainItem.setId(event.getDomainId());
        final INetworkDomainMarkable networkDomainMarkable = networkDomainItem.toMarkableNetworkDomain(false);
        networkDomainMarkable.setDiscoveryPermited(event.isAutomaticActivationPermitted());

        sendAttributeValueChangeNotification(markableAS);

        sendAttributeValueChangeNotification(networkDomainMarkable);
    }
}
