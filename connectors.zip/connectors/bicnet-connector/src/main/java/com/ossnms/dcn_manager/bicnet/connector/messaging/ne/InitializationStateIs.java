package com.ossnms.dcn_manager.bicnet.connector.messaging.ne;

import rx.functions.Func1;

import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementProxyMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.InitState;

final class InitializationStateIs
        implements Func1<INetworkElementProxyMarkable, Boolean> {
    private final InitState initState;

    public InitializationStateIs(InitState state) {
        this.initState = state;
    }

    @Override
    public Boolean call(INetworkElementProxyMarkable m) {
        return m.isMarkedInitState() && initState == m.getInitState();
    }
}