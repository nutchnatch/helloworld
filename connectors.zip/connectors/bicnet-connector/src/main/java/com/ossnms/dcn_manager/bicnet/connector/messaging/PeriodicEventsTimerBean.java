package com.ossnms.dcn_manager.bicnet.connector.messaging;

import com.ossnms.dcn_manager.core.events.periodic.PeriodicActivationVerificationEvent;
import com.ossnms.dcn_manager.core.events.periodic.PeriodicInitializationVerificationEvent;

import javax.ejb.Schedule;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

/**
 * Taps into the application server timer services to inject
 * periodic timer events in the relevant event source.
 *
 * Must be a separate EJB because it is not possible to use the
 * AS scheduler in singletons.
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class PeriodicEventsTimerBean {

    @Inject private PeriodicEventsSource periodicEvents;

    @Schedule(hour="*", minute="*", persistent=false)
    public void onTimeout() {
        periodicEvents.push(new PeriodicActivationVerificationEvent());
        periodicEvents.push(new PeriodicInitializationVerificationEvent());
    }

}
