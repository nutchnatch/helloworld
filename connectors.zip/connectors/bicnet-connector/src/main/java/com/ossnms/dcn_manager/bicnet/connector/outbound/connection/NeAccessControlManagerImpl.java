package com.ossnms.dcn_manager.bicnet.connector.outbound.connection;

import com.ossnms.bicnet.bcb.facade.elementMgmt.*;
import com.ossnms.bicnet.bcb.facade.platform.IConnectionManager;
import com.ossnms.bicnet.bcb.facade.platform.UnavailableFacadeException;
import com.ossnms.bicnet.bcb.facade.platform.UnsupportedFacadeException;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElement;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.platform.PlatformException;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.composables.outbound.NeAccessControlManager;
import com.ossnms.dcn_manager.composables.outbound.exception.AccessControlException;

import javax.annotation.Nonnull;
import javax.inject.Inject;

import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertIntegerToBcbNe.convert;

/**
 * @see NeAccessControlManager
 */
public class NeAccessControlManagerImpl implements NeAccessControlManager<BicnetCallContext> {

    private static final String WRITE_ACCESS_STATE_PKG = "elementMgmt.WriteAccessStatePkg";
    private static final String NETWORK_ELEMENT_FACADE = "elementMgmt.NetworkElement";
    private static final String SOFTWARE_MANAGER = "elementMgmt.SoftwareManager";

    private final IConnectionManager connectionManager;

    @Inject
    public NeAccessControlManagerImpl(@DcnManager IConnectionManager connectionManager) {
        super();
        this.connectionManager = connectionManager;
    }

    /**
     * @see NeAccessControlManager#releaseWriteAccess(com.ossnms.dcn_manager.composables.context.CallContext, int)
     */
    @Override
    public void requestWriteAccess(BicnetCallContext context, int neId) throws AccessControlException {
        try {
            ISessionContext sessionContext = context.getSessionContext();
            INEId bcbNeId = convert(neId);
            IWriteAccessStatePkgFacade statePkgFacade = getWriteAccessStateFacade(sessionContext, bcbNeId);

            statePkgFacade.requestWriteAccess(sessionContext, bcbNeId.neId());
        } catch (UnsupportedOperationException | BcbException e) {
            throw new AccessControlException(e);
        }
    }

    /**
     * @see NeAccessControlManager#releaseWriteAccess(com.ossnms.dcn_manager.composables.context.CallContext, int)
     */
    @Override
    public void releaseWriteAccess(BicnetCallContext context, int neId) throws AccessControlException {
        try {
            ISessionContext sessionContext = context.getSessionContext();
            INEId bcbNeId = convert(neId);
            IWriteAccessStatePkgFacade statePkgFacade = getWriteAccessStateFacade(sessionContext, bcbNeId);

            statePkgFacade.releaseWriteAccess(sessionContext, bcbNeId.neId());
        } catch (UnsupportedOperationException | BcbException e) {
            throw new AccessControlException(e);
        }
    }

    /**
     * @see NeAccessControlManager#enforceWriteAccess(com.ossnms.dcn_manager.composables.context.CallContext, int)
     */
    @Override
    public void enforceWriteAccess(BicnetCallContext context, int neId) throws AccessControlException {
        try {
            ISessionContext sessionContext = context.getSessionContext();
            INEId bcbNeId = convert(neId);
            IWriteAccessStatePkgFacade statePkgFacade = getWriteAccessStateFacade(sessionContext, bcbNeId);

            statePkgFacade.enforceWriteAccess(sessionContext, bcbNeId.neId());
        } catch (UnsupportedOperationException | BcbException e) {
            throw new AccessControlException(e);
        }
    }

    /**
     * @see NeAccessControlManager#toActiveStateMode(com.ossnms.dcn_manager.composables.context.CallContext, int)
     */
    @Override
    public void toActiveStateMode(@Nonnull BicnetCallContext context, int neId) throws AccessControlException {
        try {
            ISessionContext sessionContext = context.getSessionContext();
            INE bcbNeItem = convert(neId);

            ISoftwareManagerFacade softwareManagerFacade = (ISoftwareManagerFacade) connectionManager.getFacadeStrict(
                    sessionContext, SOFTWARE_MANAGER, bcbNeItem.getNEId());

            softwareManagerFacade.setToActive(sessionContext, bcbNeItem.neId());
        } catch (UnsupportedOperationException | BcbException e) {
            throw new AccessControlException(e);
        }
    }

    /**
     * @see NeAccessControlManager#toOperationalMode(com.ossnms.dcn_manager.composables.context.CallContext, int)
     */
    @Override
    public void toOperationalMode(BicnetCallContext context, int neId) throws AccessControlException {
        try {
            ISessionContext sessionContext = context.getSessionContext();
            INEId bcbNeId = convert(neId);
            INetworkElementFacade networkElementFacade = getNetworkElementFacade(sessionContext, bcbNeId);

            INetworkElementMarkable markable = getBcbNetworkElementMarkable(sessionContext, networkElementFacade,
                    bcbNeId);
            markable.setEventForwarding(EnableSwitch.ENABLED);

            networkElementFacade.modifyNetworkElement(sessionContext, markable);
        } catch (UnsupportedOperationException | BcbException e) {
            throw new AccessControlException(e);
        }
    }

    /**
     * @see NeAccessControlManager#toMaitenanceMode(com.ossnms.dcn_manager.composables.context.CallContext, int)
     */
    @Override
    public void toMaitenanceMode(BicnetCallContext context, int neId) throws AccessControlException {
        try {
            ISessionContext sessionContext = context.getSessionContext();
            INEId bcbNeId = convert(neId);
            INetworkElementFacade networkElementFacade = getNetworkElementFacade(sessionContext, bcbNeId);

            INetworkElementMarkable markable = getBcbNetworkElementMarkable(sessionContext, networkElementFacade,
                    bcbNeId);
            markable.setEventForwarding(EnableSwitch.DISABLED);

            networkElementFacade.modifyNetworkElement(sessionContext, markable);
        } catch (UnsupportedOperationException | BcbException e) {
            throw new AccessControlException(e);
        }
    }

    /**
     * Gets the Bicnet Network Element Markable.
     * 
     * @see INetworkElementMarkable
     * 
     * @param sessionContext
     * @param networkElementFacade
     * @param bcbNeId
     * @return
     * @throws BcbException
     */
    private INetworkElementMarkable getBcbNetworkElementMarkable(ISessionContext sessionContext,
            INetworkElementFacade networkElementFacade, INEId bcbNeId) throws BcbException {
        INetworkElement bcbNetworkElement = networkElementFacade.getSingleNetworkElement(sessionContext,
                new NetworkElementIdItem(bcbNeId.getId()));
        return NetworkElementMarkableItem.of(bcbNetworkElement);
    }

    /**
     * Gets the Bicnet Network Element Facade.
     * 
     * @see INetworkElementFacade
     * 
     * @param sessionContext
     * @param bcbNeId
     * @return
     * @throws PlatformException
     * @throws UnsupportedFacadeException 
     * @throws UnavailableFacadeException 
     */
    private INetworkElementFacade getNetworkElementFacade(ISessionContext sessionContext, INEId bcbNeId)
            throws PlatformException, UnavailableFacadeException, UnsupportedFacadeException {
        return (INetworkElementFacade) connectionManager.getFacadeStrict(sessionContext, NETWORK_ELEMENT_FACADE, bcbNeId);
    }

    /**
     * Gets the Bicnet AccessState PkgFacade.
     * 
     * @see IWriteAccessStatePkgFacade
     * 
     * @param sessionContext
     * @param bcbNeId
     * @return
     * @throws PlatformException
     * @throws UnsupportedFacadeException 
     * @throws UnavailableFacadeException 
     */
    private IWriteAccessStatePkgFacade getWriteAccessStateFacade(ISessionContext sessionContext, INEId bcbNeId)
            throws PlatformException, UnavailableFacadeException, UnsupportedFacadeException {
        return (IWriteAccessStatePkgFacade) connectionManager.getFacadeStrict(sessionContext, WRITE_ACCESS_STATE_PKG, bcbNeId);
    }
}
