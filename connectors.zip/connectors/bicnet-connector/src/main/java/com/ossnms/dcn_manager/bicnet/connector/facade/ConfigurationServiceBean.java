package com.ossnms.dcn_manager.bicnet.connector.facade;

import com.ossnms.bicnet.bcb.facade.platform.IConnectionManager;
import com.ossnms.bicnet.bcb.facade.scs.BooleanSettingItem;
import com.ossnms.bicnet.bcb.facade.scs.ISystemControlEjbFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.scs.IBooleanSettingMarkable;
import com.ossnms.bicnet.bcb.model.scs.SettingCategory;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ConfigurationService;
import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.commands.settings.GetGlobalSettings;
import com.ossnms.dcn_manager.commands.settings.internal.UpdateDcnManagerProperties;
import com.ossnms.dcn_manager.composables.context.CallContext;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.outbound.GlobalSettingsNotifications;
import com.ossnms.dcn_manager.core.policies.SystemSchedulingConfiguration;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import java.util.Map;

import static com.ossnms.dcn_manager.bicnet.connector.facade.util.Exceptions.logAndRethrowAsBcb;
import static org.slf4j.LoggerFactory.getLogger;

@Stateless(name = "ConfigurationServiceBean")
@Local(ConfigurationService.class)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class ConfigurationServiceBean implements ConfigurationService {

    private static final Logger LOGGER = getLogger(ConfigurationServiceBean.class);

    @Inject
    private StaticConfigurationSingleton configuration;

    @Inject @DcnManager
    private SettingsRepository repository;

    @Inject
    private GlobalSettingsNotifications notifications;

    @Inject @DcnManager
    private IConnectionManager connectionManager;

    @Inject @DcnManager
    private ISystemControlEjbFacade scs;

    @Inject @DcnManager
    private SystemSchedulingConfiguration systemScheduling;

    @Inject
    private LoggerManagerImpl loggerManager;

    @Override
    public Map<String, String> getGlobalSettings(@Nonnull final ISessionContext context) throws BcbException {
        final GetGlobalSettings<CallContext> command = new GetGlobalSettings<CallContext>(new BicnetCallContext(context), repository);

        try {
            return command.call();
        } catch (final CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public void updateGlobalSettings(@Nonnull final ISessionContext context, final Map<String, String> updatedProperties) throws BcbException{
        final UpdateDcnManagerProperties<BicnetCallContext> command =
                new UpdateDcnManagerProperties<>(new BicnetCallContext(context), repository, notifications,
                        systemScheduling, loggerManager, updatedProperties);
        try {
            final GlobalSettings call = command.call();
            final BooleanSettingItem setting = new BooleanSettingItem();
            final IBooleanSettingMarkable settingMarkable = setting.toMarkableBooleanSetting();
            settingMarkable.setValue(call.isNativeNeNamingEnabled());
            settingMarkable.setCategory(SettingCategory.FAULT);
            settingMarkable.setName("nativeLocation");
            scs.modifySetting(context, settingMarkable);
            connectionManager.setDcnGlobalProperties(context, updatedProperties);
        } catch (CommandException | DataUpdateException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override public boolean isNodeManagerSelected() {
        return configuration.isNodeManagerSelected();
    }
}
