package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableMap;
import com.ossnms.bicnet.bcb.facade.common.IconPairIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.common.AdministrativeState;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentTypes;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.common.GatewayRole;
import com.ossnms.bicnet.bcb.model.common.IIconPairId;
import com.ossnms.bicnet.bcb.model.common.OperationalState;
import com.ossnms.bicnet.bcb.model.common.ProvisioningState;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommissioningStatusSummary;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.elementMgmt.InitState;
import com.ossnms.bicnet.bcb.model.elementMgmt.NeFamily;
import com.ossnms.bicnet.bcb.model.elementMgmt.NeSubType;
import com.ossnms.bicnet.bcb.model.elementMgmt.TpGroupMode;
import com.ossnms.bicnet.bcb.model.elementMgmt.WriteAccessState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeActivationState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeCapabilities;
import com.ossnms.bicnet.bcb.model.networkMgmt.TransportLayerSet;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNeTypePropertyNames;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.ne.data.types.CommissioningMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.GatewayMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.OperationalMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;
import com.ossnms.dcn_manager.core.entities.ne.data.types.TpGroupSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.types.WriteAccessMode;
import com.ossnms.dcn_manager.core.properties.ne.NeProperties;
import com.ossnms.dcn_manager.core.properties.ne.NeProperty;
import com.ossnms.dcn_manager.i18n.Message;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import javax.xml.bind.DatatypeConverter;
import java.util.Collections;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Handles conversion of internal domain entities representing an NE to its
 * corresponding type in the BCB object model.
 */
public final class ConvertNeToBcb {

    private static final Logger LOGGER = getLogger(ConvertNeToBcb.class);
    private static final String EMPTY_NE_LOCATION = ""; //by contract of INetworkElement location is never null

    private ConvertNeToBcb() {

    }

    /**
     * Fills an existing {@link INE} BCB object with information from our domain entity.
     *
     * @param type NE type metadata.
     * @param entity NE instance that will be the source of data.
     * @param routes NE routes related to the NE instance provided.
     * @param instances Physical NE instances.
     * @param existing BCB INE instance to fill with data.
     */
    public static void fillExisting(@Nonnull NeType type, @Nonnull NeEntity entity,
            @Nonnull Iterable<NeGatewayRouteData> routes, @Nonnull Iterable<NePhysicalConnectionData> instances,
            @Nonnull INE existing) {
        final String iconName = entity.getInfo().getIconId().orElse(type.getDefaultIcon());
        final NeProperties neProperties = new NeProperties();

        existing.setActivation(convert(entity.getInfo().isActive()));
        existing.setAdditionalInfo(entity.getConnection().getAdditionalInfo().orElse(null));
        existing.setAssociatedEmId(entity.getInfo().getChannelId());
        existing.setCapabilities(NeCapabilities.fromDbString(neProperties.getProperty(type, entity, NeProperty.CAPABILITIES).orElse(EMPTY)));
        existing.setCommissioningStatus(convertCommissioningMode(entity.getOperation().getCommissioning()));
        existing.setCommunicationState(convertToCommunicationState(entity.getConnection().getActivationState()));
        existing.setActualActivationState(convertToNeActivationState(entity.getConnection().getActivationState()));
        existing.setCoreId(entity.getInfo().getCoreId().orElse(null));
        existing.setEventForwarding(convertEventForwarding(entity.getOperation().isEventForwardingActive()));
        existing.setGlobalId(entity.getPreferences().getGlobalId().orElse(null));
        existing.setId(entity.getInfo().getNeId());
        existing.setIdName(entity.getPreferences().getName());
        existing.setInitState(convertToInitState(entity.getConnection().getActivationState()));
        existing.setGatewayRole(convertGatewayMode(entity.getOperation().getGatewayMode()));
        existing.setMainRelease(entity.getOperation().getMainRelease().orElse(null));
        existing.setMaintenanceRelease(entity.getOperation().getMaintenanceRelease().orElse(null));
        existing.setNeFamilyEnum(convertNeFamily(entity.getOperation().getFamily()));
        existing.setNeProxyType(type.getName());
        existing.setNeSubType(entity.getOperation().getNeSubTypeDescription().orElse(null));
        existing.setNeSubTypeEnum(convertToNeSubType(entity.getOperation().getNeSubType()));
        existing.setNeTypeEnum(convertToNeType(entity.getOperation().getNeType()));
        existing.setOperationalState(convertOperationalMode(entity.getOperation().getOperational()));
        existing.setPropertiesValid(true);
        existing.setRealNeName(entity.getOperation().getRealNeName().orElse(null));
        existing.setReconnectInterval(entity.getPreferences().getReconnectInterval());
        existing.setSupportedLayers(TransportLayerSet.fromDbString(neProperties.getProperty(type, entity, NeProperty.SUPPORTED_LAYERS).orElse(EMPTY)));
        existing.setSpecificType(entity.getOperation().getNeSpecificType().orElse(null));
        existing.setNeighbourhoodId(entity.getOperation().getNeighbourhoodId().orElse(null));
        existing.setTpGroupMask(entity.getOperation().getTpGroupMask().orElse(0L));
        existing.setTpGroupMode(convertTpGroupSettings(entity.getOperation().getTpGroupMode()));
        existing.setUsesGNE(entity.getPreferences().usesGne());
        existing.setWriteAccessState(convertWriteAccessMode(entity.getOperation().getWriteAccess()));
        existing.setAssociatedSystemContainerId(entity.getPreferences().getContainerId().orElse(0));

        final IIconPairId defaultIconPair = new IconPairIdItem(BiCNetComponentType.DCN_MANAGER, iconName);
        existing.setIconId(defaultIconPair);
        existing.setIconIdContext(defaultIconPair.getContext());
        existing.setIconIdId(defaultIconPair.getId());

        final ActualActivationState actualActivationState =
                ConvertNeToNeGuiInfo.findInstanceActualActivationState(instances, ConvertNeToNeGuiInfo.ACTIVE)
                    .orElse(entity.getConnection().getActivationState());
        existing.setDisplayState(describe(actualActivationState));

        existing.setDisplayAddress(neProperties.getProperty(type, entity, NeProperty.DISPLAY_ADDRESS).orElse(null));
        existing.setConnectedVia(neProperties.buildCurrentRouteDescription(entity, routes).orElse(null));

        existing.setUsedBy(convertUsage(entity.getInfo().getUsedBy()));

        existing.setAdministrativeState(AdministrativeState.UNLOCKED);
        existing.setProvisioningState(ProvisioningState.UNPROVISIONED);

        existing.setLoginPasswordMd5(decodeToBinary(entity.getPreferences().getPassword()));
        existing.setLoginUserName(entity.getPreferences().getUserName().orElse(null));

        existing.setPasswordPolicy(type.getTypeProperties().get(WellKnownNeTypePropertyNames.SECURITY_POLICY));
        
        existing.setLocation(entity.getOperation().getLocation().orElse(EMPTY_NE_LOCATION));
    }

    private static byte[] decodeToBinary(Optional<String> encryptedPassword) {
        if (encryptedPassword.isPresent()) {
            try {
                return DatatypeConverter.parseHexBinary(encryptedPassword.get());
            } catch (final IllegalArgumentException e) {
                LOGGER.error("Failed to convert string password into its binary form.");
            }
        }
        return null;
    }

    /**
     * Converts between the internal, agnostic, usage representation and the external BCB format.
     * @param usedBy Internal usage representation string.
     * @return An instance of {@link BiCNetComponentTypes}.
     */
    public static BiCNetComponentTypes convertUsage(Optional<String> usedBy) {
        return usedBy.isPresent()
                ? BiCNetComponentTypes.fromDbString(usedBy.get())
                : BiCNetComponentTypes.none();
    }

    private static final BiMap<OperationalState, OperationalMode> OPERATION_STATE_TO_MODE =
            ImmutableBiMap.of(
                    OperationalState.DISABLED, OperationalMode.DISABLED,
                    OperationalState.ENABLED, OperationalMode.ENABLED
            );

    private static final BiMap<CommissioningStatusSummary, CommissioningMode> COMMISSIONING_STATUS_SUMMARY_TO_MODE =
            ImmutableBiMap.of(
                    CommissioningStatusSummary.COMMISSIONED, CommissioningMode.COMMISSIONED,
                    CommissioningStatusSummary.NOT_COMMISSIONED, CommissioningMode.NOT_COMMISSIONED,
                    CommissioningStatusSummary.PARTIALLY_COMMISSIONED, CommissioningMode.PARTIALLY_COMMISSIONED
            );

    private static final BiMap<WriteAccessState, WriteAccessMode> WRITE_ACCESS_STATE_TO_MODE =
            ImmutableBiMap.of(
                    WriteAccessState.CLIENT_EM, WriteAccessMode.CLIENT_EM,
                    WriteAccessState.EXTERNAL, WriteAccessMode.EXTERNAL,
                    WriteAccessState.NE_PROXY, WriteAccessMode.NE_PROXY,
                    WriteAccessState.NE_PROXY_AND_CLIENT_EM, WriteAccessMode.NE_PROXY_AND_CLIENT_EM,
                    WriteAccessState.NO, WriteAccessMode.NO
            );

    private static final BiMap<GatewayRole, GatewayMode> GATEWAY_ROLE_TO_MODE =
            ImmutableBiMap.of(
                    GatewayRole.NONE, GatewayMode.NONE,
                    GatewayRole.PRIMARY, GatewayMode.PRIMARY,
                    GatewayRole.SECONDARY, GatewayMode.SECONDARY
            );

    
    public static CommissioningMode convertCommissioningStatusSummary(CommissioningStatusSummary status) {
        return COMMISSIONING_STATUS_SUMMARY_TO_MODE.get(status);
    }

    public static WriteAccessMode convertWriteAccessState(WriteAccessState writeAccessState) {
        return WRITE_ACCESS_STATE_TO_MODE.get(writeAccessState);
    }

    public static GatewayMode convertGatewayRole(GatewayRole gatewayRole) {
        return GATEWAY_ROLE_TO_MODE.get(gatewayRole);
    }

    static NeSubType convertToNeSubType(Optional<String> subType) {
        return subType.isPresent()
                ? NeSubType.fromName(subType.get())
                : NeSubType.NOT_APPLICABLE;
    }

    static com.ossnms.bicnet.bcb.model.elementMgmt.NeType convertToNeType(
            Optional<String> neType) {
        return neType.isPresent()
                ? com.ossnms.bicnet.bcb.model.elementMgmt.NeType.fromName(neType.get())
                : com.ossnms.bicnet.bcb.model.elementMgmt.NeType.NOT_APPLICABLE;
    }

    static NeFamily convertNeFamily(Optional<String> family) {
        return family.isPresent()
                ? NeFamily.fromName(family.get())
                : NeFamily.NOT_APPLICABLE;
    }

    /**
     * Maintains the set of equivalences between the BCB connection states and the internal
     * actual activation state. Note that the BCB state is split in two components and that the
     * set of valid/supported combinations is limited.
     */
    private static final ImmutableMap<Pair<CommunicationState, InitState>, ActualActivationState> COMM_STATES =
            ImmutableMap.<Pair<CommunicationState, InitState>, ActualActivationState>builder()
                    .put(ImmutablePair.of(CommunicationState.CONNECTING, InitState.NOT_INITIALIZED), ActualActivationState.CONNECTING)
                    .put(ImmutablePair.of(CommunicationState.CONNECTED, InitState.NOT_INITIALIZED), ActualActivationState.CONNECTED)
                    .put(ImmutablePair.of(CommunicationState.CONNECTED, InitState.INITIALIZING), ActualActivationState.INITIALIZING)
                    .put(ImmutablePair.of(CommunicationState.CONNECTED, InitState.INITIALIZED), ActualActivationState.INITIALIZED)
                    .put(ImmutablePair.of(CommunicationState.DISCONNECTING, InitState.SHUTTING_DOWN), ActualActivationState.DISCONNECTING)
                    .put(ImmutablePair.of(CommunicationState.DISCONNECTED, InitState.NOT_INITIALIZED), ActualActivationState.DISCONNECTED)
                    .put(ImmutablePair.of(CommunicationState.FAILED, InitState.FAILED), ActualActivationState.FAILED)
                    .build();

    /**
     * Maintains the set of equivalences between the internal actual activation state and its
     * BCB counterparts. Note that the BCB state is split in two components and that the
     * set of valid/supported combinations is limited.
     */
    private static final ImmutableMap<ActualActivationState, Pair<CommunicationState, InitState>> ACTIVATION_STATES =
            ImmutableMap.<ActualActivationState, Pair<CommunicationState, InitState>>builder()
                    .put(ActualActivationState.CONNECTING, ImmutablePair.of(CommunicationState.CONNECTING, InitState.NOT_INITIALIZED))
                    .put(ActualActivationState.CONNECTED, ImmutablePair.of(CommunicationState.CONNECTED, InitState.NOT_INITIALIZED))
                    .put(ActualActivationState.INITIALIZING, ImmutablePair.of(CommunicationState.CONNECTED, InitState.INITIALIZING))
                    .put(ActualActivationState.INITIALIZED, ImmutablePair.of(CommunicationState.CONNECTED, InitState.INITIALIZED))
                    .put(ActualActivationState.DISCONNECTING, ImmutablePair.of(CommunicationState.DISCONNECTING, InitState.SHUTTING_DOWN))
                    .put(ActualActivationState.DISCONNECTED, ImmutablePair.of(CommunicationState.DISCONNECTED, InitState.NOT_INITIALIZED))
                    .put(ActualActivationState.FAILED, ImmutablePair.of(CommunicationState.FAILED, InitState.FAILED))
                    .put(ActualActivationState.STARTUP, ImmutablePair.of(CommunicationState.CONNECTING, InitState.NOT_INITIALIZED))
                    .put(ActualActivationState.SHUTDOWN, ImmutablePair.of(CommunicationState.DISCONNECTING, InitState.SHUTTING_DOWN))
                    .build();

    private static Pair<CommunicationState, InitState> getBcbState(ActualActivationState activationState) {
        final Pair<CommunicationState, InitState> bcb = ACTIVATION_STATES.get(activationState);
        if (null == bcb) {
            throw new IllegalStateException("Actual activation state not supported in BCB: " + activationState);
        }
        return bcb;
    }

    /**
     * Given a pair of BCB communication and initialization states, provides the corresponding Actual Activation State.
     * Not all possible combinations of BCB states are supported. Unsupported combinations will not be translated.
     *
     * @param commState BCB communication state.
     * @param initState BCB initialization state.
     * @return The corresponding Actual Activation State or an absent value if the input combination is not supported.
     */
    public static Optional<ActualActivationState> tryConvertToActualActivationState(
            CommunicationState commState, InitState initState) {
        return Optional.ofNullable(COMM_STATES.get(ImmutablePair.of(commState, initState)));
    }

    /**
     * Given the internal NE actual activation state, obtain the BCB Initialization State.
     *
     * @param activationState NE actual activation state.
     * @return BCB Initialization State.
     */
    public static InitState convertToInitState(ActualActivationState activationState) {
        return getBcbState(activationState).getRight();
    }

    /**
     * Given the internal NE actual activation state, obtain the BCB Communication State.
     *
     * @param activationState NE actual activation state.
     * @return BCB Communication State.
     */
    public static CommunicationState convertToCommunicationState(ActualActivationState activationState) {
        return getBcbState(activationState).getLeft();
    }

    /**
     * Given the internal NE actual activation state, obtain the public BCB actual activation state.
     *
     * @param activationState NE actual activation state.
     * @return Public BCB actual activation state.
     */
    public static NeActivationState convertToNeActivationState(ActualActivationState activationState) {
        switch (activationState) {
        case INITIALIZED:
            return NeActivationState.ACTIVE;
        case FAILED:
            return NeActivationState.FAILED;
        case CONNECTING:
        case CONNECTED:
        case INITIALIZING:
            return NeActivationState.ACTIVATING;
        case DISCONNECTING:
            return NeActivationState.DEACTIVATING;
        case STARTUP:
            return NeActivationState.STARTING_UP;
        case SHUTDOWN:
            return NeActivationState.SHUTTING_DOWN;
        case DISCONNECTED:
            return NeActivationState.INACTIVE;
        default:
            return NeActivationState.INACTIVE;
        }
    }

    /**
     * Given the NE Actual Activation state, find the appropriate human readable description.
     * @param activationState NE Actual Activation state.
     * @return A human readable state description.
     * @throws IllegalStateException If there is no description for the state given.
     */
    public static String describe(ActualActivationState activationState) {
        switch (activationState) {
        case STARTUP:
        case INITIALIZING:
        case CONNECTING:
        case CONNECTED:
            return tr(Message.ACTIVATING);
        case INITIALIZED:
            return tr(Message.ACTIVE);
        case DISCONNECTED:
            return tr(Message.INACTIVE);
        case FAILED:
            return tr(Message.FAILED);
        case DISCONNECTING:
        case SHUTDOWN:
            return tr(Message.DEACTIVATING);
        default:
            throw new IllegalStateException("Actual activation state without description: " + activationState);
        }
    }

    /**
     * Given the NE Actual Activation state, find the appropriate human readable for each state.
     * @param activationState NE Actual Activation state.
     * @return A human readable state description.
     * @throws IllegalStateException If there is no description for the state given.
     */
    public static String describeEachStates(ActualActivationState activationState) {
        switch (activationState) {
        case INITIALIZING:
            return tr(Message.INITIALIZING);
        case CONNECTING:
            return tr(Message.CONNECTING);
        case CONNECTED:
            return tr(Message.CONNECTED);
        case INITIALIZED:
            return tr(Message.ACTIVE);
        case DISCONNECTED:
            return tr(Message.INACTIVE);
        case FAILED:
            return tr(Message.FAILED);
        case SHUTDOWN:
            return tr(Message.SHUTTING_DOWN);
        case DISCONNECTING:
            return tr(Message.DEACTIVATING);
        case STARTUP:
            return tr(Message.STARTING_UP);
        default:
            throw new IllegalStateException("Actual activation state without description: " + activationState);
        }
    }

    /**
     * Fills a BCB {@link INEMarkable} object with changed information from a mutation descriptor.
     * @param markable Target BCB NE markable instance.
     * @param preferences Mutation descriptor instance.
     */
    public static void updateMarkable(INEMarkable markable, NeUserPreferencesMutationDescriptor preferences) {
        if (preferences.getName().isPresent()) {
            markable.setIdName(preferences.getName().get());
        }
        if (preferences.getReconnectInterval().isPresent()) {
            markable.setReconnectInterval(preferences.getReconnectInterval().get());
        }
        if (preferences.getUsesGne().isPresent()) {
            markable.setUsesGNE(preferences.getUsesGne().get());
        }
        if (preferences.getGlobalId().isPresent()) {
            markable.setGlobalId(preferences.getGlobalId().get());
        }
        if (preferences.getPassword().isPresent()) {
            markable.setLoginPasswordMd5(preferences.getPassword().get().getBytes());
        }
        if (preferences.getUserName().isPresent()) {
            markable.setLoginUserName(preferences.getUserName().get());
        }
        if (preferences.getContainerId().isPresent()) {
            markable.setAssociatedSystemContainerId(preferences.getContainerId().get());
        }
    }

    /**
     * Fills a BCB {@link INEMarkable} object with changed information from a mutation descriptor.
     * @param markable Target BCB NE markable instance.
     * @param state Mutation descriptor instance.
     */
    public static void updateMarkable(INEMarkable markable, NeInfoMutationDescriptor state) {
        if (state.getCoreId().isPresent()) {
            markable.setCoreId(state.getCoreId().get());
        }
        if (state.getProxyType().isPresent()) {
            markable.setNeProxyType(state.getProxyType().get());
        }
        if (state.getIconId().isPresent()) {
            markable.setIconIdId(state.getIconId().get());
        }
        if (state.getUsedBy().isPresent()) {
            markable.setUsedBy(convertUsage(state.getUsedBy()));
        }
        if (state.getChannelId().isPresent()) {
            markable.setAssociatedEmId(state.getChannelId().get());
        }
        if (state.getRequiredActivationState().isPresent()) {
            markable.setActivation(convert(state.getRequiredActivationState().get() == RequiredActivationState.ACTIVE));
        }
    }

    /**
     * Fills a BCB {@link INEMarkable} object with changed information from a mutation descriptor.
     * @param markable Target BCB NE markable instance.
     * @param connection Mutation descriptor instance.
     */
    public static void updateMarkable(INEMarkable markable, NeConnectionMutationDescriptor connection) {
        if (connection.getConnectedVia().isPresent()) {
            markable.setConnectedVia(connection.getConnectedVia().get());
        }
        if (connection.getAdditionalInfo().isPresent()) {
            markable.setAdditionalInfo(connection.getAdditionalInfo().get());
        }
        if (connection.getActivationState().isPresent()) {
            final ActualActivationState activationState = connection.getActivationState().get();
            markable.setInitState(convertToInitState(activationState));
            markable.setCommunicationState(convertToCommunicationState(activationState));
            markable.setActualActivationState(convertToNeActivationState(activationState));
            markable.setDisplayState(describe(activationState));
        }
    }

    /**
     * Fills a BCB {@link INEMarkable} object with changed information from a mutation descriptor.
     * @param markable Target BCB NE markable instance.
     * @param operation Mutation descriptor instance.
     */
    public static void updateMarkable(INEMarkable markable, NeOperationMutationDescriptor operation) {

        updateMarkableNeConfigurations(markable, operation);

        updateMarkableNeSoftwareVersions(markable, operation);

        updateMarkableTpGroups(markable, operation);

        updateMarkableNeTypes(markable, operation);

        if (operation.getRealNeName().isPresent()) {
            markable.setRealNeName(operation.getRealNeName().get());
        }
        if ( operation.getNeighbourhoodId().isPresent()) {
            markable.setNeighbourhoodId(operation.getNeighbourhoodId().get());
        }

        operation.getLocation().ifPresent(markable::setLocation);
    }

    private static void updateMarkableNeConfigurations(INEMarkable markable,
            NeOperationMutationDescriptor operation) {
        if (operation.getCommissioning().isPresent()) {
            markable.setCommissioningStatus(convertCommissioningMode(operation.getCommissioning()));
        }
        if (operation.isEventForwardingActive().isPresent()) {
            markable.setEventForwarding(convertEventForwarding(operation.isEventForwardingActive()));
        }
        if (operation.getOperationalMode().isPresent()) {
            markable.setOperationalState(convertOperationalMode(operation.getOperationalMode()));
        }
        if (operation.getWriteAccess().isPresent()) {
            markable.setWriteAccessState(convertWriteAccessMode(operation.getWriteAccess()));
        }
        if (operation.getGatewayMode().isPresent()) {
            markable.setGatewayRole(convertGatewayMode(operation.getGatewayMode()));
        }
    }

    private static void updateMarkableNeSoftwareVersions(INEMarkable markable,
            NeOperationMutationDescriptor operation) {
        if (operation.getMainRelease().isPresent()) {
            markable.setMainRelease(operation.getMainRelease().get());
        }
        if (operation.getMaintenanceRelease().isPresent()) {
            markable.setMaintenanceRelease(operation.getMaintenanceRelease().get());
        }
    }

    private static void updateMarkableTpGroups(INEMarkable markable,
            NeOperationMutationDescriptor operation) {
        if (operation.getTpGroupMask().isPresent()) {
            markable.setTpGroupMask(operation.getTpGroupMask().get());
        }
        if (operation.getTpGroupMode().isPresent()) {
            markable.setTpGroupMode(convertTpGroupSettings(operation.getTpGroupMode()));
        }
    }

    private static void updateMarkableNeTypes(INEMarkable markable,
            NeOperationMutationDescriptor operation) {
        if (operation.getFamily().isPresent()) {
            markable.setNeFamilyEnum(NeFamily.fromName(operation.getFamily().get()));
        }
        if (operation.getNeType().isPresent()) {
            markable.setNeTypeEnum(convertToNeType(operation.getNeType()));
        }
        if (operation.getNeSpecificType().isPresent()) {
            markable.setSpecificType(operation.getNeSpecificType().get());
        }
        if (operation.getNeSubTypeDescription().isPresent()) {
            markable.setNeSubType(operation.getNeSubTypeDescription().get());
        }
        if (operation.getNeSubType().isPresent()) {
            markable.setNeSubTypeEnum(convertToNeSubType(operation.getNeSubType()));
        }
    }

    private static int convertWriteAccessMode(Optional<WriteAccessMode> writeAccess) {
        return writeAccess.isPresent()
                ? WRITE_ACCESS_STATE_TO_MODE.inverse().get(writeAccess.get()).getOrdinal()
                : 0;
    }

    static TpGroupMode convertTpGroupSettings(Optional<TpGroupSettings> tpGroupMode) {
        return tpGroupMode.isPresent()
                ? new TpGroupMode(tpGroupMode.get().isAlwaysCompatible(), tpGroupMode.get().isMultipleGroupMembership(),
                tpGroupMode.get().isSubgroupsMustBeEqual(), tpGroupMode.get().isMultipleSubgroupMembership())
                : defaultTpGroupMode();
    }

    private static TpGroupMode defaultTpGroupMode() {
        return new TpGroupMode(true, false, false, false);
    }

    static OperationalState convertOperationalMode(Optional<OperationalMode> operational) {
        return operational.isPresent()
                ? OPERATION_STATE_TO_MODE.inverse().get(operational.get())
                : OperationalState.NOT_APPLICABLE;
    }

    private static EnableSwitch convert(boolean value) {
        return value ? EnableSwitch.ENABLED : EnableSwitch.DISABLED;
    }

    private static EnableSwitch convertEventForwarding(Optional<Boolean> value) {
        return value.isPresent() ? convert(value.get()) : EnableSwitch.ENABLED;
    }

    static CommissioningStatusSummary convertCommissioningMode(Optional<CommissioningMode> commissioning) {
        return commissioning.isPresent()
                ? COMMISSIONING_STATUS_SUMMARY_TO_MODE.inverse().get(commissioning.get())
                : CommissioningStatusSummary.COMMISSIONED;
    }

    static GatewayRole convertGatewayMode(Optional<GatewayMode> gatewayMode) {
        return gatewayMode.isPresent()
                ? GATEWAY_ROLE_TO_MODE.inverse().get(gatewayMode.get())
                : GatewayRole.NONE;
    }

    /**
     * Converts an NE domain entity into a new {@link INE} BCB object.
     *
     * @param type NE type metadata.
     * @param ne NE instance that will be the source of data.
     * @param routes NE routes related to the NE instance provided.
     * @param instances Physical NE instances.
     * @return A new BCB INE instance filled with data.
     */
    public static INE convert(@Nonnull NeType type, @Nonnull NeEntity ne,
          @Nonnull Iterable<NeGatewayRouteData> routes, @Nonnull Iterable<NePhysicalConnectionData> instances) {
        final INE newNe = new NEItem();
        fillExisting(type, ne, routes, instances, newNe);
        return newNe;
    }

    /**
     * Converts an NE domain entity into a new {@link INE} BCB object.
     *
     * @param type NE type metadata.
     * @param ne NE instance that will be the source of data.
     * @param instances Physical NE instances.
     * @return A new BCB INE instance filled with data.
     */
    public static INE convert(@Nonnull NeType type,
                              @Nonnull NeEntity ne, @Nonnull Iterable<NePhysicalConnectionData> instances) {
        final INE newNe = new NEItem();
        fillExisting(type, ne, Collections.emptyList(), instances, newNe);
        return newNe;
    }

}
