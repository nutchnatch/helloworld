package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionInitialData;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static com.ossnms.dcn_manager.bicnet.connector.facade.util.Exceptions.logAndRethrowAsBcb;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.mapping;
import static java.util.stream.Collectors.toSet;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * The purpose of this class is to ensure that all volatile repositories with physical
 * connection data are populated upon system startup.
 */
public class StandbyHelper {

    private static final Logger LOGGER = getLogger(StandbyHelper.class);

    private final MediatorEntityRepository mediatorRepository;
    private final MediatorInstanceEntityRepository mediatorInstanceRepository;

    private final ChannelEntityRepository channelRepository;
    private final ChannelPhysicalConnectionRepository channelInstanceRepository;

    private final NeEntityRepository neRepository;
    private final NePhysicalConnectionRepository neInstanceRepository;

    /**
     * Constructs a new instance with all repositories necessary.
     */
    public StandbyHelper(MediatorEntityRepository mediatorRepository,
            MediatorInstanceEntityRepository mediatorInstanceRepository,
            ChannelEntityRepository channelRepository,
             ChannelPhysicalConnectionRepository channelInstanceRepository,
            NeEntityRepository neRepository,
            NePhysicalConnectionRepository neInstanceRepository) {
        this.mediatorRepository = mediatorRepository;
        this.mediatorInstanceRepository = mediatorInstanceRepository;
        this.channelRepository = channelRepository;
        this.channelInstanceRepository = channelInstanceRepository;
        this.neRepository = neRepository;
        this.neInstanceRepository = neInstanceRepository;
    }

    /**
     * Determine which mediator instances will be active, according to a preference
     * setting provided by the caller.
     *
     * @param activeInstancePriority Preferred active instance priority (i.e., primary,
     *                               secondary, ...).
     * @throws BcbException
     */
    public void configureStandbyMediatorInstances(int activeInstancePriority) throws BcbException {
        final MediatorPhysicalConnectionRepository physicalConnectionRepository =
                mediatorInstanceRepository.getMediatorPhysicalConnectionRepository();

        LOGGER.info("Configuring data repositories for standby. Active priority = {}", activeInstancePriority);

        try {
            final Map<Integer, Set<Integer>> channelsUnderMediators = gatherChannelIdsUnderMediators();
            final Map<Integer, Set<Integer>> nesUnderChannels = gatherNeIdsUnderChannels();

            for (final MediatorInfoData infoData : mediatorRepository.getMediatorInfoRepository().queryAll()) {

                final Collection<Integer> channelIdsUnderMediator =
                        channelsUnderMediators.getOrDefault(infoData.getId(), Collections.emptySet());

                final List<MediatorInstance> mediatorInstances = // make a copy, we'll iterate the iterable twice.
                        ImmutableList.copyOf(mediatorInstanceRepository.queryAll(infoData.getId()));

                int mediatorActiveInstancePriority =
                        findBestAvailablePriority(activeInstancePriority, mediatorInstances);

                for (final MediatorInstance instance : mediatorInstances) {
                    final boolean active = instance.getPhysicalInfo().getPriority() == mediatorActiveInstancePriority;
                    final MediatorPhysicalConnectionMutationDescriptor connectionMutation =
                        new MediatorPhysicalConnectionMutationDescriptor(instance.getConnection())
                            .setActive(active);
                    final Optional<MediatorPhysicalConnectionData> updatedConnection =
                            physicalConnectionRepository.tryUpdate(connectionMutation);
                    LOGGER.debug("Configured Mediator Instance: {} / {}", updatedConnection.orElse(instance.getConnection()), instance.getPhysicalInfo());

                    final List<ChannelPhysicalConnectionData> channelInstances =
                        configureStandbyChannelInstances(channelIdsUnderMediator, instance.getPhysicalInfo().getId(), active);

                    configureStandbyNeInstances(channelInstances, nesUnderChannels);
                }
            }
        } catch (final RepositoryException e) {
            LOGGER.error("Failed to configure data repositories for standby!", e);
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    /**
     * Try to find an instance with the priority desired, or use some other existing instance priority.
     */
    private int findBestAvailablePriority(int desiredActiveInstancePriority, List<MediatorInstance> mediatorInstances) {
        return Iterables.tryFind(mediatorInstances,
            instance -> instance.getPhysicalInfo().getPriority() == desiredActiveInstancePriority)
        .transform(instance -> instance.getPhysicalInfo().getPriority())
        .or(mediatorInstances.isEmpty()
                ? MediatorInstance.PRIMARY_PRIORITY_LEVEL
                : mediatorInstances.get(0).getPhysicalInfo().getPriority());
    }

    private Map<Integer, Set<Integer>> gatherNeIdsUnderChannels() throws RepositoryException {
        return StreamSupport
            .stream(neRepository.getNeInfoRepository().queryAll().spliterator(), false)
            .collect(groupingBy(NeInfoData::getChannelId, mapping(NeInfoData::getId, toSet())));
    }

    private Map<Integer, Set<Integer>> gatherChannelIdsUnderMediators() throws RepositoryException {
        return StreamSupport
            .stream(channelRepository.getChannelInfoRepository().queryAll().spliterator(), false)
            .collect(groupingBy(ChannelInfoData::getMediatorId, mapping(ChannelInfoData::getId, toSet())));

    }

    private void configureStandbyNeInstances(List<ChannelPhysicalConnectionData> channelInstances, Map<Integer, Set<Integer>> nesUnderChannels) {

        for (final ChannelPhysicalConnectionData channelInstance : channelInstances) {

            nesUnderChannels.getOrDefault(channelInstance.getLogicalChannelId(), Collections.emptySet())
                .forEach(logicalNeId -> neInstanceRepository.insert(
                        new NePhysicalConnectionInitialData().setActive(channelInstance.isActive()),
                        logicalNeId, channelInstance.getId()));

        }

    }

    private List<ChannelPhysicalConnectionData> configureStandbyChannelInstances(Collection<Integer> channelIds, int mediatorInstanceId, boolean active) {
        return channelIds
            .stream()
            .map(channelId -> channelInstanceRepository.insert(new ChannelConnectionInitialData().setActive(active), channelId, mediatorInstanceId))
            .collect(Collectors.toList());
    }

}
