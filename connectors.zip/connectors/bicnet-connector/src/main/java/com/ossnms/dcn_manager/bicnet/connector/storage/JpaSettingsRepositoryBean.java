package com.ossnms.dcn_manager.bicnet.connector.storage;

import static org.slf4j.LoggerFactory.getLogger;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import org.slf4j.Logger;

import com.google.common.base.Supplier;
import com.ossnms.bicnet.bcb.facade.scs.ISystemControlEjbFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.factory.SystemContext;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.storage.settings.JpaSettingsRepositoryConnector;
import com.ossnms.dcn_manager.connector.storage.settings.entities.GlobalSettingsDb;

/**
 * EJB that maintains an instance of the repository of global EM/NE settings.
 */
@DcnManager
@ApplicationScoped
public class JpaSettingsRepositoryBean extends JpaSettingsRepositoryConnector {

    private static final Logger LOGGER = getLogger(JpaSettingsRepositoryBean.class);

    @Inject
    private JpaRepositoryBean repositoryBean;

    @Inject
    private ISystemControlEjbFacade scs;

    @Inject @DcnManager @SystemContext
    private ISessionContext systemContext;
        
    @Inject
    private StaticConfigurationSingleton configuration;
    
    private Supplier<CloseableEntityTransaction> transactionSupplier;

    public JpaSettingsRepositoryBean() {

    }

    @PostConstruct
    public void initialize() {
        transactionSupplier = repositoryBean.getTransactionSupplier();
    }

    @Override
    protected CloseableEntityTransaction getTransaction() {
        return transactionSupplier.get();
    }

    @Override
    public boolean areStandbyConnectionsAllowed() {
        try {
            return scs.isStandbyConfigured(systemContext);
        } catch (BcbException e) {
            LOGGER.error("Failed to obtain standby configuration from SCS.", e);
            return false;
        }
    }

    @Override
    protected GlobalSettingsDb injectStartupLimit(GlobalSettingsDb globalSettingsDb) {
        globalSettingsDb.setScaledStartupLimit(configuration.getHWConfiguration().getValue());        
        return globalSettingsDb;
    }
}
