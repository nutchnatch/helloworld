package com.ossnms.dcn_manager.bicnet.connector.outbound.connection;

/**
 * Contains mediation facade names.
 */
final class MediationFacade {

    private MediationFacade() {
        // Utility: Constant-only class.
    }

    static final String NE_PROXY_FACADE = "elementMgmt.NetworkElementProxy";
    static final String INIT_FACADE = "elementMgmt.InitStatePkg";
    static final String COMMUNICATION_FACADE = "elementMgmt.CommunicationStatePkg";
    static final String ELEMENT_MANAGER_FACADE = "elementMgmt.ElementManager";
    static final String ELEMENT_MANAGER_FACTORY_FACADE = "elementMgmt.IElementManagerFactory";

}
