package com.ossnms.dcn_manager.bicnet.connector.facade.util;

/**
 * Thrown during getXxxx calls when a markable filter requests predicates
 * that are not supported.
 */
public class UnsupportedQueryParametersException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * Constructs a new runtime exception with the specified detail message.
     * @param message The detail message.
     */
    public UnsupportedQueryParametersException(String message) {
        super(message);
    }

}
