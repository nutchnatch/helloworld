package com.ossnms.dcn_manager.bicnet.connector.outbound;

import com.google.common.base.Throwables;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmIdItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.AlarmItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.FaultManagerIdItem;
import com.ossnms.bicnet.bcb.facade.faultMgmt.IFaultMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.TimeOrigin;
import com.ossnms.bicnet.bcb.model.common.TrafficDirection;
import com.ossnms.bicnet.bcb.model.elementMgmt.ObjectTemplate;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmLogRecord;
import com.ossnms.bicnet.bcb.model.logMgmt.LogRecordFields;
import com.ossnms.bicnet.bcb.model.faultMgmt.AlarmSeverity;
import com.ossnms.bicnet.bcb.model.faultMgmt.FaultCondition;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarm;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmId;
import com.ossnms.bicnet.bcb.model.faultMgmt.IAlarmLogRecordId;
import com.ossnms.bicnet.bcb.model.faultMgmt.ProbableCause;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.outbound.Alarms;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import java.util.Arrays;
import java.util.Date;
import java.util.Optional;

public class AlarmsImpl implements Alarms {

    private static final ProbableCause COMMS_LINK_FAIL = ProbableCause.fromName("commsLinkFail");

    private static final Logger LOGGER = LoggerFactory.getLogger(AlarmsImpl.class);

    private static final ObjectTemplate neTemplate = ObjectTemplate.fromName("ne");

    private final IFaultMgrFacade faultManager;
    private final NeEntityRepository neRepository;
    private final ChannelEntityRepository channelRepository;
    private final ISessionContext sessionContext;

    @Inject
    public AlarmsImpl(
            @DcnManager IFaultMgrFacade faultManager,
            @DcnManager ISessionContext sessionContext,
            @DcnManager NeEntityRepository neRepository,
            @DcnManager ChannelEntityRepository channelRepository) {
        this.faultManager = faultManager;
        this.sessionContext = sessionContext;
        this.neRepository = neRepository;
        this.channelRepository = channelRepository;
    }

    @Override
    public boolean raiseConnectionLost(int neId, @Nonnull Optional<String> description) {
        try {
            final Optional<NeUserPreferencesData> nePreferencesFound =
                    neRepository.getNeUserPreferencesRepository().query(neId);
            final Optional<NeInfoData> neInfoFound =
                    neRepository.getNeInfoRepository().query(neId);

            if (neInfoFound.isPresent() && nePreferencesFound.isPresent()) {
                final NeInfoData neInfo = neInfoFound.get();
                if (neInfo.isCommsLostAlarmRaised()) {
                    LOGGER.warn("Not raising already raised connection lost alarm for NEid {}", neInfo.getNeId());
                } else {
                    final boolean raised = raiseConnectionLost(description, nePreferencesFound.get().getName(), neInfo);
                    updateAlarmRaisedStatus(neInfo, raised);
                    return raised;
                }
            } else {
                LOGGER.error("Failed to raise an alarm on NE# {} because the NE could not be found.", neId);
            }
        } catch (final RepositoryException e) {
            LOGGER.error("Failed to raise an alarm on NE# {} due to a repository error: {} {}",
                    neId, e.getMessage(), Throwables.getStackTraceAsString(e));
        } catch (final BcbException e) {
            LOGGER.error("Failed to raise an alarm on NE# {} due to a manager error: {} {}",
                    neId, e.getMessage(), Throwables.getStackTraceAsString(e));
        }
        return false;
    }

    @Override
    public boolean clearConnectionLost(int neId, boolean forceSynchronizationWithFault) {
        final IAlarmId alarmId = createConnectionLostAlarmIdentifier(neId);
        try {
            final Optional<NeInfoData> neStateFound =
                    neRepository.getNeInfoRepository().query(neId);
            if (neStateFound.isPresent()) {
                final NeInfoData stateData = neStateFound.get();
                //sometimes we may become desynchronized with fault. Here we try to force resynchronization
                // so we can clear the alarm
                if (stateData.isCommsLostAlarmRaised() || (forceSynchronizationWithFault && isAlarmRaised(alarmId))) {
                    faultManager.clearAlarm(sessionContext, new FaultManagerIdItem(),
                            alarmId, new Date(), TimeOrigin.POSTDATED);
                    updateAlarmRaisedStatus(stateData, false);
                    return true;
                }
            } else {
                LOGGER.warn("Not clearing connection lost alarm for unknown NE {}", neId);
            }
        } catch (final RepositoryException | BcbException e) {
            LOGGER.error("Failed to clear alarm {} due to error: {} {}", alarmId,
                    e.getMessage(), Throwables.getStackTraceAsString(e));
        }
        return false;
    }

    private boolean isAlarmRaised(IAlarmId alarmId) throws BcbException {

        final IAlarmLogRecord[] raisedAlarmsById = faultManager
                .getRaisedAlarmsById(sessionContext, new IAlarmId[]{alarmId},
                new LogRecordFields[]{LogRecordFields.ID});

        if (LOGGER.isDebugEnabled()){
            LOGGER.debug("Alarm fetched from FM {} for alarmID {}", Arrays.toString(raisedAlarmsById), alarmId);
        }

        return raisedAlarmsById != null && raisedAlarmsById.length > 0;
    }

    private void updateAlarmRaisedStatus(NeInfoData stateData, boolean alarmRaised) {
        final NeInfoMutationDescriptor mutation = new NeInfoMutationDescriptor(stateData)
            .setCommsLostAlarmRaised(alarmRaised);
        try {
            neRepository.getNeInfoRepository().tryUpdate(mutation);
        } catch (final RepositoryException e) {
            LOGGER.error("Failed to record the NE alarm raised status in the repository for NE {}: {} {}",
                stateData.getId(), e.getMessage(), Throwables.getStackTraceAsString(e));
        }
    }

    private boolean raiseConnectionLost(Optional<String> description, String neName, NeInfoData neInfo)
            throws RepositoryException, BcbException {
        final String channelName = getChannelName(neInfo);
        final IAlarm alarm =
            createConnectionLostAlarmItem(neInfo.getId(), neInfo.getChannelId(), neName, channelName, description.orElse(""));
        final IAlarmLogRecordId alarmLogId =
            faultManager.raiseAlarm(sessionContext, new FaultManagerIdItem(), alarm, TimeOrigin.POSTDATED);
        return alarmLogId != null;
    }

    private String getChannelName(final NeInfoData neInfo) throws RepositoryException {
        final Optional<ChannelUserPreferencesData> channelPreferences =
            channelRepository.getChannelUserPreferencesRepository().query(neInfo.getChannelId());
        final String channelName;
        if (channelPreferences.isPresent()) {
            channelName = channelPreferences.get().getName();
        } else {
            channelName = "";
            LOGGER.warn("Raising an NE alarm on an inexistant Channel for NE id {}.", neInfo.getNeId());
        }
        return channelName;
    }

    private IAlarmId createConnectionLostAlarmIdentifier(int neId) {
        return new AlarmIdItem(
            /* affectedObject */ new NEIdItem(neId),
            /* sourceComponentType */ BiCNetComponentType.DCN_MANAGER,
            /* sourceComponentName */ BiCNetComponentType.DCN_MANAGER.toString(),
            /* affectedObjectType */ neTemplate,
            /* affectedObjectLocation */ " ",
            /* probableCause */ COMMS_LINK_FAIL,
            /* probableCauseQualifier */ null,
            /* affectedObjectTypeExtendedGuiLabel */ neTemplate.guiLabelLong(),
            /* effectiveProbableCauseGuiLabel */ null);
    }

    private IAlarm createConnectionLostAlarmItem(int neId, int emId, @Nonnull String neName, @Nonnull String channelName,
            @Nonnull String additionalInfo) {
        return new AlarmItem(/* IMoFacet[] */null,
                /* affectedObject */new NEIdItem(neId),
                /* sourceComponentType */ BiCNetComponentType.DCN_MANAGER,
                /* sourceComponentName */ BiCNetComponentType.DCN_MANAGER.toString(),
                /* affectedObjectType */ neTemplate,
                /* affectedObjectLocation */ " ",
                /* probableCause */ COMMS_LINK_FAIL,
                /* probableCauseQualifier */ null,
                /* affectedObjectTypeExtendedGuiLabel */ neTemplate.guiLabelLong(),
                /* effectiveProbableCauseGuiLabel */ null,
                /* affectedNativeLocation */ " ",
                /* affectedPhysicalLocation */ " ",
                /* raiseTime */ new Date() ,
                /* severity */ AlarmSeverity.CRITICAL, // Default
                /* trafficDirection */ TrafficDirection.NONE,
                /* faultCondition */FaultCondition.NEUTRAL,
                /* equipmentType */ neTemplate,
                /* addtionalInfo */ additionalInfo,
                /* equipmentTypeExtendedGuiLabel */ neTemplate.guiLabelLong(),
                /* affectedNe */ neId,
                /* affectedNeName */ neName,
                /* affectedEmName */ channelName,
                /* affectedEm */ emId,
                /* subrackLocation */ " ");
    }

}
