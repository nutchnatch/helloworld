package com.ossnms.dcn_manager.bicnet.connector.facade;

import static com.google.common.collect.Iterables.toArray;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IAS;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IASId;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.DomainService;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.DomainHelper;

/**
 * "Private" facade bean that exposes an API for handling AS/EON/Domains.
 */
@Stateless(name = "DomainServiceBean")
@Local(DomainService.class)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class DomainServiceBean implements DomainService {

    @Inject
    private DomainHelper helper;

    /** {@inheritDoc} */
    @Override
    public IAS getSingleAS(final ISessionContext sessionContext, final IASId domainId) throws BcbException {
        return helper.getDomain(sessionContext, domainId);
    }

    /** {@inheritDoc} */
    @Override
    public IAS[] getASList(final ISessionContext sessionContext) throws BcbException {
        return toArray(helper.getDomains(sessionContext), IAS.class);
    }

    @Override
    public void setAutomaticNeActivationPolicy(final ISessionContext sessionContext, final IASId[] domainIds, final boolean allow) throws BcbException {
        helper.setAutomaticNeActivationPolicy(sessionContext, domainIds, allow);
    }
}
