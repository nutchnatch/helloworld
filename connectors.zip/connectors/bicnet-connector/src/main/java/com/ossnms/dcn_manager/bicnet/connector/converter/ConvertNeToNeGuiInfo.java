package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.ossnms.dcn_manager.bicnet.connector.common.entities.GuiActualActivationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeInfo;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.NeRouteInfo;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;

import javax.annotation.Nonnull;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.apache.commons.lang3.StringUtils.EMPTY;

/**
 * Handles conversion of internal domain entities representing an NE to its
 * corresponding type containing only GUI information.
 */
public final class ConvertNeToNeGuiInfo {

    static final boolean ACTIVE = true;
    static final boolean STANDBY = false;

    private ConvertNeToNeGuiInfo() {
    }

    /**
     * Builds an instance of {@link NeInfo} containing GUI information.
     *
     * @param entity NE entity.
     * @param instances Physical NE connections.
     * @return An instance of {@link NeInfo} containing GUI information.
     */
    public static NeInfo build(@Nonnull NeEntity entity, @Nonnull Iterable<NePhysicalConnectionData> instances, @Nonnull Iterable<NeGatewayRouteData> routes) {
        final Optional<ActualActivationState> standbyActualActivationState =
                findInstanceActualActivationState(instances, STANDBY);
        final Optional<ActualActivationState> activeActualActivationState =
                findInstanceActualActivationState(instances, ACTIVE);
        return new NeInfo(entity.getInfo().getNeId())
                .setGuiActualActivationState(activeActualActivationState.map(ConvertNeToNeGuiInfo::convert)
                        .orElseGet(() -> convert(entity.getConnection().getActivationState())))
                .setUserText(entity.getPreferences().getUserText().orElse(null))
                .setGuiStandbyActualActivationState(standbyActualActivationState.map(ConvertNeToNeGuiInfo::convert).orElse(null))
                .setStandbyDisplayState(standbyActualActivationState.map(ConvertNeToBcb::describe).orElse(EMPTY))
                .setNeRouteInfo(convertRoutes(routes))
                .setAdditionalTypeInfo(entity.getOperation().getAdditionalTypeInfo().orElse(null));
    }

    public static Set<NeRouteInfo> convertRoutes(Iterable<NeGatewayRouteData> routes) {
        List<NeRouteInfo> neRoutesInfo = StreamSupport.stream(routes.spliterator(), false)
                .map(route -> new NeRouteInfo(route.getDomain().orElse(EMPTY), route.getCost(), route.getGneName()))
                .collect(Collectors.toList());

        Set<NeRouteInfo> filtered = new HashSet<>();
        for (NeRouteInfo neRouteInfo : neRoutesInfo) {
            neRoutesInfo.stream()
                    .filter(route -> route.equals(neRouteInfo))
                    .min((route1, route2) -> Integer.compare(route1.getCost(), route2.getCost()))
                    .ifPresent(filtered::add);
        }

        return filtered;
    }


    static Optional<ActualActivationState> findInstanceActualActivationState(Iterable<NePhysicalConnectionData> instances, boolean active) {
        return StreamSupport.stream(instances.spliterator(), false)
            .filter(instance -> instance.isActive() == active)
            .findFirst()
            .map(NePhysicalConnectionData::getActualActivationState);
    }

    /**
     * Given the current connection state, obtain the corresponding state for displaying in the GUI.
     */
    public static GuiActualActivationState convert(@Nonnull final ActualActivationState activationState) {
        switch (activationState) {
            case INITIALIZING:
            case CONNECTING:
            case CONNECTED:
                return GuiActualActivationState.ACTIVATING;
            case STARTUP:
                return GuiActualActivationState.STARTINGUP;
            case INITIALIZED:
                return GuiActualActivationState.ACTIVE;
            case DISCONNECTED:
                return GuiActualActivationState.INACTIVE;
            case FAILED:
                return GuiActualActivationState.FAILED;
            case SHUTDOWN:
                return GuiActualActivationState.SHUTTINGDOWN;
            case DISCONNECTING:
                return GuiActualActivationState.DEACTIVATING;
            default:
                throw new IllegalStateException("Actual activation state without description: " + activationState);
        }
    }
}
