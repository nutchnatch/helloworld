package com.ossnms.dcn_manager.bicnet.connector.outbound.connection;

import com.google.common.base.Strings;
import com.google.common.base.Throwables;
import com.google.common.collect.FluentIterable;
import com.ossnms.bicnet.bcb.facade.elementMgmt.ElementManagerIdItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.IElementManagerFacade;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMMarkableItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.platform.IConnectionManager;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.bicnet.bcb.model.platform.PlatformException;
import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertEntryToBcbProperty;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.factory.SystemContext;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSettingsRepositoryBean;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemChannel;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.emne.SettingsProperties;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.channel.ChannelEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelCreatedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelCreatingEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatingEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelConnectionManager;
import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;
import com.ossnms.dcn_manager.core.properties.channel.ChannelProperties;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import java.util.Map;
import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertChannelToBcb.convert;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertIntegerToBcbEm.convert;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertMapToProperties.convertToProps;
import static org.apache.commons.lang3.ArrayUtils.isEmpty;

/**
 * @see ChannelConnectionManager
 */
public class ChannelConnectionManagerImpl implements ChannelConnectionManager {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChannelConnectionManagerImpl.class);


    private final IConnectionManager connectionManager;
    private final StaticConfigurationSingleton configuration;
    private final BicnetCallContext context;
    private final ChannelEntityRepository channelRepository;
    private final LoggerManager<BicnetCallContext> loggerManager;
    private final JpaSettingsRepositoryBean settingsRepository;
    private final MessageSource<ChannelEvent> channelEvents;
    private final ChannelPhysicalConnectionRepository channelInstanceRepository;

    @Inject
    public ChannelConnectionManagerImpl(
            @SystemContext BicnetCallContext context,
            @DcnManager IConnectionManager connectionManager,
            StaticConfigurationSingleton configuration,
            ChannelManagers channelManagers,
            @DcnManager JpaSettingsRepositoryBean settingsRepository,
            LoggerManager<BicnetCallContext> loggerManager) {
        this.connectionManager = connectionManager;
        this.configuration = configuration;
        this.context = context;
        this.channelRepository = channelManagers.getChannelRepository();
        this.settingsRepository = settingsRepository;
        this.loggerManager = loggerManager;
        this.channelEvents = channelManagers.getChannelEvents();
        this.channelInstanceRepository = channelManagers.getChannelInstanceConnections();
    }

    @Override
    public void connect(int instanceId) {
        final Optional<ChannelPhysicalConnectionData> channelInstance = findChannelInstance(instanceId);
        if (channelInstance.isPresent()) {
            final int channelId = channelInstance.get().getLogicalChannelId();
            final Optional<ChannelEntity> channel = findChannel(channelId);
            if (channel.isPresent()) {
                connect(channel.get(), channelInstance.get());
            } else {
                reportConnectionStateError(channelId, instanceId, channelInstance.get().isActive(),
                        findChannelName(channelId), new UnknownChannelIdException("Unknown Channel ID {}", channelId));
            }
        } else {
            reportConnectionStateError(0, instanceId, true, "", new UnknownChannelIdException("Unknown Channel Instance ID {}", instanceId));
        }
    }

    /**
     * @see ChannelConnectionManager#connect(ChannelState)
     *
     * <img src="doc-files/em-connmanger-connet-sequence.png">
     */
    /*
     * @startuml doc-files/em-connmanger-connet-sequence.png
     * ChannelConnectionManager --> "@P ConnectionManager": createDao
     * box "BicNet" #LightBlue
     *    participant "@P ConnectionManager"
     * end box
     * @enduml
     */
	protected void connect(@Nonnull ChannelEntity channel, @Nonnull ChannelPhysicalConnectionData channelInstance) {
        final ChannelInfoData info = channel.getInfo();
        final ChannelUserPreferencesData userPreferences = channel.getUserPreferences();
        final ChannelType channelType = configuration.getChannelTypes().get(info.getType());

        try {
            channelEvents.push(new PhysicalChannelCreatingEvent(channelInstance.getId(), info.getId(), channelInstance.isActive()));

            final Map<String, String> channelProperties = SettingsProperties.getProperties(settingsRepository.getSettings());
            channelProperties.putAll(new ChannelProperties().getProperties(channelType, userPreferences));

            final String[] facades = connectionManager.createElementManager(
                    context.getSessionContext(),
                    new MediatorIdItem(channelInstance.getMediatorInstanceId()),
                    convert(channelType, channel),
                    convertToProps(channelProperties));

            if (isEmpty(facades)) {
                final ConnectException connectException = new ConnectException("Channel id={} has no supported facades.", info.getId());
                reportConnectionStateError(info.getId(), channelInstance.getId(), channelInstance.isActive(), userPreferences.getName(), connectException);
            } else {
                channelEvents.push(new PhysicalChannelCreatedEvent(channelInstance.getId(), info.getId(), channelInstance.isActive()));
            }
        } catch (final BcbException e) {
            reportConnectionStateError(info.getId(), channelInstance.getId(), channelInstance.isActive(), userPreferences.getName(), e);
		}
	}

 	/**
     * @see ChannelConnectionManager#disconnect(com.ossnms.dcn_manager.composables.context.CallContext, ChannelEntity)
     *
     * <img src="doc-files/em-connmanger-disconnect-sequence.png">
     */
    /*
     * @startuml doc-files/em-connmanger-disconnect-sequence.png
     * ChannelConnectionManager --> "@P Layer": deactivateElementManager
     * ChannelConnectionManager --> "@P ConnectionManager": deleteDao
     * box "BicNet" #LightBlue
     *    participant "@P Layer"
     *    participant "@P ConnectionManager"
     * end box
     * @enduml
     */
    @Override
    public void disconnect(int instanceId) {
        final Optional<ChannelPhysicalConnectionData> channelInstance = findChannelInstance(instanceId);
        if (channelInstance.isPresent()) {
            final int channelId = channelInstance.get().getLogicalChannelId();
            final IEM em = convert(channelId);
            final ISessionContext sessionContext = context.getSessionContext();
            try {
                channelEvents.push(new PhysicalChannelDeactivatingEvent(channelInstance.get().getId(), channelId, channelInstance.get().isActive()));

                deleteElementManager(em,  channelInstance.get().getMediatorInstanceId(), sessionContext);

            } catch (final RuntimeException e) {
                 logConnectionStateError(findChannelName(channelId), channelInstance.get().isActive(), e);
            } finally {
                // ensure that the channel is marked as disconnected even in the case of an error
                channelEvents.push(new PhysicalChannelDeactivatedEvent(channelInstance.get().getId(), channelId, channelInstance.get().isActive()));
            }
        } else {
            reportConnectionStateError(0, instanceId, false, "", new UnknownChannelIdException("Unknown Channel Instance ID {}", instanceId));
        }
    }

    private void deleteElementManager(final IEM em, final int mediatorId, final ISessionContext sessionContext) {
        try {
            connectionManager.deleteElementManager(sessionContext, new MediatorIdItem(mediatorId), em);
        } catch (final RuntimeException | PlatformException e) {
            LOGGER.error("Error while releasing DAO for Channel {}. {} {}", em, e.getMessage(),
                    Throwables.getStackTraceAsString(e));
        }
    }

    @Override
    public void updateChannelProperties(int channelId, @Nonnull Map<String, String> properties) throws ConnectException {
        try {
            final IEM em = convert(channelId);
            final ISessionContext sessionContext = context.getSessionContext();

            final IElementManagerFacade elementManagerFacade = (IElementManagerFacade) connectionManager.getFacade(sessionContext, MediationFacade.ELEMENT_MANAGER_FACADE, em);

            elementManagerFacade.updateEM(
                    sessionContext,
                    new ElementManagerIdItem(channelId),
                    EMMarkableItem.of(em),
                    FluentIterable.from(properties.entrySet())
                        .transform(new ConvertEntryToBcbProperty())
                        .toArray(Property.class));

        } catch (final RuntimeException | BcbException e) {
            throw new ConnectException(e);
        }
    }

    private void reportConnectionStateError(int channelId, int instanceId, boolean isActive, String channelName, Exception e) {
        final String message = logConnectionStateError(channelName, isActive, e);

        channelEvents.push(new PhysicalChannelActivationFailedEvent(instanceId, channelId, isActive, message));
    }

    private String logConnectionStateError(String channelName, boolean isActive, Exception e) {
        final String message = Strings.nullToEmpty(Throwables.getRootCause(e).getMessage());

        loggerManager.createSystemEventLog(context,
            new LoggerItemChannel(
                StringUtils.join(new String[] {
                    channelName,
                    isActive ? null : "(standby)"
                }, ' '),
                StringUtils.join(new String[] {
                    "Error during channel activation/deactivation.",
                    message
                }, ' '),
                MessageSeverity.ERROR));

        LOGGER.error("Channel activation/deactivation error.", e);
        return message;
    }

    private Optional<ChannelEntity> findChannel(int id) {
        try {
            return channelRepository.queryChannel(id);
        } catch (final RepositoryException e) {
            LOGGER.error("Failed to query the repository for channel {}. {} {}", id, e.getMessage(), Throwables.getStackTraceAsString(e));
            return Optional.empty();
        }
    }

    private Optional<ChannelPhysicalConnectionData> findChannelInstance(int instanceId) {
        try {
            return channelInstanceRepository.query(instanceId);
        } catch (final RepositoryException e) {
            LOGGER.error("Failed to query the repository for channel instance {}. {} {}", instanceId, e.getMessage(), Throwables.getStackTraceAsString(e));
            return Optional.empty();
        }
    }

    protected String findChannelName(int id) {
        try {
            final Optional<ChannelUserPreferencesData> prefs = channelRepository.getChannelUserPreferencesRepository().query(id);
            if (prefs.isPresent()) {
                return prefs.get().getName();
            }
        } catch (final RepositoryException e) {
            LOGGER.error("Failed to query the repository for channel {}. {} {}", id, e.getMessage(), Throwables.getStackTraceAsString(e));
        }
        return "EM=" + id;
    }
}
