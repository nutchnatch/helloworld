package com.ossnms.dcn_manager.bicnet.connector.outbound.connection;

import com.google.common.base.Strings;
import com.google.common.base.Throwables;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.ImmutableSet;
import com.ossnms.bicnet.bcb.facade.elementMgmt.ElementManagerIdItem;
import com.ossnms.bicnet.bcb.facade.elementMgmt.ICommunicationStatePkgFacade;
import com.ossnms.bicnet.bcb.facade.elementMgmt.IElementManagerFacade;
import com.ossnms.bicnet.bcb.facade.elementMgmt.IGctMgrFacade;
import com.ossnms.bicnet.bcb.facade.elementMgmt.IInitStatePkgFacade;
import com.ossnms.bicnet.bcb.facade.elementMgmt.INetworkElementProxyFacade;
import com.ossnms.bicnet.bcb.facade.elementMgmt.NetworkElementProxyIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.platform.IMediationFacadeManager;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.elementMgmt.INeConfigurationCounterPkg;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementProxy;
import com.ossnms.bicnet.bcb.model.elementMgmt.InitMode;
import com.ossnms.bicnet.bcb.model.elementMgmt.InitScope;
import com.ossnms.bicnet.bcb.model.elementMgmt.InitState;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEMarkable;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.bicnet.bcb.model.platform.PlatformException;
import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertEntryToBcbProperty;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.factory.SystemContext;
import com.ossnms.dcn_manager.bicnet.connector.messaging.ne.NeEventSource;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemNe;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.NeSynchronizationEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeConnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeConnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeDisconnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeDisconnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeInitializedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeInitializingEvent;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;
import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;
import com.ossnms.dcn_manager.core.properties.ne.NeDirectRouteProperties;
import com.ossnms.dcn_manager.core.properties.ne.NeGatewayRouteProperties;
import com.ossnms.dcn_manager.core.properties.ne.NeProperties;
import com.ossnms.dcn_manager.core.storage.channel.ChannelPhysicalConnectionRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.Collections;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import static com.google.common.base.Throwables.getCausalChain;
import static com.google.common.base.Throwables.getRootCause;
import static com.google.common.base.Throwables.getStackTraceAsString;
import static com.google.common.collect.Iterables.concat;
import static com.google.common.collect.Iterables.tryFind;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb.convert;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb.updateMarkable;
import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * @see NeConnectionManager
 */
@ApplicationScoped // because of the proxy lock cache
public class NeConnectionManagerImpl implements NeConnectionManager {

    private static final Logger LOGGER = LoggerFactory.getLogger(NeConnectionManagerImpl.class);

    private final IGctMgrFacade gctManager;
    private final IMediationFacadeManager connectionManager;
    private final BicnetCallContext context;
    private final NeEntityRepository neRepository;
    private final StaticConfigurationSingleton configuration;
    private final LoggerManager<BicnetCallContext> loggerManager;
    private final NeEventSource neEvents;
    private final NePhysicalConnectionRepository neInstancesRepository;
    private final ChannelPhysicalConnectionRepository channelInstancesRepository;

    private static final long PROXY_LOCK_TIMEOUT_SECONDS = 120;

    /*
     * Used as an attempt at serializing calls to activate/deactivate NE proxies.
     * Such calls are the most problematic for mediators and until today they do not enforce any
     * thread safety themselves.
     */
    private final LoadingCache<Integer, Lock> proxyLockCache =
            CacheBuilder.newBuilder()
                    .weakValues()
                    .build(new CacheLoader<Integer, Lock>() {
                        @Override
                        public Lock load(@Nonnull Integer identifier) {
                            return new ReentrantLock();
                        }
                    });

    @Inject
    public NeConnectionManagerImpl(
            @SystemContext BicnetCallContext context,
            StaticConfigurationSingleton configuration,
            @DcnManager IGctMgrFacade gctManager,
            @DcnManager IMediationFacadeManager connectionManager,
            @DcnManager NeEntityRepository neRepository,
            @DcnManager NePhysicalConnectionRepository neInstancesRepository,
            @DcnManager ChannelPhysicalConnectionRepository channelInstancesRepository,
            LoggerManager<BicnetCallContext> loggerManager,
            NeEventSource neEvents) {
        this.context = context;
        this.configuration = configuration;
        this.gctManager = gctManager;
        this.connectionManager = connectionManager;
        this.neRepository = neRepository;
        this.neInstancesRepository = neInstancesRepository;
        this.channelInstancesRepository = channelInstancesRepository;
        this.loggerManager = loggerManager;
        this.neEvents = neEvents;
    }

    /** Default constructor to make the class proxyable by Jboss. */
    protected NeConnectionManagerImpl() {
        gctManager = null;
        connectionManager = null;
        context = null;
        neRepository = null;
        configuration = null;
        loggerManager = null;
        neEvents = null;
        neInstancesRepository = null;
        channelInstancesRepository = null;
    }

    /**
     * {@inheritDoc}
     * <p>This is an asynchronous call. Its result will be reported as an NE event.</p>
     * <p><img src="doc-files/neconnectionmanagerimpl-activate-sequence.png"/></p>
     */
    /*
     * @startuml doc-files/neconnectionmanagerimpl-activate-sequence.png
     * title Activation
     * database NeEntityRepository
     * participant NeEventSource
     * participant NeConnectionManagerImpl #FFBF00
     * NeConnectionManagerImpl -> NeEntityRepository : findNe()
     * activate NeEntityRepository
     * NeConnectionManagerImpl <-- NeEntityRepository : ne
     * deactivate NeEntityRepository
     * NeConnectionManagerImpl -> NeEventSource : push(NeConnectingEvent)
     * NeConnectionManagerImpl -> ConnectionManager : getDao(ElementManagerFacade)
     * activate ConnectionManager
     * boundary ElementManagerFacade
     * create ElementManagerFacade
     * ConnectionManager -> ElementManagerFacade : get
     * NeConnectionManagerImpl <-- ConnectionManager : elementManagerFacade
     * deactivate ConnectionManager
     * NeConnectionManagerImpl -> ElementManagerFacade : activateNetworkElementProxy()
     * activate ElementManagerFacade
     * NeConnectionManagerImpl <-- ElementManagerFacade : proxy
     * deactivate ElementManagerFacade
     * NeConnectionManagerImpl -> NeEntityRepository : updateNe(ne)
     * alt The proxy is not connected yet
     * NeConnectionManagerImpl -> ConnectionManager : getDao(CommunicationStatePkgFacade)
     * activate ConnectionManager
     * boundary CommunicationStatePkgFacade
     * create CommunicationStatePkgFacade
     * ConnectionManager -> CommunicationStatePkgFacade : new
     * NeConnectionManagerImpl <-- ConnectionManager : communicationStatePkgFacade
     * deactivate ConnectionManager
     * NeConnectionManagerImpl ->> CommunicationStatePkgFacade : connect()
     * else The proxy is already connected and compatible
     * NeConnectionManagerImpl -> NeEventSource : push(NeConnectedEvent)
     * ref over NeConnectionManagerImpl : Initialization
     * end
     * @enduml
     */
    @Override
    public void activate(@Nonnull RequiredNeStateEvent.Activate event) {

        try {
            LOGGER.info("Activating NE: {}", event);
            NePhysicalConnectionData neInstance = findNeInstance(event.getPhysicalNeId());

            try {
                final ChannelPhysicalConnectionData channelInstance = findChannelInstance(neInstance.getChannelInstanceId());
                final NeEntity ne = findNe(neInstance.getLogicalNeId());
                final NeInfoData neInfo = ne.getInfo();

                /*
                 * Activate the "NE proxy" at the mediation.
                 * No actual connection to the NE is attempted at this point.
                 */
                final INetworkElementProxy neProxy = activateNeProxy(ne, channelInstance);

                /*
                 * Update persisted NE information with any data that we may be able to gather from the
                 * proxy itself.
                 */
                updateNeInfoFromProxy(neInfo, neProxy);

                /*
                 * Validate the current instance connectivity state information. Remember that
                 * proxy activation at the mediation is an open call, which may take some time, and
                 * under high concurrency it is possible that a deactivation is trying to cancel
                 * this activation right now.
                 */
                neInstance = findNeInstance(event.getPhysicalNeId());
                if (neInstance.getActualActivationState() != ActualActivationState.STARTUP) {
                    LOGGER.warn("Cancelling activation prematurely, NE is no longer starting up: neID {}", neInstance.getId());
                    return;
                }

                /*
                 * The mediation may be already connected, in which case it will not report this event. Some
                 * circumstances will cause mediators not to report the current state on the proxy so we may
                 * be in the dark about this. Just emit the event internally.
                 */
                neEvents.push(new PhysicalNeConnectingEvent(neInstance.getId(), neInstance.getLogicalNeId(), neInstance.isActive()));

                if (neProxy.getCommunicationState() == CommunicationState.CONNECTED) {
                    /*
                     * The connection is already established at the mediation.
                     * Change the NE state here already to reflect this fact.
                     */
                    if (isProxyCompatible(neInfo, neProxy)) {
                        neEvents.push(new PhysicalNeConnectedEvent(neInstance.getId(), neInstance.getLogicalNeId(), neInstance.isActive()));
                        // initialization should be triggered by the Connected event handler.
                    } else {
                        LOGGER.error("Mismatched NE proxy type: found '{}', expected '{}'.",
                                neProxy.getType(), neInfo.getProxyType());
                        setError(findNeName(event.getNeId()), neInstance, tr(Message.MISMATCHED_NE_PROXY_TYPE));
                    }
                } else {
                    startConnection(context, neInstance.getLogicalNeId(), channelInstance);
                }

                LOGGER.debug("Invoked activation steps for NE: {}", event);
            } catch (final RepositoryException | RuntimeException | ConnectException | BcbException e) {
                setErrorOnException(findNeName(event.getNeId()), neInstance.getLogicalNeId(), neInstance.getId(), neInstance.isActive(), e);
            }

        } catch (final ConnectException e) {
            final String message = getExceptionMessage(e);
            reportConnectionStateError(findNeName(event.getNeId()), event.getNeId(), message);
        }
    }

    private boolean isProxyCompatible(NeInfoData neInfo, INetworkElementProxy proxy) {
        return neInfo.getProxyType().equals(proxy.getType());
    }

    private Optional<Lock> tryLock(int neId) {
        try {
            final Lock proxyLock = proxyLockCache.getUnchecked(neId);
            final boolean locked = proxyLock.tryLock(PROXY_LOCK_TIMEOUT_SECONDS, TimeUnit.SECONDS);
            if (locked) {
                return Optional.of(proxyLock);
            }
            LOGGER.warn("Abandoning NE {} proxy lock due to a timeout.", neId);
        } catch (InterruptedException e) {
            LOGGER.warn("NE {} proxy lock wait interrupted.", neId);
        }
        return Optional.empty();
    }

    private INetworkElementProxy activateNeProxy(NeEntity ne, ChannelPhysicalConnectionData channelInstance)
            throws ConnectException, BcbException {
        final Optional<Lock> lock = tryLock(ne.getInfo().getNeId());
        try {
            LOGGER.info("Activating Proxy for NE {} on channel instance {}", ne.getInfo().getId(), channelInstance.getId());
            final NeType type = findNeType(ne);
            final Iterable<NeGatewayRouteData> neRoutes = findNeRoutes(ne.getInfo().getNeId());
            final IElementManagerFacade emFacade = fetchElementManagerFacade(channelInstance);
            final Property[] neProperties = buildPropertyArray(ne, Collections.emptyMap());
            final INetworkElementProxy neProxy = emFacade.activateNetworkElementProxy(context.getSessionContext(),
                    new ElementManagerIdItem(channelInstance.getLogicalChannelId()),
                    convert(type, ne, neRoutes, Collections.emptyList()), // Connection Manager does not care about physical instance info
                    neProperties);
            LOGGER.info("Activated Proxy for NE {} in channel instance {}", neProxy, channelInstance);
            return neProxy;
        } finally {
            lock.ifPresent(Lock::unlock);
        }
    }

    private void deactivateNeProxy(int neId, int channelId, IElementManagerFacade emFacade) throws BcbException {
        final Optional<Lock> lock = tryLock(neId);
        try {
            LOGGER.info("Deactivating Proxy for NE {} on channel instance {}", neId, channelId);
            emFacade.deactivateNetworkElementProxy(context.getSessionContext(),
                    new ElementManagerIdItem(channelId), new NEIdItem(neId));
        } finally {
            LOGGER.info("Deactivated Proxy for NE {} on channel instance {}", neId, channelId);
            lock.ifPresent(Lock::unlock);
        }
    }

    private void startConnection(BicnetCallContext context, int logicalNeId, ChannelPhysicalConnectionData channelInstance)
            throws BcbException {
        final ICommunicationStatePkgFacade proxyFacade = (ICommunicationStatePkgFacade)
                connectionManager.getFacade(context.getSessionContext(), MediationFacade.COMMUNICATION_FACADE,
                        new MediatorIdItem(channelInstance.getMediatorInstanceId()),
                        new EMIdItem(channelInstance.getLogicalChannelId()));
        LOGGER.info("Connecting NE {} on channel instance {}", logicalNeId, channelInstance);
        proxyFacade.connect(context.getSessionContext(), new NetworkElementProxyIdItem(logicalNeId));
        LOGGER.debug("Invoked connect for NE {} on channel instance {}", logicalNeId, channelInstance);
    }

    private void updateNeInfoFromProxy(NeInfoData neInfo, INetworkElementProxy neProxy) throws RepositoryException {
        if (!Strings.isNullOrEmpty(neProxy.getIconIdId())) {
            final Optional<NeInfoData> updatedNeInfo =
                neRepository.getNeInfoRepository().tryUpdate(new NeInfoMutationDescriptor(neInfo)
                    .setIconId(neProxy.getIconIdId())
                );
            if (!updatedNeInfo.isPresent()) {
                LOGGER.warn("Could not update NE {} information with proxy data {}.", neInfo.getNeId(), neProxy);
            }
        }
    }

    /**
     * {@inheritDoc}
     * <p>This is an asynchronous call. Its result will be reported as an NE event.</p>
     * <p><img src="doc-files/neconnectionmanagerimpl-deactivate-sequence.png"/></p>
     */
    /*
     * @startuml doc-files/neconnectionmanagerimpl-deactivate-sequence.png
     * title Deactivation
     * database NeEntityRepository
     * participant NeEventSource
     * participant NeConnectionManagerImpl #FFBF00
     * NeConnectionManagerImpl -> NeEventSource : push(NeDisconnectingEvent)
     * NeConnectionManagerImpl -> NeEntityRepository : findNe()
     * activate NeEntityRepository
     * NeConnectionManagerImpl <-- NeEntityRepository : ne
     * deactivate NeEntityRepository
     * NeConnectionManagerImpl -> ConnectionManager : getDao(ElementManagerFacade)
     * activate ConnectionManager
     * boundary ElementManagerFacade
     * create ElementManagerFacade
     * ConnectionManager -> ElementManagerFacade : get
     * NeConnectionManagerImpl <-- ConnectionManager : elementManagerFacade
     * deactivate ConnectionManager
     * NeConnectionManagerImpl ->> ElementManagerFacade : deactivateNetworkElementProxy()
     * @enduml
     */
    @Override
    public void deactivate(@Nonnull RequiredNeStateEvent.Deactivate deactivate) {
        LOGGER.info("Deactivating NE: {}", deactivate);
        
        NePhysicalConnectionData neInstance;
        try {
            neInstance = findNeInstance(deactivate.getPhysicalNeId());

        } catch (final ConnectException e) {
            final String message = getExceptionMessage(e);
            reportConnectionStateError(findNeName(deactivate.getNeId()), deactivate.getNeId(), message);
            return;
        }
        /*
         * We provide immediate feedback to the user.
         */
        neEvents.push(new PhysicalNeDisconnectingEvent(neInstance.getId(), neInstance.getLogicalNeId(), neInstance.isActive()));

        if (neInstance.isActive()) {
            notifyGctOfDisconnection(neInstance.getLogicalNeId());
        }

        requestDeactivationOnMediation(deactivate, neInstance);

        /*
         * This is a "best effort only" deactivation attempt of the NE Proxy. As far as we're concerned,
         * the deactivation has succeeded regardless of the actual outcome at the mediation level.
         */
        neEvents.push(new PhysicalNeDisconnectedEvent(neInstance.getId(), neInstance.getLogicalNeId(), neInstance.isActive()));

    }

    private void requestDeactivationOnMediation(@Nonnull RequiredNeStateEvent.Deactivate deactivate, NePhysicalConnectionData neInstance) {
        try {

            final ChannelPhysicalConnectionData channelInstance = findChannelInstance(neInstance.getChannelInstanceId());
            if (channelInstance.isStateActive()) {
                final IElementManagerFacade emFacade = fetchElementManagerFacade(channelInstance);
                deactivateNeProxy(neInstance.getLogicalNeId(), channelInstance.getLogicalChannelId(), emFacade);
            } else {
                LOGGER.debug("Channel inactive, not invoking deactivate for NE {} on channel {}", deactivate, channelInstance);
            }

        } catch (final RuntimeException | ConnectException | BcbException e) {
            final String message = getExceptionMessage(e);
            reportConnectionStateError(findNeName(deactivate.getNeId()), deactivate.getNeId(), message);
        }
    }

    private void notifyGctOfDisconnection(int neId) {
        LOGGER.debug("GCT unadvise for NE {}.", neId);
        try {
            gctManager.unadviseGctSession(context.getSessionContext(), neId, null);
        } catch (BcbException e) {
            LOGGER.error("GCT unadvise failed for NE {}: {}", neId, getStackTraceAsString(e));
        }
    }

    /**
     * {@inheritDoc}
     * <p>This is an asynchronous call. Its result will be reported as an NE event.</p>
     * <p><img src="doc-files/neconnectionmanagerimpl-initialize-sequence.png"/></p>
     */
    /*
     * @startuml doc-files/neconnectionmanagerimpl-initialize-sequence.png
     * title Initialization
     * database NeEntityRepository
     * participant NeEventSource
     * participant NeConnectionManagerImpl #FFBF00
     * NeConnectionManagerImpl -> NeEntityRepository : findNe()
     * activate NeEntityRepository
     * NeConnectionManagerImpl <-- NeEntityRepository : ne
     * deactivate NeEntityRepository
     * NeConnectionManagerImpl -> ConnectionManager : getDao(ElementManagerFacade)
     * activate ConnectionManager
     * boundary ElementManagerFacade
     * create ElementManagerFacade
     * ConnectionManager -> ElementManagerFacade : get
     * NeConnectionManagerImpl <-- ConnectionManager : elementManagerFacade
     * deactivate ConnectionManager
     * NeConnectionManagerImpl -> NeEventSource : push(NeInitializingEvent)
     * NeConnectionManagerImpl -> ElementManagerFacade : activateNetworkElementProxy()
     * activate ElementManagerFacade
     * NeConnectionManagerImpl <-- ElementManagerFacade : proxy
     * deactivate ElementManagerFacade
     * alt The proxy is not initialized yet
     * NeConnectionManagerImpl -> ConnectionManager : getDao(CommunicationStatePkgFacade)
     * activate ConnectionManager
     * boundary InitStatePkgFacade
     * create InitStatePkgFacade
     * ConnectionManager -> InitStatePkgFacade : new
     * NeConnectionManagerImpl <-- ConnectionManager : initStatePkgFacade
     * deactivate ConnectionManager
     * NeConnectionManagerImpl ->> InitStatePkgFacade : initialize()
     * else The proxy is already initialized
     * NeConnectionManagerImpl -> NeEventSource : push(NeInitializedEvent)
     * end
     * @enduml
     */
    @Override
    public void lazyInitialize(@Nonnull NeSynchronizationEvent event) {
        try {
            LOGGER.info("Lazily initializing NE: {}", event);
            final NePhysicalConnectionData neInstance = findNeInstance(event.getPhysicalNeId());

            try {
                final ChannelPhysicalConnectionData channelInstance = findChannelInstance(neInstance.getChannelInstanceId());
                final NeEntity ne = findNe(event.getNeId());
                final INetworkElementProxy neProxy = activateNeProxy(ne, channelInstance);

                /*
                 * The mediation may be running an initialization already, or it may take a while to respond.
                 */
                neEvents.push(new PhysicalNeInitializingEvent(neInstance.getId(), neInstance.getLogicalNeId(), neInstance.isActive()));

                if (neProxy.getInitState() != InitState.INITIALIZED) {
                    /*
                     * We must request a new initialization.
                     */
                    startInitialization(neInstance.getLogicalNeId(), channelInstance.getLogicalChannelId(), channelInstance.getMediatorInstanceId(),
                            neInstance.getActualActivationMode());
                } else {
                    /*
                     * The mediation is already initialized against the NE. Change its state here already.
                     */
                    neEvents.push(new PhysicalNeInitializedEvent(neInstance.getId(), neInstance.getLogicalNeId(), neInstance.isActive()));
                }
            } catch (final RuntimeException | ConnectException | BcbException e) {
                setErrorOnException(findNeName(event.getNeId()), neInstance.getLogicalNeId(), neInstance.getId(), neInstance.isActive(), e);
            }

        } catch (final ConnectException e) {
            final String message = getExceptionMessage(e);
            reportConnectionStateError(findNeName(event.getNeId()), event.getNeId(), message);
        }
    }

    /**
     * {@inheritDoc}
     * <p>This is an asynchronous call. Its result will be reported as an NE event.</p>
     * @see #lazyInitialize(NeSynchronizationEvent)
     */
    @Override
    public void alwaysInitialize(@Nonnull NeSynchronizationEvent event) {
        try {
            final NePhysicalConnectionData neInstance = findNeInstance(event.getPhysicalNeId());

            try {
                final ChannelPhysicalConnectionData channelInstance = findChannelInstance(event.getPhysicalChannelId());
                startInitialization(neInstance.getLogicalNeId(), channelInstance.getLogicalChannelId(),
                        channelInstance.getMediatorInstanceId(), neInstance.getActualActivationMode());
            } catch (final RuntimeException | ConnectException | BcbException e) {
                setErrorOnException(findNeName(event.getNeId()), neInstance.getLogicalNeId(), neInstance.getId(), neInstance.isActive(), e);
            }

        } catch (final ConnectException e) {
            final String message = getExceptionMessage(e);
            reportConnectionStateError(findNeName(event.getNeId()), event.getNeId(), message);
        }
    }

    private void startInitialization(int neId, int channelId, int mediatorId, @Nonnull ActualActivationMode actualActivationMode)
            throws BcbException {
        final IInitStatePkgFacade initFacade = (IInitStatePkgFacade)
                connectionManager.getFacade(context.getSessionContext(), MediationFacade.INIT_FACADE,
                        new MediatorIdItem(mediatorId), new EMIdItem(channelId));
        InitMode initMode = actualActivationMode == ActualActivationMode.CONNECT_RECOVER ? InitMode.INIT_DELTA : InitMode.INIT_FULL;
        LOGGER.info("Initializing NE #{} in mode {}", neId, initMode);
        initFacade.initialize(context.getSessionContext(), new NetworkElementProxyIdItem(neId), initMode, InitScope.INIT_ALL);
        LOGGER.debug("Invoked initialize for NE #{}", neId);
    }

    @Override
    public void updateNeProperties(
            @Nonnull NeEntity ne, @Nonnull NePhysicalConnectionData neInstance,
            @Nonnull NeUserPreferencesMutationDescriptor newPreferences, @Nonnull Map<String, String> updatedEmptyProperties)
            throws ConnectException {
        final ChannelPhysicalConnectionData channelInstance = findChannelInstance(neInstance.getChannelInstanceId());

        try {
            final INetworkElementProxyFacade neFacade = (INetworkElementProxyFacade)
                    connectionManager.getFacade(context.getSessionContext(), MediationFacade.NE_PROXY_FACADE,
                            new MediatorIdItem(channelInstance.getMediatorInstanceId()), new EMIdItem(channelInstance.getLogicalChannelId()));

            final NEItem bcbNe = new NEItem();
            bcbNe.setId(neInstance.getLogicalNeId());
            bcbNe.setNeProxyType(ne.getInfo().getProxyType());
            final INEMarkable bcbNeMarkable = bcbNe.toMarkableNE();
            updateMarkable(bcbNeMarkable, newPreferences);

            final Property[] neProperties = buildPropertyArray(ne, updatedEmptyProperties);

            neFacade.updateNE(
                    context.getSessionContext(),
                    new NetworkElementProxyIdItem(neInstance.getLogicalNeId()),
                    bcbNeMarkable,
                    neProperties
            );
        } catch (RuntimeException | BcbException e) {
            throw new ConnectException(e);
        }
    }

    private Property[] buildPropertyArray(@Nonnull NeEntity ne, Map<String, String> updatedEmptyProperties) throws ConnectException {
        final NeType type = findNeType(ne);
        final Iterable<NeGatewayRouteData> neRoutes = findNeRoutes(ne.getInfo().getNeId());
        final ImmutableSet<? extends Entry<String, String>> propertySet = FluentIterable
                .from(concat(
                        new NeProperties().getProperties(type, ne).entrySet(),
                        new NeDirectRouteProperties().toProperties(ne).entrySet(),
                        new NeGatewayRouteProperties(type).toProperties(ne, neRoutes).entrySet(),
                        updatedEmptyProperties.entrySet()))
                .toSet();
        final Property[] propertyArray =
            //Removed filtering null or empty values because empty properties (like SFTP details) must be sent to mediation.
            FluentIterable.from(propertySet)
                .transform(new ConvertEntryToBcbProperty())
                .toArray(Property.class);
        LOGGER.debug("Preparing properties for NE {}, {} with {}", ne.getInfo().getNeId(), ne.getPreferences().getName(),
                propertyArray);
        return propertyArray;
    }

    /**
     * Retrieves the difference of NE configuration/synchronization counters/stamps from the
     * mediator. Nothing will be returned if the target mediator/NE does not support this
     * feature.
     *
     * @param ne NE entity.
     * @param neInstance Target physical NE connection.
     * @return The different values.
     * @throws ConnectException Should an error occur while communicating with the mediator
     * or south-bound components.
     */
    public Optional<NeSynchronizationMutationDescriptor> getCurrentSynchronizationData(NeEntity ne, NePhysicalConnectionData neInstance)
            throws ConnectException {
        try {
            final ChannelPhysicalConnectionData channelInstance = findChannelInstance(neInstance.getChannelInstanceId());
            final INetworkElementProxy proxy = activateNeProxy(ne, channelInstance);
            final INeConfigurationCounterPkg facet = (INeConfigurationCounterPkg) proxy.getFacette(INeConfigurationCounterPkg.class);
            if (null != facet) {
                final NeSynchronizationMutationDescriptor descriptor = new NeSynchronizationMutationDescriptor(ne.getSync());
                if (facet.getAllCategoryCounterHash() > 0) {
                    descriptor.setAll(facet.getAllCategoryCounterHash());
                }
                if (facet.getAlarmsCategoryCounterHash() > 0) {
                    descriptor.setAlarms(facet.getAlarmsCategoryCounterHash());
                }
                if (facet.getPacketCategoryCounterHash() > 0) {
                    descriptor.setPacket(facet.getPacketCategoryCounterHash());
                }
                return Optional.of(descriptor);
            }
            return Optional.empty();
        } catch (final BcbException e) {
            throw new ConnectException(e);
        }
    }

    private ChannelPhysicalConnectionData findChannelInstance(int channelInstanceId) throws ConnectException {
        try {
            final Optional<ChannelPhysicalConnectionData> channelInstance = channelInstancesRepository.query(channelInstanceId);
            if (!channelInstance.isPresent()) {
                throw new ConnectException("Unknown Channel Instance: {}", channelInstanceId);
            }
            return channelInstance.get();
        } catch (final RepositoryException exception) {
            throw new ConnectException(exception);
        }
    }

    private NePhysicalConnectionData findNeInstance(int neInstanceId) throws ConnectException {
        try {
            final Optional<NePhysicalConnectionData> neInstance = neInstancesRepository.query(neInstanceId);
            if (!neInstance.isPresent()) {
                throw new ConnectException("Unknown NE Instance: {}", neInstanceId);
            }
            return neInstance.get();
        } catch (final RepositoryException exception) {
            throw new ConnectException(exception);
        }
    }

    private NeEntity findNe(int neId) throws ConnectException {
        try {
            final Optional<NeEntity> ne = neRepository.queryNe(neId);
            if (!ne.isPresent()) {
                throw new ConnectException("Unknown NE: {}", neId);
            }
            return ne.get();
        } catch (final RepositoryException exception) {
            throw new ConnectException(exception);
        }
    }

    private Iterable<NeGatewayRouteData> findNeRoutes(int neId) throws ConnectException {
        try {
            return neRepository.getNeGatewayRoutesRepository().queryRoutes(neId);
        } catch (final RepositoryException exception) {
            throw new ConnectException(exception);
        }
    }

    private String findNeName(int neId) {
        try {
            final Optional<String> neName = neRepository.queryNeName(neId);
            if (neName.isPresent()) {
                return neName.get();
            }
        } catch (final RepositoryException exception) {
            LOGGER.error("Error searching for NE {} name: {} {}", neId, exception.getMessage(),
                    Throwables.getStackTraceAsString(exception));
        }
        return "NE=" + neId;
    }

    private NeType findNeType(NeEntity ne) throws ConnectException {
        final String typeName = ne.getInfo().getProxyType();
        final NeType neType = configuration.getNeTypes().get(typeName);
        if (null == neType) {
            throw new ConnectException("Unknown NE type: {}", typeName);
        }
        return neType;
    }

    private void reportConnectionStateError(String neName, int neId, String message) {
        LOGGER.warn("Reporting NE activation/deactivation error: {}", message);
        loggerManager.createSystemEventLog(context,
            new LoggerItemNe(
                neName,
                "Error during NE activation/deactivation. " + message,
                neId,
                MessageSeverity.ERROR));
    }

    private void setErrorOnException(String neName, int neId, int neInstanceId, boolean isActive, Exception e) {
        final String message = getExceptionMessage(e);
        reportConnectionStateError(neName, neId, message);
        neEvents.push(new PhysicalNeActivationFailedEvent(neInstanceId, neId, isActive, message));
        LOGGER.error("NE Connection error: {} {}", e.getMessage(), Throwables.getStackTraceAsString(e));
    }

    /**
     * Given an exception e, we will go through its causes and use the message from the first
     * BiCNet component in the chain. Should we be unable to find one, compute the root cause
     * message as usual.
     *
     * @param e Exception caught.
     * @return The most relevant exception message.
     */
    @SuppressWarnings("ThrowableResultOfMethodCallIgnored")
    private String getExceptionMessage(Exception e) {
        final Throwable selectedCause =
                tryFind(getCausalChain(e), t -> t instanceof BcbException)
                    .or(() -> getRootCause(e));
        return Strings.nullToEmpty(selectedCause.getMessage());
    }

    private void setError(String neName, NePhysicalConnectionData neInstance, String message) {
        reportConnectionStateError(neName, neInstance.getLogicalNeId(), message);
        neEvents.push(new PhysicalNeActivationFailedEvent(neInstance.getId(), neInstance.getLogicalNeId(), neInstance.isActive(), message));
        LOGGER.error("NE Connection error: {}", message);
    }

    private IElementManagerFacade fetchElementManagerFacade(ChannelPhysicalConnectionData channelInstance)
            throws PlatformException, ConnectException {
        final IElementManagerFacade facade = (IElementManagerFacade) connectionManager.getFacade(
                context.getSessionContext(), MediationFacade.ELEMENT_MANAGER_FACADE,
                new MediatorIdItem(channelInstance.getMediatorInstanceId()), new EMIdItem(channelInstance.getLogicalChannelId()));
        if (facade == null) {
            // if the facade comes out null from Connection Manager, most probably the channel is not connected.
            throw new ConnectException("Channel not active.");
        }
        return facade;
    }

    public void setGlobalProperties(ISessionContext sessionContext, Map<String, String> properties) {
        connectionManager.setDcnGlobalProperties(sessionContext, properties);
    }
}
