package com.ossnms.dcn_manager.bicnet.events;

import com.ossnms.bicnet.bcb.facade.common.BiCNetComponentIdItem;
import com.ossnms.bicnet.bcb.facade.scs.IScsFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.IBiCNetComponentId;
import com.ossnms.bicnet.bcb.model.elementMgmt.CategoryOutOfSync;
import com.ossnms.bicnet.bcb.model.platform.SynchNotification;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncMode;
import com.ossnms.bicnet.bcb.model.scs.ScsSyncState;
import com.ossnms.bicnet.messaging.util.BiCNetMessageBuilder;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationState;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.ScsSynchronizationStateNotification;
import com.ossnms.dcn_manager.bicnet.connector.messaging.DecoratedNotification;
import com.ossnms.dcn_manager.bicnet.connector.storage.InMemoryNeSyncStateRepository;
import org.slf4j.Logger;
import rx.Observable;

import javax.annotation.Nonnull;

import java.util.Optional;

import static org.slf4j.LoggerFactory.getLogger;

/**
 * <p>Dispatches BiCNet events within the BiCNet Connector layer only.</p>
 *
 * <p>Some events have behavior that is tightly coupled with the BiCNet architecture and
 * TNMS components. Therefore it does not make sense to propagate such dependencies to
 * the EM/NE core.</p>
 */
public class BiCNetIncomingEventDispatcher {

    private static final Logger LOGGER = getLogger(BiCNetIncomingEventDispatcher.class);

    private final InMemoryNeSyncStateRepository syncStateRepository;
    private final IBiCNetMessageDispatcher messageDispatcher;
    private final IScsFacade scs;
    @Nonnull
    private final ISessionContext systemContext;

    /**
     * Creates a new instance.
     *
     */
    public BiCNetIncomingEventDispatcher(
            @Nonnull InMemoryNeSyncStateRepository syncStateRepository,
            @Nonnull IBiCNetMessageDispatcher messageDispatcher,
            @Nonnull IScsFacade scs,
            @Nonnull ISessionContext systemContext) {
        this.syncStateRepository = syncStateRepository;
        this.messageDispatcher = messageDispatcher;
        this.scs = scs;
        this.systemContext = systemContext;
    }


    /**
     * Initializes dispatching of events emitted by an event source.
     *
     * @param notificationSource Event source as an instance of {@link Observable}.
     */
    public final void initialize(Observable<DecoratedNotification> notificationSource) {

        notificationSource
            .map(n -> n.getNotification(SynchNotification.class))
            .filter(Optional::isPresent).map(Optional::get)
            .subscribe(this::updateAndForwardScsSynchronizationState);

        notificationSource
            .map(n -> n.getNotification(CategoryOutOfSync.class))
            .filter(Optional::isPresent).map(Optional::get)
            .filter(n -> n.getCategory() != null)
            .subscribe(this::resyncCategoryByMediationRequest);

    }

    private void resyncCategoryByMediationRequest(CategoryOutOfSync notification) {
        try {
            int neId = notification.getSenderIdNeId();
            final BiCNetComponentIdItem componentIdItem =
                    new BiCNetComponentIdItem(BiCNetComponentType.ELEMENT_MANAGER, 0, neId);
            LOGGER.info("Mediation requested {} synchronization of NE {} from SCS.", notification.getCategory(), neId);
            scs.triggerForcedSync(systemContext,
                    new IBiCNetComponentId[] { componentIdItem },
                    ScsSyncMode.HARD_SYNC, notification.getCategory());
        } catch (final BcbException e) {
            LOGGER.error("Failed to request synchronization of NE from SCS.", e);
        }
    }

    private void updateAndForwardScsSynchronizationState(SynchNotification notification) {
        final ScsSyncState state = notification.getSyncState();
        if (null != state) {
            final ScsSynchronizationState synchronizationState = new ScsSynchronizationState(
                    notification.getSyncObject().neId().getNeId(),
                    state,
                    notification.getMessage());

            LOGGER.debug("Received SCS sync state: {}", synchronizationState);

            syncStateRepository.tryUpdate(synchronizationState);

            final IBiCNetMessage message = new BiCNetMessageBuilder()
                .asPrivate()
                .withPayload(new ScsSynchronizationStateNotification(synchronizationState))
                .from(BiCNetComponentType.DCN_MANAGER.toString())
                .build();
            messageDispatcher.sendToClient(message);
        }
    }

}
