package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.ossnms.bicnet.bcb.facade.common.IMOUsagePkgFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentTypes;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToBcb;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.outbound.notifications.NeNotificationsManagerImpl;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;

import javax.inject.Inject;

import java.util.Optional;

import static com.ossnms.dcn_manager.bicnet.connector.facade.util.Exceptions.logAndRethrowAsBcb;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * <p>Managed object usage handling.</p>
 *
 * <p>Note that the connector does not use a Command for updating the NE usage information.
 * Core NE domain objects do not interpret the NE usage in any way and do not have any
 * dedicated data format to represent it. Therefore all conversion to and from BCB happens
 * at this level.</p>
 *
 * <p>A Command is not used because it would not make much sense to create one Command
 * specifically to update a single attribute in one domain entity. Especially because
 * this attribute is managed solely to satisfy a usage pattern that is specific to
 * BiCNet.</p>
 */
public class MOHelper implements IMOUsagePkgFacade {

    private static final Logger LOGGER = getLogger(MOHelper.class);

    @Inject @DcnManager
    private NeEntityRepository neRepository;

    @Inject
    private NeNotificationsManagerImpl notifications;

    /**
     * Registers NE usage by other components.
     *
     * @param sessionContext BiCNet session information.
     * @param managedObjectId Instance of {@link INEId} that identifies the target NE.
     * @throws BcbException If {@code managedObjectId} is not an instance of {@link INEId},
     *  if there is no NE with the ID provided or if it was not possible to store the
     *  new usage information in the repository.
     */
    @Override
    public void addUsage(ISessionContext sessionContext, IManagedObjectId managedObjectId, BiCNetComponentType componentType)
            throws BcbException {
        if (managedObjectId instanceof INEId) {
            final NeInfoData neInfo = findNeInfo(managedObjectId.neId().getNeId());
            final BiCNetComponentTypes currentUsage = ConvertNeToBcb.convertUsage(neInfo.getUsedBy());
            // this check is not really necessary since usage is a set, but we'll try to avoid an unnecessary store.
            if (!currentUsage.contains(componentType)) {
                currentUsage.add(componentType);
                storeUsageAndNotifyChange(neInfo, currentUsage);
            }
        } else {
            throw new BcbException("Unsupported managed object: " + managedObjectId);
        }
    }

    /**
     * Removes usage of the NE by other components.
     *
     * @param sessionContext BiCNet session information.
     * @param managedObjectId Instance of {@link INEId} that identifies the target NE.
     * @throws BcbException If {@code managedObjectId} is not an instance of {@link INEId},
     *  if there is no NE with the ID provided or if it was not possible to store the
     *  new usage information in the repository.
     */
    @Override
    public void releaseUsage(ISessionContext sessionContext, IManagedObjectId managedObjectId, BiCNetComponentType componentType)
            throws BcbException {
        if (managedObjectId instanceof INEId) {
            final NeInfoData neInfo = findNeInfo(managedObjectId.neId().getNeId());
            final BiCNetComponentTypes currentUsage = ConvertNeToBcb.convertUsage(neInfo.getUsedBy());
            // this check is not really necessary since usage is a set, but we'll try to avoid an unnecessary store.
            if (currentUsage.contains(componentType)) {
                currentUsage.remove(componentType);
                storeUsageAndNotifyChange(neInfo, currentUsage);
            }
        } else {
            throw new BcbException("Unsupported managed object: " + managedObjectId);
        }
    }

    private void storeUsageAndNotifyChange(final NeInfoData neInfo,
            final BiCNetComponentTypes currentUsage) throws BcbException {
        final NeInfoMutationDescriptor mutation =
            new NeInfoMutationDescriptor(neInfo)
                .setUsedBy(currentUsage.toDbString());
        updateNeInfo(mutation);
        notifications.notifyChanges(mutation);
    }

    private void updateNeInfo(NeInfoMutationDescriptor mutation) throws BcbException {
        try {
            final Optional<NeInfoData> updatedNeInfo =
                    neRepository.getNeInfoRepository().tryUpdate(mutation);
            if (!updatedNeInfo.isPresent()) {
                throw new BcbException("Could not store the new usage information for NE " + mutation.getTarget().getNeId());
            }
        } catch (final RepositoryException exception) {
            throw logAndRethrowAsBcb(exception, LOGGER);
        }
    }

    private NeInfoData findNeInfo(int neId) throws BcbException {
        try {
            final Optional<NeInfoData> neInfo =
                    neRepository.getNeInfoRepository().query(neId);
            if (!neInfo.isPresent()) {
                throw new BcbException("Unknown NE ID " + neId);
            }
            return neInfo.get();
        } catch (final RepositoryException exception) {
            throw logAndRethrowAsBcb(exception, LOGGER);
        }
    }
}
