package com.ossnms.dcn_manager.bicnet.connector.security;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.ossnms.dcn_manager.bicnet.connector.common.security.SecureAction;

/**
 * <p>Marks methods that represent a secure operation: their
 * execution will be validated against a security authority.
 * An instance of {@link SecureAction} must be provided in the
 * annotation in order to specify the method identifier for validation.</p>
 * <p>May be used in conjunction with {@link SecuredObject}.</p>
 * @see SecureActionValidation
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Securable {

    /**
     * Method identifier, used during validation.
     */
    SecureAction value();

}
