package com.ossnms.dcn_manager.bicnet.connector.outbound.connection;

import com.google.common.base.Throwables;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.platform.IConnectionManager;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.platform.BcbSessionRole;
import com.ossnms.bicnet.bcb.model.platform.DuplicatedSessionException;
import com.ossnms.dcn_manager.bicnet.connector.configuration.StaticConfigurationSingleton;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.factory.SystemContext;
import com.ossnms.dcn_manager.bicnet.connector.messaging.MediatorEventSource;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaSettingsRepositoryBean;
import com.ossnms.dcn_manager.composables.outbound.LoggerManager;
import com.ossnms.dcn_manager.composables.outbound.dtos.LoggerItemMediator;
import com.ossnms.dcn_manager.composables.outbound.dtos.MessageSeverity;
import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.entities.emne.SettingsProperties;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorDeactivatingEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorConnectionManager;
import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;
import com.ossnms.dcn_manager.core.properties.mediator.MediatorProperties;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorIdException;
import com.ossnms.dcn_manager.i18n.Message;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.google.common.base.Strings.nullToEmpty;
import static com.google.common.base.Throwables.getRootCause;
import static com.google.common.base.Throwables.getStackTraceAsString;
import static com.ossnms.dcn_manager.bicnet.connector.converter.ConvertMapToProperties.convertToProps;
import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * @see MediatorConnectionManager
 */
public class MediatorConnectionManagerImpl implements MediatorConnectionManager {

    private final MediatorEventSource mediatorEvents;
    private final BicnetCallContext context;
    private final IConnectionManager connectionManager;
    private final JpaSettingsRepositoryBean settingsRepository;
    private final MediatorEntityRepository mediatorRepository;
    private final MediatorInstanceEntityRepository mediatorInstancesRepository;
    private final StaticConfigurationSingleton configuration;
    private final LoggerManager<BicnetCallContext> loggerManager;

    private static final Logger LOGGER = LoggerFactory.getLogger(MediatorConnectionManagerImpl.class);

    @Inject
    public MediatorConnectionManagerImpl(
            @SystemContext BicnetCallContext context,
            @DcnManager IConnectionManager connectionManager,
            StaticConfigurationSingleton configuration,
            @DcnManager JpaSettingsRepositoryBean settingsRepository,
            @DcnManager MediatorEntityRepository mediatorRepository,
            @DcnManager MediatorInstanceEntityRepository mediatorInstancesRepository,
            LoggerManager<BicnetCallContext> loggerManager,
            MediatorEventSource mediatorEvents) {
        this.connectionManager = connectionManager;
        this.configuration = configuration;
        this.context = context;
        this.settingsRepository = settingsRepository;
        this.mediatorRepository = mediatorRepository;
        this.mediatorInstancesRepository = mediatorInstancesRepository;
        this.loggerManager = loggerManager;
        this.mediatorEvents = mediatorEvents;
    }

    @Override
    public void connect(int physicalMediatorInstanceId) {

        final Optional<MediatorInstance> mediatorInstance = findMediatorInstance(physicalMediatorInstanceId);
        if (mediatorInstance.isPresent()) {
            final int logicalMediatorId = mediatorInstance.get().getConnection().getLogicalMediatorId();
            final boolean instanceActive = mediatorInstance.get().getConnection().isActive();
            final Optional<MediatorEntity> mediator = findMediator(logicalMediatorId);
            if (mediator.isPresent()) {
                final Map<String, String> mediatorProperties = buildMediatorPropertyMap(mediatorInstance.get(), mediator.get());
                try {
                    mediatorEvents.push(new PhysicalMediatorActivatingEvent(physicalMediatorInstanceId,
                            logicalMediatorId, instanceActive));

                    connectionManager.connect(context.getSessionContext(),
                            new MediatorIdItem(physicalMediatorInstanceId),
                            convertToProps(mediatorProperties),
                            instanceActive ? BcbSessionRole.ACTIVE : BcbSessionRole.STANDBY);

                    connectionManager.updateProperties(context.getSessionContext(),
                            new MediatorIdItem(physicalMediatorInstanceId),
                            mediatorProperties);
                    
                    mediatorEvents.push(new PhysicalMediatorActivatedEvent(physicalMediatorInstanceId,
                            logicalMediatorId, instanceActive));
                } catch (final DuplicatedSessionException e) {
                    reportPhysicalConnectionStateError(physicalMediatorInstanceId, logicalMediatorId, instanceActive,
                            mediator.get().getInfo().getName(),
                            tr(Message.MEDIATOR_CONNECTION_ALREADY_ACTIVE,
                                    findMediatorNameForInstance(e.getAlreadyActiveMediatorId().getId())));
                } catch (final BcbException e) {
                    reportPhysicalConnectionStateError(physicalMediatorInstanceId, logicalMediatorId, instanceActive,
                            mediator.get().getInfo().getName(), e);
                }
            } else {
                reportLogicalConnectionStateError(physicalMediatorInstanceId, logicalMediatorId, instanceActive,
                        "", new UnknownMediatorIdException("Unknown Mediator ID {}", logicalMediatorId));
            }
        } else {
            reportUnknownMediatorError(physicalMediatorInstanceId,
                    new UnknownMediatorIdException("Unknown Mediator Instance ID {}", physicalMediatorInstanceId));
        }
    }

    private static final Pattern PROPERTY_MEDIATOR_HOST_PATTERN =
            Pattern.compile("(\\$\\{Property\\.BCB-Attribute/Mediator/host\\})", Pattern.CASE_INSENSITIVE);

    private Map<String, String> buildMediatorPropertyMap(MediatorInstance mediatorInstance, MediatorEntity mediator) {
        final String instanceHost = mediatorInstance.getPhysicalInfo().getHost();
        final MediatorType mediatorType = configuration.getMediatorTypes().get(mediator.getInfo().getTypeName());
        final Map<String, String> mediatorProperties = SettingsProperties.getProperties(settingsRepository.getSettings());
        mediatorProperties.putAll(new MediatorProperties().getProperties(mediatorType, mediator));
        /*
         * This is EXTREMELY ugly. However we need this or something equivalent until CM and/or its "provider" classes are refactored
         * so that their configuration details, parameter formats, etc., are hidden from callers.
         */
        mediatorProperties.replaceAll((key, value) -> {
            final String typePropertyValue = mediatorType.getTypeProperties().get(key);
            if (null != typePropertyValue) {
                final Matcher matcher = PROPERTY_MEDIATOR_HOST_PATTERN.matcher(typePropertyValue);
                if (matcher.find()) {
                    final StringBuffer buffer = new StringBuffer();
                    do {
                        matcher.appendReplacement(buffer, instanceHost);
                    } while (matcher.find());
                    matcher.appendTail(buffer);
                    return buffer.toString();
                }
            }
            return value;
        });
        return mediatorProperties;
    }

    @Override
    public void disconnect(int physicalMediatorInstanceId) {

        final Optional<MediatorInstance> mediatorInstance = findMediatorInstance(physicalMediatorInstanceId);
        if (mediatorInstance.isPresent()) {
            final int logicalMediatorId = mediatorInstance.get().getConnection().getLogicalMediatorId();
            final boolean instanceActive = mediatorInstance.get().getConnection().isActive();
            final Optional<MediatorEntity> mediator = findMediator(logicalMediatorId);
            if (mediator.isPresent()) {
                try {
                    mediatorEvents.push(new PhysicalMediatorDeactivatingEvent(physicalMediatorInstanceId,
                            logicalMediatorId, instanceActive));

                    connectionManager.disconnect(context.getSessionContext(), new MediatorIdItem(physicalMediatorInstanceId));

                } catch (final RuntimeException | BcbException e) {
                    /* We don't report the error as a connection state error because we will be switching to
                     * Deactivated anyway. There's no point in going through a transient Failed state.
                     */
                    logConnectionStateError(mediator.get().getInfo().getName(), instanceActive, e);
                } finally {
                    mediatorEvents.push(new PhysicalMediatorDeactivatedEvent(physicalMediatorInstanceId,
                            logicalMediatorId, instanceActive));
                }
            } else {
                reportLogicalConnectionStateError(physicalMediatorInstanceId, logicalMediatorId, instanceActive,
                        "", new UnknownMediatorIdException("Unknown Mediator ID {}", logicalMediatorId));
            }
        } else {
            reportUnknownMediatorError(physicalMediatorInstanceId,
                    new UnknownMediatorIdException("Unknown Mediator Instance ID {}", physicalMediatorInstanceId));
        }
    }

    @Override   
    public void updateMediatorProperties(int physicalMediatorInstanceId, @Nonnull Map<String, String> properties)  throws ConnectException {
        try {
            connectionManager.updateProperties(context.getSessionContext(), new MediatorIdItem(physicalMediatorInstanceId), properties);
        } catch (BcbException e) {
            throw new ConnectException(e);
        }
    }

    
    private String findMediatorNameForInstance(int mediatorInstanceId) {
        Optional<String> name = Optional.empty();
        final Optional<MediatorInstance> mediatorInstance = findMediatorInstance(mediatorInstanceId);
        if (mediatorInstance.isPresent()) {
            final MediatorInstance instance = mediatorInstance.get();
            try {
                name = mediatorRepository.queryMediatorName(instance.getPhysicalInfo().getLogicalMediatorId());
            } catch (RepositoryException e) {
                LOGGER.error("Failed to search for name of mediator instance {}: {}",
                        instance, getStackTraceAsString(e));
            }
        }
        return name.orElse("");
    }

    private Optional<MediatorInstance> findMediatorInstance(int id) {
        try {
            return mediatorInstancesRepository.query(id);
        } catch (final RepositoryException e) {
            LOGGER.error("Failed to query the repository for physical mediator instance {}. {}", id, getStackTraceAsString(e));
            return Optional.empty();
        }
    }

    private Optional<MediatorEntity> findMediator(int id) {
        try {
            return mediatorRepository.query(id);
        } catch (final RepositoryException e) {
            LOGGER.error("Failed to query the repository for mediator {}. {} {}", id, e.getMessage(), Throwables.getStackTraceAsString(e));
            return Optional.empty();
        }
    }

    private void reportPhysicalConnectionStateError(int mediatorId, int logicalMediatorId, boolean instanceActive,
            String mediatorName, String message) {
        logConnectionStateError(mediatorName, instanceActive, message);

        mediatorEvents.push(new PhysicalMediatorActivationFailedEvent(mediatorId, logicalMediatorId, instanceActive, message));
    }

    private void reportPhysicalConnectionStateError(int mediatorId, int logicalMediatorId, boolean instanceActive,
            String mediatorName, Exception e) {
        final String message = logConnectionStateError(mediatorName, instanceActive, e);

        mediatorEvents.push(new PhysicalMediatorActivationFailedEvent(mediatorId, logicalMediatorId, instanceActive, message));
    }

    private void reportLogicalConnectionStateError(int physicalMediatorId, int logicalMediatorId, boolean instanceActive,
            String mediatorName, Exception e) {
        final String message = logConnectionStateError(mediatorName, instanceActive, e);

        mediatorEvents.push(new PhysicalMediatorActivationFailedEvent(physicalMediatorId, logicalMediatorId, instanceActive, message));
    }

    private void reportUnknownMediatorError(int physicalMediatorId, UnknownMediatorIdException e) {
        final String message = logConnectionStateError("", true, e);

        mediatorEvents.push(new PhysicalMediatorActivationFailedEvent(physicalMediatorId, 0, false, message));
    }

    private String logConnectionStateError(String mediatorName, boolean isActive, String message) {

        loggerManager.createSystemEventLog(context,
                new LoggerItemMediator(
                        mediatorName,
                        StringUtils.join(new String[] {
                            "Error during mediator activation/deactivation.",
                            message,
                            isActive ? null : "(standby)"
                        }, ' '),
                        MessageSeverity.ERROR));

        LOGGER.error("Mediator activation/deactivation error: {}", message);
        return message;
    }

    private String logConnectionStateError(String mediatorName, boolean isActive, Exception e) {
        LOGGER.error("Mediator activation/deactivation error.", e);
        return logConnectionStateError(mediatorName, isActive, nullToEmpty(getOriginalErrorCauseInMessage(getRootCause(e).getMessage())));
    }
    
    private String getOriginalErrorCauseInMessage(String rootCauseMessage) {
        
        if(rootCauseMessage != null) {
            int lastColon = rootCauseMessage.lastIndexOf(':');
            if(lastColon > -1 && lastColon < rootCauseMessage.length()) {
                return rootCauseMessage.substring(lastColon + 1).trim();
            }
        }
        
        return rootCauseMessage;
    }
}
