package com.ossnms.dcn_manager.bicnet.connector.messaging;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.messaging.layering.listener.BiCNetLayeringMessageListener;

import javax.annotation.Nonnull;
import javax.inject.Inject;

import static com.ossnms.bicnet.messaging.layering.listener.BiCNetLayeringMessageListener.DefaultFlowModes.FORWARD;

/**
 * <p>Implements the IBiCNetMessageListener interface to receive BiCNet messages produced by Message Dispatcher BiCNet Component.</p>
 * 
 * <p>The registration is done based on {@link BiCNetMessageListenerConfiguration} during component initialization</p>
 */
public class BiCNetMessageListener extends BiCNetLayeringMessageListener {

    @Inject private BiCNetMessageSink bicnetSource;

    protected BiCNetMessageListener() {
        setDefaultFlowMode(FORWARD); //process mediation notifications from all NEs 
    }

    @Override protected void onLayerMessage(@Nonnull ISessionContext sessionContext, @Nonnull IBiCNetMessage message,
                                            @Nonnull IBiCNetMessageDispatcher messageDispatcher) throws BcbException {
        bicnetSource.pushMessage(message);
    }

}
