package com.ossnms.dcn_manager.bicnet.connector.messaging;

import javax.annotation.Nonnull;

import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;

import rx.Observable;

/**
 * <p>Provides an {@link Observable} that converts BiCNet messages and emits {@link DecoratedNotification}.
 * Emission is triggered from the outside by calling {@link BiCNetMessageSink#pushMessage(IBiCNetMessage)}.</p>
 */
public interface BiCNetMessageSink {

    /**
     * Provides an {@link Observable} that emits {@link DecoratedNotification}.
     * @return An instance of {@link Observable}.
     */
    Observable<DecoratedNotification> observe();

    /**
     * Triggers emission of a BiCNet Message.
     * @param message The {@link IBiCNetMessage} instance that is to be emitted to subscribers.
     */
    void pushMessage(@Nonnull IBiCNetMessage message);

}
