package com.ossnms.dcn_manager.bicnet.configuration.export;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ChannelsReply;

public interface ChannelConfigurationExportService {

    /**
     * Returns ChannelsReply with one page of ExportChannels items.
     *
     * @param sessionContext current context
     * @param startAfter index to start the page, that index will not be include in the result (exclusive)
     * @param howMany page size, total of objects that will be returned.
     * @return the result o elements respecting the #startAfter and the #howMany params.
     * @throws BcbException
     */
    ChannelsReply export(ISessionContext sessionContext, int startAfter, int howMany) throws BcbException;
}
