package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.mysema.query.BooleanBuilder;
import com.mysema.query.support.Expressions;
import com.mysema.query.types.Ops;
import com.mysema.query.types.expr.BooleanExpression;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.IEMFacade;
import com.ossnms.bicnet.bcb.facade.scs.ISystemControlEjbFacade;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.common.EnableSwitch;
import com.ossnms.bicnet.bcb.model.common.Property;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEM;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IEMMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorId;
import com.ossnms.dcn_manager.bicnet.connector.common.entities.FullChannelData;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.ChannelService;
import com.ossnms.dcn_manager.bicnet.connector.context.BicnetCallContext;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertBcbPropertyToMap;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertChannelToBcb;
import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertChannelToFullChannel;
import com.ossnms.dcn_manager.bicnet.connector.facade.util.BicnetStandbyProperties;
import com.ossnms.dcn_manager.bicnet.connector.facade.util.MarkableFilters;
import com.ossnms.dcn_manager.bicnet.connector.facade.util.UnsupportedQueryParametersException;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.outbound.LoggerManagerImpl;
import com.ossnms.dcn_manager.bicnet.connector.storage.JpaChannelRepositoryBean;
import com.ossnms.dcn_manager.commands.CommandException;
import com.ossnms.dcn_manager.commands.channel.ActivateStandbyChannel;
import com.ossnms.dcn_manager.commands.channel.CreateChannel;
import com.ossnms.dcn_manager.commands.channel.DeactivateStandbyChannel;
import com.ossnms.dcn_manager.commands.channel.DeleteChannel;
import com.ossnms.dcn_manager.commands.channel.GetAllChannels;
import com.ossnms.dcn_manager.commands.channel.GetAllRegisteredChannels;
import com.ossnms.dcn_manager.commands.channel.GetChannel;
import com.ossnms.dcn_manager.commands.channel.GetChannelProperties;
import com.ossnms.dcn_manager.commands.channel.GetRegisteredEMs;
import com.ossnms.dcn_manager.commands.channel.internal.ChannelActivationRequired;
import com.ossnms.dcn_manager.commands.channel.internal.ChannelDeactivationRequired;
import com.ossnms.dcn_manager.commands.channel.internal.MoveChannelsToAnotherMediator;
import com.ossnms.dcn_manager.commands.channel.internal.UpdateChannelProperties;
import com.ossnms.dcn_manager.composables.channel.PhysicalChannelModification;
import com.ossnms.dcn_manager.connector.jpa.JpaCloseableQuery;
import com.ossnms.dcn_manager.connector.storage.channel.entities.QChannelEntityDb;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.configuration.transformations.GetChannelTypeName;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.outbound.ChannelConnectionManager;
import com.ossnms.dcn_manager.core.policies.ChannelSchedulingConfiguration;
import com.ossnms.dcn_manager.core.properties.channel.ChannelProperties;
import com.ossnms.dcn_manager.core.storage.SettingsRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.events.base.ChannelManagers;
import com.ossnms.dcn_manager.events.base.NetworkElementManagers;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;
import com.ossnms.dcn_manager.exceptions.DuplicatedObjectNameException;
import com.ossnms.dcn_manager.exceptions.IllegalChannelStateException;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelIdException;
import com.ossnms.dcn_manager.exceptions.UnknownChannelTypeException;
import com.ossnms.dcn_manager.exceptions.UnknownMediatorTypeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.persistence.PersistenceException;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static com.google.common.base.Predicates.notNull;
import static com.google.common.collect.Iterables.toArray;
import static com.google.common.collect.Iterables.transform;
import static com.ossnms.dcn_manager.bicnet.connector.facade.util.Exceptions.logAndRethrowAsBcb;
import static java.util.stream.Collectors.toList;

public class ChannelHelper implements IEMFacade, ChannelService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChannelHelper.class);

    @Inject
    private StaticConfiguration configuration;

    @Inject
    private ChannelManagers channelManagers;

    @Inject private NetworkElementManagers neManagers;

    @Inject
    private ChannelConnectionManager channelConnections;

    @Inject @DcnManager
    private ChannelSchedulingConfiguration channelScheduling;

    @Inject @DcnManager
    private JpaChannelRepositoryBean channelRepository;

    @Inject @DcnManager
    private NeEntityRepository neRepository;

    @Inject @DcnManager
    private MediatorEntityRepository mediatorRepository;

    @Inject @DcnManager
    private MediatorInstanceEntityRepository mediatorInstanceRepository;

    @Inject @DcnManager
    private SettingsRepository settingsRepository;

    @Inject
    private LoggerManagerImpl loggerManager;

    @Inject @DcnManager
    private ISystemControlEjbFacade scs;


    @Override
    public Collection<FullChannelData> getFullChannelList(ISessionContext sessionContext) throws BcbException {
        final GetAllChannels<BicnetCallContext> command = new GetAllChannels<>(new BicnetCallContext(sessionContext),
                channelManagers.getChannelRepository());
        try {
            return toFullChannels(StreamSupport.stream(command.call().spliterator(), false))
                    .collect(toList());
        } catch (final CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    public Stream<FullChannelData> toFullChannels(Stream<ChannelEntity> channels) {
        return channels
                .map(new PairChannelWithTypeAndInstances(configuration, channelManagers.getChannelInstanceConnections()))
                .map(new ConvertChannelToFullChannel());
    }

    @Override public FullChannelData getFullChannel(ISessionContext sessionContext, Integer id) throws BcbException {
        final GetChannel<BicnetCallContext> command = new GetChannel<>(new BicnetCallContext(sessionContext),
                channelManagers.getChannelRepository(), id);
        try {
            Optional<ChannelEntity> channel = command.call();
            return toFullChannels(channel.isPresent() ? Stream.of(channel.get()) : Stream.empty())
                    .findAny().orElse(null);
        } catch (final CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public String[] getRegisteredEmTypes(final ISessionContext sessionContext, final String mediatorType)
            throws BcbException {
        try {
            final GetRegisteredEMs<BicnetCallContext> cmd =
                    new GetRegisteredEMs<>(new BicnetCallContext(sessionContext), configuration, mediatorType);
            return toArray(transform(cmd.call(), new GetChannelTypeName()), String.class);
        } catch (final UnknownMediatorTypeException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public String[] getRegisteredEmTypes(final ISessionContext sessionContext) {
        final GetAllRegisteredChannels<BicnetCallContext> cmd =
                new GetAllRegisteredChannels<>(new BicnetCallContext(sessionContext), configuration);
        return StreamSupport.stream(cmd.call().spliterator(), false)
                .map(new GetChannelTypeName()::apply)
                .toArray(String[]::new);
    }

    @Override
    public IEM getSingleEM(final ISessionContext sessionContext, final IEMId emId) throws BcbException {
        final GetChannel<BicnetCallContext> get = new GetChannel<>(new BicnetCallContext(sessionContext), channelRepository,
                emId.getId());
        try {
            final Optional<ChannelEntity> channel = get.call();
            return channel.isPresent() ? ConvertChannelToBcb.convert(
                    configuration.getChannelTypes().get(channel.get().getInfo().getType()), channel.get()) : null;
        } catch (final CommandException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    private JpaCloseableQuery buildQueryExpression(final IEMId startAfter, final IEMMarkable[] filter, final int howMany,
                                                   final QChannelEntityDb channel) {
        final JpaCloseableQuery query = channelRepository.query(channel);
        final BooleanBuilder predicateBuilder = new BooleanBuilder();

        predicateBuilder.and(MarkableFilters.buildPredicateExpression(channel, filter, this::buildPredicateExpression));

        if (startAfter != null) {
            predicateBuilder.and(channel.info.channelId.goe(startAfter.getId()));
        }
        if (predicateBuilder.hasValue()) {
            query.where(predicateBuilder);
        }
        if (howMany > -1) {
            query.limit(howMany);
        }
        query.orderBy(channel.info.channelId.asc());
        return query;
    }

    private BooleanExpression buildPredicateExpression(QChannelEntityDb channel, IEMMarkable markable) {
        final List<BooleanExpression> booleanExpressions = new LinkedList<>();
        LOGGER.debug("Filtering Channel listing with: {}", markable.toStringOnlyMarkedAttributes());
        if (markable.isMarkedId()) {
            booleanExpressions.add(Expressions.predicate(Ops.EQ, channel.info.channelId, Expressions.constant(markable.getId())));
            markable.markId(false);
        }
        if (markable.isMarkedEmType()) {
            booleanExpressions.add(Expressions.predicate(Ops.EQ, channel.info.type, Expressions.constant(markable.getEmType())));
            markable.markEmType(false);
        }
        if (markable.isMarkedAssociatedMediatorId()) {
            booleanExpressions.add(Expressions.predicate(Ops.EQ, channel.info.mediatorId, Expressions.constant(markable.getAssociatedMediatorId())));
            markable.markAssociatedMediatorId(false);
        }
        if (markable.isMarkedIdName()) {
            booleanExpressions.add(Expressions.predicate(Ops.EQ, channel.preferences.name, Expressions.constant(markable.getIdName())));
            markable.markIdName(false);
        }
        if (markable.isMarkedActivation()) {
            booleanExpressions.add(Expressions.predicate(Ops.EQ, channel.info.isActivationRequired, Expressions.constant(markable.getActivation() == EnableSwitch.ENABLED)));
            markable.markActivation(false);
        }
        if (markable.countMarks() > 0) {
            throw new UnsupportedQueryParametersException("Unsupported query parameters: " + markable.toStringOnlyMarkedAttributes());
        }
        return BooleanExpression.allOf(booleanExpressions.toArray(new BooleanExpression[booleanExpressions.size()]));
    }

    @Override
    public EMReply getEMList(final ISessionContext sessionContext, final IEMId startAfter, final IEMMarkable[] filter, final int howMany)
            throws BcbException {
        final QChannelEntityDb channel = QChannelEntityDb.channelEntityDb;
        try (final JpaCloseableQuery query = buildQueryExpression(startAfter, filter, howMany, channel)) {
            final IEM[] ems = query.list(channel).stream()
                    .map(channelRepository.getEntityTransformer()::apply)
                    .filter(Optional::isPresent).map(Optional::get)
                    .map(new PairChannelWithType(configuration))
                    .map(new ConvertChannelToBcb()::apply)
                    .filter(notNull()::apply)
                    .toArray(IEM[]::new);
            return new EMReply(ems, true, null);
        } catch (final PersistenceException | UnsupportedQueryParametersException | RepositoryException exception) {
            throw logAndRethrowAsBcb(exception, LOGGER);
        }
    }

    @Override
    public EMIdReply getEMIdList(final ISessionContext sessionContext, final IEMId startAfter, final IEMMarkable[] filter, final int howMany)
            throws BcbException {
        final QChannelEntityDb channel = QChannelEntityDb.channelEntityDb;
        try (final JpaCloseableQuery query = buildQueryExpression(startAfter, filter, howMany, channel)) {
            final Iterable<IEMId> emIds = query.list(channel.info.channelId).stream()
                    .map(EMIdItem::new)
                    .collect(toList());
            return new EMIdReply(toArray(emIds, IEMId.class), true, null);
        } catch (final PersistenceException | UnsupportedQueryParametersException | RepositoryException exception) {
            throw logAndRethrowAsBcb(exception, LOGGER);
        }
    }

    @Override
    public void updateProperties(final ISessionContext sessionContext, final IEMId emId, final Map<String, String> updatedProperties)
            throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        final UpdateChannelProperties<BicnetCallContext> get = new UpdateChannelProperties<>(context,
                channelManagers, channelConnections, channelScheduling, configuration, settingsRepository, loggerManager,
                emId.getId(), updatedProperties);
        try {
            get.call();
        } catch (final DcnManagerException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public void moveChannelsToAnotherMediators(ISessionContext sessionContext, Collection<IEMId> emIds, IMediatorId targetMediatorId)
            throws BcbException {
        BicnetCallContext context = new BicnetCallContext(sessionContext);
        Iterable<Integer> channels = emIds.stream().map(IEMId::getId).collect(toList());
        PhysicalChannelModification physicalChannelModification = new PhysicalChannelModification(
                neManagers.getNeInstanceRepository(),
                neManagers.getNeRepository(),
                neManagers.getNeNotifications(),
                channelManagers.getChannelNotifications(),
                channelManagers.getChannelRepository(),
                channelManagers.getChannelInstanceConnections(),
                channelScheduling);
        try {
            new MoveChannelsToAnotherMediator<>(context, channelManagers, mediatorRepository, mediatorInstanceRepository,
                    loggerManager, channels, targetMediatorId.getId(), physicalChannelModification).call();
        } catch (DcnManagerException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public void activateEMs(final ISessionContext sessionContext, final IEMId[] emIds) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        for (final IEMId emId : emIds) {
            try {
                new ChannelActivationRequired<>(context, emId.getId(),
                        channelManagers, mediatorRepository, mediatorInstanceRepository, loggerManager)
                        .call();
            } catch (final DcnManagerException e) {
                LOGGER.error("Failed to execute the activate command on channel {}. {}", emId, e);
            }
        }
    }

    @Override
    public void deactivateEMs(final ISessionContext sessionContext, final IEMId[] emIds) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        for (final IEMId emId : emIds) {
            try {
                new ChannelDeactivationRequired<>(context, emId.getId(),
                        channelManagers, neRepository, mediatorRepository, loggerManager).call();
            } catch (final DcnManagerException e) {
                LOGGER.error("Failed to execute the deactivate command on channel {}. {}", emId, e);
            }
        }
    }

    @Override
    public void deactivateAllEMs(final ISessionContext sessionContext) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        try {
            for (final ChannelEntity channel : channelRepository.queryAll()) {
                try {
                    new ChannelDeactivationRequired<>(context, channel.getInfo().getId(),
                            channelManagers, neRepository, mediatorRepository, loggerManager).call();
                } catch (final DcnManagerException e) {
                    LOGGER.error("Failed to execute the deactivate command on channel {}. {}", channel, e);
                }
            }
        } catch (final RepositoryException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public IEM createEM(final ISessionContext sessionContext, final IEM em) throws BcbException {
        return createEM(sessionContext, em.getEmType(), em.getIdName(), em.getAssociatedMediator(), Optional.empty());
    }

    @Override
    public IEM createEM(final ISessionContext sessionContext, final String emType, final String emIdName,
                        final IMediatorId mediatorId, final Property[] emProperties) throws BcbException {
        return createEM(sessionContext, emType, emIdName, mediatorId, Optional.of(ConvertBcbPropertyToMap.convert(emProperties)));
    }

    private IEM createEM(final ISessionContext sessionContext, final String emType, final String emIdName,
                         final IMediatorId mediatorId, final Optional<Map<String, String>> emProperties) throws BcbException {
        LOGGER.info("Attempting to create EM of type {} with name {} under mediator {} and properties {}",
                emType, emIdName, mediatorId, emProperties);
        final BicnetCallContext context = new BicnetCallContext(sessionContext);
        final ChannelType type = findType(emType);
        final ChannelProperties channelProperties = new ChannelProperties();
        final ChannelCreateDescriptor createDescriptor = new ChannelCreateDescriptor(type, mediatorId.getId());
        try {
            applyDefaultChannelProperties(channelProperties, type, createDescriptor);
            createDescriptor.getPreferencesInitialData().setName(emIdName);
            if (emProperties.isPresent()) {
                channelProperties.setProperties(type, createDescriptor.getPreferencesInitialData(), emProperties.get());
            }
            final ChannelEntity emEntity = new CreateChannel<>(context, channelManagers, channelScheduling,
                    mediatorRepository, mediatorInstanceRepository, loggerManager, createDescriptor).call();
            return ConvertChannelToBcb.convert(type, emEntity);
        } catch (final CommandException | InvalidMutationException | IllegalArgumentException | DuplicatedObjectNameException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    private ChannelType findType(final String typeName) throws BcbException {
        final ChannelType type = configuration.getChannelTypes().get(typeName);
        if (null == type) {
            throw new BcbException("Unsupported EM type requested: " + typeName);
        }
        return type;
    }

    private void applyDefaultChannelProperties(final ChannelProperties channelProperties, final ChannelType type, final ChannelCreateDescriptor createEvent) {
        // Apply default property values to the newly created instance
        for (final Entry<String, String> entry : type.getSupportedPropertyDefaultValues().entrySet()) {
            try {
                channelProperties.setProperty(type, createEvent.getPreferencesInitialData(), entry.getKey(), entry.getValue());
            } catch (final InvalidMutationException e) {
                LOGGER.warn("Default property ('{}','{}') could not be applied on new channel: {}",
                        entry.getKey(), entry.getValue(), e.getMessage());
            }
        }
    }

    @Override
    public void deleteEM(final ISessionContext sessionContext, final IEMId emId) throws BcbException {
        deleteChannels(sessionContext, ImmutableList.of(emId));
    }

    @Override
    public IEMMarkable modifyEM(final ISessionContext sessionContext, final IEMMarkable em) throws BcbException {
        throw new UnsupportedOperationException();
    }

    @Override
    public IEMMarkable[] modifyEMs(final ISessionContext sessionContext, final IEMMarkable[] ems) throws BcbException {
        throw new UnsupportedOperationException();
    }

    @Override
    public Map<String, String> getProperties(final ISessionContext context, final IEMId channelId)
            throws BcbException {
        try {
            final Optional<Map<String, String>> properties =
                    new GetChannelProperties<>(new BicnetCallContext(context), channelRepository, configuration, channelId.getId())
                            .call();
            return properties
                    .map(channelProperties -> {
                        channelProperties.putAll(BicnetStandbyProperties.getProperties(context, scs));
                        return channelProperties;
                    })
                    .orElse(ImmutableMap.of());
        } catch (CommandException | UnknownChannelTypeException e) {
            throw logAndRethrowAsBcb(e, LOGGER);
        }
    }

    @Override
    public void deleteChannels(final ISessionContext sessionContext, final Collection<IEMId> mediatorType) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);

        for (final IEMId emId : mediatorType) {
            LOGGER.info("Attempting to delete EM from BCB: {}", emId);

            try {
                new DeleteChannel<>(context, channelManagers, channelScheduling, neRepository, loggerManager, emId.getId())
                        .call();
            } catch (final CommandException | IllegalChannelStateException | UnknownChannelIdException e) {
                throw logAndRethrowAsBcb(e, LOGGER);
            }
        }
    }


    @Override
    public void activateChannelsOnStandbyMediation(ISessionContext sessionContext, Collection<IEMId> channelIds) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);

        for (final IEMId channelId : channelIds) {

            final ActivateStandbyChannel<BicnetCallContext> command = new ActivateStandbyChannel<>(context, channelId.getId(), channelManagers, loggerManager, settingsRepository);

            try {
                command.call();
            } catch (final UnknownChannelIdException e) {
                LOGGER.warn("Trying to activate an unexistant Channel with ID {}", channelId);
            } catch (RepositoryException | IllegalChannelStateException | CommandException e) {
                throw logAndRethrowAsBcb(e, LOGGER);
            }

        }
    }

    @Override
    public void deactivateChannelsOnStandbyMediation(ISessionContext sessionContext, Collection<IEMId> channelIds) throws BcbException {
        final BicnetCallContext context = new BicnetCallContext(sessionContext);

        for (final IEMId channelId : channelIds) {

            final DeactivateStandbyChannel<BicnetCallContext> command = new DeactivateStandbyChannel<>(context, channelId.getId(), channelManagers, loggerManager);

            try {
                command.call();
            } catch (final UnknownChannelIdException e) {
                LOGGER.warn("Trying to deactivate an unexistant Channel with ID {}", channelId);
            } catch (RepositoryException | IllegalChannelStateException | CommandException e) {
                throw logAndRethrowAsBcb(e, LOGGER);
            }

        }

    }

}
