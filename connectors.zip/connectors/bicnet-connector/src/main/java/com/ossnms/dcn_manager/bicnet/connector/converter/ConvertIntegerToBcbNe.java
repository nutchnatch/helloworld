package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.google.common.base.Function;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INE;

/**
 * Converts a NE id to BCB INE.
 */
public final class ConvertIntegerToBcbNe implements Function<Integer, INE> {

    /**
     * @param input The NE Id.
     * @return INE with only the key setted.
     */
    public static INE convert(int input) {
        final INE newNe = new NEItem();
        newNe.setId(input);
        return newNe;
    }

    /**
     * @see Function#apply(Object)
     */
    @Override
    public INE apply(Integer input) {
        return input == null ? null : convert(input);
    }
}
