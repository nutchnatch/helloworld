package com.ossnms.dcn_manager.bicnet.connector.messaging;

import com.google.common.base.Strings;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IMediatorMarkable;
import com.ossnms.bicnet.bcb.model.emObjMgmt.MediatorActivationState;
import com.ossnms.bicnet.bcb.model.platform.AttributeValueChange;
import com.ossnms.dcn_manager.core.events.mediator.MediatorEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivationFailedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;

import javax.enterprise.context.ApplicationScoped;

/**
 * <p>Event source for events related to Mediators.</p>
 *
 * <p>Not only does it transform BiCNet events into EM/NE internal events, but it
 * also allows direct injection of EM/NE events produced by Connectors into the
 * normal event stream.</p>
 *
 * <p>It may be argued that this violates the single responsibility principle.
 * However this class is responsible for providing an Observable of Mediator events.
 * This Observable gathers its events from two origins: BiCNet notifications and
 * internal sources. Hence the principle is not violated.</p>
 */
@ApplicationScoped
public class MediatorEventSource
        extends MessageSourceImpl<MediatorEvent>
        implements EventSource<MediatorEvent> {

    private static final Logger LOGGER = LoggerFactory.getLogger(MediatorEventSource.class);

    @Override
    public void subscribe(Observable<DecoratedNotification> notificationSource) {

        LOGGER.debug("Initializing Mediator event subscriptions.");

        final Observable<DecoratedNotification> mediatorAvcs =
                notificationSource
                    .filter(notification ->
                        notification.getNotification(AttributeValueChange.class).isPresent() &&
                        notification.getOriginatingPhysicalMediator().isPresent());

        /*
         * Due to the way how we interact with Connection Manager, the only event CM is
         * expected to issue is an error notification when its ping mechanism detects
         * a connection failure.
         */
        chain(gatherMediatorActivationFailedEvents(mediatorAvcs));
    }

    private Observable<MediatorEvent> gatherMediatorActivationFailedEvents(
            final Observable<DecoratedNotification> notificationsSource) {
        /*
         * Note that we're using the incoming Mediator ID directly as the Physical Mediator
         * Instance ID. This is possible because we activate the active & standby mediators
         * on Connection Manager with different IDs.
         */
        return notificationsSource
            .filter(n ->
                n.getAffectedObject(IMediatorMarkable.class)
                    .map(m -> m.isMarkedActualActivationState() && m.getActualActivationState() == MediatorActivationState.FAILED)
                    .orElse(false))
            .map(n ->
                n.getAffectedObject(IMediatorMarkable.class)
                    .map(m -> new PhysicalMediatorActivationFailedEvent(
                            m.getId(),
                            n.getOriginatingPhysicalMediator().get().getLogicalMediatorId(),
                            n.getOriginatingPhysicalMediator().get().isActive(),
                            Strings.nullToEmpty(m.getAdditionalInfo()))
                        )
                    .get()
                );
    }

}
