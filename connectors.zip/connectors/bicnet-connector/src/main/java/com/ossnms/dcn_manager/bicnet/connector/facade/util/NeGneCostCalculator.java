package com.ossnms.dcn_manager.bicnet.connector.facade.util;

import com.ossnms.bicnet.bcb.model.emObjMgmt.GneCost;
import com.ossnms.bicnet.bcb.model.emObjMgmt.INEId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeGneCost;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.GatewayMode;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.slf4j.Logger;

import java.util.Optional;

import static com.google.common.base.Throwables.getStackTraceAsString;
import static java.util.stream.StreamSupport.stream;
import static org.apache.commons.lang3.StringUtils.trimToNull;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Utility class for finding and sorting all NE gateway routes, per NE, in BiCNet format.
 */
public class NeGneCostCalculator {

    private static final Logger LOGGER = getLogger(NeGneCostCalculator.class);
    private final NeEntityRepository neRepository;

    /**
     * Constructs a new object.
     * @param neRepository Repository of NE objects. Necessary to obtain
     *                     NE identifiers, names, operational information and routes.
     */
    public NeGneCostCalculator(NeEntityRepository neRepository) {
        this.neRepository = neRepository;
    }

    /**
     * @return The GNEs costs and their names for all NEs.
     * @throws RepositoryException Should an error occur with the NE repository.
     */
    public NeGneCost[] calculateCostToGneMap() throws RepositoryException {

        return stream(neRepository.getNeOperationRepository().queryAll().spliterator(), false)
                .map(operation -> new NeGneCost(calculateNeName(operation), fetchGneCosts(operation)))
                .toArray(NeGneCost[]::new);
    }
    
    /**
     * @return The GNE costs and name for selected NE.
     * @throws RepositoryException Should an error occur with the NE repository.
     */
    public NeGneCost calculateCostToGne(INEId neId) throws RepositoryException {

        return neRepository.getNeOperationRepository().query(neId.getId())             
                .map(operation -> new NeGneCost(calculateNeName(operation), fetchGneCosts(operation)))
                .orElseThrow(RepositoryException::new);

    }
     
    private String calculateNeName(NeOperationData operation) {

        try {
            return neRepository.queryNeName(operation.getId()).map(Optional::of).orElse(operation.getRealNeName()).orElse(String.valueOf(operation.getId()));
        } catch (RepositoryException e) {
            LOGGER.error("Could not fetch NE name for {}: {}", operation, getStackTraceAsString(e));
            return operation.getRealNeName().orElse(String.valueOf(operation.getId()));
        }

    }

    private GneCost[] fetchGneCosts(NeOperationData operation) {

        try {
            final Iterable<NeGatewayRouteData> routes =
                    neRepository.getNeGatewayRoutesRepository().queryRoutes(operation.getId());
            return stream(routes.spliterator(), false)
                    .map(route -> buildGneCost(operation, route))
                    .filter(costs -> costs != null)
                    .sorted((cost1, cost2) ->
                            cost1.getGne_cost() == cost2.getGne_cost()
                                    ? Boolean.compare(cost2.getIsUsed(), cost1.getIsUsed())
                                    : cost1.getGne_cost() - cost2.getGne_cost())
                    .toArray(GneCost[]::new);
        } catch (RepositoryException e) {
            LOGGER.error("Could not fetch routes for {}: {}", operation, getStackTraceAsString(e));
            return new GneCost[0];
        }

    }

    private GneCost buildGneCost(NeOperationData operation, NeGatewayRouteData route) {
        String gneName = route.getGneName();
        if (null == trimToNull(gneName) && GatewayMode.NONE != operation.getGatewayMode().orElse(GatewayMode.NONE)) {
            /* Legacy logic: GM provides a "loopback" route without a GNE name for all GNEs.
             * In this case we're supposed to provide the NE network name to identify the route.
             */
            gneName = operation.getRealNeName().orElse("");
        }

        if (!gneName.isEmpty()) {
            return new GneCost(gneName, route.getCost(), route.getDomain().orElse(null), route.isUsed());
        }

        return null;
    }

}
