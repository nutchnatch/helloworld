package com.ossnms.dcn_manager.bicnet.connector.facade.util;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.composables.configuration.AppProperties;

import javax.annotation.Nonnull;
import java.util.Map;

/**
 * Contains definitions and methods for producing sets of properties
 * describing the current static configuration of DCN Manager in a
 * BiCNet installation.
 */
public final class BicnetConfigurationProperties {

    private static final String NODE_MANAGER_SELECTED = "NODE_MANAGER_SELECTED";

    private BicnetConfigurationProperties() {

    }

    /**
     * Produces properties about the static DCN Manager configuration , for
     * usage in its GUI.
     * @param appProperties Static DCN Manager configuration data source.
     * @return Properties describing the current DCN Manager configuration attributes
     * that are relevant to the GUI.
     */
    public static Map<String, String> getProperties(@Nonnull AppProperties appProperties) {
        return ImmutableMap.of(
                NODE_MANAGER_SELECTED, appProperties.isNodeManagerSelected().toString()
        );
    }

}
