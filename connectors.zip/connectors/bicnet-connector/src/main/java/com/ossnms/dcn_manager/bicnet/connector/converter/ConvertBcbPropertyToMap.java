package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.google.common.base.Strings;
import com.ossnms.bicnet.bcb.model.common.Property;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;

import static org.apache.commons.lang3.ArrayUtils.isNotEmpty;

/**
 * Holds methods to convert on array of BCB {@link Property} objects
 * into a map of string keys to string values.
 */
public final class ConvertBcbPropertyToMap {

    private ConvertBcbPropertyToMap() {
        // utility class constructor
    }

    /**
     * Converts on array of BCB {@link Property} objects
     * into a map of string keys to string values.
     * @param properties An array of BCB properties.
     * @return A map of string keys to string values.
     */
    public static Map<String, String> convert(@Nullable final Property[] properties) {
        final Map<String, String> map = new HashMap<>();

        if (isNotEmpty(properties)) {
            for (final Property property : properties) {
                map.put(property.getName(), Strings.nullToEmpty(property.getValue()));
            }
        }

        return map;
    }
}
