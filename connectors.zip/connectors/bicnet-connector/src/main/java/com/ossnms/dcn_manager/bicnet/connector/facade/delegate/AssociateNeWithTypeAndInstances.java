/*
* Copyright (C) Coriant
* The reproduction, transmission or use of this document or its contents 
 * is not permitted without express written authorization.
* Offenders will be liable for damages.
* All rights, including rights created by patent grant or 
 * registration of a utility model or design, are reserved.
* Modifications made to this document are restricted to authorized personnel only. 
 * Technical specifications and features are binding only when specifically 
 * and expressly agreed upon in a written contract.
*
*/

package com.ossnms.dcn_manager.bicnet.connector.facade.delegate;

import com.ossnms.dcn_manager.bicnet.connector.converter.ConvertNeToFullNe;
import com.ossnms.dcn_manager.bicnet.connector.storage.InMemoryNeSyncStateRepository;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.model.StaticConfiguration;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.storage.ne.NePhysicalConnectionRepository;

import java.util.function.Function;

public final class AssociateNeWithTypeAndInstances implements
        Function<NeEntity, ConvertNeToFullNe.ConversionData> {

    private final StaticConfiguration configuration;
    private final InMemoryNeSyncStateRepository syncStateRepository;
    private final NePhysicalConnectionRepository nePhysicalConnectionRepository;
    private final Function<Integer,Iterable<NeGatewayRouteData>> neGatewayRouteDataProvider;

    public AssociateNeWithTypeAndInstances(
            StaticConfiguration configuration, InMemoryNeSyncStateRepository syncStateRepository,
            NePhysicalConnectionRepository nePhysicalConnectionRepository,
            Function<Integer,Iterable<NeGatewayRouteData>> neGatewayRouteDataProvider) {
        this.configuration = configuration;
        this.syncStateRepository = syncStateRepository;
        this.nePhysicalConnectionRepository = nePhysicalConnectionRepository;
        this.neGatewayRouteDataProvider = neGatewayRouteDataProvider;
    }

    @Override
    public ConvertNeToFullNe.ConversionData apply(NeEntity ne) {
        if (null == ne) {
            return null;
        } else {
            NeType type = configuration.getNeTypes().get(ne.getInfo().getProxyType());
            return null == type
                    ? null
                    : new ConvertNeToFullNe.ConversionData(
                    type,
                    syncStateRepository.query(ne.getInfo().getId()),
                    ne,
                    neGatewayRouteDataProvider.apply(ne.getInfo().getNeId()),
                    nePhysicalConnectionRepository.queryAll(ne.getInfo().getId()));
        }
    }

}
