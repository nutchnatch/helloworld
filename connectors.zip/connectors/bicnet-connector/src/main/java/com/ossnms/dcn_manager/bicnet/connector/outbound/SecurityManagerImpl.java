package com.ossnms.dcn_manager.bicnet.connector.outbound;

import com.google.common.base.Predicates;
import com.google.common.base.Throwables;
import com.google.common.collect.FluentIterable;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.EMItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.MediatorItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NEItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.NetworkDomainItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdItem;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem;
import com.ossnms.bicnet.bcb.facade.security.ISecurityMgrFacade;
import com.ossnms.bicnet.bcb.facade.security.SecurableObjectContainerIdItem;
import com.ossnms.bicnet.bcb.facade.security.SecurableObjectContainerItem;
import com.ossnms.bicnet.bcb.facade.security.SecurableObjectIdItem;
import com.ossnms.bicnet.bcb.facade.security.SecurableObjectItem;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.security.ISecurableObject;
import com.ossnms.bicnet.bcb.model.security.ISecurableObjectContainer;
import com.ossnms.bicnet.bcb.model.security.ISecurableObjectContainerId;
import com.ossnms.bicnet.bcb.model.security.ISecurableObjectContainerMarkable;
import com.ossnms.bicnet.bcb.model.security.ISecurableObjectId;
import com.ossnms.bicnet.bcb.model.security.ISecurableObjectMarkable;
import com.ossnms.bicnet.bcb.model.security.ISecurityDomainId;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.composables.outbound.SecurityManager;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.core.storage.container.ContainerRepository;
import com.ossnms.dcn_manager.core.storage.container.SystemRepository;
import com.ossnms.dcn_manager.core.storage.domain.DomainRepository;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;
import com.ossnms.dcn_manager.core.storage.ne.NeEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import java.util.Collection;
import java.util.Collections;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesPrototype.UNSIGNED;
import static java.util.stream.StreamSupport.stream;

/**
 * Implements the connection between EM/NE and TNMS User Security Manager.
 */
public class SecurityManagerImpl implements SecurityManager {

    private static final Logger LOGGER = LoggerFactory.getLogger(SecurityManagerImpl.class);

    private final ISecurityMgrFacade securityManager;
    private final DomainRepository domainRepository;
    private final ContainerRepository containerRepository;
    private final SystemRepository systemRepository;
    private final NeEntityRepository neRepository;
    private final ChannelEntityRepository channelRepository;
    private final MediatorEntityRepository mediatorRepository;

    /**
     * Creates a new object.
     *
     * @param securityManager BCB facade towards User Security Manager.
     * @param domainRepository NE domain repository. Used to build full
     *  securable objects for NEs.
     * @param neRepository NE repository. Used to obtain additional information
     *  when the incoming data is insufficient to build an updated securable
     *  object.
     */
    @Inject
    public SecurityManagerImpl(
    		@DcnManager ISecurityMgrFacade securityManager,
    		@DcnManager DomainRepository domainRepository,
    		@DcnManager NeEntityRepository neRepository,
    		@DcnManager ChannelEntityRepository channelRepository,
    		@DcnManager MediatorEntityRepository mediatorRepository,
            @DcnManager ContainerRepository containerRepository,
            @DcnManager SystemRepository systemRepository) {
        this.securityManager = securityManager;
        this.domainRepository = domainRepository;
        this.neRepository = neRepository;
        this.channelRepository = channelRepository;
        this.mediatorRepository = mediatorRepository;
        this.containerRepository = containerRepository;
        this.systemRepository = systemRepository;
    }

    @Override public void updateSystem(@Nonnull SystemInfo systemInfo) {
        securityManager.updateObjectContainer(BiCNetComponentType.DCN_MANAGER,
                buildSecurableObjectContainer(systemInfo));
    }

    /**
     * Reports updates done on a System.
     *
     * @param systemId The System being updated.
     */
    @Override public void updateSystem(@Nonnull int systemId) {
        try {
            final Optional<SystemInfo> systemInfo = systemRepository.query(systemId);
            if (!systemInfo.isPresent()) {
                LOGGER.warn("Could not update NE {} in USM because its preferences could not be found.", systemId);
                return;
            }

            updateSystem(systemInfo.get());
        } catch (final RepositoryException e) {
            LOGGER.error("An error has occurred while querying for System {} information: {}", systemId,
                    Throwables.getStackTraceAsString(e));
        }
    }

    @Override public void updateContainer(@Nonnull ContainerInfo containerInfo) {
        securityManager.updateObjectContainer(BiCNetComponentType.DCN_MANAGER,
                buildSecurableObjectContainer(containerInfo));
    }

    @Override
    public void updateMediator(@Nonnull MediatorEntity mediatorEntity) {

        securityManager.updateObjectContainer(BiCNetComponentType.DCN_MANAGER,
                buildSecurableObjectContainer(mediatorEntity.getInfo()));

    }

    @Override
    public void updateMediator(@Nonnull MediatorInfoData preferences) {

        securityManager.updateObjectContainer(BiCNetComponentType.DCN_MANAGER,
                buildSecurableObjectContainer(preferences));

    }

    @Override
    public void updateChannel(@Nonnull ChannelEntity channelEntity) {

        securityManager.updateObjectContainer(BiCNetComponentType.DCN_MANAGER,
                buildSecurableObjectContainer(channelEntity.getInfo(), channelEntity.getUserPreferences()));

    }

    @Override
    public void updateChannel(@Nonnull ChannelUserPreferencesData preferences) {

        final Optional<ChannelInfoData> channelInfo = tryQueryInfo(preferences);
        if (!channelInfo.isPresent()) {
            LOGGER.warn("Could not update Channel {} in USM because its information could not be found.", preferences.getId());
            return;
        }

        securityManager.updateObjectContainer(BiCNetComponentType.DCN_MANAGER,
                buildSecurableObjectContainer(channelInfo.get(), preferences));

    }

    @Override
    public void createNe(@Nonnull NeEntity neEntity) {

        final ISecurableObject secNe = buildSecurableObject(neEntity);

        securityManager.registerObject(BiCNetComponentType.DCN_MANAGER, secNe);

    }

    @Override
    public void deleteNe(@Nonnull NeEntity neEntity) {

        final ISecurableObject secNe = buildSecurableObject(neEntity);

        securityManager.unregisterObject(BiCNetComponentType.DCN_MANAGER, secNe);

    }

    @Override
    public void updateNe(@Nonnull NeEntity neEntity) {

        final ISecurableObject secNe = buildSecurableObject(neEntity);

        securityManager.updateObject(BiCNetComponentType.DCN_MANAGER, secNe);

    }

    @Override
    public void updateNe(@Nonnull NeUserPreferencesData preferences) {

        final Optional<NeInfoData> info = tryQueryInfo(preferences);
        if (!info.isPresent()) {
            LOGGER.warn("Could not update NE {} in USM because its information could not be found.", preferences.getId());
            return;
        }

        final ISecurableObject secNe = buildSecurableObject(info.get(), preferences);

        securityManager.updateObject(BiCNetComponentType.DCN_MANAGER, secNe);

    }

    @Override
    public void updateNe(int neId) {

        final Optional<NeUserPreferencesData> neEntity = tryQueryNePreferences(neId);
        if (!neEntity.isPresent()) {
            LOGGER.warn("Could not update NE {} in USM because its preferences could not be found.", neId);
            return;
        }

        updateNe(neEntity.get());
    }

    private Optional<NeUserPreferencesData> tryQueryNePreferences(int neId) {
        try {
            return neRepository.getNeUserPreferencesRepository().query(neId);
        } catch (final RepositoryException e) {
            LOGGER.error("An error has occurred while querying for NE {} entity: {}",
                    neId, Throwables.getStackTraceAsString(e));
            return Optional.empty();
        }
    }

    private Optional<NeInfoData> tryQueryInfo(NeUserPreferencesData preferences) {
        try {
            return neRepository.getNeInfoRepository().query(preferences.getId());
        } catch (final RepositoryException e) {
            LOGGER.error("An error has occurred while querying for NE {} information: {}",
                    preferences.getId(), Throwables.getStackTraceAsString(e));
            return Optional.empty();
        }
    }

    private Optional<ChannelInfoData> tryQueryInfo(ChannelUserPreferencesData preferences) {
        try {
            return channelRepository.getChannelInfoRepository().query(preferences.getId());
        } catch (final RepositoryException e) {
            LOGGER.error("An error has occurred while querying for Channel {} information: {}",
                    preferences.getId(), Throwables.getStackTraceAsString(e));
            return Optional.empty();
        }
    }

    private Optional<MediatorInfoData> tryQueryMediator(int mediatorId) {
        try {
            return mediatorRepository.getMediatorInfoRepository().query(mediatorId);
        } catch (final RepositoryException e) {
            LOGGER.error("An error has occurred while querying for Mediator {} information: {}",
                    mediatorId, Throwables.getStackTraceAsString(e));
            return Optional.empty();
        }
    }

    private Optional<ChannelEntity> tryQueryChannel(int channelId) {
        try {
            return channelRepository.queryChannel(channelId);
        } catch (final RepositoryException e) {
            LOGGER.error("An error has occurred while querying for Channel {} information: {}",
                    channelId, Throwables.getStackTraceAsString(e));
            return Optional.empty();
        }
    }

    private Optional<ContainerInfo> tryQueryContainer(int containerId) {
        try {
            return containerRepository.query(containerId);
        } catch (final RepositoryException e) {
            LOGGER.error("An error has occurred while querying for Container {} information: {}",
                    containerId, Throwables.getStackTraceAsString(e));
            return Optional.empty();
        }
    }

    private Collection<ISecurableObjectContainer> queryNeAssignments(NeUserPreferencesData preferences) {
        try {
            if (preferences.getContainerId().isPresent() && preferences.getContainerId().get() != UNSIGNED) {
                return systemRepository.query(preferences.getContainerId().get())
                        .map(system -> Collections.singletonList(buildSecurableObjectContainer(system)))
                        .orElse(Collections.emptyList());
            } else {
                final Iterable<NeAssignmentData> neAssignmentDatas = containerRepository
                        .queryAllByNE(preferences.getId());

                return stream(neAssignmentDatas.spliterator(), false).map(NeAssignmentData::getContainerInfo)
                        .map(this::buildSecurableObjectContainer).collect(Collectors.toList());
            }
        } catch (final RepositoryException e) {
            LOGGER.error("An error has occurred while querying for NE {} information: {}", preferences.getId(),
                    Throwables.getStackTraceAsString(e));
            return Collections.emptyList();
        }
    }

    private ISecurableObjectContainer buildSecurableObjectContainer(DomainInfoData domain) {
        final SecurableNetworkDomain secDomain = new SecurableNetworkDomain();
        secDomain.setId(domain.getId());
        secDomain.setIdName(domain.getName());
        secDomain.setContainerList(null); // Domains (ASs) feel like top level objects...
        secDomain.setContainerName(domain.getName());
        // Note that we didn't populate the list of domain children.
        // It doesn't seem to be necessary because the hierarchy of securable objects depends
        // on each securable object reporting its containers. Also, USM does not know specifics
        // about our business objects.
        return secDomain;
    }

    private ISecurableObjectContainer buildSecurableObjectContainer(ChannelInfoData channelInfo, ChannelUserPreferencesData preferences) {
        final SecurableChannel secChannel = new SecurableChannel();
        secChannel.setId(channelInfo.getId());
        secChannel.setIdName(preferences.getName());
        secChannel.setContainerList(
                tryQueryMediator(channelInfo.getMediatorId()).map(mediator -> new ISecurableObjectContainer[]{buildSecurableObjectContainer(mediator)}).orElse(null));
        secChannel.setContainerName(preferences.getName());
        return secChannel;
    }

    private ISecurableObjectContainer buildSecurableObjectContainer(@Nonnull final MediatorInfoData mediatorInfo) {
        final SecurableMediator secMediator = new SecurableMediator();
        secMediator.setId(mediatorInfo.getId());
        secMediator.setIdName(mediatorInfo.getName());
        secMediator.setContainerName(mediatorInfo.getName());
        return secMediator;
    }

    private ISecurableObjectContainer buildSecurableObjectContainer(@Nonnull final SystemInfo systemInfo) {
        final SecurableSystem securableSystem = new SecurableSystem();

        securableSystem.setId(systemInfo.getId());
        securableSystem.setIdName(systemInfo.getName());
        securableSystem.setContainerName(systemInfo.getName());

        securableSystem.setContainerList(
                stream(containerRepository.queryAllBySystem(systemInfo.getId()).spliterator(), false)
                        .map(SystemAssignmentData::getContainerInfo)
                        .map(this::buildSecurableObjectContainer)
                        .toArray(ISecurableObjectContainer[]::new));

        return securableSystem;
    }

    private ISecurableObjectContainer buildSecurableObjectContainer(@Nonnull final ContainerInfo containerInfo) {
        final SecurableContainer securableContainer = new SecurableContainer();

        if (containerInfo.getParentId().isPresent()) {
            final Optional<ContainerInfo> parentInfo = tryQueryContainer(containerInfo.getParentId().get());
            securableContainer.setContainerList(parentInfo.map(p -> new ISecurableObjectContainer[]{buildSecurableObjectContainer(p)}).orElse(null));
        }

        securableContainer.setId(containerInfo.getId());
        securableContainer.setIdName(containerInfo.getName());
        securableContainer.setContainerName(containerInfo.getName());

        return securableContainer;
    }

    /**
     * Converts an NE into an instance of {@link ISecurableObject}.
     *
     * @param neEntity NE business entity.
     *
     * @return An instance of {@link ISecurableObject} representing the NE
     *  provided, with all containers. Domains that contain this NE  will be
     *  converted into {@link ISecurableObjectContainer}.
     */
    public ISecurableObject buildSecurableObject(NeEntity neEntity) {
        return buildSecurableObject(neEntity.getInfo(), neEntity.getPreferences());
    }

    /**
     * Converts an NE into an instance of {@link ISecurableObject}.
     *
     * @param info NE information. Necessary to determine the NE icon.
     * @param preferences NE preferences. Necessary to determine the NE name.
     *
     * @return An instance of {@link ISecurableObject} representing the NE
     *  provided, with all containers. Domains that contain this NE  will be
     *  converted into {@link ISecurableObjectContainer}.
     */
    private ISecurableObject buildSecurableObject(NeInfoData info, NeUserPreferencesData preferences) {
        final SecurableNe secNe = new SecurableNe();
        final Iterable<DomainInfoData> domains = domainRepository.queryAllForNE(preferences.getId());
        final ISecurableObjectContainerId[] containers = FluentIterable.from(domains)
            .transform(this::buildSecurableObjectContainer)
            .append(
                    tryQueryChannel(info.getChannelId()).map(channel -> buildSecurableObjectContainer(channel.getInfo(), channel.getUserPreferences())).orElse(null))
            .append(queryNeAssignments(preferences))
            .filter(Predicates.notNull())
            .toArray(ISecurableObjectContainer.class);
        secNe.setContainerList(containers);
        secNe.setObjectName(preferences.getName());
        secNe.setId(preferences.getId());
        secNe.setIdName(preferences.getName());
        secNe.setIconIdContext(BiCNetComponentType.DCN_MANAGER);
        secNe.setIconIdId(info.getIconId().orElse(null));
        return secNe;
    }

    /**
     * Temporary class to carry NE information in the form of a Securable Object.
     * Unfortunately USM uses the BCB key as the object identifier, so if we switch to
     * SecurableObjectItem instances immediately we'll loose compatibility. For the time being
     * we'll keep on using private objects instead of the SecurableObjectItem class.
     */
    public static final class SecurableNe extends NEItem implements ISecurableObject {

        private static final long serialVersionUID = 1L;

        private final SecurableObjectItem securableDelegate;

        private SecurableNe() {
            securableDelegate = new SecurableObjectItem();
        }

        @Override
        public String getObjectName() {
            return securableDelegate.getObjectName();
        }

        @Override
        public void setObjectName(String objectName) {
            securableDelegate.setObjectName(objectName);
        }

        @Override
        public ISecurableObjectId getSecurableObjectId() {
            return securableDelegate.getSecurableObjectId();
        }

        @Override
        public ISecurityDomainId[] getSecurityDomainList() {
            return securableDelegate.getSecurityDomainList();
        }

        @Override
        public void setSecurityDomainList(ISecurityDomainId[] securityDomainList) {
            securableDelegate.setSecurityDomainList(securityDomainList);
        }

        @Override
        public ISecurableObjectContainerId[] getContainerList() {
            return securableDelegate.getContainerList();
        }

        @Override
        public void setContainerList(ISecurableObjectContainerId[] containerList) {
            securableDelegate.setContainerList(containerList);
        }

        @Override
        public ISecurableObjectMarkable toMarkableSecurableObject(boolean clone) {
            return securableDelegate.toMarkableSecurableObject(clone);
        }

        /**
         * <p>In this case we need to compare IDs from all object "personalities".</p>
         * @see NEItem#equals(Object)
         */
        @Override
        public boolean equals(Object arg0) {
            return NEIdItem.equals(this, arg0) && SecurableObjectIdItem.equals(this, arg0);
        }

        /**
         * <p>In this case we need to merge hash codes from all object "personalities".</p>
         * @see NEItem#hashCode()
         */
        @Override
        public int hashCode() {
            return new HashCodeBuilder()
                .append(NEIdItem.hashCode(this))
                .append(SecurableObjectIdItem.hashCode(this))
                .toHashCode();
        }
    }

    /**
     * Temporary class to carry Domain information in the form of a Securable Object Container.
     * See {@link SecurableNe} for an explanation on why this class exists.
     */
    public static final class SecurableNetworkDomain extends NetworkDomainItem implements ISecurableObjectContainer {

        private static final long serialVersionUID = 1L;

        private final SecurableObjectContainerItem securableDelegate;

        private SecurableNetworkDomain() {
            securableDelegate = new SecurableObjectContainerItem();
        }

        @Override
        public String getContainerName() {
            return securableDelegate.getContainerName();
        }

        @Override
        public void setContainerName(String containerName) {
            securableDelegate.setContainerName(containerName);
        }

        @Override
        public ISecurableObjectContainerId getSecurableObjectContainerId() {
            return securableDelegate.getSecurableObjectContainerId();
        }

        @Override
        public ISecurableObjectContainerId[] getContainerList() {
            return securableDelegate.getContainerList();
        }

        @Override
        public void setContainerList(ISecurableObjectContainerId[] containerList) {
            securableDelegate.setContainerList(containerList);
        }

        @Override public boolean getCompound() {
            return securableDelegate.getCompound();
        }

        @Override public void setCompound(boolean compound) {
            securableDelegate.setCompound(compound);
        }

        @Override
        public ISecurableObjectContainerMarkable toMarkableSecurableObjectContainer(boolean clone) {
            return securableDelegate.toMarkableSecurableObjectContainer(clone);
        }

        /**
         * <p>In this case we need to compare IDs from all object "personalities".</p>
         * @see NEItem#equals(Object)
         */
        @Override
        public boolean equals(Object arg0) {
            return NetworkDomainIdItem.equals(this, arg0) && SecurableObjectContainerIdItem.equals(this, arg0);
        }

        /**
         * <p>In this case we need to merge hash codes from all object "personalities".</p>
         * @see NEItem#hashCode()
         */
        @Override
        public int hashCode() {
            return new HashCodeBuilder()
                .append(NetworkDomainIdItem.hashCode(this))
                .append(SecurableObjectContainerIdItem.hashCode(this))
                .toHashCode();
        }

    }

    /**
     * Temporary class to carry Channel information in the form of a Securable Object Container.
     * See {@link SecurableNe} for an explanation on why this class exists.
     */
    public static final class SecurableChannel extends EMItem implements ISecurableObjectContainer {

        private static final long serialVersionUID = 1L;

        private final SecurableObjectContainerItem securableDelegate;

        private SecurableChannel() {
            securableDelegate = new SecurableObjectContainerItem();
        }

        @Override
        public String getContainerName() {
            return securableDelegate.getContainerName();
        }

        @Override
        public void setContainerName(String containerName) {
            securableDelegate.setContainerName(containerName);
        }

        @Override
        public ISecurableObjectContainerId getSecurableObjectContainerId() {
            return securableDelegate.getSecurableObjectContainerId();
        }

        @Override public boolean getCompound() {
            return securableDelegate.getCompound();
        }

        @Override public void setCompound(boolean compound) {
            securableDelegate.setCompound(compound);
        }

        @Override
        public ISecurableObjectContainerId[] getContainerList() {
            return securableDelegate.getContainerList();
        }

        @Override
        public void setContainerList(ISecurableObjectContainerId[] containerList) {
            securableDelegate.setContainerList(containerList);
        }

        @Override
        public ISecurableObjectContainerMarkable toMarkableSecurableObjectContainer(boolean clone) {
            return securableDelegate.toMarkableSecurableObjectContainer(clone);
        }

        /**
         * <p>In this case we need to compare IDs from all object "personalities".</p>
         * @see NEItem#equals(Object)
         */
        @Override
        public boolean equals(Object arg0) {
            return EMIdItem.equals(this, arg0) && SecurableObjectContainerIdItem.equals(this, arg0);
        }

        /**
         * <p>In this case we need to merge hash codes from all object "personalities".</p>
         * @see NEItem#hashCode()
         */
        @Override
        public int hashCode() {
            return new HashCodeBuilder()
                .append(EMIdItem.hashCode(this))
                .append(SecurableObjectContainerIdItem.hashCode(this))
                .toHashCode();
        }

    }

    /**
     * Temporary class to carry Mediator information in the form of a Securable Object Container.
     * See {@link SecurableNe} for an explanation on why this class exists.
     */
    public static final class SecurableMediator extends MediatorItem implements ISecurableObjectContainer {

        private static final long serialVersionUID = 1L;

        private final SecurableObjectContainerItem securableDelegate;

        private SecurableMediator() {
            securableDelegate = new SecurableObjectContainerItem();
        }

        @Override
        public String getContainerName() {
            return securableDelegate.getContainerName();
        }

        @Override
        public void setContainerName(String containerName) {
            securableDelegate.setContainerName(containerName);
        }

        @Override
        public ISecurableObjectContainerId getSecurableObjectContainerId() {
            return securableDelegate.getSecurableObjectContainerId();
        }

        @Override public boolean getCompound() {
            return securableDelegate.getCompound();
        }

        @Override public void setCompound(boolean compound) {
            securableDelegate.setCompound(compound);
        }

        @Override
        public ISecurableObjectContainerId[] getContainerList() {
            return securableDelegate.getContainerList();
        }

        @Override
        public void setContainerList(ISecurableObjectContainerId[] containerList) {
            securableDelegate.setContainerList(containerList);
        }

        @Override
        public ISecurableObjectContainerMarkable toMarkableSecurableObjectContainer(boolean clone) {
            return securableDelegate.toMarkableSecurableObjectContainer(clone);
        }

        /**
         * <p>In this case we need to compare IDs from all object "personalities".</p>
         * @see NEItem#equals(Object)
         */
        @Override
        public boolean equals(Object arg0) {
            return MediatorIdItem.equals(this, arg0) && SecurableObjectContainerIdItem.equals(this, arg0);
        }

        /**
         * <p>In this case we need to merge hash codes from all object "personalities".</p>
         * @see NEItem#hashCode()
         */
        @Override
        public int hashCode() {
            return new HashCodeBuilder()
                .append(MediatorIdItem.hashCode(this))
                .append(SecurableObjectContainerIdItem.hashCode(this))
                .toHashCode();
        }

    }

    /**
     * Temporary class to carry System information in the form of a Securable Object Container.
     * See {@link SecurableSystem} for an explanation on why this class exists.
     */
    public static final class SecurableSystem extends SystemContainerItem implements ISecurableObjectContainer {

        private static final long serialVersionUID = 1L;

        private final SecurableObjectContainerItem securableDelegate;

        private SecurableSystem() {
            securableDelegate = new SecurableObjectContainerItem();
            securableDelegate.setCompound(true);
        }

        @Override
        public String getContainerName() {
            return securableDelegate.getContainerName();
        }

        @Override
        public void setContainerName(String containerName) {
            securableDelegate.setContainerName(containerName);
        }

        @Override
        public ISecurableObjectContainerId getSecurableObjectContainerId() {
            return securableDelegate.getSecurableObjectContainerId();
        }

        @Override public boolean getCompound() {
            return securableDelegate.getCompound();
        }

        @Override public void setCompound(boolean compound) {
            securableDelegate.setCompound(compound);
        }

        @Override
        public ISecurableObjectContainerId[] getContainerList() {
            return securableDelegate.getContainerList();
        }

        @Override
        public void setContainerList(ISecurableObjectContainerId[] containerList) {
            securableDelegate.setContainerList(containerList);
        }

        @Override
        public ISecurableObjectContainerMarkable toMarkableSecurableObjectContainer(boolean clone) {
            return securableDelegate.toMarkableSecurableObjectContainer(clone);
        }

        @Override
        public String getNativeName() { return securableDelegate.getContainerName();}

        /**
         * <p>In this case we need to compare IDs from all object "personalities".</p>
         * @see SystemContainerItem#equals(Object)
         */
        @Override
        public boolean equals(Object arg0) {
            return SystemContainerIdItem.equals(this, arg0) && SecurableObjectContainerIdItem.equals(this, arg0);
        }

        /**
         * <p>In this case we need to merge hash codes from all object "personalities".</p>
         * @see SystemContainerItem#hashCode()
         */
        @Override
        public int hashCode() {
            return new HashCodeBuilder()
                    .append(SystemContainerIdItem.hashCode(this))
                    .append(SecurableObjectContainerIdItem.hashCode(this))
                    .toHashCode();
        }
    }

    /**
     * Temporary class to carry Container information in the form of a Securable Object Container.
     * See {@link SecurableContainer} for an explanation on why this class exists.
     */
    public static final class SecurableContainer extends GenericContainerItem implements ISecurableObjectContainer {

        private static final long serialVersionUID = 1L;

        private final SecurableObjectContainerItem securableDelegate;

        private SecurableContainer() {
            securableDelegate = new SecurableObjectContainerItem();
        }

        @Override
        public String getContainerName() {
            return securableDelegate.getContainerName();
        }

        @Override
        public void setContainerName(String containerName) {
            securableDelegate.setContainerName(containerName);
        }

        @Override public boolean getCompound() {
            return securableDelegate.getCompound();
        }

        @Override public void setCompound(boolean compound) {
            securableDelegate.setCompound(compound);
        }

        @Override
        public ISecurableObjectContainerId getSecurableObjectContainerId() {
            return securableDelegate.getSecurableObjectContainerId();
        }

        @Override
        public ISecurableObjectContainerId[] getContainerList() {
            return securableDelegate.getContainerList();
        }

        @Override
        public void setContainerList(ISecurableObjectContainerId[] containerList) {
            securableDelegate.setContainerList(containerList);
        }

        @Override
        public String getNativeName() { return securableDelegate.getContainerName();}

        @Override
        public ISecurableObjectContainerMarkable toMarkableSecurableObjectContainer(boolean clone) {
            return securableDelegate.toMarkableSecurableObjectContainer(clone);
        }

        /**
         * <p>In this case we need to compare IDs from all object "personalities".</p>
         * @see GenericContainerIdItem#equals(Object)
         */
        @Override
        public boolean equals(Object arg0) {
            return GenericContainerIdItem.equals(this, arg0) && SecurableObjectContainerIdItem.equals(this, arg0);
        }

        /**
         * <p>In this case we need to merge hash codes from all object "personalities".</p>
         * @see GenericContainerIdItem#hashCode()
         */
        @Override
        public int hashCode() {
            return new HashCodeBuilder()
                    .append(GenericContainerIdItem.hashCode(this))
                    .append(SecurableObjectContainerIdItem.hashCode(this))
                    .toHashCode();
        }
    }
}
