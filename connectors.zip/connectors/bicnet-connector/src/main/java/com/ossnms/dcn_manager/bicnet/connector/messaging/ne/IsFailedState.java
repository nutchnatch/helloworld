package com.ossnms.dcn_manager.bicnet.connector.messaging.ne;

import com.ossnms.bicnet.bcb.model.elementMgmt.CommunicationState;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementProxyMarkable;
import com.ossnms.bicnet.bcb.model.elementMgmt.InitState;
import rx.functions.Func1;

final class IsFailedState implements
        Func1<INetworkElementProxyMarkable, Boolean> {

    @Override
    public Boolean call(INetworkElementProxyMarkable m) {
        return isCommunicationStateFailed(m) || isInitializationStateFailed(m);
    }

    private boolean isInitializationStateFailed(INetworkElementProxyMarkable m) {
        return m.isMarkedInitState() && m.getInitState() == InitState.FAILED;
    }

    private boolean isCommunicationStateFailed(INetworkElementProxyMarkable m) {
        return m.isMarkedCommunicationState() && m.getCommunicationState() == CommunicationState.FAILED;
    }
}