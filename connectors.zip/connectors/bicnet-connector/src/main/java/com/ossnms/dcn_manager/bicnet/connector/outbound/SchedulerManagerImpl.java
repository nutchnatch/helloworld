package com.ossnms.dcn_manager.bicnet.connector.outbound;

import com.ossnms.dcn_manager.composables.outbound.SchedulerManager;

public class SchedulerManagerImpl implements SchedulerManager{

}
