package com.ossnms.dcn_manager.bicnet.connector.messaging;

import java.util.Objects;
import java.util.Optional;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.platform.Notification;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;

/**
 * Carries a BiCNet {@link Notification} along with information about the
 * physical objects that issued it.
 */
public final class DecoratedNotification {

    private final Notification originalNotification;
    private MediatorPhysicalConnectionData originatingPhysicalMediator;
    private ChannelPhysicalConnectionData originatingPhysicalChannel;
    private NePhysicalConnectionData originatingPhysicalNe;

    /**
     * Initializes a decorated notification without information about the
     * originating mediator.
     *
     * Used when the original notification was not issued by a mediator.
     *
     * @param originalNotification Original BiCNet {@link Notification} object.
     */
    public DecoratedNotification(@Nonnull Notification originalNotification) {
        this.originalNotification = originalNotification;
    }

    /**
     * @return Information about the physical Mediator that issued the original notification.
     */
    public Optional<MediatorPhysicalConnectionData> getOriginatingPhysicalMediator() {
        return Optional.ofNullable(originatingPhysicalMediator);
    }

    /**
     * @return Information about the physical Channel that issued the original notification.
     */
    public Optional<ChannelPhysicalConnectionData> getOriginatingPhysicalChannel() {
        return Optional.ofNullable(originatingPhysicalChannel);
    }

    /**
     * @return Information about the physical NE that issued the original notification.
     */
    public Optional<NePhysicalConnectionData> getOriginatingPhysicalNe() {
        return Optional.ofNullable(originatingPhysicalNe);
    }

    /**
     * Gets the managed object affected by the notification, cast to an
     * appropriate class type.
     *
     * @param <T> Expected managed object type.
     * @param affectedObjectClass Expected managed object type class metadata.
     * @return The affected object as an instance of type T.
     */
    public <T extends IManagedObjectId> Optional<T> getAffectedObject(Class<T> affectedObjectClass) {
        return affectedObjectClass.isInstance(originalNotification.affectedMO())
                ? Optional.of(affectedObjectClass.cast(originalNotification.affectedMO()))
                : Optional.empty();
    }

    /**
     * Gets the the notification, cast to an appropriate class type.
     *
     * @param <T> Expected notification type.
     * @param affectedObjectClass Expected notification type class metadata.
     * @return The affected object as an instance of type T.
     */
    public <T extends Notification> Optional<T> getNotification(Class<T> affectedObjectClass) {
        return affectedObjectClass.isInstance(originalNotification)
                ? Optional.of(affectedObjectClass.cast(originalNotification))
                : Optional.empty();
    }

    public DecoratedNotification setOriginatingPhysicalMediator(MediatorPhysicalConnectionData originatingPhysicalMediator) {
        this.originatingPhysicalMediator = originatingPhysicalMediator;
        return this;
    }

    public DecoratedNotification setOriginatingPhysicalChannel(ChannelPhysicalConnectionData originatingPhysicalChannel) {
        this.originatingPhysicalChannel = originatingPhysicalChannel;
        return this;
    }

    public DecoratedNotification setOriginatingPhysicalNe(NePhysicalConnectionData originatingPhysicalNe) {
        this.originatingPhysicalNe = originatingPhysicalNe;
        return this;
    }

    @Override
    public int hashCode() {
        return Objects.hash(originalNotification, originatingPhysicalMediator, originatingPhysicalChannel, originatingPhysicalNe);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final DecoratedNotification rhs = (DecoratedNotification) obj;
        return new EqualsBuilder()
            .append(originalNotification, rhs.originalNotification)
            .append(originatingPhysicalMediator, rhs.originatingPhysicalMediator)
            .append(originatingPhysicalChannel, rhs.originatingPhysicalChannel)
            .append(originatingPhysicalNe, rhs.originatingPhysicalNe)
            .isEquals();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
            .append("originalNotification", originalNotification)
            .append("originatingPhysicalMediator", originatingPhysicalMediator)
            .append("originatingPhysicalChannel", originatingPhysicalChannel)
            .append("originatingPhysicalNe", originatingPhysicalNe)
            .toString();
    };
}
