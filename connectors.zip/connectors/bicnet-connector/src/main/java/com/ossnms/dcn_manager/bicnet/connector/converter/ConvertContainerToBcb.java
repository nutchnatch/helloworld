package com.ossnms.dcn_manager.bicnet.connector.converter;

import com.google.common.base.Function;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.GenericContainerItem;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainer;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;

/**
 * Handles conversion of internal domain entities representing a Container Container to its
 * corresponding type in the BCB object model.
 */
public class ConvertContainerToBcb implements Function<ContainerInfo, IGenericContainer> {

    /**
     * Converts internal domain entities representing a Container Container to a
     * {@link IGenericContainer} BCB object.
     *
     * @param entity Container Container entity instance that will be the source of data.
     * @return A new instance of {@link IGenericContainer} filled with data.
     */
    public static IGenericContainer convert(ContainerInfo entity) {
        final IGenericContainer container = new GenericContainerItem();
        fillExisting(entity, container);
        return container;
    }

    /**
     * Fills an existing {@link IGenericContainer} BCB object with information from our domain entity.
     *
     * @param entity Container entity instance that will be the source of data.
     * @param container An instance of {@link IGenericContainer} to be filled with data.
     */
    public static void fillExisting(ContainerInfo entity, IGenericContainer container) {
        container.setId(entity.getId());
        container.setIdName(entity.getName());
        container.setParentId(entity.getParentId().orElse(0));
        container.setDescription(entity.getDescription().orElse(null));
        container.setUserLabel(entity.getUserText().orElse(null));
    }

    @Override
    public IGenericContainer apply(ContainerInfo input) {
        return null != input ? convert(input) : null;
    }

}
