package com.ossnms.dcn_manager.bicnet.connector.outbound.notifications;

import com.ossnms.bicnet.bcb.messaging.IBiCNetMessage;
import com.ossnms.bicnet.bcb.messaging.IBiCNetMessageDispatcher;
import com.ossnms.bicnet.bcb.model.IManagedObject;
import com.ossnms.bicnet.bcb.model.IManagedObjectId;
import com.ossnms.bicnet.bcb.model.IManagedObjectMarkable;
import com.ossnms.bicnet.bcb.model.common.BiCNetComponentType;
import com.ossnms.bicnet.bcb.model.elementMgmt.INetworkElementId;
import com.ossnms.bicnet.bcb.model.platform.*;
import com.ossnms.bicnet.messaging.BiCNetMessage;
import com.ossnms.bicnet.messaging.util.BiCNetMessageBuilder;
import com.ossnms.dcn_manager.bicnet.connector.factory.DcnManager;
import com.ossnms.dcn_manager.bicnet.connector.messaging.MessageSourceImpl;
import com.ossnms.dcn_manager.core.events.Event;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.inject.Inject;
import java.util.Date;

class NotificationsManagerBase<E extends Event> extends MessageSourceImpl<E> {

    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationsManagerBase.class);

    @DcnManager
    @Inject
    private IBiCNetMessageDispatcher messageDispatcher;

    /**
     * Builds a <code>IBiCNetMessage</code> instance from the given parameters.
     *
     * @param notif the <code>Notification</code> to send in the message.
     * @param notificationType the <code>NotificationType</code> for this message.
     * @param neId the <code>INetworkElementId</code> to use for this message.
     * @param objectId the <code>ObjectId</code> property value for this message.
     * @return the <code>IBiCNetMessage</code> instance.
     */
    protected IBiCNetMessage buildBiCNetMessage(@Nonnull Notification notif, @Nonnull NotificationType notificationType, @Nullable INetworkElementId neId, @Nonnull String objectId) {
        final IBiCNetMessage biCNetMessage = new BiCNetMessage();

        biCNetMessage.setNeId(neId != null ? neId.getNeId() : 0);
        biCNetMessage.setIntProperty("NotificationType", notificationType.getOrdinal());
        biCNetMessage.setStringProperty("ObjectId", objectId);
        biCNetMessage.setStringProperty(IBiCNetMessage.PROP_SENDER_ID, BiCNetComponentType.DCN_MANAGER.toString());
        biCNetMessage.setObject(new Notification[] { notif });

        LOGGER.debug("{} ObjID: {}", notif, objectId);

        return biCNetMessage;
    }

    protected void sendObjectCreatedNotification(IManagedObject object) {
        LOGGER.debug("Object Created send {}", object.getGenericId());

        final Notification notif = new ObjectCreation(new Date(), object);
        final IBiCNetMessage biCNetMessage =
            buildBiCNetMessage(notif, NotificationType.OBJECT_CREATION, object.neId(), object.key());

        messageDispatcher.sendToSource(biCNetMessage, true);
    }

    protected void sendObjectDeletedNotification(IManagedObjectId object) {
        LOGGER.debug("Object Deleted send {}", object);

        final Notification notif = new ObjectDeletion(new Date(), object);
        final IBiCNetMessage biCNetMessage =
            buildBiCNetMessage(notif, NotificationType.OBJECT_DELETION, object.neId(), object.key());

        messageDispatcher.sendToSource(biCNetMessage, true);
    }

    protected void sendAttributeValueChangeNotification(IManagedObjectMarkable moMarkable) {
        LOGGER.debug("AVC send {}", moMarkable.getGenericId());

        final Notification notif = new AttributeValueChange(new Date(), moMarkable);
        final IBiCNetMessage biCNetMessage =
            buildBiCNetMessage(notif, NotificationType.ATTRIBUTE_VALUE_CHANGE, moMarkable.neId(), moMarkable.key());

        messageDispatcher.sendToSource(biCNetMessage, true);
    }

    protected void sendCustomNotificationToClient(Notification notification) {
        LOGGER.debug("Custom send to client {}", notification);

        final IBiCNetMessage message = new BiCNetMessageBuilder()
                .asPrivate()
                .withPayload(notification)
                .from(BiCNetComponentType.DCN_MANAGER.toString())
                .build();
        messageDispatcher.sendToClient(message);
    }

}