package com.ossnms.dcn_manager.bicnet.configuration.export;

import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NesReply;

public interface NeConfigurationExportService {

    /**
     * Returns NesReply with one page of ExportNEs items.
     *
     * @param sessionContext current context
     * @param lastNE id of last exported NE
     * @param howMany page size, total of objects that will be returned.
     * @return the result o elements respecting the #lastNE and the #howMany params.
     * @throws BcbException
     */
    NesReply export(ISessionContext sessionContext, int lastNE, int howMany) throws BcbException;
}
