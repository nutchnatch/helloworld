package com.ossnms.dcn_manager.bicnet.connector.facade;

import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerIdReply;
import com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerReply;
import com.ossnms.bicnet.bcb.facade.security.ISessionContext;
import com.ossnms.bicnet.bcb.model.BcbException;
import com.ossnms.bicnet.bcb.model.emObjMgmt.IGenericContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainer;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerId;
import com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemContainerMarkable;
import com.ossnms.dcn_manager.bicnet.connector.common.interfaces.SystemContainerService;
import com.ossnms.dcn_manager.bicnet.connector.facade.delegate.SystemContainerHelper;

import javax.annotation.Nonnull;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import java.util.Collection;

/**
 * The bean implementation simply forwards the call to the inner POJO.
 * Once in the public facade, this will be necessary to compose an enormous public
 * interface from a more manageable set of classes.
 */
@Stateless(name = "SystemContainerServiceBean")
@Local(SystemContainerService.class)
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class SystemContainerServiceBean implements SystemContainerService {

    @Inject private SystemContainerHelper helper;

    /**
     * Delete zero or more System containers in one swoop.
     *
     * @param sessionContext     BiCNet session context.
     * @param systemContainerIds All {@link ISystemContainerId} instances representing
     *                           System Containers to delete.
     * @throws BcbException
     */
    @Override public void deleteSystemContainers(@Nonnull ISessionContext sessionContext,
            @Nonnull Collection<ISystemContainerId> systemContainerIds) throws BcbException {
        helper.deleteSystemContainers(sessionContext, systemContainerIds);
    }

    /**
     * Create a new System Container inside a NE Container.
     *
     * @param sessionContext     BiCNet session context.
     * @param systemContainer    System container to be created.
     * @param genericContainerId The parent Generic container.
     * @return The new system container
     * @throws BcbException
     */
    @Override public ISystemContainer createSystemContainer(@Nonnull ISessionContext sessionContext,
            @Nonnull ISystemContainer systemContainer, @Nonnull IGenericContainerId genericContainerId)
            throws BcbException {
        return helper.createSystemContainer(sessionContext, systemContainer, genericContainerId);
    }

    @Override
    public void moveToContainers(ISessionContext sessionContext, Collection<ISystemContainerId> systems, IGenericContainerId primaryContainer, Collection<IGenericContainerId> containers) throws BcbException {
        helper.moveToContainers(sessionContext, systems, primaryContainer, containers);
    }

    /**
     * creates the given SystemContainer. All create-parameters (see Information Model) must be given.
     *
     * @param sessionContext  the session context is passed as 1st parameter in every facade method.
     * @param systemContainer a SystemContainer value object. The following attributes must be valid: idName
     * @return the created SystemContainer as value object.
     * @throws BcbException when there is a server failure (including a communication problem)<br/>
     *                      or when the given systemcontainer object is null<br/>
     *                      or when the server (or network element) rejects to create the systemcontainer.
     */
    @Override public ISystemContainer createSystemContainer(ISessionContext sessionContext,
            ISystemContainer systemContainer) throws BcbException {
        return helper.createSystemContainer(sessionContext, systemContainer);
    }

    /**
     * finds and returns the SystemContainer with the given <code>systemcontainerId</code>.
     *
     * @param sessionContext    the session context is passed as 1st parameter in every facade method.
     * @param systemContainerId the identifier of the requested SystemContainer instance
     * @return the found SystemContainer MO or null, if the MO was not found (see CF000566)
     * @throws BcbException when there is a server failure or when the given <code>systemcontainerId</code> is null.<br/>
     *                      Note: no exception is thrown when the requested MO does not exist. Instead null is returned.
     */
    @Override public ISystemContainer getSingleSystemContainer(ISessionContext sessionContext,
            ISystemContainerId systemContainerId) throws BcbException {
        return helper.getSingleSystemContainer(sessionContext, systemContainerId);
    }

    /**
     * finds and returns a list of SystemContainers matching the given criteria.
     *
     * @param sessionContext the session context is passed as 1st parameter in every facade method
     * @param startAfter     this parameter supports block-wise requests of SystemContainers.
     *                       The Id of the first SystemContainer to be returned (=<code>result.getData()[0]</code>) must be the immediate successor of <code>startAfter</code>.
     *                       This means, that there must not be another SystemContainer X with startAfter less than X less than result.getData()[0].
     *                       However, this condition is only valid at the time of issuing this particular request.
     *                       Due to the stateless nature of this iteration concept the set of objects might change between subsequent block-requests.
     *                       Therefore, even the SystemContainer identified by startAfter may have already been deleted.<br/>
     *                       Use startAfter=null in order to get the first 'howMany' SystemContainers.<br/>
     *                       Use startAfter=lastresult.getLastReadId() in order to continue the last request. an array of pattern SystemContainers forming a set of filter elements.
     *                       A filter element matches a given SystemContainer under the following conditions<ul>
     *                       <li>All marked attributes in the filter element match the corresponding SystemContainer attributes.</li>
     *                       <li>If the filter element contains optional facets then all these facets must be also contained in the SystemContainer.
     *                       All marked attributes of the filter-facets must match the corresponding attributes in the SystemContainer-facets.</li></ul>
     *                       Match between a SystemContainer and a filter element can be tested with {@link com.ossnms.bicnet.bcb.facade.emObjMgmt.SystemContainerItem#matches(ISystemContainer, ISystemContainerMarkable)}.<br/>
     *                       A filter matches a given SystemContainer if at least one filter element matches the SystemContainer.
     * @param filter         The attributes to be filtered
     * @param howMany        specifies the number of SystemContainer elements to be contained in the result list.
     *                       If this parameter is set to -1, this means that as much as possible available SystemContainers are requested.
     *                       However it's not guaranteed  that all objects will be obtained, due to memory limitations. Hence, the caller should use the iteration mechanisms to ensure all objects are retrieved..  @return a SystemContainerReply object containing <ul>
     *                       <li>an array of SystemContainers matching the criteria defined by
     *                       <code>startAfter</code>, <code>filter</code> and <code>howMany</code>.</li>
     *                       <li>a list of all stored MOs, if the filter is empty, <code>null</code>, or if filter.length is 0. Note that
     *                       <code>howMany</code> is taken into account in this constraint.</li>
     *                       <li>an empty reply, if <code>howMany</code> is 0.</li></ul>
     *                       The called server may shorten this array by returning less elements than was requested in the howMany parameter.
     *                       This might be necessary e.g. due to memory limitations.
     *                       As a consequence the client must check the end-of-list condition by calling endOfFile() on the returned object
     *                       and must not interpret a smaller number of replied objects as an end-of-list condition.<br/>
     *                       CF000375-01: In the case the number of objects found during this operation is zero, this operation should return a reply object which <ul>
     *                       <li>is NOT null</li>
     *                       <li>contains an empty Array , i.e. an array of the correct type  - i.e. the same array as being returned for the not-empty case which is NOT null but has length zero</li>
     *                       <li>has its endOfFile parameter set to 'true'</li>
     *                       <li>has its lastReadId parameter set to 'null'</li></ul>
     * @throws BcbException
     */
    @Override public SystemContainerReply getSystemContainerList(ISessionContext sessionContext,
            ISystemContainerId startAfter, ISystemContainerMarkable[] filter, int howMany) throws BcbException {
        return helper.getSystemContainerList(sessionContext, startAfter, filter, howMany);
    }

    /**
     * finds and returns a list of Ids for all SystemContainer matching the given criteria
     * This method works in the same way as getSystemContainerList,
     * but instead of returning the complete SystemContainers it just delivers their Ids
     *
     * @param sessionContext the session context is passed as 1st parameter in every facade method
     * @param startAfter     same meaning as in getSystemContainerList
     * @param filter         same meaning as in getSystemContainerList
     * @param howMany        same meaning as in getSystemContainerList
     * @return a SystemContainerIdReply object containing an arry of SystemContainer identifiers.
     * CF000375-01: In the case the number of objects found during this operation is zero, this operation should return a reply object which <ul>
     * <li>is NOT null</li>
     * <li>contains an empty Array , i.e. an array of the correct type  - i.e. the same array as being returned for the not-empty case which is NOT null but has length zero</li>
     * <li>has its endOfFile parameter set to 'true'</li>
     * <li>has its lastReadId parameter set to 'null'</li></ul>
     * @throws BcbException
     */
    @Override public SystemContainerIdReply getSystemContainerIdList(ISessionContext sessionContext,
            ISystemContainerId startAfter, ISystemContainerMarkable[] filter, int howMany) throws BcbException {
        return helper.getSystemContainerIdList(sessionContext, startAfter, filter, howMany);
    }

    /**
     * deletes the given SystemContainer.
     *
     * @param sessionContext    the session context is passed as 1st parameter in every facade method
     * @param systemContainerId a SystemContainer-Id value object identifying the SystemContainer to delete
     * @throws BcbException when there is a server failure (including a communication problem)<br/>
     *                      or when the given systemcontainerId is null<br/>
     *                      or when the given systemcontainer does not exist<br/>
     *                      or when the server (or network element) rejects to delete the systemcontainer.
     */
    @Override public void deleteSystemContainer(ISessionContext sessionContext, ISystemContainerId systemContainerId)
            throws BcbException {
        helper.deleteSystemContainer(sessionContext, systemContainerId);
    }

    /**
     * modifies the given SystemContainer and returns the modified SystemContainer.
     *
     * @param sessionContext  the session context is passed as 1st parameter in every facade method.
     * @param systemContainer the SystemContainer to be modified as a markable value object.
     *                        Modification is applied to all <b>marked</b> (cc.isMarkedXxx() == true) attributes in <code>systemcontainer</code>.
     *                        Modification is done in a best-effort manner, i.e. if a particular attribute cannot be modified,
     *                        then no exception is thrown and all remaining attributes are modified.<br/>
     *                        <b>NOTE: Id attributes cannot be modified.</b> The value of the marker-flags for these attributes is ignored.
     *                        All Id attributes must be valid. These attributes are used on the server side to find the object to be modified.
     * @return the modified SystemContainer as a markable value object on which the modified attributes
     * are <b>marked true</b> and attributes that have not been
     * modified are <b>marked false</b>.
     * @throws BcbException when there is a server failure (including a communication problem)<br/>
     *                      or when the given systemcontainer or its id attribute is null<br/>
     *                      or when the systemcontainer does not exist.
     */
    @Override public ISystemContainerMarkable modifySystemContainer(ISessionContext sessionContext,
            ISystemContainerMarkable systemContainer) throws BcbException {
        return helper.modifySystemContainer(sessionContext, systemContainer);
    }

    /**
     * modifies all the given SystemContainers. This is equivalent to calling modifySystemContainer() for each individual SystemContainer instance.
     *
     * @param sessionContext   the session context is passed as 1st parameter in every facade method.
     * @param systemContainers array of SystemContainers to be modified as markable value objects.
     * @return an array of markable SystemContainers with all the elements in <code>ccs</code>.
     * Each element is set and marked according to the status of the modify operation performed on it.
     * @throws BcbException when there is a server failure (including a communication problem)<br/>
     *                      or when the given id array is or contains null<br/>
     *                      or when one of the systemcontainers does not exist.
     */
    @Override public ISystemContainerMarkable[] modifySystemContainers(ISessionContext sessionContext,
            ISystemContainerMarkable[] systemContainers) throws BcbException {
        return helper.modifySystemContainers(sessionContext, systemContainers);
    }
}
