package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.bnpp.cardif.sugar.rest.ui.model.FolderType;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

public class FolderTypeConverterTest {
    
    private PodamFactory factory = new PodamFactoryImpl();

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void testConvertFolderClass() {
        
        FolderClass obj1 = factory.manufacturePojo(FolderClass.class);
        FolderClass obj3 = new FolderClass();
        
        FolderType result = FolderTypeConverter.convert(obj1);
        assertNotNull(result);
        assertNotNull(result.getName());
        assertTrue(result.getName().equals(obj1.getLongLabel()));
        
        FolderType result3 = FolderTypeConverter.convert(obj3);
        assertNotNull(result3);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testConvertListOfFolderClass() {
        
        List<FolderClass> obj1 = factory.manufacturePojo(List.class, FolderClass.class);
        List<FolderClass> obj3 = new ArrayList<>();
        
        List<FolderType> result = FolderTypeConverter.convert(obj1);
        assertNotNull(result);
        assertTrue(result.size() == obj1.size());
        
        List<FolderType> result3 = FolderTypeConverter.convert(obj3);
        assertNotNull(result3);
    }

    @Test
    public void testConvertFolderTypeString() {
        
        FolderType obj1 = factory.manufacturePojo(FolderType.class);
        FolderType obj2 = factory.manufacturePojoWithFullData(FolderType.class);
        FolderType obj3 = new FolderType();
        
        FolderClass result = FolderTypeConverter.convert(obj1, "Syldavia");
        assertNotNull(result);
        assertNotNull(result.getLongLabel());
        assertTrue(result.getLongLabel().equals(obj1.getName()));
        
        FolderClass result2 = FolderTypeConverter.convert(obj2, "Syldavia");
        assertNotNull(result2);
        assertNotNull(result2.getLongLabel());
        assertTrue(result2.getLongLabel().equals(obj2.getName()));
        
        FolderClass result3 = FolderTypeConverter.convert(obj3, "Syldavia");
        assertNotNull(result3);
    }

}
