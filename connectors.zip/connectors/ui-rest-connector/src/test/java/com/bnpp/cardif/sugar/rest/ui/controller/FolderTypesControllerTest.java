package com.bnpp.cardif.sugar.rest.ui.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Comparator;
import java.util.List;

import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.AclService;
import com.bnpp.cardif.sugar.frontend.services.FolderTypeService;
import com.bnpp.cardif.sugar.rest.ui.model.Acl;
import com.bnpp.cardif.sugar.rest.ui.model.FolderType;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpp.cardif.sugar.rest.ui.model.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * 
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class FolderTypesControllerTest extends FrontendControllerTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    FolderTypeService folderTypeService;

    @Mock
    AclService aclService;

    @InjectMocks
    private FolderTypesController folderTypesController = new FolderTypesController();

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetAllFolderType() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        boolean inactive = false;
        // Moçked response
        List<FolderClass> result = factory.manufacturePojo(List.class, FolderClass.class);
        // Mockito expectations
        when(folderTypeService.getAllFolderType()).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<FolderType>> finalResult = folderTypesController.getAllFolderType(inactive,
                xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(folderTypeService).getAllFolderType();
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<FolderType> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(result.size(), body.getResult().size());
        result.sort(Comparator.comparing(FolderClass::getLongLabel, String.CASE_INSENSITIVE_ORDER));
        assertEquals(result.get(0).getLongLabel(), body.getResult().get(0).getName());
    }

    @Test
    public void testGetFolderTypeByID() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String folderTypeId = "123";
        Integer folderTypeVersion = new Integer(1);
        // Moçked response
        FolderClass result = factory.manufacturePojo(FolderClass.class);
        // Mockito expectations
        when(folderTypeService.getFolderTypeByID(folderTypeId, folderTypeVersion)).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<FolderType>> finalResult = folderTypesController.getFolderTypeByID(folderTypeId,
                folderTypeVersion, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(folderTypeService).getFolderTypeByID(folderTypeId, folderTypeVersion);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<FolderType> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getLongLabel(), body.getResult().get(0).getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testSearchFolderTags() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String folderTypeId = "123";
        int version = 1;
        Integer folderTypeVersion = new Integer(version);
        // Moçked response
        List<TagClass> result = factory.manufacturePojo(List.class, TagClass.class);
        // Mockito expectations
        when(folderTypeService.getFolderTypeTags(folderTypeId, version)).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Tag>> finalResult = folderTypesController.searchFolderTags(folderTypeId,
                folderTypeVersion, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(folderTypeService).getFolderTypeTags(folderTypeId, version);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Tag> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(result.size(), body.getResult().size());
        assertEquals(result.get(0).getSymbolicName(), body.getResult().get(0).getName());
    }

    @Test
    public void testCreateFolderType() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        FolderType inputFolderType = factory.manufacturePojo(FolderType.class);

        // Moçked response
        FolderClass result = factory.manufacturePojo(FolderClass.class);
        // Mockito expectations
        when(folderTypeService.createFolderType(any(FolderClass.class))).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<FolderType>> finalResult = folderTypesController.createFolderType(inputFolderType,
                xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(folderTypeService).createFolderType(any(FolderClass.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<FolderType> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getLongLabel(), body.getResult().get(0).getName());
    }

    @Test
    public void testUpdateFolderType() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String folderTypeId = "123";
        int version = 1;
        Integer folderTypeVersion = new Integer(version);
        FolderType inputFolderType = factory.manufacturePojo(FolderType.class);

        // Moçked response
        FolderClass result = factory.manufacturePojo(FolderClass.class);
        // Mockito expectations
        when(folderTypeService.updateFolderType(any(FolderClass.class))).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<FolderType>> finalResult = folderTypesController.updateFolderType(folderTypeId,
                folderTypeVersion, inputFolderType, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(folderTypeService).updateFolderType(any(FolderClass.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<FolderType> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getLongLabel(), body.getResult().get(0).getName());
    }

    @Test
    public void testActivateFolderType() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String folderTypeId = "123";
        int version = 1;
        Integer folderTypeVersion = new Integer(version);

        // Moçked response

        // Mockito expectations

        // Execute the method being tested
        ResponseEntity<RestResponse<String>> finalResult = folderTypesController.activateFolderType(folderTypeId,
                folderTypeVersion, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(folderTypeService).activateFolderType(folderTypeId, version);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<String> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(0, body.getResult().size());
    }

    @Test
    public void testDeactivateFolderType() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String folderTypeId = "123";
        int version = 1;
        Integer folderTypeVersion = new Integer(version);

        // Moçked response

        // Mockito expectations

        // Execute the method being tested
        ResponseEntity<RestResponse<String>> finalResult = folderTypesController.deactivateFolderType(folderTypeId,
                folderTypeVersion, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(folderTypeService).deactivateFolderType(folderTypeId, version);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<String> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(0, body.getResult().size());
    }

    @Test
    public void testGetFolderTypeAcl() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String folderTypeId = "123";
        int version = 1;
        Integer folderTypeVersion = new Integer(version);
        // Moçked response
        AccessControlList result = factory.manufacturePojo(AccessControlList.class);
        AccessControlList result2 = factory.manufacturePojo(AccessControlList.class);
        // Mockito expectations
        when(aclService.getAclListByClassId(folderTypeId, version, true)).thenReturn(result);
        when(aclService.getAclListByClassId(folderTypeId, version, false)).thenReturn(result2);

        // Execute the method being tested
        ResponseEntity<RestResponse<Acl>> finalResult = folderTypesController.getFolderTypeAcl(folderTypeId,
                folderTypeVersion, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(aclService).getAclListByClassId(folderTypeId, version, true);
        verify(aclService).getAclListByClassId(folderTypeId, version, false);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Acl> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(2, body.getResult().size());
        assertEquals(result.getName(), body.getResult().get(0).getName());
    }

    @Test
    public void testAssignFolderTypeAcl() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String folderTypeId = "123";
        int version = 1;
        Integer folderTypeVersion = new Integer(version);
        Acl inputAcl = factory.manufacturePojo(Acl.class);
        // Moçked response
        AccessControlList result = factory.manufacturePojo(AccessControlList.class);
        // Mockito expectations
        when(aclService.assignAclToClassId(inputAcl.getAclId(), folderTypeId, version, inputAcl.getIsInstanceValue()))
                .thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Acl>> finalResult = folderTypesController.assignFolderTypeAcl(folderTypeId,
                folderTypeVersion, inputAcl, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(aclService).assignAclToClassId(inputAcl.getAclId(), folderTypeId, version,
                inputAcl.getIsInstanceValue());
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Acl> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getName(), body.getResult().get(0).getName());
    }

}
