package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.bnpp.cardif.sugar.rest.ui.model.DocumentAttachedToFoldersResult;
import com.bnpp.cardif.sugar.rest.ui.model.Folder;
import com.bnpp.cardif.sugar.rest.ui.model.FolderCreationResult;

import uk.co.jemos.podam.api.DataProviderStrategy;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

public class FolderConverterTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Before
    public void setUp() throws Exception {
        DataProviderStrategy strategy = factory.getStrategy();
        strategy.setDefaultNumberOfCollectionElements(2);
    }

    @Test
    public void testConvertFolderStringString() {

        com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder obj1 = factory
                .manufacturePojo(com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder.class);
        com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder obj3 = new com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder();

        Folder result = FolderConverter.convert(obj1, "Syldavia", "Valid-token");
        assertNotNull(result);
        assertNotNull(result.getName());
        assertNotNull(obj1.getData());
        assertTrue(result.getName().equals(obj1.getData().getName()));

        Folder result3 = FolderConverter.convert(obj3, "Syldavia", "Valid-token");
        assertNotNull(result3);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testConvertListOfFolderStringString() {

        List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> obj1 = factory.manufacturePojo(
                List.class, com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder.class);
        List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> obj3 = new ArrayList<>();

        List<Folder> result = FolderConverter.convert(obj1, "Syldavia", "Valid-token");
        assertNotNull(result);
        assertTrue(result.size() == obj1.size());

        List<Folder> result3 = FolderConverter.convert(obj3, "Syldavia", "Valid-token");
        assertNotNull(result3);
        assertTrue(result3.size() == 0);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testConvertListOfFolderString() {

        List<Folder> obj1 = factory.manufacturePojo(List.class, Folder.class);
        List<Folder> obj3 = new ArrayList<>();

        List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> result = FolderConverter
                .convert(obj1, "Syldavia");
        assertNotNull(result);
        assertTrue(result.size() == obj1.size());

        List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> result3 = FolderConverter
                .convert(obj3, "Syldavia");
        assertNotNull(result3);
        assertTrue(result3.size() == 0);
    }

    @Test
    public void testConvertFolderString() {

        Folder obj1 = factory.manufacturePojo(Folder.class);
        Folder obj3 = new Folder();

        com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder result = FolderConverter.convert(obj1,
                "Syldavia");
        assertNotNull(result);
        assertNotNull(result.getData());
        assertNotNull(obj1.getName());
        assertTrue(obj1.getName().equals(result.getData().getName()));

        com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder result3 = FolderConverter.convert(obj3,
                "Syldavia");
        assertNotNull(result3);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testConvertToFolderCreationResult() {

        List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> obj1 = factory.manufacturePojo(
                List.class, com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder.class);
        List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> obj3 = new ArrayList<>();

        List<FolderCreationResult> result = FolderConverter.convertToFolderCreationResult(obj1);
        assertNotNull(result);
        assertTrue(result.size() == obj1.size());

        List<FolderCreationResult> result3 = FolderConverter.convertToFolderCreationResult(obj3);
        assertNotNull(result3);
        assertTrue(result3.size() == 0);
    }

    @Test
    public void testConvertToDocumentAttachedToFoldersResult() {

        com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder obj1 = factory
                .manufacturePojo(com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder.class);
        com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder obj3 = new com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder();

        DocumentAttachedToFoldersResult result = FolderConverter.convertToDocumentAttachedToFoldersResult(obj1);
        assertNotNull(result);
        assertNotNull(result.getFolderId());
        assertNotNull(obj1.getFolderId());
        assertTrue(obj1.getFolderId().getValue().equals(result.getFolderId()));

        DocumentAttachedToFoldersResult result3 = FolderConverter.convertToDocumentAttachedToFoldersResult(obj3);
        assertNull(result3);
    }

}
