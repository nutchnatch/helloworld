package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

import com.bnpp.cardif.sugar.rest.ui.model.Basket;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

public class BasketConverterTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Test
    public void testConvertBasketString() throws InstantiationException, IllegalAccessException {

        com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket obj1 = factory
                .manufacturePojo(com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket.class);
        com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket obj2 = factory
                .manufacturePojoWithFullData(com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket.class);
        com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket obj3 = com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket.class
                .newInstance();

        Basket result = BasketConverter.convert(obj1, "Syldavia");
        assertNotNull(result);
        assertNotNull(result.getBasketId());
        assertNotNull(obj1.getBasketId());
        assertTrue(result.getBasketId().equals(obj1.getBasketId().getValue()));

        Basket result2 = BasketConverter.convert(obj2, "Syldavia");
        assertNotNull(result2);
        assertNotNull(result2.getBasketId());
        assertNotNull(obj2.getBasketId());
        assertTrue(result2.getBasketId().equals(obj2.getBasketId().getValue()));

        Basket result3 = BasketConverter.convert(obj3, "Syldavia");
        assertNotNull(result3);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testConvertListOfBasketString() {

        List<com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket> obj1 = factory
                .manufacturePojo(List.class, com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket.class);
        List<com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket> obj2 = factory
                .manufacturePojoWithFullData(List.class,
                        com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket.class);

        List<Basket> result = BasketConverter.convert(obj1, "Syldavia");
        assertNotNull(result);
        assertTrue(result.size() != 0);

        List<Basket> result2 = BasketConverter.convert(obj2, "Syldavia");
        assertNotNull(result2);
        assertTrue(result2.size() != 0);
    }

    @Test
    public void testConvertBasketString1() throws InstantiationException, IllegalAccessException {

        Basket obj1 = factory.manufacturePojo(Basket.class);
        Basket obj2 = factory.manufacturePojoWithFullData(Basket.class);
        Basket obj3 = Basket.class.newInstance();

        com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket result = BasketConverter.convert(obj1,
                "Syldavia");
        assertNotNull(result);
        assertNotNull(result.getBasketId());
        assertNotNull(obj1.getBasketId());
        assertTrue(result.getBasketId().getValue().equals(obj1.getBasketId()));
        
        com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket result2 = BasketConverter.convert(obj2,
                "Syldavia");
        assertNotNull(result2);
        assertNotNull(result2.getBasketId());
        assertNotNull(obj2.getBasketId());
        assertTrue(result2.getBasketId().getValue().equals(obj2.getBasketId()));
        
        com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket result3 = BasketConverter.convert(obj3,
                "Syldavia");
        assertNotNull(result3);
    }

}
