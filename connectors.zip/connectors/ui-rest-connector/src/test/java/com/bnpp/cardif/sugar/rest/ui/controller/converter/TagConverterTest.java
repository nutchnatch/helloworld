package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.bnpp.cardif.sugar.rest.ui.model.Tag;
import com.bnpp.cardif.sugar.rest.ui.model.TagElement;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

public class TagConverterTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void testConvertTagClass() {

        TagClass obj1 = factory.manufacturePojo(TagClass.class);
        TagClass obj3 = new TagClass();

        Tag result = TagConverter.convert(obj1);
        assertNotNull(result);
        assertNotNull(result.getName());
        assertTrue(result.getName().equals(obj1.getSymbolicName()));

        Tag result3 = TagConverter.convert(obj3);
        assertNotNull(result3);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testConvertListOfTagClass() {

        List<TagClass> obj1 = factory.manufacturePojo(List.class, TagClass.class);
        List<TagClass> obj3 = new ArrayList<>();

        List<Tag> result = TagConverter.convert(obj1);
        assertNotNull(result);
        assertTrue(result.size() == obj1.size());

        List<Tag> result3 = TagConverter.convert(obj3);
        assertNotNull(result3);
    }

    @Test
    public void testConvertElementTag() {

        com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag obj1 = factory
                .manufacturePojo(com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag.class);
        com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag obj3 = new com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag();

        TagElement result = TagConverter.convertElement(obj1);
        assertNotNull(result);
        assertNotNull(result.getTagName());
        assertTrue(result.getTagName().equals(obj1.getName()));

        TagElement result3 = TagConverter.convertElement(obj3);
        assertNotNull(result3);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testConvertElementListOfTag() {

        List<com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag> obj1 = factory.manufacturePojo(List.class,
                com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag.class);
        List<com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag> obj3 = new ArrayList<>();

        List<TagElement> result = TagConverter.convertElement(obj1);
        assertNotNull(result);
        assertTrue(result.size() == obj1.size());

        List<TagElement> result3 = TagConverter.convertElement(obj3);
        assertNotNull(result3);
    }

    @Test
    public void testConvertTagString() {
        
        Tag obj1 = factory.manufacturePojo(Tag.class);
        Tag obj3 = new Tag();
        
        TagClass result = TagConverter.convert(obj1, "Syldvia");
        assertNotNull(result);
        assertNotNull(result.getSymbolicName());
        assertTrue(result.getSymbolicName().equals(obj1.getName()));

        TagClass result3 = TagConverter.convert(obj3, "Syldavia");
        assertNotNull(result3);
    }

}
