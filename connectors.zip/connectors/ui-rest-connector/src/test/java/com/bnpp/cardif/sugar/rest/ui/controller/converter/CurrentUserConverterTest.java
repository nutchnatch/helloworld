package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.bnpp.cardif.sugar.rest.ui.model.CurrentUser;
import com.bnpp.cardif.sugar.security.AuthenticatedUser;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

public class CurrentUserConverterTest {
    
    private PodamFactory factory = new PodamFactoryImpl();

    @Test
    public void testConvert() throws InstantiationException, IllegalAccessException {
        
        AuthenticatedUser obj1 = factory.manufacturePojo(AuthenticatedUser.class);
        AuthenticatedUser obj2 = factory.manufacturePojoWithFullData(AuthenticatedUser.class);
        
        CurrentUser result = CurrentUserConverter.convert(obj1);
        assertNotNull(result);
        assertNotNull(result.getUsername());
        assertNotNull(obj1.getUsername());
        assertTrue(result.getUsername().equals(obj1.getUsername()));
        
        CurrentUser result2 = CurrentUserConverter.convert(obj2);
        assertNotNull(result2);
        assertNotNull(result2.getUsername());
        assertNotNull(obj2.getUsername());
        assertTrue(result2.getUsername().equals(obj2.getUsername()));
    }

}
