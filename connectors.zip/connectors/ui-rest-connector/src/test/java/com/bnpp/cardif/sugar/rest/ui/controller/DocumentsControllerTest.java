package com.bnpp.cardif.sugar.rest.ui.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.DocumentFilesService;
import com.bnpp.cardif.sugar.frontend.services.DocumentService;
import com.bnpp.cardif.sugar.frontend.services.FolderService;
import com.bnpp.cardif.sugar.frontend.services.model.PagingList;
import com.bnpp.cardif.sugar.rest.ui.model.Document;
import com.bnpp.cardif.sugar.rest.ui.model.DocumentCreationResult;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;

import uk.co.jemos.podam.api.DataProviderStrategy;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * 
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class DocumentsControllerTest extends FrontendControllerTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private DocumentService documentService;

    @Mock
    private FolderService folderService;

    @Mock
    private DocumentFilesService documentFilesService;

    @InjectMocks
    private DocumentsController documentsController = new DocumentsController();

    @Before
    public void setUp() throws Exception {
        super.setUp();
        DataProviderStrategy strategy = factory.getStrategy();
        strategy.setDefaultNumberOfCollectionElements(2);
    }

    @Test
    public void testGetDocumentByID() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String docId = "123";
        // Moçked response
        com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document result = factory
                .manufacturePojo(com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document.class);
        // Mockito expectations
        when(documentService.getDocumentByID(docId)).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Document>> finalResult = documentsController.getDocumentByID(docId, xCardifConsumer,
                xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentService).getDocumentByID(docId);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Document> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getData().getName(), body.getResult().get(0).getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetDocuments() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        List<String> docIdsCriteria = null;
        String quickSearch = factory.manufacturePojo(String.class);
        String creationDateCriteria = "greater_than|2016-10-27";
        String updateDateCriteria = "less_than|2017-10-27";
        String creatorCriteria = "equals_to|my name";
        String lastModifierCriteria = "starts_with|my";
        String nameCriteria = "contains|doc";
        String validityCriteria = "not_equals_to|VALID";
        String confidentialityCriteria = "equals_to|confdential";
        List<String> docTypeIdsCriteria = factory.manufacturePojo(List.class, String.class);
        List<String> tags = new ArrayList<>();
        tags.add("tagName1|string|ends_with|value1");
        tags.add("tagName2|string|not_equals_to|value2");
        Boolean orderAscending = true;
        String orderField = "creation_date";
        String orderTagName = factory.manufacturePojo(String.class);
        Integer pageNumber = 1;
        Integer pageSize = 20;
        // Moçked response
        PagingList<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> result = factory
                .manufacturePojo(PagingList.class,
                        com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document.class);
        // Mockito expectations
        when(documentService.findDocuments(eq(0L), eq(20L), eq(quickSearch), any(List.class), any(OrderClause.class)))
                .thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Document>> finalResult = documentsController.getDocuments(docIdsCriteria,
                quickSearch, creationDateCriteria, updateDateCriteria, creatorCriteria, lastModifierCriteria,
                nameCriteria, validityCriteria, confidentialityCriteria, docTypeIdsCriteria, tags, orderAscending,
                orderField, orderTagName, pageNumber, pageSize, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentService).findDocuments(eq(0L), eq(20L), eq(quickSearch), any(List.class),
                any(OrderClause.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Document> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(result.getItemList().size(), body.getResult().size());
        assertEquals(result.getItemList().get(0).getData().getName(), body.getResult().get(0).getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetDocumentsByIDs() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        List<String> docIdsCriteria = factory.manufacturePojo(List.class, String.class);
        ;
        String quickSearch = factory.manufacturePojo(String.class);
        String creationDateCriteria = "greater_than|2016-10-27";
        String updateDateCriteria = "less_than|2017-10-27";
        String creatorCriteria = "equals_to|my name";
        String lastModifierCriteria = "starts_with|my";
        String nameCriteria = "contains|doc";
        String validityCriteria = "not_equals_to|VALID";
        String confidentialityCriteria = "equals_to|confdential";
        List<String> docTypeIdsCriteria = factory.manufacturePojo(List.class, String.class);
        List<String> tags = new ArrayList<>();
        tags.add("tagName1|string|ends_with|value1");
        tags.add("tagName2|string|not_equals_to|value2");
        Boolean orderAscending = true;
        String orderField = "creation_date";
        String orderTagName = factory.manufacturePojo(String.class);
        Integer pageNumber = 1;
        Integer pageSize = 20;
        // Moçked response
        List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> result = factory.manufacturePojo(
                List.class, com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document.class);
        // Mockito expectations
        when(documentService.getDocumentByIDs(any(List.class))).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Document>> finalResult = documentsController.getDocuments(docIdsCriteria,
                quickSearch, creationDateCriteria, updateDateCriteria, creatorCriteria, lastModifierCriteria,
                nameCriteria, validityCriteria, confidentialityCriteria, docTypeIdsCriteria, tags, orderAscending,
                orderField, orderTagName, pageNumber, pageSize, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentService).getDocumentByIDs(any(List.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Document> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(result.size(), body.getResult().size());
        assertEquals(result.get(0).getData().getName(), body.getResult().get(0).getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testUpdateDocument() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String docId = "123";
        Document inputDocument = factory.manufacturePojo(Document.class);
        // Moçked response
        List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> result = factory.manufacturePojo(
                List.class, com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document.class);
        // Mockito expectations
        when(documentService.reindexDocument(any(List.class))).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<DocumentCreationResult>> finalResult = documentsController.updateDocument(docId,
                inputDocument, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentService).reindexDocument(any(List.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<DocumentCreationResult> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(result.size(), body.getResult().size());
        assertEquals(result.get(0).getId().getValue(), body.getResult().get(0).getDocumentId());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testUpdateDocumentList() throws FunctionalException, TechnicalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        List<Document> documentList = factory.manufacturePojo(List.class, Document.class);
        // Moçked response
        List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> result = factory.manufacturePojo(
                List.class, com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document.class);
        // Mockito expectations
        when(documentService.reindexDocument(any(List.class))).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<DocumentCreationResult>> finalResult = documentsController
                .updateDocumentList(documentList, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentService).reindexDocument(any(List.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<DocumentCreationResult> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(result.size(), body.getResult().size());
        assertEquals(result.get(0).getId().getValue(), body.getResult().get(0).getDocumentId());
    }

}
