package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.bnpp.cardif.sugar.rest.ui.model.BusinessScope;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

public class BusinessScopeConverterTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Test
    public void testConvertBusinessScope() throws InstantiationException, IllegalAccessException {

        com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope obj1 = factory
                .manufacturePojo(com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope.class);
        com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope obj2 = factory
                .manufacturePojoWithFullData(
                        com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope.class);
        com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope obj3 = com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope.class
                .newInstance();

        BusinessScope result = BusinessScopeConverter.convert(obj1);
        assertNotNull(result);
        assertNotNull(result.getBusinessScopeId());
        assertNotNull(obj1.getBusinessScopeId());
        assertTrue(result.getBusinessScopeId().equals(obj1.getBusinessScopeId().getValue()));

        BusinessScope result2 = BusinessScopeConverter.convert(obj2);
        assertNotNull(result2);
        assertNotNull(result2.getBusinessScopeId());
        assertNotNull(obj2.getBusinessScopeId());
        assertTrue(result2.getBusinessScopeId().equals(obj2.getBusinessScopeId().getValue()));

        BusinessScope result3 = BusinessScopeConverter.convert(obj3);
        assertNotNull(result3);
    }

    @Test
    public void testConvertBusinessScope1() throws InstantiationException, IllegalAccessException {

        BusinessScope obj1 = factory.manufacturePojo(BusinessScope.class);
        BusinessScope obj2 = factory.manufacturePojoWithFullData(BusinessScope.class);
        BusinessScope obj3 = BusinessScope.class.newInstance();

        com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope result = BusinessScopeConverter
                .convert(obj1);
        assertNotNull(result);
        assertNotNull(result.getBusinessScopeId());
        assertNotNull(obj1.getBusinessScopeId());
        assertTrue(result.getBusinessScopeId().getValue().equals(obj1.getBusinessScopeId()));

        com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope result2 = BusinessScopeConverter.convert(obj2);
        assertNotNull(result2);
        assertNotNull(result2.getBusinessScopeId());
        assertNotNull(obj2.getBusinessScopeId());
        assertTrue(result2.getBusinessScopeId().getValue().equals(obj2.getBusinessScopeId()));

        com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope result3 = BusinessScopeConverter.convert(obj3);
        assertNotNull(result3);
    }

}
