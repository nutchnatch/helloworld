package com.bnpp.cardif.sugar.rest.ui.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.TagsService;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpp.cardif.sugar.rest.ui.model.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * 
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class TagsControllerTest extends FrontendControllerTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    TagsService tagsService;

    @InjectMocks
    private TagsController tagsController = new TagsController();

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testTagsTagNameGet() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String tagName = "myTag";
        // Moçked response
        List<String> symbolicNames = new ArrayList<>();
        symbolicNames.add(tagName);
        List<TagClass> result = factory.manufacturePojo(List.class, TagClass.class);
        // Mockito expectations
        when(tagsService.getTagListBySymbolicName(symbolicNames)).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Tag>> finalResult = tagsController.tagsTagNameGet(tagName, xCardifConsumer,
                xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(tagsService).getTagListBySymbolicName(symbolicNames);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Tag> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(result.size(), body.getResult().size());
        assertEquals(result.get(0).getSymbolicName(), body.getResult().get(0).getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetAllTags() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        // Moçked response
        List<TagClass> result = factory.manufacturePojo(List.class, TagClass.class);
        // Mockito expectations
        when(tagsService.getAllTagList()).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Tag>> finalResult = tagsController.getAllTags(xCardifConsumer, xCardifRequestId,
                xCardifExtReqId);

        // Validation
        verify(tagsService).getAllTagList();
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Tag> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(result.size(), body.getResult().size());
        assertEquals(result.get(0).getSymbolicName(), body.getResult().get(0).getName());
    }

    @Test
    public void testCreateTag() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        Tag inputTag = factory.manufacturePojo(Tag.class);
        // Moçked response
        TagClass result = factory.manufacturePojo(TagClass.class);
        // Mockito expectations
        when(tagsService.createTag(any(TagClass.class))).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Tag>> finalResult = tagsController.createTag(inputTag, xCardifConsumer,
                xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(tagsService).createTag(any(TagClass.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Tag> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getSymbolicName(), body.getResult().get(0).getName());
    }

    @Test
    public void testUpdateTag() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String tagId = "123";
        Tag inputTag = factory.manufacturePojo(Tag.class);
        // Moçked response
        TagClass result = factory.manufacturePojo(TagClass.class);
        // Mockito expectations
        when(tagsService.updateTag(any(TagClass.class))).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Tag>> finalResult = tagsController.updateTag(tagId, inputTag, xCardifConsumer,
                xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(tagsService).updateTag(any(TagClass.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Tag> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getSymbolicName(), body.getResult().get(0).getName());
    }

}
