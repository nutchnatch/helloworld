package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import com.bnpp.cardif.sugar.rest.ui.model.DocumentIdentifier;
import com.bnpp.cardif.sugar.rest.ui.model.Envelope;
import com.bnpp.cardif.sugar.rest.ui.model.EnvelopeCreationResult;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

import uk.co.jemos.podam.api.DataProviderStrategy;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

public class EnvelopeConverterTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Before
    public void setUp() throws Exception {
        DataProviderStrategy strategy = factory.getStrategy();
        strategy.setDefaultNumberOfCollectionElements(2);
    }

    @Test
    public void testConvertDocumentStringString() {

        com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document obj1 = factory
                .manufacturePojo(com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document.class);
        com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document obj3 = new com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document();

        Envelope result = EnvelopeConverter.convert(obj1, "Syldavia", "Valid-token");
        assertNotNull(result);
        assertNotNull(result.getId());
        assertNotNull(obj1.getId());
        assertTrue(result.getId().equals(obj1.getId().getValue()));

        Envelope result3 = EnvelopeConverter.convert(obj3, "Syldavia", "Valid-token");
        assertNotNull(result3);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGenerateDocumentIdentifierFromIds() {

        List<DocumentIdentifier> listOfDocumentId = new ArrayList<>();
        List<Id> obj1 = factory.manufacturePojo(List.class, Id.class);
        List<DocumentIdentifier> listOfDocumentId3 = new ArrayList<>();
        List<Id> obj3 = new ArrayList<>();

        EnvelopeConverter.generateDocumentIdentifierFromIds(listOfDocumentId, obj1);
        assertNotNull(listOfDocumentId);
        assertTrue(listOfDocumentId.size() == 2);

        EnvelopeConverter.generateDocumentIdentifierFromIds(listOfDocumentId3, obj3);
        assertNotNull(listOfDocumentId3);
        assertTrue(listOfDocumentId3.size() == 0);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGenerateDocumentIdentifier() {

        List<DocumentIdentifier> listOfDocumentId = new ArrayList<>();
        List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> obj1 = factory.manufacturePojo(
                List.class, com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document.class);
        List<DocumentIdentifier> listOfDocumentId3 = new ArrayList<>();
        List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> obj3 = new ArrayList<>();

        EnvelopeConverter.generateDocumentIdentifier(listOfDocumentId, obj1);
        assertNotNull(listOfDocumentId);
        assertTrue(listOfDocumentId.size() == 2);

        EnvelopeConverter.generateDocumentIdentifier(listOfDocumentId3, obj3);
        assertNotNull(listOfDocumentId);
        assertTrue(listOfDocumentId.size() == 2);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testConvertListOfDocumentStringString() {

        List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> obj1 = factory.manufacturePojo(
                List.class, com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document.class);
        List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> obj3 = new ArrayList<>();

        List<Envelope> result = EnvelopeConverter.convert(obj1, "Syldavia", "Valid-token");
        assertNotNull(result);
        assertTrue(result.size() == 2);

        List<Envelope> result3 = EnvelopeConverter.convert(obj3, "Syldavia", "Valid-token");
        assertNotNull(result3);
        assertTrue(result3.size() == 0);
    }

    @Test
    public void testConvertEnvelopeString() {

        Envelope obj1 = factory.manufacturePojo(Envelope.class);
        Envelope obj3 = new Envelope();

        com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document result = EnvelopeConverter.convert(obj1,
                "Syldavia");
        assertNotNull(result);
        assertNotNull(result.getId());
        assertTrue(result.getId().getValue().equals(obj1.getId()));

        com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document result3 = EnvelopeConverter.convert(obj3,
                "Syldavia");
        assertNotNull(result3);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testConvertToEnvelopeCreationResult() {

        List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> obj1 = factory.manufacturePojo(
                List.class, com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document.class);
        List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> obj3 = new ArrayList<>();

        List<EnvelopeCreationResult> result = EnvelopeConverter.convertToEnvelopeCreationResult(obj1);
        assertNotNull(result);
        assertTrue(result.size() == 1);

        List<EnvelopeCreationResult> result3 = EnvelopeConverter.convertToEnvelopeCreationResult(obj3);
        assertNotNull(result3);
        assertTrue(result3.size() == 0);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testConvertListOfMultipartFileStringDocumentClass() {

        List<MultipartFile> obj1 = factory.manufacturePojo(List.class, MockMultipartFile.class);

        com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document result = EnvelopeConverter.convert(obj1,
                "Syldavia");
        assertNotNull(result);
        assertNotNull(result.getData());

        com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document result3 = EnvelopeConverter.convert(obj1,
                "Syldavia");
        assertNotNull(result3);
        assertNotNull(result3.getData());
    }

}
