package com.bnpp.cardif.sugar.rest.ui.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Comparator;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.AclService;
import com.bnpp.cardif.sugar.frontend.services.DocumentTypeService;
import com.bnpp.cardif.sugar.rest.ui.model.Acl;
import com.bnpp.cardif.sugar.rest.ui.model.EnvelopeType;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpp.cardif.sugar.rest.ui.model.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * 
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class EnvelopeTypesControllerTest extends FrontendControllerTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    DocumentTypeService documentTypeService;

    @Mock
    AclService aclService;

    @InjectMocks
    private EnvelopeTypesController envelopeTypesController = new EnvelopeTypesController();

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testGetEnvelopeTypeByID() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String envelopeTypeId = "123";
        Integer envelopeTypeVersion = new Integer(1);
        // Moçked response
        DocumentClass result = factory.manufacturePojo(DocumentClass.class);
        // Mockito expectations
        when(documentTypeService.getDocumentTypeByID(envelopeTypeId, envelopeTypeVersion)).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<EnvelopeType>> finalResult = envelopeTypesController.getEnvelopeTypeByID(
                envelopeTypeId, envelopeTypeVersion, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentTypeService).getDocumentTypeByID(envelopeTypeId, envelopeTypeVersion);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<EnvelopeType> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getLongLabel(), body.getResult().get(0).getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetEnvelopeTypes() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        boolean inactive = false;
        // Moçked response
        List<DocumentClass> result = factory.manufacturePojo(List.class, DocumentClass.class);
        // Mockito expectations
        when(documentTypeService.getAllEnvelopeType()).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<EnvelopeType>> finalResult = envelopeTypesController.getEnvelopeTypes(inactive,
                xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentTypeService).getAllEnvelopeType();
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<EnvelopeType> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(result.size(), body.getResult().size());
        result.sort(Comparator.comparing(DocumentClass::getLongLabel, String.CASE_INSENSITIVE_ORDER));
        assertEquals(result.get(0).getLongLabel(), body.getResult().get(0).getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testSearchEnvelopeTags() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String envelopeTypeId = "123";
        int version = 1;
        Integer envelopeTypeVersion = new Integer(version);
        // Moçked response
        List<TagClass> result = factory.manufacturePojo(List.class, TagClass.class);
        // Mockito expectations
        when(documentTypeService.getDocumentTypeTags(envelopeTypeId, version)).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Tag>> finalResult = envelopeTypesController.searchEnvelopeTags(envelopeTypeId,
                envelopeTypeVersion, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentTypeService).getDocumentTypeTags(envelopeTypeId, version);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Tag> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(result.size(), body.getResult().size());
        assertEquals(result.get(0).getSymbolicName(), body.getResult().get(0).getName());
    }

    @Test
    public void testCreateEnvelopeType() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        EnvelopeType inputEnvelopeType = factory.manufacturePojo(EnvelopeType.class);

        // Moçked response
        DocumentClass result = factory.manufacturePojo(DocumentClass.class);
        // Mockito expectations
        when(documentTypeService.createEnvelopeType(any(DocumentClass.class))).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<EnvelopeType>> finalResult = envelopeTypesController
                .createEnvelopeType(inputEnvelopeType, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentTypeService).createEnvelopeType(any(DocumentClass.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<EnvelopeType> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getLongLabel(), body.getResult().get(0).getName());
    }

    @Test
    public void testUpdateEnvelopeType() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String envelopeTypeId = "123";
        int version = 1;
        Integer envelopeTypeVersion = new Integer(version);
        EnvelopeType inputEnvelopeType = factory.manufacturePojo(EnvelopeType.class);

        // Moçked response
        DocumentClass result = factory.manufacturePojo(DocumentClass.class);
        // Mockito expectations
        when(documentTypeService.updateEnvelopeType(any(DocumentClass.class))).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<EnvelopeType>> finalResult = envelopeTypesController.updateEnvelopeType(
                envelopeTypeId, envelopeTypeVersion, inputEnvelopeType, xCardifConsumer, xCardifRequestId,
                xCardifExtReqId);

        // Validation
        verify(documentTypeService).updateEnvelopeType(any(DocumentClass.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<EnvelopeType> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getLongLabel(), body.getResult().get(0).getName());
    }

    @Test
    public void testActivateEnvelopeType() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String envelopeTypeId = "123";
        int version = 1;
        Integer envelopeTypeVersion = new Integer(version);

        // Moçked response

        // Mockito expectations

        // Execute the method being tested
        ResponseEntity<RestResponse<String>> finalResult = envelopeTypesController.activateEnvelopeType(envelopeTypeId,
                envelopeTypeVersion, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentTypeService).activateEnvelopeType(envelopeTypeId, version);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<String> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(0, body.getResult().size());
    }

    @Test
    public void testDeactivateEnvelopeType() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String envelopeTypeId = "123";
        int version = 1;
        Integer envelopeTypeVersion = new Integer(version);

        // Moçked response

        // Mockito expectations

        // Execute the method being tested
        ResponseEntity<RestResponse<String>> finalResult = envelopeTypesController.deactivateEnvelopeType(
                envelopeTypeId, envelopeTypeVersion, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentTypeService).deactivateEnvelopeType(envelopeTypeId, version);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<String> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(0, body.getResult().size());
    }

    @Test
    public void testGetEnvelopeTypeAcl() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String envelopeTypeId = "123";
        int version = 1;
        Integer envelopeTypeVersion = new Integer(version);
        // Moçked response
        AccessControlList result = factory.manufacturePojo(AccessControlList.class);
        AccessControlList result2 = factory.manufacturePojo(AccessControlList.class);
        // Mockito expectations
        when(aclService.getAclListByClassId(envelopeTypeId, version, true)).thenReturn(result);
        when(aclService.getAclListByClassId(envelopeTypeId, version, false)).thenReturn(result2);

        // Execute the method being tested
        ResponseEntity<RestResponse<Acl>> finalResult = envelopeTypesController.getEnvelopeTypeAcl(envelopeTypeId,
                envelopeTypeVersion, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(aclService).getAclListByClassId(envelopeTypeId, version, true);
        verify(aclService).getAclListByClassId(envelopeTypeId, version, false);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Acl> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(2, body.getResult().size());
        assertEquals(result.getName(), body.getResult().get(0).getName());
    }

    @Test
    public void testAssignEnvelopeTypeAcl() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String envelopeTypeId = "123";
        int version = 1;
        Integer envelopeTypeVersion = new Integer(version);
        Acl inputAcl = factory.manufacturePojo(Acl.class);
        // Moçked response
        AccessControlList result = factory.manufacturePojo(AccessControlList.class);
        // Mockito expectations
        when(aclService.assignAclToClassId(inputAcl.getAclId(), envelopeTypeId, version, inputAcl.getIsInstanceValue()))
                .thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Acl>> finalResult = envelopeTypesController.assignEnvelopeTypeAcl(envelopeTypeId,
                envelopeTypeVersion, inputAcl, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(aclService).assignAclToClassId(inputAcl.getAclId(), envelopeTypeId, version,
                inputAcl.getIsInstanceValue());
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Acl> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getName(), body.getResult().get(0).getName());
    }

}
