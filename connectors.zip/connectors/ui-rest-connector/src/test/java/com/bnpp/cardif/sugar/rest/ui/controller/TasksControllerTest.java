package com.bnpp.cardif.sugar.rest.ui.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.TasksService;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpp.cardif.sugar.rest.ui.model.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * 
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class TasksControllerTest extends FrontendControllerTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private TasksService tasksService;

    @InjectMocks
    private TasksController tasksController = new TasksController();

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testGetTaskByID() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String taskId = "123";
        // Moçked response
        Task result = factory.manufacturePojo(Task.class);
        // Mockito expectations
        when(tasksService.getTaskByID(taskId)).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<com.bnpp.cardif.sugar.rest.ui.model.Task>> finalResult = tasksController
                .getTaskByID(taskId, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(tasksService).getTaskByID(taskId);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<com.bnpp.cardif.sugar.rest.ui.model.Task> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getName(), body.getResult().get(0).getName());
    }

    @Test
    public void testTransferTask() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String taskId = "123";
        String basketId = "456";
        // Moçked response
        String result = factory.manufacturePojo(String.class);
        // Mockito expectations
        when(tasksService.transferTask(taskId, basketId)).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<String>> finalResult = tasksController.transferTask(taskId, basketId,
                xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(tasksService).transferTask(taskId, basketId);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<String> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result, body.getResult().get(0));
    }

    @Test
    public void testLockTask() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String taskId = "123";
        // Moçked response
        String result = factory.manufacturePojo(String.class);
        // Mockito expectations
        when(tasksService.lockTask(taskId)).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<String>> finalResult = tasksController.lockTask(taskId, xCardifConsumer,
                xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(tasksService).lockTask(taskId);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<String> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result, body.getResult().get(0));
    }

    @Test
    public void testUnlockTask() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String taskId = "123";
        // Moçked response
        String result = factory.manufacturePojo(String.class);
        // Mockito expectations
        when(tasksService.unlockTask(taskId)).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<String>> finalResult = tasksController.unlockTask(taskId, xCardifConsumer,
                xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(tasksService).unlockTask(taskId);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<String> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result, body.getResult().get(0));
    }

    @Test
    public void testUpdateTaskStatus() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String taskId = "123";
        String status = "test";
        // Moçked response
        String result = factory.manufacturePojo(String.class);
        // Mockito expectations
        when(tasksService.updateTaskStatus(taskId, status)).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<String>> finalResult = tasksController.updateTaskStatus(taskId, status,
                xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(tasksService).updateTaskStatus(taskId, status);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<String> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result, body.getResult().get(0));
    }

}
