package com.bnpp.cardif.sugar.rest.ui.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Comparator;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.AclService;
import com.bnpp.cardif.sugar.frontend.services.DocumentTypeService;
import com.bnpp.cardif.sugar.rest.ui.model.Acl;
import com.bnpp.cardif.sugar.rest.ui.model.DocumentType;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpp.cardif.sugar.rest.ui.model.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * 
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class DocumentTypesControllerTest extends FrontendControllerTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    DocumentTypeService documentTypeService;

    @Mock
    AclService aclService;

    @InjectMocks
    private DocumentTypesController documentTypesController = new DocumentTypesController();

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testGetDocumentTypeById() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String documentTypeId = "123";
        Integer documentTypeVersion = new Integer(1);
        // Moçked response
        DocumentClass result = factory.manufacturePojo(DocumentClass.class);
        // Mockito expectations
        when(documentTypeService.getDocumentTypeByID(documentTypeId, documentTypeVersion)).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<DocumentType>> finalResult = documentTypesController.getDocumentTypeById(
                documentTypeId, documentTypeVersion, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentTypeService).getDocumentTypeByID(documentTypeId, documentTypeVersion);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<DocumentType> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getLongLabel(), body.getResult().get(0).getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetDocumentTypes() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        boolean inactive = false;
        // Moçked response
        List<DocumentClass> result = factory.manufacturePojo(List.class, DocumentClass.class);
        // Mockito expectations
        when(documentTypeService.getAllDocumentType()).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<DocumentType>> finalResult = documentTypesController.getDocumentTypes(inactive,
                xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentTypeService).getAllDocumentType();
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<DocumentType> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(result.size(), body.getResult().size());

        result.sort(Comparator.comparing(DocumentClass::getLongLabel, String.CASE_INSENSITIVE_ORDER));
        assertEquals(result.get(0).getLongLabel(), body.getResult().get(0).getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testSearchDocumentTags() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String documentTypeId = "123";
        int version = 1;
        Integer documentTypeVersion = new Integer(version);
        // Moçked response
        List<TagClass> result = factory.manufacturePojo(List.class, TagClass.class);
        // Mockito expectations
        when(documentTypeService.getDocumentTypeTags(documentTypeId, version)).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Tag>> finalResult = documentTypesController.searchDocumentTags(documentTypeId,
                documentTypeVersion, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentTypeService).getDocumentTypeTags(documentTypeId, version);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Tag> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(result.size(), body.getResult().size());
        assertEquals(result.get(0).getSymbolicName(), body.getResult().get(0).getName());
    }

    @Test
    public void testCreateDocumentType() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        DocumentType inputDocumentType = factory.manufacturePojo(DocumentType.class);

        // Moçked response
        DocumentClass result = factory.manufacturePojo(DocumentClass.class);
        // Mockito expectations
        when(documentTypeService.createDocumentType(any(DocumentClass.class))).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<DocumentType>> finalResult = documentTypesController
                .createDocumentType(inputDocumentType, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentTypeService).createDocumentType(any(DocumentClass.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<DocumentType> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getLongLabel(), body.getResult().get(0).getName());
    }

    @Test
    public void testUpdateDocumentType() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String documentTypeId = "123";
        int version = 1;
        Integer documentTypeVersion = new Integer(version);
        DocumentType inputDocumentType = factory.manufacturePojo(DocumentType.class);

        // Moçked response
        DocumentClass result = factory.manufacturePojo(DocumentClass.class);
        // Mockito expectations
        when(documentTypeService.updateDocumentType(any(DocumentClass.class))).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<DocumentType>> finalResult = documentTypesController.updateDocumentType(
                documentTypeId, documentTypeVersion, inputDocumentType, xCardifConsumer, xCardifRequestId,
                xCardifExtReqId);

        // Validation
        verify(documentTypeService).updateDocumentType(any(DocumentClass.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<DocumentType> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getLongLabel(), body.getResult().get(0).getName());
    }

    @Test
    public void testActivateDocumentType() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String documentTypeId = "123";
        int version = 1;
        Integer documentTypeVersion = new Integer(version);

        // Moçked response

        // Mockito expectations

        // Execute the method being tested
        ResponseEntity<RestResponse<String>> finalResult = documentTypesController.activateDocumentType(documentTypeId,
                documentTypeVersion, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentTypeService).activateDocumentType(documentTypeId, version);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<String> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(0, body.getResult().size());
    }

    @Test
    public void testDeactivateDocumentType() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String documentTypeId = "123";
        int version = 1;
        Integer documentTypeVersion = new Integer(version);

        // Moçked response

        // Mockito expectations

        // Execute the method being tested
        ResponseEntity<RestResponse<String>> finalResult = documentTypesController.deactivateDocumentType(
                documentTypeId, documentTypeVersion, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentTypeService).deactivateDocumentType(documentTypeId, version);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<String> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(0, body.getResult().size());
    }

    @Test
    public void testGetDocumentTypeAcl() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String documentTypeId = "123";
        int version = 1;
        Integer documentTypeVersion = new Integer(version);
        // Moçked response
        AccessControlList result = factory.manufacturePojo(AccessControlList.class);
        AccessControlList result2 = factory.manufacturePojo(AccessControlList.class);
        // Mockito expectations
        when(aclService.getAclListByClassId(documentTypeId, version, true)).thenReturn(result);
        when(aclService.getAclListByClassId(documentTypeId, version, false)).thenReturn(result2);

        // Execute the method being tested
        ResponseEntity<RestResponse<Acl>> finalResult = documentTypesController.getDocumentTypeAcl(documentTypeId,
                documentTypeVersion, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(aclService).getAclListByClassId(documentTypeId, version, true);
        verify(aclService).getAclListByClassId(documentTypeId, version, false);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Acl> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(2, body.getResult().size());
        assertEquals(result.getName(), body.getResult().get(0).getName());
    }

    @Test
    public void testAssignDocumentTypeAcl() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String documentTypeId = "123";
        int version = 1;
        Integer documentTypeVersion = new Integer(version);
        Acl inputAcl = factory.manufacturePojo(Acl.class);
        // Moçked response
        AccessControlList result = factory.manufacturePojo(AccessControlList.class);
        // Mockito expectations
        when(aclService.assignAclToClassId(inputAcl.getAclId(), documentTypeId, version, inputAcl.getIsInstanceValue()))
                .thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Acl>> finalResult = documentTypesController.assignDocumentTypeAcl(documentTypeId,
                documentTypeVersion, inputAcl, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(aclService).assignAclToClassId(inputAcl.getAclId(), documentTypeId, version, inputAcl.getIsInstanceValue());
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Acl> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getName(), body.getResult().get(0).getName());
    }

}
