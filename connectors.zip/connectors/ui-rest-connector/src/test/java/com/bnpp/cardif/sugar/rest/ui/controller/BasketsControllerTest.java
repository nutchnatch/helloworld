package com.bnpp.cardif.sugar.rest.ui.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import com.bnpp.cardif.sugar.frontend.services.AclService;
import com.bnpp.cardif.sugar.rest.ui.model.Acl;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.BasketsService;
import com.bnpp.cardif.sugar.frontend.services.TasksService;
import com.bnpp.cardif.sugar.frontend.services.model.PagingList;
import com.bnpp.cardif.sugar.rest.ui.model.Basket;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpp.cardif.sugar.rest.ui.model.Task;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * 
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class BasketsControllerTest extends FrontendControllerTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private BasketsService basketsService;

    @Mock
    private TasksService tasksService;

    @InjectMocks
    private BasketsController basketsController = new BasketsController();

    @Mock
    private AclService aclService;
    
    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testGetBasketById() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String basketId = "123";

        AccessControlList accessControlList = factory.manufacturePojo(AccessControlList.class);
        // Moçked response
        com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket result = factory
                .manufacturePojo(com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket.class);
        // Mockito expectations
        when(basketsService.getBasketByID(basketId)).thenReturn(result);
        when(aclService.getAclListByBasketId(basketId)).thenReturn(accessControlList);

        // Execute the method being tested
        ResponseEntity<RestResponse<Basket>> finalResult = basketsController.getBasketById(basketId, xCardifConsumer,
                xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(basketsService).getBasketByID(basketId);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Basket> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getSymbolicName(), body.getResult().get(0).getSymbolicName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetTaskListFromBasket() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String basketId = "123";
        Integer pageNumber = 1;
        Integer pageSize = 10;
        // Moçked response
        PagingList<com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task> result = factory
                .manufacturePojo(PagingList.class, com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task.class);
        // Mockito expectations
        when(tasksService.getTaskListByBasket(basketId, 0, pageSize)).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Task>> finalResult = basketsController.getTaskListFromBasket(basketId, pageNumber,
                pageSize, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(tasksService).getTaskListByBasket(basketId, 0, pageSize);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Task> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(result.getItemList().size(), body.getResult().size());
        assertEquals(result.getItemList().get(0).getName(), body.getResult().get(0).getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetBaskets() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        // Moçked response
        List<com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket> result = factory
                .manufacturePojo(List.class, com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket.class);
        // Mockito expectations
        when(basketsService.getAllBasketList()).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Basket>> finalResult = basketsController.getBaskets(xCardifConsumer,
                xCardifRequestId, xCardifExtReqId);
        // Validation
        verify(basketsService).getAllBasketList();
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Basket> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(result.size(), body.getResult().size());
        assertEquals(result.get(0).getSymbolicName(), body.getResult().get(0).getSymbolicName());
    }

    @Test
    public void testCreateBasket() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        Basket inputBasket = factory.manufacturePojo(Basket.class);
        // Moçked response
        com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket result = factory
                .manufacturePojo(com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket.class);
        // Mockito expectations
        when(basketsService.createBasket(any(com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket.class)))
                .thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Basket>> finalResult = basketsController.createBasket(inputBasket, xCardifConsumer,
                xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(basketsService)
                .createBasket(any(com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Basket> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getSymbolicName(), body.getResult().get(0).getSymbolicName());
    }

    @Test
    public void testUpdateBasket() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String basketId = "123";
        Basket inputBasket = factory.manufacturePojo(Basket.class);
        // Moçked response
        com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket result = factory
                .manufacturePojo(com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket.class);
        // Mockito expectations
        when(basketsService.updateBasket(any(com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket.class)))
                .thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Basket>> finalResult = basketsController.updateBasket(basketId, inputBasket,
                xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(basketsService)
                .updateBasket(any(com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Basket> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getSymbolicName(), body.getResult().get(0).getSymbolicName());
    }

    @Test
    public void testDeleteBasket() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String basketId = "123";
        // Moçked response
        
        // Mockito expectations

        // Execute the method being tested
        ResponseEntity<RestResponse<String>> finalResult = basketsController.deleteBasket(basketId, xCardifConsumer,
                xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(basketsService).deleteBasket(basketId);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<String> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(0, body.getResult().size());
    }

    @Test
    public void testAssignBasketAcl() throws TechnicalException, FunctionalException {

        String basketId = "34343-45454";
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        Acl acl = factory.manufacturePojo(Acl.class);
        ResponseEntity<RestResponse<Acl>> response = basketsController.assignBasketAcl(basketId, acl, xCardifConsumer, xCardifRequestId, xCardifExtReqId);
        verify(aclService).assignAclToBasketId(any(String.class), any(String.class));

        assertNotNull(response);
        RestResponse<Acl> body = response.getBody();
        assertNotNull(body);
        assertTrue(body.getStatus());
        assertNull(body.getError());
        assertNotNull(body.getResult());

    }
}
