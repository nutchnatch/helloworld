package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.bnpp.cardif.sugar.rest.ui.model.Tag;
import com.bnpp.cardif.sugar.rest.ui.model.Task;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

public class TaskConverterTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void testConvertTask() {

        com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task obj1 = factory
                .manufacturePojo(com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task.class);
        com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task obj3 = new com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task();

        Task result = TaskConverter.convert(obj1);
        assertNotNull(result);
        assertNotNull(result.getBasketId());
        assertNotNull(obj1.getBasketId());
        assertTrue(result.getBasketId().equals(obj1.getBasketId().getValue()));

        Task result3 = TaskConverter.convert(obj3);
        assertNotNull(result3);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testConvertListOfTask() {
        
        List<com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task> obj1 = factory
                .manufacturePojo(List.class, com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task.class);
        List<com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task> obj3 = new ArrayList<>();
        
        List<Task> result = TaskConverter.convert(obj1);
        assertNotNull(result);
        assertTrue(result.size() == obj1.size());

        List<Task> result3 = TaskConverter.convert(obj3);
        assertNotNull(result3);
    }

}
