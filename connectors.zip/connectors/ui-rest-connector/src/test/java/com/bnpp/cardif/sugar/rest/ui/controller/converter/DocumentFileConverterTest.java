package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import java.io.IOException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

import static org.junit.Assert.*;

public class DocumentFileConverterTest {
    
    private PodamFactory factory = new PodamFactoryImpl();

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void testConvertMultipartFileString() throws IOException {
        
        MultipartFile obj1WithoutName = factory.manufacturePojo(MockMultipartFile.class);
        MultipartFile obj2 = factory.manufacturePojoWithFullData(MockMultipartFile.class);

        DocumentFile result = DocumentFileConverter.convert(obj1WithoutName, "Syldavia");
        assertNotNull(result);
        assertNotNull(result.getName());
        // not equals since the name is empty so we will have a default name set
        assertNotEquals(obj1WithoutName.getOriginalFilename(), result.getName());
        
        DocumentFile result2 = DocumentFileConverter.convert(obj2, "Syldavia");
        assertNotNull(result2);
        assertNotNull(result2.getName());
        assertEquals(obj2.getOriginalFilename(), result2.getName());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testConvertListOfMultipartFileString() throws IOException {
        
        List<MultipartFile> obj1 = factory.manufacturePojo(List.class, MockMultipartFile.class);
        List<MultipartFile> obj2 = factory.manufacturePojoWithFullData(List.class, MockMultipartFile.class);
        
        List<DocumentFile> result = DocumentFileConverter.convert(obj1, "Syldavia");
        assertNotNull(result);
        assertTrue(result.size() == obj1.size());
        
        List<DocumentFile> result2 = DocumentFileConverter.convert(obj2, "Syldavia");
        assertNotNull(result2);
        assertTrue(result2.size() == obj2.size());
    }

}
