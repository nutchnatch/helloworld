package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import static org.junit.Assert.*;

import java.util.List;
import java.util.Optional;

import org.junit.Test;

import com.bnpp.cardif.sugar.rest.ui.model.Acl;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

public class AclConverterTest {
    
    private PodamFactory factory = new PodamFactoryImpl();

    @Test
    public void testConvertAccessControlListAccessControlList() throws InstantiationException, IllegalAccessException {
        
        AccessControlList obj1 = factory.manufacturePojo(AccessControlList.class);
        AccessControlList obj2 = factory.manufacturePojoWithFullData(AccessControlList.class);
        AccessControlList obj3 = AccessControlList.class.newInstance();
        
        List<Acl> result = AclConverter.convert(Optional.ofNullable(obj1), Optional.ofNullable(obj2));
        assertNotNull(result);
        assertTrue(result.size() == 2);
        List<Acl> result2 = AclConverter.convert(Optional.ofNullable(obj2), Optional.ofNullable(obj3));
        assertNotNull(result2);
        assertTrue(result2.size() == 2);
    }

    @Test
    public void testConvertAccessControlListBoolean() throws InstantiationException, IllegalAccessException {
        
        AccessControlList obj1 = factory.manufacturePojo(AccessControlList.class);
        AccessControlList obj2 = factory.manufacturePojoWithFullData(AccessControlList.class);
        AccessControlList obj3 = AccessControlList.class.newInstance();
        
        Acl result = AclConverter.convert(obj1, true);
        assertNotNull(result);
        assertNotNull(result.getName());
        assertTrue(result.getName().equals(obj1.getName()));
        
        Acl result2 = AclConverter.convert(obj2, false);
        assertNotNull(result2);
        assertNotNull(result2.getName());
        assertTrue(result2.getName().equals(obj2.getName()));
        
        Acl result3 = AclConverter.convert(obj3, true);
        assertNotNull(result3);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testConvertListOfAccessControlList() {
        
        List<AccessControlList> obj1 = factory.manufacturePojo(List.class, AccessControlList.class);
        List<AccessControlList> obj2 = factory.manufacturePojoWithFullData(List.class, AccessControlList.class);
        
        List<Acl> result = AclConverter.convert(obj1);
        assertNotNull(result);
        assertTrue(result.size() != 0);
        
        List<Acl> result2 = AclConverter.convert(obj2);
        assertNotNull(result2);
        assertTrue(result2.size() != 0);
    }

}
