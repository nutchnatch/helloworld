package com.bnpp.cardif.sugar.rest.ui.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.AclService;
import com.bnpp.cardif.sugar.frontend.services.BusinessScopeService;
import com.bnpp.cardif.sugar.rest.ui.model.Acl;
import com.bnpp.cardif.sugar.rest.ui.model.BusinessScope;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * 
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class BusinessScopesControllerTest extends FrontendControllerTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private BusinessScopeService businessScopeService;

    @Mock
    private AclService aclService;

    @InjectMocks
    private BusinessScopesController businessScopesController = new BusinessScopesController();

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testGetBusinessScope() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        // Moçked response
        com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope result = factory
                .manufacturePojo(com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope.class);
        // Mockito expectations
        when(businessScopeService.getBusinessScope()).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<BusinessScope>> finalResult = businessScopesController
                .getBusinessScope(xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(businessScopeService).getBusinessScope();
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<BusinessScope> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getSymbolicName(), body.getResult().get(0).getSymbolicName());
    }

    @Test
    public void testUpdateBusinessScope() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String businessScopeId = "123";
        BusinessScope inputBusinessScope = factory.manufacturePojo(BusinessScope.class);
        // Moçked response
        com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope result = factory
                .manufacturePojo(com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope.class);
        // Mockito expectations
        when(businessScopeService.updateBusinessScope(
                any(com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope.class)))
                        .thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<BusinessScope>> finalResult = businessScopesController.updateBusinessScope(
                businessScopeId, inputBusinessScope, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(businessScopeService).updateBusinessScope(
                any(com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<BusinessScope> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getSymbolicName(), body.getResult().get(0).getSymbolicName());
    }

    @Test
    public void testUpdateRuleFile() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String businessScopeId = "123";
        MultipartFile file = factory.manufacturePojo(MockMultipartFile.class);
        // Moçked response
        com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope result = factory
                .manufacturePojo(com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope.class);
        // Mockito expectations
        when(businessScopeService.updateRuleFile(any(DocumentFile.class))).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<BusinessScope>> finalResult = businessScopesController
                .updateRuleFile(file, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(businessScopeService).updateRuleFile(any(DocumentFile.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<BusinessScope> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getSymbolicName(), body.getResult().get(0).getSymbolicName());
    }

    @Test
    public void testGetBusinessScopeAcl() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String businessScopeId = "123";
        // Moçked response
        AccessControlList result = factory.manufacturePojo(AccessControlList.class);
        // Mockito expectations
        when(aclService.getDefaultAclByBuisnessScope()).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Acl>> finalResult = businessScopesController.getBusinessScopeAcl(businessScopeId,
                xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(aclService).getDefaultAclByBuisnessScope();
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Acl> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getName(), body.getResult().get(0).getName());
    }

    @Test
    public void testSetBusinessScopeAcl() throws TechnicalException, FunctionalException {

        AccessControlList accessControlList = factory.manufacturePojo(AccessControlList.class);
        Acl acl = factory.manufacturePojo(Acl.class);
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String businessScopeId = "123";
        String businessId = "5454-779798";
        when(aclService.assignBusinessScopeACL(any(String.class), any(String.class))).thenReturn(accessControlList);
        ResponseEntity<RestResponse<Acl>> response = businessScopesController.assignBusinessScopeAcl(businessScopeId, acl, xCardifConsumer, xCardifRequestId, xCardifExtReqId);
        verify(aclService).assignBusinessScopeACL(any(String.class), any(String.class));

        assertNotNull(response);
        RestResponse<Acl> body = response.getBody();
        assertNotNull(body);
        assertTrue(body.getStatus());
        assertNull(body.getError());
        assertNotNull(body.getResult());
        assertEquals(accessControlList.getName(), body.getResult().get(0).getName());
    }
}
