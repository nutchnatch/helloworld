package com.bnpp.cardif.sugar.rest.ui.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import com.bnpp.cardif.sugar.frontend.services.*;
import com.bnpp.cardif.sugar.rest.ui.model.*;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.BasketRatio;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.DocumentStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.EnvelopeFlows;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.FolderStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.Summary;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * 
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ReportingControllerTest extends FrontendControllerTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private ReportingService reportingService;
    @Mock
    private BasketsService basketsService;
    @Mock
    private DocumentTypeService documentTypeService;
    @Mock
    private FolderTypeService folderTypeService;

    @InjectMocks
    private ReportingController reportingController = new ReportingController();

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetBasketReporting() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        LocalDate startDate = LocalDate.now();
        LocalDate endDate = LocalDate.now();
        // Moçked response
        List<BasketRatio> result = factory.manufacturePojo(List.class, BasketRatio.class);
        // Mockito expectations
        when(reportingService.getBasketRatioIndicators(any(String.class), any(String.class))).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<BasketReporting>> finalResult = reportingController.getBasketReporting(null, startDate,
                endDate, false);

        // Validation
        verify(reportingService).getBasketRatioIndicators(any(String.class), any(String.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<BasketReporting> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content

        result.sort((o1, o2) -> Long.compare(o2.getNumberOfOpened(), o1.getNumberOfOpened()));
        assertNotNull(body.getResult());
        assertEquals(result.size(), body.getResult().size());
        assertEquals(result.get(0).getBasketId().getValue(), body.getResult().get(0).getBasketId());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetDocumentReporting() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        LocalDate startDate = LocalDate.now();
        LocalDate endDate = LocalDate.now();
        // Moçked response
        List<DocumentStock> result = factory.manufacturePojo(List.class, DocumentStock.class);
        // Mockito expectations
        when(reportingService.getDocumentStockIndicators(any(String.class), any(String.class))).thenReturn(result);
        when(documentTypeService.getAllDocumentTypeWithInactives()).thenReturn(result.stream().map(envelopeFlow -> {
            DocumentClass documentClass = new DocumentClass();
            documentClass.setClassId(envelopeFlow.getClassId());
            return documentClass;
        }).collect(Collectors.toList()));
        // Execute the method being tested
        ResponseEntity<RestResponse<DocumentReporting>> finalResult = reportingController
                .getDocumentReporting(null, startDate, endDate, false);

        // Validation
        verify(reportingService).getDocumentStockIndicators(any(String.class), any(String.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<DocumentReporting> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        result.sort((o1, o2) -> Long.compare(o2.getNumberOfDocuments(), o1.getNumberOfDocuments()));
        assertEquals(result.size(), body.getResult().size());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetEnvelopeReporting() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        LocalDate startDate = LocalDate.now();
        LocalDate endDate = LocalDate.now();
        // Moçked response
        List<EnvelopeFlows> result = factory.manufacturePojo(List.class, EnvelopeFlows.class);
        // Mockito expectations
        when(reportingService.getEnvelopeFlowsIndicators(any(String.class), any(String.class))).thenReturn(result);
        when(documentTypeService.getAllEnvelopeTypeWithInactive()).thenReturn(result.stream().map(envelopeFlow -> {
            DocumentClass documentClass = new DocumentClass();
            documentClass.setClassId(envelopeFlow.getClassId());
            return documentClass;
        }).collect(Collectors.toList()));
        // Execute the method being tested
        ResponseEntity<RestResponse<EnvelopeReporting>> finalResult = reportingController
                .getEnvelopeReporting(null, startDate, endDate, false);

        // Validation
        verify(reportingService).getEnvelopeFlowsIndicators(any(String.class), any(String.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<EnvelopeReporting> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        result.sort((o1, o2) -> Long.compare(o2.getNumberOfEnvelopes(), o1.getNumberOfEnvelopes()));
        assertEquals(result.size(), body.getResult().size());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetFolderReporting() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        LocalDate startDate = LocalDate.now();
        LocalDate endDate = LocalDate.now();
        // Moçked response
        List<FolderStock> result = factory.manufacturePojo(List.class, FolderStock.class);
        // Mockito expectations
        when(reportingService.getFolderStockIndicators(any(String.class), any(String.class))).thenReturn(result);
        when(folderTypeService.getAllFolderTypeWithInactive()).thenReturn(result.stream().map(folderStock -> {
            FolderClass folderClass = new FolderClass();
            folderClass.setClassId(folderStock.getClassId());
            return folderClass;
        }).collect(Collectors.toList()));

        // Execute the method being tested
        ResponseEntity<RestResponse<FolderReporting>> finalResult = reportingController.getFolderReporting(null, startDate,
                endDate, false);

        // Validation
        verify(reportingService).getFolderStockIndicators(any(String.class), any(String.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<FolderReporting> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        result.sort((o1, o2) -> Long.compare(o2.getNumberOfFolders(), o1.getNumberOfFolders()));
        assertEquals(result.size(), body.getResult().size());
    }

    @Test
    public void testGetReportingSummary() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        // Moçked response
        Summary result = factory.manufacturePojo(Summary.class);
        // Mockito expectations
        when(reportingService.getReportingSummary()).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<ReportingSummary>> finalResult = reportingController
                .getReportingSummary(xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(reportingService).getReportingSummary();
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<ReportingSummary> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getNumbereOfEnvelopes(), body.getResult().get(0).getNumberOfEnvelopes());
    }

}
