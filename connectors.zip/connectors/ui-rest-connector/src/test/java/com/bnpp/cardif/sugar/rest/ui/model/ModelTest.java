package com.bnpp.cardif.sugar.rest.ui.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Set;
import java.util.regex.Pattern;

import org.junit.Test;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.RegexPatternTypeFilter;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

public class ModelTest {
    
    private PodamFactory factory = new PodamFactoryImpl();
    
    @Test
    public void allBeansTest() throws Exception {

        //get all the bean from the package com.bnppa.sesame.services.internal.model.v2
        ClassPathScanningCandidateComponentProvider provider = new ClassPathScanningCandidateComponentProvider(false);
        provider.addIncludeFilter(new RegexPatternTypeFilter(Pattern.compile(".*")));
        provider.addExcludeFilter(new RegexPatternTypeFilter(Pattern.compile(".*Test.*")));
        provider.addExcludeFilter(new RegexPatternTypeFilter(Pattern.compile(".*Enum.*")));
        provider.addExcludeFilter(new RegexPatternTypeFilter(Pattern.compile(".*OrderField.*")));
        provider.addExcludeFilter(new RegexPatternTypeFilter(Pattern.compile(".*SearchOperator.*")));
        provider.addExcludeFilter(new RegexPatternTypeFilter(Pattern.compile(".*TagType.*")));
        provider.addExcludeFilter(new RegexPatternTypeFilter(Pattern.compile(".*RestResponse.*")));
        provider.addExcludeFilter(new RegexPatternTypeFilter(Pattern.compile(".*TrackReport.*")));
        provider.addExcludeFilter(new RegexPatternTypeFilter(Pattern.compile(".*ReportBasket.*")));
        provider.addExcludeFilter(new RegexPatternTypeFilter(Pattern.compile(".*ReportEnvelope.*")));
        provider.addExcludeFilter(new RegexPatternTypeFilter(Pattern.compile(".*ReportDocument.*")));
        provider.addExcludeFilter(new RegexPatternTypeFilter(Pattern.compile(".*ReportFolder.*")));
        Set<BeanDefinition> classes = provider.findCandidateComponents("com.bnpp.cardif.sugar.rest.ui.model");
        //for each bean launch a test
        for (BeanDefinition bd : classes) {
            testModel(bd.getBeanClassName());
        }
    }

    @SuppressWarnings("unchecked")
    private void testModel(String className)
            throws ClassNotFoundException, InvocationTargetException, IllegalAccessException, InstantiationException {
        
        System.out.println("testing class : "+className);
        Class s = Thread.currentThread().getContextClassLoader().loadClass(className);
        long start = System.currentTimeMillis();
        Object obj1 = factory.manufacturePojo(s);
        Object obj2 = factory.manufacturePojoWithFullData(s);
        Object obj3 = s.newInstance();

        //test equals
        assertNotNull(obj1.equals(obj2));
        assertTrue(obj1.equals(obj1));
        assertFalse(obj1.equals(null));
        assertFalse(obj1.equals(""));
        assertFalse(obj3.equals(""));

        //test hashcode
        assertNotNull(obj1.hashCode());
        assertNotNull(obj3.hashCode());

        assertNotNull(obj1.toString());
        assertNotNull(obj3.toString());
        
        if (obj1 instanceof Comparable) {
            assertNotNull(((Comparable)obj1).compareTo(obj2));

            try {
                ((Comparable)obj1).compareTo("sdf");
                fail("Compare " + className + " with a String must thrown a ClassCastException.");
            } catch (ClassCastException e) {
                //ok
            }
            try {
                assertNotNull(((Comparable) obj1).compareTo(null));
                fail("Compare " + className + " with null must thrown a NullPointerException.");
            } catch (NullPointerException e) {
                //ok
            }
        }

        Method[] methods = s.getDeclaredMethods();
        for (int i = 0; i < methods.length; i++) {
            Method method = methods[i];

            if (Modifier.isPublic(method.getModifiers()) && method.getParameterTypes().length == 0) {
                // System.out.println(method.toString());
                method.invoke(obj1,null);
            }
        }
        
    }

}
