package com.bnpp.cardif.sugar.rest.ui.controller;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import javax.servlet.http.HttpSession;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.ResourcesService;
import com.bnpp.cardif.sugar.rest.ui.model.CurrentUser;
import com.bnpp.cardif.sugar.rest.ui.model.FolderType;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpp.cardif.sugar.security.AuthenticatedUser;
import com.bnppa.sesame.services.standard.proxy.InvalidTokenException;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * 
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ResourcesControllerTest extends FrontendControllerTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private ResourcesService resourcesService;

    @Mock
    private HttpSession httpSession;

    @InjectMocks
    private ResourcesController resourcesController = new ResourcesController();

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testGetCurrentUser() throws TechnicalException {

        // input variable

        // Moçked response
        AuthenticatedUser result = factory.manufacturePojo(AuthenticatedUser.class);
        // Mockito expectations
        when(resourcesService.getUser()).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<CurrentUser>> finalResult = resourcesController.getCurrentUser();

        // Validation
        verify(resourcesService).getUser();
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<CurrentUser> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getLastName(), body.getResult().get(0).getLastName());
    }

    @Test
    public void testLogout() throws InvalidTokenException, com.bnppa.sesame.services.standard.proxy.TechnicalException {

        // input variable

        // Moçked response
        
        // Mockito expectations
        

        // Execute the method being tested
        ResponseEntity<RestResponse<String>> finalResult = resourcesController.logout();

        // Validation
        verify(resourcesService).logout(any(HttpSession.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<String> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(0, body.getResult().size());

    }

}
