package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.bnpp.cardif.sugar.rest.ui.model.BasketReporting;
import com.bnpp.cardif.sugar.rest.ui.model.DocumentReporting;
import com.bnpp.cardif.sugar.rest.ui.model.EnvelopeReporting;
import com.bnpp.cardif.sugar.rest.ui.model.FolderReporting;
import com.bnpp.cardif.sugar.rest.ui.model.ReportingSummary;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.BasketRatio;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.DocumentStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.EnvelopeFlows;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.FolderStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.Summary;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

public class ReportingConverterTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Before
    public void setUp() throws Exception {
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testConvertListOfBasketRatio() {

        List<BasketRatio> obj1 = factory.manufacturePojo(List.class, BasketRatio.class);
        List<BasketRatio> obj2 = factory.manufacturePojoWithFullData(List.class, BasketRatio.class);
        List<BasketRatio> obj3 = new ArrayList<>();

        List<BasketReporting> result = ReportingConverter.convert(obj1);
        assertNotNull(result);
        assertTrue(result.size() == obj1.size());

        List<BasketReporting> result2 = ReportingConverter.convert(obj2);
        assertNotNull(result2);
        assertTrue(result2.size() == obj2.size());

        List<BasketReporting> result3 = ReportingConverter.convert(obj3);
        assertNotNull(result3);
        assertTrue(result3.size() == obj3.size());
    }

    @Test
    public void testConvertBasketRatio() {
        
        BasketRatio obj1 = factory.manufacturePojo(BasketRatio.class);
        BasketRatio obj2 = factory.manufacturePojoWithFullData(BasketRatio.class);
        BasketRatio obj3 = new BasketRatio();
        
        BasketReporting result = ReportingConverter.convert(obj1);
        assertNotNull(result);
        assertNotNull(result.getBasketId());
        assertNotNull(obj1.getBasketId());
        assertTrue(result.getBasketId().equals(obj1.getBasketId().getValue()));
        
        BasketReporting result2 = ReportingConverter.convert(obj2);
        assertNotNull(result2);
        assertNotNull(result2.getBasketId());
        assertNotNull(obj2.getBasketId());
        assertTrue(result2.getBasketId().equals(obj2.getBasketId().getValue()));
        
        BasketReporting result3 = ReportingConverter.convert(obj3);
        assertNotNull(result3);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testConvertDocListOfDocumentStock() {
        
        List<DocumentStock> obj1 = factory.manufacturePojo(List.class, DocumentStock.class);
        List<DocumentStock> obj2 = factory.manufacturePojoWithFullData(List.class, DocumentStock.class);
        List<DocumentStock> obj3 = new ArrayList<>();
        
        List<DocumentReporting> result = ReportingConverter.convertDoc(obj1);
        assertNotNull(result);
        assertTrue(result.size() == obj1.size());
        
        List<DocumentReporting> result2 = ReportingConverter.convertDoc(obj2);
        assertNotNull(result2);
        assertTrue(result2.size() == obj2.size());
        
        List<DocumentReporting> result3 = ReportingConverter.convertDoc(obj3);
        assertNotNull(result3);
        assertTrue(result3.size() == obj3.size());
    }

    @Test
    public void testConvertDocDocumentStock() {
        
        DocumentStock obj1 = factory.manufacturePojo(DocumentStock.class);
        DocumentStock obj2 = factory.manufacturePojoWithFullData(DocumentStock.class);
        DocumentStock obj3 = new DocumentStock();
        
        DocumentReporting result = ReportingConverter.convertDoc(obj1);
        assertNotNull(result);
        assertNotNull(result.getClassId());
        assertNotNull(obj1.getClassId());
        assertTrue(result.getClassId().equals(obj1.getClassId().getValue()));
        
        DocumentReporting result2 = ReportingConverter.convertDoc(obj2);
        assertNotNull(result2);
        assertNotNull(result2.getClassId());
        assertNotNull(obj2.getClassId());
        assertTrue(result2.getClassId().equals(obj2.getClassId().getValue()));
        
        DocumentReporting result3 = ReportingConverter.convertDoc(obj3);
        assertNotNull(result3);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testConvertEnvListOfEnvelopeFlows() {
        
        List<EnvelopeFlows> obj1 = factory.manufacturePojo(List.class, EnvelopeFlows.class);
        List<EnvelopeFlows> obj2 = factory.manufacturePojoWithFullData(List.class, EnvelopeFlows.class);
        List<EnvelopeFlows> obj3 = new ArrayList<>();
        
        List<EnvelopeReporting> result = ReportingConverter.convertEnv(obj1);
        assertNotNull(result);
        assertTrue(result.size() == obj1.size());
        
        List<EnvelopeReporting> result2 = ReportingConverter.convertEnv(obj2);
        assertNotNull(result2);
        assertTrue(result2.size() == obj2.size());
        
        List<EnvelopeReporting> result3 = ReportingConverter.convertEnv(obj3);
        assertNotNull(result3);
        assertTrue(result3.size() == obj3.size());
    }

    @Test
    public void testConvertEnvEnvelopeFlows() {
        
        EnvelopeFlows obj1 = factory.manufacturePojo(EnvelopeFlows.class);
        EnvelopeFlows obj2 = factory.manufacturePojoWithFullData(EnvelopeFlows.class);
        EnvelopeFlows obj3 = new EnvelopeFlows();
        
        EnvelopeReporting result = ReportingConverter.convertEnv(obj1);
        assertNotNull(result);
        assertNotNull(result.getClassId());
        assertNotNull(obj1.getClassId());
        assertTrue(result.getClassId().equals(obj1.getClassId().getValue()));
        
        EnvelopeReporting result2 = ReportingConverter.convertEnv(obj2);
        assertNotNull(result2);
        assertNotNull(result2.getClassId());
        assertNotNull(obj2.getClassId());
        assertTrue(result2.getClassId().equals(obj2.getClassId().getValue()));
        
        EnvelopeReporting result3 = ReportingConverter.convertEnv(obj3);
        assertNotNull(result3);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testConvertFolderListOfFolderStock() {
        
        List<FolderStock> obj1 = factory.manufacturePojo(List.class, FolderStock.class);
        List<FolderStock> obj2 = factory.manufacturePojoWithFullData(List.class, FolderStock.class);
        List<FolderStock> obj3 = new ArrayList<>();
        
        List<FolderReporting> result = ReportingConverter.convertFolder(obj1);
        assertNotNull(result);
        assertTrue(result.size() == obj1.size());
        
        List<FolderReporting> result2 = ReportingConverter.convertFolder(obj2);
        assertNotNull(result2);
        assertTrue(result2.size() == obj2.size());
        
        List<FolderReporting> result3 = ReportingConverter.convertFolder(obj3);
        assertNotNull(result3);
        assertTrue(result3.size() == obj3.size());
    }

    @Test
    public void testConvertFolderFolderStock() {
        
        FolderStock obj1 = factory.manufacturePojo(FolderStock.class);
        FolderStock obj2 = factory.manufacturePojoWithFullData(FolderStock.class);
        FolderStock obj3 = new FolderStock();
        
        FolderReporting result = ReportingConverter.convertFolder(obj1);
        assertNotNull(result);
        assertNotNull(result.getClassId());
        assertNotNull(obj1.getClassId());
        assertTrue(result.getClassId().equals(obj1.getClassId().getValue()));
        
        FolderReporting result2 = ReportingConverter.convertFolder(obj2);
        assertNotNull(result2);
        assertNotNull(result2.getClassId());
        assertNotNull(obj2.getClassId());
        assertTrue(result2.getClassId().equals(obj2.getClassId().getValue()));
        
        FolderReporting result3 = ReportingConverter.convertFolder(obj3);
        assertNotNull(result3);
    }

    @Test
    public void testConvertSummary() {
        
        Summary obj1 = factory.manufacturePojo(Summary.class);
        Summary obj2 = factory.manufacturePojoWithFullData(Summary.class);
        Summary obj3 = new Summary();
        
        ReportingSummary result = ReportingConverter.convertSummary(obj1);
        assertNotNull(result);
        assertNotNull(result.getNumberOfDocuments());
        assertNotNull(obj1.getNumberOfDocuments());
        assertTrue(result.getNumberOfDocuments() == obj1.getNumberOfDocuments());
        
        ReportingSummary result2 = ReportingConverter.convertSummary(obj2);
        assertNotNull(result2);
        assertNotNull(result2.getNumberOfDocuments());
        assertNotNull(obj2.getNumberOfDocuments());
        assertTrue(result2.getNumberOfDocuments() == obj2.getNumberOfDocuments());
        
        ReportingSummary result3 = ReportingConverter.convertSummary(obj3);
        assertNotNull(result3);
    }

}
