package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.bnpp.cardif.sugar.rest.ui.model.DocumentType;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

public class DocumentTypeConverterTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void testConvertDocumentClass() {

        DocumentClass obj1 = factory.manufacturePojo(DocumentClass.class);
        DocumentClass obj3 = new DocumentClass();

        DocumentType result = DocumentTypeConverter.convert(obj1);
        assertNotNull(result);
        assertNotNull(result.getName());
        assertTrue(result.getName().equals(obj1.getLongLabel()));

        DocumentType result3 = DocumentTypeConverter.convert(obj3);
        assertNotNull(result3);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testConvertListOfDocumentClass() {

        List<DocumentClass> obj1 = factory.manufacturePojo(List.class, DocumentClass.class);
        List<DocumentClass> obj3 = new ArrayList<>();

        List<DocumentType> result = DocumentTypeConverter.convert(obj1);
        assertNotNull(result);
        assertTrue(result.size() == obj1.size());

        List<DocumentType> result3 = DocumentTypeConverter.convert(obj3);
        assertNotNull(result3);
    }

    @Test
    public void testConvertDocumentTypeString() {

        DocumentType obj1 = factory.manufacturePojo(DocumentType.class);
        DocumentType obj2 = factory.manufacturePojoWithFullData(DocumentType.class);
        DocumentType obj3 = new DocumentType();

        DocumentClass result = DocumentTypeConverter.convert(obj1, "Syldavia");
        assertNotNull(result);
        assertNotNull(result.getLongLabel());
        assertTrue(result.getLongLabel().equals(obj1.getName()));

        DocumentClass result2 = DocumentTypeConverter.convert(obj2, "Syldavia");
        assertNotNull(result2);
        assertNotNull(result2.getLongLabel());
        assertTrue(result2.getLongLabel().equals(obj2.getName()));

        DocumentClass result3 = DocumentTypeConverter.convert(obj3, "Syldavia");
        assertNotNull(result3);
    }

}
