package com.bnpp.cardif.sugar.rest.ui.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.AclService;
import com.bnpp.cardif.sugar.rest.ui.model.Acl;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * 
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class AclControllerTest extends FrontendControllerTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    private AclService aclService;

    @InjectMocks
    private AclController aclController = new AclController();

    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetAllAcl() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        // Moçked response
        List<AccessControlList> result = factory.manufacturePojo(List.class, AccessControlList.class);
        // Mockito expectations
        when(aclService.getAllAclList()).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Acl>> finalResult = aclController.getAllAcl(xCardifConsumer, xCardifRequestId,
                xCardifExtReqId);

        // Validation
        verify(aclService).getAllAclList();
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Acl> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(result.size(), body.getResult().size());
        assertEquals(result.get(0).getName(), body.getResult().get(0).getName());
    }

}
