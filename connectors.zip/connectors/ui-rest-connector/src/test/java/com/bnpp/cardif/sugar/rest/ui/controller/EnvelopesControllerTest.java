package com.bnpp.cardif.sugar.rest.ui.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.BusinessScopeService;
import com.bnpp.cardif.sugar.frontend.services.DocumentFilesService;
import com.bnpp.cardif.sugar.frontend.services.DocumentService;
import com.bnpp.cardif.sugar.frontend.services.DocumentTypeService;
import com.bnpp.cardif.sugar.frontend.services.model.PagingList;
import com.bnpp.cardif.sugar.rest.ui.model.Document;
import com.bnpp.cardif.sugar.rest.ui.model.Envelope;
import com.bnpp.cardif.sugar.rest.ui.model.EnvelopeCreationResult;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;

import uk.co.jemos.podam.api.DataProviderStrategy;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * 
 * @author 831743
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class EnvelopesControllerTest extends FrontendControllerTest {

    private PodamFactory factory = new PodamFactoryImpl();

    @Mock
    DocumentService documentService;

    @Mock
    DocumentTypeService documentTypeService;

    @Mock
    DocumentFilesService documentFilesService;

    @Mock
    BusinessScopeService businessScopeService;

    @InjectMocks
    private EnvelopesController envelopesController = new EnvelopesController();

    @Before
    public void setUp() throws Exception {
        super.setUp();
        DataProviderStrategy strategy = factory.getStrategy();
        strategy.setDefaultNumberOfCollectionElements(2);
    }

    @Test
    public void testGetEnvelopeById() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String envelopeId = "123";
        // Moçked response
        com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document result = factory
                .manufacturePojo(com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document.class);
        // Mockito expectations
        when(documentService.getDocumentWithChildByID(envelopeId)).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Envelope>> finalResult = envelopesController.getEnvelopeById(envelopeId,
                xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentService).getDocumentWithChildByID(envelopeId);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Envelope> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertEquals(result.getData().getDirectionCode(), body.getResult().get(0).getDirection());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetEnvelopes() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String quickSearch = factory.manufacturePojo(String.class);
        String creationDateCriteria = "greater_than|2016-10-27";
        String updateDateCriteria = "less_than|2017-10-27";
        String creatorCriteria = "equals_to|my name";
        String lastModifierCriteria = "starts_with|my";
        String nameCriteria = "contains|doc";
        String validityCriteria = "not_equals_to|VALID";
        String confidentialityCriteria = "equals_to|confdential";
        List<String> envelopeTypeIdsCriteria = factory.manufacturePojo(List.class, String.class);
        List<String> tags = new ArrayList<>();
        tags.add("tagName1|string|ends_with|value1");
        tags.add("tagName2|string|not_equals_to|value2");
        Boolean orderAscending = true;
        String orderField = "creation_date";
        String orderTagName = factory.manufacturePojo(String.class);
        Integer pageNumber = 1;
        Integer pageSize = 20;
        // Moçked response
        PagingList<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> result = factory
                .manufacturePojo(PagingList.class,
                        com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document.class);
        // Mockito expectations
        when(documentService.findEnvelopes(eq(0L), eq(20L), eq(quickSearch), any(List.class), any(OrderClause.class)))
                .thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<Envelope>> finalResult = envelopesController.getEnvelopes(quickSearch,
                creationDateCriteria, updateDateCriteria, creatorCriteria, lastModifierCriteria, nameCriteria,
                validityCriteria, confidentialityCriteria, envelopeTypeIdsCriteria, tags, orderAscending, orderField,
                orderTagName, pageNumber, pageSize, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentService).findEnvelopes(eq(0L), eq(20L), eq(quickSearch), any(List.class),
                any(OrderClause.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Envelope> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(result.getItemList().size(), body.getResult().size());
        assertEquals(result.getItemList().get(0).getData().getDirectionCode(), body.getResult().get(0).getDirection());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testUpdateEnvelope() throws FunctionalException, TechnicalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String envelopeId = "123";
        Envelope envelope = factory.manufacturePojo(Envelope.class);
        // Moçked response
        List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> result = factory.manufacturePojo(
                List.class, com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document.class);
        result.get(0).setCategory(Category.ENVELOPE);
        result.get(1).setCategory(Category.DOCUMENT);
        // Mockito expectations
        when(documentService.reindexDocument(any(List.class))).thenReturn(result);

        // Execute the method being tested
        ResponseEntity<RestResponse<EnvelopeCreationResult>> finalResult = envelopesController
                .updateEnvelope(envelopeId, envelope, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentService).reindexDocument(any(List.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<EnvelopeCreationResult> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertNotNull(body.getResult().get(0).getEnvelopeId());
        assertNotNull(body.getResult().get(0).getDocumentIdList());
        assertEquals(1, body.getResult().get(0).getDocumentIdList().size());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testAddEnvelope() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        List<MultipartFile> fileList = factory.manufacturePojo(List.class, MockMultipartFile.class);
        // Moçked response
        BusinessScope result = factory.manufacturePojo(BusinessScope.class);
        DocumentClass result2 = factory.manufacturePojo(DocumentClass.class);
        DocumentClass result3 = factory.manufacturePojo(DocumentClass.class);
        List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> result4 = factory.manufacturePojo(
                List.class, com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document.class);
        result4.get(0).setCategory(Category.ENVELOPE);
        result4.get(1).setCategory(Category.DOCUMENT);
        // Mockito expectations
        when(businessScopeService.getBusinessScope()).thenReturn(result);
        when(documentService.createEnvelopeWithFile(any(List.class),
                any(com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document.class), any(List.class)))
                        .thenReturn(result4);

        // Execute the method being tested
        ResponseEntity<RestResponse<EnvelopeCreationResult>> finalResult = envelopesController.addEnvelope(fileList,
                xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentService).createEnvelopeWithFile(any(List.class),
                any(com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document.class), any(List.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<EnvelopeCreationResult> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertNotNull(body.getResult().get(0).getEnvelopeId());
        assertNotNull(body.getResult().get(0).getDocumentIdList());
        assertEquals(1, body.getResult().get(0).getDocumentIdList().size());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testAddDocumentsToEnvelope() throws TechnicalException, FunctionalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String envelopeId = "123";
        List<MultipartFile> fileList = factory.manufacturePojo(List.class, MockMultipartFile.class);
        // Moçked response
        List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> result4 = factory.manufacturePojo(
                List.class, com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document.class);
        result4.get(0).setCategory(Category.ENVELOPE);
        result4.get(1).setCategory(Category.DOCUMENT);
        // Mockito expectations
        when(documentService.addFileToEnvelope(any(List.class), eq(envelopeId), any(List.class))).thenReturn(result4);

        // Execute the method being tested
        ResponseEntity<RestResponse<EnvelopeCreationResult>> finalResult = envelopesController
                .addDocumentsToEnvelope(envelopeId, fileList, xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentService).addFileToEnvelope(any(List.class), eq(envelopeId), any(List.class));
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<EnvelopeCreationResult> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(1, body.getResult().size());
        assertNotNull(body.getResult().get(0).getEnvelopeId());
        assertNotNull(body.getResult().get(0).getDocumentIdList());
        assertEquals(1, body.getResult().get(0).getDocumentIdList().size());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetDocumentsFromEnvelope() throws FunctionalException, TechnicalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String envelopeId = "123";
        // Moçked response
        List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> result4 = factory.manufacturePojo(
                List.class, com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document.class);
        result4.get(0).setCategory(Category.DOCUMENT);
        result4.get(1).setCategory(Category.DOCUMENT);
        // Mockito expectations
        when(documentService.getDocumentsFromEnvelope(envelopeId)).thenReturn(result4);

        // Execute the method being tested
        ResponseEntity<RestResponse<Document>> finalResult = envelopesController.getDocumentsFromEnvelope(envelopeId,
                xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentService).getDocumentsFromEnvelope(envelopeId);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<Document> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
        assertEquals(2, body.getResult().size());
        assertEquals(result4.get(0).getData().getConfdntltyLvl(), body.getResult().get(0).getConfidentiality());
    }

    @Test
    public void testDeleteEnvelope() throws FunctionalException, TechnicalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String envelopeId = "123";
        // Moçked response

        // Mockito expectations

        // Execute the method being tested
        ResponseEntity<RestResponse<String>> finalResult = envelopesController.deleteEnvelope(envelopeId,
                xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentService).deleteEnvelope(envelopeId);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<String> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
    }

    @Test
    public void testDeleteDocument() throws FunctionalException, TechnicalException {

        // input variable
        String xCardifConsumer = "SUGAR";
        String xCardifRequestId = "SUGAR-123-456";
        String xCardifExtReqId = "SUGAR-000-123-456";
        String envelopeId = "123";
        String documentId = "456";
        // Moçked response

        // Mockito expectations

        // Execute the method being tested
        ResponseEntity<RestResponse<String>> finalResult = envelopesController.deleteDocument(envelopeId, documentId,
                xCardifConsumer, xCardifRequestId, xCardifExtReqId);

        // Validation
        verify(documentService).deleteDocument(documentId);
        // check a response exist
        assertNotNull(finalResult);
        RestResponse<String> body = finalResult.getBody();
        assertNotNull(body);
        // check no error returned
        assertTrue(body.getStatus());
        assertNull(body.getError());
        // check response content
        assertNotNull(body.getResult());
    }

}
