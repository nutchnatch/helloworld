package com.bnpp.cardif.sugar.rest.ui.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum TagType {

    STRING, TIMESTAMP, BOOLEAN, INTEGER, CHOICELIST, FLOAT;
    
    @JsonCreator
    public static TagType fromString(String name) {
        return TagType.valueOf(name.toUpperCase());
    }
    
    @JsonValue
    public String getName() {
        return name().toLowerCase();
    }
}
