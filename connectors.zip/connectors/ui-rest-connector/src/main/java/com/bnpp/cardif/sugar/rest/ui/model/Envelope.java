package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Contains a set of documents.
 */
@ApiModel(description = "Contains a set of documents.")
public class Envelope implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("id")
    private String id = null;

    @JsonProperty("envelopeStatus")
    private String envelopeStatus = null;

    @JsonProperty("creationDate")
    private ZonedDateTime creationDate = null;

    @JsonProperty("createdBy")
    private String createdBy = null;

    @JsonProperty("updatingDate")
    private ZonedDateTime updatingDate = null;

    @JsonProperty("updatedBy")
    private String updateBy = null;

    @JsonProperty("confidentiality")
    private String confidentiality = null;

    @JsonProperty("envTypeId")
    private String envTypeId = null;

    @JsonProperty("envTypeVersion")
    private int envTypeVersion;

    @JsonProperty("direction")
    private String direction = null;

    @JsonProperty("validity")
    private String validity = null;

    @JsonProperty("listOfDocumentId")
    private List<DocumentIdentifier> listOfDocumentId = new ArrayList<>();

    @JsonProperty("tagList")
    private List<TagElement> tagList = new ArrayList<>();

    public Envelope id(String id) {
        this.id = id;
        return this;
    }

    /**
     * Identification of the envelope.
     * 
     * @return id
     **/
    @ApiModelProperty(required = true, value = "Identification of the envelope.")
    @NotNull
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Envelope envelopeStatus(String envelopeStatus) {
        this.envelopeStatus = envelopeStatus;
        return this;
    }

    /**
     * Status of the envelope.
     * 
     * @return envelopeStatus
     **/
    @ApiModelProperty(value = "Status of the envelope.")
    public String getEnvelopeStatus() {
        return envelopeStatus;
    }

    public void setEnvelopeStatus(String envelopeStatus) {
        this.envelopeStatus = envelopeStatus;
    }

    public Envelope creationDate(ZonedDateTime creationDate) {
        this.creationDate = creationDate;
        return this;
    }

    /**
     * Date of creation of the envelope. On creation, this date will be filled
     * with the current date.
     * 
     * @return creationDate
     **/
    @ApiModelProperty(value = "Date of creation of the envelope. On creation, this date will be filled with the current date.", example = "2017-12-08T10:37:30+01:00")
    @Valid
    public ZonedDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(ZonedDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public Envelope updatingDate(ZonedDateTime updatingDate) {
        this.updatingDate = updatingDate;
        return this;
    }

    /**
     * When the envelope was updated.
     * 
     * @return updatingDate
     **/
    @ApiModelProperty(value = "When the envelope was updated.", example = "2017-12-08T10:37:30+01:00")
    @Valid
    public ZonedDateTime getUpdatingDate() {
        return updatingDate;
    }

    public void setUpdatingDate(ZonedDateTime updatingDate) {
        this.updatingDate = updatingDate;
    }

    public Envelope confidentiality(String confidentiality) {
        this.confidentiality = confidentiality;
        return this;
    }

    /**
     * Defines if the envelope is confidential. or not.
     * 
     * @return confidentiality
     **/
    @ApiModelProperty(value = "Defines if the envelope is confidential. or not.")
    public String getConfidentiality() {
        return confidentiality;
    }

    public void setConfidentiality(String confidentiality) {
        this.confidentiality = confidentiality;
    }

    public Envelope envTypeId(String envTypeId) {
        this.envTypeId = envTypeId;
        return this;
    }

    /**
     * Identification of the envelope type. On creation of a document, this
     * field will be filled with an default value fetched from the document
     * type.
     * 
     * @return envTypeId
     **/
    @ApiModelProperty(value = "Identification of the envelope type. On creation of a document, this field will be filled with an default value fetched from the document type.")
    public String getEnvTypeId() {
        return envTypeId;
    }

    public void setEnvTypeId(String envTypeId) {
        this.envTypeId = envTypeId;
    }

    public Envelope envTypeVersion(int envTypeVersion) {
        this.envTypeVersion = envTypeVersion;
        return this;
    }

    /**
     * Version of the envelope type. On creation of a document, this field will
     * be filled with an default value fetched from the document type.
     * 
     * @return envTypeId
     **/
    @ApiModelProperty(value = "Version of the envelope type. On creation of a document, this field will be filled with an default value fetched from the document type.")
    public int getEnvTypeVersion() {
        return envTypeVersion;
    }

    public void setEnvTypeVersion(int envTypeVersion) {
        this.envTypeVersion = envTypeVersion;
    }

    public Envelope direction(String direction) {
        this.direction = direction;
        return this;
    }

    /**
     * Identification of the document direction. On creation of a document, this
     * field will be filled with an default value fetched from the document
     * direction
     * 
     * @return direction
     **/
    @ApiModelProperty(value = "Identification of the Envelope direction. On creation of a document, this field will be filled with an default value fetched from the document direction")
    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public Envelope validity(String validity) {
        this.validity = validity;
        return this;
    }

    /**
     * Identification of the document validity. On creation of a document, this
     * field will be filled with an default value fetched from the document
     * validity
     * 
     * @return validity
     **/
    @ApiModelProperty(value = "Identification of the Envelope validity. On creation of a document, this field will be filled with an default value fetched from the document validity")
    public String getValidity() {
        return validity;
    }

    public void setValidity(String validity) {
        this.validity = validity;
    }

    public Envelope listOfDocumentId(List<DocumentIdentifier> listOfDocumentId) {
        this.listOfDocumentId = listOfDocumentId;
        return this;
    }

    public Envelope addListOfDocumentIdItem(DocumentIdentifier listOfDocumentIdItem) {
        if (this.listOfDocumentId == null) {
            this.listOfDocumentId = new ArrayList<>();
        }
        this.listOfDocumentId.add(listOfDocumentIdItem);
        return this;
    }

    /**
     * List document identification.
     * 
     * @return listOfDocumentId
     **/
    @ApiModelProperty(value = "List document identification.")
    public List<DocumentIdentifier> getListOfDocumentId() {
        return listOfDocumentId;
    }

    public void setListOfDocumentId(List<DocumentIdentifier> listOfDocumentId) {
        this.listOfDocumentId = listOfDocumentId;
    }

    public Envelope tagList(List<TagElement> tagList) {
        this.tagList = tagList;
        return this;
    }

    public Envelope addTagListItem(TagElement tagListItem) {
        if (this.tagList == null) {
            this.tagList = new ArrayList<>();
        }
        this.tagList.add(tagListItem);
        return this;
    }

    /**
     * Get tagList
     * 
     * @return tagList
     **/
    @ApiModelProperty(value = "List of Tags")
    @Valid
    public List<TagElement> getTagList() {
        return tagList;
    }

    public void setTagList(List<TagElement> tagList) {
        this.tagList = tagList;
    }

    /**
     * Gets the createdBy.
     *
     * @return value of createdBy
     */
    @ApiModelProperty(value = "Created by")
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the createdBy.
     *
     * @param createdBy Value of createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * Gets the updateBy.
     *
     * @return value of updateBy
     */
    @ApiModelProperty(value = "Updated by")
    public String getUpdateBy() {
        return updateBy;
    }

    /**
     * Sets the updateBy.
     *
     * @param updateBy Value of updateBy to set
     */
    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        Envelope envelope = (Envelope) o;
        if (envTypeVersion != envelope.envTypeVersion) {
            return false;
        }
        if (!Objects.equals(id, envelope.id)) {
            return false;
        }
        if (!Objects.equals(envelopeStatus, envelope.envelopeStatus)) {
            return false;
        }
        if (!Objects.equals(creationDate, envelope.creationDate)) {
            return false;
        }
        if (!Objects.equals(createdBy, envelope.createdBy)) {
            return false;
        }
        if (!Objects.equals(updatingDate, envelope.updatingDate)) {
            return false;
        }
        if (!Objects.equals(updateBy, envelope.updateBy)) {
            return false;
        }
        if (!Objects.equals(confidentiality, envelope.confidentiality)) {
            return false;
        }
        if (!Objects.equals(envTypeId, envelope.envTypeId)) {
            return false;
        }
        if (!Objects.equals(direction, envelope.direction)) {
            return false;
        }
        if (!Objects.equals(validity, envelope.validity)) {
            return false;
        }
        if (!Objects.equals(listOfDocumentId, envelope.listOfDocumentId)) {
            return false;
        }
        return Objects.equals(tagList, envelope.tagList);
    }

    @Override
    public int hashCode() {

        return Objects
                .hash(id, envelopeStatus, creationDate, createdBy, updatingDate, updateBy, confidentiality, envTypeId,
                        envTypeVersion, direction, validity, listOfDocumentId, tagList);
    }

    @Override
    public String toString() {
        return "Envelope{" + "id='" + id + '\'' + ", envelopeStatus='" + envelopeStatus + '\'' + ", creationDate="
                + creationDate + ", createdBy='" + createdBy + '\'' + ", updatingDate=" + updatingDate + ", updateBy='"
                + updateBy + '\'' + ", confidentiality='" + confidentiality + '\'' + ", envTypeId='" + envTypeId + '\''
                + ", envTypeVersion=" + envTypeVersion + ", direction='" + direction + '\'' + ", validity='" + validity
                + '\'' + ", listOfDocumentId=" + listOfDocumentId + ", tagList=" + tagList + '}';
    }
}
