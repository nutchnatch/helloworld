package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * EnvelopeCreationResult
 */
public class EnvelopeCreationResult implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("envelopeId")
    private String envelopeId = null;

    @JsonProperty("documentIdList")
    private List<String> documentIdList = new ArrayList<>();

    public EnvelopeCreationResult envelopeId(String envelopeId) {
        this.envelopeId = envelopeId;
        return this;
    }

    /**
     * Created envelope identification.
     * 
     * @return envelopeId
     **/
    @ApiModelProperty(value = "Created envelope identification.")
    public String getEnvelopeId() {
        return envelopeId;
    }

    public void setEnvelopeId(String envelopeId) {
        this.envelopeId = envelopeId;
    }

    public EnvelopeCreationResult documentIdList(List<String> documentIdList) {
        this.documentIdList = documentIdList;
        return this;
    }

    /**
     * Created envelope identification.
     * 
     * @return envelopeId
     **/
    @ApiModelProperty(value = "Created documents identification.")
    public List<String> getDocumentIdList() {
        return documentIdList;
    }

    public void setDocumentIdList(List<String> documentIdList) {
        this.documentIdList = documentIdList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((documentIdList == null) ? 0 : documentIdList.hashCode());
        result = prime * result + ((envelopeId == null) ? 0 : envelopeId.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof EnvelopeCreationResult))
            return false;
        EnvelopeCreationResult other = (EnvelopeCreationResult) obj;
        if (documentIdList == null) {
            if (other.documentIdList != null)
                return false;
        }
        else if (!documentIdList.equals(other.documentIdList))
            return false;
        if (envelopeId == null) {
            if (other.envelopeId != null)
                return false;
        }
        else if (!envelopeId.equals(other.envelopeId))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("EnvelopeCreationResult [envelopeId=");
        builder.append(envelopeId);
        builder.append(", documentIdList=");
        builder.append(documentIdList);
        builder.append("]");
        return builder.toString();
    }

}
