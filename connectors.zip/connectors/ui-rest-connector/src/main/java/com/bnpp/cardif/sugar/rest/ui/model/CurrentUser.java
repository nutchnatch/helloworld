package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * CurrentUser
 */
public class CurrentUser implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("username")
    private String username = null;

    @JsonProperty("firstName")
    private String firstName = null;

    @JsonProperty("lastName")
    private String lastName = null;

    @JsonProperty("authorities")
    private List<String> authorities = new ArrayList<>();

    @JsonProperty("businessScopes")
    private List<String> businessScopes = new ArrayList<>();

    @JsonProperty("currentBusinessScope")
    private String currentBusinessScope = null;

    @JsonProperty("commercialVersion")
    private String commercialVersion = null;

    @JsonProperty("isSafEnabled")
    private boolean isSafEnabled;

    public CurrentUser isSafEnabled() {
        return this;
    }

    /**
     * User login
     * 
     * @return username
     **/
    @ApiModelProperty(required = true, value = "User login")
    @NotNull
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public CurrentUser firstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    /**
     * User first name
     * 
     * @return firstName
     **/
    @ApiModelProperty(value = "User first name")
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public CurrentUser lastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    /**
     * User last name
     * 
     * @return lastName
     **/
    @ApiModelProperty(value = "User last name")
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public CurrentUser authorities(List<String> authorities) {
        this.authorities = authorities;
        return this;
    }

    public CurrentUser addAuthoritiesItem(String authoritiesItem) {
        this.authorities.add(authoritiesItem);
        return this;
    }

    /**
     * List of the user Roles
     * 
     * @return authorities
     **/
    @ApiModelProperty(required = true, value = "List of the user Roles")
    @NotNull
    public List<String> getAuthorities() {
        return authorities;
    }

    public void setAuthorities(List<String> authorities) {
        this.authorities = authorities;
    }

    public CurrentUser businessScopes(List<String> businessScopes) {
        this.businessScopes = businessScopes;
        return this;
    }

    public CurrentUser addBusinessScopesItem(String businessScopesItem) {
        if (this.businessScopes == null) {
            this.businessScopes = new ArrayList<>();
        }
        this.businessScopes.add(businessScopesItem);
        return this;
    }

    /**
     * List of the user business Scopes
     * 
     * @return businessScopes
     **/
    @ApiModelProperty(value = "List of the user business Scopes")
    public List<String> getBusinessScopes() {
        return businessScopes;
    }

    public void setBusinessScopes(List<String> businessScopes) {
        this.businessScopes = businessScopes;
    }

    public CurrentUser currentBusinessScope(String currentBusinessScope) {
        this.currentBusinessScope = currentBusinessScope;
        return this;
    }

    /**
     * Current business Scope
     * 
     * @return currentBusinessScope
     **/
    @ApiModelProperty(value = "Current business Scope")
    public String getCurrentBusinessScope() {
        return currentBusinessScope;
    }

    public void setCurrentBusinessScope(String currentBusinessScope) {
        this.currentBusinessScope = currentBusinessScope;
    }

    public CurrentUser commercialVersion(String commercialVersion) {
        this.commercialVersion = commercialVersion;
        return this;
    }

    /**
     * Commercial version of the application.
     * 
     * @return commercialVersion
     **/
    @ApiModelProperty(value = "Commercial version of the application.")
    public String getCommercialVersion() {
        return commercialVersion;
    }

    public void setCommercialVersion(String commercialVersion) {
        this.commercialVersion = commercialVersion;
    }

    @ApiModelProperty(required = true, value = "Returns true is SAF is enabled")
    @NotNull
    public CurrentUser username(String username) {
        this.username = username;
        return this;
    }

    public void setSafEnabled(boolean safEnabled) {
        isSafEnabled = safEnabled;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((authorities == null) ? 0 : authorities.hashCode());
        result = prime * result + ((businessScopes == null) ? 0 : businessScopes.hashCode());
        result = prime * result + ((commercialVersion == null) ? 0 : commercialVersion.hashCode());
        result = prime * result + ((currentBusinessScope == null) ? 0 : currentBusinessScope.hashCode());
        result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
        result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
        result = prime * result + ((username == null) ? 0 : username.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof CurrentUser))
            return false;
        CurrentUser other = (CurrentUser) obj;
        if (authorities == null) {
            if (other.authorities != null)
                return false;
        }
        else if (!authorities.equals(other.authorities))
            return false;
        if (businessScopes == null) {
            if (other.businessScopes != null)
                return false;
        }
        else if (!businessScopes.equals(other.businessScopes))
            return false;
        if (commercialVersion == null) {
            if (other.commercialVersion != null)
                return false;
        }
        else if (!commercialVersion.equals(other.commercialVersion))
            return false;
        if (currentBusinessScope == null) {
            if (other.currentBusinessScope != null)
                return false;
        }
        else if (!currentBusinessScope.equals(other.currentBusinessScope))
            return false;
        if (firstName == null) {
            if (other.firstName != null)
                return false;
        }
        else if (!firstName.equals(other.firstName))
            return false;
        if (lastName == null) {
            if (other.lastName != null)
                return false;
        }
        else if (!lastName.equals(other.lastName))
            return false;
        if (username == null) {
            if (other.username != null)
                return false;
        }
        else if (!username.equals(other.username))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("CurrentUser [username=");
        builder.append(username);
        builder.append(", firstName=");
        builder.append(firstName);
        builder.append(", lastName=");
        builder.append(lastName);
        builder.append(", authorities=");
        builder.append(authorities);
        builder.append(", businessScopes=");
        builder.append(businessScopes);
        builder.append(", currentBusinessScope=");
        builder.append(currentBusinessScope);
        builder.append(", commercialVersion=");
        builder.append(commercialVersion);
        builder.append("]");
        return builder.toString();
    }

}
