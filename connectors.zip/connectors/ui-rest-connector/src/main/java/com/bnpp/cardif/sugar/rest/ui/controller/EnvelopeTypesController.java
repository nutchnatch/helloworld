package com.bnpp.cardif.sugar.rest.ui.controller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.bnpp.cardif.sugar.rest.ui.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.AclService;
import com.bnpp.cardif.sugar.frontend.services.DocumentTypeService;
import com.bnpp.cardif.sugar.rest.ui.api.EnvelopeTypesApi;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.AclConverter;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.EnvelopeTypeConverter;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.TagConverter;
import com.bnpp.cardif.sugar.utils.CollectionUtils;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/v1")
public class EnvelopeTypesController extends FrontendController implements EnvelopeTypesApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(EnvelopeTypesController.class);

    @Autowired
    private DocumentTypeService documentTypeService;
    
    @Autowired
    private AclService aclService;

    @RequestMapping(value = "/envelope-types/{envelopeTypeId}/{envelopeTypeVersion}", produces = {
            "application/json; charset=UTF-8" }, consumes = { "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<EnvelopeType>> getEnvelopeTypeByID(
            @ApiParam(value = "Envelope type identification.", required = true) @PathVariable("envelopeTypeId") String envelopeTypeId,
            @ApiParam(value = "Envelope type Version.", required = true) @PathVariable("envelopeTypeVersion") Integer envelopeTypeVersion,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getEnvelopeTypeByID called");
        RestResponse<EnvelopeType> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputEnvelopeTypeById(envelopeTypeId, envelopeTypeVersion);
            @SuppressWarnings("squid:S2259")
            int version = envelopeTypeVersion.intValue();
            // call service
            Optional<DocumentClass> result = Optional.ofNullable(documentTypeService.getDocumentTypeByID(envelopeTypeId, version));
            EnvelopeType envelopeType = result.map(EnvelopeTypeConverter::convert).orElseThrow(() -> new TechnicalException(ErrorCode.TE002));

            List<Acl> aclList = fetchAcls(envelopeTypeId, envelopeTypeVersion);
            envelopeType.setAclList(aclList);
            List<EnvelopeType> valueList = new ArrayList<>();

            valueList.add(envelopeType);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getEnvelopeTypeByID end");
        return ResponseEntity.ok(restResponse);
    }

    private List<Acl> fetchAcls(
            @ApiParam(value = "Document type ID.", required = true) @PathVariable("documentTypeId") String documentTypeId,
            int version) throws TechnicalException, FunctionalException {

        AccessControlList instanceAcl = aclService.getAclListByClassId(documentTypeId, version, true);
        AccessControlList classAcl = aclService.getAclListByClassId(documentTypeId, version, false);
        return AclConverter.convert(Optional.ofNullable(instanceAcl), Optional.ofNullable(classAcl));
    }

    private void validateInputEnvelopeTypeById(String envelopeTypeId, Integer envelopeTypeVersion)
            throws InvalidInputException {
        List<String> missingInputs = new ArrayList<>();
        if (envelopeTypeId == null || envelopeTypeId.isEmpty()) {
            missingInputs.add("envelopeTypeId");
        }
        if (envelopeTypeVersion == null) {
            missingInputs.add("envelopeTypeVersion");
        }
        if (!missingInputs.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + CollectionUtils.collectionToString(missingInputs));
        }
    }

    @RequestMapping(value = "/envelope-types", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<EnvelopeType>> getEnvelopeTypes(
            @ApiParam(value = "Includes inactive ones ?", required = false, defaultValue = "false") @RequestParam(value = "inactive", required = false, defaultValue = "false") boolean inactive,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getEnvelopeTypes called");
        RestResponse<EnvelopeType> restResponse = new RestResponse<>();
        try {
            List<DocumentClass> result = getActiveOrInactiveDocumentType(inactive);
            final List<EnvelopeType> envelopeTypeList = new ArrayList<>();
            Optional.ofNullable(result).map(res -> envelopeTypeList.addAll(EnvelopeTypeConverter.convert(res)));

            for(EnvelopeType envelopeType : envelopeTypeList) {
                envelopeType.setAclList(fetchAcls(envelopeType.getId(), envelopeType.getVersion()));
            }
            
            envelopeTypeList.sort(Comparator.comparing(EnvelopeType::getName, String.CASE_INSENSITIVE_ORDER));
            restResponse.setResult(envelopeTypeList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getEnvelopeTypes end");
        return ResponseEntity.ok(restResponse);
    }

    private List<DocumentClass> getActiveOrInactiveDocumentType(boolean inactive) throws TechnicalException, FunctionalException {
        return inactive ? documentTypeService.getAllEnvelopeTypeWithInactive() : documentTypeService.getAllEnvelopeType();
    }

    @RequestMapping(value = "/envelope-types/{envelopeTypeId}/{envelopeTypeVersion}/tags", produces = {
            "application/json; charset=UTF-8" }, consumes = { "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Tag>> searchEnvelopeTags(
            @ApiParam(value = "Envelope type identification.", required = true) @PathVariable("envelopeTypeId") String envelopeTypeId,
            @ApiParam(value = "Envelope type Version.", required = true) @PathVariable("envelopeTypeVersion") Integer envelopeTypeVersion,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("searchEnvelopeTags called");
        RestResponse<Tag> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputEnvelopeTypeById(envelopeTypeId, envelopeTypeVersion);
            @SuppressWarnings("squid:S2259")
            int version = envelopeTypeVersion.intValue();
            // call service
            List<TagClass> result = documentTypeService.getDocumentTypeTags(envelopeTypeId, version);
            // transform service result into JSON response
            List<Tag> valueList = TagConverter.convert(result);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("searchEnvelopeTags end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/envelope-types", produces = { "application/json; charset=UTF-8" }, consumes = {
            "application/json; charset=UTF-8" }, method = RequestMethod.POST)
    public ResponseEntity<RestResponse<EnvelopeType>> createEnvelopeType(
            @ApiParam(value = "The DocumentType to create", required = true) @Valid @RequestBody EnvelopeType inputEnvelopeType,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("createEnvelopeType called");
        RestResponse<EnvelopeType> restResponse = new RestResponse<>();
        try {
            // validate input
            if (inputEnvelopeType == null) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + "inputEnvelopeType");
            }
            DocumentClass input = EnvelopeTypeConverter.convert(inputEnvelopeType, getScope());
            // call service
            DocumentClass result = documentTypeService.createEnvelopeType(input);
            // transform service result into JSON response
            EnvelopeType envelopeType = null;
            if (result != null) {
                envelopeType = EnvelopeTypeConverter.convert(result);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<EnvelopeType> valueList = new ArrayList<>();
            valueList.add(envelopeType);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("createEnvelopeType end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/envelope-types/{envelopeTypeId}/{envelopeTypeVersion}", produces = {
            "application/json; charset=UTF-8" }, consumes = {
                    "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<EnvelopeType>> updateEnvelopeType(
            @ApiParam(value = "Envelope type ID.", required = true) @PathVariable("envelopeTypeId") String envelopeTypeId,
            @ApiParam(value = "Envelope type Version.", required = true) @PathVariable("envelopeTypeVersion") Integer envelopeTypeVersion,
            @ApiParam(value = "The Envelope Type to update", required = true) @Valid @RequestBody EnvelopeType inputEnvelopeType,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("updateEnvelopeType called");
        RestResponse<EnvelopeType> restResponse = new RestResponse<>();
        try {
            // validate input
            if (inputEnvelopeType == null) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + "inputEnvelopeType");
            }
            DocumentClass input = EnvelopeTypeConverter.convert(inputEnvelopeType, getScope());
            // call service
            DocumentClass result = documentTypeService.updateEnvelopeType(input);
            // transform service result into JSON response
            EnvelopeType envelopeType = null;
            if (result != null) {
                envelopeType = EnvelopeTypeConverter.convert(result);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<EnvelopeType> valueList = new ArrayList<>();
            valueList.add(envelopeType);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("updateEnvelopeType end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/envelope-types/{envelopeTypeId}/{envelopeTypeVersion}/activate", produces = {
            "application/json; charset=UTF-8" }, consumes = {
                    "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<String>> activateEnvelopeType(
            @ApiParam(value = "Envelope type ID.", required = true) @PathVariable("envelopeTypeId") String envelopeTypeId,
            @ApiParam(value = "Envelope type Version.", required = true) @PathVariable("envelopeTypeVersion") Integer envelopeTypeVersion,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("activateEnvelopeType called");
        RestResponse<String> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputEnvelopeTypeById(envelopeTypeId, envelopeTypeVersion);
            @SuppressWarnings("squid:S2259")
            int version = envelopeTypeVersion.intValue();
            // call service
            documentTypeService.activateEnvelopeType(envelopeTypeId, version);
            List<String> valueList = new ArrayList<>();
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("activateEnvelopeType end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/envelope-types/{envelopeTypeId}/{envelopeTypeVersion}/deactivate", produces = {
            "application/json; charset=UTF-8" }, consumes = {
                    "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<String>> deactivateEnvelopeType(
            @ApiParam(value = "Envelope type ID.", required = true) @PathVariable("envelopeTypeId") String envelopeTypeId,
            @ApiParam(value = "Envelope type Version.", required = true) @PathVariable("envelopeTypeVersion") Integer envelopeTypeVersion,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("deactivateEnvelopeType called");
        RestResponse<String> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputEnvelopeTypeById(envelopeTypeId, envelopeTypeVersion);
            @SuppressWarnings("squid:S2259")
            int version = envelopeTypeVersion.intValue();
            // call service
            documentTypeService.deactivateEnvelopeType(envelopeTypeId, version);
            List<String> valueList = new ArrayList<>();
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("deactivateEnvelopeType end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/envelope-types/{envelopeTypeId}/{envelopeTypeVersion}/acls", produces = {
            "application/json; charset=UTF-8" }, consumes = { "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Acl>> getEnvelopeTypeAcl(
            @ApiParam(value = "Envelope type ID.", required = true) @PathVariable("envelopeTypeId") String envelopeTypeId,
            @ApiParam(value = "Envelope type Version.", required = true) @PathVariable("envelopeTypeVersion") Integer envelopeTypeVersion,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getEnvelopeTypeAcl called");
        RestResponse<Acl> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputEnvelopeTypeById(envelopeTypeId, envelopeTypeVersion);
            @SuppressWarnings("squid:S2259")
            int version = envelopeTypeVersion.intValue();
            // call service
            AccessControlList instanceAcl = aclService.getAclListByClassId(envelopeTypeId, version, true);
            AccessControlList classAcl = aclService.getAclListByClassId(envelopeTypeId, version, false);
            // transform service result into JSON response
            List<Acl> valueList = AclConverter.convert(Optional.ofNullable(instanceAcl), Optional.ofNullable(classAcl));
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getEnvelopeTypeAcl end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/envelope-types/{envelopeTypeId}/{envelopeTypeVersion}/acls", produces = {
            "application/json; charset=UTF-8" }, consumes = {
                    "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<Acl>> assignEnvelopeTypeAcl(
            @ApiParam(value = "Envelope type ID.", required = true) @PathVariable("envelopeTypeId") String envelopeTypeId,
            @ApiParam(value = "Envelope type Version.", required = true) @PathVariable("envelopeTypeVersion") Integer envelopeTypeVersion,
            @ApiParam(value = "The Acl to assign", required = true) @Valid @RequestBody Acl inputAcl,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("assignEnvelopeTypeAcl called");
        RestResponse<Acl> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputEnvelopeTypeById(envelopeTypeId, envelopeTypeVersion);
            @SuppressWarnings("squid:S2259")
            int version = envelopeTypeVersion.intValue();
            // call service
            AccessControlList result = aclService.assignAclToClassId(inputAcl.getAclId(), envelopeTypeId, version,
                    inputAcl.getIsInstanceValue());
            // transform service result into JSON response
            List<Acl> valueList = new ArrayList<>();
            if (result != null) {
                Acl assignedAcl = AclConverter.convert(result, inputAcl.getIsInstanceValue());
                valueList.add(assignedAcl);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("assignEnvelopeTypeAcl end");
        return ResponseEntity.ok(restResponse);
    }

}
