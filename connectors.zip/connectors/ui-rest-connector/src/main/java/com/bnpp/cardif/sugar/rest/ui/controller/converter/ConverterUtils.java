package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import com.bnpp.cardif.sugar.rest.ui.model.AssociatedTag;
import com.bnpp.cardif.sugar.rest.ui.model.DisplayNameItem;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOTagReference;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

class ConverterUtils
{
    static final String ISSUER = "CARDIF";

    static final String SCHEME = "Sugar";

    private ConverterUtils()
    {
        // nothing to do
    }

    static void convertTagList(DocumentClass documentClass, Supplier<List<AssociatedTag>> supplier)
    {
        List<MCOTagReference> backendTagList = documentClass.getTagReference();
        List<AssociatedTag> tagList = supplier.get();
        if (tagList == null)
        {
            tagList = new ArrayList<>();
        }
        if (backendTagList != null)
        {
            for (MCOTagReference backendTag : backendTagList)
            {
                AssociatedTag associatedTag = new AssociatedTag();
                associatedTag.setSymbolicName(backendTag.getSymbolicName());
                associatedTag.setMandatory(backendTag.isMandatory());
                associatedTag.setMultivalued(backendTag.isMultivalued());
                tagList.add(associatedTag);
            }
        }
    }

    static void convertLabelList(DocumentClass documentClass, Supplier<List<DisplayNameItem>> supplier)
    {
        List<MCOI18NLabel> backendLabelList = documentClass.getShortLabel();
        List<DisplayNameItem> labelList = supplier.get();
        if (labelList == null)
        {
            labelList = new ArrayList<>();
        }
        if (backendLabelList != null)
        {
            for (MCOI18NLabel backendLabel : backendLabelList)
            {
                DisplayNameItem label = new DisplayNameItem();
                label.setLanguage(backendLabel.getLanguage());
                label.setValue(backendLabel.getValue());
                labelList.add(label);
            }
        }
    }
}
