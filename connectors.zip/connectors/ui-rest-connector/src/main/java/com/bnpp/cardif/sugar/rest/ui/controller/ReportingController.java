package com.bnpp.cardif.sugar.rest.ui.controller;

import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.BasketsService;
import com.bnpp.cardif.sugar.frontend.services.DocumentTypeService;
import com.bnpp.cardif.sugar.frontend.services.FolderTypeService;
import com.bnpp.cardif.sugar.frontend.services.ReportingService;
import com.bnpp.cardif.sugar.rest.ui.api.ReportingApi;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.ReportingConverter;
import com.bnpp.cardif.sugar.rest.ui.model.*;

import com.bnpp.cardif.sugar.utils.GZIPUtils;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.*;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.apache.commons.io.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/v1")
public class ReportingController extends FrontendController implements ReportingApi {

    private static final String DATE_FORMAT = "yyyy-MM-dd";

    private static final Logger LOGGER = LoggerFactory.getLogger(ReportingController.class);

    private static final String CONTENT_DISPOSITION = "Content-disposition";

    private static final String CONTENT_TYPE = "Content-type";

    private static final String ATTACHMENT_FILENAME_REPORT_XLS = "attachment;filename=report.xls";

    private static final String ATTACHMENT_FILENAME_REPORT_ZIP = "attachment;filename=report.zip";

    private static final String APPLICATION_VND_OPENXMLFORMATS_OFFICEDOCUMENT_SPREADSHEETML_SHEET = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

    private static final String APPLICATION_ZIP = "application/zip";

    @Autowired
    private ReportingService reportingService;

    @Autowired
    private DocumentTypeService documentTypeService;
    @Autowired
    private FolderTypeService folderTypeService;
    @Autowired
    private BasketsService basketsService;

    @RequestMapping(value = "/reporting/baskets", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    @SuppressWarnings("squid:S2147")
    public ResponseEntity<RestResponse<BasketReporting>> getBasketReporting(final HttpServletResponse response,
            @ApiParam(value = "startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "startDate", required = true) LocalDate startDate,
            @ApiParam(value = "endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "endDate", required = true) LocalDate endDate,
            @ApiParam(value = "download") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "download", required = false, defaultValue = "false") boolean download) {

        LOGGER.debug("getBasketReporting called");
        RestResponse<BasketReporting> restResponse = new RestResponse<>();
        try {
            validateInput(startDate, endDate);

            String startingDate = startDate.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
            String endingDate = endDate.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
            // call service
            List<BasketRatio> result = reportingService.getBasketRatioIndicators(startingDate, endingDate);
            // transform service result into JSON response
            List<BasketReporting> basketReportingList = new ArrayList<>();
            if (result != null) {
                basketReportingList = ReportingConverter.convert(result);

                for (final BasketReporting basketReporting : basketReportingList) {
                    final Basket basket = basketsService.getBasketByID(basketReporting.getBasketId());
                    if (basket != null) {
                        basketReporting.setBasketId(basket.getSymbolicName());
                    }
                }
                basketReportingList.sort((o1, o2) -> Long.compare(o2.getNumberOfOpened(), o1.getNumberOfOpened()));

            }
            if (download) {
                final XSSFWorkbook workbook = new XSSFWorkbook();
                ReportBasket.fill(workbook, basketReportingList);

                response.addHeader(CONTENT_DISPOSITION, ATTACHMENT_FILENAME_REPORT_XLS);
                response.addHeader(CONTENT_TYPE, APPLICATION_VND_OPENXMLFORMATS_OFFICEDOCUMENT_SPREADSHEETML_SHEET);
                workbook.write(response.getOutputStream());
                response.flushBuffer();
            }
            restResponse.setResult(basketReportingList);
            restResponse.setStatus(true);
        }
        catch (IOException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getBasketReporting end");
        return ResponseEntity.ok(restResponse);
    }

    private void validateInput(LocalDate startDate, LocalDate endDate) throws InvalidInputException {
        if (startDate == null) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + "startDate");
        }
        if (endDate == null) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "endDate");
        }
    }

    @RequestMapping(value = "/reporting/document", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    @SuppressWarnings("squid:S2147")
    public ResponseEntity<RestResponse<DocumentReporting>> getDocumentReporting(final HttpServletResponse response,
            @ApiParam(value = "startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "startDate", required = true) LocalDate startDate,
            @ApiParam(value = "endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "endDate", required = true) LocalDate endDate,
            @ApiParam(value = "download") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "download", required = false, defaultValue = "false") boolean download) {

        LOGGER.debug("getDocumentReporting called");
        RestResponse<DocumentReporting> restResponse = new RestResponse<>();
        try {
            validateInput(startDate, endDate);

            String startingDate = startDate.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
            String endingDate = endDate.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
            // call service
            List<DocumentStock> result = reportingService.getDocumentStockIndicators(startingDate, endingDate);
            // transform service result into JSON response
            List<DocumentReporting> documentReportingList = new ArrayList<>();
            if (result != null) {
                documentReportingList = ReportingConverter.convertDoc(result);
                final List<DocumentClass> docTypes = documentTypeService.getAllDocumentTypeWithInactives();
                for (final DocumentReporting documentReporting : documentReportingList) {
                    Optional<DocumentClass> docClass = docTypes.stream().filter(docType -> docType.getClassId().getValue().equals(documentReporting.getClassId())).findFirst();
                    documentReporting.setClassId(docClass.orElseThrow(() -> new TechnicalException("Document class not found")).getLongLabel());
                }
                documentReportingList.sort((o1, o2) -> Long.compare(o2.getNumberOfDocuments(), o1.getNumberOfDocuments()));
            }
            if (download) {
                final XSSFWorkbook workbook = new XSSFWorkbook();
                ReportDocument.fill(workbook, documentReportingList);

                response.addHeader(CONTENT_DISPOSITION, ATTACHMENT_FILENAME_REPORT_XLS);
                response.addHeader(CONTENT_TYPE, APPLICATION_VND_OPENXMLFORMATS_OFFICEDOCUMENT_SPREADSHEETML_SHEET);
                workbook.write(response.getOutputStream());
                response.flushBuffer();
            }
            restResponse.setResult(documentReportingList);
            restResponse.setStatus(true);
        }
        catch (IOException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getDocumentReporting end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/reporting/envelope", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    @SuppressWarnings("squid:S2147")
    public ResponseEntity<RestResponse<EnvelopeReporting>> getEnvelopeReporting(final HttpServletResponse response,
            @ApiParam(value = "startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "startDate", required = true) LocalDate startDate,
            @ApiParam(value = "endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "endDate", required = true) LocalDate endDate,
            @ApiParam(value = "download") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "download", required = false, defaultValue = "false") boolean download) {

        LOGGER.debug("getEnvelopeReporting called");
        RestResponse<EnvelopeReporting> restResponse = new RestResponse<>();
        try {
            validateInput(startDate, endDate);

            String startingDate = startDate.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
            String endingDate = endDate.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
            // call service
            List<EnvelopeFlows> result = reportingService.getEnvelopeFlowsIndicators(startingDate, endingDate);
            // transform service result into JSON response
            List<EnvelopeReporting> envelopeReportingList = new ArrayList<>();
            if (result != null) {
                envelopeReportingList = ReportingConverter.convertEnv(result);
                final List<DocumentClass> docTypes = documentTypeService.getAllEnvelopeTypeWithInactive();
                for (final EnvelopeReporting envelopeReporting : envelopeReportingList) {
                    Optional<DocumentClass> docClass = docTypes.stream().filter(docType -> docType.getClassId().getValue().equals(envelopeReporting.getClassId())).findFirst();
                    envelopeReporting.setClassId(docClass.orElseThrow(() -> new TechnicalException("Envelope class not found")).getLongLabel());
                }
                envelopeReportingList.sort((o1, o2) -> Long.compare(o2.getNumberOfEnvelopes(), o1.getNumberOfEnvelopes()));
            }
            if (download) {
                final XSSFWorkbook workbook = new XSSFWorkbook();
                ReportEnvelope.fill(workbook, envelopeReportingList);

                response.addHeader(CONTENT_DISPOSITION, ATTACHMENT_FILENAME_REPORT_XLS);
                response.addHeader(CONTENT_TYPE, APPLICATION_VND_OPENXMLFORMATS_OFFICEDOCUMENT_SPREADSHEETML_SHEET);
                workbook.write(response.getOutputStream());
                response.flushBuffer();
            }
            restResponse.setResult(envelopeReportingList);
            restResponse.setStatus(true);
        }
        catch (IOException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getEnvelopeReporting end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/reporting/folder", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    @SuppressWarnings("squid:S2147")
    public ResponseEntity<RestResponse<FolderReporting>> getFolderReporting(final HttpServletResponse response,
            @ApiParam(value = "startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "startDate", required = true) LocalDate startDate,
            @ApiParam(value = "endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "endDate", required = true) LocalDate endDate,
            @ApiParam(value = "download") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) @RequestParam(value = "download", required = false, defaultValue = "false") boolean download) {

        LOGGER.debug("getFolderReporting called");
        RestResponse<FolderReporting> restResponse = new RestResponse<>();
        try {
            validateInput(startDate, endDate);

            String startingDate = startDate.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
            String endingDate = endDate.format(DateTimeFormatter.ofPattern(DATE_FORMAT));
            // call service
            List<FolderStock> result = reportingService.getFolderStockIndicators(startingDate, endingDate);
            // transform service result into JSON response
            List<FolderReporting> folderReportingList = new ArrayList<>();
            if (result != null) {
                folderReportingList = ReportingConverter.convertFolder(result);
                final List<FolderClass> folderClasses = folderTypeService.getAllFolderTypeWithInactive();
                for (final FolderReporting folderReporting : folderReportingList) {
                    Optional<FolderClass> folderClass = folderClasses.stream().filter(folderType -> folderType.getClassId().getValue().equals(folderReporting.getClassId())).findFirst();
                    folderReporting.setClassId(folderClass.orElseThrow(() -> new TechnicalException("Folder class not found")).getLongLabel());
                }
                folderReportingList.sort((o1, o2) -> Long.compare(o2.getNumberOfFolders(), o1.getNumberOfFolders()));
            }
            if (download) {
                final XSSFWorkbook workbook = new XSSFWorkbook();
                ReportFolder.fill(workbook, folderReportingList);

                response.addHeader(CONTENT_DISPOSITION, ATTACHMENT_FILENAME_REPORT_XLS);
                response.addHeader(CONTENT_TYPE, APPLICATION_VND_OPENXMLFORMATS_OFFICEDOCUMENT_SPREADSHEETML_SHEET);
                workbook.write(response.getOutputStream());
                response.flushBuffer();
            }
            restResponse.setResult(folderReportingList);
            restResponse.setStatus(true);
        }
        catch (IOException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getFolderReporting end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/reporting/summary", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<ReportingSummary>> getReportingSummary(
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getReportingSummary called");
        RestResponse<ReportingSummary> restResponse = new RestResponse<>();
        try {
            // call service
            Summary result = reportingService.getReportingSummary();
            // transform service result into JSON response
            List<ReportingSummary> reportingSummaryList = new ArrayList<>();
            if (result != null) {
                ReportingSummary content = ReportingConverter.convertSummary(result);
                reportingSummaryList.add(content);
            }
            restResponse.setResult(reportingSummaryList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getReportingSummary end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/track-and-log", consumes = MediaType.ALL_VALUE)
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
                            @ApiResponse(code = 400, message = "Bad Request", response = Response.class) })
    @ResponseBody
    @SuppressWarnings("squid:S2147")
    public ResponseEntity<RestResponse<ReportingSummary>> exportTrackLog(final HttpServletResponse response,
            @ApiParam(value = "startDateTime") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) @RequestParam(value = "startDateTime", required = true) LocalDateTime startDate,
            @ApiParam(value = "endDateTime") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) @RequestParam(value = "endDateTime", required = true) LocalDateTime endDate,
            @ApiParam(value = "objectId") @RequestParam(value = "objectId", required = false) String objectId,
            @ApiParam(value = "userId") @RequestParam(value = "userId", required = false) String userId){
        LOGGER.debug("exportTrackLog called");
        RestResponse<ReportingSummary> restResponse = new RestResponse<>();

        try
        {
            pipeReport(response, reportingService.getTraceLogFile(startDate, endDate, objectId, userId));
        }
        catch (IOException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }

        LOGGER.debug("exportTrackLog end");
        return ResponseEntity.ok(restResponse);
    }

    private void pipeReport(HttpServletResponse response, String report) throws IOException
    {
        response.addHeader(CONTENT_DISPOSITION, ATTACHMENT_FILENAME_REPORT_ZIP);
        response.addHeader(CONTENT_TYPE, APPLICATION_ZIP);
        response.setContentType(APPLICATION_ZIP);

        try(ByteArrayInputStream bais = new ByteArrayInputStream(GZIPUtils.decode(report)))
        {
            IOUtils.copy(bais, response.getOutputStream(), 1024);
        }
        response.getOutputStream().close();

        response.flushBuffer();
    }
}
