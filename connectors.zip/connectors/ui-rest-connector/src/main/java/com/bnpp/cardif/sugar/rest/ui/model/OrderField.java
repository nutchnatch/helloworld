package com.bnpp.cardif.sugar.rest.ui.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum OrderField {
    
    NAME, VALIDITY_CODE, CREATOR, LAST_MODIFIER, CREATION_DATE, UPDATE_DATE, CONFIDENTIALITY, TAG;
    
    @JsonCreator
    public static OrderField fromString(String name) {
        return OrderField.valueOf(name.toUpperCase());
    }
    
    @JsonValue
    public String getName() {
        return name().toLowerCase();
    }
}
