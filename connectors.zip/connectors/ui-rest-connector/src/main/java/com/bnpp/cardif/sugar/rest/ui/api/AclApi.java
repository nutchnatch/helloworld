package com.bnpp.cardif.sugar.rest.ui.api;

import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bnpp.cardif.sugar.rest.ui.model.Acl;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;

@SuppressWarnings("squid:S1609")
@Path("/acls")
@Api(value = "acls")
@Produces({ "application/json; charset=UTF-8" })
public interface AclApi {

    @ApiOperation(value = "Get all ACL", notes = "Retrieves all ACL.", authorizations = {
            @Authorization(value = "header_token") })
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Response OK with paginated result (200)"),
            @ApiResponse(code = 400, message = "Bad Request.(400)", response = RestResponse.class),
            @ApiResponse(code = 401, message = "Unauthorized access.(401)", response = RestResponse.class),
            @ApiResponse(code = 403, message = "Forbidden access.(403)", response = RestResponse.class),
            @ApiResponse(code = 404, message = "The specified resource was not found.(404)", response = RestResponse.class),
            @ApiResponse(code = 500, message = "Internal server error occurred.(500)", response = RestResponse.class),
            @ApiResponse(code = 503, message = "Service unavailable.(503)", response = RestResponse.class),
            @ApiResponse(code = 504, message = "Gateway timeout.(504)", response = RestResponse.class) })
    @RequestMapping(value = "/acls", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Acl>> getAllAcl(
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId);

}
