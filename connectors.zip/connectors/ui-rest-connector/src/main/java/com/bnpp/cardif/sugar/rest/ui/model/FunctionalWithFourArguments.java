package com.bnpp.cardif.sugar.rest.ui.model;

@FunctionalInterface
public interface FunctionalWithFourArguments<A, B, C, D, R>
{
    R apply(A a, B b, C c, D d);
}