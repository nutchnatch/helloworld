package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Contains the selected values for a tag. If the type is a choice list, the we
 * may have a list of values with the correspondent display values.
 */
@ApiModel(description = "Contains the selected values for a tag. If the type is a choice list, the we may have a list of values with the correspondent display values.")
public class TagValues implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("value")
    private String value = null;

    @JsonProperty("displayValue")
    private String displayValue = null;

    public TagValues value(String value) {
        this.value = value;
        return this;
    }

    /**
     * Contains the value depending on the selected type.
     * 
     * @return value
     **/
    @ApiModelProperty(required = true, value = "Contains the value depending on the selected type.")
    @NotNull

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public TagValues displayValue(String displayValue) {
        this.displayValue = displayValue;
        return this;
    }

    /**
     * Contains the displayed value for this value.
     * 
     * @return displayValue
     **/
    @ApiModelProperty(required = true, value = "Contains the displayed value for this value.")
    @NotNull

    public String getDisplayValue() {
        return displayValue;
    }

    public void setDisplayValue(String displayValue) {
        this.displayValue = displayValue;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((displayValue == null) ? 0 : displayValue.hashCode());
        result = prime * result + ((value == null) ? 0 : value.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof TagValues))
            return false;
        TagValues other = (TagValues) obj;
        if (displayValue == null) {
            if (other.displayValue != null)
                return false;
        }
        else if (!displayValue.equals(other.displayValue))
            return false;
        if (value == null) {
            if (other.value != null)
                return false;
        }
        else if (!value.equals(other.value))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("TagValues [value=");
        builder.append(value);
        builder.append(", displayValue=");
        builder.append(displayValue);
        builder.append("]");
        return builder.toString();
    }

}
