package com.bnpp.cardif.sugar.rest.ui.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Folder
 */
public class Folder implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("id")
    private String id = null;

    @JsonProperty("name")
    private String name = null;

    @JsonProperty("owner")
    private String owner = null;

    @JsonProperty("status")
    private String status = null;

    @JsonProperty("creationDate")
    private ZonedDateTime creationDate = null;

    @JsonProperty("createdBy")
    private String createdBy = null;

    @JsonProperty("lastUpdateDate")
    private ZonedDateTime lastUpdateDate = null;

    @JsonProperty("updatedBy")
    private String updatedBy = null;

    @JsonProperty("retentionDate")
    private LocalDate retentionDate = null;

    @JsonProperty("folderTypeId")
    private String folderTypeId = null;

    @JsonProperty("folderTypeVersion")
    private int folderTypeVersion;

    @JsonProperty("listOfDocumentId")
    private List<DocumentIdentifier> listOfDocumentId = new ArrayList<>();

    @JsonProperty("tagList")
    private List<TagElement> tagList = new ArrayList<>();

    public Folder id(String id) {
        this.id = id;
        return this;
    }

    /**
     * Folder identification.
     * 
     * @return id
     **/
    @ApiModelProperty(required = true, value = "Folder identification.")
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Folder name(String name) {
        this.name = name;
        return this;
    }

    /**
     * Name of the Folder.
     * 
     * @return name
     **/
    @ApiModelProperty(required = true, value = "Name of the Folder.")
    @NotNull
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Folder owner(String owner) {
        this.owner = owner;
        return this;
    }

    /**
     * Owner of the Folder. On the folder creation, this field will be
     * automatically filled with the current user session id.
     * 
     * @return owner
     **/
    @ApiModelProperty(value = "Owner of the Folder. On the folder creation, this field will be automatically filled with the  current user session id.")
    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public Folder status(String status) {
        this.status = status;
        return this;
    }

    /**
     * State of the Folder.
     * 
     * @return status
     **/
    @ApiModelProperty(value = "State of the Folder.")
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Folder creationDate(ZonedDateTime creationDate) {
        this.creationDate = creationDate;
        return this;
    }

    /**
     * When the Folder is created. On creation, this date will be filled with
     * the current date.
     * 
     * @return creationDate
     **/
    @ApiModelProperty(value = "When the Folder is created. On creation, this date will be filled with the current date.", example = "2017-12-08T10:37:30+01:00")
    @Valid
    public ZonedDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(ZonedDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public Folder lastUpdateDate(ZonedDateTime lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
        return this;
    }

    /**
     * Last date when the folder was updated.
     * 
     * @return lastUpdateDate
     **/
    @ApiModelProperty(value = "Last date when the folder was updated.", example = "2017-12-08T10:37:30+01:00")
    @Valid
    public ZonedDateTime getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(ZonedDateTime lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public Folder retentionDate(LocalDate retentionDate) {
        this.retentionDate = retentionDate;
        return this;
    }

    /**
     * Date until when this folder can be kept stored.
     * 
     * @return retentionDate
     **/
    @ApiModelProperty(value = "Date until when this folder can be kept stored.")
    @Valid
    public LocalDate getRetentionDate() {
        return retentionDate;
    }

    public void setRetentionDate(LocalDate retentionDate) {
        this.retentionDate = retentionDate;
    }

    public Folder folderTypeId(String folderTypeId) {
        this.folderTypeId = folderTypeId;
        return this;
    }

    /**
     * Identification of the folder type selected. On creation of a document,
     * this field will be filled with a default value fetched from the folder
     * type.
     * 
     * @return folderTypeId
     **/
    @ApiModelProperty(value = "Identification of the folder type selected. On creation of a document, this field will be filled with a default value fetched from the folder type.")
    public String getFolderTypeId() {
        return folderTypeId;
    }

    public void setFolderTypeId(String folderTypeId) {
        this.folderTypeId = folderTypeId;
    }

    public Folder folderTypeVersion(int folderTypeVersion) {
        this.folderTypeVersion = folderTypeVersion;
        return this;
    }

    /**
     * Version of the folder type selected. On creation of a document, this
     * field will be filled with a default value fetched from the folder type.
     * 
     * @return folderTypeVersion
     **/
    @ApiModelProperty(value = "Version of the folder type selected. On creation of a document, this field will be filled with a default value fetched from the folder type.")
    public int getFolderTypeVersion() {
        return folderTypeVersion;
    }

    public void setFolderTypeVersion(int folderTypeVersion) {
        this.folderTypeVersion = folderTypeVersion;
    }

    public Folder listOfDocumentId(List<DocumentIdentifier> listOfDocumentId) {
        this.listOfDocumentId = listOfDocumentId;
        return this;
    }

    public Folder addListOfDocumentIdItem(DocumentIdentifier listOfDocumentIdItem) {
        if (this.listOfDocumentId == null) {
            this.listOfDocumentId = new ArrayList<>();
        }
        this.listOfDocumentId.add(listOfDocumentIdItem);
        return this;
    }

    /**
     * List of document identification.
     * 
     * @return listOfDocumentId
     **/
    @ApiModelProperty(value = "List of document identification.")
    public List<DocumentIdentifier> getListOfDocumentId() {
        return listOfDocumentId;
    }

    public void setListOfDocumentId(List<DocumentIdentifier> listOfDocumentId) {
        this.listOfDocumentId = listOfDocumentId;
    }

    public Folder tagList(List<TagElement> tagList) {
        this.tagList = tagList;
        return this;
    }

    public Folder addTagListItem(TagElement tagListItem) {
        if (this.tagList == null) {
            this.tagList = new ArrayList<>();
        }
        this.tagList.add(tagListItem);
        return this;
    }

    /**
     * Get tagList
     * 
     * @return tagList
     **/
    @ApiModelProperty(value = "")
    @Valid
    public List<TagElement> getTagList() {
        return tagList;
    }

    public void setTagList(List<TagElement> tagList) {
        this.tagList = tagList;
    }

    /**
     * Gets the createdBy.
     *
     * @return value of createdBy
     */
    @ApiModelProperty(value = "Created by")
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the createdBy.
     *
     * @param createdBy Value of createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * Gets the updatedBy.
     *
     * @return value of updatedBy
     */
    @ApiModelProperty(value = "Updated by")
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * Sets the updatedBy.
     *
     * @param updatedBy Value of updatedBy to set
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        Folder folder = (Folder) o;
        if (folderTypeVersion != folder.folderTypeVersion) {
            return false;
        }
        if (!Objects.equals(id, folder.id)) {
            return false;
        }
        if (!Objects.equals(name, folder.name)) {
            return false;
        }
        if (!Objects.equals(owner, folder.owner)) {
            return false;
        }
        if (!Objects.equals(status, folder.status)) {
            return false;
        }
        if (!Objects.equals(creationDate, folder.creationDate)) {
            return false;
        }
        if (!Objects.equals(createdBy, folder.createdBy)) {
            return false;
        }
        if (!Objects.equals(lastUpdateDate, folder.lastUpdateDate)) {
            return false;
        }
        if (!Objects.equals(updatedBy, folder.updatedBy)) {
            return false;
        }
        if (!Objects.equals(retentionDate, folder.retentionDate)) {
            return false;
        }
        if (!Objects.equals(folderTypeId, folder.folderTypeId)) {
            return false;
        }
        if (!Objects.equals(listOfDocumentId, folder.listOfDocumentId)) {
            return false;
        }
        return Objects.equals(tagList, folder.tagList);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, name, owner, status, creationDate, createdBy, lastUpdateDate, updatedBy, retentionDate,
                folderTypeId, folderTypeVersion, listOfDocumentId, tagList);
    }

    @Override
    public String toString() {
        return "Folder{" + "id='" + id + '\'' + ", name='" + name + '\'' + ", owner='" + owner + '\'' + ", status='"
                + status + '\'' + ", creationDate=" + creationDate + ", createdBy='" + createdBy + '\''
                + ", lastUpdateDate=" + lastUpdateDate + ", updatedBy='" + updatedBy + '\'' + ", retentionDate="
                + retentionDate + ", folderTypeId='" + folderTypeId + '\'' + ", folderTypeVersion=" + folderTypeVersion
                + ", listOfDocumentId=" + listOfDocumentId + ", tagList=" + tagList + '}';
    }
}
