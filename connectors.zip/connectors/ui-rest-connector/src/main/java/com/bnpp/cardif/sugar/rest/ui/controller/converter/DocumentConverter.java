package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import com.bnpp.cardif.sugar.rest.ui.model.Document;
import com.bnpp.cardif.sugar.rest.ui.model.DocumentCreationResult;
import com.bnpp.cardif.sugar.rest.ui.model.Folder;
import com.bnpp.cardif.sugar.rest.ui.model.TagElement;
import com.bnpp.cardif.sugar.utils.DateUtils;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.*;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.FileData;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.ParentId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 
 * @author 831743
 *
 */
public class DocumentConverter {

    private static final String DEFAULT_FILE_NAME = "document";

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentConverter.class);

    /**
     * private empty constructor
     */
    private DocumentConverter() {
        // private constructor to avoid instance creation.
    }

    /**
     * Convert a backend document into a JSON Document
     * 
     * @param backendDoc
     *            com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document
     * @return Document
     */
    public static Document convert(com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document backendDoc) {
        Document result = null;
        if (backendDoc != null) {
            result = new Document();
            // Id
            if (backendDoc.getId() != null) {
                result.setId(backendDoc.getId().getValue());
            }
            result.setDocViewURL(backendDoc.getArenderURI());
            // doc data
            ElectronicDocumentDataType docData = backendDoc.getData();
            convertDocumentData(result, docData);
            // file data
            FileData fileData = backendDoc.getFileData();
            convertFileData(fileData, result);
            // parent data
            ParentId documentParent = backendDoc.getParentId();
            convertParentData(result, documentParent);
            // tag list
            List<TagElement> tagList = new ArrayList<>();
            if (backendDoc.getTags() != null) {
                Tags documentTags = backendDoc.getTags();
                List<com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag> documentTagList = documentTags
                        .getTag();
                if (documentTagList != null && !documentTagList.isEmpty()) {
                    tagList = TagConverter.convertElement(documentTagList);
                }
            }
            result.setTagList(tagList);
        }
        return result;
    }

    @SuppressWarnings("squid:S1066")
    private static void convertParentData(Document result, ParentId documentParent) {
        if (documentParent != null) {
            if (documentParent.getId() != null) {
                result.setEnvelopeID(documentParent.getId().getValue());
            }
            // other data
        }
    }

    @SuppressWarnings("squid:S1066")
    private static void convertFileData(FileData fileData, Document result) {
        if (fileData != null) {
            if (fileData.getURI() != null && !fileData.getURI().isEmpty()) {
                result.setDocFileID(fileData.getURI().get(0));

            }
            // If needed documentFile are here
        }
    }

    private static void convertDocumentData(Document result, ElectronicDocumentDataType docData) {
        if (docData != null) {
            result.setConfidentiality(docData.getConfdntltyLvl());
            if (docData.getCreatnDate() != null) {
                result.setCreationDate(DateUtils.asZonedDateTime(docData.getCreatnDate()));
            }
            result.setCreatedBy(docData.getCreator());
            if (docData.getUpdtDate() != null) {
                result.setUpdateDate(DateUtils.asZonedDateTime(docData.getUpdtDate()));
            }
            result.setUpdatedBy(docData.getLastModifier());
            if (docData.getClassId() != null) {
                result.setDocTypeId(docData.getClassId().getValue());
                result.setDocTypeVersion(docData.getClassId().getVersId());
            }
            result.setDirection(docData.getDirectionCode());
            if (docData.getValidityCode() != null) {
                result.setValidity(docData.getValidityCode().value());
            }
            result.setLanguage(docData.getLangCode());
            result.setName(docData.getName());
            if (docData.getRetentionEndDate() != null) {
                result.setRetentionEndDate(DateUtils.asLocalDate(docData.getRetentionEndDate()));
            }
            if (docData.getRetentionStartDate() != null) {
                result.setRetentionStartDate(DateUtils.asLocalDate(docData.getRetentionStartDate()));
            }
        }
    }

    /**
     * Convert a list of backend document into a List of JSON Document
     * 
     * @param backendDocList
     *            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document>
     * @return List<Document>
     */
    public static List<Document> convert(
            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> backendDocList) {
        List<Document> result = new ArrayList<>();
        if (backendDocList != null && !backendDocList.isEmpty()) {
            for (com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document backendDoc : backendDocList) {
                Document content = DocumentConverter.convert(backendDoc);
                result.add(content);
            }
        }
        return result;
    }

    public static List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document>
            convert(List<Document> documentList, String scope) {

        List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> result = new ArrayList<>();
        if (documentList != null) {
            for (Document document : documentList) {
                com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document backendDoc = DocumentConverter
                        .convert(document, scope);
                result.add(backendDoc);
            }
        }
        return result;
    }

    public static com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document convert(Document document,
            String scope) {

        com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document result = null;
        if (document != null) {
            result = new com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document();
            result.setCategory(Category.DOCUMENT);
            ElectronicDocumentDataType docData = DocumentConverter.convertData(document);
            result.setData(docData);
            FileData fileData = DocumentConverter.convertFileData(document);
            result.setFileData(fileData);
            Id id = DocumentConverter.convertId(document);
            result.setId(id);
            ParentId parentid = DocumentConverter.convertParent(document);
            result.setParentId(parentid);
            result.setScope(scope);
            Tags docTags = DocumentConverter.convertTags(document);
            result.setTags(docTags);
        }
        return result;
    }

    private static Id convertId(Document document) {
        Id result = new Id();
        if (document != null) {
            result.setIssuer(ConverterUtils.ISSUER);
            result.setScheme(ConverterUtils.SCHEME);
            result.setValue(document.getId());
        }
        return result;
    }

    private static Tags convertTags(Document document) {

        List<Tag> backendTagList = new ArrayList<>();
        Tags result = new Tags(backendTagList);
        if (document != null && document.getTagList() != null) {

            List<TagElement> taglist = document.getTagList();
            for (TagElement tagElement : taglist) {
                Tag currentTag = new Tag();
                currentTag.setName(tagElement.getTagName());
                currentTag.setValue(tagElement.getTagValue());
                backendTagList.add(currentTag);
            }
        }
        return result;
    }

    private static ParentId convertParent(Document document) {

        ParentId result = new ParentId();
        if (document != null) {
            Id id = new Id();
            id.setIssuer(ConverterUtils.ISSUER);
            id.setScheme(ConverterUtils.SCHEME);
            id.setValue(document.getEnvelopeID());
            result.setId(id);
        }
        return result;
    }

    private static FileData convertFileData(Document document) {

        FileData result = new FileData();
        if (document != null && document.getDocFileID() != null) {
            List<String> uriList = result.getURI();
            uriList.add(document.getDocFileID());
        }
        return result;
    }

    private static ElectronicDocumentDataType convertData(Document document) {

        ElectronicDocumentDataType result = new ElectronicDocumentDataType();
        if (document != null) {
            result.setConfdntltyLvl(document.getConfidentiality());
            ClassId classId = new ClassId(document.getDocTypeId(), ConverterUtils.ISSUER, document.getDocTypeVersion());
            result.setClassId(classId);
            result.setDirectionCode(document.getDirection());
            result.setLangCode(document.getLanguage());
            result.setName(document.getName());
            LocalDate retentionEndDate = document.getRetentionEndDate();
            if (retentionEndDate != null) {
                result.setRetentionEndDate(DateUtils.asDate(retentionEndDate));
            }
            LocalDate retentionStartDate = document.getRetentionStartDate();
            if (retentionStartDate != null) {
                result.setRetentionStartDate(DateUtils.asDate(retentionStartDate));
            }
            if (document.getValidity() != null) {
                try {
                    result.setValidityCode(ValdtyCode.valueOf(document.getValidity()));
                }
                catch (IllegalArgumentException e) {
                    LOGGER.warn("Invalid value for ValdtyCode, ignored.", e);
                }
            }
        }
        return result;
    }

    public static List<DocumentCreationResult> convertToDocumentCreationResult(
            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> backendDocList) {

        List<DocumentCreationResult> result = new ArrayList<>();
        if (backendDocList != null && !backendDocList.isEmpty()) {
            for (com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document backendDoc : backendDocList) {
                DocumentCreationResult content = DocumentConverter.convertToDocumentCreationResult(backendDoc);
                result.add(content);
            }
        }
        return result;
    }

    private static DocumentCreationResult convertToDocumentCreationResult(
            com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document backendDoc) {

        DocumentCreationResult result = null;
        if (backendDoc != null && backendDoc.getId() != null) {
            result = new DocumentCreationResult();
            result.setDocumentId(backendDoc.getId().getValue());
            if (backendDoc.getParentId() != null && backendDoc.getParentId().getId() != null) {
                result.setEnvelopeId(backendDoc.getParentId().getId().getValue());
            }
        }
        return result;
    }

    public static Document addFolderListToDocument(Document document,
            List<com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder> backendFolderList, String scope,
            String token) {

        List<Folder> folderList = FolderConverter.convert(backendFolderList, scope, token);
        if (folderList != null) {
            document.setFolderList(folderList);
        }
        return document;
    }

    public static com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document convert(MultipartFile file,
            String scope) {

        com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document result = null;
        if (file != null) {
            result = new com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document();
            result.setCategory(Category.DOCUMENT);
            ElectronicDocumentDataType docData = DocumentConverter.convertData(file);
            result.setData(docData);
            result.setScope(scope);
        }
        return result;
    }

    private static ElectronicDocumentDataType convertData(MultipartFile file) {

        ElectronicDocumentDataType result = new ElectronicDocumentDataType();

        if(file.getOriginalFilename() != null && ! file.getOriginalFilename().isEmpty()) {
            result.setName(file.getOriginalFilename());
        } else {
            result.setName(DEFAULT_FILE_NAME);
        }
        result.setCreatnDate(new Date());
        result.setSndngDate(new Date());
        result.setReciptDate(new Date());
        result.setUpdtDate(new Date());
        result.setValidityCode(ValdtyCode.UNDER_CONSTRUCTION);
        return result;
    }

    public static List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document>
            convertMultipart(List<MultipartFile> fileList, String scope) {

        List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> result = new ArrayList<>();
        if (fileList != null) {
            // loop over the file list
            for (MultipartFile file : fileList) {
                if (file != null) {
                    com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document content = DocumentConverter
                            .convert(file, scope);
                    result.add(content);
                }
            }
        }
        return result;
    }

}
