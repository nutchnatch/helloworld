package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpp.cardif.sugar.rest.ui.model.BusinessScope;
import com.bnpp.cardif.sugar.rest.ui.model.BusinessScope.DefaultRetentionDateEnum;
import com.bnpp.cardif.sugar.rest.ui.model.DisplayNameItem;
import com.bnpp.cardif.sugar.rest.ui.model.DocumentIdentifier;
import com.bnpp.cardif.sugar.utils.DateUtils;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScopeId;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.MCOBusinessScope.FileData;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DefaultRetentionStartDateValue;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;

/**
 * 
 * @author 831743
 *
 */
public class BusinessScopeConverter {

    private static final Logger LOGGER = LoggerFactory.getLogger(BusinessScopeConverter.class);

    /**
     * private empty constructor
     */
    private BusinessScopeConverter() {
        // private constructor to avoid instance creation.
    }

    public static BusinessScope convert(
            com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope backendBusinessScope) {

        BusinessScope result = null;
        if (backendBusinessScope != null) {
            result = new BusinessScope();
            if (backendBusinessScope.getBusinessScopeId() != null) {
                result.setBusinessScopeId(backendBusinessScope.getBusinessScopeId().getValue());
            }
            if (backendBusinessScope.getCreationDate() != null) {
                result.setCreationDate(DateUtils.asZonedDateTime(backendBusinessScope.getCreationDate()));
            }
            result.setDefaultDocumentType(backendBusinessScope.getDefaultDocumentClass());
            result.setDefaultEnvelopeType(backendBusinessScope.getDefaultEnvelopClass());
            result.setDefaultFolderType(backendBusinessScope.getDefaultFolderClass());
            applyDefaultRetentionStartDate(backendBusinessScope, result);
            result.setDescription(backendBusinessScope.getDescription());
            List<DisplayNameItem> displayName = generateDisplayNameList(backendBusinessScope);
            result.setDisplayName(displayName);
            List<String> languages = new ArrayList<>();
            if (backendBusinessScope.getLanguages() != null && !backendBusinessScope.getLanguages().isEmpty()) {
                languages.addAll(backendBusinessScope.getLanguages());
            }
            result.setLanguages(languages);
            result.setOrganizationalUnit(backendBusinessScope.getOrganisationalUnit());
            List<String> preferredLanguages = new ArrayList<>();
            generatePreferedLanguageList(backendBusinessScope, preferredLanguages);
            result.setPreferredLanguages(preferredLanguages);
            result.setSymbolicName(backendBusinessScope.getSymbolicName());
            if (backendBusinessScope.getUpdateDate() != null) {
                result.setUpdateDate(DateUtils.asZonedDateTime(backendBusinessScope.getUpdateDate()));
            }
            DocumentIdentifier basketRuleFile = generateBasketRuleFile(backendBusinessScope);
            result.setBasketRuleFile(basketRuleFile);
            result.setEncryptionIdentifier(backendBusinessScope.getEncryptionIdentifier());
            result.setAvailableEncryptionIdentifiers(backendBusinessScope.getAvailableEncryptionIdentifiers());
        }
        return result;
    }

    private static DocumentIdentifier generateBasketRuleFile(
            com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope backendBusinessScope) {
        DocumentIdentifier basketRuleFile = null;
        FileData data = backendBusinessScope.getFileData();
        if (data != null) {
            basketRuleFile = new DocumentIdentifier();
            basketRuleFile.setId(data.getURI());
            DocumentFile documentFile = data.getDocumentFile();
            if (documentFile != null) {
                basketRuleFile.setName(documentFile.getName());
            }
        }
        return basketRuleFile;
    }

    private static void generatePreferedLanguageList(
            com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope backendBusinessScope,
            List<String> preferredLanguages) {
        List<MCOI18NLabel> preferedLang = backendBusinessScope.getPreferedLanguages();
        if (preferedLang != null) {
            for (MCOI18NLabel mcoi18nLabel : preferedLang) {
                preferredLanguages.add(mcoi18nLabel.getValue());
            }
        }
    }

    private static List<DisplayNameItem> generateDisplayNameList(
            com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope backendBusinessScope) {
        List<DisplayNameItem> displayName = new ArrayList<>();
        List<MCOI18NLabel> backendNameList = backendBusinessScope.getDisplayName();
        if (backendNameList != null) {
            for (MCOI18NLabel mcoi18nLabel : backendNameList) {
                DisplayNameItem name = new DisplayNameItem();
                name.setLanguage(mcoi18nLabel.getLanguage());
                name.setValue(mcoi18nLabel.getValue());
                displayName.add(name);
            }
        }
        return displayName;
    }

    private static void applyDefaultRetentionStartDate(
            com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope backendBusinessScope,
            BusinessScope result) {
        if (backendBusinessScope.getDefaultRetentionStartDate() != null
                && backendBusinessScope.getDefaultRetentionStartDate().value() != null) {
            DefaultRetentionDateEnum defaultRetentionDate = DefaultRetentionDateEnum
                    .valueOf(backendBusinessScope.getDefaultRetentionStartDate().value());
            result.setDefaultRetentionDate(defaultRetentionDate);
        }
    }

    public static com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope
            convert(BusinessScope businessScope) {

        com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope result = null;
        if (businessScope != null) {
            result = new com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope();
            if (businessScope.getBusinessScopeId() != null && !businessScope.getBusinessScopeId().isEmpty()) {
                BusinessScopeId businessScopeId = new BusinessScopeId(businessScope.getBusinessScopeId(), ConverterUtils.ISSUER,
                        ConverterUtils.SCHEME);
                result.setBusinessScopeId(businessScopeId);
            }
            if (businessScope.getCreationDate() != null) {
                result.setCreationDate(DateUtils.asDate(businessScope.getCreationDate()));
            }
            result.setDefaultDocumentClass(businessScope.getDefaultDocumentType());
            result.setDefaultEnvelopClass(businessScope.getDefaultEnvelopeType());
            result.setDefaultFolderClass(businessScope.getDefaultFolderType());
            if (businessScope.getDefaultRetentionDate() != null
                    && businessScope.getDefaultRetentionDate().name() != null) {
                try {
                DefaultRetentionStartDateValue defaultRetentionStartDate = DefaultRetentionStartDateValue
                        .fromValue(businessScope.getDefaultRetentionDate().name());
                result.setDefaultRetentionStartDate(defaultRetentionStartDate);
                } catch (IllegalArgumentException e) {
                    LOGGER.warn("Invalid value for DefaultRetentionStartDate, ignoring the value.", e);
                }
            }
            result.setDescription(businessScope.getDescription());
            addDisplayNameList(businessScope, result);
            List<String> languageList = result.getLanguages();
            List<String> langList = businessScope.getLanguages();
            languageList.addAll(langList);
            result.setOrganisationalUnit(businessScope.getOrganizationalUnit());
            addPreferedLanguageList(businessScope, result);
            result.setSymbolicName(businessScope.getSymbolicName());
            if (businessScope.getUpdateDate() != null) {
                result.setUpdateDate(DateUtils.asDate(businessScope.getUpdateDate()));
            }
            setBasketRuleFile(businessScope, result);
            result.setEncryptionIdentifier(businessScope.getEncryptionIdentifier());
        }
        return result;
    }

    private static void setBasketRuleFile(BusinessScope businessScope,
            com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope result) {
        if (businessScope.getBasketRuleFile() != null && businessScope.getBasketRuleFile().getId() != null
                && !businessScope.getBasketRuleFile().getId().isEmpty()) {
            FileData data = result.getFileData();
            if(data == null) {
                data = new FileData();
                result.setFileData(data);
            }
            data.setURI(businessScope.getBasketRuleFile().getId());
        }
    }

    private static void addPreferedLanguageList(BusinessScope businessScope,
            com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope result) {
        List<MCOI18NLabel> preferedLanguageList = result.getPreferedLanguages();
        List<String> preferedLang = businessScope.getPreferredLanguages();
        for (String string : preferedLang) {
            MCOI18NLabel content = new MCOI18NLabel(string, "");
            preferedLanguageList.add(content);
        }
    }

    private static void addDisplayNameList(BusinessScope businessScope,
            com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope result) {
        List<MCOI18NLabel> labelList = result.getDisplayName();
        List<DisplayNameItem> displayNameList = businessScope.getDisplayName();
        for (DisplayNameItem displayNameItem : displayNameList) {
            MCOI18NLabel content = new MCOI18NLabel(displayNameItem.getValue(), displayNameItem.getLanguage());
            labelList.add(content);
        }
    }

}
