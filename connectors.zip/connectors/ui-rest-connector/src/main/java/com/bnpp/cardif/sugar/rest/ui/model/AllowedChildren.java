package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class AllowedChildren implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("id")
    private String id = null;

    @JsonProperty("version")
    private int version;

    @JsonProperty("symbolicName")
    private String symbolicName = null;

    public AllowedChildren id(String id) {
        this.id = id;
        return this;
    }

    /**
     * ID
     * 
     * @return id
     **/
    @ApiModelProperty(value = "ID")
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public AllowedChildren version(int version) {
        this.version = version;
        return this;
    }

    /**
     * Version
     * 
     * @return version
     **/
    @ApiModelProperty(value = "Version")
    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public AllowedChildren symbolicName(String symbolicName) {
        this.symbolicName = symbolicName;
        return this;
    }

    /**
     * Symbolic name
     * 
     * @return symbolicName
     **/
    @ApiModelProperty(value = "Symbolic name")
    public String getSymbolicName() {
        return symbolicName;
    }

    public void setSymbolicName(String symbolicName) {
        this.symbolicName = symbolicName;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((symbolicName == null) ? 0 : symbolicName.hashCode());
        result = prime * result + version;
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override public boolean equals(Object o)
    {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        AllowedChildren that = (AllowedChildren) o;
        return version == that.version && Objects.equals(id, that.id) && Objects
                .equals(symbolicName, that.symbolicName);
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("AllowedChildren [id=");
        builder.append(id);
        builder.append(", version=");
        builder.append(version);
        builder.append(", symbolicName=");
        builder.append(symbolicName);
        builder.append("]");
        return builder.toString();
    }

}
