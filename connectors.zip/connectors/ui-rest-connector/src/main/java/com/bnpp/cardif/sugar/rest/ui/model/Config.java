package com.bnpp.cardif.sugar.rest.ui.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

/**
 *
 * Config object to be converted to json.
 *
 * @author a20257
 * @since 1.1.0
 */
public class Config implements Serializable {

    @JsonProperty("changePasswordUrl")
    private String changePasswordUrl;

    public void setChangePasswordUrl(String changePasswordUrl) {
        this.changePasswordUrl = changePasswordUrl;
    }

    public String getChangePasswordUrl() {
        return changePasswordUrl;
    }
}
