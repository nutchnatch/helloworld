package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.bnpp.cardif.sugar.rest.ui.model.BasketReporting;
import com.bnpp.cardif.sugar.rest.ui.model.DocumentReporting;
import com.bnpp.cardif.sugar.rest.ui.model.EnvelopeReporting;
import com.bnpp.cardif.sugar.rest.ui.model.FolderReporting;
import com.bnpp.cardif.sugar.rest.ui.model.ReportingSummary;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.BasketRatio;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.DocumentStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.EnvelopeFlows;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.FolderStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.Summary;

/**
 * 
 * @author 831743
 *
 */
public class ReportingConverter {

    public static final int BYTES_IN_MEGA = 1000000;

    /**
     * private empty constructor
     */
    private ReportingConverter() {
        // private constructor to avoid instance creation.
    }

    public static List<BasketReporting> convert(List<BasketRatio> basketRatioList) {

        List<BasketReporting> result = new ArrayList<>();
        if (basketRatioList != null) {
            for (BasketRatio basketRatio : basketRatioList) {
                BasketReporting content = ReportingConverter.convert(basketRatio);
                result.add(content);
            }
        }
        return result;
    }

    public static BasketReporting convert(BasketRatio basketRatio) {

        BasketReporting result = null;
        if (basketRatio != null) {
            result = new BasketReporting();
            if (basketRatio.getBasketId() != null) {
                result.setBasketId(basketRatio.getBasketId().getValue());
            }
            result.setNumberOfOpened(basketRatio.getNumberOfOpened());
            result.setNumberOfClosed(basketRatio.getNumberOfClosed());
        }
        return result;
    }

    public static List<DocumentReporting> convertDoc(List<DocumentStock> documentStockList) {

        List<DocumentReporting> result = new ArrayList<>();
        if (documentStockList != null) {
            for (DocumentStock documentStock : documentStockList) {
                DocumentReporting content = ReportingConverter.convertDoc(documentStock);
                result.add(content);
            }
        }
        return result;
    }

    public static DocumentReporting convertDoc(DocumentStock documentStock) {

        DocumentReporting result = null;
        if (documentStock != null) {
            result = new DocumentReporting();
            if (documentStock.getClassId() != null) {
                result.setClassId(documentStock.getClassId().getValue());
                result.setClassVersion(documentStock.getClassId().getVersId());
            }
            result.setNumberOfDocuments(documentStock.getNumberOfDocuments());
            final BigDecimal size = new BigDecimal(documentStock.getSizeOfFiles());
            result.setSizeOfFiles(size.setScale(2, BigDecimal.ROUND_HALF_DOWN).divide(new BigDecimal(BYTES_IN_MEGA), BigDecimal.ROUND_HALF_DOWN).doubleValue());
        }
        return result;
    }

    public static List<EnvelopeReporting> convertEnv(List<EnvelopeFlows> envelopeFlowsList) {

        List<EnvelopeReporting> result = new ArrayList<>();
        if (envelopeFlowsList != null) {
            for (EnvelopeFlows envelopeFlows : envelopeFlowsList) {
                EnvelopeReporting content = ReportingConverter.convertEnv(envelopeFlows);
                result.add(content);
            }
        }
        return result;
    }

    public static EnvelopeReporting convertEnv(EnvelopeFlows envelopeFlows) {

        EnvelopeReporting result = null;
        if (envelopeFlows != null) {
            result = new EnvelopeReporting();
            result.setDirectionCode(envelopeFlows.getDirectionCode());
            if (envelopeFlows.getClassId() != null) {
                result.setClassId(envelopeFlows.getClassId().getValue());
                result.setClassVersion(envelopeFlows.getClassId().getVersId());
            }
            result.setNumberOfEnvelopes(envelopeFlows.getNumberOfEnvelopes());
            result.setNumberOfDocuments(envelopeFlows.getNumberOfDocuments());
            final BigDecimal size = new BigDecimal(envelopeFlows.getSizeOfDocuments());
            result.setSizeOfDocuments(size.setScale(2, BigDecimal.ROUND_HALF_DOWN).divide(new BigDecimal(BYTES_IN_MEGA), BigDecimal.ROUND_HALF_DOWN).doubleValue());
        }
        return result;
    }

    public static List<FolderReporting> convertFolder(List<FolderStock> folderStockList) {

        List<FolderReporting> result = new ArrayList<>();
        if (folderStockList != null) {
            for (FolderStock folderStock : folderStockList) {
                FolderReporting content = ReportingConverter.convertFolder(folderStock);
                result.add(content);
            }
        }
        return result;
    }

    public static FolderReporting convertFolder(FolderStock folderStock) {

        FolderReporting result = null;
        if (folderStock != null) {
            result = new FolderReporting();
            if (folderStock.getClassId() != null) {
                result.setClassId(folderStock.getClassId().getValue());
                result.setClassVersion(folderStock.getClassId().getVersId());
            }
            result.setNumberOfFolders(folderStock.getNumberOfFolders());
        }
        return result;
    }

    public static ReportingSummary convertSummary(Summary summary) {
        ReportingSummary result = null;
        if(summary != null) {
            result = new ReportingSummary();
            result.setNumberOfDocuments(summary.getNumberOfDocuments());
            result.setNumberOfEnvelopes(summary.getNumbereOfEnvelopes());
            result.setNumberOfFolders(summary.getNumbereOfFolders());
            result.setNumberOfTasks(summary.getNumberOfTasks());
        }
        return result;
    }

}
