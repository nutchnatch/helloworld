package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class ReportingSummary implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @JsonProperty("numberOfDocuments")
    private long numberOfDocuments = 0;

    @JsonProperty("numberOfEnvelopes")
    private long numberOfEnvelopes = 0;

    @JsonProperty("numberOfFolders")
    private long numberOfFolders = 0;

    @JsonProperty("numberOfTasks")
    private long numberOfTasks = 0;

    public ReportingSummary numberOfDocuments(long numberOfDocuments) {
        this.numberOfDocuments = numberOfDocuments;
        return this;
    }

    /**
     * Number of documents.
     * 
     * @return numberOfDocuments
     **/
    @ApiModelProperty(required = true, value = "Number of documents.")
    @NotNull
    public long getNumberOfDocuments() {
        return numberOfDocuments;
    }

    public void setNumberOfDocuments(long numberOfDocuments) {
        this.numberOfDocuments = numberOfDocuments;
    }

    public ReportingSummary numberOfEnvelopes(long numberOfEnvelopes) {
        this.numberOfEnvelopes = numberOfEnvelopes;
        return this;
    }

    /**
     * Number of folder.
     * 
     * @return numberOfEnvelopes
     **/
    @ApiModelProperty(required = true, value = "Number of folder.")
    @NotNull
    public long getNumberOfEnvelopes() {
        return numberOfEnvelopes;
    }

    public void setNumberOfEnvelopes(long numberOfEnvelopes) {
        this.numberOfEnvelopes = numberOfEnvelopes;
    }

    public ReportingSummary numberOfFolders(long numberOfFolders) {
        this.numberOfFolders = numberOfFolders;
        return this;
    }

    /**
     * Number of folder.
     * 
     * @return numberOfFolders
     **/
    @ApiModelProperty(required = true, value = "Number of folder.")
    @NotNull
    public long getNumberOfFolders() {
        return numberOfFolders;
    }

    public void setNumberOfFolders(long numberOfFolders) {
        this.numberOfFolders = numberOfFolders;
    }

    public ReportingSummary numberOfTasks(long numberOfTasks) {
        this.numberOfTasks = numberOfTasks;
        return this;
    }

    /**
     * Number of Tasks.
     * 
     * @return numberOfTasks
     **/
    @ApiModelProperty(required = true, value = "Number of Tasks.")
    @NotNull
    public long getNumberOfTasks() {
        return numberOfTasks;
    }

    public void setNumberOfTasks(long numberOfTasks) {
        this.numberOfTasks = numberOfTasks;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (numberOfDocuments ^ (numberOfDocuments >>> 32));
        result = prime * result + (int) (numberOfEnvelopes ^ (numberOfEnvelopes >>> 32));
        result = prime * result + (int) (numberOfFolders ^ (numberOfFolders >>> 32));
        result = prime * result + (int) (numberOfTasks ^ (numberOfTasks >>> 32));
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof ReportingSummary))
            return false;
        ReportingSummary other = (ReportingSummary) obj;
        if (numberOfDocuments != other.numberOfDocuments)
            return false;
        if (numberOfEnvelopes != other.numberOfEnvelopes)
            return false;
        if (numberOfFolders != other.numberOfFolders)
            return false;
        if (numberOfTasks != other.numberOfTasks)
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("ReportingSummary [numberOfDocuments=");
        builder.append(numberOfDocuments);
        builder.append(", numberOfEnvelopes=");
        builder.append(numberOfEnvelopes);
        builder.append(", numberOfFolders=");
        builder.append(numberOfFolders);
        builder.append(", numberOfTasks=");
        builder.append(numberOfTasks);
        builder.append("]");
        return builder.toString();
    }

}
