package com.bnpp.cardif.sugar.rest.ui.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.TasksService;
import com.bnpp.cardif.sugar.rest.ui.api.TasksApi;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.TaskConverter;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpp.cardif.sugar.rest.ui.model.Task;

import io.swagger.annotations.ApiParam;

@Controller
@RequestMapping("/v1")
public class TasksController extends FrontendController implements TasksApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(TasksController.class);

    @Autowired
    private TasksService tasksService;

    @RequestMapping(value = "/tasks/{taskId}", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Task>> getTaskByID(
            @ApiParam(value = "Identifier of the task", required = true) @PathVariable("taskId") String taskId,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getTaskByID called");
        RestResponse<Task> restResponse = new RestResponse<>();
        try {
            com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task backendTask = tasksService.getTaskByID(taskId);
            // transform service result into JSON response
            Task task = null;
            if (backendTask != null) {
                task = TaskConverter.convert(backendTask);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<Task> valueList = new ArrayList<>();
            valueList.add(task);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getTaskByID end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/tasks/{taskId}/transfer", produces = { "application/json; charset=UTF-8" }, consumes = {
            "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<String>> transferTask(
            @ApiParam(value = "Identifier of the task", required = true) @PathVariable("taskId") String taskId,
            @ApiParam(value = "Identifier of the destination basket", required = true) @RequestBody String basketId,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("transferTask called");
        RestResponse<String> restResponse = new RestResponse<>();
        try {
            String updatedTaskId = tasksService.transferTask(taskId, basketId);
            // transform service result into JSON response
            if (updatedTaskId == null || updatedTaskId.isEmpty()) {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<String> valueList = new ArrayList<>();
            valueList.add(updatedTaskId);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("transferTask end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/tasks/{taskId}/lock", produces = { "application/json; charset=UTF-8" }, consumes = {
            "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<String>> lockTask(
            @ApiParam(value = "Identifier of the task", required = true) @PathVariable("taskId") String taskId,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("lockTask called");
        RestResponse<String> restResponse = new RestResponse<>();
        try {
            String updatedTaskId = tasksService.lockTask(taskId);
            // transform service result into JSON response
            if (updatedTaskId == null || updatedTaskId.isEmpty()) {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<String> valueList = new ArrayList<>();
            valueList.add(updatedTaskId);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("lockTask end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/tasks/{taskId}/unlock", produces = { "application/json; charset=UTF-8" }, consumes = {
            "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<String>> unlockTask(
            @ApiParam(value = "Identifier of the task", required = true) @PathVariable("taskId") String taskId,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("unlockTask called");
        RestResponse<String> restResponse = new RestResponse<>();
        try {
            String updatedTaskId = tasksService.unlockTask(taskId);
            // transform service result into JSON response
            if (updatedTaskId == null || updatedTaskId.isEmpty()) {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<String> valueList = new ArrayList<>();
            valueList.add(updatedTaskId);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("unlockTask end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/tasks/{taskId}/status", produces = { "application/json; charset=UTF-8" }, consumes = {
            "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<String>> updateTaskStatus(
            @ApiParam(value = "Identifier of the task", required = true) @PathVariable("taskId") String taskId,
            @ApiParam(value = "Status to apply to the task", required = true, allowableValues = "NEW, PENDING, CLOSE") @RequestBody String status,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("updateTaskStatus called");
        RestResponse<String> restResponse = new RestResponse<>();
        try {
            String updatedStatus = tasksService.updateTaskStatus(taskId, status);
            // transform service result into JSON response
            if (updatedStatus == null || updatedStatus.isEmpty()) {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<String> valueList = new ArrayList<>();
            valueList.add(updatedStatus);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("updateTaskStatus end");
        return ResponseEntity.ok(restResponse);
    }

}
