package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * ErrorStack
 */
public class ErrorStack implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("code")
    private String code = null;

    @JsonProperty("message")
    private String message = null;

    @JsonProperty("detail")
    private String detail = null;

    public ErrorStack code(String code) {
        this.code = code;
        return this;
    }

    /**
     * Error code.
     * 
     * @return code
     **/
    @ApiModelProperty(value = "Error code.")

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public ErrorStack message(String message) {
        this.message = message;
        return this;
    }

    /**
     * Error detail message.
     * 
     * @return message
     **/
    @ApiModelProperty(value = "Error detail message.")

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ErrorStack detail(String detail) {
        this.detail = detail;
        return this;
    }

    /**
     * Get detail
     * 
     * @return detail
     **/
    @ApiModelProperty(value = "")

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((code == null) ? 0 : code.hashCode());
        result = prime * result + ((detail == null) ? 0 : detail.hashCode());
        result = prime * result + ((message == null) ? 0 : message.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof ErrorStack))
            return false;
        ErrorStack other = (ErrorStack) obj;
        if (code == null) {
            if (other.code != null)
                return false;
        }
        else if (!code.equals(other.code))
            return false;
        if (detail == null) {
            if (other.detail != null)
                return false;
        }
        else if (!detail.equals(other.detail))
            return false;
        if (message == null) {
            if (other.message != null)
                return false;
        }
        else if (!message.equals(other.message))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("ErrorStack [code=");
        builder.append(code);
        builder.append(", message=");
        builder.append(message);
        builder.append(", detail=");
        builder.append(detail);
        builder.append("]");
        return builder.toString();
    }

}
