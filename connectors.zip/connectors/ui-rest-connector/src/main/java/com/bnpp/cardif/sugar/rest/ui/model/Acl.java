package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class Acl implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("aclId")
    private String aclId = null;

    @JsonProperty("name")
    private String name = null;

    @JsonProperty("isInstanceValue")
    private boolean isInstanceValue;

    public Acl aclId(String aclId) {
        this.aclId = aclId;
        return this;
    }

    /**
     * Identifies uniquely an ACL.
     * 
     * @return aclId
     **/
    @ApiModelProperty(required = true, value = "Identifies uniquely an ACL.")
    @NotNull
    public String getAclId() {
        return aclId;
    }

    public void setAclId(String aclId) {
        this.aclId = aclId;
    }

    public Acl name(String name) {
        this.name = name;
        return this;
    }

    /**
     * ACL name.
     * 
     * @return name
     **/
    @ApiModelProperty(required = true, value = "ACL name.")
    @NotNull
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Acl isInstanceValue(boolean isInstanceValue) {
        this.isInstanceValue = isInstanceValue;
        return this;
    }

    /**
     * Indicate if the ACL apply to instance or to classes
     * 
     * @return isInstanceValue
     **/
    @ApiModelProperty(required = true, value = "Identifies uniquely an ACL.")
    @NotNull
    public boolean getIsInstanceValue() {
        return isInstanceValue;
    }

    public void setIsInstanceValue(boolean isInstanceValue) {
        this.isInstanceValue = isInstanceValue;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((aclId == null) ? 0 : aclId.hashCode());
        result = prime * result + (isInstanceValue ? 1231 : 1237);
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof Acl))
            return false;
        Acl other = (Acl) obj;
        if (aclId == null) {
            if (other.aclId != null)
                return false;
        }
        else if (!aclId.equals(other.aclId))
            return false;
        if (isInstanceValue != other.isInstanceValue)
            return false;
        if (name == null) {
            if (other.name != null)
                return false;
        }
        else if (!name.equals(other.name))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Acl [aclId=");
        builder.append(aclId);
        builder.append(", name=");
        builder.append(name);
        builder.append(", isInstanceValue=");
        builder.append(isInstanceValue);
        builder.append("]");
        return builder.toString();
    }

}
