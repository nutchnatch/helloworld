package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;

import com.bnpp.cardif.sugar.rest.ui.model.CurrentUser;
import com.bnpp.cardif.sugar.security.AuthenticatedUser;

public class CurrentUserConverter {

    /**
     * private empty constructor
     */
    private CurrentUserConverter() {
        // private constructor to avoid instance creation.
    }

    /**
     * Convert AuthenticatedUser into CurrentUser
     * 
     * @param authenticatedUser
     * @return CurrentUser
     */
    public static CurrentUser convert(AuthenticatedUser authenticatedUser) {
        CurrentUser result = null;
        if (authenticatedUser != null) {
            result = new CurrentUser();
            if (authenticatedUser.getAuthorities() != null) {
                List<String> authorities = new ArrayList<>();
                for (GrantedAuthority grantedAuthority : authenticatedUser.getAuthorities()) {
                    if (grantedAuthority != null) {
                        authorities.add(grantedAuthority.getAuthority());
                    }
                }
                result.setAuthorities(authorities);
            }
            if (authenticatedUser.getBusinessScopes() != null) {
                List<String> businessScopes = new ArrayList<>();
                for (String scope : authenticatedUser.getBusinessScopes()) {
                    businessScopes.add(scope);
                }
                result.setBusinessScopes(businessScopes);
            }
            result.setCommercialVersion(authenticatedUser.getCommercialVersion());
            result.setCurrentBusinessScope(authenticatedUser.getCurrentBusinessScope());
            result.setFirstName(authenticatedUser.getFirstName());
            result.setLastName(authenticatedUser.getLastName());
            result.setUsername(authenticatedUser.getUsername());
        }
        return result;
    }

}
