package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Represents the details of the response, the error part is filled in cas of
 * error and the result part is filled in case of success.
 */
@ApiModel(description = "Represents the details of the response, the error part is filled in cas of error and the result part is filled in case of success.")
public class RestResponse<E extends Serializable> implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("status")
    private Boolean status = null;

    @JsonProperty("error")
    private ErrorCause error = null;

    @JsonProperty("result")
    private List<E> result = new ArrayList<>();

    @JsonProperty("paging")
    private Paging paging = null;

    public RestResponse<E> status(Boolean status) {
        this.status = status;
        return this;
    }

    /**
     * Global status of the response. True means success, missing status or
     * false means failure.
     * 
     * @return status
     **/
    @ApiModelProperty(required = true, value = "Global status of the response. True means success, missing status or false means failure.")
    @NotNull
    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public RestResponse<E> error(ErrorCause error) {
        this.error = error;
        return this;
    }

    /**
     * Get error
     * 
     * @return error
     **/
    @ApiModelProperty(value = "")
    @Valid
    public ErrorCause getError() {
        return error;
    }

    public void setError(ErrorCause error) {
        this.error = error;
    }

    public RestResponse<E> result(List<E> result) {
        this.result = result;
        return this;
    }

    public RestResponse<E> addResultItem(E resultItem) {
        if (this.result == null) {
            this.result = new ArrayList<>();
        }
        this.result.add(resultItem);
        return this;
    }

    /**
     * Get result
     * 
     * @return result
     **/
    @ApiModelProperty(value = "")
    @Valid
    public List<E> getResult() {
        return result;
    }

    public void setResult(List<E> result) {
        this.result = result;
    }

    public RestResponse<E> paging(Paging paging) {
        this.paging = paging;
        return this;
    }

    /**
     * Get paging
     * 
     * @return paging
     **/
    @ApiModelProperty(value = "")
    @Valid
    public Paging getPaging() {
        return paging;
    }

    public void setPaging(Paging paging) {
        this.paging = paging;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int res = 1;
        res = prime * res + ((error == null) ? 0 : error.hashCode());
        res = prime * res + ((paging == null) ? 0 : paging.hashCode());
        res = prime * res + ((this.result == null) ? 0 : this.result.hashCode());
        res = prime * res + ((status == null) ? 0 : status.hashCode());
        return res;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */

    @Override public boolean equals(Object o)
    {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        RestResponse<?> that = (RestResponse<?>) o;
        return Objects.equals(status, that.status) && Objects.equals(error, that.error) && Objects
                .equals(result, that.result) && Objects.equals(paging, that.paging);
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("RestResponse [status=");
        builder.append(status);
        builder.append(", error=");
        builder.append(error);
        builder.append(", result=");
        builder.append(result);
        builder.append(", paging=");
        builder.append(paging);
        builder.append("]");
        return builder.toString();
    }

}
