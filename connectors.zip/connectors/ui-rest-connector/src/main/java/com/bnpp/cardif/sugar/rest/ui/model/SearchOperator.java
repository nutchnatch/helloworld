package com.bnpp.cardif.sugar.rest.ui.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum SearchOperator {

    NOT_EQUALS_TO, EQUALS_TO, CONTAINS, LESS_THAN, GREATER_THAN, STARTS_WITH, ENDS_WITH, BETWEEN;
    
    @JsonCreator
    public static SearchOperator fromString(String name) {
        return SearchOperator.valueOf(name.toUpperCase());
    }
    
    @JsonValue
    public String getName() {
        return name().toLowerCase();
    }

}
