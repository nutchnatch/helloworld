package com.bnpp.cardif.sugar.rest.ui.model;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Stream;

public enum ReportFolder
{
    CLASS   (0,  "Class", FolderReporting::getClassId),
    CREATED   (1,  "Created", FolderReporting::getNumberOfFolders);

    private static final Function<Workbook, CellStyle>  headerStyler = workbook ->
    {
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 12);

        CellStyle headerStyle = workbook.createCellStyle();
        headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerStyle.setFont(headerFont);

        return headerStyle;
    };

    private final int index;
    private final String header;
    private final Function<FolderReporting, Object> getter;

    ReportFolder(int index, String header, Function<FolderReporting, Object> getter)
    {
        this.index = index;
        this.header = header;
        this.getter = getter;
    }

    public static void fill(XSSFWorkbook workbook, List<FolderReporting> data)
    {
        final XSSFSheet sheet = workbook.createSheet("report");

        int rowNum = 0;

        final CellStyle headerStyle = headerStyler.apply(workbook);

        Row row = sheet.createRow(rowNum);
        Stream.of(ReportFolder.values())
            .forEach(tr ->{
                Cell cell = row.createCell(tr.index);
                cell.setCellValue(tr.header);
                cell.setCellStyle(headerStyle);
            });

        for (final FolderReporting entry : data)
        {
            Row rowReport = sheet.createRow(++rowNum);

            Stream.of(ReportFolder.values())
                .forEach(report -> {
                    Cell cell = rowReport.createCell(report.index);

                    Object value = report.getter.apply(entry);

                    cell.setCellValue(value!=null?value.toString():"");
                });
        }

        Stream.of(ReportFolder.values())
            .forEach(tr -> sheet.autoSizeColumn(tr.index));
    }
}
