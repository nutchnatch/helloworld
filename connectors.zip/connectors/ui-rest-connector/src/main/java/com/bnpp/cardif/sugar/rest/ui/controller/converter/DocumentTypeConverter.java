package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.bnpp.cardif.sugar.rest.ui.model.AssociatedTag;
import com.bnpp.cardif.sugar.rest.ui.model.DisplayNameItem;
import com.bnpp.cardif.sugar.rest.ui.model.DocumentType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DurationType;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOTagReference;

/**
 * 
 * @author 831743
 *
 */
public class DocumentTypeConverter {
    /**
     * private empty constructor
     */
    private DocumentTypeConverter() {
        // private constructor to avoid instance creation.
    }

    public static DocumentType convert(DocumentClass documentClass) {
        DocumentType result = null;
        if (documentClass != null) {
            result = new DocumentType();
            convertVersionData(documentClass, result);
            result.setName(documentClass.getLongLabel());
            result.setActive(documentClass.isActive());
            convertLabelList(documentClass, result);
            convertTagList(documentClass, result);
            DurationType durationType = documentClass.getRetentionDuration();
            if (durationType != null) {
                result.setRetentionDurationUnit(durationType.getTimeUnit());
                result.setRetentionDurationValue(durationType.getValue().intValue());
            }
        }
        return result;
    }

    private static void convertTagList(DocumentClass documentClass, DocumentType result)
    {
        ConverterUtils.convertTagList(documentClass, result::getTagList);
    }

    private static void convertLabelList(DocumentClass documentClass, DocumentType result)
    {
        ConverterUtils.convertLabelList(documentClass, result::getDisplayNameList);
    }

    private static void convertVersionData(DocumentClass documentClass, DocumentType result) {
        Optional.ofNullable(documentClass.getClassId()).ifPresent(classId -> {
            result.setId(classId.getValue());
            result.setVersion(classId.getVersId());
        });
    }

    public static List<DocumentType> convert(List<DocumentClass> documentClassList) {

        final List<DocumentType> result = new ArrayList<>();
        Optional.ofNullable(documentClassList).ifPresent(docClassList -> result.addAll(getDocumentTypeList(docClassList)));
        return result;
    }

    private static List<DocumentType> getDocumentTypeList(List<DocumentClass> documentClassList) {
        return documentClassList.stream()
            .map(DocumentTypeConverter::convert)
            .collect(Collectors.toList());
    }

    public static DocumentClass convert(DocumentType documentType, String scope) {

        DocumentClass result = null;
        if (documentType != null) {
            result = new DocumentClass();
            ClassId classId = new ClassId(documentType.getId(), ConverterUtils.ISSUER, documentType.getVersion());
            result.setClassId(classId);
            result.setActive(documentType.getActive());
            result.setLongLabel(documentType.getName());
            DurationType retentionDuration = new DurationType(
                    BigInteger.valueOf(documentType.getRetentionDurationValue()),
                    documentType.getRetentionDurationUnit());
            result.setRetentionDuration(retentionDuration);
            result.setScope(scope);
            setLabelList(documentType, result);
            setTagList(documentType, result);
        }
        return result;
    }

    private static void setTagList(DocumentType documentType, DocumentClass result) {
        List<MCOTagReference> tagList = result.getTagReference();
        List<AssociatedTag> associatedTagList = documentType.getTagList();
        if (associatedTagList != null) {
            for (AssociatedTag associatedTag : associatedTagList) {
                MCOTagReference content = new MCOTagReference(associatedTag.getSymbolicName(),
                        associatedTag.getMandatory(), associatedTag.getMultivalued());
                tagList.add(content);
            }
        }
    }

    private static void setLabelList(DocumentType documentType, DocumentClass result) {
        List<MCOI18NLabel> labelList = result.getShortLabel();
        List<DisplayNameItem> displayNameList = documentType.getDisplayNameList();
        if (displayNameList != null) {
            for (DisplayNameItem displayNameItem : displayNameList) {
                MCOI18NLabel label = new MCOI18NLabel(displayNameItem.getValue(), displayNameItem.getLanguage());
                labelList.add(label);
            }
        }
    }

}
