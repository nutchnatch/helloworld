package com.bnpp.cardif.sugar.rest.ui.model;

import com.bnpp.cardif.sugar.utils.DateUtils;
import com.bnpparibas.assurance.sugar.internal.service.app.track.v1.Track;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Stream;

public enum TrackReport
{
    OBJ_ID   (0,  "Object ID",   Track::getObjectId),
    USR_ID   (1,  "User ID",     Track::getUserId),
    ACTION   (2,  "Action",      Track::getAction),
    ACT_DT   (3,  "Action Date (UTC)",
        track -> DateUtils.toStringDate(track.getActionDate()),
        (workbook, rowTrack, trackReport, track) ->
        {
            Cell cell = rowTrack.createCell(trackReport.index);

            CellStyle cellStyle = workbook.createCellStyle();
            cellStyle.setDataFormat(workbook.getCreationHelper().createDataFormat().getFormat("dd/mm/yyyy hh:mm:ss"));

            cell.setCellValue(trackReport.getter.apply(track));

            cell.setCellStyle(cellStyle);
            return true;
        }),
    OBJ_NAME (4,  "Object Name", Track::getObjectName),
    OBJ_TYPE (5,  "Object Type", Track::getObjectType),
    SCOPE    (6,  "Scope",       Track::getAppScope),
    APPLI    (7,  "Application", Track::getAppName),
    DEST_ID  (8,  "Destination ID", Track::getDestinationId),
    DEST_NAME(9,  "Destination Name", Track::getDestinationName),
    DESC     (10, "Description", Track::getLogText),
    LOG_LVL  (11, "Level",       Track::getLogLevel);

    private static final Function<Workbook, CellStyle>  headerStyler = workbook ->
    {
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 12);

        CellStyle headerStyle = workbook.createCellStyle();
        headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerStyle.setFont(headerFont);

        return headerStyle;
    };

    private static final int CELL_MAX_SIZE = 32760;

    private final int index;
    private final String header;
    private final Function<Track, String> getter;
    private final FunctionalWithFourArguments<XSSFWorkbook, Row, TrackReport, Track, Boolean> setter;

    TrackReport(int index, String header, Function<Track, String> getter)
    {
        this.index = index;
        this.header = header;
        this.getter = getter;
        this.setter = (ignored, rowTrack, trackReport, track) ->
        {
            Cell cell = rowTrack.createCell(trackReport.index);

            String value = trackReport.getter.apply(track);

            if(value!= null && value.length() > CELL_MAX_SIZE)
            {
                value = trackReport.getter.apply(track)
                    .substring(0, CELL_MAX_SIZE)
                    .concat("(...)");
            }

            cell.setCellValue(value);
            return true;
        };
    }

    @SuppressWarnings("unused")
    TrackReport(int index, String header, Function<Track, String> getter, FunctionalWithFourArguments<XSSFWorkbook, Row, TrackReport, Track, Boolean> setter)
    {
        this.index = index;
        this.header = header;
        this.getter = getter;
        this.setter = setter;
    }

    public static void fill(XSSFWorkbook workbook, List<Track> tracks)
    {
        final XSSFSheet sheet = workbook.createSheet("report");

        int rowNum = 0;

        final CellStyle headerStyle = headerStyler.apply(workbook);

        Row row = sheet.createRow(rowNum);
        Stream.of(TrackReport.values())
            .forEach(tr ->{
                Cell cell = row.createCell(tr.index);
                cell.setCellValue(tr.header);
                cell.setCellStyle(headerStyle);
            });

        for (final Track track : tracks)
        {
            Row rowTrack = sheet.createRow(++rowNum);
            Stream.of(TrackReport.values())
                .forEach(trackReport -> trackReport.setter.apply(workbook, rowTrack, trackReport, track));
        }

        Stream.of(TrackReport.values())
            .forEach(tr -> sheet.autoSizeColumn(tr.index));
    }
}
