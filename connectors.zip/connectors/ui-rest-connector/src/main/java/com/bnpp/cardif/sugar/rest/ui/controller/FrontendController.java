package com.bnpp.cardif.sugar.rest.ui.controller;

import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.rest.ui.model.*;
import com.bnpp.cardif.sugar.security.AuthenticatedUser;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.io.IOException;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FrontendController {

    private static final String SEPARATOR_REGEX = "\\|";
    
    private static final String VALUE_SEPARATOR_REGEX = "#";

    private static final Logger PARENT_LOGGER = LoggerFactory.getLogger(FrontendController.class);

    /**
     * Get user scope.
     * 
     * @return the scope to get
     * @throws TechnicalException
     */
    protected String getScope() throws TechnicalException {

        String scope = null;

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            AuthenticatedUser springAuthenticatedUser = (AuthenticatedUser) authentication.getPrincipal();
            scope = springAuthenticatedUser.getCurrentBusinessScope();
        }
        else {
            PARENT_LOGGER.warn("No Authentication found");
            throw new TechnicalException(ErrorCode.TE002);
        }
        return scope;
    }

    protected <T extends Serializable> void generateTechnicalExceptionResponse(RestResponse<T> restResponse,
            IOException e) {
        restResponse.setStatus(false);
        ErrorCause errorCause = new ErrorCause();
        errorCause.setCode(ErrorCode.TE003.getCode());
        errorCause.setErrorDate(ZonedDateTime.now());
        errorCause.setMessage("Technical error : " + e.getMessage());
        restResponse.setError(errorCause);
    }

    protected <T extends Serializable> void generateTechnicalExceptionResponse(RestResponse<T> restResponse,
            TechnicalException e) {
        restResponse.setStatus(false);
        ErrorCause errorCause = new ErrorCause();
        errorCause.setCode(e.getCode());
        errorCause.setErrorDate(ZonedDateTime.now());
        errorCause.setMessage("Technical error : " + e.getMessage());
        restResponse.setError(errorCause);
    }

    protected <T extends Serializable> void generateFunctionalExceptionResponse(RestResponse<T> restResponse,
            FunctionalException e) {
        restResponse.setStatus(false);
        ErrorCause errorCause = new ErrorCause();
        errorCause.setCode(e.getCode());
        errorCause.setErrorDate(ZonedDateTime.now());
        errorCause.setMessage("Functional error : " + e.getMessage());
        restResponse.setError(errorCause);
    }

    protected Operators mapOperators(SearchOperator uiOpereator) {
        Operators result = null;
        switch (uiOpereator) {
        case NOT_EQUALS_TO:
            result = Operators.NOT_EQUALS_TO;
            break;
        case EQUALS_TO:
            result = Operators.EQUALS_TO;
            break;
        case LESS_THAN:
            result = Operators.LESS_THAN;
            break;
        case GREATER_THAN:
            result = Operators.GREATER_THAN;
            break;
        case STARTS_WITH:
            result = Operators.STARTS_WITH;
            break;
        case ENDS_WITH:
            result = Operators.ENDS_WITH;
            break;
        case CONTAINS:
            result = Operators.CONTAINS;
            break;
        case BETWEEN:
            result = Operators.BETWEEN;
            break;
        default:
            result = Operators.STARTS_WITH;
            break;
        }
        return result;
    }

    protected Types mapTagType(TagType tagType) {
        Types result = null;
        switch (tagType) {
        case BOOLEAN:
            result = Types.BOOLEAN;
            break;
        case INTEGER:
            result = Types.INTEGER;
            break;
        case TIMESTAMP:
            result = Types.TIMESTAMP;
            break;
        case FLOAT:
            result = Types.FLOAT;
            break;
        case STRING:
        case CHOICELIST:
        default:
            result = Types.STRING;
            break;
        }
        return result;
    }

    protected OrderClause generateOrderClauseFromInput(Boolean ascending, String orderField, String tagName)
            throws InvalidInputException {

        OrderClause result = null;
        if (ascending != null && orderField != null && !orderField.isEmpty()) {
            try {
                boolean ascendingBoll = ascending.booleanValue();
                OrderField orderFieldEnum = OrderField.fromString(orderField);
                result = this.generateOrderClause(ascendingBoll, orderFieldEnum, tagName);
            }
            catch (IllegalArgumentException | NullPointerException | DateTimeParseException e) {
                PARENT_LOGGER.warn("invalid ordering input : {}", orderField, e);
                // Invalids tag structure, add to the invalid list.
                throw new InvalidInputException(ErrorCode.IIE007.getCode(), ErrorCode.IIE007.getMessage() + orderField, e);
            }
        }
        return result;
    }

    @SuppressWarnings("squid:MethodCyclomaticComplexity")
    private OrderClause generateOrderClause(boolean ascending, OrderField orderField, String tagName) {
        OrderClause result;
        result = new OrderClause();
        result.setAscending(ascending);
        switch (orderField) {
        case NAME:
            result.setLevel(Levels.DATA);
            result.setName("Name");
            result.setType(Types.STRING);
            break;
        case VALIDITY_CODE:
            result.setLevel(Levels.DATA);
            result.setName("ValidityCode");
            result.setType(Types.STRING);
            break;
        case CREATOR:
            result.setLevel(Levels.DATA);
            result.setName("Creator");
            result.setType(Types.STRING);
            break;
        case LAST_MODIFIER:
            result.setLevel(Levels.DATA);
            result.setName("LastModifier");
            result.setType(Types.STRING);
            break;
        case UPDATE_DATE:
            result.setLevel(Levels.DATA);
            result.setName("UpdtDate");
            result.setType(Types.TIMESTAMP);
            break;
        case CONFIDENTIALITY:
            result.setLevel(Levels.DATA);
            result.setName("ConfdntltyLvl");
            result.setType(Types.STRING);
            break;
        case TAG:
            result.setLevel(Levels.TAG);
            result.setName(tagName);
            result.setType(Types.STRING);
            break;
        case CREATION_DATE:
        default:
            result.setLevel(Levels.DATA);
            result.setName("CreatnDate");
            result.setType(Types.TIMESTAMP);
            break;
        }
        return result;
    }

    @SuppressWarnings("squid:S00107")
    protected List<Criterion> generateCriterionListFromInput(final String creationDateCriteria, final String updateDateCriteria,
            final String creatorCriteria, final String lastModifierCriteria, final List<String> docTypeIdsCriteria, final String nameCriteria,
            final String validityCriteria, final String confidentialityCriteria, final List<String> tags, final String statusCode) throws InvalidInputException {

        final List<Criterion> result = new ArrayList<>();
        this.addTagListCriterion(result, tags);
        this.addDocTypeIdsCriterion(result, docTypeIdsCriteria);
        this.addDataCriterion(result, creationDateCriteria, "CreatnDate", Types.TIMESTAMP);
        this.addDataCriterion(result, updateDateCriteria, "UpdtDate", Types.TIMESTAMP);
        this.addDataCriterion(result, creatorCriteria, "Creator", Types.STRING);
        this.addDataCriterion(result, lastModifierCriteria, "LastModifier", Types.STRING);
        this.addDataCriterion(result, nameCriteria, "Name", Types.STRING);
        this.addDataCriterion(result, validityCriteria, "ValidityCode", Types.STRING);
        this.addDataCriterion(result, confidentialityCriteria, "ConfdntltyLvl", Types.STRING);
        this.addDataCriterion(result, statusCode, "StatusCode", Types.STRING);
        return result;
    }

    private void addDocTypeIdsCriterion(List<Criterion> result, List<String> docTypeIds) {
        if (docTypeIds != null && !docTypeIds.isEmpty()) {
            Criterion criterion = new Criterion();
            criterion.setLevel(Levels.DATA);
            criterion.setName("ClassId");
            criterion.setOperator(Operators.EQUALS_TO);
            criterion.setType(Types.STRING);
            List<String> valueList = criterion.getValues();
            if (valueList == null) {
                valueList = new ArrayList<>();
            }
            valueList.addAll(docTypeIds);
            result.add(criterion);
        }
        else {
            PARENT_LOGGER.warn("docTypeIds value is null.");
        }
    }

    private void addTagListCriterion(List<Criterion> result, List<String> tags) throws InvalidInputException {

        List<String> invalidTags = new ArrayList<>();
        if (tags != null && !tags.isEmpty()) {
            // looping on the tag list
            for (String tagSearchElement : tags) {
                addTagCriterion(result, invalidTags, tagSearchElement);
            }
            // If One tag is wrong return an error
            if (!invalidTags.isEmpty()) {
                throw new InvalidInputException(ErrorCode.IIE007.getCode(),
                        ErrorCode.IIE007.getMessage() + invalidTags);
            }
        }
        else {
            PARENT_LOGGER.warn("TagList is null or empty.");
        }
    }

    private void addTagCriterion(List<Criterion> result, List<String> invalidTags, String tagSearchElement) {

        // Split the tag String to get the various parts
        String[] tagElements = tagSearchElement.split(SEPARATOR_REGEX);
        String errorMessage = "invalid Tag : {}";
        if (tagElements == null || tagElements.length != 4) {
            PARENT_LOGGER.warn(errorMessage, tagSearchElement);
            // Invalids tag structure, add to the invalid list.
            invalidTags.add(tagSearchElement);
        }
        else {
            // processing tag
            try {
                TagType tagType = TagType.fromString(tagElements[1]);
                SearchOperator critOperator = SearchOperator.fromString(tagElements[2]);
                Criterion criterion = new Criterion();
                criterion.setLevel(Levels.TAG);
                criterion.setName(tagElements[0]);
                criterion.setOperator(this.mapOperators(critOperator));
                criterion.setType(this.mapTagType(tagType));
                // In case of multiple value, split the sent string
                String[] tagValues = tagElements[3].split(VALUE_SEPARATOR_REGEX);
                List<String> valueList = criterion.getValues();
                for (String tagValue : tagValues) {
                    PARENT_LOGGER.debug("Adding value to tag criterion name: {} value : {}", tagElements[0], tagValue);
                    valueList.add(tagValue);
                }
                result.add(criterion);
            }
            catch (IllegalArgumentException | NullPointerException e) {
                PARENT_LOGGER.warn(errorMessage, tagSearchElement, e);
                // Invalids tag structure, add to the invalid list.
                invalidTags.add(tagSearchElement);
            }
        }
    }

    private void addDataCriterion(List<Criterion> result, String inputCriteria, String fieldName, Types fieldType)
            throws InvalidInputException {
        if (inputCriteria != null && !inputCriteria.isEmpty()) {
            // split creationDateCriteria using separator
            String[] inputElements = inputCriteria.split(SEPARATOR_REGEX);
            if (inputElements.length != 2) {
                PARENT_LOGGER.warn("invalid inputCriteria : {}", inputCriteria);
                // Invalids tag structure, add to the invalid list.
                throw new InvalidInputException(ErrorCode.IIE007.getCode(),
                        ErrorCode.IIE007.getMessage() + inputCriteria);
            }
            else {
                processCriteria(result, inputCriteria, fieldName, fieldType, inputElements);
            }
        }
        else {
            PARENT_LOGGER.warn("inputCriteria is null for field : {}.", fieldName);
        }
    }

    private void processCriteria(List<Criterion> result, String inputCriteria, String fieldName, Types fieldType,
            String[] inputElements) throws InvalidInputException {
        // processing criteria
        try {
            SearchOperator critOperator = SearchOperator.fromString(inputElements[0]);
            Criterion criterion = new Criterion();
            criterion.setLevel(Levels.DATA);
            criterion.setName(fieldName);
            criterion.setOperator(this.mapOperators(critOperator));
            criterion.setType(fieldType);
            List<String> valueList = criterion.getValues();
            if (valueList == null) {
                valueList = new ArrayList<>();
            }

            valueList.addAll(Arrays.asList(inputElements[1].split(VALUE_SEPARATOR_REGEX)));
            result.add(criterion);
        }
        catch (IllegalArgumentException | NullPointerException | DateTimeParseException e) {
            PARENT_LOGGER.warn("invalid inputCriteria : {}", inputCriteria, e);
            // Invalids tag structure, add to the invalid list.
            throw new InvalidInputException(ErrorCode.IIE007.getCode(),
                    ErrorCode.IIE007.getMessage() + inputCriteria, e);
        }
    }

    protected void validatePagingInput(Integer pageNumber, Integer pageSize, List<String> missingInputs) {
        if (pageNumber == null) {
            missingInputs.add("pageNumber");
        }
        if (pageSize == null) {
            missingInputs.add("pageSize");
        }
    }

    protected void validateOrderField(String orderField) throws InvalidInputException {
        if (orderField != null && !orderField.isEmpty()) {
            try {
                OrderField.fromString(orderField);
            }
            catch (IllegalArgumentException e) {
                throw new InvalidInputException(ErrorCode.IIE005.getCode(), ErrorCode.IIE005.getMessage() + orderField);
            }
        }
    }

}
