package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import com.bnpp.cardif.sugar.domain.model.ConfidentialityLevel;
import com.bnpp.cardif.sugar.rest.ui.model.DocumentIdentifier;
import com.bnpp.cardif.sugar.rest.ui.model.Envelope;
import com.bnpp.cardif.sugar.rest.ui.model.EnvelopeCreationResult;
import com.bnpp.cardif.sugar.rest.ui.model.TagElement;
import com.bnpp.cardif.sugar.utils.DateUtils;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.*;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.ChildObject;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.FileData;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.ParentId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 
 * @author 831743
 *
 */
public class EnvelopeConverter {

    private static final String IN_DIRECTION = "IN";

    private static final Logger LOGGER = LoggerFactory.getLogger(EnvelopeConverter.class);

    /**
     * private empty constructor
     */
    private EnvelopeConverter() {
        // private constructor to avoid instance creation.
    }

    /**
     * Convert a backend document into a JSON Envelope
     * 
     * @param backendDoc
     *            com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document
     * @param token
     * @param scope
     * @return Document
     */
    public static Envelope convert(com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document backendDoc,
            String scope, String token) {
        Envelope result = null;
        if (backendDoc != null) {
            result = new Envelope();
            // doc data
            ElectronicDocumentDataType docData = backendDoc.getData();
            convertDocumentData(result, docData);
            // doc status
            DocumentStatusType documentStatusType = backendDoc.getStatus();
            convertStatusData(documentStatusType, result);
            // doc file
            FileData fileData = backendDoc.getFileData();
            convertFileData(fileData, result);
            // Parent data
            ParentId documentParent = backendDoc.getParentId();
            convertParentData(result, documentParent);
            // Child Data
            ChildObject childData = backendDoc.getChildObject();
            convertChildData(result, childData, scope, token);
            // Id
            if (backendDoc.getId() != null) {
                result.setId(backendDoc.getId().getValue());
            }
            // Tag list
            List<TagElement> tagList = new ArrayList<>();
            if (backendDoc.getTags() != null) {
                Tags documentTags = backendDoc.getTags();
                List<com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag> documentTagList = documentTags
                        .getTag();
                if (documentTagList != null && !documentTagList.isEmpty()) {
                    tagList = TagConverter.convertElement(documentTagList);
                }
            }
            result.setTagList(tagList);
        }
        return result;

    }

    private static void convertStatusData(DocumentStatusType documentStatusType, Envelope result) {
        if (documentStatusType != null) {
            result.setEnvelopeStatus(documentStatusType.getCode());
        }
    }

    @SuppressWarnings({ "squid:S3776", "squid:S134" })
    private static void convertChildData(Envelope result, ChildObject childData, String scope, String token) {

        if (childData != null) {
            LOGGER.warn("Processing child Data : {}", childData);
            List<DocumentIdentifier> listOfDocumentId = new ArrayList<>();
            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> backendDocumentList = childData
                    .getDocument();
            if (backendDocumentList != null) {
                // using the documents
                generateDocumentIdentifier(listOfDocumentId, backendDocumentList);
            }
            else {
                // using the Ids
                List<Id> documentIdList = childData.getId();
                if (documentIdList != null) {
                    generateDocumentIdentifierFromIds(listOfDocumentId, documentIdList);
                }
            }
            result.setListOfDocumentId(listOfDocumentId);
        }
    }

    public static void generateDocumentIdentifierFromIds(List<DocumentIdentifier> listOfDocumentId,
            List<Id> documentIdList) {
        for (Id backendDocId : documentIdList) {
            DocumentIdentifier docId = new DocumentIdentifier();
            if (backendDocId != null) {
                docId.setId(backendDocId.getValue());
                listOfDocumentId.add(docId);
            }
            else {
                LOGGER.warn("Document has no ID skipping : {}", backendDocId);
            }
        }
    }

    static void generateDocumentIdentifier(List<DocumentIdentifier> listOfDocumentId,
            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> documentIdList) {

        for (com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document backendDoc : documentIdList) {
            DocumentIdentifier docId = new DocumentIdentifier();
            Id backendDocId = backendDoc.getId();
            if (backendDocId != null) {
                docId.setId(backendDocId.getValue());
                ElectronicDocumentDataType backendDocData = backendDoc.getData();
                if (backendDocData != null) {
                    docId.setName(backendDocData.getName());
                    docId.setDocViewURL(backendDoc.getArenderURI());
                    docId.setDocValidity(backendDocData.getValidityCode());
                    listOfDocumentId.add(docId);
                }
                else {
                    LOGGER.warn("Document has no Data skipping : {}", backendDoc);
                }
            }
            else {
                LOGGER.warn("Document has no ID skipping : {}", backendDoc);
            }
        }
    }

    @SuppressWarnings("squid:S1172")
    private static void convertParentData(Envelope result, ParentId documentParent) {
        if (documentParent != null) {
            // no data process here
        }
    }

    @SuppressWarnings("squid:S1172")
    private static void convertFileData(FileData fileData, Envelope result) {
        if (fileData != null) {
            // no data process here
        }
    }

    private static void convertDocumentData(Envelope result, ElectronicDocumentDataType docData) {
        if (docData != null) {
            result.setConfidentiality(docData.getConfdntltyLvl());
            if (docData.getCreatnDate() != null) {
                result.setCreationDate(DateUtils.asZonedDateTime(docData.getCreatnDate()));
            }
            result.setCreatedBy(docData.getCreator());
            if (docData.getUpdtDate() != null) {
                result.setUpdatingDate(DateUtils.asZonedDateTime(docData.getUpdtDate()));
            }
            result.setUpdateBy(docData.getLastModifier());
            if (docData.getClassId() != null) {
                result.setEnvTypeId(docData.getClassId().getValue());
                result.setEnvTypeVersion(docData.getClassId().getVersId());
            }
            result.setDirection(docData.getDirectionCode());
            if (docData.getValidityCode() != null) {
                result.setValidity(docData.getValidityCode().value());
            }
        }
    }

    /**
     * Convert a list of backend document into a List of JSON Document
     * 
     * @param backendDocList
     *            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document>
     * @return List<Document>
     */
    public static List<Envelope> convert(
            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> backendDocList, String scope,
            String token) {
        List<Envelope> result = new ArrayList<>();
        if (backendDocList != null && !backendDocList.isEmpty()) {
            for (com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document backendDoc : backendDocList) {
                Envelope content = EnvelopeConverter.convert(backendDoc, scope, token);
                result.add(content);
            }
        }
        return result;
    }

    public static com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document convert(Envelope envelope,
            String scope) {

        com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document result = null;
        if (envelope != null) {
            result = new com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document();
            result.setCategory(Category.ENVELOPE);
            ElectronicDocumentDataType docData = EnvelopeConverter.convertData(envelope);
            result.setData(docData);
            Id id = EnvelopeConverter.convertId(envelope);
            result.setId(id);
            result.setScope(scope);
            Tags docTags = EnvelopeConverter.convertTags(envelope);
            result.setTags(docTags);
            ChildObject childObject = EnvelopeConverter.convertChild(envelope);
            result.setChildObject(childObject);
        }
        return result;
    }

    private static ElectronicDocumentDataType convertData(Envelope envelope) {

        ElectronicDocumentDataType result = new ElectronicDocumentDataType();
        if (envelope != null) {
            result.setConfdntltyLvl(envelope.getConfidentiality());
            ClassId classId = new ClassId(envelope.getEnvTypeId(), ConverterUtils.ISSUER, envelope.getEnvTypeVersion());
            result.setClassId(classId);
            result.setDirectionCode(envelope.getDirection());
            if (envelope.getValidity() != null) {
                try {
                    result.setValidityCode(ValdtyCode.valueOf(envelope.getValidity()));
                }
                catch (IllegalArgumentException e) {
                    LOGGER.warn("Invalid ValdtyCode value, ignoring", e);
                }
            }
        }
        return result;
    }

    private static Id convertId(Envelope envelope) {
        Id result = new Id();
        if (envelope != null) {
            result.setIssuer(ConverterUtils.ISSUER);
            result.setScheme(ConverterUtils.SCHEME);
            result.setValue(envelope.getId());
        }
        return result;
    }

    private static Tags convertTags(Envelope envelope) {

        List<Tag> backendTagList = new ArrayList<>();
        Tags result = new Tags(backendTagList);
        if (envelope != null && envelope.getTagList() != null) {

            List<TagElement> taglist = envelope.getTagList();
            for (TagElement tagElement : taglist) {
                Tag currentTag = new Tag();
                currentTag.setName(tagElement.getTagName());
                currentTag.setValue(tagElement.getTagValue());
                backendTagList.add(currentTag);
            }
        }
        return result;
    }

    private static ChildObject convertChild(Envelope envelope) {

        ChildObject result = new ChildObject();
        if (envelope != null && envelope.getListOfDocumentId() != null) {
            List<Id> idList = result.getId();
            List<DocumentIdentifier> documentIdList = envelope.getListOfDocumentId();
            for (DocumentIdentifier documentIdentifier : documentIdList) {
                Id currentId = new Id(documentIdentifier.getId(), ConverterUtils.ISSUER, ConverterUtils.SCHEME);
                idList.add(currentId);
            }
        }
        return result;
    }

    public static List<EnvelopeCreationResult> convertToEnvelopeCreationResult(
            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> backendDocList) {

        List<EnvelopeCreationResult> result = new ArrayList<>();
        if (backendDocList != null && !backendDocList.isEmpty()) {
            EnvelopeCreationResult content = new EnvelopeCreationResult();
            List<String> documentList = new ArrayList<>();
            fillCreationResult(backendDocList, content, documentList);
            result.add(content);
        }
        return result;
    }

    private static void fillCreationResult(
            List<com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document> backendDocList,
            EnvelopeCreationResult content, List<String> documentList) {
        for (com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document backendDoc : backendDocList) {
            if (backendDoc != null && backendDoc.getCategory().equals(Category.ENVELOPE)) {
                if (backendDoc.getId() != null) {
                    content.setEnvelopeId(backendDoc.getId().getValue());
                }
            }
            else {
                if (backendDoc != null && backendDoc.getId() != null) {
                    documentList.add(backendDoc.getId().getValue());
                }
            }
        }
        content.setDocumentIdList(documentList);
    }

    public static com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document
            convert(List<MultipartFile> fileList, String scope) {

        com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document result = null;
        if (fileList != null) {
            result = new com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document();
            result.setCategory(Category.ENVELOPE);
            ElectronicDocumentDataType docData = EnvelopeConverter.convertData();
            result.setData(docData);
            result.setScope(scope);
        }
        return result;
    }

    private static ElectronicDocumentDataType convertData() {

        ElectronicDocumentDataType result = new ElectronicDocumentDataType();
        result.setCreatnDate(new Date());
        result.setSndngDate(new Date());
        result.setReciptDate(new Date());
        result.setUpdtDate(new Date());
        result.setValidityCode(ValdtyCode.UNDER_CONSTRUCTION);
        result.setDirectionCode(IN_DIRECTION);
        result.setConfdntltyLvl(ConfidentialityLevel.PUBLIC.name());
        return result;
    }

}
