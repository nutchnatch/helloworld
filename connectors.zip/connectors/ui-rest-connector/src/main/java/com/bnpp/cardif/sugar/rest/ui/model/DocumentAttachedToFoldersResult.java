package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * DocumentAttachedToFoldersResult
 */
public class DocumentAttachedToFoldersResult implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("folderId")
    private String folderId = null;

    @JsonProperty("documentIdArray")
    private List<String> documentIdArray = new ArrayList<>();

    /**
     * Folder identification.
     * 
     * @return folderId
     **/
    @ApiModelProperty(value = "Folder identification.")
    public String getFolderId() {
        return folderId;
    }

    public void setFolderId(String folderId) {
        this.folderId = folderId;
    }

    public DocumentAttachedToFoldersResult documentIdArray(List<String> documentIdArray) {
        this.documentIdArray = documentIdArray;
        return this;
    }

    public DocumentAttachedToFoldersResult addDocumentIdArrayItem(String documentIdArrayItem) {
        if (this.documentIdArray == null) {
            this.documentIdArray = new ArrayList<>();
        }
        this.documentIdArray.add(documentIdArrayItem);
        return this;
    }

    /**
     * Created document identification array.
     * 
     * @return documentIdArray
     **/
    @ApiModelProperty(value = "Created document identification array.")
    public List<String> getDocumentIdArray() {
        return documentIdArray;
    }

    public void setDocumentIdArray(List<String> documentIdArray) {
        this.documentIdArray = documentIdArray;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((documentIdArray == null) ? 0 : documentIdArray.hashCode());
        result = prime * result + ((folderId == null) ? 0 : folderId.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof DocumentAttachedToFoldersResult))
            return false;
        DocumentAttachedToFoldersResult other = (DocumentAttachedToFoldersResult) obj;
        if (documentIdArray == null) {
            if (other.documentIdArray != null)
                return false;
        }
        else if (!documentIdArray.equals(other.documentIdArray))
            return false;
        if (folderId == null) {
            if (other.folderId != null)
                return false;
        }
        else if (!folderId.equals(other.folderId))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("DocumentAttachedToFoldersResult [folderId=");
        builder.append(folderId);
        builder.append(", documentIdArray=");
        builder.append(documentIdArray);
        builder.append("]");
        return builder.toString();
    }

}
