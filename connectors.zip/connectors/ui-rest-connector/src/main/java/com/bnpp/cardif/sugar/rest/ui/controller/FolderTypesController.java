package com.bnpp.cardif.sugar.rest.ui.controller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.bnpp.cardif.sugar.rest.ui.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.AclService;
import com.bnpp.cardif.sugar.frontend.services.FolderTypeService;
import com.bnpp.cardif.sugar.rest.ui.api.FolderTypesApi;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.AclConverter;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.FolderTypeConverter;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.TagConverter;
import com.bnpp.cardif.sugar.utils.CollectionUtils;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/v1")
public class FolderTypesController extends FrontendController implements FolderTypesApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(FolderTypesController.class);

    @Autowired
    private FolderTypeService folderTypeService;
    
    @Autowired
    private AclService aclService;

    @RequestMapping(value = "/folder-types", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<FolderType>> getAllFolderType(
            @ApiParam(value = "Includes inactive ones ?", required = false, defaultValue = "false") @RequestParam(value = "inactive", required = false, defaultValue = "false") boolean inactive,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getAllFolderType called");
        RestResponse<FolderType> restResponse = new RestResponse<>();
        try {
            List<FolderClass> result = getActiveOrInactiveDocumentType(inactive);
            final List<FolderType> folderTypeList = new ArrayList<>();
            Optional.ofNullable(result).map(res -> folderTypeList.addAll(FolderTypeConverter.convert(res)));

            for(FolderType folderType : folderTypeList) {
                folderType.setAclList(fetchAcls(folderType.getId(), folderType.getVersion()));
            }

            folderTypeList.sort(Comparator.comparing(FolderType::getName, String.CASE_INSENSITIVE_ORDER));
            restResponse.setResult(folderTypeList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getAllFolderType end");
        return ResponseEntity.ok(restResponse);
    }

    private List<FolderClass> getActiveOrInactiveDocumentType(boolean inactive) throws TechnicalException, FunctionalException {
        return inactive ? folderTypeService.getAllFolderTypeWithInactive() : folderTypeService.getAllFolderType();
    }

    @RequestMapping(value = "/folder-types/{folderTypeId}/{folderTypeVersion}", produces = {
            "application/json; charset=UTF-8" }, consumes = { "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<FolderType>> getFolderTypeByID(
            @ApiParam(value = "Folder type identification.", required = true) @PathVariable("folderTypeId") String folderTypeId,
            @ApiParam(value = "Folder type Version.", required = true) @PathVariable("folderTypeVersion") Integer folderTypeVersion,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getFolderTypeByID called");
        RestResponse<FolderType> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputFolderTypeById(folderTypeId, folderTypeVersion);
            @SuppressWarnings("squid:S2259")
            // call service
            Optional<FolderClass> result = Optional.ofNullable(folderTypeService.getFolderTypeByID(folderTypeId, folderTypeVersion));

            FolderType folderType = result.map(FolderTypeConverter::convert).orElseThrow(() -> new TechnicalException(ErrorCode.TE002));

            List<Acl> aclList = fetchAcls(folderTypeId, folderTypeVersion);
            folderType.setAclList(aclList);

            List<FolderType> valueList = new ArrayList<>();
            valueList.add(folderType);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getFolderTypeByID end");
        return ResponseEntity.ok(restResponse);
    }

    private List<Acl> fetchAcls(
            @ApiParam(value = "Document type ID.", required = true) @PathVariable("documentTypeId") String documentTypeId,
            int version) throws TechnicalException, FunctionalException {

        AccessControlList instanceAcl = aclService.getAclListByClassId(documentTypeId, version, true);
        AccessControlList classAcl = aclService.getAclListByClassId(documentTypeId, version, false);
        return AclConverter.convert(Optional.ofNullable(instanceAcl), Optional.ofNullable(classAcl));
    }

    private void validateInputFolderTypeById(String folderTypeId, Integer folderTypeVersion)
            throws InvalidInputException {
        List<String> missingInputs = new ArrayList<>();
        if (folderTypeId == null || folderTypeId.isEmpty()) {
            missingInputs.add("folderTypeId");
        }
        if (folderTypeVersion == null) {
            missingInputs.add("folderTypeVersion");
        }
        if (!missingInputs.isEmpty()) {
            throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                    ErrorCode.IIE004.getMessage() + CollectionUtils.collectionToString(missingInputs));
        }
    }

    @RequestMapping(value = "/folder-types/{folderTypeId}/{folderTypeVersion}/tags", produces = {
            "application/json; charset=UTF-8" }, consumes = { "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Tag>> searchFolderTags(
            @ApiParam(value = "Folder type identification.", required = true) @PathVariable("folderTypeId") String folderTypeId,
            @ApiParam(value = "Folder type Version.", required = true) @PathVariable("folderTypeVersion") Integer folderTypeVersion,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("searchFolderTags called");
        RestResponse<Tag> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputFolderTypeById(folderTypeId, folderTypeVersion);
            @SuppressWarnings("squid:S2259")
            int version = folderTypeVersion.intValue();
            // call service
            List<TagClass> result = folderTypeService.getFolderTypeTags(folderTypeId, version);
            // transform service result into JSON response
            List<Tag> valueList = TagConverter.convert(result);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("searchFolderTags end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/folder-types", produces = { "application/json; charset=UTF-8" }, consumes = {
            "application/json; charset=UTF-8" }, method = RequestMethod.POST)
    public ResponseEntity<RestResponse<FolderType>> createFolderType(
            @ApiParam(value = "The FolderType to create", required = true) @Valid @RequestBody FolderType inputFolderType,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("createFolderType called");
        RestResponse<FolderType> restResponse = new RestResponse<>();
        try {
            // validate input
            if (inputFolderType == null) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + "inputFolderType");
            }
            FolderClass input = FolderTypeConverter.convert(inputFolderType, getScope());
            // call service
            FolderClass result = folderTypeService.createFolderType(input);
            // transform service result into JSON response
            FolderType folderType = null;
            if (result != null) {
                folderType = FolderTypeConverter.convert(result);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<FolderType> valueList = new ArrayList<>();
            valueList.add(folderType);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("createFolderType end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/folder-types/{folderTypeId}/{folderTypeVersion}", produces = {
            "application/json; charset=UTF-8" }, consumes = {
                    "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<FolderType>> updateFolderType(
            @ApiParam(value = "Folder type ID.", required = true) @PathVariable("folderTypeId") String folderTypeId,
            @ApiParam(value = "Folder type Version.", required = true) @PathVariable("folderTypeVersion") Integer folderTypeVersion,
            @ApiParam(value = "The FolderType to update", required = true) @Valid @RequestBody FolderType inputFolderType,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("updateFolderType called");
        RestResponse<FolderType> restResponse = new RestResponse<>();
        try {
            // validate input
            if (inputFolderType == null) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + "inputFolderType");
            }
            FolderClass input = FolderTypeConverter.convert(inputFolderType, getScope());
            // call service
            FolderClass result = folderTypeService.updateFolderType(input);
            // transform service result into JSON response
            FolderType folderType = null;
            if (result != null) {
                folderType = FolderTypeConverter.convert(result);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<FolderType> valueList = new ArrayList<>();
            valueList.add(folderType);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("updateFolderType end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/folder-types/{folderTypeId}/{folderTypeVersion}/activate", produces = {
            "application/json; charset=UTF-8" }, consumes = {
                    "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<String>> activateFolderType(
            @ApiParam(value = "Folder type ID.", required = true) @PathVariable("folderTypeId") String folderTypeId,
            @ApiParam(value = "Folder type Version.", required = true) @PathVariable("folderTypeVersion") Integer folderTypeVersion,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("activateFolderType called");
        RestResponse<String> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputFolderTypeById(folderTypeId, folderTypeVersion);
            @SuppressWarnings("squid:S2259")
            int version = folderTypeVersion.intValue();
            // call service
            folderTypeService.activateFolderType(folderTypeId, version);
            List<String> valueList = new ArrayList<>();
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("activateFolderType end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/folder-types/{folderTypeId}/{folderTypeVersion}/deactivate", produces = {
            "application/json; charset=UTF-8" }, consumes = {
                    "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<String>> deactivateFolderType(
            @ApiParam(value = "Folder type ID.", required = true) @PathVariable("folderTypeId") String folderTypeId,
            @ApiParam(value = "Folder type Version.", required = true) @PathVariable("folderTypeVersion") Integer folderTypeVersion,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("deactivateFolderType called");
        RestResponse<String> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputFolderTypeById(folderTypeId, folderTypeVersion);
            @SuppressWarnings("squid:S2259")
            int version = folderTypeVersion.intValue();
            // call service
            folderTypeService.deactivateFolderType(folderTypeId, version);
            List<String> valueList = new ArrayList<>();
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("deactivateFolderType end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/folder-types/{folderTypeId}/{folderTypeVersion}/acls", produces = {
            "application/json; charset=UTF-8" }, consumes = { "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Acl>> getFolderTypeAcl(
            @ApiParam(value = "Folder type ID.", required = true) @PathVariable("folderTypeId") String folderTypeId,
            @ApiParam(value = "Folder type Version.", required = true) @PathVariable("folderTypeVersion") Integer folderTypeVersion,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getFolderTypeAcl called");
        RestResponse<Acl> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputFolderTypeById(folderTypeId, folderTypeVersion);
            @SuppressWarnings("squid:S2259")
            int version = folderTypeVersion.intValue();
            // call service
            AccessControlList instanceAcl = aclService.getAclListByClassId(folderTypeId, version, true);
            AccessControlList classAcl = aclService.getAclListByClassId(folderTypeId, version, false);
            // transform service result into JSON response
            List<Acl> valueList = AclConverter.convert(Optional.ofNullable(instanceAcl), Optional.ofNullable(classAcl));
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getFolderTypeAcl end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/folder-types/{folderTypeId}/{folderTypeVersion}/acls", produces = {
            "application/json; charset=UTF-8" }, consumes = {
                    "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<Acl>> assignFolderTypeAcl(
            @ApiParam(value = "Folder type ID.", required = true) @PathVariable("folderTypeId") String folderTypeId,
            @ApiParam(value = "Folder type Version.", required = true) @PathVariable("folderTypeVersion") Integer folderTypeVersion,
            @ApiParam(value = "The Acl to assign", required = true) @Valid @RequestBody Acl inputAcl,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("assignFolderTypeAcl called");
        RestResponse<Acl> restResponse = new RestResponse<>();
        try {
            // validate input
            this.validateInputFolderTypeById(folderTypeId, folderTypeVersion);
            @SuppressWarnings("squid:S2259")
            int version = folderTypeVersion.intValue();
            // call service
            AccessControlList result = aclService.assignAclToClassId(inputAcl.getAclId(), folderTypeId, version,
                    inputAcl.getIsInstanceValue());
            // transform service result into JSON response
            List<Acl> valueList = new ArrayList<>();
            if (result != null) {
                Acl assignedAcl = AclConverter.convert(result, inputAcl.getIsInstanceValue());
                valueList.add(assignedAcl);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("assignFolderTypeAcl end");
        return ResponseEntity.ok(restResponse);
    }

}
