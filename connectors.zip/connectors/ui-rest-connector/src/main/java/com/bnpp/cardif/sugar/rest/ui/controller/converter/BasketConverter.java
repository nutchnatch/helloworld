package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import java.util.ArrayList;
import java.util.List;

import com.bnpp.cardif.sugar.rest.ui.model.Basket;
import com.bnpp.cardif.sugar.rest.ui.model.DisplayNameItem;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;

/**
 * 
 * @author 831743
 *
 */
public class BasketConverter {



    /**
     * private empty constructor
     */
    private BasketConverter() {
        // private constructor to avoid instance creation.
    }

    public static Basket convert(com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket backendBasket,
            String scope) {

        Basket result = null;
        if (backendBasket != null) {
            result = new Basket();
            if (backendBasket.getBasketId() != null) {
                result.setBasketId(backendBasket.getBasketId().getValue());
            }
            List<DisplayNameItem> displayNameItem = generateDisplayNameItemList(backendBasket);
            result.setDisplayNameItem(displayNameItem);
            result.setScope(scope);
            result.setSymbolicName(backendBasket.getSymbolicName());
        }
        return result;
    }

    private static List<DisplayNameItem> generateDisplayNameItemList(
            com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket backendBasket) {
        List<DisplayNameItem> displayNameItem = new ArrayList<>();
        List<MCOI18NLabel> labelList = backendBasket.getDisplayName();
        if (labelList != null) {
            for (MCOI18NLabel mcoi18nLabel : labelList) {
                DisplayNameItem content = new DisplayNameItem();
                content.setLanguage(mcoi18nLabel.getLanguage());
                content.setValue(mcoi18nLabel.getValue());
                displayNameItem.add(content);
            }
        }
        return displayNameItem;
    }

    public static List<Basket> convert(
            List<com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket> backendBasketList, String scope) {

        List<Basket> result = new ArrayList<>();
        if (backendBasketList != null) {
            for (com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket backendBasket : backendBasketList) {
                Basket content = BasketConverter.convert(backendBasket, scope);
                result.add(content);
            }
        }
        return result;
    }

    public static com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket convert(Basket inputBasket,
            String scope) {

        com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket result = null;
        if (inputBasket != null) {
            result = new com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket();
            if (inputBasket.getBasketId() != null) {
                BasketId basketId = new BasketId(inputBasket.getBasketId(), ConverterUtils.ISSUER, ConverterUtils.SCHEME);
                result.setBasketId(basketId);
            }
            result.setScope(scope);
            result.setSymbolicName(inputBasket.getSymbolicName());
            List<MCOI18NLabel> labelList = result.getDisplayName();
            List<DisplayNameItem> displayNameItemList = inputBasket.getDisplayNameItem();
            for (DisplayNameItem displayNameItem : displayNameItemList) {
                MCOI18NLabel content = new MCOI18NLabel(displayNameItem.getValue(), displayNameItem.getLanguage());
                labelList.add(content);
            }
        }
        return result;
    }

}
