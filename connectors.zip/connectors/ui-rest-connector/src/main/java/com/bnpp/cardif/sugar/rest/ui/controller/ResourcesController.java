package com.bnpp.cardif.sugar.rest.ui.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.bnpp.cardif.sugar.rest.ui.model.Config;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.ResourcesService;
import com.bnpp.cardif.sugar.rest.ui.api.ResourcesApi;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.CurrentUserConverter;
import com.bnpp.cardif.sugar.rest.ui.model.CurrentUser;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpp.cardif.sugar.security.AuthenticatedUser;
import com.bnppa.sesame.services.standard.proxy.InvalidTokenException;

@RestController
public class ResourcesController extends FrontendController implements ResourcesApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(ResourcesController.class);

    @Autowired
    private ResourcesService resourcesService;

    @Autowired
    private HttpSession httpSession;

    @Value("${sugar.config.changePassword.url}")
    private String changePasswordURL;

    @Value("${authentication.use-saml}")
    private Boolean isSafSession;

    @RequestMapping(value = "/v1/resources/user", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<CurrentUser>> getCurrentUser() {

        LOGGER.debug("getCurrentUser called");
        RestResponse<CurrentUser> restResponse = new RestResponse<>();
        try {
            AuthenticatedUser authenticatedUser = resourcesService.getUser();
            // transform service result into JSON response
            CurrentUser currentUser = null;
            if (authenticatedUser != null) {
                currentUser = CurrentUserConverter.convert(authenticatedUser);
                currentUser.setSafEnabled(isSafSession != null && isSafSession);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<CurrentUser> valueList = new ArrayList<>();
            valueList.add(currentUser);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getCurrentUser End");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/v1/resources/scope", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.POST)
    public ResponseEntity<RestResponse<String>> setScope(
            @ApiParam(value = "The business scope") @RequestBody(required = false) final String scope) {

        LOGGER.debug("setScope called");
        RestResponse<String> restResponse = new RestResponse<>();
        try {
            resourcesService.setBusinessScope(scope);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("setScope End");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/v1/resources/logout", produces = { "application/json; charset=UTF-8" }, consumes = {
            "application/json; charset=UTF-8" }, method = RequestMethod.POST)
    public ResponseEntity<RestResponse<String>> logout() {
        LOGGER.debug("logout called");
        String errorMessage = "logout error : ";
        RestResponse<String> restResponse = new RestResponse<>();
        try {
            // calling service to perform the action
            resourcesService.logout(httpSession);
            // transform service result into JSON response
            List<String> content = new ArrayList<>();
            restResponse.setResult(content);
            restResponse.setStatus(true);
        }
        catch (InvalidTokenException | com.bnppa.sesame.services.standard.proxy.TechnicalException e) {
            LOGGER.warn(errorMessage, e);
            // specific case for logout: doesn't fails if the session is already
            // expired.
            List<String> content = new ArrayList<>();
            restResponse.setResult(content);
            restResponse.setStatus(true);
        }
        LOGGER.debug("logout End");
        return isSafSession != null && isSafSession ? buildSafLogoutRedirectionResponse() : ResponseEntity.ok(restResponse);
    }

    private ResponseEntity<RestResponse<String>> buildSafLogoutRedirectionResponse() {

        RestResponse<String> restResponse = new RestResponse<>();
        List<String> content = new ArrayList<>();
        restResponse.setResult(content);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(restResponse);
    }

    @RequestMapping(value = "/application/config", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<Config> getConfig() {

        LOGGER.debug("getConfig called");

        final Config config = new Config();
        config.setChangePasswordUrl(changePasswordURL);
        LOGGER.debug("getConfig End");
        return ResponseEntity.ok(config);
    }

}
