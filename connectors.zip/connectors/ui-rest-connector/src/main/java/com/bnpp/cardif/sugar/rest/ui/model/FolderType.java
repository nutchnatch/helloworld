package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * FolderType
 */
public class FolderType implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("id")
    private String id = null;

    @JsonProperty("version")
    private int version;

    @JsonProperty("name")
    private String name = null;

    @JsonProperty("type")
    private String type;

    @JsonProperty("displayNameList")
    private List<DisplayNameItem> displayNameList = new ArrayList<>();

    @JsonProperty("tagList")
    private List<AssociatedTag> tagList = new ArrayList<>();

    @JsonProperty("active")
    private boolean active;

    @JsonProperty("retentionDurationValue")
    private int retentionDurationValue;

    @JsonProperty("retentionDurationUnit")
    private String retentionDurationUnit;

    @JsonProperty("aclList")
    private List<Acl> aclList = new ArrayList<>();

    public FolderType id(String id) {
        this.id = id;
        return this;
    }

    /**
     * Identification of the Folder type.
     * 
     * @return id
     **/
    @ApiModelProperty(required = true, value = "Identification of the Folder type.")
    @NotNull
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public FolderType version(Integer version) {
        this.version = version;
        return this;
    }

    /**
     * Version of the Folder type.
     * 
     * @return name
     **/
    @ApiModelProperty(required = true, value = "Version of the Folder type.")
    @NotNull
    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public FolderType name(String name) {
        this.name = name;
        return this;
    }

    /**
     * Name of the Folder type.
     * 
     * @return name
     **/
    @ApiModelProperty(required = true, value = "Name of the Folder type.")
    @NotNull
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public FolderType type(String type) {
        this.type = type;
        return this;
    }

    /**
     * Type of the Folder type.
     * 
     * @return type
     **/
    @ApiModelProperty(value = "type of the Folder type.")
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public FolderType displayNameList(List<DisplayNameItem> displayNameList) {
        this.displayNameList = displayNameList;
        return this;
    }

    public FolderType addDisplayNameListItem(DisplayNameItem displayNameListItem) {
        this.displayNameList.add(displayNameListItem);
        return this;
    }

    /**
     * Display name.
     * 
     * @return displayNameList
     **/
    @ApiModelProperty(required = true, value = "Display name.")
    @NotNull
    @Valid
    public List<DisplayNameItem> getDisplayNameList() {
        return displayNameList;
    }

    public void setDisplayNameList(List<DisplayNameItem> displayNameList) {
        this.displayNameList = displayNameList;
    }

    public FolderType tagList(List<AssociatedTag> tagList) {
        this.tagList = tagList;
        return this;
    }

    public FolderType addTagListItem(AssociatedTag tagListItem) {
        if (this.tagList == null) {
            this.tagList = new ArrayList<>();
        }
        this.tagList.add(tagListItem);
        return this;
    }

    /**
     * Get tagList
     * 
     * @return tagList
     **/
    @ApiModelProperty(value = "")
    @Valid
    public List<AssociatedTag> getTagList() {
        return tagList;
    }

    public void setTagList(List<AssociatedTag> tagList) {
        this.tagList = tagList;
    }

    public FolderType active(boolean active) {
        this.active = active;
        return this;
    }

    /**
     * Folder type activation flag.
     * 
     * @return active
     **/
    @ApiModelProperty(required = true, value = "Folder type activation flag.")
    @NotNull
    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public FolderType retentionDurationValue(int retentionDurationValue) {
        this.retentionDurationValue = retentionDurationValue;
        return this;
    }

    /**
     * Folder type activation flag.
     * 
     * @return active
     **/
    @ApiModelProperty(required = true, value = "Retention Duration quantity.")
    @NotNull
    public int getRetentionDurationValue() {
        return retentionDurationValue;
    }

    public void setRetentionDurationValue(int retentionDurationValue) {
        this.retentionDurationValue = retentionDurationValue;
    }

    public FolderType retentionDurationUnit(String retentionDurationUnit) {
        this.retentionDurationUnit = retentionDurationUnit;
        return this;
    }

    FolderType aclList(List<Acl> aclList) {
        this.aclList = aclList;
        return this;
    }

    @ApiModelProperty(value = "List of Acl associated to the document type.")
    @Valid
    public List<Acl> getAclList() {
        return aclList;
    }

    public void setAclList(List<Acl> aclList) {
        this.aclList = aclList;
    }

    /**
     * Folder type activation flag.
     * 
     * @return active
     **/
    @ApiModelProperty(required = true, value = "Retention Duration Unit", allowableValues = "DAY,MONTH,YEAR")
    @NotNull
    public String getRetentionDurationUnit() {
        return retentionDurationUnit;
    }

    public void setRetentionDurationUnit(String retentionDurationUnit) {
        this.retentionDurationUnit = retentionDurationUnit;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (active ? 1231 : 1237);
        result = prime * result + ((displayNameList == null) ? 0 : displayNameList.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((retentionDurationUnit == null) ? 0 : retentionDurationUnit.hashCode());
        result = prime * result + retentionDurationValue;
        result = prime * result + ((tagList == null) ? 0 : tagList.hashCode());
        result = prime * result + ((type == null) ? 0 : type.hashCode());
        result = prime * result + version;
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */

    @Override public boolean equals(Object o)
    {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        FolderType that = (FolderType) o;
        return version == that.version && active == that.active && retentionDurationValue == that.retentionDurationValue
                && Objects.equals(id, that.id) && Objects.equals(name, that.name) && Objects.equals(type, that.type)
                && Objects.equals(displayNameList, that.displayNameList) && Objects.equals(tagList, that.tagList)
                && Objects.equals(retentionDurationUnit, that.retentionDurationUnit);
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("FolderType [id=");
        builder.append(id);
        builder.append(", version=");
        builder.append(version);
        builder.append(", name=");
        builder.append(name);
        builder.append(", type=");
        builder.append(type);
        builder.append(", displayNameList=");
        builder.append(displayNameList);
        builder.append(", tagList=");
        builder.append(tagList);
        builder.append(", active=");
        builder.append(active);
        builder.append(", retentionDurationValue=");
        builder.append(retentionDurationValue);
        builder.append(", retentionDurationUnit=");
        builder.append(retentionDurationUnit);
        builder.append("]");
        return builder.toString();
    }

}
