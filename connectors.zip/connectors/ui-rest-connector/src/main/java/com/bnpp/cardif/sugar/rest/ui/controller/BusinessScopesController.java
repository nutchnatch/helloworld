package com.bnpp.cardif.sugar.rest.ui.controller;

import com.bnpp.cardif.sugar.exception.ErrorCode;
import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.InvalidInputException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.AclService;
import com.bnpp.cardif.sugar.frontend.services.BusinessScopeService;
import com.bnpp.cardif.sugar.rest.ui.api.BusinessScopesApi;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.AclConverter;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.BusinessScopeConverter;
import com.bnpp.cardif.sugar.rest.ui.controller.converter.DocumentFileConverter;
import com.bnpp.cardif.sugar.rest.ui.model.Acl;
import com.bnpp.cardif.sugar.rest.ui.model.BusinessScope;
import com.bnpp.cardif.sugar.rest.ui.model.ErrorCause;
import com.bnpp.cardif.sugar.rest.ui.model.RestResponse;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import io.swagger.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/v1")
public class BusinessScopesController extends FrontendController implements BusinessScopesApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(BusinessScopesController.class);

    @Autowired
    private BusinessScopeService businessScopeService;

    @Autowired
    private AclService aclService;

    @RequestMapping(value = "/business-scopes", produces = { "application/json; charset=UTF-8" }, consumes = {
            "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<BusinessScope>> getBusinessScope(
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getBusinessScope called");
        RestResponse<BusinessScope> restResponse = new RestResponse<>();
        try {
            Optional<com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope> backendBusinessScope =
                    Optional.ofNullable(businessScopeService.getBusinessScope());

            BusinessScope businessScope = backendBusinessScope.map(BusinessScopeConverter::convert).orElseThrow(() -> new TechnicalException(ErrorCode.TE002));

            final List<Acl> aclList = getAcls();

            businessScope.setAclList(aclList);
            List<BusinessScope> businessScopeList = new ArrayList<>();
            businessScopeList.add(businessScope);
            restResponse.setResult(businessScopeList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getBusinessScope end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/business-scopes/{businessScopeId}", produces = {
            "application/json; charset=UTF-8" }, consumes = {
                    "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<BusinessScope>> updateBusinessScope(
            @ApiParam(value = "BusinessScope ID", required = true) @PathVariable("businessScopeId") String businessScopeId,
            @ApiParam(value = "The BusinessScope to update", required = true) @Valid @RequestBody BusinessScope inputBusinessScope,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("updateBusinessScope called");
        RestResponse<BusinessScope> restResponse = new RestResponse<>();
        try {
            // validate input
            if (inputBusinessScope == null) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + "businessScope");
            }
            // create input parameters
            com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope inputBS = BusinessScopeConverter
                    .convert(inputBusinessScope);
            com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope backendBusinessScope = businessScopeService
                    .updateBusinessScope(inputBS);
            // transform service result into JSON response
            BusinessScope businessScope = null;
            if (backendBusinessScope != null) {
                businessScope = BusinessScopeConverter.convert(backendBusinessScope);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }

            final List<Acl> aclList = getAcls();
            businessScope.setAclList(aclList);

            List<BusinessScope> valueList = new ArrayList<>();
            valueList.add(businessScope);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("updateBusinessScope end");
        return ResponseEntity.ok(restResponse);
    }

    private List<Acl> getAcls() throws TechnicalException, FunctionalException {

        AccessControlList instanceAcl = aclService.getDefaultAclByBuisnessScope();
        final List<Acl> aclList = new ArrayList<>();
        Optional.ofNullable(instanceAcl).map(aclControlList -> AclConverter.convert(instanceAcl, true)).ifPresent(aclList::add);
        return aclList;
    }

    @RequestMapping(value = "/business-scopes/rule-file", produces = {
            "application/json; charset=UTF-8" }, consumes = { MediaType.MULTIPART_FORM_DATA_VALUE}, method = RequestMethod.POST)
    public ResponseEntity<RestResponse<BusinessScope>> updateRuleFile(
            @ApiParam(value = "The rule File content (binary data)", required = true) @RequestPart("file") MultipartFile file,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("updateRuleFile called");
        RestResponse<BusinessScope> restResponse = new RestResponse<>();
        try {
            // validate input
            if (file == null) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(), ErrorCode.IIE004.getMessage() + "file");
            }
            // create input parameters
            String scope = this.getScope();
            DocumentFile inputDocFile = DocumentFileConverter.convert(file, scope);
            com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope backendBusinessScope = businessScopeService
                    .updateRuleFile(inputDocFile);
            // transform service result into JSON response
            BusinessScope businessScope = null;
            if (backendBusinessScope != null) {
                businessScope = BusinessScopeConverter.convert(backendBusinessScope);
            }
            else {
                throw new TechnicalException(ErrorCode.TE002);
            }
            List<BusinessScope> valueList = new ArrayList<>();
            valueList.add(businessScope);
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (IOException e) {
            LOGGER.info("addEnvelope error : ", e);
            restResponse.setStatus(false);
            ErrorCause errorCause = new ErrorCause();
            errorCause.setCode(ErrorCode.TE003.getCode());
            errorCause.setErrorDate(ZonedDateTime.now());
            errorCause.setMessage("Technical error : " + e.getMessage());
            restResponse.setError(errorCause);
        }
        LOGGER.debug("updateRuleFile end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/business-scopes/{businessScopeId}/acls", produces = {
            "application/json; charset=UTF-8" }, consumes = { "*/*" }, method = RequestMethod.GET)
    public ResponseEntity<RestResponse<Acl>> getBusinessScopeAcl(
            @ApiParam(value = "BusinessScope ID", required = true) @PathVariable("businessScopeId") String businessScopeId,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("getBusinessScopeAcl called");
        RestResponse<Acl> restResponse = new RestResponse<>();
        try {
            // validate input
            if (businessScopeId == null || businessScopeId.isEmpty()) {
                throw new InvalidInputException(ErrorCode.IIE004.getCode(),
                        ErrorCode.IIE004.getMessage() + "businessScopeId");
            }
            // call service
            AccessControlList instanceAcl = aclService.getDefaultAclByBuisnessScope();
            // transform service result into JSON response
            List<Acl> valueList = new ArrayList<>();
            if (instanceAcl != null) {
                Acl content = AclConverter.convert(instanceAcl, true);
                valueList.add(content);
            }
            restResponse.setResult(valueList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        LOGGER.debug("getBusinessScopeAcl end");
        return ResponseEntity.ok(restResponse);
    }

    @RequestMapping(value = "/business-scopes/{businessScope}/acls", produces = {
            "application/json; charset=UTF-8" }, consumes = {
            "application/json; charset=UTF-8" }, method = RequestMethod.PUT)
    public ResponseEntity<RestResponse<Acl>> assignBusinessScopeAcl(
            @ApiParam(value = "BusinessScope ID", required = true) @PathVariable("businessScope") String businessScope,
            @ApiParam(value = "The Acl to assign", required = true) @Valid @RequestBody Acl inputAcl,
            @ApiParam(value = "Application that is performing the request.", required = true, defaultValue = "SUGAR") @RequestHeader(value = "X-CARDIF-CONSUMER", required = true) String xCardifConsumer,
            @ApiParam(value = "Request Identifier.", defaultValue = "SUGAR-123-456") @RequestHeader(value = "X-CARDIF-REQUEST-ID", required = false) String xCardifRequestId,
            @ApiParam(value = "Request correlation Identifier.", defaultValue = "SUGAR-000-123-456") @RequestHeader(value = "X-CARDIF-EXT-REQ-ID", required = false) String xCardifExtReqId) {

        LOGGER.debug("assignBusinessScopeAcl called");
        RestResponse<Acl> restResponse = new RestResponse<>();

        try {
            final List<Acl> aclList = new ArrayList<>();
            AccessControlList assignedAcl = aclService.assignBusinessScopeACL(businessScope, inputAcl.getAclId());
            Optional.ofNullable(assignedAcl).map(acl -> aclList.add(AclConverter.convert(acl, true)));
            restResponse.setResult(aclList);
            restResponse.setStatus(true);
        }
        catch (TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }

        LOGGER.debug("assignBusinessScopeAcl end");
        return ResponseEntity.ok(restResponse);
    }

    @ApiOperation(value = "Download the business scope rule file", notes = "Download the business scope rule file", authorizations = {
            @Authorization(value = "header_token") })
    @RequestMapping(method = RequestMethod.GET, value = "/business-scopes/rule-file", consumes = MediaType.ALL_VALUE)
    @ApiResponses(value = { @ApiResponse(code = 200, message = "Success"),
            @ApiResponse(code = 400, message = "Bad Request", response = Response.class) })
    @SuppressWarnings("squid:S2147")
    public ResponseEntity<RestResponse<BusinessScope>> downloadRuleFile(final HttpServletResponse response){
        LOGGER.debug("downloadRuleFile called");
        RestResponse<BusinessScope> restResponse = new RestResponse<>();

        try {
            com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope backendBusinessScope = businessScopeService
                    .getBusinessScope();
            if (backendBusinessScope.getFileData() != null && backendBusinessScope.getFileData().getDocumentFile() != null) {
                response.addHeader("Content-disposition", "attachment;filename=" + backendBusinessScope.getFileData().getDocumentFile().getName());
                response.addHeader("Content-type", backendBusinessScope.getFileData().getDocumentFile().getContent().getContentType());
                try (final InputStream fileContent = backendBusinessScope.getFileData().getDocumentFile().getContent().getInputStream()) {
                    byte[] outputByte = new byte[4096];
                    int readLen = -1;

                    while ((readLen = fileContent.read(outputByte)) != -1) {
                        response.getOutputStream().write(outputByte, 0, readLen);
                    }
                }
            }
            response.getOutputStream().close();
            response.flushBuffer();
        }
        catch (IOException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (final TechnicalException e) {
            generateTechnicalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }
        catch (final FunctionalException e) {
            generateFunctionalExceptionResponse(restResponse, e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(restResponse);
        }

        LOGGER.debug("downloadRuleFile end");
        return ResponseEntity.ok(restResponse);
    }
}
