package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Represents the details of the response with the expected HTTP code and a
 * description message.
 */
@ApiModel(description = "Represents the details of the response with the expected HTTP code and a description message.")
public class Error implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("status")
    private Boolean status = null;

    @JsonProperty("errorCause")
    private ErrorCause errorCause = null;

    public Error status(Boolean status) {
        this.status = status;
        return this;
    }

    /**
     * Global status of the response. True means success, missing status or
     * false means failure.
     * 
     * @return status
     **/
    @ApiModelProperty(required = true, value = "Global status of the response. True means success, missing status or false means failure.")
    @NotNull

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public Error errorCause(ErrorCause errorCause) {
        this.errorCause = errorCause;
        return this;
    }

    /**
     * Get errorCause
     * 
     * @return errorCause
     **/
    @ApiModelProperty(required = true, value = "")
    @NotNull

    @Valid

    public ErrorCause getErrorCause() {
        return errorCause;
    }

    public void setErrorCause(ErrorCause errorCause) {
        this.errorCause = errorCause;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((errorCause == null) ? 0 : errorCause.hashCode());
        result = prime * result + ((status == null) ? 0 : status.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof Error))
            return false;
        Error other = (Error) obj;
        if (errorCause == null) {
            if (other.errorCause != null)
                return false;
        }
        else if (!errorCause.equals(other.errorCause))
            return false;
        if (status == null) {
            if (other.status != null)
                return false;
        }
        else if (!status.equals(other.status))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Error [status=");
        builder.append(status);
        builder.append(", errorCause=");
        builder.append(errorCause);
        builder.append("]");
        return builder.toString();
    }

}
