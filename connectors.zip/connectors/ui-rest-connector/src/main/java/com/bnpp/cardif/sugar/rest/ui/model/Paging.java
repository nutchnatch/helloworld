package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Represents paginated way in wich data can be retrieved.
 */
@ApiModel(description = "Represents paginated way in wich data can be retrieved.")
public class Paging implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("totalItems")
    private Long totalItems = null;

    @JsonProperty("totalPages")
    private Long totalPages = null;

    @JsonProperty("pageSize")
    private Long pageSize = null;

    @JsonProperty("currentPage")
    private Long currentPage = null;

    public Paging totalItems(Long totalItems) {
        this.totalItems = totalItems;
        return this;
    }

    /**
     * Total number of items.
     * 
     * @return totalItems
     **/
    @ApiModelProperty(value = "Total number of items.")
    public Long getTotalItems() {
        return totalItems;
    }

    public void setTotalItems(Long totalItems) {
        this.totalItems = totalItems;
    }

    public Paging totalPages(Long totalPages) {
        this.totalPages = totalPages;
        return this;
    }

    /**
     * Total number of pages.
     * 
     * @return totalPages
     **/
    @ApiModelProperty(value = "Total number of pages.")
    public Long getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(Long totalPages) {
        this.totalPages = totalPages;
    }

    public Paging pageSize(Long pageSize) {
        this.pageSize = pageSize;
        return this;
    }

    /**
     * Size of the page.
     * 
     * @return pageSize
     **/
    @ApiModelProperty(value = "Size of the page.")
    public Long getPageSize() {
        return pageSize;
    }

    public void setPageSize(Long pageSize) {
        this.pageSize = pageSize;
    }

    public Paging currentPage(Long currentPage) {
        this.currentPage = currentPage;
        return this;
    }

    /**
     * Current page number.
     * 
     * @return currentPage
     **/
    @ApiModelProperty(value = "Current page number.")
    public Long getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(Long currentPage) {
        this.currentPage = currentPage;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((currentPage == null) ? 0 : currentPage.hashCode());
        result = prime * result + ((pageSize == null) ? 0 : pageSize.hashCode());
        result = prime * result + ((totalItems == null) ? 0 : totalItems.hashCode());
        result = prime * result + ((totalPages == null) ? 0 : totalPages.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof Paging))
            return false;
        Paging other = (Paging) obj;
        if (currentPage == null) {
            if (other.currentPage != null)
                return false;
        }
        else if (!currentPage.equals(other.currentPage))
            return false;
        if (pageSize == null) {
            if (other.pageSize != null)
                return false;
        }
        else if (!pageSize.equals(other.pageSize))
            return false;
        if (totalItems == null) {
            if (other.totalItems != null)
                return false;
        }
        else if (!totalItems.equals(other.totalItems))
            return false;
        if (totalPages == null) {
            if (other.totalPages != null)
                return false;
        }
        else if (!totalPages.equals(other.totalPages))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Paging [totalItems=");
        builder.append(totalItems);
        builder.append(", totalPages=");
        builder.append(totalPages);
        builder.append(", pageSize=");
        builder.append(pageSize);
        builder.append(", currentPage=");
        builder.append(currentPage);
        builder.append("]");
        return builder.toString();
    }

}
