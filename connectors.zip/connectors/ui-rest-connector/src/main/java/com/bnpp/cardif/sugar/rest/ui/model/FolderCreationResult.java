package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * FolderCreationResult
 */
public class FolderCreationResult implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("folderId")
    private String folderId = null;

    public FolderCreationResult folderId(String folderId) {
        this.folderId = folderId;
        return this;
    }

    /**
     * Created folder identification.
     * 
     * @return folderId
     **/
    @ApiModelProperty(value = "Created folder identification.")
    public String getFolderId() {
        return folderId;
    }

    public void setFolderId(String folderId) {
        this.folderId = folderId;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((folderId == null) ? 0 : folderId.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof FolderCreationResult))
            return false;
        FolderCreationResult other = (FolderCreationResult) obj;
        if (folderId == null) {
            if (other.folderId != null)
                return false;
        }
        else if (!folderId.equals(other.folderId))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("FolderCreationResult [folderId=");
        builder.append(folderId);
        builder.append("]");
        return builder.toString();
    }

}
