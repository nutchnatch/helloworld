package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

import io.swagger.annotations.ApiModelProperty;

/**
 * BusinessScope
 */
public class BusinessScope implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("businessScopeId")
    private String businessScopeId = null;

    @JsonProperty("organizationalUnit")
    private String organizationalUnit = null;

    @JsonProperty("description")
    private String description = null;

    @JsonProperty("displayName")
    private List<DisplayNameItem> displayName = new ArrayList<>();

    @JsonProperty("languages")
    private List<String> languages = new ArrayList<>();

    @JsonProperty("preferredLanguages")
    private List<String> preferredLanguages = new ArrayList<>();

    @JsonProperty("defaultEnvelopeType")
    private String defaultEnvelopeType = null;

    @JsonProperty("defaultDocumentType")
    private String defaultDocumentType = null;

    @JsonProperty("defaultFolderType")
    private String defaultFolderType = null;

    @JsonProperty("encryptionIdentifier")
    private String encryptionIdentifier = null;

    @JsonProperty("availableEncryptionIdentifiers")
    private List<String> availableEncryptionIdentifiers = new ArrayList<>();

    @JsonProperty("creationDate")
    private ZonedDateTime creationDate = null;

    @JsonProperty("updateDate")
    private ZonedDateTime updateDate = null;

    @JsonProperty("aclList")
    private List<Acl> aclList = new ArrayList<>();

    /**
     * Default retention date.
     */
    public enum DefaultRetentionDateEnum {
        NOT_CURRENT_DATE("NOT_CURRENT_DATE"),

        CURRENT_DATE("CURRENT_DATE");

        private String value;

        DefaultRetentionDateEnum(String value) {
            this.value = value;
        }

        @Override
        @JsonValue
        public String toString() {
            return String.valueOf(value);
        }

        @JsonCreator
        public static DefaultRetentionDateEnum fromValue(String text) {
            for (DefaultRetentionDateEnum b : DefaultRetentionDateEnum.values()) {
                if (String.valueOf(b.value).equals(text)) {
                    return b;
                }
            }
            return null;
        }
    }

    @JsonProperty("defaultRetentionDate")
    private DefaultRetentionDateEnum defaultRetentionDate = DefaultRetentionDateEnum.NOT_CURRENT_DATE;

    @JsonProperty("symbolicName")
    private String symbolicName = null;

    @JsonProperty("basketRuleFile")
    private DocumentIdentifier basketRuleFile = null;

    public BusinessScope businessScopeId(String businessScopeId) {
        this.businessScopeId = businessScopeId;
        return this;
    }

    /**
     * Identifies uniquely a business scope.
     * 
     * @return businessScopeId
     **/
    @ApiModelProperty(required = true, value = "Identifies uniquely a business scope.")
    @NotNull
    public String getBusinessScopeId() {
        return businessScopeId;
    }

    public void setBusinessScopeId(String businessScopeId) {
        this.businessScopeId = businessScopeId;
    }

    public BusinessScope organizationalUnit(String organizationalUnit) {
        this.organizationalUnit = organizationalUnit;
        return this;
    }

    /**
     * Organizational unit.
     * 
     * @return organizationalUnit
     **/
    @ApiModelProperty(value = "Organizational unit.")
    public String getOrganizationalUnit() {
        return organizationalUnit;
    }

    public void setOrganizationalUnit(String organizationalUnit) {
        this.organizationalUnit = organizationalUnit;
    }

    public BusinessScope description(String description) {
        this.description = description;
        return this;
    }

    /**
     * Description.
     * 
     * @return description
     **/
    @ApiModelProperty(value = "Description.")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BusinessScope displayName(List<DisplayNameItem> displayName) {
        this.displayName = displayName;
        return this;
    }

    public BusinessScope addDisplayNameItem(DisplayNameItem displayNameItem) {
        if (this.displayName == null) {
            this.displayName = new ArrayList<>();
        }
        this.displayName.add(displayNameItem);
        return this;
    }

    /**
     * Get displayName
     * 
     * @return displayName
     **/
    @ApiModelProperty(value = "List of Display Name")
    @Valid
    public List<DisplayNameItem> getDisplayName() {
        return displayName;
    }

    public void setDisplayName(List<DisplayNameItem> displayName) {
        this.displayName = displayName;
    }

    public BusinessScope languages(List<String> languages) {
        this.languages = languages;
        return this;
    }

    public BusinessScope addLanguagesItem(String languagesItem) {
        if (this.languages == null) {
            this.languages = new ArrayList<>();
        }
        this.languages.add(languagesItem);
        return this;
    }

    /**
     * Languages supported.
     * 
     * @return languages
     **/
    @ApiModelProperty(value = "Languages supported.")
    public List<String> getLanguages() {
        return languages;
    }

    public void setLanguages(List<String> languages) {
        this.languages = languages;
    }

    public BusinessScope preferredLanguages(List<String> preferredLanguages) {
        this.preferredLanguages = preferredLanguages;
        return this;
    }

    public BusinessScope setAvailableEncryptionIdentifiers(List<String> identifiers) {
        this.availableEncryptionIdentifiers = identifiers;
        return this;
    }

    @ApiModelProperty(value = "Encryption Identifiers")
    public List<String> getAvailableEncryptionIdentifiers() {
        return availableEncryptionIdentifiers;
    }

    public BusinessScope addPreferredLanguagesItem(String preferredLanguagesItem) {
        if (this.preferredLanguages == null) {
            this.preferredLanguages = new ArrayList<>();
        }
        this.preferredLanguages.add(preferredLanguagesItem);
        return this;
    }

    /**
     * Preferred languages.
     * 
     * @return preferredLanguages
     **/
    @ApiModelProperty(value = "Preferred languages.")
    public List<String> getPreferredLanguages() {
        return preferredLanguages;
    }

    public void setPreferredLanguages(List<String> preferredLanguages) {
        this.preferredLanguages = preferredLanguages;
    }

    public BusinessScope defaultEnvelopeType(String defaultEnvelopeType) {
        this.defaultEnvelopeType = defaultEnvelopeType;
        return this;
    }

    /**
     * Default envelope type.
     * 
     * @return defaultEnvelopeType
     **/
    @ApiModelProperty(value = "Default envelope type.")
    public String getDefaultEnvelopeType() {
        return defaultEnvelopeType;
    }

    public void setDefaultEnvelopeType(String defaultEnvelopeType) {
        this.defaultEnvelopeType = defaultEnvelopeType;
    }

    public BusinessScope defaultDocumentType(String defaultDocumentType) {
        this.defaultDocumentType = defaultDocumentType;
        return this;
    }

    /**
     * Default document type.
     * 
     * @return defaultDocumentType
     **/
    @ApiModelProperty(value = "Default document type.")
    public String getDefaultDocumentType() {
        return defaultDocumentType;
    }

    public void setDefaultDocumentType(String defaultDocumentType) {
        this.defaultDocumentType = defaultDocumentType;
    }

    public BusinessScope defaultFolderType(String defaultFolderType) {
        this.defaultFolderType = defaultFolderType;
        return this;
    }

    /**
     * Default folder type.
     * 
     * @return defaultFolderType
     **/
    @ApiModelProperty(value = "Default folder type.")
    public String getDefaultFolderType() {
        return defaultFolderType;
    }

    public void setDefaultFolderType(String defaultFolderType) {
        this.defaultFolderType = defaultFolderType;
    }

    public BusinessScope encryptionIdentifier(String encryptionIdentifier) {
        this.encryptionIdentifier = encryptionIdentifier;
        return this;
    }

    /**
     * Default folder type.
     * 
     * @return encryptionIdentifier
     **/
    @ApiModelProperty(value = "Identify the encryption details applied to the data.")
    public String getEncryptionIdentifier() {
        return encryptionIdentifier;
    }

    public void setEncryptionIdentifier(String encryptionIdentifier) {
        this.encryptionIdentifier = encryptionIdentifier;
    }

    public BusinessScope creationDate(ZonedDateTime creationDate) {
        this.creationDate = creationDate;
        return this;
    }

    /**
     * Date of creation.
     * 
     * @return creationDate
     **/
    @ApiModelProperty(value = "Date of creation.", example = "2017-12-08T10:37:30+01:00")
    @Valid
    public ZonedDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(ZonedDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public BusinessScope updateDate(ZonedDateTime updateDate) {
        this.updateDate = updateDate;
        return this;
    }

    /**
     * Update date of the business scope.
     * 
     * @return updateDate
     **/
    @ApiModelProperty(value = "Update date of the business scope.", example = "2017-12-08T10:37:30+01:00")
    @Valid
    public ZonedDateTime getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(ZonedDateTime updateDate) {
        this.updateDate = updateDate;
    }

    public BusinessScope defaultRetentionDate(DefaultRetentionDateEnum defaultRetentionDate) {
        this.defaultRetentionDate = defaultRetentionDate;
        return this;
    }

    BusinessScope aclList(List<Acl> aclList) {
        this.aclList = aclList;
        return this;
    }

    @ApiModelProperty(value = "List of Acl associated to the document type.")
    @Valid
    public List<Acl> getAclList() {
        return aclList;
    }

    public void setAclList(List<Acl> aclList) {
        this.aclList = aclList;
    }

    /**
     * Default retention date.
     * 
     * @return defaultRetentionDate
     **/
    @ApiModelProperty(value = "Default retention date.")
    public DefaultRetentionDateEnum getDefaultRetentionDate() {
        return defaultRetentionDate;
    }

    public void setDefaultRetentionDate(DefaultRetentionDateEnum defaultRetentionDate) {
        this.defaultRetentionDate = defaultRetentionDate;
    }

    public BusinessScope symbolicName(String symbolicName) {
        this.symbolicName = symbolicName;
        return this;
    }

    /**
     * Symbolic Name.
     * 
     * @return symbolicName
     **/
    @ApiModelProperty(value = "Symbolic Name.")
    public String getSymbolicName() {
        return symbolicName;
    }

    public void setSymbolicName(String symbolicName) {
        this.symbolicName = symbolicName;
    }

    public BusinessScope basketRuleFile(DocumentIdentifier basketRuleFile) {
        this.basketRuleFile = basketRuleFile;
        return this;
    }

    /**
     * Symbolic Name.
     * 
     * @return symbolicName
     **/
    @ApiModelProperty(value = "File for basket rules")
    public DocumentIdentifier getBasketRuleFile() {
        return basketRuleFile;
    }

    public void setBasketRuleFile(DocumentIdentifier basketRuleFile) {
        this.basketRuleFile = basketRuleFile;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((basketRuleFile == null) ? 0 : basketRuleFile.hashCode());
        result = prime * result + ((businessScopeId == null) ? 0 : businessScopeId.hashCode());
        result = prime * result + ((creationDate == null) ? 0 : creationDate.hashCode());
        result = prime * result + ((defaultDocumentType == null) ? 0 : defaultDocumentType.hashCode());
        result = prime * result + ((defaultEnvelopeType == null) ? 0 : defaultEnvelopeType.hashCode());
        result = prime * result + ((defaultFolderType == null) ? 0 : defaultFolderType.hashCode());
        result = prime * result + ((defaultRetentionDate == null) ? 0 : defaultRetentionDate.hashCode());
        result = prime * result + ((description == null) ? 0 : description.hashCode());
        result = prime * result + ((displayName == null) ? 0 : displayName.hashCode());
        result = prime * result + ((encryptionIdentifier == null) ? 0 : encryptionIdentifier.hashCode());
        result = prime * result + ((languages == null) ? 0 : languages.hashCode());
        result = prime * result + ((organizationalUnit == null) ? 0 : organizationalUnit.hashCode());
        result = prime * result + ((preferredLanguages == null) ? 0 : preferredLanguages.hashCode());
        result = prime * result + ((symbolicName == null) ? 0 : symbolicName.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */

    @Override
    public boolean equals(Object o)
    {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        BusinessScope that = (BusinessScope) o;
        return Objects.equals(businessScopeId, that.businessScopeId) &&
               Objects.equals(organizationalUnit, that.organizationalUnit) &&
               Objects.equals(description, that.description) &&
               Objects.equals(displayName, that.displayName) &&
               Objects.equals(languages, that.languages) &&
               Objects.equals(preferredLanguages, that.preferredLanguages) &&
               Objects.equals(defaultEnvelopeType, that.defaultEnvelopeType) &&
               Objects.equals(defaultDocumentType, that.defaultDocumentType) &&
               Objects.equals(defaultFolderType, that.defaultFolderType) &&
               Objects.equals(encryptionIdentifier, that.encryptionIdentifier) &&
               Objects.equals(availableEncryptionIdentifiers, that.availableEncryptionIdentifiers) &&
               Objects.equals(creationDate, that.creationDate) &&
               Objects.equals(updateDate, that.updateDate) &&
               defaultRetentionDate == that.defaultRetentionDate &&
               Objects.equals(symbolicName, that.symbolicName)&&
               Objects.equals(basketRuleFile, that.basketRuleFile);
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("BusinessScope [businessScopeId=");
        builder.append(businessScopeId);
        builder.append(", organizationalUnit=");
        builder.append(organizationalUnit);
        builder.append(", description=");
        builder.append(description);
        builder.append(", displayName=");
        builder.append(displayName);
        builder.append(", languages=");
        builder.append(languages);
        builder.append(", preferredLanguages=");
        builder.append(preferredLanguages);
        builder.append(", defaultEnvelopeType=");
        builder.append(defaultEnvelopeType);
        builder.append(", defaultDocumentType=");
        builder.append(defaultDocumentType);
        builder.append(", defaultFolderType=");
        builder.append(defaultFolderType);
        builder.append(", encryptionIdentifier=");
        builder.append(encryptionIdentifier);
        builder.append(", creationDate=");
        builder.append(creationDate);
        builder.append(", updateDate=");
        builder.append(updateDate);
        builder.append(", defaultRetentionDate=");
        builder.append(defaultRetentionDate);
        builder.append(", symbolicName=");
        builder.append(symbolicName);
        builder.append(", basketRuleFile=");
        builder.append(basketRuleFile);
        builder.append("]");
        return builder.toString();
    }

}
