package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * For a given type, defines if a tag is mandatory, or not.
 */
@ApiModel(description = "For a given type, defines if a tag is mandatory, or not.")
public class AssociatedTag implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("symbolicName")
    private String symbolicName = null;

    @JsonProperty("mandatory")
    private Boolean mandatory = null;

    @JsonProperty("multivalued")
    private Boolean multivalued = null;

    public AssociatedTag symbolicName(String symbolicName) {
        this.symbolicName = symbolicName;
        return this;
    }

    /**
     * Get symbolicName
     * 
     * @return symbolicName
     **/
    @ApiModelProperty(required = true, value = "")
    @NotNull
    public String getSymbolicName() {
        return symbolicName;
    }

    public void setSymbolicName(String symbolicName) {
        this.symbolicName = symbolicName;
    }

    public AssociatedTag mandatory(Boolean mandatory) {
        this.mandatory = mandatory;
        return this;
    }

    /**
     * Defines if this tag is mandatory, or not.
     * 
     * @return mandatory
     **/
    @ApiModelProperty(required = true, value = "Defines if this tag is mandatory, or not.")
    @NotNull

    public Boolean getMandatory() {
        return mandatory;
    }

    public void setMandatory(Boolean mandatory) {
        this.mandatory = mandatory;
    }

    public AssociatedTag multivalued(Boolean multivalued) {
        this.multivalued = multivalued;
        return this;
    }

    /**
     * Defines if this tag is multivalued, or not.
     * 
     * @return multivalued
     **/
    @ApiModelProperty(required = true, value = "Defines if this tag is multivalued, or not.")
    @NotNull
    public Boolean getMultivalued() {
        return multivalued;
    }

    public void setMultivalued(Boolean multivalued) {
        this.multivalued = multivalued;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((mandatory == null) ? 0 : mandatory.hashCode());
        result = prime * result + ((multivalued == null) ? 0 : multivalued.hashCode());
        result = prime * result + ((symbolicName == null) ? 0 : symbolicName.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof AssociatedTag))
            return false;
        AssociatedTag other = (AssociatedTag) obj;
        if (mandatory == null) {
            if (other.mandatory != null)
                return false;
        }
        else if (!mandatory.equals(other.mandatory))
            return false;
        if (multivalued == null) {
            if (other.multivalued != null)
                return false;
        }
        else if (!multivalued.equals(other.multivalued))
            return false;
        if (symbolicName == null) {
            if (other.symbolicName != null)
                return false;
        }
        else if (!symbolicName.equals(other.symbolicName))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("AssociatedTag [symbolicName=");
        builder.append(symbolicName);
        builder.append(", mandatory=");
        builder.append(mandatory);
        builder.append(", multivalued=");
        builder.append(multivalued);
        builder.append("]");
        return builder.toString();
    }

}
