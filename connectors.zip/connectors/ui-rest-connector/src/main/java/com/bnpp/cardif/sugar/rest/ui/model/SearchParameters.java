package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @author 831743
 *
 */
@ApiModel(description = "Contains the all the parameters to search document and enveloppe.")
public class SearchParameters implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("criteria")
    private SearchCriteria criteria = null;

    @JsonProperty("order")
    private SearchOrder order = null;

    /**
     * @return the criteria
     */
    @ApiModelProperty(required = true, value = "search criteria")
    @NotNull
    public SearchCriteria getCriteria() {
        return criteria;
    }

    /**
     * @param criteria
     *            the criteria to set
     */
    public void setCriteria(SearchCriteria criteria) {
        this.criteria = criteria;
    }

    /**
     * @return the order
     */
    @ApiModelProperty(required = true, value = "search result ordering")
    public SearchOrder getOrder() {
        return order;
    }

    /**
     * @param order
     *            the order to set
     */
    public void setOrder(SearchOrder order) {
        this.order = order;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((criteria == null) ? 0 : criteria.hashCode());
        result = prime * result + ((order == null) ? 0 : order.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof SearchParameters))
            return false;
        SearchParameters other = (SearchParameters) obj;
        if (criteria == null) {
            if (other.criteria != null)
                return false;
        }
        else if (!criteria.equals(other.criteria))
            return false;
        if (order == null) {
            if (other.order != null)
                return false;
        }
        else if (!order.equals(other.order))
            return false;
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("SearchParameters [criteria=");
        builder.append(criteria);
        builder.append(", order=");
        builder.append(order);
        builder.append("]");
        return builder.toString();
    }

}
