package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class EnvelopeReporting implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @JsonProperty("directionCode")
    private String directionCode = null;

    @JsonProperty("classId")
    private String classId = null;

    @JsonProperty("classVersion")
    private long classVersion = 0;

    @JsonProperty("numberOfEnvelopes")
    private long numberOfEnvelopes = 0;

    @JsonProperty("numberOfDocuments")
    private long numberOfDocuments = 0;

    @JsonProperty("sizeOfDocuments")
    private double sizeOfDocuments = 0;

    public EnvelopeReporting directionCode(String directionCode) {
        this.directionCode = directionCode;
        return this;
    }

    /**
     * Envelope direction
     * 
     * @return directionCode
     **/
    @ApiModelProperty(required = false, value = "Envelope direction")
    @NotNull
    public String getDirectionCode() {
        return directionCode;
    }

    public void setDirectionCode(String directionCode) {
        this.directionCode = directionCode;
    }

    public EnvelopeReporting classId(String classId) {
        this.classId = classId;
        return this;
    }

    /**
     * Identifier of the envelope class.
     * 
     * @return classId
     **/
    @ApiModelProperty(required = true, value = "Identifier of the envelope class.")
    @NotNull
    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public EnvelopeReporting classVersion(long classVersion) {
        this.classVersion = classVersion;
        return this;
    }

    /**
     * Version of the envelope class.
     * 
     * @return classVersion
     **/
    @ApiModelProperty(required = true, value = "Version of the envelope class.")
    @NotNull
    public long getClassVersion() {
        return classVersion;
    }

    public void setClassVersion(long classVersion) {
        this.classVersion = classVersion;
    }

    public EnvelopeReporting numberOfEnvelopes(long numberOfEnvelopes) {
        this.numberOfEnvelopes = numberOfEnvelopes;
        return this;
    }

    /**
     * Number of envelope of the related class.
     * 
     * @return numberOfEnvelopes
     **/
    @ApiModelProperty(required = true, value = "Number of envelope of the related class.")
    @NotNull
    public long getNumberOfEnvelopes() {
        return numberOfEnvelopes;
    }

    public void setNumberOfEnvelopes(long numberOfEnvelopes) {
        this.numberOfEnvelopes = numberOfEnvelopes;
    }

    public EnvelopeReporting numberOfDocuments(long numberOfDocuments) {
        this.numberOfDocuments = numberOfDocuments;
        return this;
    }

    /**
     * Number of document in the envelopes.
     * 
     * @return numberOfDocuments
     **/
    @ApiModelProperty(required = true, value = "Number of document in the envelopes.")
    @NotNull
    public long getNumberOfDocuments() {
        return numberOfDocuments;
    }

    public void setNumberOfDocuments(long numberOfDocuments) {
        this.numberOfDocuments = numberOfDocuments;
    }

    public EnvelopeReporting sizeOfDocuments(long sizeOfDocuments) {
        this.sizeOfDocuments = sizeOfDocuments;
        return this;
    }

    /**
     * Size of the documents in the envelopes.
     * 
     * @return numberOfDocuments
     **/
    @ApiModelProperty(required = true, value = "Size of the documents in the envelopes.")
    @NotNull
    public double getSizeOfDocuments() {
        return sizeOfDocuments;
    }

    public void setSizeOfDocuments(double sizeOfDocuments) {
        this.sizeOfDocuments = sizeOfDocuments;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        EnvelopeReporting that = (EnvelopeReporting) o;

        if (classVersion != that.classVersion)
            return false;
        if (numberOfEnvelopes != that.numberOfEnvelopes)
            return false;
        if (numberOfDocuments != that.numberOfDocuments)
            return false;
        if (Double.compare(that.sizeOfDocuments, sizeOfDocuments) != 0)
            return false;
        if (directionCode != null ? !directionCode.equals(that.directionCode) : that.directionCode != null)
            return false;
        return classId != null ? classId.equals(that.classId) : that.classId == null;
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = directionCode != null ? directionCode.hashCode() : 0;
        result = 31 * result + (classId != null ? classId.hashCode() : 0);
        result = 31 * result + (int) (classVersion ^ (classVersion >>> 32));
        result = 31 * result + (int) (numberOfEnvelopes ^ (numberOfEnvelopes >>> 32));
        result = 31 * result + (int) (numberOfDocuments ^ (numberOfDocuments >>> 32));
        temp = Double.doubleToLongBits(sizeOfDocuments);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("EnvelopeReporting [directionCode=");
        builder.append(directionCode);
        builder.append(", classId=");
        builder.append(classId);
        builder.append(", classVersion=");
        builder.append(classVersion);
        builder.append(", numberOfEnvelopes=");
        builder.append(numberOfEnvelopes);
        builder.append(", numberOfDocuments=");
        builder.append(numberOfDocuments);
        builder.append(", sizeOfDocuments=");
        builder.append(sizeOfDocuments);
        builder.append("]");
        return builder.toString();
    }

}
