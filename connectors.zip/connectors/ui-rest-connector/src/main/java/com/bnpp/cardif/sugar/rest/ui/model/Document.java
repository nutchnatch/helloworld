package com.bnpp.cardif.sugar.rest.ui.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Document
 */
public class Document implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("id")
    private String id = null;

    @JsonProperty("name")
    private String name = null;

    @JsonProperty("docFileID")
    private String docFileID = null;

    @JsonProperty("docViewURL")
    private String docViewURL = null;

    @JsonProperty("envelopeID")
    private String envelopeID = null;

    @JsonProperty("creationDate")
    private ZonedDateTime creationDate = null;

    @JsonProperty("createdBy")
    private String createdBy = null;

    @JsonProperty("updateDate")
    private ZonedDateTime updateDate = null;

    @JsonProperty("updatedBy")
    private String updatedBy = null;

    @JsonProperty("language")
    private String language = null;

    @JsonProperty("retentionStartDate")
    private LocalDate retentionStartDate = null;

    @JsonProperty("retentionEndDate")
    private LocalDate retentionEndDate = null;

    @JsonProperty("confidentiality")
    private String confidentiality = null;

    @JsonProperty("docTypeId")
    private String docTypeId = null;

    @JsonProperty("docTypeVersion")
    private int docTypeVersion;

    @JsonProperty("direction")
    private String direction = null;

    @JsonProperty("validity")
    private String validity = null;

    @JsonProperty("tagList")
    private List<TagElement> tagList = new ArrayList<>();
    
    @JsonProperty("folderList")
    private List<Folder> folderList = new ArrayList<>();

    public Document id(String id) {
        this.id = id;
        return this;
    }

    /**
     * Document identification
     * 
     * @return id
     **/
    @ApiModelProperty(required = true, value = "Document identification")
    @NotNull
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Document name(String name) {
        this.name = name;
        return this;
    }

    /**
     * Contains the name of the document.
     * 
     * @return name
     **/
    @ApiModelProperty(required = true, value = "Contains the name of the document.")
    @NotNull
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Document docFileID(String docFileID) {
        this.docFileID = docFileID;
        return this;
    }

    /**
     * Identification of the File already stored in the system.
     * 
     * @return docFileID
     **/
    @ApiModelProperty(required = true, value = "Identification of the File already stored in the system.")
    @NotNull
    public String getDocFileID() {
        return docFileID;
    }

    public void setDocFileID(String docFileID) {
        this.docFileID = docFileID;
    }

    public Document docViewURL(String docViewURL) {
        this.docViewURL = docViewURL;
        return this;
    }

    /**
     * URL to view the document file.
     * 
     * @return docViewURL
     **/
    @ApiModelProperty(required = true, value = "URL to view the document file.")
    public String getDocViewURL() {
        return docViewURL;
    }

    public void setDocViewURL(String docViewURL) {
        this.docViewURL = docViewURL;
    }

    public Document envelopeID(String envelopeID) {
        this.envelopeID = envelopeID;
        return this;
    }

    /**
     * Identification of the envelope where the document will be stored.
     * 
     * @return envelopeID
     **/
    @ApiModelProperty(required = true, value = "Identification of the envelope where the document will be stored.")
    @NotNull
    public String getEnvelopeID() {
        return envelopeID;
    }

    public void setEnvelopeID(String envelopeID) {
        this.envelopeID = envelopeID;
    }

    public Document creationDate(ZonedDateTime creationDate) {
        this.creationDate = creationDate;
        return this;
    }

    /**
     * When the document is created. On creation, this date will be filled with
     * the current date.
     * 
     * @return creationDate
     **/
    @ApiModelProperty(value = "When the document is created. On creation, this date will be filled with the current date.", example = "2017-12-08T10:37:30+01:00")
    @Valid
    public ZonedDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(ZonedDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public Document language(String language) {
        this.language = language;
        return this;
    }

    /**
     * Language for yhe document.
     * 
     * @return language
     **/
    @ApiModelProperty(value = "Language for the document.")
    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public Document retentionStartDate(LocalDate retentionStartDate) {
        this.retentionStartDate = retentionStartDate;
        return this;
    }

    /**
     * Date from when document should be kept stored.
     * 
     * @return retentionStartDate
     **/
    @ApiModelProperty(value = "Date from when document should be kept stored.")
    @Valid
    public LocalDate getRetentionStartDate() {
        return retentionStartDate;
    }

    public void setRetentionStartDate(LocalDate retentionStartDate) {
        this.retentionStartDate = retentionStartDate;
    }

    public Document retentionEndDate(LocalDate retentionEndDate) {
        this.retentionEndDate = retentionEndDate;
        return this;
    }

    /**
     * Date until when document should be kept stored.
     * 
     * @return retentionEndDate
     **/
    @ApiModelProperty(value = "Date until when document should be kept stored.")
    @Valid
    public LocalDate getRetentionEndDate() {
        return retentionEndDate;
    }

    public void setRetentionEndDate(LocalDate retentionEndDate) {
        this.retentionEndDate = retentionEndDate;
    }

    public Document confidentiality(String confidentiality) {
        this.confidentiality = confidentiality;
        return this;
    }

    /**
     * Defines if the document is confidential or not.
     * 
     * @return confidentiality
     **/
    @ApiModelProperty(value = "Defines if the document is confidential or not.")
    public String getConfidentiality() {
        return confidentiality;
    }

    public void setConfidentiality(String confidentiality) {
        this.confidentiality = confidentiality;
    }

    public Document docTypeVersion(int docTypeVersion) {
        this.docTypeVersion = docTypeVersion;
        return this;
    }

    /**
     * Contains the version of the document type. On creation of a document,
     * this field will be filled with an default value fetched from the document
     * type.
     * 
     * @return docTypeVersion
     **/
    @ApiModelProperty(value = "Contains the version of the document type. On creation of a document, this field will be filled with an default value fetched from the document type.")
    public int getDocTypeVersion() {
        return docTypeVersion;
    }

    public void setDocTypeVersion(int docTypeVersion) {
        this.docTypeVersion = docTypeVersion;
    }

    public Document docTypeId(String docTypeId) {
        this.docTypeId = docTypeId;
        return this;
    }

    /**
     * Identification of the document type. On creation of a document, this
     * field will be filled with an default value fetched from the document type
     * 
     * @return docTypeId
     **/
    @ApiModelProperty(value = "Identification of the document type. On creation of a document, this field will be filled with an default value fetched from the document type")
    public String getDocTypeId() {
        return docTypeId;
    }

    public void setDocTypeId(String docTypeId) {
        this.docTypeId = docTypeId;
    }

    public Document direction(String direction) {
        this.direction = direction;
        return this;
    }

    /**
     * Identification of the document direction. On creation of a document, this
     * field will be filled with an default value fetched from the document
     * direction
     * 
     * @return direction
     **/
    @ApiModelProperty(value = "Identification of the document direction. On creation of a document, this field will be filled with an default value fetched from the document direction")
    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public Document validity(String validity) {
        this.validity = validity;
        return this;
    }

    /**
     * Identification of the document validity. On creation of a document, this
     * field will be filled with an default value fetched from the document
     * validity
     * 
     * @return validity
     **/
    @ApiModelProperty(value = "Identification of the document validity. On creation of a document, this field will be filled with an default value fetched from the document validity")
    public String getValidity() {
        return validity;
    }

    public void setValidity(String validity) {
        this.validity = validity;
    }

    public Document tagList(List<TagElement> tagList) {
        this.tagList = tagList;
        return this;
    }

    public Document addTagListItem(TagElement tagListItem) {
        if (this.tagList == null) {
            this.tagList = new ArrayList<>();
        }
        this.tagList.add(tagListItem);
        return this;
    }

    /**
     * Get tagList
     * 
     * @return tagList
     **/
    @ApiModelProperty(value = "")
    @Valid
    public List<TagElement> getTagList() {
        return tagList;
    }

    public void setTagList(List<TagElement> tagList) {
        this.tagList = tagList;
    }
    
    public Document folderList(List<Folder> folderList) {
        this.folderList = folderList;
        return this;
    }

    public Document addFolderListItem(Folder folderItem) {
        if (this.folderList == null) {
            this.folderList = new ArrayList<>();
        }
        this.folderList.add(folderItem);
        return this;
    }

    /**
     * Get folderList
     * 
     * @return folderList
     **/
    @ApiModelProperty(value = "")
    @Valid
    public List<Folder> getFolderList() {
        return folderList;
    }

    public void setFolderList(List<Folder> folderList) {
        this.folderList = folderList;
    }

    /**
     * Gets the createdBy.
     *
     * @return value of createdBy
     */
    @ApiModelProperty(value = "Created by")
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the createdBy.
     *
     * @param createdBy Value of createdBy to set
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * Gets the updateDate.
     *
     * @return value of updateDate
     */
    @ApiModelProperty(value = "Update date")
    public ZonedDateTime getUpdateDate() {
        return updateDate;
    }

    /**
     * Sets the updateDate.
     *
     * @param updateDate Value of updateDate to set
     */
    public void setUpdateDate(ZonedDateTime updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * Gets the updatedBy.
     *
     * @return value of updatedBy
     */
    @ApiModelProperty(value = "Updated by")
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * Sets the updatedBy.
     *
     * @param updatedBy Value of updatedBy to set
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        Document document = (Document) o;
        return docTypeVersion == document.docTypeVersion && Objects.equals(id, document.id) && Objects
                .equals(name, document.name) && Objects.equals(docFileID, document.docFileID) && Objects
                .equals(docViewURL, document.docViewURL) && Objects.equals(envelopeID, document.envelopeID) && Objects
                .equals(creationDate, document.creationDate) && Objects.equals(createdBy, document.createdBy) && Objects
                .equals(updateDate, document.updateDate) && Objects.equals(updatedBy, document.updatedBy) && Objects
                .equals(language, document.language) && Objects.equals(retentionStartDate, document.retentionStartDate)
                && Objects.equals(retentionEndDate, document.retentionEndDate) && Objects
                .equals(confidentiality, document.confidentiality) && Objects.equals(docTypeId, document.docTypeId)
                && Objects.equals(direction, document.direction) && Objects.equals(validity, document.validity)
                && Objects.equals(tagList, document.tagList) && Objects.equals(folderList, document.folderList);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, name, docFileID, docViewURL, envelopeID, creationDate, createdBy, updateDate, updatedBy,
                language, retentionStartDate, retentionEndDate, confidentiality, docTypeId, docTypeVersion, direction,
                validity, tagList, folderList);
    }

    @Override
    public String toString() {
        return "Document{" + "id='" + id + '\'' + ", name='" + name + '\'' + ", docFileID='" + docFileID + '\''
                + ", docViewURL='" + docViewURL + '\'' + ", envelopeID='" + envelopeID + '\'' + ", creationDate="
                + creationDate + ", createdBy='" + createdBy + '\'' + ", updateDate=" + updateDate + ", updatedBy='"
                + updatedBy + '\'' + ", language='" + language + '\'' + ", retentionStartDate=" + retentionStartDate
                + ", retentionEndDate=" + retentionEndDate + ", confidentiality='" + confidentiality + '\''
                + ", docTypeId='" + docTypeId + '\'' + ", docTypeVersion=" + docTypeVersion + ", direction='"
                + direction + '\'' + ", validity='" + validity + '\'' + ", tagList=" + tagList + ", folderList="
                + folderList + '}';
    }
}
