package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Defines the type of envelopes.
 */
@ApiModel(description = "Defines the type of envelopes.")
public class EnvelopeType implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("id")
    private String id = null;

    @JsonProperty("version")
    private int version;

    @JsonProperty("name")
    private String name = null;

    @JsonProperty("firstLevel")
    private boolean firstLevel;
    
    @JsonProperty("active")
    private boolean active;

    @JsonProperty("displayNameList")
    private List<DisplayNameItem> displayNameList = new ArrayList<>();

    @JsonProperty("tagList")
    private List<AssociatedTag> tagList = new ArrayList<>();

    @JsonProperty("allowedChildren")
    private List<AllowedChildren> allowedChildren = new ArrayList<>();

    @JsonProperty("aclList")
    private List<Acl> aclList = new ArrayList<>();

    public EnvelopeType id(String id) {
        this.id = id;
        return this;
    }

    /**
     * Identification of the envelope.
     * 
     * @return id
     **/
    @ApiModelProperty(value = "Identification of the envelope type.")
    @NotNull
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public EnvelopeType version(int version) {
        this.version = version;
        return this;
    }

    /**
     * Identification of the envelope.
     * 
     * @return id
     **/
    @ApiModelProperty(value = "version of the envelope type.")
    @NotNull
    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public EnvelopeType name(String name) {
        this.name = name;
        return this;
    }

    /**
     * Symbolic name for this type envelope.
     * 
     * @return name
     **/
    @ApiModelProperty(required = true, value = "Symbolic name for this type envelope.")
    @NotNull
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public EnvelopeType firstLevel(boolean firstLevel) {
        this.firstLevel = firstLevel;
        return this;
    }

    /**
     * Name. Is the unic ID of the documentType
     * 
     * @return name
     **/
    @ApiModelProperty(required = true, value = "firstLevel. indicate if it is a first level type or not.")
    @NotNull
    public boolean getFirstLevel() {
        return firstLevel;
    }

    public void setFirstLevel(boolean firstLevel) {
        this.firstLevel = firstLevel;
    }
    
    public EnvelopeType active(boolean active) {
        this.active = active;
        return this;
    }

    /**
     * active. indicate if the EnvelopeType is active or not..
     * 
     * @return name
     **/
    @ApiModelProperty(required = true, value = "active. indicate if the EnvelopeType is active or not..")
    @NotNull
    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public EnvelopeType displayNameList(List<DisplayNameItem> displayNameList) {
        this.displayNameList = displayNameList;
        return this;
    }

    public EnvelopeType addDisplayNameListItem(DisplayNameItem displayNameListItem) {
        if (this.displayNameList == null) {
            this.displayNameList = new ArrayList<>();
        }
        this.displayNameList.add(displayNameListItem);
        return this;
    }

    EnvelopeType aclList(List<Acl> aclList) {
        this.aclList = aclList;
        return this;
    }

    @ApiModelProperty(value = "List of Acl associated to the document type.")
    @Valid
    public List<Acl> getAclList() {
        return aclList;
    }

    public void setAclList(List<Acl> aclList) {
        this.aclList = aclList;
    }

    /**
     * Name to be displayed.
     * 
     * @return displayNameList
     **/
    @ApiModelProperty(value = "Name to be displayed.")
    @Valid
    public List<DisplayNameItem> getDisplayNameList() {
        return displayNameList;
    }

    public void setDisplayNameList(List<DisplayNameItem> displayNameList) {
        this.displayNameList = displayNameList;
    }

    public EnvelopeType tagList(List<AssociatedTag> tagList) {
        this.tagList = tagList;
        return this;
    }

    public EnvelopeType addTagListItem(AssociatedTag tagListItem) {
        if (this.tagList == null) {
            this.tagList = new ArrayList<>();
        }
        this.tagList.add(tagListItem);
        return this;
    }

    /**
     * Get tagList
     * 
     * @return tagList
     **/
    @ApiModelProperty(value = "")
    @Valid
    public List<AssociatedTag> getTagList() {
        return tagList;
    }

    public void setTagList(List<AssociatedTag> tagList) {
        this.tagList = tagList;
    }

    public EnvelopeType allowedChildren(List<AllowedChildren> allowedChildren) {
        this.allowedChildren = allowedChildren;
        return this;
    }

    public EnvelopeType addAllowedChildrenItem(AllowedChildren allowedChildrenItem) {
        if (this.allowedChildren == null) {
            this.allowedChildren = new ArrayList<>();
        }
        this.allowedChildren.add(allowedChildrenItem);
        return this;
    }

    /**
     * List of EnvelopeType that are authorized as childrens.
     * 
     * @return allowedChildren
     **/
    @ApiModelProperty(value = "List of EnvelopeType that are authorized as childrens.")
    @Valid
    public List<AllowedChildren> getAllowedChildren() {
        return allowedChildren;
    }

    public void setAllowedChildren(List<AllowedChildren> allowedChildren) {
        this.allowedChildren = allowedChildren;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((allowedChildren == null) ? 0 : allowedChildren.hashCode());
        result = prime * result + ((displayNameList == null) ? 0 : displayNameList.hashCode());
        result = prime * result + (firstLevel ? 1231 : 1237);
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((tagList == null) ? 0 : tagList.hashCode());
        result = prime * result + version;
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */

    @Override public boolean equals(Object o)
    {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        EnvelopeType that = (EnvelopeType) o;
        return version == that.version && firstLevel == that.firstLevel && active == that.active && Objects
                .equals(id, that.id) && Objects.equals(name, that.name) && Objects
                .equals(displayNameList, that.displayNameList) && Objects.equals(tagList, that.tagList) && Objects
                .equals(allowedChildren, that.allowedChildren);
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("EnvelopeType [id=");
        builder.append(id);
        builder.append(", version=");
        builder.append(version);
        builder.append(", name=");
        builder.append(name);
        builder.append(", firstLevel=");
        builder.append(firstLevel);
        builder.append(", displayNameList=");
        builder.append(displayNameList);
        builder.append(", tagList=");
        builder.append(tagList);
        builder.append(", allowedChildren=");
        builder.append(allowedChildren);
        builder.append("]");
        return builder.toString();
    }

}
