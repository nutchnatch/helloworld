package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * DocumentType
 */
public class DocumentType implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("id")
    private String id = null;

    @JsonProperty("version")
    private int version;

    @JsonProperty("name")
    private String name = null;

    @JsonProperty("displayNameList")
    private List<DisplayNameItem> displayNameList = new ArrayList<>();

    @JsonProperty("tagList")
    private List<AssociatedTag> tagList = new ArrayList<>();

    @JsonProperty("active")
    private boolean active;

    @JsonProperty("retentionDurationValue")
    private int retentionDurationValue;

    @JsonProperty("retentionDurationUnit")
    private String retentionDurationUnit;

    @JsonProperty("aclList")
    private List<Acl> aclList = new ArrayList<>();

    public DocumentType id(String id) {
        this.id = id;
        return this;
    }

    /**
     * Document type identification
     * 
     * @return id
     **/
    @ApiModelProperty(required = true, value = "Document type identification")
    @NotNull
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public DocumentType version(int version) {
        this.version = version;
        return this;
    }

    /**
     * Document type version
     * 
     * @return version
     **/
    @ApiModelProperty(required = true, value = "Document type version")
    @NotNull
    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public DocumentType name(String name) {
        this.name = name;
        return this;
    }

    /**
     * Name. Is the unic ID of the documentType
     * 
     * @return name
     **/
    @ApiModelProperty(required = true, value = "Name. Is the unic ID of the documentType")
    @NotNull
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public DocumentType displayNameList(List<DisplayNameItem> displayNameList) {
        this.displayNameList = displayNameList;
        return this;
    }

    public DocumentType addDisplayNameListItem(DisplayNameItem displayNameListItem) {
        if (this.displayNameList == null) {
            this.displayNameList = new ArrayList<>();
        }
        this.displayNameList.add(displayNameListItem);
        return this;
    }

    /**
     * Get displayNameList
     * 
     * @return displayNameList
     **/
    @ApiModelProperty(value = "")
    @Valid
    public List<DisplayNameItem> getDisplayNameList() {
        return displayNameList;
    }

    public void setDisplayNameList(List<DisplayNameItem> displayNameList) {
        this.displayNameList = displayNameList;
    }

    public DocumentType active(boolean active) {
        this.active = active;
        return this;
    }

    /**
     * active. indicate if the documentType is active or not..
     * 
     * @return name
     **/
    @ApiModelProperty(required = true, value = "active. indicate if the documentType is active or not..")
    @NotNull
    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public DocumentType tagList(List<AssociatedTag> tagList) {
        this.tagList = tagList;
        return this;
    }

    public DocumentType addTagListItem(AssociatedTag tagListItem) {
        if (this.tagList == null) {
            this.tagList = new ArrayList<>();
        }
        this.tagList.add(tagListItem);
        return this;
    }

    /**
     * List of tag associated to the document type. Some of which are mandatory
     * and some are optional.
     * 
     * @return tagList
     **/
    @ApiModelProperty(value = "List of tag associated to the document type. Some of which are mandatory and some are optional.")
    @Valid
    public List<AssociatedTag> getTagList() {
        return tagList;
    }

    public void setTagList(List<AssociatedTag> tagList) {
        this.tagList = tagList;
    }

    public DocumentType retentionDurationValue(int retentionDurationValue) {
        this.retentionDurationValue = retentionDurationValue;
        return this;
    }

    DocumentType aclList(List<Acl> aclList) {
        this.aclList = aclList;
        return this;
    }

    @ApiModelProperty(value = "List of Acl associated to the document type.")
    @Valid
    public List<Acl> getAclList() {
        return aclList;
    }

    public void setAclList(List<Acl> aclList) {
        this.aclList = aclList;
    }

    /**
     * Document type version
     * 
     * @return version
     **/
    @ApiModelProperty(required = true, value = "Retention Duration quantity")
    @NotNull
    public int getRetentionDurationValue() {
        return retentionDurationValue;
    }

    public void setRetentionDurationValue(int retentionDurationValue) {
        this.retentionDurationValue = retentionDurationValue;
    }

    public DocumentType retentionDurationUnit(String retentionDurationUnit) {
        this.retentionDurationUnit = retentionDurationUnit;
        return this;
    }

    /**
     * Document type version
     * 
     * @return version
     **/
    @ApiModelProperty(required = true, value = "Retention Duration Unit", allowableValues = "DAY,MONTH,YEAR")
    @NotNull
    public String getRetentionDurationUnit() {
        return retentionDurationUnit;
    }

    public void setRetentionDurationUnit(String retentionDurationUnit) {
        this.retentionDurationUnit = retentionDurationUnit;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (active ? 1231 : 1237);
        result = prime * result + ((displayNameList == null) ? 0 : displayNameList.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((retentionDurationUnit == null) ? 0 : retentionDurationUnit.hashCode());
        result = prime * result + retentionDurationValue;
        result = prime * result + ((tagList == null) ? 0 : tagList.hashCode());
        result = prime * result + version;
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */

    @Override public boolean equals(Object o)
    {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        DocumentType that = (DocumentType) o;
        return version == that.version
                && active == that.active
                && retentionDurationValue == that.retentionDurationValue
                && Objects.equals(id, that.id)
                && Objects.equals(name, that.name)
                && Objects.equals(displayNameList, that.displayNameList)
                && Objects.equals(tagList, that.tagList)
                && Objects.equals(retentionDurationUnit, that.retentionDurationUnit);
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("DocumentType [id=");
        builder.append(id);
        builder.append(", version=");
        builder.append(version);
        builder.append(", name=");
        builder.append(name);
        builder.append(", displayNameList=");
        builder.append(displayNameList);
        builder.append(", tagList=");
        builder.append(tagList);
        builder.append(", active=");
        builder.append(active);
        builder.append(", retentionDurationValue=");
        builder.append(retentionDurationValue);
        builder.append(", retentionDurationUnit=");
        builder.append(retentionDurationUnit);
        builder.append("]");
        return builder.toString();
    }

}
