package com.bnpp.cardif.sugar.rest.ui.controller.converter;

import java.util.ArrayList;
import java.util.List;

import com.bnpp.cardif.sugar.rest.ui.model.Task;
import com.bnpp.cardif.sugar.utils.DateUtils;

/**
 * 
 * @author 831743
 *
 */
public class TaskConverter {

    /**
     * private empty constructor
     */
    private TaskConverter() {
        // private constructor to avoid instance creation.
    }

    public static Task convert(com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task backendTask) {

        Task result = null;
        if (backendTask != null) {
            result = new Task();
            if (backendTask.getBasketId() != null) {
                result.setBasketId(backendTask.getBasketId().getValue());
            }
            if (backendTask.getCreatnDate() != null) {
                result.setCreationDate(DateUtils.asZonedDateTime(backendTask.getCreatnDate()));
            }
            if (backendTask.getDocID() != null && backendTask.getDocID().getId() != null) {
                result.setEnvelopeId(backendTask.getDocID().getId().getValue());
            }
            result.setLockName(backendTask.getLockerName());
            result.setName(backendTask.getName());
            result.setScope(backendTask.getScope());
            result.setStatus(backendTask.getStatus());
            if (backendTask.getTaskId() != null) {
                result.setTaskId(backendTask.getTaskId().getValue());
            }
            if (backendTask.getUpdtDate() != null) {
                result.setUpdateDate(DateUtils.asZonedDateTime(backendTask.getUpdtDate()));
            }
        }
        return result;
    }

    public static List<Task> convert(List<com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task> itemList) {
        
        List<Task> result = new ArrayList<>();
        if(itemList != null) {
            for (com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task backendTask : itemList) {
                Task content = TaskConverter.convert(backendTask);
                result.add(content);
            }
        }
        return result;
    }

}
