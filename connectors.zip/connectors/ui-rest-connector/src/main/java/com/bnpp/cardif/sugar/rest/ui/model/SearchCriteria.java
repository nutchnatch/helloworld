package com.bnpp.cardif.sugar.rest.ui.model;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @author 831743
 *
 */
@ApiModel(description = "Contains the search criteria for document and enveloppe search.")
public class SearchCriteria implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonProperty("docTypeIds")
    private List<String> docTypeIds = new ArrayList<>();

    @JsonProperty("name")
    private String name = null;

    @JsonProperty("nameOperator")
    private SearchOperator nameOperator;

    @JsonProperty("validityCode")
    private String validityCode = null;

    @JsonProperty("validityCodeOperator")
    private SearchOperator validityCodeOperator;

    @JsonProperty("creator")
    private String creator = null;

    @JsonProperty("creatorOperator")
    private SearchOperator creatorOperator;

    @JsonProperty("lastModifier")
    private String lastModifier = null;

    @JsonProperty("lastModifierOperator")
    private SearchOperator lastModifierOperator;

    @JsonProperty("creationDate")
    private ZonedDateTime creationDate = null;

    @JsonProperty("creationDateOperator")
    private SearchOperator creationDateOperator;

    @JsonProperty("updateDate")
    private ZonedDateTime updateDate = null;

    @JsonProperty("updateDateOperator")
    private SearchOperator updateDateOperator;

    @JsonProperty("confidentiality")
    private String confidentiality = null;

    @JsonProperty("confidentialityOperator")
    private SearchOperator confidentialityOperator;

    @JsonProperty("tagList")
    private List<TagSearchElement> tagList = new ArrayList<>();

    /**
     * @return the docTypeIds
     */
    @ApiModelProperty(value = "the list of documentType Ids to search")
    public List<String> getDocTypeIds() {
        return docTypeIds;
    }

    /**
     * @param docTypeIds
     *            the docTypeIds to set
     */
    public void setDocTypeIds(List<String> docTypeIds) {
        this.docTypeIds = docTypeIds;
    }

    /**
     * @return the name
     */
    @ApiModelProperty(value = "the document name to search")
    public String getName() {
        return name;
    }

    /**
     * @param name
     *            the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the nameOperator
     */
    @ApiModelProperty(value = "the search operator for document name", example = "starts_with", allowableValues = "not_equals_to, equals_to, contains, less_than, greater_than, starts_with, ends_with")
    public SearchOperator getNameOperator() {
        return nameOperator;
    }

    /**
     * @param nameOperator
     *            the nameOperator to set
     */
    public void setNameOperator(SearchOperator nameOperator) {
        this.nameOperator = nameOperator;
    }

    /**
     * @return the validityCode
     */
    @ApiModelProperty(value = "the document validity code to search")
    public String getValidityCode() {
        return validityCode;
    }

    /**
     * @param validityCode
     *            the validityCode to set
     */
    public void setValidityCode(String validityCode) {
        this.validityCode = validityCode;
    }

    /**
     * @return the validityCodeOperator
     */
    @ApiModelProperty(value = "the search operator for document validity code", example = "equals_to", allowableValues = "not_equals_to, equals_to, contains, less_than, greater_than, starts_with, ends_with")
    public SearchOperator getValidityCodeOperator() {
        return validityCodeOperator;
    }

    /**
     * @param validityCodeOperator
     *            the validityCodeOperator to set
     */
    public void setValidityCodeOperator(SearchOperator validityCodeOperator) {
        this.validityCodeOperator = validityCodeOperator;
    }

    /**
     * @return the creator
     */
    @ApiModelProperty(value = "the document creator name to search")
    public String getCreator() {
        return creator;
    }

    /**
     * @param creator
     *            the creator to set
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * @return the creatorOperator
     */
    @ApiModelProperty(value = "the search operator for document creator name", example = "starts_with", allowableValues = "not_equals_to, equals_to, contains, less_than, greater_than, starts_with, ends_with")
    public SearchOperator getCreatorOperator() {
        return creatorOperator;
    }

    /**
     * @param creatorOperator
     *            the creatorOperator to set
     */
    public void setCreatorOperator(SearchOperator creatorOperator) {
        this.creatorOperator = creatorOperator;
    }

    /**
     * @return the lastModifier
     */
    @ApiModelProperty(value = "the document last modifier name to search")
    public String getLastModifier() {
        return lastModifier;
    }

    /**
     * @param lastModifier
     *            the lastModifier to set
     */
    public void setLastModifier(String lastModifier) {
        this.lastModifier = lastModifier;
    }

    /**
     * @return the lastModifierOperator
     */
    @ApiModelProperty(value = "the search operator for document last modifier", example = "starts_with", allowableValues = "not_equals_to, equals_to, contains, less_than, greater_than, starts_with, ends_with")
    public SearchOperator getLastModifierOperator() {
        return lastModifierOperator;
    }

    /**
     * @param lastModifierOperator
     *            the lastModifierOperator to set
     */
    public void setLastModifierOperator(SearchOperator lastModifierOperator) {
        this.lastModifierOperator = lastModifierOperator;
    }

    /**
     * @return the creationDate
     */
    @ApiModelProperty(value = "the document creation date to search", example = "2017-12-08T10:37:30+01:00")
    public ZonedDateTime getCreationDate() {
        return creationDate;
    }

    /**
     * @param creationDate
     *            the creationDate to set
     */
    public void setCreationDate(ZonedDateTime creationDate) {
        this.creationDate = creationDate;
    }

    /**
     * @return the creationDateOperator
     */
    @ApiModelProperty(value = "the search operator for document creation date", example = "greater_than", allowableValues = "not_equals_to, equals_to, contains, less_than, greater_than, starts_with, ends_with")
    public SearchOperator getCreationDateOperator() {
        return creationDateOperator;
    }

    /**
     * @param creationDateOperator
     *            the creationDateOperator to set
     */
    public void setCreationDateOperator(SearchOperator creationDateOperator) {
        this.creationDateOperator = creationDateOperator;
    }

    /**
     * @return the updateDate
     */
    @ApiModelProperty(value = "the document last update date to search", example = "2017-12-08T10:37:30+01:00")
    public ZonedDateTime getUpdateDate() {
        return updateDate;
    }

    /**
     * @param updateDate
     *            the updateDate to set
     */
    public void setUpdateDate(ZonedDateTime updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * @return the updateDateOperator
     */
    @ApiModelProperty(value = "the search operator for document last update date", example = "greater_than", allowableValues = "not_equals_to, equals_to, contains, less_than, greater_than, starts_with, ends_with")
    public SearchOperator getUpdateDateOperator() {
        return updateDateOperator;
    }

    /**
     * @param updateDateOperator
     *            the updateDateOperator to set
     */
    public void setUpdateDateOperator(SearchOperator updateDateOperator) {
        this.updateDateOperator = updateDateOperator;
    }

    /**
     * @return the confidentiality
     */
    @ApiModelProperty(value = "the document confidentiality level to search")
    public String getConfidentiality() {
        return confidentiality;
    }

    /**
     * @param confidentiality
     *            the confidentiality to set
     */
    public void setConfidentiality(String confidentiality) {
        this.confidentiality = confidentiality;
    }

    /**
     * @return the confidentialityOperator
     */
    @ApiModelProperty(value = "the search operator for document confidentiality level", example = "equals_to", allowableValues = "not_equals_to, equals_to, contains, less_than, greater_than, starts_with, ends_with")
    public SearchOperator getConfidentialityOperator() {
        return confidentialityOperator;
    }

    /**
     * @param confidentialityOperator
     *            the confidentialityOperator to set
     */
    public void setConfidentialityOperator(SearchOperator confidentialityOperator) {
        this.confidentialityOperator = confidentialityOperator;
    }

    /**
     * @return the tagList
     */
    @ApiModelProperty(value = "the list of tags to search")
    public List<TagSearchElement> getTagList() {
        return tagList;
    }

    /**
     * @param tagList
     *            the tagList to set
     */
    public void setTagList(List<TagSearchElement> tagList) {
        this.tagList = tagList;
    }

    public SearchCriteria tagList(List<TagSearchElement> tagList) {
        this.tagList = tagList;
        return this;
    }

    public SearchCriteria addTagListItem(TagSearchElement tagListItem) {
        if (this.tagList == null) {
            this.tagList = new ArrayList<>();
        }
        this.tagList.add(tagListItem);
        return this;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @SuppressWarnings("squid:S3776")
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((confidentiality == null) ? 0 : confidentiality.hashCode());
        result = prime * result + ((confidentialityOperator == null) ? 0 : confidentialityOperator.hashCode());
        result = prime * result + ((creationDate == null) ? 0 : creationDate.hashCode());
        result = prime * result + ((creationDateOperator == null) ? 0 : creationDateOperator.hashCode());
        result = prime * result + ((creator == null) ? 0 : creator.hashCode());
        result = prime * result + ((creatorOperator == null) ? 0 : creatorOperator.hashCode());
        result = prime * result + ((docTypeIds == null) ? 0 : docTypeIds.hashCode());
        result = prime * result + ((lastModifier == null) ? 0 : lastModifier.hashCode());
        result = prime * result + ((lastModifierOperator == null) ? 0 : lastModifierOperator.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((nameOperator == null) ? 0 : nameOperator.hashCode());
        result = prime * result + ((tagList == null) ? 0 : tagList.hashCode());
        result = prime * result + ((updateDate == null) ? 0 : updateDate.hashCode());
        result = prime * result + ((updateDateOperator == null) ? 0 : updateDateOperator.hashCode());
        result = prime * result + ((validityCode == null) ? 0 : validityCode.hashCode());
        result = prime * result + ((validityCodeOperator == null) ? 0 : validityCodeOperator.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */

    @Override public boolean equals(Object o)
    {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        SearchCriteria that = (SearchCriteria) o;
        return Objects.equals(docTypeIds, that.docTypeIds) && Objects.equals(name, that.name)
                && nameOperator == that.nameOperator && Objects.equals(validityCode, that.validityCode)
                && validityCodeOperator == that.validityCodeOperator && Objects.equals(creator, that.creator)
                && creatorOperator == that.creatorOperator && Objects.equals(lastModifier, that.lastModifier)
                && lastModifierOperator == that.lastModifierOperator && Objects.equals(creationDate, that.creationDate)
                && creationDateOperator == that.creationDateOperator && Objects.equals(updateDate, that.updateDate)
                && updateDateOperator == that.updateDateOperator && Objects
                .equals(confidentiality, that.confidentiality)
                && confidentialityOperator == that.confidentialityOperator && Objects.equals(tagList, that.tagList);
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("SearchCriteria [docTypeIds=");
        builder.append(docTypeIds);
        builder.append(", name=");
        builder.append(name);
        builder.append(", nameOperator=");
        builder.append(nameOperator);
        builder.append(", validityCode=");
        builder.append(validityCode);
        builder.append(", validityCodeOperator=");
        builder.append(validityCodeOperator);
        builder.append(", creator=");
        builder.append(creator);
        builder.append(", creatorOperator=");
        builder.append(creatorOperator);
        builder.append(", lastModifier=");
        builder.append(lastModifier);
        builder.append(", lastModifierOperator=");
        builder.append(lastModifierOperator);
        builder.append(", creationDate=");
        builder.append(creationDate);
        builder.append(", creationDateOperator=");
        builder.append(creationDateOperator);
        builder.append(", updateDate=");
        builder.append(updateDate);
        builder.append(", updateDateOperator=");
        builder.append(updateDateOperator);
        builder.append(", confidentiality=");
        builder.append(confidentiality);
        builder.append(", confidentialityOperator=");
        builder.append(confidentialityOperator);
        builder.append(", tagList=");
        builder.append(tagList);
        builder.append("]");
        return builder.toString();
    }

}
