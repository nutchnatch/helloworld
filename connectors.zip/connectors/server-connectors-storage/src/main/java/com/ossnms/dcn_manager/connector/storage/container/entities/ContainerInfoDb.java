package com.ossnms.dcn_manager.connector.storage.container.entities;

import com.google.common.base.Function;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerCreationDescriptor;
import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import org.apache.commons.lang3.builder.EqualsBuilder;

import javax.annotation.Nonnull;
import java.util.Objects;
import java.util.Optional;

public class ContainerInfoDb extends BaseContainerInfoDb<ContainerInfo> {
    private static final long serialVersionUID = 4481246709165701310L;

    public static final Function<ContainerInfoDb, ContainerInfo> BUILDER = input -> null != input ?
            input.build() :
            null;

    public ContainerInfoDb() {

    }

    public ContainerInfoDb(@Nonnull Integer id, int version, @Nonnull Optional<Integer> parentId, @Nonnull String containerName) {
        super(id, version, parentId, containerName);
    }

    public ContainerInfoDb(@Nonnull ContainerCreationDescriptor descriptor) {
        super(descriptor.getName());
        setContainerDescription(descriptor.getDescription());
        setContainerUserText(descriptor.getUserText());
        setParentId(descriptor.getParentIdentifier());
    }

    public ContainerInfoDb(@Nonnull final ContainerInfo containerInfo) {
        setContainerId(containerInfo.getId());
        setContainerName(containerInfo.getName());
        setVersion(containerInfo.getVersion());
        setContainerDescription(containerInfo.getDescription());
        setContainerUserText(containerInfo.getUserText());
        setParentId(containerInfo.getParentId());
    }

    @Override public ContainerInfo build() {
        return new ContainerInfo(getContainerId(), getVersion(), getParentId(), getContainerName(),
                getContainerDescription(), getContainerUserText());
    }

    @Override public int hashCode() {
        return Objects.hash(getContainerId(), getVersion(), getContainerName());
    }

    @Override public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final ContainerInfoDb rhs = (ContainerInfoDb) obj;
        return new EqualsBuilder()
                .append(getContainerId(), rhs.getContainerId())
                .append(getVersion(), rhs.getVersion())
                .append(getContainerName(), rhs.getContainerName())
                .isEquals();
    }
}
