package com.ossnms.dcn_manager.connector.storage.channel.entities;

import com.ossnms.dcn_manager.connector.storage.BusinessObjectDb;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesPrototype;

import javax.annotation.Nonnull;

public class ChannelUserPreferencesDb
        extends ChannelUserPreferencesPrototype<ChannelUserPreferencesDb>
        implements BusinessObjectDb<ChannelUserPreferencesData> {

    private int channelId;
    private int versionNumber;

    public ChannelUserPreferencesDb() {

    }

    public ChannelUserPreferencesDb(int id, @Nonnull ChannelUserPreferencesPrototype<?> prototype) {
        super(prototype);
        channelId = id;
    }

    public ChannelUserPreferencesDb(int id, int version, @Nonnull ChannelUserPreferencesData copy) {
        channelId = id;
        versionNumber = version;

        setName(copy.getName());
        setReconnectInterval(copy.getReconnectInterval());
        setConcurrentActivationsLimited(copy.isConcurrentActivationsLimited());
        setConcurrentActivationsLimit(copy.getConcurrentActivationsLimit());
        setProperties(copy.getAllOpaqueProperties());
        setUserText(copy.getUserText());
    }

    @Override
    public ChannelUserPreferencesData build() {
        return new ChannelUserPreferencesData(channelId, versionNumber, this);
    }

    @Override
    protected ChannelUserPreferencesDb self() {
        return this;
    }

}
