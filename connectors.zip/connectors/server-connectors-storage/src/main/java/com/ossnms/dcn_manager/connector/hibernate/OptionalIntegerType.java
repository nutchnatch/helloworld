package com.ossnms.dcn_manager.connector.hibernate;

import org.hibernate.type.IntegerType;

public final class OptionalIntegerType extends OptionalTypes<Integer> {

    public OptionalIntegerType() {
        super(IntegerType.INSTANCE);
    }

}