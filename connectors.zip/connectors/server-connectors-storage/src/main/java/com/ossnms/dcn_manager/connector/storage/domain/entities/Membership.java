package com.ossnms.dcn_manager.connector.storage.domain.entities;

/** Types of NE/Domain membership. */
public enum Membership {
    /** The NE has been placed directly inside the domain. */
    NATURAL,
    /** The NE membership is inherited, for example, through a route. */
    TRANSITIVE
}