package com.ossnms.dcn_manager.connector.jpa;

import java.util.List;
import java.util.Map;
import java.util.Spliterator;
import java.util.Spliterators;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import javax.persistence.EntityManager;

import com.mysema.commons.lang.CloseableIterator;
import com.mysema.query.QueryModifiers;
import com.mysema.query.ResultTransformer;
import com.mysema.query.SearchResults;
import com.mysema.query.Tuple;
import com.mysema.query.jpa.impl.JPAQuery;
import com.mysema.query.types.EntityPath;
import com.mysema.query.types.Expression;
import com.mysema.query.types.OrderSpecifier;
import com.mysema.query.types.ParamExpression;
import com.mysema.query.types.Predicate;
import com.ossnms.dcn_manager.core.storage.Query;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

public class JpaCloseableQuery implements Query<JpaCloseableQuery> {

    private final JPAQuery delegate;
    private final EntityManager entityManager;

    public JpaCloseableQuery(EntityManager entityManager, EntityPath<?> path) {
        this.entityManager = entityManager;
        this.delegate = new JPAQuery(entityManager).from(path);
    }

    @Override
    public void close() throws RepositoryException {
        try {
            entityManager.close();
        } catch (final RuntimeException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public long count() {
        return delegate.count();
    }

    @Override
    public boolean exists() {
        return delegate.exists();
    }

    @Override
    public boolean notExists() {
        return delegate.notExists();
    }

    private <T> Stream<T> asStream(CloseableIterator<T> iterator) {
        final Spliterator<T> spliterator = Spliterators.spliteratorUnknownSize(
                iterator,
                Spliterator.IMMUTABLE | Spliterator.NONNULL | Spliterator.ORDERED);
        return StreamSupport.stream(spliterator, false).onClose(() -> iterator.close());
    }

    /** Provides a stream view over a query projection. */
    public <RT> Stream<RT> stream(Expression<RT> projection) {
        return asStream(delegate.iterate(projection));
    }

    /** Provides a stream view over a query projection. */
    public Stream<Tuple> stream(Expression<?>... projection) {
        return asStream(delegate.iterate(projection));
    }

    @Override
    public CloseableIterator<Tuple> iterate(Expression<?>... args) {
        return delegate.iterate(args);
    }

    @Override
    public <RT> CloseableIterator<RT> iterate(Expression<RT> projection) {
        return delegate.iterate(projection);
    }

    @Override
    public List<Tuple> list(Expression<?>... args) {
        return delegate.list(args);
    }

    @Override
    public <RT> List<RT> list(Expression<RT> projection) {
        return delegate.list(projection);
    }

    @Override
    public SearchResults<Tuple> listResults(Expression<?>... args) {
        return delegate.listResults(args);
    }

    @Override
    public <RT> SearchResults<RT> listResults(Expression<RT> projection) {
        return delegate.listResults(projection);
    }

    @Override
    public <K, V> Map<K, V> map(Expression<K> key, Expression<V> value) {
        return delegate.map(key, value);
    }

    @Override
    public Tuple singleResult(Expression<?>... args) {
        return delegate.singleResult(args);
    }

    @Override
    public <RT> RT singleResult(Expression<RT> projection) {
        return delegate.singleResult(projection);
    }

    @Override
    public <T> T transform(ResultTransformer<T> transformer) {
        return delegate.transform(transformer);
    }

    @Override
    public Tuple uniqueResult(Expression<?>... args) {
        return delegate.uniqueResult(args);
    }

    @Override
    public <RT> RT uniqueResult(Expression<RT> projection) {
        return delegate.uniqueResult(projection);
    }

    @Override
    public JpaCloseableQuery limit(long limit) {
        delegate.limit(limit);
        return this;
    }

    @Override
    public JpaCloseableQuery offset(long offset) {
        delegate.offset(offset);
        return this;
    }

    @Override
    public JpaCloseableQuery restrict(QueryModifiers modifiers) {
        delegate.restrict(modifiers);
        return this;
    }

    @Override
    public JpaCloseableQuery orderBy(OrderSpecifier<?>... o) {
        delegate.orderBy(o);
        return this;
    }

    @Override
    public <T> JpaCloseableQuery set(ParamExpression<T> param, T value) {
        delegate.set(param, value);
        return this;
    }

    @Override
    public JpaCloseableQuery distinct() {
        delegate.distinct();
        return this;
    }

    @Override
    public JpaCloseableQuery where(Predicate o) {
        delegate.where(o);
        return this;
    }

    @Override
    public JpaCloseableQuery where(Predicate... o) {
        delegate.where(o);
        return this;
    }

}
