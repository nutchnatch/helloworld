package com.ossnms.dcn_manager.connector.jpa;

import java.util.Optional;

import javax.annotation.Nonnull;

public class JpaExceptionsHelper {

    /**
     * Searches for a throwable of a specific type in the list of causes of a top level throwable.
     *
     * @param throwable Top level throwable.
     * @param cause Desired throwable type.
     * @return The throwable found.
     */
    public static <T extends Throwable> Optional<Throwable> tryFindInChain(@Nonnull Throwable throwable, @Nonnull Class<T> cause) {
        Throwable t = throwable;
        while (null != t) {
            if (cause.isInstance(t)) {
                return Optional.of(t);
            }
            t = t.getCause();
        }
        return Optional.empty();
    }


}
