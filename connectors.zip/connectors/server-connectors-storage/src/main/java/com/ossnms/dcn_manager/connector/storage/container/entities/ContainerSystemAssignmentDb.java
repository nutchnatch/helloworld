package com.ossnms.dcn_manager.connector.storage.container.entities;

import com.google.common.base.Function;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.SystemAssignmentData;
import org.apache.commons.lang3.builder.EqualsBuilder;

import javax.annotation.Nonnull;
import java.io.Serializable;
import java.util.Objects;

/**
 * Association class between Containers and Systems. Allows to specify whether
 * this is a "primary" or "logical" container assignmentType.
 */
public class ContainerSystemAssignmentDb implements Serializable {
    private static final long serialVersionUID = -4842510680363126921L;

    private ContainerSystemKey containerSystemKey;
    private AssignmentType assignmentType;

    public static final Function<ContainerSystemAssignmentDb, SystemAssignmentData> BUILDER = input -> null != input ?
            input.build() :
            null;

    public ContainerSystemAssignmentDb() {
    }

    public ContainerSystemAssignmentDb(@Nonnull final ContainerSystemKey containerSystemKey,
            @Nonnull final AssignmentType assignmentType) {
        this.containerSystemKey = containerSystemKey;
        this.assignmentType = assignmentType;
    }

    public ContainerSystemAssignmentDb(@Nonnull final SystemAssignmentData systemAssignmentData) {
        containerSystemKey = new ContainerSystemKey(new ContainerInfoDb(systemAssignmentData.getContainerInfo()),
                systemAssignmentData.getSystemContainerId());
        assignmentType = systemAssignmentData.getAssignmentType();
    }

    public SystemAssignmentData build() {
        return new SystemAssignmentData(ContainerInfoDb.BUILDER.apply(containerSystemKey.getContainerInfo()),
                containerSystemKey.getSystemContainerId(), assignmentType);
    }

    @Override public int hashCode() {
        return Objects.hash(containerSystemKey.hashCode());
    }

    @Override public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final ContainerSystemAssignmentDb rhs = (ContainerSystemAssignmentDb) obj;
        return new EqualsBuilder().append(containerSystemKey, rhs.containerSystemKey).isEquals();
    }

    public ContainerSystemKey getContainerSystemKey() {
        return containerSystemKey;
    }

    public void setContainerSystemKey(ContainerSystemKey containerSystemKey) {
        this.containerSystemKey = containerSystemKey;
    }

    public AssignmentType getAssignmentType() {
        return assignmentType;
    }

    public void setAssignmentType(AssignmentType assignmentType) {
        this.assignmentType = assignmentType;
    }
}
