package com.ossnms.dcn_manager.connector.storage.ne.entities;

import com.ossnms.dcn_manager.connector.storage.ne.entities.NeConnectionRouteDbKey.Type;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionRouteData.NeConnectionRoutePrototype;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;

import javax.annotation.Nonnull;

public class NeGatewayRouteDb extends NeConnectionRouteDb<NeGatewayRouteData, NeGatewayRouteDb> {

    public NeGatewayRouteDb() {
        super(Type.GATEWAY);
    }

    public NeGatewayRouteDb(int neId, NeConnectionRoutePrototype<?, ?> other) {
        super(Type.GATEWAY, neId, other);
    }

    public NeGatewayRouteDb(@Nonnull NeGatewayRouteData copy) {
        super(Type.GATEWAY);
        setNeId(copy.getId());
        setVersion(copy.getVersion());
        setCost(copy.getCost());
        setDomain(copy.getDomain());
        setKey(copy.getKey());
        setGneName(copy.getGneName());
        getRouteKey().setKey(copy.getKey());
        setPriority(copy.getPriority());
        setProperties(copy.getAllOpaqueProperties());
        setUsed(copy.isUsed());
    }

    @Override
    protected NeGatewayRouteDb self() {
        return this;
    }

    public NeGatewayRouteData build() {
        setKey(getRouteKey().getKey());
        return new NeGatewayRouteData(getNeId(), getVersion(), this);
    }

}
