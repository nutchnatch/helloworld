package com.ossnms.dcn_manager.connector.hibernate;

import org.hibernate.type.BooleanType;

public final class OptionalBooleanType extends OptionalTypes<Boolean> {

    public OptionalBooleanType() {
        super(BooleanType.INSTANCE);
    }

}