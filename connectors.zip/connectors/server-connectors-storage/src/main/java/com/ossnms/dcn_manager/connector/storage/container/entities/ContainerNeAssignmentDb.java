package com.ossnms.dcn_manager.connector.storage.container.entities;

import com.google.common.base.Function;
import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;
import com.ossnms.dcn_manager.core.entities.container.assignment.NeAssignmentData;
import org.apache.commons.lang3.builder.EqualsBuilder;

import javax.annotation.Nonnull;
import java.io.Serializable;
import java.util.Objects;

/**
 * Association class between Containers and NEs. Allows to specify whether
 * this is a "primary" or "logical" container assignmentType.
 */
public class ContainerNeAssignmentDb implements Serializable {
    private static final long serialVersionUID = -2891525697640494964L;

    private ContainerNeKey containerNeKey;
    private AssignmentType assignmentType;

    public static final Function<ContainerNeAssignmentDb, NeAssignmentData> BUILDER = input -> null != input ?
            input.build() :
            null;

    public ContainerNeAssignmentDb() {
    }

    public ContainerNeAssignmentDb(@Nonnull final ContainerNeKey containerNeKey, @Nonnull final AssignmentType assignmentType) {
        this.containerNeKey = containerNeKey;
        this.assignmentType = assignmentType;
    }

    public ContainerNeAssignmentDb(@Nonnull final NeAssignmentData neAssignmentData) {

        containerNeKey = new ContainerNeKey(new ContainerInfoDb(neAssignmentData.getContainerInfo()), neAssignmentData.getNeId());
        assignmentType = neAssignmentData.getAssignmentType();
    }

    public NeAssignmentData build() {
        return new NeAssignmentData(ContainerInfoDb.BUILDER.apply(containerNeKey.getContainerInfo()), containerNeKey.getNeId(), assignmentType);
    }

    @Override public int hashCode() {
        return Objects.hash(containerNeKey.hashCode());
    }

    @Override public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final ContainerNeAssignmentDb rhs = (ContainerNeAssignmentDb) obj;
        return new EqualsBuilder().append(containerNeKey, rhs.containerNeKey).isEquals();
    }

    public ContainerNeKey getContainerNeKey() {
        return containerNeKey;
    }

    public void setContainerNeKey(ContainerNeKey containerNeKey) {
        this.containerNeKey = containerNeKey;
    }

    public AssignmentType getAssignmentType() {
        return assignmentType;
    }

    public void setAssignmentType(AssignmentType assignmentType) {
        this.assignmentType = assignmentType;
    }
}
