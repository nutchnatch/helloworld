package com.ossnms.dcn_manager.connector.jpa;

import com.google.common.base.Supplier;
import com.ossnms.dcn_manager.connector.storage.BusinessObjectDb;
import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import javax.persistence.PersistenceException;

public abstract class JpaAnchorDomainObjectRepository
    <T extends BusinessObjectData, M extends MutationDescriptor<T, M>, D extends BusinessObjectDb<T>, P>
        extends JpaDomainObjectRepository<T, M, D, P> {

    private final String selectAllIdsNamedQuery;

    public JpaAnchorDomainObjectRepository(
            @Nonnull Class<D> dbClass, @Nonnull Supplier<CloseableEntityTransaction> transactionSupplier,
            @Nonnull String selectAllNamedQuery, @Nonnull String selectAllIdsNamedQuery) {
        super(dbClass, transactionSupplier, selectAllNamedQuery);
        this.selectAllIdsNamedQuery = selectAllIdsNamedQuery;
    }

    public T insert(P initialData) throws RepositoryException {
        return persist(buildDatabaseObjectForInsert(initialData))
                .map(getDataBuilder()::apply)
                .get();
    }

    public T insert(@Nonnull CloseableEntityTransaction tx, @Nonnull P initialData)
            throws RepositoryException {
        try {
            final D dbObject = buildDatabaseObjectForInsert(initialData);
            tx.getEntityManager().persist(dbObject);
            return getDataBuilder().apply(dbObject);
        } catch (final PersistenceException exception) {
            throw new RepositoryException(exception);
        }
    }

    public Iterable<Integer> queryAllEntityIdentifiers() throws RepositoryException {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            return tx.getEntityManager()
                    .createNamedQuery(selectAllIdsNamedQuery, Integer.class)
                    .getResultList();
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    protected abstract D buildDatabaseObjectForInsert(int parentId, P objectPrototype);

    protected abstract D buildDatabaseObjectForInsert(P objectPrototype);

}
