package com.ossnms.dcn_manager.connector.storage.mediator;

import com.mysema.query.collections.CollQuery;
import com.mysema.query.collections.CollQueryFactory;
import com.ossnms.dcn_manager.composables.storage.InMemoryDomainObjectRepository;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.QMediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorInstanceEntityRepository;

/**
 * Concrete type that supports an in-memory implementation of the
 * {@link com.ossnms.bicnet.emne.core.storage.mediator.MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository}
 * interface.
 * Because there is no need for further specialization of the {@link InMemoryDomainObjectRepository}
 * implementation, this type's sole purpose is to define a symbol to be used internally.
 */
class InMemoryMediatorPhysicalConnectionRepository
    extends InMemoryDomainObjectRepository<MediatorPhysicalConnectionData, MediatorPhysicalConnectionMutationDescriptor>
    implements MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository {

    @Override
    public CollQuery query(QMediatorPhysicalConnectionData info) {
        return CollQueryFactory.from(info, queryAll());
    }

    @Override
    public Iterable<MediatorPhysicalConnectionData> queryAll(int logicalMediatorId) {
        final QMediatorPhysicalConnectionData connectionData = QMediatorPhysicalConnectionData.mediatorPhysicalConnectionData;
        return query(connectionData).where(connectionData.logicalMediatorId.eq(logicalMediatorId)).list(connectionData);
    }

}
