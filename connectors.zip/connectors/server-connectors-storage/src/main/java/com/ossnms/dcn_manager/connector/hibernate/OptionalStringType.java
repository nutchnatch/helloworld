package com.ossnms.dcn_manager.connector.hibernate;

import org.hibernate.type.StringType;

public final class OptionalStringType extends OptionalTypes<String> {

    public OptionalStringType() {
        super(StringType.INSTANCE);
    }

}