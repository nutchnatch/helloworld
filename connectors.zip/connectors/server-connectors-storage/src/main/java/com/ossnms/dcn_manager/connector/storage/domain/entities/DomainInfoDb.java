package com.ossnms.dcn_manager.connector.storage.domain.entities;

import java.io.Serializable;
import java.util.Objects;

import org.apache.commons.lang3.builder.EqualsBuilder;

import com.google.common.base.Function;
import com.ossnms.dcn_manager.connector.storage.BusinessObjectDb;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;

public class DomainInfoDb implements BusinessObjectDb<DomainInfoData>, Serializable {

    private static final long serialVersionUID = 6571035344558563318L;

    private int domainId;
    private int version;
    private String domainName;
    private boolean automaticNeActivationPermitted;

    public static final Function<DomainInfoDb, DomainInfoData> BUILDER = new Function<DomainInfoDb, DomainInfoData>() {
        @Override
        public DomainInfoData apply(DomainInfoDb input) {
            return null != input ? input.build() : null;
        }
    };

    public DomainInfoDb() {

    }

    public DomainInfoDb(String domainName, boolean automaticNeActivationPermitted) {
        this.domainName = domainName;
        this.setAutomaticNeActivationPermitted(automaticNeActivationPermitted);
    }

    public DomainInfoDb(int domainId, int version, String domainName, boolean automaticNeActivationPermitted) {
        this.domainId = domainId;
        this.version = version;
        this.domainName = domainName;
        this.setAutomaticNeActivationPermitted(automaticNeActivationPermitted);
    }

    @Override
    public int hashCode() {
        return Objects.hash(domainId, version, domainName, automaticNeActivationPermitted);
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final DomainInfoDb rhs = (DomainInfoDb) obj;
        return new EqualsBuilder()
                .append(domainId, rhs.domainId)
                .append(version, rhs.version)
                .append(domainName, rhs.domainName)
                .append(automaticNeActivationPermitted, rhs.automaticNeActivationPermitted)
                .isEquals();
    }

    @Override
    public DomainInfoData build() {
        return new DomainInfoData(domainId, version, domainName, isAutomaticNeActivationPermitted());
    }

    public int getDomainId() {
        return domainId;
    }

    public void setDomainId(int domainId) {
        this.domainId = domainId;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public boolean isAutomaticNeActivationPermitted() {
        return automaticNeActivationPermitted;
    }

    public void setAutomaticNeActivationPermitted(boolean automaticNeActivationPermitted) {
        this.automaticNeActivationPermitted = automaticNeActivationPermitted;
    }

}
