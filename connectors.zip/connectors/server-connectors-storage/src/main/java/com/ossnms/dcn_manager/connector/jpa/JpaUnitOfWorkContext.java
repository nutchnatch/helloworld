package com.ossnms.dcn_manager.connector.jpa;

import com.ossnms.dcn_manager.core.storage.uow.UowContext;

public class JpaUnitOfWorkContext implements UowContext, AutoCloseable {

    private final CloseableEntityTransaction transaction;

    public JpaUnitOfWorkContext(CloseableEntityTransaction transaction) {
        this.transaction = transaction;
    }

    public CloseableEntityTransaction getTransaction() {
        return transaction;
    }

    @Override
    public void close() {
        transaction.close();
    }
}
