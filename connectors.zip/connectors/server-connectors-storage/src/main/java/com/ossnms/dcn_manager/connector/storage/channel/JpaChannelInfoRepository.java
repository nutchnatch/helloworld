package com.ossnms.dcn_manager.connector.storage.channel;

import java.util.Collection;

import javax.persistence.PersistenceException;

import com.google.common.base.Supplier;
import com.google.common.collect.Collections2;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaAnchorDomainObjectRepository;
import com.ossnms.dcn_manager.connector.storage.channel.entities.ChannelInfoDb;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoInitialData;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

/**
 * Concrete type that supports a JPA implementation of the {@link ChannelInfoRepository}.
 */
public class JpaChannelInfoRepository
	    extends JpaAnchorDomainObjectRepository<ChannelInfoData, ChannelInfoMutationDescriptor, ChannelInfoDb, ChannelInfoInitialData>
		implements ChannelEntityRepository.ChannelInfoRepository {

    public JpaChannelInfoRepository(Supplier<CloseableEntityTransaction> transactionSupplier) {
        super(ChannelInfoDb.class, transactionSupplier,
            "ChannelInfoDb.SELECT_ALL", "ChannelInfoDb.SELECT_ALL_IDENTIFIERS");
    }

    @Override
    protected ChannelInfoDb buildDatabaseObjectForUpdate(ChannelInfoData targetObject, ChannelInfoData mutationResult) {
        return new ChannelInfoDb(targetObject.getId(), mutationResult.getMediatorId(), targetObject.getVersion(), mutationResult);
    }

    @Override
    protected ChannelInfoDb buildDatabaseObjectForInsert(ChannelInfoInitialData objectPrototype) {
        throw new UnsupportedOperationException();
    }

    @Override
    protected ChannelInfoDb buildDatabaseObjectForInsert(int parentId, ChannelInfoInitialData objectPrototype) {
        return new ChannelInfoDb(parentId, objectPrototype);
    }

    @Override
    public Collection<Integer> queryChannelIdsUnderMediator(int mediatorId) throws RepositoryException {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            return tx.getEntityManager()
                    .createNamedQuery("ChannelInfoDb.SELECT_IDS_UNDER_MEDIATOR", Integer.class)
                    .setParameter("mid", mediatorId)
                    .getResultList();
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public Collection<ChannelInfoData> queryActivationRequiredIs(int mediatorId, boolean activationRequired) throws RepositoryException {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            return Collections2.transform(
                    tx.getEntityManager()
                        .createNamedQuery("ChannelInfoDb.SELECT_BY_ACTIVATION", ChannelInfoDb.class)
                        .setParameter("mid", mediatorId)
                        .setParameter("act", activationRequired)
                        .getResultList(),
                    new BuildInfoDataFromDb());
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    public boolean channelsExist(int mediatorId) throws RepositoryException {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            return tx.getEntityManager()
                    .createNamedQuery("ChannelInfoDb.CHANNEL_COUNT_UNDER_MEDIATOR", Long.class)
                    .setParameter("mid", mediatorId)
                    .getSingleResult() > 0;
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

}