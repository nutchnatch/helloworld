package com.ossnms.dcn_manager.connector.storage;

import com.ossnms.dcn_manager.core.entities.BusinessObjectData;

public interface BusinessObjectDb<T extends BusinessObjectData> {

    T build();

}
