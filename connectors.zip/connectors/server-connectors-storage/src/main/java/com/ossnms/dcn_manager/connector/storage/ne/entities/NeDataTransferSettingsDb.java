package com.ossnms.dcn_manager.connector.storage.ne.entities;

import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySetters.NeDataTransferSettingsAdapter;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.DataTransferSettingsAdapter;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Optional;

public class NeDataTransferSettingsDb extends DataTransferSettingsAdapter {

    public NeDataTransferSettingsDb() {
        super();
    }

    @Nonnull
      public NeDataTransferSettingsDb from(@Nullable NeDataTransferSettingsAdapter<?> input) {
        if (null != input) {
            this.setIpAddress(input.getIpAddress());
            this.setIsScp(input.getIsScp());
            this.setPassword(input.getPassword());
            this.setUploadpath(input.getUploadpath());
            this.setUsername(input.getUsername());
        }
        return this;
    }

    @Nonnull
    public NeDataTransferSettingsDb from(@Nonnull NeUserPreferencesData input) {
        this.setIpAddress(input.getDataTransferSettings().getIpAddress());
        this.setIsScp(Optional.of(input.getDataTransferSettings().getIsScp()));
        this.setPassword(input.getDataTransferSettings().getPassword());
        this.setUploadpath(input.getDataTransferSettings().getUploadPath());
        this.setUsername(input.getDataTransferSettings().getUsername());

        return this;
    }
}
