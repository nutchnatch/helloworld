package com.ossnms.dcn_manager.connector.storage.ne.entities;

import com.ossnms.dcn_manager.connector.storage.ne.entities.NeConnectionRouteDbKey.Type;
import com.ossnms.dcn_manager.core.entities.ne.data.NeDirectRouteData;

public class NeDirectRouteDb extends NeConnectionRouteDb<NeDirectRouteData, NeDirectRouteDb> {

    public NeDirectRouteDb() {
        super(Type.DIRECT);
    }

    @Override
    protected NeDirectRouteDb self() {
        return this;
    }

}
