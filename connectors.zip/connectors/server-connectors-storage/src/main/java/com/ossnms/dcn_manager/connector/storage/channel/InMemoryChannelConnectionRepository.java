package com.ossnms.dcn_manager.connector.storage.channel;

import com.mysema.query.collections.CollQuery;
import com.mysema.query.collections.CollQueryFactory;
import com.ossnms.dcn_manager.composables.storage.InMemoryDomainObjectRepository;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.QChannelConnectionData;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository;

/**
 * Concrete type that supports an in-memory implementation of the {@link ChannelConnectionRepository}.
 */
public class InMemoryChannelConnectionRepository
        extends InMemoryDomainObjectRepository<ChannelConnectionData, ChannelConnectionMutationDescriptor>
	    implements ChannelEntityRepository.ChannelConnectionRepository {

    @Override
    public CollQuery query(QChannelConnectionData info) {
        return CollQueryFactory.from(info, queryAll());
    }

}