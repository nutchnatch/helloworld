package com.ossnms.dcn_manager.connector.storage.channel.entities;

public class ChannelEntityDb {

    private int channelId;
    private ChannelInfoDb info;
    private ChannelUserPreferencesDb preferences;

    /**
     * @return the channelId
     */
    public int getChannelId() {
        return channelId;
    }
    /**
     * @param channelId the channelId to set
     */
    public void setChannelId(int channelId) {
        this.channelId = channelId;
    }
    /**
     * @return the info
     */
    public ChannelInfoDb getInfo() {
        return info;
    }
    /**
     * @param info the info to set
     */
    public void setInfo(ChannelInfoDb info) {
        this.info = info;
    }
    /**
     * @return the preferences
     */
    public ChannelUserPreferencesDb getPreferences() {
        return preferences;
    }
    /**
     * @param preferences the preferences to set
     */
    public void setPreferences(ChannelUserPreferencesDb preferences) {
        this.preferences = preferences;
    }

}
