package com.ossnms.dcn_manager.connector.storage.channel;

import com.google.common.base.Supplier;
import com.ossnms.dcn_manager.connector.jpa.CloseableEntityTransaction;
import com.ossnms.dcn_manager.connector.jpa.JpaDomainObjectRepository;
import com.ossnms.dcn_manager.connector.storage.channel.entities.ChannelUserPreferencesDb;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesInitialData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.channel.ChannelEntityRepository.ChannelUserPreferencesRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;
import java.util.Optional;

/**
 * Concrete type that supports a JPA implementation of the {@link ChannelUserPreferencesRepository}.
 */
public class JpaChannelUserPreferencesRepository
        extends JpaDomainObjectRepository<ChannelUserPreferencesData, ChannelUserPreferencesMutationDescriptor, ChannelUserPreferencesDb, ChannelUserPreferencesInitialData>
	    implements ChannelUserPreferencesRepository {

    public JpaChannelUserPreferencesRepository(@Nonnull Supplier<CloseableEntityTransaction> transactionSupplier) {
        super(ChannelUserPreferencesDb.class, transactionSupplier,
            "ChannelUserPreferencesDb.SELECT_ALL");
    }

    @Override
    public Optional<ChannelUserPreferencesData> query(@Nonnull String channelName) throws RepositoryException {
        try (final CloseableEntityTransaction tx = getTransaction()) {
            try {
                return Optional.of(tx.getEntityManager()
                        .createNamedQuery("ChannelUserPreferencesDb.SELECT_BY_NAME", ChannelUserPreferencesDb.class)
                        .setParameter("name", channelName)
                        .getSingleResult())
                    .map(getDataBuilder()::apply);
            } catch (final NoResultException ex) {
                return Optional.empty();
            }
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    protected ChannelUserPreferencesDb buildDatabaseObjectForUpdate(ChannelUserPreferencesData targetObject, ChannelUserPreferencesData mutationResult) {
        return new ChannelUserPreferencesDb(targetObject.getId(), targetObject.getVersion(), mutationResult);
    }

    @Override
    protected ChannelUserPreferencesDb buildDatabaseObjectForInsert(int parentId, ChannelUserPreferencesInitialData initialData) {
        return new ChannelUserPreferencesDb(parentId, initialData);
    }

}