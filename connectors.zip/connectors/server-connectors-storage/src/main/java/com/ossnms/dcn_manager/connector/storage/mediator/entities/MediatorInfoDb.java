package com.ossnms.dcn_manager.connector.storage.mediator.entities;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.ossnms.dcn_manager.connector.storage.BusinessObjectDb;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoPrototype;

public class MediatorInfoDb extends MediatorInfoPrototype<MediatorInfoDb> implements BusinessObjectDb<MediatorInfoData> {

    private int id;
    private int versionNumber;

    public MediatorInfoDb() {

    }

    public MediatorInfoDb(int id, int versionNumber, MediatorInfoData copy) {
        this.id = id;
        this.versionNumber = versionNumber;

        setName(copy.getName());
        setTypeName(copy.getTypeName());
        setDescription(copy.getDescription());
        setActivationRequired(copy.isActivationRequired());
        setUserText(copy.getUserText());

        setConcurrentActivationsLimited(copy.isConcurrentActivationsLimited());
        setConcurrentActivationsLimit(copy.getConcurrentActivationsLimit());
        setReconnectAttemptInterval(copy.getReconnectAttemptInterval());

        setProperties(copy.getAllOpaqueProperties());
    }

    public MediatorInfoDb(MediatorInfoPrototype<?> prototype) {
        super(prototype);
    }

    @Override
    public MediatorInfoData build() {
        return new MediatorInfoData(id, versionNumber, this);
    }

    @Override
    protected MediatorInfoDb self() {
        return this;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("id", id)
                .append("versionNumber", versionNumber)
                .appendSuper(super.toString())
                .toString();
    }

}
