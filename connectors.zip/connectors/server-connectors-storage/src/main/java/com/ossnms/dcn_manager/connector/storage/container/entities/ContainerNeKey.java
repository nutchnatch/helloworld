package com.ossnms.dcn_manager.connector.storage.container.entities;

import org.apache.commons.lang3.builder.EqualsBuilder;

import java.io.Serializable;
import java.util.Objects;

/**
 * Maps the Association between Containers and NEs.
 */
public class ContainerNeKey implements Serializable {
    private static final long serialVersionUID = -5869640347328265452L;

    private ContainerInfoDb containerInfo;
    private int neId;

    public ContainerNeKey() {
    }

    public ContainerNeKey(final ContainerInfoDb containerInfo, final int neId) {
        this.containerInfo = containerInfo;
        this.neId = neId;
    }

    @Override public int hashCode() {
        return Objects.hash(containerInfo.getContainerId(), neId);
    }

    @Override public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final ContainerNeKey rhs = (ContainerNeKey) obj;
        return new EqualsBuilder().append(containerInfo.getContainerId(), rhs.containerInfo.getContainerId())
                .append(neId, rhs.neId).isEquals();
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public ContainerInfoDb getContainerInfo() {
        return containerInfo;
    }

    public void setContainerInfo(ContainerInfoDb containerInfo) {
        this.containerInfo = containerInfo;
    }

    public int getNeId() {
        return neId;
    }

    public void setNeId(int neId) {
        this.neId = neId;
    }
}
