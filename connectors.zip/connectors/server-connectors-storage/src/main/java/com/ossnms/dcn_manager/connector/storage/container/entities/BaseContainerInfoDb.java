package com.ossnms.dcn_manager.connector.storage.container.entities;

import com.ossnms.dcn_manager.connector.storage.BusinessObjectDb;
import com.ossnms.dcn_manager.core.entities.container.ContainerInfoBase;

import java.io.Serializable;
import java.util.Optional;

public abstract class BaseContainerInfoDb<T extends ContainerInfoBase> implements BusinessObjectDb<T>, Serializable {
    private static final long serialVersionUID = -5984513912772682473L;

    private Integer containerId;
    private Optional<Integer> parentId = Optional.empty();
    private int version;
    private String containerName;
    private Optional<String> containerDescription = Optional.empty();
    private Optional<String> containerUserText = Optional.empty();

    protected BaseContainerInfoDb() {

    }

    protected BaseContainerInfoDb(int containerId, int version, Optional<Integer> parentId, String containerName) {
        this.containerId = containerId;
        this.parentId = parentId;
        this.version = version;
        this.containerName = containerName;
    }

    public BaseContainerInfoDb(String systemName) {
        this.containerName = systemName;
    }

    public Integer getContainerId() {
        return containerId;
    }

    public void setContainerId(Integer containerId) {
        this.containerId = containerId;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public String getContainerName() {
        return containerName;
    }

    public void setContainerName(String systemName) {
        this.containerName = systemName;
    }

    public Optional<Integer> getParentId() {
        return parentId;
    }

    public void setParentId(Optional<Integer> parentId) {
        this.parentId = parentId;
    }

    public Optional<String> getContainerDescription() {
        return containerDescription;
    }

    public void setContainerDescription(Optional<String> containerDescription) {
        this.containerDescription = containerDescription;
    }

    public Optional<String> getContainerUserText() {
        return containerUserText;
    }

    public void setContainerUserText(Optional<String> containerUserText) {
        this.containerUserText = containerUserText;
    }
}
