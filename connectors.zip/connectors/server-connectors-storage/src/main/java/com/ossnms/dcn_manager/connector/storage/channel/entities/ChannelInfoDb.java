package com.ossnms.dcn_manager.connector.storage.channel.entities;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.connector.storage.BusinessObjectDb;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoPrototype;

public class ChannelInfoDb extends ChannelInfoPrototype<ChannelInfoDb> implements BusinessObjectDb<ChannelInfoData> {

    private int channelId;
    private int versionNumber;
    private int mediatorId;

    public ChannelInfoDb() {

    }

    public ChannelInfoDb(int mediatorId, @Nonnull ChannelInfoPrototype<?> prototype) {
        super(prototype);
        this.mediatorId = mediatorId;
    }

    public ChannelInfoDb(int id, int mediatorId, int version, @Nonnull ChannelInfoData copy) {
        this.channelId = id;
        this.mediatorId = mediatorId;
        this.versionNumber = version;

        setType(copy.getType());
        setCoreId(copy.getCoreId());
        setActivationRequired(copy.isActivationRequired());
    }

    @Override
    public ChannelInfoData build() {
        return new ChannelInfoData(channelId, versionNumber, mediatorId, this);
    }

    @Override
    protected ChannelInfoDb self() {
        return this;
    }
}
