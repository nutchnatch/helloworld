package com.ossnms.dcn_manager.connector.hibernate;

import com.ossnms.dcn_manager.core.entities.ne.data.types.TpGroupSettings;
import org.hibernate.HibernateException;
import org.hibernate.PropertyAccessException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.BooleanType;
import org.hibernate.type.Type;
import org.hibernate.usertype.CompositeUserType;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;
import java.util.Optional;

@SuppressWarnings("unchecked")
public class OptionalTpGroupSettingsType implements CompositeUserType {

    private static final int MULTIPLE_SUBGROUP_MEMBER = 0;
    private static final int SUBGROUPS_EQUAL = 1;
    private static final int MULTIPLE_GROUP_MEMBER = 2;
    private static final int ALWAYS_COMPATIBLE = 3;

    @Override
    public String[] getPropertyNames() {
        return new String[] {
            "multipleSubgroupMembership", "subgroupsMustBeEqual", "multipleGroupMembership", "alwaysCompatible"
            // "MULTIPLE_SUBGROUP_MEMBER", "SUBGROUPS_EQUAL", "MULTIPLE_GROUP_MEMBER", "ALWAYS_COMPATIBLE"
        };
    }

    @Override
    public Type[] getPropertyTypes() {
        return new Type[] {
            BooleanType.INSTANCE, BooleanType.INSTANCE, BooleanType.INSTANCE, BooleanType.INSTANCE
        };
    }

    @Override
    public Object getPropertyValue(Object component, int property) throws HibernateException {
        final Optional<TpGroupSettings> optionalGroupSettings = (Optional<TpGroupSettings>) component;
        if (optionalGroupSettings != null && optionalGroupSettings.isPresent()) {
            final TpGroupSettings tpGroupSettings = optionalGroupSettings.get();
            switch (property) {
            case MULTIPLE_SUBGROUP_MEMBER:
                return tpGroupSettings.isMultipleSubgroupMembership();
            case MULTIPLE_GROUP_MEMBER:
                return tpGroupSettings.isMultipleGroupMembership();
            case SUBGROUPS_EQUAL:
                return tpGroupSettings.isSubgroupsMustBeEqual();
            case ALWAYS_COMPATIBLE:
                return tpGroupSettings.isAlwaysCompatible();
            }
        }
        return null;
    }

    @Override
    public void setPropertyValue(Object component, int property, Object value)
            throws HibernateException {
        if (null != value) {
            throw new PropertyAccessException(null, "Can not set individual properties.", true, getClass(), getPropertyNames()[property]);
        }
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Class returnedClass() {
        return Optional.class;
    }

    @Override
    public boolean equals(Object x, Object y) throws HibernateException { // NOMPD: overriding CompositeUserType#equals, not Object#equals
        return Objects.equals(x, y);
    }

    @Override
    public int hashCode(Object x) throws HibernateException {
        return x.hashCode();
    }

    @Override
    public Object nullSafeGet(ResultSet rs, String[] names, SessionImplementor session, Object owner)
            throws HibernateException, SQLException {
        return Optional.of(
            new TpGroupSettings(rs.getBoolean(names[ALWAYS_COMPATIBLE]), rs.getBoolean(names[MULTIPLE_GROUP_MEMBER]),
                    rs.getBoolean(names[SUBGROUPS_EQUAL]), rs.getBoolean(names[MULTIPLE_SUBGROUP_MEMBER]))
        );
    }

    @Override
    public void nullSafeSet(PreparedStatement st, Object value, int index,
            SessionImplementor session) throws HibernateException, SQLException {
        final Optional<TpGroupSettings> optionalValue = (Optional<TpGroupSettings>) value;
        if (optionalValue != null && optionalValue.isPresent()) {
            final TpGroupSettings tpGroupSettings = optionalValue.get();
            st.setBoolean(index + ALWAYS_COMPATIBLE, tpGroupSettings.isAlwaysCompatible());
            st.setBoolean(index + MULTIPLE_GROUP_MEMBER, tpGroupSettings.isMultipleGroupMembership());
            st.setBoolean(index + SUBGROUPS_EQUAL, tpGroupSettings.isSubgroupsMustBeEqual());
            st.setBoolean(index + MULTIPLE_SUBGROUP_MEMBER, tpGroupSettings.isMultipleSubgroupMembership());
        } else {
            st.setObject(index + ALWAYS_COMPATIBLE, null);
            st.setObject(index + MULTIPLE_GROUP_MEMBER, null);
            st.setObject(index + SUBGROUPS_EQUAL, null);
            st.setObject(index + MULTIPLE_SUBGROUP_MEMBER, null);
        }
    }

    @Override
    public Object deepCopy(Object value) throws HibernateException {
        return value;
    }

    @Override
    public boolean isMutable() {
        return false;
    }

    @SuppressWarnings("rawtypes")
    @Override
    public Serializable disassemble(Object value, SessionImplementor session) throws HibernateException {
        return (Serializable) (value != null ? ((Optional) value).orElse(null) : null);
    }

    @Override
    public Object assemble(Serializable cached, SessionImplementor session, Object owner) throws HibernateException {
        return Optional.ofNullable(cached);
    }

    @Override
    public Object replace(Object original, Object target, SessionImplementor session, Object owner) throws HibernateException {
        return original;
    }

}
