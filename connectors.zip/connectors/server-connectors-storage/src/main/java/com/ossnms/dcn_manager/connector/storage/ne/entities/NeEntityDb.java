package com.ossnms.dcn_manager.connector.storage.ne.entities;

public class NeEntityDb {

    private int neId;
    private NeInfoDb info;
    private NeOperationDb operation;
    private NeUserPreferencesDb preferences;
    private NeSynchronizationDb synchronization;

    public int getNeId() {
        return neId;
    }
    public NeInfoDb getInfo() {
        return info;
    }
    public NeOperationDb getOperation() {
        return operation;
    }
    public NeUserPreferencesDb getPreferences() {
        return preferences;
    }
    public NeSynchronizationDb getSynchronization() {
        return synchronization;
    }

}
