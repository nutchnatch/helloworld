package com.ossnms.dcn_manager.connector.storage.mediator;

import com.ossnms.dcn_manager.composables.storage.InMemoryDomainObjectRepository;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository;

/**
 * Concrete type that supports an in-memory implementation of the
 * {@link com.ossnms.dcn_manager.core.storage.mediator.MediatorEntityRepository.MediatorConnectionRepository}
 * interface.
 * Because there is no need for further specialization of the {@link InMemoryDomainObjectRepository}
 * implementation, this type's sole purpose is to define a symbol to be used internally.
 */
public class InMemoryMediatorConnectionRepository
    extends InMemoryDomainObjectRepository<MediatorConnectionData, MediatorConnectionMutationDescriptor>
    implements MediatorEntityRepository.MediatorConnectionRepository {

}
