package com.ossnms.bicnet.emne.connector.storage.mediator;

import com.ossnms.bicnet.emne.composables.storage.InMemoryDomainObjectRepository;
import com.ossnms.bicnet.emne.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.bicnet.emne.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.bicnet.emne.core.storage.mediator.MediatorInstanceEntityRepository;

/**
 * Concrete type that supports an in-memory implementation of the
 * {@link com.ossnms.bicnet.emne.core.storage.mediator.MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository}
 * interface.
 * Because there is no need for further specialization of the {@link InMemoryDomainObjectRepository}
 * implementation, this type's sole purpose is to define a symbol to be used internally.
 */
class InMemoryMediatorPhysicalConnectionRepository
    extends InMemoryDomainObjectRepository<MediatorPhysicalConnectionData, MediatorPhysicalConnectionMutationDescriptor>
    implements MediatorInstanceEntityRepository.MediatorPhysicalConnectionRepository {

}
