package com.ossnms.bicnet.emne.connector.storage.ne;

import com.ossnms.bicnet.emne.composables.storage.InMemoryDomainObjectRepository;
import com.ossnms.bicnet.emne.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.bicnet.emne.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.bicnet.emne.core.storage.ne.NePhysicalConnectionRepository;

public class InMemoryNePhysicalConnectionRepository
        extends InMemoryDomainObjectRepository<NePhysicalConnectionData, NePhysicalConnectionMutationDescriptor>
        implements NePhysicalConnectionRepository {

}
