package com.ossnms.bicnet.emne.connector.storage.channel;

import com.ossnms.bicnet.emne.composables.storage.InMemoryDomainObjectRepository;
import com.ossnms.bicnet.emne.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.bicnet.emne.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.bicnet.emne.core.storage.channel.ChannelPhysicalConnectionRepository;

/**
 * Concrete type that supports an in-memory implementation of the {@link ChannelPhysicalConnectionRepository}.
 */
public class InMemoryPhysicalChannelConnectionRepository
        extends InMemoryDomainObjectRepository<ChannelPhysicalConnectionData, ChannelPhysicalConnectionMutationDescriptor>
	    implements ChannelPhysicalConnectionRepository {

}