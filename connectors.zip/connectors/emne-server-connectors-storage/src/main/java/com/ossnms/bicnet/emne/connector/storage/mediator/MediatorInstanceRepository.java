package com.ossnms.bicnet.emne.connector.storage.mediator;

import static com.google.common.collect.Iterables.filter;
import static org.slf4j.LoggerFactory.getLogger;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.annotation.Nonnull;
import javax.persistence.EntityManager;
import javax.persistence.OptimisticLockException;
import javax.persistence.PersistenceException;

import org.slf4j.Logger;

import com.google.common.base.Optional;
import com.google.common.base.Predicate;
import com.google.common.base.Supplier;
import com.google.common.collect.AbstractIterator;
import com.ossnms.bicnet.emne.connector.jpa.CloseableEntityTransaction;
import com.ossnms.bicnet.emne.connector.storage.StartableRepository;
import com.ossnms.bicnet.emne.connector.storage.mediator.entities.MediatorPhysicalDataDb;
import com.ossnms.bicnet.emne.core.entities.mediator.data.MediatorInstance;
import com.ossnms.bicnet.emne.core.entities.mediator.data.MediatorInstanceCreateDescriptor;
import com.ossnms.bicnet.emne.core.entities.mediator.data.MediatorInstanceDeleteDescriptor;
import com.ossnms.bicnet.emne.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.bicnet.emne.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.bicnet.emne.core.entities.mediator.data.MediatorPhysicalData;
import com.ossnms.bicnet.emne.core.entities.mediator.data.MediatorPhysicalDataMutationDescriptor;
import com.ossnms.bicnet.emne.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.bicnet.emne.exceptions.RepositoryException;

public abstract class MediatorInstanceRepository implements MediatorInstanceEntityRepository, StartableRepository {

    private static final Logger LOGGER = getLogger(MediatorInstanceRepository.class);

    private InMemoryMediatorPhysicalConnectionRepository connectionRepo;
    private JpaMediatorPhysicalDataRepository infoRepo;

    private Supplier<CloseableEntityTransaction> transactionSupplier;

    protected MediatorInstance create(CloseableEntityTransaction tx, int logicalMediatorId, MediatorInstanceCreateDescriptor descriptor) throws RepositoryException {

        // We use the Mediator Physical Data repository as the authority for the existence of the Domain Entity.
        final MediatorPhysicalData info = infoRepo.insert(tx, logicalMediatorId, descriptor.getInitialData());

        final MediatorPhysicalConnectionData connection =
                new MediatorPhysicalConnectionData(info.getId(), logicalMediatorId, info.getVersion(), descriptor.getConnectionInitialData());
        connectionRepo.insert(connection);

        return new MediatorInstance(info, connection);
    }

    protected void delete(CloseableEntityTransaction tx, MediatorInstanceDeleteDescriptor descriptor) throws RepositoryException {
        final int entityId = descriptor.getId();
        // Signal the removal of the domain entity instance by first removing from
        // the Mediator Physical Data repository (see comments on the implementation of the create method)
        infoRepo.remove(entityId);
        connectionRepo.remove(entityId);
    }

    @Override
    public MediatorPhysicalDataRepository getMediatorPhysicalDataRepository() {
        return infoRepo;
    }

    @Override
    public MediatorPhysicalConnectionRepository getMediatorPhysicalConnectionRepository() {
        return connectionRepo;
    }

    @Override
    public void updateInstance(int logicalMediatorId, @Nonnull Iterable<MediatorPhysicalDataMutationDescriptor> changes,
            @Nonnull Iterable<MediatorInstanceCreateDescriptor> creations) throws RepositoryException {

        final List<MediatorPhysicalDataDb> newInstances = new LinkedList<>();

        try (CloseableEntityTransaction tx = transactionSupplier.get()) {

            final EntityManager entityManager = tx.getEntityManager();

            for (final MediatorPhysicalDataMutationDescriptor change : changes) {
                final MediatorPhysicalData newData = change.apply();
                entityManager.merge(new MediatorPhysicalDataDb(newData.getId(), change.getTarget().getVersion(), newData));
            }
            for (final MediatorInstanceCreateDescriptor creation : creations) {
                newInstances.add(
                    entityManager.merge(new MediatorPhysicalDataDb(logicalMediatorId, creation.getInitialData())));
            }

        } catch (final OptimisticLockException e) {
            LOGGER.warn("Tried to update out-of-date mediator {} instance with {}, {}", logicalMediatorId, changes, creations);
            throw new RepositoryException(e);
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }

        for (final MediatorPhysicalDataDb data : newInstances) {
            connectionRepo.insert(new MediatorPhysicalConnectionBuilder().build(data.getId(), logicalMediatorId, 0));
        }
    }

    @Override
    public void deleteInstance(int physicalInstanceId) throws RepositoryException {

        infoRepo.remove(physicalInstanceId);
        connectionRepo.remove(physicalInstanceId);

    }

    @Override
    public Optional<MediatorInstance> query(int physicalMediatorId) throws RepositoryException {
        // Again, the order is important to ensure that only benign race conditions may occur
        final Optional<MediatorPhysicalData> info = infoRepo.query(physicalMediatorId);
        if (!info.isPresent()) {
            return Optional.absent();
        }

        return fetchMediatorInstanceFromMediatorData(info.get());
    }

    @Override
    public Iterable<MediatorInstance> queryAll() throws RepositoryException {
        final Iterable<MediatorPhysicalData> allInfos = infoRepo.queryAll();
        return transformToEntity(allInfos);
    }

    @Override
    public Iterable<MediatorInstance> queryAll(final int logicalMediatorId) throws RepositoryException {
        // There are just a few mediators in any system so we can save on database layer complexity and filter here.
        final Iterable<MediatorPhysicalData> specificInfos =
            filter(infoRepo.queryAll(),
                   new Predicate<MediatorPhysicalData>() {
                       @Override
                       public boolean apply(MediatorPhysicalData input) {
                           return input != null && input.getLogicalMediatorId() == logicalMediatorId;
                       }
                   });
        return transformToEntity(specificInfos);
    }

    private Iterable<MediatorInstance> transformToEntity(final Iterable<MediatorPhysicalData> allInfos) {
        return new Iterable<MediatorInstance>() {
            @Override
            public Iterator<MediatorInstance> iterator() {
                // Retain weak-consistent view of the current repo contents
                final Iterator<MediatorPhysicalData> sourceIterator = allInfos.iterator();
                return new AbstractIterator<MediatorInstance>() {
                    @Override
                    protected MediatorInstance computeNext() {
                        // Fetch next valid entity, if one exists
                        while(sourceIterator.hasNext()) {
                            final Optional<MediatorInstance> nextEntity = fetchMediatorInstanceFromMediatorData(sourceIterator.next());
                            if(nextEntity.isPresent()) {
                                return nextEntity.get();
                            }
                        }
                        return endOfData();
                    }
                };
            }
        };
    }

    /**
     * Helper method that gathers the remaining domain object instances associated to the domain entity
     * that has the given mediator physical data
     * @param mediatorInfo The object representing the mediator data part of the entity to be retrieved
     * @return An {@link Optional} bearing the retrieved entity, if one exists
     */
    private Optional<MediatorInstance> fetchMediatorInstanceFromMediatorData(MediatorPhysicalData mediatorPhysicalData) {
        final int entityId =  mediatorPhysicalData.getId();
        final Optional<MediatorPhysicalConnectionData> connection = connectionRepo.query(entityId);

        return connection.isPresent() ?
                Optional.of(new MediatorInstance(mediatorPhysicalData, connection.get())) :
                Optional.<MediatorInstance>absent();
    }

    protected void initialize(final Supplier<CloseableEntityTransaction> transactionSupplier) {
        this.transactionSupplier = transactionSupplier;
        this.connectionRepo = new InMemoryMediatorPhysicalConnectionRepository();
        this.infoRepo = new JpaMediatorPhysicalDataRepository(transactionSupplier);
    }

    @Override
    public void start() throws RepositoryException {
        LOGGER.info("Starting Mediator Instance Repository (JPA).");

        final Iterable<MediatorPhysicalData> all = infoRepo.queryAll();
        for (final MediatorPhysicalData mediatorPhysicalData : all) {
            final MediatorPhysicalConnectionData connection =
                new MediatorPhysicalConnectionBuilder().build(mediatorPhysicalData.getId(), mediatorPhysicalData.getLogicalMediatorId(), 0);
            connectionRepo.insert(connection);
        }
    }

}
