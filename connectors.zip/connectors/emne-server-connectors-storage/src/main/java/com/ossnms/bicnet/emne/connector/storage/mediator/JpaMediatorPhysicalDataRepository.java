package com.ossnms.bicnet.emne.connector.storage.mediator;

import javax.annotation.Nonnull;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;

import com.google.common.base.Optional;
import com.google.common.base.Supplier;
import com.ossnms.bicnet.emne.connector.jpa.CloseableEntityTransaction;
import com.ossnms.bicnet.emne.connector.jpa.JpaAnchorDomainObjectRepository;
import com.ossnms.bicnet.emne.connector.storage.mediator.entities.MediatorPhysicalDataDb;
import com.ossnms.bicnet.emne.core.entities.mediator.data.MediatorPhysicalData;
import com.ossnms.bicnet.emne.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataInitialData;
import com.ossnms.bicnet.emne.core.entities.mediator.data.MediatorPhysicalDataMutationDescriptor;
import com.ossnms.bicnet.emne.core.storage.mediator.MediatorInstanceEntityRepository;
import com.ossnms.bicnet.emne.exceptions.RepositoryException;

class JpaMediatorPhysicalDataRepository
        extends JpaAnchorDomainObjectRepository<MediatorPhysicalData, MediatorPhysicalDataMutationDescriptor, MediatorPhysicalDataDb, MediatorPhysicalDataInitialData>
        implements MediatorInstanceEntityRepository.MediatorPhysicalDataRepository {

    private final Supplier<CloseableEntityTransaction> transactionSupplier;

    public JpaMediatorPhysicalDataRepository(@Nonnull Supplier<CloseableEntityTransaction> transactionSupplier) {
        super(MediatorPhysicalDataDb.class, transactionSupplier, "MediatorPhysicalDataDb.SELECT_ALL", "MediatorPhysicalDataDb.SELECT_ALL_IDS");
        this.transactionSupplier = transactionSupplier;
    }

    @Override
    public Optional<MediatorPhysicalData> queryByHost(String hostName) throws RepositoryException {
        try (final CloseableEntityTransaction tx = transactionSupplier.get()) {

            final MediatorPhysicalDataDb mediatorPhysicalDataDb =
                tx.getEntityManager()
                    .createNamedQuery("MediatorPhysicalDataDb.SELECT_BY_HOST", MediatorPhysicalDataDb.class)
                    .setParameter("n", hostName)
                    .getSingleResult();

            return Optional.fromNullable(mediatorPhysicalDataDb).transform(getDataBuilder());
        } catch (final NoResultException e) {
            return Optional.absent();
        } catch (final PersistenceException e) {
            throw new RepositoryException(e);
        }
    }

    @Override
    protected MediatorPhysicalDataDb buildDatabaseObjectForInsert(int parentId, MediatorPhysicalDataInitialData objectPrototype) {
        return new MediatorPhysicalDataDb(parentId, objectPrototype);
    }

    @Override
    protected MediatorPhysicalDataDb buildDatabaseObjectForInsert(MediatorPhysicalDataInitialData objectPrototype) {
        return new MediatorPhysicalDataDb(objectPrototype);
    }

    @Override
    protected MediatorPhysicalDataDb buildDatabaseObjectForUpdate(MediatorPhysicalData targetObject,
            MediatorPhysicalData mutationResult) {
        return new MediatorPhysicalDataDb(targetObject.getId(), targetObject.getVersion(), mutationResult);
    }

}