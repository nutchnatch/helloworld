package com.ossnms.bicnet.emne.connector.storage.mediator;

import static com.ossnms.bicnet.emne.test.util.OtherMatchers.absent;
import static com.ossnms.bicnet.emne.test.util.OtherMatchers.present;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

import javax.persistence.PersistenceException;

import org.junit.Before;
import org.junit.Test;

import com.google.common.base.Optional;
import com.google.common.base.Supplier;
import com.ossnms.bicnet.emne.connector.jpa.CloseableEntityTransaction;
import com.ossnms.bicnet.emne.connector.storage.JpaRepositoryTestBase;
import com.ossnms.bicnet.emne.connector.storage.mediator.entities.MediatorPhysicalDataDb;
import com.ossnms.bicnet.emne.core.entities.mediator.data.MediatorPhysicalData;
import com.ossnms.bicnet.emne.core.entities.mediator.data.MediatorPhysicalData.MediatorPhysicalDataInitialData;
import com.ossnms.bicnet.emne.exceptions.RepositoryException;

public class JpaMediatorPhysicalDataRepositoryTest extends JpaRepositoryTestBase {

    private JpaMediatorPhysicalDataRepository repo;

    @Override
    @Before
    public void setUp() {
        super.setUp();

        repo = new JpaMediatorPhysicalDataRepository(
                new Supplier<CloseableEntityTransaction>() {
                    @Override
                    public CloseableEntityTransaction get() {
                        return tx;
                    }
                });
    }

    @Test
    public void insert() throws Exception {

        final MediatorPhysicalDataInitialData data =
            new MediatorPhysicalDataInitialData()
                .setHost("host")
                .setPriority(1);

        final MediatorPhysicalData inserted = repo.insert(tx, 34, data);
        assertThat(inserted.getHost(), is("host"));
        assertThat(inserted.getLogicalMediatorId(), is(34));
        assertThat(inserted.getPriority(), is(1));
    }

    @Test
    public void queryByHost() throws Exception {
        final MediatorPhysicalDataDb db =
            new MediatorPhysicalDataDb(11, new MediatorPhysicalDataInitialData()
                .setHost("host")
                .setPriority(1));
        mockSingleResultQuery("MediatorPhysicalDataDb.SELECT_BY_HOST", MediatorPhysicalDataDb.class, db);

        final Optional<MediatorPhysicalData> found = repo.queryByHost("host");
        assertThat(found, is(present()));
        assertThat(found.get().getHost(), is("host"));
        assertThat(found.get().getLogicalMediatorId(), is(11));
        assertThat(found.get().getPriority(), is(1));
    }

    @Test
    public void queryByHost_notFound_returnsAbsent() throws Exception {

        mockSingleResultQuery("MediatorPhysicalDataDb.SELECT_BY_HOST", MediatorPhysicalDataDb.class);

        final Optional<MediatorPhysicalData> found = repo.queryByHost("host");
        assertThat(found, is(absent()));
    }

    @Test(expected=RepositoryException.class)
    public void queryByHost_error_throws() throws Exception {

        when(entityManager.createNamedQuery("MediatorPhysicalDataDb.SELECT_BY_HOST", MediatorPhysicalDataDb.class))
            .thenThrow(new PersistenceException());

        repo.queryByHost("host");
    }
}
