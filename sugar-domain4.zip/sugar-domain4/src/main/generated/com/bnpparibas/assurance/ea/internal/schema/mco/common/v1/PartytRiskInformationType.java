
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type for to mange risk information for a third
 * 				party
 * 			
 * 
 * <p>Java class for PartytRiskInformationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartytRiskInformationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Ratng" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FinancialRatingType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="FinanclRatio" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ThirdPartyFinancialRatiosType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartytRiskInformationType", propOrder = {
    "ratng",
    "financlRatio"
})
public class PartytRiskInformationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Ratng")
    protected List<FinancialRatingType> ratng;
    @XmlElement(name = "FinanclRatio")
    protected List<ThirdPartyFinancialRatiosType> financlRatio;

    /**
     * Default no-arg constructor
     * 
     */
    public PartytRiskInformationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PartytRiskInformationType(final List<FinancialRatingType> ratng, final List<ThirdPartyFinancialRatiosType> financlRatio) {
        this.ratng = ratng;
        this.financlRatio = financlRatio;
    }

    /**
     * Gets the value of the ratng property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ratng property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRatng().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FinancialRatingType }
     * 
     * 
     */
    public List<FinancialRatingType> getRatng() {
        if (ratng == null) {
            ratng = new ArrayList<FinancialRatingType>();
        }
        return this.ratng;
    }

    public boolean isSetRatng() {
        return ((this.ratng!= null)&&(!this.ratng.isEmpty()));
    }

    public void unsetRatng() {
        this.ratng = null;
    }

    /**
     * Gets the value of the financlRatio property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the financlRatio property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFinanclRatio().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ThirdPartyFinancialRatiosType }
     * 
     * 
     */
    public List<ThirdPartyFinancialRatiosType> getFinanclRatio() {
        if (financlRatio == null) {
            financlRatio = new ArrayList<ThirdPartyFinancialRatiosType>();
        }
        return this.financlRatio;
    }

    public boolean isSetFinanclRatio() {
        return ((this.financlRatio!= null)&&(!this.financlRatio.isEmpty()));
    }

    public void unsetFinanclRatio() {
        this.financlRatio = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("ratng", ratng).add("financlRatio", financlRatio).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(ratng, financlRatio);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PartytRiskInformationType o = ((PartytRiskInformationType) other);
        return (Objects.equal(ratng, o.ratng)&&Objects.equal(financlRatio, o.financlRatio));
    }

}
