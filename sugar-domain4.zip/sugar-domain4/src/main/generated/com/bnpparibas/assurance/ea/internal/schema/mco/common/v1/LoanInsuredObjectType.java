
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * NOTE : Utilisé par
 * 				ProtectionPolicy -> doublon avec LoanInsuranceObjectDataType. A
 * 				remplacer?
 * 			
 * 
 * <p>Java class for LoanInsuredObjectType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LoanInsuredObjectType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="LoanlIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="Data" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PolicyUnderlyingLoanDataType"/&gt;
 *         &lt;element name="GoodsData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GoodsDataType" minOccurs="0"/&gt;
 *         &lt;element name="Instllmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LoanInstallmentOrSchedulePaymentDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="LoanStage" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LoanStageDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="LndrOrgansm" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LoanLenderOrganismDataType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LoanInsuredObjectType", propOrder = {
    "loanlIdntfctn",
    "data",
    "goodsData",
    "instllmnt",
    "loanStage",
    "lndrOrgansm"
})
public class LoanInsuredObjectType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "LoanlIdntfctn", required = true)
    protected ObjectIdentificationType loanlIdntfctn;
    @XmlElement(name = "Data", required = true)
    protected PolicyUnderlyingLoanDataType data;
    @XmlElement(name = "GoodsData")
    protected GoodsDataType goodsData;
    @XmlElement(name = "Instllmnt")
    protected List<LoanInstallmentOrSchedulePaymentDataType> instllmnt;
    @XmlElement(name = "LoanStage")
    protected List<LoanStageDataType> loanStage;
    @XmlElement(name = "LndrOrgansm")
    protected LoanLenderOrganismDataType lndrOrgansm;

    /**
     * Default no-arg constructor
     * 
     */
    public LoanInsuredObjectType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public LoanInsuredObjectType(final ObjectIdentificationType loanlIdntfctn, final PolicyUnderlyingLoanDataType data, final GoodsDataType goodsData, final List<LoanInstallmentOrSchedulePaymentDataType> instllmnt, final List<LoanStageDataType> loanStage, final LoanLenderOrganismDataType lndrOrgansm) {
        this.loanlIdntfctn = loanlIdntfctn;
        this.data = data;
        this.goodsData = goodsData;
        this.instllmnt = instllmnt;
        this.loanStage = loanStage;
        this.lndrOrgansm = lndrOrgansm;
    }

    /**
     * Gets the value of the loanlIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getLoanlIdntfctn() {
        return loanlIdntfctn;
    }

    /**
     * Sets the value of the loanlIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setLoanlIdntfctn(ObjectIdentificationType value) {
        this.loanlIdntfctn = value;
    }

    public boolean isSetLoanlIdntfctn() {
        return (this.loanlIdntfctn!= null);
    }

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     {@link PolicyUnderlyingLoanDataType }
     *     
     */
    public PolicyUnderlyingLoanDataType getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     {@link PolicyUnderlyingLoanDataType }
     *     
     */
    public void setData(PolicyUnderlyingLoanDataType value) {
        this.data = value;
    }

    public boolean isSetData() {
        return (this.data!= null);
    }

    /**
     * Gets the value of the goodsData property.
     * 
     * @return
     *     possible object is
     *     {@link GoodsDataType }
     *     
     */
    public GoodsDataType getGoodsData() {
        return goodsData;
    }

    /**
     * Sets the value of the goodsData property.
     * 
     * @param value
     *     allowed object is
     *     {@link GoodsDataType }
     *     
     */
    public void setGoodsData(GoodsDataType value) {
        this.goodsData = value;
    }

    public boolean isSetGoodsData() {
        return (this.goodsData!= null);
    }

    /**
     * Gets the value of the instllmnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the instllmnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInstllmnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LoanInstallmentOrSchedulePaymentDataType }
     * 
     * 
     */
    public List<LoanInstallmentOrSchedulePaymentDataType> getInstllmnt() {
        if (instllmnt == null) {
            instllmnt = new ArrayList<LoanInstallmentOrSchedulePaymentDataType>();
        }
        return this.instllmnt;
    }

    public boolean isSetInstllmnt() {
        return ((this.instllmnt!= null)&&(!this.instllmnt.isEmpty()));
    }

    public void unsetInstllmnt() {
        this.instllmnt = null;
    }

    /**
     * Gets the value of the loanStage property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the loanStage property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLoanStage().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LoanStageDataType }
     * 
     * 
     */
    public List<LoanStageDataType> getLoanStage() {
        if (loanStage == null) {
            loanStage = new ArrayList<LoanStageDataType>();
        }
        return this.loanStage;
    }

    public boolean isSetLoanStage() {
        return ((this.loanStage!= null)&&(!this.loanStage.isEmpty()));
    }

    public void unsetLoanStage() {
        this.loanStage = null;
    }

    /**
     * Gets the value of the lndrOrgansm property.
     * 
     * @return
     *     possible object is
     *     {@link LoanLenderOrganismDataType }
     *     
     */
    public LoanLenderOrganismDataType getLndrOrgansm() {
        return lndrOrgansm;
    }

    /**
     * Sets the value of the lndrOrgansm property.
     * 
     * @param value
     *     allowed object is
     *     {@link LoanLenderOrganismDataType }
     *     
     */
    public void setLndrOrgansm(LoanLenderOrganismDataType value) {
        this.lndrOrgansm = value;
    }

    public boolean isSetLndrOrgansm() {
        return (this.lndrOrgansm!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("loanlIdntfctn", loanlIdntfctn).add("data", data).add("goodsData", goodsData).add("instllmnt", instllmnt).add("loanStage", loanStage).add("lndrOrgansm", lndrOrgansm).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(loanlIdntfctn, data, goodsData, instllmnt, loanStage, lndrOrgansm);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final LoanInsuredObjectType o = ((LoanInsuredObjectType) other);
        return (((((Objects.equal(loanlIdntfctn, o.loanlIdntfctn)&&Objects.equal(data, o.data))&&Objects.equal(goodsData, o.goodsData))&&Objects.equal(instllmnt, o.instllmnt))&&Objects.equal(loanStage, o.loanStage))&&Objects.equal(lndrOrgansm, o.lndrOrgansm));
    }

}
