
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Document folder data
 * 			
 * 
 * <p>Java class for FolderDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FolderDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ClassId"/&gt;
 *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
 *         &lt;element name="Owner" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="Creator" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="LastModifier" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="CreatnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="UpdtDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="RetentionEndDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="CloseDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="StatusCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FolderStatusCodeType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FolderDataType", propOrder = {
    "classId",
    "name",
    "owner",
    "creator",
    "lastModifier",
    "creatnDate",
    "updtDate",
    "retentionEndDate",
    "closeDate",
    "statusCode"
})
public class FolderDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ClassId", required = true)
    protected ClassId classId;
    @XmlElement(name = "Name", required = true)
    protected String name;
    @XmlElement(name = "Owner")
    protected String owner;
    @XmlElement(name = "Creator")
    protected String creator;
    @XmlElement(name = "LastModifier")
    protected String lastModifier;
    @XmlElement(name = "CreatnDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date creatnDate;
    @XmlElement(name = "UpdtDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date updtDate;
    @XmlElement(name = "RetentionEndDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date retentionEndDate;
    @XmlElement(name = "CloseDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date closeDate;
    @XmlElement(name = "StatusCode")
    @XmlSchemaType(name = "string")
    protected FolderStatusCodeType statusCode;

    /**
     * Default no-arg constructor
     * 
     */
    public FolderDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FolderDataType(final ClassId classId, final String name, final String owner, final String creator, final String lastModifier, final Date creatnDate, final Date updtDate, final Date retentionEndDate, final Date closeDate, final FolderStatusCodeType statusCode) {
        this.classId = classId;
        this.name = name;
        this.owner = owner;
        this.creator = creator;
        this.lastModifier = lastModifier;
        this.creatnDate = creatnDate;
        this.updtDate = updtDate;
        this.retentionEndDate = retentionEndDate;
        this.closeDate = closeDate;
        this.statusCode = statusCode;
    }

    /**
     * Class of object: Code of document (Identity card,
     * 						Death certificate, subscription document, etc.
     * 					
     * 
     * @return
     *     possible object is
     *     {@link ClassId }
     *     
     */
    public ClassId getClassId() {
        return classId;
    }

    /**
     * Sets the value of the classId property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassId }
     *     
     */
    public void setClassId(ClassId value) {
        this.classId = value;
    }

    public boolean isSetClassId() {
        return (this.classId!= null);
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the owner property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOwner() {
        return owner;
    }

    /**
     * Sets the value of the owner property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOwner(String value) {
        this.owner = value;
    }

    public boolean isSetOwner() {
        return (this.owner!= null);
    }

    /**
     * Gets the value of the creator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreator() {
        return creator;
    }

    /**
     * Sets the value of the creator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreator(String value) {
        this.creator = value;
    }

    public boolean isSetCreator() {
        return (this.creator!= null);
    }

    /**
     * Gets the value of the lastModifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastModifier() {
        return lastModifier;
    }

    /**
     * Sets the value of the lastModifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastModifier(String value) {
        this.lastModifier = value;
    }

    public boolean isSetLastModifier() {
        return (this.lastModifier!= null);
    }

    /**
     * Gets the value of the creatnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCreatnDate() {
        return creatnDate;
    }

    /**
     * Sets the value of the creatnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatnDate(Date value) {
        this.creatnDate = value;
    }

    public boolean isSetCreatnDate() {
        return (this.creatnDate!= null);
    }

    /**
     * Gets the value of the updtDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getUpdtDate() {
        return updtDate;
    }

    /**
     * Sets the value of the updtDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdtDate(Date value) {
        this.updtDate = value;
    }

    public boolean isSetUpdtDate() {
        return (this.updtDate!= null);
    }

    /**
     * Gets the value of the retentionEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getRetentionEndDate() {
        return retentionEndDate;
    }

    /**
     * Sets the value of the retentionEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetentionEndDate(Date value) {
        this.retentionEndDate = value;
    }

    public boolean isSetRetentionEndDate() {
        return (this.retentionEndDate!= null);
    }

    /**
     * Gets the value of the closeDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCloseDate() {
        return closeDate;
    }

    /**
     * Sets the value of the closeDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCloseDate(Date value) {
        this.closeDate = value;
    }

    public boolean isSetCloseDate() {
        return (this.closeDate!= null);
    }

    /**
     * Gets the value of the statusCode property.
     * 
     * @return
     *     possible object is
     *     {@link FolderStatusCodeType }
     *     
     */
    public FolderStatusCodeType getStatusCode() {
        return statusCode;
    }

    /**
     * Sets the value of the statusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link FolderStatusCodeType }
     *     
     */
    public void setStatusCode(FolderStatusCodeType value) {
        this.statusCode = value;
    }

    public boolean isSetStatusCode() {
        return (this.statusCode!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("classId", classId).add("name", name).add("owner", owner).add("creator", creator).add("lastModifier", lastModifier).add("creatnDate", creatnDate).add("updtDate", updtDate).add("retentionEndDate", retentionEndDate).add("closeDate", closeDate).add("statusCode", statusCode).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(classId, name, owner, creator, lastModifier, creatnDate, updtDate, retentionEndDate, closeDate, statusCode);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FolderDataType o = ((FolderDataType) other);
        return (((((((((Objects.equal(classId, o.classId)&&Objects.equal(name, o.name))&&Objects.equal(owner, o.owner))&&Objects.equal(creator, o.creator))&&Objects.equal(lastModifier, o.lastModifier))&&Objects.equal(creatnDate, o.creatnDate))&&Objects.equal(updtDate, o.updtDate))&&Objects.equal(retentionEndDate, o.retentionEndDate))&&Objects.equal(closeDate, o.closeDate))&&Objects.equal(statusCode, o.statusCode));
    }

}
