
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on benficiary clause at policy
 * 				level
 * 			
 * 
 * <p>Java class for PolicyBeneficiaryClauseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PolicyBeneficiaryClauseType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Id" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="ClauseType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BeneficiaryClauseTypeCodeSLN"/&gt;
 *         &lt;element name="ApplctnCaseCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverageCode"/&gt;
 *         &lt;element name="StdClauseId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}StandardBeneficiaryClauseCode" minOccurs="0"/&gt;
 *         &lt;element name="FreeClauseText" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BeneficiaryClauseTextType" minOccurs="0"/&gt;
 *         &lt;element name="DismbrmntIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="NamedBenfciary" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PolicyNamedBeneficiaryClauseType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PolicyBeneficiaryClauseType", propOrder = {
    "id",
    "clauseType",
    "applctnCaseCode",
    "stdClauseId",
    "freeClauseText",
    "dismbrmntIndic",
    "namedBenfciary"
})
public class PolicyBeneficiaryClauseType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Id")
    protected String id;
    @XmlElement(name = "ClauseType", required = true)
    protected String clauseType;
    @XmlElement(name = "ApplctnCaseCode", required = true)
    protected String applctnCaseCode;
    @XmlElement(name = "StdClauseId")
    protected String stdClauseId;
    @XmlElement(name = "FreeClauseText")
    protected String freeClauseText;
    @XmlElement(name = "DismbrmntIndic")
    protected String dismbrmntIndic;
    @XmlElement(name = "NamedBenfciary")
    protected List<PolicyNamedBeneficiaryClauseType> namedBenfciary;

    /**
     * Default no-arg constructor
     * 
     */
    public PolicyBeneficiaryClauseType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PolicyBeneficiaryClauseType(final String id, final String clauseType, final String applctnCaseCode, final String stdClauseId, final String freeClauseText, final String dismbrmntIndic, final List<PolicyNamedBeneficiaryClauseType> namedBenfciary) {
        this.id = id;
        this.clauseType = clauseType;
        this.applctnCaseCode = applctnCaseCode;
        this.stdClauseId = stdClauseId;
        this.freeClauseText = freeClauseText;
        this.dismbrmntIndic = dismbrmntIndic;
        this.namedBenfciary = namedBenfciary;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    public boolean isSetId() {
        return (this.id!= null);
    }

    /**
     * Gets the value of the clauseType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClauseType() {
        return clauseType;
    }

    /**
     * Sets the value of the clauseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClauseType(String value) {
        this.clauseType = value;
    }

    public boolean isSetClauseType() {
        return (this.clauseType!= null);
    }

    /**
     * Gets the value of the applctnCaseCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplctnCaseCode() {
        return applctnCaseCode;
    }

    /**
     * Sets the value of the applctnCaseCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplctnCaseCode(String value) {
        this.applctnCaseCode = value;
    }

    public boolean isSetApplctnCaseCode() {
        return (this.applctnCaseCode!= null);
    }

    /**
     * Gets the value of the stdClauseId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStdClauseId() {
        return stdClauseId;
    }

    /**
     * Sets the value of the stdClauseId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStdClauseId(String value) {
        this.stdClauseId = value;
    }

    public boolean isSetStdClauseId() {
        return (this.stdClauseId!= null);
    }

    /**
     * Gets the value of the freeClauseText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFreeClauseText() {
        return freeClauseText;
    }

    /**
     * Sets the value of the freeClauseText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFreeClauseText(String value) {
        this.freeClauseText = value;
    }

    public boolean isSetFreeClauseText() {
        return (this.freeClauseText!= null);
    }

    /**
     * Gets the value of the dismbrmntIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDismbrmntIndic() {
        return dismbrmntIndic;
    }

    /**
     * Sets the value of the dismbrmntIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDismbrmntIndic(String value) {
        this.dismbrmntIndic = value;
    }

    public boolean isSetDismbrmntIndic() {
        return (this.dismbrmntIndic!= null);
    }

    /**
     * Gets the value of the namedBenfciary property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the namedBenfciary property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNamedBenfciary().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PolicyNamedBeneficiaryClauseType }
     * 
     * 
     */
    public List<PolicyNamedBeneficiaryClauseType> getNamedBenfciary() {
        if (namedBenfciary == null) {
            namedBenfciary = new ArrayList<PolicyNamedBeneficiaryClauseType>();
        }
        return this.namedBenfciary;
    }

    public boolean isSetNamedBenfciary() {
        return ((this.namedBenfciary!= null)&&(!this.namedBenfciary.isEmpty()));
    }

    public void unsetNamedBenfciary() {
        this.namedBenfciary = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("id", id).add("clauseType", clauseType).add("applctnCaseCode", applctnCaseCode).add("stdClauseId", stdClauseId).add("freeClauseText", freeClauseText).add("dismbrmntIndic", dismbrmntIndic).add("namedBenfciary", namedBenfciary).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, clauseType, applctnCaseCode, stdClauseId, freeClauseText, dismbrmntIndic, namedBenfciary);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PolicyBeneficiaryClauseType o = ((PolicyBeneficiaryClauseType) other);
        return ((((((Objects.equal(id, o.id)&&Objects.equal(clauseType, o.clauseType))&&Objects.equal(applctnCaseCode, o.applctnCaseCode))&&Objects.equal(stdClauseId, o.stdClauseId))&&Objects.equal(freeClauseText, o.freeClauseText))&&Objects.equal(dismbrmntIndic, o.dismbrmntIndic))&&Objects.equal(namedBenfciary, o.namedBenfciary));
    }

}
