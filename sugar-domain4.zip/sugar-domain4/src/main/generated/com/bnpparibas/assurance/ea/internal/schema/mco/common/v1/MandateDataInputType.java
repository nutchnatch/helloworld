
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on rights given on the contract
 * 				to persons as a part of a mandate or a delegation to execute some
 * 				operation types
 * 			
 * 
 * <p>Java class for MandateDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MandateDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CustIdntctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="MndateData" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Idntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *                   &lt;element name="Mode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProxyModeCode" minOccurs="0"/&gt;
 *                   &lt;element name="PrtyRole" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *                   &lt;element name="OpeType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationTypeCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
 *                   &lt;element name="Prd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OptionalDatePeriodType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MandateDataInputType", propOrder = {
    "custIdntctn",
    "mndateData"
})
public class MandateDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CustIdntctn")
    protected PartyRoleType custIdntctn;
    @XmlElement(name = "MndateData")
    protected List<MandateDataInputType.MndateData> mndateData;

    /**
     * Default no-arg constructor
     * 
     */
    public MandateDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MandateDataInputType(final PartyRoleType custIdntctn, final List<MandateDataInputType.MndateData> mndateData) {
        this.custIdntctn = custIdntctn;
        this.mndateData = mndateData;
    }

    /**
     * Gets the value of the custIdntctn property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getCustIdntctn() {
        return custIdntctn;
    }

    /**
     * Sets the value of the custIdntctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setCustIdntctn(PartyRoleType value) {
        this.custIdntctn = value;
    }

    public boolean isSetCustIdntctn() {
        return (this.custIdntctn!= null);
    }

    /**
     * Gets the value of the mndateData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the mndateData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMndateData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MandateDataInputType.MndateData }
     * 
     * 
     */
    public List<MandateDataInputType.MndateData> getMndateData() {
        if (mndateData == null) {
            mndateData = new ArrayList<MandateDataInputType.MndateData>();
        }
        return this.mndateData;
    }

    public boolean isSetMndateData() {
        return ((this.mndateData!= null)&&(!this.mndateData.isEmpty()));
    }

    public void unsetMndateData() {
        this.mndateData = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("custIdntctn", custIdntctn).add("mndateData", mndateData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(custIdntctn, mndateData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MandateDataInputType o = ((MandateDataInputType) other);
        return (Objects.equal(custIdntctn, o.custIdntctn)&&Objects.equal(mndateData, o.mndateData));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Idntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
     *         &lt;element name="Mode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProxyModeCode" minOccurs="0"/&gt;
     *         &lt;element name="PrtyRole" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
     *         &lt;element name="OpeType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationTypeCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
     *         &lt;element name="Prd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OptionalDatePeriodType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "idntfctn",
        "mode",
        "prtyRole",
        "opeType",
        "prd"
    })
    public static class MndateData implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Idntfctn")
        protected ObjectIdentificationType idntfctn;
        @XmlElement(name = "Mode")
        protected String mode;
        @XmlElement(name = "PrtyRole")
        protected PartyRoleType prtyRole;
        @XmlElement(name = "OpeType")
        protected List<String> opeType;
        @XmlElement(name = "Prd")
        protected OptionalDatePeriodType prd;

        /**
         * Default no-arg constructor
         * 
         */
        public MndateData() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public MndateData(final ObjectIdentificationType idntfctn, final String mode, final PartyRoleType prtyRole, final List<String> opeType, final OptionalDatePeriodType prd) {
            this.idntfctn = idntfctn;
            this.mode = mode;
            this.prtyRole = prtyRole;
            this.opeType = opeType;
            this.prd = prd;
        }

        /**
         * Gets the value of the idntfctn property.
         * 
         * @return
         *     possible object is
         *     {@link ObjectIdentificationType }
         *     
         */
        public ObjectIdentificationType getIdntfctn() {
            return idntfctn;
        }

        /**
         * Sets the value of the idntfctn property.
         * 
         * @param value
         *     allowed object is
         *     {@link ObjectIdentificationType }
         *     
         */
        public void setIdntfctn(ObjectIdentificationType value) {
            this.idntfctn = value;
        }

        public boolean isSetIdntfctn() {
            return (this.idntfctn!= null);
        }

        /**
         * Gets the value of the mode property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMode() {
            return mode;
        }

        /**
         * Sets the value of the mode property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMode(String value) {
            this.mode = value;
        }

        public boolean isSetMode() {
            return (this.mode!= null);
        }

        /**
         * Gets the value of the prtyRole property.
         * 
         * @return
         *     possible object is
         *     {@link PartyRoleType }
         *     
         */
        public PartyRoleType getPrtyRole() {
            return prtyRole;
        }

        /**
         * Sets the value of the prtyRole property.
         * 
         * @param value
         *     allowed object is
         *     {@link PartyRoleType }
         *     
         */
        public void setPrtyRole(PartyRoleType value) {
            this.prtyRole = value;
        }

        public boolean isSetPrtyRole() {
            return (this.prtyRole!= null);
        }

        /**
         * Gets the value of the opeType property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the opeType property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getOpeType().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link String }
         * 
         * 
         */
        public List<String> getOpeType() {
            if (opeType == null) {
                opeType = new ArrayList<String>();
            }
            return this.opeType;
        }

        public boolean isSetOpeType() {
            return ((this.opeType!= null)&&(!this.opeType.isEmpty()));
        }

        public void unsetOpeType() {
            this.opeType = null;
        }

        /**
         * Gets the value of the prd property.
         * 
         * @return
         *     possible object is
         *     {@link OptionalDatePeriodType }
         *     
         */
        public OptionalDatePeriodType getPrd() {
            return prd;
        }

        /**
         * Sets the value of the prd property.
         * 
         * @param value
         *     allowed object is
         *     {@link OptionalDatePeriodType }
         *     
         */
        public void setPrd(OptionalDatePeriodType value) {
            this.prd = value;
        }

        public boolean isSetPrd() {
            return (this.prd!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("idntfctn", idntfctn).add("mode", mode).add("prtyRole", prtyRole).add("opeType", opeType).add("prd", prd).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(idntfctn, mode, prtyRole, opeType, prd);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final MandateDataInputType.MndateData o = ((MandateDataInputType.MndateData) other);
            return ((((Objects.equal(idntfctn, o.idntfctn)&&Objects.equal(mode, o.mode))&&Objects.equal(prtyRole, o.prtyRole))&&Objects.equal(opeType, o.opeType))&&Objects.equal(prd, o.prd));
        }

    }

}
