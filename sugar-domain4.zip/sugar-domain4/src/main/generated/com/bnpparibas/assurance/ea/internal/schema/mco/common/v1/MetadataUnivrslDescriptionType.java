
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Universal description of
 * 				one particular document metadata. Composed of a name, a data
 * 				category and an optional data format which makes it possible to
 * 				actually define and transmit an unnormalized metadata.
 * 			
 * 
 * <p>Java class for MetadataUnivrslDescriptionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MetadataUnivrslDescriptionType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LongNameType"/&gt;
 *         &lt;element name="ValueCategory" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DataCategoryCodeSLN"/&gt;
 *         &lt;element name="ValueRegExpFormatStd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}RegExpCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="ValueRegExpFormatPattern" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LongNameType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MetadataUnivrslDescriptionType", propOrder = {
    "name",
    "valueCategory",
    "valueRegExpFormatStd",
    "valueRegExpFormatPattern"
})
public class MetadataUnivrslDescriptionType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Name", required = true)
    protected String name;
    @XmlElement(name = "ValueCategory", required = true)
    protected String valueCategory;
    @XmlElement(name = "ValueRegExpFormatStd")
    protected String valueRegExpFormatStd;
    @XmlElement(name = "ValueRegExpFormatPattern")
    protected String valueRegExpFormatPattern;

    /**
     * Default no-arg constructor
     * 
     */
    public MetadataUnivrslDescriptionType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MetadataUnivrslDescriptionType(final String name, final String valueCategory, final String valueRegExpFormatStd, final String valueRegExpFormatPattern) {
        this.name = name;
        this.valueCategory = valueCategory;
        this.valueRegExpFormatStd = valueRegExpFormatStd;
        this.valueRegExpFormatPattern = valueRegExpFormatPattern;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the valueCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValueCategory() {
        return valueCategory;
    }

    /**
     * Sets the value of the valueCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValueCategory(String value) {
        this.valueCategory = value;
    }

    public boolean isSetValueCategory() {
        return (this.valueCategory!= null);
    }

    /**
     * Gets the value of the valueRegExpFormatStd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValueRegExpFormatStd() {
        return valueRegExpFormatStd;
    }

    /**
     * Sets the value of the valueRegExpFormatStd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValueRegExpFormatStd(String value) {
        this.valueRegExpFormatStd = value;
    }

    public boolean isSetValueRegExpFormatStd() {
        return (this.valueRegExpFormatStd!= null);
    }

    /**
     * Gets the value of the valueRegExpFormatPattern property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValueRegExpFormatPattern() {
        return valueRegExpFormatPattern;
    }

    /**
     * Sets the value of the valueRegExpFormatPattern property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValueRegExpFormatPattern(String value) {
        this.valueRegExpFormatPattern = value;
    }

    public boolean isSetValueRegExpFormatPattern() {
        return (this.valueRegExpFormatPattern!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("name", name).add("valueCategory", valueCategory).add("valueRegExpFormatStd", valueRegExpFormatStd).add("valueRegExpFormatPattern", valueRegExpFormatPattern).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name, valueCategory, valueRegExpFormatStd, valueRegExpFormatPattern);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MetadataUnivrslDescriptionType o = ((MetadataUnivrslDescriptionType) other);
        return (((Objects.equal(name, o.name)&&Objects.equal(valueCategory, o.valueCategory))&&Objects.equal(valueRegExpFormatStd, o.valueRegExpFormatStd))&&Objects.equal(valueRegExpFormatPattern, o.valueRegExpFormatPattern));
    }

}
