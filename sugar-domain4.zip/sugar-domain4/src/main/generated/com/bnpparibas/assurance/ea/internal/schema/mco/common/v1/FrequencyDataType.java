
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on frequency : To be not used
 * 			
 * 
 * <p>Java class for FrequencyDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FrequencyDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FqcyType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FrequencyTypeCodeSLN"/&gt;
 *         &lt;element name="PrdType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="SpecifPrdType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SpecificPeriodTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="PrdTimesNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FrequencyDataType", propOrder = {
    "fqcyType",
    "prdType",
    "specifPrdType",
    "prdTimesNumb"
})
public class FrequencyDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "FqcyType", required = true)
    protected String fqcyType;
    @XmlElement(name = "PrdType")
    protected String prdType;
    @XmlElement(name = "SpecifPrdType")
    protected String specifPrdType;
    @XmlElement(name = "PrdTimesNumb")
    protected BigInteger prdTimesNumb;

    /**
     * Default no-arg constructor
     * 
     */
    public FrequencyDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FrequencyDataType(final String fqcyType, final String prdType, final String specifPrdType, final BigInteger prdTimesNumb) {
        this.fqcyType = fqcyType;
        this.prdType = prdType;
        this.specifPrdType = specifPrdType;
        this.prdTimesNumb = prdTimesNumb;
    }

    /**
     * Gets the value of the fqcyType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFqcyType() {
        return fqcyType;
    }

    /**
     * Sets the value of the fqcyType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFqcyType(String value) {
        this.fqcyType = value;
    }

    public boolean isSetFqcyType() {
        return (this.fqcyType!= null);
    }

    /**
     * Gets the value of the prdType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrdType() {
        return prdType;
    }

    /**
     * Sets the value of the prdType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrdType(String value) {
        this.prdType = value;
    }

    public boolean isSetPrdType() {
        return (this.prdType!= null);
    }

    /**
     * Gets the value of the specifPrdType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpecifPrdType() {
        return specifPrdType;
    }

    /**
     * Sets the value of the specifPrdType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpecifPrdType(String value) {
        this.specifPrdType = value;
    }

    public boolean isSetSpecifPrdType() {
        return (this.specifPrdType!= null);
    }

    /**
     * Gets the value of the prdTimesNumb property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getPrdTimesNumb() {
        return prdTimesNumb;
    }

    /**
     * Sets the value of the prdTimesNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setPrdTimesNumb(BigInteger value) {
        this.prdTimesNumb = value;
    }

    public boolean isSetPrdTimesNumb() {
        return (this.prdTimesNumb!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("fqcyType", fqcyType).add("prdType", prdType).add("specifPrdType", specifPrdType).add("prdTimesNumb", prdTimesNumb).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(fqcyType, prdType, specifPrdType, prdTimesNumb);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FrequencyDataType o = ((FrequencyDataType) other);
        return (((Objects.equal(fqcyType, o.fqcyType)&&Objects.equal(prdType, o.prdType))&&Objects.equal(specifPrdType, o.specifPrdType))&&Objects.equal(prdTimesNumb, o.prdTimesNumb));
    }

}
