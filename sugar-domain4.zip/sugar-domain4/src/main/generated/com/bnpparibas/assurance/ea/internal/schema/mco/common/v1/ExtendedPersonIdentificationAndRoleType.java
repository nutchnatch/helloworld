
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to define identification and role and of
 * 				customer extended with birthdate, gender and rank information
 * 			
 * 
 * <p>Java class for ExtendedPersonIdentificationAndRoleType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ExtendedPersonIdentificationAndRoleType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Idnfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="RoleData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PersonRoleType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="BrthDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="Gendr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GenderIndicatorCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Rnk" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ExtendedPersonIdentificationAndRoleType", propOrder = {
    "idnfctn",
    "roleData",
    "brthDate",
    "gendr",
    "rnk"
})
public class ExtendedPersonIdentificationAndRoleType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Idnfctn", required = true)
    protected ObjectIdentificationType idnfctn;
    @XmlElement(name = "RoleData", required = true)
    protected List<PersonRoleType> roleData;
    @XmlElement(name = "BrthDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date brthDate;
    @XmlElement(name = "Gendr")
    protected String gendr;
    @XmlElement(name = "Rnk")
    protected BigInteger rnk;

    /**
     * Default no-arg constructor
     * 
     */
    public ExtendedPersonIdentificationAndRoleType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ExtendedPersonIdentificationAndRoleType(final ObjectIdentificationType idnfctn, final List<PersonRoleType> roleData, final Date brthDate, final String gendr, final BigInteger rnk) {
        this.idnfctn = idnfctn;
        this.roleData = roleData;
        this.brthDate = brthDate;
        this.gendr = gendr;
        this.rnk = rnk;
    }

    /**
     * Gets the value of the idnfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getIdnfctn() {
        return idnfctn;
    }

    /**
     * Sets the value of the idnfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setIdnfctn(ObjectIdentificationType value) {
        this.idnfctn = value;
    }

    public boolean isSetIdnfctn() {
        return (this.idnfctn!= null);
    }

    /**
     * Gets the value of the roleData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the roleData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRoleData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PersonRoleType }
     * 
     * 
     */
    public List<PersonRoleType> getRoleData() {
        if (roleData == null) {
            roleData = new ArrayList<PersonRoleType>();
        }
        return this.roleData;
    }

    public boolean isSetRoleData() {
        return ((this.roleData!= null)&&(!this.roleData.isEmpty()));
    }

    public void unsetRoleData() {
        this.roleData = null;
    }

    /**
     * Gets the value of the brthDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getBrthDate() {
        return brthDate;
    }

    /**
     * Sets the value of the brthDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBrthDate(Date value) {
        this.brthDate = value;
    }

    public boolean isSetBrthDate() {
        return (this.brthDate!= null);
    }

    /**
     * Gets the value of the gendr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGendr() {
        return gendr;
    }

    /**
     * Sets the value of the gendr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGendr(String value) {
        this.gendr = value;
    }

    public boolean isSetGendr() {
        return (this.gendr!= null);
    }

    /**
     * Gets the value of the rnk property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getRnk() {
        return rnk;
    }

    /**
     * Sets the value of the rnk property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setRnk(BigInteger value) {
        this.rnk = value;
    }

    public boolean isSetRnk() {
        return (this.rnk!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("idnfctn", idnfctn).add("roleData", roleData).add("brthDate", brthDate).add("gendr", gendr).add("rnk", rnk).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(idnfctn, roleData, brthDate, gendr, rnk);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ExtendedPersonIdentificationAndRoleType o = ((ExtendedPersonIdentificationAndRoleType) other);
        return ((((Objects.equal(idnfctn, o.idnfctn)&&Objects.equal(roleData, o.roleData))&&Objects.equal(brthDate, o.brthDate))&&Objects.equal(gendr, o.gendr))&&Objects.equal(rnk, o.rnk));
    }

}
