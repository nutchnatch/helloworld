
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage inforamtion on an index or rate
 * 			
 * 
 * <p>Java class for FinancialIndexAndRateDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FinancialIndexAndRateDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
 *         &lt;element name="QuotatnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *         &lt;element name="Price" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FinancialIndexAndRatePriceType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="IndexatnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IndexationTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="GeogrphcalZone" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GeographicalZoneCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Curr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FinancialIndexAndRateDataType", propOrder = {
    "name",
    "quotatnDate",
    "price",
    "indexatnType",
    "geogrphcalZone",
    "curr"
})
public class FinancialIndexAndRateDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Name", required = true)
    protected String name;
    @XmlElement(name = "QuotatnDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date quotatnDate;
    @XmlElement(name = "Price", required = true)
    protected List<FinancialIndexAndRatePriceType> price;
    @XmlElement(name = "IndexatnType")
    protected String indexatnType;
    @XmlElement(name = "GeogrphcalZone")
    protected String geogrphcalZone;
    @XmlElement(name = "Curr")
    protected String curr;

    /**
     * Default no-arg constructor
     * 
     */
    public FinancialIndexAndRateDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FinancialIndexAndRateDataType(final String name, final Date quotatnDate, final List<FinancialIndexAndRatePriceType> price, final String indexatnType, final String geogrphcalZone, final String curr) {
        this.name = name;
        this.quotatnDate = quotatnDate;
        this.price = price;
        this.indexatnType = indexatnType;
        this.geogrphcalZone = geogrphcalZone;
        this.curr = curr;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the quotatnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getQuotatnDate() {
        return quotatnDate;
    }

    /**
     * Sets the value of the quotatnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuotatnDate(Date value) {
        this.quotatnDate = value;
    }

    public boolean isSetQuotatnDate() {
        return (this.quotatnDate!= null);
    }

    /**
     * Gets the value of the price property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the price property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPrice().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FinancialIndexAndRatePriceType }
     * 
     * 
     */
    public List<FinancialIndexAndRatePriceType> getPrice() {
        if (price == null) {
            price = new ArrayList<FinancialIndexAndRatePriceType>();
        }
        return this.price;
    }

    public boolean isSetPrice() {
        return ((this.price!= null)&&(!this.price.isEmpty()));
    }

    public void unsetPrice() {
        this.price = null;
    }

    /**
     * Gets the value of the indexatnType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIndexatnType() {
        return indexatnType;
    }

    /**
     * Sets the value of the indexatnType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIndexatnType(String value) {
        this.indexatnType = value;
    }

    public boolean isSetIndexatnType() {
        return (this.indexatnType!= null);
    }

    /**
     * Gets the value of the geogrphcalZone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGeogrphcalZone() {
        return geogrphcalZone;
    }

    /**
     * Sets the value of the geogrphcalZone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGeogrphcalZone(String value) {
        this.geogrphcalZone = value;
    }

    public boolean isSetGeogrphcalZone() {
        return (this.geogrphcalZone!= null);
    }

    /**
     * Gets the value of the curr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurr() {
        return curr;
    }

    /**
     * Sets the value of the curr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurr(String value) {
        this.curr = value;
    }

    public boolean isSetCurr() {
        return (this.curr!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("name", name).add("quotatnDate", quotatnDate).add("price", price).add("indexatnType", indexatnType).add("geogrphcalZone", geogrphcalZone).add("curr", curr).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name, quotatnDate, price, indexatnType, geogrphcalZone, curr);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FinancialIndexAndRateDataType o = ((FinancialIndexAndRateDataType) other);
        return (((((Objects.equal(name, o.name)&&Objects.equal(quotatnDate, o.quotatnDate))&&Objects.equal(price, o.price))&&Objects.equal(indexatnType, o.indexatnType))&&Objects.equal(geogrphcalZone, o.geogrphcalZone))&&Objects.equal(curr, o.curr));
    }

}
