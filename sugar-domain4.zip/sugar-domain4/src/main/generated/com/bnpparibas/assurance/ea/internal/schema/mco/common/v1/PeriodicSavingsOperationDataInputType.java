
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on regular savings
 * 				premium and regular savings withdrawal
 * 			
 * 
 * <p>Java class for PeriodicSavingsOperationDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PeriodicSavingsOperationDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OpeSchedlrIdntcn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="PaymntRef" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PaymentMethodWithPayerInputType" minOccurs="0"/&gt;
 *         &lt;element name="SchedlrData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodicSavingsSchedulerDataInputType" minOccurs="0"/&gt;
 *         &lt;element name="SpecifSchedlrData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SpecifPeriodicSavingsSchedulerDataInputType" minOccurs="0"/&gt;
 *         &lt;element name="FundDistrbtn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SavingsOperationFundDistributionInputType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PeriodicSavingsOperationDataInputType", propOrder = {
    "opeSchedlrIdntcn",
    "paymntRef",
    "schedlrData",
    "specifSchedlrData",
    "fundDistrbtn"
})
public class PeriodicSavingsOperationDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "OpeSchedlrIdntcn")
    protected ObjectIdentificationType opeSchedlrIdntcn;
    @XmlElement(name = "PaymntRef")
    protected PaymentMethodWithPayerInputType paymntRef;
    @XmlElement(name = "SchedlrData")
    protected PeriodicSavingsSchedulerDataInputType schedlrData;
    @XmlElement(name = "SpecifSchedlrData")
    protected SpecifPeriodicSavingsSchedulerDataInputType specifSchedlrData;
    @XmlElement(name = "FundDistrbtn")
    protected List<SavingsOperationFundDistributionInputType> fundDistrbtn;

    /**
     * Default no-arg constructor
     * 
     */
    public PeriodicSavingsOperationDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PeriodicSavingsOperationDataInputType(final ObjectIdentificationType opeSchedlrIdntcn, final PaymentMethodWithPayerInputType paymntRef, final PeriodicSavingsSchedulerDataInputType schedlrData, final SpecifPeriodicSavingsSchedulerDataInputType specifSchedlrData, final List<SavingsOperationFundDistributionInputType> fundDistrbtn) {
        this.opeSchedlrIdntcn = opeSchedlrIdntcn;
        this.paymntRef = paymntRef;
        this.schedlrData = schedlrData;
        this.specifSchedlrData = specifSchedlrData;
        this.fundDistrbtn = fundDistrbtn;
    }

    /**
     * Gets the value of the opeSchedlrIdntcn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getOpeSchedlrIdntcn() {
        return opeSchedlrIdntcn;
    }

    /**
     * Sets the value of the opeSchedlrIdntcn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setOpeSchedlrIdntcn(ObjectIdentificationType value) {
        this.opeSchedlrIdntcn = value;
    }

    public boolean isSetOpeSchedlrIdntcn() {
        return (this.opeSchedlrIdntcn!= null);
    }

    /**
     * Gets the value of the paymntRef property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentMethodWithPayerInputType }
     *     
     */
    public PaymentMethodWithPayerInputType getPaymntRef() {
        return paymntRef;
    }

    /**
     * Sets the value of the paymntRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentMethodWithPayerInputType }
     *     
     */
    public void setPaymntRef(PaymentMethodWithPayerInputType value) {
        this.paymntRef = value;
    }

    public boolean isSetPaymntRef() {
        return (this.paymntRef!= null);
    }

    /**
     * Gets the value of the schedlrData property.
     * 
     * @return
     *     possible object is
     *     {@link PeriodicSavingsSchedulerDataInputType }
     *     
     */
    public PeriodicSavingsSchedulerDataInputType getSchedlrData() {
        return schedlrData;
    }

    /**
     * Sets the value of the schedlrData property.
     * 
     * @param value
     *     allowed object is
     *     {@link PeriodicSavingsSchedulerDataInputType }
     *     
     */
    public void setSchedlrData(PeriodicSavingsSchedulerDataInputType value) {
        this.schedlrData = value;
    }

    public boolean isSetSchedlrData() {
        return (this.schedlrData!= null);
    }

    /**
     * Gets the value of the specifSchedlrData property.
     * 
     * @return
     *     possible object is
     *     {@link SpecifPeriodicSavingsSchedulerDataInputType }
     *     
     */
    public SpecifPeriodicSavingsSchedulerDataInputType getSpecifSchedlrData() {
        return specifSchedlrData;
    }

    /**
     * Sets the value of the specifSchedlrData property.
     * 
     * @param value
     *     allowed object is
     *     {@link SpecifPeriodicSavingsSchedulerDataInputType }
     *     
     */
    public void setSpecifSchedlrData(SpecifPeriodicSavingsSchedulerDataInputType value) {
        this.specifSchedlrData = value;
    }

    public boolean isSetSpecifSchedlrData() {
        return (this.specifSchedlrData!= null);
    }

    /**
     * Gets the value of the fundDistrbtn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fundDistrbtn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFundDistrbtn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SavingsOperationFundDistributionInputType }
     * 
     * 
     */
    public List<SavingsOperationFundDistributionInputType> getFundDistrbtn() {
        if (fundDistrbtn == null) {
            fundDistrbtn = new ArrayList<SavingsOperationFundDistributionInputType>();
        }
        return this.fundDistrbtn;
    }

    public boolean isSetFundDistrbtn() {
        return ((this.fundDistrbtn!= null)&&(!this.fundDistrbtn.isEmpty()));
    }

    public void unsetFundDistrbtn() {
        this.fundDistrbtn = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("opeSchedlrIdntcn", opeSchedlrIdntcn).add("paymntRef", paymntRef).add("schedlrData", schedlrData).add("specifSchedlrData", specifSchedlrData).add("fundDistrbtn", fundDistrbtn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(opeSchedlrIdntcn, paymntRef, schedlrData, specifSchedlrData, fundDistrbtn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PeriodicSavingsOperationDataInputType o = ((PeriodicSavingsOperationDataInputType) other);
        return ((((Objects.equal(opeSchedlrIdntcn, o.opeSchedlrIdntcn)&&Objects.equal(paymntRef, o.paymntRef))&&Objects.equal(schedlrData, o.schedlrData))&&Objects.equal(specifSchedlrData, o.specifSchedlrData))&&Objects.equal(fundDistrbtn, o.fundDistrbtn));
    }

}
