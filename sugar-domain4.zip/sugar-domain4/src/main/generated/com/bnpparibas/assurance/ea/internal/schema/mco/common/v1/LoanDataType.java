
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage information on a loan
 * 			
 * 
 * <p>Java class for LoanDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LoanDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="LoanType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LoanObjectCodeSLN"/&gt;
 *         &lt;element name="LoanPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType"/&gt;
 *         &lt;element name="AmrtztnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LoanAmortizationTypeCodeSLN"/&gt;
 *         &lt;element name="LoanAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *         &lt;element name="TermDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="LoanDuratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType"/&gt;
 *         &lt;element name="DefrdPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="IntrstRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LoanDataType", propOrder = {
    "loanType",
    "loanPrd",
    "amrtztnType",
    "loanAmnt",
    "termDate",
    "loanDuratn",
    "defrdPrd",
    "intrstRate"
})
public class LoanDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "LoanType", required = true)
    protected String loanType;
    @XmlElement(name = "LoanPrd", required = true)
    protected DatePeriodType loanPrd;
    @XmlElement(name = "AmrtztnType", required = true)
    protected String amrtztnType;
    @XmlElement(name = "LoanAmnt", required = true)
    protected CurrencyAndAmountType loanAmnt;
    @XmlElement(name = "TermDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date termDate;
    @XmlElement(name = "LoanDuratn", required = true)
    protected DurationType loanDuratn;
    @XmlElement(name = "DefrdPrd")
    protected DurationType defrdPrd;
    @XmlElement(name = "IntrstRate")
    protected Double intrstRate;

    /**
     * Default no-arg constructor
     * 
     */
    public LoanDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public LoanDataType(final String loanType, final DatePeriodType loanPrd, final String amrtztnType, final CurrencyAndAmountType loanAmnt, final Date termDate, final DurationType loanDuratn, final DurationType defrdPrd, final Double intrstRate) {
        this.loanType = loanType;
        this.loanPrd = loanPrd;
        this.amrtztnType = amrtztnType;
        this.loanAmnt = loanAmnt;
        this.termDate = termDate;
        this.loanDuratn = loanDuratn;
        this.defrdPrd = defrdPrd;
        this.intrstRate = intrstRate;
    }

    /**
     * Gets the value of the loanType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoanType() {
        return loanType;
    }

    /**
     * Sets the value of the loanType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoanType(String value) {
        this.loanType = value;
    }

    public boolean isSetLoanType() {
        return (this.loanType!= null);
    }

    /**
     * Gets the value of the loanPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getLoanPrd() {
        return loanPrd;
    }

    /**
     * Sets the value of the loanPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setLoanPrd(DatePeriodType value) {
        this.loanPrd = value;
    }

    public boolean isSetLoanPrd() {
        return (this.loanPrd!= null);
    }

    /**
     * Gets the value of the amrtztnType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmrtztnType() {
        return amrtztnType;
    }

    /**
     * Sets the value of the amrtztnType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmrtztnType(String value) {
        this.amrtztnType = value;
    }

    public boolean isSetAmrtztnType() {
        return (this.amrtztnType!= null);
    }

    /**
     * Gets the value of the loanAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getLoanAmnt() {
        return loanAmnt;
    }

    /**
     * Sets the value of the loanAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setLoanAmnt(CurrencyAndAmountType value) {
        this.loanAmnt = value;
    }

    public boolean isSetLoanAmnt() {
        return (this.loanAmnt!= null);
    }

    /**
     * Gets the value of the termDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getTermDate() {
        return termDate;
    }

    /**
     * Sets the value of the termDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTermDate(Date value) {
        this.termDate = value;
    }

    public boolean isSetTermDate() {
        return (this.termDate!= null);
    }

    /**
     * Gets the value of the loanDuratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getLoanDuratn() {
        return loanDuratn;
    }

    /**
     * Sets the value of the loanDuratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setLoanDuratn(DurationType value) {
        this.loanDuratn = value;
    }

    public boolean isSetLoanDuratn() {
        return (this.loanDuratn!= null);
    }

    /**
     * Gets the value of the defrdPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getDefrdPrd() {
        return defrdPrd;
    }

    /**
     * Sets the value of the defrdPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setDefrdPrd(DurationType value) {
        this.defrdPrd = value;
    }

    public boolean isSetDefrdPrd() {
        return (this.defrdPrd!= null);
    }

    /**
     * Gets the value of the intrstRate property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getIntrstRate() {
        return intrstRate;
    }

    /**
     * Sets the value of the intrstRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setIntrstRate(Double value) {
        this.intrstRate = value;
    }

    public boolean isSetIntrstRate() {
        return (this.intrstRate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("loanType", loanType).add("loanPrd", loanPrd).add("amrtztnType", amrtztnType).add("loanAmnt", loanAmnt).add("termDate", termDate).add("loanDuratn", loanDuratn).add("defrdPrd", defrdPrd).add("intrstRate", intrstRate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(loanType, loanPrd, amrtztnType, loanAmnt, termDate, loanDuratn, defrdPrd, intrstRate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final LoanDataType o = ((LoanDataType) other);
        return (((((((Objects.equal(loanType, o.loanType)&&Objects.equal(loanPrd, o.loanPrd))&&Objects.equal(amrtztnType, o.amrtztnType))&&Objects.equal(loanAmnt, o.loanAmnt))&&Objects.equal(termDate, o.termDate))&&Objects.equal(loanDuratn, o.loanDuratn))&&Objects.equal(defrdPrd, o.defrdPrd))&&Objects.equal(intrstRate, o.intrstRate));
    }

}
