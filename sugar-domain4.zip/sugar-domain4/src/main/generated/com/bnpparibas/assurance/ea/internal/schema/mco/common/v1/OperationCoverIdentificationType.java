
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information about the identification
 * 				of a cover defined at aan operation level
 * 			
 * 
 * <p>Java class for OperationCoverIdentificationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OperationCoverIdentificationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Id" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="PdctCovId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType"/&gt;
 *         &lt;element name="CovName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="CovrgeCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverageCode"/&gt;
 *         &lt;element name="LifeIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LifeIndicatorCodeSLN"/&gt;
 *         &lt;element name="PdctPckgeId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="PdctCovPlanId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OperationCoverIdentificationType", propOrder = {
    "id",
    "pdctCovId",
    "covName",
    "covrgeCode",
    "lifeIndic",
    "pdctPckgeId",
    "pdctCovPlanId"
})
public class OperationCoverIdentificationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Id")
    protected String id;
    @XmlElement(name = "PdctCovId", required = true)
    protected String pdctCovId;
    @XmlElement(name = "CovName")
    protected String covName;
    @XmlElement(name = "CovrgeCode", required = true)
    protected String covrgeCode;
    @XmlElement(name = "LifeIndic", required = true)
    protected String lifeIndic;
    @XmlElement(name = "PdctPckgeId")
    protected String pdctPckgeId;
    @XmlElement(name = "PdctCovPlanId")
    protected String pdctCovPlanId;

    /**
     * Default no-arg constructor
     * 
     */
    public OperationCoverIdentificationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public OperationCoverIdentificationType(final String id, final String pdctCovId, final String covName, final String covrgeCode, final String lifeIndic, final String pdctPckgeId, final String pdctCovPlanId) {
        this.id = id;
        this.pdctCovId = pdctCovId;
        this.covName = covName;
        this.covrgeCode = covrgeCode;
        this.lifeIndic = lifeIndic;
        this.pdctPckgeId = pdctPckgeId;
        this.pdctCovPlanId = pdctCovPlanId;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    public boolean isSetId() {
        return (this.id!= null);
    }

    /**
     * Gets the value of the pdctCovId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPdctCovId() {
        return pdctCovId;
    }

    /**
     * Sets the value of the pdctCovId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPdctCovId(String value) {
        this.pdctCovId = value;
    }

    public boolean isSetPdctCovId() {
        return (this.pdctCovId!= null);
    }

    /**
     * Gets the value of the covName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCovName() {
        return covName;
    }

    /**
     * Sets the value of the covName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCovName(String value) {
        this.covName = value;
    }

    public boolean isSetCovName() {
        return (this.covName!= null);
    }

    /**
     * Gets the value of the covrgeCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCovrgeCode() {
        return covrgeCode;
    }

    /**
     * Sets the value of the covrgeCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCovrgeCode(String value) {
        this.covrgeCode = value;
    }

    public boolean isSetCovrgeCode() {
        return (this.covrgeCode!= null);
    }

    /**
     * Gets the value of the lifeIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLifeIndic() {
        return lifeIndic;
    }

    /**
     * Sets the value of the lifeIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLifeIndic(String value) {
        this.lifeIndic = value;
    }

    public boolean isSetLifeIndic() {
        return (this.lifeIndic!= null);
    }

    /**
     * Gets the value of the pdctPckgeId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPdctPckgeId() {
        return pdctPckgeId;
    }

    /**
     * Sets the value of the pdctPckgeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPdctPckgeId(String value) {
        this.pdctPckgeId = value;
    }

    public boolean isSetPdctPckgeId() {
        return (this.pdctPckgeId!= null);
    }

    /**
     * Gets the value of the pdctCovPlanId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPdctCovPlanId() {
        return pdctCovPlanId;
    }

    /**
     * Sets the value of the pdctCovPlanId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPdctCovPlanId(String value) {
        this.pdctCovPlanId = value;
    }

    public boolean isSetPdctCovPlanId() {
        return (this.pdctCovPlanId!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("id", id).add("pdctCovId", pdctCovId).add("covName", covName).add("covrgeCode", covrgeCode).add("lifeIndic", lifeIndic).add("pdctPckgeId", pdctPckgeId).add("pdctCovPlanId", pdctCovPlanId).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, pdctCovId, covName, covrgeCode, lifeIndic, pdctPckgeId, pdctCovPlanId);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final OperationCoverIdentificationType o = ((OperationCoverIdentificationType) other);
        return ((((((Objects.equal(id, o.id)&&Objects.equal(pdctCovId, o.pdctCovId))&&Objects.equal(covName, o.covName))&&Objects.equal(covrgeCode, o.covrgeCode))&&Objects.equal(lifeIndic, o.lifeIndic))&&Objects.equal(pdctPckgeId, o.pdctPckgeId))&&Objects.equal(pdctCovPlanId, o.pdctCovPlanId));
    }

}
