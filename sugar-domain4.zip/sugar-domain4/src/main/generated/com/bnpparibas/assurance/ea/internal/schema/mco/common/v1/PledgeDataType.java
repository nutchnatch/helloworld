
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage data on a policy pledge
 * 			
 * 
 * <p>Java class for PledgeDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PledgeDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Idntctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="Quota" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}QuotaCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="MltiPlcty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MultiplicityCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Status" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LegalMeasuresStatusCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="EffctveDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="Prty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="DelgatdOpe" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DelgatedOperationType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="FreeText" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FreeTextType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PledgeDataType", propOrder = {
    "idntctn",
    "quota",
    "mltiPlcty",
    "status",
    "effctveDate",
    "prty",
    "delgatdOpe",
    "freeText"
})
public class PledgeDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Idntctn")
    protected ObjectIdentificationType idntctn;
    @XmlElement(name = "Quota")
    protected String quota;
    @XmlElement(name = "MltiPlcty")
    protected String mltiPlcty;
    @XmlElement(name = "Status")
    protected String status;
    @XmlElement(name = "EffctveDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date effctveDate;
    @XmlElement(name = "Prty")
    protected PartyRoleType prty;
    @XmlElement(name = "DelgatdOpe")
    protected List<DelgatedOperationType> delgatdOpe;
    @XmlElement(name = "FreeText")
    protected String freeText;

    /**
     * Default no-arg constructor
     * 
     */
    public PledgeDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PledgeDataType(final ObjectIdentificationType idntctn, final String quota, final String mltiPlcty, final String status, final Date effctveDate, final PartyRoleType prty, final List<DelgatedOperationType> delgatdOpe, final String freeText) {
        this.idntctn = idntctn;
        this.quota = quota;
        this.mltiPlcty = mltiPlcty;
        this.status = status;
        this.effctveDate = effctveDate;
        this.prty = prty;
        this.delgatdOpe = delgatdOpe;
        this.freeText = freeText;
    }

    /**
     * Gets the value of the idntctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getIdntctn() {
        return idntctn;
    }

    /**
     * Sets the value of the idntctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setIdntctn(ObjectIdentificationType value) {
        this.idntctn = value;
    }

    public boolean isSetIdntctn() {
        return (this.idntctn!= null);
    }

    /**
     * Gets the value of the quota property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQuota() {
        return quota;
    }

    /**
     * Sets the value of the quota property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQuota(String value) {
        this.quota = value;
    }

    public boolean isSetQuota() {
        return (this.quota!= null);
    }

    /**
     * Gets the value of the mltiPlcty property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMltiPlcty() {
        return mltiPlcty;
    }

    /**
     * Sets the value of the mltiPlcty property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMltiPlcty(String value) {
        this.mltiPlcty = value;
    }

    public boolean isSetMltiPlcty() {
        return (this.mltiPlcty!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    /**
     * Gets the value of the effctveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getEffctveDate() {
        return effctveDate;
    }

    /**
     * Sets the value of the effctveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEffctveDate(Date value) {
        this.effctveDate = value;
    }

    public boolean isSetEffctveDate() {
        return (this.effctveDate!= null);
    }

    /**
     * Gets the value of the prty property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrty() {
        return prty;
    }

    /**
     * Sets the value of the prty property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrty(PartyRoleType value) {
        this.prty = value;
    }

    public boolean isSetPrty() {
        return (this.prty!= null);
    }

    /**
     * Gets the value of the delgatdOpe property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the delgatdOpe property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDelgatdOpe().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DelgatedOperationType }
     * 
     * 
     */
    public List<DelgatedOperationType> getDelgatdOpe() {
        if (delgatdOpe == null) {
            delgatdOpe = new ArrayList<DelgatedOperationType>();
        }
        return this.delgatdOpe;
    }

    public boolean isSetDelgatdOpe() {
        return ((this.delgatdOpe!= null)&&(!this.delgatdOpe.isEmpty()));
    }

    public void unsetDelgatdOpe() {
        this.delgatdOpe = null;
    }

    /**
     * Gets the value of the freeText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFreeText() {
        return freeText;
    }

    /**
     * Sets the value of the freeText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFreeText(String value) {
        this.freeText = value;
    }

    public boolean isSetFreeText() {
        return (this.freeText!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("idntctn", idntctn).add("quota", quota).add("mltiPlcty", mltiPlcty).add("status", status).add("effctveDate", effctveDate).add("prty", prty).add("delgatdOpe", delgatdOpe).add("freeText", freeText).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(idntctn, quota, mltiPlcty, status, effctveDate, prty, delgatdOpe, freeText);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PledgeDataType o = ((PledgeDataType) other);
        return (((((((Objects.equal(idntctn, o.idntctn)&&Objects.equal(quota, o.quota))&&Objects.equal(mltiPlcty, o.mltiPlcty))&&Objects.equal(status, o.status))&&Objects.equal(effctveDate, o.effctveDate))&&Objects.equal(prty, o.prty))&&Objects.equal(delgatdOpe, o.delgatdOpe))&&Objects.equal(freeText, o.freeText));
    }

}
