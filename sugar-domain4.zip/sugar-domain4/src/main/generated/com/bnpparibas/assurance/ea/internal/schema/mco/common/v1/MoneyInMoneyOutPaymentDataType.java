
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * To mange information ont payment and involved
 * 				parties
 * 			
 * 
 * <p>Java class for MoneyInMoneyOutPaymentDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MoneyInMoneyOutPaymentDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Prty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="FrstName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="BnkAcct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BankAccountIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="Card" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PaymentCardDataType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MoneyInMoneyOutPaymentDataType", propOrder = {
    "prty",
    "name",
    "frstName",
    "bnkAcct",
    "card"
})
public class MoneyInMoneyOutPaymentDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Prty", required = true)
    protected PartyRoleType prty;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "FrstName")
    protected String frstName;
    @XmlElement(name = "BnkAcct")
    protected BankAccountIdentificationType bnkAcct;
    @XmlElement(name = "Card")
    protected PaymentCardDataType card;

    /**
     * Default no-arg constructor
     * 
     */
    public MoneyInMoneyOutPaymentDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MoneyInMoneyOutPaymentDataType(final PartyRoleType prty, final String name, final String frstName, final BankAccountIdentificationType bnkAcct, final PaymentCardDataType card) {
        this.prty = prty;
        this.name = name;
        this.frstName = frstName;
        this.bnkAcct = bnkAcct;
        this.card = card;
    }

    /**
     * Gets the value of the prty property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrty() {
        return prty;
    }

    /**
     * Sets the value of the prty property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrty(PartyRoleType value) {
        this.prty = value;
    }

    public boolean isSetPrty() {
        return (this.prty!= null);
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the frstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrstName() {
        return frstName;
    }

    /**
     * Sets the value of the frstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrstName(String value) {
        this.frstName = value;
    }

    public boolean isSetFrstName() {
        return (this.frstName!= null);
    }

    /**
     * Gets the value of the bnkAcct property.
     * 
     * @return
     *     possible object is
     *     {@link BankAccountIdentificationType }
     *     
     */
    public BankAccountIdentificationType getBnkAcct() {
        return bnkAcct;
    }

    /**
     * Sets the value of the bnkAcct property.
     * 
     * @param value
     *     allowed object is
     *     {@link BankAccountIdentificationType }
     *     
     */
    public void setBnkAcct(BankAccountIdentificationType value) {
        this.bnkAcct = value;
    }

    public boolean isSetBnkAcct() {
        return (this.bnkAcct!= null);
    }

    /**
     * Gets the value of the card property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentCardDataType }
     *     
     */
    public PaymentCardDataType getCard() {
        return card;
    }

    /**
     * Sets the value of the card property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentCardDataType }
     *     
     */
    public void setCard(PaymentCardDataType value) {
        this.card = value;
    }

    public boolean isSetCard() {
        return (this.card!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("prty", prty).add("name", name).add("frstName", frstName).add("bnkAcct", bnkAcct).add("card", card).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(prty, name, frstName, bnkAcct, card);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MoneyInMoneyOutPaymentDataType o = ((MoneyInMoneyOutPaymentDataType) other);
        return ((((Objects.equal(prty, o.prty)&&Objects.equal(name, o.name))&&Objects.equal(frstName, o.frstName))&&Objects.equal(bnkAcct, o.bnkAcct))&&Objects.equal(card, o.card));
    }

}
