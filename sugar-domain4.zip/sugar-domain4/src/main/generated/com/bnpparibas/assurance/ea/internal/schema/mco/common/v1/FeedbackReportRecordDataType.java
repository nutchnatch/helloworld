
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * Feedback report record
 * 				data.
 * 			
 * 
 * <p>Java class for FeedbackReportRecordDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FeedbackReportRecordDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SeqId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="Status" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AcknowledgementStatusCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="StdFamily" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeedbackReportTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="SpecifFamily" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="Protocol" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DataProcessingProtocolCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="ProtocolVers" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeedbackReportMessageTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="ProcessUnitData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProcessUnitDataType" minOccurs="0"/&gt;
 *         &lt;element name="Line" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntervalType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Timestamp" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="Details" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeedbackReportRecordDetailsType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FeedbackReportRecordDataType", propOrder = {
    "seqId",
    "status",
    "stdFamily",
    "specifFamily",
    "protocol",
    "protocolVers",
    "type",
    "processUnitData",
    "line",
    "timestamp",
    "details"
})
public class FeedbackReportRecordDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SeqId")
    protected String seqId;
    @XmlElement(name = "Status")
    protected String status;
    @XmlElement(name = "StdFamily")
    protected String stdFamily;
    @XmlElement(name = "SpecifFamily")
    protected String specifFamily;
    @XmlElement(name = "Protocol")
    protected String protocol;
    @XmlElement(name = "ProtocolVers")
    protected String protocolVers;
    @XmlElement(name = "Type")
    protected String type;
    @XmlElement(name = "ProcessUnitData")
    protected ProcessUnitDataType processUnitData;
    @XmlElement(name = "Line")
    protected List<IntervalType> line;
    @XmlElement(name = "Timestamp", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date timestamp;
    @XmlElement(name = "Details")
    protected List<FeedbackReportRecordDetailsType> details;

    /**
     * Default no-arg constructor
     * 
     */
    public FeedbackReportRecordDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FeedbackReportRecordDataType(final String seqId, final String status, final String stdFamily, final String specifFamily, final String protocol, final String protocolVers, final String type, final ProcessUnitDataType processUnitData, final List<IntervalType> line, final Date timestamp, final List<FeedbackReportRecordDetailsType> details) {
        this.seqId = seqId;
        this.status = status;
        this.stdFamily = stdFamily;
        this.specifFamily = specifFamily;
        this.protocol = protocol;
        this.protocolVers = protocolVers;
        this.type = type;
        this.processUnitData = processUnitData;
        this.line = line;
        this.timestamp = timestamp;
        this.details = details;
    }

    /**
     * Gets the value of the seqId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqId() {
        return seqId;
    }

    /**
     * Sets the value of the seqId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqId(String value) {
        this.seqId = value;
    }

    public boolean isSetSeqId() {
        return (this.seqId!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    /**
     * Gets the value of the stdFamily property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStdFamily() {
        return stdFamily;
    }

    /**
     * Sets the value of the stdFamily property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStdFamily(String value) {
        this.stdFamily = value;
    }

    public boolean isSetStdFamily() {
        return (this.stdFamily!= null);
    }

    /**
     * Gets the value of the specifFamily property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpecifFamily() {
        return specifFamily;
    }

    /**
     * Sets the value of the specifFamily property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpecifFamily(String value) {
        this.specifFamily = value;
    }

    public boolean isSetSpecifFamily() {
        return (this.specifFamily!= null);
    }

    /**
     * Gets the value of the protocol property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProtocol() {
        return protocol;
    }

    /**
     * Sets the value of the protocol property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProtocol(String value) {
        this.protocol = value;
    }

    public boolean isSetProtocol() {
        return (this.protocol!= null);
    }

    /**
     * Gets the value of the protocolVers property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProtocolVers() {
        return protocolVers;
    }

    /**
     * Sets the value of the protocolVers property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProtocolVers(String value) {
        this.protocolVers = value;
    }

    public boolean isSetProtocolVers() {
        return (this.protocolVers!= null);
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the processUnitData property.
     * 
     * @return
     *     possible object is
     *     {@link ProcessUnitDataType }
     *     
     */
    public ProcessUnitDataType getProcessUnitData() {
        return processUnitData;
    }

    /**
     * Sets the value of the processUnitData property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProcessUnitDataType }
     *     
     */
    public void setProcessUnitData(ProcessUnitDataType value) {
        this.processUnitData = value;
    }

    public boolean isSetProcessUnitData() {
        return (this.processUnitData!= null);
    }

    /**
     * Gets the value of the line property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the line property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLine().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IntervalType }
     * 
     * 
     */
    public List<IntervalType> getLine() {
        if (line == null) {
            line = new ArrayList<IntervalType>();
        }
        return this.line;
    }

    public boolean isSetLine() {
        return ((this.line!= null)&&(!this.line.isEmpty()));
    }

    public void unsetLine() {
        this.line = null;
    }

    /**
     * Gets the value of the timestamp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getTimestamp() {
        return timestamp;
    }

    /**
     * Sets the value of the timestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTimestamp(Date value) {
        this.timestamp = value;
    }

    public boolean isSetTimestamp() {
        return (this.timestamp!= null);
    }

    /**
     * Gets the value of the details property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the details property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FeedbackReportRecordDetailsType }
     * 
     * 
     */
    public List<FeedbackReportRecordDetailsType> getDetails() {
        if (details == null) {
            details = new ArrayList<FeedbackReportRecordDetailsType>();
        }
        return this.details;
    }

    public boolean isSetDetails() {
        return ((this.details!= null)&&(!this.details.isEmpty()));
    }

    public void unsetDetails() {
        this.details = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("seqId", seqId).add("status", status).add("stdFamily", stdFamily).add("specifFamily", specifFamily).add("protocol", protocol).add("protocolVers", protocolVers).add("type", type).add("processUnitData", processUnitData).add("line", line).add("timestamp", timestamp).add("details", details).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(seqId, status, stdFamily, specifFamily, protocol, protocolVers, type, processUnitData, line, timestamp, details);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FeedbackReportRecordDataType o = ((FeedbackReportRecordDataType) other);
        return ((((((((((Objects.equal(seqId, o.seqId)&&Objects.equal(status, o.status))&&Objects.equal(stdFamily, o.stdFamily))&&Objects.equal(specifFamily, o.specifFamily))&&Objects.equal(protocol, o.protocol))&&Objects.equal(protocolVers, o.protocolVers))&&Objects.equal(type, o.type))&&Objects.equal(processUnitData, o.processUnitData))&&Objects.equal(line, o.line))&&Objects.equal(timestamp, o.timestamp))&&Objects.equal(details, o.details));
    }

}
