
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to mange information on the recipient of a
 * 				mailing document
 * 			
 * 
 * <p>Java class for MailingDocumentRecipientDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MailingDocumentRecipientDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PhoneAdrs" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PhoneAddressInputType" minOccurs="0"/&gt;
 *         &lt;element name="EMailAdrs" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MailingDocumentRecipientEMailAddressType" minOccurs="0"/&gt;
 *         &lt;element name="PostAdrs" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PostalAddressInputType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MailingDocumentRecipientDataType", propOrder = {
    "phoneAdrs",
    "eMailAdrs",
    "postAdrs"
})
public class MailingDocumentRecipientDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PhoneAdrs")
    protected PhoneAddressInputType phoneAdrs;
    @XmlElement(name = "EMailAdrs")
    protected MailingDocumentRecipientEMailAddressType eMailAdrs;
    @XmlElement(name = "PostAdrs")
    protected PostalAddressInputType postAdrs;

    /**
     * Default no-arg constructor
     * 
     */
    public MailingDocumentRecipientDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MailingDocumentRecipientDataType(final PhoneAddressInputType phoneAdrs, final MailingDocumentRecipientEMailAddressType eMailAdrs, final PostalAddressInputType postAdrs) {
        this.phoneAdrs = phoneAdrs;
        this.eMailAdrs = eMailAdrs;
        this.postAdrs = postAdrs;
    }

    /**
     * Gets the value of the phoneAdrs property.
     * 
     * @return
     *     possible object is
     *     {@link PhoneAddressInputType }
     *     
     */
    public PhoneAddressInputType getPhoneAdrs() {
        return phoneAdrs;
    }

    /**
     * Sets the value of the phoneAdrs property.
     * 
     * @param value
     *     allowed object is
     *     {@link PhoneAddressInputType }
     *     
     */
    public void setPhoneAdrs(PhoneAddressInputType value) {
        this.phoneAdrs = value;
    }

    public boolean isSetPhoneAdrs() {
        return (this.phoneAdrs!= null);
    }

    /**
     * Gets the value of the eMailAdrs property.
     * 
     * @return
     *     possible object is
     *     {@link MailingDocumentRecipientEMailAddressType }
     *     
     */
    public MailingDocumentRecipientEMailAddressType getEMailAdrs() {
        return eMailAdrs;
    }

    /**
     * Sets the value of the eMailAdrs property.
     * 
     * @param value
     *     allowed object is
     *     {@link MailingDocumentRecipientEMailAddressType }
     *     
     */
    public void setEMailAdrs(MailingDocumentRecipientEMailAddressType value) {
        this.eMailAdrs = value;
    }

    public boolean isSetEMailAdrs() {
        return (this.eMailAdrs!= null);
    }

    /**
     * Gets the value of the postAdrs property.
     * 
     * @return
     *     possible object is
     *     {@link PostalAddressInputType }
     *     
     */
    public PostalAddressInputType getPostAdrs() {
        return postAdrs;
    }

    /**
     * Sets the value of the postAdrs property.
     * 
     * @param value
     *     allowed object is
     *     {@link PostalAddressInputType }
     *     
     */
    public void setPostAdrs(PostalAddressInputType value) {
        this.postAdrs = value;
    }

    public boolean isSetPostAdrs() {
        return (this.postAdrs!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("phoneAdrs", phoneAdrs).add("eMailAdrs", eMailAdrs).add("postAdrs", postAdrs).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(phoneAdrs, eMailAdrs, postAdrs);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MailingDocumentRecipientDataType o = ((MailingDocumentRecipientDataType) other);
        return ((Objects.equal(phoneAdrs, o.phoneAdrs)&&Objects.equal(eMailAdrs, o.eMailAdrs))&&Objects.equal(postAdrs, o.postAdrs));
    }

}
