
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage information on loan installement and
 * 				outstanding balance
 * 			
 * 
 * <p>Java class for LoanInstallmentDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LoanInstallmentDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OutstdngBalnceAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *         &lt;element name="InstllmntAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *         &lt;element name="Fqcy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN"/&gt;
 *         &lt;element name="CalctnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LoanInstallmentDataType", propOrder = {
    "outstdngBalnceAmnt",
    "instllmntAmnt",
    "fqcy",
    "calctnDate"
})
public class LoanInstallmentDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "OutstdngBalnceAmnt", required = true)
    protected CurrencyAndAmountType outstdngBalnceAmnt;
    @XmlElement(name = "InstllmntAmnt", required = true)
    protected CurrencyAndAmountType instllmntAmnt;
    @XmlElement(name = "Fqcy", required = true)
    protected String fqcy;
    @XmlElement(name = "CalctnDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date calctnDate;

    /**
     * Default no-arg constructor
     * 
     */
    public LoanInstallmentDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public LoanInstallmentDataType(final CurrencyAndAmountType outstdngBalnceAmnt, final CurrencyAndAmountType instllmntAmnt, final String fqcy, final Date calctnDate) {
        this.outstdngBalnceAmnt = outstdngBalnceAmnt;
        this.instllmntAmnt = instllmntAmnt;
        this.fqcy = fqcy;
        this.calctnDate = calctnDate;
    }

    /**
     * Gets the value of the outstdngBalnceAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getOutstdngBalnceAmnt() {
        return outstdngBalnceAmnt;
    }

    /**
     * Sets the value of the outstdngBalnceAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setOutstdngBalnceAmnt(CurrencyAndAmountType value) {
        this.outstdngBalnceAmnt = value;
    }

    public boolean isSetOutstdngBalnceAmnt() {
        return (this.outstdngBalnceAmnt!= null);
    }

    /**
     * Gets the value of the instllmntAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getInstllmntAmnt() {
        return instllmntAmnt;
    }

    /**
     * Sets the value of the instllmntAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setInstllmntAmnt(CurrencyAndAmountType value) {
        this.instllmntAmnt = value;
    }

    public boolean isSetInstllmntAmnt() {
        return (this.instllmntAmnt!= null);
    }

    /**
     * Gets the value of the fqcy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFqcy() {
        return fqcy;
    }

    /**
     * Sets the value of the fqcy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFqcy(String value) {
        this.fqcy = value;
    }

    public boolean isSetFqcy() {
        return (this.fqcy!= null);
    }

    /**
     * Gets the value of the calctnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCalctnDate() {
        return calctnDate;
    }

    /**
     * Sets the value of the calctnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCalctnDate(Date value) {
        this.calctnDate = value;
    }

    public boolean isSetCalctnDate() {
        return (this.calctnDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("outstdngBalnceAmnt", outstdngBalnceAmnt).add("instllmntAmnt", instllmntAmnt).add("fqcy", fqcy).add("calctnDate", calctnDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(outstdngBalnceAmnt, instllmntAmnt, fqcy, calctnDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final LoanInstallmentDataType o = ((LoanInstallmentDataType) other);
        return (((Objects.equal(outstdngBalnceAmnt, o.outstdngBalnceAmnt)&&Objects.equal(instllmntAmnt, o.instllmntAmnt))&&Objects.equal(fqcy, o.fqcy))&&Objects.equal(calctnDate, o.calctnDate));
    }

}
