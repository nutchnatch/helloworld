
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage the distribution per fund for a
 * 				regular switch operation
 * 			
 * 
 * <p>Java class for PeriodicSwitchFundDistributionInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PeriodicSwitchFundDistributionInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SwitchWay" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}InvestmentDirectionCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="FundDistrbtn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SavingsOperationFundDistributionInputType"/&gt;
 *         &lt;element name="Trig" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SwitchTriggerType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Cond" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SwitchConditionType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PeriodicSwitchFundDistributionInputType", propOrder = {
    "switchWay",
    "fundDistrbtn",
    "trig",
    "cond"
})
public class PeriodicSwitchFundDistributionInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SwitchWay")
    protected String switchWay;
    @XmlElement(name = "FundDistrbtn", required = true)
    protected SavingsOperationFundDistributionInputType fundDistrbtn;
    @XmlElement(name = "Trig")
    protected List<SwitchTriggerType> trig;
    @XmlElement(name = "Cond")
    protected SwitchConditionType cond;

    /**
     * Default no-arg constructor
     * 
     */
    public PeriodicSwitchFundDistributionInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PeriodicSwitchFundDistributionInputType(final String switchWay, final SavingsOperationFundDistributionInputType fundDistrbtn, final List<SwitchTriggerType> trig, final SwitchConditionType cond) {
        this.switchWay = switchWay;
        this.fundDistrbtn = fundDistrbtn;
        this.trig = trig;
        this.cond = cond;
    }

    /**
     * Gets the value of the switchWay property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSwitchWay() {
        return switchWay;
    }

    /**
     * Sets the value of the switchWay property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSwitchWay(String value) {
        this.switchWay = value;
    }

    public boolean isSetSwitchWay() {
        return (this.switchWay!= null);
    }

    /**
     * Gets the value of the fundDistrbtn property.
     * 
     * @return
     *     possible object is
     *     {@link SavingsOperationFundDistributionInputType }
     *     
     */
    public SavingsOperationFundDistributionInputType getFundDistrbtn() {
        return fundDistrbtn;
    }

    /**
     * Sets the value of the fundDistrbtn property.
     * 
     * @param value
     *     allowed object is
     *     {@link SavingsOperationFundDistributionInputType }
     *     
     */
    public void setFundDistrbtn(SavingsOperationFundDistributionInputType value) {
        this.fundDistrbtn = value;
    }

    public boolean isSetFundDistrbtn() {
        return (this.fundDistrbtn!= null);
    }

    /**
     * Gets the value of the trig property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the trig property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTrig().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SwitchTriggerType }
     * 
     * 
     */
    public List<SwitchTriggerType> getTrig() {
        if (trig == null) {
            trig = new ArrayList<SwitchTriggerType>();
        }
        return this.trig;
    }

    public boolean isSetTrig() {
        return ((this.trig!= null)&&(!this.trig.isEmpty()));
    }

    public void unsetTrig() {
        this.trig = null;
    }

    /**
     * Gets the value of the cond property.
     * 
     * @return
     *     possible object is
     *     {@link SwitchConditionType }
     *     
     */
    public SwitchConditionType getCond() {
        return cond;
    }

    /**
     * Sets the value of the cond property.
     * 
     * @param value
     *     allowed object is
     *     {@link SwitchConditionType }
     *     
     */
    public void setCond(SwitchConditionType value) {
        this.cond = value;
    }

    public boolean isSetCond() {
        return (this.cond!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("switchWay", switchWay).add("fundDistrbtn", fundDistrbtn).add("trig", trig).add("cond", cond).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(switchWay, fundDistrbtn, trig, cond);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PeriodicSwitchFundDistributionInputType o = ((PeriodicSwitchFundDistributionInputType) other);
        return (((Objects.equal(switchWay, o.switchWay)&&Objects.equal(fundDistrbtn, o.fundDistrbtn))&&Objects.equal(trig, o.trig))&&Objects.equal(cond, o.cond));
    }

}
