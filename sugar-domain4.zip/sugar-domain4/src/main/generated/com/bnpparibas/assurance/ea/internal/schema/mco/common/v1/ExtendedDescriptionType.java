
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Extended description.
 * 			
 * 
 * <p>Java class for ExtendedDescriptionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ExtendedDescriptionType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Lang" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LanguageCode" minOccurs="0"/&gt;
 *         &lt;element name="ShortTxt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType" minOccurs="0"/&gt;
 *         &lt;element name="LongTxt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LongDescriptionType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ExtendedDescriptionType", propOrder = {
    "lang",
    "shortTxt",
    "longTxt"
})
public class ExtendedDescriptionType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Lang")
    protected String lang;
    @XmlElement(name = "ShortTxt")
    protected String shortTxt;
    @XmlElement(name = "LongTxt")
    protected String longTxt;

    /**
     * Default no-arg constructor
     * 
     */
    public ExtendedDescriptionType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ExtendedDescriptionType(final String lang, final String shortTxt, final String longTxt) {
        this.lang = lang;
        this.shortTxt = shortTxt;
        this.longTxt = longTxt;
    }

    /**
     * Gets the value of the lang property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * Sets the value of the lang property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

    public boolean isSetLang() {
        return (this.lang!= null);
    }

    /**
     * Gets the value of the shortTxt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShortTxt() {
        return shortTxt;
    }

    /**
     * Sets the value of the shortTxt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShortTxt(String value) {
        this.shortTxt = value;
    }

    public boolean isSetShortTxt() {
        return (this.shortTxt!= null);
    }

    /**
     * Gets the value of the longTxt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLongTxt() {
        return longTxt;
    }

    /**
     * Sets the value of the longTxt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLongTxt(String value) {
        this.longTxt = value;
    }

    public boolean isSetLongTxt() {
        return (this.longTxt!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("lang", lang).add("shortTxt", shortTxt).add("longTxt", longTxt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(lang, shortTxt, longTxt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ExtendedDescriptionType o = ((ExtendedDescriptionType) other);
        return ((Objects.equal(lang, o.lang)&&Objects.equal(shortTxt, o.shortTxt))&&Objects.equal(longTxt, o.longTxt));
    }

}
