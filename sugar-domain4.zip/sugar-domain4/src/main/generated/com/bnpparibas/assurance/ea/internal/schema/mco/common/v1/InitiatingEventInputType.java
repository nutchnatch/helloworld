
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * Common input event data linked to sales and after
 * 				sales operation requests
 * 			
 * 
 * <p>Java class for InitiatingEventInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InitiatingEventInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Ctgory" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}EventTypeCode"/&gt;
 *         &lt;element name="InputChnnl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CommunicationChannelCodeSLN"/&gt;
 *         &lt;element name="InputDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType"/&gt;
 *         &lt;element name="EffctveDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="EndDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="Origin" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ApplicationComponentCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="User" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}UserType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InitiatingEventInputType", propOrder = {
    "ctgory",
    "inputChnnl",
    "inputDate",
    "effctveDate",
    "endDate",
    "origin",
    "user"
})
public class InitiatingEventInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Ctgory", required = true)
    protected String ctgory;
    @XmlElement(name = "InputChnnl", required = true)
    protected String inputChnnl;
    @XmlElement(name = "InputDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date inputDate;
    @XmlElement(name = "EffctveDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date effctveDate;
    @XmlElement(name = "EndDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date endDate;
    @XmlElement(name = "Origin")
    protected String origin;
    @XmlElement(name = "User")
    protected UserType user;

    /**
     * Default no-arg constructor
     * 
     */
    public InitiatingEventInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public InitiatingEventInputType(final String ctgory, final String inputChnnl, final Date inputDate, final Date effctveDate, final Date endDate, final String origin, final UserType user) {
        this.ctgory = ctgory;
        this.inputChnnl = inputChnnl;
        this.inputDate = inputDate;
        this.effctveDate = effctveDate;
        this.endDate = endDate;
        this.origin = origin;
        this.user = user;
    }

    /**
     * Gets the value of the ctgory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCtgory() {
        return ctgory;
    }

    /**
     * Sets the value of the ctgory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCtgory(String value) {
        this.ctgory = value;
    }

    public boolean isSetCtgory() {
        return (this.ctgory!= null);
    }

    /**
     * Gets the value of the inputChnnl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInputChnnl() {
        return inputChnnl;
    }

    /**
     * Sets the value of the inputChnnl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInputChnnl(String value) {
        this.inputChnnl = value;
    }

    public boolean isSetInputChnnl() {
        return (this.inputChnnl!= null);
    }

    /**
     * Gets the value of the inputDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getInputDate() {
        return inputDate;
    }

    /**
     * Sets the value of the inputDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInputDate(Date value) {
        this.inputDate = value;
    }

    public boolean isSetInputDate() {
        return (this.inputDate!= null);
    }

    /**
     * Gets the value of the effctveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getEffctveDate() {
        return effctveDate;
    }

    /**
     * Sets the value of the effctveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEffctveDate(Date value) {
        this.effctveDate = value;
    }

    public boolean isSetEffctveDate() {
        return (this.effctveDate!= null);
    }

    /**
     * Gets the value of the endDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     * Sets the value of the endDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndDate(Date value) {
        this.endDate = value;
    }

    public boolean isSetEndDate() {
        return (this.endDate!= null);
    }

    /**
     * Gets the value of the origin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrigin() {
        return origin;
    }

    /**
     * Sets the value of the origin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrigin(String value) {
        this.origin = value;
    }

    public boolean isSetOrigin() {
        return (this.origin!= null);
    }

    /**
     * Gets the value of the user property.
     * 
     * @return
     *     possible object is
     *     {@link UserType }
     *     
     */
    public UserType getUser() {
        return user;
    }

    /**
     * Sets the value of the user property.
     * 
     * @param value
     *     allowed object is
     *     {@link UserType }
     *     
     */
    public void setUser(UserType value) {
        this.user = value;
    }

    public boolean isSetUser() {
        return (this.user!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("ctgory", ctgory).add("inputChnnl", inputChnnl).add("inputDate", inputDate).add("effctveDate", effctveDate).add("endDate", endDate).add("origin", origin).add("user", user).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(ctgory, inputChnnl, inputDate, effctveDate, endDate, origin, user);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final InitiatingEventInputType o = ((InitiatingEventInputType) other);
        return ((((((Objects.equal(ctgory, o.ctgory)&&Objects.equal(inputChnnl, o.inputChnnl))&&Objects.equal(inputDate, o.inputDate))&&Objects.equal(effctveDate, o.effctveDate))&&Objects.equal(endDate, o.endDate))&&Objects.equal(origin, o.origin))&&Objects.equal(user, o.user));
    }

}
