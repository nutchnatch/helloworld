
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on the fees derogation
 * 				at fund class level
 * 			
 * 
 * <p>Java class for FundClassFeeDerogationDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FundClassFeeDerogationDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Fee" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeeDerogationInputType"/&gt;
 *         &lt;element name="FundType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}UnitTypeCodeSLN"/&gt;
 *         &lt;element name="ProfIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FundClassFeeDerogationDataType", propOrder = {
    "fee",
    "fundType",
    "profIdntfctn"
})
public class FundClassFeeDerogationDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Fee", required = true)
    protected FeeDerogationInputType fee;
    @XmlElement(name = "FundType", required = true)
    protected String fundType;
    @XmlElement(name = "ProfIdntfctn")
    protected ObjectIdentificationType profIdntfctn;

    /**
     * Default no-arg constructor
     * 
     */
    public FundClassFeeDerogationDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FundClassFeeDerogationDataType(final FeeDerogationInputType fee, final String fundType, final ObjectIdentificationType profIdntfctn) {
        this.fee = fee;
        this.fundType = fundType;
        this.profIdntfctn = profIdntfctn;
    }

    /**
     * Gets the value of the fee property.
     * 
     * @return
     *     possible object is
     *     {@link FeeDerogationInputType }
     *     
     */
    public FeeDerogationInputType getFee() {
        return fee;
    }

    /**
     * Sets the value of the fee property.
     * 
     * @param value
     *     allowed object is
     *     {@link FeeDerogationInputType }
     *     
     */
    public void setFee(FeeDerogationInputType value) {
        this.fee = value;
    }

    public boolean isSetFee() {
        return (this.fee!= null);
    }

    /**
     * Gets the value of the fundType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundType() {
        return fundType;
    }

    /**
     * Sets the value of the fundType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundType(String value) {
        this.fundType = value;
    }

    public boolean isSetFundType() {
        return (this.fundType!= null);
    }

    /**
     * Gets the value of the profIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getProfIdntfctn() {
        return profIdntfctn;
    }

    /**
     * Sets the value of the profIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setProfIdntfctn(ObjectIdentificationType value) {
        this.profIdntfctn = value;
    }

    public boolean isSetProfIdntfctn() {
        return (this.profIdntfctn!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("fee", fee).add("fundType", fundType).add("profIdntfctn", profIdntfctn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(fee, fundType, profIdntfctn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FundClassFeeDerogationDataType o = ((FundClassFeeDerogationDataType) other);
        return ((Objects.equal(fee, o.fee)&&Objects.equal(fundType, o.fundType))&&Objects.equal(profIdntfctn, o.profIdntfctn));
    }

}
