
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Distributor Bloc identification with role and
 * 				network to which the distributor belongs
 * 			
 * 
 * <p>Java class for PartnerPartyType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartnerPartyType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PrtyIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="Role" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}RoleCodeSLN"/&gt;
 *         &lt;element name="Netwrk" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="NetwrkUnit" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="MgmtUnit" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartnerPartyType", propOrder = {
    "prtyIdntfctn",
    "role",
    "netwrk",
    "netwrkUnit",
    "mgmtUnit"
})
public class PartnerPartyType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PrtyIdntfctn", required = true)
    protected ObjectIdentificationType prtyIdntfctn;
    @XmlElement(name = "Role", required = true)
    protected String role;
    @XmlElement(name = "Netwrk")
    protected String netwrk;
    @XmlElement(name = "NetwrkUnit")
    protected String netwrkUnit;
    @XmlElement(name = "MgmtUnit")
    protected String mgmtUnit;

    /**
     * Default no-arg constructor
     * 
     */
    public PartnerPartyType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PartnerPartyType(final ObjectIdentificationType prtyIdntfctn, final String role, final String netwrk, final String netwrkUnit, final String mgmtUnit) {
        this.prtyIdntfctn = prtyIdntfctn;
        this.role = role;
        this.netwrk = netwrk;
        this.netwrkUnit = netwrkUnit;
        this.mgmtUnit = mgmtUnit;
    }

    /**
     * Gets the value of the prtyIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPrtyIdntfctn() {
        return prtyIdntfctn;
    }

    /**
     * Sets the value of the prtyIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPrtyIdntfctn(ObjectIdentificationType value) {
        this.prtyIdntfctn = value;
    }

    public boolean isSetPrtyIdntfctn() {
        return (this.prtyIdntfctn!= null);
    }

    /**
     * Gets the value of the role property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRole() {
        return role;
    }

    /**
     * Sets the value of the role property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRole(String value) {
        this.role = value;
    }

    public boolean isSetRole() {
        return (this.role!= null);
    }

    /**
     * Gets the value of the netwrk property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetwrk() {
        return netwrk;
    }

    /**
     * Sets the value of the netwrk property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetwrk(String value) {
        this.netwrk = value;
    }

    public boolean isSetNetwrk() {
        return (this.netwrk!= null);
    }

    /**
     * Gets the value of the netwrkUnit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetwrkUnit() {
        return netwrkUnit;
    }

    /**
     * Sets the value of the netwrkUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetwrkUnit(String value) {
        this.netwrkUnit = value;
    }

    public boolean isSetNetwrkUnit() {
        return (this.netwrkUnit!= null);
    }

    /**
     * Gets the value of the mgmtUnit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMgmtUnit() {
        return mgmtUnit;
    }

    /**
     * Sets the value of the mgmtUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMgmtUnit(String value) {
        this.mgmtUnit = value;
    }

    public boolean isSetMgmtUnit() {
        return (this.mgmtUnit!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("prtyIdntfctn", prtyIdntfctn).add("role", role).add("netwrk", netwrk).add("netwrkUnit", netwrkUnit).add("mgmtUnit", mgmtUnit).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(prtyIdntfctn, role, netwrk, netwrkUnit, mgmtUnit);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PartnerPartyType o = ((PartnerPartyType) other);
        return ((((Objects.equal(prtyIdntfctn, o.prtyIdntfctn)&&Objects.equal(role, o.role))&&Objects.equal(netwrk, o.netwrk))&&Objects.equal(netwrkUnit, o.netwrkUnit))&&Objects.equal(mgmtUnit, o.mgmtUnit));
    }

}
