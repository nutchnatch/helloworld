
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Interval definition
 * 				(inclusive).
 * 			
 * 
 * <p>Java class for IntervalType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="IntervalType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Start" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *         &lt;element name="Numb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *         &lt;element name="End" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IntervalType", propOrder = {
    "start",
    "numb",
    "end"
})
public class IntervalType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Start")
    protected BigInteger start;
    @XmlElement(name = "Numb")
    protected BigInteger numb;
    @XmlElement(name = "End")
    protected BigInteger end;

    /**
     * Default no-arg constructor
     * 
     */
    public IntervalType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public IntervalType(final BigInteger start, final BigInteger numb, final BigInteger end) {
        this.start = start;
        this.numb = numb;
        this.end = end;
    }

    /**
     * Gets the value of the start property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getStart() {
        return start;
    }

    /**
     * Sets the value of the start property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setStart(BigInteger value) {
        this.start = value;
    }

    public boolean isSetStart() {
        return (this.start!= null);
    }

    /**
     * Gets the value of the numb property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNumb() {
        return numb;
    }

    /**
     * Sets the value of the numb property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNumb(BigInteger value) {
        this.numb = value;
    }

    public boolean isSetNumb() {
        return (this.numb!= null);
    }

    /**
     * Gets the value of the end property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getEnd() {
        return end;
    }

    /**
     * Sets the value of the end property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setEnd(BigInteger value) {
        this.end = value;
    }

    public boolean isSetEnd() {
        return (this.end!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("start", start).add("numb", numb).add("end", end).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(start, numb, end);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final IntervalType o = ((IntervalType) other);
        return ((Objects.equal(start, o.start)&&Objects.equal(numb, o.numb))&&Objects.equal(end, o.end));
    }

}
