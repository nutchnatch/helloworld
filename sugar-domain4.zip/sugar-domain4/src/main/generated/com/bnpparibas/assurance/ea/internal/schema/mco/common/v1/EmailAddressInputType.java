
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type of email address
 * 
 * <p>Java class for EmailAddressInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EmailAddressInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="UseType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ContactInformationUseTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="UseCntxt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}UseContextTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="EmailName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}EmailFormatType"/&gt;
 *         &lt;element name="ValdtyDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EmailAddressInputType", propOrder = {
    "useType",
    "useCntxt",
    "emailName",
    "valdtyDate"
})
public class EmailAddressInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "UseType")
    protected String useType;
    @XmlElement(name = "UseCntxt")
    protected String useCntxt;
    @XmlElement(name = "EmailName", required = true)
    protected String emailName;
    @XmlElement(name = "ValdtyDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date valdtyDate;

    /**
     * Default no-arg constructor
     * 
     */
    public EmailAddressInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public EmailAddressInputType(final String useType, final String useCntxt, final String emailName, final Date valdtyDate) {
        this.useType = useType;
        this.useCntxt = useCntxt;
        this.emailName = emailName;
        this.valdtyDate = valdtyDate;
    }

    /**
     * Gets the value of the useType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUseType() {
        return useType;
    }

    /**
     * Sets the value of the useType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUseType(String value) {
        this.useType = value;
    }

    public boolean isSetUseType() {
        return (this.useType!= null);
    }

    /**
     * Gets the value of the useCntxt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUseCntxt() {
        return useCntxt;
    }

    /**
     * Sets the value of the useCntxt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUseCntxt(String value) {
        this.useCntxt = value;
    }

    public boolean isSetUseCntxt() {
        return (this.useCntxt!= null);
    }

    /**
     * Gets the value of the emailName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailName() {
        return emailName;
    }

    /**
     * Sets the value of the emailName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailName(String value) {
        this.emailName = value;
    }

    public boolean isSetEmailName() {
        return (this.emailName!= null);
    }

    /**
     * Gets the value of the valdtyDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getValdtyDate() {
        return valdtyDate;
    }

    /**
     * Sets the value of the valdtyDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValdtyDate(Date value) {
        this.valdtyDate = value;
    }

    public boolean isSetValdtyDate() {
        return (this.valdtyDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("useType", useType).add("useCntxt", useCntxt).add("emailName", emailName).add("valdtyDate", valdtyDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(useType, useCntxt, emailName, valdtyDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final EmailAddressInputType o = ((EmailAddressInputType) other);
        return (((Objects.equal(useType, o.useType)&&Objects.equal(useCntxt, o.useCntxt))&&Objects.equal(emailName, o.emailName))&&Objects.equal(valdtyDate, o.valdtyDate));
    }

}
