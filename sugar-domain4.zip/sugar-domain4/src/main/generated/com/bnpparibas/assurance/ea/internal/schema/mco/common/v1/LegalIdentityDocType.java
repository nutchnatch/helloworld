
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * used to describe identity card of a customer
 * 			
 * 
 * <p>Java class for LegalIdentityDocType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LegalIdentityDocType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentityLegalDocumentTypeCodeSLN"/&gt;
 *         &lt;element name="Number" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType"/&gt;
 *         &lt;element name="ExpirtnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LegalIdentityDocType", propOrder = {
    "type",
    "number",
    "expirtnDate"
})
public class LegalIdentityDocType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "Number", required = true)
    protected String number;
    @XmlElement(name = "ExpirtnDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date expirtnDate;

    /**
     * Default no-arg constructor
     * 
     */
    public LegalIdentityDocType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public LegalIdentityDocType(final String type, final String number, final Date expirtnDate) {
        this.type = type;
        this.number = number;
        this.expirtnDate = expirtnDate;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the number property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumber() {
        return number;
    }

    /**
     * Sets the value of the number property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumber(String value) {
        this.number = value;
    }

    public boolean isSetNumber() {
        return (this.number!= null);
    }

    /**
     * Gets the value of the expirtnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getExpirtnDate() {
        return expirtnDate;
    }

    /**
     * Sets the value of the expirtnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpirtnDate(Date value) {
        this.expirtnDate = value;
    }

    public boolean isSetExpirtnDate() {
        return (this.expirtnDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("type", type).add("number", number).add("expirtnDate", expirtnDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(type, number, expirtnDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final LegalIdentityDocType o = ((LegalIdentityDocType) other);
        return ((Objects.equal(type, o.type)&&Objects.equal(number, o.number))&&Objects.equal(expirtnDate, o.expirtnDate));
    }

}
