
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Description of one
 * 				particular group of metadata.
 * 			
 * 
 * <p>Java class for MetadataGroupType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MetadataGroupType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Cntxt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MetadataGroupContextType" minOccurs="0"/&gt;
 *         &lt;element name="OthrData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MetadataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MetadataGroupType", propOrder = {
    "cntxt",
    "othrData"
})
public class MetadataGroupType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Cntxt")
    protected MetadataGroupContextType cntxt;
    @XmlElement(name = "OthrData")
    protected List<MetadataType> othrData;

    /**
     * Default no-arg constructor
     * 
     */
    public MetadataGroupType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MetadataGroupType(final MetadataGroupContextType cntxt, final List<MetadataType> othrData) {
        this.cntxt = cntxt;
        this.othrData = othrData;
    }

    /**
     * Gets the value of the cntxt property.
     * 
     * @return
     *     possible object is
     *     {@link MetadataGroupContextType }
     *     
     */
    public MetadataGroupContextType getCntxt() {
        return cntxt;
    }

    /**
     * Sets the value of the cntxt property.
     * 
     * @param value
     *     allowed object is
     *     {@link MetadataGroupContextType }
     *     
     */
    public void setCntxt(MetadataGroupContextType value) {
        this.cntxt = value;
    }

    public boolean isSetCntxt() {
        return (this.cntxt!= null);
    }

    /**
     * Gets the value of the othrData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the othrData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOthrData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MetadataType }
     * 
     * 
     */
    public List<MetadataType> getOthrData() {
        if (othrData == null) {
            othrData = new ArrayList<MetadataType>();
        }
        return this.othrData;
    }

    public boolean isSetOthrData() {
        return ((this.othrData!= null)&&(!this.othrData.isEmpty()));
    }

    public void unsetOthrData() {
        this.othrData = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("cntxt", cntxt).add("othrData", othrData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(cntxt, othrData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MetadataGroupType o = ((MetadataGroupType) other);
        return (Objects.equal(cntxt, o.cntxt)&&Objects.equal(othrData, o.othrData));
    }

}
