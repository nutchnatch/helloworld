
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to define data on fees
 * 
 * <p>Java class for FeeType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FeeType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Code" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeesCodeSLN"/&gt;
 *         &lt;element name="BaseAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="Status" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeesCharacterCodeSLN"/&gt;
 *         &lt;element name="DerogtnIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="PrcntageRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" minOccurs="0"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *         &lt;element name="RateType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}WayOfCalculatingCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FeeType", propOrder = {
    "code",
    "baseAmnt",
    "status",
    "derogtnIdntfctn",
    "prcntageRate",
    "amnt",
    "rateType"
})
public class FeeType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Code", required = true)
    protected String code;
    @XmlElement(name = "BaseAmnt")
    protected CurrencyAndAmountType baseAmnt;
    @XmlElement(name = "Status", required = true)
    protected String status;
    @XmlElement(name = "DerogtnIdntfctn")
    protected ObjectIdentificationType derogtnIdntfctn;
    @XmlElement(name = "PrcntageRate")
    protected Double prcntageRate;
    @XmlElement(name = "Amnt", required = true)
    protected CurrencyAndAmountType amnt;
    @XmlElement(name = "RateType")
    protected String rateType;

    /**
     * Default no-arg constructor
     * 
     */
    public FeeType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FeeType(final String code, final CurrencyAndAmountType baseAmnt, final String status, final ObjectIdentificationType derogtnIdntfctn, final Double prcntageRate, final CurrencyAndAmountType amnt, final String rateType) {
        this.code = code;
        this.baseAmnt = baseAmnt;
        this.status = status;
        this.derogtnIdntfctn = derogtnIdntfctn;
        this.prcntageRate = prcntageRate;
        this.amnt = amnt;
        this.rateType = rateType;
    }

    /**
     * Gets the value of the code property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCode(String value) {
        this.code = value;
    }

    public boolean isSetCode() {
        return (this.code!= null);
    }

    /**
     * Gets the value of the baseAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getBaseAmnt() {
        return baseAmnt;
    }

    /**
     * Sets the value of the baseAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setBaseAmnt(CurrencyAndAmountType value) {
        this.baseAmnt = value;
    }

    public boolean isSetBaseAmnt() {
        return (this.baseAmnt!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    /**
     * Gets the value of the derogtnIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getDerogtnIdntfctn() {
        return derogtnIdntfctn;
    }

    /**
     * Sets the value of the derogtnIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setDerogtnIdntfctn(ObjectIdentificationType value) {
        this.derogtnIdntfctn = value;
    }

    public boolean isSetDerogtnIdntfctn() {
        return (this.derogtnIdntfctn!= null);
    }

    /**
     * Gets the value of the prcntageRate property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getPrcntageRate() {
        return prcntageRate;
    }

    /**
     * Sets the value of the prcntageRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setPrcntageRate(Double value) {
        this.prcntageRate = value;
    }

    public boolean isSetPrcntageRate() {
        return (this.prcntageRate!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    /**
     * Gets the value of the rateType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRateType() {
        return rateType;
    }

    /**
     * Sets the value of the rateType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRateType(String value) {
        this.rateType = value;
    }

    public boolean isSetRateType() {
        return (this.rateType!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("code", code).add("baseAmnt", baseAmnt).add("status", status).add("derogtnIdntfctn", derogtnIdntfctn).add("prcntageRate", prcntageRate).add("amnt", amnt).add("rateType", rateType).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(code, baseAmnt, status, derogtnIdntfctn, prcntageRate, amnt, rateType);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FeeType o = ((FeeType) other);
        return ((((((Objects.equal(code, o.code)&&Objects.equal(baseAmnt, o.baseAmnt))&&Objects.equal(status, o.status))&&Objects.equal(derogtnIdntfctn, o.derogtnIdntfctn))&&Objects.equal(prcntageRate, o.prcntageRate))&&Objects.equal(amnt, o.amnt))&&Objects.equal(rateType, o.rateType));
    }

}
