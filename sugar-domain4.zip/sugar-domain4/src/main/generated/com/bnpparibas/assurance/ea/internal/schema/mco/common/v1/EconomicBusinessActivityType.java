
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type of economic activity
 * 
 * <p>Java class for EconomicBusinessActivityType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EconomicBusinessActivityType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CSPCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CSPCode" minOccurs="0"/&gt;
 *         &lt;element name="OccptnDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType" minOccurs="0"/&gt;
 *         &lt;element name="EmplmntStatus" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}EmploymentStatusCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="EmplmntData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}EmploymentDataType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EconomicBusinessActivityType", propOrder = {
    "cspCode",
    "occptnDesc",
    "emplmntStatus",
    "emplmntData"
})
public class EconomicBusinessActivityType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CSPCode")
    protected String cspCode;
    @XmlElement(name = "OccptnDesc")
    protected String occptnDesc;
    @XmlElement(name = "EmplmntStatus")
    protected String emplmntStatus;
    @XmlElement(name = "EmplmntData")
    protected EmploymentDataType emplmntData;

    /**
     * Default no-arg constructor
     * 
     */
    public EconomicBusinessActivityType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public EconomicBusinessActivityType(final String cspCode, final String occptnDesc, final String emplmntStatus, final EmploymentDataType emplmntData) {
        this.cspCode = cspCode;
        this.occptnDesc = occptnDesc;
        this.emplmntStatus = emplmntStatus;
        this.emplmntData = emplmntData;
    }

    /**
     * Gets the value of the cspCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCSPCode() {
        return cspCode;
    }

    /**
     * Sets the value of the cspCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCSPCode(String value) {
        this.cspCode = value;
    }

    public boolean isSetCSPCode() {
        return (this.cspCode!= null);
    }

    /**
     * Gets the value of the occptnDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOccptnDesc() {
        return occptnDesc;
    }

    /**
     * Sets the value of the occptnDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOccptnDesc(String value) {
        this.occptnDesc = value;
    }

    public boolean isSetOccptnDesc() {
        return (this.occptnDesc!= null);
    }

    /**
     * Gets the value of the emplmntStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmplmntStatus() {
        return emplmntStatus;
    }

    /**
     * Sets the value of the emplmntStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmplmntStatus(String value) {
        this.emplmntStatus = value;
    }

    public boolean isSetEmplmntStatus() {
        return (this.emplmntStatus!= null);
    }

    /**
     * Gets the value of the emplmntData property.
     * 
     * @return
     *     possible object is
     *     {@link EmploymentDataType }
     *     
     */
    public EmploymentDataType getEmplmntData() {
        return emplmntData;
    }

    /**
     * Sets the value of the emplmntData property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmploymentDataType }
     *     
     */
    public void setEmplmntData(EmploymentDataType value) {
        this.emplmntData = value;
    }

    public boolean isSetEmplmntData() {
        return (this.emplmntData!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("cspCode", cspCode).add("occptnDesc", occptnDesc).add("emplmntStatus", emplmntStatus).add("emplmntData", emplmntData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(cspCode, occptnDesc, emplmntStatus, emplmntData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final EconomicBusinessActivityType o = ((EconomicBusinessActivityType) other);
        return (((Objects.equal(cspCode, o.cspCode)&&Objects.equal(occptnDesc, o.occptnDesc))&&Objects.equal(emplmntStatus, o.emplmntStatus))&&Objects.equal(emplmntData, o.emplmntData));
    }

}
