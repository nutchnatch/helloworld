
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * information on a goods like the value of a car, a
 * 				flat, etc
 * 			
 * 
 * <p>Java class for GoodsDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GoodsDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="GoodsAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GoodsDataInputType", propOrder = {
    "goodsAmnt"
})
public class GoodsDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "GoodsAmnt")
    protected CurrencyAndAmountType goodsAmnt;

    /**
     * Default no-arg constructor
     * 
     */
    public GoodsDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public GoodsDataInputType(final CurrencyAndAmountType goodsAmnt) {
        this.goodsAmnt = goodsAmnt;
    }

    /**
     * Gets the value of the goodsAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getGoodsAmnt() {
        return goodsAmnt;
    }

    /**
     * Sets the value of the goodsAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setGoodsAmnt(CurrencyAndAmountType value) {
        this.goodsAmnt = value;
    }

    public boolean isSetGoodsAmnt() {
        return (this.goodsAmnt!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("goodsAmnt", goodsAmnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(goodsAmnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final GoodsDataInputType o = ((GoodsDataInputType) other);
        return Objects.equal(goodsAmnt, o.goodsAmnt);
    }

}
