
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage global data of a mailing document
 * 			
 * 
 * <p>Java class for MailingDocumentDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MailingDocumentDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Format" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentFormatTypeCodeSLN"/&gt;
 *         &lt;element name="ChnnlType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MediaTypeCodeSLN"/&gt;
 *         &lt;element name="PriortyDgree" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PriorityDegreeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="AcknwldgeType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MailingAcknowledgementTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Lang" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LanguageCode"/&gt;
 *         &lt;element name="SubmssionPrd" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="DatePrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *                   &lt;element name="TimePrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}TimePeriodType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MailingDocumentDataType", propOrder = {
    "format",
    "chnnlType",
    "priortyDgree",
    "acknwldgeType",
    "lang",
    "submssionPrd"
})
public class MailingDocumentDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Format", required = true)
    protected String format;
    @XmlElement(name = "ChnnlType", required = true)
    protected String chnnlType;
    @XmlElement(name = "PriortyDgree")
    protected String priortyDgree;
    @XmlElement(name = "AcknwldgeType")
    protected String acknwldgeType;
    @XmlElement(name = "Lang", required = true)
    protected String lang;
    @XmlElement(name = "SubmssionPrd")
    protected List<MailingDocumentDataType.SubmssionPrd> submssionPrd;

    /**
     * Default no-arg constructor
     * 
     */
    public MailingDocumentDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MailingDocumentDataType(final String format, final String chnnlType, final String priortyDgree, final String acknwldgeType, final String lang, final List<MailingDocumentDataType.SubmssionPrd> submssionPrd) {
        this.format = format;
        this.chnnlType = chnnlType;
        this.priortyDgree = priortyDgree;
        this.acknwldgeType = acknwldgeType;
        this.lang = lang;
        this.submssionPrd = submssionPrd;
    }

    /**
     * Gets the value of the format property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormat() {
        return format;
    }

    /**
     * Sets the value of the format property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormat(String value) {
        this.format = value;
    }

    public boolean isSetFormat() {
        return (this.format!= null);
    }

    /**
     * Gets the value of the chnnlType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChnnlType() {
        return chnnlType;
    }

    /**
     * Sets the value of the chnnlType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChnnlType(String value) {
        this.chnnlType = value;
    }

    public boolean isSetChnnlType() {
        return (this.chnnlType!= null);
    }

    /**
     * Gets the value of the priortyDgree property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPriortyDgree() {
        return priortyDgree;
    }

    /**
     * Sets the value of the priortyDgree property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPriortyDgree(String value) {
        this.priortyDgree = value;
    }

    public boolean isSetPriortyDgree() {
        return (this.priortyDgree!= null);
    }

    /**
     * Gets the value of the acknwldgeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAcknwldgeType() {
        return acknwldgeType;
    }

    /**
     * Sets the value of the acknwldgeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAcknwldgeType(String value) {
        this.acknwldgeType = value;
    }

    public boolean isSetAcknwldgeType() {
        return (this.acknwldgeType!= null);
    }

    /**
     * Gets the value of the lang property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLang() {
        return lang;
    }

    /**
     * Sets the value of the lang property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLang(String value) {
        this.lang = value;
    }

    public boolean isSetLang() {
        return (this.lang!= null);
    }

    /**
     * Gets the value of the submssionPrd property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the submssionPrd property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSubmssionPrd().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MailingDocumentDataType.SubmssionPrd }
     * 
     * 
     */
    public List<MailingDocumentDataType.SubmssionPrd> getSubmssionPrd() {
        if (submssionPrd == null) {
            submssionPrd = new ArrayList<MailingDocumentDataType.SubmssionPrd>();
        }
        return this.submssionPrd;
    }

    public boolean isSetSubmssionPrd() {
        return ((this.submssionPrd!= null)&&(!this.submssionPrd.isEmpty()));
    }

    public void unsetSubmssionPrd() {
        this.submssionPrd = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("format", format).add("chnnlType", chnnlType).add("priortyDgree", priortyDgree).add("acknwldgeType", acknwldgeType).add("lang", lang).add("submssionPrd", submssionPrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(format, chnnlType, priortyDgree, acknwldgeType, lang, submssionPrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MailingDocumentDataType o = ((MailingDocumentDataType) other);
        return (((((Objects.equal(format, o.format)&&Objects.equal(chnnlType, o.chnnlType))&&Objects.equal(priortyDgree, o.priortyDgree))&&Objects.equal(acknwldgeType, o.acknwldgeType))&&Objects.equal(lang, o.lang))&&Objects.equal(submssionPrd, o.submssionPrd));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="DatePrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
     *         &lt;element name="TimePrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}TimePeriodType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "datePrd",
        "timePrd"
    })
    public static class SubmssionPrd implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "DatePrd")
        protected DatePeriodType datePrd;
        @XmlElement(name = "TimePrd")
        protected TimePeriodType timePrd;

        /**
         * Default no-arg constructor
         * 
         */
        public SubmssionPrd() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public SubmssionPrd(final DatePeriodType datePrd, final TimePeriodType timePrd) {
            this.datePrd = datePrd;
            this.timePrd = timePrd;
        }

        /**
         * Gets the value of the datePrd property.
         * 
         * @return
         *     possible object is
         *     {@link DatePeriodType }
         *     
         */
        public DatePeriodType getDatePrd() {
            return datePrd;
        }

        /**
         * Sets the value of the datePrd property.
         * 
         * @param value
         *     allowed object is
         *     {@link DatePeriodType }
         *     
         */
        public void setDatePrd(DatePeriodType value) {
            this.datePrd = value;
        }

        public boolean isSetDatePrd() {
            return (this.datePrd!= null);
        }

        /**
         * Gets the value of the timePrd property.
         * 
         * @return
         *     possible object is
         *     {@link TimePeriodType }
         *     
         */
        public TimePeriodType getTimePrd() {
            return timePrd;
        }

        /**
         * Sets the value of the timePrd property.
         * 
         * @param value
         *     allowed object is
         *     {@link TimePeriodType }
         *     
         */
        public void setTimePrd(TimePeriodType value) {
            this.timePrd = value;
        }

        public boolean isSetTimePrd() {
            return (this.timePrd!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("datePrd", datePrd).add("timePrd", timePrd).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(datePrd, timePrd);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final MailingDocumentDataType.SubmssionPrd o = ((MailingDocumentDataType.SubmssionPrd) other);
            return (Objects.equal(datePrd, o.datePrd)&&Objects.equal(timePrd, o.timePrd));
        }

    }

}
