
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage data on a policy pledge
 * 			
 * 
 * <p>Java class for PledgeDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PledgeDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Idntctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PledgeTypeCode" minOccurs="0"/&gt;
 *         &lt;element name="Status" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PledgeStatusCode" minOccurs="0"/&gt;
 *         &lt;element name="EffctveDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="Prty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="DelgatdOpe" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DelgatedOperationType" minOccurs="0"/&gt;
 *         &lt;element name="FreeText" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FreeTextType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PledgeDataInputType", propOrder = {
    "idntctn",
    "type",
    "status",
    "effctveDate",
    "prty",
    "delgatdOpe",
    "freeText"
})
public class PledgeDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Idntctn")
    protected ObjectIdentificationType idntctn;
    @XmlElement(name = "Type")
    protected String type;
    @XmlElement(name = "Status")
    protected String status;
    @XmlElement(name = "EffctveDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date effctveDate;
    @XmlElement(name = "Prty")
    protected PartyRoleType prty;
    @XmlElement(name = "DelgatdOpe")
    protected DelgatedOperationType delgatdOpe;
    @XmlElement(name = "FreeText")
    protected String freeText;

    /**
     * Default no-arg constructor
     * 
     */
    public PledgeDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PledgeDataInputType(final ObjectIdentificationType idntctn, final String type, final String status, final Date effctveDate, final PartyRoleType prty, final DelgatedOperationType delgatdOpe, final String freeText) {
        this.idntctn = idntctn;
        this.type = type;
        this.status = status;
        this.effctveDate = effctveDate;
        this.prty = prty;
        this.delgatdOpe = delgatdOpe;
        this.freeText = freeText;
    }

    /**
     * Gets the value of the idntctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getIdntctn() {
        return idntctn;
    }

    /**
     * Sets the value of the idntctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setIdntctn(ObjectIdentificationType value) {
        this.idntctn = value;
    }

    public boolean isSetIdntctn() {
        return (this.idntctn!= null);
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    /**
     * Gets the value of the effctveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getEffctveDate() {
        return effctveDate;
    }

    /**
     * Sets the value of the effctveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEffctveDate(Date value) {
        this.effctveDate = value;
    }

    public boolean isSetEffctveDate() {
        return (this.effctveDate!= null);
    }

    /**
     * Gets the value of the prty property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrty() {
        return prty;
    }

    /**
     * Sets the value of the prty property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrty(PartyRoleType value) {
        this.prty = value;
    }

    public boolean isSetPrty() {
        return (this.prty!= null);
    }

    /**
     * Gets the value of the delgatdOpe property.
     * 
     * @return
     *     possible object is
     *     {@link DelgatedOperationType }
     *     
     */
    public DelgatedOperationType getDelgatdOpe() {
        return delgatdOpe;
    }

    /**
     * Sets the value of the delgatdOpe property.
     * 
     * @param value
     *     allowed object is
     *     {@link DelgatedOperationType }
     *     
     */
    public void setDelgatdOpe(DelgatedOperationType value) {
        this.delgatdOpe = value;
    }

    public boolean isSetDelgatdOpe() {
        return (this.delgatdOpe!= null);
    }

    /**
     * Gets the value of the freeText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFreeText() {
        return freeText;
    }

    /**
     * Sets the value of the freeText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFreeText(String value) {
        this.freeText = value;
    }

    public boolean isSetFreeText() {
        return (this.freeText!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("idntctn", idntctn).add("type", type).add("status", status).add("effctveDate", effctveDate).add("prty", prty).add("delgatdOpe", delgatdOpe).add("freeText", freeText).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(idntctn, type, status, effctveDate, prty, delgatdOpe, freeText);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PledgeDataInputType o = ((PledgeDataInputType) other);
        return ((((((Objects.equal(idntctn, o.idntctn)&&Objects.equal(type, o.type))&&Objects.equal(status, o.status))&&Objects.equal(effctveDate, o.effctveDate))&&Objects.equal(prty, o.prty))&&Objects.equal(delgatdOpe, o.delgatdOpe))&&Objects.equal(freeText, o.freeText));
    }

}
