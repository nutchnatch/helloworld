
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on extra-premium with removed
 * 				exlusions
 * 			
 * 
 * <p>Java class for ExtraPremiumType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ExtraPremiumType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ExtraPremData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ExtraPremiumDataType"/&gt;
 *         &lt;element name="RemvdExclsn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CoverParticularExclusionType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ExtraPremiumType", propOrder = {
    "extraPremData",
    "remvdExclsn"
})
public class ExtraPremiumType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ExtraPremData", required = true)
    protected ExtraPremiumDataType extraPremData;
    @XmlElement(name = "RemvdExclsn")
    protected CoverParticularExclusionType remvdExclsn;

    /**
     * Default no-arg constructor
     * 
     */
    public ExtraPremiumType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ExtraPremiumType(final ExtraPremiumDataType extraPremData, final CoverParticularExclusionType remvdExclsn) {
        this.extraPremData = extraPremData;
        this.remvdExclsn = remvdExclsn;
    }

    /**
     * Gets the value of the extraPremData property.
     * 
     * @return
     *     possible object is
     *     {@link ExtraPremiumDataType }
     *     
     */
    public ExtraPremiumDataType getExtraPremData() {
        return extraPremData;
    }

    /**
     * Sets the value of the extraPremData property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExtraPremiumDataType }
     *     
     */
    public void setExtraPremData(ExtraPremiumDataType value) {
        this.extraPremData = value;
    }

    public boolean isSetExtraPremData() {
        return (this.extraPremData!= null);
    }

    /**
     * Gets the value of the remvdExclsn property.
     * 
     * @return
     *     possible object is
     *     {@link CoverParticularExclusionType }
     *     
     */
    public CoverParticularExclusionType getRemvdExclsn() {
        return remvdExclsn;
    }

    /**
     * Sets the value of the remvdExclsn property.
     * 
     * @param value
     *     allowed object is
     *     {@link CoverParticularExclusionType }
     *     
     */
    public void setRemvdExclsn(CoverParticularExclusionType value) {
        this.remvdExclsn = value;
    }

    public boolean isSetRemvdExclsn() {
        return (this.remvdExclsn!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("extraPremData", extraPremData).add("remvdExclsn", remvdExclsn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(extraPremData, remvdExclsn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ExtraPremiumType o = ((ExtraPremiumType) other);
        return (Objects.equal(extraPremData, o.extraPremData)&&Objects.equal(remvdExclsn, o.remvdExclsn));
    }

}
