
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Standard identification bloc with ISIN identifier
 * 				and an additional block to manage other identifiers
 * 			
 * 
 * <p>Java class for FinancialInstrumentIdentificationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FinancialInstrumentIdentificationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ISIN" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISINIdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="OthrIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="ListngPlaceId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MICIdentifierType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FinancialInstrumentIdentificationType", propOrder = {
    "isin",
    "othrIdntfctn",
    "listngPlaceId"
})
public class FinancialInstrumentIdentificationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ISIN")
    protected String isin;
    @XmlElement(name = "OthrIdntfctn")
    protected ObjectIdentificationType othrIdntfctn;
    @XmlElement(name = "ListngPlaceId")
    protected String listngPlaceId;

    /**
     * Default no-arg constructor
     * 
     */
    public FinancialInstrumentIdentificationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FinancialInstrumentIdentificationType(final String isin, final ObjectIdentificationType othrIdntfctn, final String listngPlaceId) {
        this.isin = isin;
        this.othrIdntfctn = othrIdntfctn;
        this.listngPlaceId = listngPlaceId;
    }

    /**
     * Gets the value of the isin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISIN() {
        return isin;
    }

    /**
     * Sets the value of the isin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISIN(String value) {
        this.isin = value;
    }

    public boolean isSetISIN() {
        return (this.isin!= null);
    }

    /**
     * Gets the value of the othrIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getOthrIdntfctn() {
        return othrIdntfctn;
    }

    /**
     * Sets the value of the othrIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setOthrIdntfctn(ObjectIdentificationType value) {
        this.othrIdntfctn = value;
    }

    public boolean isSetOthrIdntfctn() {
        return (this.othrIdntfctn!= null);
    }

    /**
     * Gets the value of the listngPlaceId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getListngPlaceId() {
        return listngPlaceId;
    }

    /**
     * Sets the value of the listngPlaceId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setListngPlaceId(String value) {
        this.listngPlaceId = value;
    }

    public boolean isSetListngPlaceId() {
        return (this.listngPlaceId!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("isin", isin).add("othrIdntfctn", othrIdntfctn).add("listngPlaceId", listngPlaceId).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(isin, othrIdntfctn, listngPlaceId);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FinancialInstrumentIdentificationType o = ((FinancialInstrumentIdentificationType) other);
        return ((Objects.equal(isin, o.isin)&&Objects.equal(othrIdntfctn, o.othrIdntfctn))&&Objects.equal(listngPlaceId, o.listngPlaceId));
    }

}
