
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage some data on a interest based fund
 * 				for statement
 * 			
 * 
 * <p>Java class for InterestFundStatementDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InterestFundStatementDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType"/&gt;
 *         &lt;element name="RateType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}RateCategoryCodeSLN"/&gt;
 *         &lt;element name="IntrstRateType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}InterestRateTypeCodeSLN"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InterestFundStatementDataType", propOrder = {
    "rate",
    "rateType",
    "intrstRateType"
})
public class InterestFundStatementDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Rate")
    protected double rate;
    @XmlElement(name = "RateType", required = true)
    protected String rateType;
    @XmlElement(name = "IntrstRateType", required = true)
    protected String intrstRateType;

    /**
     * Default no-arg constructor
     * 
     */
    public InterestFundStatementDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public InterestFundStatementDataType(final double rate, final String rateType, final String intrstRateType) {
        this.rate = rate;
        this.rateType = rateType;
        this.intrstRateType = intrstRateType;
    }

    /**
     * Gets the value of the rate property.
     * 
     */
    public double getRate() {
        return rate;
    }

    /**
     * Sets the value of the rate property.
     * 
     */
    public void setRate(double value) {
        this.rate = value;
    }

    public boolean isSetRate() {
        return true;
    }

    /**
     * Gets the value of the rateType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRateType() {
        return rateType;
    }

    /**
     * Sets the value of the rateType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRateType(String value) {
        this.rateType = value;
    }

    public boolean isSetRateType() {
        return (this.rateType!= null);
    }

    /**
     * Gets the value of the intrstRateType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntrstRateType() {
        return intrstRateType;
    }

    /**
     * Sets the value of the intrstRateType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntrstRateType(String value) {
        this.intrstRateType = value;
    }

    public boolean isSetIntrstRateType() {
        return (this.intrstRateType!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("rate", rate).add("rateType", rateType).add("intrstRateType", intrstRateType).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(rate, rateType, intrstRateType);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final InterestFundStatementDataType o = ((InterestFundStatementDataType) other);
        return ((Objects.equal(rate, o.rate)&&Objects.equal(rateType, o.rateType))&&Objects.equal(intrstRateType, o.intrstRateType));
    }

}
