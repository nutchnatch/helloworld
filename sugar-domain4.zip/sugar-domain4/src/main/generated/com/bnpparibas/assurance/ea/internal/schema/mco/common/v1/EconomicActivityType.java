
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type of economic activity
 * 
 * <p>Java class for EconomicActivityType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EconomicActivityType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CSPCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CSPCode" minOccurs="0"/&gt;
 *         &lt;element name="OccptnDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EconomicActivityType", propOrder = {
    "cspCode",
    "occptnDesc"
})
public class EconomicActivityType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CSPCode")
    protected String cspCode;
    @XmlElement(name = "OccptnDesc")
    protected String occptnDesc;

    /**
     * Default no-arg constructor
     * 
     */
    public EconomicActivityType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public EconomicActivityType(final String cspCode, final String occptnDesc) {
        this.cspCode = cspCode;
        this.occptnDesc = occptnDesc;
    }

    /**
     * Gets the value of the cspCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCSPCode() {
        return cspCode;
    }

    /**
     * Sets the value of the cspCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCSPCode(String value) {
        this.cspCode = value;
    }

    public boolean isSetCSPCode() {
        return (this.cspCode!= null);
    }

    /**
     * Gets the value of the occptnDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOccptnDesc() {
        return occptnDesc;
    }

    /**
     * Sets the value of the occptnDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOccptnDesc(String value) {
        this.occptnDesc = value;
    }

    public boolean isSetOccptnDesc() {
        return (this.occptnDesc!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("cspCode", cspCode).add("occptnDesc", occptnDesc).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(cspCode, occptnDesc);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final EconomicActivityType o = ((EconomicActivityType) other);
        return (Objects.equal(cspCode, o.cspCode)&&Objects.equal(occptnDesc, o.occptnDesc));
    }

}
