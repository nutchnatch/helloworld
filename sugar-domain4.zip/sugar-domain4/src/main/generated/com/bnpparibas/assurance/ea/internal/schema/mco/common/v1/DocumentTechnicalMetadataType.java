
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Document's technical
 * 				metadata description.
 * 			
 * 
 * <p>Java class for DocumentTechnicalMetadataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DocumentTechnicalMetadataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Nature" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentNatureType" minOccurs="0"/&gt;
 *         &lt;element name="Action" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentTechnicalActionType" minOccurs="0"/&gt;
 *         &lt;element name="Data" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentTechnicalDataType" minOccurs="0"/&gt;
 *         &lt;element name="OthrData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MetadataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DocumentTechnicalMetadataType", propOrder = {
    "nature",
    "action",
    "data",
    "othrData"
})
public class DocumentTechnicalMetadataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Nature")
    protected DocumentNatureType nature;
    @XmlElement(name = "Action")
    protected DocumentTechnicalActionType action;
    @XmlElement(name = "Data")
    protected DocumentTechnicalDataType data;
    @XmlElement(name = "OthrData")
    protected List<MetadataType> othrData;

    /**
     * Default no-arg constructor
     * 
     */
    public DocumentTechnicalMetadataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public DocumentTechnicalMetadataType(final DocumentNatureType nature, final DocumentTechnicalActionType action, final DocumentTechnicalDataType data, final List<MetadataType> othrData) {
        this.nature = nature;
        this.action = action;
        this.data = data;
        this.othrData = othrData;
    }

    /**
     * Gets the value of the nature property.
     * 
     * @return
     *     possible object is
     *     {@link DocumentNatureType }
     *     
     */
    public DocumentNatureType getNature() {
        return nature;
    }

    /**
     * Sets the value of the nature property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentNatureType }
     *     
     */
    public void setNature(DocumentNatureType value) {
        this.nature = value;
    }

    public boolean isSetNature() {
        return (this.nature!= null);
    }

    /**
     * Gets the value of the action property.
     * 
     * @return
     *     possible object is
     *     {@link DocumentTechnicalActionType }
     *     
     */
    public DocumentTechnicalActionType getAction() {
        return action;
    }

    /**
     * Sets the value of the action property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentTechnicalActionType }
     *     
     */
    public void setAction(DocumentTechnicalActionType value) {
        this.action = value;
    }

    public boolean isSetAction() {
        return (this.action!= null);
    }

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     {@link DocumentTechnicalDataType }
     *     
     */
    public DocumentTechnicalDataType getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentTechnicalDataType }
     *     
     */
    public void setData(DocumentTechnicalDataType value) {
        this.data = value;
    }

    public boolean isSetData() {
        return (this.data!= null);
    }

    /**
     * Gets the value of the othrData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the othrData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOthrData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MetadataType }
     * 
     * 
     */
    public List<MetadataType> getOthrData() {
        if (othrData == null) {
            othrData = new ArrayList<MetadataType>();
        }
        return this.othrData;
    }

    public boolean isSetOthrData() {
        return ((this.othrData!= null)&&(!this.othrData.isEmpty()));
    }

    public void unsetOthrData() {
        this.othrData = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("nature", nature).add("action", action).add("data", data).add("othrData", othrData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(nature, action, data, othrData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final DocumentTechnicalMetadataType o = ((DocumentTechnicalMetadataType) other);
        return (((Objects.equal(nature, o.nature)&&Objects.equal(action, o.action))&&Objects.equal(data, o.data))&&Objects.equal(othrData, o.othrData));
    }

}
