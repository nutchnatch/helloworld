
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Context of one particular
 * 				metadata group.
 * 			
 * 
 * <p>Java class for MetadataGroupContextType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MetadataGroupContextType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SeqId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LongNameType" minOccurs="0"/&gt;
 *         &lt;element name="Role" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}RoleCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="DocType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentTypeCode" minOccurs="0"/&gt;
 *         &lt;element name="Objct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="DbObjct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}New_DatabaseObjectCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="OthrDataGrp" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MetadataGroupType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MetadataGroupContextType", propOrder = {
    "seqId",
    "name",
    "role",
    "docType",
    "objct",
    "dbObjct",
    "othrDataGrp"
})
public class MetadataGroupContextType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SeqId")
    protected String seqId;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "Role")
    protected String role;
    @XmlElement(name = "DocType")
    protected String docType;
    @XmlElement(name = "Objct")
    protected String objct;
    @XmlElement(name = "DbObjct")
    protected String dbObjct;
    @XmlElement(name = "OthrDataGrp")
    protected MetadataGroupType othrDataGrp;

    /**
     * Default no-arg constructor
     * 
     */
    public MetadataGroupContextType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MetadataGroupContextType(final String seqId, final String name, final String role, final String docType, final String objct, final String dbObjct, final MetadataGroupType othrDataGrp) {
        this.seqId = seqId;
        this.name = name;
        this.role = role;
        this.docType = docType;
        this.objct = objct;
        this.dbObjct = dbObjct;
        this.othrDataGrp = othrDataGrp;
    }

    /**
     * Gets the value of the seqId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqId() {
        return seqId;
    }

    /**
     * Sets the value of the seqId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqId(String value) {
        this.seqId = value;
    }

    public boolean isSetSeqId() {
        return (this.seqId!= null);
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the role property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRole() {
        return role;
    }

    /**
     * Sets the value of the role property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRole(String value) {
        this.role = value;
    }

    public boolean isSetRole() {
        return (this.role!= null);
    }

    /**
     * Gets the value of the docType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocType() {
        return docType;
    }

    /**
     * Sets the value of the docType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocType(String value) {
        this.docType = value;
    }

    public boolean isSetDocType() {
        return (this.docType!= null);
    }

    /**
     * Gets the value of the objct property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getObjct() {
        return objct;
    }

    /**
     * Sets the value of the objct property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setObjct(String value) {
        this.objct = value;
    }

    public boolean isSetObjct() {
        return (this.objct!= null);
    }

    /**
     * Gets the value of the dbObjct property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbObjct() {
        return dbObjct;
    }

    /**
     * Sets the value of the dbObjct property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbObjct(String value) {
        this.dbObjct = value;
    }

    public boolean isSetDbObjct() {
        return (this.dbObjct!= null);
    }

    /**
     * Gets the value of the othrDataGrp property.
     * 
     * @return
     *     possible object is
     *     {@link MetadataGroupType }
     *     
     */
    public MetadataGroupType getOthrDataGrp() {
        return othrDataGrp;
    }

    /**
     * Sets the value of the othrDataGrp property.
     * 
     * @param value
     *     allowed object is
     *     {@link MetadataGroupType }
     *     
     */
    public void setOthrDataGrp(MetadataGroupType value) {
        this.othrDataGrp = value;
    }

    public boolean isSetOthrDataGrp() {
        return (this.othrDataGrp!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("seqId", seqId).add("name", name).add("role", role).add("docType", docType).add("objct", objct).add("dbObjct", dbObjct).add("othrDataGrp", othrDataGrp).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(seqId, name, role, docType, objct, dbObjct, othrDataGrp);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MetadataGroupContextType o = ((MetadataGroupContextType) other);
        return ((((((Objects.equal(seqId, o.seqId)&&Objects.equal(name, o.name))&&Objects.equal(role, o.role))&&Objects.equal(docType, o.docType))&&Objects.equal(objct, o.objct))&&Objects.equal(dbObjct, o.dbObjct))&&Objects.equal(othrDataGrp, o.othrDataGrp));
    }

}
