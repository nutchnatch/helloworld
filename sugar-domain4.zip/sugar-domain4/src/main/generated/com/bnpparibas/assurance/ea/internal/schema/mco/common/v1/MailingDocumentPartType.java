
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage parts that compose a documentt
 * 			
 * 
 * <p>Java class for MailingDocumentPartType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MailingDocumentPartType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SeqId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType"/&gt;
 *         &lt;element name="Format" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentFormatTypeCodeSLN"/&gt;
 *         &lt;element name="ContentData"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentPartTypeCodeSLN"/&gt;
 *                   &lt;element name="TextContent" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="BnryContent" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/&gt;
 *                   &lt;element name="DocURI" type="{http://www.w3.org/2001/XMLSchema}anyURI" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MailingDocumentPartType", propOrder = {
    "seqId",
    "format",
    "contentData"
})
public class MailingDocumentPartType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SeqId", required = true)
    protected String seqId;
    @XmlElement(name = "Format", required = true)
    protected String format;
    @XmlElement(name = "ContentData", required = true)
    protected MailingDocumentPartType.ContentData contentData;

    /**
     * Default no-arg constructor
     * 
     */
    public MailingDocumentPartType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MailingDocumentPartType(final String seqId, final String format, final MailingDocumentPartType.ContentData contentData) {
        this.seqId = seqId;
        this.format = format;
        this.contentData = contentData;
    }

    /**
     * Gets the value of the seqId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqId() {
        return seqId;
    }

    /**
     * Sets the value of the seqId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqId(String value) {
        this.seqId = value;
    }

    public boolean isSetSeqId() {
        return (this.seqId!= null);
    }

    /**
     * Gets the value of the format property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFormat() {
        return format;
    }

    /**
     * Sets the value of the format property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFormat(String value) {
        this.format = value;
    }

    public boolean isSetFormat() {
        return (this.format!= null);
    }

    /**
     * Gets the value of the contentData property.
     * 
     * @return
     *     possible object is
     *     {@link MailingDocumentPartType.ContentData }
     *     
     */
    public MailingDocumentPartType.ContentData getContentData() {
        return contentData;
    }

    /**
     * Sets the value of the contentData property.
     * 
     * @param value
     *     allowed object is
     *     {@link MailingDocumentPartType.ContentData }
     *     
     */
    public void setContentData(MailingDocumentPartType.ContentData value) {
        this.contentData = value;
    }

    public boolean isSetContentData() {
        return (this.contentData!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("seqId", seqId).add("format", format).add("contentData", contentData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(seqId, format, contentData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MailingDocumentPartType o = ((MailingDocumentPartType) other);
        return ((Objects.equal(seqId, o.seqId)&&Objects.equal(format, o.format))&&Objects.equal(contentData, o.contentData));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DocumentPartTypeCodeSLN"/&gt;
     *         &lt;element name="TextContent" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="BnryContent" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/&gt;
     *         &lt;element name="DocURI" type="{http://www.w3.org/2001/XMLSchema}anyURI" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "type",
        "textContent",
        "bnryContent",
        "docURI"
    })
    public static class ContentData implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Type", required = true)
        protected String type;
        @XmlElement(name = "TextContent")
        protected String textContent;
        @XmlElement(name = "BnryContent")
        protected byte[] bnryContent;
        @XmlElement(name = "DocURI")
        @XmlSchemaType(name = "anyURI")
        protected String docURI;

        /**
         * Default no-arg constructor
         * 
         */
        public ContentData() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public ContentData(final String type, final String textContent, final byte[] bnryContent, final String docURI) {
            this.type = type;
            this.textContent = textContent;
            this.bnryContent = bnryContent;
            this.docURI = docURI;
        }

        /**
         * Gets the value of the type property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getType() {
            return type;
        }

        /**
         * Sets the value of the type property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setType(String value) {
            this.type = value;
        }

        public boolean isSetType() {
            return (this.type!= null);
        }

        /**
         * Gets the value of the textContent property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTextContent() {
            return textContent;
        }

        /**
         * Sets the value of the textContent property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTextContent(String value) {
            this.textContent = value;
        }

        public boolean isSetTextContent() {
            return (this.textContent!= null);
        }

        /**
         * Gets the value of the bnryContent property.
         * 
         * @return
         *     possible object is
         *     byte[]
         */
        public byte[] getBnryContent() {
            return bnryContent;
        }

        /**
         * Sets the value of the bnryContent property.
         * 
         * @param value
         *     allowed object is
         *     byte[]
         */
        public void setBnryContent(byte[] value) {
            this.bnryContent = value;
        }

        public boolean isSetBnryContent() {
            return (this.bnryContent!= null);
        }

        /**
         * Gets the value of the docURI property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDocURI() {
            return docURI;
        }

        /**
         * Sets the value of the docURI property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDocURI(String value) {
            this.docURI = value;
        }

        public boolean isSetDocURI() {
            return (this.docURI!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("type", type).add("textContent", textContent).add("bnryContent", bnryContent).add("docURI", docURI).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(type, textContent, bnryContent, docURI);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final MailingDocumentPartType.ContentData o = ((MailingDocumentPartType.ContentData) other);
            return (((Objects.equal(type, o.type)&&Objects.equal(textContent, o.textContent))&&Objects.equal(bnryContent, o.bnryContent))&&Objects.equal(docURI, o.docURI));
        }

    }

}
