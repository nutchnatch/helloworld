
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import com.google.common.base.Objects;


/**
 * Taux complété de sa base
 * 				de calcul et du type de solde sur lequel il est appliqué.
 * 			
 * 
 * <p>Java class for ExtendedRateType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ExtendedRateType"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1&gt;DecimalNumberType"&gt;
 *       &lt;attribute name="RateBasis" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" /&gt;
 *       &lt;attribute name="BalnceAmntType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BalanceTypeCode" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ExtendedRateType", propOrder = {
    "value"
})
public class ExtendedRateType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlValue
    protected double value;
    @XmlAttribute(name = "RateBasis")
    protected BigInteger rateBasis;
    @XmlAttribute(name = "BalnceAmntType")
    protected String balnceAmntType;

    /**
     * Default no-arg constructor
     * 
     */
    public ExtendedRateType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ExtendedRateType(final double value, final BigInteger rateBasis, final String balnceAmntType) {
        this.value = value;
        this.rateBasis = rateBasis;
        this.balnceAmntType = balnceAmntType;
    }

    /**
     * To define the format of decimal numbers
     * 			
     * 
     */
    public double getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     */
    public void setValue(double value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return true;
    }

    /**
     * Gets the value of the rateBasis property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getRateBasis() {
        return rateBasis;
    }

    /**
     * Sets the value of the rateBasis property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setRateBasis(BigInteger value) {
        this.rateBasis = value;
    }

    public boolean isSetRateBasis() {
        return (this.rateBasis!= null);
    }

    /**
     * Gets the value of the balnceAmntType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBalnceAmntType() {
        return balnceAmntType;
    }

    /**
     * Sets the value of the balnceAmntType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBalnceAmntType(String value) {
        this.balnceAmntType = value;
    }

    public boolean isSetBalnceAmntType() {
        return (this.balnceAmntType!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("value", value).add("rateBasis", rateBasis).add("balnceAmntType", balnceAmntType).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(value, rateBasis, balnceAmntType);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ExtendedRateType o = ((ExtendedRateType) other);
        return ((Objects.equal(value, o.value)&&Objects.equal(rateBasis, o.rateBasis))&&Objects.equal(balnceAmntType, o.balnceAmntType));
    }

}
