
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import com.google.common.base.Objects;


/**
 * Basic bloc of Indentification of object with
 * 				version (product, agreement, etc)
 * 			
 * 
 * <p>Java class for IdentificationtWithVersionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="IdentificationtWithVersionType"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1&gt;IdentifierType"&gt;
 *       &lt;attribute name="Issuer" use="required" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IssuerCodeSLN" /&gt;
 *       &lt;attribute name="Scheme" use="required" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SchemeCodeSLN" /&gt;
 *       &lt;attribute name="VersId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentificationtWithVersionType", propOrder = {
    "value"
})
public class IdentificationtWithVersionType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlValue
    protected String value;
    @XmlAttribute(name = "Issuer", required = true)
    protected String issuer;
    @XmlAttribute(name = "Scheme", required = true)
    protected String scheme;
    @XmlAttribute(name = "VersId")
    protected String versId;

    /**
     * Default no-arg constructor
     * 
     */
    public IdentificationtWithVersionType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public IdentificationtWithVersionType(final String value, final String issuer, final String scheme, final String versId) {
        this.value = value;
        this.issuer = issuer;
        this.scheme = scheme;
        this.versId = versId;
    }

    /**
     * Any simple identifier
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValue(String value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return (this.value!= null);
    }

    /**
     * Gets the value of the issuer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssuer() {
        return issuer;
    }

    /**
     * Sets the value of the issuer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssuer(String value) {
        this.issuer = value;
    }

    public boolean isSetIssuer() {
        return (this.issuer!= null);
    }

    /**
     * Gets the value of the scheme property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScheme() {
        return scheme;
    }

    /**
     * Sets the value of the scheme property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScheme(String value) {
        this.scheme = value;
    }

    public boolean isSetScheme() {
        return (this.scheme!= null);
    }

    /**
     * Gets the value of the versId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersId() {
        return versId;
    }

    /**
     * Sets the value of the versId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersId(String value) {
        this.versId = value;
    }

    public boolean isSetVersId() {
        return (this.versId!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("value", value).add("issuer", issuer).add("scheme", scheme).add("versId", versId).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(value, issuer, scheme, versId);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final IdentificationtWithVersionType o = ((IdentificationtWithVersionType) other);
        return (((Objects.equal(value, o.value)&&Objects.equal(issuer, o.issuer))&&Objects.equal(scheme, o.scheme))&&Objects.equal(versId, o.versId));
    }

}
