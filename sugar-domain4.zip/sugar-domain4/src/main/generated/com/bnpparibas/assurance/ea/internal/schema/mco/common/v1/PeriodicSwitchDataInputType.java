
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on regular switch
 * 			
 * 
 * <p>Java class for PeriodicSwitchDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PeriodicSwitchDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OpeSchedlrIdntcn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="SchedlrData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SwitchSchedulerDataInputType" minOccurs="0"/&gt;
 *         &lt;element name="SwitchDistrbtn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodicSwitchFundDistributionInputType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PeriodicSwitchDataInputType", propOrder = {
    "opeSchedlrIdntcn",
    "schedlrData",
    "switchDistrbtn"
})
public class PeriodicSwitchDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "OpeSchedlrIdntcn")
    protected ObjectIdentificationType opeSchedlrIdntcn;
    @XmlElement(name = "SchedlrData")
    protected SwitchSchedulerDataInputType schedlrData;
    @XmlElement(name = "SwitchDistrbtn")
    protected List<PeriodicSwitchFundDistributionInputType> switchDistrbtn;

    /**
     * Default no-arg constructor
     * 
     */
    public PeriodicSwitchDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PeriodicSwitchDataInputType(final ObjectIdentificationType opeSchedlrIdntcn, final SwitchSchedulerDataInputType schedlrData, final List<PeriodicSwitchFundDistributionInputType> switchDistrbtn) {
        this.opeSchedlrIdntcn = opeSchedlrIdntcn;
        this.schedlrData = schedlrData;
        this.switchDistrbtn = switchDistrbtn;
    }

    /**
     * Gets the value of the opeSchedlrIdntcn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getOpeSchedlrIdntcn() {
        return opeSchedlrIdntcn;
    }

    /**
     * Sets the value of the opeSchedlrIdntcn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setOpeSchedlrIdntcn(ObjectIdentificationType value) {
        this.opeSchedlrIdntcn = value;
    }

    public boolean isSetOpeSchedlrIdntcn() {
        return (this.opeSchedlrIdntcn!= null);
    }

    /**
     * Gets the value of the schedlrData property.
     * 
     * @return
     *     possible object is
     *     {@link SwitchSchedulerDataInputType }
     *     
     */
    public SwitchSchedulerDataInputType getSchedlrData() {
        return schedlrData;
    }

    /**
     * Sets the value of the schedlrData property.
     * 
     * @param value
     *     allowed object is
     *     {@link SwitchSchedulerDataInputType }
     *     
     */
    public void setSchedlrData(SwitchSchedulerDataInputType value) {
        this.schedlrData = value;
    }

    public boolean isSetSchedlrData() {
        return (this.schedlrData!= null);
    }

    /**
     * Gets the value of the switchDistrbtn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the switchDistrbtn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSwitchDistrbtn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PeriodicSwitchFundDistributionInputType }
     * 
     * 
     */
    public List<PeriodicSwitchFundDistributionInputType> getSwitchDistrbtn() {
        if (switchDistrbtn == null) {
            switchDistrbtn = new ArrayList<PeriodicSwitchFundDistributionInputType>();
        }
        return this.switchDistrbtn;
    }

    public boolean isSetSwitchDistrbtn() {
        return ((this.switchDistrbtn!= null)&&(!this.switchDistrbtn.isEmpty()));
    }

    public void unsetSwitchDistrbtn() {
        this.switchDistrbtn = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("opeSchedlrIdntcn", opeSchedlrIdntcn).add("schedlrData", schedlrData).add("switchDistrbtn", switchDistrbtn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(opeSchedlrIdntcn, schedlrData, switchDistrbtn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PeriodicSwitchDataInputType o = ((PeriodicSwitchDataInputType) other);
        return ((Objects.equal(opeSchedlrIdntcn, o.opeSchedlrIdntcn)&&Objects.equal(schedlrData, o.schedlrData))&&Objects.equal(switchDistrbtn, o.switchDistrbtn));
    }

}
