
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on regular savings
 * 				premium and regular savings withdrawal
 * 			
 * 
 * <p>Java class for PeriodicSavingsOperationDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PeriodicSavingsOperationDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OpeSchedlrIdntcn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="SchedlrStatus" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodicOperationSchedulerStatusDataType" minOccurs="0"/&gt;
 *         &lt;element name="PaymntRef" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PaymentMethodWithPayerType" minOccurs="0"/&gt;
 *         &lt;element name="SchedlrData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodicSavingsSchedulerDataType"/&gt;
 *         &lt;element name="SpecifSchedlrData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SpecifPeriodicSavingsSchedulerDataType" minOccurs="0"/&gt;
 *         &lt;element name="Fee" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SavingsFeeType" minOccurs="0"/&gt;
 *         &lt;element name="FundDistrbtn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SavingsOperationFundDistributionType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PeriodicSavingsOperationDataType", propOrder = {
    "opeSchedlrIdntcn",
    "schedlrStatus",
    "paymntRef",
    "schedlrData",
    "specifSchedlrData",
    "fee",
    "fundDistrbtn"
})
public class PeriodicSavingsOperationDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "OpeSchedlrIdntcn")
    protected ObjectIdentificationType opeSchedlrIdntcn;
    @XmlElement(name = "SchedlrStatus")
    protected PeriodicOperationSchedulerStatusDataType schedlrStatus;
    @XmlElement(name = "PaymntRef")
    protected PaymentMethodWithPayerType paymntRef;
    @XmlElement(name = "SchedlrData", required = true)
    protected PeriodicSavingsSchedulerDataType schedlrData;
    @XmlElement(name = "SpecifSchedlrData")
    protected SpecifPeriodicSavingsSchedulerDataType specifSchedlrData;
    @XmlElement(name = "Fee")
    protected SavingsFeeType fee;
    @XmlElement(name = "FundDistrbtn")
    protected List<SavingsOperationFundDistributionType> fundDistrbtn;

    /**
     * Default no-arg constructor
     * 
     */
    public PeriodicSavingsOperationDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PeriodicSavingsOperationDataType(final ObjectIdentificationType opeSchedlrIdntcn, final PeriodicOperationSchedulerStatusDataType schedlrStatus, final PaymentMethodWithPayerType paymntRef, final PeriodicSavingsSchedulerDataType schedlrData, final SpecifPeriodicSavingsSchedulerDataType specifSchedlrData, final SavingsFeeType fee, final List<SavingsOperationFundDistributionType> fundDistrbtn) {
        this.opeSchedlrIdntcn = opeSchedlrIdntcn;
        this.schedlrStatus = schedlrStatus;
        this.paymntRef = paymntRef;
        this.schedlrData = schedlrData;
        this.specifSchedlrData = specifSchedlrData;
        this.fee = fee;
        this.fundDistrbtn = fundDistrbtn;
    }

    /**
     * Gets the value of the opeSchedlrIdntcn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getOpeSchedlrIdntcn() {
        return opeSchedlrIdntcn;
    }

    /**
     * Sets the value of the opeSchedlrIdntcn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setOpeSchedlrIdntcn(ObjectIdentificationType value) {
        this.opeSchedlrIdntcn = value;
    }

    public boolean isSetOpeSchedlrIdntcn() {
        return (this.opeSchedlrIdntcn!= null);
    }

    /**
     * Gets the value of the schedlrStatus property.
     * 
     * @return
     *     possible object is
     *     {@link PeriodicOperationSchedulerStatusDataType }
     *     
     */
    public PeriodicOperationSchedulerStatusDataType getSchedlrStatus() {
        return schedlrStatus;
    }

    /**
     * Sets the value of the schedlrStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link PeriodicOperationSchedulerStatusDataType }
     *     
     */
    public void setSchedlrStatus(PeriodicOperationSchedulerStatusDataType value) {
        this.schedlrStatus = value;
    }

    public boolean isSetSchedlrStatus() {
        return (this.schedlrStatus!= null);
    }

    /**
     * Gets the value of the paymntRef property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentMethodWithPayerType }
     *     
     */
    public PaymentMethodWithPayerType getPaymntRef() {
        return paymntRef;
    }

    /**
     * Sets the value of the paymntRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentMethodWithPayerType }
     *     
     */
    public void setPaymntRef(PaymentMethodWithPayerType value) {
        this.paymntRef = value;
    }

    public boolean isSetPaymntRef() {
        return (this.paymntRef!= null);
    }

    /**
     * Gets the value of the schedlrData property.
     * 
     * @return
     *     possible object is
     *     {@link PeriodicSavingsSchedulerDataType }
     *     
     */
    public PeriodicSavingsSchedulerDataType getSchedlrData() {
        return schedlrData;
    }

    /**
     * Sets the value of the schedlrData property.
     * 
     * @param value
     *     allowed object is
     *     {@link PeriodicSavingsSchedulerDataType }
     *     
     */
    public void setSchedlrData(PeriodicSavingsSchedulerDataType value) {
        this.schedlrData = value;
    }

    public boolean isSetSchedlrData() {
        return (this.schedlrData!= null);
    }

    /**
     * Gets the value of the specifSchedlrData property.
     * 
     * @return
     *     possible object is
     *     {@link SpecifPeriodicSavingsSchedulerDataType }
     *     
     */
    public SpecifPeriodicSavingsSchedulerDataType getSpecifSchedlrData() {
        return specifSchedlrData;
    }

    /**
     * Sets the value of the specifSchedlrData property.
     * 
     * @param value
     *     allowed object is
     *     {@link SpecifPeriodicSavingsSchedulerDataType }
     *     
     */
    public void setSpecifSchedlrData(SpecifPeriodicSavingsSchedulerDataType value) {
        this.specifSchedlrData = value;
    }

    public boolean isSetSpecifSchedlrData() {
        return (this.specifSchedlrData!= null);
    }

    /**
     * Gets the value of the fee property.
     * 
     * @return
     *     possible object is
     *     {@link SavingsFeeType }
     *     
     */
    public SavingsFeeType getFee() {
        return fee;
    }

    /**
     * Sets the value of the fee property.
     * 
     * @param value
     *     allowed object is
     *     {@link SavingsFeeType }
     *     
     */
    public void setFee(SavingsFeeType value) {
        this.fee = value;
    }

    public boolean isSetFee() {
        return (this.fee!= null);
    }

    /**
     * Gets the value of the fundDistrbtn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fundDistrbtn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFundDistrbtn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SavingsOperationFundDistributionType }
     * 
     * 
     */
    public List<SavingsOperationFundDistributionType> getFundDistrbtn() {
        if (fundDistrbtn == null) {
            fundDistrbtn = new ArrayList<SavingsOperationFundDistributionType>();
        }
        return this.fundDistrbtn;
    }

    public boolean isSetFundDistrbtn() {
        return ((this.fundDistrbtn!= null)&&(!this.fundDistrbtn.isEmpty()));
    }

    public void unsetFundDistrbtn() {
        this.fundDistrbtn = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("opeSchedlrIdntcn", opeSchedlrIdntcn).add("schedlrStatus", schedlrStatus).add("paymntRef", paymntRef).add("schedlrData", schedlrData).add("specifSchedlrData", specifSchedlrData).add("fee", fee).add("fundDistrbtn", fundDistrbtn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(opeSchedlrIdntcn, schedlrStatus, paymntRef, schedlrData, specifSchedlrData, fee, fundDistrbtn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PeriodicSavingsOperationDataType o = ((PeriodicSavingsOperationDataType) other);
        return ((((((Objects.equal(opeSchedlrIdntcn, o.opeSchedlrIdntcn)&&Objects.equal(schedlrStatus, o.schedlrStatus))&&Objects.equal(paymntRef, o.paymntRef))&&Objects.equal(schedlrData, o.schedlrData))&&Objects.equal(specifSchedlrData, o.specifSchedlrData))&&Objects.equal(fee, o.fee))&&Objects.equal(fundDistrbtn, o.fundDistrbtn));
    }

}
