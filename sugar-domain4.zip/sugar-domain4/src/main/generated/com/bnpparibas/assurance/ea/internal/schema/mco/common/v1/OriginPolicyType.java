
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * The origin policy in case of a transfer from an
 * 				original policy to a new policy
 * 			
 * 
 * <p>Java class for OriginPolicyType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OriginPolicyType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PolIdntcn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="EffctveDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *         &lt;element name="LegalSchme" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LegalSchemeCodeSLN"/&gt;
 *         &lt;element name="PolCurr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="TransfType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PolicyTransferTypeCodeSLN"/&gt;
 *         &lt;element name="PdctType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SavingProductTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="TransfAmnt" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="AmntType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountType" minOccurs="0"/&gt;
 *                   &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="PrtyRole" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="FreeDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OriginPolicyType", propOrder = {
    "polIdntcn",
    "effctveDate",
    "legalSchme",
    "polCurr",
    "transfType",
    "pdctType",
    "transfAmnt",
    "prtyRole",
    "freeDesc"
})
public class OriginPolicyType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PolIdntcn", required = true)
    protected ObjectIdentificationType polIdntcn;
    @XmlElement(name = "EffctveDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date effctveDate;
    @XmlElement(name = "LegalSchme", required = true)
    protected String legalSchme;
    @XmlElement(name = "PolCurr")
    protected String polCurr;
    @XmlElement(name = "TransfType", required = true)
    protected String transfType;
    @XmlElement(name = "PdctType")
    protected String pdctType;
    @XmlElement(name = "TransfAmnt")
    protected List<OriginPolicyType.TransfAmnt> transfAmnt;
    @XmlElement(name = "PrtyRole")
    protected List<PartyRoleType> prtyRole;
    @XmlElement(name = "FreeDesc")
    protected String freeDesc;

    /**
     * Default no-arg constructor
     * 
     */
    public OriginPolicyType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public OriginPolicyType(final ObjectIdentificationType polIdntcn, final Date effctveDate, final String legalSchme, final String polCurr, final String transfType, final String pdctType, final List<OriginPolicyType.TransfAmnt> transfAmnt, final List<PartyRoleType> prtyRole, final String freeDesc) {
        this.polIdntcn = polIdntcn;
        this.effctveDate = effctveDate;
        this.legalSchme = legalSchme;
        this.polCurr = polCurr;
        this.transfType = transfType;
        this.pdctType = pdctType;
        this.transfAmnt = transfAmnt;
        this.prtyRole = prtyRole;
        this.freeDesc = freeDesc;
    }

    /**
     * Gets the value of the polIdntcn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPolIdntcn() {
        return polIdntcn;
    }

    /**
     * Sets the value of the polIdntcn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPolIdntcn(ObjectIdentificationType value) {
        this.polIdntcn = value;
    }

    public boolean isSetPolIdntcn() {
        return (this.polIdntcn!= null);
    }

    /**
     * Gets the value of the effctveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getEffctveDate() {
        return effctveDate;
    }

    /**
     * Sets the value of the effctveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEffctveDate(Date value) {
        this.effctveDate = value;
    }

    public boolean isSetEffctveDate() {
        return (this.effctveDate!= null);
    }

    /**
     * Gets the value of the legalSchme property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLegalSchme() {
        return legalSchme;
    }

    /**
     * Sets the value of the legalSchme property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLegalSchme(String value) {
        this.legalSchme = value;
    }

    public boolean isSetLegalSchme() {
        return (this.legalSchme!= null);
    }

    /**
     * Gets the value of the polCurr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPolCurr() {
        return polCurr;
    }

    /**
     * Sets the value of the polCurr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPolCurr(String value) {
        this.polCurr = value;
    }

    public boolean isSetPolCurr() {
        return (this.polCurr!= null);
    }

    /**
     * Gets the value of the transfType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransfType() {
        return transfType;
    }

    /**
     * Sets the value of the transfType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransfType(String value) {
        this.transfType = value;
    }

    public boolean isSetTransfType() {
        return (this.transfType!= null);
    }

    /**
     * Gets the value of the pdctType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPdctType() {
        return pdctType;
    }

    /**
     * Sets the value of the pdctType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPdctType(String value) {
        this.pdctType = value;
    }

    public boolean isSetPdctType() {
        return (this.pdctType!= null);
    }

    /**
     * Gets the value of the transfAmnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the transfAmnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTransfAmnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OriginPolicyType.TransfAmnt }
     * 
     * 
     */
    public List<OriginPolicyType.TransfAmnt> getTransfAmnt() {
        if (transfAmnt == null) {
            transfAmnt = new ArrayList<OriginPolicyType.TransfAmnt>();
        }
        return this.transfAmnt;
    }

    public boolean isSetTransfAmnt() {
        return ((this.transfAmnt!= null)&&(!this.transfAmnt.isEmpty()));
    }

    public void unsetTransfAmnt() {
        this.transfAmnt = null;
    }

    /**
     * Gets the value of the prtyRole property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the prtyRole property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPrtyRole().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartyRoleType }
     * 
     * 
     */
    public List<PartyRoleType> getPrtyRole() {
        if (prtyRole == null) {
            prtyRole = new ArrayList<PartyRoleType>();
        }
        return this.prtyRole;
    }

    public boolean isSetPrtyRole() {
        return ((this.prtyRole!= null)&&(!this.prtyRole.isEmpty()));
    }

    public void unsetPrtyRole() {
        this.prtyRole = null;
    }

    /**
     * Gets the value of the freeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFreeDesc() {
        return freeDesc;
    }

    /**
     * Sets the value of the freeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFreeDesc(String value) {
        this.freeDesc = value;
    }

    public boolean isSetFreeDesc() {
        return (this.freeDesc!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("polIdntcn", polIdntcn).add("effctveDate", effctveDate).add("legalSchme", legalSchme).add("polCurr", polCurr).add("transfType", transfType).add("pdctType", pdctType).add("transfAmnt", transfAmnt).add("prtyRole", prtyRole).add("freeDesc", freeDesc).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(polIdntcn, effctveDate, legalSchme, polCurr, transfType, pdctType, transfAmnt, prtyRole, freeDesc);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final OriginPolicyType o = ((OriginPolicyType) other);
        return ((((((((Objects.equal(polIdntcn, o.polIdntcn)&&Objects.equal(effctveDate, o.effctveDate))&&Objects.equal(legalSchme, o.legalSchme))&&Objects.equal(polCurr, o.polCurr))&&Objects.equal(transfType, o.transfType))&&Objects.equal(pdctType, o.pdctType))&&Objects.equal(transfAmnt, o.transfAmnt))&&Objects.equal(prtyRole, o.prtyRole))&&Objects.equal(freeDesc, o.freeDesc));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="AmntType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountType" minOccurs="0"/&gt;
     *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "amntType",
        "amnt"
    })
    public static class TransfAmnt implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "AmntType")
        protected Double amntType;
        @XmlElement(name = "Amnt", required = true)
        protected CurrencyAndAmountType amnt;

        /**
         * Default no-arg constructor
         * 
         */
        public TransfAmnt() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public TransfAmnt(final Double amntType, final CurrencyAndAmountType amnt) {
            this.amntType = amntType;
            this.amnt = amnt;
        }

        /**
         * Gets the value of the amntType property.
         * 
         * @return
         *     possible object is
         *     {@link Double }
         *     
         */
        public Double getAmntType() {
            return amntType;
        }

        /**
         * Sets the value of the amntType property.
         * 
         * @param value
         *     allowed object is
         *     {@link Double }
         *     
         */
        public void setAmntType(Double value) {
            this.amntType = value;
        }

        public boolean isSetAmntType() {
            return (this.amntType!= null);
        }

        /**
         * Gets the value of the amnt property.
         * 
         * @return
         *     possible object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public CurrencyAndAmountType getAmnt() {
            return amnt;
        }

        /**
         * Sets the value of the amnt property.
         * 
         * @param value
         *     allowed object is
         *     {@link CurrencyAndAmountType }
         *     
         */
        public void setAmnt(CurrencyAndAmountType value) {
            this.amnt = value;
        }

        public boolean isSetAmnt() {
            return (this.amnt!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("amntType", amntType).add("amnt", amnt).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(amntType, amnt);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final OriginPolicyType.TransfAmnt o = ((OriginPolicyType.TransfAmnt) other);
            return (Objects.equal(amntType, o.amntType)&&Objects.equal(amnt, o.amnt));
        }

    }

}
