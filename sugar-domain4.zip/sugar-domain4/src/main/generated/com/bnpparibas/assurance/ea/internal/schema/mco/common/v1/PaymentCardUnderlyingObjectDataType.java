
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * It is the underlying card in the case of payment
 * 				instrument protection or revolving loan
 * 			
 * 
 * <p>Java class for PaymentCardUnderlyingObjectDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PaymentCardUnderlyingObjectDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Numb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PaymentCardType"/&gt;
 *         &lt;element name="ExpiryDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="HoldrName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="IssuerName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CardTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="MaxOutstdngBalnce" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PaymentCardUnderlyingObjectDataType", propOrder = {
    "numb",
    "expiryDate",
    "holdrName",
    "issuerName",
    "type",
    "maxOutstdngBalnce"
})
public class PaymentCardUnderlyingObjectDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Numb", required = true)
    protected String numb;
    @XmlElement(name = "ExpiryDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date expiryDate;
    @XmlElement(name = "HoldrName")
    protected String holdrName;
    @XmlElement(name = "IssuerName")
    protected String issuerName;
    @XmlElement(name = "Type")
    protected String type;
    @XmlElement(name = "MaxOutstdngBalnce")
    protected CurrencyAndAmountType maxOutstdngBalnce;

    /**
     * Default no-arg constructor
     * 
     */
    public PaymentCardUnderlyingObjectDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PaymentCardUnderlyingObjectDataType(final String numb, final Date expiryDate, final String holdrName, final String issuerName, final String type, final CurrencyAndAmountType maxOutstdngBalnce) {
        this.numb = numb;
        this.expiryDate = expiryDate;
        this.holdrName = holdrName;
        this.issuerName = issuerName;
        this.type = type;
        this.maxOutstdngBalnce = maxOutstdngBalnce;
    }

    /**
     * Gets the value of the numb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumb() {
        return numb;
    }

    /**
     * Sets the value of the numb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumb(String value) {
        this.numb = value;
    }

    public boolean isSetNumb() {
        return (this.numb!= null);
    }

    /**
     * Gets the value of the expiryDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getExpiryDate() {
        return expiryDate;
    }

    /**
     * Sets the value of the expiryDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExpiryDate(Date value) {
        this.expiryDate = value;
    }

    public boolean isSetExpiryDate() {
        return (this.expiryDate!= null);
    }

    /**
     * Gets the value of the holdrName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHoldrName() {
        return holdrName;
    }

    /**
     * Sets the value of the holdrName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHoldrName(String value) {
        this.holdrName = value;
    }

    public boolean isSetHoldrName() {
        return (this.holdrName!= null);
    }

    /**
     * Gets the value of the issuerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssuerName() {
        return issuerName;
    }

    /**
     * Sets the value of the issuerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssuerName(String value) {
        this.issuerName = value;
    }

    public boolean isSetIssuerName() {
        return (this.issuerName!= null);
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the maxOutstdngBalnce property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getMaxOutstdngBalnce() {
        return maxOutstdngBalnce;
    }

    /**
     * Sets the value of the maxOutstdngBalnce property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setMaxOutstdngBalnce(CurrencyAndAmountType value) {
        this.maxOutstdngBalnce = value;
    }

    public boolean isSetMaxOutstdngBalnce() {
        return (this.maxOutstdngBalnce!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("numb", numb).add("expiryDate", expiryDate).add("holdrName", holdrName).add("issuerName", issuerName).add("type", type).add("maxOutstdngBalnce", maxOutstdngBalnce).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(numb, expiryDate, holdrName, issuerName, type, maxOutstdngBalnce);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PaymentCardUnderlyingObjectDataType o = ((PaymentCardUnderlyingObjectDataType) other);
        return (((((Objects.equal(numb, o.numb)&&Objects.equal(expiryDate, o.expiryDate))&&Objects.equal(holdrName, o.holdrName))&&Objects.equal(issuerName, o.issuerName))&&Objects.equal(type, o.type))&&Objects.equal(maxOutstdngBalnce, o.maxOutstdngBalnce));
    }

}
