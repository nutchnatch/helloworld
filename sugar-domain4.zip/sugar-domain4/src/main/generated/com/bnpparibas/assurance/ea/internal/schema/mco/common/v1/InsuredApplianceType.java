
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * TO NOT BE USED.Type to manage data on the insured
 * 				appliance
 * 			
 * 
 * <p>Java class for InsuredApplianceType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InsuredApplianceType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Id" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}InsuredObjectTypeCodeSLN"/&gt;
 *         &lt;element name="BrndCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BrandCodeSLN"/&gt;
 *         &lt;element name="PurchsngDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *         &lt;element name="Price" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *         &lt;element name="WarntyEndDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InsuredApplianceType", propOrder = {
    "id",
    "type",
    "brndCode",
    "purchsngDate",
    "price",
    "warntyEndDate"
})
public class InsuredApplianceType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Id")
    protected String id;
    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "BrndCode", required = true)
    protected String brndCode;
    @XmlElement(name = "PurchsngDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date purchsngDate;
    @XmlElement(name = "Price", required = true)
    protected CurrencyAndAmountType price;
    @XmlElement(name = "WarntyEndDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date warntyEndDate;

    /**
     * Default no-arg constructor
     * 
     */
    public InsuredApplianceType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public InsuredApplianceType(final String id, final String type, final String brndCode, final Date purchsngDate, final CurrencyAndAmountType price, final Date warntyEndDate) {
        this.id = id;
        this.type = type;
        this.brndCode = brndCode;
        this.purchsngDate = purchsngDate;
        this.price = price;
        this.warntyEndDate = warntyEndDate;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    public boolean isSetId() {
        return (this.id!= null);
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the brndCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBrndCode() {
        return brndCode;
    }

    /**
     * Sets the value of the brndCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBrndCode(String value) {
        this.brndCode = value;
    }

    public boolean isSetBrndCode() {
        return (this.brndCode!= null);
    }

    /**
     * Gets the value of the purchsngDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getPurchsngDate() {
        return purchsngDate;
    }

    /**
     * Sets the value of the purchsngDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPurchsngDate(Date value) {
        this.purchsngDate = value;
    }

    public boolean isSetPurchsngDate() {
        return (this.purchsngDate!= null);
    }

    /**
     * Gets the value of the price property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getPrice() {
        return price;
    }

    /**
     * Sets the value of the price property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setPrice(CurrencyAndAmountType value) {
        this.price = value;
    }

    public boolean isSetPrice() {
        return (this.price!= null);
    }

    /**
     * Gets the value of the warntyEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getWarntyEndDate() {
        return warntyEndDate;
    }

    /**
     * Sets the value of the warntyEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWarntyEndDate(Date value) {
        this.warntyEndDate = value;
    }

    public boolean isSetWarntyEndDate() {
        return (this.warntyEndDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("id", id).add("type", type).add("brndCode", brndCode).add("purchsngDate", purchsngDate).add("price", price).add("warntyEndDate", warntyEndDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id, type, brndCode, purchsngDate, price, warntyEndDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final InsuredApplianceType o = ((InsuredApplianceType) other);
        return (((((Objects.equal(id, o.id)&&Objects.equal(type, o.type))&&Objects.equal(brndCode, o.brndCode))&&Objects.equal(purchsngDate, o.purchsngDate))&&Objects.equal(price, o.price))&&Objects.equal(warntyEndDate, o.warntyEndDate));
    }

}
