
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data for fund statement
 * 			
 * 
 * <p>Java class for FundStatementType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FundStatementType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FinanclFundIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ExtendedFinancialFundIdentificationType"/&gt;
 *         &lt;element name="PdctProfIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="Statmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FundStatementDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Status" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FundStatementPerStatusDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FundStatementType", propOrder = {
    "financlFundIdntfctn",
    "pdctProfIdntfctn",
    "statmnt",
    "status"
})
public class FundStatementType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "FinanclFundIdntfctn", required = true)
    protected ExtendedFinancialFundIdentificationType financlFundIdntfctn;
    @XmlElement(name = "PdctProfIdntfctn")
    protected ObjectIdentificationType pdctProfIdntfctn;
    @XmlElement(name = "Statmnt")
    protected List<FundStatementDataType> statmnt;
    @XmlElement(name = "Status")
    protected List<FundStatementPerStatusDataType> status;

    /**
     * Default no-arg constructor
     * 
     */
    public FundStatementType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FundStatementType(final ExtendedFinancialFundIdentificationType financlFundIdntfctn, final ObjectIdentificationType pdctProfIdntfctn, final List<FundStatementDataType> statmnt, final List<FundStatementPerStatusDataType> status) {
        this.financlFundIdntfctn = financlFundIdntfctn;
        this.pdctProfIdntfctn = pdctProfIdntfctn;
        this.statmnt = statmnt;
        this.status = status;
    }

    /**
     * Gets the value of the financlFundIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ExtendedFinancialFundIdentificationType }
     *     
     */
    public ExtendedFinancialFundIdentificationType getFinanclFundIdntfctn() {
        return financlFundIdntfctn;
    }

    /**
     * Sets the value of the financlFundIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExtendedFinancialFundIdentificationType }
     *     
     */
    public void setFinanclFundIdntfctn(ExtendedFinancialFundIdentificationType value) {
        this.financlFundIdntfctn = value;
    }

    public boolean isSetFinanclFundIdntfctn() {
        return (this.financlFundIdntfctn!= null);
    }

    /**
     * Gets the value of the pdctProfIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPdctProfIdntfctn() {
        return pdctProfIdntfctn;
    }

    /**
     * Sets the value of the pdctProfIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPdctProfIdntfctn(ObjectIdentificationType value) {
        this.pdctProfIdntfctn = value;
    }

    public boolean isSetPdctProfIdntfctn() {
        return (this.pdctProfIdntfctn!= null);
    }

    /**
     * Gets the value of the statmnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the statmnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStatmnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FundStatementDataType }
     * 
     * 
     */
    public List<FundStatementDataType> getStatmnt() {
        if (statmnt == null) {
            statmnt = new ArrayList<FundStatementDataType>();
        }
        return this.statmnt;
    }

    public boolean isSetStatmnt() {
        return ((this.statmnt!= null)&&(!this.statmnt.isEmpty()));
    }

    public void unsetStatmnt() {
        this.statmnt = null;
    }

    /**
     * Gets the value of the status property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the status property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStatus().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FundStatementPerStatusDataType }
     * 
     * 
     */
    public List<FundStatementPerStatusDataType> getStatus() {
        if (status == null) {
            status = new ArrayList<FundStatementPerStatusDataType>();
        }
        return this.status;
    }

    public boolean isSetStatus() {
        return ((this.status!= null)&&(!this.status.isEmpty()));
    }

    public void unsetStatus() {
        this.status = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("financlFundIdntfctn", financlFundIdntfctn).add("pdctProfIdntfctn", pdctProfIdntfctn).add("statmnt", statmnt).add("status", status).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(financlFundIdntfctn, pdctProfIdntfctn, statmnt, status);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FundStatementType o = ((FundStatementType) other);
        return (((Objects.equal(financlFundIdntfctn, o.financlFundIdntfctn)&&Objects.equal(pdctProfIdntfctn, o.pdctProfIdntfctn))&&Objects.equal(statmnt, o.statmnt))&&Objects.equal(status, o.status));
    }

}
