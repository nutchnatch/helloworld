
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * physical or individual person type
 * 			
 * 
 * <p>Java class for NaturalPersonType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NaturalPersonType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Title" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CivilityUsualNamingCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="LastName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
 *         &lt;element name="BrthName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="FrstName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="UsdName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="BrthDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="BrthPlace" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BirthPlaceType" minOccurs="0"/&gt;
 *         &lt;element name="MaritalStatus" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MaritalSituationCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Nation" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NationalityCodeSLN"/&gt;
 *         &lt;element name="Gendr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GenderIndicatorCodeSLN"/&gt;
 *         &lt;element name="DeathDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="DeathNotceReciptDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="ChildCount" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *         &lt;element name="VIPIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="VIPCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}VIPCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="ForsenRetirAge" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *         &lt;element name="Cvlty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MainCivilityCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NaturalPersonType", propOrder = {
    "title",
    "lastName",
    "brthName",
    "frstName",
    "usdName",
    "brthDate",
    "brthPlace",
    "maritalStatus",
    "nation",
    "gendr",
    "deathDate",
    "deathNotceReciptDate",
    "childCount",
    "vipIndic",
    "vipCode",
    "forsenRetirAge",
    "cvlty"
})
public class NaturalPersonType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Title")
    protected List<String> title;
    @XmlElement(name = "LastName", required = true)
    protected String lastName;
    @XmlElement(name = "BrthName")
    protected String brthName;
    @XmlElement(name = "FrstName", required = true)
    protected List<String> frstName;
    @XmlElement(name = "UsdName")
    protected String usdName;
    @XmlElement(name = "BrthDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date brthDate;
    @XmlElement(name = "BrthPlace")
    protected BirthPlaceType brthPlace;
    @XmlElement(name = "MaritalStatus")
    protected String maritalStatus;
    @XmlElement(name = "Nation", required = true)
    protected String nation;
    @XmlElement(name = "Gendr", required = true)
    protected String gendr;
    @XmlElement(name = "DeathDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date deathDate;
    @XmlElement(name = "DeathNotceReciptDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date deathNotceReciptDate;
    @XmlElement(name = "ChildCount")
    protected BigInteger childCount;
    @XmlElement(name = "VIPIndic")
    protected String vipIndic;
    @XmlElement(name = "VIPCode")
    protected String vipCode;
    @XmlElement(name = "ForsenRetirAge")
    protected BigInteger forsenRetirAge;
    @XmlElement(name = "Cvlty")
    protected String cvlty;

    /**
     * Default no-arg constructor
     * 
     */
    public NaturalPersonType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public NaturalPersonType(final List<String> title, final String lastName, final String brthName, final List<String> frstName, final String usdName, final Date brthDate, final BirthPlaceType brthPlace, final String maritalStatus, final String nation, final String gendr, final Date deathDate, final Date deathNotceReciptDate, final BigInteger childCount, final String vipIndic, final String vipCode, final BigInteger forsenRetirAge, final String cvlty) {
        this.title = title;
        this.lastName = lastName;
        this.brthName = brthName;
        this.frstName = frstName;
        this.usdName = usdName;
        this.brthDate = brthDate;
        this.brthPlace = brthPlace;
        this.maritalStatus = maritalStatus;
        this.nation = nation;
        this.gendr = gendr;
        this.deathDate = deathDate;
        this.deathNotceReciptDate = deathNotceReciptDate;
        this.childCount = childCount;
        this.vipIndic = vipIndic;
        this.vipCode = vipCode;
        this.forsenRetirAge = forsenRetirAge;
        this.cvlty = cvlty;
    }

    /**
     * Gets the value of the title property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the title property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTitle().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getTitle() {
        if (title == null) {
            title = new ArrayList<String>();
        }
        return this.title;
    }

    public boolean isSetTitle() {
        return ((this.title!= null)&&(!this.title.isEmpty()));
    }

    public void unsetTitle() {
        this.title = null;
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    public boolean isSetLastName() {
        return (this.lastName!= null);
    }

    /**
     * Gets the value of the brthName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBrthName() {
        return brthName;
    }

    /**
     * Sets the value of the brthName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBrthName(String value) {
        this.brthName = value;
    }

    public boolean isSetBrthName() {
        return (this.brthName!= null);
    }

    /**
     * Gets the value of the frstName property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the frstName property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFrstName().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getFrstName() {
        if (frstName == null) {
            frstName = new ArrayList<String>();
        }
        return this.frstName;
    }

    public boolean isSetFrstName() {
        return ((this.frstName!= null)&&(!this.frstName.isEmpty()));
    }

    public void unsetFrstName() {
        this.frstName = null;
    }

    /**
     * Gets the value of the usdName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUsdName() {
        return usdName;
    }

    /**
     * Sets the value of the usdName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUsdName(String value) {
        this.usdName = value;
    }

    public boolean isSetUsdName() {
        return (this.usdName!= null);
    }

    /**
     * Gets the value of the brthDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getBrthDate() {
        return brthDate;
    }

    /**
     * Sets the value of the brthDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBrthDate(Date value) {
        this.brthDate = value;
    }

    public boolean isSetBrthDate() {
        return (this.brthDate!= null);
    }

    /**
     * Gets the value of the brthPlace property.
     * 
     * @return
     *     possible object is
     *     {@link BirthPlaceType }
     *     
     */
    public BirthPlaceType getBrthPlace() {
        return brthPlace;
    }

    /**
     * Sets the value of the brthPlace property.
     * 
     * @param value
     *     allowed object is
     *     {@link BirthPlaceType }
     *     
     */
    public void setBrthPlace(BirthPlaceType value) {
        this.brthPlace = value;
    }

    public boolean isSetBrthPlace() {
        return (this.brthPlace!= null);
    }

    /**
     * Gets the value of the maritalStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaritalStatus() {
        return maritalStatus;
    }

    /**
     * Sets the value of the maritalStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaritalStatus(String value) {
        this.maritalStatus = value;
    }

    public boolean isSetMaritalStatus() {
        return (this.maritalStatus!= null);
    }

    /**
     * Gets the value of the nation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNation() {
        return nation;
    }

    /**
     * Sets the value of the nation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNation(String value) {
        this.nation = value;
    }

    public boolean isSetNation() {
        return (this.nation!= null);
    }

    /**
     * Gets the value of the gendr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGendr() {
        return gendr;
    }

    /**
     * Sets the value of the gendr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGendr(String value) {
        this.gendr = value;
    }

    public boolean isSetGendr() {
        return (this.gendr!= null);
    }

    /**
     * Gets the value of the deathDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDeathDate() {
        return deathDate;
    }

    /**
     * Sets the value of the deathDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeathDate(Date value) {
        this.deathDate = value;
    }

    public boolean isSetDeathDate() {
        return (this.deathDate!= null);
    }

    /**
     * Gets the value of the deathNotceReciptDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDeathNotceReciptDate() {
        return deathNotceReciptDate;
    }

    /**
     * Sets the value of the deathNotceReciptDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeathNotceReciptDate(Date value) {
        this.deathNotceReciptDate = value;
    }

    public boolean isSetDeathNotceReciptDate() {
        return (this.deathNotceReciptDate!= null);
    }

    /**
     * Gets the value of the childCount property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getChildCount() {
        return childCount;
    }

    /**
     * Sets the value of the childCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setChildCount(BigInteger value) {
        this.childCount = value;
    }

    public boolean isSetChildCount() {
        return (this.childCount!= null);
    }

    /**
     * Gets the value of the vipIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVIPIndic() {
        return vipIndic;
    }

    /**
     * Sets the value of the vipIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVIPIndic(String value) {
        this.vipIndic = value;
    }

    public boolean isSetVIPIndic() {
        return (this.vipIndic!= null);
    }

    /**
     * Gets the value of the vipCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVIPCode() {
        return vipCode;
    }

    /**
     * Sets the value of the vipCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVIPCode(String value) {
        this.vipCode = value;
    }

    public boolean isSetVIPCode() {
        return (this.vipCode!= null);
    }

    /**
     * Gets the value of the forsenRetirAge property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getForsenRetirAge() {
        return forsenRetirAge;
    }

    /**
     * Sets the value of the forsenRetirAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setForsenRetirAge(BigInteger value) {
        this.forsenRetirAge = value;
    }

    public boolean isSetForsenRetirAge() {
        return (this.forsenRetirAge!= null);
    }

    /**
     * Gets the value of the cvlty property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCvlty() {
        return cvlty;
    }

    /**
     * Sets the value of the cvlty property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCvlty(String value) {
        this.cvlty = value;
    }

    public boolean isSetCvlty() {
        return (this.cvlty!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("title", title).add("lastName", lastName).add("brthName", brthName).add("frstName", frstName).add("usdName", usdName).add("brthDate", brthDate).add("brthPlace", brthPlace).add("maritalStatus", maritalStatus).add("nation", nation).add("gendr", gendr).add("deathDate", deathDate).add("deathNotceReciptDate", deathNotceReciptDate).add("childCount", childCount).add("vipIndic", vipIndic).add("vipCode", vipCode).add("forsenRetirAge", forsenRetirAge).add("cvlty", cvlty).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(title, lastName, brthName, frstName, usdName, brthDate, brthPlace, maritalStatus, nation, gendr, deathDate, deathNotceReciptDate, childCount, vipIndic, vipCode, forsenRetirAge, cvlty);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final NaturalPersonType o = ((NaturalPersonType) other);
        return ((((((((((((((((Objects.equal(title, o.title)&&Objects.equal(lastName, o.lastName))&&Objects.equal(brthName, o.brthName))&&Objects.equal(frstName, o.frstName))&&Objects.equal(usdName, o.usdName))&&Objects.equal(brthDate, o.brthDate))&&Objects.equal(brthPlace, o.brthPlace))&&Objects.equal(maritalStatus, o.maritalStatus))&&Objects.equal(nation, o.nation))&&Objects.equal(gendr, o.gendr))&&Objects.equal(deathDate, o.deathDate))&&Objects.equal(deathNotceReciptDate, o.deathNotceReciptDate))&&Objects.equal(childCount, o.childCount))&&Objects.equal(vipIndic, o.vipIndic))&&Objects.equal(vipCode, o.vipCode))&&Objects.equal(forsenRetirAge, o.forsenRetirAge))&&Objects.equal(cvlty, o.cvlty));
    }

}
