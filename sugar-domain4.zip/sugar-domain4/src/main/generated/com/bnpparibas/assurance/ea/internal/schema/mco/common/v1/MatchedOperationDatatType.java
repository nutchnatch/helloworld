
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * To manage data on a mateched operation
 * 			
 * 
 * <p>Java class for MatchedOperationDatatType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MatchedOperationDatatType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OpeIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="OpeType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationTypeCodeSLN"/&gt;
 *         &lt;element name="Status" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationStatusType"/&gt;
 *         &lt;element name="SlipRef" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="AllctdAmt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="LinkdObjcts" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MatchedOperationLinkedObjectsType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MatchedOperationDatatType", propOrder = {
    "opeIdntfctn",
    "opeType",
    "status",
    "slipRef",
    "allctdAmt",
    "linkdObjcts"
})
public class MatchedOperationDatatType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "OpeIdntfctn", required = true)
    protected ObjectIdentificationType opeIdntfctn;
    @XmlElement(name = "OpeType", required = true)
    protected String opeType;
    @XmlElement(name = "Status", required = true)
    protected OperationStatusType status;
    @XmlElement(name = "SlipRef")
    protected ObjectIdentificationType slipRef;
    @XmlElement(name = "AllctdAmt", required = true)
    protected List<CurrencyAndAmountType> allctdAmt;
    @XmlElement(name = "LinkdObjcts", required = true)
    protected MatchedOperationLinkedObjectsType linkdObjcts;

    /**
     * Default no-arg constructor
     * 
     */
    public MatchedOperationDatatType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MatchedOperationDatatType(final ObjectIdentificationType opeIdntfctn, final String opeType, final OperationStatusType status, final ObjectIdentificationType slipRef, final List<CurrencyAndAmountType> allctdAmt, final MatchedOperationLinkedObjectsType linkdObjcts) {
        this.opeIdntfctn = opeIdntfctn;
        this.opeType = opeType;
        this.status = status;
        this.slipRef = slipRef;
        this.allctdAmt = allctdAmt;
        this.linkdObjcts = linkdObjcts;
    }

    /**
     * Gets the value of the opeIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getOpeIdntfctn() {
        return opeIdntfctn;
    }

    /**
     * Sets the value of the opeIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setOpeIdntfctn(ObjectIdentificationType value) {
        this.opeIdntfctn = value;
    }

    public boolean isSetOpeIdntfctn() {
        return (this.opeIdntfctn!= null);
    }

    /**
     * Gets the value of the opeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpeType() {
        return opeType;
    }

    /**
     * Sets the value of the opeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpeType(String value) {
        this.opeType = value;
    }

    public boolean isSetOpeType() {
        return (this.opeType!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link OperationStatusType }
     *     
     */
    public OperationStatusType getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link OperationStatusType }
     *     
     */
    public void setStatus(OperationStatusType value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    /**
     * Gets the value of the slipRef property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getSlipRef() {
        return slipRef;
    }

    /**
     * Sets the value of the slipRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setSlipRef(ObjectIdentificationType value) {
        this.slipRef = value;
    }

    public boolean isSetSlipRef() {
        return (this.slipRef!= null);
    }

    /**
     * Gets the value of the allctdAmt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the allctdAmt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAllctdAmt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CurrencyAndAmountType }
     * 
     * 
     */
    public List<CurrencyAndAmountType> getAllctdAmt() {
        if (allctdAmt == null) {
            allctdAmt = new ArrayList<CurrencyAndAmountType>();
        }
        return this.allctdAmt;
    }

    public boolean isSetAllctdAmt() {
        return ((this.allctdAmt!= null)&&(!this.allctdAmt.isEmpty()));
    }

    public void unsetAllctdAmt() {
        this.allctdAmt = null;
    }

    /**
     * Gets the value of the linkdObjcts property.
     * 
     * @return
     *     possible object is
     *     {@link MatchedOperationLinkedObjectsType }
     *     
     */
    public MatchedOperationLinkedObjectsType getLinkdObjcts() {
        return linkdObjcts;
    }

    /**
     * Sets the value of the linkdObjcts property.
     * 
     * @param value
     *     allowed object is
     *     {@link MatchedOperationLinkedObjectsType }
     *     
     */
    public void setLinkdObjcts(MatchedOperationLinkedObjectsType value) {
        this.linkdObjcts = value;
    }

    public boolean isSetLinkdObjcts() {
        return (this.linkdObjcts!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("opeIdntfctn", opeIdntfctn).add("opeType", opeType).add("status", status).add("slipRef", slipRef).add("allctdAmt", allctdAmt).add("linkdObjcts", linkdObjcts).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(opeIdntfctn, opeType, status, slipRef, allctdAmt, linkdObjcts);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MatchedOperationDatatType o = ((MatchedOperationDatatType) other);
        return (((((Objects.equal(opeIdntfctn, o.opeIdntfctn)&&Objects.equal(opeType, o.opeType))&&Objects.equal(status, o.status))&&Objects.equal(slipRef, o.slipRef))&&Objects.equal(allctdAmt, o.allctdAmt))&&Objects.equal(linkdObjcts, o.linkdObjcts));
    }

}
