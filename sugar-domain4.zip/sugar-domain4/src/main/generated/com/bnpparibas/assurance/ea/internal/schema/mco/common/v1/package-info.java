@javax.xml.bind.annotation.XmlSchema(namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;
