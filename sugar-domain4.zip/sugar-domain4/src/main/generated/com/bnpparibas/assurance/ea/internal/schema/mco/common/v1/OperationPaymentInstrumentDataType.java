
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on instrument payment at
 * 				operation level
 * 			
 * 
 * <p>Java class for OperationPaymentInstrumentDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OperationPaymentInstrumentDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SettlmntMode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SettlementModeCodeSLN"/&gt;
 *         &lt;element name="BnkAcct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BankAccountAndCreditorDataType" minOccurs="0"/&gt;
 *         &lt;element name="CheckNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="Card" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CardTransactionType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OperationPaymentInstrumentDataType", propOrder = {
    "settlmntMode",
    "bnkAcct",
    "checkNumb",
    "card"
})
public class OperationPaymentInstrumentDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SettlmntMode", required = true)
    protected String settlmntMode;
    @XmlElement(name = "BnkAcct")
    protected BankAccountAndCreditorDataType bnkAcct;
    @XmlElement(name = "CheckNumb")
    protected String checkNumb;
    @XmlElement(name = "Card")
    protected CardTransactionType card;

    /**
     * Default no-arg constructor
     * 
     */
    public OperationPaymentInstrumentDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public OperationPaymentInstrumentDataType(final String settlmntMode, final BankAccountAndCreditorDataType bnkAcct, final String checkNumb, final CardTransactionType card) {
        this.settlmntMode = settlmntMode;
        this.bnkAcct = bnkAcct;
        this.checkNumb = checkNumb;
        this.card = card;
    }

    /**
     * Gets the value of the settlmntMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSettlmntMode() {
        return settlmntMode;
    }

    /**
     * Sets the value of the settlmntMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSettlmntMode(String value) {
        this.settlmntMode = value;
    }

    public boolean isSetSettlmntMode() {
        return (this.settlmntMode!= null);
    }

    /**
     * Gets the value of the bnkAcct property.
     * 
     * @return
     *     possible object is
     *     {@link BankAccountAndCreditorDataType }
     *     
     */
    public BankAccountAndCreditorDataType getBnkAcct() {
        return bnkAcct;
    }

    /**
     * Sets the value of the bnkAcct property.
     * 
     * @param value
     *     allowed object is
     *     {@link BankAccountAndCreditorDataType }
     *     
     */
    public void setBnkAcct(BankAccountAndCreditorDataType value) {
        this.bnkAcct = value;
    }

    public boolean isSetBnkAcct() {
        return (this.bnkAcct!= null);
    }

    /**
     * Gets the value of the checkNumb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCheckNumb() {
        return checkNumb;
    }

    /**
     * Sets the value of the checkNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCheckNumb(String value) {
        this.checkNumb = value;
    }

    public boolean isSetCheckNumb() {
        return (this.checkNumb!= null);
    }

    /**
     * Gets the value of the card property.
     * 
     * @return
     *     possible object is
     *     {@link CardTransactionType }
     *     
     */
    public CardTransactionType getCard() {
        return card;
    }

    /**
     * Sets the value of the card property.
     * 
     * @param value
     *     allowed object is
     *     {@link CardTransactionType }
     *     
     */
    public void setCard(CardTransactionType value) {
        this.card = value;
    }

    public boolean isSetCard() {
        return (this.card!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("settlmntMode", settlmntMode).add("bnkAcct", bnkAcct).add("checkNumb", checkNumb).add("card", card).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(settlmntMode, bnkAcct, checkNumb, card);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final OperationPaymentInstrumentDataType o = ((OperationPaymentInstrumentDataType) other);
        return (((Objects.equal(settlmntMode, o.settlmntMode)&&Objects.equal(bnkAcct, o.bnkAcct))&&Objects.equal(checkNumb, o.checkNumb))&&Objects.equal(card, o.card));
    }

}
