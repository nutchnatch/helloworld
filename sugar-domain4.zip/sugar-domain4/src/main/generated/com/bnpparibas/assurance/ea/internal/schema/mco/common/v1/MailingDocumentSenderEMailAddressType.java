
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage the Email address of a sender of a
 * 				mailing
 * 			
 * 
 * <p>Java class for MailingDocumentSenderEMailAddressType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MailingDocumentSenderEMailAddressType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Adrs" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}EmailAddressInputType"/&gt;
 *         &lt;element name="AdrsReplyTo" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}EmailAddressInputType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MailingDocumentSenderEMailAddressType", propOrder = {
    "adrs",
    "adrsReplyTo"
})
public class MailingDocumentSenderEMailAddressType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Adrs", required = true)
    protected EmailAddressInputType adrs;
    @XmlElement(name = "AdrsReplyTo")
    protected EmailAddressInputType adrsReplyTo;

    /**
     * Default no-arg constructor
     * 
     */
    public MailingDocumentSenderEMailAddressType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MailingDocumentSenderEMailAddressType(final EmailAddressInputType adrs, final EmailAddressInputType adrsReplyTo) {
        this.adrs = adrs;
        this.adrsReplyTo = adrsReplyTo;
    }

    /**
     * Gets the value of the adrs property.
     * 
     * @return
     *     possible object is
     *     {@link EmailAddressInputType }
     *     
     */
    public EmailAddressInputType getAdrs() {
        return adrs;
    }

    /**
     * Sets the value of the adrs property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmailAddressInputType }
     *     
     */
    public void setAdrs(EmailAddressInputType value) {
        this.adrs = value;
    }

    public boolean isSetAdrs() {
        return (this.adrs!= null);
    }

    /**
     * Gets the value of the adrsReplyTo property.
     * 
     * @return
     *     possible object is
     *     {@link EmailAddressInputType }
     *     
     */
    public EmailAddressInputType getAdrsReplyTo() {
        return adrsReplyTo;
    }

    /**
     * Sets the value of the adrsReplyTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmailAddressInputType }
     *     
     */
    public void setAdrsReplyTo(EmailAddressInputType value) {
        this.adrsReplyTo = value;
    }

    public boolean isSetAdrsReplyTo() {
        return (this.adrsReplyTo!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("adrs", adrs).add("adrsReplyTo", adrsReplyTo).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(adrs, adrsReplyTo);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MailingDocumentSenderEMailAddressType o = ((MailingDocumentSenderEMailAddressType) other);
        return (Objects.equal(adrs, o.adrs)&&Objects.equal(adrsReplyTo, o.adrsReplyTo));
    }

}
