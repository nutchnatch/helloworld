
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage
 * 				information on loan installement and outstanding balance
 * 			
 * 
 * <p>Java class for LoanInstallmentOrSchedulePaymentDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LoanInstallmentOrSchedulePaymentDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="YearlyOutstdngBalnceAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="OutstdngBalnceAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="InstllmntAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *         &lt;element name="Fqcy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="CalctnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="InitAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="Numb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LoanInstallmentOrSchedulePaymentDataType", propOrder = {
    "yearlyOutstdngBalnceAmnt",
    "outstdngBalnceAmnt",
    "instllmntAmnt",
    "fqcy",
    "calctnDate",
    "initAmnt",
    "numb"
})
public class LoanInstallmentOrSchedulePaymentDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "YearlyOutstdngBalnceAmnt")
    protected CurrencyAndAmountType yearlyOutstdngBalnceAmnt;
    @XmlElement(name = "OutstdngBalnceAmnt")
    protected CurrencyAndAmountType outstdngBalnceAmnt;
    @XmlElement(name = "InstllmntAmnt", required = true)
    protected CurrencyAndAmountType instllmntAmnt;
    @XmlElement(name = "Fqcy")
    protected String fqcy;
    @XmlElement(name = "CalctnDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date calctnDate;
    @XmlElement(name = "InitAmnt")
    protected CurrencyAndAmountType initAmnt;
    @XmlElement(name = "Numb")
    protected BigInteger numb;

    /**
     * Default no-arg constructor
     * 
     */
    public LoanInstallmentOrSchedulePaymentDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public LoanInstallmentOrSchedulePaymentDataType(final CurrencyAndAmountType yearlyOutstdngBalnceAmnt, final CurrencyAndAmountType outstdngBalnceAmnt, final CurrencyAndAmountType instllmntAmnt, final String fqcy, final Date calctnDate, final CurrencyAndAmountType initAmnt, final BigInteger numb) {
        this.yearlyOutstdngBalnceAmnt = yearlyOutstdngBalnceAmnt;
        this.outstdngBalnceAmnt = outstdngBalnceAmnt;
        this.instllmntAmnt = instllmntAmnt;
        this.fqcy = fqcy;
        this.calctnDate = calctnDate;
        this.initAmnt = initAmnt;
        this.numb = numb;
    }

    /**
     * Gets the value of the yearlyOutstdngBalnceAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getYearlyOutstdngBalnceAmnt() {
        return yearlyOutstdngBalnceAmnt;
    }

    /**
     * Sets the value of the yearlyOutstdngBalnceAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setYearlyOutstdngBalnceAmnt(CurrencyAndAmountType value) {
        this.yearlyOutstdngBalnceAmnt = value;
    }

    public boolean isSetYearlyOutstdngBalnceAmnt() {
        return (this.yearlyOutstdngBalnceAmnt!= null);
    }

    /**
     * Gets the value of the outstdngBalnceAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getOutstdngBalnceAmnt() {
        return outstdngBalnceAmnt;
    }

    /**
     * Sets the value of the outstdngBalnceAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setOutstdngBalnceAmnt(CurrencyAndAmountType value) {
        this.outstdngBalnceAmnt = value;
    }

    public boolean isSetOutstdngBalnceAmnt() {
        return (this.outstdngBalnceAmnt!= null);
    }

    /**
     * Gets the value of the instllmntAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getInstllmntAmnt() {
        return instllmntAmnt;
    }

    /**
     * Sets the value of the instllmntAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setInstllmntAmnt(CurrencyAndAmountType value) {
        this.instllmntAmnt = value;
    }

    public boolean isSetInstllmntAmnt() {
        return (this.instllmntAmnt!= null);
    }

    /**
     * Gets the value of the fqcy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFqcy() {
        return fqcy;
    }

    /**
     * Sets the value of the fqcy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFqcy(String value) {
        this.fqcy = value;
    }

    public boolean isSetFqcy() {
        return (this.fqcy!= null);
    }

    /**
     * Gets the value of the calctnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCalctnDate() {
        return calctnDate;
    }

    /**
     * Sets the value of the calctnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCalctnDate(Date value) {
        this.calctnDate = value;
    }

    public boolean isSetCalctnDate() {
        return (this.calctnDate!= null);
    }

    /**
     * Gets the value of the initAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getInitAmnt() {
        return initAmnt;
    }

    /**
     * Sets the value of the initAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setInitAmnt(CurrencyAndAmountType value) {
        this.initAmnt = value;
    }

    public boolean isSetInitAmnt() {
        return (this.initAmnt!= null);
    }

    /**
     * Gets the value of the numb property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNumb() {
        return numb;
    }

    /**
     * Sets the value of the numb property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNumb(BigInteger value) {
        this.numb = value;
    }

    public boolean isSetNumb() {
        return (this.numb!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("yearlyOutstdngBalnceAmnt", yearlyOutstdngBalnceAmnt).add("outstdngBalnceAmnt", outstdngBalnceAmnt).add("instllmntAmnt", instllmntAmnt).add("fqcy", fqcy).add("calctnDate", calctnDate).add("initAmnt", initAmnt).add("numb", numb).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(yearlyOutstdngBalnceAmnt, outstdngBalnceAmnt, instllmntAmnt, fqcy, calctnDate, initAmnt, numb);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final LoanInstallmentOrSchedulePaymentDataType o = ((LoanInstallmentOrSchedulePaymentDataType) other);
        return ((((((Objects.equal(yearlyOutstdngBalnceAmnt, o.yearlyOutstdngBalnceAmnt)&&Objects.equal(outstdngBalnceAmnt, o.outstdngBalnceAmnt))&&Objects.equal(instllmntAmnt, o.instllmntAmnt))&&Objects.equal(fqcy, o.fqcy))&&Objects.equal(calctnDate, o.calctnDate))&&Objects.equal(initAmnt, o.initAmnt))&&Objects.equal(numb, o.numb));
    }

}
