
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Description of lossless
 * 				encapsulation transformations applied to data.
 * 			
 * 
 * <p>Java class for LosslessDataEncapsulationDescriptionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LosslessDataEncapsulationDescriptionType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Comprsn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DataLosslessCompressionCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="BnryToTextEncdng" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BinaryToTextEncodingCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LosslessDataEncapsulationDescriptionType", propOrder = {
    "comprsn",
    "bnryToTextEncdng"
})
public class LosslessDataEncapsulationDescriptionType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Comprsn")
    protected String comprsn;
    @XmlElement(name = "BnryToTextEncdng")
    protected String bnryToTextEncdng;

    /**
     * Default no-arg constructor
     * 
     */
    public LosslessDataEncapsulationDescriptionType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public LosslessDataEncapsulationDescriptionType(final String comprsn, final String bnryToTextEncdng) {
        this.comprsn = comprsn;
        this.bnryToTextEncdng = bnryToTextEncdng;
    }

    /**
     * Gets the value of the comprsn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComprsn() {
        return comprsn;
    }

    /**
     * Sets the value of the comprsn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComprsn(String value) {
        this.comprsn = value;
    }

    public boolean isSetComprsn() {
        return (this.comprsn!= null);
    }

    /**
     * Gets the value of the bnryToTextEncdng property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBnryToTextEncdng() {
        return bnryToTextEncdng;
    }

    /**
     * Sets the value of the bnryToTextEncdng property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBnryToTextEncdng(String value) {
        this.bnryToTextEncdng = value;
    }

    public boolean isSetBnryToTextEncdng() {
        return (this.bnryToTextEncdng!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("comprsn", comprsn).add("bnryToTextEncdng", bnryToTextEncdng).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(comprsn, bnryToTextEncdng);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final LosslessDataEncapsulationDescriptionType o = ((LosslessDataEncapsulationDescriptionType) other);
        return (Objects.equal(comprsn, o.comprsn)&&Objects.equal(bnryToTextEncdng, o.bnryToTextEncdng));
    }

}
