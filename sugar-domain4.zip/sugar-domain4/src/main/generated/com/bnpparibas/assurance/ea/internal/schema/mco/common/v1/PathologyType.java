
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Classification and description of a pathology
 * 			
 * 
 * <p>Java class for PathologyType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PathologyType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PathologyTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="FreeDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LongDescriptionType" minOccurs="0"/&gt;
 *         &lt;element name="DueIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PathologyType", propOrder = {
    "type",
    "freeDesc",
    "dueIndic"
})
public class PathologyType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Type")
    protected String type;
    @XmlElement(name = "FreeDesc")
    protected String freeDesc;
    @XmlElement(name = "DueIndic")
    protected String dueIndic;

    /**
     * Default no-arg constructor
     * 
     */
    public PathologyType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PathologyType(final String type, final String freeDesc, final String dueIndic) {
        this.type = type;
        this.freeDesc = freeDesc;
        this.dueIndic = dueIndic;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the freeDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFreeDesc() {
        return freeDesc;
    }

    /**
     * Sets the value of the freeDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFreeDesc(String value) {
        this.freeDesc = value;
    }

    public boolean isSetFreeDesc() {
        return (this.freeDesc!= null);
    }

    /**
     * Gets the value of the dueIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDueIndic() {
        return dueIndic;
    }

    /**
     * Sets the value of the dueIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDueIndic(String value) {
        this.dueIndic = value;
    }

    public boolean isSetDueIndic() {
        return (this.dueIndic!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("type", type).add("freeDesc", freeDesc).add("dueIndic", dueIndic).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(type, freeDesc, dueIndic);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PathologyType o = ((PathologyType) other);
        return ((Objects.equal(type, o.type)&&Objects.equal(freeDesc, o.freeDesc))&&Objects.equal(dueIndic, o.dueIndic));
    }

}
