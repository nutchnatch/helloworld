
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * publication context data of objects carried by a
 * 				data flow
 * 			
 * 
 * <p>Java class for FilePublicationDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FilePublicationDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FileIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="CreatnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FilePublicationDataType", propOrder = {
    "fileIdntfctn",
    "creatnDate"
})
public class FilePublicationDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "FileIdntfctn")
    protected IdentificationType fileIdntfctn;
    @XmlElement(name = "CreatnDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date creatnDate;

    /**
     * Default no-arg constructor
     * 
     */
    public FilePublicationDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FilePublicationDataType(final IdentificationType fileIdntfctn, final Date creatnDate) {
        this.fileIdntfctn = fileIdntfctn;
        this.creatnDate = creatnDate;
    }

    /**
     * Gets the value of the fileIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link IdentificationType }
     *     
     */
    public IdentificationType getFileIdntfctn() {
        return fileIdntfctn;
    }

    /**
     * Sets the value of the fileIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentificationType }
     *     
     */
    public void setFileIdntfctn(IdentificationType value) {
        this.fileIdntfctn = value;
    }

    public boolean isSetFileIdntfctn() {
        return (this.fileIdntfctn!= null);
    }

    /**
     * Gets the value of the creatnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCreatnDate() {
        return creatnDate;
    }

    /**
     * Sets the value of the creatnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatnDate(Date value) {
        this.creatnDate = value;
    }

    public boolean isSetCreatnDate() {
        return (this.creatnDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("fileIdntfctn", fileIdntfctn).add("creatnDate", creatnDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(fileIdntfctn, creatnDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FilePublicationDataType o = ((FilePublicationDataType) other);
        return (Objects.equal(fileIdntfctn, o.fileIdntfctn)&&Objects.equal(creatnDate, o.creatnDate));
    }

}
