
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * To manage information on matched payment in
 * 				matching operations
 * 			
 * 
 * <p>Java class for MatchedPaymentDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MatchedPaymentDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PaymntIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="OpeType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationTypeCodeSLN"/&gt;
 *         &lt;element name="Status" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationStatusType"/&gt;
 *         &lt;element name="SettlmntMode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SettlementModeCodeSLN"/&gt;
 *         &lt;element name="SlipRef" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="DocRef" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="AllctdAmt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="PaymntPrty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MatchedPaymentDataType", propOrder = {
    "paymntIdntfctn",
    "opeType",
    "status",
    "settlmntMode",
    "slipRef",
    "docRef",
    "allctdAmt",
    "paymntPrty"
})
public class MatchedPaymentDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PaymntIdntfctn", required = true)
    protected ObjectIdentificationType paymntIdntfctn;
    @XmlElement(name = "OpeType", required = true)
    protected String opeType;
    @XmlElement(name = "Status", required = true)
    protected OperationStatusType status;
    @XmlElement(name = "SettlmntMode", required = true)
    protected String settlmntMode;
    @XmlElement(name = "SlipRef")
    protected ObjectIdentificationType slipRef;
    @XmlElement(name = "DocRef")
    protected String docRef;
    @XmlElement(name = "AllctdAmt", required = true)
    protected List<CurrencyAndAmountType> allctdAmt;
    @XmlElement(name = "PaymntPrty")
    protected PartyRoleType paymntPrty;

    /**
     * Default no-arg constructor
     * 
     */
    public MatchedPaymentDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MatchedPaymentDataType(final ObjectIdentificationType paymntIdntfctn, final String opeType, final OperationStatusType status, final String settlmntMode, final ObjectIdentificationType slipRef, final String docRef, final List<CurrencyAndAmountType> allctdAmt, final PartyRoleType paymntPrty) {
        this.paymntIdntfctn = paymntIdntfctn;
        this.opeType = opeType;
        this.status = status;
        this.settlmntMode = settlmntMode;
        this.slipRef = slipRef;
        this.docRef = docRef;
        this.allctdAmt = allctdAmt;
        this.paymntPrty = paymntPrty;
    }

    /**
     * Gets the value of the paymntIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPaymntIdntfctn() {
        return paymntIdntfctn;
    }

    /**
     * Sets the value of the paymntIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPaymntIdntfctn(ObjectIdentificationType value) {
        this.paymntIdntfctn = value;
    }

    public boolean isSetPaymntIdntfctn() {
        return (this.paymntIdntfctn!= null);
    }

    /**
     * Gets the value of the opeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpeType() {
        return opeType;
    }

    /**
     * Sets the value of the opeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpeType(String value) {
        this.opeType = value;
    }

    public boolean isSetOpeType() {
        return (this.opeType!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link OperationStatusType }
     *     
     */
    public OperationStatusType getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link OperationStatusType }
     *     
     */
    public void setStatus(OperationStatusType value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    /**
     * Gets the value of the settlmntMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSettlmntMode() {
        return settlmntMode;
    }

    /**
     * Sets the value of the settlmntMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSettlmntMode(String value) {
        this.settlmntMode = value;
    }

    public boolean isSetSettlmntMode() {
        return (this.settlmntMode!= null);
    }

    /**
     * Gets the value of the slipRef property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getSlipRef() {
        return slipRef;
    }

    /**
     * Sets the value of the slipRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setSlipRef(ObjectIdentificationType value) {
        this.slipRef = value;
    }

    public boolean isSetSlipRef() {
        return (this.slipRef!= null);
    }

    /**
     * Gets the value of the docRef property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocRef() {
        return docRef;
    }

    /**
     * Sets the value of the docRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocRef(String value) {
        this.docRef = value;
    }

    public boolean isSetDocRef() {
        return (this.docRef!= null);
    }

    /**
     * Gets the value of the allctdAmt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the allctdAmt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAllctdAmt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CurrencyAndAmountType }
     * 
     * 
     */
    public List<CurrencyAndAmountType> getAllctdAmt() {
        if (allctdAmt == null) {
            allctdAmt = new ArrayList<CurrencyAndAmountType>();
        }
        return this.allctdAmt;
    }

    public boolean isSetAllctdAmt() {
        return ((this.allctdAmt!= null)&&(!this.allctdAmt.isEmpty()));
    }

    public void unsetAllctdAmt() {
        this.allctdAmt = null;
    }

    /**
     * Gets the value of the paymntPrty property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPaymntPrty() {
        return paymntPrty;
    }

    /**
     * Sets the value of the paymntPrty property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPaymntPrty(PartyRoleType value) {
        this.paymntPrty = value;
    }

    public boolean isSetPaymntPrty() {
        return (this.paymntPrty!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("paymntIdntfctn", paymntIdntfctn).add("opeType", opeType).add("status", status).add("settlmntMode", settlmntMode).add("slipRef", slipRef).add("docRef", docRef).add("allctdAmt", allctdAmt).add("paymntPrty", paymntPrty).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(paymntIdntfctn, opeType, status, settlmntMode, slipRef, docRef, allctdAmt, paymntPrty);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MatchedPaymentDataType o = ((MatchedPaymentDataType) other);
        return (((((((Objects.equal(paymntIdntfctn, o.paymntIdntfctn)&&Objects.equal(opeType, o.opeType))&&Objects.equal(status, o.status))&&Objects.equal(settlmntMode, o.settlmntMode))&&Objects.equal(slipRef, o.slipRef))&&Objects.equal(docRef, o.docRef))&&Objects.equal(allctdAmt, o.allctdAmt))&&Objects.equal(paymntPrty, o.paymntPrty));
    }

}
