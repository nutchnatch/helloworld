
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * To manage objects with which a money in or money
 * 				out operation has dependencies
 * 			
 * 
 * <p>Java class for MoneyInMoneyOutLinkedObjectsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MoneyInMoneyOutLinkedObjectsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Pdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductSharedDataType" minOccurs="0"/&gt;
 *         &lt;element name="Pol" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="Distrbtr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartnerPartyType" minOccurs="0"/&gt;
 *         &lt;element name="Prdctr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="Cust" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="LinkdMoneyInMoneyOut" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="OpeIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *                   &lt;element name="OpeType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationTypeCodeSLN"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MoneyInMoneyOutLinkedObjectsType", propOrder = {
    "pdct",
    "pol",
    "distrbtr",
    "prdctr",
    "cust",
    "linkdMoneyInMoneyOut"
})
public class MoneyInMoneyOutLinkedObjectsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Pdct")
    protected ProductSharedDataType pdct;
    @XmlElement(name = "Pol")
    protected ObjectIdentificationType pol;
    @XmlElement(name = "Distrbtr")
    protected PartnerPartyType distrbtr;
    @XmlElement(name = "Prdctr", required = true)
    protected PartyRoleType prdctr;
    @XmlElement(name = "Cust")
    protected PartyRoleType cust;
    @XmlElement(name = "LinkdMoneyInMoneyOut")
    protected List<MoneyInMoneyOutLinkedObjectsType.LinkdMoneyInMoneyOut> linkdMoneyInMoneyOut;

    /**
     * Default no-arg constructor
     * 
     */
    public MoneyInMoneyOutLinkedObjectsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MoneyInMoneyOutLinkedObjectsType(final ProductSharedDataType pdct, final ObjectIdentificationType pol, final PartnerPartyType distrbtr, final PartyRoleType prdctr, final PartyRoleType cust, final List<MoneyInMoneyOutLinkedObjectsType.LinkdMoneyInMoneyOut> linkdMoneyInMoneyOut) {
        this.pdct = pdct;
        this.pol = pol;
        this.distrbtr = distrbtr;
        this.prdctr = prdctr;
        this.cust = cust;
        this.linkdMoneyInMoneyOut = linkdMoneyInMoneyOut;
    }

    /**
     * Gets the value of the pdct property.
     * 
     * @return
     *     possible object is
     *     {@link ProductSharedDataType }
     *     
     */
    public ProductSharedDataType getPdct() {
        return pdct;
    }

    /**
     * Sets the value of the pdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductSharedDataType }
     *     
     */
    public void setPdct(ProductSharedDataType value) {
        this.pdct = value;
    }

    public boolean isSetPdct() {
        return (this.pdct!= null);
    }

    /**
     * Gets the value of the pol property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPol() {
        return pol;
    }

    /**
     * Sets the value of the pol property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPol(ObjectIdentificationType value) {
        this.pol = value;
    }

    public boolean isSetPol() {
        return (this.pol!= null);
    }

    /**
     * Gets the value of the distrbtr property.
     * 
     * @return
     *     possible object is
     *     {@link PartnerPartyType }
     *     
     */
    public PartnerPartyType getDistrbtr() {
        return distrbtr;
    }

    /**
     * Sets the value of the distrbtr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartnerPartyType }
     *     
     */
    public void setDistrbtr(PartnerPartyType value) {
        this.distrbtr = value;
    }

    public boolean isSetDistrbtr() {
        return (this.distrbtr!= null);
    }

    /**
     * Gets the value of the prdctr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrdctr() {
        return prdctr;
    }

    /**
     * Sets the value of the prdctr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrdctr(PartyRoleType value) {
        this.prdctr = value;
    }

    public boolean isSetPrdctr() {
        return (this.prdctr!= null);
    }

    /**
     * Gets the value of the cust property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getCust() {
        return cust;
    }

    /**
     * Sets the value of the cust property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setCust(PartyRoleType value) {
        this.cust = value;
    }

    public boolean isSetCust() {
        return (this.cust!= null);
    }

    /**
     * Gets the value of the linkdMoneyInMoneyOut property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the linkdMoneyInMoneyOut property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLinkdMoneyInMoneyOut().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MoneyInMoneyOutLinkedObjectsType.LinkdMoneyInMoneyOut }
     * 
     * 
     */
    public List<MoneyInMoneyOutLinkedObjectsType.LinkdMoneyInMoneyOut> getLinkdMoneyInMoneyOut() {
        if (linkdMoneyInMoneyOut == null) {
            linkdMoneyInMoneyOut = new ArrayList<MoneyInMoneyOutLinkedObjectsType.LinkdMoneyInMoneyOut>();
        }
        return this.linkdMoneyInMoneyOut;
    }

    public boolean isSetLinkdMoneyInMoneyOut() {
        return ((this.linkdMoneyInMoneyOut!= null)&&(!this.linkdMoneyInMoneyOut.isEmpty()));
    }

    public void unsetLinkdMoneyInMoneyOut() {
        this.linkdMoneyInMoneyOut = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pdct", pdct).add("pol", pol).add("distrbtr", distrbtr).add("prdctr", prdctr).add("cust", cust).add("linkdMoneyInMoneyOut", linkdMoneyInMoneyOut).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pdct, pol, distrbtr, prdctr, cust, linkdMoneyInMoneyOut);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MoneyInMoneyOutLinkedObjectsType o = ((MoneyInMoneyOutLinkedObjectsType) other);
        return (((((Objects.equal(pdct, o.pdct)&&Objects.equal(pol, o.pol))&&Objects.equal(distrbtr, o.distrbtr))&&Objects.equal(prdctr, o.prdctr))&&Objects.equal(cust, o.cust))&&Objects.equal(linkdMoneyInMoneyOut, o.linkdMoneyInMoneyOut));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="OpeIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
     *         &lt;element name="OpeType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationTypeCodeSLN"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "opeIdntfctn",
        "opeType"
    })
    public static class LinkdMoneyInMoneyOut implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "OpeIdntfctn", required = true)
        protected ObjectIdentificationType opeIdntfctn;
        @XmlElement(name = "OpeType", required = true)
        protected String opeType;

        /**
         * Default no-arg constructor
         * 
         */
        public LinkdMoneyInMoneyOut() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public LinkdMoneyInMoneyOut(final ObjectIdentificationType opeIdntfctn, final String opeType) {
            this.opeIdntfctn = opeIdntfctn;
            this.opeType = opeType;
        }

        /**
         * Gets the value of the opeIdntfctn property.
         * 
         * @return
         *     possible object is
         *     {@link ObjectIdentificationType }
         *     
         */
        public ObjectIdentificationType getOpeIdntfctn() {
            return opeIdntfctn;
        }

        /**
         * Sets the value of the opeIdntfctn property.
         * 
         * @param value
         *     allowed object is
         *     {@link ObjectIdentificationType }
         *     
         */
        public void setOpeIdntfctn(ObjectIdentificationType value) {
            this.opeIdntfctn = value;
        }

        public boolean isSetOpeIdntfctn() {
            return (this.opeIdntfctn!= null);
        }

        /**
         * Gets the value of the opeType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getOpeType() {
            return opeType;
        }

        /**
         * Sets the value of the opeType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setOpeType(String value) {
            this.opeType = value;
        }

        public boolean isSetOpeType() {
            return (this.opeType!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("opeIdntfctn", opeIdntfctn).add("opeType", opeType).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(opeIdntfctn, opeType);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final MoneyInMoneyOutLinkedObjectsType.LinkdMoneyInMoneyOut o = ((MoneyInMoneyOutLinkedObjectsType.LinkdMoneyInMoneyOut) other);
            return (Objects.equal(opeIdntfctn, o.opeIdntfctn)&&Objects.equal(opeType, o.opeType));
        }

    }

}
