
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on the fees derogation
 * 				at fund level
 * 			
 * 
 * <p>Java class for FundFeeDerogationDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FundFeeDerogationDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Fee" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeeDerogationInputType"/&gt;
 *         &lt;element name="FundIntctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FinancialFundIdentificationType"/&gt;
 *         &lt;element name="ProfIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FundFeeDerogationDataType", propOrder = {
    "fee",
    "fundIntctn",
    "profIdntfctn"
})
public class FundFeeDerogationDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Fee", required = true)
    protected FeeDerogationInputType fee;
    @XmlElement(name = "FundIntctn", required = true)
    protected FinancialFundIdentificationType fundIntctn;
    @XmlElement(name = "ProfIdntfctn")
    protected ObjectIdentificationType profIdntfctn;

    /**
     * Default no-arg constructor
     * 
     */
    public FundFeeDerogationDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FundFeeDerogationDataType(final FeeDerogationInputType fee, final FinancialFundIdentificationType fundIntctn, final ObjectIdentificationType profIdntfctn) {
        this.fee = fee;
        this.fundIntctn = fundIntctn;
        this.profIdntfctn = profIdntfctn;
    }

    /**
     * Gets the value of the fee property.
     * 
     * @return
     *     possible object is
     *     {@link FeeDerogationInputType }
     *     
     */
    public FeeDerogationInputType getFee() {
        return fee;
    }

    /**
     * Sets the value of the fee property.
     * 
     * @param value
     *     allowed object is
     *     {@link FeeDerogationInputType }
     *     
     */
    public void setFee(FeeDerogationInputType value) {
        this.fee = value;
    }

    public boolean isSetFee() {
        return (this.fee!= null);
    }

    /**
     * Gets the value of the fundIntctn property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialFundIdentificationType }
     *     
     */
    public FinancialFundIdentificationType getFundIntctn() {
        return fundIntctn;
    }

    /**
     * Sets the value of the fundIntctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialFundIdentificationType }
     *     
     */
    public void setFundIntctn(FinancialFundIdentificationType value) {
        this.fundIntctn = value;
    }

    public boolean isSetFundIntctn() {
        return (this.fundIntctn!= null);
    }

    /**
     * Gets the value of the profIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getProfIdntfctn() {
        return profIdntfctn;
    }

    /**
     * Sets the value of the profIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setProfIdntfctn(ObjectIdentificationType value) {
        this.profIdntfctn = value;
    }

    public boolean isSetProfIdntfctn() {
        return (this.profIdntfctn!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("fee", fee).add("fundIntctn", fundIntctn).add("profIdntfctn", profIdntfctn).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(fee, fundIntctn, profIdntfctn);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FundFeeDerogationDataType o = ((FundFeeDerogationDataType) other);
        return ((Objects.equal(fee, o.fee)&&Objects.equal(fundIntctn, o.fundIntctn))&&Objects.equal(profIdntfctn, o.profIdntfctn));
    }

}
