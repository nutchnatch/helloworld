
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to define identification and role and of
 * 				customer
 * 			
 * 
 * <p>Java class for PersonIdentificationAndRoleType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PersonIdentificationAndRoleType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Idnfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="RoleData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PersonRoleType" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PersonIdentificationAndRoleType", propOrder = {
    "idnfctn",
    "roleData"
})
public class PersonIdentificationAndRoleType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Idnfctn", required = true)
    protected ObjectIdentificationType idnfctn;
    @XmlElement(name = "RoleData", required = true)
    protected List<PersonRoleType> roleData;

    /**
     * Default no-arg constructor
     * 
     */
    public PersonIdentificationAndRoleType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PersonIdentificationAndRoleType(final ObjectIdentificationType idnfctn, final List<PersonRoleType> roleData) {
        this.idnfctn = idnfctn;
        this.roleData = roleData;
    }

    /**
     * Gets the value of the idnfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getIdnfctn() {
        return idnfctn;
    }

    /**
     * Sets the value of the idnfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setIdnfctn(ObjectIdentificationType value) {
        this.idnfctn = value;
    }

    public boolean isSetIdnfctn() {
        return (this.idnfctn!= null);
    }

    /**
     * Gets the value of the roleData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the roleData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRoleData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PersonRoleType }
     * 
     * 
     */
    public List<PersonRoleType> getRoleData() {
        if (roleData == null) {
            roleData = new ArrayList<PersonRoleType>();
        }
        return this.roleData;
    }

    public boolean isSetRoleData() {
        return ((this.roleData!= null)&&(!this.roleData.isEmpty()));
    }

    public void unsetRoleData() {
        this.roleData = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("idnfctn", idnfctn).add("roleData", roleData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(idnfctn, roleData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PersonIdentificationAndRoleType o = ((PersonIdentificationAndRoleType) other);
        return (Objects.equal(idnfctn, o.idnfctn)&&Objects.equal(roleData, o.roleData));
    }

}
