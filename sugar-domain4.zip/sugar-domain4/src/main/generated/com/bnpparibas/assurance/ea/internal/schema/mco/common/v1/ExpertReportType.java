
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Expert report type
 * 
 * <p>Java class for ExpertReportType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ExpertReportType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Exprt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="Data" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ExpertReportDataType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ExpertReportType", propOrder = {
    "exprt",
    "data"
})
public class ExpertReportType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Exprt", required = true)
    protected PartyRoleType exprt;
    @XmlElement(name = "Data", required = true)
    protected ExpertReportDataType data;

    /**
     * Default no-arg constructor
     * 
     */
    public ExpertReportType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ExpertReportType(final PartyRoleType exprt, final ExpertReportDataType data) {
        this.exprt = exprt;
        this.data = data;
    }

    /**
     * Gets the value of the exprt property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getExprt() {
        return exprt;
    }

    /**
     * Sets the value of the exprt property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setExprt(PartyRoleType value) {
        this.exprt = value;
    }

    public boolean isSetExprt() {
        return (this.exprt!= null);
    }

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     {@link ExpertReportDataType }
     *     
     */
    public ExpertReportDataType getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExpertReportDataType }
     *     
     */
    public void setData(ExpertReportDataType value) {
        this.data = value;
    }

    public boolean isSetData() {
        return (this.data!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("exprt", exprt).add("data", data).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(exprt, data);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ExpertReportType o = ((ExpertReportType) other);
        return (Objects.equal(exprt, o.exprt)&&Objects.equal(data, o.data));
    }

}
