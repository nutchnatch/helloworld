
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Identification, rôle et
 * 				sous rôle d'un client
 * 			
 * 
 * <p>Java class for ExtendedPersonIdentificationAndRoleSubRoleType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ExtendedPersonIdentificationAndRoleSubRoleType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Idnfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="RoleData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PersonRoleAndSubRoleType" maxOccurs="unbounded"/&gt;
 *         &lt;element name="Title" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CivilityUsualNamingCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="LastName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="FrstName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ExtendedPersonIdentificationAndRoleSubRoleType", propOrder = {
    "idnfctn",
    "roleData",
    "title",
    "lastName",
    "frstName"
})
public class ExtendedPersonIdentificationAndRoleSubRoleType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Idnfctn", required = true)
    protected ObjectIdentificationType idnfctn;
    @XmlElement(name = "RoleData", required = true)
    protected List<PersonRoleAndSubRoleType> roleData;
    @XmlElement(name = "Title")
    protected String title;
    @XmlElement(name = "LastName")
    protected String lastName;
    @XmlElement(name = "FrstName")
    protected List<String> frstName;

    /**
     * Default no-arg constructor
     * 
     */
    public ExtendedPersonIdentificationAndRoleSubRoleType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ExtendedPersonIdentificationAndRoleSubRoleType(final ObjectIdentificationType idnfctn, final List<PersonRoleAndSubRoleType> roleData, final String title, final String lastName, final List<String> frstName) {
        this.idnfctn = idnfctn;
        this.roleData = roleData;
        this.title = title;
        this.lastName = lastName;
        this.frstName = frstName;
    }

    /**
     * Gets the value of the idnfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getIdnfctn() {
        return idnfctn;
    }

    /**
     * Sets the value of the idnfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setIdnfctn(ObjectIdentificationType value) {
        this.idnfctn = value;
    }

    public boolean isSetIdnfctn() {
        return (this.idnfctn!= null);
    }

    /**
     * Gets the value of the roleData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the roleData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRoleData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PersonRoleAndSubRoleType }
     * 
     * 
     */
    public List<PersonRoleAndSubRoleType> getRoleData() {
        if (roleData == null) {
            roleData = new ArrayList<PersonRoleAndSubRoleType>();
        }
        return this.roleData;
    }

    public boolean isSetRoleData() {
        return ((this.roleData!= null)&&(!this.roleData.isEmpty()));
    }

    public void unsetRoleData() {
        this.roleData = null;
    }

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle(String value) {
        this.title = value;
    }

    public boolean isSetTitle() {
        return (this.title!= null);
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastName(String value) {
        this.lastName = value;
    }

    public boolean isSetLastName() {
        return (this.lastName!= null);
    }

    /**
     * Gets the value of the frstName property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the frstName property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFrstName().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getFrstName() {
        if (frstName == null) {
            frstName = new ArrayList<String>();
        }
        return this.frstName;
    }

    public boolean isSetFrstName() {
        return ((this.frstName!= null)&&(!this.frstName.isEmpty()));
    }

    public void unsetFrstName() {
        this.frstName = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("idnfctn", idnfctn).add("roleData", roleData).add("title", title).add("lastName", lastName).add("frstName", frstName).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(idnfctn, roleData, title, lastName, frstName);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ExtendedPersonIdentificationAndRoleSubRoleType o = ((ExtendedPersonIdentificationAndRoleSubRoleType) other);
        return ((((Objects.equal(idnfctn, o.idnfctn)&&Objects.equal(roleData, o.roleData))&&Objects.equal(title, o.title))&&Objects.equal(lastName, o.lastName))&&Objects.equal(frstName, o.frstName));
    }

}
