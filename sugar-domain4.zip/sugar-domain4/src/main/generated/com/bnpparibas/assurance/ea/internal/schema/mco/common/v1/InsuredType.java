
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Le type représentant
 * 				l'assuré
 * 			
 * 
 * <p>Java class for InsuredType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InsuredType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="InsrdIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *         &lt;element name="Rnk" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntegerType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InsuredType", propOrder = {
    "insrdIdntfctn",
    "rnk"
})
public class InsuredType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "InsrdIdntfctn", required = true)
    protected PartyRoleType insrdIdntfctn;
    @XmlElement(name = "Rnk")
    protected BigInteger rnk;

    /**
     * Default no-arg constructor
     * 
     */
    public InsuredType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public InsuredType(final PartyRoleType insrdIdntfctn, final BigInteger rnk) {
        this.insrdIdntfctn = insrdIdntfctn;
        this.rnk = rnk;
    }

    /**
     * Gets the value of the insrdIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getInsrdIdntfctn() {
        return insrdIdntfctn;
    }

    /**
     * Sets the value of the insrdIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setInsrdIdntfctn(PartyRoleType value) {
        this.insrdIdntfctn = value;
    }

    public boolean isSetInsrdIdntfctn() {
        return (this.insrdIdntfctn!= null);
    }

    /**
     * Gets the value of the rnk property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getRnk() {
        return rnk;
    }

    /**
     * Sets the value of the rnk property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setRnk(BigInteger value) {
        this.rnk = value;
    }

    public boolean isSetRnk() {
        return (this.rnk!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("insrdIdntfctn", insrdIdntfctn).add("rnk", rnk).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(insrdIdntfctn, rnk);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final InsuredType o = ((InsuredType) other);
        return (Objects.equal(insrdIdntfctn, o.insrdIdntfctn)&&Objects.equal(rnk, o.rnk));
    }

}
