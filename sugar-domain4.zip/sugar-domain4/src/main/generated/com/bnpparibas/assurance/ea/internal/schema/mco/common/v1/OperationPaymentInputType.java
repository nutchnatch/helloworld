
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on operation payment
 * 				with information on the affectation and possibly the recipient of
 * 				the payment
 * 			
 * 
 * <p>Java class for OperationPaymentInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OperationPaymentInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PaymntData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationPaymentInstrumentDataInputType" minOccurs="0"/&gt;
 *         &lt;element name="OpePaymntAllctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationPaymentAllocationDataInputType" minOccurs="0"/&gt;
 *         &lt;element name="RecipintPrty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="SpecifRecipint" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PaymentSpecificRecipientType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OperationPaymentInputType", propOrder = {
    "paymntData",
    "opePaymntAllctn",
    "recipintPrty",
    "specifRecipint"
})
public class OperationPaymentInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PaymntData")
    protected OperationPaymentInstrumentDataInputType paymntData;
    @XmlElement(name = "OpePaymntAllctn")
    protected OperationPaymentAllocationDataInputType opePaymntAllctn;
    @XmlElement(name = "RecipintPrty")
    protected PartyRoleType recipintPrty;
    @XmlElement(name = "SpecifRecipint")
    protected PaymentSpecificRecipientType specifRecipint;

    /**
     * Default no-arg constructor
     * 
     */
    public OperationPaymentInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public OperationPaymentInputType(final OperationPaymentInstrumentDataInputType paymntData, final OperationPaymentAllocationDataInputType opePaymntAllctn, final PartyRoleType recipintPrty, final PaymentSpecificRecipientType specifRecipint) {
        this.paymntData = paymntData;
        this.opePaymntAllctn = opePaymntAllctn;
        this.recipintPrty = recipintPrty;
        this.specifRecipint = specifRecipint;
    }

    /**
     * Gets the value of the paymntData property.
     * 
     * @return
     *     possible object is
     *     {@link OperationPaymentInstrumentDataInputType }
     *     
     */
    public OperationPaymentInstrumentDataInputType getPaymntData() {
        return paymntData;
    }

    /**
     * Sets the value of the paymntData property.
     * 
     * @param value
     *     allowed object is
     *     {@link OperationPaymentInstrumentDataInputType }
     *     
     */
    public void setPaymntData(OperationPaymentInstrumentDataInputType value) {
        this.paymntData = value;
    }

    public boolean isSetPaymntData() {
        return (this.paymntData!= null);
    }

    /**
     * Gets the value of the opePaymntAllctn property.
     * 
     * @return
     *     possible object is
     *     {@link OperationPaymentAllocationDataInputType }
     *     
     */
    public OperationPaymentAllocationDataInputType getOpePaymntAllctn() {
        return opePaymntAllctn;
    }

    /**
     * Sets the value of the opePaymntAllctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link OperationPaymentAllocationDataInputType }
     *     
     */
    public void setOpePaymntAllctn(OperationPaymentAllocationDataInputType value) {
        this.opePaymntAllctn = value;
    }

    public boolean isSetOpePaymntAllctn() {
        return (this.opePaymntAllctn!= null);
    }

    /**
     * Gets the value of the recipintPrty property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getRecipintPrty() {
        return recipintPrty;
    }

    /**
     * Sets the value of the recipintPrty property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setRecipintPrty(PartyRoleType value) {
        this.recipintPrty = value;
    }

    public boolean isSetRecipintPrty() {
        return (this.recipintPrty!= null);
    }

    /**
     * Gets the value of the specifRecipint property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentSpecificRecipientType }
     *     
     */
    public PaymentSpecificRecipientType getSpecifRecipint() {
        return specifRecipint;
    }

    /**
     * Sets the value of the specifRecipint property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentSpecificRecipientType }
     *     
     */
    public void setSpecifRecipint(PaymentSpecificRecipientType value) {
        this.specifRecipint = value;
    }

    public boolean isSetSpecifRecipint() {
        return (this.specifRecipint!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("paymntData", paymntData).add("opePaymntAllctn", opePaymntAllctn).add("recipintPrty", recipintPrty).add("specifRecipint", specifRecipint).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(paymntData, opePaymntAllctn, recipintPrty, specifRecipint);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final OperationPaymentInputType o = ((OperationPaymentInputType) other);
        return (((Objects.equal(paymntData, o.paymntData)&&Objects.equal(opePaymntAllctn, o.opePaymntAllctn))&&Objects.equal(recipintPrty, o.recipintPrty))&&Objects.equal(specifRecipint, o.specifRecipint));
    }

}
