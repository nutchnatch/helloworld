
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Description of one
 * 				particular metadata.
 * 			
 * 
 * <p>Java class for MetadataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MetadataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SeqId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="CharEncdng" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CharacterEncodingCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="MetadataCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MetadataTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="UnivrslDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MetadataUnivrslDescriptionType" minOccurs="0"/&gt;
 *         &lt;element name="ValueEncapsltn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LosslessDataEncapsulationDescriptionType" minOccurs="0"/&gt;
 *         &lt;element name="InhrtdIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="Value" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ActualDataFlowContentType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MetadataType", propOrder = {
    "seqId",
    "charEncdng",
    "metadataCode",
    "univrslDesc",
    "valueEncapsltn",
    "inhrtdIndic",
    "value"
})
public class MetadataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SeqId")
    protected String seqId;
    @XmlElement(name = "CharEncdng")
    protected String charEncdng;
    @XmlElement(name = "MetadataCode")
    protected String metadataCode;
    @XmlElement(name = "UnivrslDesc")
    protected MetadataUnivrslDescriptionType univrslDesc;
    @XmlElement(name = "ValueEncapsltn")
    protected LosslessDataEncapsulationDescriptionType valueEncapsltn;
    @XmlElement(name = "InhrtdIndic")
    protected String inhrtdIndic;
    @XmlElement(name = "Value")
    protected ActualDataFlowContentType value;

    /**
     * Default no-arg constructor
     * 
     */
    public MetadataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MetadataType(final String seqId, final String charEncdng, final String metadataCode, final MetadataUnivrslDescriptionType univrslDesc, final LosslessDataEncapsulationDescriptionType valueEncapsltn, final String inhrtdIndic, final ActualDataFlowContentType value) {
        this.seqId = seqId;
        this.charEncdng = charEncdng;
        this.metadataCode = metadataCode;
        this.univrslDesc = univrslDesc;
        this.valueEncapsltn = valueEncapsltn;
        this.inhrtdIndic = inhrtdIndic;
        this.value = value;
    }

    /**
     * Gets the value of the seqId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqId() {
        return seqId;
    }

    /**
     * Sets the value of the seqId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqId(String value) {
        this.seqId = value;
    }

    public boolean isSetSeqId() {
        return (this.seqId!= null);
    }

    /**
     * Gets the value of the charEncdng property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCharEncdng() {
        return charEncdng;
    }

    /**
     * Sets the value of the charEncdng property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCharEncdng(String value) {
        this.charEncdng = value;
    }

    public boolean isSetCharEncdng() {
        return (this.charEncdng!= null);
    }

    /**
     * Gets the value of the metadataCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMetadataCode() {
        return metadataCode;
    }

    /**
     * Sets the value of the metadataCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMetadataCode(String value) {
        this.metadataCode = value;
    }

    public boolean isSetMetadataCode() {
        return (this.metadataCode!= null);
    }

    /**
     * Gets the value of the univrslDesc property.
     * 
     * @return
     *     possible object is
     *     {@link MetadataUnivrslDescriptionType }
     *     
     */
    public MetadataUnivrslDescriptionType getUnivrslDesc() {
        return univrslDesc;
    }

    /**
     * Sets the value of the univrslDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link MetadataUnivrslDescriptionType }
     *     
     */
    public void setUnivrslDesc(MetadataUnivrslDescriptionType value) {
        this.univrslDesc = value;
    }

    public boolean isSetUnivrslDesc() {
        return (this.univrslDesc!= null);
    }

    /**
     * Gets the value of the valueEncapsltn property.
     * 
     * @return
     *     possible object is
     *     {@link LosslessDataEncapsulationDescriptionType }
     *     
     */
    public LosslessDataEncapsulationDescriptionType getValueEncapsltn() {
        return valueEncapsltn;
    }

    /**
     * Sets the value of the valueEncapsltn property.
     * 
     * @param value
     *     allowed object is
     *     {@link LosslessDataEncapsulationDescriptionType }
     *     
     */
    public void setValueEncapsltn(LosslessDataEncapsulationDescriptionType value) {
        this.valueEncapsltn = value;
    }

    public boolean isSetValueEncapsltn() {
        return (this.valueEncapsltn!= null);
    }

    /**
     * Gets the value of the inhrtdIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInhrtdIndic() {
        return inhrtdIndic;
    }

    /**
     * Sets the value of the inhrtdIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInhrtdIndic(String value) {
        this.inhrtdIndic = value;
    }

    public boolean isSetInhrtdIndic() {
        return (this.inhrtdIndic!= null);
    }

    /**
     * Gets the value of the value property.
     * 
     * @return
     *     possible object is
     *     {@link ActualDataFlowContentType }
     *     
     */
    public ActualDataFlowContentType getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link ActualDataFlowContentType }
     *     
     */
    public void setValue(ActualDataFlowContentType value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return (this.value!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("seqId", seqId).add("charEncdng", charEncdng).add("metadataCode", metadataCode).add("univrslDesc", univrslDesc).add("valueEncapsltn", valueEncapsltn).add("inhrtdIndic", inhrtdIndic).add("value", value).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(seqId, charEncdng, metadataCode, univrslDesc, valueEncapsltn, inhrtdIndic, value);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MetadataType o = ((MetadataType) other);
        return ((((((Objects.equal(seqId, o.seqId)&&Objects.equal(charEncdng, o.charEncdng))&&Objects.equal(metadataCode, o.metadataCode))&&Objects.equal(univrslDesc, o.univrslDesc))&&Objects.equal(valueEncapsltn, o.valueEncapsltn))&&Objects.equal(inhrtdIndic, o.inhrtdIndic))&&Objects.equal(value, o.value));
    }

}
