
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;
import org.w3._2001.xmlschema.Adapter2;


/**
 * To manage global data of money in or money out
 * 				operation
 * 			
 * 
 * <p>Java class for MoneyInMoneyOutDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MoneyInMoneyOutDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SettlmntMode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SettlementModeCodeSLN"/&gt;
 *         &lt;element name="ProcessngMode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProcessingModeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="SlipRef" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="DocRef" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="SignDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="CardTrans" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CardTransactionDataType" minOccurs="0"/&gt;
 *         &lt;element name="EffctveDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountType"/&gt;
 *         &lt;element name="OpeCurr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MoneyInMoneyOutDataType", propOrder = {
    "settlmntMode",
    "processngMode",
    "slipRef",
    "docRef",
    "signDate",
    "cardTrans",
    "effctveDate",
    "amnt",
    "opeCurr"
})
public class MoneyInMoneyOutDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SettlmntMode", required = true)
    protected String settlmntMode;
    @XmlElement(name = "ProcessngMode")
    protected String processngMode;
    @XmlElement(name = "SlipRef")
    protected ObjectIdentificationType slipRef;
    @XmlElement(name = "DocRef")
    protected String docRef;
    @XmlElement(name = "SignDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date signDate;
    @XmlElement(name = "CardTrans")
    protected CardTransactionDataType cardTrans;
    @XmlElement(name = "EffctveDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date effctveDate;
    @XmlElement(name = "Amnt")
    protected double amnt;
    @XmlElement(name = "OpeCurr", required = true)
    protected String opeCurr;

    /**
     * Default no-arg constructor
     * 
     */
    public MoneyInMoneyOutDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MoneyInMoneyOutDataType(final String settlmntMode, final String processngMode, final ObjectIdentificationType slipRef, final String docRef, final Date signDate, final CardTransactionDataType cardTrans, final Date effctveDate, final double amnt, final String opeCurr) {
        this.settlmntMode = settlmntMode;
        this.processngMode = processngMode;
        this.slipRef = slipRef;
        this.docRef = docRef;
        this.signDate = signDate;
        this.cardTrans = cardTrans;
        this.effctveDate = effctveDate;
        this.amnt = amnt;
        this.opeCurr = opeCurr;
    }

    /**
     * Gets the value of the settlmntMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSettlmntMode() {
        return settlmntMode;
    }

    /**
     * Sets the value of the settlmntMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSettlmntMode(String value) {
        this.settlmntMode = value;
    }

    public boolean isSetSettlmntMode() {
        return (this.settlmntMode!= null);
    }

    /**
     * Gets the value of the processngMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProcessngMode() {
        return processngMode;
    }

    /**
     * Sets the value of the processngMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProcessngMode(String value) {
        this.processngMode = value;
    }

    public boolean isSetProcessngMode() {
        return (this.processngMode!= null);
    }

    /**
     * Gets the value of the slipRef property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getSlipRef() {
        return slipRef;
    }

    /**
     * Sets the value of the slipRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setSlipRef(ObjectIdentificationType value) {
        this.slipRef = value;
    }

    public boolean isSetSlipRef() {
        return (this.slipRef!= null);
    }

    /**
     * Gets the value of the docRef property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocRef() {
        return docRef;
    }

    /**
     * Sets the value of the docRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocRef(String value) {
        this.docRef = value;
    }

    public boolean isSetDocRef() {
        return (this.docRef!= null);
    }

    /**
     * Gets the value of the signDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getSignDate() {
        return signDate;
    }

    /**
     * Sets the value of the signDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSignDate(Date value) {
        this.signDate = value;
    }

    public boolean isSetSignDate() {
        return (this.signDate!= null);
    }

    /**
     * Gets the value of the cardTrans property.
     * 
     * @return
     *     possible object is
     *     {@link CardTransactionDataType }
     *     
     */
    public CardTransactionDataType getCardTrans() {
        return cardTrans;
    }

    /**
     * Sets the value of the cardTrans property.
     * 
     * @param value
     *     allowed object is
     *     {@link CardTransactionDataType }
     *     
     */
    public void setCardTrans(CardTransactionDataType value) {
        this.cardTrans = value;
    }

    public boolean isSetCardTrans() {
        return (this.cardTrans!= null);
    }

    /**
     * Gets the value of the effctveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getEffctveDate() {
        return effctveDate;
    }

    /**
     * Sets the value of the effctveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEffctveDate(Date value) {
        this.effctveDate = value;
    }

    public boolean isSetEffctveDate() {
        return (this.effctveDate!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     */
    public double getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     */
    public void setAmnt(double value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return true;
    }

    /**
     * Gets the value of the opeCurr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpeCurr() {
        return opeCurr;
    }

    /**
     * Sets the value of the opeCurr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpeCurr(String value) {
        this.opeCurr = value;
    }

    public boolean isSetOpeCurr() {
        return (this.opeCurr!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("settlmntMode", settlmntMode).add("processngMode", processngMode).add("slipRef", slipRef).add("docRef", docRef).add("signDate", signDate).add("cardTrans", cardTrans).add("effctveDate", effctveDate).add("amnt", amnt).add("opeCurr", opeCurr).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(settlmntMode, processngMode, slipRef, docRef, signDate, cardTrans, effctveDate, amnt, opeCurr);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MoneyInMoneyOutDataType o = ((MoneyInMoneyOutDataType) other);
        return ((((((((Objects.equal(settlmntMode, o.settlmntMode)&&Objects.equal(processngMode, o.processngMode))&&Objects.equal(slipRef, o.slipRef))&&Objects.equal(docRef, o.docRef))&&Objects.equal(signDate, o.signDate))&&Objects.equal(cardTrans, o.cardTrans))&&Objects.equal(effctveDate, o.effctveDate))&&Objects.equal(amnt, o.amnt))&&Objects.equal(opeCurr, o.opeCurr));
    }

}
