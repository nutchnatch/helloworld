
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information for the communication
 * 				with the party
 * 			
 * 
 * <p>Java class for PartyManagementInformationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartyManagementInformationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Lang" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LocalType" minOccurs="0"/&gt;
 *         &lt;element name="ActvIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyManagementInformationType", propOrder = {
    "lang",
    "actvIndic"
})
public class PartyManagementInformationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Lang")
    protected LocalType lang;
    @XmlElement(name = "ActvIndic")
    protected String actvIndic;

    /**
     * Default no-arg constructor
     * 
     */
    public PartyManagementInformationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PartyManagementInformationType(final LocalType lang, final String actvIndic) {
        this.lang = lang;
        this.actvIndic = actvIndic;
    }

    /**
     * Gets the value of the lang property.
     * 
     * @return
     *     possible object is
     *     {@link LocalType }
     *     
     */
    public LocalType getLang() {
        return lang;
    }

    /**
     * Sets the value of the lang property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocalType }
     *     
     */
    public void setLang(LocalType value) {
        this.lang = value;
    }

    public boolean isSetLang() {
        return (this.lang!= null);
    }

    /**
     * Gets the value of the actvIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActvIndic() {
        return actvIndic;
    }

    /**
     * Sets the value of the actvIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActvIndic(String value) {
        this.actvIndic = value;
    }

    public boolean isSetActvIndic() {
        return (this.actvIndic!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("lang", lang).add("actvIndic", actvIndic).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(lang, actvIndic);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PartyManagementInformationType o = ((PartyManagementInformationType) other);
        return (Objects.equal(lang, o.lang)&&Objects.equal(actvIndic, o.actvIndic));
    }

}
