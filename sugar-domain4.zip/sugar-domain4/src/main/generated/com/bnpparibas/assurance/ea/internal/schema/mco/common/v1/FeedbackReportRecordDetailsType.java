
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * Feedback report record
 * 				details.
 * 			
 * 
 * <p>Java class for FeedbackReportRecordDetailsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FeedbackReportRecordDetailsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Severity" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MessageSeverityLevelCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="StdCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeedbackErrorTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="StdDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType" minOccurs="0"/&gt;
 *         &lt;element name="SpecifCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="SpecifDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ExtendedDescriptionType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Col" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IntervalType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Timestamp" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FeedbackReportRecordDetailsType", propOrder = {
    "severity",
    "stdCode",
    "stdDesc",
    "specifCode",
    "specifDesc",
    "col",
    "timestamp"
})
public class FeedbackReportRecordDetailsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Severity")
    protected String severity;
    @XmlElement(name = "StdCode")
    protected String stdCode;
    @XmlElement(name = "StdDesc")
    protected String stdDesc;
    @XmlElement(name = "SpecifCode")
    protected String specifCode;
    @XmlElement(name = "SpecifDesc")
    protected List<ExtendedDescriptionType> specifDesc;
    @XmlElement(name = "Col")
    protected List<IntervalType> col;
    @XmlElement(name = "Timestamp", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date timestamp;

    /**
     * Default no-arg constructor
     * 
     */
    public FeedbackReportRecordDetailsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FeedbackReportRecordDetailsType(final String severity, final String stdCode, final String stdDesc, final String specifCode, final List<ExtendedDescriptionType> specifDesc, final List<IntervalType> col, final Date timestamp) {
        this.severity = severity;
        this.stdCode = stdCode;
        this.stdDesc = stdDesc;
        this.specifCode = specifCode;
        this.specifDesc = specifDesc;
        this.col = col;
        this.timestamp = timestamp;
    }

    /**
     * Gets the value of the severity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeverity() {
        return severity;
    }

    /**
     * Sets the value of the severity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeverity(String value) {
        this.severity = value;
    }

    public boolean isSetSeverity() {
        return (this.severity!= null);
    }

    /**
     * Gets the value of the stdCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStdCode() {
        return stdCode;
    }

    /**
     * Sets the value of the stdCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStdCode(String value) {
        this.stdCode = value;
    }

    public boolean isSetStdCode() {
        return (this.stdCode!= null);
    }

    /**
     * Gets the value of the stdDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStdDesc() {
        return stdDesc;
    }

    /**
     * Sets the value of the stdDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStdDesc(String value) {
        this.stdDesc = value;
    }

    public boolean isSetStdDesc() {
        return (this.stdDesc!= null);
    }

    /**
     * Gets the value of the specifCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpecifCode() {
        return specifCode;
    }

    /**
     * Sets the value of the specifCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpecifCode(String value) {
        this.specifCode = value;
    }

    public boolean isSetSpecifCode() {
        return (this.specifCode!= null);
    }

    /**
     * Gets the value of the specifDesc property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the specifDesc property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSpecifDesc().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ExtendedDescriptionType }
     * 
     * 
     */
    public List<ExtendedDescriptionType> getSpecifDesc() {
        if (specifDesc == null) {
            specifDesc = new ArrayList<ExtendedDescriptionType>();
        }
        return this.specifDesc;
    }

    public boolean isSetSpecifDesc() {
        return ((this.specifDesc!= null)&&(!this.specifDesc.isEmpty()));
    }

    public void unsetSpecifDesc() {
        this.specifDesc = null;
    }

    /**
     * Gets the value of the col property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the col property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCol().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IntervalType }
     * 
     * 
     */
    public List<IntervalType> getCol() {
        if (col == null) {
            col = new ArrayList<IntervalType>();
        }
        return this.col;
    }

    public boolean isSetCol() {
        return ((this.col!= null)&&(!this.col.isEmpty()));
    }

    public void unsetCol() {
        this.col = null;
    }

    /**
     * Gets the value of the timestamp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getTimestamp() {
        return timestamp;
    }

    /**
     * Sets the value of the timestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTimestamp(Date value) {
        this.timestamp = value;
    }

    public boolean isSetTimestamp() {
        return (this.timestamp!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("severity", severity).add("stdCode", stdCode).add("stdDesc", stdDesc).add("specifCode", specifCode).add("specifDesc", specifDesc).add("col", col).add("timestamp", timestamp).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(severity, stdCode, stdDesc, specifCode, specifDesc, col, timestamp);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FeedbackReportRecordDetailsType o = ((FeedbackReportRecordDetailsType) other);
        return ((((((Objects.equal(severity, o.severity)&&Objects.equal(stdCode, o.stdCode))&&Objects.equal(stdDesc, o.stdDesc))&&Objects.equal(specifCode, o.specifCode))&&Objects.equal(specifDesc, o.specifDesc))&&Objects.equal(col, o.col))&&Objects.equal(timestamp, o.timestamp));
    }

}
