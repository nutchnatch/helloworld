
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Payment card data
 * 
 * <p>Java class for PaymentCardDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PaymentCardDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Numb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PaymentCardType"/&gt;
 *         &lt;element name="HoldrName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="ValdtyEndDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="IssuerName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="CreditLimitAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="ChckDgit" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CardCheckDigitType" minOccurs="0"/&gt;
 *         &lt;element name="CardType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CardTypeCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PaymentCardDataType", propOrder = {
    "numb",
    "holdrName",
    "valdtyEndDate",
    "issuerName",
    "creditLimitAmnt",
    "chckDgit",
    "cardType"
})
public class PaymentCardDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Numb", required = true)
    protected String numb;
    @XmlElement(name = "HoldrName")
    protected String holdrName;
    @XmlElement(name = "ValdtyEndDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date valdtyEndDate;
    @XmlElement(name = "IssuerName")
    protected String issuerName;
    @XmlElement(name = "CreditLimitAmnt")
    protected CurrencyAndAmountType creditLimitAmnt;
    @XmlElement(name = "ChckDgit")
    protected String chckDgit;
    @XmlElement(name = "CardType")
    protected String cardType;

    /**
     * Default no-arg constructor
     * 
     */
    public PaymentCardDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PaymentCardDataType(final String numb, final String holdrName, final Date valdtyEndDate, final String issuerName, final CurrencyAndAmountType creditLimitAmnt, final String chckDgit, final String cardType) {
        this.numb = numb;
        this.holdrName = holdrName;
        this.valdtyEndDate = valdtyEndDate;
        this.issuerName = issuerName;
        this.creditLimitAmnt = creditLimitAmnt;
        this.chckDgit = chckDgit;
        this.cardType = cardType;
    }

    /**
     * Gets the value of the numb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumb() {
        return numb;
    }

    /**
     * Sets the value of the numb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumb(String value) {
        this.numb = value;
    }

    public boolean isSetNumb() {
        return (this.numb!= null);
    }

    /**
     * Gets the value of the holdrName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHoldrName() {
        return holdrName;
    }

    /**
     * Sets the value of the holdrName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHoldrName(String value) {
        this.holdrName = value;
    }

    public boolean isSetHoldrName() {
        return (this.holdrName!= null);
    }

    /**
     * Gets the value of the valdtyEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getValdtyEndDate() {
        return valdtyEndDate;
    }

    /**
     * Sets the value of the valdtyEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValdtyEndDate(Date value) {
        this.valdtyEndDate = value;
    }

    public boolean isSetValdtyEndDate() {
        return (this.valdtyEndDate!= null);
    }

    /**
     * Gets the value of the issuerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssuerName() {
        return issuerName;
    }

    /**
     * Sets the value of the issuerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssuerName(String value) {
        this.issuerName = value;
    }

    public boolean isSetIssuerName() {
        return (this.issuerName!= null);
    }

    /**
     * Gets the value of the creditLimitAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getCreditLimitAmnt() {
        return creditLimitAmnt;
    }

    /**
     * Sets the value of the creditLimitAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setCreditLimitAmnt(CurrencyAndAmountType value) {
        this.creditLimitAmnt = value;
    }

    public boolean isSetCreditLimitAmnt() {
        return (this.creditLimitAmnt!= null);
    }

    /**
     * Gets the value of the chckDgit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChckDgit() {
        return chckDgit;
    }

    /**
     * Sets the value of the chckDgit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChckDgit(String value) {
        this.chckDgit = value;
    }

    public boolean isSetChckDgit() {
        return (this.chckDgit!= null);
    }

    /**
     * Gets the value of the cardType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardType() {
        return cardType;
    }

    /**
     * Sets the value of the cardType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardType(String value) {
        this.cardType = value;
    }

    public boolean isSetCardType() {
        return (this.cardType!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("numb", numb).add("holdrName", holdrName).add("valdtyEndDate", valdtyEndDate).add("issuerName", issuerName).add("creditLimitAmnt", creditLimitAmnt).add("chckDgit", chckDgit).add("cardType", cardType).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(numb, holdrName, valdtyEndDate, issuerName, creditLimitAmnt, chckDgit, cardType);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PaymentCardDataType o = ((PaymentCardDataType) other);
        return ((((((Objects.equal(numb, o.numb)&&Objects.equal(holdrName, o.holdrName))&&Objects.equal(valdtyEndDate, o.valdtyEndDate))&&Objects.equal(issuerName, o.issuerName))&&Objects.equal(creditLimitAmnt, o.creditLimitAmnt))&&Objects.equal(chckDgit, o.chckDgit))&&Objects.equal(cardType, o.cardType));
    }

}
