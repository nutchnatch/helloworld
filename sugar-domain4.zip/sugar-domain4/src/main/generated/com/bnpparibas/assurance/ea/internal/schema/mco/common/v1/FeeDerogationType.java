
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on the fees derogation
 * 			
 * 
 * <p>Java class for FeeDerogationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FeeDerogationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DerogtnIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeesCodeSLN"/&gt;
 *         &lt;element name="Status" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FeesCharacterCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="PrcntageRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" minOccurs="0"/&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="ValdtyPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OptionalDatePeriodType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FeeDerogationType", propOrder = {
    "derogtnIdntfctn",
    "type",
    "status",
    "prcntageRate",
    "amnt",
    "valdtyPrd"
})
public class FeeDerogationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "DerogtnIdntfctn")
    protected ObjectIdentificationType derogtnIdntfctn;
    @XmlElement(name = "Type", required = true)
    protected String type;
    @XmlElement(name = "Status")
    protected String status;
    @XmlElement(name = "PrcntageRate")
    protected Double prcntageRate;
    @XmlElement(name = "Amnt")
    protected CurrencyAndAmountType amnt;
    @XmlElement(name = "ValdtyPrd")
    protected OptionalDatePeriodType valdtyPrd;

    /**
     * Default no-arg constructor
     * 
     */
    public FeeDerogationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FeeDerogationType(final ObjectIdentificationType derogtnIdntfctn, final String type, final String status, final Double prcntageRate, final CurrencyAndAmountType amnt, final OptionalDatePeriodType valdtyPrd) {
        this.derogtnIdntfctn = derogtnIdntfctn;
        this.type = type;
        this.status = status;
        this.prcntageRate = prcntageRate;
        this.amnt = amnt;
        this.valdtyPrd = valdtyPrd;
    }

    /**
     * Gets the value of the derogtnIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getDerogtnIdntfctn() {
        return derogtnIdntfctn;
    }

    /**
     * Sets the value of the derogtnIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setDerogtnIdntfctn(ObjectIdentificationType value) {
        this.derogtnIdntfctn = value;
    }

    public boolean isSetDerogtnIdntfctn() {
        return (this.derogtnIdntfctn!= null);
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    public boolean isSetType() {
        return (this.type!= null);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    public boolean isSetStatus() {
        return (this.status!= null);
    }

    /**
     * Gets the value of the prcntageRate property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getPrcntageRate() {
        return prcntageRate;
    }

    /**
     * Sets the value of the prcntageRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setPrcntageRate(Double value) {
        this.prcntageRate = value;
    }

    public boolean isSetPrcntageRate() {
        return (this.prcntageRate!= null);
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    /**
     * Gets the value of the valdtyPrd property.
     * 
     * @return
     *     possible object is
     *     {@link OptionalDatePeriodType }
     *     
     */
    public OptionalDatePeriodType getValdtyPrd() {
        return valdtyPrd;
    }

    /**
     * Sets the value of the valdtyPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link OptionalDatePeriodType }
     *     
     */
    public void setValdtyPrd(OptionalDatePeriodType value) {
        this.valdtyPrd = value;
    }

    public boolean isSetValdtyPrd() {
        return (this.valdtyPrd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("derogtnIdntfctn", derogtnIdntfctn).add("type", type).add("status", status).add("prcntageRate", prcntageRate).add("amnt", amnt).add("valdtyPrd", valdtyPrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(derogtnIdntfctn, type, status, prcntageRate, amnt, valdtyPrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FeeDerogationType o = ((FeeDerogationType) other);
        return (((((Objects.equal(derogtnIdntfctn, o.derogtnIdntfctn)&&Objects.equal(type, o.type))&&Objects.equal(status, o.status))&&Objects.equal(prcntageRate, o.prcntageRate))&&Objects.equal(amnt, o.amnt))&&Objects.equal(valdtyPrd, o.valdtyPrd));
    }

}
