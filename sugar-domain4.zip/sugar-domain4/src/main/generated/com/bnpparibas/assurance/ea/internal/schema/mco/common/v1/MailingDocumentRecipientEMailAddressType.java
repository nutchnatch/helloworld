
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage the Email address of a recipient of
 * 				a mailing
 * 			
 * 
 * <p>Java class for MailingDocumentRecipientEMailAddressType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MailingDocumentRecipientEMailAddressType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DestntnType"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;maxLength value="50"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Adrs" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}EmailAddressInputType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MailingDocumentRecipientEMailAddressType", propOrder = {
    "destntnType",
    "adrs"
})
public class MailingDocumentRecipientEMailAddressType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "DestntnType", required = true)
    protected String destntnType;
    @XmlElement(name = "Adrs", required = true)
    protected EmailAddressInputType adrs;

    /**
     * Default no-arg constructor
     * 
     */
    public MailingDocumentRecipientEMailAddressType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MailingDocumentRecipientEMailAddressType(final String destntnType, final EmailAddressInputType adrs) {
        this.destntnType = destntnType;
        this.adrs = adrs;
    }

    /**
     * Gets the value of the destntnType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestntnType() {
        return destntnType;
    }

    /**
     * Sets the value of the destntnType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestntnType(String value) {
        this.destntnType = value;
    }

    public boolean isSetDestntnType() {
        return (this.destntnType!= null);
    }

    /**
     * Gets the value of the adrs property.
     * 
     * @return
     *     possible object is
     *     {@link EmailAddressInputType }
     *     
     */
    public EmailAddressInputType getAdrs() {
        return adrs;
    }

    /**
     * Sets the value of the adrs property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmailAddressInputType }
     *     
     */
    public void setAdrs(EmailAddressInputType value) {
        this.adrs = value;
    }

    public boolean isSetAdrs() {
        return (this.adrs!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("destntnType", destntnType).add("adrs", adrs).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(destntnType, adrs);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MailingDocumentRecipientEMailAddressType o = ((MailingDocumentRecipientEMailAddressType) other);
        return (Objects.equal(destntnType, o.destntnType)&&Objects.equal(adrs, o.adrs));
    }

}
