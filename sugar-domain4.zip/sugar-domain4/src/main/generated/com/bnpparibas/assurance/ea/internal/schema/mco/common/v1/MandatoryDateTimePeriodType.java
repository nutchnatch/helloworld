
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * mandatory date time period
 * 
 * <p>Java class for MandatoryDateTimePeriodType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MandatoryDateTimePeriodType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FromDateTime" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType"/&gt;
 *         &lt;element name="ToDateTime" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MandatoryDateTimePeriodType", propOrder = {
    "fromDateTime",
    "toDateTime"
})
public class MandatoryDateTimePeriodType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "FromDateTime", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date fromDateTime;
    @XmlElement(name = "ToDateTime", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date toDateTime;

    /**
     * Default no-arg constructor
     * 
     */
    public MandatoryDateTimePeriodType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MandatoryDateTimePeriodType(final Date fromDateTime, final Date toDateTime) {
        this.fromDateTime = fromDateTime;
        this.toDateTime = toDateTime;
    }

    /**
     * Gets the value of the fromDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getFromDateTime() {
        return fromDateTime;
    }

    /**
     * Sets the value of the fromDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFromDateTime(Date value) {
        this.fromDateTime = value;
    }

    public boolean isSetFromDateTime() {
        return (this.fromDateTime!= null);
    }

    /**
     * Gets the value of the toDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getToDateTime() {
        return toDateTime;
    }

    /**
     * Sets the value of the toDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToDateTime(Date value) {
        this.toDateTime = value;
    }

    public boolean isSetToDateTime() {
        return (this.toDateTime!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("fromDateTime", fromDateTime).add("toDateTime", toDateTime).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(fromDateTime, toDateTime);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MandatoryDateTimePeriodType o = ((MandatoryDateTimePeriodType) other);
        return (Objects.equal(fromDateTime, o.fromDateTime)&&Objects.equal(toDateTime, o.toDateTime));
    }

}
