
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import com.google.common.base.Objects;


/**
 * Local=Language + country ( US EN, CND FR )
 * 			
 * 
 * <p>Java class for LocalType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LocalType"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1&gt;LanguageCode"&gt;
 *       &lt;attribute name="Cntry" use="required" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CountryCodeSLN" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LocalType", propOrder = {
    "value"
})
public class LocalType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlValue
    protected String value;
    @XmlAttribute(name = "Cntry", required = true)
    protected String cntry;

    /**
     * Default no-arg constructor
     * 
     */
    public LocalType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public LocalType(final String value, final String cntry) {
        this.value = value;
        this.cntry = cntry;
    }

    /**
     * The language in which all the communication should
     * 				be done for this account
     * 			
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValue(String value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return (this.value!= null);
    }

    /**
     * Gets the value of the cntry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCntry() {
        return cntry;
    }

    /**
     * Sets the value of the cntry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCntry(String value) {
        this.cntry = value;
    }

    public boolean isSetCntry() {
        return (this.cntry!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("value", value).add("cntry", cntry).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(value, cntry);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final LocalType o = ((LocalType) other);
        return (Objects.equal(value, o.value)&&Objects.equal(cntry, o.cntry));
    }

}
