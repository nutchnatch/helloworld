
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on the stages of a loan
 * 			
 * 
 * <p>Java class for LoanStageDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LoanStageDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Amnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType"/&gt;
 *         &lt;element name="Duratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType"/&gt;
 *         &lt;element name="SeqId" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LoanStageDataType", propOrder = {
    "amnt",
    "duratn",
    "seqId"
})
public class LoanStageDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Amnt", required = true)
    protected CurrencyAndAmountType amnt;
    @XmlElement(name = "Duratn", required = true)
    protected DurationType duratn;
    @XmlElement(name = "SeqId")
    protected String seqId;

    /**
     * Default no-arg constructor
     * 
     */
    public LoanStageDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public LoanStageDataType(final CurrencyAndAmountType amnt, final DurationType duratn, final String seqId) {
        this.amnt = amnt;
        this.duratn = duratn;
        this.seqId = seqId;
    }

    /**
     * Gets the value of the amnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAmnt() {
        return amnt;
    }

    /**
     * Sets the value of the amnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAmnt(CurrencyAndAmountType value) {
        this.amnt = value;
    }

    public boolean isSetAmnt() {
        return (this.amnt!= null);
    }

    /**
     * Gets the value of the duratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getDuratn() {
        return duratn;
    }

    /**
     * Sets the value of the duratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setDuratn(DurationType value) {
        this.duratn = value;
    }

    public boolean isSetDuratn() {
        return (this.duratn!= null);
    }

    /**
     * Gets the value of the seqId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSeqId() {
        return seqId;
    }

    /**
     * Sets the value of the seqId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSeqId(String value) {
        this.seqId = value;
    }

    public boolean isSetSeqId() {
        return (this.seqId!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("amnt", amnt).add("duratn", duratn).add("seqId", seqId).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(amnt, duratn, seqId);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final LoanStageDataType o = ((LoanStageDataType) other);
        return ((Objects.equal(amnt, o.amnt)&&Objects.equal(duratn, o.duratn))&&Objects.equal(seqId, o.seqId));
    }

}
