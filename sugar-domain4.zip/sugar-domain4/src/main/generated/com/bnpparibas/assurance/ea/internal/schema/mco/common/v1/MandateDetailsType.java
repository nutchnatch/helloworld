
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Données de détail du(des)
 * 				mandat(s)
 * 			
 * 
 * <p>Java class for MandateDetailsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MandateDetailsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Idntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="Mode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProxyModeCodeSLN"/&gt;
 *         &lt;element name="PrtyRole" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="OpeType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationTypeCodeSLN" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Prd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MandateDetailsType", propOrder = {
    "idntfctn",
    "mode",
    "prtyRole",
    "opeType",
    "prd"
})
public class MandateDetailsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Idntfctn", required = true)
    protected ObjectIdentificationType idntfctn;
    @XmlElement(name = "Mode", required = true)
    protected String mode;
    @XmlElement(name = "PrtyRole")
    protected PartyRoleType prtyRole;
    @XmlElement(name = "OpeType")
    protected List<String> opeType;
    @XmlElement(name = "Prd")
    protected DatePeriodType prd;

    /**
     * Default no-arg constructor
     * 
     */
    public MandateDetailsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MandateDetailsType(final ObjectIdentificationType idntfctn, final String mode, final PartyRoleType prtyRole, final List<String> opeType, final DatePeriodType prd) {
        this.idntfctn = idntfctn;
        this.mode = mode;
        this.prtyRole = prtyRole;
        this.opeType = opeType;
        this.prd = prd;
    }

    /**
     * Gets the value of the idntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getIdntfctn() {
        return idntfctn;
    }

    /**
     * Sets the value of the idntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setIdntfctn(ObjectIdentificationType value) {
        this.idntfctn = value;
    }

    public boolean isSetIdntfctn() {
        return (this.idntfctn!= null);
    }

    /**
     * Gets the value of the mode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMode() {
        return mode;
    }

    /**
     * Sets the value of the mode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMode(String value) {
        this.mode = value;
    }

    public boolean isSetMode() {
        return (this.mode!= null);
    }

    /**
     * Gets the value of the prtyRole property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrtyRole() {
        return prtyRole;
    }

    /**
     * Sets the value of the prtyRole property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrtyRole(PartyRoleType value) {
        this.prtyRole = value;
    }

    public boolean isSetPrtyRole() {
        return (this.prtyRole!= null);
    }

    /**
     * Gets the value of the opeType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the opeType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOpeType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getOpeType() {
        if (opeType == null) {
            opeType = new ArrayList<String>();
        }
        return this.opeType;
    }

    public boolean isSetOpeType() {
        return ((this.opeType!= null)&&(!this.opeType.isEmpty()));
    }

    public void unsetOpeType() {
        this.opeType = null;
    }

    /**
     * Gets the value of the prd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getPrd() {
        return prd;
    }

    /**
     * Sets the value of the prd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setPrd(DatePeriodType value) {
        this.prd = value;
    }

    public boolean isSetPrd() {
        return (this.prd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("idntfctn", idntfctn).add("mode", mode).add("prtyRole", prtyRole).add("opeType", opeType).add("prd", prd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(idntfctn, mode, prtyRole, opeType, prd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MandateDetailsType o = ((MandateDetailsType) other);
        return ((((Objects.equal(idntfctn, o.idntfctn)&&Objects.equal(mode, o.mode))&&Objects.equal(prtyRole, o.prtyRole))&&Objects.equal(opeType, o.opeType))&&Objects.equal(prd, o.prd));
    }

}
