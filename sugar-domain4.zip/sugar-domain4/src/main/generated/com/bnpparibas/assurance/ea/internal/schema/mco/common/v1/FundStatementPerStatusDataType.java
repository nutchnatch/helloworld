
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data for fund statement per status
 * 			
 * 
 * <p>Java class for FundStatementPerStatusDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FundStatementPerStatusDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Code" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MovementStatusCodeSLN"/&gt;
 *         &lt;element name="Statmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FundStatementDataType" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FundStatementPerStatusDataType", propOrder = {
    "code",
    "statmnt"
})
public class FundStatementPerStatusDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Code", required = true)
    protected String code;
    @XmlElement(name = "Statmnt", required = true)
    protected List<FundStatementDataType> statmnt;

    /**
     * Default no-arg constructor
     * 
     */
    public FundStatementPerStatusDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FundStatementPerStatusDataType(final String code, final List<FundStatementDataType> statmnt) {
        this.code = code;
        this.statmnt = statmnt;
    }

    /**
     * Gets the value of the code property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCode(String value) {
        this.code = value;
    }

    public boolean isSetCode() {
        return (this.code!= null);
    }

    /**
     * Gets the value of the statmnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the statmnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStatmnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FundStatementDataType }
     * 
     * 
     */
    public List<FundStatementDataType> getStatmnt() {
        if (statmnt == null) {
            statmnt = new ArrayList<FundStatementDataType>();
        }
        return this.statmnt;
    }

    public boolean isSetStatmnt() {
        return ((this.statmnt!= null)&&(!this.statmnt.isEmpty()));
    }

    public void unsetStatmnt() {
        this.statmnt = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("code", code).add("statmnt", statmnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(code, statmnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FundStatementPerStatusDataType o = ((FundStatementPerStatusDataType) other);
        return (Objects.equal(code, o.code)&&Objects.equal(statmnt, o.statmnt));
    }

}
