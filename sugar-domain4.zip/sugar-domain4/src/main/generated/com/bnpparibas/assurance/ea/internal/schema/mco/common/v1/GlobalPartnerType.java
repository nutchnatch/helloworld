
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 *  global distribution
 * 				partner of products
 * 			
 * 
 * <p>Java class for GlobalPartnerType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GlobalPartnerType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Idntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="ShortLbl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
 *         &lt;element name="LongLbl" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LongNameType" minOccurs="0"/&gt;
 *         &lt;element name="Desc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DescriptionType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GlobalPartnerType", propOrder = {
    "idntfctn",
    "shortLbl",
    "longLbl",
    "desc"
})
public class GlobalPartnerType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Idntfctn", required = true)
    protected ObjectIdentificationType idntfctn;
    @XmlElement(name = "ShortLbl", required = true)
    protected String shortLbl;
    @XmlElement(name = "LongLbl")
    protected String longLbl;
    @XmlElement(name = "Desc")
    protected String desc;

    /**
     * Default no-arg constructor
     * 
     */
    public GlobalPartnerType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public GlobalPartnerType(final ObjectIdentificationType idntfctn, final String shortLbl, final String longLbl, final String desc) {
        this.idntfctn = idntfctn;
        this.shortLbl = shortLbl;
        this.longLbl = longLbl;
        this.desc = desc;
    }

    /**
     * Gets the value of the idntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getIdntfctn() {
        return idntfctn;
    }

    /**
     * Sets the value of the idntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setIdntfctn(ObjectIdentificationType value) {
        this.idntfctn = value;
    }

    public boolean isSetIdntfctn() {
        return (this.idntfctn!= null);
    }

    /**
     * Gets the value of the shortLbl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShortLbl() {
        return shortLbl;
    }

    /**
     * Sets the value of the shortLbl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShortLbl(String value) {
        this.shortLbl = value;
    }

    public boolean isSetShortLbl() {
        return (this.shortLbl!= null);
    }

    /**
     * Gets the value of the longLbl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLongLbl() {
        return longLbl;
    }

    /**
     * Sets the value of the longLbl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLongLbl(String value) {
        this.longLbl = value;
    }

    public boolean isSetLongLbl() {
        return (this.longLbl!= null);
    }

    /**
     * Gets the value of the desc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDesc() {
        return desc;
    }

    /**
     * Sets the value of the desc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDesc(String value) {
        this.desc = value;
    }

    public boolean isSetDesc() {
        return (this.desc!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("idntfctn", idntfctn).add("shortLbl", shortLbl).add("longLbl", longLbl).add("desc", desc).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(idntfctn, shortLbl, longLbl, desc);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final GlobalPartnerType o = ((GlobalPartnerType) other);
        return (((Objects.equal(idntfctn, o.idntfctn)&&Objects.equal(shortLbl, o.shortLbl))&&Objects.equal(longLbl, o.longLbl))&&Objects.equal(desc, o.desc));
    }

}
