
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import com.google.common.base.Objects;


/**
 * Represents a metadata from the catalogue with
 * 				additional optional attributes to further qualify the metadata
 * 				provider (namely: an Issuer and a Scheme).
 * 			
 * 
 * <p>Java class for EmbeddedCatalogueMetadataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EmbeddedCatalogueMetadataType"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1&gt;MetadataTypeCodeSLN"&gt;
 *       &lt;attribute name="Issuer" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IssuerCodeSLN" /&gt;
 *       &lt;attribute name="Scheme" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SchemeCodeSLN" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EmbeddedCatalogueMetadataType", propOrder = {
    "value"
})
public class EmbeddedCatalogueMetadataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlValue
    protected String value;
    @XmlAttribute(name = "Issuer")
    protected String issuer;
    @XmlAttribute(name = "Scheme")
    protected String scheme;

    /**
     * Default no-arg constructor
     * 
     */
    public EmbeddedCatalogueMetadataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public EmbeddedCatalogueMetadataType(final String value, final String issuer, final String scheme) {
        this.value = value;
        this.issuer = issuer;
        this.scheme = scheme;
    }

    /**
     * Codification of metadata
     * 				types: customer name, client birth date, ...
     * 			
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValue(String value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return (this.value!= null);
    }

    /**
     * Gets the value of the issuer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssuer() {
        return issuer;
    }

    /**
     * Sets the value of the issuer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssuer(String value) {
        this.issuer = value;
    }

    public boolean isSetIssuer() {
        return (this.issuer!= null);
    }

    /**
     * Gets the value of the scheme property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScheme() {
        return scheme;
    }

    /**
     * Sets the value of the scheme property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScheme(String value) {
        this.scheme = value;
    }

    public boolean isSetScheme() {
        return (this.scheme!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("value", value).add("issuer", issuer).add("scheme", scheme).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(value, issuer, scheme);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final EmbeddedCatalogueMetadataType o = ((EmbeddedCatalogueMetadataType) other);
        return ((Objects.equal(value, o.value)&&Objects.equal(issuer, o.issuer))&&Objects.equal(scheme, o.scheme));
    }

}
