
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Role party link
 * 
 * <p>Java class for PartyRoleType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartyRoleType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PrtyIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="Role" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}RoleCodeSLN"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyRoleType", propOrder = {
    "prtyIdntfctn",
    "role"
})
public class PartyRoleType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "PrtyIdntfctn", required = true)
    protected ObjectIdentificationType prtyIdntfctn;
    @XmlElement(name = "Role", required = true)
    protected String role;

    /**
     * Default no-arg constructor
     * 
     */
    public PartyRoleType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PartyRoleType(final ObjectIdentificationType prtyIdntfctn, final String role) {
        this.prtyIdntfctn = prtyIdntfctn;
        this.role = role;
    }

    /**
     * Gets the value of the prtyIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPrtyIdntfctn() {
        return prtyIdntfctn;
    }

    /**
     * Sets the value of the prtyIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPrtyIdntfctn(ObjectIdentificationType value) {
        this.prtyIdntfctn = value;
    }

    public boolean isSetPrtyIdntfctn() {
        return (this.prtyIdntfctn!= null);
    }

    /**
     * Gets the value of the role property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRole() {
        return role;
    }

    /**
     * Sets the value of the role property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRole(String value) {
        this.role = value;
    }

    public boolean isSetRole() {
        return (this.role!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("prtyIdntfctn", prtyIdntfctn).add("role", role).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(prtyIdntfctn, role);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PartyRoleType o = ((PartyRoleType) other);
        return (Objects.equal(prtyIdntfctn, o.prtyIdntfctn)&&Objects.equal(role, o.role));
    }

}
