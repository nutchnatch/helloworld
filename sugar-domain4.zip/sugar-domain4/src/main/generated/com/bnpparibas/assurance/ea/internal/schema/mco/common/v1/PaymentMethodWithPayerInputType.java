
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on the payment method at
 * 				policy, cover, cash bank, etc levels
 * 			
 * 
 * <p>Java class for PaymentMethodWithPayerInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PaymentMethodWithPayerInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Pyr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="SettlmntMode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}SettlementModeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="BnkRef" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BankingReferenceAndCreditorType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PaymentMethodWithPayerInputType", propOrder = {
    "pyr",
    "settlmntMode",
    "bnkRef"
})
public class PaymentMethodWithPayerInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Pyr")
    protected PartyRoleType pyr;
    @XmlElement(name = "SettlmntMode")
    protected String settlmntMode;
    @XmlElement(name = "BnkRef")
    protected BankingReferenceAndCreditorType bnkRef;

    /**
     * Default no-arg constructor
     * 
     */
    public PaymentMethodWithPayerInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PaymentMethodWithPayerInputType(final PartyRoleType pyr, final String settlmntMode, final BankingReferenceAndCreditorType bnkRef) {
        this.pyr = pyr;
        this.settlmntMode = settlmntMode;
        this.bnkRef = bnkRef;
    }

    /**
     * Gets the value of the pyr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPyr() {
        return pyr;
    }

    /**
     * Sets the value of the pyr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPyr(PartyRoleType value) {
        this.pyr = value;
    }

    public boolean isSetPyr() {
        return (this.pyr!= null);
    }

    /**
     * Gets the value of the settlmntMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSettlmntMode() {
        return settlmntMode;
    }

    /**
     * Sets the value of the settlmntMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSettlmntMode(String value) {
        this.settlmntMode = value;
    }

    public boolean isSetSettlmntMode() {
        return (this.settlmntMode!= null);
    }

    /**
     * Gets the value of the bnkRef property.
     * 
     * @return
     *     possible object is
     *     {@link BankingReferenceAndCreditorType }
     *     
     */
    public BankingReferenceAndCreditorType getBnkRef() {
        return bnkRef;
    }

    /**
     * Sets the value of the bnkRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link BankingReferenceAndCreditorType }
     *     
     */
    public void setBnkRef(BankingReferenceAndCreditorType value) {
        this.bnkRef = value;
    }

    public boolean isSetBnkRef() {
        return (this.bnkRef!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pyr", pyr).add("settlmntMode", settlmntMode).add("bnkRef", bnkRef).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pyr, settlmntMode, bnkRef);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PaymentMethodWithPayerInputType o = ((PaymentMethodWithPayerInputType) other);
        return ((Objects.equal(pyr, o.pyr)&&Objects.equal(settlmntMode, o.settlmntMode))&&Objects.equal(bnkRef, o.bnkRef));
    }

}
