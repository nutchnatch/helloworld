
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import com.google.common.base.Objects;


/**
 * Duration expressed in a unit time
 * 			
 * 
 * <p>Java class for DurationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DurationType"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1&gt;IntegerType"&gt;
 *       &lt;attribute name="TimeUnit" use="required" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PeriodTypeCodeSLN" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DurationType", propOrder = {
    "value"
})
public class DurationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlValue
    protected BigInteger value;
    @XmlAttribute(name = "TimeUnit", required = true)
    protected String timeUnit;

    /**
     * Default no-arg constructor
     * 
     */
    public DurationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public DurationType(final BigInteger value, final String timeUnit) {
        this.value = value;
        this.timeUnit = timeUnit;
    }

    /**
     * Type for integers
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setValue(BigInteger value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return (this.value!= null);
    }

    /**
     * Gets the value of the timeUnit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTimeUnit() {
        return timeUnit;
    }

    /**
     * Sets the value of the timeUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTimeUnit(String value) {
        this.timeUnit = value;
    }

    public boolean isSetTimeUnit() {
        return (this.timeUnit!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("value", value).add("timeUnit", timeUnit).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(value, timeUnit);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final DurationType o = ((DurationType) other);
        return (Objects.equal(value, o.value)&&Objects.equal(timeUnit, o.timeUnit));
    }

}
