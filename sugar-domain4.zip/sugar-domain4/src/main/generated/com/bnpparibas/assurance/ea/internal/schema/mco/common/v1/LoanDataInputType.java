
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage information on a loan
 * 			
 * 
 * <p>Java class for LoanDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LoanDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="LoanObjct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LoanObjectCodeSLN"/&gt;
 *         &lt;element name="LoanType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LoanFinancingTypeCode"/&gt;
 *         &lt;element name="LoanPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OptionalDatePeriodType" minOccurs="0"/&gt;
 *         &lt;element name="AmrtztnType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LoanAmortizationTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="LoanAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="TermDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="LoanDuratn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType"/&gt;
 *         &lt;element name="DefrdPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="IntrstRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" minOccurs="0"/&gt;
 *         &lt;element name="Curr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="MaxRvlvngLoanAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="FundRelseDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="ZeroRateBnftIndic" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}YesNoIndicatorSLN" minOccurs="0"/&gt;
 *         &lt;element name="TaxDdctnNature" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}TaxBenefitType" minOccurs="0"/&gt;
 *         &lt;element name="PaymntDueDayNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MonthDayCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LoanDataInputType", propOrder = {
    "loanObjct",
    "loanType",
    "loanPrd",
    "amrtztnType",
    "loanAmnt",
    "termDate",
    "loanDuratn",
    "defrdPrd",
    "intrstRate",
    "curr",
    "maxRvlvngLoanAmnt",
    "fundRelseDate",
    "zeroRateBnftIndic",
    "taxDdctnNature",
    "paymntDueDayNumb"
})
public class LoanDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "LoanObjct", required = true)
    protected String loanObjct;
    @XmlElement(name = "LoanType", required = true)
    protected String loanType;
    @XmlElement(name = "LoanPrd")
    protected OptionalDatePeriodType loanPrd;
    @XmlElement(name = "AmrtztnType")
    protected String amrtztnType;
    @XmlElement(name = "LoanAmnt")
    protected CurrencyAndAmountType loanAmnt;
    @XmlElement(name = "TermDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date termDate;
    @XmlElement(name = "LoanDuratn", required = true)
    protected DurationType loanDuratn;
    @XmlElement(name = "DefrdPrd")
    protected DurationType defrdPrd;
    @XmlElement(name = "IntrstRate")
    protected Double intrstRate;
    @XmlElement(name = "Curr")
    protected String curr;
    @XmlElement(name = "MaxRvlvngLoanAmnt")
    protected CurrencyAndAmountType maxRvlvngLoanAmnt;
    @XmlElement(name = "FundRelseDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date fundRelseDate;
    @XmlElement(name = "ZeroRateBnftIndic")
    protected String zeroRateBnftIndic;
    @XmlElement(name = "TaxDdctnNature")
    protected String taxDdctnNature;
    @XmlElement(name = "PaymntDueDayNumb")
    protected String paymntDueDayNumb;

    /**
     * Default no-arg constructor
     * 
     */
    public LoanDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public LoanDataInputType(final String loanObjct, final String loanType, final OptionalDatePeriodType loanPrd, final String amrtztnType, final CurrencyAndAmountType loanAmnt, final Date termDate, final DurationType loanDuratn, final DurationType defrdPrd, final Double intrstRate, final String curr, final CurrencyAndAmountType maxRvlvngLoanAmnt, final Date fundRelseDate, final String zeroRateBnftIndic, final String taxDdctnNature, final String paymntDueDayNumb) {
        this.loanObjct = loanObjct;
        this.loanType = loanType;
        this.loanPrd = loanPrd;
        this.amrtztnType = amrtztnType;
        this.loanAmnt = loanAmnt;
        this.termDate = termDate;
        this.loanDuratn = loanDuratn;
        this.defrdPrd = defrdPrd;
        this.intrstRate = intrstRate;
        this.curr = curr;
        this.maxRvlvngLoanAmnt = maxRvlvngLoanAmnt;
        this.fundRelseDate = fundRelseDate;
        this.zeroRateBnftIndic = zeroRateBnftIndic;
        this.taxDdctnNature = taxDdctnNature;
        this.paymntDueDayNumb = paymntDueDayNumb;
    }

    /**
     * Gets the value of the loanObjct property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoanObjct() {
        return loanObjct;
    }

    /**
     * Sets the value of the loanObjct property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoanObjct(String value) {
        this.loanObjct = value;
    }

    public boolean isSetLoanObjct() {
        return (this.loanObjct!= null);
    }

    /**
     * Gets the value of the loanType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoanType() {
        return loanType;
    }

    /**
     * Sets the value of the loanType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoanType(String value) {
        this.loanType = value;
    }

    public boolean isSetLoanType() {
        return (this.loanType!= null);
    }

    /**
     * Gets the value of the loanPrd property.
     * 
     * @return
     *     possible object is
     *     {@link OptionalDatePeriodType }
     *     
     */
    public OptionalDatePeriodType getLoanPrd() {
        return loanPrd;
    }

    /**
     * Sets the value of the loanPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link OptionalDatePeriodType }
     *     
     */
    public void setLoanPrd(OptionalDatePeriodType value) {
        this.loanPrd = value;
    }

    public boolean isSetLoanPrd() {
        return (this.loanPrd!= null);
    }

    /**
     * Gets the value of the amrtztnType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmrtztnType() {
        return amrtztnType;
    }

    /**
     * Sets the value of the amrtztnType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmrtztnType(String value) {
        this.amrtztnType = value;
    }

    public boolean isSetAmrtztnType() {
        return (this.amrtztnType!= null);
    }

    /**
     * Gets the value of the loanAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getLoanAmnt() {
        return loanAmnt;
    }

    /**
     * Sets the value of the loanAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setLoanAmnt(CurrencyAndAmountType value) {
        this.loanAmnt = value;
    }

    public boolean isSetLoanAmnt() {
        return (this.loanAmnt!= null);
    }

    /**
     * Gets the value of the termDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getTermDate() {
        return termDate;
    }

    /**
     * Sets the value of the termDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTermDate(Date value) {
        this.termDate = value;
    }

    public boolean isSetTermDate() {
        return (this.termDate!= null);
    }

    /**
     * Gets the value of the loanDuratn property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getLoanDuratn() {
        return loanDuratn;
    }

    /**
     * Sets the value of the loanDuratn property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setLoanDuratn(DurationType value) {
        this.loanDuratn = value;
    }

    public boolean isSetLoanDuratn() {
        return (this.loanDuratn!= null);
    }

    /**
     * Gets the value of the defrdPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getDefrdPrd() {
        return defrdPrd;
    }

    /**
     * Sets the value of the defrdPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setDefrdPrd(DurationType value) {
        this.defrdPrd = value;
    }

    public boolean isSetDefrdPrd() {
        return (this.defrdPrd!= null);
    }

    /**
     * Gets the value of the intrstRate property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getIntrstRate() {
        return intrstRate;
    }

    /**
     * Sets the value of the intrstRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setIntrstRate(Double value) {
        this.intrstRate = value;
    }

    public boolean isSetIntrstRate() {
        return (this.intrstRate!= null);
    }

    /**
     * Gets the value of the curr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurr() {
        return curr;
    }

    /**
     * Sets the value of the curr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurr(String value) {
        this.curr = value;
    }

    public boolean isSetCurr() {
        return (this.curr!= null);
    }

    /**
     * Gets the value of the maxRvlvngLoanAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getMaxRvlvngLoanAmnt() {
        return maxRvlvngLoanAmnt;
    }

    /**
     * Sets the value of the maxRvlvngLoanAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setMaxRvlvngLoanAmnt(CurrencyAndAmountType value) {
        this.maxRvlvngLoanAmnt = value;
    }

    public boolean isSetMaxRvlvngLoanAmnt() {
        return (this.maxRvlvngLoanAmnt!= null);
    }

    /**
     * Gets the value of the fundRelseDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getFundRelseDate() {
        return fundRelseDate;
    }

    /**
     * Sets the value of the fundRelseDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundRelseDate(Date value) {
        this.fundRelseDate = value;
    }

    public boolean isSetFundRelseDate() {
        return (this.fundRelseDate!= null);
    }

    /**
     * Gets the value of the zeroRateBnftIndic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getZeroRateBnftIndic() {
        return zeroRateBnftIndic;
    }

    /**
     * Sets the value of the zeroRateBnftIndic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setZeroRateBnftIndic(String value) {
        this.zeroRateBnftIndic = value;
    }

    public boolean isSetZeroRateBnftIndic() {
        return (this.zeroRateBnftIndic!= null);
    }

    /**
     * Gets the value of the taxDdctnNature property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxDdctnNature() {
        return taxDdctnNature;
    }

    /**
     * Sets the value of the taxDdctnNature property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxDdctnNature(String value) {
        this.taxDdctnNature = value;
    }

    public boolean isSetTaxDdctnNature() {
        return (this.taxDdctnNature!= null);
    }

    /**
     * Gets the value of the paymntDueDayNumb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymntDueDayNumb() {
        return paymntDueDayNumb;
    }

    /**
     * Sets the value of the paymntDueDayNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymntDueDayNumb(String value) {
        this.paymntDueDayNumb = value;
    }

    public boolean isSetPaymntDueDayNumb() {
        return (this.paymntDueDayNumb!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("loanObjct", loanObjct).add("loanType", loanType).add("loanPrd", loanPrd).add("amrtztnType", amrtztnType).add("loanAmnt", loanAmnt).add("termDate", termDate).add("loanDuratn", loanDuratn).add("defrdPrd", defrdPrd).add("intrstRate", intrstRate).add("curr", curr).add("maxRvlvngLoanAmnt", maxRvlvngLoanAmnt).add("fundRelseDate", fundRelseDate).add("zeroRateBnftIndic", zeroRateBnftIndic).add("taxDdctnNature", taxDdctnNature).add("paymntDueDayNumb", paymntDueDayNumb).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(loanObjct, loanType, loanPrd, amrtztnType, loanAmnt, termDate, loanDuratn, defrdPrd, intrstRate, curr, maxRvlvngLoanAmnt, fundRelseDate, zeroRateBnftIndic, taxDdctnNature, paymntDueDayNumb);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final LoanDataInputType o = ((LoanDataInputType) other);
        return ((((((((((((((Objects.equal(loanObjct, o.loanObjct)&&Objects.equal(loanType, o.loanType))&&Objects.equal(loanPrd, o.loanPrd))&&Objects.equal(amrtztnType, o.amrtztnType))&&Objects.equal(loanAmnt, o.loanAmnt))&&Objects.equal(termDate, o.termDate))&&Objects.equal(loanDuratn, o.loanDuratn))&&Objects.equal(defrdPrd, o.defrdPrd))&&Objects.equal(intrstRate, o.intrstRate))&&Objects.equal(curr, o.curr))&&Objects.equal(maxRvlvngLoanAmnt, o.maxRvlvngLoanAmnt))&&Objects.equal(fundRelseDate, o.fundRelseDate))&&Objects.equal(zeroRateBnftIndic, o.zeroRateBnftIndic))&&Objects.equal(taxDdctnNature, o.taxDdctnNature))&&Objects.equal(paymntDueDayNumb, o.paymntDueDayNumb));
    }

}
