
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * Block that describes the context of an object
 * 			
 * 
 * <p>Java class for ObjectContextType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ObjectContextType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Origin" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ApplicationComponentCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="CreatnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="CreatnUser" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}UserType" minOccurs="0"/&gt;
 *         &lt;element name="UpdtDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *         &lt;element name="UpdtUser" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}UserType" minOccurs="0"/&gt;
 *         &lt;element name="ClosureDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ObjectContextType", propOrder = {
    "origin",
    "creatnDate",
    "creatnUser",
    "updtDate",
    "updtUser",
    "closureDate"
})
public class ObjectContextType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Origin")
    protected String origin;
    @XmlElement(name = "CreatnDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date creatnDate;
    @XmlElement(name = "CreatnUser")
    protected UserType creatnUser;
    @XmlElement(name = "UpdtDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date updtDate;
    @XmlElement(name = "UpdtUser")
    protected UserType updtUser;
    @XmlElement(name = "ClosureDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date closureDate;

    /**
     * Default no-arg constructor
     * 
     */
    public ObjectContextType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ObjectContextType(final String origin, final Date creatnDate, final UserType creatnUser, final Date updtDate, final UserType updtUser, final Date closureDate) {
        this.origin = origin;
        this.creatnDate = creatnDate;
        this.creatnUser = creatnUser;
        this.updtDate = updtDate;
        this.updtUser = updtUser;
        this.closureDate = closureDate;
    }

    /**
     * Gets the value of the origin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrigin() {
        return origin;
    }

    /**
     * Sets the value of the origin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrigin(String value) {
        this.origin = value;
    }

    public boolean isSetOrigin() {
        return (this.origin!= null);
    }

    /**
     * Gets the value of the creatnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCreatnDate() {
        return creatnDate;
    }

    /**
     * Sets the value of the creatnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatnDate(Date value) {
        this.creatnDate = value;
    }

    public boolean isSetCreatnDate() {
        return (this.creatnDate!= null);
    }

    /**
     * Gets the value of the creatnUser property.
     * 
     * @return
     *     possible object is
     *     {@link UserType }
     *     
     */
    public UserType getCreatnUser() {
        return creatnUser;
    }

    /**
     * Sets the value of the creatnUser property.
     * 
     * @param value
     *     allowed object is
     *     {@link UserType }
     *     
     */
    public void setCreatnUser(UserType value) {
        this.creatnUser = value;
    }

    public boolean isSetCreatnUser() {
        return (this.creatnUser!= null);
    }

    /**
     * Gets the value of the updtDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getUpdtDate() {
        return updtDate;
    }

    /**
     * Sets the value of the updtDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdtDate(Date value) {
        this.updtDate = value;
    }

    public boolean isSetUpdtDate() {
        return (this.updtDate!= null);
    }

    /**
     * Gets the value of the updtUser property.
     * 
     * @return
     *     possible object is
     *     {@link UserType }
     *     
     */
    public UserType getUpdtUser() {
        return updtUser;
    }

    /**
     * Sets the value of the updtUser property.
     * 
     * @param value
     *     allowed object is
     *     {@link UserType }
     *     
     */
    public void setUpdtUser(UserType value) {
        this.updtUser = value;
    }

    public boolean isSetUpdtUser() {
        return (this.updtUser!= null);
    }

    /**
     * Gets the value of the closureDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getClosureDate() {
        return closureDate;
    }

    /**
     * Sets the value of the closureDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClosureDate(Date value) {
        this.closureDate = value;
    }

    public boolean isSetClosureDate() {
        return (this.closureDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("origin", origin).add("creatnDate", creatnDate).add("creatnUser", creatnUser).add("updtDate", updtDate).add("updtUser", updtUser).add("closureDate", closureDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(origin, creatnDate, creatnUser, updtDate, updtUser, closureDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ObjectContextType o = ((ObjectContextType) other);
        return (((((Objects.equal(origin, o.origin)&&Objects.equal(creatnDate, o.creatnDate))&&Objects.equal(creatnUser, o.creatnUser))&&Objects.equal(updtDate, o.updtDate))&&Objects.equal(updtUser, o.updtUser))&&Objects.equal(closureDate, o.closureDate));
    }

}
