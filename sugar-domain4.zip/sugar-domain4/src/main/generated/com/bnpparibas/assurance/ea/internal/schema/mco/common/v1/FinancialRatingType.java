
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * Type to manage information for financial rating
 * 			
 * 
 * <p>Java class for FinancialRatingType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FinancialRatingType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Agncy" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}RatingAgencyCodeSLN"/&gt;
 *         &lt;element name="Rnk" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}RatingValueCodeSLN"/&gt;
 *         &lt;element name="TermType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}TermTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="RatngOutlook" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}RatingOutlookCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="RatngDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FinancialRatingType", propOrder = {
    "agncy",
    "rnk",
    "termType",
    "ratngOutlook",
    "ratngDate"
})
public class FinancialRatingType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Agncy", required = true)
    protected String agncy;
    @XmlElement(name = "Rnk", required = true)
    protected String rnk;
    @XmlElement(name = "TermType")
    protected String termType;
    @XmlElement(name = "RatngOutlook")
    protected String ratngOutlook;
    @XmlElement(name = "RatngDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date ratngDate;

    /**
     * Default no-arg constructor
     * 
     */
    public FinancialRatingType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FinancialRatingType(final String agncy, final String rnk, final String termType, final String ratngOutlook, final Date ratngDate) {
        this.agncy = agncy;
        this.rnk = rnk;
        this.termType = termType;
        this.ratngOutlook = ratngOutlook;
        this.ratngDate = ratngDate;
    }

    /**
     * Gets the value of the agncy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgncy() {
        return agncy;
    }

    /**
     * Sets the value of the agncy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgncy(String value) {
        this.agncy = value;
    }

    public boolean isSetAgncy() {
        return (this.agncy!= null);
    }

    /**
     * Gets the value of the rnk property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRnk() {
        return rnk;
    }

    /**
     * Sets the value of the rnk property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRnk(String value) {
        this.rnk = value;
    }

    public boolean isSetRnk() {
        return (this.rnk!= null);
    }

    /**
     * Gets the value of the termType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTermType() {
        return termType;
    }

    /**
     * Sets the value of the termType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTermType(String value) {
        this.termType = value;
    }

    public boolean isSetTermType() {
        return (this.termType!= null);
    }

    /**
     * Gets the value of the ratngOutlook property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRatngOutlook() {
        return ratngOutlook;
    }

    /**
     * Sets the value of the ratngOutlook property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRatngOutlook(String value) {
        this.ratngOutlook = value;
    }

    public boolean isSetRatngOutlook() {
        return (this.ratngOutlook!= null);
    }

    /**
     * Gets the value of the ratngDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getRatngDate() {
        return ratngDate;
    }

    /**
     * Sets the value of the ratngDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRatngDate(Date value) {
        this.ratngDate = value;
    }

    public boolean isSetRatngDate() {
        return (this.ratngDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("agncy", agncy).add("rnk", rnk).add("termType", termType).add("ratngOutlook", ratngOutlook).add("ratngDate", ratngDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(agncy, rnk, termType, ratngOutlook, ratngDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FinancialRatingType o = ((FinancialRatingType) other);
        return ((((Objects.equal(agncy, o.agncy)&&Objects.equal(rnk, o.rnk))&&Objects.equal(termType, o.termType))&&Objects.equal(ratngOutlook, o.ratngOutlook))&&Objects.equal(ratngDate, o.ratngDate));
    }

}
