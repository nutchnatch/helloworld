
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * To manage objects with which matching operations
 * 				has dependencies
 * 			
 * 
 * <p>Java class for MatchingOperationLinkedObjectsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MatchingOperationLinkedObjectsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Pdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductSharedDataType" minOccurs="0"/&gt;
 *         &lt;element name="Pol" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="Distrbtr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartnerPartyType"/&gt;
 *         &lt;element name="Prdctr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MatchingOperationLinkedObjectsType", propOrder = {
    "pdct",
    "pol",
    "distrbtr",
    "prdctr"
})
public class MatchingOperationLinkedObjectsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Pdct")
    protected ProductSharedDataType pdct;
    @XmlElement(name = "Pol")
    protected ObjectIdentificationType pol;
    @XmlElement(name = "Distrbtr", required = true)
    protected PartnerPartyType distrbtr;
    @XmlElement(name = "Prdctr", required = true)
    protected PartyRoleType prdctr;

    /**
     * Default no-arg constructor
     * 
     */
    public MatchingOperationLinkedObjectsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MatchingOperationLinkedObjectsType(final ProductSharedDataType pdct, final ObjectIdentificationType pol, final PartnerPartyType distrbtr, final PartyRoleType prdctr) {
        this.pdct = pdct;
        this.pol = pol;
        this.distrbtr = distrbtr;
        this.prdctr = prdctr;
    }

    /**
     * Gets the value of the pdct property.
     * 
     * @return
     *     possible object is
     *     {@link ProductSharedDataType }
     *     
     */
    public ProductSharedDataType getPdct() {
        return pdct;
    }

    /**
     * Sets the value of the pdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductSharedDataType }
     *     
     */
    public void setPdct(ProductSharedDataType value) {
        this.pdct = value;
    }

    public boolean isSetPdct() {
        return (this.pdct!= null);
    }

    /**
     * Gets the value of the pol property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPol() {
        return pol;
    }

    /**
     * Sets the value of the pol property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPol(ObjectIdentificationType value) {
        this.pol = value;
    }

    public boolean isSetPol() {
        return (this.pol!= null);
    }

    /**
     * Gets the value of the distrbtr property.
     * 
     * @return
     *     possible object is
     *     {@link PartnerPartyType }
     *     
     */
    public PartnerPartyType getDistrbtr() {
        return distrbtr;
    }

    /**
     * Sets the value of the distrbtr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartnerPartyType }
     *     
     */
    public void setDistrbtr(PartnerPartyType value) {
        this.distrbtr = value;
    }

    public boolean isSetDistrbtr() {
        return (this.distrbtr!= null);
    }

    /**
     * Gets the value of the prdctr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrdctr() {
        return prdctr;
    }

    /**
     * Sets the value of the prdctr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrdctr(PartyRoleType value) {
        this.prdctr = value;
    }

    public boolean isSetPrdctr() {
        return (this.prdctr!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pdct", pdct).add("pol", pol).add("distrbtr", distrbtr).add("prdctr", prdctr).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pdct, pol, distrbtr, prdctr);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MatchingOperationLinkedObjectsType o = ((MatchingOperationLinkedObjectsType) other);
        return (((Objects.equal(pdct, o.pdct)&&Objects.equal(pol, o.pol))&&Objects.equal(distrbtr, o.distrbtr))&&Objects.equal(prdctr, o.prdctr));
    }

}
