
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.bnpparibas.assurance.ea.internal.schema.mco.common.v1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Tags_QNAME = new QName("http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1", "Tags");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.bnpparibas.assurance.ea.internal.schema.mco.common.v1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link DocumentClassDataType }
     * 
     */
    public DocumentClassDataType createDocumentClassDataType() {
        return new DocumentClassDataType();
    }

    /**
     * Create an instance of {@link ThirdPartyContactWithAddressType }
     * 
     */
    public ThirdPartyContactWithAddressType createThirdPartyContactWithAddressType() {
        return new ThirdPartyContactWithAddressType();
    }

    /**
     * Create an instance of {@link ThirdPartyContactType }
     * 
     */
    public ThirdPartyContactType createThirdPartyContactType() {
        return new ThirdPartyContactType();
    }

    /**
     * Create an instance of {@link ThirdPartyContactInputType }
     * 
     */
    public ThirdPartyContactInputType createThirdPartyContactInputType() {
        return new ThirdPartyContactInputType();
    }

    /**
     * Create an instance of {@link SubscriptionQuestionnaryDataInputType }
     * 
     */
    public SubscriptionQuestionnaryDataInputType createSubscriptionQuestionnaryDataInputType() {
        return new SubscriptionQuestionnaryDataInputType();
    }

    /**
     * Create an instance of {@link StructureElementParentType }
     * 
     */
    public StructureElementParentType createStructureElementParentType() {
        return new StructureElementParentType();
    }

    /**
     * Create an instance of {@link SimplifiedProtectionProductDataType }
     * 
     */
    public SimplifiedProtectionProductDataType createSimplifiedProtectionProductDataType() {
        return new SimplifiedProtectionProductDataType();
    }

    /**
     * Create an instance of {@link SimplifiedProtectionCoversPackageDataType }
     * 
     */
    public SimplifiedProtectionCoversPackageDataType createSimplifiedProtectionCoversPackageDataType() {
        return new SimplifiedProtectionCoversPackageDataType();
    }

    /**
     * Create an instance of {@link SimplifiedProtectiionCoverDataType }
     * 
     */
    public SimplifiedProtectiionCoverDataType createSimplifiedProtectiionCoverDataType() {
        return new SimplifiedProtectiionCoverDataType();
    }

    /**
     * Create an instance of {@link SimplifiedProtectiionCoverDataType.Fee }
     * 
     */
    public SimplifiedProtectiionCoverDataType.Fee createSimplifiedProtectiionCoverDataTypeFee() {
        return new SimplifiedProtectiionCoverDataType.Fee();
    }

    /**
     * Create an instance of {@link SimplifiedProtectiionCoverDataType.Prem }
     * 
     */
    public SimplifiedProtectiionCoverDataType.Prem createSimplifiedProtectiionCoverDataTypePrem() {
        return new SimplifiedProtectiionCoverDataType.Prem();
    }

    /**
     * Create an instance of {@link SimplifiedProtectiionCoverDataType.Prem.CalctnTerms }
     * 
     */
    public SimplifiedProtectiionCoverDataType.Prem.CalctnTerms createSimplifiedProtectiionCoverDataTypePremCalctnTerms() {
        return new SimplifiedProtectiionCoverDataType.Prem.CalctnTerms();
    }

    /**
     * Create an instance of {@link SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis }
     * 
     */
    public SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis createSimplifiedProtectiionCoverDataTypePremCalctnTermsBasis() {
        return new SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis();
    }

    /**
     * Create an instance of {@link SimplifiedProtectiionCoverDataType.ClaimTerms }
     * 
     */
    public SimplifiedProtectiionCoverDataType.ClaimTerms createSimplifiedProtectiionCoverDataTypeClaimTerms() {
        return new SimplifiedProtectiionCoverDataType.ClaimTerms();
    }

    /**
     * Create an instance of {@link SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms }
     * 
     */
    public SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms createSimplifiedProtectiionCoverDataTypeClaimTermsLoanBnftTerms() {
        return new SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms();
    }

    /**
     * Create an instance of {@link SavingsOperationInputDataType }
     * 
     */
    public SavingsOperationInputDataType createSavingsOperationInputDataType() {
        return new SavingsOperationInputDataType();
    }

    /**
     * Create an instance of {@link ReserveOperationDataType }
     * 
     */
    public ReserveOperationDataType createReserveOperationDataType() {
        return new ReserveOperationDataType();
    }

    /**
     * Create an instance of {@link ProtectionProductDataType }
     * 
     */
    public ProtectionProductDataType createProtectionProductDataType() {
        return new ProtectionProductDataType();
    }

    /**
     * Create an instance of {@link ProtectionProductDataType.DurtnAndRnwal }
     * 
     */
    public ProtectionProductDataType.DurtnAndRnwal createProtectionProductDataTypeDurtnAndRnwal() {
        return new ProtectionProductDataType.DurtnAndRnwal();
    }

    /**
     * Create an instance of {@link ProtectionOperationPaymentType }
     * 
     */
    public ProtectionOperationPaymentType createProtectionOperationPaymentType() {
        return new ProtectionOperationPaymentType();
    }

    /**
     * Create an instance of {@link ProtectionClaimBenefitDataType }
     * 
     */
    public ProtectionClaimBenefitDataType createProtectionClaimBenefitDataType() {
        return new ProtectionClaimBenefitDataType();
    }

    /**
     * Create an instance of {@link ProductOperationFeeTermsDataType }
     * 
     */
    public ProductOperationFeeTermsDataType createProductOperationFeeTermsDataType() {
        return new ProductOperationFeeTermsDataType();
    }

    /**
     * Create an instance of {@link OriginPolicyType }
     * 
     */
    public OriginPolicyType createOriginPolicyType() {
        return new OriginPolicyType();
    }

    /**
     * Create an instance of {@link OriginPolicyInputType }
     * 
     */
    public OriginPolicyInputType createOriginPolicyInputType() {
        return new OriginPolicyInputType();
    }

    /**
     * Create an instance of {@link MoneyInMoneyOutLinkedObjectsType }
     * 
     */
    public MoneyInMoneyOutLinkedObjectsType createMoneyInMoneyOutLinkedObjectsType() {
        return new MoneyInMoneyOutLinkedObjectsType();
    }

    /**
     * Create an instance of {@link MandateDataInputType }
     * 
     */
    public MandateDataInputType createMandateDataInputType() {
        return new MandateDataInputType();
    }

    /**
     * Create an instance of {@link MainStructureDataType }
     * 
     */
    public MainStructureDataType createMainStructureDataType() {
        return new MainStructureDataType();
    }

    /**
     * Create an instance of {@link MailingDocumentPartType }
     * 
     */
    public MailingDocumentPartType createMailingDocumentPartType() {
        return new MailingDocumentPartType();
    }

    /**
     * Create an instance of {@link MailingDocumentDataType }
     * 
     */
    public MailingDocumentDataType createMailingDocumentDataType() {
        return new MailingDocumentDataType();
    }

    /**
     * Create an instance of {@link DocumentCompositionOutputOptionType }
     * 
     */
    public DocumentCompositionOutputOptionType createDocumentCompositionOutputOptionType() {
        return new DocumentCompositionOutputOptionType();
    }

    /**
     * Create an instance of {@link DocumentCompositionContextType }
     * 
     */
    public DocumentCompositionContextType createDocumentCompositionContextType() {
        return new DocumentCompositionContextType();
    }

    /**
     * Create an instance of {@link DocumentCompositionDataType }
     * 
     */
    public DocumentCompositionDataType createDocumentCompositionDataType() {
        return new DocumentCompositionDataType();
    }

    /**
     * Create an instance of {@link DocumentCompositionDataType.RecrsveCmpstn }
     * 
     */
    public DocumentCompositionDataType.RecrsveCmpstn createDocumentCompositionDataTypeRecrsveCmpstn() {
        return new DocumentCompositionDataType.RecrsveCmpstn();
    }

    /**
     * Create an instance of {@link DistributionSpecificDataInputType }
     * 
     */
    public DistributionSpecificDataInputType createDistributionSpecificDataInputType() {
        return new DistributionSpecificDataInputType();
    }

    /**
     * Create an instance of {@link CoverPremiumCalculationRulesDataType }
     * 
     */
    public CoverPremiumCalculationRulesDataType createCoverPremiumCalculationRulesDataType() {
        return new CoverPremiumCalculationRulesDataType();
    }

    /**
     * Create an instance of {@link CoverPremiumFeeTermsDataType }
     * 
     */
    public CoverPremiumFeeTermsDataType createCoverPremiumFeeTermsDataType() {
        return new CoverPremiumFeeTermsDataType();
    }

    /**
     * Create an instance of {@link CoverClaimTermsDataType }
     * 
     */
    public CoverClaimTermsDataType createCoverClaimTermsDataType() {
        return new CoverClaimTermsDataType();
    }

    /**
     * Create an instance of {@link CoverClaimTermsDataType.LoanExitBnft }
     * 
     */
    public CoverClaimTermsDataType.LoanExitBnft createCoverClaimTermsDataTypeLoanExitBnft() {
        return new CoverClaimTermsDataType.LoanExitBnft();
    }

    /**
     * Create an instance of {@link CoverClaimTermsDataType.Ddctble }
     * 
     */
    public CoverClaimTermsDataType.Ddctble createCoverClaimTermsDataTypeDdctble() {
        return new CoverClaimTermsDataType.Ddctble();
    }

    /**
     * Create an instance of {@link ClaimDeclarationQuestionnaryDataType }
     * 
     */
    public ClaimDeclarationQuestionnaryDataType createClaimDeclarationQuestionnaryDataType() {
        return new ClaimDeclarationQuestionnaryDataType();
    }

    /**
     * Create an instance of {@link BirthPlaceType }
     * 
     */
    public BirthPlaceType createBirthPlaceType() {
        return new BirthPlaceType();
    }

    /**
     * Create an instance of {@link AcknowledgementActionAndErrorDataType }
     * 
     */
    public AcknowledgementActionAndErrorDataType createAcknowledgementActionAndErrorDataType() {
        return new AcknowledgementActionAndErrorDataType();
    }

    /**
     * Create an instance of {@link AcknowledgementActionAndErrorDataType.ErrDtail }
     * 
     */
    public AcknowledgementActionAndErrorDataType.ErrDtail createAcknowledgementActionAndErrorDataTypeErrDtail() {
        return new AcknowledgementActionAndErrorDataType.ErrDtail();
    }

    /**
     * Create an instance of {@link EDMS2IdentificationType }
     * 
     */
    public EDMS2IdentificationType createEDMS2IdentificationType() {
        return new EDMS2IdentificationType();
    }

    /**
     * Create an instance of {@link ClassId }
     * 
     */
    public ClassId createClassId() {
        return new ClassId();
    }

    /**
     * Create an instance of {@link ClassIdentificationType }
     * 
     */
    public ClassIdentificationType createClassIdentificationType() {
        return new ClassIdentificationType();
    }

    /**
     * Create an instance of {@link Tags }
     * 
     */
    public Tags createTags() {
        return new Tags();
    }

    /**
     * Create an instance of {@link AcknowledgementRecipientApplicationType }
     * 
     */
    public AcknowledgementRecipientApplicationType createAcknowledgementRecipientApplicationType() {
        return new AcknowledgementRecipientApplicationType();
    }

    /**
     * Create an instance of {@link AcknowledgementSourceApplicationType }
     * 
     */
    public AcknowledgementSourceApplicationType createAcknowledgementSourceApplicationType() {
        return new AcknowledgementSourceApplicationType();
    }

    /**
     * Create an instance of {@link AcknowledgementSourceApplicationObjectStatusType }
     * 
     */
    public AcknowledgementSourceApplicationObjectStatusType createAcknowledgementSourceApplicationObjectStatusType() {
        return new AcknowledgementSourceApplicationObjectStatusType();
    }

    /**
     * Create an instance of {@link AcknowledgementStatusType }
     * 
     */
    public AcknowledgementStatusType createAcknowledgementStatusType() {
        return new AcknowledgementStatusType();
    }

    /**
     * Create an instance of {@link AdditionalAmountType }
     * 
     */
    public AdditionalAmountType createAdditionalAmountType() {
        return new AdditionalAmountType();
    }

    /**
     * Create an instance of {@link AllCommunicationAddressesType }
     * 
     */
    public AllCommunicationAddressesType createAllCommunicationAddressesType() {
        return new AllCommunicationAddressesType();
    }

    /**
     * Create an instance of {@link AnnuityDataType }
     * 
     */
    public AnnuityDataType createAnnuityDataType() {
        return new AnnuityDataType();
    }

    /**
     * Create an instance of {@link AssuredOutstandingsDataType }
     * 
     */
    public AssuredOutstandingsDataType createAssuredOutstandingsDataType() {
        return new AssuredOutstandingsDataType();
    }

    /**
     * Create an instance of {@link AuthorizationObjctDataType }
     * 
     */
    public AuthorizationObjctDataType createAuthorizationObjctDataType() {
        return new AuthorizationObjctDataType();
    }

    /**
     * Create an instance of {@link AuthorizationDataLinkedObjectsDataType }
     * 
     */
    public AuthorizationDataLinkedObjectsDataType createAuthorizationDataLinkedObjectsDataType() {
        return new AuthorizationDataLinkedObjectsDataType();
    }

    /**
     * Create an instance of {@link AuthorizationObjectLinkType }
     * 
     */
    public AuthorizationObjectLinkType createAuthorizationObjectLinkType() {
        return new AuthorizationObjectLinkType();
    }

    /**
     * Create an instance of {@link BankAccountAndCreditorDataType }
     * 
     */
    public BankAccountAndCreditorDataType createBankAccountAndCreditorDataType() {
        return new BankAccountAndCreditorDataType();
    }

    /**
     * Create an instance of {@link BankAccountIdentificationType }
     * 
     */
    public BankAccountIdentificationType createBankAccountIdentificationType() {
        return new BankAccountIdentificationType();
    }

    /**
     * Create an instance of {@link BankAccountIdentificationWithStatusType }
     * 
     */
    public BankAccountIdentificationWithStatusType createBankAccountIdentificationWithStatusType() {
        return new BankAccountIdentificationWithStatusType();
    }

    /**
     * Create an instance of {@link BankingReferenceInputType }
     * 
     */
    public BankingReferenceInputType createBankingReferenceInputType() {
        return new BankingReferenceInputType();
    }

    /**
     * Create an instance of {@link BankingReferenceType }
     * 
     */
    public BankingReferenceType createBankingReferenceType() {
        return new BankingReferenceType();
    }

    /**
     * Create an instance of {@link BankingReferenceAndCreditorType }
     * 
     */
    public BankingReferenceAndCreditorType createBankingReferenceAndCreditorType() {
        return new BankingReferenceAndCreditorType();
    }

    /**
     * Create an instance of {@link BankingReferenceWithStatusType }
     * 
     */
    public BankingReferenceWithStatusType createBankingReferenceWithStatusType() {
        return new BankingReferenceWithStatusType();
    }

    /**
     * Create an instance of {@link BeneficiaryMinimumDataType }
     * 
     */
    public BeneficiaryMinimumDataType createBeneficiaryMinimumDataType() {
        return new BeneficiaryMinimumDataType();
    }

    /**
     * Create an instance of {@link BasisRateType }
     * 
     */
    public BasisRateType createBasisRateType() {
        return new BasisRateType();
    }

    /**
     * Create an instance of {@link BasisOptionalRateType }
     * 
     */
    public BasisOptionalRateType createBasisOptionalRateType() {
        return new BasisOptionalRateType();
    }

    /**
     * Create an instance of {@link CashBankAccountCommercialOfferInputType }
     * 
     */
    public CashBankAccountCommercialOfferInputType createCashBankAccountCommercialOfferInputType() {
        return new CashBankAccountCommercialOfferInputType();
    }

    /**
     * Create an instance of {@link CashBankAccountCommercialOfferType }
     * 
     */
    public CashBankAccountCommercialOfferType createCashBankAccountCommercialOfferType() {
        return new CashBankAccountCommercialOfferType();
    }

    /**
     * Create an instance of {@link CashBankAccountIdentificationType }
     * 
     */
    public CashBankAccountIdentificationType createCashBankAccountIdentificationType() {
        return new CashBankAccountIdentificationType();
    }

    /**
     * Create an instance of {@link CashBankAccountFinancialOperationInputType }
     * 
     */
    public CashBankAccountFinancialOperationInputType createCashBankAccountFinancialOperationInputType() {
        return new CashBankAccountFinancialOperationInputType();
    }

    /**
     * Create an instance of {@link CashBankAccountPeriodicDepositDataType }
     * 
     */
    public CashBankAccountPeriodicDepositDataType createCashBankAccountPeriodicDepositDataType() {
        return new CashBankAccountPeriodicDepositDataType();
    }

    /**
     * Create an instance of {@link CashBankAccountPeriodicDepositDataInputType }
     * 
     */
    public CashBankAccountPeriodicDepositDataInputType createCashBankAccountPeriodicDepositDataInputType() {
        return new CashBankAccountPeriodicDepositDataInputType();
    }

    /**
     * Create an instance of {@link CashBankAccountInitialDepositType }
     * 
     */
    public CashBankAccountInitialDepositType createCashBankAccountInitialDepositType() {
        return new CashBankAccountInitialDepositType();
    }

    /**
     * Create an instance of {@link CashBankAccountLinkedObjectsType }
     * 
     */
    public CashBankAccountLinkedObjectsType createCashBankAccountLinkedObjectsType() {
        return new CashBankAccountLinkedObjectsType();
    }

    /**
     * Create an instance of {@link CashBankAccountLinkedObjectsInputType }
     * 
     */
    public CashBankAccountLinkedObjectsInputType createCashBankAccountLinkedObjectsInputType() {
        return new CashBankAccountLinkedObjectsInputType();
    }

    /**
     * Create an instance of {@link CashBankAccountType }
     * 
     */
    public CashBankAccountType createCashBankAccountType() {
        return new CashBankAccountType();
    }

    /**
     * Create an instance of {@link CashBankAccountOperationInputType }
     * 
     */
    public CashBankAccountOperationInputType createCashBankAccountOperationInputType() {
        return new CashBankAccountOperationInputType();
    }

    /**
     * Create an instance of {@link CashBankAccountPeriodicDepositInputType }
     * 
     */
    public CashBankAccountPeriodicDepositInputType createCashBankAccountPeriodicDepositInputType() {
        return new CashBankAccountPeriodicDepositInputType();
    }

    /**
     * Create an instance of {@link CashBankAccountStatementBlalanceType }
     * 
     */
    public CashBankAccountStatementBlalanceType createCashBankAccountStatementBlalanceType() {
        return new CashBankAccountStatementBlalanceType();
    }

    /**
     * Create an instance of {@link CashBankAccountStatementDataType }
     * 
     */
    public CashBankAccountStatementDataType createCashBankAccountStatementDataType() {
        return new CashBankAccountStatementDataType();
    }

    /**
     * Create an instance of {@link CashBankAccountStatementLinkedObjectsType }
     * 
     */
    public CashBankAccountStatementLinkedObjectsType createCashBankAccountStatementLinkedObjectsType() {
        return new CashBankAccountStatementLinkedObjectsType();
    }

    /**
     * Create an instance of {@link CashBankAccountPeriodicDepositType }
     * 
     */
    public CashBankAccountPeriodicDepositType createCashBankAccountPeriodicDepositType() {
        return new CashBankAccountPeriodicDepositType();
    }

    /**
     * Create an instance of {@link CashBankAccountStatementEntryType }
     * 
     */
    public CashBankAccountStatementEntryType createCashBankAccountStatementEntryType() {
        return new CashBankAccountStatementEntryType();
    }

    /**
     * Create an instance of {@link CashBankAccountyStatementStatusType }
     * 
     */
    public CashBankAccountyStatementStatusType createCashBankAccountyStatementStatusType() {
        return new CashBankAccountyStatementStatusType();
    }

    /**
     * Create an instance of {@link CashBankAccountStatusType }
     * 
     */
    public CashBankAccountStatusType createCashBankAccountStatusType() {
        return new CashBankAccountStatusType();
    }

    /**
     * Create an instance of {@link CashBankProductSharedDataType }
     * 
     */
    public CashBankProductSharedDataType createCashBankProductSharedDataType() {
        return new CashBankProductSharedDataType();
    }

    /**
     * Create an instance of {@link CashBalanceType }
     * 
     */
    public CashBalanceType createCashBalanceType() {
        return new CashBalanceType();
    }

    /**
     * Create an instance of {@link CardTransactionDataType }
     * 
     */
    public CardTransactionDataType createCardTransactionDataType() {
        return new CardTransactionDataType();
    }

    /**
     * Create an instance of {@link CardTransactionType }
     * 
     */
    public CardTransactionType createCardTransactionType() {
        return new CardTransactionType();
    }

    /**
     * Create an instance of {@link ClaimBenefitPaymentType }
     * 
     */
    public ClaimBenefitPaymentType createClaimBenefitPaymentType() {
        return new ClaimBenefitPaymentType();
    }

    /**
     * Create an instance of {@link ClaimEventOriginInputDataType }
     * 
     */
    public ClaimEventOriginInputDataType createClaimEventOriginInputDataType() {
        return new ClaimEventOriginInputDataType();
    }

    /**
     * Create an instance of {@link ClaimDeclarationEmploymentDataType }
     * 
     */
    public ClaimDeclarationEmploymentDataType createClaimDeclarationEmploymentDataType() {
        return new ClaimDeclarationEmploymentDataType();
    }

    /**
     * Create an instance of {@link ClaimDeclarationRequestInputDataType }
     * 
     */
    public ClaimDeclarationRequestInputDataType createClaimDeclarationRequestInputDataType() {
        return new ClaimDeclarationRequestInputDataType();
    }

    /**
     * Create an instance of {@link ClaimDeclarationLinkedObjectedInputType }
     * 
     */
    public ClaimDeclarationLinkedObjectedInputType createClaimDeclarationLinkedObjectedInputType() {
        return new ClaimDeclarationLinkedObjectedInputType();
    }

    /**
     * Create an instance of {@link CommercialCommunicationType }
     * 
     */
    public CommercialCommunicationType createCommercialCommunicationType() {
        return new CommercialCommunicationType();
    }

    /**
     * Create an instance of {@link CommercialOfferSharedDataApplicationInputType }
     * 
     */
    public CommercialOfferSharedDataApplicationInputType createCommercialOfferSharedDataApplicationInputType() {
        return new CommercialOfferSharedDataApplicationInputType();
    }

    /**
     * Create an instance of {@link CommercialOfferSharedDataApplicationType }
     * 
     */
    public CommercialOfferSharedDataApplicationType createCommercialOfferSharedDataApplicationType() {
        return new CommercialOfferSharedDataApplicationType();
    }

    /**
     * Create an instance of {@link ContactIdentityType }
     * 
     */
    public ContactIdentityType createContactIdentityType() {
        return new ContactIdentityType();
    }

    /**
     * Create an instance of {@link CoreProductAndPackageDataType }
     * 
     */
    public CoreProductAndPackageDataType createCoreProductAndPackageDataType() {
        return new CoreProductAndPackageDataType();
    }

    /**
     * Create an instance of {@link CoreProductCountryApplicationType }
     * 
     */
    public CoreProductCountryApplicationType createCoreProductCountryApplicationType() {
        return new CoreProductCountryApplicationType();
    }

    /**
     * Create an instance of {@link CoreProductDistributionInformationType }
     * 
     */
    public CoreProductDistributionInformationType createCoreProductDistributionInformationType() {
        return new CoreProductDistributionInformationType();
    }

    /**
     * Create an instance of {@link CoreProductFeaturesType }
     * 
     */
    public CoreProductFeaturesType createCoreProductFeaturesType() {
        return new CoreProductFeaturesType();
    }

    /**
     * Create an instance of {@link CoreProductHierarchyType }
     * 
     */
    public CoreProductHierarchyType createCoreProductHierarchyType() {
        return new CoreProductHierarchyType();
    }

    /**
     * Create an instance of {@link CoreProductIdentificationAndHierarchyDataType }
     * 
     */
    public CoreProductIdentificationAndHierarchyDataType createCoreProductIdentificationAndHierarchyDataType() {
        return new CoreProductIdentificationAndHierarchyDataType();
    }

    /**
     * Create an instance of {@link CoreProductObjectStatusType }
     * 
     */
    public CoreProductObjectStatusType createCoreProductObjectStatusType() {
        return new CoreProductObjectStatusType();
    }

    /**
     * Create an instance of {@link CoreProductOfferDataType }
     * 
     */
    public CoreProductOfferDataType createCoreProductOfferDataType() {
        return new CoreProductOfferDataType();
    }

    /**
     * Create an instance of {@link CoreProductOfferType }
     * 
     */
    public CoreProductOfferType createCoreProductOfferType() {
        return new CoreProductOfferType();
    }

    /**
     * Create an instance of {@link CoreProductTechnicalStatusType }
     * 
     */
    public CoreProductTechnicalStatusType createCoreProductTechnicalStatusType() {
        return new CoreProductTechnicalStatusType();
    }

    /**
     * Create an instance of {@link CoverAuthorizedBenficiaryClauseDataType }
     * 
     */
    public CoverAuthorizedBenficiaryClauseDataType createCoverAuthorizedBenficiaryClauseDataType() {
        return new CoverAuthorizedBenficiaryClauseDataType();
    }

    /**
     * Create an instance of {@link CoverBeneficiaryClauseType }
     * 
     */
    public CoverBeneficiaryClauseType createCoverBeneficiaryClauseType() {
        return new CoverBeneficiaryClauseType();
    }

    /**
     * Create an instance of {@link CoverBeneficiaryClauseInputType }
     * 
     */
    public CoverBeneficiaryClauseInputType createCoverBeneficiaryClauseInputType() {
        return new CoverBeneficiaryClauseInputType();
    }

    /**
     * Create an instance of {@link CoverExitBenefitDataType }
     * 
     */
    public CoverExitBenefitDataType createCoverExitBenefitDataType() {
        return new CoverExitBenefitDataType();
    }

    /**
     * Create an instance of {@link CoverIdentificationInputType }
     * 
     */
    public CoverIdentificationInputType createCoverIdentificationInputType() {
        return new CoverIdentificationInputType();
    }

    /**
     * Create an instance of {@link CoverIdentificationType }
     * 
     */
    public CoverIdentificationType createCoverIdentificationType() {
        return new CoverIdentificationType();
    }

    /**
     * Create an instance of {@link CoverNamedBeneficiaryClauseInputType }
     * 
     */
    public CoverNamedBeneficiaryClauseInputType createCoverNamedBeneficiaryClauseInputType() {
        return new CoverNamedBeneficiaryClauseInputType();
    }

    /**
     * Create an instance of {@link CoverNamedBeneficiaryClauseType }
     * 
     */
    public CoverNamedBeneficiaryClauseType createCoverNamedBeneficiaryClauseType() {
        return new CoverNamedBeneficiaryClauseType();
    }

    /**
     * Create an instance of {@link CoverParticularExclusionType }
     * 
     */
    public CoverParticularExclusionType createCoverParticularExclusionType() {
        return new CoverParticularExclusionType();
    }

    /**
     * Create an instance of {@link CoverPremiumCalculationAndRevisabiltyTermsDataType }
     * 
     */
    public CoverPremiumCalculationAndRevisabiltyTermsDataType createCoverPremiumCalculationAndRevisabiltyTermsDataType() {
        return new CoverPremiumCalculationAndRevisabiltyTermsDataType();
    }

    /**
     * Create an instance of {@link CoverStandardExclusionDataType }
     * 
     */
    public CoverStandardExclusionDataType createCoverStandardExclusionDataType() {
        return new CoverStandardExclusionDataType();
    }

    /**
     * Create an instance of {@link CoverStatusType }
     * 
     */
    public CoverStatusType createCoverStatusType() {
        return new CoverStatusType();
    }

    /**
     * Create an instance of {@link CurrencyAndAmountType }
     * 
     */
    public CurrencyAndAmountType createCurrencyAndAmountType() {
        return new CurrencyAndAmountType();
    }

    /**
     * Create an instance of {@link CurrencyExchangeDataType }
     * 
     */
    public CurrencyExchangeDataType createCurrencyExchangeDataType() {
        return new CurrencyExchangeDataType();
    }

    /**
     * Create an instance of {@link CustomerGenericDataInputType }
     * 
     */
    public CustomerGenericDataInputType createCustomerGenericDataInputType() {
        return new CustomerGenericDataInputType();
    }

    /**
     * Create an instance of {@link CustomerGenericDataType }
     * 
     */
    public CustomerGenericDataType createCustomerGenericDataType() {
        return new CustomerGenericDataType();
    }

    /**
     * Create an instance of {@link CustomerHealthRiskInputType }
     * 
     */
    public CustomerHealthRiskInputType createCustomerHealthRiskInputType() {
        return new CustomerHealthRiskInputType();
    }

    /**
     * Create an instance of {@link CustomerHealthRiskType }
     * 
     */
    public CustomerHealthRiskType createCustomerHealthRiskType() {
        return new CustomerHealthRiskType();
    }

    /**
     * Create an instance of {@link CustomerCharacteristicsDataInputType }
     * 
     */
    public CustomerCharacteristicsDataInputType createCustomerCharacteristicsDataInputType() {
        return new CustomerCharacteristicsDataInputType();
    }

    /**
     * Create an instance of {@link CustomerCharacteristicsDataType }
     * 
     */
    public CustomerCharacteristicsDataType createCustomerCharacteristicsDataType() {
        return new CustomerCharacteristicsDataType();
    }

    /**
     * Create an instance of {@link CustomerExternalQualificationDataType }
     * 
     */
    public CustomerExternalQualificationDataType createCustomerExternalQualificationDataType() {
        return new CustomerExternalQualificationDataType();
    }

    /**
     * Create an instance of {@link CustomerLinkedObjectsInputType }
     * 
     */
    public CustomerLinkedObjectsInputType createCustomerLinkedObjectsInputType() {
        return new CustomerLinkedObjectsInputType();
    }

    /**
     * Create an instance of {@link CustomerLinkedObjectsType }
     * 
     */
    public CustomerLinkedObjectsType createCustomerLinkedObjectsType() {
        return new CustomerLinkedObjectsType();
    }

    /**
     * Create an instance of {@link CustomerLinkInputType }
     * 
     */
    public CustomerLinkInputType createCustomerLinkInputType() {
        return new CustomerLinkInputType();
    }

    /**
     * Create an instance of {@link CustomerLinkType }
     * 
     */
    public CustomerLinkType createCustomerLinkType() {
        return new CustomerLinkType();
    }

    /**
     * Create an instance of {@link CustomerManagementInformationInputType }
     * 
     */
    public CustomerManagementInformationInputType createCustomerManagementInformationInputType() {
        return new CustomerManagementInformationInputType();
    }

    /**
     * Create an instance of {@link CustomerManagementInformationType }
     * 
     */
    public CustomerManagementInformationType createCustomerManagementInformationType() {
        return new CustomerManagementInformationType();
    }

    /**
     * Create an instance of {@link DatePeriodType }
     * 
     */
    public DatePeriodType createDatePeriodType() {
        return new DatePeriodType();
    }

    /**
     * Create an instance of {@link DeductibleDataType }
     * 
     */
    public DeductibleDataType createDeductibleDataType() {
        return new DeductibleDataType();
    }

    /**
     * Create an instance of {@link DelgatedOperationType }
     * 
     */
    public DelgatedOperationType createDelgatedOperationType() {
        return new DelgatedOperationType();
    }

    /**
     * Create an instance of {@link DistrbutionAuthorizationDataType }
     * 
     */
    public DistrbutionAuthorizationDataType createDistrbutionAuthorizationDataType() {
        return new DistrbutionAuthorizationDataType();
    }

    /**
     * Create an instance of {@link DocumentCompositionActionType }
     * 
     */
    public DocumentCompositionActionType createDocumentCompositionActionType() {
        return new DocumentCompositionActionType();
    }

    /**
     * Create an instance of {@link DocumentDataInputType }
     * 
     */
    public DocumentDataInputType createDocumentDataInputType() {
        return new DocumentDataInputType();
    }

    /**
     * Create an instance of {@link DocumentDataType }
     * 
     */
    public DocumentDataType createDocumentDataType() {
        return new DocumentDataType();
    }

    /**
     * Create an instance of {@link DocumentIndexationTagsType }
     * 
     */
    public DocumentIndexationTagsType createDocumentIndexationTagsType() {
        return new DocumentIndexationTagsType();
    }

    /**
     * Create an instance of {@link DocumentStatusType }
     * 
     */
    public DocumentStatusType createDocumentStatusType() {
        return new DocumentStatusType();
    }

    /**
     * Create an instance of {@link DurationType }
     * 
     */
    public DurationType createDurationType() {
        return new DurationType();
    }

    /**
     * Create an instance of {@link EconomicActivityInputType }
     * 
     */
    public EconomicActivityInputType createEconomicActivityInputType() {
        return new EconomicActivityInputType();
    }

    /**
     * Create an instance of {@link EconomicActivityType }
     * 
     */
    public EconomicActivityType createEconomicActivityType() {
        return new EconomicActivityType();
    }

    /**
     * Create an instance of {@link EconomicBusinessActivityType }
     * 
     */
    public EconomicBusinessActivityType createEconomicBusinessActivityType() {
        return new EconomicBusinessActivityType();
    }

    /**
     * Create an instance of {@link ElectronicDocumentDataType }
     * 
     */
    public ElectronicDocumentDataType createElectronicDocumentDataType() {
        return new ElectronicDocumentDataType();
    }

    /**
     * Create an instance of {@link ElectronicDocumentFileDataType }
     * 
     */
    public ElectronicDocumentFileDataType createElectronicDocumentFileDataType() {
        return new ElectronicDocumentFileDataType();
    }

    /**
     * Create an instance of {@link EmailAddressInputType }
     * 
     */
    public EmailAddressInputType createEmailAddressInputType() {
        return new EmailAddressInputType();
    }

    /**
     * Create an instance of {@link EmailAddressType }
     * 
     */
    public EmailAddressType createEmailAddressType() {
        return new EmailAddressType();
    }

    /**
     * Create an instance of {@link EmploymentDataType }
     * 
     */
    public EmploymentDataType createEmploymentDataType() {
        return new EmploymentDataType();
    }

    /**
     * Create an instance of {@link EmployerDataType }
     * 
     */
    public EmployerDataType createEmployerDataType() {
        return new EmployerDataType();
    }

    /**
     * Create an instance of {@link EventStatusDataType }
     * 
     */
    public EventStatusDataType createEventStatusDataType() {
        return new EventStatusDataType();
    }

    /**
     * Create an instance of {@link ExtendedDescriptionType }
     * 
     */
    public ExtendedDescriptionType createExtendedDescriptionType() {
        return new ExtendedDescriptionType();
    }

    /**
     * Create an instance of {@link ExtendedFinancialFundIdentificationType }
     * 
     */
    public ExtendedFinancialFundIdentificationType createExtendedFinancialFundIdentificationType() {
        return new ExtendedFinancialFundIdentificationType();
    }

    /**
     * Create an instance of {@link ExtendedObjectContextType }
     * 
     */
    public ExtendedObjectContextType createExtendedObjectContextType() {
        return new ExtendedObjectContextType();
    }

    /**
     * Create an instance of {@link ExtendedPersonIdentificationAndRoleSubRoleType }
     * 
     */
    public ExtendedPersonIdentificationAndRoleSubRoleType createExtendedPersonIdentificationAndRoleSubRoleType() {
        return new ExtendedPersonIdentificationAndRoleSubRoleType();
    }

    /**
     * Create an instance of {@link ExtendedPersonIdentificationAndRoleType }
     * 
     */
    public ExtendedPersonIdentificationAndRoleType createExtendedPersonIdentificationAndRoleType() {
        return new ExtendedPersonIdentificationAndRoleType();
    }

    /**
     * Create an instance of {@link ExtendedProductSharedDataType }
     * 
     */
    public ExtendedProductSharedDataType createExtendedProductSharedDataType() {
        return new ExtendedProductSharedDataType();
    }

    /**
     * Create an instance of {@link ExtendedRateType }
     * 
     */
    public ExtendedRateType createExtendedRateType() {
        return new ExtendedRateType();
    }

    /**
     * Create an instance of {@link ExtraPremiumDataType }
     * 
     */
    public ExtraPremiumDataType createExtraPremiumDataType() {
        return new ExtraPremiumDataType();
    }

    /**
     * Create an instance of {@link ExtraPremiumType }
     * 
     */
    public ExtraPremiumType createExtraPremiumType() {
        return new ExtraPremiumType();
    }

    /**
     * Create an instance of {@link FeeDerogationType }
     * 
     */
    public FeeDerogationType createFeeDerogationType() {
        return new FeeDerogationType();
    }

    /**
     * Create an instance of {@link FeeDerogationInputType }
     * 
     */
    public FeeDerogationInputType createFeeDerogationInputType() {
        return new FeeDerogationInputType();
    }

    /**
     * Create an instance of {@link FeeType }
     * 
     */
    public FeeType createFeeType() {
        return new FeeType();
    }

    /**
     * Create an instance of {@link FilePublicationDataType }
     * 
     */
    public FilePublicationDataType createFilePublicationDataType() {
        return new FilePublicationDataType();
    }

    /**
     * Create an instance of {@link FinancialInstrumentIdentificationType }
     * 
     */
    public FinancialInstrumentIdentificationType createFinancialInstrumentIdentificationType() {
        return new FinancialInstrumentIdentificationType();
    }

    /**
     * Create an instance of {@link FinancialFundDistributionType }
     * 
     */
    public FinancialFundDistributionType createFinancialFundDistributionType() {
        return new FinancialFundDistributionType();
    }

    /**
     * Create an instance of {@link FinancialFundIdentificationType }
     * 
     */
    public FinancialFundIdentificationType createFinancialFundIdentificationType() {
        return new FinancialFundIdentificationType();
    }

    /**
     * Create an instance of {@link FinancialIndexAndRateDataType }
     * 
     */
    public FinancialIndexAndRateDataType createFinancialIndexAndRateDataType() {
        return new FinancialIndexAndRateDataType();
    }

    /**
     * Create an instance of {@link FinancialIndexAndRatePriceType }
     * 
     */
    public FinancialIndexAndRatePriceType createFinancialIndexAndRatePriceType() {
        return new FinancialIndexAndRatePriceType();
    }

    /**
     * Create an instance of {@link FinancialIndexAndRateStatusType }
     * 
     */
    public FinancialIndexAndRateStatusType createFinancialIndexAndRateStatusType() {
        return new FinancialIndexAndRateStatusType();
    }

    /**
     * Create an instance of {@link FinancialRatingType }
     * 
     */
    public FinancialRatingType createFinancialRatingType() {
        return new FinancialRatingType();
    }

    /**
     * Create an instance of {@link FreeExtentionPointType }
     * 
     */
    public FreeExtentionPointType createFreeExtentionPointType() {
        return new FreeExtentionPointType();
    }

    /**
     * Create an instance of {@link FrequencyDataType }
     * 
     */
    public FrequencyDataType createFrequencyDataType() {
        return new FrequencyDataType();
    }

    /**
     * Create an instance of {@link FundFeeDerogationDataInputType }
     * 
     */
    public FundFeeDerogationDataInputType createFundFeeDerogationDataInputType() {
        return new FundFeeDerogationDataInputType();
    }

    /**
     * Create an instance of {@link FundFeeDerogationDataType }
     * 
     */
    public FundFeeDerogationDataType createFundFeeDerogationDataType() {
        return new FundFeeDerogationDataType();
    }

    /**
     * Create an instance of {@link FundClassFeeDerogationDataInputType }
     * 
     */
    public FundClassFeeDerogationDataInputType createFundClassFeeDerogationDataInputType() {
        return new FundClassFeeDerogationDataInputType();
    }

    /**
     * Create an instance of {@link FundClassFeeDerogationDataType }
     * 
     */
    public FundClassFeeDerogationDataType createFundClassFeeDerogationDataType() {
        return new FundClassFeeDerogationDataType();
    }

    /**
     * Create an instance of {@link FundStatementType }
     * 
     */
    public FundStatementType createFundStatementType() {
        return new FundStatementType();
    }

    /**
     * Create an instance of {@link FundStatementDataType }
     * 
     */
    public FundStatementDataType createFundStatementDataType() {
        return new FundStatementDataType();
    }

    /**
     * Create an instance of {@link FundStatementPerStatusDataType }
     * 
     */
    public FundStatementPerStatusDataType createFundStatementPerStatusDataType() {
        return new FundStatementPerStatusDataType();
    }

    /**
     * Create an instance of {@link GenderPopulationRateType }
     * 
     */
    public GenderPopulationRateType createGenderPopulationRateType() {
        return new GenderPopulationRateType();
    }

    /**
     * Create an instance of {@link GlobalPartnerType }
     * 
     */
    public GlobalPartnerType createGlobalPartnerType() {
        return new GlobalPartnerType();
    }

    /**
     * Create an instance of {@link GroupPolicySharedDataType }
     * 
     */
    public GroupPolicySharedDataType createGroupPolicySharedDataType() {
        return new GroupPolicySharedDataType();
    }

    /**
     * Create an instance of {@link GoodsDataType }
     * 
     */
    public GoodsDataType createGoodsDataType() {
        return new GoodsDataType();
    }

    /**
     * Create an instance of {@link GoodsDataInputType }
     * 
     */
    public GoodsDataInputType createGoodsDataInputType() {
        return new GoodsDataInputType();
    }

    /**
     * Create an instance of {@link IdentificationType }
     * 
     */
    public IdentificationType createIdentificationType() {
        return new IdentificationType();
    }

    /**
     * Create an instance of {@link IdentificationtWithVersionType }
     * 
     */
    public IdentificationtWithVersionType createIdentificationtWithVersionType() {
        return new IdentificationtWithVersionType();
    }

    /**
     * Create an instance of {@link IncomeType }
     * 
     */
    public IncomeType createIncomeType() {
        return new IncomeType();
    }

    /**
     * Create an instance of {@link InitiatingEventType }
     * 
     */
    public InitiatingEventType createInitiatingEventType() {
        return new InitiatingEventType();
    }

    /**
     * Create an instance of {@link InitiatingEventInputType }
     * 
     */
    public InitiatingEventInputType createInitiatingEventInputType() {
        return new InitiatingEventInputType();
    }

    /**
     * Create an instance of {@link InsrdPopStatDataType }
     * 
     */
    public InsrdPopStatDataType createInsrdPopStatDataType() {
        return new InsrdPopStatDataType();
    }

    /**
     * Create an instance of {@link InsuredApplianceInputType }
     * 
     */
    public InsuredApplianceInputType createInsuredApplianceInputType() {
        return new InsuredApplianceInputType();
    }

    /**
     * Create an instance of {@link InsuredApplianceType }
     * 
     */
    public InsuredApplianceType createInsuredApplianceType() {
        return new InsuredApplianceType();
    }

    /**
     * Create an instance of {@link InsuredObjectDataType }
     * 
     */
    public InsuredObjectDataType createInsuredObjectDataType() {
        return new InsuredObjectDataType();
    }

    /**
     * Create an instance of {@link InsuredType }
     * 
     */
    public InsuredType createInsuredType() {
        return new InsuredType();
    }

    /**
     * Create an instance of {@link InterestFundStatementDataType }
     * 
     */
    public InterestFundStatementDataType createInterestFundStatementDataType() {
        return new InterestFundStatementDataType();
    }

    /**
     * Create an instance of {@link IntervalType }
     * 
     */
    public IntervalType createIntervalType() {
        return new IntervalType();
    }

    /**
     * Create an instance of {@link LegalEntityInputType }
     * 
     */
    public LegalEntityInputType createLegalEntityInputType() {
        return new LegalEntityInputType();
    }

    /**
     * Create an instance of {@link LegalEntityType }
     * 
     */
    public LegalEntityType createLegalEntityType() {
        return new LegalEntityType();
    }

    /**
     * Create an instance of {@link LoanCollateralPolicyType }
     * 
     */
    public LoanCollateralPolicyType createLoanCollateralPolicyType() {
        return new LoanCollateralPolicyType();
    }

    /**
     * Create an instance of {@link LoanDataInputType }
     * 
     */
    public LoanDataInputType createLoanDataInputType() {
        return new LoanDataInputType();
    }

    /**
     * Create an instance of {@link LoanDataType }
     * 
     */
    public LoanDataType createLoanDataType() {
        return new LoanDataType();
    }

    /**
     * Create an instance of {@link LoanInstallmentDataInputType }
     * 
     */
    public LoanInstallmentDataInputType createLoanInstallmentDataInputType() {
        return new LoanInstallmentDataInputType();
    }

    /**
     * Create an instance of {@link LoanInstallmentDataType }
     * 
     */
    public LoanInstallmentDataType createLoanInstallmentDataType() {
        return new LoanInstallmentDataType();
    }

    /**
     * Create an instance of {@link LoanInstallmentOrSchedulePaymentDataType }
     * 
     */
    public LoanInstallmentOrSchedulePaymentDataType createLoanInstallmentOrSchedulePaymentDataType() {
        return new LoanInstallmentOrSchedulePaymentDataType();
    }

    /**
     * Create an instance of {@link LoanInsuranceObjectDataType }
     * 
     */
    public LoanInsuranceObjectDataType createLoanInsuranceObjectDataType() {
        return new LoanInsuranceObjectDataType();
    }

    /**
     * Create an instance of {@link LoanInsuranceObjectDataInputType }
     * 
     */
    public LoanInsuranceObjectDataInputType createLoanInsuranceObjectDataInputType() {
        return new LoanInsuranceObjectDataInputType();
    }

    /**
     * Create an instance of {@link LoanLenderOrganismDataInputType }
     * 
     */
    public LoanLenderOrganismDataInputType createLoanLenderOrganismDataInputType() {
        return new LoanLenderOrganismDataInputType();
    }

    /**
     * Create an instance of {@link LoanLenderOrganismDataType }
     * 
     */
    public LoanLenderOrganismDataType createLoanLenderOrganismDataType() {
        return new LoanLenderOrganismDataType();
    }

    /**
     * Create an instance of {@link LoanInsuredObjectType }
     * 
     */
    public LoanInsuredObjectType createLoanInsuredObjectType() {
        return new LoanInsuredObjectType();
    }

    /**
     * Create an instance of {@link LoanPaymentScheduleInputType }
     * 
     */
    public LoanPaymentScheduleInputType createLoanPaymentScheduleInputType() {
        return new LoanPaymentScheduleInputType();
    }

    /**
     * Create an instance of {@link LoanStageDataType }
     * 
     */
    public LoanStageDataType createLoanStageDataType() {
        return new LoanStageDataType();
    }

    /**
     * Create an instance of {@link LocalType }
     * 
     */
    public LocalType createLocalType() {
        return new LocalType();
    }

    /**
     * Create an instance of {@link MailingDocumentRecipientDataType }
     * 
     */
    public MailingDocumentRecipientDataType createMailingDocumentRecipientDataType() {
        return new MailingDocumentRecipientDataType();
    }

    /**
     * Create an instance of {@link MailingDocumentRecipientEMailAddressType }
     * 
     */
    public MailingDocumentRecipientEMailAddressType createMailingDocumentRecipientEMailAddressType() {
        return new MailingDocumentRecipientEMailAddressType();
    }

    /**
     * Create an instance of {@link MailingDocumentSenderDataType }
     * 
     */
    public MailingDocumentSenderDataType createMailingDocumentSenderDataType() {
        return new MailingDocumentSenderDataType();
    }

    /**
     * Create an instance of {@link MailingDocumentSenderEMailAddressType }
     * 
     */
    public MailingDocumentSenderEMailAddressType createMailingDocumentSenderEMailAddressType() {
        return new MailingDocumentSenderEMailAddressType();
    }

    /**
     * Create an instance of {@link MandateDataType }
     * 
     */
    public MandateDataType createMandateDataType() {
        return new MandateDataType();
    }

    /**
     * Create an instance of {@link MandateDetailsType }
     * 
     */
    public MandateDetailsType createMandateDetailsType() {
        return new MandateDetailsType();
    }

    /**
     * Create an instance of {@link MandatoryDateTimePeriodType }
     * 
     */
    public MandatoryDateTimePeriodType createMandatoryDateTimePeriodType() {
        return new MandatoryDateTimePeriodType();
    }

    /**
     * Create an instance of {@link MatchedOperationDatatType }
     * 
     */
    public MatchedOperationDatatType createMatchedOperationDatatType() {
        return new MatchedOperationDatatType();
    }

    /**
     * Create an instance of {@link MatchedOperationLinkedObjectsType }
     * 
     */
    public MatchedOperationLinkedObjectsType createMatchedOperationLinkedObjectsType() {
        return new MatchedOperationLinkedObjectsType();
    }

    /**
     * Create an instance of {@link MatchedPaymentDataType }
     * 
     */
    public MatchedPaymentDataType createMatchedPaymentDataType() {
        return new MatchedPaymentDataType();
    }

    /**
     * Create an instance of {@link MatchingOperationDataType }
     * 
     */
    public MatchingOperationDataType createMatchingOperationDataType() {
        return new MatchingOperationDataType();
    }

    /**
     * Create an instance of {@link MatchingOperationLinkedObjectsType }
     * 
     */
    public MatchingOperationLinkedObjectsType createMatchingOperationLinkedObjectsType() {
        return new MatchingOperationLinkedObjectsType();
    }

    /**
     * Create an instance of {@link MoneyInMoneyOutPaymentDataType }
     * 
     */
    public MoneyInMoneyOutPaymentDataType createMoneyInMoneyOutPaymentDataType() {
        return new MoneyInMoneyOutPaymentDataType();
    }

    /**
     * Create an instance of {@link MoneyInMoneyOutDataType }
     * 
     */
    public MoneyInMoneyOutDataType createMoneyInMoneyOutDataType() {
        return new MoneyInMoneyOutDataType();
    }

    /**
     * Create an instance of {@link NaturalPersonInputType }
     * 
     */
    public NaturalPersonInputType createNaturalPersonInputType() {
        return new NaturalPersonInputType();
    }

    /**
     * Create an instance of {@link NaturalPersonType }
     * 
     */
    public NaturalPersonType createNaturalPersonType() {
        return new NaturalPersonType();
    }

    /**
     * Create an instance of {@link ObjectContextType }
     * 
     */
    public ObjectContextType createObjectContextType() {
        return new ObjectContextType();
    }

    /**
     * Create an instance of {@link ObjectIdentificationType }
     * 
     */
    public ObjectIdentificationType createObjectIdentificationType() {
        return new ObjectIdentificationType();
    }

    /**
     * Create an instance of {@link ObjectIdentificationWithVersionType }
     * 
     */
    public ObjectIdentificationWithVersionType createObjectIdentificationWithVersionType() {
        return new ObjectIdentificationWithVersionType();
    }

    /**
     * Create an instance of {@link ObjectStatusDataType }
     * 
     */
    public ObjectStatusDataType createObjectStatusDataType() {
        return new ObjectStatusDataType();
    }

    /**
     * Create an instance of {@link ObjectTypologyAndIdentificationType }
     * 
     */
    public ObjectTypologyAndIdentificationType createObjectTypologyAndIdentificationType() {
        return new ObjectTypologyAndIdentificationType();
    }

    /**
     * Create an instance of {@link OperationCoverIdentificationType }
     * 
     */
    public OperationCoverIdentificationType createOperationCoverIdentificationType() {
        return new OperationCoverIdentificationType();
    }

    /**
     * Create an instance of {@link OperationPaymentAllocationDataType }
     * 
     */
    public OperationPaymentAllocationDataType createOperationPaymentAllocationDataType() {
        return new OperationPaymentAllocationDataType();
    }

    /**
     * Create an instance of {@link OperationPaymentAllocationDataInputType }
     * 
     */
    public OperationPaymentAllocationDataInputType createOperationPaymentAllocationDataInputType() {
        return new OperationPaymentAllocationDataInputType();
    }

    /**
     * Create an instance of {@link OperationPaymentInstrumentDataType }
     * 
     */
    public OperationPaymentInstrumentDataType createOperationPaymentInstrumentDataType() {
        return new OperationPaymentInstrumentDataType();
    }

    /**
     * Create an instance of {@link OperationPaymentInstrumentDataInputType }
     * 
     */
    public OperationPaymentInstrumentDataInputType createOperationPaymentInstrumentDataInputType() {
        return new OperationPaymentInstrumentDataInputType();
    }

    /**
     * Create an instance of {@link OperationPaymentInputType }
     * 
     */
    public OperationPaymentInputType createOperationPaymentInputType() {
        return new OperationPaymentInputType();
    }

    /**
     * Create an instance of {@link OperationStatusType }
     * 
     */
    public OperationStatusType createOperationStatusType() {
        return new OperationStatusType();
    }

    /**
     * Create an instance of {@link OptionalDatePeriodType }
     * 
     */
    public OptionalDatePeriodType createOptionalDatePeriodType() {
        return new OptionalDatePeriodType();
    }

    /**
     * Create an instance of {@link OptionalDateTimePeriodType }
     * 
     */
    public OptionalDateTimePeriodType createOptionalDateTimePeriodType() {
        return new OptionalDateTimePeriodType();
    }

    /**
     * Create an instance of {@link PaymentCardDataType }
     * 
     */
    public PaymentCardDataType createPaymentCardDataType() {
        return new PaymentCardDataType();
    }

    /**
     * Create an instance of {@link PaymentCardUnderlyingObjectDataType }
     * 
     */
    public PaymentCardUnderlyingObjectDataType createPaymentCardUnderlyingObjectDataType() {
        return new PaymentCardUnderlyingObjectDataType();
    }

    /**
     * Create an instance of {@link PaymentMethodWithPayerType }
     * 
     */
    public PaymentMethodWithPayerType createPaymentMethodWithPayerType() {
        return new PaymentMethodWithPayerType();
    }

    /**
     * Create an instance of {@link PaymentMethodWithPayerInputType }
     * 
     */
    public PaymentMethodWithPayerInputType createPaymentMethodWithPayerInputType() {
        return new PaymentMethodWithPayerInputType();
    }

    /**
     * Create an instance of {@link PaymentSpecificRecipientType }
     * 
     */
    public PaymentSpecificRecipientType createPaymentSpecificRecipientType() {
        return new PaymentSpecificRecipientType();
    }

    /**
     * Create an instance of {@link PartnerPartyType }
     * 
     */
    public PartnerPartyType createPartnerPartyType() {
        return new PartnerPartyType();
    }

    /**
     * Create an instance of {@link PartyManagementInformationType }
     * 
     */
    public PartyManagementInformationType createPartyManagementInformationType() {
        return new PartyManagementInformationType();
    }

    /**
     * Create an instance of {@link PartytRiskInformationType }
     * 
     */
    public PartytRiskInformationType createPartytRiskInformationType() {
        return new PartytRiskInformationType();
    }

    /**
     * Create an instance of {@link PartyRoleType }
     * 
     */
    public PartyRoleType createPartyRoleType() {
        return new PartyRoleType();
    }

    /**
     * Create an instance of {@link PathologyType }
     * 
     */
    public PathologyType createPathologyType() {
        return new PathologyType();
    }

    /**
     * Create an instance of {@link PeriodicOperationSchedulerStatusDataType }
     * 
     */
    public PeriodicOperationSchedulerStatusDataType createPeriodicOperationSchedulerStatusDataType() {
        return new PeriodicOperationSchedulerStatusDataType();
    }

    /**
     * Create an instance of {@link PeriodicSavingsOperationDataInputType }
     * 
     */
    public PeriodicSavingsOperationDataInputType createPeriodicSavingsOperationDataInputType() {
        return new PeriodicSavingsOperationDataInputType();
    }

    /**
     * Create an instance of {@link PeriodicSavingsOperationDataType }
     * 
     */
    public PeriodicSavingsOperationDataType createPeriodicSavingsOperationDataType() {
        return new PeriodicSavingsOperationDataType();
    }

    /**
     * Create an instance of {@link PeriodicSavingsSchedulerDataInputType }
     * 
     */
    public PeriodicSavingsSchedulerDataInputType createPeriodicSavingsSchedulerDataInputType() {
        return new PeriodicSavingsSchedulerDataInputType();
    }

    /**
     * Create an instance of {@link PeriodicSavingsSchedulerDataType }
     * 
     */
    public PeriodicSavingsSchedulerDataType createPeriodicSavingsSchedulerDataType() {
        return new PeriodicSavingsSchedulerDataType();
    }

    /**
     * Create an instance of {@link PeriodicSwitchDataInputType }
     * 
     */
    public PeriodicSwitchDataInputType createPeriodicSwitchDataInputType() {
        return new PeriodicSwitchDataInputType();
    }

    /**
     * Create an instance of {@link PeriodicSwitchDataType }
     * 
     */
    public PeriodicSwitchDataType createPeriodicSwitchDataType() {
        return new PeriodicSwitchDataType();
    }

    /**
     * Create an instance of {@link PeriodicSwitchFundDistributionInputType }
     * 
     */
    public PeriodicSwitchFundDistributionInputType createPeriodicSwitchFundDistributionInputType() {
        return new PeriodicSwitchFundDistributionInputType();
    }

    /**
     * Create an instance of {@link PeriodicSwitchFundDistributionType }
     * 
     */
    public PeriodicSwitchFundDistributionType createPeriodicSwitchFundDistributionType() {
        return new PeriodicSwitchFundDistributionType();
    }

    /**
     * Create an instance of {@link PeriodType }
     * 
     */
    public PeriodType createPeriodType() {
        return new PeriodType();
    }

    /**
     * Create an instance of {@link PersonIdentificationAndRoleType }
     * 
     */
    public PersonIdentificationAndRoleType createPersonIdentificationAndRoleType() {
        return new PersonIdentificationAndRoleType();
    }

    /**
     * Create an instance of {@link PersonIdentificationAndRoleSubRoleType }
     * 
     */
    public PersonIdentificationAndRoleSubRoleType createPersonIdentificationAndRoleSubRoleType() {
        return new PersonIdentificationAndRoleSubRoleType();
    }

    /**
     * Create an instance of {@link PersonRoleAndSubRoleType }
     * 
     */
    public PersonRoleAndSubRoleType createPersonRoleAndSubRoleType() {
        return new PersonRoleAndSubRoleType();
    }

    /**
     * Create an instance of {@link PersonRoleType }
     * 
     */
    public PersonRoleType createPersonRoleType() {
        return new PersonRoleType();
    }

    /**
     * Create an instance of {@link PersonStatusType }
     * 
     */
    public PersonStatusType createPersonStatusType() {
        return new PersonStatusType();
    }

    /**
     * Create an instance of {@link PhoneAddressInputType }
     * 
     */
    public PhoneAddressInputType createPhoneAddressInputType() {
        return new PhoneAddressInputType();
    }

    /**
     * Create an instance of {@link PhoneAddressType }
     * 
     */
    public PhoneAddressType createPhoneAddressType() {
        return new PhoneAddressType();
    }

    /**
     * Create an instance of {@link PledgeDataInputType }
     * 
     */
    public PledgeDataInputType createPledgeDataInputType() {
        return new PledgeDataInputType();
    }

    /**
     * Create an instance of {@link PledgeDataType }
     * 
     */
    public PledgeDataType createPledgeDataType() {
        return new PledgeDataType();
    }

    /**
     * Create an instance of {@link PolicyBeneficiaryClauseInputType }
     * 
     */
    public PolicyBeneficiaryClauseInputType createPolicyBeneficiaryClauseInputType() {
        return new PolicyBeneficiaryClauseInputType();
    }

    /**
     * Create an instance of {@link PolicyBeneficiaryClauseType }
     * 
     */
    public PolicyBeneficiaryClauseType createPolicyBeneficiaryClauseType() {
        return new PolicyBeneficiaryClauseType();
    }

    /**
     * Create an instance of {@link PolicyCoverIdentificationType }
     * 
     */
    public PolicyCoverIdentificationType createPolicyCoverIdentificationType() {
        return new PolicyCoverIdentificationType();
    }

    /**
     * Create an instance of {@link PolicyEndorsementDataType }
     * 
     */
    public PolicyEndorsementDataType createPolicyEndorsementDataType() {
        return new PolicyEndorsementDataType();
    }

    /**
     * Create an instance of {@link PolicyNamedBeneficiaryClauseInputType }
     * 
     */
    public PolicyNamedBeneficiaryClauseInputType createPolicyNamedBeneficiaryClauseInputType() {
        return new PolicyNamedBeneficiaryClauseInputType();
    }

    /**
     * Create an instance of {@link PolicyNamedBeneficiaryClauseType }
     * 
     */
    public PolicyNamedBeneficiaryClauseType createPolicyNamedBeneficiaryClauseType() {
        return new PolicyNamedBeneficiaryClauseType();
    }

    /**
     * Create an instance of {@link PolicyStatDataType }
     * 
     */
    public PolicyStatDataType createPolicyStatDataType() {
        return new PolicyStatDataType();
    }

    /**
     * Create an instance of {@link PolicyStatementLinkedObjectType }
     * 
     */
    public PolicyStatementLinkedObjectType createPolicyStatementLinkedObjectType() {
        return new PolicyStatementLinkedObjectType();
    }

    /**
     * Create an instance of {@link PolicyTaxInformationType }
     * 
     */
    public PolicyTaxInformationType createPolicyTaxInformationType() {
        return new PolicyTaxInformationType();
    }

    /**
     * Create an instance of {@link PolicyTerminationDataType }
     * 
     */
    public PolicyTerminationDataType createPolicyTerminationDataType() {
        return new PolicyTerminationDataType();
    }

    /**
     * Create an instance of {@link PolicyUnderlyingLoanDataType }
     * 
     */
    public PolicyUnderlyingLoanDataType createPolicyUnderlyingLoanDataType() {
        return new PolicyUnderlyingLoanDataType();
    }

    /**
     * Create an instance of {@link PostalAddressType }
     * 
     */
    public PostalAddressType createPostalAddressType() {
        return new PostalAddressType();
    }

    /**
     * Create an instance of {@link PostalAddressInputType }
     * 
     */
    public PostalAddressInputType createPostalAddressInputType() {
        return new PostalAddressInputType();
    }

    /**
     * Create an instance of {@link PostalAddressWithValidityStatusType }
     * 
     */
    public PostalAddressWithValidityStatusType createPostalAddressWithValidityStatusType() {
        return new PostalAddressWithValidityStatusType();
    }

    /**
     * Create an instance of {@link PremiumPaymentType }
     * 
     */
    public PremiumPaymentType createPremiumPaymentType() {
        return new PremiumPaymentType();
    }

    /**
     * Create an instance of {@link PremiumRecoverySchemeDataType }
     * 
     */
    public PremiumRecoverySchemeDataType createPremiumRecoverySchemeDataType() {
        return new PremiumRecoverySchemeDataType();
    }

    /**
     * Create an instance of {@link PremiumStatDataType }
     * 
     */
    public PremiumStatDataType createPremiumStatDataType() {
        return new PremiumStatDataType();
    }

    /**
     * Create an instance of {@link PremiumTypeDataType }
     * 
     */
    public PremiumTypeDataType createPremiumTypeDataType() {
        return new PremiumTypeDataType();
    }

    /**
     * Create an instance of {@link ProcessUnitDataType }
     * 
     */
    public ProcessUnitDataType createProcessUnitDataType() {
        return new ProcessUnitDataType();
    }

    /**
     * Create an instance of {@link ProductAuthorizedOperationRequestDataType }
     * 
     */
    public ProductAuthorizedOperationRequestDataType createProductAuthorizedOperationRequestDataType() {
        return new ProductAuthorizedOperationRequestDataType();
    }

    /**
     * Create an instance of {@link ProductAuthorizedPaymentMethodDataType }
     * 
     */
    public ProductAuthorizedPaymentMethodDataType createProductAuthorizedPaymentMethodDataType() {
        return new ProductAuthorizedPaymentMethodDataType();
    }

    /**
     * Create an instance of {@link ProductCoverDataType }
     * 
     */
    public ProductCoverDataType createProductCoverDataType() {
        return new ProductCoverDataType();
    }

    /**
     * Create an instance of {@link ProductCoverLinkedObjectDataType }
     * 
     */
    public ProductCoverLinkedObjectDataType createProductCoverLinkedObjectDataType() {
        return new ProductCoverLinkedObjectDataType();
    }

    /**
     * Create an instance of {@link ProductFunctionalStatusDataType }
     * 
     */
    public ProductFunctionalStatusDataType createProductFunctionalStatusDataType() {
        return new ProductFunctionalStatusDataType();
    }

    /**
     * Create an instance of {@link ProductLoanDataTermsDataType }
     * 
     */
    public ProductLoanDataTermsDataType createProductLoanDataTermsDataType() {
        return new ProductLoanDataTermsDataType();
    }

    /**
     * Create an instance of {@link ProductManagementModeDataType }
     * 
     */
    public ProductManagementModeDataType createProductManagementModeDataType() {
        return new ProductManagementModeDataType();
    }

    /**
     * Create an instance of {@link ProductRiskIdentificationDataType }
     * 
     */
    public ProductRiskIdentificationDataType createProductRiskIdentificationDataType() {
        return new ProductRiskIdentificationDataType();
    }

    /**
     * Create an instance of {@link ProductAndLegalSchemeDataType }
     * 
     */
    public ProductAndLegalSchemeDataType createProductAndLegalSchemeDataType() {
        return new ProductAndLegalSchemeDataType();
    }

    /**
     * Create an instance of {@link ProductSharedDataType }
     * 
     */
    public ProductSharedDataType createProductSharedDataType() {
        return new ProductSharedDataType();
    }

    /**
     * Create an instance of {@link ProductSocioProfessionalCategoryDataType }
     * 
     */
    public ProductSocioProfessionalCategoryDataType createProductSocioProfessionalCategoryDataType() {
        return new ProductSocioProfessionalCategoryDataType();
    }

    /**
     * Create an instance of {@link ProfileAndFundDataType }
     * 
     */
    public ProfileAndFundDataType createProfileAndFundDataType() {
        return new ProfileAndFundDataType();
    }

    /**
     * Create an instance of {@link ProfitAndLossOperationDataType }
     * 
     */
    public ProfitAndLossOperationDataType createProfitAndLossOperationDataType() {
        return new ProfitAndLossOperationDataType();
    }

    /**
     * Create an instance of {@link ProfitAndLossOperationLinkedObjetsType }
     * 
     */
    public ProfitAndLossOperationLinkedObjetsType createProfitAndLossOperationLinkedObjetsType() {
        return new ProfitAndLossOperationLinkedObjetsType();
    }

    /**
     * Create an instance of {@link ProtectionClaimBenefitLinkedObjectsType }
     * 
     */
    public ProtectionClaimBenefitLinkedObjectsType createProtectionClaimBenefitLinkedObjectsType() {
        return new ProtectionClaimBenefitLinkedObjectsType();
    }

    /**
     * Create an instance of {@link ProtectionAggregatePolicyDataType }
     * 
     */
    public ProtectionAggregatePolicyDataType createProtectionAggregatePolicyDataType() {
        return new ProtectionAggregatePolicyDataType();
    }

    /**
     * Create an instance of {@link ProtectionAggregatePolicyLinkedObjectsDataType }
     * 
     */
    public ProtectionAggregatePolicyLinkedObjectsDataType createProtectionAggregatePolicyLinkedObjectsDataType() {
        return new ProtectionAggregatePolicyLinkedObjectsDataType();
    }

    /**
     * Create an instance of {@link ProtectionCoverDataType }
     * 
     */
    public ProtectionCoverDataType createProtectionCoverDataType() {
        return new ProtectionCoverDataType();
    }

    /**
     * Create an instance of {@link ProtectionCoversPackageDataType }
     * 
     */
    public ProtectionCoversPackageDataType createProtectionCoversPackageDataType() {
        return new ProtectionCoversPackageDataType();
    }

    /**
     * Create an instance of {@link ProtectionCoverFeaturesDataType }
     * 
     */
    public ProtectionCoverFeaturesDataType createProtectionCoverFeaturesDataType() {
        return new ProtectionCoverFeaturesDataType();
    }

    /**
     * Create an instance of {@link ProtectionCoverPremiumDataType }
     * 
     */
    public ProtectionCoverPremiumDataType createProtectionCoverPremiumDataType() {
        return new ProtectionCoverPremiumDataType();
    }

    /**
     * Create an instance of {@link ProtectionCoverPremiumLinkedObjectsType }
     * 
     */
    public ProtectionCoverPremiumLinkedObjectsType createProtectionCoverPremiumLinkedObjectsType() {
        return new ProtectionCoverPremiumLinkedObjectsType();
    }

    /**
     * Create an instance of {@link ProtectionCoverPremiumType }
     * 
     */
    public ProtectionCoverPremiumType createProtectionCoverPremiumType() {
        return new ProtectionCoverPremiumType();
    }

    /**
     * Create an instance of {@link ProtectionExtraPremiumDataType }
     * 
     */
    public ProtectionExtraPremiumDataType createProtectionExtraPremiumDataType() {
        return new ProtectionExtraPremiumDataType();
    }

    /**
     * Create an instance of {@link ProtectionPolicyClaimOptionsDataType }
     * 
     */
    public ProtectionPolicyClaimOptionsDataType createProtectionPolicyClaimOptionsDataType() {
        return new ProtectionPolicyClaimOptionsDataType();
    }

    /**
     * Create an instance of {@link ProtectionPolicyCoverDataType }
     * 
     */
    public ProtectionPolicyCoverDataType createProtectionPolicyCoverDataType() {
        return new ProtectionPolicyCoverDataType();
    }

    /**
     * Create an instance of {@link ProtectionPolicyCoverGenDataType }
     * 
     */
    public ProtectionPolicyCoverGenDataType createProtectionPolicyCoverGenDataType() {
        return new ProtectionPolicyCoverGenDataType();
    }

    /**
     * Create an instance of {@link ProtectionPolicyCoverLinkedObjectsType }
     * 
     */
    public ProtectionPolicyCoverLinkedObjectsType createProtectionPolicyCoverLinkedObjectsType() {
        return new ProtectionPolicyCoverLinkedObjectsType();
    }

    /**
     * Create an instance of {@link ProtectionPolicyCoverPremiumDataType }
     * 
     */
    public ProtectionPolicyCoverPremiumDataType createProtectionPolicyCoverPremiumDataType() {
        return new ProtectionPolicyCoverPremiumDataType();
    }

    /**
     * Create an instance of {@link ProtectionPolicyCoverPriceListType }
     * 
     */
    public ProtectionPolicyCoverPriceListType createProtectionPolicyCoverPriceListType() {
        return new ProtectionPolicyCoverPriceListType();
    }

    /**
     * Create an instance of {@link ProtectionPolicyCoverPricingRationaleType }
     * 
     */
    public ProtectionPolicyCoverPricingRationaleType createProtectionPolicyCoverPricingRationaleType() {
        return new ProtectionPolicyCoverPricingRationaleType();
    }

    /**
     * Create an instance of {@link ProtectionPolicyCoverSurchrgOrDiscntType }
     * 
     */
    public ProtectionPolicyCoverSurchrgOrDiscntType createProtectionPolicyCoverSurchrgOrDiscntType() {
        return new ProtectionPolicyCoverSurchrgOrDiscntType();
    }

    /**
     * Create an instance of {@link ProtectionPolicyDataType }
     * 
     */
    public ProtectionPolicyDataType createProtectionPolicyDataType() {
        return new ProtectionPolicyDataType();
    }

    /**
     * Create an instance of {@link ProtectionPolicyGenDataType }
     * 
     */
    public ProtectionPolicyGenDataType createProtectionPolicyGenDataType() {
        return new ProtectionPolicyGenDataType();
    }

    /**
     * Create an instance of {@link ProtectionPolicyLinkedObjectsInputType }
     * 
     */
    public ProtectionPolicyLinkedObjectsInputType createProtectionPolicyLinkedObjectsInputType() {
        return new ProtectionPolicyLinkedObjectsInputType();
    }

    /**
     * Create an instance of {@link ProtectionPolicyLinkedObjectsType }
     * 
     */
    public ProtectionPolicyLinkedObjectsType createProtectionPolicyLinkedObjectsType() {
        return new ProtectionPolicyLinkedObjectsType();
    }

    /**
     * Create an instance of {@link ProtectionPolicyStatusType }
     * 
     */
    public ProtectionPolicyStatusType createProtectionPolicyStatusType() {
        return new ProtectionPolicyStatusType();
    }

    /**
     * Create an instance of {@link ProtectionPremiumDataType }
     * 
     */
    public ProtectionPremiumDataType createProtectionPremiumDataType() {
        return new ProtectionPremiumDataType();
    }

    /**
     * Create an instance of {@link ProtectionPremiumFeeType }
     * 
     */
    public ProtectionPremiumFeeType createProtectionPremiumFeeType() {
        return new ProtectionPremiumFeeType();
    }

    /**
     * Create an instance of {@link ProtectionPremiumFeesCalculationDataType }
     * 
     */
    public ProtectionPremiumFeesCalculationDataType createProtectionPremiumFeesCalculationDataType() {
        return new ProtectionPremiumFeesCalculationDataType();
    }

    /**
     * Create an instance of {@link ProtectionPremiumLinkedObjectsType }
     * 
     */
    public ProtectionPremiumLinkedObjectsType createProtectionPremiumLinkedObjectsType() {
        return new ProtectionPremiumLinkedObjectsType();
    }

    /**
     * Create an instance of {@link ProtectionPremiumStatusType }
     * 
     */
    public ProtectionPremiumStatusType createProtectionPremiumStatusType() {
        return new ProtectionPremiumStatusType();
    }

    /**
     * Create an instance of {@link ProtectionProductFeaturesDataType }
     * 
     */
    public ProtectionProductFeaturesDataType createProtectionProductFeaturesDataType() {
        return new ProtectionProductFeaturesDataType();
    }

    /**
     * Create an instance of {@link ProtectionProductLinkedObjectsType }
     * 
     */
    public ProtectionProductLinkedObjectsType createProtectionProductLinkedObjectsType() {
        return new ProtectionProductLinkedObjectsType();
    }

    /**
     * Create an instance of {@link ProtectionSubscriptionStatusDataType }
     * 
     */
    public ProtectionSubscriptionStatusDataType createProtectionSubscriptionStatusDataType() {
        return new ProtectionSubscriptionStatusDataType();
    }

    /**
     * Create an instance of {@link PremiumOrBenefitRevisabilityTermsDataType }
     * 
     */
    public PremiumOrBenefitRevisabilityTermsDataType createPremiumOrBenefitRevisabilityTermsDataType() {
        return new PremiumOrBenefitRevisabilityTermsDataType();
    }

    /**
     * Create an instance of {@link ReferenceDataCodificationType }
     * 
     */
    public ReferenceDataCodificationType createReferenceDataCodificationType() {
        return new ReferenceDataCodificationType();
    }

    /**
     * Create an instance of {@link RemovedStandardExlusionType }
     * 
     */
    public RemovedStandardExlusionType createRemovedStandardExlusionType() {
        return new RemovedStandardExlusionType();
    }

    /**
     * Create an instance of {@link ReserveOperationLinkedObjectsDataType }
     * 
     */
    public ReserveOperationLinkedObjectsDataType createReserveOperationLinkedObjectsDataType() {
        return new ReserveOperationLinkedObjectsDataType();
    }

    /**
     * Create an instance of {@link ReserveStatDataType }
     * 
     */
    public ReserveStatDataType createReserveStatDataType() {
        return new ReserveStatDataType();
    }

    /**
     * Create an instance of {@link SavingsCoverBeneficiaryClauseType }
     * 
     */
    public SavingsCoverBeneficiaryClauseType createSavingsCoverBeneficiaryClauseType() {
        return new SavingsCoverBeneficiaryClauseType();
    }

    /**
     * Create an instance of {@link SavingsCoverDataInputType }
     * 
     */
    public SavingsCoverDataInputType createSavingsCoverDataInputType() {
        return new SavingsCoverDataInputType();
    }

    /**
     * Create an instance of {@link SavingsCoverDataType }
     * 
     */
    public SavingsCoverDataType createSavingsCoverDataType() {
        return new SavingsCoverDataType();
    }

    /**
     * Create an instance of {@link SavingsCoverNamedBeneficiaryClauseType }
     * 
     */
    public SavingsCoverNamedBeneficiaryClauseType createSavingsCoverNamedBeneficiaryClauseType() {
        return new SavingsCoverNamedBeneficiaryClauseType();
    }

    /**
     * Create an instance of {@link SavingsCoverStatementType }
     * 
     */
    public SavingsCoverStatementType createSavingsCoverStatementType() {
        return new SavingsCoverStatementType();
    }

    /**
     * Create an instance of {@link SavingsFeeType }
     * 
     */
    public SavingsFeeType createSavingsFeeType() {
        return new SavingsFeeType();
    }

    /**
     * Create an instance of {@link SavingsFinancialOperationLinkedObjectInputType }
     * 
     */
    public SavingsFinancialOperationLinkedObjectInputType createSavingsFinancialOperationLinkedObjectInputType() {
        return new SavingsFinancialOperationLinkedObjectInputType();
    }

    /**
     * Create an instance of {@link SavingsFundByOpeDataType }
     * 
     */
    public SavingsFundByOpeDataType createSavingsFundByOpeDataType() {
        return new SavingsFundByOpeDataType();
    }

    /**
     * Create an instance of {@link SavingsFundByOpeStatmtDataType }
     * 
     */
    public SavingsFundByOpeStatmtDataType createSavingsFundByOpeStatmtDataType() {
        return new SavingsFundByOpeStatmtDataType();
    }

    /**
     * Create an instance of {@link SavigsMovementStatusDataType }
     * 
     */
    public SavigsMovementStatusDataType createSavigsMovementStatusDataType() {
        return new SavigsMovementStatusDataType();
    }

    /**
     * Create an instance of {@link SavingsLoanBalanceType }
     * 
     */
    public SavingsLoanBalanceType createSavingsLoanBalanceType() {
        return new SavingsLoanBalanceType();
    }

    /**
     * Create an instance of {@link SavingsLoanStatementType }
     * 
     */
    public SavingsLoanStatementType createSavingsLoanStatementType() {
        return new SavingsLoanStatementType();
    }

    /**
     * Create an instance of {@link SavingsOperationFundDistributionInputType }
     * 
     */
    public SavingsOperationFundDistributionInputType createSavingsOperationFundDistributionInputType() {
        return new SavingsOperationFundDistributionInputType();
    }

    /**
     * Create an instance of {@link SavingsOperationFundDistributionType }
     * 
     */
    public SavingsOperationFundDistributionType createSavingsOperationFundDistributionType() {
        return new SavingsOperationFundDistributionType();
    }

    /**
     * Create an instance of {@link SavingsOperationFundMovementInputType }
     * 
     */
    public SavingsOperationFundMovementInputType createSavingsOperationFundMovementInputType() {
        return new SavingsOperationFundMovementInputType();
    }

    /**
     * Create an instance of {@link SavingsOperationStatementDataType }
     * 
     */
    public SavingsOperationStatementDataType createSavingsOperationStatementDataType() {
        return new SavingsOperationStatementDataType();
    }

    /**
     * Create an instance of {@link SavingsPolicyCoverDataInputType }
     * 
     */
    public SavingsPolicyCoverDataInputType createSavingsPolicyCoverDataInputType() {
        return new SavingsPolicyCoverDataInputType();
    }

    /**
     * Create an instance of {@link SavingsPolicyDataInputType }
     * 
     */
    public SavingsPolicyDataInputType createSavingsPolicyDataInputType() {
        return new SavingsPolicyDataInputType();
    }

    /**
     * Create an instance of {@link SavingsPolicyCoverDataType }
     * 
     */
    public SavingsPolicyCoverDataType createSavingsPolicyCoverDataType() {
        return new SavingsPolicyCoverDataType();
    }

    /**
     * Create an instance of {@link SavingsPolicyCoverLinkedObjectsType }
     * 
     */
    public SavingsPolicyCoverLinkedObjectsType createSavingsPolicyCoverLinkedObjectsType() {
        return new SavingsPolicyCoverLinkedObjectsType();
    }

    /**
     * Create an instance of {@link SavingsPolicyDataType }
     * 
     */
    public SavingsPolicyDataType createSavingsPolicyDataType() {
        return new SavingsPolicyDataType();
    }

    /**
     * Create an instance of {@link SavingsPolicyEndorsementDataType }
     * 
     */
    public SavingsPolicyEndorsementDataType createSavingsPolicyEndorsementDataType() {
        return new SavingsPolicyEndorsementDataType();
    }

    /**
     * Create an instance of {@link SpecifSavingsPolicyDataInputType }
     * 
     */
    public SpecifSavingsPolicyDataInputType createSpecifSavingsPolicyDataInputType() {
        return new SpecifSavingsPolicyDataInputType();
    }

    /**
     * Create an instance of {@link SavingsPolicyFeesDerogationInputType }
     * 
     */
    public SavingsPolicyFeesDerogationInputType createSavingsPolicyFeesDerogationInputType() {
        return new SavingsPolicyFeesDerogationInputType();
    }

    /**
     * Create an instance of {@link SavingsPolicyFeesDerogationType }
     * 
     */
    public SavingsPolicyFeesDerogationType createSavingsPolicyFeesDerogationType() {
        return new SavingsPolicyFeesDerogationType();
    }

    /**
     * Create an instance of {@link SavingsPolicyLinkedObjectsInputType }
     * 
     */
    public SavingsPolicyLinkedObjectsInputType createSavingsPolicyLinkedObjectsInputType() {
        return new SavingsPolicyLinkedObjectsInputType();
    }

    /**
     * Create an instance of {@link SavingsPolicyLinkedObjectsType }
     * 
     */
    public SavingsPolicyLinkedObjectsType createSavingsPolicyLinkedObjectsType() {
        return new SavingsPolicyLinkedObjectsType();
    }

    /**
     * Create an instance of {@link SavingsPolicyOutstandingBalanceType }
     * 
     */
    public SavingsPolicyOutstandingBalanceType createSavingsPolicyOutstandingBalanceType() {
        return new SavingsPolicyOutstandingBalanceType();
    }

    /**
     * Create an instance of {@link SavingsPolicyProfileInputType }
     * 
     */
    public SavingsPolicyProfileInputType createSavingsPolicyProfileInputType() {
        return new SavingsPolicyProfileInputType();
    }

    /**
     * Create an instance of {@link SavingsPolicyProfileType }
     * 
     */
    public SavingsPolicyProfileType createSavingsPolicyProfileType() {
        return new SavingsPolicyProfileType();
    }

    /**
     * Create an instance of {@link SavingsPolicyStatementDataType }
     * 
     */
    public SavingsPolicyStatementDataType createSavingsPolicyStatementDataType() {
        return new SavingsPolicyStatementDataType();
    }

    /**
     * Create an instance of {@link SavingsPolicyStatusType }
     * 
     */
    public SavingsPolicyStatusType createSavingsPolicyStatusType() {
        return new SavingsPolicyStatusType();
    }

    /**
     * Create an instance of {@link SavingsPolicyTaxSimulationType }
     * 
     */
    public SavingsPolicyTaxSimulationType createSavingsPolicyTaxSimulationType() {
        return new SavingsPolicyTaxSimulationType();
    }

    /**
     * Create an instance of {@link SavingsPremiumClassDataType }
     * 
     */
    public SavingsPremiumClassDataType createSavingsPremiumClassDataType() {
        return new SavingsPremiumClassDataType();
    }

    /**
     * Create an instance of {@link SeizureDataInputType }
     * 
     */
    public SeizureDataInputType createSeizureDataInputType() {
        return new SeizureDataInputType();
    }

    /**
     * Create an instance of {@link SeizureDataType }
     * 
     */
    public SeizureDataType createSeizureDataType() {
        return new SeizureDataType();
    }

    /**
     * Create an instance of {@link SenderOrReceiverType }
     * 
     */
    public SenderOrReceiverType createSenderOrReceiverType() {
        return new SenderOrReceiverType();
    }

    /**
     * Create an instance of {@link ServiceFeeOperationFeeDataType }
     * 
     */
    public ServiceFeeOperationFeeDataType createServiceFeeOperationFeeDataType() {
        return new ServiceFeeOperationFeeDataType();
    }

    /**
     * Create an instance of {@link ServiceFeeOperationLinkedObjetsType }
     * 
     */
    public ServiceFeeOperationLinkedObjetsType createServiceFeeOperationLinkedObjetsType() {
        return new ServiceFeeOperationLinkedObjetsType();
    }

    /**
     * Create an instance of {@link SimplifiedCustomerInputDataType }
     * 
     */
    public SimplifiedCustomerInputDataType createSimplifiedCustomerInputDataType() {
        return new SimplifiedCustomerInputDataType();
    }

    /**
     * Create an instance of {@link SimplifiedProtectionProductLinkedObjctsType }
     * 
     */
    public SimplifiedProtectionProductLinkedObjctsType createSimplifiedProtectionProductLinkedObjctsType() {
        return new SimplifiedProtectionProductLinkedObjctsType();
    }

    /**
     * Create an instance of {@link ThirdPartyFinancialRatiosType }
     * 
     */
    public ThirdPartyFinancialRatiosType createThirdPartyFinancialRatiosType() {
        return new ThirdPartyFinancialRatiosType();
    }

    /**
     * Create an instance of {@link SpecificAddressInputType }
     * 
     */
    public SpecificAddressInputType createSpecificAddressInputType() {
        return new SpecificAddressInputType();
    }

    /**
     * Create an instance of {@link SpecificAddressType }
     * 
     */
    public SpecificAddressType createSpecificAddressType() {
        return new SpecificAddressType();
    }

    /**
     * Create an instance of {@link SpecifPeriodicSavingsSchedulerDataInputType }
     * 
     */
    public SpecifPeriodicSavingsSchedulerDataInputType createSpecifPeriodicSavingsSchedulerDataInputType() {
        return new SpecifPeriodicSavingsSchedulerDataInputType();
    }

    /**
     * Create an instance of {@link SpecifPeriodicSavingsSchedulerDataType }
     * 
     */
    public SpecifPeriodicSavingsSchedulerDataType createSpecifPeriodicSavingsSchedulerDataType() {
        return new SpecifPeriodicSavingsSchedulerDataType();
    }

    /**
     * Create an instance of {@link SpecifPolicyTaxInformationInputType }
     * 
     */
    public SpecifPolicyTaxInformationInputType createSpecifPolicyTaxInformationInputType() {
        return new SpecifPolicyTaxInformationInputType();
    }

    /**
     * Create an instance of {@link SpecifPolicyTaxInformationType }
     * 
     */
    public SpecifPolicyTaxInformationType createSpecifPolicyTaxInformationType() {
        return new SpecifPolicyTaxInformationType();
    }

    /**
     * Create an instance of {@link SpecifSavingsPolicyDataType }
     * 
     */
    public SpecifSavingsPolicyDataType createSpecifSavingsPolicyDataType() {
        return new SpecifSavingsPolicyDataType();
    }

    /**
     * Create an instance of {@link StandardConditionDataType }
     * 
     */
    public StandardConditionDataType createStandardConditionDataType() {
        return new StandardConditionDataType();
    }

    /**
     * Create an instance of {@link StatementStatusType }
     * 
     */
    public StatementStatusType createStatementStatusType() {
        return new StatementStatusType();
    }

    /**
     * Create an instance of {@link StatementAdditionalAmountType }
     * 
     */
    public StatementAdditionalAmountType createStatementAdditionalAmountType() {
        return new StatementAdditionalAmountType();
    }

    /**
     * Create an instance of {@link StructureElementDataType }
     * 
     */
    public StructureElementDataType createStructureElementDataType() {
        return new StructureElementDataType();
    }

    /**
     * Create an instance of {@link StructureElementLinkedObjectsType }
     * 
     */
    public StructureElementLinkedObjectsType createStructureElementLinkedObjectsType() {
        return new StructureElementLinkedObjectsType();
    }

    /**
     * Create an instance of {@link StructureElementStatusType }
     * 
     */
    public StructureElementStatusType createStructureElementStatusType() {
        return new StructureElementStatusType();
    }

    /**
     * Create an instance of {@link StructuredPhoneAddressType }
     * 
     */
    public StructuredPhoneAddressType createStructuredPhoneAddressType() {
        return new StructuredPhoneAddressType();
    }

    /**
     * Create an instance of {@link SubscriptionCoverDataInputType }
     * 
     */
    public SubscriptionCoverDataInputType createSubscriptionCoverDataInputType() {
        return new SubscriptionCoverDataInputType();
    }

    /**
     * Create an instance of {@link SubscriptionPackageFeatureDataInputType }
     * 
     */
    public SubscriptionPackageFeatureDataInputType createSubscriptionPackageFeatureDataInputType() {
        return new SubscriptionPackageFeatureDataInputType();
    }

    /**
     * Create an instance of {@link SubscriptionPackageDataInputType }
     * 
     */
    public SubscriptionPackageDataInputType createSubscriptionPackageDataInputType() {
        return new SubscriptionPackageDataInputType();
    }

    /**
     * Create an instance of {@link SummaryControlReportType }
     * 
     */
    public SummaryControlReportType createSummaryControlReportType() {
        return new SummaryControlReportType();
    }

    /**
     * Create an instance of {@link SwitchConditionType }
     * 
     */
    public SwitchConditionType createSwitchConditionType() {
        return new SwitchConditionType();
    }

    /**
     * Create an instance of {@link SwitchSchedulerDataInputType }
     * 
     */
    public SwitchSchedulerDataInputType createSwitchSchedulerDataInputType() {
        return new SwitchSchedulerDataInputType();
    }

    /**
     * Create an instance of {@link SwitchSchedulerDataType }
     * 
     */
    public SwitchSchedulerDataType createSwitchSchedulerDataType() {
        return new SwitchSchedulerDataType();
    }

    /**
     * Create an instance of {@link SwitchTriggerType }
     * 
     */
    public SwitchTriggerType createSwitchTriggerType() {
        return new SwitchTriggerType();
    }

    /**
     * Create an instance of {@link TargetPopulationDataType }
     * 
     */
    public TargetPopulationDataType createTargetPopulationDataType() {
        return new TargetPopulationDataType();
    }

    /**
     * Create an instance of {@link TaxType }
     * 
     */
    public TaxType createTaxType() {
        return new TaxType();
    }

    /**
     * Create an instance of {@link TaxInformationInputType }
     * 
     */
    public TaxInformationInputType createTaxInformationInputType() {
        return new TaxInformationInputType();
    }

    /**
     * Create an instance of {@link TaxInformationType }
     * 
     */
    public TaxInformationType createTaxInformationType() {
        return new TaxInformationType();
    }

    /**
     * Create an instance of {@link TimePeriodType }
     * 
     */
    public TimePeriodType createTimePeriodType() {
        return new TimePeriodType();
    }

    /**
     * Create an instance of {@link ThirdPartyCharacteristicsDataType }
     * 
     */
    public ThirdPartyCharacteristicsDataType createThirdPartyCharacteristicsDataType() {
        return new ThirdPartyCharacteristicsDataType();
    }

    /**
     * Create an instance of {@link ThirdPartyLinkedObjectsType }
     * 
     */
    public ThirdPartyLinkedObjectsType createThirdPartyLinkedObjectsType() {
        return new ThirdPartyLinkedObjectsType();
    }

    /**
     * Create an instance of {@link ThirdPartyLinkType }
     * 
     */
    public ThirdPartyLinkType createThirdPartyLinkType() {
        return new ThirdPartyLinkType();
    }

    /**
     * Create an instance of {@link UnitFundStatementDataType }
     * 
     */
    public UnitFundStatementDataType createUnitFundStatementDataType() {
        return new UnitFundStatementDataType();
    }

    /**
     * Create an instance of {@link UserType }
     * 
     */
    public UserType createUserType() {
        return new UserType();
    }

    /**
     * Create an instance of {@link ValueDataType }
     * 
     */
    public ValueDataType createValueDataType() {
        return new ValueDataType();
    }

    /**
     * Create an instance of {@link VehiculeDataType }
     * 
     */
    public VehiculeDataType createVehiculeDataType() {
        return new VehiculeDataType();
    }

    /**
     * Create an instance of {@link WebAddressInputType }
     * 
     */
    public WebAddressInputType createWebAddressInputType() {
        return new WebAddressInputType();
    }

    /**
     * Create an instance of {@link WebAddressType }
     * 
     */
    public WebAddressType createWebAddressType() {
        return new WebAddressType();
    }

    /**
     * Create an instance of {@link Wording }
     * 
     */
    public Wording createWording() {
        return new Wording();
    }

    /**
     * Create an instance of {@link BeneficiaryClaimBenefitDataType }
     * 
     */
    public BeneficiaryClaimBenefitDataType createBeneficiaryClaimBenefitDataType() {
        return new BeneficiaryClaimBenefitDataType();
    }

    /**
     * Create an instance of {@link BeneficiaryClaimBenefitPaymentType }
     * 
     */
    public BeneficiaryClaimBenefitPaymentType createBeneficiaryClaimBenefitPaymentType() {
        return new BeneficiaryClaimBenefitPaymentType();
    }

    /**
     * Create an instance of {@link BeneficiaryClaimBenefitType }
     * 
     */
    public BeneficiaryClaimBenefitType createBeneficiaryClaimBenefitType() {
        return new BeneficiaryClaimBenefitType();
    }

    /**
     * Create an instance of {@link ClaimActionType }
     * 
     */
    public ClaimActionType createClaimActionType() {
        return new ClaimActionType();
    }

    /**
     * Create an instance of {@link ClaimDeclarationStatusDataType }
     * 
     */
    public ClaimDeclarationStatusDataType createClaimDeclarationStatusDataType() {
        return new ClaimDeclarationStatusDataType();
    }

    /**
     * Create an instance of {@link ClaimFileDataType }
     * 
     */
    public ClaimFileDataType createClaimFileDataType() {
        return new ClaimFileDataType();
    }

    /**
     * Create an instance of {@link ClaimFileLinkedObjectsType }
     * 
     */
    public ClaimFileLinkedObjectsType createClaimFileLinkedObjectsType() {
        return new ClaimFileLinkedObjectsType();
    }

    /**
     * Create an instance of {@link ClaimBenefitDataType }
     * 
     */
    public ClaimBenefitDataType createClaimBenefitDataType() {
        return new ClaimBenefitDataType();
    }

    /**
     * Create an instance of {@link ClaimBenefitType }
     * 
     */
    public ClaimBenefitType createClaimBenefitType() {
        return new ClaimBenefitType();
    }

    /**
     * Create an instance of {@link ClaimBenefitStatusType }
     * 
     */
    public ClaimBenefitStatusType createClaimBenefitStatusType() {
        return new ClaimBenefitStatusType();
    }

    /**
     * Create an instance of {@link ClaimStudyDataType }
     * 
     */
    public ClaimStudyDataType createClaimStudyDataType() {
        return new ClaimStudyDataType();
    }

    /**
     * Create an instance of {@link ClaimStudyFunctionalStatusDataType }
     * 
     */
    public ClaimStudyFunctionalStatusDataType createClaimStudyFunctionalStatusDataType() {
        return new ClaimStudyFunctionalStatusDataType();
    }

    /**
     * Create an instance of {@link ClaimStudyLinkedObjectsType }
     * 
     */
    public ClaimStudyLinkedObjectsType createClaimStudyLinkedObjectsType() {
        return new ClaimStudyLinkedObjectsType();
    }

    /**
     * Create an instance of {@link ClaimStudyPointType }
     * 
     */
    public ClaimStudyPointType createClaimStudyPointType() {
        return new ClaimStudyPointType();
    }

    /**
     * Create an instance of {@link ClaimStudyType }
     * 
     */
    public ClaimStudyType createClaimStudyType() {
        return new ClaimStudyType();
    }

    /**
     * Create an instance of {@link ExpertReportDataType }
     * 
     */
    public ExpertReportDataType createExpertReportDataType() {
        return new ExpertReportDataType();
    }

    /**
     * Create an instance of {@link ExpertReportType }
     * 
     */
    public ExpertReportType createExpertReportType() {
        return new ExpertReportType();
    }

    /**
     * Create an instance of {@link ThirdPartyDecisionDataType }
     * 
     */
    public ThirdPartyDecisionDataType createThirdPartyDecisionDataType() {
        return new ThirdPartyDecisionDataType();
    }

    /**
     * Create an instance of {@link ThirdPartyDecisionType }
     * 
     */
    public ThirdPartyDecisionType createThirdPartyDecisionType() {
        return new ThirdPartyDecisionType();
    }

    /**
     * Create an instance of {@link CoverClaimTermsDataInputType }
     * 
     */
    public CoverClaimTermsDataInputType createCoverClaimTermsDataInputType() {
        return new CoverClaimTermsDataInputType();
    }

    /**
     * Create an instance of {@link ProtectionPolicyDataInputType }
     * 
     */
    public ProtectionPolicyDataInputType createProtectionPolicyDataInputType() {
        return new ProtectionPolicyDataInputType();
    }

    /**
     * Create an instance of {@link ProtectionCoverDataInputType }
     * 
     */
    public ProtectionCoverDataInputType createProtectionCoverDataInputType() {
        return new ProtectionCoverDataInputType();
    }

    /**
     * Create an instance of {@link ProtectionPremiumOptionsDataType }
     * 
     */
    public ProtectionPremiumOptionsDataType createProtectionPremiumOptionsDataType() {
        return new ProtectionPremiumOptionsDataType();
    }

    /**
     * Create an instance of {@link ProtectionCoverPremiumOptionsDataType }
     * 
     */
    public ProtectionCoverPremiumOptionsDataType createProtectionCoverPremiumOptionsDataType() {
        return new ProtectionCoverPremiumOptionsDataType();
    }

    /**
     * Create an instance of {@link ProtectionPolicyCoverDataInputType }
     * 
     */
    public ProtectionPolicyCoverDataInputType createProtectionPolicyCoverDataInputType() {
        return new ProtectionPolicyCoverDataInputType();
    }

    /**
     * Create an instance of {@link ProtectionPolicyCoverLinkedObjectsInputType }
     * 
     */
    public ProtectionPolicyCoverLinkedObjectsInputType createProtectionPolicyCoverLinkedObjectsInputType() {
        return new ProtectionPolicyCoverLinkedObjectsInputType();
    }

    /**
     * Create an instance of {@link LegalIdentityDocType }
     * 
     */
    public LegalIdentityDocType createLegalIdentityDocType() {
        return new LegalIdentityDocType();
    }

    /**
     * Create an instance of {@link MeasureType }
     * 
     */
    public MeasureType createMeasureType() {
        return new MeasureType();
    }

    /**
     * Create an instance of {@link RateByStageType }
     * 
     */
    public RateByStageType createRateByStageType() {
        return new RateByStageType();
    }

    /**
     * Create an instance of {@link LoanStageDataInputType }
     * 
     */
    public LoanStageDataInputType createLoanStageDataInputType() {
        return new LoanStageDataInputType();
    }

    /**
     * Create an instance of {@link AmortizationDataInputType }
     * 
     */
    public AmortizationDataInputType createAmortizationDataInputType() {
        return new AmortizationDataInputType();
    }

    /**
     * Create an instance of {@link BrokerCommissionInputType }
     * 
     */
    public BrokerCommissionInputType createBrokerCommissionInputType() {
        return new BrokerCommissionInputType();
    }

    /**
     * Create an instance of {@link DocumentAnnotationDataType }
     * 
     */
    public DocumentAnnotationDataType createDocumentAnnotationDataType() {
        return new DocumentAnnotationDataType();
    }

    /**
     * Create an instance of {@link LocalLabelType }
     * 
     */
    public LocalLabelType createLocalLabelType() {
        return new LocalLabelType();
    }

    /**
     * Create an instance of {@link FolderDataType }
     * 
     */
    public FolderDataType createFolderDataType() {
        return new FolderDataType();
    }

    /**
     * Create an instance of {@link DocumentIdntfctnType }
     * 
     */
    public DocumentIdntfctnType createDocumentIdntfctnType() {
        return new DocumentIdntfctnType();
    }

    /**
     * Create an instance of {@link DocumentEnterpriseObjectType }
     * 
     */
    public DocumentEnterpriseObjectType createDocumentEnterpriseObjectType() {
        return new DocumentEnterpriseObjectType();
    }

    /**
     * Create an instance of {@link DocumentBusinessStatusType }
     * 
     */
    public DocumentBusinessStatusType createDocumentBusinessStatusType() {
        return new DocumentBusinessStatusType();
    }

    /**
     * Create an instance of {@link DocumentTechnicalActionType }
     * 
     */
    public DocumentTechnicalActionType createDocumentTechnicalActionType() {
        return new DocumentTechnicalActionType();
    }

    /**
     * Create an instance of {@link DocumentTechnicalMetadataType }
     * 
     */
    public DocumentTechnicalMetadataType createDocumentTechnicalMetadataType() {
        return new DocumentTechnicalMetadataType();
    }

    /**
     * Create an instance of {@link DocumentTechnicalDataType }
     * 
     */
    public DocumentTechnicalDataType createDocumentTechnicalDataType() {
        return new DocumentTechnicalDataType();
    }

    /**
     * Create an instance of {@link DocumentNatureType }
     * 
     */
    public DocumentNatureType createDocumentNatureType() {
        return new DocumentNatureType();
    }

    /**
     * Create an instance of {@link ActualDataFlowContentType }
     * 
     */
    public ActualDataFlowContentType createActualDataFlowContentType() {
        return new ActualDataFlowContentType();
    }

    /**
     * Create an instance of {@link EDMSIdentificationType }
     * 
     */
    public EDMSIdentificationType createEDMSIdentificationType() {
        return new EDMSIdentificationType();
    }

    /**
     * Create an instance of {@link MetadataCryptographicDescriptionType }
     * 
     */
    public MetadataCryptographicDescriptionType createMetadataCryptographicDescriptionType() {
        return new MetadataCryptographicDescriptionType();
    }

    /**
     * Create an instance of {@link LosslessDataEncapsulationDescriptionType }
     * 
     */
    public LosslessDataEncapsulationDescriptionType createLosslessDataEncapsulationDescriptionType() {
        return new LosslessDataEncapsulationDescriptionType();
    }

    /**
     * Create an instance of {@link MetadataUnivrslDescriptionType }
     * 
     */
    public MetadataUnivrslDescriptionType createMetadataUnivrslDescriptionType() {
        return new MetadataUnivrslDescriptionType();
    }

    /**
     * Create an instance of {@link EmbeddedCatalogueMetadataType }
     * 
     */
    public EmbeddedCatalogueMetadataType createEmbeddedCatalogueMetadataType() {
        return new EmbeddedCatalogueMetadataType();
    }

    /**
     * Create an instance of {@link MetadataType }
     * 
     */
    public MetadataType createMetadataType() {
        return new MetadataType();
    }

    /**
     * Create an instance of {@link MetadataGroupType }
     * 
     */
    public MetadataGroupType createMetadataGroupType() {
        return new MetadataGroupType();
    }

    /**
     * Create an instance of {@link MetadataGroupContextType }
     * 
     */
    public MetadataGroupContextType createMetadataGroupContextType() {
        return new MetadataGroupContextType();
    }

    /**
     * Create an instance of {@link FeedbackReportRecordDetailsType }
     * 
     */
    public FeedbackReportRecordDetailsType createFeedbackReportRecordDetailsType() {
        return new FeedbackReportRecordDetailsType();
    }

    /**
     * Create an instance of {@link XattrType }
     * 
     */
    public XattrType createXattrType() {
        return new XattrType();
    }

    /**
     * Create an instance of {@link FeedbackReportRecordDataType }
     * 
     */
    public FeedbackReportRecordDataType createFeedbackReportRecordDataType() {
        return new FeedbackReportRecordDataType();
    }

    /**
     * Create an instance of {@link Tag }
     * 
     */
    public Tag createTag() {
        return new Tag();
    }

    /**
     * Create an instance of {@link DocumentClassDataType.Status }
     * 
     */
    public DocumentClassDataType.Status createDocumentClassDataTypeStatus() {
        return new DocumentClassDataType.Status();
    }

    /**
     * Create an instance of {@link ThirdPartyContactWithAddressType.CntctIdnty }
     * 
     */
    public ThirdPartyContactWithAddressType.CntctIdnty createThirdPartyContactWithAddressTypeCntctIdnty() {
        return new ThirdPartyContactWithAddressType.CntctIdnty();
    }

    /**
     * Create an instance of {@link ThirdPartyContactType.CntctIdnty }
     * 
     */
    public ThirdPartyContactType.CntctIdnty createThirdPartyContactTypeCntctIdnty() {
        return new ThirdPartyContactType.CntctIdnty();
    }

    /**
     * Create an instance of {@link ThirdPartyContactInputType.CntctIdnty }
     * 
     */
    public ThirdPartyContactInputType.CntctIdnty createThirdPartyContactInputTypeCntctIdnty() {
        return new ThirdPartyContactInputType.CntctIdnty();
    }

    /**
     * Create an instance of {@link SubscriptionQuestionnaryDataInputType.RspnseData }
     * 
     */
    public SubscriptionQuestionnaryDataInputType.RspnseData createSubscriptionQuestionnaryDataInputTypeRspnseData() {
        return new SubscriptionQuestionnaryDataInputType.RspnseData();
    }

    /**
     * Create an instance of {@link StructureElementParentType.LinkData }
     * 
     */
    public StructureElementParentType.LinkData createStructureElementParentTypeLinkData() {
        return new StructureElementParentType.LinkData();
    }

    /**
     * Create an instance of {@link SimplifiedProtectionProductDataType.RnwalData }
     * 
     */
    public SimplifiedProtectionProductDataType.RnwalData createSimplifiedProtectionProductDataTypeRnwalData() {
        return new SimplifiedProtectionProductDataType.RnwalData();
    }

    /**
     * Create an instance of {@link SimplifiedProtectionCoversPackageDataType.CovIdntfctn }
     * 
     */
    public SimplifiedProtectionCoversPackageDataType.CovIdntfctn createSimplifiedProtectionCoversPackageDataTypeCovIdntfctn() {
        return new SimplifiedProtectionCoversPackageDataType.CovIdntfctn();
    }

    /**
     * Create an instance of {@link SimplifiedProtectiionCoverDataType.Idntfctn }
     * 
     */
    public SimplifiedProtectiionCoverDataType.Idntfctn createSimplifiedProtectiionCoverDataTypeIdntfctn() {
        return new SimplifiedProtectiionCoverDataType.Idntfctn();
    }

    /**
     * Create an instance of {@link SimplifiedProtectiionCoverDataType.Data }
     * 
     */
    public SimplifiedProtectiionCoverDataType.Data createSimplifiedProtectiionCoverDataTypeData() {
        return new SimplifiedProtectiionCoverDataType.Data();
    }

    /**
     * Create an instance of {@link SimplifiedProtectiionCoverDataType.Fee.Basis }
     * 
     */
    public SimplifiedProtectiionCoverDataType.Fee.Basis createSimplifiedProtectiionCoverDataTypeFeeBasis() {
        return new SimplifiedProtectiionCoverDataType.Fee.Basis();
    }

    /**
     * Create an instance of {@link SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis.AgeIntrvl }
     * 
     */
    public SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis.AgeIntrvl createSimplifiedProtectiionCoverDataTypePremCalctnTermsBasisAgeIntrvl() {
        return new SimplifiedProtectiionCoverDataType.Prem.CalctnTerms.Basis.AgeIntrvl();
    }

    /**
     * Create an instance of {@link SimplifiedProtectiionCoverDataType.ClaimTerms.Ddctble }
     * 
     */
    public SimplifiedProtectiionCoverDataType.ClaimTerms.Ddctble createSimplifiedProtectiionCoverDataTypeClaimTermsDdctble() {
        return new SimplifiedProtectiionCoverDataType.ClaimTerms.Ddctble();
    }

    /**
     * Create an instance of {@link SimplifiedProtectiionCoverDataType.ClaimTerms.Bnft }
     * 
     */
    public SimplifiedProtectiionCoverDataType.ClaimTerms.Bnft createSimplifiedProtectiionCoverDataTypeClaimTermsBnft() {
        return new SimplifiedProtectiionCoverDataType.ClaimTerms.Bnft();
    }

    /**
     * Create an instance of {@link SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms.SurndrPnlty }
     * 
     */
    public SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms.SurndrPnlty createSimplifiedProtectiionCoverDataTypeClaimTermsLoanBnftTermsSurndrPnlty() {
        return new SimplifiedProtectiionCoverDataType.ClaimTerms.LoanBnftTerms.SurndrPnlty();
    }

    /**
     * Create an instance of {@link SavingsOperationInputDataType.SpecificSwitchData }
     * 
     */
    public SavingsOperationInputDataType.SpecificSwitchData createSavingsOperationInputDataTypeSpecificSwitchData() {
        return new SavingsOperationInputDataType.SpecificSwitchData();
    }

    /**
     * Create an instance of {@link ReserveOperationDataType.SubRsrve }
     * 
     */
    public ReserveOperationDataType.SubRsrve createReserveOperationDataTypeSubRsrve() {
        return new ReserveOperationDataType.SubRsrve();
    }

    /**
     * Create an instance of {@link ProtectionProductDataType.SubscrAge }
     * 
     */
    public ProtectionProductDataType.SubscrAge createProtectionProductDataTypeSubscrAge() {
        return new ProtectionProductDataType.SubscrAge();
    }

    /**
     * Create an instance of {@link ProtectionProductDataType.PremPaymntTolrnce }
     * 
     */
    public ProtectionProductDataType.PremPaymntTolrnce createProtectionProductDataTypePremPaymntTolrnce() {
        return new ProtectionProductDataType.PremPaymntTolrnce();
    }

    /**
     * Create an instance of {@link ProtectionProductDataType.DurtnAndRnwal.Duratn }
     * 
     */
    public ProtectionProductDataType.DurtnAndRnwal.Duratn createProtectionProductDataTypeDurtnAndRnwalDuratn() {
        return new ProtectionProductDataType.DurtnAndRnwal.Duratn();
    }

    /**
     * Create an instance of {@link ProtectionProductDataType.DurtnAndRnwal.Rnwal }
     * 
     */
    public ProtectionProductDataType.DurtnAndRnwal.Rnwal createProtectionProductDataTypeDurtnAndRnwalRnwal() {
        return new ProtectionProductDataType.DurtnAndRnwal.Rnwal();
    }

    /**
     * Create an instance of {@link ProtectionOperationPaymentType.UniquePremPaymnt }
     * 
     */
    public ProtectionOperationPaymentType.UniquePremPaymnt createProtectionOperationPaymentTypeUniquePremPaymnt() {
        return new ProtectionOperationPaymentType.UniquePremPaymnt();
    }

    /**
     * Create an instance of {@link ProtectionClaimBenefitDataType.CovrdPrd }
     * 
     */
    public ProtectionClaimBenefitDataType.CovrdPrd createProtectionClaimBenefitDataTypeCovrdPrd() {
        return new ProtectionClaimBenefitDataType.CovrdPrd();
    }

    /**
     * Create an instance of {@link ProductOperationFeeTermsDataType.AmntRnge }
     * 
     */
    public ProductOperationFeeTermsDataType.AmntRnge createProductOperationFeeTermsDataTypeAmntRnge() {
        return new ProductOperationFeeTermsDataType.AmntRnge();
    }

    /**
     * Create an instance of {@link ProductOperationFeeTermsDataType.TimeRnge }
     * 
     */
    public ProductOperationFeeTermsDataType.TimeRnge createProductOperationFeeTermsDataTypeTimeRnge() {
        return new ProductOperationFeeTermsDataType.TimeRnge();
    }

    /**
     * Create an instance of {@link OriginPolicyType.TransfAmnt }
     * 
     */
    public OriginPolicyType.TransfAmnt createOriginPolicyTypeTransfAmnt() {
        return new OriginPolicyType.TransfAmnt();
    }

    /**
     * Create an instance of {@link OriginPolicyInputType.TransfAmnt }
     * 
     */
    public OriginPolicyInputType.TransfAmnt createOriginPolicyInputTypeTransfAmnt() {
        return new OriginPolicyInputType.TransfAmnt();
    }

    /**
     * Create an instance of {@link MoneyInMoneyOutLinkedObjectsType.LinkdMoneyInMoneyOut }
     * 
     */
    public MoneyInMoneyOutLinkedObjectsType.LinkdMoneyInMoneyOut createMoneyInMoneyOutLinkedObjectsTypeLinkdMoneyInMoneyOut() {
        return new MoneyInMoneyOutLinkedObjectsType.LinkdMoneyInMoneyOut();
    }

    /**
     * Create an instance of {@link MandateDataInputType.MndateData }
     * 
     */
    public MandateDataInputType.MndateData createMandateDataInputTypeMndateData() {
        return new MandateDataInputType.MndateData();
    }

    /**
     * Create an instance of {@link MainStructureDataType.Data }
     * 
     */
    public MainStructureDataType.Data createMainStructureDataTypeData() {
        return new MainStructureDataType.Data();
    }

    /**
     * Create an instance of {@link MailingDocumentPartType.ContentData }
     * 
     */
    public MailingDocumentPartType.ContentData createMailingDocumentPartTypeContentData() {
        return new MailingDocumentPartType.ContentData();
    }

    /**
     * Create an instance of {@link MailingDocumentDataType.SubmssionPrd }
     * 
     */
    public MailingDocumentDataType.SubmssionPrd createMailingDocumentDataTypeSubmssionPrd() {
        return new MailingDocumentDataType.SubmssionPrd();
    }

    /**
     * Create an instance of {@link DocumentCompositionOutputOptionType.Option }
     * 
     */
    public DocumentCompositionOutputOptionType.Option createDocumentCompositionOutputOptionTypeOption() {
        return new DocumentCompositionOutputOptionType.Option();
    }

    /**
     * Create an instance of {@link DocumentCompositionContextType.ReqData }
     * 
     */
    public DocumentCompositionContextType.ReqData createDocumentCompositionContextTypeReqData() {
        return new DocumentCompositionContextType.ReqData();
    }

    /**
     * Create an instance of {@link DocumentCompositionDataType.TmpltAndActns }
     * 
     */
    public DocumentCompositionDataType.TmpltAndActns createDocumentCompositionDataTypeTmpltAndActns() {
        return new DocumentCompositionDataType.TmpltAndActns();
    }

    /**
     * Create an instance of {@link DocumentCompositionDataType.RecrsveCmpstn.Data }
     * 
     */
    public DocumentCompositionDataType.RecrsveCmpstn.Data createDocumentCompositionDataTypeRecrsveCmpstnData() {
        return new DocumentCompositionDataType.RecrsveCmpstn.Data();
    }

    /**
     * Create an instance of {@link DistributionSpecificDataInputType.Opt }
     * 
     */
    public DistributionSpecificDataInputType.Opt createDistributionSpecificDataInputTypeOpt() {
        return new DistributionSpecificDataInputType.Opt();
    }

    /**
     * Create an instance of {@link DistributionSpecificDataInputType.SuggstdProf }
     * 
     */
    public DistributionSpecificDataInputType.SuggstdProf createDistributionSpecificDataInputTypeSuggstdProf() {
        return new DistributionSpecificDataInputType.SuggstdProf();
    }

    /**
     * Create an instance of {@link CoverPremiumCalculationRulesDataType.RatePerAge }
     * 
     */
    public CoverPremiumCalculationRulesDataType.RatePerAge createCoverPremiumCalculationRulesDataTypeRatePerAge() {
        return new CoverPremiumCalculationRulesDataType.RatePerAge();
    }

    /**
     * Create an instance of {@link CoverPremiumCalculationRulesDataType.RatePerAmnt }
     * 
     */
    public CoverPremiumCalculationRulesDataType.RatePerAmnt createCoverPremiumCalculationRulesDataTypeRatePerAmnt() {
        return new CoverPremiumCalculationRulesDataType.RatePerAmnt();
    }

    /**
     * Create an instance of {@link CoverPremiumFeeTermsDataType.AmntRnge }
     * 
     */
    public CoverPremiumFeeTermsDataType.AmntRnge createCoverPremiumFeeTermsDataTypeAmntRnge() {
        return new CoverPremiumFeeTermsDataType.AmntRnge();
    }

    /**
     * Create an instance of {@link CoverClaimTermsDataType.LoanExitBnft.SurndrPnlty }
     * 
     */
    public CoverClaimTermsDataType.LoanExitBnft.SurndrPnlty createCoverClaimTermsDataTypeLoanExitBnftSurndrPnlty() {
        return new CoverClaimTermsDataType.LoanExitBnft.SurndrPnlty();
    }

    /**
     * Create an instance of {@link CoverClaimTermsDataType.Ddctble.DdctblePrd }
     * 
     */
    public CoverClaimTermsDataType.Ddctble.DdctblePrd createCoverClaimTermsDataTypeDdctbleDdctblePrd() {
        return new CoverClaimTermsDataType.Ddctble.DdctblePrd();
    }

    /**
     * Create an instance of {@link ClaimDeclarationQuestionnaryDataType.RspnseData }
     * 
     */
    public ClaimDeclarationQuestionnaryDataType.RspnseData createClaimDeclarationQuestionnaryDataTypeRspnseData() {
        return new ClaimDeclarationQuestionnaryDataType.RspnseData();
    }

    /**
     * Create an instance of {@link BirthPlaceType.BrthArea }
     * 
     */
    public BirthPlaceType.BrthArea createBirthPlaceTypeBrthArea() {
        return new BirthPlaceType.BrthArea();
    }

    /**
     * Create an instance of {@link AcknowledgementActionAndErrorDataType.ActnData }
     * 
     */
    public AcknowledgementActionAndErrorDataType.ActnData createAcknowledgementActionAndErrorDataTypeActnData() {
        return new AcknowledgementActionAndErrorDataType.ActnData();
    }

    /**
     * Create an instance of {@link AcknowledgementActionAndErrorDataType.ErrDtail.SrceTag }
     * 
     */
    public AcknowledgementActionAndErrorDataType.ErrDtail.SrceTag createAcknowledgementActionAndErrorDataTypeErrDtailSrceTag() {
        return new AcknowledgementActionAndErrorDataType.ErrDtail.SrceTag();
    }

    /**
     * Create an instance of {@link AcknowledgementActionAndErrorDataType.ErrDtail.Data }
     * 
     */
    public AcknowledgementActionAndErrorDataType.ErrDtail.Data createAcknowledgementActionAndErrorDataTypeErrDtailData() {
        return new AcknowledgementActionAndErrorDataType.ErrDtail.Data();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Tags }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1", name = "Tags")
    public JAXBElement<Tags> createTags(Tags value) {
        return new JAXBElement<Tags>(_Tags_QNAME, Tags.class, null, value);
    }

}
