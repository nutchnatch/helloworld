
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Pourcentage de la
 * 				population du sexe mentioné
 * 			
 * 
 * <p>Java class for GenderPopulationRateType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GenderPopulationRateType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Gendr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GenderIndicatorCodeSLN"/&gt;
 *         &lt;element name="PopulationRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GenderPopulationRateType", propOrder = {
    "gendr",
    "populationRate"
})
public class GenderPopulationRateType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Gendr", required = true)
    protected String gendr;
    @XmlElement(name = "PopulationRate", required = true)
    protected BasisRateType populationRate;

    /**
     * Default no-arg constructor
     * 
     */
    public GenderPopulationRateType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public GenderPopulationRateType(final String gendr, final BasisRateType populationRate) {
        this.gendr = gendr;
        this.populationRate = populationRate;
    }

    /**
     * Gets the value of the gendr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGendr() {
        return gendr;
    }

    /**
     * Sets the value of the gendr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGendr(String value) {
        this.gendr = value;
    }

    public boolean isSetGendr() {
        return (this.gendr!= null);
    }

    /**
     * Gets the value of the populationRate property.
     * 
     * @return
     *     possible object is
     *     {@link BasisRateType }
     *     
     */
    public BasisRateType getPopulationRate() {
        return populationRate;
    }

    /**
     * Sets the value of the populationRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasisRateType }
     *     
     */
    public void setPopulationRate(BasisRateType value) {
        this.populationRate = value;
    }

    public boolean isSetPopulationRate() {
        return (this.populationRate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("gendr", gendr).add("populationRate", populationRate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(gendr, populationRate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final GenderPopulationRateType o = ((GenderPopulationRateType) other);
        return (Objects.equal(gendr, o.gendr)&&Objects.equal(populationRate, o.populationRate));
    }

}
