
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Statistic about insured population
 * 			
 * 
 * <p>Java class for InsrdPopStatDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InsrdPopStatDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ActrlAge" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType"/&gt;
 *         &lt;element name="PopRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}GenderPopulationRateType" maxOccurs="2"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InsrdPopStatDataType", propOrder = {
    "actrlAge",
    "popRate"
})
public class InsrdPopStatDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "ActrlAge")
    protected double actrlAge;
    @XmlElement(name = "PopRate", required = true)
    protected List<GenderPopulationRateType> popRate;

    /**
     * Default no-arg constructor
     * 
     */
    public InsrdPopStatDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public InsrdPopStatDataType(final double actrlAge, final List<GenderPopulationRateType> popRate) {
        this.actrlAge = actrlAge;
        this.popRate = popRate;
    }

    /**
     * Gets the value of the actrlAge property.
     * 
     */
    public double getActrlAge() {
        return actrlAge;
    }

    /**
     * Sets the value of the actrlAge property.
     * 
     */
    public void setActrlAge(double value) {
        this.actrlAge = value;
    }

    public boolean isSetActrlAge() {
        return true;
    }

    /**
     * Gets the value of the popRate property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the popRate property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPopRate().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GenderPopulationRateType }
     * 
     * 
     */
    public List<GenderPopulationRateType> getPopRate() {
        if (popRate == null) {
            popRate = new ArrayList<GenderPopulationRateType>();
        }
        return this.popRate;
    }

    public boolean isSetPopRate() {
        return ((this.popRate!= null)&&(!this.popRate.isEmpty()));
    }

    public void unsetPopRate() {
        this.popRate = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("actrlAge", actrlAge).add("popRate", popRate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(actrlAge, popRate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final InsrdPopStatDataType o = ((InsrdPopStatDataType) other);
        return (Objects.equal(actrlAge, o.actrlAge)&&Objects.equal(popRate, o.popRate));
    }

}
