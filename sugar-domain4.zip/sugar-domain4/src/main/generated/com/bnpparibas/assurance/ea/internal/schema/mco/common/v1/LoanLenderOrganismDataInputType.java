
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage information on a loan lender
 * 				organism
 * 			
 * 
 * <p>Java class for LoanLenderOrganismDataInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LoanLenderOrganismDataInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="PostAdrs" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PostalAddressInputType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Corrspndnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ThirdPartyContactInputType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LoanLenderOrganismDataInputType", propOrder = {
    "name",
    "postAdrs",
    "corrspndnt"
})
public class LoanLenderOrganismDataInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "PostAdrs")
    protected List<PostalAddressInputType> postAdrs;
    @XmlElement(name = "Corrspndnt")
    protected List<ThirdPartyContactInputType> corrspndnt;

    /**
     * Default no-arg constructor
     * 
     */
    public LoanLenderOrganismDataInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public LoanLenderOrganismDataInputType(final String name, final List<PostalAddressInputType> postAdrs, final List<ThirdPartyContactInputType> corrspndnt) {
        this.name = name;
        this.postAdrs = postAdrs;
        this.corrspndnt = corrspndnt;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the postAdrs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the postAdrs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPostAdrs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PostalAddressInputType }
     * 
     * 
     */
    public List<PostalAddressInputType> getPostAdrs() {
        if (postAdrs == null) {
            postAdrs = new ArrayList<PostalAddressInputType>();
        }
        return this.postAdrs;
    }

    public boolean isSetPostAdrs() {
        return ((this.postAdrs!= null)&&(!this.postAdrs.isEmpty()));
    }

    public void unsetPostAdrs() {
        this.postAdrs = null;
    }

    /**
     * Gets the value of the corrspndnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the corrspndnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCorrspndnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ThirdPartyContactInputType }
     * 
     * 
     */
    public List<ThirdPartyContactInputType> getCorrspndnt() {
        if (corrspndnt == null) {
            corrspndnt = new ArrayList<ThirdPartyContactInputType>();
        }
        return this.corrspndnt;
    }

    public boolean isSetCorrspndnt() {
        return ((this.corrspndnt!= null)&&(!this.corrspndnt.isEmpty()));
    }

    public void unsetCorrspndnt() {
        this.corrspndnt = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("name", name).add("postAdrs", postAdrs).add("corrspndnt", corrspndnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name, postAdrs, corrspndnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final LoanLenderOrganismDataInputType o = ((LoanLenderOrganismDataInputType) other);
        return ((Objects.equal(name, o.name)&&Objects.equal(postAdrs, o.postAdrs))&&Objects.equal(corrspndnt, o.corrspndnt));
    }

}
