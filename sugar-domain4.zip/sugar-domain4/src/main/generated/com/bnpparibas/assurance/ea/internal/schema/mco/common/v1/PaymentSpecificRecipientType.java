
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to define information for a specific recipient
 * 				of a payement. The recipient is not manager as a person in the
 * 				system
 * 			
 * 
 * <p>Java class for PaymentSpecificRecipientType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PaymentSpecificRecipientType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="FrstName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="PostAdrs" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PostalAddressInputType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PaymentSpecificRecipientType", propOrder = {
    "name",
    "frstName",
    "postAdrs"
})
public class PaymentSpecificRecipientType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "FrstName")
    protected String frstName;
    @XmlElement(name = "PostAdrs")
    protected PostalAddressInputType postAdrs;

    /**
     * Default no-arg constructor
     * 
     */
    public PaymentSpecificRecipientType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PaymentSpecificRecipientType(final String name, final String frstName, final PostalAddressInputType postAdrs) {
        this.name = name;
        this.frstName = frstName;
        this.postAdrs = postAdrs;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the frstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFrstName() {
        return frstName;
    }

    /**
     * Sets the value of the frstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFrstName(String value) {
        this.frstName = value;
    }

    public boolean isSetFrstName() {
        return (this.frstName!= null);
    }

    /**
     * Gets the value of the postAdrs property.
     * 
     * @return
     *     possible object is
     *     {@link PostalAddressInputType }
     *     
     */
    public PostalAddressInputType getPostAdrs() {
        return postAdrs;
    }

    /**
     * Sets the value of the postAdrs property.
     * 
     * @param value
     *     allowed object is
     *     {@link PostalAddressInputType }
     *     
     */
    public void setPostAdrs(PostalAddressInputType value) {
        this.postAdrs = value;
    }

    public boolean isSetPostAdrs() {
        return (this.postAdrs!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("name", name).add("frstName", frstName).add("postAdrs", postAdrs).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name, frstName, postAdrs);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PaymentSpecificRecipientType o = ((PaymentSpecificRecipientType) other);
        return ((Objects.equal(name, o.name)&&Objects.equal(frstName, o.frstName))&&Objects.equal(postAdrs, o.postAdrs));
    }

}
