
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * To describe the employment of a customer :
 * 				employer, start date of employment , length of service
 * 			
 * 
 * <p>Java class for EmploymentDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EmploymentDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Employer" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}EmployerDataType" minOccurs="0"/&gt;
 *         &lt;element name="EmplmntStartDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="ServLength" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DurationType" minOccurs="0"/&gt;
 *         &lt;element name="Salary" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AdditionalAmountType" maxOccurs="2" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EmploymentDataType", propOrder = {
    "employer",
    "emplmntStartDate",
    "servLength",
    "salary"
})
public class EmploymentDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Employer")
    protected EmployerDataType employer;
    @XmlElement(name = "EmplmntStartDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date emplmntStartDate;
    @XmlElement(name = "ServLength")
    protected DurationType servLength;
    @XmlElement(name = "Salary")
    protected List<AdditionalAmountType> salary;

    /**
     * Default no-arg constructor
     * 
     */
    public EmploymentDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public EmploymentDataType(final EmployerDataType employer, final Date emplmntStartDate, final DurationType servLength, final List<AdditionalAmountType> salary) {
        this.employer = employer;
        this.emplmntStartDate = emplmntStartDate;
        this.servLength = servLength;
        this.salary = salary;
    }

    /**
     * Gets the value of the employer property.
     * 
     * @return
     *     possible object is
     *     {@link EmployerDataType }
     *     
     */
    public EmployerDataType getEmployer() {
        return employer;
    }

    /**
     * Sets the value of the employer property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmployerDataType }
     *     
     */
    public void setEmployer(EmployerDataType value) {
        this.employer = value;
    }

    public boolean isSetEmployer() {
        return (this.employer!= null);
    }

    /**
     * Gets the value of the emplmntStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getEmplmntStartDate() {
        return emplmntStartDate;
    }

    /**
     * Sets the value of the emplmntStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmplmntStartDate(Date value) {
        this.emplmntStartDate = value;
    }

    public boolean isSetEmplmntStartDate() {
        return (this.emplmntStartDate!= null);
    }

    /**
     * Gets the value of the servLength property.
     * 
     * @return
     *     possible object is
     *     {@link DurationType }
     *     
     */
    public DurationType getServLength() {
        return servLength;
    }

    /**
     * Sets the value of the servLength property.
     * 
     * @param value
     *     allowed object is
     *     {@link DurationType }
     *     
     */
    public void setServLength(DurationType value) {
        this.servLength = value;
    }

    public boolean isSetServLength() {
        return (this.servLength!= null);
    }

    /**
     * Gets the value of the salary property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the salary property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSalary().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdditionalAmountType }
     * 
     * 
     */
    public List<AdditionalAmountType> getSalary() {
        if (salary == null) {
            salary = new ArrayList<AdditionalAmountType>();
        }
        return this.salary;
    }

    public boolean isSetSalary() {
        return ((this.salary!= null)&&(!this.salary.isEmpty()));
    }

    public void unsetSalary() {
        this.salary = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("employer", employer).add("emplmntStartDate", emplmntStartDate).add("servLength", servLength).add("salary", salary).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(employer, emplmntStartDate, servLength, salary);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final EmploymentDataType o = ((EmploymentDataType) other);
        return (((Objects.equal(employer, o.employer)&&Objects.equal(emplmntStartDate, o.emplmntStartDate))&&Objects.equal(servLength, o.servLength))&&Objects.equal(salary, o.salary));
    }

}
