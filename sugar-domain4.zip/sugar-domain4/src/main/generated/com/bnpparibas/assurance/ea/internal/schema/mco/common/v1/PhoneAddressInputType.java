
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type of address phone
 * 
 * <p>Java class for PhoneAddressInputType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PhoneAddressInputType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="UseType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ContactInformationUseTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="UseCntxt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}UseContextTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="LineType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PhoneLineTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="Unstruc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PhoneFormatType" minOccurs="0"/&gt;
 *         &lt;element name="Structed" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}StructuredPhoneAddressType" minOccurs="0"/&gt;
 *         &lt;element name="ValdtyDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PhoneAddressInputType", propOrder = {
    "useType",
    "useCntxt",
    "lineType",
    "unstruc",
    "structed",
    "valdtyDate"
})
public class PhoneAddressInputType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "UseType")
    protected String useType;
    @XmlElement(name = "UseCntxt")
    protected String useCntxt;
    @XmlElement(name = "LineType")
    protected String lineType;
    @XmlElement(name = "Unstruc")
    protected String unstruc;
    @XmlElement(name = "Structed")
    protected StructuredPhoneAddressType structed;
    @XmlElement(name = "ValdtyDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date valdtyDate;

    /**
     * Default no-arg constructor
     * 
     */
    public PhoneAddressInputType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public PhoneAddressInputType(final String useType, final String useCntxt, final String lineType, final String unstruc, final StructuredPhoneAddressType structed, final Date valdtyDate) {
        this.useType = useType;
        this.useCntxt = useCntxt;
        this.lineType = lineType;
        this.unstruc = unstruc;
        this.structed = structed;
        this.valdtyDate = valdtyDate;
    }

    /**
     * Gets the value of the useType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUseType() {
        return useType;
    }

    /**
     * Sets the value of the useType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUseType(String value) {
        this.useType = value;
    }

    public boolean isSetUseType() {
        return (this.useType!= null);
    }

    /**
     * Gets the value of the useCntxt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUseCntxt() {
        return useCntxt;
    }

    /**
     * Sets the value of the useCntxt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUseCntxt(String value) {
        this.useCntxt = value;
    }

    public boolean isSetUseCntxt() {
        return (this.useCntxt!= null);
    }

    /**
     * Gets the value of the lineType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLineType() {
        return lineType;
    }

    /**
     * Sets the value of the lineType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLineType(String value) {
        this.lineType = value;
    }

    public boolean isSetLineType() {
        return (this.lineType!= null);
    }

    /**
     * Gets the value of the unstruc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnstruc() {
        return unstruc;
    }

    /**
     * Sets the value of the unstruc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnstruc(String value) {
        this.unstruc = value;
    }

    public boolean isSetUnstruc() {
        return (this.unstruc!= null);
    }

    /**
     * Gets the value of the structed property.
     * 
     * @return
     *     possible object is
     *     {@link StructuredPhoneAddressType }
     *     
     */
    public StructuredPhoneAddressType getStructed() {
        return structed;
    }

    /**
     * Sets the value of the structed property.
     * 
     * @param value
     *     allowed object is
     *     {@link StructuredPhoneAddressType }
     *     
     */
    public void setStructed(StructuredPhoneAddressType value) {
        this.structed = value;
    }

    public boolean isSetStructed() {
        return (this.structed!= null);
    }

    /**
     * Gets the value of the valdtyDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getValdtyDate() {
        return valdtyDate;
    }

    /**
     * Sets the value of the valdtyDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValdtyDate(Date value) {
        this.valdtyDate = value;
    }

    public boolean isSetValdtyDate() {
        return (this.valdtyDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("useType", useType).add("useCntxt", useCntxt).add("lineType", lineType).add("unstruc", unstruc).add("structed", structed).add("valdtyDate", valdtyDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(useType, useCntxt, lineType, unstruc, structed, valdtyDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final PhoneAddressInputType o = ((PhoneAddressInputType) other);
        return (((((Objects.equal(useType, o.useType)&&Objects.equal(useCntxt, o.useCntxt))&&Objects.equal(lineType, o.lineType))&&Objects.equal(unstruc, o.unstruc))&&Objects.equal(structed, o.structed))&&Objects.equal(valdtyDate, o.valdtyDate));
    }

}
