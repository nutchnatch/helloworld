
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Cryptographic metadata
 * 				(NF Z 42 compliance, see
 * 				http://membres.multimania.fr/wingedstudio/download/nfz42013.pdf).
 * 			
 * 
 * <p>Java class for MetadataCryptographicDescriptionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MetadataCryptographicDescriptionType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CryptogrphcHashAlgo" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CryptographicHashAlgoCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="CryptogrphcHashValue" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}Base64BinaryType" minOccurs="0"/&gt;
 *         &lt;element name="DgtlSignAlgo" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DigitalSignatureAlgoCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="DgtlSignValue" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}Base64BinaryType" minOccurs="0"/&gt;
 *         &lt;element name="CryptogrphcAsymtricAlgo" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CryptographicAsymmetricAlgoCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="CryptogrphcSymtricAlgo" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CryptographicSymmetricAlgoCodeSLN" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MetadataCryptographicDescriptionType", propOrder = {
    "cryptogrphcHashAlgo",
    "cryptogrphcHashValue",
    "dgtlSignAlgo",
    "dgtlSignValue",
    "cryptogrphcAsymtricAlgo",
    "cryptogrphcSymtricAlgo"
})
public class MetadataCryptographicDescriptionType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CryptogrphcHashAlgo")
    protected String cryptogrphcHashAlgo;
    @XmlElement(name = "CryptogrphcHashValue")
    protected byte[] cryptogrphcHashValue;
    @XmlElement(name = "DgtlSignAlgo")
    protected String dgtlSignAlgo;
    @XmlElement(name = "DgtlSignValue")
    protected byte[] dgtlSignValue;
    @XmlElement(name = "CryptogrphcAsymtricAlgo")
    protected String cryptogrphcAsymtricAlgo;
    @XmlElement(name = "CryptogrphcSymtricAlgo")
    protected String cryptogrphcSymtricAlgo;

    /**
     * Default no-arg constructor
     * 
     */
    public MetadataCryptographicDescriptionType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MetadataCryptographicDescriptionType(final String cryptogrphcHashAlgo, final byte[] cryptogrphcHashValue, final String dgtlSignAlgo, final byte[] dgtlSignValue, final String cryptogrphcAsymtricAlgo, final String cryptogrphcSymtricAlgo) {
        this.cryptogrphcHashAlgo = cryptogrphcHashAlgo;
        this.cryptogrphcHashValue = cryptogrphcHashValue;
        this.dgtlSignAlgo = dgtlSignAlgo;
        this.dgtlSignValue = dgtlSignValue;
        this.cryptogrphcAsymtricAlgo = cryptogrphcAsymtricAlgo;
        this.cryptogrphcSymtricAlgo = cryptogrphcSymtricAlgo;
    }

    /**
     * Gets the value of the cryptogrphcHashAlgo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCryptogrphcHashAlgo() {
        return cryptogrphcHashAlgo;
    }

    /**
     * Sets the value of the cryptogrphcHashAlgo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCryptogrphcHashAlgo(String value) {
        this.cryptogrphcHashAlgo = value;
    }

    public boolean isSetCryptogrphcHashAlgo() {
        return (this.cryptogrphcHashAlgo!= null);
    }

    /**
     * Gets the value of the cryptogrphcHashValue property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getCryptogrphcHashValue() {
        return cryptogrphcHashValue;
    }

    /**
     * Sets the value of the cryptogrphcHashValue property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setCryptogrphcHashValue(byte[] value) {
        this.cryptogrphcHashValue = value;
    }

    public boolean isSetCryptogrphcHashValue() {
        return (this.cryptogrphcHashValue!= null);
    }

    /**
     * Gets the value of the dgtlSignAlgo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDgtlSignAlgo() {
        return dgtlSignAlgo;
    }

    /**
     * Sets the value of the dgtlSignAlgo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDgtlSignAlgo(String value) {
        this.dgtlSignAlgo = value;
    }

    public boolean isSetDgtlSignAlgo() {
        return (this.dgtlSignAlgo!= null);
    }

    /**
     * Gets the value of the dgtlSignValue property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getDgtlSignValue() {
        return dgtlSignValue;
    }

    /**
     * Sets the value of the dgtlSignValue property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setDgtlSignValue(byte[] value) {
        this.dgtlSignValue = value;
    }

    public boolean isSetDgtlSignValue() {
        return (this.dgtlSignValue!= null);
    }

    /**
     * Gets the value of the cryptogrphcAsymtricAlgo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCryptogrphcAsymtricAlgo() {
        return cryptogrphcAsymtricAlgo;
    }

    /**
     * Sets the value of the cryptogrphcAsymtricAlgo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCryptogrphcAsymtricAlgo(String value) {
        this.cryptogrphcAsymtricAlgo = value;
    }

    public boolean isSetCryptogrphcAsymtricAlgo() {
        return (this.cryptogrphcAsymtricAlgo!= null);
    }

    /**
     * Gets the value of the cryptogrphcSymtricAlgo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCryptogrphcSymtricAlgo() {
        return cryptogrphcSymtricAlgo;
    }

    /**
     * Sets the value of the cryptogrphcSymtricAlgo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCryptogrphcSymtricAlgo(String value) {
        this.cryptogrphcSymtricAlgo = value;
    }

    public boolean isSetCryptogrphcSymtricAlgo() {
        return (this.cryptogrphcSymtricAlgo!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("cryptogrphcHashAlgo", cryptogrphcHashAlgo).add("cryptogrphcHashValue", cryptogrphcHashValue).add("dgtlSignAlgo", dgtlSignAlgo).add("dgtlSignValue", dgtlSignValue).add("cryptogrphcAsymtricAlgo", cryptogrphcAsymtricAlgo).add("cryptogrphcSymtricAlgo", cryptogrphcSymtricAlgo).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(cryptogrphcHashAlgo, cryptogrphcHashValue, dgtlSignAlgo, dgtlSignValue, cryptogrphcAsymtricAlgo, cryptogrphcSymtricAlgo);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MetadataCryptographicDescriptionType o = ((MetadataCryptographicDescriptionType) other);
        return (((((Objects.equal(cryptogrphcHashAlgo, o.cryptogrphcHashAlgo)&&Objects.equal(cryptogrphcHashValue, o.cryptogrphcHashValue))&&Objects.equal(dgtlSignAlgo, o.dgtlSignAlgo))&&Objects.equal(dgtlSignValue, o.dgtlSignValue))&&Objects.equal(cryptogrphcAsymtricAlgo, o.cryptogrphcAsymtricAlgo))&&Objects.equal(cryptogrphcSymtricAlgo, o.cryptogrphcSymtricAlgo));
    }

}
