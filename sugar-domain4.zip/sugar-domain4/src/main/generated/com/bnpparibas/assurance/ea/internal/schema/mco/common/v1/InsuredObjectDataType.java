
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * To manage information of the insured object :
 * 				phone, microwave, etc
 * 			
 * 
 * <p>Java class for InsuredObjectDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="InsuredObjectDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SerialNumb" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentifierType" minOccurs="0"/&gt;
 *         &lt;element name="ObjctType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}InsuredObjectTypeCodeSLN"/&gt;
 *         &lt;element name="BrandCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="PurchsngDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="Price" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="WarntyEndDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="Vhcle" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}VehiculeDataType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InsuredObjectDataType", propOrder = {
    "serialNumb",
    "objctType",
    "brandCode",
    "purchsngDate",
    "price",
    "warntyEndDate",
    "vhcle"
})
public class InsuredObjectDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "SerialNumb")
    protected String serialNumb;
    @XmlElement(name = "ObjctType", required = true)
    protected String objctType;
    @XmlElement(name = "BrandCode")
    protected String brandCode;
    @XmlElement(name = "PurchsngDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date purchsngDate;
    @XmlElement(name = "Price")
    protected CurrencyAndAmountType price;
    @XmlElement(name = "WarntyEndDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date warntyEndDate;
    @XmlElement(name = "Vhcle")
    protected VehiculeDataType vhcle;

    /**
     * Default no-arg constructor
     * 
     */
    public InsuredObjectDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public InsuredObjectDataType(final String serialNumb, final String objctType, final String brandCode, final Date purchsngDate, final CurrencyAndAmountType price, final Date warntyEndDate, final VehiculeDataType vhcle) {
        this.serialNumb = serialNumb;
        this.objctType = objctType;
        this.brandCode = brandCode;
        this.purchsngDate = purchsngDate;
        this.price = price;
        this.warntyEndDate = warntyEndDate;
        this.vhcle = vhcle;
    }

    /**
     * Gets the value of the serialNumb property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSerialNumb() {
        return serialNumb;
    }

    /**
     * Sets the value of the serialNumb property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSerialNumb(String value) {
        this.serialNumb = value;
    }

    public boolean isSetSerialNumb() {
        return (this.serialNumb!= null);
    }

    /**
     * Gets the value of the objctType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getObjctType() {
        return objctType;
    }

    /**
     * Sets the value of the objctType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setObjctType(String value) {
        this.objctType = value;
    }

    public boolean isSetObjctType() {
        return (this.objctType!= null);
    }

    /**
     * Gets the value of the brandCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBrandCode() {
        return brandCode;
    }

    /**
     * Sets the value of the brandCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBrandCode(String value) {
        this.brandCode = value;
    }

    public boolean isSetBrandCode() {
        return (this.brandCode!= null);
    }

    /**
     * Gets the value of the purchsngDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getPurchsngDate() {
        return purchsngDate;
    }

    /**
     * Sets the value of the purchsngDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPurchsngDate(Date value) {
        this.purchsngDate = value;
    }

    public boolean isSetPurchsngDate() {
        return (this.purchsngDate!= null);
    }

    /**
     * Gets the value of the price property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getPrice() {
        return price;
    }

    /**
     * Sets the value of the price property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setPrice(CurrencyAndAmountType value) {
        this.price = value;
    }

    public boolean isSetPrice() {
        return (this.price!= null);
    }

    /**
     * Gets the value of the warntyEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getWarntyEndDate() {
        return warntyEndDate;
    }

    /**
     * Sets the value of the warntyEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWarntyEndDate(Date value) {
        this.warntyEndDate = value;
    }

    public boolean isSetWarntyEndDate() {
        return (this.warntyEndDate!= null);
    }

    /**
     * Gets the value of the vhcle property.
     * 
     * @return
     *     possible object is
     *     {@link VehiculeDataType }
     *     
     */
    public VehiculeDataType getVhcle() {
        return vhcle;
    }

    /**
     * Sets the value of the vhcle property.
     * 
     * @param value
     *     allowed object is
     *     {@link VehiculeDataType }
     *     
     */
    public void setVhcle(VehiculeDataType value) {
        this.vhcle = value;
    }

    public boolean isSetVhcle() {
        return (this.vhcle!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("serialNumb", serialNumb).add("objctType", objctType).add("brandCode", brandCode).add("purchsngDate", purchsngDate).add("price", price).add("warntyEndDate", warntyEndDate).add("vhcle", vhcle).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(serialNumb, objctType, brandCode, purchsngDate, price, warntyEndDate, vhcle);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final InsuredObjectDataType o = ((InsuredObjectDataType) other);
        return ((((((Objects.equal(serialNumb, o.serialNumb)&&Objects.equal(objctType, o.objctType))&&Objects.equal(brandCode, o.brandCode))&&Objects.equal(purchsngDate, o.purchsngDate))&&Objects.equal(price, o.price))&&Objects.equal(warntyEndDate, o.warntyEndDate))&&Objects.equal(vhcle, o.vhcle));
    }

}
