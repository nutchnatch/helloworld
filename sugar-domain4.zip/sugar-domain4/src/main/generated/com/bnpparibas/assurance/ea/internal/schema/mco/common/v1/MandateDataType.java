
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on rights given on the contract
 * 				to persons as a part of a mandate or a delegation to execute some
 * 				operation types
 * 			
 * 
 * <p>Java class for MandateDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MandateDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CustIdntctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="MndateData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}MandateDetailsType" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MandateDataType", propOrder = {
    "custIdntctn",
    "mndateData"
})
public class MandateDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CustIdntctn")
    protected PartyRoleType custIdntctn;
    @XmlElement(name = "MndateData", required = true)
    protected List<MandateDetailsType> mndateData;

    /**
     * Default no-arg constructor
     * 
     */
    public MandateDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MandateDataType(final PartyRoleType custIdntctn, final List<MandateDetailsType> mndateData) {
        this.custIdntctn = custIdntctn;
        this.mndateData = mndateData;
    }

    /**
     * Gets the value of the custIdntctn property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getCustIdntctn() {
        return custIdntctn;
    }

    /**
     * Sets the value of the custIdntctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setCustIdntctn(PartyRoleType value) {
        this.custIdntctn = value;
    }

    public boolean isSetCustIdntctn() {
        return (this.custIdntctn!= null);
    }

    /**
     * Gets the value of the mndateData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the mndateData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMndateData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MandateDetailsType }
     * 
     * 
     */
    public List<MandateDetailsType> getMndateData() {
        if (mndateData == null) {
            mndateData = new ArrayList<MandateDetailsType>();
        }
        return this.mndateData;
    }

    public boolean isSetMndateData() {
        return ((this.mndateData!= null)&&(!this.mndateData.isEmpty()));
    }

    public void unsetMndateData() {
        this.mndateData = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("custIdntctn", custIdntctn).add("mndateData", mndateData).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(custIdntctn, mndateData);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MandateDataType o = ((MandateDataType) other);
        return (Objects.equal(custIdntctn, o.custIdntctn)&&Objects.equal(mndateData, o.mndateData));
    }

}
