
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage data on extra-premium
 * 			
 * 
 * <p>Java class for ExtraPremiumDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ExtraPremiumDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CalctnRuleType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountCalculationRuleTypeCodeSLN"/&gt;
 *         &lt;element name="FixdAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="Rate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BasisRateType" minOccurs="0"/&gt;
 *         &lt;element name="BasisAmntType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AmountTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="MotivCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ExclusionAndExtraPremiumMotiveCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="ValdtyPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DatePeriodType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ExtraPremiumDataType", propOrder = {
    "calctnRuleType",
    "fixdAmnt",
    "rate",
    "basisAmntType",
    "motivCode",
    "valdtyPrd"
})
public class ExtraPremiumDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "CalctnRuleType", required = true)
    protected String calctnRuleType;
    @XmlElement(name = "FixdAmnt")
    protected CurrencyAndAmountType fixdAmnt;
    @XmlElement(name = "Rate")
    protected BasisRateType rate;
    @XmlElement(name = "BasisAmntType")
    protected String basisAmntType;
    @XmlElement(name = "MotivCode")
    protected String motivCode;
    @XmlElement(name = "ValdtyPrd")
    protected DatePeriodType valdtyPrd;

    /**
     * Default no-arg constructor
     * 
     */
    public ExtraPremiumDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ExtraPremiumDataType(final String calctnRuleType, final CurrencyAndAmountType fixdAmnt, final BasisRateType rate, final String basisAmntType, final String motivCode, final DatePeriodType valdtyPrd) {
        this.calctnRuleType = calctnRuleType;
        this.fixdAmnt = fixdAmnt;
        this.rate = rate;
        this.basisAmntType = basisAmntType;
        this.motivCode = motivCode;
        this.valdtyPrd = valdtyPrd;
    }

    /**
     * Gets the value of the calctnRuleType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCalctnRuleType() {
        return calctnRuleType;
    }

    /**
     * Sets the value of the calctnRuleType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCalctnRuleType(String value) {
        this.calctnRuleType = value;
    }

    public boolean isSetCalctnRuleType() {
        return (this.calctnRuleType!= null);
    }

    /**
     * Gets the value of the fixdAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getFixdAmnt() {
        return fixdAmnt;
    }

    /**
     * Sets the value of the fixdAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setFixdAmnt(CurrencyAndAmountType value) {
        this.fixdAmnt = value;
    }

    public boolean isSetFixdAmnt() {
        return (this.fixdAmnt!= null);
    }

    /**
     * Gets the value of the rate property.
     * 
     * @return
     *     possible object is
     *     {@link BasisRateType }
     *     
     */
    public BasisRateType getRate() {
        return rate;
    }

    /**
     * Sets the value of the rate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BasisRateType }
     *     
     */
    public void setRate(BasisRateType value) {
        this.rate = value;
    }

    public boolean isSetRate() {
        return (this.rate!= null);
    }

    /**
     * Gets the value of the basisAmntType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBasisAmntType() {
        return basisAmntType;
    }

    /**
     * Sets the value of the basisAmntType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBasisAmntType(String value) {
        this.basisAmntType = value;
    }

    public boolean isSetBasisAmntType() {
        return (this.basisAmntType!= null);
    }

    /**
     * Gets the value of the motivCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMotivCode() {
        return motivCode;
    }

    /**
     * Sets the value of the motivCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMotivCode(String value) {
        this.motivCode = value;
    }

    public boolean isSetMotivCode() {
        return (this.motivCode!= null);
    }

    /**
     * Gets the value of the valdtyPrd property.
     * 
     * @return
     *     possible object is
     *     {@link DatePeriodType }
     *     
     */
    public DatePeriodType getValdtyPrd() {
        return valdtyPrd;
    }

    /**
     * Sets the value of the valdtyPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatePeriodType }
     *     
     */
    public void setValdtyPrd(DatePeriodType value) {
        this.valdtyPrd = value;
    }

    public boolean isSetValdtyPrd() {
        return (this.valdtyPrd!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("calctnRuleType", calctnRuleType).add("fixdAmnt", fixdAmnt).add("rate", rate).add("basisAmntType", basisAmntType).add("motivCode", motivCode).add("valdtyPrd", valdtyPrd).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(calctnRuleType, fixdAmnt, rate, basisAmntType, motivCode, valdtyPrd);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ExtraPremiumDataType o = ((ExtraPremiumDataType) other);
        return (((((Objects.equal(calctnRuleType, o.calctnRuleType)&&Objects.equal(fixdAmnt, o.fixdAmnt))&&Objects.equal(rate, o.rate))&&Objects.equal(basisAmntType, o.basisAmntType))&&Objects.equal(motivCode, o.motivCode))&&Objects.equal(valdtyPrd, o.valdtyPrd));
    }

}
