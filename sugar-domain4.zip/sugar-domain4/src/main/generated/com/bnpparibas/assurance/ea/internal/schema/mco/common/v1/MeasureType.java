
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;
import com.google.common.base.Objects;


/**
 * type to describe a measure with an unit measure
 * 			
 * 
 * <p>Java class for MeasureType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MeasureType"&gt;
 *   &lt;simpleContent&gt;
 *     &lt;extension base="&lt;http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1&gt;IntegerType"&gt;
 *       &lt;attribute name="Unit" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}UnitOfMeasurementCodeSLN" /&gt;
 *     &lt;/extension&gt;
 *   &lt;/simpleContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MeasureType", propOrder = {
    "value"
})
public class MeasureType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlValue
    protected BigInteger value;
    @XmlAttribute(name = "Unit")
    protected String unit;

    /**
     * Default no-arg constructor
     * 
     */
    public MeasureType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MeasureType(final BigInteger value, final String unit) {
        this.value = value;
        this.unit = unit;
    }

    /**
     * Type for integers
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setValue(BigInteger value) {
        this.value = value;
    }

    public boolean isSetValue() {
        return (this.value!= null);
    }

    /**
     * Gets the value of the unit property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnit() {
        return unit;
    }

    /**
     * Sets the value of the unit property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnit(String value) {
        this.unit = value;
    }

    public boolean isSetUnit() {
        return (this.unit!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("value", value).add("unit", unit).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(value, unit);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MeasureType o = ((MeasureType) other);
        return (Objects.equal(value, o.value)&&Objects.equal(unit, o.unit));
    }

}
