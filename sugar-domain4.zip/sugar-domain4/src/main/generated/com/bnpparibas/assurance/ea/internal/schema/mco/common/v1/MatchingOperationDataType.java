
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * To manage global data on matching operation
 * 			
 * 
 * <p>Java class for MatchingOperationDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MatchingOperationDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="OpeCurr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyCodeSLN"/&gt;
 *         &lt;element name="SettlmntVarnceAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="MtchngCreditAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="MtchngDebtAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MatchingOperationDataType", propOrder = {
    "opeCurr",
    "settlmntVarnceAmnt",
    "mtchngCreditAmnt",
    "mtchngDebtAmnt"
})
public class MatchingOperationDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "OpeCurr", required = true)
    protected String opeCurr;
    @XmlElement(name = "SettlmntVarnceAmnt")
    protected CurrencyAndAmountType settlmntVarnceAmnt;
    @XmlElement(name = "MtchngCreditAmnt")
    protected CurrencyAndAmountType mtchngCreditAmnt;
    @XmlElement(name = "MtchngDebtAmnt")
    protected CurrencyAndAmountType mtchngDebtAmnt;

    /**
     * Default no-arg constructor
     * 
     */
    public MatchingOperationDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MatchingOperationDataType(final String opeCurr, final CurrencyAndAmountType settlmntVarnceAmnt, final CurrencyAndAmountType mtchngCreditAmnt, final CurrencyAndAmountType mtchngDebtAmnt) {
        this.opeCurr = opeCurr;
        this.settlmntVarnceAmnt = settlmntVarnceAmnt;
        this.mtchngCreditAmnt = mtchngCreditAmnt;
        this.mtchngDebtAmnt = mtchngDebtAmnt;
    }

    /**
     * Gets the value of the opeCurr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpeCurr() {
        return opeCurr;
    }

    /**
     * Sets the value of the opeCurr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpeCurr(String value) {
        this.opeCurr = value;
    }

    public boolean isSetOpeCurr() {
        return (this.opeCurr!= null);
    }

    /**
     * Gets the value of the settlmntVarnceAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getSettlmntVarnceAmnt() {
        return settlmntVarnceAmnt;
    }

    /**
     * Sets the value of the settlmntVarnceAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setSettlmntVarnceAmnt(CurrencyAndAmountType value) {
        this.settlmntVarnceAmnt = value;
    }

    public boolean isSetSettlmntVarnceAmnt() {
        return (this.settlmntVarnceAmnt!= null);
    }

    /**
     * Gets the value of the mtchngCreditAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getMtchngCreditAmnt() {
        return mtchngCreditAmnt;
    }

    /**
     * Sets the value of the mtchngCreditAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setMtchngCreditAmnt(CurrencyAndAmountType value) {
        this.mtchngCreditAmnt = value;
    }

    public boolean isSetMtchngCreditAmnt() {
        return (this.mtchngCreditAmnt!= null);
    }

    /**
     * Gets the value of the mtchngDebtAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getMtchngDebtAmnt() {
        return mtchngDebtAmnt;
    }

    /**
     * Sets the value of the mtchngDebtAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setMtchngDebtAmnt(CurrencyAndAmountType value) {
        this.mtchngDebtAmnt = value;
    }

    public boolean isSetMtchngDebtAmnt() {
        return (this.mtchngDebtAmnt!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("opeCurr", opeCurr).add("settlmntVarnceAmnt", settlmntVarnceAmnt).add("mtchngCreditAmnt", mtchngCreditAmnt).add("mtchngDebtAmnt", mtchngDebtAmnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(opeCurr, settlmntVarnceAmnt, mtchngCreditAmnt, mtchngDebtAmnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MatchingOperationDataType o = ((MatchingOperationDataType) other);
        return (((Objects.equal(opeCurr, o.opeCurr)&&Objects.equal(settlmntVarnceAmnt, o.settlmntVarnceAmnt))&&Objects.equal(mtchngCreditAmnt, o.mtchngCreditAmnt))&&Objects.equal(mtchngDebtAmnt, o.mtchngDebtAmnt));
    }

}
