
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type to manage specific data for fund statement
 * 			
 * 
 * <p>Java class for FundStatementDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FundStatementDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RefPrd" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ReferencePeriodTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="AmntType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}BalanceTypeCode" minOccurs="0"/&gt;
 *         &lt;element name="FundAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="FundWghtRate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}DecimalNumberType" minOccurs="0"/&gt;
 *         &lt;element name="UnitFundData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}UnitFundStatementDataType" minOccurs="0"/&gt;
 *         &lt;element name="IntrstFundData" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}InterestFundStatementDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="AddAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}StatementAdditionalAmountType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FundStatementDataType", propOrder = {
    "refPrd",
    "amntType",
    "fundAmnt",
    "fundWghtRate",
    "unitFundData",
    "intrstFundData",
    "addAmnt"
})
public class FundStatementDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "RefPrd")
    protected String refPrd;
    @XmlElement(name = "AmntType")
    protected String amntType;
    @XmlElement(name = "FundAmnt")
    protected CurrencyAndAmountType fundAmnt;
    @XmlElement(name = "FundWghtRate")
    protected Double fundWghtRate;
    @XmlElement(name = "UnitFundData")
    protected UnitFundStatementDataType unitFundData;
    @XmlElement(name = "IntrstFundData")
    protected List<InterestFundStatementDataType> intrstFundData;
    @XmlElement(name = "AddAmnt")
    protected List<StatementAdditionalAmountType> addAmnt;

    /**
     * Default no-arg constructor
     * 
     */
    public FundStatementDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public FundStatementDataType(final String refPrd, final String amntType, final CurrencyAndAmountType fundAmnt, final Double fundWghtRate, final UnitFundStatementDataType unitFundData, final List<InterestFundStatementDataType> intrstFundData, final List<StatementAdditionalAmountType> addAmnt) {
        this.refPrd = refPrd;
        this.amntType = amntType;
        this.fundAmnt = fundAmnt;
        this.fundWghtRate = fundWghtRate;
        this.unitFundData = unitFundData;
        this.intrstFundData = intrstFundData;
        this.addAmnt = addAmnt;
    }

    /**
     * Gets the value of the refPrd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefPrd() {
        return refPrd;
    }

    /**
     * Sets the value of the refPrd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefPrd(String value) {
        this.refPrd = value;
    }

    public boolean isSetRefPrd() {
        return (this.refPrd!= null);
    }

    /**
     * Gets the value of the amntType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmntType() {
        return amntType;
    }

    /**
     * Sets the value of the amntType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmntType(String value) {
        this.amntType = value;
    }

    public boolean isSetAmntType() {
        return (this.amntType!= null);
    }

    /**
     * Gets the value of the fundAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getFundAmnt() {
        return fundAmnt;
    }

    /**
     * Sets the value of the fundAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setFundAmnt(CurrencyAndAmountType value) {
        this.fundAmnt = value;
    }

    public boolean isSetFundAmnt() {
        return (this.fundAmnt!= null);
    }

    /**
     * Gets the value of the fundWghtRate property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getFundWghtRate() {
        return fundWghtRate;
    }

    /**
     * Sets the value of the fundWghtRate property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setFundWghtRate(Double value) {
        this.fundWghtRate = value;
    }

    public boolean isSetFundWghtRate() {
        return (this.fundWghtRate!= null);
    }

    /**
     * Gets the value of the unitFundData property.
     * 
     * @return
     *     possible object is
     *     {@link UnitFundStatementDataType }
     *     
     */
    public UnitFundStatementDataType getUnitFundData() {
        return unitFundData;
    }

    /**
     * Sets the value of the unitFundData property.
     * 
     * @param value
     *     allowed object is
     *     {@link UnitFundStatementDataType }
     *     
     */
    public void setUnitFundData(UnitFundStatementDataType value) {
        this.unitFundData = value;
    }

    public boolean isSetUnitFundData() {
        return (this.unitFundData!= null);
    }

    /**
     * Gets the value of the intrstFundData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the intrstFundData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIntrstFundData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InterestFundStatementDataType }
     * 
     * 
     */
    public List<InterestFundStatementDataType> getIntrstFundData() {
        if (intrstFundData == null) {
            intrstFundData = new ArrayList<InterestFundStatementDataType>();
        }
        return this.intrstFundData;
    }

    public boolean isSetIntrstFundData() {
        return ((this.intrstFundData!= null)&&(!this.intrstFundData.isEmpty()));
    }

    public void unsetIntrstFundData() {
        this.intrstFundData = null;
    }

    /**
     * Gets the value of the addAmnt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the addAmnt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddAmnt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link StatementAdditionalAmountType }
     * 
     * 
     */
    public List<StatementAdditionalAmountType> getAddAmnt() {
        if (addAmnt == null) {
            addAmnt = new ArrayList<StatementAdditionalAmountType>();
        }
        return this.addAmnt;
    }

    public boolean isSetAddAmnt() {
        return ((this.addAmnt!= null)&&(!this.addAmnt.isEmpty()));
    }

    public void unsetAddAmnt() {
        this.addAmnt = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("refPrd", refPrd).add("amntType", amntType).add("fundAmnt", fundAmnt).add("fundWghtRate", fundWghtRate).add("unitFundData", unitFundData).add("intrstFundData", intrstFundData).add("addAmnt", addAmnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(refPrd, amntType, fundAmnt, fundWghtRate, unitFundData, intrstFundData, addAmnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final FundStatementDataType o = ((FundStatementDataType) other);
        return ((((((Objects.equal(refPrd, o.refPrd)&&Objects.equal(amntType, o.amntType))&&Objects.equal(fundAmnt, o.fundAmnt))&&Objects.equal(fundWghtRate, o.fundWghtRate))&&Objects.equal(unitFundData, o.unitFundData))&&Objects.equal(intrstFundData, o.intrstFundData))&&Objects.equal(addAmnt, o.addAmnt));
    }

}
