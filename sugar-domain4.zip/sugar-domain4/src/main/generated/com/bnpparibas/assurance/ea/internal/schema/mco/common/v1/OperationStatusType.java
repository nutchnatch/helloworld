
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * Type to manage status data of financial operations
 * 			
 * 
 * <p>Java class for OperationStatusType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OperationStatusType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Code" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationStatusCodeSLN"/&gt;
 *         &lt;element name="EffctveDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType"/&gt;
 *         &lt;element name="ChngeReasn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}EventTypeCode" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="PrevStatus" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}OperationStatusCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="PrevStatusEffctveDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OperationStatusType", propOrder = {
    "code",
    "effctveDate",
    "chngeReasn",
    "prevStatus",
    "prevStatusEffctveDate"
})
public class OperationStatusType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Code", required = true)
    protected String code;
    @XmlElement(name = "EffctveDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date effctveDate;
    @XmlElement(name = "ChngeReasn")
    protected List<String> chngeReasn;
    @XmlElement(name = "PrevStatus")
    protected String prevStatus;
    @XmlElement(name = "PrevStatusEffctveDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date prevStatusEffctveDate;

    /**
     * Default no-arg constructor
     * 
     */
    public OperationStatusType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public OperationStatusType(final String code, final Date effctveDate, final List<String> chngeReasn, final String prevStatus, final Date prevStatusEffctveDate) {
        this.code = code;
        this.effctveDate = effctveDate;
        this.chngeReasn = chngeReasn;
        this.prevStatus = prevStatus;
        this.prevStatusEffctveDate = prevStatusEffctveDate;
    }

    /**
     * Gets the value of the code property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCode(String value) {
        this.code = value;
    }

    public boolean isSetCode() {
        return (this.code!= null);
    }

    /**
     * Gets the value of the effctveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getEffctveDate() {
        return effctveDate;
    }

    /**
     * Sets the value of the effctveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEffctveDate(Date value) {
        this.effctveDate = value;
    }

    public boolean isSetEffctveDate() {
        return (this.effctveDate!= null);
    }

    /**
     * Gets the value of the chngeReasn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the chngeReasn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getChngeReasn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getChngeReasn() {
        if (chngeReasn == null) {
            chngeReasn = new ArrayList<String>();
        }
        return this.chngeReasn;
    }

    public boolean isSetChngeReasn() {
        return ((this.chngeReasn!= null)&&(!this.chngeReasn.isEmpty()));
    }

    public void unsetChngeReasn() {
        this.chngeReasn = null;
    }

    /**
     * Gets the value of the prevStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrevStatus() {
        return prevStatus;
    }

    /**
     * Sets the value of the prevStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrevStatus(String value) {
        this.prevStatus = value;
    }

    public boolean isSetPrevStatus() {
        return (this.prevStatus!= null);
    }

    /**
     * Gets the value of the prevStatusEffctveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getPrevStatusEffctveDate() {
        return prevStatusEffctveDate;
    }

    /**
     * Sets the value of the prevStatusEffctveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrevStatusEffctveDate(Date value) {
        this.prevStatusEffctveDate = value;
    }

    public boolean isSetPrevStatusEffctveDate() {
        return (this.prevStatusEffctveDate!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("code", code).add("effctveDate", effctveDate).add("chngeReasn", chngeReasn).add("prevStatus", prevStatus).add("prevStatusEffctveDate", prevStatusEffctveDate).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(code, effctveDate, chngeReasn, prevStatus, prevStatusEffctveDate);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final OperationStatusType o = ((OperationStatusType) other);
        return ((((Objects.equal(code, o.code)&&Objects.equal(effctveDate, o.effctveDate))&&Objects.equal(chngeReasn, o.chngeReasn))&&Objects.equal(prevStatus, o.prevStatus))&&Objects.equal(prevStatusEffctveDate, o.prevStatusEffctveDate));
    }

}
