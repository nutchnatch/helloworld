
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * Type pour identifier un
 * 				support plus un libellé
 * 			
 * 
 * <p>Java class for ExtendedFinancialFundIdentificationType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ExtendedFinancialFundIdentificationType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FundIdntfctn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="FundType" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}UnitTypeCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="UndrlyngFinanclInstrmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}FinancialInstrumentIdentificationType" minOccurs="0"/&gt;
 *         &lt;element name="FundName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ExtendedFinancialFundIdentificationType", propOrder = {
    "fundIdntfctn",
    "fundType",
    "undrlyngFinanclInstrmnt",
    "fundName"
})
public class ExtendedFinancialFundIdentificationType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "FundIdntfctn")
    protected ObjectIdentificationType fundIdntfctn;
    @XmlElement(name = "FundType")
    protected String fundType;
    @XmlElement(name = "UndrlyngFinanclInstrmnt")
    protected FinancialInstrumentIdentificationType undrlyngFinanclInstrmnt;
    @XmlElement(name = "FundName")
    protected String fundName;

    /**
     * Default no-arg constructor
     * 
     */
    public ExtendedFinancialFundIdentificationType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public ExtendedFinancialFundIdentificationType(final ObjectIdentificationType fundIdntfctn, final String fundType, final FinancialInstrumentIdentificationType undrlyngFinanclInstrmnt, final String fundName) {
        this.fundIdntfctn = fundIdntfctn;
        this.fundType = fundType;
        this.undrlyngFinanclInstrmnt = undrlyngFinanclInstrmnt;
        this.fundName = fundName;
    }

    /**
     * Gets the value of the fundIdntfctn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getFundIdntfctn() {
        return fundIdntfctn;
    }

    /**
     * Sets the value of the fundIdntfctn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setFundIdntfctn(ObjectIdentificationType value) {
        this.fundIdntfctn = value;
    }

    public boolean isSetFundIdntfctn() {
        return (this.fundIdntfctn!= null);
    }

    /**
     * Gets the value of the fundType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundType() {
        return fundType;
    }

    /**
     * Sets the value of the fundType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundType(String value) {
        this.fundType = value;
    }

    public boolean isSetFundType() {
        return (this.fundType!= null);
    }

    /**
     * Gets the value of the undrlyngFinanclInstrmnt property.
     * 
     * @return
     *     possible object is
     *     {@link FinancialInstrumentIdentificationType }
     *     
     */
    public FinancialInstrumentIdentificationType getUndrlyngFinanclInstrmnt() {
        return undrlyngFinanclInstrmnt;
    }

    /**
     * Sets the value of the undrlyngFinanclInstrmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link FinancialInstrumentIdentificationType }
     *     
     */
    public void setUndrlyngFinanclInstrmnt(FinancialInstrumentIdentificationType value) {
        this.undrlyngFinanclInstrmnt = value;
    }

    public boolean isSetUndrlyngFinanclInstrmnt() {
        return (this.undrlyngFinanclInstrmnt!= null);
    }

    /**
     * Gets the value of the fundName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFundName() {
        return fundName;
    }

    /**
     * Sets the value of the fundName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFundName(String value) {
        this.fundName = value;
    }

    public boolean isSetFundName() {
        return (this.fundName!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("fundIdntfctn", fundIdntfctn).add("fundType", fundType).add("undrlyngFinanclInstrmnt", undrlyngFinanclInstrmnt).add("fundName", fundName).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(fundIdntfctn, fundType, undrlyngFinanclInstrmnt, fundName);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final ExtendedFinancialFundIdentificationType o = ((ExtendedFinancialFundIdentificationType) other);
        return (((Objects.equal(fundIdntfctn, o.fundIdntfctn)&&Objects.equal(fundType, o.fundType))&&Objects.equal(undrlyngFinanclInstrmnt, o.undrlyngFinanclInstrmnt))&&Objects.equal(fundName, o.fundName));
    }

}
