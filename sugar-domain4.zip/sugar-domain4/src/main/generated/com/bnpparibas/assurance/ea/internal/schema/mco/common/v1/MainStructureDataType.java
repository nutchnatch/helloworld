
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * Type to manage data on the main structure
 * 			
 * 
 * <p>Java class for MainStructureDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MainStructureDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Idntcn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="Data"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}StructureTypeCodeSLN"/&gt;
 *                   &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
 *                   &lt;element name="StartDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *                   &lt;element name="EndDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *                   &lt;element name="FreeDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LongDescriptionType" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Ownr" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *         &lt;element name="Cntct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ThirdPartyContactWithAddressType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MainStructureDataType", propOrder = {
    "idntcn",
    "data",
    "ownr",
    "cntct"
})
public class MainStructureDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Idntcn", required = true)
    protected ObjectIdentificationType idntcn;
    @XmlElement(name = "Data", required = true)
    protected MainStructureDataType.Data data;
    @XmlElement(name = "Ownr")
    protected PartyRoleType ownr;
    @XmlElement(name = "Cntct")
    protected List<ThirdPartyContactWithAddressType> cntct;

    /**
     * Default no-arg constructor
     * 
     */
    public MainStructureDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MainStructureDataType(final ObjectIdentificationType idntcn, final MainStructureDataType.Data data, final PartyRoleType ownr, final List<ThirdPartyContactWithAddressType> cntct) {
        this.idntcn = idntcn;
        this.data = data;
        this.ownr = ownr;
        this.cntct = cntct;
    }

    /**
     * Gets the value of the idntcn property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getIdntcn() {
        return idntcn;
    }

    /**
     * Sets the value of the idntcn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setIdntcn(ObjectIdentificationType value) {
        this.idntcn = value;
    }

    public boolean isSetIdntcn() {
        return (this.idntcn!= null);
    }

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     {@link MainStructureDataType.Data }
     *     
     */
    public MainStructureDataType.Data getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     {@link MainStructureDataType.Data }
     *     
     */
    public void setData(MainStructureDataType.Data value) {
        this.data = value;
    }

    public boolean isSetData() {
        return (this.data!= null);
    }

    /**
     * Gets the value of the ownr property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getOwnr() {
        return ownr;
    }

    /**
     * Sets the value of the ownr property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setOwnr(PartyRoleType value) {
        this.ownr = value;
    }

    public boolean isSetOwnr() {
        return (this.ownr!= null);
    }

    /**
     * Gets the value of the cntct property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cntct property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCntct().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ThirdPartyContactWithAddressType }
     * 
     * 
     */
    public List<ThirdPartyContactWithAddressType> getCntct() {
        if (cntct == null) {
            cntct = new ArrayList<ThirdPartyContactWithAddressType>();
        }
        return this.cntct;
    }

    public boolean isSetCntct() {
        return ((this.cntct!= null)&&(!this.cntct.isEmpty()));
    }

    public void unsetCntct() {
        this.cntct = null;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("idntcn", idntcn).add("data", data).add("ownr", ownr).add("cntct", cntct).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(idntcn, data, ownr, cntct);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MainStructureDataType o = ((MainStructureDataType) other);
        return (((Objects.equal(idntcn, o.idntcn)&&Objects.equal(data, o.data))&&Objects.equal(ownr, o.ownr))&&Objects.equal(cntct, o.cntct));
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Type" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}StructureTypeCodeSLN"/&gt;
     *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
     *         &lt;element name="StartDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
     *         &lt;element name="EndDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
     *         &lt;element name="FreeDesc" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LongDescriptionType" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "type",
        "name",
        "startDate",
        "endDate",
        "freeDesc"
    })
    public static class Data implements Serializable
    {

        private final static long serialVersionUID = 1L;
        @XmlElement(name = "Type", required = true)
        protected String type;
        @XmlElement(name = "Name", required = true)
        protected String name;
        @XmlElement(name = "StartDate", type = String.class)
        @XmlJavaTypeAdapter(Adapter2 .class)
        @XmlSchemaType(name = "date")
        protected Date startDate;
        @XmlElement(name = "EndDate", type = String.class)
        @XmlJavaTypeAdapter(Adapter2 .class)
        @XmlSchemaType(name = "date")
        protected Date endDate;
        @XmlElement(name = "FreeDesc")
        protected String freeDesc;

        /**
         * Default no-arg constructor
         * 
         */
        public Data() {
            super();
        }

        /**
         * Fully-initialising value constructor
         * 
         */
        public Data(final String type, final String name, final Date startDate, final Date endDate, final String freeDesc) {
            this.type = type;
            this.name = name;
            this.startDate = startDate;
            this.endDate = endDate;
            this.freeDesc = freeDesc;
        }

        /**
         * Gets the value of the type property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getType() {
            return type;
        }

        /**
         * Sets the value of the type property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setType(String value) {
            this.type = value;
        }

        public boolean isSetType() {
            return (this.type!= null);
        }

        /**
         * Gets the value of the name property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getName() {
            return name;
        }

        /**
         * Sets the value of the name property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setName(String value) {
            this.name = value;
        }

        public boolean isSetName() {
            return (this.name!= null);
        }

        /**
         * Gets the value of the startDate property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public Date getStartDate() {
            return startDate;
        }

        /**
         * Sets the value of the startDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setStartDate(Date value) {
            this.startDate = value;
        }

        public boolean isSetStartDate() {
            return (this.startDate!= null);
        }

        /**
         * Gets the value of the endDate property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public Date getEndDate() {
            return endDate;
        }

        /**
         * Sets the value of the endDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setEndDate(Date value) {
            this.endDate = value;
        }

        public boolean isSetEndDate() {
            return (this.endDate!= null);
        }

        /**
         * Gets the value of the freeDesc property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFreeDesc() {
            return freeDesc;
        }

        /**
         * Sets the value of the freeDesc property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFreeDesc(String value) {
            this.freeDesc = value;
        }

        public boolean isSetFreeDesc() {
            return (this.freeDesc!= null);
        }

        @Override
        public String toString() {
            return Objects.toStringHelper(this).add("type", type).add("name", name).add("startDate", startDate).add("endDate", endDate).add("freeDesc", freeDesc).toString();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(type, name, startDate, endDate, freeDesc);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (other == null) {
                return false;
            }
            if (getClass()!= other.getClass()) {
                return false;
            }
            final MainStructureDataType.Data o = ((MainStructureDataType.Data) other);
            return ((((Objects.equal(type, o.type)&&Objects.equal(name, o.name))&&Objects.equal(startDate, o.startDate))&&Objects.equal(endDate, o.endDate))&&Objects.equal(freeDesc, o.freeDesc));
        }

    }

}
