
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * To describe the employer of a customer: name,
 * 				address
 * 			
 * 
 * <p>Java class for EmployerDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EmployerDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType" minOccurs="0"/&gt;
 *         &lt;element name="PostAdrs" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PostalAddressInputType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EmployerDataType", propOrder = {
    "name",
    "postAdrs"
})
public class EmployerDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Name")
    protected String name;
    @XmlElement(name = "PostAdrs")
    protected PostalAddressInputType postAdrs;

    /**
     * Default no-arg constructor
     * 
     */
    public EmployerDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public EmployerDataType(final String name, final PostalAddressInputType postAdrs) {
        this.name = name;
        this.postAdrs = postAdrs;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the postAdrs property.
     * 
     * @return
     *     possible object is
     *     {@link PostalAddressInputType }
     *     
     */
    public PostalAddressInputType getPostAdrs() {
        return postAdrs;
    }

    /**
     * Sets the value of the postAdrs property.
     * 
     * @param value
     *     allowed object is
     *     {@link PostalAddressInputType }
     *     
     */
    public void setPostAdrs(PostalAddressInputType value) {
        this.postAdrs = value;
    }

    public boolean isSetPostAdrs() {
        return (this.postAdrs!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("name", name).add("postAdrs", postAdrs).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name, postAdrs);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final EmployerDataType o = ((EmployerDataType) other);
        return (Objects.equal(name, o.name)&&Objects.equal(postAdrs, o.postAdrs));
    }

}
