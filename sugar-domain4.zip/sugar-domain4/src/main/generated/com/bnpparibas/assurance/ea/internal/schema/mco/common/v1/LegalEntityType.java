
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter2;


/**
 * moral person
 * 
 * <p>Java class for LegalEntityType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LegalEntityType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Name" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}NameType"/&gt;
 *         &lt;element name="LegalForm" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LegalFormCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="StatusCode" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}LegalEntityActivityStatusCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="LegalRegstrtn" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}IdentificationType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="RegstrtnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="CreatnDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateType" minOccurs="0"/&gt;
 *         &lt;element name="CaptlAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *         &lt;element name="RegstrtnCntry" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CountryCodeSLN" minOccurs="0"/&gt;
 *         &lt;element name="RegstrtnCityName" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CityNameType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LegalEntityType", propOrder = {
    "name",
    "legalForm",
    "statusCode",
    "legalRegstrtn",
    "regstrtnDate",
    "creatnDate",
    "captlAmnt",
    "regstrtnCntry",
    "regstrtnCityName"
})
public class LegalEntityType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Name", required = true)
    protected String name;
    @XmlElement(name = "LegalForm")
    protected String legalForm;
    @XmlElement(name = "StatusCode")
    protected String statusCode;
    @XmlElement(name = "LegalRegstrtn")
    protected List<IdentificationType> legalRegstrtn;
    @XmlElement(name = "RegstrtnDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date regstrtnDate;
    @XmlElement(name = "CreatnDate", type = String.class)
    @XmlJavaTypeAdapter(Adapter2 .class)
    @XmlSchemaType(name = "date")
    protected Date creatnDate;
    @XmlElement(name = "CaptlAmnt")
    protected CurrencyAndAmountType captlAmnt;
    @XmlElement(name = "RegstrtnCntry")
    protected String regstrtnCntry;
    @XmlElement(name = "RegstrtnCityName")
    protected String regstrtnCityName;

    /**
     * Default no-arg constructor
     * 
     */
    public LegalEntityType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public LegalEntityType(final String name, final String legalForm, final String statusCode, final List<IdentificationType> legalRegstrtn, final Date regstrtnDate, final Date creatnDate, final CurrencyAndAmountType captlAmnt, final String regstrtnCntry, final String regstrtnCityName) {
        this.name = name;
        this.legalForm = legalForm;
        this.statusCode = statusCode;
        this.legalRegstrtn = legalRegstrtn;
        this.regstrtnDate = regstrtnDate;
        this.creatnDate = creatnDate;
        this.captlAmnt = captlAmnt;
        this.regstrtnCntry = regstrtnCntry;
        this.regstrtnCityName = regstrtnCityName;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    public boolean isSetName() {
        return (this.name!= null);
    }

    /**
     * Gets the value of the legalForm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLegalForm() {
        return legalForm;
    }

    /**
     * Sets the value of the legalForm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLegalForm(String value) {
        this.legalForm = value;
    }

    public boolean isSetLegalForm() {
        return (this.legalForm!= null);
    }

    /**
     * Gets the value of the statusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusCode() {
        return statusCode;
    }

    /**
     * Sets the value of the statusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusCode(String value) {
        this.statusCode = value;
    }

    public boolean isSetStatusCode() {
        return (this.statusCode!= null);
    }

    /**
     * Gets the value of the legalRegstrtn property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the legalRegstrtn property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLegalRegstrtn().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IdentificationType }
     * 
     * 
     */
    public List<IdentificationType> getLegalRegstrtn() {
        if (legalRegstrtn == null) {
            legalRegstrtn = new ArrayList<IdentificationType>();
        }
        return this.legalRegstrtn;
    }

    public boolean isSetLegalRegstrtn() {
        return ((this.legalRegstrtn!= null)&&(!this.legalRegstrtn.isEmpty()));
    }

    public void unsetLegalRegstrtn() {
        this.legalRegstrtn = null;
    }

    /**
     * Gets the value of the regstrtnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getRegstrtnDate() {
        return regstrtnDate;
    }

    /**
     * Sets the value of the regstrtnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegstrtnDate(Date value) {
        this.regstrtnDate = value;
    }

    public boolean isSetRegstrtnDate() {
        return (this.regstrtnDate!= null);
    }

    /**
     * Gets the value of the creatnDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCreatnDate() {
        return creatnDate;
    }

    /**
     * Sets the value of the creatnDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatnDate(Date value) {
        this.creatnDate = value;
    }

    public boolean isSetCreatnDate() {
        return (this.creatnDate!= null);
    }

    /**
     * Gets the value of the captlAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getCaptlAmnt() {
        return captlAmnt;
    }

    /**
     * Sets the value of the captlAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setCaptlAmnt(CurrencyAndAmountType value) {
        this.captlAmnt = value;
    }

    public boolean isSetCaptlAmnt() {
        return (this.captlAmnt!= null);
    }

    /**
     * Gets the value of the regstrtnCntry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegstrtnCntry() {
        return regstrtnCntry;
    }

    /**
     * Sets the value of the regstrtnCntry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegstrtnCntry(String value) {
        this.regstrtnCntry = value;
    }

    public boolean isSetRegstrtnCntry() {
        return (this.regstrtnCntry!= null);
    }

    /**
     * Gets the value of the regstrtnCityName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegstrtnCityName() {
        return regstrtnCityName;
    }

    /**
     * Sets the value of the regstrtnCityName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegstrtnCityName(String value) {
        this.regstrtnCityName = value;
    }

    public boolean isSetRegstrtnCityName() {
        return (this.regstrtnCityName!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("name", name).add("legalForm", legalForm).add("statusCode", statusCode).add("legalRegstrtn", legalRegstrtn).add("regstrtnDate", regstrtnDate).add("creatnDate", creatnDate).add("captlAmnt", captlAmnt).add("regstrtnCntry", regstrtnCntry).add("regstrtnCityName", regstrtnCityName).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(name, legalForm, statusCode, legalRegstrtn, regstrtnDate, creatnDate, captlAmnt, regstrtnCntry, regstrtnCityName);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final LegalEntityType o = ((LegalEntityType) other);
        return ((((((((Objects.equal(name, o.name)&&Objects.equal(legalForm, o.legalForm))&&Objects.equal(statusCode, o.statusCode))&&Objects.equal(legalRegstrtn, o.legalRegstrtn))&&Objects.equal(regstrtnDate, o.regstrtnDate))&&Objects.equal(creatnDate, o.creatnDate))&&Objects.equal(captlAmnt, o.captlAmnt))&&Objects.equal(regstrtnCntry, o.regstrtnCntry))&&Objects.equal(regstrtnCityName, o.regstrtnCityName));
    }

}
