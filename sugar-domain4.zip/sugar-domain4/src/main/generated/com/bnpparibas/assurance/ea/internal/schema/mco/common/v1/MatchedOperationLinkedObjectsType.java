
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.google.common.base.Objects;


/**
 * To manage objects with which a mateched operation
 * 				has dependencies
 * 			
 * 
 * <p>Java class for MatchedOperationLinkedObjectsType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MatchedOperationLinkedObjectsType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Pdct" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ProductSharedDataType"/&gt;
 *         &lt;element name="Pol" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ObjectIdentificationType"/&gt;
 *         &lt;element name="Prty" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}PartyRoleType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MatchedOperationLinkedObjectsType", propOrder = {
    "pdct",
    "pol",
    "prty"
})
public class MatchedOperationLinkedObjectsType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "Pdct", required = true)
    protected ProductSharedDataType pdct;
    @XmlElement(name = "Pol", required = true)
    protected ObjectIdentificationType pol;
    @XmlElement(name = "Prty")
    protected PartyRoleType prty;

    /**
     * Default no-arg constructor
     * 
     */
    public MatchedOperationLinkedObjectsType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public MatchedOperationLinkedObjectsType(final ProductSharedDataType pdct, final ObjectIdentificationType pol, final PartyRoleType prty) {
        this.pdct = pdct;
        this.pol = pol;
        this.prty = prty;
    }

    /**
     * Gets the value of the pdct property.
     * 
     * @return
     *     possible object is
     *     {@link ProductSharedDataType }
     *     
     */
    public ProductSharedDataType getPdct() {
        return pdct;
    }

    /**
     * Sets the value of the pdct property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductSharedDataType }
     *     
     */
    public void setPdct(ProductSharedDataType value) {
        this.pdct = value;
    }

    public boolean isSetPdct() {
        return (this.pdct!= null);
    }

    /**
     * Gets the value of the pol property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public ObjectIdentificationType getPol() {
        return pol;
    }

    /**
     * Sets the value of the pol property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectIdentificationType }
     *     
     */
    public void setPol(ObjectIdentificationType value) {
        this.pol = value;
    }

    public boolean isSetPol() {
        return (this.pol!= null);
    }

    /**
     * Gets the value of the prty property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRoleType }
     *     
     */
    public PartyRoleType getPrty() {
        return prty;
    }

    /**
     * Sets the value of the prty property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRoleType }
     *     
     */
    public void setPrty(PartyRoleType value) {
        this.prty = value;
    }

    public boolean isSetPrty() {
        return (this.prty!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("pdct", pdct).add("pol", pol).add("prty", prty).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(pdct, pol, prty);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final MatchedOperationLinkedObjectsType o = ((MatchedOperationLinkedObjectsType) other);
        return ((Objects.equal(pdct, o.pdct)&&Objects.equal(pol, o.pol))&&Objects.equal(prty, o.prty));
    }

}
