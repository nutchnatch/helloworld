
package com.bnpparibas.assurance.ea.internal.schema.mco.common.v1;

import java.io.Serializable;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.google.common.base.Objects;
import org.w3._2001.xmlschema.Adapter1;


/**
 * Type to manage the assignement of a payment to
 * 				financial operations
 * 			
 * 
 * <p>Java class for OperationPaymentAllocationDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OperationPaymentAllocationDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="AllctnStatus" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}AppropriationStatusCodeSLN"/&gt;
 *         &lt;element name="AllctnEffctveDate" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}ISODateTimeType"/&gt;
 *         &lt;element name="AllctdAmnt" type="{http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1}CurrencyAndAmountType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OperationPaymentAllocationDataType", propOrder = {
    "allctnStatus",
    "allctnEffctveDate",
    "allctdAmnt"
})
public class OperationPaymentAllocationDataType implements Serializable
{

    private final static long serialVersionUID = 1L;
    @XmlElement(name = "AllctnStatus", required = true)
    protected String allctnStatus;
    @XmlElement(name = "AllctnEffctveDate", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date allctnEffctveDate;
    @XmlElement(name = "AllctdAmnt")
    protected CurrencyAndAmountType allctdAmnt;

    /**
     * Default no-arg constructor
     * 
     */
    public OperationPaymentAllocationDataType() {
        super();
    }

    /**
     * Fully-initialising value constructor
     * 
     */
    public OperationPaymentAllocationDataType(final String allctnStatus, final Date allctnEffctveDate, final CurrencyAndAmountType allctdAmnt) {
        this.allctnStatus = allctnStatus;
        this.allctnEffctveDate = allctnEffctveDate;
        this.allctdAmnt = allctdAmnt;
    }

    /**
     * Gets the value of the allctnStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllctnStatus() {
        return allctnStatus;
    }

    /**
     * Sets the value of the allctnStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllctnStatus(String value) {
        this.allctnStatus = value;
    }

    public boolean isSetAllctnStatus() {
        return (this.allctnStatus!= null);
    }

    /**
     * Gets the value of the allctnEffctveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getAllctnEffctveDate() {
        return allctnEffctveDate;
    }

    /**
     * Sets the value of the allctnEffctveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllctnEffctveDate(Date value) {
        this.allctnEffctveDate = value;
    }

    public boolean isSetAllctnEffctveDate() {
        return (this.allctnEffctveDate!= null);
    }

    /**
     * Gets the value of the allctdAmnt property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public CurrencyAndAmountType getAllctdAmnt() {
        return allctdAmnt;
    }

    /**
     * Sets the value of the allctdAmnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAndAmountType }
     *     
     */
    public void setAllctdAmnt(CurrencyAndAmountType value) {
        this.allctdAmnt = value;
    }

    public boolean isSetAllctdAmnt() {
        return (this.allctdAmnt!= null);
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("allctnStatus", allctnStatus).add("allctnEffctveDate", allctnEffctveDate).add("allctdAmnt", allctdAmnt).toString();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(allctnStatus, allctnEffctveDate, allctdAmnt);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null) {
            return false;
        }
        if (getClass()!= other.getClass()) {
            return false;
        }
        final OperationPaymentAllocationDataType o = ((OperationPaymentAllocationDataType) other);
        return ((Objects.equal(allctnStatus, o.allctnStatus)&&Objects.equal(allctnEffctveDate, o.allctnEffctveDate))&&Objects.equal(allctdAmnt, o.allctdAmnt));
    }

}
