package com.bnpp.cardif.sugar.domain.task.test;

import java.util.Date;
import java.util.UUID;

import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.TaskStatus;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.MCOTask.DocID;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;

/**
 * Utility class allowing to generate task for test purposes
 * 
 * @author Florian Deruette
 * 
 */

public class TaskMockUtility {

    public static Task generateBlankTask(Document document) {
        if (document == null) {
            return null;
        }
        Task task = new Task();
        task.setTaskId(new TaskId());
        task.getTaskId().setIssuer(document.getId().getIssuer());
        task.getTaskId().setScheme(document.getId().getScheme());
        task.getTaskId().setValue(UUID.randomUUID().toString());
        task.setDocID(new DocID());
        task.getDocID().setId(document.getId());
        task.setScope(document.getScope());
        task.setCreatnDate(new Date());
        task.setStatus(TaskStatus.NEW.name());
        return task;
    }
}
