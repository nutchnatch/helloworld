# Skeleton project for Swagger

app.js contains the main configuration to run the node js server.

In order to test application, this tool provides a Swagger Editor rendered in a browser, where all web api schema can be tested. It
provides the following:
	1- Validation and endpoit routing;
	2- Docs on the fly generation;
	3- Easy-to-read Yaml
	
Steps to lauch the tool (commands to be run in this dir):
-> Pre-requisit: Node JS must be installed before executing next steps.
1-Navigate to ...\sugar-web-api\api-mock 
2-Install swagger:
	* npm install -g swagger
3- Install dependencies:
	* npm install
4- Start application :
	* swagger project start
	-> Note: to run the application in mock mode, add run te following command: swagger project start -m
5- Open swagger editor:	
	* swagger project edit
	-> Schema can be tested with swagger editor or other tools like curl, for example.
	
	
It will be listening on (base URL): http://localhost:10010/sugar-backend-webapp/rest/

Example of a call: with curl:
curl -X GET \
  'http://localhost:10010/sugar-backend-webapp/rest/v1/folders?pageNumber=1&pageSize=20' \
  -H 'cache-control: no-cache' \
  -H 'postman-token: 17b5149d-141c-5558-bf44-c17d6c2f13c6' \
  -H 'x-api-key: 1234'