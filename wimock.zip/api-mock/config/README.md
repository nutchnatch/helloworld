Configuration for this mock tool is found on default.yaml file driving the application's config directory.
Details are provided to give more details about the folllowd configuration.
