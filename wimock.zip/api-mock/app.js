'use strict';

var SwaggerExpress = require('swagger-express-mw');
var app = require('express')();
module.exports = app; // for testing

var config = {
  appRoot: __dirname, // required config
  
  swaggerSecurityHandlers: {
    header_token: function (req, authOrSecDef, scopesOrApiKey, cb) {
      // your security code
	  console.log('scopesOrApiKey: ' + scopesOrApiKey);
      if ('1234' === scopesOrApiKey) {
        cb(null);
      } else {
        cb(new Error('access denied, really???!'));
      }
    },
	query_token: function (req, authOrSecDef, scopesOrApiKey, cb) {
      // your security code
	  console.log('scopesOrApiKey: ' + scopesOrApiKey);
      if ('1234' === scopesOrApiKey) {
        cb(null);
      } else {
        cb(new Error('access denied, really???!'));
      }
    }
  }
};

SwaggerExpress.create(config, function(err, swaggerExpress) {
  if (err) { throw err; }

  // install middleware
  swaggerExpress.register(app);

  var port = process.env.PORT || 10010;
  app.listen(port);

  if (swaggerExpress.runner.swagger.paths['/documents']) {
    console.log('try this request example:\ncurl http://127.0.0.1:' + port + '/business-scope/v1/documents');
  }
});
