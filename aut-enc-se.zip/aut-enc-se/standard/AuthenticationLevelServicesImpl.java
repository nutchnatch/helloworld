package com.bnppa.sesame.services.standard;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnppa.sesame.MessageDescriptionBuilder;
import com.bnppa.sesame.account.AccountEBO;
import com.bnppa.sesame.account.AccountPermSBO;
import com.bnppa.sesame.applicationdomain.ApplicationDomainEBO;
import com.bnppa.sesame.applicationdomain.ApplicationDomainSBO;
import com.bnppa.sesame.authaccount.AuthAccountEBO;
import com.bnppa.sesame.authenticationlevel.AuthenticationLevelEBO;
import com.bnppa.sesame.authenticationlevel.AuthenticationLevelSBO;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.TechnicalBOException;
import com.bnppa.sesame.perm.PermissionEBO;
import com.bnppa.sesame.perm.PermissionSBO;
import com.bnppa.sesame.services.exception.FunctionalException;
import com.bnppa.sesame.services.exception.TechnicalException;
import com.bnppa.sesame.services.standard.mapper.GeneralExceptionMapper;
import com.bnppa.sesame.services.standard.model.Permission;
import com.bnppa.sesame.token.TokenEBO;
import com.bnppa.sesame.token.TokenSBO;
import org.springframework.transaction.annotation.Transactional;
import com.bnppa.sesame.utils.annot.Profiled;
import com.bnppa.sesame.utils.annot.TokenControl;
import com.bnppa.sesame.utils.annot.Token;
import com.bnppa.sesame.utils.annot.RuntimeCatcher;
import com.bnppa.sesame.utils.annot.Audit;

/**
 * @author karakasfa 01/2013
 *
 */
public class AuthenticationLevelServicesImpl implements AuthenticationLevelServices 
{
	private static final Log logger	= LogFactory.getLog(AuthenticationLevelServicesImpl.class);

	private MessageDescriptionBuilder messageBuilder;
	private GeneralExceptionMapper exceptionMapper;
	private TokenSBO tokenSBO;
	private AuthenticationLevelSBO authenticationLevelSBO;
	private ApplicationDomainSBO applicationDomainSBO;
	private PermissionSBO permissionSBO;
	
	@Autowired
	private AccountPermSBO accountPermSBO;
	
	/* (non-Javadoc)
	 * @see com.bnppa.sesame.services.standard.AuthenticationLevelServices#isAuthorizedForLevel(java.lang.String, java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = FunctionalException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-authent_level_v1-isAuthorizedForLevel")
	@Transactional(readOnly = true)
	public boolean isAuthorizedForLevel(@Token String token, String authLevel)
		throws FunctionalException, TechnicalException 
	{
		try
		{
			TokenEBO tokenEBO = getTokenSBO().find(token);
			
			// SESAME-1427 : Check token validity
			if (tokenEBO == null) {
				String msg = getMessageBuilder().build(
						InvalidParameterBOExceptionConstants.TOKEN_NOT_EXIST,
						new String[] { token });
				logger.error(msg);
				throw new FunctionalException(msg);
			}
			
			// Sanity check
			if (StringUtils.isBlank(authLevel)) 
			{
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.AUTHENTICATION_LEVEL_IS_BLANK,
								new String[] { "OTP" });
				logger.error(msg);
				throw new InvalidParameterBOException(msg, logger);
			}
			
			// Find the authentication level, checks if it exists
			AuthenticationLevelEBO authenticationLevelEBO = getAuthenticationLevelSBO().find(authLevel);
			
			// Sanity check
			if (authenticationLevelEBO == null) 
			{
				throw new InvalidParameterBOException(
						InvalidParameterBOExceptionConstants.AUTHENTICATION_LEVEL_NOT_EXIST,
						new String[] { authLevel }, logger);
			}			
			
			// a user is authorized for a level if the authentication level of his token
			// is greater than or equals to the specified level
			return getAuthenticationLevelSBO().isStrongerOrEquals(tokenEBO.getAuthenticationLevel(), authLevel);			

		} catch (InvalidParameterBOException e) {
			throw getExceptionMapper().map(e, logger);
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(e, logger);
		}
	}

	/* (non-Javadoc)
	 * @see com.bnppa.sesame.services.standard.AuthenticationLevelServices#getPermissions(java.lang.String, java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = FunctionalException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-authent_level_v1-getPermissionsWithAuthenticationLevel")
	@Transactional(readOnly = true)
	public Permission[] getPermissionsWithAuthenticationLevel(@Token String token, String appDomainId)
		throws FunctionalException, TechnicalException 
	{
		try 
		{		
			TokenEBO tokenEBO = getTokenSBO().find(token);
			
			if (StringUtils.isBlank(appDomainId)) 
			{
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.APPLICATION_DOMAIN_IS_BLANK);
				logger.error(msg);
				throw new InvalidParameterBOException(msg, logger);
			}

			AuthAccountEBO authAccountEBO = getTokenSBO().getAuthAccount(tokenEBO);
			AccountEBO accountEBO = authAccountEBO.getAccount();
		
			ApplicationDomainEBO applicationEBO = getApplicationDomainSBO().findById(appDomainId);
			
			if (applicationEBO == null) 
			{
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.APPLICATION_DOMAIN_NOT_EXIST,
								new String[] { appDomainId });
				logger.error(msg);
				throw new InvalidParameterBOException(msg, logger);
			}
			
			// Get permissions, actually the EBO contains only the ids of the permissions
			Set permissionEBOs = accountPermSBO.getPermissions(accountEBO, applicationEBO);
			
			if(permissionEBOs == null) return null;
			
			// Retrieve all information using the ids of the permissions
			permissionEBOs = getPermissionSBO().findPermissions(getPermissionIds(permissionEBOs));
			
			if(permissionEBOs == null) return null;
			
			// return an array of permission with authentication level filled
			return (Permission[]) permissionModelSetFromEBOSet(permissionEBOs)
									.toArray(new Permission[permissionEBOs.size()]);

		} catch (InvalidParameterBOException e) {
			throw getExceptionMapper().map(e, logger);
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(e, logger);
		}
	}	
	
	/**
	 * This method returns a set of permission ids retrieved from the permission set
	 * @param permissionEBOs
	 * @return an set of String representing a permission id
	 */
	private Set getPermissionIds(Set permissionEBOs)
	{
		if(permissionEBOs == null) return null;
		
		Set result = new HashSet();
		
		for (Iterator itr = permissionEBOs.iterator(); itr.hasNext();) 
		{
			PermissionEBO permissionEBO = (PermissionEBO) itr.next();
			result.add(permissionEBO.getId());
		}
		
		return result;
	}
	
	/**
	 * This method tranforms a set of permissionEBOs to a set of permission model object
	 * @param permissionEBOs
	 * @return permission (model� object) hashset
	 */
	private Set permissionModelSetFromEBOSet(Set permissionEBOs)
	{
		if(permissionEBOs == null) return null;

		Set result = new HashSet();
		
		if(permissionEBOs != null)
		{
			for (Iterator itr = permissionEBOs.iterator(); itr.hasNext();) 
			{
				PermissionEBO permissionEBO = (PermissionEBO) itr.next();
				result.add(permissionEBOToModel(permissionEBO));
			}
		}
		
		return result;
	}
	
	/**
	 * Creates a model permission object from a permission object EBO.
	 * @param permissionEBO
	 * @return the model object
	 */
	private Permission permissionEBOToModel(PermissionEBO permissionEBO)
	{
		if(permissionEBO == null) return null;

		Permission permission = new Permission();

		permission.setId(permissionEBO.getId());
		permission.setLabel(permissionEBO.getLabel());
		permission.setAuthenticationLevel(permissionEBO.getAuthenticationLevel());
		
		Set areas = permissionEBO.getAuthorizingAreasAlphaId();
		if(areas == null)
			permission.setAreaIds(null);
		else
			permission.setAreaIds((String[]) areas.toArray(new String[areas.size()]));
		
		Set domains = permissionEBO.getAuthorizingApplicationDomainId();
		if(domains == null)
			permission.setApplicationDomainIds(null);
		else
			permission.setApplicationDomainIds((String[]) domains.toArray(new String[domains.size()]));
		
		return permission;
	}
	
	/**
	 * @return the authenticationLevelSBO
	 */
	public AuthenticationLevelSBO getAuthenticationLevelSBO() {
		return authenticationLevelSBO;
	}

	/**
	 * @param authenticationLevelSBO the authenticationLevelSBO to set
	 */
	public void setAuthenticationLevelSBO(
			AuthenticationLevelSBO authenticationLevelSBO) {
		this.authenticationLevelSBO = authenticationLevelSBO;
	}

	/**
	 * @return the exceptionMapper
	 */
	public GeneralExceptionMapper getExceptionMapper() {
		return exceptionMapper;
	}

	/**
	 * @param exceptionMapper the exceptionMapper to set
	 */
	public void setExceptionMapper(GeneralExceptionMapper exceptionMapper) {
		this.exceptionMapper = exceptionMapper;
	}

	/**
	 * @return the messageBuilder
	 */
	public MessageDescriptionBuilder getMessageBuilder() {
		return messageBuilder;
	}

	/**
	 * @param messageBuilder the messageBuilder to set
	 */
	public void setMessageBuilder(MessageDescriptionBuilder messageBuilder) {
		this.messageBuilder = messageBuilder;
	}

	/**
	 * @return the tokenSBO
	 */
	public TokenSBO getTokenSBO() {
		return tokenSBO;
	}

	/**
	 * @param tokenSBO the tokenSBO to set
	 */
	public void setTokenSBO(TokenSBO tokenSBO) {
		this.tokenSBO = tokenSBO;
	}

	/**
	 * @return the applicationDomainSBO
	 */
	public ApplicationDomainSBO getApplicationDomainSBO() {
		return applicationDomainSBO;
	}

	/**
	 * @param applicationDomainSBO the applicationDomainSBO to set
	 */
	public void setApplicationDomainSBO(ApplicationDomainSBO applicationDomainSBO) {
		this.applicationDomainSBO = applicationDomainSBO;
	}

	/**
	 * @return the permissionSBO
	 */
	public PermissionSBO getPermissionSBO() {
		return permissionSBO;
	}

	/**
	 * @param permissionSBO the permissionSBO to set
	 */
	public void setPermissionSBO(PermissionSBO permissionSBO) {
		this.permissionSBO = permissionSBO;
	}

}
