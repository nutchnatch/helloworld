/*
 * Created on 13 ao�t 09
 */
package com.bnppa.sesame.services.standard;

import gencl.sesame.services.standard.proxy.ArrayOfTns3NillableSecretResponse;
import gencl.sesame.services.standard.proxy.ArrayOfTns4NillableKeyValue;
import gencl.sesame.services.standard.proxy.AuthenticationServicesWSP;
import gencl.sesame.services.standard.proxy.ExpiredPasswordException;
import gencl.sesame.services.standard.proxy.InvalidParameterException;
import gencl.sesame.services.standard.proxy.InvalidPasswordException;
import gencl.sesame.services.standard.proxy.InvalidTokenException;
import gencl.sesame.services.standard.proxy.LockedLoginException;
import gencl.sesame.services.standard.proxy.LoginException;
import gencl.sesame.services.standard.proxy.TechnicalException;
import gencl.sesame.services.standard.proxy.UnauthorizedActionException;
import gencl.sesame.services.standard.proxy.UnsupportedActionException;
import gencl.sesame.services.vo.AccountId;

import java.text.Collator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bnppa.sesame.MessageDescriptionBuilder;
import com.bnppa.sesame.application.ApplicationEBO;
import com.bnppa.sesame.application.ApplicationSBO;
import com.bnppa.sesame.authaccount.AuthAccountEBO;
import com.bnppa.sesame.authaccount.AuthAccountSBO;
import com.bnppa.sesame.channelmessageformat.ChannelMessageFormatEBO;
import com.bnppa.sesame.channelmessageformat.ChannelMessageFormatSBO;
import com.bnppa.sesame.constants.AccountConstants;
import com.bnppa.sesame.constants.AuthAccountConstants;
import com.bnppa.sesame.constants.CommonBOExceptionConstants;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.constants.LoginBOExceptionConstants;
import com.bnppa.sesame.constants.TechnicalBOExceptionConstants;
import com.bnppa.sesame.constants.UnAuthorizedActionBOExceptionConstants;
import com.bnppa.sesame.exceptions.BadPasswordBOException;
import com.bnppa.sesame.exceptions.ExpiredPasswordBOException;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.InvalidPasswordBOException;
import com.bnppa.sesame.exceptions.LockedAccountBOException;
import com.bnppa.sesame.exceptions.LoginBOException;
import com.bnppa.sesame.exceptions.TechnicalBOException;
import com.bnppa.sesame.exceptions.UnAuthorizedActionBOException;
import com.bnppa.sesame.secretquestion.SecretQuestionEBO;
import com.bnppa.sesame.secretquestion.SecretQuestionSBO;
import com.bnppa.sesame.services.standard.mapper.StandardExceptionMapper;
import com.bnppa.sesame.token.TokenEBO;
import com.bnppa.sesame.token.TokenSBO;
import com.bnppa.sesame.utils.WebFaultFactory;
import org.springframework.transaction.annotation.Transactional;
import com.bnppa.sesame.utils.annot.Profiled;
import java.lang.Exception;
import com.bnppa.sesame.utils.annot.RuntimeCatcher;
import com.bnppa.sesame.utils.annot.Audit;
import com.bnppa.sesame.utils.annot.AuditHide;
import com.bnppa.sesame.utils.annot.Login;
import com.bnppa.sesame.utils.annot.Token;
import com.bnppa.sesame.utils.annot.TokenControl;

/**
 * @author bellidori
 * @version 13 ao�t 09
 * @version 24/08/10
 * @version 25/08/10
 */
public class StandardAuthenticationServicesImpl implements AuthenticationServicesWSP {

	private static final Log logger = LogFactory.getLog(StandardAuthenticationServicesImpl.class);

	/**
	 * Exceptions messages buileder
	 */
	private MessageDescriptionBuilder messageBuilder;

	/**
	 * Exception mapper.
	 */
	private StandardExceptionMapper exceptionMapper;

	/**
	 * Session business object of authentication account
	 */
	private AuthAccountSBO authAccountSBO;

	/**
	 * Secret question session business object.
	 */
	private SecretQuestionSBO secretQuestionSBO;

	/**
	 * session business object of token
	 */
	private TokenSBO tokenSBO;

	private ApplicationSBO applicationSBO;

	private ChannelMessageFormatSBO channelMessageFormatSBO;

	/**
	 * @author bellidori
	 * @version 13 ao�t 09
	 * @see com.bnppa.sesame.services.standard.AuthenticationServices#changePassword(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@Profiled(name = "in-soap-authentication_std_v1-changePassword")
	@Transactional(noRollbackFor = { com.bnppa.sesame.services.exception.LoginException.class })
	public void changePassword(@Login String login, @AuditHide String oldPassword, @AuditHide String newPassword) throws LoginException, LockedLoginException,
			InvalidPasswordException, UnsupportedActionException, TechnicalException {

		try {

			AuthAccountEBO authAccountEBO = getAuthAccountSBO().find(login);
			if (authAccountEBO == null) {
				String msg = getMessageBuilder().build(LoginBOExceptionConstants.LOGIN_IS_WRONG, new String[] { login });
				logger.error(msg);
				throw WebFaultFactory.createLoginException(msg, null);
			}

			if (authAccountEBO.getAccount() != null && authAccountEBO.getAccount().getIdAccountType() != null) {
				if (AccountConstants.TYPE_APPLICATION.equals(authAccountEBO.getAccount().getIdAccountType())) {
					String msg = getMessageBuilder().build(CommonBOExceptionConstants.FORBID_ACCESS_SERVICE,
							new String[] { AccountConstants.TYPE_APPLICATION });
					gencl.sesame.services.common.exception.UnsupportedActionException bean = new gencl.sesame.services.common.exception.UnsupportedActionException();
					bean.setMessage(msg);
					UnsupportedActionException exc = new UnsupportedActionException(msg, bean);
					logger.error(msg);
					throw exc;
				}
			}
			// TODO SCH check the way to change password
			authAccountSBO.changePassword(authAccountEBO, oldPassword, newPassword);

		} catch (LoginBOException e) {
			LoginException exc = WebFaultFactory.createLoginException(
					getMessageBuilder().build(LoginBOExceptionConstants.LOGIN_IS_WRONG, new String[] { login }), e);
			logger.error(exc, e);
			throw exc;
		} catch (LockedAccountBOException e) {
			throw getExceptionMapper().map(logger, e);
		} catch (InvalidPasswordBOException e) {
			throw getExceptionMapper().map(logger, e);
		} catch (UnAuthorizedActionBOException e) {
			String msg = getMessageBuilder().build(e.getMessageCode(), e.getParameters());
			gencl.sesame.services.common.exception.UnsupportedActionException bean = new gencl.sesame.services.common.exception.UnsupportedActionException();
			bean.setMessage(msg);
			UnsupportedActionException exc = new UnsupportedActionException(msg, bean);
			logger.error(exc, e);
			throw exc;
		} catch (InvalidParameterBOException e) {
			LoginException exc = WebFaultFactory.createLoginException(
					getMessageBuilder().build(LoginBOExceptionConstants.LOGIN_IS_WRONG, new String[] { login }), e);
			logger.error(exc, e);
			throw exc;
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}

	}

	/**
	 * @author bellidori
	 * @version 13 ao�t 09
	 * @see com.bnppa.sesame.services.standard.AuthenticationServices#login(java.lang.String,
	 *      java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@Profiled(name = "in-soap-authentication_std_v1-login")
	@Transactional(noRollbackFor = { com.bnppa.sesame.services.exception.LoginException.class })
	public String login(@Login String login, @AuditHide String password) throws LoginException, LockedLoginException, ExpiredPasswordException,
			TechnicalException {

		try {
			AuthAccountEBO authAccountEBO = getAuthAccountSBO().find(login, AuthAccountConstants.SYST_SESAME,
					AuthAccountConstants.TYPE_CLIENT);
			if (authAccountEBO == null) {
				authAccountEBO = getAuthAccountSBO().find(login, AuthAccountConstants.SYST_SESAME, AuthAccountConstants.TYPE_TIERS);
			}
			if (authAccountEBO == null) {
				authAccountEBO = getAuthAccountSBO().findInRefogFromAuth(login);
			}
			if (authAccountEBO == null) {
				String msg = getMessageBuilder().build(LoginBOExceptionConstants.LOGIN_IS_WRONG, new String[] { login });
				logger.error(msg);
				throw WebFaultFactory.createLoginException(msg, null);
			}

			if (authAccountEBO.getAccount() != null && authAccountEBO.getAccount().getIdAccountType() != null) {
				if (!AccountConstants.TYPE_USER.equals(authAccountEBO.getAccount().getIdAccountType())
						&& !AccountConstants.TYPE_MONITORING.equals(authAccountEBO.getAccount().getIdAccountType())) {
					String msg = getMessageBuilder().build(CommonBOExceptionConstants.FORBID_ACCESS_SERVICE,
							new String[] { authAccountEBO.getAccount().getIdAccountType() });
					logger.error(msg);
					throw WebFaultFactory.createLoginException(msg, null);
				}
			}

			try {
				authAccountSBO.login(authAccountEBO, password);
			} catch (LoginBOException e) {
				throw getExceptionMapper().map(logger, e);
			}

			TokenEBO tokenEBO = getTokenSBO().create(authAccountEBO);

			return tokenEBO.getId();

		} catch (InvalidParameterBOException e) {
			LoginException exc = WebFaultFactory.createLoginException(
					getMessageBuilder().build(e.getMessageCode(), new String[] { login }), e);
			logger.error(exc, e);
			throw exc;
		} catch (BadPasswordBOException e) {
			LoginException exc = WebFaultFactory.createLoginException(
					getMessageBuilder().build(LoginBOExceptionConstants.LOGIN_IS_WRONG, new String[] { login }), e);
			logger.error(exc, e);
			throw exc;
		} catch (LockedAccountBOException e) {
			throw getExceptionMapper().map(logger, e);
		} catch (ExpiredPasswordBOException e) {
			String msg = getMessageBuilder().build(e.getMessageCode(), new String[] { login });
			gencl.sesame.services.exception.ExpiredPasswordException bean = new gencl.sesame.services.exception.ExpiredPasswordException();
			bean.setMessage(msg);
			ExpiredPasswordException exc = new ExpiredPasswordException(msg, bean, e);
			logger.error(exc, e);
			throw exc;
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}
	}

	/**
	 * @author bellidori
	 * @version 13 ao�t 09
	 * @see com.bnppa.sesame.services.standard.AuthenticationServices#loginInUserRef(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@Profiled(name = "in-soap-authentication_std_v1-loginInUserRef")
	@Transactional(noRollbackFor = { com.bnppa.sesame.services.exception.LoginException.class })
	public String loginInUserRef(@Login String login, @AuditHide String password, String authType) throws LoginException, LockedLoginException,
			ExpiredPasswordException, InvalidParameterException, TechnicalException {

		try {
			AuthAccountEBO authAccountEBO = null;

			if (AuthAccountConstants.TYPE_GROUP.equals(authType)) {
				authAccountEBO = getAuthAccountSBO().findInRefogFromAuth(login);
			} else {
				authAccountEBO = getAuthAccountSBO().find(login, AuthAccountConstants.SYST_SESAME, authType);
			}

			if (authAccountEBO == null) {
				String msg = getMessageBuilder().build(LoginBOExceptionConstants.LOGIN_IS_WRONG, new String[] { login });
				logger.error(msg);
				throw WebFaultFactory.createLoginException(msg, null);
			}

			if (authAccountEBO.getAccount() != null && authAccountEBO.getAccount().getIdAccountType() != null) {
				if (!AccountConstants.TYPE_USER.equals(authAccountEBO.getAccount().getIdAccountType())
						&& !AccountConstants.TYPE_MONITORING.equals(authAccountEBO.getAccount().getIdAccountType())) {
					String msg = getMessageBuilder().build(CommonBOExceptionConstants.FORBID_ACCESS_SERVICE,
							new String[] { authAccountEBO.getAccount().getIdAccountType() });
					logger.error(msg);
					throw WebFaultFactory.createLoginException(msg, null);
				}
			}

			authAccountSBO.login(authAccountEBO, password);

			TokenEBO tokenEBO = getTokenSBO().create(authAccountEBO);

			return tokenEBO.getId();

		} catch (LoginBOException e) {
			LoginException exc = WebFaultFactory.createLoginException(
					getMessageBuilder().build(e.getMessageCode(), new String[] { login }), e);
			logger.error(exc, e);
			throw exc;
		} catch (InvalidParameterBOException e) {
			LoginException exc = WebFaultFactory.createLoginException(
					getMessageBuilder().build(LoginBOExceptionConstants.LOGIN_IS_WRONG, new String[] { login }), e);
			logger.error(exc, e);
			throw exc;
		} catch (BadPasswordBOException e) {
			LoginException exc = WebFaultFactory.createLoginException(
					getMessageBuilder().build(LoginBOExceptionConstants.LOGIN_IS_WRONG, new String[] { login }), e);
			logger.error(exc, e);
			throw exc;
		} catch (LockedAccountBOException e) {
			throw getExceptionMapper().map(logger, e);
		} catch (ExpiredPasswordBOException e) {
			String msg = getMessageBuilder().build(e.getMessageCode(), new String[] { login });
			gencl.sesame.services.exception.ExpiredPasswordException bean = new gencl.sesame.services.exception.ExpiredPasswordException();
			bean.setMessage(msg);
			ExpiredPasswordException exc = new ExpiredPasswordException(msg, bean, e);

			logger.error(exc, e);
			throw exc;
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}

	}

	/**
	 * @author bellidori
	 * @version 13 ao�t 09
	 * @see com.bnppa.sesame.services.standard.AuthenticationServices#logout(java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@Profiled(name = "in-soap-authentication_std_v1-logout")
	@Transactional(readOnly = true)
	public void logout(@Token String token) throws InvalidTokenException, TechnicalException {

		try {
			TokenEBO ebo = tokenSBO.find(token);

			if (ebo == null) {
				// SESAME-1262
				// InvalidTokenException exc = new InvalidTokenException();
				logger.debug("The tokenEBO associated to (" + token + ") hasn't been found in cache");
				// throw exc;
			} else {
				// Token found in cache
				tokenSBO.delete(ebo);
			}
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}

	}

	/**
	 * @author bellidori
	 * @author gilletmc
	 * @version 13 ao�t 09
	 * @version Aug 04, 2010
	 * @see com.bnppa.sesame.services.standard.AuthenticationServices#resetAndSendPasswordBySecretResponses(com.bnppa.sesame.services.vo.AccountId,
	 *      com.bnppa.sesame.services.vo.SecretResponse[], java.lang.String,
	 *      java.lang.String, java.lang.String,
	 *      com.bnppa.sesame.services.common.model.KeyValue[])
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@Profiled(name = "in-soap-authentication_std_v1-resetAndSendPasswordBySecretResponses")
	@Transactional(rollbackFor = { Exception.class })
	public void resetAndSendPasswordBySecretResponses(@Login AccountId accountId, @AuditHide ArrayOfTns3NillableSecretResponse secretResponses,
			String applicationCode, String channelType, String channelMessageFormatCode,
			ArrayOfTns4NillableKeyValue channelMessageParameters) throws InvalidParameterException, UnauthorizedActionException,
			TechnicalException {

		try {
			// Check Parameters
			if (accountId == null) {
				String msg = getMessageBuilder().build(InvalidParameterBOExceptionConstants.ACCOUNT_ID_IS_EMPTY);
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			AuthAccountEBO authAccountEBO = getAuthAccountSBO().find(accountId.getLogin(), AuthAccountConstants.SYST_SESAME,
					accountId.getAuthType());

			if (authAccountEBO == null) {
				String msg = getMessageBuilder().build(InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_WITHTYPE_NOT_EXIST,
						new String[] { accountId.getLogin(), accountId.getAuthType() });
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			if (authAccountEBO.getAccount() != null && authAccountEBO.getAccount().getIdAccountType() != null) {
				if (AccountConstants.TYPE_APPLICATION.equals(authAccountEBO.getAccount().getIdAccountType())) {
					String msg = getMessageBuilder().build(CommonBOExceptionConstants.FORBID_ACCESS_SERVICE,
							new String[] { AccountConstants.TYPE_APPLICATION });
					logger.error(msg);
					throw WebFaultFactory.createUnauthorizedActionException(msg);
				}
			}

			if (secretResponses == null) {
				String msg = getMessageBuilder().build(InvalidParameterBOExceptionConstants.SECRET_RESPONSES_EMPTY);
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			} else if (applicationCode == null) {
				String msg = getMessageBuilder().build(InvalidParameterBOExceptionConstants.APPLICATION_CODE_IS_BLANK);
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			} else if (channelType == null) {
				String msg = getMessageBuilder().build(InvalidParameterBOExceptionConstants.CHANNEL_TYPE_IS_NULL);
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			} else if (channelMessageFormatCode == null) {
				String msg = getMessageBuilder().build(InvalidParameterBOExceptionConstants.CHANNEL_MESSAGE_FORMAT_CODE_IS_NULL);
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			if (AuthAccountConstants.TYPE_GROUP.equals(accountId.getAuthType())) {
				String msg = getMessageBuilder().build(UnAuthorizedActionBOExceptionConstants.CANNOT_RESET_GROUP_AUTHACCOUNT_PWD,
						new String[] { accountId.getAuthType() });
				logger.error(msg);
				throw WebFaultFactory.createUnauthorizedActionException(msg);
			}

			// Check secret responses
			Map userSecretResponses = getAuthAccountSBO().findSecretResponses(authAccountEBO);

			boolean isChecked = false;

			// For each response
			for (int i = 0; i < secretResponses.getSecretResponseLength(); i++) {
				gencl.sesame.services.vo.SecretResponse aSecretResponse = secretResponses.getSecretResponse(i);
				String questionFunctionalId = aSecretResponse.getQuestionId();
				SecretQuestionEBO secretQuestion = getSecretQuestionSBO().find(questionFunctionalId);
				String userResponse = (String) userSecretResponses.get(secretQuestion);

				if (userResponse != null) {
					// Instantiation d'un collator
					Collator compareOperator = Collator.getInstance(new Locale(secretQuestion.getLanguage()));

					// Comparaison sans tenir compte des accents
					compareOperator.setStrength(Collator.PRIMARY);
					logger.debug("compare : " + compareOperator.compare(userResponse, aSecretResponse.getResponse()));
					if (compareOperator.compare(userResponse, aSecretResponse.getResponse()) != 0) {
						String msg = getMessageBuilder().build(InvalidParameterBOExceptionConstants.SECRET_RESPONSES_INCORRECT,
								new String[] { accountId.getLogin(), accountId.getAuthType() });
						logger.error(msg);
						throw WebFaultFactory.createInvalidParameterException(msg);
					} else {
						isChecked = true;
					}
				} else {
					String msg = getMessageBuilder().build(InvalidParameterBOExceptionConstants.SECRET_RESPONSES_NOT_FOUND,
							new String[] { accountId.getLogin(), accountId.getAuthType() });
					logger.error(msg);
					throw WebFaultFactory.createInvalidParameterException(msg);
				}

			}

			// one response checked ?
			if (!isChecked) {
				String msg = getMessageBuilder().build(InvalidParameterBOExceptionConstants.SECRET_RESPONSES_INCORRECT,
						new String[] { accountId.getLogin(), accountId.getAuthType() });
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			// Check existence of ApplicationEBO
			ApplicationEBO applicationEBO = getApplicationSBO().find(applicationCode);
			if (applicationEBO == null) {
				String msg = getMessageBuilder().build(InvalidParameterBOExceptionConstants.APPLICATION_NOT_EXIST,
						new String[] { applicationCode });
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			// Check existence of ChannelMessageFormatEBO
			ChannelMessageFormatEBO channelMessageFormatEBO = getChannelMessageFormatSBO().find(channelMessageFormatCode, channelType);
			if (channelMessageFormatEBO == null) {
				String msg = getMessageBuilder().build(InvalidParameterBOExceptionConstants.CHANNEL_MESSAGE_FORMAT_NOT_EXIST,
						new String[] { channelMessageFormatCode });
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			Map<String, String> parameters = new HashMap<>();
			if (channelMessageParameters != null) {
				for (int i = 0; i < channelMessageParameters.getKeyValueLength(); i++) {
					parameters.put(channelMessageParameters.getKeyValue(i).getKey(), channelMessageParameters.getKeyValue(i).getValue());
				}
			}

			authAccountSBO.resetAndSendPassword(authAccountEBO, authAccountEBO, channelMessageFormatEBO, parameters, new Date(),
					applicationEBO.getSecurityLevel());
		} catch (InvalidParameterBOException e) {
			throw getExceptionMapper().map(logger, e);
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}
	}

	/**
	 * @author bellidori
	 * @see com.bnppa.sesame.services.standard.AuthenticationServices#setSecretResponses(java.lang.String,
	 *      com.bnppa.sesame.services.vo.SecretResponse[])
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = InvalidTokenException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-authentication_std_v1-setSecretResponses")
	@Transactional(rollbackFor = { Exception.class })
	public void setSecretResponses(@Token String token, ArrayOfTns3NillableSecretResponse secretResponses) throws InvalidTokenException,
			UnauthorizedActionException, InvalidParameterException, TechnicalException {

		try {
			TokenEBO tokenEBO = tokenSBO.find(token);

			/*
			 * NOT NEED TO DO THAT BECAUSE AN ASPECT VERIFY THAT THE TOKEN IS
			 * NOT NULL
			 * 
			 * if (tokenEBO == null) { String msg = getMessageBuilder().build(
			 * InvalidParameterBOExceptionConstants.TOKEN_NOT_EXIST); if
			 * (logger.isInfoEnabled()) { logger.info(new
			 * StringBuffer(msg).append(" : ").append( token).toString()); }
			 * throw new InvalidTokenException(msg); }
			 */

			if (AccountConstants.TYPE_APPLICATION.equals(tokenEBO.getIdAccountType())) {
				String msg = getMessageBuilder().build(CommonBOExceptionConstants.FORBID_ACCESS_SERVICE,
						new String[] { AccountConstants.TYPE_APPLICATION });
				logger.error(msg);
				throw WebFaultFactory.createUnauthorizedActionException(msg);
			}

			// check secretResponses is valid
			if (secretResponses == null || secretResponses.getSecretResponseLength() == 0) {
				String msg = getMessageBuilder().build(InvalidParameterBOExceptionConstants.SECRET_RESPONSES_EMPTY);
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);

			}

			// check question and response are not blank
			for (int i = 0; i < secretResponses.getSecretResponseLength(); i++) {
				if (StringUtils.isBlank(secretResponses.getSecretResponse(i).getResponse())) {
					String msg = getMessageBuilder().build(InvalidParameterBOExceptionConstants.SECRET_RESPONSES_EMPTY);
					logger.error(msg);
					throw WebFaultFactory.createInvalidParameterException(msg);

				}

				if (StringUtils.isBlank(secretResponses.getSecretResponse(i).getQuestionId())) {
					String msg = getMessageBuilder().build(InvalidParameterBOExceptionConstants.SECRET_QUESTION_ID_IS_BLANK);
					logger.error(msg);
					throw WebFaultFactory.createInvalidParameterException(msg);

				}
			}

			// }

			AuthAccountEBO authAccountEBO = getTokenSBO().getAuthAccount(tokenEBO);

			Map oldSecretResponses = this.getAuthAccountSBO().findSecretResponses(authAccountEBO);

			// built a map of new secretResponse
			Map newSecretResponses = new HashMap();
			for (int i = 0; i < secretResponses.getSecretResponseLength(); i++) {
				gencl.sesame.services.vo.SecretResponse secretResponse = secretResponses.getSecretResponse(i);
				SecretQuestionEBO secretQuestionEBO = getSecretQuestionSBO().find(secretResponse.getQuestionId());
				// question exists ?
				if (secretQuestionEBO == null) {
					String msg = getMessageBuilder().build(InvalidParameterBOExceptionConstants.SECRET_QUESTION_NOT_EXIST,
							new String[] { secretResponse.getQuestionId() });
					logger.error(msg);
					throw WebFaultFactory.createInvalidParameterException(msg);
				}
				newSecretResponses.put(secretQuestionEBO, secretResponse.getResponse());

			}

			Set oldSecretQuestions = oldSecretResponses.keySet();
			Set newSecretQuestions = newSecretResponses.keySet();

			// find secretQuestions to delete
			Set secretQuestionToDelete = new HashSet(oldSecretQuestions);
			secretQuestionToDelete.removeAll(newSecretQuestions);
			for (Iterator iter = secretQuestionToDelete.iterator(); iter.hasNext();) {
				SecretQuestionEBO element = (SecretQuestionEBO) iter.next();
				this.getAuthAccountSBO().removeSecretResponse(authAccountEBO, element);
				iter.remove();

			}
			secretQuestionToDelete = null;
			// find new responses
			Set secretQuestionToAdd = new HashSet(newSecretQuestions);
			secretQuestionToAdd.removeAll(oldSecretQuestions);
			for (Iterator iter = secretQuestionToAdd.iterator(); iter.hasNext();) {
				SecretQuestionEBO element = (SecretQuestionEBO) iter.next();
				this.getAuthAccountSBO().addSecretResponse(authAccountEBO, element, (String) newSecretResponses.get(element));
				iter.remove();

			}
			secretQuestionToAdd = null;
			// find response to update
			Set secretQuestionToUpdate = new HashSet(oldSecretQuestions);
			secretQuestionToUpdate.retainAll(newSecretQuestions);
			oldSecretQuestions = null;
			newSecretQuestions = null;
			for (Iterator iter = secretQuestionToUpdate.iterator(); iter.hasNext();) {
				SecretQuestionEBO element = (SecretQuestionEBO) iter.next();

				String oldResponse = (String) oldSecretResponses.get(element);
				String newResponse = (String) newSecretResponses.get(element);

				// if response is not same => update it !
				if (!oldResponse.equals(newResponse)) {

					this.getAuthAccountSBO().updateSecretResponse(authAccountEBO, element, (String) newSecretResponses.get(element));
				}
				iter.remove();

			}
			secretQuestionToUpdate = null;

		} catch (TechnicalBOException e) {
			String msg = getMessageBuilder().build(TechnicalBOExceptionConstants.GET_ECACHE_ERROR);
			logger.error(msg);
			throw WebFaultFactory.createTechnicalException(msg);
		}

	}

	/**
	 * @param constanteMsg
	 * @param param
	 * @throws InvalidParameterException
	 */
	private void throwIPE(String constanteMsg, String param) throws InvalidParameterException {
		String msg = getMessageBuilder().build(constanteMsg, new String[] { param });
		logger.error(msg);
		throw WebFaultFactory.createInvalidParameterException(msg);
	}

	/**
	 * @param constanteMsg
	 * @throws InvalidParameterException
	 */
	private void throwIPE(String constanteMsg) throws InvalidParameterException {
		String msg = getMessageBuilder().build(constanteMsg);
		logger.error(msg);
		throw WebFaultFactory.createInvalidParameterException(msg);
	}

	/**
	 * @author bellidori
	 * @version 13 ao�t 09
	 * @see com.bnppa.sesame.services.standard.AuthenticationServices#validateToken(java.lang.String)
	 */
	@RuntimeCatcher(techEx = TechnicalException.class)
	@Profiled(name = "in-soap-authentication_std_v1-validateToken")
	@Transactional(readOnly = true)
	public Boolean validateToken(String token) throws TechnicalException {

		try {

			TokenEBO tokenEBO = tokenSBO.find(token);

			if (tokenEBO != null && getTokenSBO().getAuthAccount(tokenEBO) != null) {

				return Boolean.TRUE;

			}

			return Boolean.FALSE;

		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}

	}

	/**
	 * @return Returns the authAccountSBO.
	 */
	private AuthAccountSBO getAuthAccountSBO() {
		return authAccountSBO;
	}

	/**
	 * @param authAccountSBO
	 *            The authAccountSBO to set.
	 */
	public void setAuthAccountSBO(AuthAccountSBO authAccountSBO) {
		this.authAccountSBO = authAccountSBO;
	}

	/**
	 * @return Returns the tokenSBO.
	 */
	private TokenSBO getTokenSBO() {
		return tokenSBO;
	}

	/**
	 * @param tokenSBO
	 *            The tokenSBO to set.
	 */
	public void setTokenSBO(TokenSBO tokenSBO) {
		this.tokenSBO = tokenSBO;
	}

	/**
	 * @return messageBuilder
	 */
	private MessageDescriptionBuilder getMessageBuilder() {
		return messageBuilder;
	}

	/**
	 * @param messageBuilder
	 */
	public void setMessageBuilder(MessageDescriptionBuilder messageBuilder) {
		this.messageBuilder = messageBuilder;
	}

	/**
	 * @return the exceptionMapper
	 */
	private StandardExceptionMapper getExceptionMapper() {
		return this.exceptionMapper;
	}

	/**
	 * @param exceptionMapper
	 *            the exceptionMapper to set
	 */
	public void setExceptionMapper(StandardExceptionMapper exceptionMapper) {
		this.exceptionMapper = exceptionMapper;
	}

	/**
	 * @return the secretQuestionSBO
	 */
	private SecretQuestionSBO getSecretQuestionSBO() {
		return this.secretQuestionSBO;
	}

	/**
	 * @param secretQuestionSBO
	 *            the secretQuestionSBO to set
	 */
	public void setSecretQuestionSBO(SecretQuestionSBO secretQuestionSBO) {
		this.secretQuestionSBO = secretQuestionSBO;
	}

	/**
	 * @return the applicationSBO
	 */
	public ApplicationSBO getApplicationSBO() {
		return applicationSBO;
	}

	/**
	 * @param applicationSBO
	 *            the applicationSBO to set
	 */
	public void setApplicationSBO(ApplicationSBO applicationSBO) {
		this.applicationSBO = applicationSBO;
	}

	/**
	 * @return the channelMessageFormatSBO
	 */
	public ChannelMessageFormatSBO getChannelMessageFormatSBO() {
		return channelMessageFormatSBO;
	}

	/**
	 * @param channelMessageFormatSBO
	 *            the channelMessageFormatSBO to set
	 */
	public void setChannelMessageFormatSBO(ChannelMessageFormatSBO channelMessageFormatSBO) {
		this.channelMessageFormatSBO = channelMessageFormatSBO;
	}

}
