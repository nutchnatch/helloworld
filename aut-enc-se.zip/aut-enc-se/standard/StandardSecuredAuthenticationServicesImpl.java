/*
 * Cr�� le 7 sept. 2009
 *
 * TODO Pour changer le mod�le de ce fichier g�n�r�, allez � :
 * Fen�tre - Pr�f�rences - Java - Style de code - Mod�les de code
 */
package com.bnppa.sesame.services.standard;

import gencl.sesame.services.standard.proxy.ExpiredPasswordException;
import gencl.sesame.services.standard.proxy.LockedLoginException;
import gencl.sesame.services.standard.proxy.LoginException;
import gencl.sesame.services.standard.proxy.TechnicalException;

import gencl.sesame.services.standard.proxy.SecuredAuthenticationServicesWSP;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bnppa.sesame.MessageDescriptionBuilder;
import com.bnppa.sesame.authaccount.AuthAccountEBO;
import com.bnppa.sesame.authaccount.AuthAccountSBO;
import com.bnppa.sesame.constants.AuthAccountConstants;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.TechnicalBOException;
import com.bnppa.sesame.services.standard.mapper.StandardExceptionMapper;
import com.bnppa.sesame.token.TokenEBO;
import com.bnppa.sesame.token.TokenSBO;
import org.springframework.transaction.annotation.Transactional;
import com.bnppa.sesame.utils.annot.Profiled;
import com.bnppa.sesame.utils.annot.RuntimeCatcher;


/**
 * @author draboma, polancoro
 * @version Sep 21, 2009
 */
public class StandardSecuredAuthenticationServicesImpl implements SecuredAuthenticationServicesWSP {

	private static final Log logger = LogFactory.getLog(StandardSecuredAuthenticationServicesImpl.class);

	/**
	 * Exceptions messages buileder
	 */
	private MessageDescriptionBuilder messageBuilder;
	
	/**
	 * Exception mapper.
	 */
	private StandardExceptionMapper exceptionMapper;

	/**
	 * Session business object of authentication account
	 */
	private AuthAccountSBO authAccountSBO;

	/**
	 * session business object of token
	 */
	private TokenSBO tokenSBO;

	/**
	 * @author polancoro
	 * @version Sep 21, 2009
	 * @see com.bnppa.sesame.services.standard.SecuredAuthenticationServices#getTokenFromLogin(java.lang.String,
	 *      Integer)
	 */
	@RuntimeCatcher(techEx = TechnicalException.class)
	@Profiled(name = "in-soap-secured_authent_v1-getTokenFromLogin")
	@Transactional(readOnly = true)
	public String getTokenFromLogin(String login, Integer authLevel) throws ExpiredPasswordException, LockedLoginException,	TechnicalException, LoginException {

		try {
			AuthAccountEBO authAccountEBO = null;
			if (new Integer(1).equals(authLevel)) { // MUTUAL AUTH						
				authAccountEBO = getAuthAccountSBO().find(login, AuthAccountConstants.SYST_REFOG, AuthAccountConstants.TYPE_GROUP);
			}
			if (authAccountEBO == null) {
				String msg = getMessageBuilder().build(InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_NOT_EXIST, new String[] { login });
				gencl.sesame.services.exception.LoginException bean = new gencl.sesame.services.exception.LoginException();
				LoginException exc = new LoginException(msg,bean);
				logger.error(msg);
				throw exc;
			}

			TokenEBO tokenEBO = getTokenSBO().create(authAccountEBO);

			return tokenEBO.getId();

		} catch (InvalidParameterBOException e) {
			String msg = getMessageBuilder().build(e.getMessageCode(), e.getParameters());
			gencl.sesame.services.exception.LoginException bean = new gencl.sesame.services.exception.LoginException();
			LoginException exc = new LoginException(msg,bean);
			logger.error(exc, e);
			throw exc;
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}
		
	}

	/**
	 * @return Returns the messageBuilder.
	 */
	private MessageDescriptionBuilder getMessageBuilder() {
		return messageBuilder;
	}

	/**
	 * @param messageBuilder
	 *            The messageBuilder to set.
	 */
	public void setMessageBuilder(MessageDescriptionBuilder messageBuilder) {
		this.messageBuilder = messageBuilder;
	}

	/**
	 * @return the exceptionMapper
	 */
	private StandardExceptionMapper getExceptionMapper() {
		return this.exceptionMapper;
	}

	/**
	 * @param exceptionMapper the exceptionMapper to set
	 */
	public void setExceptionMapper(StandardExceptionMapper exceptionMapper) {
		this.exceptionMapper = exceptionMapper;
	}

	/**
	 * @return Returns the authAccountSBO.
	 */
	private AuthAccountSBO getAuthAccountSBO() {
		return authAccountSBO;
	}

	/**
	 * @param authAccountSBO
	 *            The authAccountSBO to set.
	 */
	public void setAuthAccountSBO(AuthAccountSBO authAccountSBO) {
		this.authAccountSBO = authAccountSBO;
	}

	/**
	 * @return Returns the tokenSBO.
	 */
	private TokenSBO getTokenSBO() {
		return tokenSBO;
	}

	/**
	 * @param tokenSBO
	 *            The tokenSBO to set.
	 */
	public void setTokenSBO(TokenSBO tokenSBO) {
		this.tokenSBO = tokenSBO;
	}
}
