/*
 * Created on Dec 9, 2009
 */
package com.bnppa.sesame.services.standard;


import gencl.sesame.services.standard.proxy.BadSignatureException;
import gencl.sesame.services.standard.proxy.ExpiredPasswordException;
import gencl.sesame.services.standard.proxy.InvalidChallengeException;
import gencl.sesame.services.standard.proxy.InvalidParameterException;
import gencl.sesame.services.standard.proxy.LockedLoginException;
import gencl.sesame.services.standard.proxy.LoginException;
import gencl.sesame.services.standard.proxy.StandardSSOServicesWSP;
import gencl.sesame.services.standard.proxy.TechnicalException;
import gencl.sesame.services.vo.AccountId;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnppa.sesame.MessageDescriptionBuilder;
import com.bnppa.sesame.account.AccountEBO;
import com.bnppa.sesame.account.AccountPermSBO;
import com.bnppa.sesame.account.AccountSBO;
import com.bnppa.sesame.application.ApplicationEBO;
import com.bnppa.sesame.application.ApplicationSBO;
import com.bnppa.sesame.authaccount.AuthAccountEBO;
import com.bnppa.sesame.authaccount.AuthAccountSBO;
import com.bnppa.sesame.cache.ChallengeCache;
import com.bnppa.sesame.constants.AccountConstants;
import com.bnppa.sesame.constants.AuthAccountConstants;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.constants.LoginBOExceptionConstants;
import com.bnppa.sesame.emailaddr.EmailAddressSBO;
import com.bnppa.sesame.exceptions.BadPasswordBOException;
import com.bnppa.sesame.exceptions.ExpiredPasswordBOException;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.InvalidPasswordBOException;
import com.bnppa.sesame.exceptions.LockedAccountBOException;
import com.bnppa.sesame.exceptions.LoginBOException;
import com.bnppa.sesame.exceptions.TechnicalBOException;
import com.bnppa.sesame.partner.PartnerEBO;
import com.bnppa.sesame.partner.PartnerSBO;
import com.bnppa.sesame.person.PersonEBO;
import com.bnppa.sesame.person.PersonSBO;
import com.bnppa.sesame.services.standard.mapper.StandardExceptionMapper;
import com.bnppa.sesame.token.TokenEBO;
import com.bnppa.sesame.token.TokenSBO;
import com.bnppa.sesame.utils.WebFaultFactory;
import org.springframework.transaction.annotation.Transactional;
import com.bnppa.sesame.utils.annot.Profiled;
import com.bnppa.sesame.utils.annot.RuntimeCatcher;
import com.bnppa.sesame.utils.annot.Audit;
import com.bnppa.sesame.utils.annot.Login;

/**
 * @author behatemo
 * @version Dec 9, 2009
 */
public class StandardSSOServicesImpl implements StandardSSOServicesWSP {

	private static final Log logger	= LogFactory.getLog(StandardAuthenticationServicesImpl.class);

	/** The challenge cache */
	private ChallengeCache challengeCache;

	/**
	 * Exceptions messages buileder
	 */
	private MessageDescriptionBuilder messageBuilder;

	/**
	 * Exception mapper.
	 */
	private StandardExceptionMapper	exceptionMapper;

	/**
	 * Session business object of authentication account
	 */
	private AuthAccountSBO authAccountSBO;

	/**
	 * session business object of token
	 */
	private TokenSBO tokenSBO;

	/**
	 * Application seesion business object
	 */
	private ApplicationSBO applicationSBO;

	/**
	 * Partner seesion business object
	 */
	private PartnerSBO partnerSBO;
	
	@Autowired
	private AccountPermSBO accountPermSBO;

	/**
	 * Account seesion business object
	 */
	private AccountSBO accountSBO;

	private EmailAddressSBO emailAddressSBO;

	private PersonSBO personSBO;

	/**
	 * @param login
	 * @return sesame token
	 * @throws LoginException
	 *             if no account identified by this login exists
	 * @throws ExpiredPasswordException
	 *             if account's password has expired
	 * @throws LockedLoginException
	 *             if account has been locked
	 * @throws TechnicalException
	 */
	private String singleSignOn(String login) throws LoginException,
			ExpiredPasswordException, LockedLoginException, TechnicalException {

		try {
			AuthAccountEBO authAccountEBO = getAuthAccountSBO().find(login,
					AuthAccountConstants.SYST_SESAME,
					AuthAccountConstants.TYPE_CLIENT);
			if (authAccountEBO == null) {
				authAccountEBO = getAuthAccountSBO().find(login,
						AuthAccountConstants.SYST_SESAME,
						AuthAccountConstants.TYPE_TIERS);
			}
			if (authAccountEBO == null) {
				authAccountEBO = getAuthAccountSBO().find(login,
						AuthAccountConstants.SYST_REFOG,
						AuthAccountConstants.TYPE_GROUP, true);
			}
			if (authAccountEBO == null) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_NOT_EXIST,
								new String[] { login });
				logger.error(msg);
				throw WebFaultFactory.createLoginException(msg,null);
			}

			authAccountSBO.login(authAccountEBO, true);

			TokenEBO tokenEBO = getTokenSBO().create(authAccountEBO);

			return tokenEBO.getId();

		} catch (LoginBOException e) {
			throw getExceptionMapper().map(logger, e);
		} catch (InvalidParameterBOException e) {
			LoginException exc = WebFaultFactory.createLoginException(getMessageBuilder().build(
					e.getMessageCode(), e.getParameters()),e);
			logger.error(exc, e);
			throw exc;
		} catch (ExpiredPasswordBOException e) {
			throw getExceptionMapper().map(logger, e);
		} catch (LockedAccountBOException e) {
			throw getExceptionMapper().map(logger, e);
		} catch (BadPasswordBOException e) {
			LoginException exc = WebFaultFactory.createLoginException(getMessageBuilder().build(
					e.getMessageCode(), e.getParameters()),e);
			logger.error(exc, e);
			throw exc;
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}
	}

	/**
	 * @return Returns the messageBuilder.
	 */
	private MessageDescriptionBuilder getMessageBuilder() {
		return messageBuilder;
	}

	/**
	 * @param messageBuilder
	 *            The messageBuilder to set.
	 */
	public void setMessageBuilder(MessageDescriptionBuilder messageBuilder) {
		this.messageBuilder = messageBuilder;
	}

	/**
	 * @return Returns the authAccountSBO.
	 */
	private AuthAccountSBO getAuthAccountSBO() {
		return authAccountSBO;
	}

	/**
	 * @param authAccountSBO
	 *            The authAccountSBO to set.
	 */
	public void setAuthAccountSBO(AuthAccountSBO authAccountSBO) {
		this.authAccountSBO = authAccountSBO;
	}

	/**
	 * @return Returns the tokenSBO.
	 */
	private TokenSBO getTokenSBO() {
		return tokenSBO;
	}

	/**
	 * @param tokenSBO
	 *            The tokenSBO to set.
	 */
	public void setTokenSBO(TokenSBO tokenSBO) {
		this.tokenSBO = tokenSBO;
	}

	/**
	 * @author bellidori
	 * @version Apr 9, 2009
	 * @see com.bnppa.sesame.services.standard.StandardSSOServices#loginFromSSOWithSignature(Integer
	 *      authLevel, AccountId accountId)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@Profiled(name = "in-soap-sso_std_v1-loginFromSSOWithSignature")
	@Transactional(noRollbackFor = { com.bnppa.sesame.services.exception.LoginException.class })
	public String loginFromSSOWithSignature(Integer authLevel,
			@Login AccountId accountId) throws LoginException,
			ExpiredPasswordException, LockedLoginException, TechnicalException,
			InvalidParameterException {

		long begin = 0;

		if (logger.isInfoEnabled()) {
			begin = System.currentTimeMillis();
		}
		if (logger.isDebugEnabled()) {
			StringBuffer logsDebug = new StringBuffer(" - authLevel : "
					+ authLevel);
			logsDebug.append(" - accountId: " + accountId.toString());
			logger.debug(logsDebug);
		}

		try {
			return singleSignOn(accountId.getLogin());

		} finally {
			if (logger.isInfoEnabled()) {
				long end = System.currentTimeMillis();
				StringBuffer logsInfo = new StringBuffer(" - execution time : ");
				logsInfo.append((end - begin));
				logsInfo.append(" ms.");
				logger.info(logsInfo);
			}
		}
	}

	/**
	 * @return challengeCache
	 */
	public ChallengeCache getChallengeCache() {
		return challengeCache;
	}

	/**
	 * @param challengeCache
	 */
	public void setChallengeCache(ChallengeCache challengeCache) {
		this.challengeCache = challengeCache;
	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see com.bnppa.sesame.services.standard.StandardSSOServices#loginPartner(java.lang.String,
	 *      java.lang.String, java.lang.String,
	 *      com.bnppa.sesame.services.vo.AccountId, java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@Profiled(name = "in-soap-sso_std_v1-loginPartner")
	@Transactional(noRollbackFor = { com.bnppa.sesame.services.exception.LoginException.class })
	public String loginPartner(String partnerId, String applicationId,
			String federationRole, @Login AccountId accountId, String firstName,
			String lastName, String email, String identityProvider)
			throws LoginException, ExpiredPasswordException,
			LockedLoginException, TechnicalException,
			InvalidParameterException, BadSignatureException,
			InvalidChallengeException {

		try {

			if (accountId == null || StringUtils.isBlank(accountId.getLogin())
					|| StringUtils.isBlank(accountId.getAuthType())) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.ACCOUNT_ID_IS_INVALID);
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);

			}

			if (StringUtils.isBlank(applicationId)) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.APPLICATION_IS_BLANK);
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			ApplicationEBO applicationEBO = getApplicationSBO().find(
					applicationId);
			if (applicationEBO == null) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.APPLICATION_NOT_EXIST,
								new String[] { applicationId });
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			if (StringUtils.isBlank(partnerId)) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.PARTNER_ID_IS_BLANK);
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			PartnerEBO partnerEBO = getPartnerSBO().find(partnerId);

			if (partnerEBO == null) {
				String msg = getMessageBuilder().build(
						InvalidParameterBOExceptionConstants.PARTNER_NOT_EXIST,
						new String[] { partnerId });
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			if (StringUtils.isBlank(federationRole)) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.FEDERATION_ROLE_IS_BLANK);
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			AccountEBO technicalAccountEBO = getAccountSBO().find(partnerEBO,
					federationRole, applicationEBO);

			if (technicalAccountEBO == null) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.TECHNICAL_ACCOUNT_NOT_EXIST,
								new String[] { partnerId, federationRole,
										applicationId });
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			Set emails = new HashSet();
			// si email renseign� => cr�er un emailAddressEBO
			if (!StringUtils.isBlank(email)) {
				emails.add(getEmailAddressSBO().create(email));
			}

			PersonEBO personEBO = getPersonSBO().create(partnerId, firstName,
					lastName, emails);

			AccountEBO accountEBO = getAccountSBO().create(
					accountId.getLogin(),
					technicalAccountEBO.getInactiveDate(),
					AccountConstants.TYPE_USER, personEBO,
					accountSBO.getAreas(technicalAccountEBO));

			accountPermSBO.addParentAccount(accountEBO, technicalAccountEBO);

			AuthAccountEBO authAccountEBO = getAuthAccountSBO().create(
					accountId.getLogin(), AuthAccountConstants.LEVEL_LOW,
					identityProvider, AuthAccountConstants.TYPE_VIRTUAL,
					accountEBO, null, null);

			if (authAccountEBO == null) {
				String msg = getMessageBuilder().build(
						LoginBOExceptionConstants.LOGIN_IS_WRONG,
						new String[] { accountId.getLogin() });
				logger.error(msg);

				throw WebFaultFactory.createLoginException(msg,null);
			}

			TokenEBO tokenEBO = getTokenSBO().create(authAccountEBO);

			return tokenEBO.getId();

		} catch (InvalidParameterBOException e) {
			throw getExceptionMapper().map(logger, e);
		} catch (InvalidPasswordBOException e) {
			LoginException exc = WebFaultFactory.createLoginException(getMessageBuilder().build(
					LoginBOExceptionConstants.LOGIN_IS_WRONG,
					new String[] { accountId.getLogin() }), e);
			logger.error(exc, e);
			throw exc;
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}

	}

	/**
	 * @return applicationSBO
	 */
	private ApplicationSBO getApplicationSBO() {
		return applicationSBO;
	}

	/**
	 * @param applicationSBO
	 *            applicationSBO � d�finir
	 */
	public void setApplicationSBO(ApplicationSBO applicationSBO) {
		this.applicationSBO = applicationSBO;
	}

	/**
	 * @return partnerSBO
	 */
	private PartnerSBO getPartnerSBO() {
		return partnerSBO;
	}

	/**
	 * @param partnerSBO
	 *            partnerSBO � d�finir
	 */
	public void setPartnerSBO(PartnerSBO partnerSBO) {
		this.partnerSBO = partnerSBO;
	}

	/**
	 * @return accountSBO
	 */
	private AccountSBO getAccountSBO() {
		return accountSBO;
	}

	/**
	 * @param accountSBO
	 *            accountSBO � d�finir
	 */
	public void setAccountSBO(AccountSBO accountSBO) {
		this.accountSBO = accountSBO;
	}

	/**
	 * @return emailAddressSBO
	 */
	private EmailAddressSBO getEmailAddressSBO() {
		return emailAddressSBO;
	}

	/**
	 * @param emailAddressSBO
	 *            emailAddressSBO � d�finir
	 */
	public void setEmailAddressSBO(EmailAddressSBO emailAddressSBO) {
		this.emailAddressSBO = emailAddressSBO;
	}

	/**
	 * @return personSBO
	 */
	public PersonSBO getPersonSBO() {
		return personSBO;
	}

	/**
	 * @param personSBO
	 *            personSBO � d�finir
	 */
	public void setPersonSBO(PersonSBO personSBO) {
		this.personSBO = personSBO;
	}

	/**
	 * @return the exceptionMapper
	 */
	private StandardExceptionMapper getExceptionMapper() {
		return this.exceptionMapper;
	}

	/**
	 * @param exceptionMapper
	 *            the exceptionMapper to set
	 */
	public void setExceptionMapper(StandardExceptionMapper exceptionMapper) {
		this.exceptionMapper = exceptionMapper;
	}

}
