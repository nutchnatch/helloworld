/*
 * Created on Sep 15, 2009
 */
package com.bnppa.sesame.services.standard;

import gencl.sesame.services.common.model.Joining;
import gencl.sesame.services.common.model.UsingRight;
import gencl.sesame.services.standard.proxy.ArrayOfTns3NillableJoining;
import gencl.sesame.services.standard.proxy.ArrayOfXsdNillableString;
import gencl.sesame.services.standard.proxy.InvalidParameterException;
import gencl.sesame.services.standard.proxy.InvalidTokenException;
import gencl.sesame.services.standard.proxy.TechnicalException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnppa.sesame.MessageDescriptionBuilder;
import com.bnppa.sesame.account.AccountEBO;
import com.bnppa.sesame.account.AccountPermSBO;
import com.bnppa.sesame.applicationdomain.ApplicationDomainEBO;
import com.bnppa.sesame.applicationdomain.ApplicationDomainSBO;
import com.bnppa.sesame.authaccount.AuthAccountEBO;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.TechnicalBOException;
import com.bnppa.sesame.joining.JoiningEBO;
import com.bnppa.sesame.perm.PermissionEBO;
import com.bnppa.sesame.perm.PermissionSBO;
import com.bnppa.sesame.profile.ProfileEBO;
import com.bnppa.sesame.profile.ProfileSBO;
import com.bnppa.sesame.right.RightEBO;
import com.bnppa.sesame.services.standard.mapper.StandardExceptionMapper;
import com.bnppa.sesame.token.TokenEBO;
import com.bnppa.sesame.token.TokenSBO;
import com.bnppa.sesame.utils.WebFaultFactory;
import org.springframework.transaction.annotation.Transactional;
import com.bnppa.sesame.utils.annot.Profiled;
import com.bnppa.sesame.utils.annot.TokenControl;
import com.bnppa.sesame.utils.annot.Token;
import com.bnppa.sesame.utils.annot.RuntimeCatcher;
import com.bnppa.sesame.utils.annot.Audit;

/**
 * @author behatemo
 * @author bellidori
 * @version Sep 15, 2009
 * @version 24/08/10
 */
public class StandardAuthorizationServicesImpl implements gencl.sesame.services.standard.proxy.AuthorizationServicesWSP {

	private static final Log			logger	= LogFactory
														.getLog(StandardAuthorizationServicesImpl.class);

	/**
	 * Exceptions messages builder
	 */
	private MessageDescriptionBuilder	messageBuilder;

	/**
	 * Exception mapper.
	 */
	private StandardExceptionMapper				exceptionMapper;

	/**
	 * session business object of token
	 */
	private TokenSBO					tokenSBO;

	/**
	 * Session business object of application
	 */
	private ApplicationDomainSBO		applicationDomainSBO;

	/**
	 * Session business object of application
	 */
	private PermissionSBO				permissionSBO;
	
	@Autowired
	private ProfileSBO profileSBO;
	
	@Autowired
	private AccountPermSBO accountPermSBO;

	/**
	 * @author behatemo
	 * @author bellidori
	 * @see com.bnppa.sesame.services.standard.AuthorizationServices#getJoinings(java.lang.String,
	 *      java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = InvalidTokenException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-authorization_std_v1-getJoinings")
	@Transactional(readOnly = true)
	public ArrayOfTns3NillableJoining getJoinings(@Token String token, String appDomainId)
			throws InvalidTokenException, InvalidParameterException,
			TechnicalException {
		try {

			if (StringUtils.isBlank(appDomainId)) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.APPLICATION_DOMAIN_IS_BLANK);
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			TokenEBO tokenEBO = getTokenSBO().find(token);
			if (tokenEBO == null) {
				String msg = getMessageBuilder().build(
						InvalidParameterBOExceptionConstants.TOKEN_NOT_EXIST,
						new String[] { token });
				logger.error(msg);
				throw WebFaultFactory.createInvalidTokenException(msg);
			}

			AuthAccountEBO authAccountEBO = getTokenSBO().getAuthAccount(
					tokenEBO);
			AccountEBO accountEBO = authAccountEBO.getAccount();

			ApplicationDomainEBO applicationEBO = getApplicationDomainSBO()
					.findById(appDomainId);
			if (applicationEBO == null) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.APPLICATION_DOMAIN_NOT_EXIST,
								new String[] { appDomainId });
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			Set joiningEBOs = new HashSet();
			
			
			
			Set accounts = new HashSet(accountEBO.getParentAccounts());
			accounts.add(accountEBO);

			// for the account and his parents
			for (Iterator iter = accounts.iterator(); iter.hasNext();) {
				AccountEBO account = (AccountEBO) iter.next();
				// get joinings of account
				joiningEBOs.addAll(accountPermSBO.getJoinings(account, applicationEBO));
				// get joinings of account's profiles
				Set accountProfiles = accountPermSBO.getProfiles(account, applicationEBO);
				for (Iterator profileIterator = accountProfiles.iterator(); profileIterator
						.hasNext();) {
					ProfileEBO profile = (ProfileEBO) profileIterator.next();
					Set profileJoinings = profileSBO.findJoiningsInEBO(profile);
					joiningEBOs.addAll(profileJoinings);

				}
				iter.remove();

			}
			accounts= null;

			Joining[] joinings = new Joining[joiningEBOs.size()];
			int i = 0;
			for (Iterator itr = joiningEBOs.iterator(); itr.hasNext();) {
				JoiningEBO joiningEBO = (JoiningEBO) itr.next();
				Joining j = new Joining();
				j.setInterv(joiningEBO.getInterv());
				j.setJoiningType(joiningEBO.getType());
				j.setSource(joiningEBO.getSource());
				j.setSubsidiary(joiningEBO.getSubsidiary());
				joinings[i++] = j;
				itr.remove();
			}
			ArrayOfTns3NillableJoining container = new ArrayOfTns3NillableJoining();
			container.setJoining(joinings);
			return container;

		} catch (InvalidParameterBOException e) {
			throw getExceptionMapper().map(logger, e);
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}
	}

	/**
	 * @author behatemo
	 * @version Sep 15, 2009
	 * @see com.bnppa.sesame.services.standard.AuthorizationServices#getPermissions(java.lang.String,
	 *      java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = InvalidTokenException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-authorization_std_v1-getPermissions")
	@Transactional(readOnly = true)
	public ArrayOfXsdNillableString getPermissions(@Token String token, String appDomainId)
			throws InvalidTokenException, InvalidParameterException,
			TechnicalException {

		try {

			if (StringUtils.isBlank(appDomainId)) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.APPLICATION_DOMAIN_IS_BLANK);
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			TokenEBO tokenEBO = getTokenSBO().find(token);
			if (tokenEBO == null) {
				String msg = getMessageBuilder().build(
						InvalidParameterBOExceptionConstants.TOKEN_NOT_EXIST,
						new String[] { token });
				logger.error(msg);
				throw WebFaultFactory.createInvalidTokenException(msg);
			}

			AuthAccountEBO authAccountEBO = getTokenSBO().getAuthAccount(
					tokenEBO);
			AccountEBO accountEBO = authAccountEBO.getAccount();

			ApplicationDomainEBO applicationEBO = getApplicationDomainSBO()
					.findById(appDomainId);
			if (applicationEBO == null) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.APPLICATION_DOMAIN_NOT_EXIST,
								new String[] { appDomainId });
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			Set permissionEBOs = accountPermSBO.getPermissions(accountEBO, applicationEBO);
			String[] permesions = new String[permissionEBOs.size()];
			int i = 0;
			for (Iterator itr = permissionEBOs.iterator(); itr.hasNext();) {
				permesions[i++] = ((PermissionEBO) itr.next()).getId();
			}

			ArrayOfXsdNillableString container = new ArrayOfXsdNillableString();
			container.setString(permesions);
			return container;

		} catch (InvalidParameterBOException e) {
			throw getExceptionMapper().map(logger, e);
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}
	}

	/**
	 * @author behatemo
	 * @version Sep 15, 2009
	 * @see com.bnppa.sesame.services.standard.AuthorizationServices#getPermissionsWithinList(java.lang.String,
	 *      java.lang.String[], java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = InvalidTokenException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-authorization_std_v1-getPermissionsWithinList")
	@Transactional(readOnly = true)
	public ArrayOfXsdNillableString getPermissionsWithinList(@Token String token,
			ArrayOfXsdNillableString permissionIds, String appDomainId)
			throws InvalidTokenException, InvalidParameterException,
			TechnicalException {
		try {

			if (permissionIds == null || permissionIds.getStringLength() == 0) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.PERMISSION_IS_BLANK);
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			if (StringUtils.isBlank(appDomainId)) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.APPLICATION_DOMAIN_IS_BLANK);
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			TokenEBO tokenEBO = getTokenSBO().find(token);
			if (tokenEBO == null) {
				String msg = getMessageBuilder().build(
						InvalidParameterBOExceptionConstants.TOKEN_NOT_EXIST,
						new String[] { token });
				logger.error(msg);
				throw WebFaultFactory.createInvalidTokenException(msg);
			}

			AuthAccountEBO authAccountEBO = getTokenSBO().getAuthAccount(
					tokenEBO);
			AccountEBO accountEBO = authAccountEBO.getAccount();

			ApplicationDomainEBO applicationEBO = getApplicationDomainSBO()
					.findById(appDomainId);
			if (applicationEBO == null) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.APPLICATION_DOMAIN_NOT_EXIST,
								new String[] { appDomainId });
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			Set permissionEBOs = accountPermSBO.getPermissions(accountEBO, applicationEBO);

			List loadedPermissionIds = new ArrayList();
			for (Iterator itr = permissionEBOs.iterator(); itr.hasNext();) {
				loadedPermissionIds.add(((PermissionEBO) itr.next()).getId());
			}

			if (loadedPermissionIds.size() == 0)
				return new ArrayOfXsdNillableString();

			loadedPermissionIds.retainAll(new ArrayList(Arrays
					.asList(permissionIds.getString())));
			
			
			String[] permissions =  (String[]) loadedPermissionIds.toArray(new String[0]);
			ArrayOfXsdNillableString container = new ArrayOfXsdNillableString();
			container.setString(permissions);
			return container;

		} catch (InvalidParameterBOException e) {
			throw getExceptionMapper().map(logger, e);
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}
	}

	/**
	 * @author behatemo
	 * @version Sep 15, 2009
	 * @see com.bnppa.sesame.services.standard.AuthorizationServices#getRoles(java.lang.String,
	 *      java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = InvalidTokenException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-authorization_std_v1-getRoles")
	@Transactional(readOnly = true)
	public ArrayOfXsdNillableString getRoles(@Token String token, String appDomainId)
			throws InvalidTokenException, InvalidParameterException,
			TechnicalException {

		try {

			if (StringUtils.isBlank(appDomainId)) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.APPLICATION_DOMAIN_IS_BLANK);
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			TokenEBO tokenEBO = getTokenSBO().find(token);
			if (tokenEBO == null) {
				String msg = getMessageBuilder().build(
						InvalidParameterBOExceptionConstants.TOKEN_NOT_EXIST,
						new String[] { token });
				logger.error(msg);
				throw WebFaultFactory.createInvalidTokenException(msg);
			}

			AuthAccountEBO authAccountEBO = getTokenSBO().getAuthAccount(
					tokenEBO);
			AccountEBO accountEBO = authAccountEBO.getAccount();

			ApplicationDomainEBO applicationEBO = getApplicationDomainSBO()
					.findById(appDomainId);
			if (applicationEBO == null) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.APPLICATION_DOMAIN_NOT_EXIST,
								new String[] { appDomainId });
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			Set profilesEBOs = accountPermSBO.getProfiles(accountEBO, applicationEBO);
			String[] profiles = new String[profilesEBOs.size()];
			int i = 0;
			for (Iterator itr = profilesEBOs.iterator(); itr.hasNext();) {
				profiles[i++] = ((ProfileEBO) itr.next()).getId();
			}
			ArrayOfXsdNillableString container = new ArrayOfXsdNillableString();
			container.setString(profiles);
			return container;

		} catch (InvalidParameterBOException e) {
			throw getExceptionMapper().map(logger, e);
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}
	}

	/**
	 * @author behatemo
	 * @version Sep 15, 2009
	 * @see com.bnppa.sesame.services.standard.AuthorizationServices#getUsingRight(java.lang.String,
	 *      java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = InvalidTokenException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-authorization_std_v1-getUsingRight")
	@Transactional(readOnly = true)
	public UsingRight getUsingRight(@Token String token, String appDomainId)
			throws InvalidTokenException, InvalidParameterException,
			TechnicalException {
		try {

			if (StringUtils.isBlank(appDomainId)) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.APPLICATION_DOMAIN_IS_BLANK);
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			TokenEBO tokenEBO = getTokenSBO().find(token);
			if (tokenEBO == null) {
				String msg = getMessageBuilder().build(
						InvalidParameterBOExceptionConstants.TOKEN_NOT_EXIST,
						new String[] { token });
				logger.error(msg);
				throw WebFaultFactory.createInvalidTokenException(msg);
			}

			AuthAccountEBO authAccountEBO = getTokenSBO().getAuthAccount(
					tokenEBO);
			AccountEBO accountEBO = authAccountEBO.getAccount();

			ApplicationDomainEBO applicationEBO = getApplicationDomainSBO()
					.findById(appDomainId);
			if (applicationEBO == null) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.APPLICATION_DOMAIN_NOT_EXIST,
								new String[] { appDomainId });
				logger.error(msg);
				throw WebFaultFactory.createInvalidParameterException(msg);
			}

			Set usingRihtsEBOs = accountPermSBO.getUserRights(accountEBO, applicationEBO);

			if (!usingRihtsEBOs.isEmpty()) {
				RightEBO userRightsEBO = (RightEBO) usingRihtsEBOs.iterator()
						.next();

				UsingRight ur = new UsingRight();
				ur.setTopGroup(userRightsEBO.isTopGroup());
				ur.setProductView(userRightsEBO.getProductView());
				ur.setContractView(userRightsEBO.getContractView());
				ur.setUserType(userRightsEBO.getUserType());
				ur.setSadr(userRightsEBO.getSadr());
				ur.setRescom(userRightsEBO.getRescom());
				
				return ur;
			}
			return null;

		} catch (InvalidParameterBOException e) {
			throw getExceptionMapper().map(logger, e);
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}
	}

	/**
	 * @author behatemo
	 * @version Sep 15, 2009
	 * @see com.bnppa.sesame.services.standard.AuthorizationServices#hasPermission(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = InvalidTokenException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-authorization_std_v1-hasPermission")
	@Transactional(readOnly = true)
	public Boolean hasPermission(@Token String token, String permissionId,
			String appDomainId) throws InvalidTokenException,
			TechnicalException {

		try {
			if (StringUtils.isBlank(appDomainId)) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.APPLICATION_DOMAIN_IS_BLANK);
				logger.error(msg);
				throw WebFaultFactory.createTechnicalException(msg);
			}

			if (StringUtils.isBlank(permissionId)) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.PERMISSION_IS_BLANK);
				logger.error(msg);
				throw WebFaultFactory.createTechnicalException(msg);
			}

			TokenEBO tokenEBO = getTokenSBO().find(token);
			if (tokenEBO == null) {
				String msg = getMessageBuilder().build(
						InvalidParameterBOExceptionConstants.TOKEN_NOT_EXIST,
						new String[] { token });
				logger.error(msg);
				throw WebFaultFactory.createInvalidTokenException(msg);
			}

			AuthAccountEBO authAccountEBO = getTokenSBO().getAuthAccount(
					tokenEBO);
			AccountEBO accountEBO = authAccountEBO.getAccount();

			ApplicationDomainEBO applicationEBO = getApplicationDomainSBO()
					.findById(appDomainId);
			if (applicationEBO == null) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.APPLICATION_DOMAIN_NOT_EXIST,
								new String[] { appDomainId });
				logger.error(msg);
				throw WebFaultFactory.createTechnicalException(msg);
			}

			PermissionEBO permissionEBO = getPermissionSBO().find(permissionId);
			if (permissionEBO == null) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.PERMISSION_NOT_EXIST,
								new String[] { permissionId });
				logger.error(msg);
				throw WebFaultFactory.createTechnicalException(msg);
			}

			return accountPermSBO.hasPermission(accountEBO, applicationEBO, permissionEBO);

		} catch (InvalidParameterBOException e) {
			// TODO A CORRIGER : IL FAUT REMONTER InvalidParameterException EN
			// UTILISANT L'ExceptionMapper!!!
			TechnicalException exc = WebFaultFactory.createTechnicalException(getMessageBuilder()
					.build(e.getMessageCode(), e.getParameters()));
			logger.error(exc, e);
			throw exc;
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}

	}

	/**
	 * @author behatemo
	 * @version Sep 15, 2009
	 * @see com.bnppa.sesame.services.standard.AuthorizationServices#hasPermissions(java.lang.String,
	 *      java.lang.String[], java.lang.String)
	 */
	@Audit(techEx = TechnicalException.class)
	@RuntimeCatcher(techEx = TechnicalException.class)
	@TokenControl(tokenEx = InvalidTokenException.class, techEx = TechnicalException.class)
	@Profiled(name = "in-soap-authorization_std_v1-hasPermissions")
	@Transactional(readOnly = true)
	public Boolean hasPermissions(@Token String token, ArrayOfXsdNillableString permissionIds,
			String appDomainId) throws InvalidTokenException,
			TechnicalException {
		try {

			if (StringUtils.isBlank(appDomainId)) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.APPLICATION_DOMAIN_IS_BLANK);
				logger.error(msg);
				throw WebFaultFactory.createTechnicalException(msg);
			}

			if (permissionIds == null || permissionIds.getStringLength() == 0) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.PERMISSION_IS_BLANK);
				logger.error(msg);
				throw WebFaultFactory.createTechnicalException(msg);
			}
			for (int i = 0; i < permissionIds.getStringLength(); i++) {
				if (StringUtils.isBlank(permissionIds.getString(i))) {
					String msg = getMessageBuilder()
							.build(
									InvalidParameterBOExceptionConstants.PERMISSION_ONE_IS_BLANK,
									new String[] { String.valueOf(i) });
					logger.error(msg);
					throw WebFaultFactory.createTechnicalException(msg);
				}
			}

			TokenEBO tokenEBO = getTokenSBO().find(token);
			if (tokenEBO == null) {
				String msg = getMessageBuilder().build(
						InvalidParameterBOExceptionConstants.TOKEN_NOT_EXIST,
						new String[] { token });
				logger.error(msg);
				throw WebFaultFactory.createInvalidTokenException(msg);
			}

			AuthAccountEBO authAccountEBO = getTokenSBO().getAuthAccount(
					tokenEBO);
			AccountEBO accountEBO = authAccountEBO.getAccount();

			ApplicationDomainEBO applicationEBO = getApplicationDomainSBO()
					.findById(appDomainId);
			if (applicationEBO == null) {
				String msg = getMessageBuilder()
						.build(
								InvalidParameterBOExceptionConstants.APPLICATION_DOMAIN_NOT_EXIST,
								new String[] { appDomainId });
				logger.error(msg);
				throw WebFaultFactory.createTechnicalException(msg);
			}

			Set permissions = getPermissionSBO().find(
					new HashSet(Arrays.asList(permissionIds.getString())));
			if (permissions != null) {
				if (permissions.size() == 0) {
					String msg = getMessageBuilder().build(
									InvalidParameterBOExceptionConstants.PERMISSIONS_NOT_EXIST,
									permissionIds.getString());
					logger.error(msg);
					throw WebFaultFactory.createTechnicalException(msg);
				}
				if (permissions.size() != permissionIds.getStringLength()) {
					return false;
				}
			}

			return accountPermSBO.hasPermissions(accountEBO, applicationEBO, permissions);

		} catch (InvalidParameterBOException e) {
			// TODO A CORRIGER : IL FAUT REMONTER InvalidParameterException EN
			// UTILISANT L'ExceptionMapper!!!
			TechnicalException exc = WebFaultFactory.createTechnicalException(getMessageBuilder()
					.build(e.getMessageCode(), e.getParameters()));
			logger.error(exc, e);
			throw exc;
		} catch (TechnicalBOException e) {
			throw getExceptionMapper().map(logger, e);
		}

	}

	/**
	 * @return Returns the tokenSBO.
	 */
	private TokenSBO getTokenSBO() {
		return tokenSBO;
	}

	/**
	 * @param tokenSBO
	 *            The tokenSBO to set.
	 */
	public void setTokenSBO(TokenSBO tokenSBO) {
		this.tokenSBO = tokenSBO;
	}

	/**
	 * @return messageBuilder
	 */
	private MessageDescriptionBuilder getMessageBuilder() {
		return messageBuilder;
	}

	/**
	 * @param messageBuilder
	 */
	public void setMessageBuilder(MessageDescriptionBuilder messageBuilder) {
		this.messageBuilder = messageBuilder;
	}

	/**
	 * @return the exceptionMapper
	 */
	private StandardExceptionMapper getExceptionMapper() {
		return this.exceptionMapper;
	}

	/**
	 * @param exceptionMapper
	 *            the exceptionMapper to set
	 */
	public void setExceptionMapper(StandardExceptionMapper exceptionMapper) {
		this.exceptionMapper = exceptionMapper;
	}

	/**
	 * @return Returns the applicationDomainSBO.
	 */
	public ApplicationDomainSBO getApplicationDomainSBO() {
		return applicationDomainSBO;
	}

	/**
	 * @param applicationDomainSBO
	 *            The applicationDomainSBO to set.
	 */
	public void setApplicationDomainSBO(
			ApplicationDomainSBO applicationDomainSBO) {
		this.applicationDomainSBO = applicationDomainSBO;
	}

	/**
	 * @return permissionSBO
	 */
	private PermissionSBO getPermissionSBO() {
		return permissionSBO;
	}

	/**
	 * @param permissionSBO
	 */
	public void setPermissionSBO(PermissionSBO permissionSBO) {
		this.permissionSBO = permissionSBO;
	}

}
