package com.bnppa.sesame.services.standard;

import com.bnppa.sesame.services.exception.FunctionalException;
import com.bnppa.sesame.services.exception.TechnicalException;
import com.bnppa.sesame.services.standard.model.Permission;

/**
 * @author karakasfa
 *
 */
public interface AuthenticationLevelServices 
{
	/**
	 * @param token
	 * @param authLevel
	 * @return
	 * @throws FunctionalException
	 * @throws TechnicalException
	 */
	boolean isAuthorizedForLevel(String token, String authLevel)
		throws FunctionalException, TechnicalException;

	/**
	 * @param token
	 * @param appDomainId
	 * @return
	 * @throws FunctionalException
	 * @throws TechnicalException
	 */
	public Permission[] getPermissionsWithAuthenticationLevel(String token, String appDomainId)
		throws FunctionalException, TechnicalException;


}
