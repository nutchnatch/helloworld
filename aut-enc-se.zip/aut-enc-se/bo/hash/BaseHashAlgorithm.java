package com.bnppa.sesame.hash;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bnppa.sesame.MessageDescriptionBuilder;
import com.bnppa.sesame.authaccount.PasswordEBO;
import com.bnppa.sesame.constants.FunctionalBOException;
import com.bnppa.sesame.constants.TechnicalBOExceptionConstants;
import com.bnppa.sesame.services.exception.FunctionalException;
import com.bnppa.sesame.services.exception.TechnicalException;
import com.bnppa.sesame.services.model.PasswordDO;

public abstract class BaseHashAlgorithm implements HashAlgorithm {

	private static final Log LOGGER	= LogFactory.getLog(BaseHashAlgorithm.class);

	protected MessageDescriptionBuilder messageBuilder;

	public void setMessageBuilder(MessageDescriptionBuilder messageBuilder) {
		this.messageBuilder = messageBuilder;
	}

	@Override
	public void checkEncryptedPassword(final String password, final PasswordEBO lastPassword) throws TechnicalException, FunctionalException {

		// Check if lastPassword exists in sesame and raise technical error if
		// don't
		if (lastPassword == null) {

			String msg = messageBuilder.build(TechnicalBOExceptionConstants.NO_PASSWORD);
			BaseHashAlgorithm.LOGGER.error(msg);
			throw new TechnicalException(msg);

		}

		// Check if the hash algorithm exists and raise technical error if don't
		final String lastAlgo = lastPassword.getAlgorithm();

		if (lastAlgo == null) {

			String msg = messageBuilder.build(TechnicalBOExceptionConstants.CODE_MISSING_HASH_ALGORITHM);
			BaseHashAlgorithm.LOGGER.error(msg);
			throw new TechnicalException(msg);

		}

		this.checkSalt(lastPassword);

		final byte[] hashedPassword = this.encryptBlandPassword(password, lastPassword.getSalt());

		// check if entered password corresponds to the last user's password in
		// sesame and raise technical error if don't
		if (!Arrays.equals(hashedPassword, lastPassword.getPassword())) {
			throw new FunctionalException(FunctionalBOException.CODE_INCORRECT_PASSWORD);
		}

	}

	@Override
	public byte[] encryptBlandPassword(final String passwordStr, final byte[] salt) throws TechnicalException {
		try {
			final byte[] password = passwordStr.getBytes(PasswordDO.CHARSET_NAME);
			final byte[] saltedPassword = salt == null ? password : BaseHashAlgorithm.concatByte(salt, password);
			return this.encryptPassword(saltedPassword);
		} catch (UnsupportedEncodingException e) {
			String msg = messageBuilder.build(TechnicalBOExceptionConstants.UNSUPPORTED_ENCODING);
			BaseHashAlgorithm.LOGGER.error(msg);
			throw new TechnicalException(msg);
		} catch (IOException e) {
			throw new TechnicalException(e.getMessage());
		}
	}

	/**
	 * concatenates both prefix and bytes
	 * @param prefix the head of the result
	 * @param bytes the tail of the result
	 * @return both prefix and bytes concatenated
	 * @throws IOException if the is a problem concatenation the bytes
	 */
	private static byte[] concatByte(final byte[] prefix, final byte[] bytes) throws IOException {
		try(final ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
			outputStream.write(prefix);
			outputStream.write(bytes);
			final byte[] ret = outputStream.toByteArray();
			return ret;
		}
	}

	@Override
	public byte[] generateSalt() throws TechnicalException {
		return null;
	}

	protected void checkSalt(final PasswordEBO password) throws TechnicalException {
	}

	protected abstract byte[] encryptPassword(final byte[] password) throws TechnicalException;
}
