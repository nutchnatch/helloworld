package com.bnppa.sesame.hash;

import java.security.SecureRandom;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bnppa.sesame.authaccount.PasswordEBO;
import com.bnppa.sesame.constants.TechnicalBOExceptionConstants;
import com.bnppa.sesame.services.exception.TechnicalException;

public abstract class SaltedHashAlgorithm extends BaseHashAlgorithm {

	private static final Log LOGGER	= LogFactory.getLog(SaltedHashAlgorithm.class);

	@Override
	protected void checkSalt(final PasswordEBO password) throws TechnicalException {
		// Check if salt exists and raise technical error if don't
		final byte[] lastSalt = password.getSalt();

		if (lastSalt == null) {
			String msg = messageBuilder.build(TechnicalBOExceptionConstants.CODE_MISSING_HASH_SALT);
			SaltedHashAlgorithm.LOGGER.error(msg);
			throw new TechnicalException(msg);
		}
	}

	@Override
	public byte[] generateSalt() throws TechnicalException {

		SecureRandom random = new SecureRandom();
		byte salt[] = new byte[64];
		random.nextBytes(salt);

		if (salt.length == 0) {

			String msg = messageBuilder.build(TechnicalBOExceptionConstants.CODE_FAIL_GENERATE_SALT);
			SaltedHashAlgorithm.LOGGER.error(msg);
			throw new TechnicalException(msg);
		}
		return salt;

	}

}
