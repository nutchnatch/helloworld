/**
 * 
 */
package com.bnppa.sesame.hash;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bnppa.sesame.constants.TechnicalBOExceptionConstants;
import com.bnppa.sesame.services.exception.TechnicalException;

/**
 * @author a12970
 *
 */
public abstract class MessageDigestHashAlgorithm extends SaltedHashAlgorithm {

	private static final Log logger = LogFactory.getLog(MessageDigestHashAlgorithm.class);

	protected byte[] encryptPassword(final byte[] password, final String hashMethod) throws TechnicalException {
		try {
			MessageDigest md = MessageDigest.getInstance(hashMethod);
			md.update(password);
			return md.digest();
		} catch (NoSuchAlgorithmException e) {

			String msg = messageBuilder.build(TechnicalBOExceptionConstants.CODE_MISSING_HASH_ALGORITHM);
			logger.error(msg);
			throw new TechnicalException(msg);
		}
	}
}
