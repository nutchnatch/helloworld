package com.bnppa.sesame.hash;

import java.io.UnsupportedEncodingException;

public class HashManager {

	public HashManager() {
		super();
	}

	public static String revertByte(byte[] byteToRevert) {
		String revert = "";

		try {
			revert = new String(byteToRevert, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return revert;
	}

}
