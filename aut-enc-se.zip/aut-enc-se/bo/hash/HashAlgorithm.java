/**
 * 
 */
package com.bnppa.sesame.hash;

import com.bnppa.sesame.MessageDescriptionBuilder;
import com.bnppa.sesame.authaccount.PasswordEBO;
import com.bnppa.sesame.services.exception.FunctionalException;
import com.bnppa.sesame.services.exception.TechnicalException;

/**
 * @author a12970
 *
 */
public interface HashAlgorithm {

	/**
	 * Checks if password matches the data in lastPassword
	 * @param password the password to check
	 * @param lastPassword the password data to check against
	 * @throws TechnicalException fi something bad happens
	 * @throws FunctionalException if password does not match lastPassword
	 */
	public void checkEncryptedPassword(String password, PasswordEBO lastPassword) throws TechnicalException, FunctionalException;

	public byte[] generateSalt() throws TechnicalException;

	/**
	 * Salts password and then encrypts it
	 * @param password the bland password
	 * @param salt the salt
	 * @return the slated and encrypted password
	 * @throws TechnicalException if something goes wrong
	 */
	public byte[] encryptBlandPassword(final String passwordStr, final byte[] salt) throws TechnicalException;
	
	/**
	 * 
	 * @param messageBuilder
	 */
	public void setMessageBuilder(MessageDescriptionBuilder messageBuilder);
}
