/**
 * 
 */
package com.bnppa.sesame.hash;

import java.security.MessageDigest;

import org.bouncycastle.jcajce.provider.digest.SHA3.DigestSHA3;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnppa.sesame.services.exception.TechnicalException;

/**
 * @author a12970
 *
 */
public class Sha3HashAlgorithm extends SaltedHashAlgorithm {

	private static final int DEFAULT_SHA3_SIZE = 256;

	@Override
	protected byte[] encryptPassword(final byte[] password) throws TechnicalException {
		MessageDigest md = new DigestSHA3(DEFAULT_SHA3_SIZE);
		md.update(password);
		return md.digest();
	}

}
