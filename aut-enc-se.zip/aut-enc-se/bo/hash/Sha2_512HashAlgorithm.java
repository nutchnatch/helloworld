package com.bnppa.sesame.hash;

import com.bnppa.sesame.services.exception.TechnicalException;
import com.bnppa.sesame.services.model.HashAlgorithmEnum;

public class Sha2_512HashAlgorithm extends MessageDigestHashAlgorithm {

	@Override
	protected byte[] encryptPassword(byte[] password) throws TechnicalException {
		return encryptPassword(password, HashAlgorithmEnum.SHA2_512.algorithmName);
	}

}
