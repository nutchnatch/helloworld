package com.bnppa.sesame.hash;

import java.lang.reflect.Method;
import java.util.EnumMap;
import java.util.Map;

import javax.naming.NamingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AbstractFactoryBean;

import com.bnppa.sesame.MessageDescriptionBuilder;
import com.bnppa.sesame.PasswordDAOFacade;
import com.bnppa.sesame.services.model.HashAlgorithmEnum;
import com.bnppa.sesame.utils.SesameJndiFacade;

public class HashAlgorithmStrategyFactory extends AbstractFactoryBean<HashAlgorithm>{

	private final static String HASH_ENCRYPTION_JNDI = "java:comp/env/sesameEncryption";
	
	private static Map<HashAlgorithmEnum, String> BY_ALGORITHM;

	@Autowired
	private PasswordDAOFacade passwordDAOFacade;
	
	@Autowired
	protected MessageDescriptionBuilder messageBuilder;
	
	public static String getHashEncryption() {
		
		try {
			return (String) SesameJndiFacade.getObject(HASH_ENCRYPTION_JNDI, String.class);
		} catch (NamingException e) {
			throw new RuntimeException("sesameEncryption not defined", e);
		}
	}
	
	public HashAlgorithmStrategyFactory() {
		super();
		HashAlgorithmStrategyFactory.BY_ALGORITHM = new EnumMap<HashAlgorithmEnum, String>(HashAlgorithmEnum.class);
		HashAlgorithmStrategyFactory.BY_ALGORITHM.put(HashAlgorithmEnum.DES, "com.bnppa.sesame.hash.DesHashAlgorithm");
		HashAlgorithmStrategyFactory.BY_ALGORITHM.put(HashAlgorithmEnum.SHA2_256, "com.bnppa.sesame.hash.Sha2_256HashAlgorithm");
		HashAlgorithmStrategyFactory.BY_ALGORITHM.put(HashAlgorithmEnum.SHA2_512, "com.bnppa.sesame.hash.Sha2_512HashAlgorithm");
		HashAlgorithmStrategyFactory.BY_ALGORITHM.put(HashAlgorithmEnum.SHA3, "com.bnppa.sesame.hash.Sha3HashAlgorithm");
		
	}

	public HashAlgorithm getEncryptionAlgorithm(final String hashEncryption) {
		
		String classHashName = HashAlgorithmStrategyFactory.BY_ALGORITHM.get(HashAlgorithmEnum.fromJndiName(hashEncryption));
		
		HashAlgorithm hashAlgorithm;
		try {
			Class<?> classHash = Thread.currentThread().getContextClassLoader().loadClass(classHashName);
			hashAlgorithm = (HashAlgorithm) classHash.newInstance();
		} catch (Exception e) {
			throw new RuntimeException("Impossible to instanciate HashAlgorithm class.",e);
		}
		hashAlgorithm.setMessageBuilder(messageBuilder);
		if (hashAlgorithm.getClass().getName().equals("com.bnppa.sesame.hash.DesHashAlgorithm")){
			Class<?> desClass;
			try {
				desClass = Thread.currentThread().getContextClassLoader().loadClass("com.bnppa.sesame.hash.DesHashAlgorithm");
				Method methodSet = desClass.getDeclaredMethod("setPasswordDAOFacade", PasswordDAOFacade.class);
				methodSet.invoke(hashAlgorithm, passwordDAOFacade);
			} catch (Exception e) {
				throw new RuntimeException("Impossible to init the DesHashAlgorithm :",e);
			}
		}
		
		return hashAlgorithm;
	}
	
	@Override
	protected HashAlgorithm createInstance() throws Exception {
		return getEncryptionAlgorithm(getHashEncryption());
	}

	@Override
	public Class<?> getObjectType() {
		return HashAlgorithm.class;
	}

}
