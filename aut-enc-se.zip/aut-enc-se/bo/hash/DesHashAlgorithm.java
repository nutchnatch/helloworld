/**
 * 
 */
package com.bnppa.sesame.hash;

import com.bnppa.sesame.PasswordDAOFacade;
import com.bnppa.sesame.services.exception.TechnicalException;

/**
 * @author a12970
 *
 */
public class DesHashAlgorithm extends BaseHashAlgorithm {

	private PasswordDAOFacade passwordDAOFacade;
	
	public void setPasswordDAOFacade(PasswordDAOFacade passwordDAOFacade) {
		this.passwordDAOFacade = passwordDAOFacade;
	}

	public DesHashAlgorithm() {
	}

	@Override
	public byte[] encryptBlandPassword(final String passwordStr, final byte[] salt) throws TechnicalException {
		if (passwordStr == null) {
			return null;
		}
		return passwordDAOFacade.crypterClef(passwordStr);
	}
	
	@Override
	protected byte[] encryptPassword(final byte[] password) throws TechnicalException {
		throw new UnsupportedOperationException();
	}

}
