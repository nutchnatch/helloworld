/*
 * Created on 31 ao�t 09
 *
 */
package com.bnppa.sesame.authaccount;

import com.bnppa.sesame.constants.AccountConstants;
import com.bnppa.sesame.constants.AuthAccountConstants;
import com.bnppa.sesame.utils.AppContext;

/**
 * @author bellidori
 * @version 31 ao�t 09
 * 
 */
public class AuthFactory {
	
	/**
	 * @param syst
	 *            system which manage authentification. it must be equals to
	 *            <code>AuthAccountConstants.SYST_SESAME</code> or,
	 *            <code> AuthAccountConstants.SYST_REFOG</code>
	 * @return SESAuthStrategy if syst is equals to
	 *         <code>AuthAccountConstants.SYST_SESAME</code> REFOGAuthStrategy
	 *         if syst is equals to
	 *         <code> AuthAccountConstants.SYST_REFOG</code>
	 */
	protected static AuthStrategy create(String syst, String idAccountType) {

		if(AccountConstants.TYPE_FEDERATION.equals(idAccountType)) {
			return (AuthStrategy) AppContext.getApplicationContext().getBean("_TECHAuthStrategy");
		}
		
		if (AuthAccountConstants.SYST_SESAME.equals(syst)) {
			return (AuthStrategy) AppContext.getApplicationContext().getBean("_SESAuthStrategy");
		}
		if (AuthAccountConstants.SYST_REFOG.equals(syst)) {
			return (AuthStrategy) AppContext.getApplicationContext().getBean("_REFOGAuthStrategy");
		}

		return null;
	}
}
