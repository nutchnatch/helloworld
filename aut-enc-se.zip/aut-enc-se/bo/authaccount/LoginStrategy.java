/**
 * 
 */
package com.bnppa.sesame.authaccount;

import com.bnppa.sesame.exceptions.InvalidParameterBOException;

/**
 * @author bellidori
 */
public interface LoginStrategy {
	/**
	 * @param accountId
	 *            account's identifier
	 * @return account's login
	 * @throws InvalidParameterBOException
	 *             if accountId is invalid
	 */
	public String createLogin(String accountId)
			throws InvalidParameterBOException;

	/**
	 * @param login
	 *            account's login
	 * @param accountId
	 *            old account's identifier
	 * @return account's identifier
	 * @throws InvalidParameterBOException
	 */
	public String createAccountId(String login, String accountId)
			throws InvalidParameterBOException;

}
