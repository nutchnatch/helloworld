/*
 * Created on Aug 12, 2009
 */
package com.bnppa.sesame.authaccount;

import java.util.Calendar;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.InvalidPasswordBOException;
import com.bnppa.sesame.exceptions.TechnicalBOException;

/**
 * @author polancoro
 * @version Aug 12, 2009
 */
public interface PasswordSBO {

	/**
	 * Search and returns the passwords of owner. </br> If there are no
	 * passwords an empty <SortedSet> is returned.
	 * 
	 * @param owner
	 *            account entity business object
	 * @return SortedSet <PasswordEBO>
	 * @throws TechnicalBOException
	 */
	public List<PasswordEBO> find(AuthAccountEBO owner) throws TechnicalBOException;

	/**
	 * Search and returns last password of owner.
	 * 
	 * @param owner
	 *            account entity business object
	 * @return last password of owner or null if owner has no password
	 */
	public PasswordEBO findLast(AuthAccountEBO owner);

	/**
	 * Find password by login and update number
	 * 
	 * @param login
	 * @param updateNumber
	 * @return {@link PasswordEBO}
	 * @author behatemo
	 * @version 17/02/2010
	 */
	public PasswordEBO find(String login, Integer updateNumber);

	/**
	 * create a password entity business object and save it in datasource
	 * 
	 * @param owner
	 *            password's owner
	 * @param updator
	 *            password's updator
	 * @param password
	 *            new password
	 * @return PasswordEBO password entity business object
	 * @throws InvalidParameterBOException
	 *             if password is not build correctly
	 * @throws InvalidPasswordBOException
	 *             if password is not valid
	 * @throws TechnicalBOException
	 */
	public PasswordEBO create(AuthAccountEBO owner, String password,
			AuthAccountEBO updator) throws InvalidParameterBOException,
			InvalidPasswordBOException, TechnicalBOException;
	
	/**
	 * create a password entity business object with reset option on and 
	 * save it in datasource
	 * 
	 * @param owner
	 *            password's owner
	 * @param updator
	 *            password's updator
	 * @param password
	 *            new password
	 * @return PasswordEBO password entity business object
	 * @throws InvalidParameterBOException
	 *             if password is not build correctly
	 * @throws InvalidPasswordBOException
	 *             if password is not valid
	 * @throws TechnicalBOException
	 */
	public PasswordEBO createWithReset(AuthAccountEBO owner, String password,
			AuthAccountEBO updator) throws InvalidParameterBOException,
			InvalidPasswordBOException, TechnicalBOException;

	/**
	 * generate the new password according to the security rules, create a
	 * password entity business object and save it in datasource
	 * 
	 * @param owner
	 *            password's owner
	 * @param updator
	 *            password's updator
	 * @return PasswordEBO password entity business object
	 * @throws InvalidParameterBOException
	 *             if password is not build correctly
	 * @throws TechnicalBOException
	 *             if password is not valid, or database cannot be acceeded
	 */
	public String create(AuthAccountEBO owner, AuthAccountEBO updator)
			throws InvalidParameterBOException, TechnicalBOException;

	/**
	 * Update the password
	 * 
	 * @param authAccountEbo authorization account containing the password to update
	 * @return true if the password has been updated and false otherwise.
	 * @throws DataAccessException if error occurs
	 * @throws NullPointerException if password is null.
	 */
	public boolean update(final AuthAccountEBO authAccountEbo)
			throws DataAccessException, NullPointerException;

	/**
	 * Set the expery date associated with the last password of the accountEBO
	 * @author FVE
	 * @param authAccount account to update.
	 * @param updator account of the updator.
	 * @param expiryDate expiry date to fix in the database.
	 */
	public void updateLastPasswordExpiryDate(AuthAccountEBO authAccount, AuthAccountEBO updator, Calendar expiryDate);
	
	/**
	 * Get the account who update the password
	 * @param passwordEBO
	 * @return
	 */
	public AuthAccountEBO getUpdator(PasswordEBO passwordEBO);
	
	public String getStatus(PasswordEBO passwordEBO, AuthAccountEBO owner);
}
