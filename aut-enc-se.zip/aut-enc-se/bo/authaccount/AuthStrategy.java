/*
 * Created on Aug 6, 2009
 */
package com.bnppa.sesame.authaccount;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Map;

import com.bnppa.sesame.channelmessageformat.ChannelMessageFormatEBO;
import com.bnppa.sesame.exceptions.ExpiredPasswordBOException;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.InvalidPasswordBOException;
import com.bnppa.sesame.exceptions.LockedAccountBOException;
import com.bnppa.sesame.exceptions.LoginBOException;
import com.bnppa.sesame.exceptions.TechnicalBOException;

/**
 * @author polancoro
 * @version Aug 6, 2009
 */
public interface AuthStrategy extends Serializable {

	/**
	 * @param typedPassword
	 *            password typed by user
	 * @param authAccount
	 * @throws TechnicalBOException
	 * @throws LoginBOException
	 * @throws InvalidParameterBOException
	 * @throws LockedAccountBOException
	 * @throws ExpiredPasswordBOException
	 */
	public void doLogin(String typedPassword, AuthAccountEBO authAccount)
			throws TechnicalBOException, LoginBOException,
			InvalidParameterBOException, LockedAccountBOException,
			ExpiredPasswordBOException;

	/**
	 * @param authAccount
	 * @throws TechnicalBOException
	 * @throws LoginBOException
	 * @throws InvalidParameterBOException
	 * @throws LockedAccountBOException
	 * @throws ExpiredPasswordBOException
	 */
	public void doLogin(AuthAccountEBO authAccount)
			throws TechnicalBOException, LoginBOException,
			InvalidParameterBOException, LockedAccountBOException,
			ExpiredPasswordBOException;

	/**
	 * @param authAccount
	 * @param bypassRefog whether or not to bypass refog
	 * @throws TechnicalBOException
	 * @throws LoginBOException
	 * @throws InvalidParameterBOException
	 * @throws LockedAccountBOException
	 * @throws ExpiredPasswordBOException
	 */
	public void doLogin(AuthAccountEBO authAccount, final boolean bypassRefog)
			throws TechnicalBOException, LoginBOException,
			InvalidParameterBOException, LockedAccountBOException,
			ExpiredPasswordBOException;
	
	/**
	 * Change the auth account password
	 * 
	 * @param authAccountEBO
	 * @param oldPassword
	 * @param newPassword
	 * @throws LoginBOException
	 * @throws LockedAccountBOException
	 * @throws InvalidPasswordBOException
	 * @throws TechnicalBOException
	 */
	public void doChangePassword(AuthAccountEBO authAccountEBO,
			String oldPassword, String newPassword) throws LoginBOException,
			LockedAccountBOException, InvalidPasswordBOException,
			TechnicalBOException;

	/**
	 * create a new password by generating the password
	 * 
	 * @param authAccount
	 *            authAccount updated
	 * @param updator
	 *            administrator who creates the password
	 * @throws TechnicalBOException
	 *             if password generated is invalid
	 * @throws InvalidParameterBOException
	 */
	public String doSetPassword(AuthAccountEBO authAccount, AuthAccountEBO updator)
			throws InvalidParameterBOException, TechnicalBOException;

	/**
	 * create a new password by using the password
	 * 
	 * @param authAccount
	 *            authAccount updated
	 * @param updator
	 *            administrator who creates the password
	 * @param password
	 *            Password
	 * @throws InvalidPasswordBOException
	 *             if password is invalid
	 * @throws TechnicalBOException
	 *             if database cannot be acceeded
	 * @throws InvalidParameterBOException
	 */
	public void doSetPassword(AuthAccountEBO authAccount,
			AuthAccountEBO updator, String password)
			throws InvalidPasswordBOException, InvalidParameterBOException,
			TechnicalBOException;

	/**
	 * Reset and send the password to user
	 * 
	 * @param owner
	 * @param updator
	 * @param channelMessageFormatEBO
	 * @param parameters
	 * @param sendingDate
	 * @throws TechnicalBOException
	 *             if send failt or password cannot be generated or database
	 *             cannot be acceeded
	 * @throws InvalidParameterBOException
	 */
	public void doResetAndSendPassword(AuthAccountEBO owner,
			AuthAccountEBO updator,
			ChannelMessageFormatEBO channelMessageFormatEBO, Map<String, String> parameters,
			Calendar sendingDate) throws InvalidParameterBOException,
			TechnicalBOException;

	/**
	 * Set the expery date associated with the last password of the accountEBO
	 * @author FVE
	 * @param authAccount
	 * @param updator
	 * @param expiryDate
	 */
	public void doSetPwdExperyDate(AuthAccountEBO authAccount, AuthAccountEBO updator, Calendar expiryDate);

	/**
	 * Do the reset of the password.
	 * @author vendefx
	 * @param accountEBO the EBO account
	 * @param updator the updator of the password
	 * @return 
	 */
	public String doResetPassword(AuthAccountEBO owner, AuthAccountEBO updator) throws InvalidParameterBOException, TechnicalBOException;
	
}
