package com.bnppa.sesame.authaccount;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.ref.SoftReference;
import java.net.URL;
import java.security.GeneralSecurityException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;

import javax.annotation.PostConstruct;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

import com.bnppa.sesame.AccountStatusCriteriaTO;
import com.bnppa.sesame.AccountStatusTO;
import com.bnppa.sesame.AuthAccountDAOFacade;
import com.bnppa.sesame.AuthAccountIdTO;
import com.bnppa.sesame.AuthAccountTO;
import com.bnppa.sesame.CriteriaAccountSearchTO;
import com.bnppa.sesame.EmailAddressIdTO;
import com.bnppa.sesame.MailingOrderDAOFacade;
import com.bnppa.sesame.MailingOrderTO;
import com.bnppa.sesame.PersonEmailAddressDAOFacade;
import com.bnppa.sesame.PersonIdTO;
import com.bnppa.sesame.REFOGAccountDAOFacade;
import com.bnppa.sesame.SecretResponseDAOFacade;
import com.bnppa.sesame.SecretResponseTO;
import com.bnppa.sesame.account.AccountEBO;
import com.bnppa.sesame.account.AccountPermSBO;
import com.bnppa.sesame.account.AccountSBO;
import com.bnppa.sesame.account.AccountStatusEBO;
import com.bnppa.sesame.application.ApplicationSBO;
import com.bnppa.sesame.cache.SesameLockedCache;
import com.bnppa.sesame.channelmessageformat.ChannelMessageFormatEBO;
import com.bnppa.sesame.constants.AccountConstants;
import com.bnppa.sesame.constants.AuthAccountConstants;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.constants.MailingOrderConstants;
import com.bnppa.sesame.constants.PasswordConstants;
import com.bnppa.sesame.constants.SearchPatternConstants;
import com.bnppa.sesame.constants.TechnicalBOExceptionConstants;
import com.bnppa.sesame.constants.UnAuthorizedActionBOExceptionConstants;
import com.bnppa.sesame.emailaddr.EmailAddressEBO;
import com.bnppa.sesame.emailaddr.EmailAddressSBO;
import com.bnppa.sesame.exceptions.BadPasswordBOException;
import com.bnppa.sesame.exceptions.ExpiredPasswordBOException;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.InvalidPasswordBOException;
import com.bnppa.sesame.exceptions.LockedAccountBOException;
import com.bnppa.sesame.exceptions.LoginBOException;
import com.bnppa.sesame.exceptions.TechnicalBOException;
import com.bnppa.sesame.exceptions.UnAuthorizedActionBOException;
import com.bnppa.sesame.ldap.LDAPAttributesKeys;
import com.bnppa.sesame.mapper.Mapper;
import com.bnppa.sesame.messagecomposition.ComposeMessageSBO;
import com.bnppa.sesame.messagecomposition.MessageCharacteristicEBO;
import com.bnppa.sesame.messagecomposition.SPOCData;
import com.bnppa.sesame.messagepublication.MCODocumentCompositionAndMailingEBO;
import com.bnppa.sesame.messagepublication.SMTPMessageEBO;
import com.bnppa.sesame.messagepublication.SendMessageSBO;
import com.bnppa.sesame.person.PersonEBO;
import com.bnppa.sesame.person.PersonSBO;
import com.bnppa.sesame.secretquestion.SecretQuestionEBO;
import com.bnppa.sesame.secretquestion.SecretQuestionSBO;
import com.bnppa.sesame.services.model.HashAlgorithmEnum;
import com.bnppa.sesame.uaa.UserAdminAreaEBO;
import com.bnppa.sesame.utils.AuthenticationValidator;
import com.bnppa.sesame.utils.PropertyLoader;
import com.bnppa.sesame.utils.crypto.SymmetricCryptoManager;

/**
 * @author rochinaen
 * @author bellidori
 * @version Aug 6, 2009
 * @version 15/07/10 : update findAttributes, call dao only if authType equals
 *          to GROUP
 * @version 06/08/10 : add addSecretResponse, removeSecretResponse
 * @version 24/08/10
 */
public class AuthAccountSBOImpl implements AuthAccountSBO {

	private static final Log logger = LogFactory.getLog(AuthAccountSBOImpl.class);

	private static final String WARN_MSG_ACCOUNT_TYPE_NULL = "default search executed, criteria.accountType : null ";

	/**
	 * Group and tiers DAO facade
	 */
	private AuthAccountDAOFacade authAccountDAOFacade;

	/**
	 * Customer DAO facade
	 */
	private AuthAccountDAOFacade customerAuthAccountDAOFacade;

	/**
	 * Group LDAP facade
	 */
	private REFOGAccountDAOFacade refogAccountDAOFacade;

	/**
	 * 
	 */
	private SecretResponseDAOFacade secretResponseDAOFacade;

	/**
	 * Mailing order DAO facade
	 */
	private MailingOrderDAOFacade mailingOrderDAOFacade;

	/**
	 * auth account mapper
	 */
	private Mapper<AuthAccountTO, AuthAccountEBO> mapper;

	/**
	 * session business object of account
	 */
	private AccountSBO accountSBO;
	
	@Autowired
	private AccountPermSBO accountPermSBO;

	@Autowired
	private EmailAddressSBO emailAddressSBO;

	/**
	 * session business object of person
	 */
	private PersonSBO personSBO;

	/**
	 * Attribute strategy factory
	 */
	private AttributeStrategyFactory attributeStrategyFactory;

	/**
	 * session business object of SecretQuestion
	 */
	private SecretQuestionSBO secretQuestionSBO;
	
	@Autowired
	private PasswordSBO passwordSBO;

	/**
	 * Symmetric Crypto Manager
	 */
	private SymmetricCryptoManager symmetricCryptoManager;

	/**
	 * session business object PersonEmailAdress
	 */
	private PersonEmailAddressDAOFacade personEmailAddressDAOFacade;

	private static SimpleDateFormat dateFormater = new SimpleDateFormat(
			"dd/MM/yy", Locale.FRENCH); //$NON-NLS-1$

	/**
	 * Application business object.
	 */
	private ApplicationSBO applicationSBO;
	
	/**
	 * Compose Message business object.
	 */
	private ComposeMessageSBO composeMessageSBO;
	
	/**
	 * Send Message business object.
	 */
	private SendMessageSBO sendMessageSBO;
	
	/**
	 * Sesame Locked Cache
	 */
	private SesameLockedCache	lockedCache;

	//TODO sieuma Clean the code as soon as possible <=> switch MAIL / ICE
	
	private boolean usedIce;
	private String mailHost;
	private String mailSender;
	private String defaultPreferredLanguage;
	
	private static final String FAIL_MAIL_PROPERTY_LOAD = "Fail to load mail.properties - ";
	private static final String FAIL_MAIL_HOST_PROPERTY_LOAD = "Fail to load the smtp host in mail.properties";
	private static final String FAIL_MAIL_SENDER_PROPERTY_LOAD = "Fail to load the mail sender in mail.properties";
	private static final String MAIL_PROPERTIES_FILE_NAME = "properties/mail.properties";
	private static final String USED_ICE_NAME = "usedIce";
	private static final String MAIL_SMTP_HOST_NAME = "mail.smtp.host";
	private static final String MAIL_SPOC_SENDER_NAME = "mail.spoc.sender";
	private static final String DEFAULT_PREFERRED_LANGUAGE = "default.preferred.language";
	
	public AuthAccountSBOImpl() {
	}
	
	@PostConstruct
	public void init() {
		try {
			Properties mailProperties = PropertyLoader.loadProperties(MAIL_PROPERTIES_FILE_NAME);
			String usedIceStr = mailProperties.getProperty(USED_ICE_NAME);
			usedIce = Boolean.valueOf(usedIceStr).booleanValue();
			defaultPreferredLanguage = mailProperties.getProperty(DEFAULT_PREFERRED_LANGUAGE);
			if (!usedIce) {
				mailHost = mailProperties.getProperty(MAIL_SMTP_HOST_NAME);
				if (StringUtils.isEmpty(mailHost)) {
					throw new RuntimeException(FAIL_MAIL_HOST_PROPERTY_LOAD);
				}
				mailSender = mailProperties.getProperty(MAIL_SPOC_SENDER_NAME);
				if (StringUtils.isEmpty(mailSender)) {
					throw new RuntimeException(FAIL_MAIL_SENDER_PROPERTY_LOAD);
				}
			}
		} catch (FileNotFoundException e) {
			throw new RuntimeException(FAIL_MAIL_PROPERTY_LOAD + e.getMessage());
		} catch (IOException e) {
			throw new RuntimeException(FAIL_MAIL_PROPERTY_LOAD + e.getMessage());
		}
	}
	
	//TODO sieuma End of clean

	/**
	 * @return session business object of person
	 */
	public PersonSBO getPersonSBO() {
		return personSBO;
	}

	/**
	 * @param personSBO
	 *            set session business object of person
	 */
	public void setPersonSBO(PersonSBO personSBO) {
		this.personSBO = personSBO;
	}

	/**
	 * @return session business object of account
	 */
	public AccountSBO getAccountSBO() {
		return accountSBO;
	}

	/**
	 * @param accountSBO
	 *            session business object to set
	 */
	public void setAccountSBO(AccountSBO accountSBO) {
		this.accountSBO = accountSBO;
	}

	/**
	 * @return Returns the attributestrategyFactory.
	 */
	private AttributeStrategyFactory getAttributeStrategyFactory() {
		return attributeStrategyFactory;
	}

	/**
	 * @param attributeStrategyFactory
	 *            The attributestrategyFactory to set.
	 */
	public void setAttributeStrategyFactory(
			AttributeStrategyFactory attributeStrategyFactory) {
		this.attributeStrategyFactory = attributeStrategyFactory;
	}

	/**
	 * @author polancoro
	 * @version Aug 14, 2009
	 * @throws InvalidParameterBOException
	 * @throws InvalidPasswordBOException
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#create(java.lang.String,
	 *      java.lang.Integer, java.lang.String, java.lang.String,
	 *      com.bnppa.sesame.account.AccountEBO,
	 *      com.bnppa.sesame.authaccount.AuthAccountEBO, String)
	 */
	public AuthAccountEBO create(String login, Integer authLevel,
			String authSyst, String authType, AccountEBO account,
			AuthAccountEBO connectedAuthAccount, String clientType)
			throws InvalidParameterBOException, TechnicalBOException,
			InvalidPasswordBOException {

		if (StringUtils.isBlank(authSyst)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTH_SYSTEM_IS_BLANK,
					logger);
		}

		// if (!AuthenticationValidator.isAuthenticationSystemValid(authSyst))
		// throw new InvalidParameterBOException(
		// InvalidParameterBOExceptionConstants.AUTH_SYSTEM_IS_INVALID,
		// new String[] { authSyst }, logger);
		AuthAccountEBO authAccountEBO = AuthAccountEBOFactory.create(authLevel,
				login, authSyst, authType, account);

		if (AuthAccountConstants.TYPE_VIRTUAL.equals(authType)) {
			return authAccountEBO;
		}
		else if (AuthAccountConstants.TYPE_CLIENT.equals(authType) && !StringUtils.isBlank(clientType)) {
			((CustomerAuthAccountEBO)authAccountEBO).setCustomerType(clientType);
		}

		getAuthAccountDAOFacade(authType).create(map(authAccountEBO));

		this.createPwd(authAccountEBO, connectedAuthAccount);
		
		// Create and attach email to user email
		Set<EmailAddressEBO> emailAddresses = personSBO.findEmailAddresses(authAccountEBO.getAccount().getPerson());
		Set<EmailAddressIdTO> emailAddressId = new HashSet<>();
		for(final EmailAddressEBO emailAddressEBO : emailAddresses) {
			if (emailAddressEBO.getAddress() != null) {
				emailAddressId.add(new EmailAddressIdTO(emailAddressEBO
						.getAddress().getAddress()));
			}
		}
		getPersonEmailAddressDAOFacade().create(
				new PersonIdTO(authAccountEBO.getLogin()), emailAddressId);

		return authAccountEBO;
	}

	/**
	 * @author polancoro
	 * @version Sep 1, 2009
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#update(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	public void update(String authAccountId, String authType, String authSystem)
			throws InvalidParameterBOException, TechnicalBOException {

		if (StringUtils.isBlank(authType)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTH_TYPE_IS_BLANK,
					new String[] { authType }, logger);
		}

		AuthAccountEBO authAccountEBO = find(authAccountId, authSystem,
				authType);
		if (authAccountEBO == null) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_NOT_EXIST,
					new String[] { authAccountId }, logger);
		}

		getAuthAccountDAOFacade(authAccountEBO.getAuthType()).update(
				new AuthAccountIdTO(authAccountEBO.getLogin(), authAccountEBO
						.getAuthType()), map(authAccountEBO));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#update(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      java.util.Calendar)
	 */
	public void update(AuthAccountEBO connectedAuthAccount,
			String authAccountId, String authType, String uid, String comments,
			Calendar expiryDate, Calendar inactiveDate) {
		if (StringUtils.isBlank(authType)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTH_TYPE_IS_BLANK,
					new String[] { authType }, logger);
		}

		String authSystem = AuthenticationValidator.getAuthSystem(authType);

		AuthAccountEBO authAccountEBO = find(authAccountId, authSystem,
				authType);
		if (authAccountEBO == null) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_NOT_EXIST,
					new String[] { authAccountId }, logger);
		}

		// We don't save the Person in this method.
		authAccountEBO.getAccount().setPerson(null);

		// Update the expiry date.
		if (expiryDate != null) {
			this.updatePwdExperyDate(authAccountEBO, connectedAuthAccount, expiryDate);
		}

		// Update the comments and the uid.

		AccountEBO account = authAccountEBO.getAccount();
		account.setUid(uid);
		account.setComments(comments);
		account.setUpdatorId(connectedAuthAccount.getAccount().getId());
		account.setInactiveDate(inactiveDate);

		getAuthAccountDAOFacade(authAccountEBO.getAuthType()).update(
				new AuthAccountIdTO(authAccountEBO.getLogin(), authAccountEBO
						.getAuthType()), map(authAccountEBO));
	}

	/**
	 * @author behatemo
	 * @version Oct 7, 2009
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#updateLogin(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      java.lang.String)
	 */
	public void updateLogin(AuthAccountEBO authAccountEBO, String newLogin) {
		getAuthAccountDAOFacade(authAccountEBO.getAuthType()).updateLogin(
				new AuthAccountIdTO(authAccountEBO.getLogin(), authAccountEBO
						.getAuthType()), newLogin);
	}

	/**
	 * @author behatemo
	 * @version Oct 8, 2009
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#updateAttemptsNumber(com.bnppa.sesame.authaccount.AuthAccountEBO)
	 */
	public void updateAttemptsNumber(AuthAccountEBO authAccountEBO) {

		getAuthAccountDAOFacade(authAccountEBO.getAuthType())
				.updateAttemptsNumber(
						new AuthAccountIdTO(authAccountEBO.getLogin(),
								authAccountEBO.getAuthType()),
						authAccountEBO.getAttemptsNumber());

	}

	/**
	 * @author behatemo
	 * @version Oct 8, 2009
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#updateLastConnexion(com.bnppa.sesame.authaccount.AuthAccountEBO)
	 */
	public void updateLastConnexion(AuthAccountEBO authAccountEBO) {

		getAuthAccountDAOFacade(authAccountEBO.getAuthType())
				.updateLastConnexion(
						new AuthAccountIdTO(authAccountEBO.getLogin(),
								authAccountEBO.getAuthType()),
						authAccountEBO.getLastConnexion());

	}

	/**
	 * @author behatemo
	 * @author bellidori
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#delete(com.bnppa.sesame.authaccount.AuthAccountEBO)
	 */
	public boolean delete(AuthAccountEBO authAccountEBO) {

		return getAuthAccountDAOFacade(authAccountEBO.getAuthType()).delete(
				new AuthAccountIdTO(authAccountEBO.getAccount().getId(),
						authAccountEBO.getAuthType()));

	}

	/**
	 * {@inheritDoc}
	 */
	public AuthAccountEBO find(Integer authLevel, String login,
			String authSystem, String authType)
			throws InvalidParameterBOException {

		return this.find(authLevel, login, authSystem, authType, false);

	}

	/**
	 * {@inheritDoc}
	 */
	public AuthAccountEBO find(Integer authLevel, String login,
			String authSystem, String authType, final boolean bypassRefog)
			throws InvalidParameterBOException {

		if (!AuthenticationValidator.isAuthenticationLevelValid(authLevel)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTH_LEVEL_IS_INVALID,
					new String[] { authLevel.toString() }, logger);
		}

		// Parameters control
		if (StringUtils.isBlank(login)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.LOGIN_IS_BLANK,
					new String[] { login }, logger);
		}

		if (!AuthenticationValidator.isAuthenticationTypeValid(authType)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTH_TYPE_IS_INVALID,
					new String[] { authType }, logger);
		}
		if (!AuthenticationValidator.isAuthenticationSystemValid(authSystem)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTH_SYSTEM_IS_INVALID,
					new String[] { authSystem }, logger);
		}

		if (AuthAccountConstants.TYPE_CLIENT.equals(authType)) {
			AuthAccountTO authAccountTO = customerAuthAccountDAOFacade
					.find(new AuthAccountIdTO(login, authType));
			return map(authAccountTO);

		}
		if (AuthAccountConstants.TYPE_TIERS.equals(authType)) {
			AuthAccountTO authAccountTO = authAccountDAOFacade
					.find(new AuthAccountIdTO(login, authType));
			return map(authAccountTO);
		}
		if (AuthAccountConstants.TYPE_GROUP.equals(authType)) {
			return findGroupAuthAccount(login, bypassRefog);
		}
		return null;

	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public AuthAccountEBO find(String login, String authSystem, String authType)
			throws InvalidParameterBOException {

		return this.find(AuthAccountConstants.LEVEL_LOW, login, authSystem, authType, false);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public AuthAccountEBO find(String login, String authSystem, String authType, boolean bypassRefog)
			throws InvalidParameterBOException {

		return find(AuthAccountConstants.LEVEL_LOW, login, authSystem, authType, bypassRefog);
	}
	
	/**
	 * @author pbo
	 * @version 24 ao�t 2011
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#find(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	public AuthAccountEBO findInRefogFromAuth(String login)
			throws InvalidParameterBOException {

		// Parameters control
		if (StringUtils.isBlank(login)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.LOGIN_IS_BLANK,
					new String[] { login }, logger);
		}

		return findGroupAuthAccount(login, true);
	}

	/**
	 * @author rochinaen
	 * @author bellidori
	 * @version Aug 6, 2009
	 * @throws InvalidParameterBOException
	 *             If no account is found with this login If problems with
	 *             database occured
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#find(java.lang.String)
	 */
	public AuthAccountEBO find(String login) throws InvalidParameterBOException {

		AuthAccountEBO authAccountEBO = null;
		authAccountEBO = find(login, AuthAccountConstants.SYST_SESAME,
				AuthAccountConstants.TYPE_CLIENT);

		if (authAccountEBO == null) {
			authAccountEBO = find(login, AuthAccountConstants.SYST_SESAME,
					AuthAccountConstants.TYPE_TIERS);
			if (authAccountEBO == null) {
				authAccountEBO = find(login, AuthAccountConstants.SYST_SESAME,
						AuthAccountConstants.TYPE_GROUP);
			}
		}

		return authAccountEBO;
	}

	/**
	 * 
	 */
	public int countByCriteriaSearch(Set logins, Set area) {

		return customerAuthAccountDAOFacade.countByCriteriaSearch(logins, area);

	}

	public int countExistentAcountByLoginsList(Set logins) {

		return customerAuthAccountDAOFacade
				.countExistentAcountByLoginsList(logins);

	}

	/**
	 * @param login
	 * @return authAccountTO
	 */
	private AuthAccountEBO findGroupAuthAccount(String login, boolean isFromAuth) {

		// search auth account is ldap
		Map attributes = null;

		// FiX PBO : When the RDI service is down this method must not return
		// null
		// because it blocks another process

		// account does not exist in ldap
		if (!isFromAuth) {
			attributes = refogAccountDAOFacade.findAttributes(login);
			if (attributes == null || attributes.isEmpty()) {
				if (attributes == null) {
					attributes = new HashMap();
				}
				if (attributes.isEmpty()) {
					attributes.put(LDAPAttributesKeys.UID, login);
				}

				Map usersAuthInfos = refogAccountDAOFacade
						.getUsersAuthInfos(login);
				attributes.putAll(usersAuthInfos);
			}
		} else {
			if (attributes == null) {
				attributes = new HashMap();
			}
			if (attributes.isEmpty()) {
				attributes.put(LDAPAttributesKeys.UID, login);
			}
		}

		// FiX PBO

		// search authorization in sesame db
		AuthAccountEBO authAccount = null;
		if(login.startsWith(LDAPAttributesKeys.L_PREFIX)) {
			AccountEBO accountEBO = accountSBO.find(login);
			authAccount = new AuthAccountEBO(
					AuthAccountConstants.LEVEL_LOW, login,
					AuthAccountConstants.SYST_REFOG,
					AuthAccountConstants.TYPE_GROUP, accountEBO);
			authAccount.setAttributes(attributes);
		} else {
			// account id is prefix by l_uid in sesame db
			AccountEBO accountEBO = null;

			//TODO prefix login to determine accountId to search

			String idToSearch = new StringBuffer(LDAPAttributesKeys.UID_PREFIX).append(login).toString();

			accountEBO = accountSBO.find(idToSearch);

			PersonEBO person = this.personSBO.create((String) attributes
					.get(LDAPAttributesKeys.UID));

			String firstName = (String) attributes
			.get(LDAPAttributesKeys.GIVEN_NAME);
			String lastName = (String) attributes.get(LDAPAttributesKeys.SN);

			if (!StringUtils.isBlank(lastName)) {
				person.setLastName(lastName);
			}

			if (!StringUtils.isBlank(firstName)) {
				person.setFirstName(firstName);
			}

			boolean existInDb = true;

			if (accountEBO == null) {
				// account does not exist in sesame db => built it dynamically !
				existInDb = false;
				accountEBO = accountSBO.create(idToSearch, null,
						AccountConstants.TYPE_USER, person, new HashSet());

			}

			accountEBO.setIdAccountType(AccountConstants.TYPE_USER);
			accountEBO.setPerson(person);
			authAccount = new AuthAccountEBO(
					AuthAccountConstants.LEVEL_LOW, login,
					AuthAccountConstants.SYST_REFOG,
					AuthAccountConstants.TYPE_GROUP, accountEBO);
			authAccount.setAttributes(attributes);

			if (!existInDb) {
				authAccount.setExistInDataStore(false);
			}

			// find if l_uo has a account
			String uOUserLDAP = (String) attributes.get(LDAPAttributesKeys.CODE_UO);
			if (!StringUtils.isBlank(uOUserLDAP)) {
				idToSearch = new StringBuffer(LDAPAttributesKeys.UO_PREFIX).append(
						uOUserLDAP).toString();

				accountPermSBO.addParentAccount(accountEBO, accountSBO.find(idToSearch));

			}
			String ISOCUserLDAP = (String) attributes
			.get(LDAPAttributesKeys.NOM_UO_LOC_UO_RATTACH);
			String GPEUserLDAP = (String) attributes
			.get(LDAPAttributesKeys.CODE_POSTE_TYPE);

			// get GPE concatenated to ISOC user LDAP attribute value

			if (!(StringUtils.isBlank(ISOCUserLDAP) || StringUtils
					.isBlank(GPEUserLDAP))) {

				idToSearch = new StringBuffer("l_").append(GPEUserLDAP).append("_") //$NON-NLS-1$//$NON-NLS-2$
				.append(ISOCUserLDAP).toString();
				accountPermSBO.addParentAccount(accountEBO, accountSBO.find(idToSearch));
			}

			if (!StringUtils.isBlank(ISOCUserLDAP)) {
				idToSearch = new StringBuffer(LDAPAttributesKeys.ISOC_PREFIX)
				.append(ISOCUserLDAP).toString();
				accountPermSBO.addParentAccount(accountEBO, accountSBO.find(idToSearch));
			}

			if (!StringUtils.isBlank(GPEUserLDAP)) {

				idToSearch = new StringBuffer(LDAPAttributesKeys.GPE_PREFIX)
				.append(GPEUserLDAP).toString();
				accountPermSBO.addParentAccount(accountEBO, accountSBO.find(idToSearch));
			}
		}
		return authAccount;

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Map<String,String> findAttributes(AuthAccountEBO authAccount) {

		return this.findAttributes(authAccount, false);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Map<String,String> findAttributes(AuthAccountEBO authAccount, final boolean bypassRefog) {

		if (AuthAccountConstants.TYPE_GROUP.equals(authAccount.getAuthType())) {
			if(!bypassRefog) {
				return this.refogAccountDAOFacade.findAttributes(authAccount.getLogin());
			}
		}
		return new HashMap<String,String>();
	}
	
	/**
	 * @param authTypePattern
	 * @param accountStatusPattern
	 * @param passwordStatusPattern
	 * @param startDate
	 * @param endDate
	 * @pre startDate is null
	 * @pre endDate is null
	 * @pre authTypePattern is null or equals to TIERS or CLIENT
	 * @pre passwordStatusPattern is null or is equals to
	 *      <code>SearchPatternConstants.ANY</code> or
	 *      <code>PasswordConstants.EXPIRED</code> or
	 *      <code>PasswordConstants.ADMIN_RESET</code> or
	 *      <code>PasswordConstants.ACTIVE</code>
	 * @throws InvalidParameterBOException
	 *             if startDate != null, <br>
	 *             if endDate != null, <br>
	 *             if authTypePattern equals to GROUP, <br>
	 *             if passwordStatusPattern is not blank and is not equals to
	 *             one of these values :<code>SearchPatternConstants.ANY</code>,<code>PasswordConstants.EXPIRED</code>,
	 *             <code>PasswordConstants.ADMIN_RESET</code>,
	 *             <code>PasswordConstants.ACTIVE</code>)
	 */
	private void checkParamsForFindByStatus(String authTypePattern,
			String accountStatusPattern, String passwordStatusPattern,
			Calendar startDate, Calendar endDate)
			throws InvalidParameterBOException {
		if (startDate != null) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.START_DATE_UNSUPPORTED,
					new Object[] { dateFormater.format(startDate.getTime()) },
					logger);
		}

		if (endDate != null) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.END_DATE_UNSUPPORTED,
					new Object[] { dateFormater.format(endDate.getTime()) },
					logger);
		}

		checkParamsForFindByStatus(authTypePattern, accountStatusPattern);

		// Validating accountTypePattern, GROUP is not supported
		if (StringUtils.isNotBlank(authTypePattern)
				&& (!"*".equals(authTypePattern) //$NON-NLS-1$
						&& !AuthAccountConstants.TYPE_TIERS
								.equals(authTypePattern) && !AuthAccountConstants.TYPE_CLIENT
						.equals(authTypePattern))) {

			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTHTYPE_PATTERN_UNSUPPORTED,
					new Object[] { authTypePattern,
							AuthAccountConstants.TYPE_TIERS,
							AuthAccountConstants.TYPE_CLIENT }, logger);
		}

		// Validating passwordStatusPattern
		if (StringUtils.isNotBlank(passwordStatusPattern)
				&& (!SearchPatternConstants.ANY.equals(passwordStatusPattern))
				&& !PasswordConstants.EXPIRED.equals(passwordStatusPattern)
				&& !PasswordConstants.ADMIN_RESET.equals(passwordStatusPattern)
				&& !PasswordConstants.ACTIVE.equals(passwordStatusPattern)) {

			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.PASSWORD_STATUS_PATTERN_UNSUPPORTED,
					new Object[] { passwordStatusPattern,
							PasswordConstants.ACTIVE,
							PasswordConstants.EXPIRED,
							PasswordConstants.ADMIN_RESET }, logger);
		}
	}

	/**
	 * @param authTypePattern
	 * @param accountStatusPattern
	 * @param passwordStatusPattern
	 * @param startDate
	 * @param endDate
	 */
	private void checkParamsForFindByStatus(String authTypePattern,
			String accountStatusPattern) {
		if (StringUtils.isBlank(authTypePattern)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTHTYPE_PATTERN_IS_BLANK,
					logger);
		}

		// Validating accountStatusPattern
		if (StringUtils.isNotBlank(accountStatusPattern)
				&& (!SearchPatternConstants.ANY.equals(accountStatusPattern))
				&& !AccountConstants.ENABLED.equals(accountStatusPattern)
				&& !AccountConstants.DISABLED.equals(accountStatusPattern)
				&& !AccountConstants.LOCKED.equals(accountStatusPattern)) {

			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.ACCOUNT_STATUS_PATTERN_UNSUPPORTED,
					new Object[] { accountStatusPattern,
							AccountConstants.ENABLED,
							AccountConstants.DISABLED, AccountConstants.LOCKED },
					logger);
		}
	}

	/**
	 * @author behatemo
	 * @author bellidori
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#find(String, String,
	 *      String, String, Calendar, Calendar, int, int, Set, Calendar)
	 */
	@Override
	public Set<AuthAccountEBO> find(String loginPattern, String authTypePattern,
			String accountStatusPattern, String passwordStatusPattern,
			Calendar startDate, Calendar endDate, int offset, int pageSize,
			Set<UserAdminAreaEBO> areaEBOs, Calendar currentDate) {

		// Parameters controls
		if (offset < 0) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.OFFSET_IS_NEGATIVE,
					new Object[] { new Integer(offset) }, logger);
		}

		if (pageSize <= 0
				|| pageSize > AccountConstants.MAX_ACCOUNT_STATUS_PAGESIZE) {

			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.PAGESIZE_OUTOF_RANGE,
					new Object[] {
							new Integer(pageSize),
							new Integer(
									AccountConstants.MAX_ACCOUNT_STATUS_PAGESIZE) },
					logger);
		}

		checkParamsForFindByStatus(authTypePattern, accountStatusPattern,
				passwordStatusPattern, startDate, endDate);

		Set<String> areaIds = new HashSet<>(areaEBOs.size());
		for(UserAdminAreaEBO ebo : areaEBOs) {
			areaIds.add(ebo.getLabel());
		}
		AccountStatusCriteriaTO accountStatusCriteriaTO = new AccountStatusCriteriaTO(
				new AuthAccountIdTO(loginPattern, authTypePattern),
				accountStatusPattern, passwordStatusPattern, startDate,
				endDate, offset, pageSize, areaIds, currentDate,
				PasswordConstants.MAX_ATTEMPS_NUMBER);
		Set<AuthAccountTO> authAccountTOs = new HashSet<>();
		if ("*".equals(authTypePattern)) { //$NON-NLS-1$

			authAccountTOs = getAuthAccountDAOFacade(
					AuthAccountConstants.TYPE_TIERS).find(
					accountStatusCriteriaTO);

		} else {
			authAccountTOs = getAuthAccountDAOFacade(authTypePattern).find(
					accountStatusCriteriaTO);
		}

		return this.mapper.mapTOtoEBOSet(authAccountTOs);
	}

	/**
	 * @author behatemo
	 * @author bellidori
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#find(String, String,
	 *      String, String, Calendar, Calendar, int, int, Set, Calendar)
	 */
	@Override
	public Set<AccountStatusEBO> findAccountStatus(String loginPattern, String authTypePattern,
			String accountStatusPattern, String passwordStatusPattern,
			Calendar startDate, Calendar endDate, int offset, int pageSize,
			Set areaIds, Calendar currentDate) {

		// Parameters controls
		if (offset < 0) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.OFFSET_IS_NEGATIVE,
					new Object[] { new Integer(offset) }, logger);

		}
		if (pageSize <= 0
				|| pageSize > AccountConstants.MAX_ACCOUNT_STATUS_PAGESIZE) {

			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.PAGESIZE_OUTOF_RANGE,
					new Object[] {
							new Integer(pageSize),
							new Integer(
									AccountConstants.MAX_ACCOUNT_STATUS_PAGESIZE) },
					logger);
		}

		checkParamsForFindByStatus(authTypePattern, accountStatusPattern,
				passwordStatusPattern, startDate, endDate);

		AccountStatusCriteriaTO accountStatusCriteriaTO = new AccountStatusCriteriaTO(
				new AuthAccountIdTO(loginPattern, authTypePattern),
				accountStatusPattern, passwordStatusPattern, startDate,
				endDate, offset, pageSize, areaIds, currentDate,
				PasswordConstants.MAX_ATTEMPS_NUMBER);
		Set<AccountStatusTO> accountStatusTOs = getAuthAccountDAOFacade(
				AuthAccountConstants.TYPE_TIERS).findBis(
				accountStatusCriteriaTO);

		Set<AccountStatusEBO> accountStatusEBOs = new HashSet<>();
		for(final AccountStatusTO a : accountStatusTOs) {
			accountStatusEBOs.add(new AccountStatusEBO(a.getLogin(), a
					.getAuthType(), a.getInactiveDate(), a.getStatus(), a
					.getAttemptsNumber()));
		}

		return accountStatusEBOs;
	}

	/**
	 * @author gilletmc
	 * @author bellidori
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#find(String, String,
	 *      int, int, Set, Calendar)
	 */
	@Override
	public Set<AuthAccountEBO> find(String authTypePattern, String accountStatusPattern,
			int offset, int pageSize, Set<UserAdminAreaEBO> areaEBOs, Calendar currentDate) {

		// Parameters controls
		if (offset < 0) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.OFFSET_IS_NEGATIVE,
					new Object[] { new Integer(offset) }, logger);
		}

		if (pageSize <= 0
				|| pageSize > AccountConstants.MAX_ACCOUNT_STATUS_PAGESIZE) {

			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.PAGESIZE_OUTOF_RANGE,
					new Object[] {
							new Integer(pageSize),
							new Integer(
									AccountConstants.MAX_ACCOUNT_STATUS_PAGESIZE) },
					logger);
		}

		checkParamsForFindByStatus(authTypePattern, accountStatusPattern);

		Set<String> areaIds = new HashSet<>(areaEBOs.size());
		for(final UserAdminAreaEBO ebo : areaEBOs) {
			areaIds.add(ebo.getLabel());
		}
		AccountStatusCriteriaTO accountStatusCriteriaTO = new AccountStatusCriteriaTO(
				new AuthAccountIdTO(null, authTypePattern),
				accountStatusPattern, null, null, null, offset, pageSize,
				areaIds, currentDate, PasswordConstants.MAX_ATTEMPS_NUMBER);
		Set<AuthAccountTO> authAccountTOs = getAuthAccountDAOFacade().find(
				accountStatusCriteriaTO);

		return this.mapper.mapTOtoEBOSet(authAccountTOs);
	}

	/**
	 * @author behatemo
	 * @author bellidori
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#count(String, String,
	 *      String, String, Calendar, Calendar, Set, Calendar)
	 */
	public Long count(String loginPattern, String authTypePattern,
			String accountStatusPattern, String passwordStatusPattern,
			Calendar startDate, Calendar endDate, Set areaIds,
			Calendar currentDate) {

		checkParamsForFindByStatus(authTypePattern, accountStatusPattern,
				passwordStatusPattern, startDate, endDate);

		Long result = new Long(0);
		AccountStatusCriteriaTO accountStatusCriteriaTO = new AccountStatusCriteriaTO(
				new AuthAccountIdTO(loginPattern, authTypePattern),
				accountStatusPattern, passwordStatusPattern, startDate,
				endDate, areaIds, currentDate,
				PasswordConstants.MAX_ATTEMPS_NUMBER);
		if ("*".equals(authTypePattern)) { //$NON-NLS-1$
			long res = getAuthAccountDAOFacade(AuthAccountConstants.TYPE_TIERS)
					.count(accountStatusCriteriaTO).longValue();

			res += getAuthAccountDAOFacade(AuthAccountConstants.TYPE_CLIENT)
					.count(accountStatusCriteriaTO).longValue();

			result = new Long(res);
		} else {
			result = getAuthAccountDAOFacade(authTypePattern).count(
					accountStatusCriteriaTO);
		}

		return result;
	}

	/**
	 * @throws TechnicalBOException
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#updateSecretResponse(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      com.bnppa.sesame.secretquestion.SecretQuestionEBO, java.lang.String)
	 */
	public boolean updateSecretResponse(AuthAccountEBO authAccount,
			SecretQuestionEBO secretQuestion, String response)
			throws TechnicalBOException {

		try {
			if (authAccount == null) {
				throw new InvalidParameterBOException(
						InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_IS_NULL,
						logger);
			}
			if (secretQuestion == null) {
				throw new InvalidParameterBOException(
						InvalidParameterBOExceptionConstants.SECRET_QUESTION_IS_NULL,
						logger);

			}
			if (StringUtils.isBlank(response)) {
				throw new InvalidParameterBOException(
						InvalidParameterBOExceptionConstants.SECRET_RESPONSES_EMPTY,
						logger);
			}

			// check if response already exists
			String previousResponse = this.findSecretResponse(authAccount,
					secretQuestion);
			if (previousResponse == null) {
				throw new InvalidParameterBOException(
						InvalidParameterBOExceptionConstants.SECRET_RESPONSES_NOT_EXISTS,
						new Object[] { secretQuestion, authAccount }, logger);
			}

			Map secretResponses = authAccount.getSecretQuestions();

			if (secretResponses == null) {
				secretResponses = new HashMap();
			}

			String encryptResponse = getSymmetricCryptoManager().encrypt(
					response);
			secretResponses.put(secretQuestion, response);
			authAccount.setSecretQuestions(secretResponses);

			// check if response is not the same
			if (response.equals(previousResponse)) {
				return false;
			}
			// update response
			SecretResponseTO secretResponseTO = new SecretResponseTO(
					secretQuestion.getLabel(), authAccount.getLogin(),
					encryptResponse);
			this.getSecretResponseDAOFacade().update(secretResponseTO);

			return true;
		} catch (GeneralSecurityException e) {
			throw new TechnicalBOException(
					TechnicalBOExceptionConstants.FAILED_TO_ENCRYPT_OR_DECRYPT,
					new String[] { response }, e, logger);
		}
	}

	/**
	 * @author rochinaen
	 * @version Nov 25, 2009
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#countByCriteriaSearch(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      java.lang.String, java.util.Set)
	 */
	public int countByCriteriaSearch(String accountType, String login,
			String lastName, String firstName, String permissionId,
			String roleId, String statusKey, String functionalAreaId,
			Set areaIds, String idAccountType, String preferredLanguage)
			throws InvalidParameterBOException {

		if (StringUtils.isBlank(accountType)) {
			accountType = AuthAccountConstants.TYPE_TIERS;
			if (logger.isWarnEnabled()) {
				logger.warn(WARN_MSG_ACCOUNT_TYPE_NULL);
			}
		}

		CriteriaAccountSearchTO criteriaAccountSearchTO = new CriteriaAccountSearchTO(
				accountType, login, lastName, firstName, permissionId, roleId,
				statusKey, functionalAreaId, idAccountType, preferredLanguage);

		int resultat = authAccountDAOFacade.countByCriteriaSearch(
				criteriaAccountSearchTO, areaIds);
		if (resultat == -1) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.ACCOUNT_TYPE_IS_INVALID,
					logger);
		}
		return resultat;

	}

	/**
	 * @author bellidori
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#findByCriteriaSearch(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      java.lang.String, int, int, java.util.Set)
	 */
	@Override
	public List<AuthAccountEBO> findByCriteriaSearch(String accountType, String login,
			String lastName, String firstName, String permissionId,
			String roleId, String statusKey, String functionalAreaId,
			int offSet, int pageSize, Set<UserAdminAreaEBO> areas, String idAccountType,
			String preferredLanguage, List sortingCriteriaList, String sortOrder)
			throws InvalidParameterBOException {

		CriteriaAccountSearchTO criteriaAccountSearchTO = new CriteriaAccountSearchTO(
				accountType, login, lastName, firstName, permissionId, roleId,
				statusKey, functionalAreaId, idAccountType, preferredLanguage);

		Set<String> labelAreasSet = new HashSet<>();
		if (areas != null) {
			for(final UserAdminAreaEBO areaEBO : areas) {
				labelAreasSet.add(areaEBO.getLabel());
			}
		}
		Collection<AuthAccountTO> resultat = authAccountDAOFacade
				.findUserIdentityFromCriteria(criteriaAccountSearchTO, offSet,
						pageSize, labelAreasSet, sortingCriteriaList, sortOrder);

		return this.mapper.mapTOtoEBOList(resultat);

	}

	/**
	 * @author behatemo
	 * @version Mar 23, 2010
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#addAttribute(AuthAccountEBO,
	 *      String, String, AccountEBO)
	 */
	public void addAttribute(AuthAccountEBO authAccountEBO, String key,
			String value, AccountEBO updatorAccountEBO) {
		AttributeStrategy attributeStrategy = getAttributeStrategyFactory()
				.create(authAccountEBO.getAuthType());

		authAccountEBO.getAccount().setUpdatorId(updatorAccountEBO.getId());
		attributeStrategy.doAddAttribute(authAccountEBO, key, value,
				updatorAccountEBO);
	}

	/**
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#addAttribute(AuthAccountEBO,
	 *      String, String, AccountEBO, boolean)
	 */
	public void addAttribute(AuthAccountEBO authAccountEBO, String key,
			String value, AccountEBO updatorAccountEBO, boolean isAdvanced) {
		if (isAdvanced) {
			AttributeStrategy attributeStrategy = getAttributeStrategyFactory()
					.create(authAccountEBO.getAuthType());

			authAccountEBO.getAccount().setUpdatorId(updatorAccountEBO.getId());
			attributeStrategy.doAddAttribute(authAccountEBO, key, value,
					updatorAccountEBO, isAdvanced);
		} else {
			addAttribute(authAccountEBO, key, value, updatorAccountEBO);
		}
	}

	/**
	 * Map an AuthAccount EBO to AuthAccount TO
	 * 
	 * @param authAccountTO
	 * @return AuthAccountEBO
	 */
	private AuthAccountEBO map(AuthAccountTO authAccountTO) {
		return (AuthAccountEBO) getMapper().mapTOtoEBO(authAccountTO);

	}

	/**
	 * Map an AuthAccount TO to AuthAccount EBO
	 * 
	 * @param authAccountEBO
	 * @return authAccountTO
	 */
	private AuthAccountTO map(AuthAccountEBO authAccountEBO) {
		return (AuthAccountTO) getMapper().mapEBOtoTO(authAccountEBO);
	}

	/**
	 * @return Returns the authAccountDAOFacade.
	 */
	public AuthAccountDAOFacade getAuthAccountDAOFacade() {
		return authAccountDAOFacade;
	}

	/**
	 * @param authAccountDAOFacade
	 *            The authAccountDAOFacade to set.
	 */
	public void setAuthAccountDAOFacade(
			AuthAccountDAOFacade authAccountDAOFacade) {
		this.authAccountDAOFacade = authAccountDAOFacade;
	}

	/**
	 * @return Returns the authAccountDAOFacade.
	 */
	public AuthAccountDAOFacade getCustomerAuthAccountDAOFacade() {
		return customerAuthAccountDAOFacade;
	}

	/**
	 * @param customerAuthAccountDAOFacade
	 *            The authAccountDAOFacade to set.
	 */
	public void setCustomerAuthAccountDAOFacade(
			AuthAccountDAOFacade customerAuthAccountDAOFacade) {
		this.customerAuthAccountDAOFacade = customerAuthAccountDAOFacade;
	}

	/**
	 * @return refogAccountDAOFacade
	 */
	public REFOGAccountDAOFacade getRefogAccountDAOFacade() {
		return refogAccountDAOFacade;
	}

	/**
	 * @param accountDAOFacade
	 */
	public void setRefogAccountDAOFacade(REFOGAccountDAOFacade accountDAOFacade) {
		refogAccountDAOFacade = accountDAOFacade;
	}

	private AuthAccountDAOFacade getAuthAccountDAOFacade(String accountType) {
		if (AuthAccountConstants.TYPE_CLIENT.equals(accountType)) {
			return this.getCustomerAuthAccountDAOFacade();
		} else if (AuthAccountConstants.TYPE_GROUP.equals(accountType)
				|| AuthAccountConstants.TYPE_TIERS.equals(accountType)) {
			return this.getAuthAccountDAOFacade();
		} else {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.ACCOUNT_TYPE_IS_INVALID,
					new Object[] { accountType }, logger);
		}
	}

	/**
	 * @return mapper
	 */
	public Mapper<AuthAccountTO, AuthAccountEBO> getMapper() {
		return mapper;
	}

	/**
	 * @param mapper
	 */
	public void setMapper(Mapper<AuthAccountTO, AuthAccountEBO> mapper) {
		this.mapper = mapper;
	}

	/**
	 * @return secretResponseDAOFacade
	 */
	private SecretResponseDAOFacade getSecretResponseDAOFacade() {
		return secretResponseDAOFacade;
	}

	/**
	 * @param secretResponseDAOFacade
	 */
	public void setSecretResponseDAOFacade(
			SecretResponseDAOFacade secretResponseDAOFacade) {
		this.secretResponseDAOFacade = secretResponseDAOFacade;
	}

	/**
	 * @throws TechnicalBOException
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#addSecretResponse(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      com.bnppa.sesame.secretquestion.SecretQuestionEBO, java.lang.String)
	 */
	public void addSecretResponse(AuthAccountEBO authAccount,
			SecretQuestionEBO secretQuestion, String response)
			throws DataAccessException, InvalidParameterBOException,
			TechnicalBOException {
		try {
			if (authAccount == null) {
				throw new InvalidParameterBOException(
						InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_IS_NULL,
						logger);
			}
			if (secretQuestion == null) {
				throw new InvalidParameterBOException(
						InvalidParameterBOExceptionConstants.SECRET_QUESTION_IS_NULL,
						logger);

			}
			if (StringUtils.isBlank(response)) {
				throw new InvalidParameterBOException(
						InvalidParameterBOExceptionConstants.SECRET_RESPONSES_EMPTY,
						logger);
			}

			if (this.findSecretResponse(authAccount, secretQuestion) != null) {
				throw new InvalidParameterBOException(
						InvalidParameterBOExceptionConstants.SECRET_RESPONSES_ALREADY_EXISTS,
						new Object[] { secretQuestion, authAccount }, logger);
			}

			String encryptResponse = getSymmetricCryptoManager().encrypt(
					response);
			SecretResponseTO secretResponseTO = new SecretResponseTO(
					secretQuestion.getLabel(), authAccount.getLogin(),
					encryptResponse);

			this.getSecretResponseDAOFacade().create(secretResponseTO);

			Map secretResponses = authAccount.getSecretQuestions();

			if (secretResponses == null) {
				secretResponses = new HashMap();
				authAccount.setSecretQuestionsInitialized(false);
			}
			secretResponses.put(secretQuestion, response);
			authAccount.setSecretQuestions(secretResponses);
		} catch (GeneralSecurityException e) {
			throw new TechnicalBOException(
					TechnicalBOExceptionConstants.FAILED_TO_ENCRYPT_OR_DECRYPT,
					new String[] { response }, e, logger);
		}

	}

	/**
	 * @throws TechnicalBOException
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#removeSecretResponse(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      com.bnppa.sesame.secretquestion.SecretQuestionEBO )
	 */
	public void removeSecretResponse(AuthAccountEBO authAccount,
			SecretQuestionEBO secretQuestion) throws DataAccessException,
			InvalidParameterBOException, TechnicalBOException {

		if (authAccount == null) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_IS_NULL,
					logger);
		}
		if (secretQuestion == null) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.SECRET_QUESTION_IS_NULL,
					logger);

		}

		if (this.findSecretResponse(authAccount, secretQuestion) == null) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.SECRET_RESPONSES_NOT_EXISTS,
					new Object[] { secretQuestion, authAccount }, logger);
		}
		// delete response
		AuthAccountIdTO authAccountIdTO = new AuthAccountIdTO(authAccount
				.getLogin(), authAccount.getAuthType());
		this.getSecretResponseDAOFacade().delete(authAccountIdTO,
				secretQuestion.getLabel());

		Map secretResponses = authAccount.getSecretQuestions();

		if (secretResponses != null) {
			secretResponses.remove(secretQuestion);
			authAccount.setSecretQuestions(secretResponses);
		}

	}

	/**
	 * @throws TechnicalBOException
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#findSecretResponse(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      com.bnppa.sesame.secretquestion.SecretQuestionEBO)
	 */
	public String findSecretResponse(AuthAccountEBO authAccount,
			SecretQuestionEBO secretQuestion) throws DataAccessException,
			InvalidParameterBOException, TechnicalBOException {

		if (authAccount == null) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_IS_NULL,
					logger);
		}
		if (secretQuestion == null) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.SECRET_QUESTION_IS_NULL,
					logger);

		}
		Map responses = authAccount.getSecretQuestions();

		if (responses == null) {
			// no responses saved on ebo => search in db
			SecretResponseTO response = this.getSecretResponseDAOFacade().find(
					authAccount.getLogin(), secretQuestion.getLabel());

			if (response == null) {
				return null;
			}

			try {
				String decryptResponse = getSymmetricCryptoManager().decrypt(
						response.getResponse());
				// save response on ebo
				responses = new HashMap();
				responses.put(secretQuestion, decryptResponse);
				authAccount.setSecretQuestions(responses);

				return decryptResponse;
			} catch (GeneralSecurityException e) {
				throw new TechnicalBOException(
						TechnicalBOExceptionConstants.FAILED_TO_ENCRYPT_OR_DECRYPT,
						new String[] { response.getResponse() }, e, logger);
			}

		}
		// response saved on ebo ?
		if (responses.containsKey(secretQuestion)) {
			return (String) responses.get(secretQuestion);
		}
		// all responses saved on ebo ?
		if (!authAccount.isSecretQuestionsInitialized()) {
			SecretResponseTO response = this.getSecretResponseDAOFacade().find(
					authAccount.getLogin(), secretQuestion.getLabel());

			if (response == null) {
				return null;
			}

			try {
				String decryptResponse = getSymmetricCryptoManager().decrypt(
						response.getResponse());
				// save response on ebo
				responses.put(secretQuestion, decryptResponse);
				authAccount.setSecretQuestions(responses);

				return decryptResponse;
			} catch (GeneralSecurityException e) {
				throw new TechnicalBOException(
						TechnicalBOExceptionConstants.FAILED_TO_ENCRYPT_OR_DECRYPT,
						new String[] { response.getResponse() }, e, logger);
			}
		}
		// no response for this question
		return null;
	}

	/**
	 * @author gilletmc
	 * @author bellidori
	 * @throws TechnicalBOException
	 * @throws TechnicalBOException
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#findSecretResponses(com.bnppa.sesame.authaccount.AuthAccountEBO)
	 */
	public Map findSecretResponses(AuthAccountEBO authAccount)
			throws DataAccessException, InvalidParameterBOException,
			TechnicalBOException {
		if (authAccount == null) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_IS_NULL,
					logger);
		}

		if (authAccount.getSecretQuestions() == null) {
			AuthAccountIdTO authAccountIdTO = new AuthAccountIdTO(authAccount
					.getLogin(), authAccount.getAuthType());
			Set secretResponses = getSecretResponseDAOFacade().find(
					authAccountIdTO);
			authAccount.setSecretQuestions(new HashMap());
			for (Iterator iter = secretResponses.iterator(); iter.hasNext();) {
				SecretResponseTO secretResponseTO = (SecretResponseTO) iter
						.next();
				SecretQuestionEBO secretQuestionEBO = getSecretQuestionSBO()
						.find(secretResponseTO.getQuestionId());

				try {
					String response = getSymmetricCryptoManager().decrypt(
							secretResponseTO.getResponse());

					authAccount.getSecretQuestions().put(secretQuestionEBO,
							response);
				} catch (GeneralSecurityException e) {
					throw new TechnicalBOException(
							TechnicalBOExceptionConstants.FAILED_TO_ENCRYPT_OR_DECRYPT,
							new String[] { secretResponseTO.getResponse() }, e,
							logger);
				}
				iter.remove();
			}
			authAccount.setSecretQuestionsInitialized(true);
		}
		return authAccount.getSecretQuestions();

	}

	/**
	 * @return the secretQuestionSBO
	 */
	public SecretQuestionSBO getSecretQuestionSBO() {
		return secretQuestionSBO;
	}

	/**
	 * @param secretQuestionSBO
	 *            the secretQuestionSBO to set
	 */
	public void setSecretQuestionSBO(SecretQuestionSBO secretQuestionSBO) {
		this.secretQuestionSBO = secretQuestionSBO;
	}

	/**
	 * @return the symmetricCryptoManager
	 */
	public SymmetricCryptoManager getSymmetricCryptoManager() {
		return symmetricCryptoManager;
	}

	/**
	 * @param symmetricCryptoManager
	 *            the symmetricCryptoManager to set
	 */
	public void setSymmetricCryptoManager(
			SymmetricCryptoManager symmetricCryptoManager) {
		this.symmetricCryptoManager = symmetricCryptoManager;
	}

	/**
	 * @return the personEmailAddressDAOFacade
	 */
	public PersonEmailAddressDAOFacade getPersonEmailAddressDAOFacade() {
		return personEmailAddressDAOFacade;
	}

	/**
	 * @param personEmailAddressDAOFacade
	 *            the personEmailAddressDAOFacade to set
	 */
	public void setPersonEmailAddressDAOFacade(
			PersonEmailAddressDAOFacade personEmailAddressDAOFacade) {
		this.personEmailAddressDAOFacade = personEmailAddressDAOFacade;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#checkAccountExistInRefog(java.lang.String)
	 */
	public void checkAccountExistInRefog(String uid) {
		Map attributes = refogAccountDAOFacade.findAttributes(uid);
		if (attributes == null || attributes.isEmpty()) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.ACCOUNT_NOT_EXIST_IN_REFOG,
					new String[] { uid }, logger);
		}
	}

	/**
	 * 
	 * @param keyValues
	 */
	private void checkKeyApplication(Map<String, String> keyValues) {
		// Control for the key APPLICATION : must be present and valid.
		if (!keyValues.keySet().contains(MailingOrderConstants.KEY_APPLICATION)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.APPLICATION_KEY_MANDATORY,
					new Object[] {}, logger);
		}

		String applicationName = keyValues.get(MailingOrderConstants.KEY_APPLICATION);
		if (StringUtils.isBlank(applicationName)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.APPLICATION_IS_BLANK,
					new Object[] {}, logger);
		}

		Set applications = getApplicationSBO().findByCriteria(applicationName,
				null, null, null);
		if (applications.size() == 0) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.APPLICATION_NOT_EXIST,
					new Object[] { applicationName }, logger);
		}
	}

	/**
	 * 
	 * @param keyValues
	 */
	private boolean checkKeyLoginAndPasswordMailingType(Map keyValues) {
		if (!keyValues.keySet().contains(
				MailingOrderConstants.KEY_LOGIN_MAIL_TYPE)
				&& !keyValues.keySet().contains(
						MailingOrderConstants.KEY_PASSWORD_MAIL_TYPE)
						&& !keyValues.keySet().contains(
								MailingOrderConstants.KEY_TOTP_MAIL_TYPE)) {
/*			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.LOGIN_MAIL_TYPE_KEY_OR_PASSWORD_MAIL_TYPE_KEY_MANDATORY,
					new Object[] {}, logger);*/
			return false;
		}

		String loginMailingType = (String) keyValues
				.get(MailingOrderConstants.KEY_LOGIN_MAIL_TYPE);
		String passwordMailingType = (String) keyValues
				.get(MailingOrderConstants.KEY_PASSWORD_MAIL_TYPE);
		String totpMailingType = (String) keyValues
			.get(MailingOrderConstants.KEY_TOTP_MAIL_TYPE);

		if (StringUtils.isBlank(loginMailingType)
				&& StringUtils.isBlank(passwordMailingType)
				&& StringUtils.isBlank(totpMailingType)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.LOGIN_MAIL_TYPE_OR_PASSWORD_MAIL_TYPE_IS_BLANK,
					new Object[] {}, logger);
		}

		if (!StringUtils.isBlank(loginMailingType)) {
			checkMailingType(loginMailingType,
					MailingOrderConstants.KEY_LOGIN_MAIL_TYPE);
		}

		if (!StringUtils.isBlank(passwordMailingType)) {
			checkMailingType(passwordMailingType,
					MailingOrderConstants.KEY_PASSWORD_MAIL_TYPE);
		}
		return true;
	}

	/**
	 * 
	 * @param mailingType
	 * @param key
	 */
	private void checkMailingType(String mailingType, String key) {
		if (!MailingOrderConstants.CHANNEL_TYPE_POSTAL
				.equalsIgnoreCase(mailingType)
				&& !MailingOrderConstants.CHANNEL_TYPE_EMAIL
						.equalsIgnoreCase(mailingType)
				&& !MailingOrderConstants.CHANNEL_TYPE_SMS
						.equalsIgnoreCase(mailingType)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.INVALID_ATTRIBUTE_VALUE_2,
					new String[] {
							mailingType,
							key,
							"null, "
									+ MailingOrderConstants.CHANNEL_TYPE_POSTAL
									+ ", "
									+ MailingOrderConstants.CHANNEL_TYPE_EMAIL
									+ ", "
									+ MailingOrderConstants.CHANNEL_TYPE_SMS },
					logger);
		}
	}
	
	
	
	private String getValueFromNode(Document document, String nodePath) {
		String tmp = "";
		if(StringUtils.isNotBlank(nodePath)) {
			String[] nodesExplode = nodePath.split("\\.");
			NodeList pere = document.getChildNodes();
			for (int i = 0; i < nodesExplode.length; i++) {
				String node = nodesExplode[i];
				for (int j = 0; j < pere.getLength(); j++) {
					Node n = pere.item(j);
					if (node.equals(n.getNodeName())) {
						pere = n.getChildNodes();
						break;
					}
				}
			}

			// arriv� ici il ne doit rester que les fils du noeud (donc le noeud texte)
			if (pere != null) {
				Node n = pere.item(0);
				tmp = n.getNodeValue();
			}
		}

		return tmp;
	}
	
	

	/**
	 * 
	 * @param authAccountEBO
	 * @param keyValues
	 * @param loginMailingType
	 * @param passwordMailingType
	 * @param channelType
	 * @throws Exception 
	 */
	private void addMailingOrderPostal(AuthAccountEBO authAccountEBO, Map<String, String> keyValues, String loginMailingType, String passwordMailingType, String channelType) {

		String application = keyValues.get(MailingOrderConstants.KEY_APPLICATION);
		String globalPrefix = MailingOrderConstants.FILE_KEY_PREFIX + application + "." + channelType;

		String infosMail = keyValues.get(MailingOrderConstants.KEY_INFOS_MAIL);
		Document outputDocument = null;
		
		boolean isCreateMailingContentFromXml = false; 
		
		if (StringUtils.isBlank(infosMail)) {
			outputDocument = createMailingContentFromProperties(keyValues, globalPrefix, application);
			isCreateMailingContentFromXml = false;
		} else {
			outputDocument = createMailingContentFromXml(infosMail, globalPrefix, application);
			isCreateMailingContentFromXml = true;
		}

		// d�terminer si c'est une cr�ation
		boolean isCreation = false;
		Calendar creationDate = authAccountEBO.getAccount().getCreationDt();
		Calendar today = Calendar.getInstance();
		today.setTime(new Date());
		if (creationDate != null
				&& creationDate.get(Calendar.YEAR) == today.get(Calendar.YEAR)
				&& creationDate.get(Calendar.MONTH) == today
						.get(Calendar.MONTH)
				&& creationDate.get(Calendar.DAY_OF_MONTH) == today
						.get(Calendar.DAY_OF_MONTH)) {
			isCreation = true;
		}

		Calendar wishCal = Calendar.getInstance();
		// trouver le prochain jour ouvr� (TODO ne prend pas en compte les jours
		// f�ri�s pour le moment)
		wishCal = getBusinessDay(wishCal);

		
		//version 2
		if(loginMailingType!=null || passwordMailingType != null)
		{	
			Document outputDocInitial = null;
			outputDocInitial = getCopyDoc(outputDocument);
			
			if (loginMailingType != null) 
			{
				// D0570-LOT1/EspaceADE : Structure XML, on met les bons TOP pour WEBCLI
				if (application != null && application.equals(MailingOrderConstants.KEY_WEBCLI)){
					// fix 2 tops pour login
					outputDocument = fixOutputDocument(outputDocument, true, false);
				}
				
				addMailingOrderPostalForLogin(outputDocument, globalPrefix,
						authAccountEBO, application,
						today, wishCal, channelType);
			}
			if (passwordMailingType != null) 
			{
				// si envoi en m�me temps de login et password
				// l'envoi du mot de passe se fait NB_DAY_AFTER_LOGIN apr�s le login
				if (loginMailingType != null) 
				{
					wishCal.add(Calendar.DAY_OF_YEAR,
							MailingOrderConstants.NB_DAY_AFTER_LOGIN);
					wishCal = getBusinessDay(wishCal);
					
					//get document without eventually login
					outputDocument = outputDocInitial;
				}

				// D0570-LOT1/EspaceADE : Structure XML ou tableau, on met les bons TOP pour WEBCLI
				if (application != null && application.equals(MailingOrderConstants.KEY_WEBCLI)){
					// fix 2 tops pour password
					outputDocument = fixOutputDocument(outputDocInitial, false, true);
				}
				
				addMailingOrderPostalForPassword(outputDocument, globalPrefix,
						authAccountEBO, application,
						today, wishCal, isCreation, channelType);
			}
		}
		else //version1
		{
			if(isCreation)
			{
				
				// document qui servira pour l'envoi du mot de passe
				Document outputDocInitial = null;
				outputDocInitial = getCopyDoc(outputDocument);
				
				// D0570-LOT1/EspaceADE : Structure XML ou tableau, on met les bons TOP pour WEBCLI pour login
				if (application != null && application.equals(MailingOrderConstants.KEY_WEBCLI)){
					// fix 2 tops pour login
					outputDocument = fixOutputDocument(outputDocument, true, false);
				}
				
				//add login
				addMailingOrderPostalForLogin(outputDocument, globalPrefix,
						authAccountEBO, application,
						today, wishCal, channelType);
				

				// D0570-LOT1/EspaceADE : Structure XML ou tableau, on met les bons TOP pour WEBCLI pour password
				if (application != null && application.equals(MailingOrderConstants.KEY_WEBCLI)){
					// fix 2 tops pour password
					outputDocInitial = fixOutputDocument(outputDocInitial, false, true);
				}
				
				//add password
				wishCal.add(Calendar.DAY_OF_YEAR, MailingOrderConstants.NB_DAY_AFTER_LOGIN);
				wishCal = getBusinessDay(wishCal);
				addMailingOrderPostalForPassword(outputDocInitial, globalPrefix,
						authAccountEBO, application,
						today, wishCal, isCreation, channelType);
			}
			else
			{
				// D0570-LOT1/EspaceADE : Structure XML ou tableau, on met les bons TOP pour WEBCLI pour password
				if (application != null && application.equals(MailingOrderConstants.KEY_WEBCLI)){
					// fix 2 tops pour password
					outputDocument = fixOutputDocument(outputDocument, false, true);
				}
				
				addMailingOrderPostalForPassword(outputDocument, globalPrefix,
						authAccountEBO, application,
						today, wishCal, isCreation, channelType);
			}
		}
	}

	private Document fixOutputDocument(Document outputDocument, boolean isLogin, boolean isPassword) {
		
		Document currentDocument = outputDocument;
		
		boolean isLoginFound = false;
		boolean isPasswordFound = false;
		
		if (currentDocument != null){
			
			NodeList loginList = currentDocument.getElementsByTagName(MailingOrderConstants.TAG_ELEMENT_TOP_LETTRE_COM);
			if(loginList != null){
				if (loginList.item(0) != null){
					isLoginFound = true;
				}
			}
			
			NodeList passwordList = currentDocument.getElementsByTagName(MailingOrderConstants.TAG_ELEMENT_TOP_LETTRE_CODE);
			if(passwordList != null){
				if (passwordList.item(0) != null){
					isPasswordFound = true;
				}
			}
			
			// Override existing values
			if (isLogin){
				if(isLoginFound){
					loginList.item(0).getFirstChild().setNodeValue("O");
				}
				if(isPasswordFound){
					passwordList.item(0).getFirstChild().setNodeValue("N");
				}
			}
			
			if (isPassword){
				if(isLoginFound){
					loginList.item(0).getFirstChild().setNodeValue("N");
				}
				if(isPasswordFound){
					passwordList.item(0).getFirstChild().setNodeValue("O");
				}
			}
		}
		return currentDocument;
	}

	/**
	 * Fix OutputDocument with TOP required for validation for WEBCLIENT
	 * @param outputDocument
	 * @return Document fixed
	 */
	private Document fixOutputDocumentWithTop(Document outputDocument) {
		Document currentDocument = outputDocument;
		
		boolean isLoginFound = false;
		boolean isPasswordFound = false;
		
		if (currentDocument != null){
			
			// SESAME-3373 : fix insert on first element
			NodeList firstNodeList = currentDocument.getChildNodes();
			Node webcliNode = null;
			Node firstElement = null;
			
			if(firstNodeList != null){
				webcliNode = firstNodeList.item(0);
				
				if (webcliNode != null){
					firstElement = webcliNode.getFirstChild();
				}
			}
			
			NodeList loginList = currentDocument.getElementsByTagName(MailingOrderConstants.TAG_ELEMENT_TOP_LETTRE_COM);
			if(loginList != null){
				if (loginList.item(0) != null){
					isLoginFound = true;
				}
			}
			
			NodeList passwordList = currentDocument.getElementsByTagName(MailingOrderConstants.TAG_ELEMENT_TOP_LETTRE_CODE);
			if(passwordList != null){
				if (passwordList.item(0) != null){
					isPasswordFound = true;
				}
			}
			
			Node passwordNode = null;
			if (passwordList != null){
				passwordNode = passwordList.item(0);
			}
			
			// Override existing values
			if (isLoginFound){
				loginList.item(0).getFirstChild().setNodeValue("N");
			}else{
				// Insert elements to the document
				Element loginElement = currentDocument.createElement(MailingOrderConstants.TAG_ELEMENT_TOP_LETTRE_COM);
				Text loginText = currentDocument.createTextNode("N");
				loginElement.appendChild(loginText);
				if (passwordNode != null){
					currentDocument.getFirstChild().insertBefore(loginElement, passwordNode);
				}else{
					currentDocument.getFirstChild().insertBefore(loginElement, firstElement);
				}
			}
			
			if (isPasswordFound){
				passwordList.item(0).getFirstChild().setNodeValue("N");
			}else{
				// Insert elements to the document
				Element passwordElement = currentDocument.createElement(MailingOrderConstants.TAG_ELEMENT_TOP_LETTRE_CODE);
				Text passwordText = currentDocument.createTextNode("N");
				passwordElement.appendChild(passwordText);
				
				// In case, we give only Top_Lettre_Com as first element, we need to insert in 2nd position
				if (firstElement != null && firstElement.getNodeName().equals("Top_Lettre_Com")){
					Node next = firstElement.getNextSibling();
					currentDocument.getFirstChild().insertBefore(passwordElement, next);
				}else{
					currentDocument.getFirstChild().insertBefore(passwordElement, firstElement);
				}
			}
		}
		return currentDocument;
	}

	private Document getCopyDoc(Document outputDocument) {

		Document outputDocTmp;
		try {
			outputDocTmp = getOutPutDoc();
		} catch (ParserConfigurationException e) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.DOCUMENT_GENERATION_IMPOSSIBLE,
					new Object[] { e.getMessage() }, e, logger);
		}
		Node cloneNode = outputDocument.getDocumentElement().cloneNode(true);
		cloneNode = outputDocTmp.importNode(cloneNode, true);
		outputDocTmp.appendChild(cloneNode);
		return outputDocTmp;
	}

	/**
	 * 
	 * @param outputDoc
	 * @param globalPrefix
	 * @param authAccountEBO
	 * @param applicationId
	 * @param today
	 * @param wishCal
	 * @param isCreation
	 * @param channelType
	 */
	private void addMailingOrderPostalForPassword(Document outputDoc,
			String globalPrefix, AuthAccountEBO authAccountEBO,
			String applicationId, Calendar today, Calendar wishCal,
			boolean isCreation, String channelType) {

		// envoi du mot de passe
		// le mot de passe
		String keyPassword = getKeyFromProperties(globalPrefix
				+ MailingOrderConstants.FILE_OUTPUT_PASSWORD_FIELD);
		addDocumentNodeAndValue(outputDoc, keyPassword, "<<PASSWORD>>");

		// indique une r�initialisation
		String keyReinit = getKeyFromProperties(globalPrefix
				+ MailingOrderConstants.FILE_OUTPUT_REINIT_FIELD);
		String orderType = null;
		if (isCreation) {
			addDocumentNodeAndValue(outputDoc, keyReinit,
					MailingOrderConstants.REINIT_VALUE_NO);
			orderType = MailingOrderConstants.ORDER_TYPE_FIRST_PASS;
		} else {
			addDocumentNodeAndValue(outputDoc, keyReinit,
					MailingOrderConstants.REINIT_VALUE_YES);
			orderType = MailingOrderConstants.ORDER_TYPE_REINIT_PASS;
		}

		// R�cup�ration du nom du fichier XSD
		String xsdFileOutput = getKeyFromProperties(globalPrefix
				+ MailingOrderConstants.FILE_OUTPUT_TEMPLATE);
		validateDocument(outputDoc, xsdFileOutput);
		
		String critere1 = null;
		String critere2 = null;
		String critere3 = null;
		try {
			critere1 = getValueFromNode(outputDoc, getValuesFromProperties(globalPrefix
						+ MailingOrderConstants.FILE_CRITERE1_FIELD));

			critere2 = getValueFromNode(outputDoc, getValuesFromProperties(globalPrefix
						+ MailingOrderConstants.FILE_CRITERE2_FIELD));

			critere3 = getValueFromNode(outputDoc, getValuesFromProperties(globalPrefix
						+ MailingOrderConstants.FILE_CRITERE3_FIELD));
		} catch (IOException e) {
			AuthAccountSBOImpl.logger.debug("nothing to do, value can be null");
		}

		// generate record in database
		MailingOrderTO mailingOrderTO = initMailingOrderTo(today, critere1,
				critere2, critere3, applicationId, authAccountEBO.getLogin(),
				outputDoc, channelType,
				orderType, wishCal);
		addMailingOrder(mailingOrderTO);
	}

	/**
	 * 
	 * @param outputDoc
	 * @param globalPrefix
	 * @param authAccountEBO
	 * @param applicationId
	 * @param today
	 * @param wishCal
	 * @param channelType
	 */
	private void addMailingOrderPostalForLogin(Document outputDoc,
			String globalPrefix, AuthAccountEBO authAccountEBO,
			String applicationId, Calendar today, Calendar wishCal, String channelType) {

		// envoi du login
		String keyLogin = getKeyFromProperties(globalPrefix
				+ MailingOrderConstants.FILE_OUTPUT_LOGIN_FIELD);
		addDocumentNodeAndValue(outputDoc, keyLogin, authAccountEBO.getLogin());

		// R�cup�ration du nom du fichier XSD
		String xsdFileOutput = getKeyFromProperties(globalPrefix
				+ MailingOrderConstants.FILE_OUTPUT_TEMPLATE);
		validateDocument(outputDoc, xsdFileOutput);

		String critere1 = null;
		String critere2 = null;
		String critere3 = null;
		try {
			critere1 = getValueFromNode(outputDoc, getValuesFromProperties(globalPrefix
						+ MailingOrderConstants.FILE_CRITERE1_FIELD));

			critere2 = getValueFromNode(outputDoc, getValuesFromProperties(globalPrefix
						+ MailingOrderConstants.FILE_CRITERE2_FIELD));

			critere3 = getValueFromNode(outputDoc, getValuesFromProperties(globalPrefix
						+ MailingOrderConstants.FILE_CRITERE3_FIELD));
		} catch (IOException e) {
			AuthAccountSBOImpl.logger.debug("nothing to do, value can be null");
		}
		
		
		// generate record in database
		MailingOrderTO mailingOrderTO = initMailingOrderTo(today, critere1,
				critere2, critere3, applicationId, authAccountEBO.getLogin(),
				outputDoc, channelType,
				MailingOrderConstants.ORDER_TYPE_LOGIN, wishCal);
		addMailingOrder(mailingOrderTO);
	}

	/**
	 * 
	 * @param outputField
	 * @return
	 */
	private String getKeyFromProperties(String outputField) {
		String key;
		try {
			key = getValuesFromProperties(outputField);
		} catch (IOException e) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.GETS_VALUE_KEY_IMPOSSIBLE,
					new Object[] { outputField }, e, logger);
		}
		if (StringUtils.isBlank(key)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.VALUE_KEY_MANDATORY,
					new Object[] { outputField }, logger);
		}
		return key;
	}

	/**
	 * Send a SMS or an Email to a person. The composition of the message is made by SPOC and the send by ICE.
	 * @param account the account of the person we want to send a message
	 * @param msgChannel used to send the message (Email or SMS)
	 * @param msgType the type of the message (Login or Password)
	 * @param applicationId the id of the application for wich we send the message
	 * @param data the informations to fill the message template
	 * @param specificEmailOrSmsNumber the specific email or sms number to send the message
	 * @param specificTemplateId specific template id
	 * @param specificTemplateVersion specific template version
	 * @throws TechnicalBOException if there is a technical problem
	 * @throws InvalidParameterBOException if there is an invalid parameter
	 */
	private void addMailingOrderSMSOrEmail(AccountEBO account, String msgChannel, String msgType, String applicationId, Object data, String specificEmailOrSmsNumber, String specificTemplateId, String specificTemplateVersion) throws TechnicalBOException, InvalidParameterBOException
	{
		PersonEBO person = account.getPerson();
		
		// Compose the message with SPOC
		MessageCharacteristicEBO messageCharacteristic = new MessageCharacteristicEBO();
		messageCharacteristic.setChannel(msgChannel);
		messageCharacteristic.setType(msgType);

		String preferredLanguage = person.getPreferredLanguage();
		if (StringUtils.isEmpty(preferredLanguage)) {
			preferredLanguage = defaultPreferredLanguage;
		}
		messageCharacteristic.setLanguage(preferredLanguage);
		
		SPOCData spocData = getComposeMessageSBO().composeMessageBySPOC(messageCharacteristic, data, specificTemplateId, specificTemplateVersion);
		
		Set<String> receivers = new HashSet<>();
		if (MailingOrderConstants.CHANNEL_TYPE_EMAIL.equals(msgChannel)) {
			if (specificEmailOrSmsNumber != null && specificEmailOrSmsNumber.length() > 0){
				receivers.add(specificEmailOrSmsNumber);
			}else{
				for(final EmailAddressEBO emailAddressEBO : this.personSBO.findEmailAddresses(person)) {
					receivers.add(emailAddressEBO.getAddress().getAddress());
				}
			}
		}
		else {
			// if message channel is SMS and smsNumber param is filled, then we replace receivers with this unique sms number
			if (specificEmailOrSmsNumber != null && specificEmailOrSmsNumber.length() > 0){
				receivers.add(specificEmailOrSmsNumber);
			} else {
				receivers = person.getMobilePhoneNumbers();
			}
		}
		
		//TODO sieuma Clean the code as soon as possible <=> switch MAIL / ICE
		if (usedIce) {
			// Publish the message in ICE to send it
			MCODocumentCompositionAndMailingEBO mcoDocumentCompositionAndMailingEBO = new MCODocumentCompositionAndMailingEBO();
			mcoDocumentCompositionAndMailingEBO.setType(msgType);
			mcoDocumentCompositionAndMailingEBO.setBody(spocData.getBody());
			mcoDocumentCompositionAndMailingEBO.setTitle(spocData.getTitle());
			mcoDocumentCompositionAndMailingEBO.setChannel(msgChannel);

			mcoDocumentCompositionAndMailingEBO.setAreaId(getFirstAreaLabel(account));
			mcoDocumentCompositionAndMailingEBO.setPreferredLanguage(preferredLanguage);
			mcoDocumentCompositionAndMailingEBO.setReceivers(receivers);
			
			getSendMessageSBO().publishMCODocumentCompositionAndMailingInIce(mcoDocumentCompositionAndMailingEBO);
		}
		else {
			// Send the message with SMTP
			// If the message type is SMS and usedIce configuration is not activated, throw an exception
			if (!MailingOrderConstants.CHANNEL_TYPE_EMAIL.equals(msgChannel)) {
				throw new TechnicalBOException(TechnicalBOExceptionConstants.SMS_SENDING_NOT_IMPLEMENTED, logger);
			}
			
			SMTPMessageEBO smtpMessageEBO = new SMTPMessageEBO();
			smtpMessageEBO.setMailHost(mailHost);
			smtpMessageEBO.setMailSender(mailSender);
			smtpMessageEBO.setReceivers(receivers);
			smtpMessageEBO.setMessageType(msgType);
			smtpMessageEBO.setMessageLanguage(preferredLanguage);
			smtpMessageEBO.setMessageBody(spocData.getBody());
			
			getSendMessageSBO().sendWithSMTP(smtpMessageEBO);
		}
		
		// Record the sending in TAMAILINGORDER
		Date currentDte = new Date();
		String orderType;
		
		MailingOrderTO mailingOrderTO = new MailingOrderTO();
		if (MailingOrderConstants.TYPE_LOGIN.equalsIgnoreCase(msgType)) {
			orderType = MailingOrderConstants.TYPE_LOGIN; 
		}
		else if (account.getCreationDt() != null && DateUtils.isSameDay(account.getCreationDt().getTime(), currentDte)) {
			orderType = MailingOrderConstants.TYPE_FIRST_PASS;
		}
		else {
			orderType = MailingOrderConstants.TYPE_REINIT_PASS;
		}
		mailingOrderTO.setOrderType(orderType);
		mailingOrderTO.setMailType(msgChannel);
		mailingOrderTO.setCreationDate(currentDte);
		mailingOrderTO.setWishedSendDate(currentDte);
		mailingOrderTO.setSendDate(currentDte);
		mailingOrderTO.setIdUser(account.getId());
		mailingOrderTO.setIdApplication(applicationId);
		mailingOrderTO.setManaged(Boolean.TRUE);
		
		addMailingOrder(mailingOrderTO);
		
	}
	
	/**
	 * Get the label of the first area of the list of user's areas
	 * @return the label of the first area.
	 */
	private String getFirstAreaLabel(AccountEBO account) {
		Set areas = accountSBO.getAreas(account);
		Iterator it = areas.iterator();
		if (it.hasNext()) {
			UserAdminAreaEBO userAdminAreaEBO = (UserAdminAreaEBO)it.next();
			return userAdminAreaEBO.getLabel();
		}
		return null;
	}
	
	@Override
	public void addMailingOrderV2(AuthAccountEBO authAccountEBO, Map keyValues)
			throws DataAccessException, InvalidParameterBOException,
			TechnicalBOException {

		// Control for the key APPLICATION : must be present and valid.
		checkKeyApplication(keyValues);

		// Control for the key LOGIN_MAIL_TYPE or PASSWORD_MAIL_TYPE or TOTP_MAIL_TYPE
		boolean controlLoginOrPasswordOrTotpMailType = checkKeyLoginAndPasswordMailingType(keyValues);

		// if no mail type, we send nothing
		if (!controlLoginOrPasswordOrTotpMailType){
			return;
		}

		String applicationName = (String) keyValues.get(MailingOrderConstants.KEY_APPLICATION);
		String loginMailingType = (String) keyValues.get(MailingOrderConstants.KEY_LOGIN_MAIL_TYPE);
		String passwordMailingType = (String) keyValues.get(MailingOrderConstants.KEY_PASSWORD_MAIL_TYPE);
		String totpMailingType = (String) keyValues.get(MailingOrderConstants.KEY_TOTP_MAIL_TYPE);

		String templateLoginId = (String) keyValues.get(MailingOrderConstants.KEY_TEMPLATE_LOGIN_ID);
		String templateLoginVersion = (String) keyValues.get(MailingOrderConstants.KEY_TEMPLATE_LOGIN_VERSION);
		String templatePasswordId = (String) keyValues.get(MailingOrderConstants.KEY_TEMPLATE_PASSWORD_ID);
		String templatePasswordVersion = (String) keyValues.get(MailingOrderConstants.KEY_TEMPLATE_PASSWORD_VERSION);
		String rcptEmail = (String) keyValues.get(MailingOrderConstants.KEY_RCPT_EMAIL);
		String rcptSms = (String) keyValues.get(MailingOrderConstants.KEY_RCPT_SMS);

		if (MailingOrderConstants.CHANNEL_TYPE_POSTAL.equals(loginMailingType)
				|| MailingOrderConstants.CHANNEL_TYPE_POSTAL
						.equals(passwordMailingType)) {
			// call addMailingOrderPostal
			addMailingOrderPostal(authAccountEBO, keyValues, loginMailingType, passwordMailingType, MailingOrderConstants.CHANNEL_TYPE_POSTAL);
		} 
		else 
		{
			PersonEBO person = authAccountEBO.getAccount().getPerson();
			if (MailingOrderConstants.CHANNEL_TYPE_EMAIL.equals(totpMailingType)){
				if (personSBO.getFirstEmailAddress(person) == null) {
					throw new InvalidParameterBOException(
							InvalidParameterBOExceptionConstants.USER_ACCOUNT_MUST_HAVE_AT_LEAST_ONE_EMAIL,
							new Object[] {}, logger);
				}
			}

			String specificEmailOrSmsNumber = null;

			if(loginMailingType!=null)
			{
				gentypes.spocmsg.login.Sesame.LoginMailing loginMailing = new gentypes.spocmsg.login.Sesame.LoginMailing();
				loginMailing.setLogin(authAccountEBO.getLogin());
				loginMailing.setFirstName(person.getFirstName());
				loginMailing.setLastName(person.getLastName());
				
				if (keyValues != null){
					
					gentypes.spocmsg.login.Collection keyValuesLoginCollection = new gentypes.spocmsg.login.Collection();
					
					Iterator keyValuesLoginSet = keyValues.entrySet().iterator();
					while (keyValuesLoginSet.hasNext()){
						Entry loginKey = (Entry)keyValuesLoginSet.next();
						gentypes.spocmsg.login.KeyValueType loginKeyValueType = new gentypes.spocmsg.login.KeyValueType();
						loginKeyValueType.setKey(loginKey.getKey().toString());
						loginKeyValueType.setValue(loginKey.getValue().toString());
						keyValuesLoginCollection.getItem().add(loginKeyValueType);
					}
					
					loginMailing.setCollection(keyValuesLoginCollection);				
				}
				
				gentypes.spocmsg.login.Sesame sesame = new gentypes.spocmsg.login.Sesame();
				sesame.setLoginMailing(loginMailing);
				
				if (templateLoginId != null && (templateLoginVersion == null || templateLoginVersion.length() == 0)){
					throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.UNDEFINED_SPOC_TEMPLATE_LOGIN_VERSION, new Object[] {}, logger);
				}

				if (MailingOrderConstants.CHANNEL_TYPE_EMAIL.equals(loginMailingType)){
					// if email is provided, we take it
					if (rcptEmail != null && rcptEmail.length() != 0){
						specificEmailOrSmsNumber = rcptEmail;
					}else{
						// else at least one email should be defined
						if (this.personSBO.getFirstEmailAddress(person) == null) {
							throw new InvalidParameterBOException(
									InvalidParameterBOExceptionConstants.USER_ACCOUNT_MUST_HAVE_AT_LEAST_ONE_EMAIL,
									new Object[] {}, logger);
						}
					}
				}else{
					// if phone number is provided, we take it
					if (MailingOrderConstants.CHANNEL_TYPE_SMS.equals(loginMailingType)){
						if (rcptSms != null && rcptSms.length() != 0){
							specificEmailOrSmsNumber = rcptSms;
						}else{
							// else at least one phone number should be defined
							if (person.getFirstMobilePhoneNumber() == null) {
								throw new InvalidParameterBOException(
										InvalidParameterBOExceptionConstants.USER_ACCOUNT_MUST_HAVE_AT_LEAST_ONE_MOBILE_PHONE_NUMBER,
										new Object[] {}, logger);
							}
						}
					}
				}

				addMailingOrderSMSOrEmail(authAccountEBO.getAccount(), loginMailingType, MailingOrderConstants.TYPE_LOGIN, applicationName, sesame, specificEmailOrSmsNumber, templateLoginId, templateLoginVersion);
			}
			if(passwordMailingType!=null)
			{
				gentypes.spocmsg.password.Sesame.PasswordMailing passwordMailing = new gentypes.spocmsg.password.Sesame.PasswordMailing();
				
				// Get the security level strategy used for the reset
				Integer securityLevel;
				if (AuthAccountConstants.TYPE_CLIENT.equals(authAccountEBO.getAuthType())) {
					securityLevel = AuthAccountConstants.LEVEL_LOW;
				} else if (AuthAccountConstants.TYPE_TIERS.equals(authAccountEBO.getAuthType())) {
					securityLevel = AuthAccountConstants.LEVEL_MIDDLE;
				} else {
					throw new InvalidParameterBOException(
							InvalidParameterBOExceptionConstants.GROUP_ACCOUNT_RESET_PASSWORD_NOT_MANAGED,
							new Object[] {}, logger);
				}
				
				// password is crypted so we regenerate it
				// Reset the password
				String password = this.resetPassword(authAccountEBO, authAccountEBO, securityLevel);

				passwordMailing.setPassword(password);
				passwordMailing.setFirstName(person.getFirstName());
				passwordMailing.setLastName(person.getLastName());

				if (keyValues != null){
					
					gentypes.spocmsg.password.Collection keyValuesPasswordCollection = new gentypes.spocmsg.password.Collection();
					
					Iterator keyValuesPasswordSet = keyValues.entrySet().iterator();
					while (keyValuesPasswordSet.hasNext()){
						Entry passwordKey = (Entry)keyValuesPasswordSet.next();
						gentypes.spocmsg.password.KeyValueType passwordKeyValueType = new gentypes.spocmsg.password.KeyValueType();
						passwordKeyValueType.setKey(passwordKey.getKey().toString());
						passwordKeyValueType.setValue(passwordKey.getValue().toString());
						keyValuesPasswordCollection.getItem().add(passwordKeyValueType);
					}

					passwordMailing.setCollection(keyValuesPasswordCollection);				
				}
				
				gentypes.spocmsg.password.Sesame sesame = new gentypes.spocmsg.password.Sesame();
				sesame.setPasswordMailing(passwordMailing);
				
				if (templatePasswordId != null && (templatePasswordVersion == null || templatePasswordVersion.length() == 0)){
					throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.UNDEFINED_SPOC_TEMPLATE_PASSWORD_VERSION, new Object[] {}, logger);
				}
				
				if (MailingOrderConstants.CHANNEL_TYPE_EMAIL.equals(passwordMailingType)){
					// if email is provided, we take it
					if (rcptEmail != null && rcptEmail.length() != 0){
						specificEmailOrSmsNumber = rcptEmail;
					}else{
						// else at least one email should be defined
						if (personSBO.getFirstEmailAddress(person) == null) {
							throw new InvalidParameterBOException(
									InvalidParameterBOExceptionConstants.USER_ACCOUNT_MUST_HAVE_AT_LEAST_ONE_EMAIL,
									new Object[] {}, logger);
						}
					}
				}else{
					if (MailingOrderConstants.CHANNEL_TYPE_SMS.equals(passwordMailingType)){
						// if phone number is provided, we take it
						if (rcptSms != null && rcptSms.length() != 0){
							specificEmailOrSmsNumber = rcptSms;
						}else{
							// else at least one phone number should be defined
							if (person
									.getFirstMobilePhoneNumber() == null) {
								throw new InvalidParameterBOException(
										InvalidParameterBOExceptionConstants.USER_ACCOUNT_MUST_HAVE_AT_LEAST_ONE_MOBILE_PHONE_NUMBER,
										new Object[] {}, logger);
							}
						}
					}
				}
				
				addMailingOrderSMSOrEmail(authAccountEBO.getAccount(), passwordMailingType, MailingOrderConstants.TYPE_PASSWORD, applicationName, sesame, specificEmailOrSmsNumber,templatePasswordId, templatePasswordVersion);
			}
			if(totpMailingType!=null)
			{
				String totpKey = (String)keyValues.get(MailingOrderConstants.KEY_TOTP_KEY);
				
				gentypes.spocmsg.totp.Sesame.TotpMailing totpMailing = new gentypes.spocmsg.totp.Sesame.TotpMailing();
				totpMailing.setKeyTOTP(totpKey);
				totpMailing.setFirstName(person.getFirstName());
				totpMailing.setLastName(person.getLastName());

				if (keyValues != null){
					
					gentypes.spocmsg.totp.Collection keyValuesTotpCollection = new gentypes.spocmsg.totp.Collection();
					
					Iterator keyValuesTotpSet = keyValues.entrySet().iterator();
					while (keyValuesTotpSet.hasNext()){
						Entry totpKeyValue = (Entry)keyValuesTotpSet.next();
						gentypes.spocmsg.totp.KeyValueType totpValueType = new gentypes.spocmsg.totp.KeyValueType();
						totpValueType.setKey(totpKeyValue.getKey().toString());
						totpValueType.setValue(totpKeyValue.getValue().toString());
						keyValuesTotpCollection.getItem().add(totpValueType);
					}
					
					totpMailing.setCollection(keyValuesTotpCollection);				
				}
				
				gentypes.spocmsg.totp.Sesame sesame = new gentypes.spocmsg.totp.Sesame();
				sesame.setTotpMailing(totpMailing);
				
				addMailingOrderSMSOrEmail(authAccountEBO.getAccount(), totpMailingType, MailingOrderConstants.TYPE_TOTP, applicationName, sesame, null, null, null);
			}
				
			
			
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void addMailingOrder(AuthAccountEBO authAccountEBO, Map<String, String> keyValues)
			throws DataAccessException, InvalidParameterBOException,
			TechnicalBOException {
		
		//Control for the key APPLICATION : must be present and valid.
		checkKeyApplication(keyValues);

		// Control for the key MAIL_TYPE
		String mailingType = keyValues.get(MailingOrderConstants.KEY_MAIL_TYPE);
		if (StringUtils.isBlank(mailingType)) {
			mailingType = MailingOrderConstants.CHANNEL_TYPE_POSTAL;
			keyValues.put(MailingOrderConstants.KEY_MAIL_TYPE, mailingType);
		}

		if (!MailingOrderConstants.CHANNEL_TYPE_POSTAL
				.equalsIgnoreCase(mailingType)
				&& !MailingOrderConstants.CHANNEL_TYPE_EMAIL
						.equalsIgnoreCase(mailingType)
				&& !MailingOrderConstants.CHANNEL_TYPE_SMS
						.equalsIgnoreCase(mailingType)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.INVALID_ATTRIBUTE_VALUE_2,
					new String[] {
							mailingType,
							MailingOrderConstants.KEY_MAIL_TYPE,
							"null, "
									+ MailingOrderConstants.CHANNEL_TYPE_POSTAL
									+ ", "
									+ MailingOrderConstants.CHANNEL_TYPE_EMAIL
									+ ", "
									+ MailingOrderConstants.CHANNEL_TYPE_SMS },
					logger);
		}

		// call addMailingOrderPostal
		addMailingOrderPostal(authAccountEBO, keyValues, null, null, mailingType);
	}

	private Calendar getBusinessDay(Calendar calendar) {
		int nb1 = 1;
		int nb2 = 2;
		int day = calendar.get(Calendar.DAY_OF_WEEK);
		if (Calendar.SATURDAY == day)
			calendar.add(Calendar.DAY_OF_YEAR, nb2);
		else if (Calendar.SUNDAY == day)
			calendar.add(Calendar.DAY_OF_YEAR, nb1);
		return calendar;
	}

	private Properties properties;

	private String getValuesFromProperties(String key) throws IOException {
		if (properties == null) {
			properties = new Properties();
			InputStream stream = Thread
					.currentThread()
					.getContextClassLoader()
					.getResourceAsStream(
							"properties/application.mailing.information.properties");
			properties.load(stream);
			stream.close();
		}

		return properties.getProperty(key);
	}

	private Document createMailingContentFromProperties(Map<String, String> keyValues,
			String globalPrefix, String application) {
		try {
			String authFields = getValuesFromProperties(globalPrefix
					+ MailingOrderConstants.FILE_AUTHORIZED_FIELDS_SUFFIX);
			Document outputDoc = null;
			if (StringUtils.isNotBlank(authFields)) {
				List<String> authorizedFields = Arrays.asList(authFields.split(","));
				String outPutPrefix = globalPrefix
						+ MailingOrderConstants.FILE_OUTPUT;

				outputDoc = getOutPutDoc();

				for (int i = 0; i < authorizedFields.size(); i++) {
					String field = authorizedFields.get(i);
					String value = keyValues.get(field);

					if (StringUtils.isNotBlank(value)) {
						String key = outPutPrefix
								+ field
								+ MailingOrderConstants.FILE_OUTPUT_ATTRIBUTE_FIELD;
						String xmlKey = getValuesFromProperties(key);
						if (StringUtils.isNotBlank(xmlKey)) {
							addDocumentNodeAndValue(outputDoc, xmlKey, value);
						}
					}
				}
				
				// Fix outputDocument pour mettre les 2 top obligatoires pour OPTIMA
				if (application != null && application.equals(MailingOrderConstants.KEY_WEBCLI)){
					outputDoc = fixOutputDocumentWithTop(outputDoc);
				}
			}
			return outputDoc;
		} catch (ParserConfigurationException e) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.INVALID_DOCUMENT_PROPERTIES,
					new Object[] { e.getMessage() }, e, logger);
		} catch (IOException e) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.INVALID_DOCUMENT_PROPERTIES,
					new Object[] { e.getMessage() }, e, logger);
		}

	}

	private MailingOrderTO initMailingOrderTo(Calendar today, String critere1,
			String critere2, String critere3, String applicationId,
			String login, Document outputDoc, String mailType,
			String orderType, Calendar wishCal) {
		MailingOrderTO mailingOrderTO = new MailingOrderTO();
		mailingOrderTO.setCreationDate(today.getTime());
		mailingOrderTO.setCritere1(critere1);
		mailingOrderTO.setCritere2(critere2);
		mailingOrderTO.setCritere3(critere3);
		mailingOrderTO.setIdApplication(applicationId);
		mailingOrderTO.setIdUser(login);
		mailingOrderTO.setMailContent(getStringFromDocument(outputDoc));
		mailingOrderTO.setMailType(mailType);
		mailingOrderTO.setOrderType(orderType);
		mailingOrderTO.setWishedSendDate(wishCal.getTime());
		mailingOrderTO.setManaged(Boolean.FALSE);
		return mailingOrderTO;
	}

	private String getStringFromDocument(Document document) {
		try {
			TransformerFactory factory = TransformerFactory.newInstance();

			Transformer transformer = factory.newTransformer();

			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty(
					"{http://xml.apache.org/xslt}indent-amount", "2");

			try(final StringWriter stringWriter = new StringWriter()) {
				Result result = new StreamResult(stringWriter);
				transformer.transform(new DOMSource(document), result);
				String ret = stringWriter.getBuffer().toString();
				return ret;
			} catch (final IOException e) {
				AuthAccountSBOImpl.logger.debug("exception while closing StringWriter", e);
				throw new RuntimeException(e);
			}
		} catch (TransformerException e) {
			return null;
		}

	}

	private void addDocumentNodeAndValue(Document outputDoc, String xmlKey,
			String value) {
		String[] nodes = xmlKey.split("\\.");
		Element pere = null;
		for (int i = 0; i < nodes.length; i++) {
			String node = nodes[i];
			NodeList list = outputDoc.getElementsByTagName(node);
			if (list.getLength() == 0) {
				Element element = outputDoc.createElement(node);
				if (pere == null) {
					outputDoc.appendChild(element);
					pere = element;
				} else {
					pere.appendChild(element);
					pere = element;
				}
				if (i == nodes.length - 1) {
					Node textValue = outputDoc.createTextNode(node + "Value");
					textValue.setNodeValue(value);
					element.appendChild(textValue);
					// pere.appendChild(element);
				}
			} else {
				Node n = list.item(0);
				pere = (Element) n;
				if (i == nodes.length - 1) {
					Node textValue = outputDoc.createTextNode(node + "Value");
					textValue.setNodeValue(value);
					n.appendChild(textValue);
				}
			}

		}
	}

	private Document getOutPutDoc() throws ParserConfigurationException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		factory.setValidating(true);
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document outputDocument = builder.newDocument();
		return outputDocument;
	}

	private Document getOutPutDocWithContent(String content)
			throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder = factory.newDocumentBuilder();
		try(final ByteArrayInputStream bais = new ByteArrayInputStream(content.getBytes())) {
			Document outputDocument = builder.parse(bais);
			return outputDocument;
		}
	}
	
	/**
	 * validateDocument
	 * BUG IN IBM JDK ? the validation with domsource doesn't work (it is working with oracle jdk)
	 * http://stackoverflow.com/questions/32187365/ibm-jre-validate-domsource-with-xsd-doesnt-work
	 * must use a StreamSource instead and convert the document to string
	 * @param document document
	 * @param xsdFile xsdFile
	 */
	protected void validateDocument(Document document, String xsdFile) {
		
		try {
			SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI); 
			URL schemaURL = Thread.currentThread().getContextClassLoader().getResource("xsd/" + xsdFile);
			Schema schema = sf.newSchema(schemaURL); 
			javax.xml.validation.Validator validator = schema.newValidator();
			//BUG IN IBM JDK ? the validation with domsource doesn't work (it is working with oracle jdk)
			//http://stackoverflow.com/questions/32187365/ibm-jre-validate-domsource-with-xsd-doesnt-work
			//Source source = new DOMSource(document);
			//must use a StreamSource instead and convert the document to string
			try(final StringReader sr = new StringReader(document2String(document))) {
				Source source = new StreamSource(sr);
				validator.validate(source);
			}
		} catch (Exception exception) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.INVALID_DOCUMENT,
					new Object[] { xsdFile }, exception, logger);
		}
	}
	
	/**
	 * document2String
	 * @param document document
	 * @return String
	 * @throws TransformerException TransformerException
	 */
	private String document2String(Document document) throws TransformerException {
		Transformer transformer = TransformerFactory.newInstance().newTransformer();
		try(final StringWriter writer = new StringWriter()) {
			Result result = new StreamResult(writer);
			transformer.transform(new DOMSource(document), result);
			final String ret = writer.getBuffer().toString();
			return ret;
		} catch (final IOException e) {
			AuthAccountSBOImpl.logger.debug("exception while closing StringWriter", e);
			throw new RuntimeException(e);
		}
	}
	
	private Document createMailingContentFromXml(String infosMail,
			String globalPrefix, String application) {
		try {
			Document document = getOutPutDocWithContent(infosMail);			
			
			String xsdFileInput = getValuesFromProperties(globalPrefix
					+ MailingOrderConstants.FILE_INPUT_TEMPLATE);
			// validation du document
			validateDocument(document, xsdFileInput);


			boolean isWebSal = false;
			boolean isWebCli = false;
			
			if (application != null && application.equals(MailingOrderConstants.KEY_WEBSAL)){
				isWebSal = true;
			}
			
			
			Document outputDoc = getOutPutDoc();
			createOutputDocWithData(outputDoc, document.getDocumentElement(),
					"", globalPrefix);
			
			// Fix outputDocument pour mettre les 2 top obligatoires pour OPTIMA
			if (application != null && application.equals(MailingOrderConstants.KEY_WEBCLI)){
				isWebCli = true;
				outputDoc = fixOutputDocumentWithTop(outputDoc);
			}
			
			String xsdFileOutput = getValuesFromProperties(globalPrefix
					+ MailingOrderConstants.FILE_OUTPUT_TEMPLATE);
			// validation du document
			validateDocument(outputDoc, xsdFileOutput);

			return outputDoc;
		} catch (ParserConfigurationException e) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.INVALID_DOCUMENT_PROPERTIES,
					new Object[] { e.getMessage() }, e, logger);
		} catch (SAXException e) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.INVALID_DOCUMENT_PROPERTIES,
					new Object[] { e.getMessage() }, e, logger);
		} catch (IOException e) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.INVALID_DOCUMENT_PROPERTIES,
					new Object[] { e.getMessage() }, e, logger);
		}

	}

	private void createOutputDocWithData(Document outputDoc, Node node,
			String path, String globalPrefix) throws IOException {

		if (node instanceof Text) {
			String key = globalPrefix + MailingOrderConstants.FILE_OUTPUT
					+ path + MailingOrderConstants.FILE_OUTPUT_XML_FIELD;
			String keyPath = getValuesFromProperties(key);
			if (StringUtils.isNotBlank(keyPath)) {
				addDocumentNodeAndValue(outputDoc, keyPath, node.getNodeValue());
			}
		} else {
			if (StringUtils.isNotBlank(path)) {
				path = path + ".";
			}
			path = path + node.getNodeName();
			NodeList nodelist = node.getChildNodes();
			for (int i = 0; i < nodelist.getLength(); i++) {
				Node n = nodelist.item(i);
				createOutputDocWithData(outputDoc, n, path, globalPrefix);
			}
		}
	}

	/* (non-Javadoc)
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#lock(java.lang.String, java.lang.String)
	 */
	public void lockInCache(String login, String type) throws TechnicalBOException {
	    DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    df.setTimeZone(TimeZone.getTimeZone("UTC"));

		logger.info("Account locked :" + login + " type=" + type + " date=" + df.format(new Date()));
		// Put something as value type,<lock_time_utc>
		getLockedCache().put(login, type + "," + df.format(new Date()) );
	}
	
	/* (non-Javadoc)
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#unlock(java.lang.String)
	 */
	public void unlockFromCache(String login) throws TechnicalBOException {

		logger.info("Unlocking account :" + login);
		// Remove the locked account from the cache
		getLockedCache().remove(login);
	}

	/* (non-Javadoc)
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#unlockFromCache(java.util.Set)
	 */
	public void unlockFromCache(Set logins) throws TechnicalBOException {
		
		if(logins != null)
		{
			for(Iterator iter = logins.iterator();iter.hasNext();)
			{
				Object login = iter.next();
				if(login != null)
				{
					this.unlockFromCache(login.toString());
				}
			}
		}
	}

	/* (non-Javadoc)
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#findLocked(java.lang.String)
	 */
	public String findLockedInCache(String token) throws TechnicalBOException {
		Object objectCached = getLockedCache().get(token);
		return objectCached == null ? null : objectCached.toString();
	}

	/* (non-Javadoc)
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#isLocked(java.lang.String)
	 */
	public boolean isLockedInCache(String token) throws TechnicalBOException {
		return findLockedInCache(token) != null;
	}


	private void addMailingOrder(MailingOrderTO mailingOrderTO) {
		getMailingOrderDAOFacade().addMailingOrder(mailingOrderTO);
	}

	public MailingOrderDAOFacade getMailingOrderDAOFacade() {
		return mailingOrderDAOFacade;
	}

	public void setMailingOrderDAOFacade(
			MailingOrderDAOFacade mailingOrderDAOFacade) {
		this.mailingOrderDAOFacade = mailingOrderDAOFacade;
	}

	/**
	 * @return applicationSBO
	 */
	public ApplicationSBO getApplicationSBO() {
		return applicationSBO;
	}

	/**
	 * @param applicationSBO
	 *            applicationSBO � d�finir
	 */
	public void setApplicationSBO(ApplicationSBO applicationSBO) {
		this.applicationSBO = applicationSBO;
	}

	/**
	 * @return composeMessageSBO
	 */
	public ComposeMessageSBO getComposeMessageSBO() {
		return composeMessageSBO;
	}

	/**
	 * @param composeMessageSBO composeMessageSBO � d�finir
	 */
	public void setComposeMessageSBO(ComposeMessageSBO composeMessageSBO) {
		this.composeMessageSBO = composeMessageSBO;
	}

	/**
	 * @return sendMessageSBO
	 */
	public SendMessageSBO getSendMessageSBO() {
		return sendMessageSBO;
	}

	/**
	 * @param sendMessageSBO sendMessageSBO � d�finir
	 */
	public void setSendMessageSBO(SendMessageSBO sendMessageSBO) {
		this.sendMessageSBO = sendMessageSBO;
	}

	/**
	 * @return SesameLockedCache
	 */
	public SesameLockedCache getLockedCache() {
		return lockedCache;
	}

	/**
	 * @param cache
	 */
	public void setLockedCache(SesameLockedCache lockedCache) {
		this.lockedCache = lockedCache;
	}

	/**
	 * @author bellidori
	 * @see com.bnppa.sesame.authaccount.AuthAccountSBO#findByCriteriaSearchV1(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      java.lang.String, int, int, java.util.Set)
	 */
	public Collection findByCriteriaSearchV1(String accountType, String login,
			String lastName, String firstName, String permissionId,
			String roleId, String statusKey, String functionalAreaId,
			int offSet, int pageSize, Set areas, String idAccountType,
			String preferredLanguage, List sortingCriteriaList, String sortOrder)
			throws InvalidParameterBOException {

		CriteriaAccountSearchTO criteriaAccountSearchTO = new CriteriaAccountSearchTO(
				accountType, login, lastName, firstName, permissionId, roleId,
				statusKey, functionalAreaId, idAccountType, preferredLanguage);

		Set labelAreasSet = new HashSet();
		if (areas != null) {
			for (Iterator iter = areas.iterator(); iter.hasNext();) {
				UserAdminAreaEBO areaEBO = (UserAdminAreaEBO) iter.next();
				labelAreasSet.add(areaEBO.getLabel());
			}
		}
		return authAccountDAOFacade
				.findUserIdentityFromCriteriaV1(criteriaAccountSearchTO, offSet,
						pageSize, labelAreasSet, sortingCriteriaList, sortOrder);

	}
	
	public AuthAccountEBO find(String login, String accountType) throws InvalidParameterBOException 
	{
		
		if (AuthAccountConstants.TYPE_CLIENT.equals(accountType)) 
		{
			return findAccountTypeClient(login);
		}
		if (AuthAccountConstants.TYPE_TIERS.equals(accountType)) 
		{
			return findAccountTypeTiers(login);
		}
		if (AuthAccountConstants.TYPE_GROUP.equals(accountType)) 
		{
			return findAccountTypeGroup(login);
		}
		return null;
	}
	
	
	public AuthAccountEBO findAccountTypeClient(String login) throws InvalidParameterBOException 
	{
		AuthAccountTO authAccountTO = customerAuthAccountDAOFacade
				.find(new AuthAccountIdTO(login, AuthAccountConstants.TYPE_CLIENT));
		return map(authAccountTO);
	}
	
	public AuthAccountEBO findAccountTypeTiers(String login) throws InvalidParameterBOException 
	{
		AuthAccountTO authAccountTO = authAccountDAOFacade
				.find(new AuthAccountIdTO(login, AuthAccountConstants.TYPE_TIERS));
		return map(authAccountTO);
	}
	
	public AuthAccountEBO findAccountTypeGroup(String login) throws InvalidParameterBOException 
	{
		if(!login.startsWith(LDAPAttributesKeys.UID_PREFIX))
		{
			login = new StringBuffer(LDAPAttributesKeys.UID_PREFIX).append(login).toString();
		}
		AuthAccountTO authAccountTO = authAccountDAOFacade.find(new AuthAccountIdTO(login, AuthAccountConstants.TYPE_GROUP));
		return map(authAccountTO);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Map<String,String> getAttributes(AuthAccountEBO authAccountEBO) {

		return this.getAttributes(authAccountEBO, false);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Map<String,String> getAttributes(AuthAccountEBO authAccountEBO, final boolean bypassRefog) {

		Map<String,String> attributes;
		if (!authAccountEBO.isAttributesInitialized() || AuthAccountConstants.TYPE_GROUP.equals(authAccountEBO.getAuthType())) {
			attributes = this.findAttributes(authAccountEBO, bypassRefog);
			authAccountEBO.setSoftAttributes(new SoftReference<Map<String,String>>(attributes));
		} else {
			attributes = authAccountEBO.getSoftAttributes().get();
		}

		return attributes;
	}
	
	/**
	 * @param lastPwd The lastPwd to set. It cannot be null
	 * @throws InvalidParameterBOException if lastPwd is null
	 * @SONAR_VIOLATION_EXCLUDE nullity of softPasswords.get() is already checked by isPwdsInitialized()
	 */
	@Override
	public void setLastPassword(AuthAccountEBO authAccountEBO, PasswordEBO lastPwd) {
		if (lastPwd == null) {
			throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_PWD_IS_NULL,new String[] { authAccountEBO.getLogin() }, logger);
		}
		
		authAccountEBO.setLastPwd(lastPwd);

		List<PasswordEBO> passwords;
		if (authAccountEBO.isPwdsInitialized()) {
			passwords = authAccountEBO.getSoftPasswords().get();
			passwords.add(0, lastPwd);
		}

		this.authAccountDAOFacade.updatePassword(authAccountEBO.getLogin(), lastPwd.getPassword(), lastPwd.getAlgorithm());
	}

	/**
	 * @return Returns the lastPwd. Can be null if authentication is not managed
	 *         by SES
	 */
	public PasswordEBO getLastPassword(AuthAccountEBO authAccountEBO) {
		if (authAccountEBO.getLastPwd() == null) {
			authAccountEBO.setLastPwd(passwordSBO.findLast(authAccountEBO));
		}
		return authAccountEBO.getLastPwd();
	}
	
	/**
	 * @return Returns the passwords. Return null if authentication is not
	 *         managed by SES
	 * @throws TechnicalBOException
	 */
	public List<PasswordEBO> getPasswords(AuthAccountEBO authAccountEBO) throws TechnicalBOException {
		List<PasswordEBO> passwords;
		if (!authAccountEBO.isPwdsInitialized()) {
			passwords = passwordSBO.find(authAccountEBO);
			this.setPasswords(authAccountEBO, passwords);
			authAccountEBO.setSoftPasswords(new SoftReference<List<PasswordEBO>>(passwords));
		} else {
			passwords = authAccountEBO.getSoftPasswords().get();
		}
		return passwords;

	}

	/**
	 * set the passwords of the account and set his last password
	 * 
	 * @param pwds
	 *            The pwds to set. It cannot be null
	 * @throws InvalidParameterBOException
	 *             if pwds is null
	 */
	private void setPasswords(AuthAccountEBO authAccountEBO, List<PasswordEBO> pwds) {

		if (pwds == null) {
			throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_PWDS_IS_NULL,new String[] { authAccountEBO.getLogin() }, logger);
		}

		if (pwds.isEmpty()) {
			authAccountEBO.setLastPwd(null);
		} else {
			this.setLastPassword(authAccountEBO, (PasswordEBO) pwds.get(pwds.size() - 1));
		}
	}


	/**
	 * @param password
	 * @throws LoginBOException
	 * @throws BadPasswordBOException
	 *             if password is wrong
	 * @throws LockedAccountBOException
	 *             if account is inactive or the maximum number of login
	 *             attempts has been reached
	 * @throws ExpiredPasswordBOException
	 *             password has expired
	 * @throws TechnicalBOException
	 *             if technical error
	 * @throws InvalidParameterBOException
	 */
	public void login(AuthAccountEBO authAccountEBO, String password) 
			throws LoginBOException,BadPasswordBOException, ExpiredPasswordBOException,LockedAccountBOException, TechnicalBOException,InvalidParameterBOException {
		
		authAccountEBO.getAuthStrategy().doLogin(password, authAccountEBO);
	}

	/**
	 * {@inheritDoc}
	 */
	public void login(AuthAccountEBO authAccountEBO) 
			throws LoginBOException, BadPasswordBOException,ExpiredPasswordBOException, LockedAccountBOException,TechnicalBOException, InvalidParameterBOException {

		this.login(authAccountEBO, false);
	}

	/**
	 * {@inheritDoc}
	 */
	public void login(AuthAccountEBO authAccountEBO, final boolean bypassRefog) 
			throws LoginBOException, BadPasswordBOException,ExpiredPasswordBOException, LockedAccountBOException,TechnicalBOException, InvalidParameterBOException {

		authAccountEBO.getAuthStrategy().doLogin(authAccountEBO, bypassRefog);
	}
	
	/**
	 * Change the auth account password
	 * 
	 * @param oldPassword
	 * @param newPassword
	 * @throws TechnicalBOException
	 * @throws InvalidPasswordBOException
	 * @throws LockedAccountBOException
	 * @throws LoginBOException
	 */
	public void changePassword(AuthAccountEBO authAccountEBO, String oldPassword, String newPassword)
			throws LoginBOException, LockedAccountBOException,InvalidPasswordBOException, TechnicalBOException {
		
		authAccountEBO.getAuthStrategy().doChangePassword(authAccountEBO, oldPassword, newPassword);
	}

	/**
	 * Change the auth account login
	 * 
	 * @param newLogin
	 * @throws UnAuthorizedActionBOException
	 * @throws InvalidParameterBOException
	 * @throws TechnicalBOException
	 */
	public void changeLogin(AuthAccountEBO authAccountEBO, String newLogin)
			throws UnAuthorizedActionBOException, InvalidParameterBOException, TechnicalBOException {
		
		if (authAccountEBO instanceof CustomerAuthAccountEBO) {
			throw new UnAuthorizedActionBOException(UnAuthorizedActionBOExceptionConstants.ONLY_TIERS_CHANGE_LOGIN,new String[] { authAccountEBO.getAuthType() }, logger);
		}

		if (!AuthAccountConstants.TYPE_TIERS.equals(authAccountEBO.getAuthType())) {
			throw new UnAuthorizedActionBOException(UnAuthorizedActionBOExceptionConstants.ONLY_TIERS_CHANGE_LOGIN,new String[] { authAccountEBO.getAuthType() }, logger);
		}

		AuthAccountEBO authAccount = this.find(newLogin);
		if (authAccount != null && authAccount.isExistInDataStore()) {
			throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.LOGIN_ALREAYDY_EXIST,new String[] { newLogin }, logger);
		}

		this.updateLogin(authAccountEBO, newLogin);

		authAccountEBO.setLogin(newLogin);

		authAccountEBO.getAccount().setId(LoginStrategyFactory.create(authAccountEBO.getAuthType()).createAccountId(authAccountEBO.getLogin(), authAccountEBO.getAccount().getId()));
	}

	/**
	 * create a password
	 * 
	 * @param updator
	 *            authentication account who created the password
	 * @throws InvalidPasswordBOException
	 *             if password is invalid
	 * @throws TechnicalBOException
	 * @throws InvalidParameterBOException
	 */
	public void createPwd(AuthAccountEBO authAccountEBO, AuthAccountEBO updator)
			throws InvalidPasswordBOException, InvalidParameterBOException, TechnicalBOException {
		
		authAccountEBO.getAuthStrategy().doSetPassword(authAccountEBO, updator);
		final String login = authAccountEBO.getLogin();
		final PasswordEBO lastPwd = authAccountEBO.getLastPwd();
		final byte[] password = lastPwd == null ? " ".getBytes() : lastPwd.getPassword();
		final String algorithm = lastPwd == null ? HashAlgorithmEnum.DES.name() : lastPwd.getAlgorithm();
		this.authAccountDAOFacade.updatePassword(login, password, algorithm);
	}
	
	/**
	 * Update the expiry date of the password
	 * @author FVE
	 * @param updator authentication account who created the password
	 */
	public void updatePwdExperyDate(AuthAccountEBO authAccountEBO, AuthAccountEBO updator, Calendar expiryDate) {
		if (expiryDate != null) {
			authAccountEBO.getAuthStrategy().doSetPwdExperyDate(authAccountEBO, updator, expiryDate);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void resetAndSendPassword(AuthAccountEBO authAccountEBO, AuthAccountEBO updator,ChannelMessageFormatEBO channelMessageFormatEBO, Map<String, String> parameters, Date sendingDate, Integer securityLevel) 
			throws InvalidParameterBOException, TechnicalBOException {

		Calendar sendingCalendar = Calendar.getInstance();
		sendingCalendar.setTime(sendingDate);
		// SESAME-1265
		// change the strategy of authentication, corresponding to the application security level
		authAccountEBO.setAuthLevel(securityLevel);
		authAccountEBO.setSecurityRulesStrategy(SecurityRulesFactory.create(authAccountEBO.getAuthLevel()));
		
		authAccountEBO.getAuthStrategy().doResetAndSendPassword(authAccountEBO, updator, channelMessageFormatEBO, parameters, sendingCalendar);

	}
	
	/**
	 * Reset password for this authentication account
	 * @param adminAuthAccountEBO the account of the admin to reset
	 * @param securityLevel the security level strategy to used
	 */
	@Override
	public String resetPassword(AuthAccountEBO authAccountEBO, AuthAccountEBO updator, Integer securityLevel)
			throws InvalidParameterBOException, TechnicalBOException {
		authAccountEBO.setAuthLevel(securityLevel);
		authAccountEBO.setSecurityRulesStrategy(SecurityRulesFactory.create(authAccountEBO.getAuthLevel()));
		return authAccountEBO.getAuthStrategy().doResetPassword(authAccountEBO, updator);
	}

	/**
	 * @return usedIce usedIce
	 */
	@Override
	public boolean isUsedIce() {
		return usedIce;
	}
}
