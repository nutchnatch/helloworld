/**
 * 
 */
package com.bnppa.sesame.authaccount;

import org.apache.commons.lang.StringUtils;

import com.bnppa.sesame.constants.AuthAccountConstants;

/**
 * @author bellidori
 */
public class LoginStrategyFactory {

	/**
	 * @param authType
	 *            authentification account's type :
	 *            <code>AuthAccountConstants.TYPE_ADMINISTRATION</code>,<br>
	 *            <code>AuthAccountConstants.TYPE_TIERS</code>,<br>
	 *            <code>AuthAccountConstants.TYPE_GROUP</code>,<br>
	 *            <code>AuthAccountConstants.TYPE_CLIENT</code>}
	 * @return Implementation of login strategy, null if no implementation found
	 */
	public static LoginStrategy create(String authType) {

		if (AuthAccountConstants.TYPE_TIERS.equals(authType)) {
			return new LoginStrategyImpl();
		}
		if (AuthAccountConstants.TYPE_CLIENT.equals(authType)) {
			return new LoginStrategyImpl();
		}
		if (AuthAccountConstants.TYPE_GROUP.equals(authType)) {
			return new LoginGroupStrategyImpl();
		}
		if (AuthAccountConstants.TYPE_ADMINISTRATION.equals(authType)) {
			return new LoginStrategyImpl();
		}
		
		return null;
	}

	/**
	 * @param accountId
	 *           acccount's identifier
	 * @return Implementation of login strategy
	 */
	public static LoginStrategy createFromAccountId(String accountId) {

		String groupPrefix = "l_"; //$NON-NLS-1$

		if (StringUtils.startsWith(accountId, groupPrefix)) {
			return new LoginGroupStrategyImpl();
		}
		return new LoginStrategyImpl();

	}

}
