/*
 * Created on Mar 23, 2010
 *
 */
package com.bnppa.sesame.authaccount;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bnppa.sesame.constants.CustomerConstants;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;

/**
 * @author behatemo
 * @version Mar 23, 2010
 * 
 */
public class KeyAttributeStrategyFactory {

	private static final Log logger = LogFactory
			.getLog(KeyAttributeStrategyFactory.class);

	private KeyAttributeStrategy statusKeyAttributeStrategy;

	private KeyAttributeStrategy customerKeyAttributeStrategy;

	protected KeyAttributeStrategy create(String keyType) {

		if (CustomerConstants.KEY_STATE.equals(keyType)) {
			return getStatusKeyAttributeStrategy();
		} else if (CustomerConstants.CUSTOMER_TYPE.equals(keyType)
				|| CustomerConstants.CONVENTION.equals(keyType)
				|| CustomerConstants.LAST_MAIL_DATE.equals(keyType)) {
			return getCustomerKeyAttributeStrategy();
		} else {
			String possibleValues = CustomerConstants.KEY_STATE +", "+
				CustomerConstants.CUSTOMER_TYPE+", "+
				CustomerConstants.CONVENTION+", "+
				CustomerConstants.LAST_MAIL_DATE;
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.INVALID_ATTRIBUTE_KEY,
					new Object[] { keyType, possibleValues }, logger);
		}

	}

	/**
	 * @return Returns the customerKeyAttributeStrategy.
	 */
	private KeyAttributeStrategy getCustomerKeyAttributeStrategy() {
		return customerKeyAttributeStrategy;
	}

	/**
	 * @param customerKeyAttributeStrategy
	 *            The customerKeyAttributeStrategy to set.
	 */
	public void setCustomerKeyAttributeStrategy(
			KeyAttributeStrategy customerKeyAttributeStrategy) {
		this.customerKeyAttributeStrategy = customerKeyAttributeStrategy;
	}

	/**
	 * @return Returns the statusKeyAttributeStrategy.
	 */
	private KeyAttributeStrategy getStatusKeyAttributeStrategy() {
		return statusKeyAttributeStrategy;
	}

	/**
	 * @param statusKeyAttributeStrategy
	 *            The statusKeyAttributeStrategy to set.
	 */
	public void setStatusKeyAttributeStrategy(
			KeyAttributeStrategy statusKeyAttributeStrategy) {
		this.statusKeyAttributeStrategy = statusKeyAttributeStrategy;
	}

}
