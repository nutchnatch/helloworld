/*
 * Created on Jul 30, 2009
 */
package com.bnppa.sesame.authaccount;

import java.util.Calendar;

import com.bnppa.sesame.account.AccountEBO;
import com.bnppa.sesame.keystatus.KeyStatusEBO;

/**
 * @author bellidori
 * @version Jul 30, 2009
 */
public class CustomerAuthAccountEBO extends AuthAccountEBO {

	/**
	 * Comment for <code>serialVersionUID</code>
	 */
	private static final long	serialVersionUID	= 1L;

	private String				convention;

	private String				customerType;

	private Integer				keyState;

	private Calendar			lastMailDt;

	private KeyStatusEBO		keyStatus;


	/**
	 * @param authLevel
	 * @param login
	 * @param syst
	 * @param authType
	 * @param convention
	 * @param customerType
	 * @param keyState
	 * @param lastMailDt
	 * @param account
	 */
	protected CustomerAuthAccountEBO(Integer authLevel, String login,
			String syst, String authType, String convention,
			String customerType, Integer keyState, Calendar lastMailDt,
			AccountEBO account) {
		super(authLevel, login, syst, authType, account);
		this.convention = convention;
		this.customerType = customerType;
		this.keyState = keyState;
		this.lastMailDt = lastMailDt;
	}
	
	/**
	 * GETTER AND SETTERS
	 */

	public Integer getKeyState() {
		return keyState;
	}

	public String getConvention() {
		return convention;
	}

	public String getCustomerType() {
		return customerType;
	}

	public Calendar getLastMailDt() {
		return lastMailDt;
	}

	protected void setKeyState(Integer keyState) {
		this.keyState = keyState;
	}

	protected void setConvention(String convention) {
		this.convention = convention;
	}

	protected void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	protected void setLastMailDt(Calendar lastMailDt) {
		this.lastMailDt = lastMailDt;
	}
	protected void setKeyStatus(KeyStatusEBO kse) {
		this.keyStatus = kse;
	}
	protected KeyStatusEBO getKeyStatus() {
		return keyStatus;
	}

}
