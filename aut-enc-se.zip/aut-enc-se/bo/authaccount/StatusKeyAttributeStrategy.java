/*
 * Created on Mar 23, 2010
 */
package com.bnppa.sesame.authaccount;

import java.util.Calendar;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bnppa.sesame.ClientKeyStatusHistoryDAOFacade;
import com.bnppa.sesame.ClientKeyStatusHistoryTO;
import com.bnppa.sesame.account.AccountEBO;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.UnsupportedActionBOException;
import com.bnppa.sesame.keystatus.KeyStatusEBO;
import com.bnppa.sesame.keystatus.KeyStatusSBO;

/**
 * @author behatemo
 * @version Mar 23, 2010
 */
public class StatusKeyAttributeStrategy implements KeyAttributeStrategy {

	private static final Log				logger	= LogFactory
															.getLog(StatusKeyAttributeStrategy.class);

	private KeyStatusSBO					keyStatusSBO;

	private ClientKeyStatusHistoryDAOFacade	keyStatusHistoryDAOFacade;

	/**
	 * @author behatemo
	 * @version Mar 23, 2010
	 * @see com.bnppa.sesame.authaccount.KeyAttributeStrategy#doSetAttribute(com.bnppa.sesame.authaccount.CustomerAuthAccountEBO,
	 *      java.lang.String, java.lang.String, com.bnppa.sesame.account.AccountEBO)
	 */
	public void doSetAttribute(CustomerAuthAccountEBO customerAuthAccountEBO,
			String key, String value, AccountEBO updatorAccountEBO) throws UnsupportedActionBOException,
			InvalidParameterBOException {
		if (StringUtils.isBlank(value) || !isLong(value)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.INVALID_ATTRIBUTE_VALUE,
					new String[] { value, key }, logger);
		}

		KeyStatusEBO kse = getKeyStatusSBO().find(Integer.valueOf(value));

		if (kse == null) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.KEY_STATUS_NOT_EXIST, new Object[] {key},
					logger);
		}

		customerAuthAccountEBO.setKeyStatus(kse);
		if (kse != null && kse.getId() != null) {
			customerAuthAccountEBO.setKeyState(kse.getId());
		}
		
		customerAuthAccountEBO.getAccount().setUpdatorId(updatorAccountEBO.getId());

		saveHistory(customerAuthAccountEBO);

	}
	
	/**
	 * @see com.bnppa.sesame.authaccount.KeyAttributeStrategy#doSetAttribute(com.bnppa.sesame.authaccount.CustomerAuthAccountEBO,
	 *      java.lang.String, java.lang.String,
	 *      com.bnppa.sesame.account.AccountEBO, boolean)
	 */
	public void doSetAttribute(CustomerAuthAccountEBO customerAuthAccountEBO,
			String key, String value, AccountEBO updatorAccountEBO, boolean isAdvanced)
			throws UnsupportedActionBOException, InvalidParameterBOException {
		doSetAttribute(customerAuthAccountEBO, key, value, updatorAccountEBO);
	}

	private boolean isLong(String s) {
		boolean b = StringUtils.isNumeric(s);
		try {
			Long.parseLong(s);
		} catch (Exception e) {
			b = false;
		}
		return b;
	}

	/**
	 * Create history for customer key status
	 * 
	 * @param customerAuthAccountEBO
	 */
	private void saveHistory(CustomerAuthAccountEBO customerAuthAccountEBO) {
		Integer oldKeyStatusId = null;

		oldKeyStatusId = getKeyStatus(customerAuthAccountEBO).getId();

		getKeyStatusHistoryDAOFacade().create(new ClientKeyStatusHistoryTO(customerAuthAccountEBO.getLogin(),oldKeyStatusId, Calendar.getInstance()));
	}
	
	/**
	 * @return Returns the keyStatus.
	 */
	protected KeyStatusEBO getKeyStatus(CustomerAuthAccountEBO caae) {
		if (caae.getKeyStatus() == null) {
			KeyStatusEBO kse = keyStatusSBO.find(caae.getKeyState());
			caae.setKeyStatus(kse);
			if (kse != null && kse.getId() != null) {
				caae.setKeyState(kse.getId());
			}
		}
		return caae.getKeyStatus();
	}

	/**
	 * @return Returns the keyStatusSBO.
	 */
	private KeyStatusSBO getKeyStatusSBO() {
		return keyStatusSBO;
	}

	/**
	 * @param keyStatusSBO
	 *            The keyStatusSBO to set.
	 */
	public void setKeyStatusSBO(KeyStatusSBO keyStatusSBO) {
		this.keyStatusSBO = keyStatusSBO;
	}

	/**
	 * @return Returns the keyStatusHistoryDAOFacade.
	 */
	public ClientKeyStatusHistoryDAOFacade getKeyStatusHistoryDAOFacade() {
		return keyStatusHistoryDAOFacade;
	}

	/**
	 * @param keyStatusHistoryDAOFacade
	 *            The keyStatusHistoryDAOFacade to set.
	 */
	public void setKeyStatusHistoryDAOFacade(
			ClientKeyStatusHistoryDAOFacade keyStatusHistoryDAOFacade) {
		this.keyStatusHistoryDAOFacade = keyStatusHistoryDAOFacade;
	}

}
