/*
 * Created on Mar 16, 2009
 *
 */
package com.bnppa.sesame.authaccount;

import java.util.Calendar;

import org.apache.commons.lang.builder.CompareToBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bnppa.sesame.AuthAccountIdTO;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.ebo.AbstractEBO;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.message.Messages;

/**
 * @author bellidori
 * @version 1.0,Mar 16, 2009
 */

public class PasswordEBO extends AbstractEBO {

	/**
	 * Comment for <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = 1L;

	private static final Log logger = LogFactory.getLog(PasswordEBO.class);

	/**
	 * password used by owner to authenticate
	 */
	private byte[] password;

	/**
	 * number of password update
	 */
	private Integer updateNo;

	/**
	 * date of password update
	 */
	private Calendar updateDate;

	/**
	 * account who updated password, managed in lazy initialization
	 */
	private AuthAccountEBO updator;

	/**
	 * expiration date
	 */
	private Calendar expiryDate;

	/**
	 * login of updator
	 */
	private AuthAccountIdTO updatorId;
	/**
	 * crypto salt
	 */
	private byte[] salt;
	/**
	 * crypto algorithm
	 */
	private String algorithm;

	/**
	 * @param password
	 *            password
	 * @param updateNo
	 *            number of password's change
	 * @param updateDate
	 *            date of password's change
	 * @param accountWhoUpdated
	 *            account who updated password
	 * 
	 * @param expiryDt
	 *            date of password's expiration
	 */
	protected PasswordEBO(byte[] password, Integer updateNo, Calendar updateDate, AuthAccountEBO accountWhoUpdated, Calendar expiryDt,
			byte[] salt, String algorithm) {
		super();
		this.setPassword(password);
		this.setUpdator(accountWhoUpdated);
		this.setUpdatorLogin(new AuthAccountIdTO(accountWhoUpdated.getLogin(), accountWhoUpdated.getAuthType()));
		this.setUpdateDate(updateDate);
		this.setExpiryDate(expiryDt);
		this.setUpdateNo(updateNo);
		this.setSalt(salt);
		this.setAlgorithm(algorithm);
	}

	/**
	 * create a password EBO. Manage updator in lazy initialization
	 * 
	 * @param password
	 *            password
	 * @param updateNo
	 *            number of password's change
	 * @param updateDate
	 *            date of password's change
	 * @param updatorLogin
	 *            updator's login
	 * @param expiryDt
	 *            date of password's expiration
	 * @param salt
	 *            crypto salt
	 * @param crypto
	 *            algorithm
	 */
	protected PasswordEBO(byte[] password, Integer updateNo, Calendar updateDate, AuthAccountIdTO updatorId, Calendar expiryDt,
			byte[] salt, String algorithm) {
		super();
		this.setPassword(password);
		this.setUpdatorLogin(updatorId);
		this.setUpdateDate(updateDate);
		this.setExpiryDate(expiryDt);
		this.setUpdateNo(updateNo);
		this.setSalt(salt);
		this.setAlgorithm(algorithm);
	}

	/**
	 * GETTER AND SETTER
	 */
	private void setExpiryDate(Calendar expiryDate) {
		if (expiryDate == null) {
			throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.PASSWORD_EXPIRY_DATE_IS_NULL, logger);
		}
		this.expiryDate = expiryDate;
	}

	public Calendar getExpiryDate() {
		return expiryDate;
	}

	protected void setUpdator(AuthAccountEBO accountWhoUpdated) {
		if (accountWhoUpdated == null) {
			throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.PASSWORD_UPDATOR_IS_NULL,
					new String[] { this.toString() }, logger);
		}
		this.updator = accountWhoUpdated;
	}

	protected AuthAccountEBO getUpdator() {
		return this.updator;
	}

	private void setPassword(byte[] password) {
		if (password == null || password.length <= 0 || new String(password).trim().length() == 0) {
			throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.PASSWORD_IS_BLANK,
					password == null ? null : new String[] { password.toString() }, logger);
		}
		this.password = password;
	}

	private void setUpdateDate(Calendar updateDate) {
		if (updateDate == null) {
			throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.PASSWORD_UPDATING_IS_NULL, logger);
		}
		this.updateDate = updateDate;
	}

	public byte[] getPassword() {
		return password;
	}

	public Integer getUpdateNo() {
		return updateNo;
	}

	public Calendar getUpdateDate() {
		return updateDate;
	}

	private void setUpdateNo(Integer updateNo) {
		if (updateNo == null) {
			throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.PASSWORD_NUMBER_IS_NULL, logger);
		}
		if (updateNo.intValue() < 1) {
			throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.PASSWORD_NUMBER_IS_WRONG,
					new String[] { updateNo.toString() }, logger);
		}
		this.updateNo = updateNo;
	}

	protected AuthAccountIdTO getUpdatorId() {
		return updatorId;
	}

	private void setUpdatorLogin(AuthAccountIdTO updatorId) {
		this.updatorId = updatorId;
	}

	/**
	 * UTILITY METHOD
	 */

	/**
	 * @return the salt
	 */
	public byte[] getSalt() {
		return salt;
	}

	/**
	 * @return the algorithm
	 */
	public String getAlgorithm() {
		return algorithm;
	}

	/**
	 * @param salt
	 *            the salt to set
	 */
	public void setSalt(byte[] salt) {
		this.salt = salt;
	}

	/**
	 * @param algorithm
	 *            the algorithm to set
	 */
	public void setAlgorithm(String algorithm) {
		this.algorithm = algorithm;
	}

	/**
	 * Indicates whether some other object is "equal to" this one by comparing : <br>
	 * - updateNumber <br>
	 * password <br>
	 * - updateDate <br>
	 * accountWhoUpdated
	 * 
	 * @author bellidori
	 * @version 1.0,16/03/2009
	 * @param obj
	 *            object to compare with this object
	 * @return <br>
	 *         - true if obj is equal to this one <br>
	 *         - false if obj is null, or obj is not instance of PasswordBO, or
	 *         is different
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 * @see org.apache.commons.lang.builder.EqualsBuilder
	 * 
	 */
	public boolean equals(Object obj) {
		final Boolean ret = this.baseEquals(obj);
		if(ret != null) {
			return ret;
		}
		PasswordEBO objectToCompare = (PasswordEBO) obj;
		return new EqualsBuilder().append(this.getUpdateNo(), objectToCompare.getUpdateNo())
				.append(this.getPassword(), objectToCompare.getPassword()).append(this.getUpdateDate(), objectToCompare.getUpdateDate())
				.append(this.getUpdatorId(), objectToCompare.getUpdatorId()).isEquals();

	}

	/**
	 * Returns a hash code value for the object by using :<br>
	 * - owner <br>
	 * - updateNo
	 * 
	 * @return a hash code value for this object.
	 * 
	 * @see java.lang.Object#hashCode()
	 * @see org.apache.commons.lang.builder.HashCodeBuilder
	 * @author bellidori
	 * @version 1.0,16/03/2009
	 * 
	 */
	public int hashCode() {
		return new HashCodeBuilder(17, 37).append(this.getUpdateNo()).toHashCode();

	}

	/**
	 * produce a toString of the format: PasswordBO@7f54[password's update
	 * no=,updated on=,updated by=]
	 * 
	 * @return a string representation of the object
	 * 
	 * @see java.lang.Object#toString()
	 * @see org.apache.commons.lang.builder.ToStringBuilder
	 * @author bellidori
	 * @version 1.0,16/03/2009
	 */
	public String toString() {
		return new ToStringBuilder(this).append(Messages.getString("PasswordEBO.updateNo"), this.getUpdateNo()).append( //$NON-NLS-1$
				Messages.getString("PasswordEBO.updatedOn"), this.getUpdateDate()).toString(); //$NON-NLS-1$

	}

	/**
	 * compare fields in the order list : updateNo
	 * 
	 * @param o
	 *            object to compare
	 * 
	 * @return <br>
	 *         - negative number if this object is before o <br>
	 *         - 0 if this object equals to o <br>
	 *         - positive number if this object is after o
	 * @author bellidori
	 * @version 1.5, 09/09/08
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 * @see org.apache.commons.lang.builder.CompareToBuilder
	 * @throws NullPointerException
	 *             if o is null
	 * @throws ClassCastException
	 *             if o is not an instance of Role
	 * 
	 */
	public int compareTo(Object o) {

		PasswordEBO objectToCompare = (PasswordEBO) o;
		return new CompareToBuilder().append(this.getUpdateNo(), objectToCompare.getUpdateNo()).toComparison();

	}
}