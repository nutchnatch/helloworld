/*
 * Created on Aug 6, 2009
 *
 */
package com.bnppa.sesame.authaccount;



/**
 * @author polancoro
 * @version Aug 6, 2009
 * 
 */
public class LowSecurityRulesStrategy extends SecurityRulesStrategyImpl {

	/**
	 * Comment for <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = 1L;

	private final static int MINIMAL_PWD_LENGHT = 8;

	private final static int MAXIMAL_PWD_LENGHT = 8;

	private final static int MINIMAL_LOWER_LETTERS = 2;
	
	private final static int MAXIMAL_LOWER_LETTERS = -1;
	
	private final static int MINIMAL_UPPER_LETTERS = 0;
	
	private final static int MAXIMAL_UPPER_LETTERS = 0;

	private final static int MINIMAL_NUMBERS = 2;
	
	private final static int MAXIMAL_NUMBERS = -1;

	private final static int MINIMAL_SPECIAL_CHARS = 1;
	
	private final static int MAXIMAL_SPECIAL_CHARS = 1;

	private final static int passwordValidityTimeLimit;
	
	private final static int numberOldPwdToCompare;
	
	private static final String NUMBER_OLD_PWD_TO_COMPARE_PROPERTY_NAME = "nb.old.password.to.compare";
	
	private static final String PASSWORD_VALIDITY_TIME_LIMIT_PROPERTY_NAME = "password.validity.time";
	
	static {
		passwordValidityTimeLimit = Integer.valueOf(strategyProperties.getProperty(PASSWORD_VALIDITY_TIME_LIMIT_PROPERTY_NAME)).intValue();
		numberOldPwdToCompare = Integer.valueOf(strategyProperties.getProperty(NUMBER_OLD_PWD_TO_COMPARE_PROPERTY_NAME)).intValue();
	}

	/**
	 * 
	 * create a new instance
	 * @author behatemo
	 * @version Sep 4, 2009
	 * 
	 * Default constructor 
	 * 
	 */
	public LowSecurityRulesStrategy() {
		super();
	}

	/**
	 * @author bellidori
	 * @version 3 sept. 09
	 * @see com.bnppa.sesame.authaccount.SecurityRulesStrategyImpl#getMaxLengthPassword()
	 */
	public int getMaxLengthPassword() {

		return MAXIMAL_PWD_LENGHT;
	}

	/**
	 * @author bellidori
	 * @version 3 sept. 09
	 * @see com.bnppa.sesame.authaccount.SecurityRulesStrategyImpl#getMinLengthPassword()
	 */
	public int getMinLengthPassword() {

		return MINIMAL_PWD_LENGHT;
	}

	/**
	 * @author bellidori
	 * @version 3 sept. 09
	 * @see com.bnppa.sesame.authaccount.SecurityRulesStrategyImpl#getMinNumberAlphaCharacters()
	 */
	public int getMinNumberLowerAlphaCharacters() {

		return MINIMAL_LOWER_LETTERS;
	}

		
	/**
	 * @author bellidori
	 * @version 3 sept. 09
	 * @see com.bnppa.sesame.authaccount.SecurityRulesStrategyImpl#getMinNumberNumericCharacters()
	 */
	public int getMinNumberNumericCharacters() {

		return MINIMAL_NUMBERS;
	}

	/**
	 * @author bellidori
	 * @version 3 sept. 09
	 * @see com.bnppa.sesame.authaccount.SecurityRulesStrategyImpl#getMinNumberSpecialCharacters()
	 */
	public int getMinNumberSpecialCharacters() {

		return MINIMAL_SPECIAL_CHARS;
	}

	/**
	 * @author bellidori
	 * @version 3 sept. 09
	 * @see com.bnppa.sesame.authaccount.SecurityRulesStrategyImpl#getPasswordValidityTimeLimit()
	 */
	public int getPasswordValidityTimeLimit() {
		return passwordValidityTimeLimit;
	}

	/**
	 * @author bellidori
	 * @version 3 sept. 09
	 * @see com.bnppa.sesame.authaccount.SecurityRulesStrategyImpl#getNumberOldPwdToCompare()
	 */
	public int getNumberOldPwdToCompare() {
		return numberOldPwdToCompare;
	}
	 
	/**
	 * @author marotph
	 * @version 24 fev 2010
	 * @see com.bnppa.sesame.authaccount.SecurityRulesStrategyImpl#getMaxNumberLowerAlphaCharacters()
	 */
	public int getMaxNumberLowerAlphaCharacters() {
		return MAXIMAL_LOWER_LETTERS;
	}

	/**
	 * @author marotph
	 * @version 24 fev 2010
	 * @see com.bnppa.sesame.authaccount.SecurityRulesStrategyImpl#getMaxNumberNumericCharacters()
	 */
	public int getMaxNumberNumericCharacters() {
		return MAXIMAL_NUMBERS;
	}

	/**
	 * @author marotph
	 * @version 24 fev 2010
	 * @see com.bnppa.sesame.authaccount.SecurityRulesStrategyImpl#getMaxNumberSpecialCharacters()
	 */
	public int getMaxNumberSpecialCharacters() {
		return MAXIMAL_SPECIAL_CHARS;
	}

	/**
	 * @author marotph
	 * @version 24 fev 2010
	 * @see com.bnppa.sesame.authaccount.SecurityRulesStrategyImpl#getMaxNumberUpperAlphaCharacters()
	 */
	public int getMaxNumberUpperAlphaCharacters() {
		return MAXIMAL_UPPER_LETTERS;
	}

	/**
	 * @author marotph
	 * @version 24 fev 2010
	 * @see com.bnppa.sesame.authaccount.SecurityRulesStrategyImpl#getMinNumberUpperAlphaCharacters()
	 */
	public int getMinNumberUpperAlphaCharacters() {
		return MINIMAL_UPPER_LETTERS;
	}

}
