/*
 * Created on Aug 28, 2009
 *
 */
package com.bnppa.sesame.authaccount;

import java.util.Calendar;

import org.springframework.beans.factory.annotation.Autowired;

import com.bnppa.sesame.AuthAccountIdTO;
import com.bnppa.sesame.PasswordTO;
import com.bnppa.sesame.mapper.AbstractMapper;

/**
 * @author polancoro
 * @version Aug 28, 2009
 * 
 */
public class PasswordMapper extends AbstractMapper<PasswordTO, PasswordEBO> {

	@Autowired
	private PasswordSBO passwordSBO;

	/**
	 * @return the passwordSBO
	 */
	protected PasswordSBO getPasswordSBO() {
		return passwordSBO;
	}

	/**
	 * @param passwordSBO
	 *            the passwordSBO to set
	 */
	protected void setPasswordSBO(PasswordSBO passwordSBO) {
		this.passwordSBO = passwordSBO;
	}

	/**
	 * @author polancoro
	 * @version Aug 28, 2009
	 * @see com.bnppa.sesame.mapper.Mapper#mapEBOtoTO(java.lang.Object,
	 *      java.lang.Object)
	 */
	public PasswordTO mapEBOtoTO(PasswordEBO sourceObject, Object ownerObject) {
		if (sourceObject == null) {
			return null;
		}
		AuthAccountEBO ownerEBO = (AuthAccountEBO) ownerObject;

		AuthAccountIdTO owner = new AuthAccountIdTO(ownerEBO.getLogin(), ownerEBO.getAuthType());

		byte[] password = sourceObject.getPassword();
		Integer updateNo = sourceObject.getUpdateNo();
		Calendar expiryDt = sourceObject.getExpiryDate();
		Calendar updateDate = sourceObject.getUpdateDate();
		AuthAccountIdTO updator = new AuthAccountIdTO(passwordSBO.getUpdator(sourceObject).getLogin(), passwordSBO.getUpdator(sourceObject)
				.getAuthType());

		PasswordTO passwordTO = new PasswordTO(owner, password, updateNo, expiryDt, updateDate, updator, sourceObject.getSalt(),
				sourceObject.getAlgorithm());

		return passwordTO;
	}

	/**
	 * @author polancoro
	 * @version Aug 28, 2009
	 * @see com.bnppa.sesame.mapper.Mapper#mapTOtoEBO(java.lang.Object)
	 */
	public PasswordEBO mapTOtoEBO(PasswordTO sourceObject) {

		if (sourceObject == null) {
			return null;
		}
		// Dans la base, c'est l'identifiant du compte et non le login qui est
		// stock�. Or on a besoin d'un login pour chercher l'EBO.
		PasswordTO to = (PasswordTO) sourceObject;
		AuthAccountIdTO authAcountIdTO = new AuthAccountIdTO(LoginStrategyFactory.create(sourceObject.getUpdator().getAuthType()).createLogin(
				to.getUpdator().getLogin()), to.getUpdator().getAuthType());

		return new PasswordEBO(sourceObject.getPassword(), sourceObject.getUpdateNo(), sourceObject.getCreationDt(), authAcountIdTO, sourceObject.getExpiryDt(), sourceObject.getSalt(),
				sourceObject.getAlgorithm());

	}

	/**
	 * @author bellidori
	 * @version 2 sept. 09
	 * @see com.bnppa.sesame.mapper.Mapper#mapEBOtoTO(java.lang.Object)
	 */
	public PasswordTO mapEBOtoTO(final PasswordEBO sourceObject) {
		return new PasswordTO(
				null, 
				sourceObject.getPassword(), 
				sourceObject.getUpdateNo(), 
				sourceObject.getExpiryDate(), 
				null, 
				null, 
				sourceObject.getSalt(), 
				sourceObject.getAlgorithm());
	}

	public static PasswordTO mapEBOtoTO(final AuthAccountEBO authAccountEbo) {
		final AuthAccountIdTO owner = new AuthAccountIdTO(authAccountEbo.getLogin(), authAccountEbo.getAuthType());
		final PasswordEBO sourceObject = authAccountEbo.getLastPwd();
		return new PasswordTO(
				owner, 
				sourceObject.getPassword(), 
				sourceObject.getUpdateNo(), 
				sourceObject.getExpiryDate(), 
				null, 
				null, 
				sourceObject.getSalt(), 
				sourceObject.getAlgorithm());
		
	}
}
