/**
 * 
 */
package com.bnppa.sesame.authaccount;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.ldap.LDAPAttributesKeys;

/**
 * @author bellidori
 */
public class LoginGroupStrategyImpl implements LoginStrategy {

	private static final Log	logger	= LogFactory
												.getLog(LoginGroupStrategyImpl.class);

	/**
	 * define login from accountId for group account
	 * 
	 * @see com.bnppa.sesame.authaccount.LoginStrategy#createLogin(java.lang.String)
	 */
	public String createLogin(String accountId) {
		String login;

		if (StringUtils.startsWith(accountId, LDAPAttributesKeys.UID_PREFIX)) {
			login = StringUtils.removeStart(accountId,
					LDAPAttributesKeys.UID_PREFIX);
			return login;
		}

		if (StringUtils.startsWith(accountId, LDAPAttributesKeys.UO_PREFIX)) {
			login = StringUtils.removeStart(accountId,
					LDAPAttributesKeys.UO_PREFIX);
			return login;
		}
		if (StringUtils.startsWith(accountId, LDAPAttributesKeys.GPE_PREFIX)) {
			login = StringUtils.removeStart(accountId,
					LDAPAttributesKeys.GPE_PREFIX);
			return login;
		}
		if (StringUtils.startsWith(accountId, LDAPAttributesKeys.ISOC_PREFIX)) {
			login = StringUtils.removeStart(accountId,
					LDAPAttributesKeys.ISOC_PREFIX);
			return login;
		}
		if (StringUtils.startsWith(accountId, LDAPAttributesKeys.L_PREFIX)) {
			login = StringUtils.removeStart(accountId,
					LDAPAttributesKeys.L_PREFIX);
			return login;
		}
		throw new InvalidParameterBOException(
				InvalidParameterBOExceptionConstants.ACCOUNT_ID_IS_INVALID,
				new String[] { accountId }, logger);

	}

	/**
	 * @see com.bnppa.sesame.authaccount.LoginStrategy#createAccountId(java.lang.String, java.lang.String)
	 */
	public String createAccountId(String login, String oldAccountId) throws InvalidParameterBOException {
		StringBuffer accountId;
		if (StringUtils.startsWith(oldAccountId, LDAPAttributesKeys.UID_PREFIX)) {
			accountId = new StringBuffer(LDAPAttributesKeys.UID_PREFIX);
			return accountId.append(login).toString();
		}
		if (StringUtils.startsWith(oldAccountId, LDAPAttributesKeys.UO_PREFIX)) {
			accountId = new StringBuffer(LDAPAttributesKeys.UO_PREFIX);
			return accountId.append(login).toString();
		}
		if (StringUtils.startsWith(oldAccountId, LDAPAttributesKeys.GPE_PREFIX)) {
			accountId = new StringBuffer(LDAPAttributesKeys.GPE_PREFIX);
			return accountId.append(login).toString();
		}
		if (StringUtils.startsWith(oldAccountId, LDAPAttributesKeys.ISOC_PREFIX)) {
			accountId = new StringBuffer(LDAPAttributesKeys.ISOC_PREFIX);
			return accountId.append(login).toString();
		}
		if (StringUtils.startsWith(oldAccountId, LDAPAttributesKeys.L_PREFIX)) {
			accountId = new StringBuffer(LDAPAttributesKeys.L_PREFIX);
			return accountId.append(login).toString();
		}
		throw new InvalidParameterBOException(
				InvalidParameterBOExceptionConstants.ACCOUNT_ID_IS_INVALID,
				new String[] { oldAccountId }, logger);
	}

}
