/*
 * Created on Mar 23, 2010
 *
 */
package com.bnppa.sesame.authaccount;

import com.bnppa.sesame.AuthAccountDAOFacade;
import com.bnppa.sesame.AuthAccountTO;
import com.bnppa.sesame.account.AccountEBO;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.UnsupportedActionBOException;
import com.bnppa.sesame.mapper.Mapper;

/**
 * @author behatemo
 * @version Mar 23, 2010
 * 
 */
public class CustomerAttributeStrategy implements AttributeStrategy {

	private KeyAttributeStrategyFactory keyAttributeStrategyFactory;

	private Mapper mapper;

	private AuthAccountDAOFacade customerAuthAccountDAOFacade;

	/**
	 * @author behatemo
	 * @version Mar 23, 2010
	 * @see com.bnppa.sesame.authaccount.AttributeStrategy#doAddAttribute(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      java.lang.String, java.lang.String, com.bnppa.sesame.account.AccountEBO)
	 */
	public void doAddAttribute(AuthAccountEBO authAccountEBO, String key,
			String value, AccountEBO updatorAccountEBO) throws UnsupportedActionBOException,
			InvalidParameterBOException, ClassCastException {

		CustomerAuthAccountEBO customerAuthAccountEBO = (CustomerAuthAccountEBO) authAccountEBO;

		getKeyAttributeStrategy(key).doSetAttribute(customerAuthAccountEBO,
				key, value, updatorAccountEBO);

		AuthAccountTO authAccountTO = (AuthAccountTO) getMapper().mapEBOtoTO(
				customerAuthAccountEBO);

		getCustomerAuthAccountDAOFacade().update(
				authAccountTO.getAuthAccountIdTO(), authAccountTO);
	}
	
	/**
	 * @see com.bnppa.sesame.authaccount.AttributeStrategy#doAddAttribute(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      java.lang.String, java.lang.String, com.bnppa.sesame.account.AccountEBO, boolean)
	 */
	public void doAddAttribute(AuthAccountEBO authAccountEBO, String key,
			String value, AccountEBO updatorAccountEBO, boolean isAdvanced) throws UnsupportedActionBOException,
			InvalidParameterBOException, ClassCastException {
		CustomerAuthAccountEBO customerAuthAccountEBO = (CustomerAuthAccountEBO) authAccountEBO;

		getKeyAttributeStrategy(key).doSetAttribute(customerAuthAccountEBO,
				key, value, updatorAccountEBO, isAdvanced);

		AuthAccountTO authAccountTO = (AuthAccountTO) getMapper().mapEBOtoTO(
				customerAuthAccountEBO);

		getCustomerAuthAccountDAOFacade().update(
				authAccountTO.getAuthAccountIdTO(), authAccountTO);
	}

	/**
	 * @return Returns the keyAttributeStrategy.
	 */
	private KeyAttributeStrategy getKeyAttributeStrategy(String key) {
		return getKeyAttributeStrategyFactory().create(key);
	}

	/**
	 * @return Returns the keyAttributeStrategyFactory.
	 */
	private KeyAttributeStrategyFactory getKeyAttributeStrategyFactory() {
		return keyAttributeStrategyFactory;
	}

	/**
	 * @param keyAttributeStrategyFactory
	 *            The keyAttributeStrategyFactory to set.
	 */
	public void setKeyAttributeStrategyFactory(
			KeyAttributeStrategyFactory keyAttributeStrategyFactory) {
		this.keyAttributeStrategyFactory = keyAttributeStrategyFactory;
	}

	/**
	 * @return Returns the mapper.
	 */
	private Mapper getMapper() {
		return mapper;
	}

	/**
	 * @param mapper
	 *            The mapper to set.
	 */
	public void setMapper(Mapper mapper) {
		this.mapper = mapper;
	}

	/**
	 * @return Returns the customerAuthAccountDAOFacade.
	 */
	private AuthAccountDAOFacade getCustomerAuthAccountDAOFacade() {
		return customerAuthAccountDAOFacade;
	}

	/**
	 * @param customerAuthAccountDAOFacade
	 *            The customerAuthAccountDAOFacade to set.
	 */
	public void setCustomerAuthAccountDAOFacade(
			AuthAccountDAOFacade customerAuthAccountDAOFacade) {
		this.customerAuthAccountDAOFacade = customerAuthAccountDAOFacade;
	}

}
