/*
 * Created on Aug 6, 2009
 */
package com.bnppa.sesame.authaccount;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.bnppa.sesame.MessageDescriptionBuilder;
import com.bnppa.sesame.account.AccountEBO;
import com.bnppa.sesame.channelmessage.PasswordEmailMessageSBO;
import com.bnppa.sesame.channelmessageformat.ChannelMessageFormatEBO;
import com.bnppa.sesame.constants.AuthAccountConstants;
import com.bnppa.sesame.constants.ExpiredPasswordBOExceptionConstants;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.constants.LockedAccountBOExceptionConstants;
import com.bnppa.sesame.constants.LoginBOExceptionConstants;
import com.bnppa.sesame.constants.PasswordConstants;
import com.bnppa.sesame.constants.TechnicalBOExceptionConstants;
import com.bnppa.sesame.exceptions.ExpiredPasswordBOException;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.InvalidPasswordBOException;
import com.bnppa.sesame.exceptions.LockedAccountBOException;
import com.bnppa.sesame.exceptions.LoginBOException;
import com.bnppa.sesame.exceptions.TechnicalBOException;
import com.bnppa.sesame.hash.HashAlgorithm;
import com.bnppa.sesame.hash.HashAlgorithmStrategyFactory;
import com.bnppa.sesame.services.exception.FunctionalException;
import com.bnppa.sesame.services.exception.TechnicalException;

/**
 * @author polancoro
 * @version Aug 6, 2009
 */
public class SESAuthStrategy implements AuthStrategy {

	/**
	 * Comment for <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = 1L;

	private static final Log logger = LogFactory.getLog(SESAuthStrategy.class);

	@Autowired
	@Qualifier("messageBuilder")
	private MessageDescriptionBuilder messageDescriptionBuilder;

	@Autowired
	private PasswordSBO passwordSBO;

	@Autowired
	private AuthAccountSBO authAccountSBO;

	@Autowired
	private PasswordEmailMessageSBO passwordEmailMessageSBO;

	@Autowired
	private HashAlgorithm hashAlgorithm;

	@Autowired
	private HashAlgorithmStrategyFactory hashAlgorithmStrategyFactory;


	/**
	 * create a new instance
	 * 
	 * @author polancoro
	 */
	protected SESAuthStrategy() {
		super();

	}

	/**
	 * @see com.bnppa.sesame.authaccount.AuthStrategy#doLogin(java.lang.String,
	 *      com.bnppa.sesame.authaccount.AuthAccountEBO)
	 */
	public void doLogin(String typedPassword, AuthAccountEBO authAccountEBO) throws TechnicalBOException, LoginBOException,
			InvalidParameterBOException, LockedAccountBOException, ExpiredPasswordBOException {

		isLockedAccount(authAccountEBO);

		isGoodPassword(typedPassword, authAccountEBO);

		isExpiredPassword(authAccountEBO);

		authAccountEBO.setAttemptsNumber(new Integer(0));
		authAccountSBO.updateAttemptsNumber(authAccountEBO);
		authAccountEBO.setLastConnexion(Calendar.getInstance());
		authAccountSBO.updateLastConnexion(authAccountEBO);

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void doLogin(AuthAccountEBO authAccount) throws TechnicalBOException, LoginBOException, InvalidParameterBOException,
			LockedAccountBOException, ExpiredPasswordBOException {

		this.doLogin(authAccount, false);

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void doLogin(AuthAccountEBO authAccount, final boolean bypassRefog) throws TechnicalBOException, LoginBOException, InvalidParameterBOException,
			LockedAccountBOException, ExpiredPasswordBOException {

		isLockedAccount(authAccount);
		isExpiredPassword(authAccount);

		authAccount.setLastConnexion(Calendar.getInstance());
		authAccountSBO.updateLastConnexion(authAccount);

	}
	
	/**
	 * @author behatemo
	 * @see com.bnppa.sesame.authaccount.AuthStrategy#doChangePassword(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      java.lang.String, java.lang.String)
	 */
	public void doChangePassword(AuthAccountEBO authAccountEBO, String oldPassword, String newPassword) throws LoginBOException,
			LockedAccountBOException, InvalidPasswordBOException, TechnicalBOException {

		isLockedAccount(authAccountEBO);

		isGoodPassword(oldPassword, authAccountEBO);

		doSetPassword(authAccountEBO, authAccountEBO, newPassword);

		authAccountEBO.setAttemptsNumber(new Integer(0));
		authAccountSBO.updateAttemptsNumber(authAccountEBO);
		authAccountEBO.setLastConnexion(Calendar.getInstance());
		authAccountSBO.updateLastConnexion(authAccountEBO);

	}

	private void isGoodPassword(String typedPassword, AuthAccountEBO authAccountEBO) throws LoginBOException, TechnicalBOException {
		if (StringUtils.isBlank(typedPassword)) {
			throw new LoginBOException(InvalidParameterBOExceptionConstants.PASSWORD_IS_BLANK, new String[] { typedPassword }, logger);
		}

		PasswordEBO passwordEBO = authAccountSBO.getLastPassword(authAccountEBO);
		if (passwordEBO == null) {
			throw new TechnicalBOException(TechnicalBOExceptionConstants.NO_PASSWORD, new String[] { authAccountEBO.toString() }, logger);
		}

		Integer attemptsNumber = authAccountEBO.getAttemptsNumber();
		try {
			final String passwordAlgorithm = passwordEBO.getAlgorithm();
			
			if (passwordAlgorithm == null){
				throw new TechnicalBOException(TechnicalBOExceptionConstants.ALGORITHM_NOT_DEFINED_FOR_THE_PASSWORD, new String[] { authAccountEBO.toString() }, logger);
			}
			
			hashAlgorithmStrategyFactory.getEncryptionAlgorithm(passwordAlgorithm).checkEncryptedPassword(typedPassword, passwordEBO);

			if (!passwordAlgorithm.equals(HashAlgorithmStrategyFactory.getHashEncryption())) {
				byte[] newSalt = hashAlgorithm.generateSalt();

				byte[] encryptedPwd = hashAlgorithm.encryptBlandPassword(typedPassword, newSalt);

				// TODO SCH update password when algorithm has changed
				PasswordEBO lastPwd = new PasswordEBO(encryptedPwd, passwordEBO.getUpdateNo(), Calendar.getInstance(), authAccountEBO,
						passwordEBO.getExpiryDate(), newSalt, HashAlgorithmStrategyFactory.getHashEncryption());
				authAccountEBO.setLastPwd(lastPwd);
				//doResetPassword(authAccountEBO, authAccountEBO);
				this.passwordSBO.update(authAccountEBO);
				this.authAccountSBO.setLastPassword(authAccountEBO, lastPwd);
			}
		} catch (TechnicalException e) {
			throw new TechnicalBOException(e.getMessage(), new String[] { authAccountEBO.toString() }, logger);
		} catch (FunctionalException e) {
			authAccountEBO.setAttemptsNumber(new Integer(attemptsNumber.intValue() + 1));
			authAccountSBO.updateAttemptsNumber(authAccountEBO);
			// check if the max attempts number has been reached
			attemptsNumber = authAccountEBO.getAttemptsNumber();
			if ((PasswordConstants.MAX_ATTEMPS_NUMBER.compareTo(attemptsNumber) <= 0)) {
				logger.warn(messageDescriptionBuilder.build(LockedAccountBOExceptionConstants.AUTHENTICATION_ACCOUNT_HAS_BEEN_LOCKED,
						new String[] { authAccountEBO.toString(), PasswordConstants.MAX_ATTEMPS_NUMBER.toString() }));
			}

			throw new LoginBOException(LoginBOExceptionConstants.PASSWORD_IS_WRONG, new String[] { authAccountEBO.toString() }, logger);
		}
	}

	private void isLockedAccount(AuthAccountEBO authAccountEBO) throws LockedAccountBOException, TechnicalBOException {

		// Check if the user is not the sesame locked cache
		// If he failed too much in a strong authentication process like TOTP
		if (authAccountSBO.isLockedInCache(authAccountEBO.getLogin())) {
			throw new LockedAccountBOException(LockedAccountBOExceptionConstants.ACCOUNT_IS_LOCKED, new String[] {
					authAccountEBO.getLogin(), authAccountSBO.findLockedInCache(authAccountEBO.getLogin()) }, logger);
		}

		if (PasswordConstants.MAX_ATTEMPS_NUMBER.compareTo(authAccountEBO.getAttemptsNumber()) <= 0) {

			throw new LockedAccountBOException(LockedAccountBOExceptionConstants.ATTEMPTS_NUMBER_EXCEEDS_MAX_ATTEMPTS_NUMBER, new String[] {
					authAccountEBO.toString(), authAccountEBO.getAttemptsNumber().toString(),
					PasswordConstants.MAX_ATTEMPS_NUMBER.toString() }, logger);
		}

		AccountEBO accountEBO = authAccountEBO.getAccount();
		if (accountEBO.getInactiveDate() != null && Calendar.getInstance().after(accountEBO.getInactiveDate())) {
			SimpleDateFormat dateFormater = new SimpleDateFormat("dd/MM/yy", Locale.FRENCH); //$NON-NLS-1$
			throw new LockedAccountBOException(LockedAccountBOExceptionConstants.ACCOUNT_IS_INACTIVE, new String[] { accountEBO.toString(),
					dateFormater.format(accountEBO.getInactiveDate().getTime()) }, logger);
		}
	}

	private void isExpiredPassword(AuthAccountEBO authAccountEBO) throws ExpiredPasswordBOException, TechnicalBOException {
		PasswordEBO passwordEBO = authAccountSBO.getLastPassword(authAccountEBO);
		if (Calendar.getInstance().after(passwordEBO.getExpiryDate())) {
			throw new ExpiredPasswordBOException(ExpiredPasswordBOExceptionConstants.PASSWORD_HAS_EXPIRED,
					new String[] { authAccountEBO.toString() }, logger);
		}
	}

	/**
	 * @author bellidori
	 * @see com.bnppa.sesame.authaccount.AuthStrategy#doSetPassword(AuthAccountEBO,
	 *      AuthAccountEBO)
	 */
	public String doSetPassword(AuthAccountEBO authAccount, AuthAccountEBO updator) throws InvalidParameterBOException,
			TechnicalBOException {
		return passwordSBO.create(authAccount, updator);

	}

	/**
	 * @author bellidori
	 * @see com.bnppa.sesame.authaccount.AuthStrategy#doSetPassword(AuthAccountEBO,
	 *      AuthAccountEBO, String)
	 */
	public void doSetPassword(AuthAccountEBO authAccount, AuthAccountEBO updator, String password) throws InvalidParameterBOException,
			InvalidPasswordBOException, TechnicalBOException {
		if (AuthAccountConstants.TYPE_CLIENT.equals(authAccount.getAuthType())) {
			String customerType = ((CustomerAuthAccountEBO) authAccount).getCustomerType();
			authAccount.getSecurityRulesStrategy().checkPwdClient(password, authAccountSBO.getPasswords(authAccount), customerType);
		} else {
			if (authAccount.getSecurityRulesStrategy().checkPwd(password, authAccountSBO.getPasswords(authAccount)));
		}
		passwordSBO.create(authAccount, password, updator);
	}

	/**
	 * @author behatemo
	 * @see com.bnppa.sesame.authaccount.AuthStrategy#doResetAndSendPassword(AuthAccountEBO,
	 *      AuthAccountEBO, ChannelMessageFormatEBO, Map, Calendar)
	 */
	@Override
	public void doResetAndSendPassword(AuthAccountEBO owner, AuthAccountEBO updator, ChannelMessageFormatEBO channelMessageFormatEBO,
			Map<String, String> parameters, Calendar sendingDate) throws InvalidParameterBOException, TechnicalBOException {

		doSetPassword(owner, updator);
		passwordEmailMessageSBO.create(owner, channelMessageFormatEBO, parameters, sendingDate);
		owner.setAttemptsNumber(new Integer(0));
		authAccountSBO.updateAttemptsNumber(owner);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bnppa.sesame.authaccount.AuthStrategy#doSetPwdExperyDate(com.bnppa
	 * .sesame.authaccount.AuthAccountEBO,
	 * com.bnppa.sesame.authaccount.AuthAccountEBO, java.util.Calendar)
	 */
	public void doSetPwdExperyDate(AuthAccountEBO authAccount, AuthAccountEBO updator, Calendar expiryDate) {
		passwordSBO.updateLastPasswordExpiryDate(authAccount, updator, expiryDate);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bnppa.sesame.authaccount.AuthStrategy#doResetPassword(com.bnppa.sesame
	 * .authaccount.AuthAccountEBO, com.bnppa.sesame.authaccount.AuthAccountEBO)
	 */
	public String doResetPassword(AuthAccountEBO owner, AuthAccountEBO updator) throws InvalidParameterBOException, TechnicalBOException {
		String password = doSetPassword(owner, updator);
		owner.setAttemptsNumber(new Integer(0));
		authAccountSBO.updateAttemptsNumber(owner);

		return password;
	}

}
