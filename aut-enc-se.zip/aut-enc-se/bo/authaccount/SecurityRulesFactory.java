/*
 * Created on 31 ao�t 09
 *
 */
package com.bnppa.sesame.authaccount;

import org.springframework.context.ApplicationContext;

import com.bnppa.sesame.constants.AuthAccountConstants;
import com.bnppa.sesame.utils.AppContext;

/**
 * @author bellidori
 * @version 31 ao�t 09
 * 
 */
public class SecurityRulesFactory {
	/**
	 * create a implemententation of SecurityRulesStrategy by the value of level
	 * 
	 * @param level
	 *            of authentication. It must be equals to
	 *            <code>AuthAccountConstants.LEVEL_LOW</code>(LOW) or
	 *            <code>AuthAccountConstants.LEVEL_MIDDLE</code>(MIDDLE), or
	 *            <code>AuthAccountConstants.LEVEL_STRONG</code>(STRONG)
	 * @return LowSecurityRulesStrategy if level is equals to
	 *         <code>AuthAccountConstants.LEVEL_LOW</code> <br>
	 *         or MidSecurityRulesStrategy if level is equals to
	 *         <code>AuthAccountConstants.LEVEL_MIDDLE</code> <br>
	 *         or null
	 */
	protected static SecurityRulesStrategy create(Integer level) {
		final ApplicationContext appContext = AppContext.getApplicationContext();
		
		if (AuthAccountConstants.LEVEL_LOW.equals(level))
			return (SecurityRulesStrategy) appContext.getBean("LowSecurityRulesStrategy");

		if (AuthAccountConstants.LEVEL_MIDDLE.equals(level))
			return (SecurityRulesStrategy) appContext.getBean("MidSecurityRulesStrategy");

		return null;
	}
}
