/*
 * Created on Aug 6, 2009
 *
 */
package com.bnppa.sesame.authaccount;

import java.util.Arrays;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnppa.sesame.REFOGAccountDAOFacade;
import com.bnppa.sesame.channelmessageformat.ChannelMessageFormatEBO;
import com.bnppa.sesame.constants.ExpiredPasswordBOExceptionConstants;
import com.bnppa.sesame.constants.LockedAccountBOExceptionConstants;
import com.bnppa.sesame.constants.LoginBOExceptionConstants;
import com.bnppa.sesame.constants.TechnicalBOExceptionConstants;
import com.bnppa.sesame.constants.UnAuthorizedActionBOExceptionConstants;
import com.bnppa.sesame.emailaddr.EmailAddressEBO;
import com.bnppa.sesame.emailaddr.EmailAddressSBO;
import com.bnppa.sesame.exceptions.ExpiredPasswordBOException;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.InvalidPasswordBOException;
import com.bnppa.sesame.exceptions.LockedAccountBOException;
import com.bnppa.sesame.exceptions.LoginBOException;
import com.bnppa.sesame.exceptions.TechnicalBOException;
import com.bnppa.sesame.exceptions.UnAuthorizedActionBOException;
import com.bnppa.sesame.ldap.LDAPAttributesKeys;
import com.bnppa.sesame.ldap.LDAPAuthConstants;
import com.bnppa.sesame.ldap.LDAPDataAccessException;
import com.bnppa.sesame.person.PersonEBO;

/**
 * @author polancoro
 * @version Aug 6, 2009
 * 
 */
public class REFOGAuthStrategy implements AuthStrategy {

	/**
	 * Comment for <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = 1L;

	private static final Log logger = LogFactory
			.getLog(REFOGAuthStrategy.class);

	@Autowired
	private REFOGAccountDAOFacade refogAccountDAOFacade;
	
	@Autowired
	private AuthAccountSBO authAccountSBO;

	@Autowired
	private EmailAddressSBO emailAddressSBO;

	/**
	 * 
	 * create a new instance
	 * 
	 * @author behatemo
	 * @version Sep 4, 2009
	 * 
	 * Default constructor
	 * 
	 */
	protected REFOGAuthStrategy() {

	}

	/**
	 * @throws LoginBOException
	 * @throws ExpiredPasswordBOException
	 * @throws TechnicalBOException
	 * @throws LockedAccountBOException 
	 * @see com.bnppa.sesame.authaccount.AuthStrategy#doLogin(java.lang.String,
	 *      com.bnppa.sesame.authaccount.AuthAccountEBO)
	 */
	public void doLogin(String password, AuthAccountEBO authAccountEBO)
			throws LoginBOException, ExpiredPasswordBOException,
			TechnicalBOException, LockedAccountBOException {

		try {
			Map<String,Object> refsgData = refogAccountDAOFacade.authentify(authAccountEBO.getLogin(), password);
			
			authAccountEBO = enrichedAuthAccountEBOWithRefsgData(authAccountEBO, refsgData);
		} catch (LDAPDataAccessException e) {
			int authStatus = e.getReason();
			if (authStatus == LDAPAuthConstants.PASSWORD_INVALID) {
				throw new LoginBOException(
						LoginBOExceptionConstants.PASSWORD_IS_WRONG, new String[] {
								authAccountEBO.toString() }, logger);
			} else if (authStatus == LDAPAuthConstants.PASSWORD_EXPIRED) {
				throw new ExpiredPasswordBOException(
						ExpiredPasswordBOExceptionConstants.PASSWORD_HAS_EXPIRED,
						new String[] {  authAccountEBO.toString() },
						logger);
			} else if (authStatus == LDAPAuthConstants.INTERNAL_ERROR) {
				throw new TechnicalBOException(
						TechnicalBOExceptionConstants.TECHNICAL_ERROR,
						new String[] {  authAccountEBO.toString() },
						logger);
			} else if (authStatus == LDAPAuthConstants.PASSWORD_OTHER) {
				throw new LockedAccountBOException(
						LockedAccountBOExceptionConstants.AUTHENTICATION_ACCOUNT_HAS_BEEN_LOCKED,
						new String[] {  authAccountEBO.toString() },
						logger);
			} else {
				throw e;
			}
			
		}
		
	}
	
	/**
	 * 
	 * @param authAccount
	 * @param datas
	 * @return
	 */
	private AuthAccountEBO enrichedAuthAccountEBOWithRefsgData(AuthAccountEBO authAccount, Map<String, Object> refsgData) {
		
		if (authAccount == null || authAccount.getAccount() == null || authAccount.getAccount().getPerson()==null) {
			return authAccount;
		}
		
		PersonEBO person = authAccount.getAccount().getPerson();

		for (Entry<String, Object> entry : refsgData.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			
			if(LDAPAttributesKeys.GIVEN_NAME.equals(key)) {
				person.setFirstName((String) value);
				
			} else if(LDAPAttributesKeys.SN.equals(key)) {
				person.setLastName((String) value);
				
			} else if(LDAPAttributesKeys.MAIL.equals(key)) {
				EmailAddressEBO emailAddress = emailAddressSBO.create((String) value);
				Set<EmailAddressEBO> emailAddresses = new HashSet<>(Arrays.asList(emailAddress));
				person.setEmailAddresses(emailAddresses);
			}
		}
		return authAccount;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void doLogin(AuthAccountEBO authAccount) throws TechnicalBOException, LoginBOException, InvalidParameterBOException,
			LockedAccountBOException, ExpiredPasswordBOException {

		this.doLogin(authAccount, false);

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void doLogin(AuthAccountEBO authAccount, final boolean bypassRefog) throws TechnicalBOException, LoginBOException, InvalidParameterBOException,
			LockedAccountBOException, ExpiredPasswordBOException {

		String isPasswordExpired = (String) authAccountSBO.getAttributes(authAccount, bypassRefog).get(LDAPAttributesKeys.PWD_WILL_EXPIRE);
		if (Boolean.TRUE.toString().equalsIgnoreCase(isPasswordExpired)) {
			throw new ExpiredPasswordBOException(ExpiredPasswordBOExceptionConstants.PASSWORD_HAS_EXPIRED,
					new String[] { authAccount.toString() }, logger);
		}

	}
	
	/**
	 * 
	 * @author behatemo
	 * @version Oct 6, 2009
	 * @see com.bnppa.sesame.authaccount.AuthStrategy#doChangePassword(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      java.lang.String, java.lang.String)
	 */
	public void doChangePassword(AuthAccountEBO authAccountEBO, String oldPassword, String newPassword) throws LoginBOException,
			LockedAccountBOException, InvalidPasswordBOException, TechnicalBOException {

		throw new UnAuthorizedActionBOException(UnAuthorizedActionBOExceptionConstants.CANNOT_CHANGE_LDAP_ACCOUNT_PWD,
				new String[] { authAccountEBO.getLogin() }, logger);
	}

	/**
	 * @author bellidori
	 * @version 31 ao�t 09
	 * @see com.bnppa.sesame.authaccount.AuthStrategy#doSetPassword(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      com.bnppa.sesame.authaccount.AuthAccountEBO)
	 */
	public String doSetPassword(AuthAccountEBO authAccount, AuthAccountEBO updator) {
		return "";
	}

	/**
	 * @author bellidori
	 * @version 1 sept. 09
	 * @see com.bnppa.sesame.authaccount.AuthStrategy#doSetPassword(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      com.bnppa.sesame.authaccount.AuthAccountEBO, java.lang.String)
	 */
	public void doSetPassword(AuthAccountEBO authAccount, AuthAccountEBO updator, String password) {

	}

	/**
	 * @author behatemo
	 * @version Feb 10, 2010
	 * @see com.bnppa.sesame.authaccount.AuthStrategy#doResetAndSendPassword(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      com.bnppa.sesame.channelmessageformat.ChannelMessageFormatEBO,
	 *      java.util.Map, java.util.Calendar)
	 */
	public void doResetAndSendPassword(AuthAccountEBO owner, AuthAccountEBO updator, ChannelMessageFormatEBO channelMessageFormatEBO,
			Map parameters, Calendar sendingDate) {

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bnppa.sesame.authaccount.AuthStrategy#doSetPwdExperyDate(com.bnppa
	 * .sesame.authaccount.AuthAccountEBO,
	 * com.bnppa.sesame.authaccount.AuthAccountEBO, java.util.Calendar)
	 */
	public void doSetPwdExperyDate(AuthAccountEBO authAccount, AuthAccountEBO updator, Calendar expiryDate) {

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bnppa.sesame.authaccount.AuthStrategy#doResetPassword(com.bnppa.sesame
	 * .authaccount.AuthAccountEBO, com.bnppa.sesame.authaccount.AuthAccountEBO)
	 */
	public String doResetPassword(AuthAccountEBO owner, AuthAccountEBO updator) throws InvalidParameterBOException, TechnicalBOException {
		return "";

	}

}
