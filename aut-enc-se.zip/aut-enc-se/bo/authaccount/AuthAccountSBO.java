/**
 * 
 */
package com.bnppa.sesame.authaccount;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.dao.DataAccessException;

import com.bnppa.sesame.account.AccountEBO;
import com.bnppa.sesame.account.AccountStatusEBO;
import com.bnppa.sesame.channelmessageformat.ChannelMessageFormatEBO;
import com.bnppa.sesame.exceptions.BadPasswordBOException;
import com.bnppa.sesame.exceptions.ExpiredPasswordBOException;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.InvalidPasswordBOException;
import com.bnppa.sesame.exceptions.LockedAccountBOException;
import com.bnppa.sesame.exceptions.LoginBOException;
import com.bnppa.sesame.exceptions.TechnicalBOException;
import com.bnppa.sesame.exceptions.UnAuthorizedActionBOException;
import com.bnppa.sesame.secretquestion.SecretQuestionEBO;
import com.bnppa.sesame.uaa.UserAdminAreaEBO;

/**
 * @author rochinaen
 * @author bellidori
 * @version Aug 6, 2009
 * @version 06/08/10 add
 *          findSecretResponses,findSecretResponse,addSecretResponse,removeSecretResponse
 */
public interface AuthAccountSBO {

	/**
	 * Create a auth account
	 * 
	 * @param login
	 * @param authLevel
	 * @param authSyst
	 * @param authType
	 * @param accountEBO
	 * @param connectedAuthAccount
	 * @param clientType type of the client
	 * @return AuthAccountEBO
	 * @throws InvalidParameterBOException
	 * @throws TechnicalBOException
	 * @throws InvalidPasswordBOException
	 *             if password is invalid
	 */
	public AuthAccountEBO create(String login, Integer authLevel,
			String authSyst, String authType, AccountEBO accountEBO,
			AuthAccountEBO connectedAuthAccount, String clientType)
			throws InvalidParameterBOException, TechnicalBOException,
			InvalidPasswordBOException;

	/**
	 * @param login
	 * @return AuthAccountEBO
	 * @throws InvalidParameterBOException
	 */
	public AuthAccountEBO find(String login) throws InvalidParameterBOException;
	
	/**
	 * @param login
	 * @param accountType
	 * @return AuthAccountEBO of the account type provided from the parameter 'accountType' if exists, otherwise return null
	 * @throws InvalidParameterBOException
	 */
	public AuthAccountEBO find(String login, String accountType) throws InvalidParameterBOException;
	
	/**
	 * 
	 * @param login
	 * @return AuthAccountEBO of accountType Client if exists, otherwise return null
	 * @throws InvalidParameterBOException
	 */
	public AuthAccountEBO findAccountTypeClient(String login) throws InvalidParameterBOException;
	
	/**
	 * 
	 * @param login
	 * @return AuthAccountEBO of accountType Tiers if exists, otherwise return null
	 * @throws InvalidParameterBOException
	 */
	public AuthAccountEBO findAccountTypeTiers(String login) throws InvalidParameterBOException;
	
	/**
	 * 
	 * @param login
	 * @return AuthAccountEBO of accountType Group if exists, otherwise return null
	 * @throws InvalidParameterBOException
	 */
	public AuthAccountEBO findAccountTypeGroup(String login) throws InvalidParameterBOException;
	
	/**
	 * @param logins
	 * @param area
	 * @return int   
	 * @throws InvalidParameterBOException
	 */
	public int countByCriteriaSearch(Set logins, Set area) throws InvalidParameterBOException;
	
	/**
	 * @param logins
	 * @return int   
	 * @throws InvalidParameterBOException 
	 */
	public int countExistentAcountByLoginsList(Set logins) throws InvalidParameterBOException;

	/**
	 * @param authLevel
	 * @param login
	 * @param authSystem
	 * @param authType
	 * @return AuthAccountEBO
	 * @throws InvalidParameterBOException
	 */
	public AuthAccountEBO find(Integer authLevel, String login,
			String authSystem, String authType)
			throws InvalidParameterBOException;

	/**
	 * @param authLevel
	 * @param login
	 * @param authSystem
	 * @param authType
	 * @param bypassRefog whether or not to bypass refog
	 * @return AuthAccountEBO
	 * @throws InvalidParameterBOException
	 */
	public AuthAccountEBO find(Integer authLevel, String login,
			String authSystem, String authType, boolean bypassRefog)
			throws InvalidParameterBOException;
	
	/**
	 * @param login
	 *            id of the authentication account
	 * @param authSystem
	 *            authentication system {@value} SES, REFOG
	 * @param authType
	 *            authentication type {@value} CLIENT, TIERS, GROUP
	 * @return entity business object of authentication account if a technical
	 *         error happened
	 * @throws InvalidParameterBOException
	 *             if system or type is unknown
	 */
	public AuthAccountEBO find(String login, String authSystem, String authType)
			throws InvalidParameterBOException;

	/**
	 * @param login
	 *            id of the authentication account
	 * @param authSystem
	 *            authentication system {@value} SES, REFOG
	 * @param authType
	 *            authentication type {@value} CLIENT, TIERS, GROUP
	 * @param bypassRefog
	 *            whether or not to bypass refog
	 * @return entity business object of authentication account if a technical
	 *         error happened
	 * @throws InvalidParameterBOException
	 *             if system or type is unknown
	 */
	public AuthAccountEBO find(String login, String authSystem, String authType, boolean bypassRefog)
			throws InvalidParameterBOException;
	
	/**
	 * Return an auth account.
	 * This methods is used only for the login because it always returns an AuthAccountEBO.
	 * @param login
	 *            id of the authentication account
	 * @return entity business object of authentication account if a technical
	 *         error happened
	 * @throws InvalidParameterBOException
	 *             if system or type is unknown
	 */	
	public AuthAccountEBO findInRefogFromAuth(String login) throws InvalidParameterBOException;

	/**
	 * Update the authAccount
	 * 
	 * @param authAccountId
	 * @param authType
	 * @param authSystem
	 * @throws InvalidParameterBOException
	 * @throws TechnicalBOException
	 */
	public void update(String authAccountId, String authType, String authSystem)
			throws InvalidParameterBOException, TechnicalBOException;

	/**
	 * Upadte the auth account login
	 * 
	 * @param authAccountEBO
	 * @param newLogin
	 */
	public void updateLogin(AuthAccountEBO authAccountEBO, String newLogin);

	/**
	 * Update the auth account attempts number
	 * 
	 * @param authAccountEBO
	 */
	public void updateAttemptsNumber(AuthAccountEBO authAccountEBO);

	/**
	 * Update the auth account last connexion
	 * 
	 * @param authAccountEBO
	 */
	public void updateLastConnexion(AuthAccountEBO authAccountEBO);

	/**
	 * @param authAccountEBO
	 *            authAccount
	 * @return Map<key, value>
	 * @throws NullPointerException
	 *             if authAccountEBO is null
	 */
	public Map<String,String> findAttributes(AuthAccountEBO authAccountEBO);

	/**
	 * @param authAccountEBO
	 *            authAccount
	 * @param bypassRefog whether or not to bypass refog
	 * @return Map<key, value>
	 * @throws NullPointerException
	 *             if authAccountEBO is null
	 */
	public Map<String,String> findAttributes(AuthAccountEBO authAccountEBO, final boolean bypassRefog);
	
	/**
	 * Creates a new response if it does not exist, updates the response if it
	 * already exists.
	 * 
	 * @param authAccount
	 *            authentication account
	 * @param secretQuestion
	 *            the secret question.
	 * @param response
	 *            the response to the question.
	 * @return true if response has been updated, false otherwise
	 * @throws InvalidParameterBOException
	 *             if response is blank, if authAccount is null,if
	 *             secretQuestion is null, if secretQuestion not answered
	 * @throws DataAccessException
	 *             if database cannot be accessed
	 * @throws TechnicalBOException
	 */
	public boolean updateSecretResponse(AuthAccountEBO authAccount,
			SecretQuestionEBO secretQuestion, String response)
			throws DataAccessException, InvalidParameterBOException,
			TechnicalBOException;

	/**
	 * @param authAccountEBO
	 * @return true if authAccount found and deleted, false if account not found
	 */
	public boolean delete(AuthAccountEBO authAccountEBO);

	/**
	 * find by account status with paging
	 * 
	 * @param loginPattern
	 * @param authTypePattern
	 * @param accountStatusPattern
	 * @param passwordStatusPattern
	 * @param startDate
	 * @param endDate
	 * @param offset
	 * @param pageSize
	 * @param areaEBOs
	 * @param currentDate
	 *            current date
	 * @return Set<AuthAccountEBO>
	 * @throws InvalidParameterBOException
	 *             if offset < 0,<br>
	 *             if pageSize <= 0, <br>
	 *             if pageSize > 500,<br>
	 *             if startDate != null, <br>
	 *             if endDate != null, <br>
	 *             if authTypePattern equals to GROUP, <br>
	 *             if passwordStatusPattern is not blank and is not equals to
	 *             one of these values :<code>SearchPatternConstants.ANY</code>,<code>PasswordConstants.EXPIRED</code>,
	 *             <code>PasswordConstants.ADMIN_RESET</code>,
	 *             <code>PasswordConstants.ACTIVE</code>)
	 * @pre offset >= 0
	 * @pre pageSize > 0
	 * @pre pageSize <= 500
	 * @pre startDate is null
	 * @pre endDate is null
	 * @pre authTypePattern is null or equals to TIERS or CLIENT
	 * @pre passwordStatusPattern is null or is equals to
	 *      <code>SearchPatternConstants.ANY</code> or
	 *      <code>PasswordConstants.EXPIRED</code> or
	 *      <code>PasswordConstants.ADMIN_RESET</code> or
	 *      <code>PasswordConstants.ACTIVE</code>
	 */
	public Set<AuthAccountEBO> find(String loginPattern, String authTypePattern,
			String accountStatusPattern, String passwordStatusPattern,
			Calendar startDate, Calendar endDate, int offset, int pageSize,
			Set<UserAdminAreaEBO> areaEBOs, Calendar currentDate)
			throws InvalidParameterBOException;

	/**
	 * find by account status with paging
	 * 
	 * @param authTypePattern
	 * @param accountStatusPattern
	 * @param offset
	 * @param pageSize
	 * @param areaEBOs
	 * @param currentDate
	 *            currentDate
	 * @return Set<AuthAccountEBO>
	 */
	public Set<AuthAccountEBO> find(String authTypePattern, String accountStatusPattern,
			int offset, int pageSize, Set<UserAdminAreaEBO> areaEBOs, Calendar currentDate);

	/**
	 * @param loginPattern
	 * @param authTypePattern
	 * @param accountStatusPattern
	 * @param passwordStatusPattern
	 * @param startDate
	 * @param endDate
	 * @param areaEBOs
	 * @param currentDate
	 *            current Date
	 * @return Long
	 */
	public Long count(String loginPattern, String authTypePattern,
			String accountStatusPattern, String passwordStatusPattern,
			Calendar startDate, Calendar endDate, Set areaEBOs,
			Calendar currentDate);

	/**
	 * @param accountType
	 * @param login
	 * @param lastName
	 * @param firstName
	 * @param permissionId
	 * @param roleId
	 * @param statusKey
	 * @param functionalAreaId
	 * @param areas
	 *            Set<UserAdminAreaEBO>
	 * @return int
	 * @throws InvalidParameterBOException
	 */
	public int countByCriteriaSearch(String accountType, String login,
			String lastName, String firstName, String permissionId,
			String roleId, String statusKey, String functionalAreaId, Set areas, String idAccountType, String preferredLanguage)
			throws InvalidParameterBOException;

	/**
	 * @param accountType
	 * @param login
	 * @param lastName
	 * @param firstName
	 * @param permissionId
	 * @param roleId
	 * @param statusKey
	 * @param functionalAreaId
	 * @param offSet
	 * @param pageSize
	 * @param areas
	 * @param idAccountType
	 * @param preferredLanguage
	 * @param sortingCriteriaList
	 * @param sortOrder
	 * @return Set<AuthAccountEBO>
	 * @throws InvalidParameterBOException
	 * @throws TechnicalBOException
	 */
	public List<AuthAccountEBO> findByCriteriaSearch(String accountType, String login,
			String lastName, String firstName, String permissionId,
			String roleId, String statusKey, String functionalAreaId,
			int offSet, int pageSize, Set<UserAdminAreaEBO> areas, String idAccountType, 
			String preferredLanguage, 
			List sortingCriteriaList, String sortOrder)
			throws InvalidParameterBOException, TechnicalBOException;

	/**
	 * Add an attribute to an auth account
	 * 
	 * @param authAccountEBO
	 *            authentication account
	 * @param key
	 *            attribute key
	 * @param value
	 *            attribute value
	 * @param updatorAccountEBO
	 *            AccountEBO updator
	 */
	public void addAttribute(AuthAccountEBO authAccountEBO, String key,
			String value, AccountEBO updatorAccountEBO);
	
	/**
	 * Add an attribute to an auth account
	 * 
	 * @param authAccountEBO
	 *            authentication account
	 * @param key
	 *            attribute key
	 * @param value
	 *            attribute value
	 * @param updatorAccountEBO
	 *            AccountEBO updator
	 * @param isAdvanced
	 * 			  indicates if it calls from advanced services           
	 */
	public void addAttribute(AuthAccountEBO authAccountEBO, String key,
			String value, AccountEBO updatorAccountEBO, boolean isAdvanced);

	/**
	 * add a new secret response
	 * 
	 * @param authAccount
	 *            authentication Account to update
	 * @param secretQuestion
	 *            secret question answered
	 * @param response
	 *            secret response to add
	 * @throws DataAccessException
	 *             if database cannot be accessed
	 * @throws InvalidParameterBOException
	 *             if response is blank,if authAccount is null, if
	 *             secretQuestion is null, if secretQuestion has already an
	 *             response
	 * @throws TechnicalBOException
	 */
	public void addSecretResponse(AuthAccountEBO authAccount,
			SecretQuestionEBO secretQuestion, String response)
			throws DataAccessException, InvalidParameterBOException,
			TechnicalBOException;

	/**
	 * remove a secret response
	 * 
	 * @param authAccount
	 *            authentication account to update
	 * @param secretQuestion
	 *            secret question to remove
	 * @throws DataAccessException
	 *             if database cannot be accessed
	 * @throws InvalidParameterBOException
	 *             if response is blank,if authAccount is null, if
	 *             secretQuestion is null, if secretQuestion has not been
	 *             answered
	 * @throws TechnicalBOException
	 */
	public void removeSecretResponse(AuthAccountEBO authAccount,
			SecretQuestionEBO secretQuestion) throws DataAccessException,
			InvalidParameterBOException, TechnicalBOException;

	/**
	 * find the response to a question for an user
	 * 
	 * @param authAccount
	 *            authentication account to look
	 * @return Map<SecretQuestionEBO,String> authAccount's secret responses
	 * @throws DataAccessException
	 *             if database cannot be accessed
	 * @throws InvalidParameterBOException
	 *             if authAccount is null, if secretQuestion is null
	 * @throws TechnicalBOException
	 */
	public Map findSecretResponses(AuthAccountEBO authAccount)
			throws DataAccessException, InvalidParameterBOException,
			TechnicalBOException;

	/**
	 * find the response to a question for an user
	 * 
	 * @param authAccount
	 *            authentication account to look
	 * @param secretQuestion
	 *            secret question to look
	 * @return secret response to secretQuestion for authAccount
	 * @throws DataAccessException
	 *             if database cannot be accessed
	 * @throws InvalidParameterBOException
	 *             if authAccount is null, if secretQuestion is null
	 * @throws TechnicalBOException
	 */
	public String findSecretResponse(AuthAccountEBO authAccount,
			SecretQuestionEBO secretQuestion) throws DataAccessException,
			InvalidParameterBOException, TechnicalBOException;

	public Set<AccountStatusEBO> findAccountStatus(String accountLogin,
			String accountTypePattern, String accountStatusPattern,
			String passwordStatusPattern, Calendar startDate, Calendar endDate,
			int offset, int pageSize, Set treeAreas, Calendar currentDate);

	/**
	 * Update the Authentification Account and the expiry date of the password if pass.
	 * @author FVE
	 * @param connectedAuthAccount 
	 * @param accountId account 
	 * @param accountType account type
	 * @param uid 
	 * @param comments
	 * @param expiryDate
	 * @param calendar 
	 * @param inactiveDate
	 */
	public void update(AuthAccountEBO connectedAuthAccount, String accountId, String accountType, String uid, String comments, Calendar expiryDate, Calendar inactiveDate);

	/**
	 * Check if the UID exist in Refog. If it's not exist then throw an InvalidParameterBOException
	 * @author FVE
	 * @param uid the uid to check
	 * @return true if exist false else
	 */
	public void checkAccountExistInRefog(String uid);
	
	/**
	 * 
	 * @param authAccountEBO
	 * @param keyValues
	 * @throws DataAccessException
	 * @throws InvalidParameterBOException
	 * @throws TechnicalBOException
	 */
	public void addMailingOrder(AuthAccountEBO authAccountEBO, Map<String, String> keyValues)
			throws DataAccessException, InvalidParameterBOException,
			TechnicalBOException;
	
	/**
	 * 
	 * @param authAccountEBO
	 * @param keyValues
	 * @throws DataAccessException
	 * @throws InvalidParameterBOException
	 * @throws TechnicalBOException
	 */
	public void addMailingOrderV2(AuthAccountEBO authAccountEBO, Map keyValues)
			throws DataAccessException, InvalidParameterBOException,
			TechnicalBOException;
	
	/**
	 * @param accountType
	 * @param login
	 * @param lastName
	 * @param firstName
	 * @param permissionId
	 * @param roleId
	 * @param statusKey
	 * @param functionalAreaId
	 * @param offSet
	 * @param pageSize
	 * @param areas
	 * @param idAccountType
	 * @param preferredLanguage
	 * @param sortingCriteriaList
	 * @param sortOrder
	 * @return Set<AuthAccountEBO>
	 * @throws InvalidParameterBOException
	 * @throws TechnicalBOException
	 */
	public Collection findByCriteriaSearchV1(String accountType, String login,
			String lastName, String firstName, String permissionId,
			String roleId, String statusKey, String functionalAreaId,
			int offSet, int pageSize, Set areas, String idAccountType, 
			String preferredLanguage, 
			List sortingCriteriaList, String sortOrder)
			throws InvalidParameterBOException, TechnicalBOException;

	/**
	 * This method locks a user account
	 * Lock means : put a token in the sesame locked cache key=login value=type,<lock_datetime_utc>
	 * @param login
	 * @param type TOTP etc ...
	 * @throws TechnicalBOException
	 */
	public void lockInCache(String login, String type) throws TechnicalBOException ;	
	
	/**
	 * Unlock the account by removing the entry in the sesame locked cache
	 * @param login
	 * @throws TechnicalBOException
	 */
	public void unlockFromCache(String login) throws TechnicalBOException;
	
	/**
	 * Bulk unlock a set of logins
	 * @param logins
	 * @throws TechnicalBOException
	 */
	public void unlockFromCache(Set logins) throws TechnicalBOException;
	
	/**
	 * Find the lock value in the sesame locked cache
	 * @param login
	 * @return the value=type,<lock_datetime_utc> or null if not found
	 * @throws TechnicalBOException
	 */
	public String findLockedInCache(String login) throws TechnicalBOException;
	
	/**
	 * Tell if an account is locked
	 * @param login
	 * @return true if locked else false
	 * @throws TechnicalBOException
	 */
	public boolean isLockedInCache(String login) throws TechnicalBOException;

	
	public abstract void changeLogin(AuthAccountEBO authAccountEBO, String newLogin) throws UnAuthorizedActionBOException,	InvalidParameterBOException, TechnicalBOException;

	public abstract void changePassword(AuthAccountEBO authAccountEBO, String oldPassword, String newPassword) throws LoginBOException,
		LockedAccountBOException, InvalidPasswordBOException, TechnicalBOException;
	
	public abstract void createPwd(AuthAccountEBO authAccountEBO, AuthAccountEBO updator) throws InvalidPasswordBOException,
		InvalidParameterBOException, TechnicalBOException;
	
	public Map<String, String> getAttributes(AuthAccountEBO authAccountEBO);

	public Map<String, String> getAttributes(AuthAccountEBO authAccountEBO, final boolean bypassRefog);

	public abstract PasswordEBO getLastPassword(AuthAccountEBO authAccountEBO);
	
	public abstract List<PasswordEBO> getPasswords(AuthAccountEBO authAccountEBO) throws TechnicalBOException;
	
	/**
	 * @throws LoginBOException
	 * @throws BadPasswordBOException
	 *             if password is wrong
	 * @throws LockedAccountBOException
	 *             if account is inactive or the maximum number of login
	 *             attempts has been reached
	 * @throws ExpiredPasswordBOException
	 *             password has expired
	 * @throws TechnicalBOException
	 *             if technical error
	 * @throws InvalidParameterBOException
	 */
	public abstract void login(AuthAccountEBO authAccountEBO) throws LoginBOException, BadPasswordBOException, ExpiredPasswordBOException,
		LockedAccountBOException, TechnicalBOException, InvalidParameterBOException;
	
	/**
	 * @throws LoginBOException
	 * @throws BadPasswordBOException
	 *             if password is wrong
	 * @throws LockedAccountBOException
	 *             if account is inactive or the maximum number of login
	 *             attempts has been reached
	 * @throws ExpiredPasswordBOException
	 *             password has expired
	 * @throws TechnicalBOException
	 *             if technical error
	 * @throws InvalidParameterBOException
	 */
	public void login(AuthAccountEBO authAccountEBO, boolean bypassRefog) throws LoginBOException, BadPasswordBOException, ExpiredPasswordBOException,
	LockedAccountBOException, TechnicalBOException, InvalidParameterBOException;
	
	public abstract void login(AuthAccountEBO authAccountEBO, String password) throws LoginBOException, BadPasswordBOException,
		ExpiredPasswordBOException, LockedAccountBOException, TechnicalBOException, InvalidParameterBOException;
	
	/**
	 * Reset and send password for this authentication account
	 * 
	 * @param updator
	 * @param channelMessageFormatEBO
	 * @param parameters
	 * @param sendingDate
	 * @throws TechnicalBOException
	 * @throws InvalidParameterBOException
	 */
	public abstract void resetAndSendPassword(AuthAccountEBO authAccountEBO, AuthAccountEBO updator,
		ChannelMessageFormatEBO channelMessageFormatEBO, Map<String, String> parameters, Date sendingDate, Integer securityLevel)
		throws InvalidParameterBOException, TechnicalBOException;
	
	public abstract String resetPassword(AuthAccountEBO authAccountEBO, AuthAccountEBO updator, Integer securityLevel)
			throws InvalidParameterBOException, TechnicalBOException;
	
	public abstract void setLastPassword(AuthAccountEBO authAccountEBO, PasswordEBO lastPwd);
	
	public abstract void updatePwdExperyDate(AuthAccountEBO authAccountEBO, AuthAccountEBO updator, Calendar expiryDate);
	
	/**
	 * @return isUsedIce
	 */
	public boolean isUsedIce();

}
