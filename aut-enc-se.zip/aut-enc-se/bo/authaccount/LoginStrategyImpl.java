/**
 * 
 */
package com.bnppa.sesame.authaccount;


/**
 * @author bellidori
 *
 */
public class LoginStrategyImpl implements LoginStrategy {

	/**
	 * 
	 * @see com.bnppa.sesame.authaccount.LoginStrategy#createLogin(java.lang.String)
	 */
	public String createLogin(String accountId) {
		
		return accountId;
	}

	/**
	 * @see com.bnppa.sesame.authaccount.LoginStrategy#createAccountId(java.lang.String, java.lang.String)
	 */
	public String createAccountId(String login, String accountId) {
		return login;
	}

}
