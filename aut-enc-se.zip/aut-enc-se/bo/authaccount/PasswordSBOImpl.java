/*
 * Created on Aug 12, 2009
 */
package com.bnppa.sesame.authaccount;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;

import com.bnppa.sesame.AuthAccountIdTO;
import com.bnppa.sesame.PasswordDAOFacade;
import com.bnppa.sesame.PasswordTO;
import com.bnppa.sesame.account.AccountEBO;
import com.bnppa.sesame.constants.AuthAccountConstants;
import com.bnppa.sesame.constants.InvalidPasswordBOExceptionConstants;
import com.bnppa.sesame.constants.PasswordConstants;
import com.bnppa.sesame.constants.TechnicalBOExceptionConstants;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.InvalidPasswordBOException;
import com.bnppa.sesame.exceptions.TechnicalBOException;
import com.bnppa.sesame.hash.HashAlgorithm;
import com.bnppa.sesame.hash.HashAlgorithmStrategyFactory;
import com.bnppa.sesame.hash.HashManager;
import com.bnppa.sesame.mapper.Mapper;
import com.bnppa.sesame.services.exception.TechnicalException;

/**
 * @author polancoro, behatemo
 * @author bellidori
 * @version Aug 12, 2009
 * @version 24/12/2009 : SESAME-605
 * @version 20/08/10
 * @version 24/08/10
 */
public class PasswordSBOImpl implements PasswordSBO {
	private static final Log logger = LogFactory.getLog(PasswordSBOImpl.class);

	private PasswordDAOFacade passwordDAOFacade;

	@Autowired
	private AuthAccountSBO authAccountSBO;

	@Autowired
	private HashAlgorithm hashAlgorithm;

//	@Autowired
//	private SesameHashEncryption sesameHashEncryption;

	static final int NB_MAX_TENTATIVES = 5;

	/**
	 * mapper of entity business object to transfer object and vice versa
	 */
	private Mapper<PasswordTO, PasswordEBO> mapper;

	private Mapper<PasswordTO, PasswordEBO> getMapper() {
		return mapper;
	}

	/**
	 * @param mapper
	 *            password's mapper for ebo and to
	 */
	public void setMapper(Mapper<PasswordTO, PasswordEBO> mapper) {
		this.mapper = mapper;
	}

	/**
	 * @throws TechnicalBOException
	 * @see com.bnppa.sesame.authaccount.PasswordSBO#find(com.bnppa.sesame.authaccount.AuthAccountEBO)
	 * @author bellidori
	 */
	public List<PasswordEBO> find(AuthAccountEBO owner) throws TechnicalBOException {

		List<PasswordTO> passwordTOs = passwordDAOFacade.find(new AuthAccountIdTO(owner.getLogin(), owner.getAuthType()));

		List<PasswordEBO> passwordEBOs = new ArrayList<PasswordEBO>(passwordTOs.size());
		for (Iterator<PasswordTO> iter = passwordTOs.iterator(); iter.hasNext();) {
			passwordEBOs.add(map(iter.next()));
			iter.remove();
		}

		return passwordEBOs;

	}

	/**
	 * @return passwordDAOFacade
	 */
	protected PasswordDAOFacade getPasswordDAOFacade() {
		return passwordDAOFacade;
	}

	/**
	 * @param passwordDAOFacade
	 */
	public void setPasswordDAOFacade(PasswordDAOFacade passwordDAOFacade) {
		this.passwordDAOFacade = passwordDAOFacade;
	}

	/**
	 * @param passwordTO
	 * @return passwordEBO
	 */
	private PasswordEBO map(PasswordTO passwordTO) {

		return (PasswordEBO) getMapper().mapTOtoEBO(passwordTO);
	}

	/**
	 * @author bellidori
	 * @see com.bnppa.sesame.authaccount.PasswordSBO#findLast(com.bnppa.sesame.authaccount.AuthAccountEBO)
	 */
	public PasswordEBO findLast(AuthAccountEBO owner) {
		PasswordTO to = getPasswordDAOFacade().findLast(new AuthAccountIdTO(owner.getLogin(), owner.getAuthType()));
		return map(to);
	}

	/**
	 * @author behatemo
	 * @see com.bnppa.sesame.authaccount.PasswordSBO#find(java.lang.String,
	 *      java.lang.Integer)
	 */
	public PasswordEBO find(String login, Integer updateNumber) {

		return map(getPasswordDAOFacade().find(login, updateNumber));
	}

	/**
	 * @author bellidori
	 * @see com.bnppa.sesame.authaccount.PasswordSBO#create(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      java.lang.String, com.bnppa.sesame.authaccount.AuthAccountEBO)
	 */
	public PasswordEBO create(AuthAccountEBO owner, String password, AuthAccountEBO updator) throws InvalidParameterBOException,
			InvalidPasswordBOException, TechnicalBOException {

		return this.create(owner, password, updator, false);
	}

	/**
	 * @author vendefx
	 * @see com.bnppa.sesame.authaccount.PasswordSBO#create(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      java.lang.String, com.bnppa.sesame.authaccount.AuthAccountEBO)
	 */
	public PasswordEBO createWithReset(AuthAccountEBO owner, String password, AuthAccountEBO updator) throws InvalidParameterBOException,
			InvalidPasswordBOException, TechnicalBOException {

		return this.create(owner, password, updator, true);
	}

	/**
	 * @author bellidori
	 * @see com.bnppa.sesame.authaccount.PasswordSBO#create(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      com.bnppa.sesame.authaccount.AuthAccountEBO)
	 */
	public String create(AuthAccountEBO owner, AuthAccountEBO updator) throws InvalidParameterBOException, TechnicalBOException {

		String password = null;
		int nbTentatives = 0;

		while (true) {
			nbTentatives++;
			// Generate new password for AccountType
			if (AuthAccountConstants.TYPE_CLIENT.equals(owner.getAuthType())) {
				String customerType = ((CustomerAuthAccountEBO) owner).getCustomerType();
				password = owner.getSecurityRulesStrategy().generatePwdClient(authAccountSBO.getPasswords(owner), customerType);
			} else {
				password = owner.getSecurityRulesStrategy().generatePwd(authAccountSBO.getPasswords(owner));
			}

			// Check compliance of the generated password
			try {
				if (AuthAccountConstants.TYPE_CLIENT.equals(owner.getAuthType())) {
					String customerType = ((CustomerAuthAccountEBO) owner).getCustomerType();
					if (owner.getSecurityRulesStrategy().checkPwdClient(password, authAccountSBO.getPasswords(owner), customerType)) {
						break;
					}
				} else {
					if (owner.getSecurityRulesStrategy().checkPwd(password, authAccountSBO.getPasswords(owner))) {
						break;
					}
				}
			} catch (InvalidPasswordBOException e) {
				if (InvalidPasswordBOExceptionConstants.NEW_PASSWORD_IS_TO_ONE_OF_LAST_OLD_PASSWORD.equals(e.getMessageCode())) {

					if (nbTentatives > NB_MAX_TENTATIVES) {
						throw new TechnicalBOException(TechnicalBOExceptionConstants.GENERATED_PASSWORD_IS_ALWAYS_INVALID, new Object[] {
								owner, password, new Integer(NB_MAX_TENTATIVES) }, e, logger);
					}
				} else {
					throw new TechnicalBOException(TechnicalBOExceptionConstants.GENERATED_PASSWORD_IS_INVALID, new Object[] { owner,
							password }, e, logger);
				}
			}

		}
		try {

			this.create(owner, password, updator, true);
			return password;
		} catch (InvalidPasswordBOException e) {
			throw new TechnicalBOException(TechnicalBOExceptionConstants.GENERATED_PASSWORD_IS_INVALID, new Object[] { owner, password },
					e, logger);
		}
	}

	/**
	 * 
	 * @see com.bnppa.sesame.authaccount.PasswordSBO#create(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      java.lang.String, com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      boolean)
	 */
	protected PasswordEBO create(AuthAccountEBO owner, String password, AuthAccountEBO updator, boolean isReset)
			throws InvalidParameterBOException, InvalidPasswordBOException, TechnicalBOException {
		List<PasswordEBO> pwds = authAccountSBO.getPasswords(owner);
		byte[] hashedPassword = null;

		if (AuthAccountConstants.TYPE_CLIENT.equals(owner.getAuthType())) {
			String customerType = ((CustomerAuthAccountEBO) owner).getCustomerType();
			owner.getSecurityRulesStrategy().checkPwdClient(HashManager.revertByte(password.getBytes()), pwds, customerType);
		} else {
			owner.getSecurityRulesStrategy().checkPwd(HashManager.revertByte(password.getBytes()), pwds);
		}

		Calendar currentDate = Calendar.getInstance();
		Integer updateNo = new Integer(pwds.size() + 1);
		Calendar expiryDt = currentDate;

		// Generation of an 'expiryDt' in the use case : call of the create
		// method by the method 'changePassword'.
		if (updator.equals(owner)) {
			expiryDt = owner.getSecurityRulesStrategy().generateExpiryDate(currentDate);
		}

		// password has been reset, it must be change
		if (isReset) {
			// FVE - We use the expiryDate of the account if fill [Evolution
			// SesameInterLot3].
			AccountEBO account = owner.getAccount();
			if (account != null & account.getExpiryDate() != null) {
				expiryDt = account.getExpiryDate();
			} else {
				expiryDt = currentDate;
			}
		}

		byte[] salt = null;

		// TODO SCH
		try {

			salt = hashAlgorithm.generateSalt();

			hashedPassword = hashAlgorithm.encryptBlandPassword(password, salt);

		} catch (TechnicalException e) {
			throw new TechnicalBOException(TechnicalBOExceptionConstants.QRCODE_CREATION_ERROR, new Object[] { owner,
					HashManager.revertByte(password.getBytes()) }, e, logger);
		}

		final String algorithm = HashAlgorithmStrategyFactory.getHashEncryption();
		PasswordEBO ebo = new PasswordEBO(hashedPassword, updateNo, currentDate, updator, expiryDt, salt, algorithm);

		authAccountSBO.setLastPassword(owner, ebo);

		PasswordTO to = new PasswordTO(new AuthAccountIdTO(owner.getLogin(), owner.getAuthType()), ebo.getPassword(), ebo.getUpdateNo(),
				ebo.getExpiryDate(), ebo.getUpdateDate(), new AuthAccountIdTO(updator.getLogin(), updator.getAuthType()), ebo.getSalt(),
				ebo.getAlgorithm()); // type de updator
		getPasswordDAOFacade().create(to);
		return ebo;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean update(final AuthAccountEBO authAccountEbo)
			throws DataAccessException, NullPointerException {
		final PasswordTO toUpdate = PasswordMapper.mapEBOtoTO(authAccountEbo);
		return this.passwordDAOFacade.update(toUpdate);
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bnppa.sesame.authaccount.PasswordSBO#updateLastPasswordExpiryDate
	 * (com.bnppa.sesame.authaccount.AuthAccountEBO,
	 * com.bnppa.sesame.authaccount.AuthAccountEBO, java.util.Calendar)
	 */
	public void updateLastPasswordExpiryDate(AuthAccountEBO owner, AuthAccountEBO updator, Calendar expiryDate) {
		Calendar currentDate = Calendar.getInstance();

		PasswordTO to = new PasswordTO(new AuthAccountIdTO(owner.getLogin(), owner.getAuthType()), null, null, expiryDate, currentDate,
				new AuthAccountIdTO(updator.getLogin(), updator.getAuthType()), null, null); // type
																								// de
																								// l'owner

		getPasswordDAOFacade().updateLastPasswordExpiryDate(to);
	}

	public AuthAccountEBO getUpdator(PasswordEBO passwordEBO) {
		if (passwordEBO.getUpdator() == null) {
			passwordEBO.setUpdator(authAccountSBO.find(passwordEBO.getUpdatorId().getLogin(), AuthAccountConstants.SYST_SESAME, passwordEBO
					.getUpdatorId().getAuthType()));

		}
		return passwordEBO.getUpdator();
	}

	/**
	 * Get the password status of the user account given in params
	 * 
	 * @param owner
	 *            password's owner. It cannot be null
	 * 
	 * @return EXPIRED if expiryDate <= currentDate and the password has not
	 *         been modified by another user. <br>
	 *         - ACTIVE if expiryDate > currentDate. <br>
	 *         - ADMIN_RESET if expiryDate <= currentDate and the password has
	 *         been modified by another user.
	 * @throws NullPointerException
	 *             if owner is null
	 */
	public String getStatus(PasswordEBO passwordEBO, AuthAccountEBO owner) {
		Calendar currentDate = Calendar.getInstance();

		if (passwordEBO.getExpiryDate().before(currentDate) || passwordEBO.getExpiryDate().equals(currentDate)) {
			if (!owner.getAccount().equals(this.getUpdator(passwordEBO).getAccount()))
				return PasswordConstants.ADMIN_RESET;

			return PasswordConstants.EXPIRED;
		}

		return PasswordConstants.ACTIVE;
	}
	
}
