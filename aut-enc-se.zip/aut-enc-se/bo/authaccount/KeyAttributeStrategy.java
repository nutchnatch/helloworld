package com.bnppa.sesame.authaccount;

import com.bnppa.sesame.account.AccountEBO;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.UnsupportedActionBOException;

/**
 * Interface to manage an extended attribute of a customer account by a
 * strategy.
 * 
 * @author brumal
 * 
 */
public interface KeyAttributeStrategy {

	/**
	 * Sets an attribute to the customer authentication account.
	 * 
	 * @param customerAuthAccountEBO
	 *            the customer authentication account where to add the
	 *            attribute.
	 * @param key
	 *            The attribute key.
	 * @param value
	 *            The attribute value.
	 * @param updatorAccountEBO
	 *            The updator accountEBO
	 * @throws UnsupportedActionBOException
	 *             if the add attribute action is not supported for the account
	 *             type.
	 * @throws InvalidParameterBOException
	 *             if parameter is not valid.
	 */
	void doSetAttribute(CustomerAuthAccountEBO customerAuthAccountEBO,
			String key, String value, AccountEBO updatorAccountEBO) throws UnsupportedActionBOException,
			InvalidParameterBOException;
	
	/**
	 * Sets an attribute to the customer authentication account.
	 * 
	 * @param customerAuthAccountEBO
	 *            the customer authentication account where to add the
	 *            attribute.
	 * @param key
	 *            The attribute key.
	 * @param value
	 *            The attribute value.
	 * @param updatorAccountEBO
	 *            The updator accountEBO
	 * @param isAdvanced
	 * 			  indicates if it calls from an advanced services
	 * @throws UnsupportedActionBOException
	 *             if the add attribute action is not supported for the account
	 *             type.
	 * @throws InvalidParameterBOException
	 *             if parameter is not valid.
	 */
	void doSetAttribute(CustomerAuthAccountEBO customerAuthAccountEBO,
			String key, String value, AccountEBO updatorAccountEBO, boolean isAdvanced) throws UnsupportedActionBOException,
			InvalidParameterBOException;

}
