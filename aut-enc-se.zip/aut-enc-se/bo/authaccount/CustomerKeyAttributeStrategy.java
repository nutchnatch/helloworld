/*
 * Created on Mar 23, 2010
 *
 */
package com.bnppa.sesame.authaccount;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bnppa.sesame.account.AccountEBO;
import com.bnppa.sesame.constants.CustomerConstants;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.constants.UnsupportedActionBOExceptionConstants;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.UnsupportedActionBOException;

/**
 * @author behatemo
 * @version Mar 23, 2010
 * 
 */
public class CustomerKeyAttributeStrategy implements KeyAttributeStrategy {

	private static final Log logger = LogFactory
			.getLog(CustomerKeyAttributeStrategy.class);

	/**
	 * @author behatemo
	 * @version Mar 23, 2010
	 * @see com.bnppa.sesame.authaccount.KeyAttributeStrategy#doSetAttribute(com.bnppa.sesame.authaccount.CustomerAuthAccountEBO,
	 *      java.lang.String, java.lang.String,
	 *      com.bnppa.sesame.account.AccountEBO)
	 */
	public void doSetAttribute(CustomerAuthAccountEBO customerAuthAccountEBO,
			String key, String value, AccountEBO updatorAccountEBO)
			throws UnsupportedActionBOException, InvalidParameterBOException {
		throw new UnsupportedActionBOException(
				UnsupportedActionBOExceptionConstants.UNSUPPORTED_ACTION,
				logger);

	}
	
	/**
	 * @see com.bnppa.sesame.authaccount.KeyAttributeStrategy#doSetAttribute(com.bnppa.sesame.authaccount.CustomerAuthAccountEBO,
	 *      java.lang.String, java.lang.String,
	 *      com.bnppa.sesame.account.AccountEBO, boolean)
	 */
	public void doSetAttribute(CustomerAuthAccountEBO customerAuthAccountEBO,
			String key, String value, AccountEBO updatorAccountEBO, boolean isAdvanced)
			throws UnsupportedActionBOException, InvalidParameterBOException {
		if(isAdvanced) {
			
			parametersTreatement(key, value);
				

			if(CustomerConstants.CUSTOMER_TYPE.equals(key)) {
				customerAuthAccountEBO.setCustomerType(value);	
			} else if(CustomerConstants.CONVENTION.equals(key)) {
				customerAuthAccountEBO.setConvention(value);	
			} else if(CustomerConstants.LAST_MAIL_DATE.equals(key)) {
				if(!StringUtils.isBlank(value)) {
					
					try {
						SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy", Locale.FRENCH);
						Date d = format.parse(value);
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(d);
						customerAuthAccountEBO.setLastMailDt(calendar);
					} catch (ParseException e) {
						// d�j� v�rifi� ne peut pas se produire
						logger.info("ParseException on doSetAttribute, d�j� v�rifi� ne peut pas se produire");
					}
				}
			}
			
			customerAuthAccountEBO.getAccount().setUpdatorId(updatorAccountEBO.getId());

		} else {
			throw new UnsupportedActionBOException(
				UnsupportedActionBOExceptionConstants.UNSUPPORTED_ACTION,
				logger);
		}

	}

	private void parametersTreatement(String key, String value) {
		if(CustomerConstants.CUSTOMER_TYPE.equals(key)) {
			// top nature client
			// valeurs autoris�es E ou I
			if(!CustomerConstants.TOP_NATURE_CLIENT_E.equals(value)
					&& !CustomerConstants.TOP_NATURE_CLIENT_I.equals(value)) {
				throw new InvalidParameterBOException(
						InvalidParameterBOExceptionConstants.INVALID_ATTRIBUTE_VALUE_2,
						new Object[] { value, key, new String(CustomerConstants.TOP_NATURE_CLIENT_E+", "+ CustomerConstants.TOP_NATURE_CLIENT_I) }
						, logger);
			}
			
		} else if(CustomerConstants.CONVENTION.equals(key)) {
			// convention
			// valeurs autoris�es N, O ou vide
			if(StringUtils.isNotBlank(value) 
					&& !CustomerConstants.CONVENTION_N.equals(value)
					&& !CustomerConstants.CONVENTION_O.equals(value)) {
				throw new InvalidParameterBOException(
						InvalidParameterBOExceptionConstants.INVALID_ATTRIBUTE_VALUE_2,
						new Object[] { value, key, new String(CustomerConstants.CONVENTION_N + ", " + CustomerConstants.CONVENTION_O + ", " + "NULL") }
						, logger);
			}
		} else if(CustomerConstants.LAST_MAIL_DATE.equals(key)) {
			// date courrier
			// valeurs autoris�es : date ou vide
			if(StringUtils.isNotBlank(value)) {
				SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
				format.setLenient(false);
				try {
					format.parse(value);
				} catch (ParseException e) {
					throw new InvalidParameterBOException(
							InvalidParameterBOExceptionConstants.INVALID_DATE_FORMAT,
							new Object[] { value, key }, logger);
				}
				
			}
			
		}
	}
}
