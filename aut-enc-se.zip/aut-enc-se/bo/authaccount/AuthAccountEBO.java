/*
 * Created on Jul 30, 2009
 *
 */
package com.bnppa.sesame.authaccount;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.lang.ref.SoftReference;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bnppa.sesame.account.AccountEBO;
import com.bnppa.sesame.constants.AuthAccountConstants;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.ebo.AbstractEBO;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.ldap.LDAPAttributesKeys;
import com.bnppa.sesame.message.Messages;
import com.bnppa.sesame.utils.AuthenticationValidator;

/**
 * @author bellidori
 * @version Jul 30, 2009
 * 
 */
public class AuthAccountEBO extends AbstractEBO {

	/**
	 * Comment for <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = 1L;

	private static final Log logger = LogFactory.getLog(AccountEBO.class);

	/**
	 * Strategy of authentication to used
	 * 
	 * @see Strategy pattern
	 */
	private AuthStrategy authStrategy;

	private transient SecurityRulesStrategy securityRulesStrategy;

	/**
	 * number of unsuccessful login attempts This number is setted to zero when
	 * login succeed
	 * 
	 * @inv attemptsNumber >= 0
	 */
	private Integer attemptsNumber;

	/**
	 * level of authentication
	 * 
	 * @value <code>AuthAccountConstants.LEVEL_LOW</code>(LOW),<br>
	 *        <code>AuthAccountConstants.LEVEL_MIDDLE</code>(MIDDLE), <br>
	 *        <code>AuthAccountConstants.LEVEL_STRONG</code>(STRONG)
	 * @inv <code>AuthAccountConstants.LEVEL_LOW</code>.equals(authLevel) ||
	 *      <code>AuthAccountConstants.LEVEL_MIDDLE</code>.equals(authLevel) ||
	 *      <code>AuthAccountConstants.LEVEL_STRONG</code>.equals(authLevel)
	 */
	private Integer authLevel;

	/**
	 * id used to log in
	 * 
	 * @inv (!StringUtils.isBlank(login)) && (<code>(AuthAccountConstants.TYPE_GROUP</code>.equals(authType)) =>
	 *      login.startsWith(LDAPAttributesKeys.UID_PREFIX) ||
	 *      userLogin.startsWith(LDAPAttributesKeys.UO_PREFIX) ||
	 *      userLogin.startsWith(LDAPAttributesKeys.GPE_PREFIX) ||
	 *      userLogin.startsWith(LDAPAttributesKeys.ISOC_PREFIX))
	 */
	private String loginId;

	/**
	 * @value <code>AuthAccountConstants.SYST_SESAME</code>, <br>
	 *        <code> AuthAccountConstants.SYST_REFOG</code>
	 * @inv <code>AuthAccountConstants.SYST_SESAME</code>.equals(syst) ||
	 *      <code> AuthAccountConstants.SYST_REFOG</code>.equals(syst)
	 */
	private String syst;

	/**
	 * @value <code>AuthAccountConstants.TYPE_CLIENT</code>, <br>
	 *        <code>AuthAccountConstants.TYPE_TIERS</code>, <br>
	 *        <code>AuthAccountConstants.TYPE_GROUP</code>
	 */
	private String authType;

	/**
	 * last time when account logged in
	 */
	private Calendar lastConnexion;

	/**
	 * account
	 * 
	 * @inv account != null
	 */
	private AccountEBO account;

	/**
	 * List of passwords of the authentication account null if not loaded empty
	 * if no password
	 * 
	 * @see coding pattern "lazy initialization"
	 */
	private transient SoftReference<List<PasswordEBO>> softPasswords;

	/**
	 * last pwd can be null if authentication is not managed by SES or if it has
	 * not been already loaded
	 * 
	 * @see coding pattern "lazy initialization"
	 */
	private transient PasswordEBO lastPwd;

	/**
	 * Auth Account LDAP attributes
	 */
	protected SoftReference<Map<String,String>> softAttributes;

	/**
	 * key(SecretQuestionEBO) = QuestionId value(String) = Response
	 */
	private transient SoftReference softSecretQuestions;

	/**
	 * If SQ is full (all SQ are in map)
	 */
	private transient boolean secretQuestionsInitialized;
	
	/**
	 * The authentification account exist in the referential.
	 */
	private boolean existInDataStore;


	/**
	 * CONSTRUCTOR
	 */
	
	
	/**
	 * create a new instance. <br>
	 * Set level to <code>AuthAccountConstants.LEVEL_MIDDLE</code>. <br>
	 * Set system to <code>AuthAccountConstants.SYST_SESAME</code>. <br>
	 * Set type to <code>AuthAccountConstants.TYPE_TIERS</code>
	 * 
	 * @author rochinaen
	 * @version Aug 7, 2009
	 * @param login
	 *            id used when log in. Can not be null. if authType is equals to
	 *            <code>AuthAccountConstants.TYPE_GROUP</code>, login must
	 *            begin by : <br>
	 *            <code>LDAPAttributesKeys.UID_PREFIX</code>, <br>
	 *            or <code>LDAPAttributesKeys.UO_PREFIX</code>, <br>
	 *            or <code>LDAPAttributesKeys.GPE_PREFIX</code>, <br>
	 *            or <code>LDAPAttributesKeys.ISOC_PREFIX</code>
	 * @param account
	 *            authorization's account. it cannot be null
	 */
	protected AuthAccountEBO(String login, AccountEBO account) {
		this(AuthAccountConstants.LEVEL_MIDDLE, login, AuthAccountConstants.SYST_SESAME, AuthAccountConstants.TYPE_TIERS, account);

	}

	/**
	 * create a new instance
	 * 
	 * @author polancoro
	 * @version Aug 7, 2009
	 * @param authLevel
	 *            level of authentication. It must be equals to
	 *            <code>AuthAccountConstants.LEVEL_LOW</code>(LOW) or
	 *            <code>AuthAccountConstants.LEVEL_MIDDLE</code>(MIDDLE), or
	 *            <code>AuthAccountConstants.LEVEL_STRONG</code>(STRONG)
	 * @param login
	 *            id used when log in. Can not be null. if authType is equals to
	 *            <code>AuthAccountConstants.TYPE_GROUP</code>, login must
	 *            begin by : <br>
	 *            <code>LDAPAttributesKeys.UID_PREFIX</code>, <br>
	 *            or <code>LDAPAttributesKeys.UO_PREFIX</code>, <br>
	 *            or <code>LDAPAttributesKeys.GPE_PREFIX</code>, <br>
	 *            or <code>LDAPAttributesKeys.ISOC_PREFIX</code>
	 * @param syst
	 *            system which manage authentification. it must be equals to
	 *            <code>AuthAccountConstants.SYST_SESAME</code> or,
	 *            <code> AuthAccountConstants.SYST_REFOG</code>
	 * @param authType
	 *            authentication's type. It must be equals to
	 *            <code>AuthAccountConstants.TYPE_CLIENT</code> for customer,
	 *            <br>
	 *            <code>AuthAccountConstants.TYPE_TIERS</code> for third user,
	 *            <br>
	 *            <code>AuthAccountConstants.TYPE_GROUP</code> for internal
	 *            user
	 * @param account
	 *            authorization's account. it cannot be null
	 * @throws InvalidParameterBOException
	 *             if login is blank if syst is wrong, if authType is wrong, if
	 *             account is null, if login is wrong
	 */

	protected AuthAccountEBO(Integer authLevel, String login, String syst, String authType, AccountEBO account) {
		super();

		// if (!AuthenticationValidator.isAuthenticationSystemValid(syst)) {
		// throw new InvalidParameterBOException(
		// InvalidParameterBOExceptionConstants.AUTH_SYSTEM_IS_INVALID,
		// new String[] { syst }, logger);
		// }

		if (StringUtils.isBlank(authType)){
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTH_TYPE_IS_BLANK,
					logger);
		}
		
		if (!AuthenticationValidator.isAuthenticationTypeValid(authType)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTH_TYPE_IS_INVALID,
					new String[] { authType }, logger);
		}
		if (!AuthenticationValidator.isAuthenticationTypeValidOnSystem(
				authType, syst)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTH_TYPE_IS_INVALID_ON_SYSTEM,
					new String[] { authType, syst }, logger);
		}

		if (authLevel == null) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTH_LEVEL_IS_NULL,
					logger);
		}

		if (!AuthenticationValidator.isAuthenticationLevelValid(authLevel)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTH_LEVEL_IS_INVALID,
					new String[] { authLevel.toString() }, logger);
		}

		if (account == null) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_IS_NULL,
					new String[] { login }, logger);
		}
		
		// Control of the coherence between the idAccountType and the accountType
		String idAccountType = account.getIdAccountType();
		if (AuthenticationValidator.isIdAccountTypeCoherentWithAccountType(authType, idAccountType)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.ASSOCIATION_ID_ACCOUNT_TYPE_AND_ACCOUNT_TYPE_INVALID,
					logger);
		}
		
		this.authLevel = authLevel;
		this.syst = syst;
		// set the strategy of authentication
		setSecurityRulesStrategy(SecurityRulesFactory.create(authLevel));
		setAuthStrategy(AuthFactory.create(syst, account.getIdAccountType()));

		this.authType = authType;
		// Test the accountId in GROUP Type
		if (AuthAccountConstants.TYPE_GROUP.equals(authType)) {
			if (!AuthenticationValidator.isREFOGAuthAccountValid(account
					.getId())) {
				throw new InvalidParameterBOException(
						InvalidParameterBOExceptionConstants.LOGIN_IS_WRONG,
						new String[] { account.getId(), authType,
								LDAPAttributesKeys.UID_PREFIX,
								LDAPAttributesKeys.UO_PREFIX,
								LDAPAttributesKeys.GPE_PREFIX,
								LDAPAttributesKeys.ISOC_PREFIX }, logger);
			}
		}
		setLogin(login);
		this.account = account;
		// set the number of unsuccessful login by default value
		this.setAttemptsNumber(new Integer(0));

		// set the existence in the referential with a default value
		this.setExistInDataStore(true);
	}

	/**
	 * create a new instance
	 * 
	 * @author polancoro
	 * @version Aug 7, 2009 *
	 * @param authLevel
	 *            level of authentication. It must be equals to
	 *            <code>AuthAccountConstants.LEVEL_LOW</code>(LOW) or
	 *            <code>AuthAccountConstants.LEVEL_MIDDLE</code>(MIDDLE), or
	 *            <code>AuthAccountConstants.LEVEL_STRONG</code>(STRONG)
	 * @param login
	 *            id used when log in. Can not be null. if authType is equals to
	 *            <code>AuthAccountConstants.TYPE_GROUP</code>, login must
	 *            begin by : <br>
	 *            <code>LDAPAttributesKeys.UID_PREFIX</code>, <br>
	 *            or <code>LDAPAttributesKeys.UO_PREFIX</code>, <br>
	 *            or <code>LDAPAttributesKeys.GPE_PREFIX</code>, <br>
	 *            or <code>LDAPAttributesKeys.ISOC_PREFIX</code>
	 * @param syst
	 *            system which manage authentification. it must be equals to
	 *            <code>AuthAccountConstants.SYST_SESAME</code> or,
	 *            <code> AuthAccountConstants.SYST_REFOG</code>
	 * @param authType
	 *            authentication's type. It must be equals to
	 *            <code>AuthAccountConstants.TYPE_CLIENT</code> for customer,
	 *            <br>
	 *            <code>AuthAccountConstants.TYPE_TIERS</code> for third user,
	 *            <br>
	 *            <code>AuthAccountConstants.TYPE_GROUP</code> for internal
	 *            user
	 * @param account
	 *            authorization's account. it cannot be null
	 * @param lastPwd
	 *            last password. It cannot be null
	 * @throws InvalidParameterBOException
	 *             if login is blank if syst is wrong, if authType is wrong, if
	 *             account is null, if login is wrong, if lastPwd is null
	 * 
	 */
	protected AuthAccountEBO(Integer authLevel, String login, String syst, String authType, AccountEBO account, PasswordEBO lastPwd) {
		this(authLevel, login, syst, authType, account);
	}
	
	
	/**
	 * GETTER AND SETTER
	 */

	
	protected boolean isSecretQuestionsInitialized() {
		return secretQuestionsInitialized && (getSecretQuestions() != null);
	}
	
	protected void setSecretQuestionsInitialized(boolean sq) {
		this.secretQuestionsInitialized = sq;
	}
	
	protected Map getSecretQuestions() {
		if (softSecretQuestions == null) {
			return null;
		}
		return (Map) this.softSecretQuestions.get();
	}
	
	protected void setSecretQuestions(Map secretQuestions) {
		if (getSecretQuestions() == null) {
			setSecretQuestionsInitialized(false);
		}
		this.softSecretQuestions = new SoftReference(secretQuestions);
	}
	
	public boolean isExistInDataStore() {
		return existInDataStore;
	}
	
	public void setExistInDataStore(boolean existInDataStore) {
		this.existInDataStore = existInDataStore;
	}
	
	public AuthStrategy getAuthStrategy() {
		return authStrategy;
	}
	
	private void setAuthStrategy(AuthStrategy authStrategy) {
		this.authStrategy = authStrategy;
	}
	
	public SecurityRulesStrategy getSecurityRulesStrategy() {
		return securityRulesStrategy;
	}
	
	protected void setSecurityRulesStrategy(SecurityRulesStrategy securityRulesStrategy) {
		if (securityRulesStrategy == null) {
			throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.SECURITY_RULES_IS_NULL,new String[] { this.toString() }, logger);
		}
		this.securityRulesStrategy = securityRulesStrategy;
	}

	public AccountEBO getAccount() {
		return account;
	}

	public Integer getAttemptsNumber() {
		return attemptsNumber;
	}
	
	public void setAttemptsNumber(Integer attemptsNumber) {
		if (attemptsNumber == null) {
			throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_ATTEMPTS_NUMBER_IS_NULL,new String[] { loginId }, logger);
		}
		if (attemptsNumber.intValue() < 0) {
			throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.ATTEMPTS_NUMBER_IS_WRONG,new String[] { loginId, attemptsNumber.toString() }, logger);
		}
		this.attemptsNumber = attemptsNumber;
	}

	public Integer getAuthLevel() {
		return authLevel;
	}
	
	protected void setAuthLevel(Integer authLevel) {
		this.authLevel = authLevel;
	}
	
	public Calendar getLastConnexion() {
		return lastConnexion;
	}

	public void setAttributes(Map<String,String> attributes) {
		this.softAttributes = new SoftReference<Map<String,String>>(attributes);
	}

	public String getLogin() {
		return loginId;
	}
	
	public void setLogin(String login) {
		if (StringUtils.isBlank(login)) {
			throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.LOGIN_IS_BLANK, new String[] { login }, logger);
		}
		this.loginId = login;
	}

	public String getSyst() {
		return syst;
	}

	public String getAuthType() {
		return authType;
	}

	protected void setLastConnexion(Calendar lastConnexion) {
		if (lastConnexion == null) {
			throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_LAST_CONNEXION_IS_NULL,new String[] { loginId }, logger);
		}
		this.lastConnexion = lastConnexion;
	}

	protected boolean isPwdsInitialized() {
		return (softPasswords != null && softPasswords.get() != null);
	}

	protected boolean isAttributesInitialized() {
		return (softAttributes != null && softAttributes.get() != null);
	}
	
	protected SoftReference<Map<String,String>> getSoftAttributes() {
		return softAttributes;
	}

	protected void setSoftAttributes(SoftReference<Map<String,String>> softAttributes) {
		this.softAttributes = softAttributes;
	}
	
	protected PasswordEBO getLastPwd() {
		return lastPwd;
	}

	protected void setLastPwd(PasswordEBO lastPwd) {
		this.lastPwd = lastPwd;
	}
	
	protected SoftReference<List<PasswordEBO>> getSoftPasswords() {
		return softPasswords;
	}

	protected void setSoftPasswords(SoftReference<List<PasswordEBO>> softPasswords) {
		this.softPasswords = softPasswords;
	}
	

	/**
	 * UTILS
	 */

	private void readObject(ObjectInputStream in) throws IOException {

		try {
			in.defaultReadObject();
			setSecurityRulesStrategy(SecurityRulesFactory.create(authLevel));
			setAuthStrategy(AuthFactory.create(syst, account.getIdAccountType()));
		} catch (ClassNotFoundException e) {
			logger
					.error(
							"ClassNotFoundException while deserializing AuthAccountEBO from cache", e);
		}

	}
	
	/**
	 * @author bellidori
	 * @version 30 ao�t 09
	 * @see java.lang.Object#hashCode()
	 * @see org.apache.commons.lang.builder.HashCodeBuilder
	 */
	public int hashCode() {

		return new HashCodeBuilder().append(this.getLogin()).append(
				this.getSyst()).append(this.getAuthType()).append(
				this.getAuthLevel()).toHashCode();

	}

	/**
	 * @author bellidori
	 * @version 30 ao�t 09
	 * @see java.lang.Object#equals(java.lang.Object)
	 * @see org.apache.commons.lang.builder.EqualsBuilder
	 */
	public boolean equals(Object obj) {
		final Boolean ret = this.baseEquals(obj);
		if(ret != null) {
			return ret;
		}
		final AuthAccountEBO other = (AuthAccountEBO) obj;
		return new EqualsBuilder().append(this.getLogin(), other.getLogin())
				.append(this.getSyst(), other.getSyst()).append(
						this.getAuthType(), other.getAuthType()).append(
						this.getAuthLevel(), other.getAuthLevel()).isEquals();

	}

	/**
	 * @author bellidori
	 * @version 30 ao�t 09
	 * @see java.lang.Object#toString()
	 * @see org.apache.commons.lang.builder.ToStringBuilder
	 */
	public String toString() {

		return new ToStringBuilder(this)
				.append(
						Messages.getString("AuthAccountEBO.login"), this.getLogin()) //$NON-NLS-1$
				.append(
						Messages.getString("AuthAccountEBO.syst"), this.getSyst()).append(Messages.getString("AuthAccountEBO.type"), //$NON-NLS-1$ //$NON-NLS-2$
						this.getAuthType()).append(
						Messages.getString("AuthAccountEBO.level"), //$NON-NLS-1$
						this.getAuthLevel().toString()).toString();

	}
}
