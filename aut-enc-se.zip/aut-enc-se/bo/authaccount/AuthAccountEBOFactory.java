/*
 * Created on 2 sept. 09
 *
 */
package com.bnppa.sesame.authaccount;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnppa.sesame.account.AccountEBO;
import com.bnppa.sesame.constants.AuthAccountConstants;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;

/**
 * @author bellidori
 * @version 2 sept. 09
 * 
 */
public class AuthAccountEBOFactory {
	
	
	private static final Log logger = LogFactory.getLog(AuthAccountEBOFactory.class);
	
	@Autowired
	private AuthAccountSBO authAccountSBO;

	/**
	 * 
	 * @param authLevel
	 *            level of authentication. It must be equals to
	 *            <code>AuthAccountConstants.LEVEL_LOW</code>(LOW) or
	 *            <code>AuthAccountConstants.LEVEL_MIDDLE</code>(MIDDLE), or
	 *            <code>AuthAccountConstants.LEVEL_STRONG</code>(STRONG)
	 * @param login
	 *            id used when log in. Can not be null. if authType is equals to
	 *            <code>AuthAccountConstants.TYPE_GROUP</code>, login must
	 *            begin by : <br>
	 *            <code>LDAPAttributesKeys.UID_PREFIX</code>, <br>
	 *            or <code>LDAPAttributesKeys.UO_PREFIX</code>, <br>
	 *            or <code>LDAPAttributesKeys.GPE_PREFIX</code>, <br>
	 *            or <code>LDAPAttributesKeys.ISOC_PREFIX</code>
	 * @param syst
	 *            system which manage authentification. it must be equals to
	 *            <code>AuthAccountConstants.SYST_SESAME</code> or,
	 *            <code> AuthAccountConstants.SYST_REFOG</code>
	 * @param authType
	 *            authentication's type. It must be equals to
	 *            <code>AuthAccountConstants.TYPE_CLIENT</code> for customer,
	 *            <br>
	 *            <code>AuthAccountConstants.TYPE_TIERS</code> for third user,
	 *            <br>
	 *            <code>AuthAccountConstants.TYPE_GROUP</code> for internal
	 *            user
	 * @param account
	 *            authorization's account. it cannot be null
	 * @return <br> - instance of CustomerAuthAccountEBO if authType is equals
	 *         to <code>AuthAccountConstants.TYPE_CLIENT</code> <br> -
	 *         instance of AuthAccountEBO if authType is equals to
	 *         <code>AuthAccountConstants.TYPE_TIERS</code> or
	 *         <code>AuthAccountConstants.TYPE_GROUP</code> <br> - null
	 *         otherwise
	 * @throws InvalidParameterBOException
	 *             if login is blank if syst is wrong, if authType is wrong, if
	 *             account is null, if login is wrong
	 */
	protected static AuthAccountEBO create(Integer authLevel, String login,
			String syst, String authType, AccountEBO account) {
		AuthAccountEBO ebo = null;
		if (AuthAccountConstants.TYPE_CLIENT.equals(authType)) {
			ebo = new CustomerAuthAccountEBO(authLevel, login, syst, authType,
					null, null, null, null, account);

		}
		if (AuthAccountConstants.TYPE_TIERS.equals(authType)
				|| AuthAccountConstants.TYPE_GROUP.equals(authType)
				|| AuthAccountConstants.TYPE_VIRTUAL.equals(authType)) {
			ebo = new AuthAccountEBO(authLevel, login, syst, authType, account);

		}
		return ebo;
	}
	
}
