/*
 * Created on Mar 23, 2010
 *
 */
package com.bnppa.sesame.authaccount;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bnppa.sesame.constants.AuthAccountConstants;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;

/**
 * @author behatemo
 * @version Mar 23, 2010
 * 
 */
public class AttributeStrategyFactory {

	private static final Log logger = LogFactory
			.getLog(AttributeStrategyFactory.class);

	private AttributeStrategy tiersAttributeStrategy;

	private AttributeStrategy customerAttributeStrategy;

	private AttributeStrategy groupAttributeStrategy;

	protected AttributeStrategy create(String authType) {

		if (AuthAccountConstants.TYPE_TIERS.equals(authType)) {
			return getTiersAttributeStrategy();
		} else if (AuthAccountConstants.TYPE_GROUP.equals(authType)) {
			return getGroupAttributeStrategy();

		} else if (AuthAccountConstants.TYPE_CLIENT.equals(authType)) {
			return getCustomerAttributeStrategy();

		}

		throw new InvalidParameterBOException(
				InvalidParameterBOExceptionConstants.AUTH_TYPE_IS_INVALID,
				new String[] { authType }, logger);
	}

	/**
	 * @return Returns the customerAttributeStrategy.
	 */
	private AttributeStrategy getCustomerAttributeStrategy() {
		return customerAttributeStrategy;
	}

	/**
	 * @param customerAttributeStrategy
	 *            The customerAttributeStrategy to set.
	 */
	public void setCustomerAttributeStrategy(
			AttributeStrategy customerAttributeStrategy) {
		this.customerAttributeStrategy = customerAttributeStrategy;
	}

	/**
	 * @return Returns the groupAttributeStrategy.
	 */
	private AttributeStrategy getGroupAttributeStrategy() {
		return groupAttributeStrategy;
	}

	/**
	 * @param groupAttributeStrategy
	 *            The groupAttributeStrategy to set.
	 */
	public void setGroupAttributeStrategy(
			AttributeStrategy groupAttributeStrategy) {
		this.groupAttributeStrategy = groupAttributeStrategy;
	}

	/**
	 * @return Returns the tiersAttributeStrategy.
	 */
	private AttributeStrategy getTiersAttributeStrategy() {
		return tiersAttributeStrategy;
	}

	/**
	 * @param tiersAttributeStrategy
	 *            The tiersAttributeStrategy to set.
	 */
	public void setTiersAttributeStrategy(
			AttributeStrategy tiersAttributeStrategy) {
		this.tiersAttributeStrategy = tiersAttributeStrategy;
	}

}
