package com.bnppa.sesame.authaccount;

import java.util.Calendar;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnppa.sesame.channelmessageformat.ChannelMessageFormatEBO;
import com.bnppa.sesame.constants.AuthAccountConstants;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.constants.LoginBOExceptionConstants;
import com.bnppa.sesame.exceptions.ExpiredPasswordBOException;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.InvalidPasswordBOException;
import com.bnppa.sesame.exceptions.LockedAccountBOException;
import com.bnppa.sesame.exceptions.LoginBOException;
import com.bnppa.sesame.exceptions.TechnicalBOException;

/**
 * @author bellidori
 *
 */
public class TECHAuthStrategy implements AuthStrategy {

	/**
	 * Comment for <code>serialVersionUID</code>
	 */
	private static final long serialVersionUID = 1L;

	private static final Log logger = LogFactory.getLog(TECHAuthStrategy.class);

	@Autowired
	private SESAuthStrategy sesAuthStrategy;

	@Autowired
	private REFOGAuthStrategy refogAuthStrategy;

	/**
	 * @see com.bnppa.sesame.authaccount.AuthStrategy#doChangePassword(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      java.lang.String, java.lang.String)
	 */
	public void doChangePassword(AuthAccountEBO authAccountEBO, String oldPassword, String newPassword) throws LoginBOException,
			LockedAccountBOException, InvalidPasswordBOException, TechnicalBOException {
		throw new LoginBOException(LoginBOExceptionConstants.TECHNICAL_ACCOUNT_IS_NOT_AUTHORIZED, logger);
	}

	/**
	 * @see com.bnppa.sesame.authaccount.AuthStrategy#doLogin(java.lang.String,
	 *      com.bnppa.sesame.authaccount.AuthAccountEBO)
	 */
	public void doLogin(String typedPassword, AuthAccountEBO authAccount) throws TechnicalBOException, LoginBOException,
			InvalidParameterBOException, LockedAccountBOException, ExpiredPasswordBOException {
		throw new LoginBOException(LoginBOExceptionConstants.TECHNICAL_ACCOUNT_IS_NOT_AUTHORIZED, logger);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void doLogin(AuthAccountEBO authAccount) throws TechnicalBOException, LoginBOException, InvalidParameterBOException,
			LockedAccountBOException, ExpiredPasswordBOException {
		this.doLogin(authAccount, false);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void doLogin(AuthAccountEBO authAccount, final boolean bypassRefog) throws TechnicalBOException, LoginBOException, InvalidParameterBOException,
			LockedAccountBOException, ExpiredPasswordBOException {
		throw new LoginBOException(LoginBOExceptionConstants.TECHNICAL_ACCOUNT_IS_NOT_AUTHORIZED, logger);
	}
	
	/**
	 * @see com.bnppa.sesame.authaccount.AuthStrategy#doResetAndSendPassword(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      com.bnppa.sesame.channelmessageformat.ChannelMessageFormatEBO,
	 *      java.util.Map, java.util.Calendar)
	 */
	public void doResetAndSendPassword(AuthAccountEBO owner, AuthAccountEBO updator, ChannelMessageFormatEBO channelMessageFormatEBO,
			Map parameters, Calendar sendingDate) throws InvalidParameterBOException, TechnicalBOException {
		throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.TECHNICAL_ACCOUNT_IS_NOT_AUTHORIZED, logger);
	}

	/**
	 * @see com.bnppa.sesame.authaccount.AuthStrategy#doSetPassword(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      com.bnppa.sesame.authaccount.AuthAccountEBO)
	 */
	public String doSetPassword(AuthAccountEBO authAccount, AuthAccountEBO updator) throws InvalidParameterBOException,
			TechnicalBOException {
		if (AuthAccountConstants.SYST_SESAME.equals(authAccount.getSyst())) {
			return sesAuthStrategy.doSetPassword(authAccount, updator);
		} else if (AuthAccountConstants.SYST_REFOG.equals(authAccount.getSyst())) {
			return refogAuthStrategy.doSetPassword(authAccount, updator);
		} else {
			throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.TECHNICAL_ACCOUNT_IS_NOT_AUTHORIZED, logger);
		}
	}

	/**
	 * @see com.bnppa.sesame.authaccount.AuthStrategy#doSetPassword(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      com.bnppa.sesame.authaccount.AuthAccountEBO, java.lang.String)
	 */
	public void doSetPassword(AuthAccountEBO authAccount, AuthAccountEBO updator, String password) throws InvalidPasswordBOException,
			InvalidParameterBOException, TechnicalBOException {
		throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.TECHNICAL_ACCOUNT_IS_NOT_AUTHORIZED, logger);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bnppa.sesame.authaccount.AuthStrategy#doSetPwdExperyDate(com.bnppa
	 * .sesame.authaccount.AuthAccountEBO,
	 * com.bnppa.sesame.authaccount.AuthAccountEBO, java.util.Calendar)
	 */
	public void doSetPwdExperyDate(AuthAccountEBO authAccount, AuthAccountEBO updator, Calendar expiryDate) {
		if (AuthAccountConstants.SYST_SESAME.equals(authAccount.getSyst())) {
			sesAuthStrategy.doSetPwdExperyDate(authAccount, updator, expiryDate);
		} else if (AuthAccountConstants.SYST_REFOG.equals(authAccount.getSyst())) {
			refogAuthStrategy.doSetPwdExperyDate(authAccount, updator, expiryDate);
		} else {
			throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.TECHNICAL_ACCOUNT_IS_NOT_AUTHORIZED, logger);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bnppa.sesame.authaccount.AuthStrategy#doResetPassword(com.bnppa.sesame
	 * .authaccount.AuthAccountEBO, com.bnppa.sesame.authaccount.AuthAccountEBO)
	 */
	public String doResetPassword(AuthAccountEBO owner, AuthAccountEBO updator) throws InvalidParameterBOException, TechnicalBOException {
		throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.TECHNICAL_ACCOUNT_IS_NOT_AUTHORIZED, logger);
	}

}
