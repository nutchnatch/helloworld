/*
 * Created on Aug 28, 2009
 *
 */
package com.bnppa.sesame.authaccount;

import com.bnppa.sesame.AccountTO;
import com.bnppa.sesame.AuthAccountTO;
import com.bnppa.sesame.CustomerAuthAccountTO;
import com.bnppa.sesame.account.AccountEBO;
import com.bnppa.sesame.account.AccountMapper;
import com.bnppa.sesame.constants.AuthAccountConstants;
import com.bnppa.sesame.mapper.AbstractMapper;

/**
 * @author behatemo
 * @version Aug 28, 2009
 * 
 */
public class AuthAccountMapper extends AbstractMapper<AuthAccountTO, AuthAccountEBO> {

	private AccountMapper accountMapper;

	private PasswordMapper passwordMapper;

	/**
	 * @author behatemo
	 * @version Aug 28, 2009
	 * @see com.bnppa.sesame.mapper.Mapper#mapEBOtoTO(java.lang.Object)
	 */
	public AuthAccountTO mapEBOtoTO(AuthAccountEBO sourceObject) {
		if (sourceObject == null) {
			return null;
		}
		if (AuthAccountConstants.TYPE_GROUP
				.equals(sourceObject.getAuthType())
				|| AuthAccountConstants.TYPE_TIERS.equals(sourceObject
						.getAuthType())) {
			AuthAccountTO authAccountTO = new AuthAccountTO(sourceObject
					.getAttemptsNumber(), sourceObject.getAuthLevel(),
					sourceObject.getLogin(), sourceObject.getSyst(),
					sourceObject.getAuthType(), sourceObject
							.getLastConnexion(), (AccountTO) accountMapper
							.mapEBOtoTO(sourceObject.getAccount()));

			return authAccountTO;
		} else if (AuthAccountConstants.TYPE_CLIENT.equals(sourceObject
				.getAuthType())) {
			CustomerAuthAccountEBO customerAuthAccountEBO = (CustomerAuthAccountEBO) sourceObject;
			CustomerAuthAccountTO customerAuthAccountTO = new CustomerAuthAccountTO(
					customerAuthAccountEBO.getAttemptsNumber(),
					customerAuthAccountEBO.getAuthLevel(),
					customerAuthAccountEBO.getLogin(), customerAuthAccountEBO
							.getSyst(), customerAuthAccountEBO.getAuthType(),
					customerAuthAccountEBO.getConvention(),
					customerAuthAccountEBO.getCustomerType(),
					customerAuthAccountEBO.getKeyState(),
					customerAuthAccountEBO.getLastMailDt(),
					customerAuthAccountEBO.getLastConnexion(),
					(AccountTO) accountMapper.mapEBOtoTO(sourceObject
							.getAccount()));

			return customerAuthAccountTO;
		} else {
			return null;
		}
		/*
		 * authAccountTO.setLastPassword((PasswordTO) passwordMapper
		 * .mapEBOtoTO(authAccountEBO.getLastPassword()));
		 */
	}

	/**
	 * @author behatemo
	 * @version Aug 28, 2009
	 * @see com.bnppa.sesame.mapper.Mapper#mapTOtoEBO(java.lang.Object)
	 */
	public AuthAccountEBO mapTOtoEBO(AuthAccountTO sourceObject) {

		if (sourceObject == null) {
			return null;
		}

		AccountEBO accountEBO = (AccountEBO) accountMapper
				.mapTOtoEBO(sourceObject.getAccount());

		// Initialize authSystem to default values
		String autSystem = sourceObject.getSyst();
		if (autSystem == null) {
			if (AuthAccountConstants.TYPE_TIERS.equals(sourceObject
					.getAuthType())
					|| AuthAccountConstants.TYPE_CLIENT.equals(sourceObject
							.getAuthType())) {
				autSystem = AuthAccountConstants.SYST_SESAME;
			} else if (AuthAccountConstants.TYPE_GROUP.equals(autSystem)) {
				autSystem = AuthAccountConstants.SYST_REFOG;
			}
		}

		Integer authLevel = sourceObject.getAuthLevel();
		if (authLevel == null) {
			if (AuthAccountConstants.TYPE_TIERS.equals(sourceObject
					.getAuthType())
					|| AuthAccountConstants.TYPE_CLIENT.equals(sourceObject
							.getAuthType())) {
				authLevel = AuthAccountConstants.LEVEL_MIDDLE;
			} else {
				authLevel = AuthAccountConstants.LEVEL_LOW;
			}
		}

		AuthAccountEBO ebo = AuthAccountEBOFactory.create(authLevel,
				sourceObject.getLogin(), autSystem, sourceObject
						.getAuthType(), accountEBO);
		ebo.setAttemptsNumber(sourceObject.getAttemptsNumber());
		if (sourceObject.getLastConnexion() != null)
			ebo.setLastConnexion(sourceObject.getLastConnexion());
		if (AuthAccountConstants.TYPE_GROUP.equals(ebo.getAuthType())) {
			// ebo.setAttributes(authAccountTO.getAttributes());
		}

		if (AuthAccountConstants.TYPE_CLIENT
				.equals(sourceObject.getAuthType())) {
			CustomerAuthAccountTO customerAuthAccountTO = (CustomerAuthAccountTO) sourceObject;
			CustomerAuthAccountEBO customerAuthAccountEBO = (CustomerAuthAccountEBO) ebo;
			customerAuthAccountEBO.setKeyState(customerAuthAccountTO
					.getKeyState());
			customerAuthAccountEBO.setCustomerType(customerAuthAccountTO
					.getCustomerType());
			customerAuthAccountEBO.setLastMailDt(customerAuthAccountTO
					.getLastMailDt());
			customerAuthAccountEBO.setConvention(customerAuthAccountTO
					.getConvention());
		}
		return ebo;

	}

	/**
	 * @return accountMapper
	 */
	public AccountMapper getAccountMapper() {
		return accountMapper;
	}

	/**
	 * @param accountMapper
	 */
	public void setAccountMapper(AccountMapper accountMapper) {
		this.accountMapper = accountMapper;
	}

	/**
	 * @return Returns the passwordMapper.
	 */
	public PasswordMapper getPasswordMapper() {
		return passwordMapper;
	}

	/**
	 * @param passwordMapper
	 *            The passwordMapper to set.
	 */
	public void setPasswordMapper(PasswordMapper passwordMapper) {
		this.passwordMapper = passwordMapper;
	}

	/**
	 * @author bellidori
	 * @version 2 sept. 09
	 * @see com.bnppa.sesame.mapper.Mapper#mapEBOtoTO(java.lang.Object,
	 *      java.lang.Object)
	 */
	public Object mapEBOtoTO(AuthAccountEBO sourceObject, Object ownerObject) {

		return mapEBOtoTO(sourceObject);
	}

}
