/*
 * Created on Jul 30, 2009
 *
 */
package com.bnppa.sesame.authaccount;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;

import com.bnppa.sesame.exceptions.InvalidPasswordBOException;

/**
 * @author bellidori
 * @version Jul 30, 2009
 * 
 */
public interface SecurityRulesStrategy extends Serializable {
	
	/**
	 * checks if the new password meets the security policies
	 * 
	 * @param newPwd
	 *            new password to check
	 * @param passwords
	 *            previous passwords in descending order
	 * @return true if new password meets the security policies, false otherwise
	 * @throws InvalidPasswordBOException if password is not valid
	 */
	public boolean checkPwd(final String newPwd, final List<PasswordEBO> passwords) throws InvalidPasswordBOException;
	
	/**
	 * checks if the new password meets the security policies for the Client AccountType
	 * 
	 * @param password
	 *            new password to check
	 * @param passwords
	 *            previous passwords in descending order
	 * @param clientType type of the client
	 * @return true if new password meets the security policies for the Client AccountType, false otherwise
	 * @throws InvalidPasswordBOException if password is not valid
	 */
	public boolean checkPwdClient(String password, List passwords, String clientType) throws InvalidPasswordBOException;

	/**
	 * generates a new password that complies with security policies
	 * 
	 * @param passwords
	 *            previous passwords in descending order
	 * @return new password
	 */
	public String generatePwd(List passwords);
	
	/**
	 * generates a new password that complies with security policies 
	 * for the Client AccountType
	 * @param passwords
	 *            previous passwords in descending order
	 * @param clientType type of the client.
	 * @return new password
	 */
	public String generatePwdClient(List passwords, String clientType);
	
	/**
	 * generate expiry date from today
	 * @param updateDate date of password updating
	 * @return expiry date
	 */
	public Calendar generateExpiryDate(Calendar updateDate);
	
	/**
	 * this method retrieves the account lock duration
	 * @return account lock duration in seconds
	 */
	public int getAccountLockDuration();
}
