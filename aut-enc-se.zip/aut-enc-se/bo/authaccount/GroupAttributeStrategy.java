/*
 * Created on Mar 23, 2010
 *
 */
package com.bnppa.sesame.authaccount;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bnppa.sesame.account.AccountEBO;
import com.bnppa.sesame.constants.UnsupportedActionBOExceptionConstants;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.UnsupportedActionBOException;

/**
 * @author behatemo
 * @version Mar 23, 2010
 * 
 */
public class GroupAttributeStrategy implements AttributeStrategy {

	private static final Log logger = LogFactory
			.getLog(GroupAttributeStrategy.class);

	/**
	 * @author behatemo
	 * @version Mar 23, 2010
	 * @see com.bnppa.sesame.authaccount.AttributeStrategy#doAddAttribute(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      java.lang.String, java.lang.String, com.bnppa.sesame.account.AccountEBO)
	 */
	public void doAddAttribute(AuthAccountEBO authAccountEBO, String key,
			String value, AccountEBO updatorAccountEBO) throws UnsupportedActionBOException,
			InvalidParameterBOException, ClassCastException {
		throw new UnsupportedActionBOException(
				UnsupportedActionBOExceptionConstants.UNSUPPORTED_ACTION,
				logger);
	}
	
	/**
	 * @see com.bnppa.sesame.authaccount.AttributeStrategy#doAddAttribute(com.bnppa.sesame.authaccount.AuthAccountEBO,
	 *      java.lang.String, java.lang.String, com.bnppa.sesame.account.AccountEBO, boolean)
	 */
	public void doAddAttribute(AuthAccountEBO authAccountEBO, String key,
			String value, AccountEBO updatorAccountEBO, boolean isAdvanced) throws UnsupportedActionBOException,
			InvalidParameterBOException, ClassCastException {
		throw new UnsupportedActionBOException(
				UnsupportedActionBOExceptionConstants.UNSUPPORTED_ACTION,
				logger);
	}

}
