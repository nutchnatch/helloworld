/*
 * Created on 3 sept. 09
 *
 */
package com.bnppa.sesame.authaccount;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnppa.sesame.constants.CustomerConstants;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.constants.InvalidPasswordBOExceptionConstants;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.InvalidPasswordBOException;
import com.bnppa.sesame.hash.HashAlgorithm;
import com.bnppa.sesame.services.exception.FunctionalException;
import com.bnppa.sesame.services.exception.TechnicalException;
import com.bnppa.sesame.utils.PropertyLoader;
import com.bnppa.sesame.utils.StringAnalyser;

/**
 * @author bellidori
 * @version 3 sept. 09
 * 
 */
public abstract class SecurityRulesStrategyImpl implements SecurityRulesStrategy {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Log logger = LogFactory.getLog(SecurityRulesStrategyImpl.class);

	private static final String CLIENT_MIN_NUMBER_NUMERIC_CHARACTERS_PROPERTY_NAME = "client.password.min.numeric.characters";
	private static final String CLIENT_MIN_NUMBER_NUMERIC_CHARACTERS_WEBSAL_PROPERTY_NAME = "client.websal.password.min.numeric.characters";
	private static final String ACOUNT_LOCK_DURATION = "account.lock.duration";
	private static final String SECURITY_STRATEGY_PROPERTIES_PATH = "properties/security_strategy.properties";
	private static final String CANNOT_READ_THE_SECURITY_STRATEGY_PROPERTIES_FILE = "Can't read the security_strategy properties file.";
	private static final String FAIL_TO_LOAD_SECURITY_STRATEGY_PROPERTIES_FILE = "Can't find the security_strategy properties file.";
	protected static final Properties strategyProperties;
	private static final int clientMinNumberNumericCharacters;
	private static final int clientMinNumberNumericCharactersWebSal;
	private static final int accountLockDuration;

	@Autowired
	private HashAlgorithm hashAlgorithm;

	static {
		try {
			strategyProperties = PropertyLoader.loadProperties(SECURITY_STRATEGY_PROPERTIES_PATH);
			clientMinNumberNumericCharacters = Integer.valueOf(
					strategyProperties.getProperty(CLIENT_MIN_NUMBER_NUMERIC_CHARACTERS_PROPERTY_NAME)).intValue();
			clientMinNumberNumericCharactersWebSal = Integer.valueOf(
					strategyProperties.getProperty(CLIENT_MIN_NUMBER_NUMERIC_CHARACTERS_WEBSAL_PROPERTY_NAME)).intValue();
			accountLockDuration = Integer.valueOf(strategyProperties.getProperty(ACOUNT_LOCK_DURATION)).intValue();
		} catch (FileNotFoundException e) {
			throw new RuntimeException(FAIL_TO_LOAD_SECURITY_STRATEGY_PROPERTIES_FILE);
		} catch (IOException e) {
			throw new RuntimeException(CANNOT_READ_THE_SECURITY_STRATEGY_PROPERTIES_FILE);
		}
	}

	/**
	 * 
	 * create a new instance
	 * 
	 * @author behatemo
	 * @version Sep 4, 2009
	 * 
	 *          Default constructor
	 * 
	 */
	protected SecurityRulesStrategyImpl() {
	}

	/**
	 * 
	 * create a new instance
	 * 
	 * @author behatemo
	 * @version Sep 4, 2009
	 * 
	 *          Default constructor
	 * 
	 */
	protected SecurityRulesStrategyImpl(final HashAlgorithm hashAlgorithm) {
		this.hashAlgorithm = hashAlgorithm;
	}
	
	/**
	 * @author bellidori
	 * @version 3 sept. 09
	 * @throws InvalidPasswordBOException
	 * @see com.bnppa.sesame.authaccount.SecurityRulesStrategy#checkPwd(java.lang.String,
	 *      java.util.List)
	 */
	@Override
	public boolean checkPwd(final String newPwd, final List<PasswordEBO> passwords) throws InvalidPasswordBOException {
		boolean isValid = true;

		if (passwords == null) {
			throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_PWDS_IS_NULL, logger);
		}

		if (newPwd == null) {
			throw new InvalidPasswordBOException(InvalidPasswordBOExceptionConstants.NEW_PASSWORD_IS_NULL, logger);

		}

		int numberOldPasswordCompared = 1;

		for(final PasswordEBO oldPassword : passwords) {
			if (numberOldPasswordCompared++ > this.getNumberOldPwdToCompare()) {
				break;
			}
			if (oldPassword == null) {
				throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_PWDS_IS_NULL, logger);
			}

			try {
				hashAlgorithm.checkEncryptedPassword(newPwd, oldPassword);
				throw new InvalidPasswordBOException(InvalidPasswordBOExceptionConstants.NEW_PASSWORD_IS_TO_ONE_OF_LAST_OLD_PASSWORD,
						new String[] { new Integer(getNumberOldPwdToCompare()).toString() }, logger);
			} catch (TechnicalException e) {
				logger.error(e);
			} catch (FunctionalException e) {
				//this is what we want to happen
				SecurityRulesStrategyImpl.logger.debug("old password " + numberOldPasswordCompared + " missmatch as expected");
			}
		}
		
		StringAnalyser newPasswordAnalyze = new StringAnalyser(newPwd);

		// check length of new password
		if (newPasswordAnalyze.getLength() < getMinLengthPassword()) {
			throw new InvalidPasswordBOException(InvalidPasswordBOExceptionConstants.NEW_PASSWORD_LENGTH_LESS_THAN_MIN,
					new String[] { new Integer(getMinLengthPassword()).toString() }, logger);

		}
		// check Numeric Character
		if (newPasswordAnalyze.getNumberNumericCharacters() < getMinNumberNumericCharacters()) {

			throw new InvalidPasswordBOException(InvalidPasswordBOExceptionConstants.NEW_PASSWORD_DOES_NOT_CONTAIN_ENOUGH_NUMERIC,
					new String[] { new Integer(getMinNumberNumericCharacters()).toString() }, logger);

		}
		// check Alpha Character
		if (newPasswordAnalyze.getNumberAlphaCharacters() < getMinNumberLowerAlphaCharacters() + getMinNumberUpperAlphaCharacters()) {

			throw new InvalidPasswordBOException(InvalidPasswordBOExceptionConstants.NEW_PASSWORD_DOES_NOT_CONTAIN_ENOUGH_CHARACTERS,
					new String[] { new Integer(getMinNumberLowerAlphaCharacters() + getMinNumberUpperAlphaCharacters()).toString() },
					logger);

		}
		// check special Character
		if (newPasswordAnalyze.getNumberSpecialCharacters() < getMinNumberSpecialCharacters()) {

			throw new InvalidPasswordBOException(InvalidPasswordBOExceptionConstants.NEW_PASSWORD_DOES_NOT_CONTAIN_ENOUGH_SPECIALS,
					new String[] { new Integer(getMinNumberSpecialCharacters()).toString() }, logger);
		}

		return isValid;
	}

	public boolean checkPwdClient(String newPwd, List passwords, String clientType) throws InvalidPasswordBOException {

		boolean isValid = true;

		if (passwords == null) {
			throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_PWDS_IS_NULL, logger);
		}

		if (newPwd == null) {
			throw new InvalidPasswordBOException(InvalidPasswordBOExceptionConstants.NEW_PASSWORD_IS_NULL, logger);

		}

		int numberOldPasswordCompared = 1;

		for (Iterator iterator = passwords.iterator(); iterator.hasNext();) {
			if (numberOldPasswordCompared > this.getNumberOldPwdToCompare())
				break;
			PasswordEBO oldPassword = (PasswordEBO) iterator.next();
			if (oldPassword == null) {
				throw new InvalidParameterBOException(InvalidParameterBOExceptionConstants.AUTH_ACCOUNT_PWDS_IS_NULL, logger);
			}
			try {
				hashAlgorithm.checkEncryptedPassword(newPwd, oldPassword);
				throw new InvalidPasswordBOException(InvalidPasswordBOExceptionConstants.NEW_PASSWORD_IS_TO_ONE_OF_LAST_OLD_PASSWORD,
						new String[] { new Integer(getNumberOldPwdToCompare()).toString() }, logger);
			} catch (TechnicalException e) {
				logger.error(e);
			} catch (FunctionalException e) {
				// this is what we want to happen
				SecurityRulesStrategyImpl.logger.debug("old password " + numberOldPasswordCompared + " missmatch as expected");
			}
			numberOldPasswordCompared++;
		}
		StringAnalyser newPasswordAnalyze = new StringAnalyser(newPwd);

		// check length of new password
		if (newPasswordAnalyze.getLength() < getClientMinNumberNumericCharacters(clientType)) {
			throw new InvalidPasswordBOException(InvalidPasswordBOExceptionConstants.NEW_PASSWORD_LENGTH_LESS_THAN_MIN,
					new String[] { new Integer(getClientMinNumberNumericCharacters(clientType)).toString() }, logger);

		}
		// check Numeric Character
		if (newPasswordAnalyze.getNumberNumericCharacters() < getClientMinNumberNumericCharacters(clientType)) {

			throw new InvalidPasswordBOException(InvalidPasswordBOExceptionConstants.NEW_PASSWORD_DOES_NOT_CONTAIN_ENOUGH_NUMERIC,
					new String[] { new Integer(getClientMinNumberNumericCharacters(clientType)).toString() }, logger);

		}

		return isValid;

	}

	/**
	 * @param clientType
	 *            type of the client
	 * @return the minimum of numeric character in the client password.
	 */
	private int getClientMinNumberNumericCharacters(String clientType) {
		if (CustomerConstants.TOP_NATURE_CLIENT_E.equals(clientType)) {
			return clientMinNumberNumericCharactersWebSal;
		}
		return clientMinNumberNumericCharacters;
	}

	/**
	 * @author bellidori
	 * @version 3 sept. 09
	 * @see com.bnppa.sesame.authaccount.SecurityRulesStrategy#generateExpiryDate(java.util.Calendar)
	 */
	public Calendar generateExpiryDate(Calendar updateDate) {
		Calendar expiryDt = (Calendar) updateDate.clone();
		expiryDt.add(GregorianCalendar.DATE, getPasswordValidityTimeLimit());
		return expiryDt;
	}

	/**
	 * Generate a password with parameters contraints
	 * 
	 * @param minimalPwdLength
	 * @param maximalPwdLength
	 * @param minNbLowerLetters
	 * @param minNbUpperLetters
	 * @param minNbInteger
	 * @param minNbSpecialChar
	 * @param maxNbLowerLetters
	 * @param maxNbUpperLetters
	 * @param maxNbInteger
	 * @param maxNbSpecialChar
	 * @return a new password
	 */
	public String generatePwd(List passwords) {
		StringBuffer pwd = new StringBuffer();

		String fullAlphabet = "";
		String lowerLetters = "abcdefghijklmnopqrstuvwxyz";
		String upperLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String numerique = "1234567890";
		String special = "*+!&$"; // -=/!&$_"; //"_-@#&'(!?)%:;/.,";

		Random rand = new Random();
		int nbPwdChars = 0;
		if (getMaxLengthPassword() > getMinLengthPassword()) {
			nbPwdChars = rand.nextInt(getMaxLengthPassword() - getMinLengthPassword() + 1);
		}
		int totalChar = 0;
		int cptNbLowerLetters = 0;
		int cptNbInteger = 0;
		int cptNbSpecialChar = 0;
		int cptNbUpperLetters = 0;
		// Minimum characters to add
		for (int i = 0; i < getMinNumberLowerAlphaCharacters(); i++) {
			pwd.append(lowerLetters.charAt(rand.nextInt(lowerLetters.length())));
			totalChar++;
			cptNbLowerLetters++;
		}
		for (int i = 0; i < getMinNumberNumericCharacters(); i++) {
			pwd.append(numerique.charAt(rand.nextInt(numerique.length())));
			totalChar++;
			cptNbInteger++;
		}
		for (int i = 0; i < getMinNumberSpecialCharacters(); i++) {
			pwd.append(special.charAt(rand.nextInt(special.length())));
			totalChar++;
			cptNbSpecialChar++;
		}
		for (int i = 0; i < getMinNumberUpperAlphaCharacters(); i++) {
			pwd.append(upperLetters.charAt(rand.nextInt(upperLetters.length())));
			totalChar++;
			cptNbUpperLetters++;
		}

		// Fill the password with others characters
		for (int i = totalChar; i < getMinLengthPassword() + nbPwdChars; i++) {
			// R�initialisation alphabet
			fullAlphabet = "";
			if ((getMaxNumberLowerAlphaCharacters() == -1)
					|| (getMaxNumberLowerAlphaCharacters() != -1 && cptNbLowerLetters < getMaxNumberLowerAlphaCharacters())) {
				fullAlphabet += lowerLetters;
			}
			if ((getMaxNumberUpperAlphaCharacters() == -1)
					|| (getMaxNumberNumericCharacters() != -1 && cptNbInteger < getMaxNumberNumericCharacters())) {
				fullAlphabet += upperLetters;
			}
			if ((getMaxNumberNumericCharacters() == -1)
					|| (getMaxNumberSpecialCharacters() != -1 && cptNbSpecialChar < getMaxNumberSpecialCharacters())) {
				fullAlphabet += numerique;
			}
			if ((getMaxNumberSpecialCharacters() == -1)
					|| (getMaxNumberUpperAlphaCharacters() != -1 && cptNbUpperLetters < getMaxNumberUpperAlphaCharacters())) {
				fullAlphabet += special;
			}
			char selectedCharacter = fullAlphabet.charAt(rand.nextInt(fullAlphabet.length()));
			pwd.append(selectedCharacter);
			if (lowerLetters.indexOf(selectedCharacter) != -1) {
				cptNbLowerLetters++;
			} else if (upperLetters.indexOf(selectedCharacter) != -1) {
				cptNbUpperLetters++;
			} else if (numerique.indexOf(selectedCharacter) != -1) {
				cptNbInteger++;
			} else if (special.indexOf(selectedCharacter) != -1) {
				cptNbSpecialChar++;
			}
		}

		return sortPassword(pwd.toString());
	}

	public String generatePwdClient(List passwords, String clientType) {

		StringBuffer pwd = new StringBuffer();
		String numerique = "1234567890";

		Random rand = new Random();

		for (int i = 0; i < getClientMinNumberNumericCharacters(clientType); i++) {
			pwd.append(numerique.charAt(rand.nextInt(numerique.length())));
		}

		return sortPassword(pwd.toString());

	}

	/**
	 * Melange les caract�res
	 * 
	 * @param password
	 * @return password
	 */
	private String sortPassword(String password) {
		char temp;
		char[] pwdBuffer = new char[password.length()];
		password.getChars(0, password.length(), pwdBuffer, 0);
		Random rnd = new Random();
		int length = pwdBuffer.length;

		for (int i = 0; i < length; i++) {
			int j = rnd.nextInt(length - 1);
			temp = pwdBuffer[i];
			pwdBuffer[i] = pwdBuffer[j];
			pwdBuffer[j] = temp;
		}
		return String.copyValueOf(pwdBuffer);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.bnppa.sesame.authaccount.SecurityRulesStrategy#getAccountLockDuration
	 * ()
	 */
	public int getAccountLockDuration() {
		return accountLockDuration;
	}

	/**
	 * @author bellidori
	 * @version 1.0,09/24/08
	 * @return number of days of password validity
	 */
	public abstract int getPasswordValidityTimeLimit();

	/**
	 * get the minimum length of password
	 * 
	 * @return the minimum length of password
	 * @author bellidori
	 * @version 1.0,09/24/08
	 */
	public abstract int getMinLengthPassword();

	/**
	 * get the maximum length of password
	 * 
	 * @return the maximum length of password
	 * @author bellidori
	 * @version 1.0,09/24/08
	 */
	public abstract int getMaxLengthPassword();

	/**
	 * get the minimum number of lower alpha characters
	 * 
	 * @return the minimum number of lower alpha characters
	 * @author marotph
	 * @version 1.0, 24/02/2010
	 */
	public abstract int getMinNumberLowerAlphaCharacters();

	/**
	 * get the maximum number of lower alpha characters
	 * 
	 * @return the maximum number of lower alpha characters
	 * @author marotph
	 * @version 1.0, 24/02/2010
	 */
	public abstract int getMaxNumberLowerAlphaCharacters();

	/**
	 * get the minimum number of upper alpha characters
	 * 
	 * @return the minimum number of upper alpha characters
	 * @author marotph
	 * @version 1.0, 24/02/2010
	 */
	public abstract int getMinNumberUpperAlphaCharacters();

	/**
	 * get the maximum number of upper alpha characters
	 * 
	 * @return the maximum number of upper alpha characters
	 * @author marotph
	 * @version 1.0, 24/02/2010
	 */
	public abstract int getMaxNumberUpperAlphaCharacters();

	/**
	 * get the minimum number of numeric characters
	 * 
	 * @return the minimum number of numeric characters
	 * @author bellidori
	 * @version 1.0,09/24/08
	 */
	public abstract int getMinNumberNumericCharacters();

	/**
	 * get the maximum number of numeric characters
	 * 
	 * @return the maximum number of numeric characters
	 * @author bellidori
	 * @version 1.0,09/24/08
	 */
	public abstract int getMaxNumberNumericCharacters();

	/**
	 * get the minimum number of special characters
	 * 
	 * @return the minimum number of special characters
	 * @author bellidori
	 * @version 1.0,09/24/08
	 */
	public abstract int getMinNumberSpecialCharacters();

	/**
	 * get the maximum number of special characters
	 * 
	 * @return the maximum number of special characters
	 * @author bellidori
	 * @version 1.0,09/24/08
	 */
	public abstract int getMaxNumberSpecialCharacters();

	/**
	 * get the number of previous passwords with which to compare the new
	 * password
	 * 
	 * @return the number of previous passwords with which to compare the new
	 *         password
	 * @author bellidori
	 * @version 1.0,09/24/08
	 */
	public abstract int getNumberOldPwdToCompare();

}
