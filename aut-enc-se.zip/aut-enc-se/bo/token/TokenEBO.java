/*
 * Created on Aug 6, 2009
 */
package com.bnppa.sesame.token;

import java.lang.ref.SoftReference;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.CompareToBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bnppa.sesame.authaccount.AuthAccountEBO;
import com.bnppa.sesame.constants.AccountConstants;
import com.bnppa.sesame.constants.AuthenticationLevelConstants;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.ebo.AbstractEBO;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.message.Messages;

/**
 * @author polancoro
 * @author brumal
 * @author bellidori
 * @version Aug 6, 2009
 * @version Apr 21, 2010
 * @version 19/08/10 : dissociate token for virtual authaccount from others
 */
public class TokenEBO extends AbstractEBO implements Comparable<TokenEBO> {

	/**
	 * serialVersionUID generated the 19/08/10 
	 */
	private static final long	serialVersionUID	= -2679670899336442925L;

	

	private static transient final Log	logger				= LogFactory
																	.getLog(TokenEBO.class);

	/**
	 * Authentification account entity bussiness object
	 * SoftReference<AuthAccountEBO>
	 */
	protected transient SoftReference<AuthAccountEBO>	authAccount;

	private String						id;

	/**
	 * level of authentication
	 * 
	 * @value <code>AuthAccountConstants.LEVEL_LOW</code>(LOW),<br>
	 *        <code>AuthAccountConstants.LEVEL_MIDDLE</code>(MIDDLE), <br>
	 *        <code>AuthAccountConstants.LEVEL_STRONG</code>(STRONG)
	 * @inv <code>AuthAccountConstants.LEVEL_LOW</code>.equals(authLevel) ||
	 *      <code>AuthAccountConstants.LEVEL_MIDDLE</code>.equals(authLevel) ||
	 *      <code>AuthAccountConstants.LEVEL_STRONG</code>.equals(authLevel)
	 */
	private Integer						authLevel;

	/**
	 * id used to log in
	 * 
	 * @inv (!StringUtils.isBlank(login)) && (<code>(AuthAccountConstants.TYPE_GROUP</code>.equals(authType)) =>
	 *      login.startsWith(LDAPAttributesKeys.UID_PREFIX) ||
	 *      userLogin.startsWith(LDAPAttributesKeys.UO_PREFIX) ||
	 *      userLogin.startsWith(LDAPAttributesKeys.GPE_PREFIX) ||
	 *      userLogin.startsWith(LDAPAttributesKeys.ISOC_PREFIX))
	 */
	private String						login;

	/**
	 * @value <code>AuthAccountConstants.SYST_SESAME</code>, <br>
	 *        <code> AuthAccountConstants.SYST_REFOG</code>
	 * @inv <code>AuthAccountConstants.SYST_SESAME</code>.equals(syst) ||
	 *      <code> AuthAccountConstants.SYST_REFOG</code>.equals(syst)
	 */
	private String						syst;

	/**
	 * @value <code>AuthAccountConstants.TYPE_CLIENT</code>, <br>
	 *        <code>AuthAccountConstants.TYPE_TIERS</code>, <br>
	 *        <code>AuthAccountConstants.TYPE_GROUP</code>
	 */
	private String						authType;
	
	
	/**
	 * idAccountType
	 */
	private String idAccountType;
	
	/**
	 * idApplication
	 */
	private String idApplication;
	
	// Authentication level of the token, by default MEDIUM can be TOTP
	private String authenticationLevel;
	

	/**
	 * create a new instance
	 * 
	 * @author polancoro
	 * @version Aug 6, 2009
	 * @param id
	 *            token's identifier. it can not be blank.
	 * @param authAccountEBO
	 *            authentication account link to this token. It can not be null.
	 * @throws InvalidParameterBOException
	 *             if id is blank or if authAccount is null
	 */
	protected TokenEBO(String id, AuthAccountEBO authAccountEBO) {
		super();

		if (StringUtils.isBlank(id)) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.TOKEN_ID_IS_BLANK,
					new String[] { id }, logger);
		}

		if (authAccountEBO == null) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.TOKEN_AUTH_ACCOUNT_IS_NULL,
					logger);
		}

		setId(id);
		setAuthAccount(authAccountEBO);

		// save data needed to find authAccount
		setLogin(authAccountEBO.getLogin());
		setAuthLevel(authAccountEBO.getAuthLevel());
		setSyst(authAccountEBO.getSyst());
		setAuthType(authAccountEBO.getAuthType());
		
		if (authAccountEBO.getAccount() == null) 
		{
			throw new InvalidParameterBOException(
				InvalidParameterBOExceptionConstants.ACCOUNT_FROM_TOKEN_AUTH_ACCOUNT_IS_NULL,
				logger);
		}
		if(AccountConstants.TYPE_APPLICATION.equals(authAccountEBO.getAccount().getIdAccountType()))
		{
			setIdAccountType(authAccountEBO.getAccount().getIdAccountType());
		}
		
		// set default level of authentication level to MEDIUM
		setAuthenticationLevel(AuthenticationLevelConstants.MEDIUM_LEVEL);
	}

	
	/**
	 * create a new instance
	 * 
	 * @param id
	 *            token's identifier. it can not be blank.
	 * @param authAccountEBO
	 *            authentication account link to this token. It can not be null.
	 * @param idApplication
	 *            id application.
	 * @throws InvalidParameterBOException
	 *             if id is blank or if authAccount is null
	 */
	protected TokenEBO(String id, AuthAccountEBO authAccountEBO, String idApplication)
	{
		this(id, authAccountEBO);
		setIdApplication(idApplication);
	}

	
	
	/**
	 * GETTERS AND SETTERS
	 */
	public String getId() {
		return id;
	}

	private void setId(String id) {
		this.id = id;
	}

	public String getAuthenticationLevel() {
		return authenticationLevel;
	}

	public void setAuthenticationLevel(String authenticationLevel) {
		this.authenticationLevel = authenticationLevel;
	}

	protected Integer getAuthLevel() {
		return authLevel;
	}

	protected String getAuthType() {
		return authType;
	}

	protected String getLogin() {
		return login;
	}

	protected String getSyst() {
		return syst;
	}

	protected void setAuthLevel(Integer authLevel) {
		this.authLevel = authLevel;
	}

	protected void setAuthType(String authType) {
		this.authType = authType;
	}

	protected void setLogin(String login) {
		this.login = login;
	}

	protected void setSyst(String syst) {
		this.syst = syst;
	}

	public String getIdAccountType() {
		return idAccountType;
	}

	protected void setIdAccountType(String idAccountType) {
		this.idAccountType = idAccountType;
	}

	protected String getIdApplication() {
		return idApplication;
	}

	protected void setIdApplication(String idApplication) {
		this.idApplication = idApplication;
	}

	protected AuthAccountEBO getAuthAccount() {
		if (this.authAccount == null) {
			return null;
		}
		return this.authAccount.get();
	}

	protected void setAuthAccount(AuthAccountEBO authAccount) {
		this.authAccount = new SoftReference<AuthAccountEBO>(authAccount);
	}
	
	/**
	 * improved GETTERs
	 */
	protected String getPersonFirstName() {

		AuthAccountEBO localAuthAccount = this.getAuthAccount();
		if (localAuthAccount == null) {
			return null;
		}
		return localAuthAccount.getAccount().getPerson().getFirstName();
	}

	protected String getPersonLastName() {
		AuthAccountEBO localAuthAccount = this.getAuthAccount();
		if (localAuthAccount == null) {
			return null;
		}
		return localAuthAccount.getAccount().getPerson().getLastName();
	}

	protected String getAccountType() {
		AuthAccountEBO localAuthAccount = this.getAuthAccount();
		if (localAuthAccount == null) {
			return null;
		}
		return localAuthAccount.getAccount().getIdAccountType();

	}

	protected String getPersonId() {
		AuthAccountEBO localAuthAccount = this.getAuthAccount();
		if (localAuthAccount == null) {
			return null;
		}
		return localAuthAccount.getAccount().getPerson().getId();
	}

	protected String getAccountId() {
		AuthAccountEBO localAuthAccount = this.getAuthAccount();
		if (localAuthAccount == null) {
			return null;
		}
		return localAuthAccount.getAccount().getId();
	}
	
	
	/**
	 * UTILITY METHODS
	 */

	
	
	/**
	 * @author bellidori
	 * @version 27 ao�t 09
	 * @see java.lang.Object#hashCode()
	 * @see org.apache.commons.lang.builder.HashCodeBuilder
	 */
	public int hashCode() {

		return new HashCodeBuilder().append(this.getId()).toHashCode();

	}

	/**
	 * @author bellidori
	 * @version 27 ao�t 09
	 * @see java.lang.Object#equals(java.lang.Object)
	 * @see org.apache.commons.lang.builder.EqualsBuilder
	 */
	public boolean equals(Object obj) {
		final Boolean ret = this.baseEquals(obj);
		if(ret != null) {
			return ret;
		}
		final TokenEBO other = (TokenEBO) obj;
		return new EqualsBuilder()
				.append(this.getId(), other.getId())
				.append(this.getAuthLevel(), other.getAuthLevel())
				.append(this.getLogin(), other.getLogin())
				.append(this.getSyst(),	other.getSyst())
				.append(this.getAuthType(), other.getAuthType())
				.isEquals();

	}

	/**
	 * @author marotph
	 * @version 12 janvier 2010
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 * @see org.apache.commons.lang.builder#toComparison()
	 */
	public int compareTo(final TokenEBO objectToCompare) {
		return new CompareToBuilder().append(this.getId(),
				objectToCompare.getAuthLevel()).append(this.getLogin(),
				objectToCompare.getSyst()).append(this.getAuthType(),
				objectToCompare.getAuthType()).toComparison();

	}

	/**
	 * @author bellidori
	 * @version 27 ao�t 09
	 * @see java.lang.Object#toString()
	 * @see org.apache.commons.lang.builder.ToStringBuilder
	 */
	public String toString() {

		return new ToStringBuilder(this).append(
				Messages.getString("TokenEBO.id"), this.getId()).toString(); //$NON-NLS-1$

	}	
}
