/*
 * Created on Aug 6, 2009
 */
package com.bnppa.sesame.token;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.bnppa.sesame.account.AccountEBO;
import com.bnppa.sesame.authaccount.AuthAccountEBO;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.person.PersonEBO;

/**
 * @author bellidori
 * @version 19/08/10
 */
public class TokenForVirtualAuthAccountEBO extends TokenEBO {

	/**
	 * generated the 19/08/10
	 */
	private static final long	serialVersionUID	= 5559931906636861440L;

	/**
	 * The connected person first name.
	 */
	private String				personFirstName;

	/**
	 * The connected person last name.
	 */
	private String				personLastName;

	/**
	 * Set<String> The connected person e-mail.
	 */
	private Set					personEmail;

	private String				personId;

	/**
	 * The all the parent account identifiers of the actual account. Set<String>
	 */
	private Set					parentAccountIds;

	/**
	 * Type of account
	 * 
	 * @value user, appli, demo
	 */
	private String				accountType;

	private String				accountId;

	/**
	 * create a new instance and save data needed to restore virtual auth
	 * account
	 * 
	 * @author bellidori
	 * @param id
	 *            token's identifier. it can not be blank.
	 * @param authAccountEBO
	 *            authentication account link to this token. It can not be null.
	 * @throws InvalidParameterBOException
	 *             if id is blank or if authAccount is null
	 */
	protected TokenForVirtualAuthAccountEBO(String id, AuthAccountEBO authAccountEBO) {
		super(id, authAccountEBO);

		AccountEBO account = authAccountEBO.getAccount();
		this.setAccountId(account.getId());
		this.setAccountType(account.getIdAccountType());

		// save id of parent accounts
		Set localParentAccountIds = new HashSet();
		for (Iterator iter = account.getParentAccounts().iterator(); iter
				.hasNext();) {
			AccountEBO parentAccountEBO = (AccountEBO) iter.next();
			localParentAccountIds.add(parentAccountEBO.getId());
		}
		setParentAccountIds(localParentAccountIds);

		// save data of person
		PersonEBO person = account.getPerson();
		setPersonId(person.getId());
		setPersonFirstName(person.getFirstName());
		setPersonLastName(person.getLastName());



	}

	/**
	 * @return the parentAccountIds
	 */
	protected Set findParentAccountIdsInEBO() {
		return this.parentAccountIds;
	}

	/**
	 * @param parentAccountIds
	 *            the parentAccountIds to set
	 */
	private void setParentAccountIds(Set parentAccountIds) {
		this.parentAccountIds = parentAccountIds;
	}

	/**
	 * @return the personEmail
	 */
	protected Set findPersonEmailInEBO() {
		return this.personEmail;
	}

	/**
	 * @param personEmail
	 *            the personEmail to set
	 */
	protected void setPersonEmail(Set personEmail) {
		this.personEmail = personEmail;
	}

	/**
	 * @return the personFirstName
	 */
	protected String getPersonFirstName() {
		return this.personFirstName;
	}

	/**
	 * @param personFirstName
	 *            the personFirstName to set
	 */
	private void setPersonFirstName(String personFirstName) {
		this.personFirstName = personFirstName;
	}

	/**
	 * @return the personLastName
	 */
	protected String getPersonLastName() {
		return this.personLastName;
	}

	/**
	 * @param personLastName
	 *            the personLastName to set
	 */
	private void setPersonLastName(String personLastName) {
		this.personLastName = personLastName;
	}

	/**
	 * @return accountType
	 */
	protected String getAccountType() {
		return accountType;
	}

	/**
	 * @param accountType
	 *            accountType � d�finir
	 */
	private void setAccountType(String type) {
		this.accountType = type;
	}

	/**
	 * @return personId
	 */
	protected String getPersonId() {
		return personId;
	}

	/**
	 * @param personId
	 *            personId � d�finir
	 */
	private void setPersonId(String personId) {
		this.personId = personId;
	}

	/**
	 * @return accountId
	 */
	protected String getAccountId() {
		return accountId;
	}

	/**
	 * @param accountId
	 *            accountId � d�finir
	 */
	private void setAccountId(String accountId) {
		this.accountId = accountId;
	}

}
