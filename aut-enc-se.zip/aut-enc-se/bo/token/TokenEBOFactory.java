/**
 * 
 */
package com.bnppa.sesame.token;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import com.bnppa.sesame.authaccount.AuthAccountEBO;
import com.bnppa.sesame.constants.AuthAccountConstants;
import com.bnppa.sesame.emailaddr.EmailAddressEBO;
import com.bnppa.sesame.person.PersonEBO;
import com.bnppa.sesame.person.PersonSBO;

/**
 * @author bellidori
 */
public class TokenEBOFactory {
	
	@Autowired
	private PersonSBO personSBO;
	
	/**
	 * create a tokenEBO
	 * 
	 * @param id
	 *            token id
	 * @param authAccount
	 *            the token's owner
	 * @return new tokenEBO instanceof TokenForVirtualAuthAccountEBO if
	 *         AuthAccountConstants.TYPE_VIRTUAL.equals(authAccount.getAuthType()
	 */
	protected TokenEBO create(String id, AuthAccountEBO authAccount) {

		if (AuthAccountConstants.TYPE_VIRTUAL.equals(authAccount.getAuthType())) {
			return this.createTokenForVirtualAuthAccountEBO(id, authAccount);
		}
		return new TokenEBO(id, authAccount);

	}
	
	public TokenForVirtualAuthAccountEBO createTokenForVirtualAuthAccountEBO(String id, AuthAccountEBO authAccountEBO) {
		
		TokenForVirtualAuthAccountEBO tokenEBO = new TokenForVirtualAuthAccountEBO(id, authAccountEBO);
		PersonEBO person = authAccountEBO.getAccount().getPerson();
		// save email addresses
		Set emailAddresses = new HashSet();
		for (Iterator iter = personSBO.findEmailAddresses(person).iterator(); iter
				.hasNext();) {
			EmailAddressEBO element = (EmailAddressEBO) iter.next();
			emailAddresses.add(element.getAddress().getAddress());
		}
		tokenEBO.setPersonEmail(emailAddresses);
		
		return tokenEBO;
	}

}
