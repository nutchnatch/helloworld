/**
 * 
 */
package com.bnppa.sesame.token;

import java.util.Set;

import com.bnppa.sesame.authaccount.AuthAccountEBO;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.TechnicalBOException;

/**
 * @author rochinaen
 * @version Aug 7, 2009
 */
public interface TokenSBO {
	
	/**
	 * create a entity business object Token. Build the id.
	 * 
	 * @param authAccountEBO
	 *            auth account link to the token
	 * @return The authentication token created
	 * @throws InvalidParameterBOException
	 *             if authAccountEBO.getLogin() is null
	 * @throws TechnicalBOException
	 *             if cannot add the token in cache
	 * @throws NullPointerException
	 *             if authAccountEBO is null
	 */
	public TokenEBO create(AuthAccountEBO authAccountEBO)
			throws InvalidParameterBOException, TechnicalBOException;
	
	/**
	 * create a entity business object Token. Build the id.
	 * 
	 * @param authAccountEBO
	 *            auth account link to the token
	 * @param idApplication 
	 * 			  the id of the application to store in the token. 
	 * @return The authentication token created
	 * @throws InvalidParameterBOException
	 *             if authAccountEBO.getLogin() is null
	 * @throws TechnicalBOException
	 *             if cannot add the token in cache
	 */
	public TokenEBO create(AuthAccountEBO authAccountEBO, String idApplication)
			throws InvalidParameterBOException, TechnicalBOException;

	/**
	 * find a entity by his id
	 * 
	 * @param token
	 *            entity's id to find
	 * @return Entity business object found (TokenEBO) or null if not found
	 * @throws TechnicalBOException
	 */
	public TokenEBO find(String token) throws TechnicalBOException;

	/**
	 * It deletes the instance of this object from the cache
	 * 
	 * @param token
	 *            token to delete
	 * @throws TechnicalBOException
	 * @throws NullPointerException
	 *             if token is null
	 */
	public void delete(TokenEBO token) throws TechnicalBOException;

	/**
	 * update token by authAccountEBO
	 * 
	 * @param token
	 * @param authAccountEBO
	 * @throws TechnicalBOException
	 */
	public void update(TokenEBO token, AuthAccountEBO authAccountEBO)
			throws TechnicalBOException;

	/**
	 * @param token
	 *            token
	 * @return the authentication account connected
	 * @throws InvalidParameterBOException
	 *             if authentication account cannot be loaded
	 * @throws TechnicalBOException if a technical error happened (database cannot be accessed...)
	 */
	public AuthAccountEBO getAuthAccount(TokenEBO token)
			throws InvalidParameterBOException,TechnicalBOException;
	
	/**
	 * This method upgrade the authentication level of a token
	 * BUT only if the newLevel is stronger (bigger strength) than the current level of the token
	 * 
	 * @author karakasfa
	 * @param token
	 * @param newLevel
	 * @return newLevel if ok, otherwise the current level of the token
	 * @throws InvalidParameterBOException
	 * @throws TechnicalBOException
	 */
	public String upgradeAuthenticationLevel(TokenEBO token, String newLevel)
			throws InvalidParameterBOException, TechnicalBOException;
	
	
	public Set findParentAccountIdsInEBO(TokenEBO token);
	
	public Set findPersonEmailInEBO(TokenEBO token);
	
}
