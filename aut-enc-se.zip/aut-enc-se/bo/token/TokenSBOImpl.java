/**
 * 
 */
package com.bnppa.sesame.token;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnppa.sesame.account.AccountEBO;
import com.bnppa.sesame.account.AccountSBO;
import com.bnppa.sesame.application.ApplicationEBO;
import com.bnppa.sesame.application.ApplicationSBO;
import com.bnppa.sesame.authaccount.AuthAccountEBO;
import com.bnppa.sesame.authaccount.AuthAccountSBO;
import com.bnppa.sesame.authenticationlevel.AuthenticationLevelSBO;
import com.bnppa.sesame.cache.SesameCache;
import com.bnppa.sesame.constants.AuthAccountConstants;
import com.bnppa.sesame.constants.InvalidParameterBOExceptionConstants;
import com.bnppa.sesame.constants.TechnicalBOExceptionConstants;
import com.bnppa.sesame.emailaddr.EmailAddressEBO;
import com.bnppa.sesame.emailaddr.EmailAddressSBO;
import com.bnppa.sesame.exceptions.InvalidParameterBOException;
import com.bnppa.sesame.exceptions.InvalidPasswordBOException;
import com.bnppa.sesame.exceptions.TechnicalBOException;
import com.bnppa.sesame.person.PersonEBO;
import com.bnppa.sesame.person.PersonSBO;

/**
 * @author rochinaen, behatemo
 * @version Aug 7, 2009
 */
public class TokenSBOImpl implements TokenSBO {

	private static final Random	randomizer	= new Random();

	private static final Log	logger		= LogFactory
													.getLog(TokenSBOImpl.class);

	private static final String	ALGORITHM	= "SHA";								//$NON-NLS-1$

	@Autowired
	private TokenEBOFactory tokenEBOFactory;

	/**
	 * session business object to find auth account
	 */
	private AuthAccountSBO		authAccountSBO;

	/**
	 * session business object to find account (need to restore virtual account)
	 */
	private AccountSBO			accountSBO;

	/**
	 * session business object to find person (need to restore virtual account)
	 */
	private PersonSBO			personSBO;

	/**
	 * session business object to find emailAddress (need to restore virtual
	 * account)
	 */

	private EmailAddressSBO		emailAddressSBO;

	private SesameCache			cache;
	
	/**
	 * Application SBO.
	 */
	private ApplicationSBO applicationSBO; 

	private AuthenticationLevelSBO authenticationLevelSBO; 

	/**
	 * @see com.bnppa.sesame.token.TokenSBO#create(com.bnppa.sesame.authaccount.AuthAccountEBO)
	 */
	public TokenEBO create(AuthAccountEBO authAccountEBO)
			throws InvalidParameterBOException, TechnicalBOException {

		String token = buildToken(authAccountEBO.getLogin());

		TokenEBO tokenEBO = tokenEBOFactory.create(token, authAccountEBO);

		cache.put(token, tokenEBO);

		return tokenEBO;
	}
	
	/* (non-Javadoc)
	 * @see com.bnppa.sesame.token.TokenSBO#create(com.bnppa.sesame.authaccount.AuthAccountEBO, java.lang.String)
	 */
	public TokenEBO create(AuthAccountEBO authAccountEBO, String idApplication) throws InvalidParameterBOException, TechnicalBOException {
		ApplicationEBO applicationEBO = getApplicationSBO().find(idApplication);
		if (applicationEBO == null) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.APPLICATION_NOT_EXIST,
					new Object[] { idApplication }, logger);
		}
		
		String token = buildToken(authAccountEBO.getLogin());

		TokenEBO tokenEBO = new TokenEBO(token, authAccountEBO, idApplication);

		cache.putForLongTime(token, tokenEBO);

		return tokenEBO;
	}

	/**
	 * @throws TechnicalBOException
	 * @see com.bnppa.sesame.token.TokenSBO#find(java.lang.String)
	 */
	public TokenEBO find(String token) throws TechnicalBOException {
		Object tokenCached = cache.get(token);
		return (TokenEBO) tokenCached;
	}

	/**
	 * @return SesameCache
	 */
	public SesameCache getCache() {
		return cache;
	}

	/**
	 * @param cache
	 */
	public void setCache(SesameCache cache) {
		this.cache = cache;
	}

	/**
	 * Build the token's id
	 * 
	 * @param login
	 *            user's id
	 * @return token hashed
	 * @throws InvalidParameterBOException
	 *             if login is blank
	 * @throws TechnicalBOException
	 *             if algorithm is not availabled
	 */
	private String buildToken(String login) throws InvalidParameterBOException,
			TechnicalBOException {

		if (StringUtils.isBlank(login)) {

			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.LOGIN_IS_BLANK,
					new String[] { login }, logger);
		}

		// Adding a timestamp to login parameter
		login = randomizer.nextInt() + login + System.currentTimeMillis();

		byte[] bytesToken = login.getBytes();
		try {
			MessageDigest algorithm = MessageDigest.getInstance(ALGORITHM);
			algorithm.reset();
			algorithm.update(bytesToken);
			byte messageDigest[] = algorithm.digest();

			StringBuffer hexString = new StringBuffer();
			for (int i = 0; i < messageDigest.length; i++) {
				String hex = Integer.toHexString(0xff & messageDigest[i]);
				if (hex.length() == 1)
					hexString.append('0');
				hexString.append(hex);
			}

			return hexString.toString();
		} catch (NoSuchAlgorithmException e) {
			throw new TechnicalBOException(
					TechnicalBOExceptionConstants.NO_SUCH_ALGORITHM,
					new String[] { ALGORITHM }, e, logger);
		}
	}

	/**
	 * @author bellidori
	 * @version 24 ao�t 09
	 * @throws TechnicalBOException
	 * @see com.bnppa.sesame.token.TokenSBO#delete(com.bnppa.sesame.token.TokenEBO)
	 */
	public void delete(TokenEBO token) throws TechnicalBOException {
		getCache().remove(token.getId());

	}

	/**
	 * @author behatemo
	 * @throws TechnicalBOException
	 * @see com.bnppa.sesame.token.TokenSBO#update(com.bnppa.sesame.token.TokenEBO,
	 *      com.bnppa.sesame.authaccount.AuthAccountEBO)
	 */
	public void update(TokenEBO token, AuthAccountEBO authAccountEBO)
			throws TechnicalBOException {
		// token.setAuthAccount(authAccountEBO);
		token.setAuthLevel(authAccountEBO.getAuthLevel());
		token.setLogin(authAccountEBO.getLogin());
		token.setSyst(authAccountEBO.getSyst());
		token.setAuthType(authAccountEBO.getAuthType());
		cache.put(token.getId(), token);
	}

	/**
	 * @see com.bnppa.sesame.token.TokenSBO#getAuthAccount(com.bnppa.sesame.token.TokenEBO)
	 */
	public AuthAccountEBO getAuthAccount(TokenEBO token)
			throws InvalidParameterBOException, TechnicalBOException {

		if (token == null) {
			throw new InvalidParameterBOException(
					InvalidParameterBOExceptionConstants.TOKEN_NOT_EXIST,
					logger);
		}

		AuthAccountEBO authAccount = token.getAuthAccount();
		if (authAccount == null) {
			// le compte a �t� supprim� du cache => il faut le recr�er
			//@deprecated : an authAccount can't be VIRTUAL. This code is never reached.
			if (AuthAccountConstants.TYPE_VIRTUAL.equals(token.getAuthType())) {
				// le compte est virtuel => il faut le r�cr�er

				// search parents account
				Set parents = new HashSet();
				for (Iterator iter = this.findParentAccountIdsInEBO(token).iterator(); iter
						.hasNext();) {
					String id = (String) iter.next();
					parents.add(this.getAccountSBO().find(id));

				}

				// create email
				Set emailAddresses = new HashSet();
				for (Iterator iter = this.findPersonEmailInEBO(token).iterator(); iter
						.hasNext();) {
					String element = (String) iter.next();
					emailAddresses.add(this.getEmailAddressSBO()
							.create(element));

				}

				// create person
				PersonEBO person = this.getPersonSBO().create(
						token.getPersonId(), token.getPersonFirstName(),
						token.getPersonLastName(), emailAddresses);

				// create account
				Calendar inactiveDate = null;
				Set areas = new HashSet();
				for (Iterator iter = parents.iterator(); iter.hasNext();) {
					AccountEBO element = (AccountEBO) iter.next();
					// search the smallest inactive date of parents
					if (element.getInactiveDate() != null) {
						if (inactiveDate == null) {
							inactiveDate = element.getInactiveDate();
						} else {
							if (element.getInactiveDate().before(inactiveDate)) {
								inactiveDate = element.getInactiveDate();
							}

						}
					}
					// merge areas
					areas.addAll(accountSBO.getAreas(element));

				}
				AccountEBO account = this.getAccountSBO().create(
						token.getAccountId(), inactiveDate,
						token.getAccountType(), person, areas, parents);

				// create authAccount
				try {
					authAccount = getAuthAccountSBO().create(token.getLogin(),
							token.getAuthLevel(), token.getSyst(),
							token.getAuthType(), account, null, null);

				} catch (InvalidPasswordBOException e) {
					throw new TechnicalBOException(
							TechnicalBOExceptionConstants.TECHNICAL_ERROR, e,
							logger);
				}

			} else {
				// ce n'est pas un compte virtuel => le rechercher
				authAccount = this.getAuthAccountSBO().find(
						token.getAuthLevel(), token.getLogin(),
						token.getSyst(), token.getAuthType());
			}
		}
		// maj le token
		token.setAuthAccount(authAccount);
		return authAccount;
	}

	/* (non-Javadoc)
	 * @see com.bnppa.sesame.token.TokenSBO#upgradeAuthenticationLevel(com.bnppa.sesame.token.TokenEBO, java.lang.String)
	 */
	public String upgradeAuthenticationLevel(TokenEBO token, String newLevel)
		throws InvalidParameterBOException, TechnicalBOException  {

		if(getAuthenticationLevelSBO().isStronger(newLevel, token.getAuthenticationLevel()))
		{
			token.setAuthenticationLevel(newLevel);
			cache.put(token.getId(), token);
			return newLevel;
		}
		
		return token.getAuthenticationLevel();
	}
	
	public Set findParentAccountIdsInEBO(TokenEBO tokenEBO) {
		
		AuthAccountEBO localAuthAccount = tokenEBO.getAuthAccount();
		if (localAuthAccount == null) {
			return null;
		}

		Set localParentAccountIds = new HashSet();
		for (Iterator iter = localAuthAccount.getAccount().getParentAccounts().iterator(); iter.hasNext();) {
			AccountEBO parentAccountEBO = (AccountEBO) iter.next();
			localParentAccountIds.add(parentAccountEBO.getId());
		}

		return localParentAccountIds;
	}

	public Set findPersonEmailInEBO(TokenEBO tokenEBO) {
		AuthAccountEBO localAuthAccount = tokenEBO.getAuthAccount();
		if (localAuthAccount == null) {
			return null;
		}

		// save email addresses
		Set emailAddresses = new HashSet();
		for (Iterator iter = personSBO.findEmailAddresses(localAuthAccount.getAccount().getPerson()).iterator(); iter.hasNext();) {
			EmailAddressEBO element = (EmailAddressEBO) iter.next();
			emailAddresses.add(element.getAddress().getAddress());
		}

		return emailAddresses;
	}

	/**
	 * @return accountSBO
	 */
	protected AccountSBO getAccountSBO() {
		return accountSBO;
	}

	/**
	 * @param accountSBO
	 *            accountSBO � d�finir
	 */
	public void setAccountSBO(AccountSBO accountSBO) {
		this.accountSBO = accountSBO;
	}

	/**
	 * @return authAccountSBO
	 */
	protected AuthAccountSBO getAuthAccountSBO() {
		return authAccountSBO;
	}

	/**
	 * @param authAccountSBO
	 *            authAccountSBO � d�finir
	 */
	public void setAuthAccountSBO(AuthAccountSBO authAccountSBO) {
		this.authAccountSBO = authAccountSBO;
	}

	/**
	 * @return emailAddressSBO
	 */
	protected EmailAddressSBO getEmailAddressSBO() {
		return emailAddressSBO;
	}

	/**
	 * @param emailAddressSBO
	 *            emailAddressSBO � d�finir
	 */
	public void setEmailAddressSBO(EmailAddressSBO emailAddressSBO) {
		this.emailAddressSBO = emailAddressSBO;
	}

	/**
	 * @return personSBO
	 */
	protected PersonSBO getPersonSBO() {
		return personSBO;
	}

	/**
	 * @param personSBO
	 *            personSBO � d�finir
	 */
	public void setPersonSBO(PersonSBO personSBO) {
		this.personSBO = personSBO;
	}

	/**
	 * @return applicationSBO
	 */
	public ApplicationSBO getApplicationSBO() {
		return applicationSBO;
	}

	/**
	 * @param applicationSBO applicationSBO � d�finir
	 */
	public void setApplicationSBO(ApplicationSBO applicationSBO) {
		this.applicationSBO = applicationSBO;
	}

	/**
	 * @return AuthenticationLevelSBO
	 */
	protected AuthenticationLevelSBO getAuthenticationLevelSBO() {
		return authenticationLevelSBO;
	}

	/**
	 * @param AuthenticationLevelSBO
	 *            
	 */
	public void setAuthenticationLevelSBO(AuthenticationLevelSBO authenticationLevelSBO) {
		this.authenticationLevelSBO = authenticationLevelSBO;
	}
	
}
