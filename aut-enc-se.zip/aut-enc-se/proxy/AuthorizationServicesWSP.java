/*
 * Created on May 6, 2008
 */
package com.bnppa.sesame.services.standard.proxy;

import gencl.sesame.services.standard.proxy.ArrayOfTns3NillableJoining;
import gencl.sesame.services.standard.proxy.ArrayOfXsdNillableString;
import gencl.sesame.services.standard.proxy.InvalidParameterException;
import gencl.sesame.services.standard.proxy.InvalidTokenException;
import gencl.sesame.services.standard.proxy.TechnicalException;

import javax.jws.HandlerChain;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.bnppa.sesame.services.common.exception.ExceptionMapper;

/**
 * @author polancoro
 *  
 */
@javax.jws.WebService(
        serviceName = "AuthorizationServicesWSPService",
        portName = "AuthorizationServicesWSP",
        targetNamespace = "http://proxy.standard.services.sesame.bnppa.com",
        endpointInterface = "gencl.sesame.services.standard.proxy.AuthorizationServicesWSP")
@HandlerChain(file = "/SesameHandlers.xml")
public class AuthorizationServicesWSP extends SpringBeanAutowiringSupport implements gencl.sesame.services.standard.proxy.AuthorizationServicesWSP {
	
	/**
	 * The log.
	 */
	private static final Log log = LogFactory.getLog(AuthorizationServicesWSP.class);

	@Autowired
	@Qualifier("authorizationservices")
	private gencl.sesame.services.standard.proxy.AuthorizationServicesWSP authorizationServices;
	
	/**
	 * The exception mapper.
	 */
	@Autowired
	private ExceptionMapper exceptionMapper;

	/**
	 * Default constructor
	 */
	public AuthorizationServicesWSP() {
	}

	/**
	 * @author polancoro 
	 * @version May 7, 2009
	 * @see com.bnppa.sesame.services.standard.AuthorizationServices#getPermissions(java.lang.String, java.lang.String)
	 */
	@Override
	public ArrayOfXsdNillableString getPermissions(String token, String applicationDomain)
			throws InvalidTokenException, InvalidParameterException,
			TechnicalException {

		try {
			return authorizationServices.getPermissions(token, applicationDomain);
		} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
	}

	/**
	 * @author polancoro 
	 * @version May 7, 2009
	 * @see com.bnppa.sesame.services.standard.AuthorizationServices#hasPermission(java.lang.String, java.lang.String, java.lang.String)
	 */
	public Boolean hasPermission(String token, String permission,
			String appDomain) throws InvalidTokenException, TechnicalException {
		try {
			return authorizationServices
				.hasPermission(token, permission, appDomain);
		} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
	}

	/**
	 * @author polancoro 
	 * @version May 7, 2009
	 * @see com.bnppa.sesame.services.standard.AuthorizationServices#hasPermissions(java.lang.String, java.lang.String[], java.lang.String)
	 */
	public Boolean hasPermissions(String token, ArrayOfXsdNillableString permissions,
			String appDomain) throws InvalidTokenException, TechnicalException {
		try {
			return authorizationServices.hasPermissions(token, permissions, appDomain);
		} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
	}

	/**
	 * @author polancoro 
	 * @version May 7, 2009
	 * @see com.bnppa.sesame.services.standard.AuthorizationServices#getPermissionsWithinList(java.lang.String, java.lang.String[], java.lang.String)
	 */
	public ArrayOfXsdNillableString getPermissionsWithinList(String token, ArrayOfXsdNillableString permission,
			String appDomain) throws InvalidTokenException,
			InvalidParameterException, TechnicalException {
		try {
			return authorizationServices.getPermissionsWithinList(token, permission, appDomain);
		} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
	}

	/**
	 * @author polancoro 
	 * @version May 7, 2009
	 * @see com.bnppa.sesame.services.standard.AuthorizationServices#getRoles(java.lang.String, java.lang.String)
	 */
	public ArrayOfXsdNillableString getRoles(String token, String appDomain)
			throws InvalidTokenException, InvalidParameterException,
			TechnicalException {
		return authorizationServices.getRoles(token, appDomain);
	}

	/**
	 * @author polancoro 
	 * @version May 7, 2009
	 * @see com.bnppa.sesame.services.standard.AuthorizationServices#getJoinings(java.lang.String, java.lang.String)
	 */
	public ArrayOfTns3NillableJoining getJoinings(String token, String appDomain)
			throws InvalidTokenException, InvalidParameterException,
			TechnicalException {
		try {
			return authorizationServices.getJoinings(token, appDomain);
		} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
	}

	/**
	 * @author polancoro 
	 * @version May 7, 2009
	 * @see com.bnppa.sesame.services.standard.AuthorizationServices#getUsingRight(java.lang.String, java.lang.String)
	 */
	public gencl.sesame.services.common.model.UsingRight getUsingRight(String token, String appDomain)
			throws InvalidTokenException, InvalidParameterException,
			TechnicalException {
		try {
			return authorizationServices.getUsingRight(token, appDomain);
		} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
	}
}
