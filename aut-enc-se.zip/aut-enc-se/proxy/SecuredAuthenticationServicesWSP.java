/*
 * Cr�� le 7 sept. 2009
 */
package com.bnppa.sesame.services.standard.proxy;

import gencl.sesame.services.standard.proxy.ExpiredPasswordException;
import gencl.sesame.services.standard.proxy.LockedLoginException;
import gencl.sesame.services.standard.proxy.LoginException;
import gencl.sesame.services.standard.proxy.TechnicalException;

import javax.annotation.Resource;
import javax.jws.HandlerChain;
import javax.xml.ws.WebServiceContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.bnppa.sesame.services.common.exception.ExceptionMapper;
import com.bnppa.sesame.utils.ManageSecurityHelper;

/**
 * @author draboma, polancoro
 * @version Sep 21, 2009
 */
@javax.jws.WebService(
        serviceName = "SecuredAuthenticationServicesWSPService",
        portName = "SecuredAuthenticationServicesWSP",
        targetNamespace = "http://proxy.standard.services.sesame.bnppa.com",
        endpointInterface = "gencl.sesame.services.standard.proxy.SecuredAuthenticationServicesWSP")
@HandlerChain(file = "/SesameHandlers.xml")
public class SecuredAuthenticationServicesWSP extends SpringBeanAutowiringSupport implements gencl.sesame.services.standard.proxy.SecuredAuthenticationServicesWSP {
	
	/**
	 * The log.
	 */
	private static final Log log = LogFactory.getLog(SecuredAuthenticationServicesWSP.class);

	@Autowired
	@Qualifier("securedAuthenticationServices")
	private gencl.sesame.services.standard.proxy.SecuredAuthenticationServicesWSP securedAuthenticationServices;
	
	/**
	 * The exception mapper.
	 */
	@Autowired
	private ExceptionMapper exceptionMapper;
	
	@Resource(name="wsContext")
	private WebServiceContext wsContext;

	/**
	 * Default constructor
	 * @author polancoro
	 * @version Sep 22, 2009
	 */
	public SecuredAuthenticationServicesWSP() {	}

	/**
	 * @param login
	 * @param authLevel
	 * @return The token
	 * @throws ExpiredPasswordException
	 * @throws LockedLoginException
	 * @throws TechnicalException
	 * @throws LoginException
	 * @see com.bnppa.sesame.services.standard.SecuredAuthenticationServices#getTokenFromLogin(java.lang.String,
	 *      java.lang.Integer)
	 */
	public String getTokenFromLogin(String login, Integer authLevel) throws ExpiredPasswordException, LockedLoginException,	TechnicalException, LoginException {
		try {

			ManageSecurityHelper.basicAuthentication(wsContext);
		
			return securedAuthenticationServices.getTokenFromLogin(login, authLevel);
		} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
	}

	
}
