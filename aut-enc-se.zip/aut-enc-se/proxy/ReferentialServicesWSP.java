package com.bnppa.sesame.services.standard.proxy;

import gencl.sesame.services.standard.proxy.ArrayOfTns2NillableSecretQuestion;
import gencl.sesame.services.standard.proxy.TechnicalException;

import javax.jws.HandlerChain;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.bnppa.sesame.services.common.exception.ExceptionMapper;

/**
 * @author polancoro
 * @version 07/05/2009
 *  
 */
@javax.jws.WebService(
        serviceName = "ReferentialServicesWSPService",
        portName = "ReferentialServicesWSP",
        targetNamespace = "http://proxy.standard.services.sesame.bnppa.com",
        endpointInterface = "gencl.sesame.services.standard.proxy.ReferentialServicesWSP")
@HandlerChain(file = "/SesameHandlers.xml")
public class ReferentialServicesWSP extends SpringBeanAutowiringSupport implements gencl.sesame.services.standard.proxy.ReferentialServicesWSP {
	
	/**
	 * The log.
	 */
	private static final Log log = LogFactory.getLog(ReferentialServicesWSP.class);

	@Autowired
	@Qualifier("referentialservices")
    private gencl.sesame.services.standard.proxy.ReferentialServicesWSP referentialServices;
    
    /**
	 * The exception mapper.
	 */
    @Autowired
	private ExceptionMapper exceptionMapper;

    /**
     * Default constructor
     */
    public ReferentialServicesWSP() {
    }

    /**
     * @author polancoro
     * @version May 7, 2009
     * @see com.bnppa.sesame.services.standard.ReferentialServices#getAllSecretQuestions()
     */
    public ArrayOfTns2NillableSecretQuestion getAllSecretQuestions() throws TechnicalException {
    	try {
    		return referentialServices.getAllSecretQuestions();
    	} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
    }
}
