package com.bnppa.sesame.services.standard.proxy;

import gencl.sesame._int.schema.mp.commons.exceptions.v1.FunctionalBaseFaultType;
import gencl.sesame._int.schema.mp.commons.exceptions.v1.TechnicalBaseFaultType;
import gencl.sesame._int.schema.mp.sesame.appauthenticationservice.v1.LoginForApplicationIn;
import gencl.sesame._int.schema.mp.sesame.appauthenticationservice.v1.LoginForApplicationOut;
import gencl.sesame._int.service.mp.sesame.appauthenticationservice.v1.AppAuthenticationServicePort;
import gencl.sesame._int.service.mp.sesame.appauthenticationservice.v1.FuncFaultMessage;
import gencl.sesame._int.service.mp.sesame.appauthenticationservice.v1.TechFaultMessage;

import javax.jws.HandlerChain;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.bnppa.sesame.services.exception.FunctionalException;
import com.bnppa.sesame.services.exception.TechnicalException;
import com.bnppa.sesame.services.standard.StandardAppAuthenticationServices;


@javax.jws.WebService(
        serviceName = "AppAuthenticationService",
        portName = "AppAuthenticationServiceSOAP",
        targetNamespace = "http://sesame.assurance.bnpparibas.com/int/service/mp/sesame/AppAuthenticationService/v1",
        endpointInterface = "gencl.sesame._int.service.mp.sesame.appauthenticationservice.v1.AppAuthenticationServicePort")
@HandlerChain(file = "/SesameHandlers.xml")
public class AppAuthenticationServiceSOAPImpl extends SpringBeanAutowiringSupport implements AppAuthenticationServicePort{
    
	@Autowired
	@Qualifier("appAuthenticationServices")
	private StandardAppAuthenticationServices standardAppAuthenticationServices;
	
	public AppAuthenticationServiceSOAPImpl() {}
	
	public LoginForApplicationOut loginForApplication(LoginForApplicationIn parameters) throws TechFaultMessage, FuncFaultMessage {
		String login = null;
		String password = null;
		String applicationId = null;
		if (parameters != null) {
			login = parameters.getLogin();
			password = parameters.getPassword();
			applicationId = parameters.getApplicationId();
		}
		try {
			String token = standardAppAuthenticationServices.loginForApplication(login, password, applicationId);
			LoginForApplicationOut loginForApplication = new LoginForApplicationOut();
			loginForApplication.setSesameToken(token);
			return loginForApplication;
		} catch (FunctionalException e) {
			FunctionalBaseFaultType beanInfo = new FunctionalBaseFaultType();
			beanInfo.setDescription(e.getMessage());
			FuncFaultMessage exp = new FuncFaultMessage(e.getMessage(),beanInfo,e);
			throw exp;
		} catch (TechnicalException e) {
			TechnicalBaseFaultType beanInfo = new TechnicalBaseFaultType();
			beanInfo.setDescription(e.getMessage());
			TechFaultMessage exp = new TechFaultMessage(e.getMessage(),beanInfo,e);
			throw exp;
		}
    }
	
}