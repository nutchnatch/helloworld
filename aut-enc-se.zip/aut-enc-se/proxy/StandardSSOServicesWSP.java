package com.bnppa.sesame.services.standard.proxy;

import gencl.sesame.services.standard.proxy.BadSignatureException;
import gencl.sesame.services.standard.proxy.ExpiredPasswordException;
import gencl.sesame.services.standard.proxy.InvalidChallengeException;
import gencl.sesame.services.standard.proxy.InvalidParameterException;
import gencl.sesame.services.standard.proxy.LockedLoginException;
import gencl.sesame.services.standard.proxy.LoginException;
import gencl.sesame.services.standard.proxy.TechnicalException;
import gencl.sesame.services.vo.AccountId;

import javax.annotation.Resource;
import javax.jws.HandlerChain;
import javax.xml.ws.WebServiceContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.bnppa.sesame.services.common.exception.ExceptionMapper;
import com.bnppa.sesame.utils.ManageSecurityHelper;

/**
 * @author behatemo
 * @author chemirlu
 * @author bellidori
 * @version Jan 8, 2010
 * @version 28/04/2010
 * @version 31/05/2010
 */
@javax.jws.WebService(
        serviceName = "StandardSSOServicesWSPService",
        portName = "StandardSSOServicesWSP",
        targetNamespace = "http://proxy.standard.services.sesame.bnppa.com",
        endpointInterface = "gencl.sesame.services.standard.proxy.StandardSSOServicesWSP")
@HandlerChain(file = "/SesameHandlers.xml")
public class StandardSSOServicesWSP extends SpringBeanAutowiringSupport implements gencl.sesame.services.standard.proxy.StandardSSOServicesWSP {
	
	/**
	 * The log.
	 */
	private static final Log log = LogFactory.getLog(StandardSSOServicesWSP.class);

	@Autowired
	@Qualifier("ssoservices")
	private gencl.sesame.services.standard.proxy.StandardSSOServicesWSP	sSOServices;
	
	/**
	 * The exception mapper.
	 */
	@Autowired
	private ExceptionMapper exceptionMapper;
	
	@Resource(name="wsContext")
	private WebServiceContext wsContext;

	/**
	 * Default constructor
	 */
	public StandardSSOServicesWSP() {}

	/**
	 * @author chemirlu
	 * @see StandardSSOServices#loginFromSSOWithSignature(Integer, AccountId)
	 */
	public String loginFromSSOWithSignature(Integer authLevel,	AccountId accountId) throws LoginException,
			ExpiredPasswordException, LockedLoginException, TechnicalException,
			InvalidParameterException {
		
		try {
			ManageSecurityHelper.basicAuthentication(wsContext);
			
			return sSOServices.loginFromSSOWithSignature(authLevel, accountId);
		} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
	}

	/**
	 * @see com.bnppa.sesame.services.standard.StandardSSOServices#loginPartner(String,
	 *      String, String, AccountId, String, String, String, String)
	 */
	public String loginPartner(String issuer, String application, String federationRole, AccountId accountId, String firstName, String lastName, String email, String identityProvider)
			throws LoginException, ExpiredPasswordException, LockedLoginException, TechnicalException, InvalidParameterException, BadSignatureException, InvalidChallengeException {
		
		try {
			ManageSecurityHelper.basicAuthentication(wsContext);
			
			return sSOServices.loginPartner(issuer, application, federationRole, accountId, firstName, lastName, email, identityProvider);
		} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
	}
}
