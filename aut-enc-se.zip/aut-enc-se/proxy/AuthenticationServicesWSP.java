package com.bnppa.sesame.services.standard.proxy;

import gencl.sesame.services.standard.proxy.ArrayOfTns3NillableSecretResponse;
import gencl.sesame.services.standard.proxy.ArrayOfTns4NillableKeyValue;
import gencl.sesame.services.standard.proxy.ExpiredPasswordException;
import gencl.sesame.services.standard.proxy.InvalidParameterException;
import gencl.sesame.services.standard.proxy.InvalidPasswordException;
import gencl.sesame.services.standard.proxy.InvalidTokenException;
import gencl.sesame.services.standard.proxy.LockedLoginException;
import gencl.sesame.services.standard.proxy.LoginException;
import gencl.sesame.services.standard.proxy.TechnicalException;
import gencl.sesame.services.standard.proxy.UnauthorizedActionException;
import gencl.sesame.services.standard.proxy.UnsupportedActionException;
import gencl.sesame.services.vo.AccountId;

import javax.jws.HandlerChain;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.bnppa.sesame.services.common.exception.ExceptionMapper;

/**
 * @author polancoro
 * @author bellidori
 * @version 1.7,10/02/08
 * 
 *  
 */
@javax.jws.WebService(
        serviceName = "AuthenticationServicesWSPService",
        portName = "AuthenticationServicesWSP",
        targetNamespace = "http://proxy.standard.services.sesame.bnppa.com",
        endpointInterface = "gencl.sesame.services.standard.proxy.AuthenticationServicesWSP")
@HandlerChain(file = "/SesameHandlers.xml")
public class AuthenticationServicesWSP extends SpringBeanAutowiringSupport implements gencl.sesame.services.standard.proxy.AuthenticationServicesWSP {
	
	/**
	 * The log 
	 */
	private static final Log log = LogFactory.getLog(AuthenticationServicesWSP.class);
	
	@Autowired
	@Qualifier("authenticationservices")
	private gencl.sesame.services.standard.proxy.AuthenticationServicesWSP authenticationServices;

	/**
	 * The exception mapper.
	 */
	@Autowired 
	private ExceptionMapper exceptionMapper;

	/**
	 * Default constructor
	 */
	public AuthenticationServicesWSP() {
	}

	/**
	 * @author polancoro 
	 * @version May 7, 2009
	 * @see com.bnppa.sesame.services.standard.AuthenticationServices#loginInUserRef(java.lang.String, java.lang.String, java.lang.String)
	 */
	public String loginInUserRef(String login, String password, String authType)
			throws LoginException, LockedLoginException,
			ExpiredPasswordException, TechnicalException,
			InvalidParameterException {

		try {
			return authenticationServices.loginInUserRef(login, password, authType);
		} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
	}

	/**
	 * @author polancoro 
	 * @version May 7, 2009
	 * @see com.bnppa.sesame.services.standard.AuthenticationServices#login(java.lang.String, java.lang.String)
	 */
	public String login(String login, String password) throws LoginException,
			LockedLoginException, ExpiredPasswordException, TechnicalException {

		try {
			return authenticationServices.login(login, password);
		} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
	}

	/**
	 * @author polancoro 
	 * @version May 7, 2009
	 * @see com.bnppa.sesame.services.standard.AuthenticationServices#logout(java.lang.String)
	 */
	public void logout(String token) throws InvalidTokenException,
			TechnicalException {
		try {
			authenticationServices.logout(token);
		} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
	}

	/**
	 * @author polancoro 
	 * @version May 7, 2009
	 * @see com.bnppa.sesame.services.standard.AuthenticationServices#changePassword(java.lang.String, java.lang.String, java.lang.String)
	 */
	public void changePassword(String login, String oldPassword, String newPassword)
			throws LoginException, LockedLoginException, InvalidPasswordException, UnsupportedActionException, TechnicalException {
		
		try {
			authenticationServices.changePassword(login, oldPassword, newPassword);
		} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
	}

	/**
	 * @author polancoro 
	 * @version May 7, 2009
	 * @see com.bnppa.sesame.services.standard.AuthenticationServices#validateToken(java.lang.String)
	 */
	public Boolean validateToken(String token) throws TechnicalException {
		try {
			return authenticationServices.validateToken(token);
		} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
	}

	/**
	 * @author polancoro 
	 * @version May 7, 2009
	 * @see com.bnppa.sesame.services.standard.AuthenticationServices#resetAndSendPasswordBySecretResponses(com.bnppa.sesame.services.vo.AccountId, com.bnppa.sesame.services.vo.SecretResponse[], java.lang.String, java.lang.String, java.lang.String, com.bnppa.sesame.services.common.model.KeyValue[])
	 */
    public void resetAndSendPasswordBySecretResponses(AccountId accountId,
    		ArrayOfTns3NillableSecretResponse secretResponses, String applicationCode,
            String channelType, String channelMessageFormatCode,
            ArrayOfTns4NillableKeyValue channelMessageParameters)
            throws InvalidParameterException, UnauthorizedActionException,
            TechnicalException {
    	try {
    		authenticationServices.resetAndSendPasswordBySecretResponses(accountId,
                secretResponses, applicationCode, channelType,
                channelMessageFormatCode, channelMessageParameters);
    	} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
    }
    
    /**
     * @author polancoro 
     * @version May 7, 2009
     * @see com.bnppa.sesame.services.standard.AuthenticationServices#setSecretResponses(java.lang.String, com.bnppa.sesame.services.vo.SecretResponse[])
     */
    public void setSecretResponses(String token,
    		ArrayOfTns3NillableSecretResponse secretResponses) throws InvalidTokenException,
            UnauthorizedActionException, InvalidParameterException,
            TechnicalException {
    	try {
    		authenticationServices.setSecretResponses(token, secretResponses);
    	} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
    }
}
