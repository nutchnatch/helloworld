package com.bnppa.sesame.services.standard.proxy;

import gencl.sesame.services.common.model.UserExtendedIdentity;
import gencl.sesame.services.common.model.UserIdentity;
import gencl.sesame.services.standard.proxy.ArrayOfTns3NillableKeyValue;
import gencl.sesame.services.standard.proxy.InvalidParameterException;
import gencl.sesame.services.standard.proxy.InvalidTokenException;
import gencl.sesame.services.standard.proxy.TechnicalException;

import javax.jws.HandlerChain;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.bnppa.sesame.services.common.exception.ExceptionMapper;

/**
 * @author polancoro
 *  
 */
@javax.jws.WebService(
        serviceName = "IdentityServicesWSPService",
        portName = "IdentityServicesWSP",
        targetNamespace = "http://proxy.standard.services.sesame.bnppa.com",
        endpointInterface = "gencl.sesame.services.standard.proxy.IdentityServicesWSP")
@HandlerChain(file = "/SesameHandlers.xml")
public class IdentityServicesWSP extends SpringBeanAutowiringSupport implements gencl.sesame.services.standard.proxy.IdentityServicesWSP {
	
	/**
	 * The log.
	 */
	private static final Log log = LogFactory.getLog(IdentityServicesWSP.class);

	@Autowired
	@Qualifier("identityservices")
	private gencl.sesame.services.standard.proxy.IdentityServicesWSP identServices;
	
	/**
	 * The exception mapper.
	 */
	@Autowired
	private ExceptionMapper exceptionMapper;

	/**
	 * Default constructor
	 */
	public IdentityServicesWSP() {
	}

	/**
	 * @author polancoro 
	 * @version Apr 9, 2009
	 * @see com.bnppa.sesame.services.standard.IdentityServices#getUserIdentity(java.lang.String)
	 */
	public UserIdentity getUserIdentity(String token) throws InvalidTokenException,
			TechnicalException {
		try {
			return identServices.getUserIdentity(token);
		} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
	}
	
	/**
	 * @author polancoro 
	 * @version Apr 9, 2009
	 * @see com.bnppa.sesame.services.standard.IdentityServices#getExtendedAttributes(java.lang.String)
	 */
	public ArrayOfTns3NillableKeyValue getExtendedAttributes(String token)
			throws InvalidTokenException, TechnicalException {
		try {
			return identServices.getExtendedAttributes(token);
		} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
	}
	
	/**
	 * 
	 * @author polancoro 
	 * @version Apr 9, 2009
	 * @see com.bnppa.sesame.services.standard.IdentityServices#getUserExtendedIdentity(java.lang.String)
	 */
	public UserExtendedIdentity getUserExtendedIdentity(String token)
			throws InvalidTokenException, TechnicalException {
		try {
			return identServices.getUserExtendedIdentity(token);
		} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
	}
	
    /**
     * @author polancoro 
     * @version Apr 9, 2009
     * @see com.bnppa.sesame.services.standard.IdentityServices#changeLogin(java.lang.String, java.lang.String)
     */
    public void changeLogin(String token, String newLogin)
            throws InvalidParameterException, InvalidTokenException,
            TechnicalException {
    	try {
    		identServices.changeLogin(token, newLogin);
    	} catch(RuntimeException e) {
			throw exceptionMapper.map(log, e);
		}
    }
}
