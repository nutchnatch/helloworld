package com.bnpp.cardif.sugar.backend.security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.AuthenticationDetailsSource;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.security.web.authentication.www.BasicAuthenticationEntryPoint;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

public class HeaderTokenAuthenticationFilter extends BasicAuthenticationFilter {

    @SuppressWarnings("squid:S2387")
    private static final Logger LOGGER = LoggerFactory.getLogger(UsernamePasswordAuthenticationFilter.class);

    private String tokenHeaderName = "X-CARDIF-AUTH-TOKEN";
    
    private AuthenticationDetailsSource<HttpServletRequest, ?> authenticationDetailsSource = new WebAuthenticationDetailsSource();
    private AuthenticationEntryPoint authenticationEntryPoint;
    private AuthenticationManager authenticationManager;
    private boolean ignoreFailure = false;

    /**
     * Creates an instance which will authenticate against the supplied
     * {@code AuthenticationManager} and which will ignore failed authentication
     * attempts, allowing the request to proceed down the filter chain.
     *
     * @param authenticationManager
     *            the bean to submit authentication requests to
     */
    public HeaderTokenAuthenticationFilter(AuthenticationManager authenticationManager) {
        super(authenticationManager);
        this.authenticationManager = authenticationManager;
    }

    /**
     * Creates an instance which will authenticate against the supplied
     * {@code AuthenticationManager} and use the supplied
     * {@code AuthenticationEntryPoint} to handle authentication failures.
     *
     * @param authenticationManager
     *            the bean to submit authentication requests to
     * @param authenticationEntryPoint
     *            will be invoked when authentication fails. Typically an
     *            instance of {@link BasicAuthenticationEntryPoint}.
     */
    public HeaderTokenAuthenticationFilter(AuthenticationManager authenticationManager,
            AuthenticationEntryPoint authenticationEntryPoint) {
        super(authenticationManager, authenticationEntryPoint);
        this.authenticationManager = authenticationManager;
        this.authenticationEntryPoint = authenticationEntryPoint;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        String header = request.getHeader(tokenHeaderName);

        if (header == null) {
            chain.doFilter(request, response);
            return;
        }

        try {
            LOGGER.debug(" header = {} ", header);
            String token = header;

            LOGGER.debug("Token Authentication Authorization header found : '{}'", token);

            if (tokenAuthenticationIsRequired(token)) {
                UsernamePasswordAuthenticationToken authRequest = new UsernamePasswordAuthenticationToken("",
                        token);
                authRequest.setDetails(this.authenticationDetailsSource.buildDetails(request));
                Authentication authResult = this.authenticationManager.authenticate(authRequest);

                LOGGER.debug("Authentication success: {} ", authResult);

                SecurityContextHolder.getContext().setAuthentication(authResult);

                onSuccessfulAuthentication(request, response, authResult);
            }

        }
        catch (AuthenticationException failed) {
            SecurityContextHolder.clearContext();

            LOGGER.debug("Authentication request for failed: ", failed);

            onUnsuccessfulAuthentication(request, response, failed);

            if (this.ignoreFailure) {
                chain.doFilter(request, response);
            }
            else {
                this.authenticationEntryPoint.commence(request, response, failed);
            }

            return;
        }

        chain.doFilter(request, response);
    }

    private boolean tokenAuthenticationIsRequired(String token) {
        // Only reauthenticate if token doesn't match SecurityContextHolder
        // and user
        // isn't authenticated
        // (see SEC-53)
        Authentication existingAuth = SecurityContextHolder.getContext().getAuthentication();

        if (existingAuth == null || !existingAuth.isAuthenticated()) {
            return true;
        }

        // Limit username comparison to providers which use usernames (ie
        // UsernamePasswordAuthenticationToken)
        // (see SEC-348)

        if (existingAuth instanceof UsernamePasswordAuthenticationToken && !existingAuth.getCredentials().equals(token)) {
            return true;
        }


        // Handle unusual condition where an AnonymousAuthenticationToken is
        // already
        // present
        // This shouldn't happen very often, as BasicProcessingFitler is meant
        // to be
        // earlier in the filter
        // chain than AnonymousAuthenticationFilter. Nevertheless, presence of
        // both an
        // AnonymousAuthenticationToken
        // together with a BASIC authentication request header should indicate
        // reauthentication using the
        // BASIC protocol is desirable. This behaviour is also consistent with
        // that
        // provided by form and digest,
        // both of which force re-authentication if the respective header is
        // detected (and
        // in doing so replace
        // any existing AnonymousAuthenticationToken). See SEC-610.
        if (existingAuth instanceof AnonymousAuthenticationToken) {
            return true;
        }

        return false;
    }

}
