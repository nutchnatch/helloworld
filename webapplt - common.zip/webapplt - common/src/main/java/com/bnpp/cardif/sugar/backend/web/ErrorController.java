package com.bnpp.cardif.sugar.backend.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.NoHandlerFoundException;

import com.bnpp.cardif.sugar.beans.RestResponse;

@ControllerAdvice
public class ErrorController
{
    private static final Logger LOGGER = LoggerFactory.getLogger(ErrorController.class);

    @ExceptionHandler(NoHandlerFoundException.class)
    @ResponseBody
    public ResponseEntity<RestResponse> handle(Exception ex)
    {
        LOGGER.error("No handler found : ", ex);
        RestResponse restResponse = new RestResponse();
        restResponse.setErrorCode("404");
        restResponse.setErrorMessage("Page not found : " + ex.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(restResponse);
    }

    @ExceptionHandler(Exception.class)
    @ResponseBody
    public ResponseEntity<RestResponse> handleException(Exception ex)
    {
        LOGGER.error("Error : ", ex);
        RestResponse restResponse = new RestResponse();
        restResponse.setErrorCode("500");
        restResponse.setErrorMessage("Internal error : " + ex.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(restResponse);
    }

}
