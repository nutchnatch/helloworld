package com.bnpp.cardif.sugar.backend.config;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.DispatcherType;
import javax.servlet.Filter;
import javax.servlet.FilterRegistration;
import javax.servlet.FilterRegistration.Dynamic;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.embedded.EmbeddedServletContainerFactory;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.boot.web.servlet.ServletContextInitializer;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.Conventions;
import org.springframework.util.Assert;
import org.springframework.util.ObjectUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.DispatcherServlet;

import com.bnpp.cardif.sugar.dao.oracle.util.SugarNameSpacePrefixMapper;

/**
 * This class configure the Root Spring context for the application.
 * 
 * This context should include all the application beans except the Spring MVC
 * controllers that will be loaded into the WebMvcConfiguration
 * 
 * The @ComponentScan is loading all configuration within the same package (and
 * child packages) as RootConfiguration. Since SecurityConfig is in this
 * package, it will be loaded with our existing setup.
 * 
 * @author 831743
 *
 */
@Configuration
// In this component scan annotation, set all the packages that contains your
// security, utility, DAO and services classes.
@ComponentScan(basePackages = { "com.bnpp.cardif.sesame.security", "com.bnpp.cardif.sugar",
        "com.bnpp.cardif.sugar.security", "com.bnpp.cardif.sugar.dao.oracle", "com.bnpp.cardif.sugar.core.tsp",
        "com.bnpp.cardif.sugar.ws.webapp" })
// Import the DB configuration
@Import({ DBConfig.class, CacheConfig.class, EndpointConfig.class })
// Load an XML config file for the code that doesn't use annotations.
@ImportResource({ "classpath:sugar-ws-webapp.xml", "sugar-rest-webapp.xml", "classpath:acl-context.xml" })
public class RootConfiguration implements ServletContextInitializer {

    private static final Logger LOGGER = LoggerFactory.getLogger(RootConfiguration.class);

    @Value("${server.port}")
    private int serverPort;

    @Value("${server.contextPath}")
    private String serverContextPath;

    @Value("${server.session.timeout}")
    private int serverSessionTimeout;

    // To resolve ${} in @Value
    @Bean
    public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public EmbeddedServletContainerFactory servletContainer() {
        TomcatEmbeddedServletContainerFactory factory = new TomcatEmbeddedServletContainerFactory();
        factory.setPort(serverPort);
        factory.setContextPath(serverContextPath);
        factory.setSessionTimeout(serverSessionTimeout, TimeUnit.MINUTES);
        return factory;
    }

    @Bean
    public SugarNameSpacePrefixMapper nameSpacePrefixMapper() {
        SugarNameSpacePrefixMapper mapper = new SugarNameSpacePrefixMapper();
        Map<String, String> prefixes = new HashMap<>();
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/businessscope/v1", "businessscope");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1", "acl");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolder/v1", "folder");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolderclass/v1", "folderclass");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1", "basket");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1", "task");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1", "doc");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/documentclass/v1", "docclass");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/documentfile/v1", "file");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1", "common");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1", "i18n");
        prefixes.put("http://www.arondor.com/schema/flower/calyx", "calyx");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/xmldao/v1", "colldb");
        mapper.setPrefixes(prefixes);
        return mapper;
    }

    @Override
    public void onStartup(ServletContext servletContext) throws ServletException {
        LOGGER.debug("Executing RootConfiguration.onStartup ");
        this.addFilterToServlet(servletContext);
    }


    protected void addFilterToServlet(ServletContext servletContext) {

        LOGGER.debug("Executing RootConfiguration.addFilterToServlet ");

        Filter[] filters = getServletFilters();
        if (!ObjectUtils.isEmpty(filters)) {
            for (Filter filter : filters) {
                registerServletFilter(servletContext, filter);
            }
        }

        //customizeRegistration(registration);
    }

    /**
     * Register ServletRegistrationBean to define the request mapping
     * @param dispatcherServlet - dispatcher servlet associated to the configured servlet context
     * @return configured servlet registration
     */
    @Bean
    public ServletRegistrationBean servletRegistration(DispatcherServlet dispatcherServlet) {

        ServletRegistrationBean servletRegistration = new ServletRegistrationBean(dispatcherServlet);
        servletRegistration.addUrlMappings(getServletMappings());
        servletRegistration.setLoadOnStartup(1);
        servletRegistration.setAsyncSupported(isAsyncSupported());
        return servletRegistration;
    }

    /**
     * Register a {@link DispatcherServlet} against the given servlet context.
     * <p>
     * This method will create a {@code DispatcherServlet} with the name
     * returned by {@link #getSoapServletName()}, initializing it with the
     * application context returned from
     * {@link #createServletApplicationContext()}, and mapping it to the
     * patterns returned from {@link #getServletMappings()}.
     * <p>
     * Further customization can be achieved by overriding
     * {@link #customizeRegistration(ServletRegistration.Dynamic)}
     *
     * @param servletContext
     *            the context to register the servlet against
     */
    @Bean
    public DispatcherServlet dispatcherServlet(ServletContext servletContext) {

        String servletName = getSoapServletName();
        Assert.hasLength(servletName, "getSoapServletName() must not return empty or null");

        WebApplicationContext servletAppContext = createServletApplicationContext();
        Assert.notNull(servletAppContext, "createServletApplicationContext() did not return an application "
                + "context for servlet [" + servletName + "]");

        DispatcherServlet dispatcherServlet = new DispatcherServlet(servletAppContext);
        dispatcherServlet.setContextInitializers(getServletApplicationContextInitializers());

        ServletRegistration.Dynamic registration = servletContext.addServlet(servletName, dispatcherServlet);
        Assert.notNull(registration, "Failed to register servlet with name '" + servletName + "'."
                + "Check if there is another servlet registered under the same name.");

        customizeRegistration(registration);
        return dispatcherServlet;
    }

    /**
     * Return the name under which the DispatcherServlet will be registered.
     * Defaults to DEFAULT_SERVLET_NAME.
     */
    protected String getSoapServletName() {
        LOGGER.debug("getSoapServletName");
        return "sugarDispatchServlet";
    }

    /**
     * This implementation creates an
     * {@link AnnotationConfigWebApplicationContext}, providing it the annotated
     * classes returned by {@link #getServletConfigClasses()}.
     */
    protected WebApplicationContext createServletApplicationContext() {
        AnnotationConfigWebApplicationContext servletAppContext = new AnnotationConfigWebApplicationContext();
        Class<?>[] configClasses = getServletConfigClasses();
        if (!ObjectUtils.isEmpty(configClasses)) {
            servletAppContext.register(configClasses);
        }
        return servletAppContext;
    }

    /**
     * Specify @Configuration and/or @Component classes to be provided to the
     * dispatcher servlet application context.
     */
    protected Class<?>[] getServletConfigClasses() {
        LOGGER.debug("getServletConfigClasses");
        return new Class[] { WebMvcConfiguration.class };
    }

    /**
     * Specify application context initializers to be applied to the
     * servlet-specific application context that the {@code DispatcherServlet}
     * is being created with.
     * 
     */
    @SuppressWarnings("squid:S1452")
    protected ApplicationContextInitializer<?>[] getServletApplicationContextInitializers() {
        return new ApplicationContextInitializer<?>[0];
    }

    /**
     * Specify the servlet mapping(s) for the {@code DispatcherServlet} for
     * example {@code "/"}, {@code "/app"}, etc.
     * 
     */
    protected String[] getServletMappings() {
        LOGGER.debug("getServletMappings");
        return new String[] { "/rest/*" };
    }

    /**
     * A single place to control the {@code asyncSupported} flag for the
     * {@code DispatcherServlet} and all filters added via
     * {@link #getServletFilters()}.
     * <p>
     * The default value is "true".
     */
    protected boolean isAsyncSupported() {
        return true;
    }

    /**
     * Specify filters to add and map to the {@code DispatcherServlet}.
     * 
     * @return an array of filters or {@code null}
     */
    protected Filter[] getServletFilters() {
        LOGGER.debug("getServletFilters");
        CharacterEncodingFilter characterEncodingFilter = new CharacterEncodingFilter();
        characterEncodingFilter.setEncoding("UTF-8");
        return new Filter[] { characterEncodingFilter };
    }

    /**
     * Add the given filter to the ServletContext and map it to the
     * {@code DispatcherServlet} as follows:
     * <ul>
     * <li>a default filter name is chosen based on its concrete type
     * <li>the {@code asyncSupported} flag is set depending on the return value
     * of {@link #isAsyncSupported() asyncSupported}
     * <li>a filter mapping is created with dispatcher types {@code REQUEST},
     * {@code FORWARD}, {@code INCLUDE}, and conditionally {@code ASYNC}
     * depending on the return value of {@link #isAsyncSupported()
     * asyncSupported}
     * </ul>
     * <p>
     * If the above defaults are not suitable or insufficient, override this
     * method and register filters directly with the {@code ServletContext}.
     * 
     * @param servletContext
     *            the servlet context to register filters with
     * @param filter
     *            the filter to be registered
     * @return the filter registration
     */
    protected FilterRegistration.Dynamic registerServletFilter(ServletContext servletContext, Filter filter) {
        String filterName = Conventions.getVariableName(filter);
        Dynamic registration = servletContext.addFilter(filterName, filter);
        if (registration == null) {
            int counter = -1;
            while (counter == -1 || registration == null) {
                counter++;
                registration = servletContext.addFilter(filterName + "#" + counter, filter);
                Assert.isTrue(counter < 100, "Failed to register filter '" + filter + "'."
                        + "Could the same Filter instance have been registered already?");
            }
        }
        registration.setAsyncSupported(isAsyncSupported());
        registration.addMappingForServletNames(getDispatcherTypes(), false, getSoapServletName());
        return registration;
    }

    private EnumSet<DispatcherType> getDispatcherTypes() {
        return (isAsyncSupported()
                ? EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD, DispatcherType.INCLUDE,
                        DispatcherType.ASYNC)
                : EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD, DispatcherType.INCLUDE));
    }

    /**
     * Optionally perform further registration customization.
     * 
     * @param registration
     *            the {@code DispatcherServlet} registration to be customized
     */
    protected void customizeRegistration(ServletRegistration.Dynamic registration) {
        // return an exception if no request handler is found for the called URL
        registration.setInitParameter("throwExceptionIfNoHandlerFound", "true");
    }

}
