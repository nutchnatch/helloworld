package com.bnpp.cardif.sugar.frontend.services;

import java.util.List;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

/**
 * 
 * @author 831743
 *
 */
public interface DocumentTypeService {

    /**
     * Get a DocumentClass identified by its ID and version.
     * 
     * @param id
     * @param version
     * @return DocumentClass
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public DocumentClass getDocumentTypeByID(String id, int version) throws TechnicalException, FunctionalException;

    /**
     * Get all DocumentClass for DOCUMENT.
     * 
     * @return List<DocumentClass>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<DocumentClass> getAllDocumentType() throws TechnicalException, FunctionalException;

    /**
     * Get all DocumentClass for DOCUMENT including the inactive ones (for admin
     * usage).
     * 
     * @return List<DocumentClass>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<DocumentClass> getAllDocumentTypeWithInactives() throws TechnicalException, FunctionalException;

    /**
     * Get all DocumentClass for ENVELOPE.
     * 
     * @return List<DocumentClass>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<DocumentClass> getAllEnvelopeType() throws TechnicalException, FunctionalException;

    /**
     * Get all DocumentClass for ENVELOPE including the inactive ones (for admin
     * usage).
     * 
     * @return List<DocumentClass>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<DocumentClass> getAllEnvelopeTypeWithInactive() throws TechnicalException, FunctionalException;

    /**
     * Get all DocumentClass for the passed Category.
     * 
     * @param category
     *            : the document category (Document/envelope)
     * @param activeOnly
     *            : if true only the active class are returned.
     * @return List<DocumentClass>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<DocumentClass> getAllDocumentType(final Category category, final boolean activeOnly)
            throws TechnicalException, FunctionalException;

    /**
     * Get the list of tags associated to a DocumentClass identified by its ID
     * and version.
     * 
     * @param id
     * @param version
     * @return List<TagClass>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<TagClass> getDocumentTypeTags(String id, int version) throws TechnicalException, FunctionalException;

    /**
     * Add a new DocumentType into the current businessScope.
     * 
     * @param input
     *            DocumentClass
     * @return DocumentClass
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public DocumentClass createDocumentType(DocumentClass input) throws TechnicalException, FunctionalException;

    /**
     * Add a new EnvelopeType into the current businessScope.
     * 
     * @param input
     *            DocumentClass
     * @return DocumentClass
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public DocumentClass createEnvelopeType(DocumentClass input) throws TechnicalException, FunctionalException;

    /**
     * Update a DocumentType into the current businessScope (by creating a new
     * version).
     * 
     * @param input
     *            DocumentClass
     * @return DocumentClass
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public DocumentClass updateDocumentType(DocumentClass input) throws TechnicalException, FunctionalException;

    /**
     * Update a EnvelopeType into the current businessScope (by creating a new
     * version).
     * 
     * @param input
     *            DocumentClass
     * @return DocumentClass
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public DocumentClass updateEnvelopeType(DocumentClass input) throws TechnicalException, FunctionalException;

    /**
     * Activate a DocumentType into the current businessScope.
     * 
     * @param documentTypeId
     * @param version
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public void activateDocumentType(String documentTypeId, int version) throws TechnicalException, FunctionalException;

    /**
     * Deactivate a DocumentType into the current businessScope.
     * 
     * @param documentTypeId
     * @param version
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public void deactivateDocumentType(String documentTypeId, int version)
            throws TechnicalException, FunctionalException;

    /**
     * Activate a EnvelopeType into the current businessScope.
     * 
     * @param documentTypeId
     * @param version
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public void activateEnvelopeType(String documentTypeId, int version) throws TechnicalException, FunctionalException;

    /**
     * Deactivate a EnvelopeType into the current businessScope.
     * 
     * @param documentTypeId
     * @param version
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public void deactivateEnvelopeType(String documentTypeId, int version)
            throws TechnicalException, FunctionalException;

}
