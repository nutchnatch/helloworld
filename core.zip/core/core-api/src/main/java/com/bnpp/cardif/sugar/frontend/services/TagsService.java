package com.bnpp.cardif.sugar.frontend.services;

import java.util.List;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

/**
 * 
 * @author 831743
 *
 */
public interface TagsService {

    /**
     * Get the list of all tagClass from the current BuisnessScope
     * 
     * @return List<TagClass>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<TagClass> getAllTagList() throws TechnicalException, FunctionalException;

    /**
     * Get the list of all tagClass with the symbolicNames passed as parameters.
     * 
     * @param symbolicNames
     * @return List<TagClass>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<TagClass> getTagListBySymbolicName(List<String> symbolicNames)
            throws TechnicalException, FunctionalException;

    /**
     * Create a new TagClass.
     * 
     * @param inputTagClass
     * @return TagClass
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public TagClass createTag(TagClass inputTagClass) throws TechnicalException, FunctionalException;

    /**
     * Update an existing TagClass.
     * 
     * @param inputTagClass
     * @return TagClass
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public TagClass updateTag(TagClass inputTagClass) throws TechnicalException, FunctionalException;

}
