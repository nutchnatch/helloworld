package com.bnpp.cardif.sugar.frontend.services.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Container for a list with pagination data
 * 
 * @author 831743
 *
 * @param <E>
 */
public class PagingList<E extends Serializable> {

    private List<E> itemList = new ArrayList<>();

    private long itemNumber;

    private long itemMax;

    public List<E> getItemList() {
        return itemList;
    }

    public void setItemList(List<E> itemList) {
        this.itemList = itemList;
    }

    public long getItemNumber() {
        return itemNumber;
    }

    public void setItemNumber(long itemNumber) {
        this.itemNumber = itemNumber;
    }

    public long getItemMax() {
        return itemMax;
    }

    public void setItemMax(long itemMax) {
        this.itemMax = itemMax;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((itemList == null) ? 0 : itemList.hashCode());
        result = prime * result + (int) (itemMax ^ (itemMax >>> 32));
        result = prime * result + (int) (itemNumber ^ (itemNumber >>> 32));
        return result;
    }

    @Override public boolean equals(Object o)
    {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        PagingList<?> that = (PagingList<?>) o;
        return itemNumber == that.itemNumber && itemMax == that.itemMax && Objects.equals(itemList, that.itemList);
    }

    @Override
    public String toString() {
        return "PagingList [itemList=" + itemList + ", itemNumber=" + itemNumber + ", itemMax=" + itemMax + "]";
    }

}
