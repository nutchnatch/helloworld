package com.bnpp.cardif.sugar.frontend.services;

import java.util.List;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.frontend.services.model.PagingList;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;

/**
 * 
 * @author 831743
 *
 */
public interface FolderService {

    /**
     * Get a Folder identified by its ID.
     * 
     * @param id
     * @return Folder
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public Folder getFolderByID(String id) throws TechnicalException, FunctionalException;

    /**
     * Find all folders matching the selected filtering parameters.
     * 
     * @param start
     * @param maximum
     * @param quickSearchValue
     * @param criterionList
     * @param orderClause
     * @param includeChild
     * @return PagingList<Folder>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public PagingList<Folder> findFolders(long start, long maximum, String quickSearchValue,
            List<Criterion> criterionList, OrderClause orderClause, boolean includeChild)
            throws TechnicalException, FunctionalException;

    /**
     * Get all the folders that contains the document identified by the passed
     * ID.
     * 
     * @param documentId
     * @return List<Folder>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<Folder> getFoldersByDocumentId(String documentId) throws TechnicalException, FunctionalException;

    /**
     * Create a list of folders in the backend. The list of created objects is
     * returned.
     * 
     * @param folderList
     *            : List<Folder> cannont be null.
     * @return List<Folder>
     * @throws FunctionalException
     * @throws TechnicalException
     */
    public List<Folder> createFolders(List<Folder> folderList) throws FunctionalException, TechnicalException;

    /**
     * Update a list of folders in the backend. The list of updated objects is
     * returned.
     * 
     * @param folderList
     *            : List<Folder> cannont be null.
     * @return List<Folder>
     * @throws FunctionalException
     * @throws TechnicalException
     */
    public List<Folder> updateFolders(List<Folder> folderList) throws FunctionalException, TechnicalException;

    /**
     * Attach a list of documents identified by their IDs to the folder
     * identified by its ID.
     * 
     * @param folderId
     * @param documentIdlist
     * @return Folder
     * @throws FunctionalException
     * @throws TechnicalException
     */
    public Folder attachDocumentToFolder(String folderId, List<String> documentIdlist)
            throws FunctionalException, TechnicalException;
    
    /**
     * Detach a list of documents identified by their IDs from the folder
     * identified by its ID.
     * 
     * @param folderId
     * @param documentIdlist
     * @return Folder
     * @throws FunctionalException
     * @throws TechnicalException
     */
    public Folder detachDocumentFromFolder(String folderId, List<String> documentIdlist)
            throws FunctionalException, TechnicalException;

}
