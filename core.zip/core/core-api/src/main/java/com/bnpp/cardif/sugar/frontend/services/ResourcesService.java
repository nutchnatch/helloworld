package com.bnpp.cardif.sugar.frontend.services;

import javax.servlet.http.HttpSession;

import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpp.cardif.sugar.security.AuthenticatedUser;
import com.bnppa.sesame.services.standard.proxy.InvalidTokenException;

/**
 * 
 * @author 831743
 *
 */
@SuppressWarnings("squid:S1609")
public interface ResourcesService {

    /**
     * Get the current authenticated user.
     * 
     * @return AuthenticatedUser
     * @throws TechnicalException
     */
    public AuthenticatedUser getUser() throws TechnicalException;



    /**
     * Set the business scope.
     *
     * @return AuthenticatedUser
     * @throws TechnicalException
     */
    public void setBusinessScope(final String scope) throws TechnicalException;
    
    /**
     * Invalidate Sesame token and invalidate current session.
     * 
     * @param httpSession
     * @throws InvalidTokenException
     * @throws com.bnppa.sesame.services.standard.proxy.TechnicalException
     */
    public void logout(HttpSession httpSession)
            throws InvalidTokenException, com.bnppa.sesame.services.standard.proxy.TechnicalException;

}
