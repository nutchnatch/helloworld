package com.bnpp.cardif.sugar.frontend.services;

import java.time.LocalDateTime;
import java.util.List;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.BasketRatio;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.DocumentStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.EnvelopeFlows;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.FolderStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.Summary;
import com.bnpparibas.assurance.sugar.internal.service.app.track.v1.Track;

/**
 * 
 * @author 831743
 *
 */
public interface ReportingService {
    
    /**
     * 
     * @param startingDate
     * @param endingDate
     * @return List<BasketRatio>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<BasketRatio> getBasketRatioIndicators(String startingDate, String endingDate) throws TechnicalException, FunctionalException;
    
    /**
     * 
     * @param startingDate
     * @param endingDate
     * @return List<DocumentStock>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<DocumentStock> getDocumentStockIndicators(String startingDate, String endingDate) throws TechnicalException, FunctionalException;
    
    /**
     * 
     * @param startingDate
     * @param endingDate
     * @return List<EnvelopeFlows>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<EnvelopeFlows> getEnvelopeFlowsIndicators(String startingDate, String endingDate) throws TechnicalException, FunctionalException;
    
    /**
     * 
     * @param startingDate
     * @param endingDate
     * @return List<FolderStock>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<FolderStock> getFolderStockIndicators(String startingDate, String endingDate) throws TechnicalException, FunctionalException;
    
    /**
     * 
     * @return Summary
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public Summary getReportingSummary() throws TechnicalException, FunctionalException;

    /**
     *
     * Get the list of traces records accordingly to the search parameters.
     *
     * @param startDateTime         The start date time of the action
     * @param endDateTime           The end date time of the action
     * @param objectId              The id of the source object of the action
     * @param userId                The id of the user who performed the action
     * @return                      The {@link List<Track>} found
     * @throws TechnicalException   if a technical error occurs
     * @throws FunctionalException  if a function error occurs
     */
    String getTraceLogFile(LocalDateTime startDateTime, LocalDateTime endDateTime, String objectId,
            String userId) throws TechnicalException, FunctionalException;
}
