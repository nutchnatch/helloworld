package com.bnpp.cardif.sugar.frontend.services;

import java.util.List;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;

import javax.annotation.Nonnull;

/**
 * 
 * @author 831743
 *
 */
public interface AclService {

    /**
     * Get the list of all AccessControlList.
     * 
     * @return List<AccessControlList>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    List<AccessControlList> getAllAclList() throws TechnicalException, FunctionalException;

    /**
     * Get the AccessControlList attached to a Class Id.
     * 
     * @param id
     * @param version
     * @param isInstanceValue
     * @return List<AccessControlList>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    AccessControlList getAclListByClassId(String id, int version, boolean isInstanceValue)
            throws TechnicalException, FunctionalException;

    /**
     * Get the AccessControlList attached to a Basket Id.
     * 
     * @param id
     * @return AccessControlList
     * @throws TechnicalException
     * @throws FunctionalException
     */
    AccessControlList getAclListByBasketId(String id) throws TechnicalException, FunctionalException;

    /**
     * Get the Default AccessControlList attached to the current BuinessScope
     * 
     * @return AccessControlList
     * @throws TechnicalException
     * @throws FunctionalException
     */
    AccessControlList getDefaultAclByBuisnessScope() throws TechnicalException, FunctionalException;

    /**
     * Assign an ACL to a class Id.
     * 
     * @param inputAclId
     * @param inputClassId
     * @param inputClassVersion
     * @param isInstanceValue
     * @return AccessControlList
     * @throws TechnicalException
     * @throws FunctionalException
     */
    AccessControlList assignAclToClassId(String inputAclId, String inputClassId, int inputClassVersion,
            boolean isInstanceValue) throws TechnicalException, FunctionalException;

    /**
     * Assign ACL to a basket Id.
     * 
     * @param inputAclId
     * @param inputBasketId
     * @return AccessControlList
     * @throws TechnicalException
     * @throws FunctionalException
     */
    AccessControlList assignAclToBasketId(String inputAclId, String inputBasketId)
            throws TechnicalException, FunctionalException;

    /**
     * Assigns ACL to business scope
     * @param scope - business scope
     * @param aclId - business scope Id
     * @return AccessControlList
     */
    AccessControlList assignBusinessScopeACL(@Nonnull String scope, @Nonnull String aclId)
            throws TechnicalException, FunctionalException;
}
