package com.bnpp.cardif.sugar.frontend.services;

import java.util.List;

import com.bnpp.cardif.sugar.exception.FunctionalException;
import com.bnpp.cardif.sugar.exception.TechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;

/**
 * 
 * @author 831743
 *
 */
public interface BasketsService {
    
    /**
     * Get the list of all baskets.
     * 
     * @return List<Basket>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<Basket> getAllBasketList() throws TechnicalException, FunctionalException;
    
    /**
     * Get the list of baskets matching the passed list of IDs
     * @param idList
     * @return List<Basket>
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public List<Basket> getBasketListByIds(List<String> idList) throws TechnicalException, FunctionalException;
    
    /**
     * Get the Basket matching the passed ID
     * 
     * @param id
     * @return Basket
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public Basket getBasketByID(String id) throws TechnicalException, FunctionalException;
    
    /**
     * Create a list of new Baskets
     * 
     * @param basketList
     * @return List<Basket>
     * @throws FunctionalException
     * @throws TechnicalException
     */
    public List<Basket> createBaskets(List<Basket> basketList) throws FunctionalException, TechnicalException;
    
    /**
     * Create one new Basket
     * 
     * @param inputBasket
     * @return Basket
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public Basket createBasket(Basket inputBasket) throws TechnicalException, FunctionalException;

    /**
     * Update a list of existing Baskets
     * 
     * @param basketList
     * @return List<Basket>
     * @throws FunctionalException
     * @throws TechnicalException
     */
    public List<Basket> updateBaskets(List<Basket> basketList) throws FunctionalException, TechnicalException;
    
    /**
     * Update one existing Basket
     * 
     * @param inputBasket
     * @return Basket
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public Basket updateBasket(Basket inputBasket) throws TechnicalException, FunctionalException;
    
    /**
     * Delete a list of existing Baskets identified by their IDs
     * 
     * @param idList
     * @throws FunctionalException
     * @throws TechnicalException
     */
    public void deleteBaskets(List<String> idList) throws FunctionalException, TechnicalException;
    
    /**
     * Delete one existing Baskets identified by its ID
     * 
     * @param inputBasketId
     * @throws TechnicalException
     * @throws FunctionalException
     */
    public void deleteBasket(String inputBasketId) throws TechnicalException, FunctionalException;
}
