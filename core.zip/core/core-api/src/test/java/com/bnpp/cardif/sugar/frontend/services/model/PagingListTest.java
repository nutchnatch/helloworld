package com.bnpp.cardif.sugar.frontend.services.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

public class PagingListTest {
    
    private PodamFactory factory = new PodamFactoryImpl();

    @Before
    public void setUp() throws Exception {
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testHashCode() {
        
        PagingList<String> testObj1 = factory.manufacturePojo(PagingList.class, String.class);
        PagingList<String> testObj2 = factory.manufacturePojo(PagingList.class, String.class);
        PagingList<String> testObj3 = new PagingList<>();
        
        assertNotNull(testObj1.hashCode());
        assertNotNull(testObj2.hashCode());
        assertNotNull(testObj3.hashCode());
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testEqualsObject() {
        
        PagingList<String> testObj1 = factory.manufacturePojo(PagingList.class, String.class);
        PagingList<String> testObj2 = factory.manufacturePojo(PagingList.class, String.class);
        PagingList<String> testObj3 = new PagingList<>();
        
        assertNotNull(testObj1.equals(testObj2));
        assertTrue(testObj1.equals(testObj1));
        assertFalse(testObj2.equals(null));
        assertFalse(testObj2.equals(""));
        assertFalse(testObj3.equals(""));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testToString() {
        
        PagingList<String> testObj1 = factory.manufacturePojo(PagingList.class, String.class);
        PagingList<String> testObj2 = factory.manufacturePojo(PagingList.class, String.class);
        PagingList<String> testObj3 = new PagingList<>();
        
        assertNotNull(testObj1.toString());
        assertNotNull(testObj2.toString());
        assertNotNull(testObj3.toString());
    }

}
