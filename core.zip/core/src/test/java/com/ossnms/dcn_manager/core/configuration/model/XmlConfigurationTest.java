package com.ossnms.dcn_manager.core.configuration.model;

import com.ossnms.dcn_manager.core.configuration.loaders.XmlConfiguration;
import com.ossnms.dcn_manager.core.jaxb.netype.Config;
import org.junit.Test;

import java.net.MalformedURLException;
import java.net.URL;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

public class XmlConfigurationTest {

    private static final URL XML_URL = XmlConfigurationTest.class.getClassLoader().getResource("netype/NeTypeLoadTest.xml");

    @Test
    public void testLoading() {
        final Config configuration = XmlConfiguration.unmarshal(Config.class, XML_URL, null);
        assertNotNull(configuration);
    }

    @Test
    public void testLoadingBadClass() {
        final Object configuration = XmlConfiguration.unmarshal(Object.class, XML_URL, null);
        assertNull(configuration);
    }

    @Test
    public void testLoadingBadUrl() throws MalformedURLException {
        assertNull(XmlConfiguration.unmarshal(Config.class, new URL("file:///xpto"), null));
    }

}
