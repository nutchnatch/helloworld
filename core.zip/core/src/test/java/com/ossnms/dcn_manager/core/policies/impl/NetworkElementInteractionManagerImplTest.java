package com.ossnms.dcn_manager.core.policies.impl;

import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent;
import com.ossnms.dcn_manager.core.events.ne.NeSynchronizationEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeDisconnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeInitializedEvent;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManagerStage;
import com.ossnms.dcn_manager.core.test.RunRunnableAnswer;
import org.junit.Before;
import org.junit.Test;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import java.util.concurrent.RejectedExecutionException;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;

public class NetworkElementInteractionManagerImplTest {

    private static final int MAX_SIMULTANEOUS_INTERACTIONS = 5;

    private NeConnectionManager connectionManager;
    private final NetworkElementInteractionManagerStage[] stages = new NetworkElementInteractionManagerStage[1];

    @Before
    public void setUp() {

        stages[0] = mock(NetworkElementInteractionManagerStage.class);
        doAnswer(new RunRunnableAnswer())
            .when(stages[0]).execute(any(Runnable.class));

        connectionManager = mock(NeConnectionManager.class);
    }

    private final class AcceptOnlyFirstRunnableAnswer implements Answer<Void> {
        private int count = 0;
        @Override
        public Void answer(InvocationOnMock invocation) throws Throwable {
            final Runnable task = (Runnable) invocation.getArguments()[0];
            if (task != null) {
                if (count < 1) {
                    count = 1;
                    task.run();
                } else {
                    throw new RejectedExecutionException();
                }
            }
            return null;
        }
    }

    @Test
    public void testScheduleActivation() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(MAX_SIMULTANEOUS_INTERACTIONS, stages, connectionManager);

        manager.scheduleActivation(new Activate(10, 1, 100, 1000, false));

        // because the manager queue was empty and the executor runs immediately, the job should already be "on going".
        assertThat(manager.getOngoingJobCount(), is(1));

        verify(connectionManager).activate(new Activate(10, 1, 100, 1000, false));
    }

    @Test
    public void testScheduleDeactivation() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(MAX_SIMULTANEOUS_INTERACTIONS, stages, connectionManager);

        manager.scheduleDeactivation(new Deactivate(10, 1, 100, 1000, false));

        assertThat(manager.getOngoingJobCount(), is(1));

        verify(connectionManager).deactivate(new Deactivate(10, 1, 100, 1000, false));
    }

    @Test
    public void testScheduleSynchronization() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(MAX_SIMULTANEOUS_INTERACTIONS, stages, connectionManager);

        manager.scheduleSynchronization(new NeSynchronizationEvent(10, 1000, 1, 100, false));

        // because the manager queue was empty and the executor runs immediately, the job should already be "on going".
        assertThat(manager.getOngoingJobCount(), is(1));

        verify(connectionManager).alwaysInitialize(new NeSynchronizationEvent(10, 1000, 1, 100, false));
    }

    @Test
    public void testScheduleDeactivation_cancelsActivation() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(1, stages, connectionManager);

        manager.scheduleActivation(new Activate(30, 1, 100, 3000, false));

        manager.scheduleActivation(new Activate(10, 1, 100, 1000, false));

        assertThat(manager.getOngoingJobCount(), is(1)); // NE ID = 30
        assertThat(manager.getPendingJobCount(), is(1)); // NE ID = 10

        manager.scheduleDeactivation(new Deactivate(20, 1, 100, 2000, false));

        assertThat(manager.getOngoingJobCount(), is(2)); // NE ID = 30; 20 (deactivations are high priority)
        assertThat(manager.getPendingJobCount(), is(1)); // NE ID = 10

        manager.scheduleDeactivation(new Deactivate(10, 1, 100, 1000, false));

        assertThat(manager.getOngoingJobCount(), is(2)); // NE ID = 30; 20 (deactivations are high priority and always run)
        assertThat(manager.getPendingJobCount(), is(0));
    }

    @Test
    public void testScheduleDeactivation_cancelsPendingSynchronization() {
        stages[0] = mock(NetworkElementInteractionManagerStage.class);
        doAnswer(new AcceptOnlyFirstRunnableAnswer())
                .when(stages[0]).execute(any(Runnable.class));

        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(1, stages, connectionManager);

        manager.scheduleActivation(new Activate(30, 1, 100, 3000, false));

        manager.scheduleSynchronization(new NeSynchronizationEvent(10, 1000, 1, 100, false));

        assertThat(manager.getOngoingJobCount(), is(1)); // NE ID = 30
        assertThat(manager.getPendingJobCount(), is(1)); // NE ID = 10

        manager.scheduleDeactivation(new Deactivate(20, 1, 100, 2000, false));

        assertThat(manager.getOngoingJobCount(), is(1)); // NE ID = 30
        assertThat(manager.getPendingJobCount(), is(2)); // NE ID = 10; 20

        manager.scheduleDeactivation(new Deactivate(10, 1, 100, 1000, false));

        assertThat(manager.getOngoingJobCount(), is(1)); // NE ID = 30
        assertThat(manager.getPendingJobCount(), is(1)); // NE ID = 20
    }

    @Test
    public void testScheduleDeactivation_cancelsRunningSynchronization() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(1, stages, connectionManager);

        manager.scheduleActivation(new Activate(30, 1, 100, 3000, false));

        manager.scheduleSynchronization(new NeSynchronizationEvent(10, 1000, 1, 100, false));

        assertThat(manager.getOngoingJobCount(), is(1)); // NE ID = 30
        assertThat(manager.getPendingJobCount(), is(1)); // NE ID = 10

        manager.scheduleDeactivation(new Deactivate(20, 1, 100, 2000, false));

        assertThat(manager.getOngoingJobCount(), is(2)); // NE ID = 30; 20 (deactivations are high priority)
        assertThat(manager.getPendingJobCount(), is(1)); // NE ID = 10

        manager.scheduleDeactivation(new Deactivate(10, 1, 100, 1000, false));

        assertThat(manager.getOngoingJobCount(), is(2)); // NE ID = 30; 20
        assertThat(manager.getPendingJobCount(), is(0));
    }

    @Test
    public void testScheduleActivation_cancelsPendingDeactivation() {
        stages[0] = mock(NetworkElementInteractionManagerStage.class);
        doAnswer(new AcceptOnlyFirstRunnableAnswer())
                .when(stages[0]).execute(any(Runnable.class));

        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(1, stages, connectionManager);

        manager.scheduleDeactivation(new Deactivate(30, 1, 100, 3000, false));

        manager.scheduleDeactivation(new Deactivate(10, 1, 100, 1000, false));

        assertThat(manager.getOngoingJobCount(), is(1)); // NE ID = 30
        assertThat(manager.getPendingJobCount(), is(1)); // NE ID = 10

        manager.scheduleActivation(new Activate(20, 1, 100, 2000, false));

        assertThat(manager.getOngoingJobCount(), is(1)); // NE ID = 30
        assertThat(manager.getPendingJobCount(), is(2)); // NE ID = 10; 20

        manager.scheduleActivation(new Activate(10, 1, 100, 1000, false));

        assertThat(manager.getOngoingJobCount(), is(1)); // NE ID = 30
        assertThat(manager.getPendingJobCount(), is(1)); // NE ID = 20
    }

    @Test
    public void testScheduleActivation_doesNotCancelRunningDeactivation() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(1, stages, connectionManager);

        manager.scheduleDeactivation(new Deactivate(30, 1, 100, 3000, false));

        manager.scheduleDeactivation(new Deactivate(10, 1, 100, 1000, false));

        assertThat(manager.getOngoingJobCount(), is(2)); // NE ID = 30; 10
        assertThat(manager.getPendingJobCount(), is(0)); // (deactivations are high priority)

        manager.scheduleActivation(new Activate(20, 1, 100, 2000, false));

        assertThat(manager.getOngoingJobCount(), is(2)); // NE ID = 30; 10
        assertThat(manager.getPendingJobCount(), is(1)); // NE ID = 20

        manager.scheduleActivation(new Activate(10, 1, 100, 1000, false));

        assertThat(manager.getOngoingJobCount(), is(2)); // NE ID = 30; 10 (deactivate)
        assertThat(manager.getPendingJobCount(), is(2)); // NE ID = 20; 10 (activate)
    }

    @Test
    public void testScheduleActivation_cancelsSynchronization() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(1, stages, connectionManager);

        manager.scheduleDeactivation(new Deactivate(30, 1, 100, 3000, false));

        manager.scheduleSynchronization(new NeSynchronizationEvent(10, 1000, 1, 100, false));

        assertThat(manager.getOngoingJobCount(), is(1)); // NE ID = 30
        assertThat(manager.getPendingJobCount(), is(1)); // NE ID = 10

        manager.scheduleActivation(new Activate(20, 1, 100, 2000, false));

        assertThat(manager.getOngoingJobCount(), is(1)); // NE ID = 30
        assertThat(manager.getPendingJobCount(), is(2)); // NE ID = 10; 20

        manager.scheduleActivation(new Activate(10, 1, 100, 1000, false));

        assertThat(manager.getOngoingJobCount(), is(1)); // NE ID = 30
        assertThat(manager.getPendingJobCount(), is(1)); // NE ID = 20
    }

    @Test
    public void testOnNeInteractionEnded_whenActivating() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(MAX_SIMULTANEOUS_INTERACTIONS, stages, connectionManager);

        manager.scheduleActivation(new Activate(10, 1, 100, 1000, false));
        manager.scheduleActivation(new Activate(20, 2, 100, 2000, false));

        assertThat(manager.getOngoingJobCount(), is(2));

        manager.onNeInteractionEnded(new ActualNeStateEvent.NeInitializedEvent(30,
                new PhysicalNeInitializedEvent(3000, 30, true)));
        assertThat(manager.getOngoingJobCount(), is(2));

        manager.onNeInteractionEnded(new ActualNeStateEvent.NeInitializedEvent(20,
                new PhysicalNeInitializedEvent(2000, 20, true)));
        assertThat(manager.getOngoingJobCount(), is(1));

        manager.onNeInteractionEnded(new ActualNeStateEvent.NeInitializedEvent(10,
                new PhysicalNeInitializedEvent(1000, 10, true)));
        assertThat(manager.getOngoingJobCount(), is(0));
    }

    @Test
    public void testOnNeInteractionEnded_whenDeactivating() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(MAX_SIMULTANEOUS_INTERACTIONS, stages, connectionManager);

        manager.scheduleDeactivation(new Deactivate(10, 1, 100, 1000, false));
        manager.scheduleDeactivation(new Deactivate(20, 2, 100, 2000, false));

        assertThat(manager.getOngoingJobCount(), is(2));

        manager.onNeInteractionEnded(new ActualNeStateEvent.NeDisconnectedEvent(30,
                new PhysicalNeDisconnectedEvent(3000, 30, true)));
        assertThat(manager.getOngoingJobCount(), is(2));

        manager.onNeInteractionEnded(new ActualNeStateEvent.NeDisconnectedEvent(20,
                new PhysicalNeDisconnectedEvent(2000, 20, true)));
        assertThat(manager.getOngoingJobCount(), is(1));

        manager.onNeInteractionEnded(new ActualNeStateEvent.NeDisconnectedEvent(10,
                new PhysicalNeDisconnectedEvent(1000, 10, true)));
        assertThat(manager.getOngoingJobCount(), is(0));
    }

    @Test
    public void testOnNeInteractionEnded_whenSynchronizing() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(MAX_SIMULTANEOUS_INTERACTIONS, stages, connectionManager);

        manager.scheduleSynchronization(new NeSynchronizationEvent(10, 1000, 1, 100, false));
        manager.scheduleSynchronization(new NeSynchronizationEvent(20, 2000, 1, 100, false));

        assertThat(manager.getOngoingJobCount(), is(2));

        manager.onNeInteractionEnded(new ActualNeStateEvent.NeDisconnectedEvent(30,
                new PhysicalNeDisconnectedEvent(3000, 30, true)));
        assertThat(manager.getOngoingJobCount(), is(2));

        manager.onNeInteractionEnded(new ActualNeStateEvent.NeDisconnectedEvent(20,
                new PhysicalNeDisconnectedEvent(2000, 20, true)));
        assertThat(manager.getOngoingJobCount(), is(1));

        manager.onNeInteractionEnded(new ActualNeStateEvent.NeDisconnectedEvent(10,
                new PhysicalNeDisconnectedEvent(1000, 10, true)));
        assertThat(manager.getOngoingJobCount(), is(0));
    }

    @Test
    public void testOnNeConnected_whenActivating_initializes() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(MAX_SIMULTANEOUS_INTERACTIONS, stages, connectionManager);

        manager.scheduleActivation(new Activate(10, 1, 100, 1000, false));
        assertThat(manager.getOngoingJobCount(), is(1));

        manager.onNeConnected(new NeSynchronizationEvent(10, 1000, 1, 12, false));
        assertThat(manager.getOngoingJobCount(), is(1));

        verify(connectionManager).lazyInitialize(new NeSynchronizationEvent(10, 1000, 1, 12, false));
    }

    @Test
    public void testActivationCancelled_whenActivationOngoing_cancels() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(MAX_SIMULTANEOUS_INTERACTIONS, stages, connectionManager);
        final Activate event = new Activate(10, 1, 100, 1000, false);

        manager.scheduleActivation(event);

        assertThat(manager.getOngoingJobCount(), is(1));

        manager.cancelActivations(event);

        assertThat(manager.getOngoingJobCount(), is(0));
    }

    @Test
    public void testActivationCancelled_whenActivationOngoingForDifferentChannel_doesNotCancel() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(MAX_SIMULTANEOUS_INTERACTIONS, stages, connectionManager);

        manager.scheduleActivation(new Activate(10, 1, 100, 1000, false));

        assertThat(manager.getOngoingJobCount(), is(1));

        manager.cancelActivations(new Activate(10, 2, 100, 1000, false));

        assertThat(manager.getOngoingJobCount(), is(1));
    }

    @Test
    public void testActivationCancelled_whenActivationOngoingForDifferentNe_doesNotCancel() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(MAX_SIMULTANEOUS_INTERACTIONS, stages, connectionManager);

        manager.scheduleActivation(new Activate(10, 1, 100, 1000, false));

        assertThat(manager.getOngoingJobCount(), is(1));

        manager.cancelActivations(new Activate(11, 1, 100, 1100, false));

        assertThat(manager.getOngoingJobCount(), is(1));
    }

    @Test
    public void testDeactivationCancelled_whenDeactivationOngoing_cancels() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(MAX_SIMULTANEOUS_INTERACTIONS, stages, connectionManager);
        final Deactivate event = new Deactivate(10, 1, 100, 1000, false);

        manager.scheduleDeactivation(event);

        assertThat(manager.getOngoingJobCount(), is(1));

        manager.cancelDeactivations(event);

        assertThat(manager.getOngoingJobCount(), is(0));
    }

    @Test
    public void testDeactivationCancelled_whenDeactivationOngoingForDifferentChannel_doesNotCancel() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(MAX_SIMULTANEOUS_INTERACTIONS, stages, connectionManager);

        manager.scheduleDeactivation(new Deactivate(10, 1, 100, 1000, false));

        assertThat(manager.getOngoingJobCount(), is(1));

        manager.cancelDeactivations(new Deactivate(10, 2, 100, 1000, false));

        assertThat(manager.getOngoingJobCount(), is(1));
    }

    @Test
    public void testDeactivationCancelled_whenDeactivationOngoingForDifferentNe_doesNotCancel() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(MAX_SIMULTANEOUS_INTERACTIONS, stages, connectionManager);

        manager.scheduleDeactivation(new Deactivate(10, 1, 100, 1000, false));

        assertThat(manager.getOngoingJobCount(), is(1));

        manager.cancelDeactivations(new Deactivate(11, 1, 100, 1100, false));

        assertThat(manager.getOngoingJobCount(), is(1));
    }

    @Test
    public void testSynchronizationCancelled_whenSynchronizationOngoing_cancels() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(MAX_SIMULTANEOUS_INTERACTIONS, stages, connectionManager);
        final NeSynchronizationEvent event = new NeSynchronizationEvent(10, 1000, 1, 100, false);

        manager.scheduleSynchronization(event);

        assertThat(manager.getOngoingJobCount(), is(1));

        manager.cancelSynchronizations(event);

        assertThat(manager.getOngoingJobCount(), is(0));
    }

    @Test
    public void testSynchronizationCancelled_whenSynchronizationOngoingForDifferentChannel_doesNotCancel() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(MAX_SIMULTANEOUS_INTERACTIONS, stages, connectionManager);

        manager.scheduleDeactivation(new Deactivate(10, 1, 100, 1000, false));

        assertThat(manager.getOngoingJobCount(), is(1));

        manager.cancelSynchronizations(new NeSynchronizationEvent(10, 1000, 2, 100, false));

        assertThat(manager.getOngoingJobCount(), is(1));
    }

    @Test
    public void testSynchronizationCancelled_whenSynchronizationOngoingForDifferentNe_doesNotCancel() {
        final NetworkElementInteractionManagerImpl manager =
                new NetworkElementInteractionManagerImpl(MAX_SIMULTANEOUS_INTERACTIONS, stages, connectionManager);

        manager.scheduleSynchronization(new NeSynchronizationEvent(10, 1000, 1, 100, false));

        assertThat(manager.getOngoingJobCount(), is(1));

        manager.cancelSynchronizations(new NeSynchronizationEvent(11, 1100, 1, 100, false));

        assertThat(manager.getOngoingJobCount(), is(1));
    }
}
