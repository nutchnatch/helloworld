package com.ossnms.dcn_manager.core.entities;

import static org.hamcrest.CoreMatchers.both;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.ossnms.dcn_manager.core.entities.BusinessObjectData;

/**
 * <p>Abstract class that defines {@link BusinessObjectData}'s hierarchy base test suit. 
 * The class serves as the base class for all concrete domain object test suites, 
 * therefore ensuring that inherited behavior is not accidentally broken, in particular,
 * their canonical methods' behavior.</p>
 * 
 * <p> Derived classes must override the setup method to ensure that the test suite fields
 * are initiated with instances of the concrete types.</p>
 * 
 * <p> Implementation note: The Ignore annotation is not required because, obviously, JUnit 
 * runner doesn't try to instantiate abstract classes and therefore . We are using it, though, 
 * for increased readability.</p>
 */
@Ignore
public abstract class DomainObjectDataTestBase<T extends BusinessObjectData> {

	/** One instance of the concrete domain object */
	protected T domainObjectOne;
	/** A copy of {@link #domainObjectOne} (i.e. all fields are equivalent) */ 
	protected T domainObjectOneCopy;
	/** A valid mutation of {@link #domainObjectOne} (i.e. same id and different version) */
	protected T domainObjectOneMutated;
	/** Another instance of the concrete domain object (i.e. different id) */
	protected T domainObjectTwo;
	
	/** The identifier to be used in {@link #domainObjectOne} */
	protected static final int ONE_ID = 1;
	/** The version to be used in {@link #domainObjectOne} */
	protected static final int ONE_VERSION = 1;
	/** The identifier to be used in {@link #domainObjectTwo} */
	protected static final int TWO_ID = 2;
	/** The version to be used in {@link #domainObjectTwo} */
	protected static final int TWO_VERSION = 1;
	
	@Before
	public abstract void setUp() throws Exception;
	
	@Test
	public void equals_withNullArgument_returnsFalse() {
		assertThat(domainObjectOne.equals(null), is(false));
	}

	@Test
	public void equals_withSameInstance_returnsTrue() {
		assertThat(domainObjectOne.equals(domainObjectOne), is(true));
	}

	@Test
	public void equals_withSameVersionAndId_returnsTrue() {
		assertThat(domainObjectOne.equals(domainObjectOneCopy), is(true));
	}
	
	@Test
	public void equals_withDifferentVersion_returnsFalse() {
		assertThat(domainObjectOne.equals(domainObjectOneMutated), is(false));
	}

	@Test
	public void equals_withDifferentId_returnsFalse() {
		assertThat(domainObjectOne.equals(domainObjectTwo), is(false));
	}
	
	@Test
	public void equals_withDifferentConcreteTypes_returnsFalse() {
		BusinessObjectData other = new BusinessObjectData(ONE_ID, ONE_VERSION) { };
		assertThat(domainObjectOne.equals(other), is(false));
	}
	
	@Test 
	public void hashCode_inEquivalentInstances_returnsSameValue() {
		assertThat(domainObjectOne.hashCode(), is(equalTo(domainObjectOneCopy.hashCode())));
	}
	
	@Test
	public void toString_inAValidInstance_producesStringWithCorrectIdAndVersion() {
		// The following string literals must match the ones used in BusinessObjectData.toString()
		// Public constant fields were not used to prevent polluting the type's public interface 
        assertThat(domainObjectOne.toString(), both(containsString("id")).and(containsString("version_number")));
	}
}
