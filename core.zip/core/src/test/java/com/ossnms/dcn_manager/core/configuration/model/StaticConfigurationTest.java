package com.ossnms.dcn_manager.core.configuration.model;

import com.ossnms.dcn_manager.core.configuration.loaders.XmlConfigurationLoader;
import org.junit.Test;
import org.reflections.util.ClasspathHelper;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.empty;
import static org.junit.Assert.assertThat;

public class StaticConfigurationTest {

    @Test
    public void testLoading() {
        final StaticConfiguration configuration = new XmlConfigurationLoader(ClasspathHelper.forClassLoader()).load();

        final Types<NeType> neTypes = configuration.getNeTypes();
        assertThat(neTypes.values(), not(empty()));

        final Types<ChannelType> channelTypes = configuration.getChannelTypes();
        assertThat(channelTypes.values(), not(empty()));

        final Types<MediatorType> mediatorTypes = configuration.getMediatorTypes();
        assertThat(mediatorTypes.values(), not(empty()));

        final DefaultPropertyValues defaultPropertyValues = configuration.getDefaultPropertyValues();
        assertThat(defaultPropertyValues.values(), not(empty()));
    }

}
