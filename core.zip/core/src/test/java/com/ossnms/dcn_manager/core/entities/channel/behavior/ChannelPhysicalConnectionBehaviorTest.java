package com.ossnms.dcn_manager.core.entities.channel.behavior;

import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelDeactivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelShuttingDownEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelStartingUpEvent;
import com.ossnms.dcn_manager.core.events.channel.ChannelEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelShuttingDownEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelStartingUpEvent;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.PhysicalNeDisconnectedEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;
import java.util.Collections;

import static com.google.common.collect.Iterables.getOnlyElement;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class ChannelPhysicalConnectionBehaviorTest {

    private static final int MEDIATOR_ID = 87;
    private static final int INSTANCE_ID = 98;
    private static final int CHANNEL_ID = 67;
    private static final int NE_ID = 12;
    private static final int NE_INSTANCE_ID = 1200;

    private ChannelInteractionManager activationManager;
    private ChannelNotifications notifications;
    private MessageSource<NeEvent> neEventSource;

    private final Collection<PhysicalNeDisconnectedEvent> childNesForDeactivation =
            Collections.singleton(new PhysicalNeDisconnectedEvent(NE_INSTANCE_ID, NE_ID, false));

    private final Iterable<PhysicalNeActivationFailedEvent> eventsForChildNes =
            Collections.singleton(new PhysicalNeActivationFailedEvent(NE_INSTANCE_ID, NE_ID, false));

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() {
        notifications = mock(ChannelNotifications.class);
        activationManager = mock(ChannelInteractionManager.class);
        neEventSource = mock(MessageSource.class);
    }

    private ChannelPhysicalConnectionData newData(ActualActivationState state) {
        return new ChannelPhysicalConnectionBuilder()
            .setActivation(state)
            .setAdditionalInfo("")
            .build(INSTANCE_ID, MEDIATOR_ID, CHANNEL_ID, 0);
    }

    @Test
    public void testInactive() {
        final ChannelPhysicalConnectionData state = newData(ActualActivationState.INACTIVE);
        final ChannelPhysicalConnectionBehavior behavior = new ChannelPhysicalConnectionBehavior(state, notifications);

        verifyStartingUp(behavior);
        assertThat(behavior.setCreating(), is(absent()));
        assertThat(behavior.setActivating(), is(absent()));
        assertThat(behavior.setActive(activationManager), is(absent()));
        assertThat(behavior.shutdown(activationManager, null), is(absent()));
        assertThat(behavior.setDeactivating(), is(absent()));
        assertThat(behavior.setInactive(activationManager, neEventSource, childNesForDeactivation), is(absent()));
        verifyFailure(behavior);
    }

    @Test
    public void testStartingUp() {
        final ChannelPhysicalConnectionData state = newData(ActualActivationState.STARTINGUP);
        final ChannelPhysicalConnectionBehavior behavior = new ChannelPhysicalConnectionBehavior(state, notifications);

        assertThat(behavior.startUp(activationManager, null), is(absent()));
        assertThat(behavior.setActivating(), is(absent()));
        assertThat(behavior.setActive(activationManager), is(absent()));

        verifyCreating(behavior);

        // Special shutdown case, in which we switch back directly to Inactive
        final Deactivate deactivationEvent =
                new Deactivate(CHANNEL_ID, MEDIATOR_ID, Collections.singleton(1));
        final ChannelPhysicalConnectionMutationDescriptor mutation = behavior.shutdown(activationManager, deactivationEvent).get();
        final ChannelDeactivatedEvent event = new ChannelDeactivatedEvent(CHANNEL_ID,
                new PhysicalChannelDeactivatedEvent(INSTANCE_ID, CHANNEL_ID, false));
        verifyMutation(mutation, ActualActivationState.INACTIVE, event);
        verify(notifications).notifyChanges(event);
        verify(activationManager).cancelActivations(deactivationEvent);

        assertThat(behavior.setDeactivating(), is(absent()));
        assertThat(behavior.setInactive(activationManager, neEventSource, childNesForDeactivation), is(absent()));
        verifyFailure(behavior);
    }

    @Test
    public void testCreating() {
        final ChannelPhysicalConnectionData state = newData(ActualActivationState.CREATING);
        final ChannelPhysicalConnectionBehavior behavior = new ChannelPhysicalConnectionBehavior(state, notifications);

        assertThat(behavior.startUp(activationManager, null), is(absent()));
        assertThat(behavior.setCreating(), is(absent()));
        assertThat(behavior.setActivating(), is(absent()));
        assertThat(behavior.setActive(activationManager), is(absent()));

        final ChannelPhysicalConnectionMutationDescriptor mutation = behavior.setCreated(activationManager).get();
        final ChannelActivatedEvent event = new ChannelActivatedEvent(CHANNEL_ID,
                new PhysicalChannelActivatedEvent(INSTANCE_ID, CHANNEL_ID, false));
        verifyMutation(mutation, ActualActivationState.ACTIVE, event);
        verify(notifications).notifyChanges(event);
        verify(activationManager).onChannelInteractionEnded(event);

        verifyShuttingDown(behavior);
        verify(activationManager).cancelActivations(isA(RequiredChannelStateEvent.class));
        assertThat(behavior.setDeactivating(), is(absent()));
        assertThat(behavior.setInactive(activationManager, neEventSource, childNesForDeactivation), is(absent()));
        verifyFailure(behavior);
    }

    @Test
    public void testActivating() {
        final ChannelPhysicalConnectionData state = newData(ActualActivationState.ACTIVATING);
        final ChannelPhysicalConnectionBehavior behavior = new ChannelPhysicalConnectionBehavior(state, notifications);

        assertThat(behavior.startUp(activationManager, null), is(absent()));
        assertThat(behavior.setCreating(), is(absent()));
        assertThat(behavior.setActivating(), is(absent()));
        verifyActive(behavior);
        verifyShuttingDown(behavior);
        verify(activationManager).cancelActivations(isA(RequiredChannelStateEvent.class));
        assertThat(behavior.setDeactivating(), is(absent()));
        assertThat(behavior.setInactive(activationManager, neEventSource, childNesForDeactivation), is(absent()));
        verifyFailure(behavior);
    }

    @Test
    public void testActive() {
        final ChannelPhysicalConnectionData state = newData(ActualActivationState.ACTIVE);
        final ChannelPhysicalConnectionBehavior behavior = new ChannelPhysicalConnectionBehavior(state, notifications);

        assertThat(behavior.startUp(activationManager,null), is(absent()));
        assertThat(behavior.setCreating(), is(absent()));
        assertThat(behavior.setActivating(), is(absent()));
        assertThat(behavior.setActive(activationManager), is(absent()));
        verifyShuttingDown(behavior);
        verify(activationManager).cancelActivations(isA(RequiredChannelStateEvent.class));
        assertThat(behavior.setDeactivating(), is(absent()));
        assertThat(behavior.setInactive(activationManager, neEventSource, childNesForDeactivation), is(absent()));
        verifyFailure(behavior);
    }

    @Test
    public void testShuttingDown() {
        final ChannelPhysicalConnectionData state = newData(ActualActivationState.SHUTTINGDOWN);
        final ChannelPhysicalConnectionBehavior behavior = new ChannelPhysicalConnectionBehavior(state, notifications);

        verifyStartingUp(behavior);
        verify(activationManager).cancelDeactivations(isA(RequiredChannelStateEvent.class));
        assertThat(behavior.setCreating(), is(absent()));
        assertThat(behavior.setActivating(), is(absent()));
        assertThat(behavior.setActive(activationManager), is(absent()));
        assertThat(behavior.shutdown(activationManager, null), is(absent()));
        verifyDeactivating(behavior);
        assertThat(behavior.setInactive(activationManager, neEventSource, childNesForDeactivation), is(absent()));
        verifyFailure(behavior);
    }

    @Test
    public void testDeactivating() {
        final ChannelPhysicalConnectionData state = newData(ActualActivationState.DEACTIVATING);
        final ChannelPhysicalConnectionBehavior behavior = new ChannelPhysicalConnectionBehavior(state, notifications);

        assertThat(behavior.startUp(activationManager, null), is(absent()));
        assertThat(behavior.setCreating(), is(absent()));
        assertThat(behavior.setActivating(), is(absent()));
        assertThat(behavior.setActive(activationManager), is(absent()));
        assertThat(behavior.shutdown(activationManager, null), is(absent()));
        assertThat(behavior.setDeactivating(), is(absent()));
        verifyInactive(behavior);
        verifyFailure(behavior);
    }

    @Test
    public void testFailed() {
        final ChannelPhysicalConnectionData state = newData(ActualActivationState.FAILED);
        final ChannelPhysicalConnectionBehavior behavior = new ChannelPhysicalConnectionBehavior(state, notifications);

        verifyStartingUp(behavior);
        assertThat(behavior.setCreating(), is(absent()));
        verifyActivating(behavior);
        assertThat(behavior.setActive(activationManager), is(absent()));
        verifyShuttingDown(behavior);
        assertThat(behavior.setDeactivating(), is(absent()));
        assertThat(behavior.setInactive(activationManager, neEventSource, childNesForDeactivation), is(absent()));
        verifyFailure(behavior);
    }

    private void verifyStartingUp(ChannelPhysicalConnectionBehavior behavior) {
        final Activate activationEvent =
                new Activate(CHANNEL_ID, MEDIATOR_ID, Collections.singleton(1));
        final ChannelPhysicalConnectionMutationDescriptor mutation = behavior.startUp(activationManager, activationEvent).get();
        final ChannelStartingUpEvent event = new ChannelStartingUpEvent(CHANNEL_ID,
                new PhysicalChannelStartingUpEvent(INSTANCE_ID, CHANNEL_ID, false));
        verifyMutation(mutation, ActualActivationState.STARTINGUP, event);
        verify(notifications).notifyChanges(event);
        verify(activationManager).cancelDeactivations(activationEvent);
        verify(activationManager).scheduleActivation(activationEvent);
    }

    private void verifyCreating(ChannelPhysicalConnectionBehavior behavior) {
        final ChannelPhysicalConnectionMutationDescriptor mutation = behavior.setCreating().get();
        verifyMutation(mutation, ActualActivationState.CREATING);
        verify(notifications).notifyChanges(isA(ChannelActivatingEvent.class));
    }

    private void verifyActivating(ChannelPhysicalConnectionBehavior behavior) {
        final ChannelPhysicalConnectionMutationDescriptor mutation =
            behavior.setActivating().get();
        final ChannelActivatingEvent event = new ChannelActivatingEvent(CHANNEL_ID,
                new PhysicalChannelActivatingEvent(INSTANCE_ID, CHANNEL_ID, false));
        verifyMutation(mutation, ActualActivationState.ACTIVATING, event);
        verify(notifications).notifyChanges(event);
    }

    private void verifyActive(ChannelPhysicalConnectionBehavior behavior) {
        final ChannelPhysicalConnectionMutationDescriptor mutation =
            behavior.setActive(activationManager).get();
        final ChannelActivatedEvent event = new ChannelActivatedEvent(CHANNEL_ID,
                new PhysicalChannelActivatedEvent(INSTANCE_ID, CHANNEL_ID, false));
        verifyMutation(mutation, ActualActivationState.ACTIVE, event);
        verify(notifications).notifyChanges(event);
        verify(activationManager).onChannelInteractionEnded(event);
    }

    private void verifyShuttingDown(ChannelPhysicalConnectionBehavior behavior) {
        final Deactivate deactivationEvent =
                new Deactivate(CHANNEL_ID, MEDIATOR_ID, Collections.singleton(1));
        final ChannelPhysicalConnectionMutationDescriptor mutation = behavior.shutdown(activationManager, deactivationEvent).get();
        final ChannelShuttingDownEvent event = new ChannelShuttingDownEvent(CHANNEL_ID,
                new PhysicalChannelShuttingDownEvent(INSTANCE_ID, CHANNEL_ID, false));
        verifyMutation(mutation, ActualActivationState.SHUTTINGDOWN, event);
        verify(notifications).notifyChanges(event);
        verify(activationManager).scheduleDeactivation(deactivationEvent);
    }

    private void verifyDeactivating(ChannelPhysicalConnectionBehavior behavior) {
        final ChannelPhysicalConnectionMutationDescriptor mutation =
            behavior.setDeactivating().get();
        final ChannelDeactivatingEvent event = new ChannelDeactivatingEvent(CHANNEL_ID,
                new PhysicalChannelDeactivatingEvent(INSTANCE_ID, CHANNEL_ID, false));
        verifyMutation(mutation, ActualActivationState.DEACTIVATING, event);
        verify(notifications).notifyChanges(event);
    }

    private void verifyInactive(ChannelPhysicalConnectionBehavior behavior) {
        final ChannelPhysicalConnectionMutationDescriptor mutation =
                behavior.setInactive(activationManager, neEventSource, childNesForDeactivation).get();
        final ChannelDeactivatedEvent event = new ChannelDeactivatedEvent(CHANNEL_ID,
                new PhysicalChannelDeactivatedEvent(INSTANCE_ID, CHANNEL_ID, false));
        verifyMutation(mutation, ActualActivationState.INACTIVE, event);
        verify(notifications).notifyChanges(event);
        verify(activationManager).onChannelInteractionEnded(event);
        verify(neEventSource).push(isA(PhysicalNeDisconnectedEvent.class));
    }

    private void verifyMutation(ChannelPhysicalConnectionMutationDescriptor mutation, ActualActivationState desiredState,
            ChannelEvent event) {
        mutation.apply();
        mutation.applied();
        assertThat(mutation.getActualActivationState().orElse(mutation.getResult().getActualActivationState()), is(desiredState));
        assertThat(mutation.getAdditionalInfo().orElse(mutation.getResult().getAdditionalInfo()), is(event.getDetailedDescription()));
    }

    private void verifyMutation(ChannelPhysicalConnectionMutationDescriptor mutation, ActualActivationState desiredState) {
        assertThat(mutation.getActualActivationState().get(), is(desiredState));
        mutation.apply();
        mutation.applied();
    }

    private void verifyFailure(ChannelPhysicalConnectionBehavior behavior) {
        final ChannelPhysicalConnectionMutationDescriptor mutation =
                behavior.setFailed(activationManager, neEventSource, eventsForChildNes, "descr").get();
        assertThat(mutation.getAdditionalInfo().get(), is("descr"));
        final ChannelActivationFailedEvent event = new ChannelActivationFailedEvent(CHANNEL_ID,
                new PhysicalChannelActivationFailedEvent(INSTANCE_ID, CHANNEL_ID, false, "descr"),
                "descr");
        verifyMutation(mutation, ActualActivationState.FAILED, event);
        verify(notifications).notifyChanges(event);
        verify(activationManager).onChannelInteractionEnded(event);
        verify(neEventSource).push(getOnlyElement(eventsForChildNes));
    }
}
