package com.ossnms.dcn_manager.core.properties.ne;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySetters;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySource;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import org.junit.Before;
import org.junit.Test;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

public class NePropertyUtilsTest {

    private NeType type;
    private NeDirectRouteProperties directRouteProperties;
    private NeProperties neProperties;

    @Before
    public void setUp() {
        type = MockFactory.mockNeType();
        directRouteProperties = mock(NeDirectRouteProperties.class);
        neProperties = mock(NeProperties.class);
    }

    @Test
    public void testSet() throws InvalidMutationException {
        final NeCreateDescriptor create = new NeCreateDescriptor(1, type);

        when(type.getSupportedPropertyDefaultValues()).thenReturn(ImmutableMap.of("A", "vA", "B", "vB"));
        when(directRouteProperties.handles(type, "B")).thenReturn(true);

        NePropertyUtils.applyDefaultProperties(create, neProperties, directRouteProperties);

        verify(directRouteProperties).set(eq(type), any(NePropertySource.class), any(NePropertySetters.class), eq("B"), eq("vB"));
        verify(directRouteProperties, never()).set(eq(type), any(NePropertySource.class), any(NePropertySetters.class), eq("A"), eq("vA"));

        verify(neProperties).setProperty(eq(type), any(NePropertySetters.class), eq("A"), eq("vA"));
        verify(neProperties, never()).setProperty(eq(type), any(NePropertySetters.class), eq("B"), eq("vB"));
    }

    @Test
    public void testSet_invalidMutation_ignoresException() throws InvalidMutationException {
        final NeCreateDescriptor create = new NeCreateDescriptor(1, type);

        when(type.getSupportedPropertyDefaultValues()).thenReturn(ImmutableMap.of("A", "vA"));
        doThrow(new InvalidMutationException()).when(neProperties).setProperty(eq(type), any(NePropertySetters.class), anyString(), anyString());

        NePropertyUtils.applyDefaultProperties(create, neProperties, directRouteProperties);
    }

    @Test
    public void testSet_noDefaults_doesNothing() throws InvalidMutationException {
        final NeCreateDescriptor create = new NeCreateDescriptor(1, type);

        when(type.getSupportedPropertyDefaultValues()).thenReturn(ImmutableMap.<String, String>of());

        NePropertyUtils.applyDefaultProperties(create, neProperties, directRouteProperties);

        verifyZeroInteractions(neProperties, directRouteProperties);
    }
}
