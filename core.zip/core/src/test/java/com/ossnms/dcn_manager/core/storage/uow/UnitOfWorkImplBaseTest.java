package com.ossnms.dcn_manager.core.storage.uow;

import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.test.UnitOfWorkImplBaseStub;
import com.ossnms.dcn_manager.exceptions.RepositoryException;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Optional;
import java.util.function.Consumer;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

public class UnitOfWorkImplBaseTest {

    @Test
    public void testSimpleUnitCall() throws Exception {

        final ArrayList<Integer> calls = new ArrayList<>(2);

        new UnitOfWorkImplBaseStub<>(null)
                .addUnit(ctx -> calls.add(1))
                .addUnit(ctx -> calls.add(2))
                .apply();

        assertThat(calls, contains(1, 2));
    }

    @Test
    public void testSimpleUnitCallWithResults() throws Exception {

        final ArrayList<Integer> calls = new ArrayList<>(2);
        final ArrayList<Integer> results = new ArrayList<>(2);

        new UnitOfWorkImplBaseStub<>(null)
                .addUnit(ctx -> { calls.add(1); return 1; }, (Consumer<Integer>) results::add)
                .addUnit(ctx -> { calls.add(2); return 2; }, (Consumer<Integer>) results::add)
                .apply();

        assertThat(calls, contains(1, 2));
        assertThat(results, contains(1, 2));
    }

    @Test
    public void testSimpleUnitCallWithAccumulator() throws Exception {

        final ArrayList<Integer> calls = new ArrayList<>(2);
        final ArrayList<Integer> results = new ArrayList<>(2);
        int finalResult;

        finalResult =
                new UnitOfWorkImplBaseStub<>(0)
                        .addUnit(ctx -> { calls.add(1); return 1; }, (r, a) -> { results.add(r); return a + r; })
                        .addUnit(ctx -> { calls.add(2); return 2; }, (r, a) -> { results.add(r); return a + r; })
                        .apply();

        assertThat(calls, contains(1, 2));
        assertThat(results, contains(1, 2));
        assertThat(finalResult, is(3));
    }

    @Test(expected = RepositoryException.class)
    public void testSimpleUnitCall_exception_propagates() throws Exception {

        new UnitOfWorkImplBaseStub<>(null)
                .addUnit(ctx -> {
                    throw new RepositoryException();
                })
                .apply();

    }

    @Test
    public void testMutationUnitCall() throws Exception {

        final ArrayList<Integer> results = new ArrayList<>(2);

        final DomainInfoMutationDescriptor mutation =
                new DomainInfoMutationDescriptor(new DomainInfoData(1, 0, "name"))
                        .setAutomaticNeActivationPermitted(true)
                        .whenApplied(m -> results.add(1));

        new UnitOfWorkImplBaseStub<>(null)
                .addUnit(this::simulateMutation, mutation,
                        r -> { assertThat(r, hasValue(mutation.getResult())); results.add(2); })
                .apply();

        assertThat(results, contains(1, 2));
    }

    @Test
    public void testMutationUnitCall_withAccumulator() throws Exception {

        final ArrayList<Integer> results = new ArrayList<>(2);

        final DomainInfoMutationDescriptor mutation =
                new DomainInfoMutationDescriptor(new DomainInfoData(1, 0, "name"))
                        .setAutomaticNeActivationPermitted(true)
                        .whenApplied(m -> results.add(1));

        int finalResult =
                new UnitOfWorkImplBaseStub<>(1)
                        .addUnit(this::simulateMutation, mutation, (r, a) -> { results.add(2); return a + 1; })
                        .apply();

        assertThat(results, contains(1, 2));
        assertThat(finalResult, is(2));
    }

    private Optional<DomainInfoData> simulateMutation(UowContext ctx, DomainInfoMutationDescriptor m) {
        m.apply();
        return Optional.of(m.getResult());
    }

}