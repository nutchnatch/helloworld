package com.ossnms.dcn_manager.core.entities.channel.behavior;

import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static com.ossnms.dcn_manager.core.utils.matchers.Matchers.mutationOf;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;

public class ChannelInfoBehaviorTest {

	private ChannelInfoData deactivationRequired;
	private ChannelInfoData activationRequired;

	private ChannelNotifications eventDispatcher;

	private ArgumentCaptor<Activate> activateEventCaptor;
	private ArgumentCaptor<Deactivate> deactivateEventCaptor;

	private ChannelInfoData applyMutation(Optional<ChannelInfoMutationDescriptor> mutation) {
		final ChannelInfoMutationDescriptor actualMutation = mutation.get();
		actualMutation.apply();
		actualMutation.applied();
		return actualMutation.getResult();
	}

	private Optional<ChannelInfoMutationDescriptor> activate(ChannelInfoData channelInfo) {
		return new ChannelInfoBehavior(channelInfo).activationRequired(eventDispatcher, Collections.singleton(1000));
	}

	private Optional<ChannelInfoMutationDescriptor> deactivate(ChannelInfoData channelInfo) {
		return new ChannelInfoBehavior(channelInfo).deactivationRequired(eventDispatcher, Collections.singleton(1000));
	}

	@Before
	public void setUp() throws Exception {
		final int ID = 1, VERSION = 1, MEDIATOR = 10;
		deactivationRequired = new ChannelInfoBuilder()
				.setType("A channel type")
				.setCoreId("A core id")
				.setActivationRequired(ChannelInfoData.ACTIVATION_NOT_REQUIRED)
				.build(ID, VERSION, MEDIATOR);
		activationRequired = new ChannelInfoBuilder()
		        .setType("A channel type")
		        .setCoreId("A core id")
		        .setActivationRequired(ChannelInfoData.ACTIVATION_REQUIRED)
		        .build(ID, VERSION, MEDIATOR);

		eventDispatcher = mock(ChannelNotifications.class);

		activateEventCaptor = ArgumentCaptor.forClass(Activate.class);
		deactivateEventCaptor = ArgumentCaptor.forClass(Deactivate.class);
	}

	@Test(expected=NullPointerException.class)
	public void instantiation_withNullArgument_throwsException() {
		new ChannelInfoBehavior(null);
	}

	@Test
	public void instantiation_withNonNullArgument_executesCorrectly() {
		new ChannelInfoBehavior(deactivationRequired);
	}

	@Test
	public void activationRequired_onAChannelInActivationRequiredState_producesNoEffect() {
		final Optional<ChannelInfoMutationDescriptor> result = activate(activationRequired);

		assertThat(result, is(absent()));
		verifyZeroInteractions(eventDispatcher);
	}

	@Test
	public void activationRequired_onAChannelInDeactivationRequiredState_producesCorrectStateMutation() {
		final Optional<ChannelInfoMutationDescriptor> mutation = activate(deactivationRequired);

		assertThat(mutation, is(present()));
		assertThat(mutation.get().getActive(), is(present()));
		assertThat(mutation.get().getActive().get(), is(true));
		verifyZeroInteractions(eventDispatcher);
	}

	@Test
	public void activationRequired_onAChannelInDeactivationRequiredState_triggersCorrectContinuation() {
		final ChannelInfoData mutationResult = applyMutation(activate(deactivationRequired));

		assertThat(mutationResult, is(mutationOf(deactivationRequired)));

		verify(eventDispatcher).notifyChanges(activateEventCaptor.capture());
		assertThat(activateEventCaptor.getValue().getChannelId(), is(equalTo(mutationResult.getId())));
	}

	@Test
	public void deactivationRequired_onAChannelInDeactivationRequiredState_producesNoEffect() {
		final Optional<ChannelInfoMutationDescriptor> result = deactivate(deactivationRequired);

		assertThat(result, is(absent()));
		verifyZeroInteractions(eventDispatcher);
	}

	@Test
	public void deactivationRequired_onAChannelInAnActivationRequiredState_producesCorrectStateMutation() {
		final Optional<ChannelInfoMutationDescriptor> mutation = deactivate(activationRequired);

		assertThat(mutation, is(present()));
		assertThat(mutation.get().getActive(), is(present()));
		assertThat(mutation.get().getActive().get(), is(false));
		verifyZeroInteractions(eventDispatcher);
	}

	@Test
	public void deactivationRequired_onAChannelInAnActivationRequiredState_triggersCorrectContinuation() {
		final ChannelInfoData mutationResult = applyMutation(deactivate(activationRequired));

		assertThat(mutationResult, is(mutationOf(activationRequired)));

		verify(eventDispatcher).notifyChanges(deactivateEventCaptor.capture());
		assertThat(deactivateEventCaptor.getValue().getChannelId(), is(equalTo(mutationResult.getId())));

	}
}
