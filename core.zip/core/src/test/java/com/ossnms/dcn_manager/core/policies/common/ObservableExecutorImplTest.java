package com.ossnms.dcn_manager.core.policies.common;

import com.ossnms.dcn_manager.core.policies.impl.CapacityNotificationObserver;
import com.ossnms.dcn_manager.core.test.RunRunnableAnswer;
import org.junit.Before;
import org.junit.Test;

import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;

import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

public class ObservableExecutorImplTest {

    private Executor executor;

    @Before
    public void setUp() {
        executor = mock(Executor.class);
    }

    @Test
    public void execute_withListener_executesWorkAndNotifies() {

        final Runnable workItem = mock(Runnable.class);
        final CapacityNotificationObserver listener = mock(CapacityNotificationObserver.class);

        final ObservableExecutorImpl executorWithListener =
                new ObservableExecutorImpl(executor);
        executorWithListener.addObserver((o, v) -> listener.capacityIsAvailable());

        doAnswer(new RunRunnableAnswer()).when(executor).execute(isA(Runnable.class));

        executorWithListener.execute(workItem);

        verify(workItem).run();
        verify(listener).capacityIsAvailable();
    }

    @Test
    public void execute_withListener_executionRejected_propagates_doesNotExecutesWorkAndDoesNotNotify() {

        final Runnable workItem = mock(Runnable.class);
        final CapacityNotificationObserver listener = mock(CapacityNotificationObserver.class);

        final ObservableExecutorImpl executorWithListener =
                new ObservableExecutorImpl(executor);
        executorWithListener.addObserver((o, v) -> listener.capacityIsAvailable());

        doThrow(new RejectedExecutionException()).when(executor).execute(isA(Runnable.class));

        try {
            executorWithListener.execute(workItem);
            fail("Did not propagate exception!");
        } catch (RejectedExecutionException e) {
            // good
        }

        verify(workItem, never()).run();
        verify(listener, never()).capacityIsAvailable();
    }

}