package com.ossnms.dcn_manager.core.properties.ne;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.jaxb.netype.Attribute;
import com.ossnms.dcn_manager.core.jaxb.netype.RouteMapping;
import com.ossnms.dcn_manager.core.test.MockFactory;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;

import static com.google.common.collect.Iterables.get;
import static com.google.common.collect.Iterables.getOnlyElement;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.isEmptyString;
import static org.hamcrest.Matchers.isIn;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class NeGatewayRoutePropertiesTest extends PropertiesTestBase {

    private static final String DIRECT_ROUTE_PROP_VALUE = "fromDirectRoute";
    private static final String DIRECT_ROUTE_PROP_NAME = "directRouteProp";
    private static final int CHANNELID = 2;
    private NeType neType;

    @Before
    public void setUp() throws Exception {
        neType = MockFactory.mockNeType();
    }

    private void configureFullGatewayRoutePropertySet() {
        when(neType.getGatewayRouteAttributes())
            .thenReturn(ImmutableMap.<String, Attribute>builder()
                    .put("routeCost", attribute("routeCost", RouteMapping.COST))
                    .put("routePrio", attribute("routePrio", RouteMapping.PRIORITY))
                    .put("routeUse", attribute("routeUse", RouteMapping.USAGE))
                    .put("routeDomain", attribute("routeDomain", RouteMapping.DOMAIN_NAME))
                    .put("routeGneName", attribute("routeGneName", RouteMapping.GNE_NAME))
                    .put("routeStuff", attribute("routeStuff"))
                    .build()
            );
    }

    @Test
    public void testGetSingleProperty() {

        configureFullGatewayRoutePropertySet();

        final Iterable<NeGatewayRouteData> routes = Arrays.asList(
                new NeGatewayRouteBuilder()
                .setPriority(1)
                .setCost(123)
                .setUsed(true)
                .setProperty("routeStuff", "blah")
                .setKey("unique1")
                .setDomain(Optional.of("domain1"))
                .build(NEID, VERSION),
                new NeGatewayRouteBuilder()
                .setPriority(2)
                .setCost(321)
                .setUsed(false)
                .setKey("unique2")
                .setDomain(Optional.of("domain2"))
                .build(NEID, VERSION));

        final NeEntity entity = buildEntity();

        assertThat(NeGatewayRouteProperties.getSingleProperty(neType, entity, routes, "routePrio_000").get(), is("1"));
        assertThat(NeGatewayRouteProperties.getSingleProperty(neType, entity, routes, "routeCost_000").get(), is("123"));
        assertThat(NeGatewayRouteProperties.getSingleProperty(neType, entity, routes, "routeUse_000").get(), is("true"));
        assertThat(NeGatewayRouteProperties.getSingleProperty(neType, entity, routes, "routeDomain_000").get(), is("domain1"));
        assertThat(NeGatewayRouteProperties.getSingleProperty(neType, entity, routes, "routeStuff_000").get(), is("blah"));

        assertThat(NeGatewayRouteProperties.getSingleProperty(neType, entity, routes, "routeCost_001").get(), is("321"));
        assertThat(NeGatewayRouteProperties.getSingleProperty(neType, entity, routes, "routePrio_001").get(), is("2"));
        assertThat(NeGatewayRouteProperties.getSingleProperty(neType, entity, routes, "routeUse_001").get(), is("false"));
        assertThat(NeGatewayRouteProperties.getSingleProperty(neType, entity, routes, "routeDomain_001").get(), is("domain2"));

        assertThat(NeGatewayRouteProperties.getSingleProperty(neType, entity, routes, "routeCost_003"), is(absent()));
        assertThat(NeGatewayRouteProperties.getSingleProperty(neType, entity, routes, "xpto"), is(absent()));
        assertThat(NeGatewayRouteProperties.getSingleProperty(neType, entity, routes, "xpto_000"), is(absent()));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testToProperties() {

        configureFullGatewayRoutePropertySet();

        final Iterable<NeGatewayRouteData> routes = Arrays.asList(
                new NeGatewayRouteBuilder()
                .setPriority(1)
                .setCost(123)
                .setUsed(true)
                .setProperty("routeStuff", "blah")
                .setProperty("unknown", "blahblah")
                .setKey("unique1")
                .setDomain(Optional.of("domain1"))
                .build(NEID, VERSION),
                new NeGatewayRouteBuilder()
                .setPriority(2)
                .setCost(321)
                .setUsed(false)
                .setKey("unique2")
                .setGneName("gne_name")
                .build(NEID, VERSION));
        final NeEntity entity = buildEntity();
        final Map<String, String> properties = new NeGatewayRouteProperties(neType).toProperties(entity, routes);

        assertThat(properties.values(), hasSize(11));
        assertThat(properties, allOf(
                hasEntry("routeCost_000", "123"),
                hasEntry("routePrio_000", "1"),
                hasEntry("routeUse_000", "true"),
                hasEntry("routeDomain_000", "domain1"),
                hasEntry("routeGneName_000", ""),
                hasEntry("routeCost_001", "321"),
                hasEntry("routePrio_001", "2"),
                hasEntry("routeUse_001", "false"),
                hasEntry("routeGneName_001", "gne_name"),
                hasEntry("routeStuff_000", "blah"),
                hasEntry(WellKnownNePropertyNames.DEPRECATED_NUM_OF_ADD_NSAPS, "2")
            ));
    }

    private NeEntity buildEntity() {
        final NeUserPreferencesBuilder prefsBuilder = new NeUserPreferencesBuilder()
            .setName("name");
        prefsBuilder.getDirectRouteAdapter()
            .setProperty(DIRECT_ROUTE_PROP_NAME, DIRECT_ROUTE_PROP_VALUE);
        final NeEntity entity = new NeEntity(
                new NeConnectionBuilder().build(NEID, VERSION),
                new NeOperationBuilder().build(NEID, VERSION),
                new NeInfoBuilder()
                    .setProxyType(neType.getName())
                    .build(NEID, CHANNELID, VERSION),
                new NeSynchronizationBuilder().build(NEID, VERSION),
                prefsBuilder
                    .build(NEID, VERSION));
        return entity;
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testToPropertiesWithSource() {

        when(neType.getDirectRouteAttributes())
        .thenReturn(ImmutableMap.<String, Attribute>builder()
                .put(DIRECT_ROUTE_PROP_NAME, attribute(DIRECT_ROUTE_PROP_NAME))
                .build());

        when(neType.getGatewayRouteAttributes())
        .thenReturn(ImmutableMap.<String, Attribute>builder()
                .put("routeCost", attribute("routeCost", RouteMapping.COST))
                .put("routePrio", attribute("routePrio", RouteMapping.PRIORITY))
                .put("routeUse", attribute("routeUse", RouteMapping.USAGE))
                .put("routeStuff", attribute("routeStuff"))
                .put("routeSource", attribute("routeSource", "${Route.routeStuff} -> ${Property." + NeProperty.NE_TYPE.getName() + "}"))
                .put("routeSourceBadRoute", attribute("routeSourceBadRoute", "X ${route.xpto}"))
                .put("routeSourceBadProp", attribute("routeSourceBadProp", "Y ${property.xpto}"))
                .put("routeSourceFixed", attribute("routeSourceBadRoute", "FIXED"))
                .put("routeSourceDirect", attribute("routeSourceBadRoute", "${property." + DIRECT_ROUTE_PROP_NAME + "}"))
                .build());

        final NeEntity entity = buildEntity();

        final Map<String, String> properties = new NeGatewayRouteProperties(neType).toProperties(entity,
                Collections.singletonList(new NeGatewayRouteBuilder()
                        .setPriority(1)
                        .setCost(123)
                        .setUsed(true)
                        .setProperty("routeStuff", "kool")
                        .setKey("unique1")
                        .build(NEID, VERSION)));

        assertThat(properties.values(), hasSize(8));
        assertThat(properties, allOf(
                hasEntry("routeCost_000", "123"),
                hasEntry("routePrio_000", "1"),
                hasEntry("routeUse_000", "true"),
                hasEntry("routeStuff_000", "kool"),
                hasEntry("routeSource_000", "kool -> " + neType.getName()),
                hasEntry("routeSourceFixed_000", "FIXED"),
                hasEntry("routeSourceDirect_000", DIRECT_ROUTE_PROP_VALUE),
                hasEntry(WellKnownNePropertyNames.DEPRECATED_NUM_OF_ADD_NSAPS, "1")
            ));
    }

    @Test
    public void testRefreshKey() throws Exception {
        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(2, neType);
        createDescriptor.getPreferences().setName("new_name");

        final NeEntity contextEntity = NeEntity.build(1, VERSION, createDescriptor);

        final Iterable<NeGatewayRouteData> routes = Arrays.asList(
                new NeGatewayRouteBuilder().setCost(123).setKey("123/NAME").build(NEID, VERSION),
                new NeGatewayRouteBuilder().setCost(123).setKey("123/new_name").build(NEID, VERSION));

        configureFullGatewayRoutePropertySet();

        when(neType.getGatewayRouteAddressKeySource())
            .thenReturn(Optional.of("${Route.routeCost}/${Property." + WellKnownNePropertyNames.ID_NAME + "}"));

        final Iterable<NeGatewayRouteMutationDescriptor> changes =
            new NeGatewayRouteProperties(neType).refreshRouteKeys(contextEntity, routes);

        assertThat(changes, is(Matchers.<NeGatewayRouteMutationDescriptor>iterableWithSize(1)));

        final NeGatewayRouteMutationDescriptor mutation = getOnlyElement(changes);
        assertThat(mutation.getTarget(), is(get(routes, 0)));
        assertThat(mutation.getKey(), hasValue("123/new_name"));

    }

    @Test
    public void testParse() {
        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(2, neType);
        createDescriptor.getPreferences().setName("NAME");
        final NeEntity contextEntity = NeEntity.build(1, VERSION, createDescriptor);

        final Map<String, String> original = ImmutableMap.<String, String>builder()
                .put("routeCost_001", "321")
//                .put("routePrio_001", "2") -> test default priority value (can't be part of key because it's not present in the map)
                .put("routeUse_001", "true")
                .put("routeStuff_001", "blah")
                .put("somethingElse_001", "blah_blah")

                .put("routeCost_000", "123")
                .put("routePrio_000", "1")
                .put("routeUse_000", "false")
                .put("routeGneName_000", "zero_name")

                .put("wtf", "blah_blah_blah")
                .build();

        configureFullGatewayRoutePropertySet();

        when(neType.getGatewayRouteAddressKeySource())
            .thenReturn(Optional.of("${Route.routeCost}/${Route.routeUse}/${Property." + WellKnownNePropertyNames.NE_TYPE + "}"));

        final Collection<NeGatewayRouteMutationDescriptor> properties =
                new NeGatewayRouteProperties(neType).parseProperties(original, contextEntity.getInfo().getNeId(), contextEntity,
                        Collections.<NeGatewayRouteData>emptyList());

        assertThat(properties.size(), is(2));

        NeGatewayRouteData route;

        route = get(properties, 0).apply();
        assertThat(route.getCost(), is(123));
        assertThat(route.getPriority(), is(1));
        assertThat(route.isUsed(), is(false));
        assertThat(route.getAllOpaqueProperties().values(), is(empty()));
        assertThat(route.getKey(), is("123/false/type_name"));
        assertThat(route.getGneName(), is("zero_name"));

        route = get(properties, 1).apply();
        assertThat(route.getCost(), is(321));
        assertThat(route.getPriority(), is(2));
        assertThat(route.isUsed(), is(true));
        assertThat(route.getAllOpaqueProperties().values(), hasSize(1));
        assertThat(route.getAllOpaqueProperties(), hasEntry("routeStuff", "blah"));
        assertThat(route.getKey(), is("321/true/type_name"));
        assertThat(route.getGneName(), isEmptyString());
    }

    @Test
    public void testParseWithExistingDataAndKeyChange() {
        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(2, neType);
        createDescriptor.getPreferences().setName("NAME");
        final Iterable<NeGatewayRouteData> routes = Arrays.asList(
                new NeGatewayRouteBuilder().setCost(123).setUsed(false).setKey("123/NAME").build(NEID, VERSION));
        final NeEntity contextEntity = NeEntity.build(1, VERSION, createDescriptor);

        final Map<String, String> original = ImmutableMap.<String, String>builder()
                .put("routeCost_000", "123")
                .put("routePrio_000", "1")
                .put("routeUse_000", "true")
                .build();

        configureFullGatewayRoutePropertySet();

        when(neType.getGatewayRouteAddressKeySource())
            .thenReturn(Optional.of("${Route.routeCost}/${Property." + WellKnownNePropertyNames.ID_NAME + "}"));

        final NeUserPreferencesMutationDescriptor preferencesMutationDescriptor =
            new NeUserPreferencesMutationDescriptor(contextEntity.getPreferences()).setName("new_name");
        final NePropertySourceWithFallback propertyContext =
            new NePropertySourceWithFallback(preferencesMutationDescriptor, contextEntity);
        final Collection<NeGatewayRouteMutationDescriptor> properties =
            new NeGatewayRouteProperties(neType).parseProperties(original, contextEntity.getInfo().getNeId(), propertyContext, routes);

        assertThat(properties.size(), is(1));

        final NeGatewayRouteMutationDescriptor mutation = get(properties, 0);
        assertThat(mutation.getTarget(), is(get(routes, 0)));
        assertThat(mutation.getCost(), hasValue(123));
        assertThat(mutation.getPriority(), hasValue(1));
        assertThat(mutation.getUsed(), hasValue(true));
        assertThat(mutation.getKey(), hasValue("123/new_name"));
    }

    @Test
    public void testParseWithExistingData() {
        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(2, neType);
        createDescriptor.getPreferences().setName("NAME");
        createDescriptor.putGatewayRoutes(ImmutableList.of(
                new NeGatewayRouteBuilder().setCost(123).setUsed(false).setKey("123/false/type_name"),
                new NeGatewayRouteBuilder().setCost(456).setUsed(false).setKey("456/false/type_name")
            ));

        final Collection<NeGatewayRouteData> routes = ImmutableList.of(
                new NeGatewayRouteBuilder().setCost(123).setUsed(false).setKey("123/false/type_name").build(NEID, VERSION),
                new NeGatewayRouteBuilder().setCost(456).setUsed(false).setKey("456/false/type_name").build(NEID, VERSION));
        final NeEntity contextEntity = NeEntity.build(1, VERSION, createDescriptor);

        final Map<String, String> original = ImmutableMap.<String, String>builder()
                .put("routeCost_000", "123")
                .put("routePrio_000", "1")
                .put("routeUse_000", "false")

                .put("routeCost_001", "321")
                .put("routePrio_001", "2")
                .put("routeUse_001", "true")
                .put("routeStuff_001", "blah")
                .put("somethingElse_001", "blah_blah")

                .put("wtf", "blah_blah_blah")
                .build();

        configureFullGatewayRoutePropertySet();

        when(neType.getGatewayRouteAddressKeySource())
            .thenReturn(Optional.of("${Route.routeCost}/${Route.routeUse}/${Property." + WellKnownNePropertyNames.NE_TYPE + "}"));

        final Collection<NeGatewayRouteMutationDescriptor> properties =
                new NeGatewayRouteProperties(neType).parseProperties(original, contextEntity.getInfo().getNeId(), contextEntity, routes);

        assertThat(properties.size(), is(2));

        NeGatewayRouteMutationDescriptor mutation = get(properties, 0);
        assertThat(mutation.getTarget(), is(get(routes, 0)));
        assertThat(mutation.getCost(), hasValue(123));
        assertThat(mutation.getPriority(), hasValue(1));
        assertThat(mutation.getUsed(), hasValue(false));

        mutation = get(properties, 1);
        assertThat(mutation.getTarget(), not(isIn(routes)));
        assertThat(mutation.getCost(), hasValue(321));
        assertThat(mutation.getPriority(), hasValue(2));
        assertThat(mutation.getUsed(), hasValue(true));
        assertThat(mutation.getProperties().size(), is(1));
        assertThat(mutation.getProperties(), hasEntry("routeStuff", "blah"));
        assertThat(mutation.apply().getKey(), is("321/true/type_name"));
    }

    @Test
    public void testParseInvalidValues() {
        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(2, neType);
        createDescriptor.getPreferences().setName("NAME");
        final NeEntity contextEntity = NeEntity.build(1, VERSION, createDescriptor);

        final Map<String, String> original = ImmutableMap.<String, String>builder()
                .put("routeCost_008", "xxx")
                .put("routePrio_008", "yyy")
                .put("routeUse_008", "????")
                .build();

        when(neType.getGatewayRouteAddressKeySource())
            .thenReturn(Optional.of("fixedKey"));

        configureFullGatewayRoutePropertySet();

        final Collection<NeGatewayRouteMutationDescriptor> properties =
                new NeGatewayRouteProperties(neType).parseProperties(original, contextEntity.getInfo().getNeId(), contextEntity,
                        Collections.<NeGatewayRouteData>emptyList());

        assertThat(properties.size(), is(1));

        final NeGatewayRouteData route = getOnlyElement(properties).apply();

        assertThat(route.getCost(), is(0));
        assertThat(route.getPriority(), is(9)); // fall back to default
        assertThat(route.isUsed(), is(false));
        assertThat(route.getAllOpaqueProperties().values(), is(empty()));

    }

    @Test
    public void testMissingKey() {
        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(2, neType);
        createDescriptor.getPreferences().setName("NAME");
        final NeEntity contextEntity = NeEntity.build(1, VERSION, createDescriptor);

        final Map<String, String> original = ImmutableMap.<String, String>builder()
                .put("routeCost_008", "1")
                .build();

        final Collection<NeGatewayRouteMutationDescriptor> properties =
                new NeGatewayRouteProperties(neType).parseProperties(original, contextEntity.getInfo().getNeId(), contextEntity,
                        Collections.<NeGatewayRouteData>emptyList());

        assertThat(properties, is(empty()));
    }

    @Test
    public void testMissingKeyValues() {
        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(2, neType);
        createDescriptor.getPreferences().setName("NAME");
        final NeEntity contextEntity = NeEntity.build(1, VERSION, createDescriptor);

        final Map<String, String> original = ImmutableMap.<String, String>builder()
                .put("routeCost_008", "1")
                .build();

        when(neType.getGatewayRouteAddressKeySource())
            .thenReturn(Optional.of("${Route.routePrio}/${Route.routeCost}}"));

        final Collection<NeGatewayRouteMutationDescriptor> properties =
                new NeGatewayRouteProperties(neType).parseProperties(original, contextEntity.getInfo().getNeId(), contextEntity,
                        Collections.<NeGatewayRouteData>emptyList());

        assertThat(properties, is(empty()));
    }

    @Test
    public void testEmptyKeyValues() {
        final NeCreateDescriptor createDescriptor = new NeCreateDescriptor(2, neType);
        createDescriptor.getPreferences().setName("NAME");
        final NeEntity contextEntity = NeEntity.build(1, VERSION, createDescriptor);

        final Map<String, String> original = ImmutableMap.<String, String>builder()
                .put("routePrio_008", "")
                .put("routeCost_008", "1")
                .build();

        when(neType.getGatewayRouteAddressKeySource())
            .thenReturn(Optional.of("${Route.routePrio}/${Route.routeCost}}"));

        final Collection<NeGatewayRouteMutationDescriptor> properties =
                new NeGatewayRouteProperties(neType).parseProperties(original, contextEntity.getInfo().getNeId(), contextEntity,
                        Collections.<NeGatewayRouteData>emptyList());

        assertThat(properties, is(empty()));
    }

}
