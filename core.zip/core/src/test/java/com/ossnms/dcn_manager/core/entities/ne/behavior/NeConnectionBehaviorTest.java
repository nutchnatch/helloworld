package com.ossnms.dcn_manager.core.entities.ne.behavior;

import com.google.common.base.Function;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeConnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeConnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeDisconnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeDisconnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializingEvent;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.outbound.Alarms;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

public class NeConnectionBehaviorTest {

    private static final int NE_ID = 1;
    private static final int CHANNEL_ID = 78;
    private static final int MEDIATOR_ID = 42;

    private NetworkElementNotifications notifications;
    private Alarms alarms;

    @Before
    public void setUp() {
        notifications = mock(NetworkElementNotifications.class);
        alarms = mock(Alarms.class);
    }

    @Test
    public void disconnected_transitions() {
        verifyPresent(ActualActivationState.DISCONNECTED, ActualActivationState.FAILED, behavior -> behavior.setFailed("descr", alarms));
        verify(notifications).notifyChanges(isA(NeActivationFailedEvent.class));
        verify(alarms).raiseConnectionLost(anyInt(), any(Optional.class));

        verifyPresent(ActualActivationState.DISCONNECTED, ActualActivationState.CONNECTING, NeConnectionBehavior::setConnecting);
        verify(notifications).notifyChanges(isA(NeConnectingEvent.class));

        verifyAbsent(ActualActivationState.DISCONNECTED, behavior -> behavior.setConnected(alarms, CHANNEL_ID, MEDIATOR_ID));

        verifyAbsent(ActualActivationState.DISCONNECTED, NeConnectionBehavior::setInitializing);

        verifyAbsent(ActualActivationState.DISCONNECTED, NeConnectionBehavior::setInitialized);

        verifyAbsent(ActualActivationState.DISCONNECTED, NeConnectionBehavior::setDisconnecting);

        verifyAbsent(ActualActivationState.DISCONNECTED, behavior -> behavior.setDisconnected(alarms));
        verify(notifications).notifyChanges(isA(NeDisconnectedEvent.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void connecting_transitions() {
        verifyPresent(ActualActivationState.CONNECTING, ActualActivationState.FAILED, behavior -> behavior.setFailed("descr", alarms));
        verify(notifications).notifyChanges(isA(NeActivationFailedEvent.class));
        verify(alarms).raiseConnectionLost(anyInt(), any(Optional.class));

        verifyAbsent(ActualActivationState.CONNECTING, NeConnectionBehavior::setConnecting);

        verifyPresent(ActualActivationState.CONNECTING, ActualActivationState.CONNECTED, behavior -> behavior.setConnected(alarms, CHANNEL_ID, MEDIATOR_ID));
        verify(notifications).notifyChanges(isA(NeConnectedEvent.class));
        //verify(alarms).clearConnectionLost(anyInt()); --> verified below

        verifyAbsent(ActualActivationState.CONNECTING, NeConnectionBehavior::setInitializing);

        verifyAbsent(ActualActivationState.CONNECTING, NeConnectionBehavior::setInitialized);

        verifyPresent(ActualActivationState.CONNECTING, ActualActivationState.DISCONNECTED, behavior -> behavior.setDisconnected(alarms));
        verify(notifications).notifyChanges(isA(NeDisconnectedEvent.class));
        verify(alarms, times(2)).clearConnectionLost(anyInt(), anyBoolean()); // from connected and disconnected

        verifyAbsent(ActualActivationState.CONNECTING, NeConnectionBehavior::resynchronize);

        verifyPresent(ActualActivationState.CONNECTING, ActualActivationState.DISCONNECTING, NeConnectionBehavior::setDisconnecting);
        verify(notifications).notifyChanges(isA(NeDisconnectingEvent.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void connected_transitions() {
        verifyPresent(ActualActivationState.CONNECTED, ActualActivationState.FAILED, behavior -> behavior.setFailed("descr", alarms));
        verify(notifications).notifyChanges(isA(NeActivationFailedEvent.class));
        verify(alarms).raiseConnectionLost(anyInt(), any(Optional.class));

        verifyAbsent(ActualActivationState.CONNECTED, NeConnectionBehavior::setConnecting);

        verifyAbsent(ActualActivationState.CONNECTED, behavior -> behavior.setConnected(alarms, CHANNEL_ID, MEDIATOR_ID));

        verifyPresent(ActualActivationState.CONNECTED, ActualActivationState.INITIALIZING, NeConnectionBehavior::setInitializing);
        verify(notifications).notifyChanges(isA(NeInitializingEvent.class));

        verifyAbsent(ActualActivationState.CONNECTED, NeConnectionBehavior::setInitialized);

        verifyPresent(ActualActivationState.CONNECTED, ActualActivationState.DISCONNECTED, behavior -> behavior.setDisconnected(alarms));
        verify(notifications).notifyChanges(isA(NeDisconnectedEvent.class));
        verify(alarms).clearConnectionLost(anyInt(), anyBoolean());

        verifyAbsent(ActualActivationState.CONNECTED, NeConnectionBehavior::resynchronize);

        verifyPresent(ActualActivationState.CONNECTED, ActualActivationState.DISCONNECTING, NeConnectionBehavior::setDisconnecting);
        verify(notifications).notifyChanges(isA(NeDisconnectingEvent.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void initializing_transitions() {
        verifyPresent(ActualActivationState.INITIALIZING, ActualActivationState.FAILED, behavior -> behavior.setFailed("descr", alarms));
        verify(notifications).notifyChanges(isA(NeActivationFailedEvent.class));
        verify(alarms).raiseConnectionLost(anyInt(), any(Optional.class));

        verifyAbsent(ActualActivationState.INITIALIZING, NeConnectionBehavior::setConnecting);

        verifyAbsent(ActualActivationState.INITIALIZING, behavior -> behavior.setConnected(alarms, CHANNEL_ID, MEDIATOR_ID));

        verifyAbsent(ActualActivationState.INITIALIZING, NeConnectionBehavior::setInitializing);

        verifyPresent(ActualActivationState.INITIALIZING, ActualActivationState.INITIALIZED, NeConnectionBehavior::setInitialized);
        final NeSynchronizationData differences = new NeSynchronizationBuilder().build(NE_ID, 0);
        verifyPresent(ActualActivationState.INITIALIZING, ActualActivationState.INITIALIZED, behavior -> behavior.setInitialized(differences));
        final ArgumentCaptor<NeInitializedEvent> initCaptor =
                ArgumentCaptor.forClass(NeInitializedEvent.class);
        verify(notifications, times(2)).notifyChanges(initCaptor.capture());
        assertThat(initCaptor.getAllValues().get(0).getSynchronizationDataDifferences().isPresent(), is(false));
        assertThat(initCaptor.getAllValues().get(1).getSynchronizationDataDifferences().get(), is(differences));

        verifyPresent(ActualActivationState.INITIALIZING, ActualActivationState.DISCONNECTED, behavior -> behavior.setDisconnected(alarms));
        verify(notifications).notifyChanges(isA(NeDisconnectedEvent.class));
        verify(alarms).clearConnectionLost(anyInt(), anyBoolean());

        verifyAbsent(ActualActivationState.INITIALIZING, NeConnectionBehavior::resynchronize);

        verifyPresent(ActualActivationState.INITIALIZING, ActualActivationState.DISCONNECTING, NeConnectionBehavior::setDisconnecting);
        verify(notifications).notifyChanges(isA(NeDisconnectingEvent.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void initialized_transitions() {
        verifyPresent(ActualActivationState.INITIALIZED, ActualActivationState.FAILED, behavior -> behavior.setFailed("descr", alarms));

        verify(notifications).notifyChanges(isA(NeActivationFailedEvent.class));
        verify(alarms).raiseConnectionLost(anyInt(), any(Optional.class));

        verifyAbsent(ActualActivationState.INITIALIZED, NeConnectionBehavior::setConnecting);

        verifyAbsent(ActualActivationState.INITIALIZED, behavior -> behavior.setConnected(alarms, CHANNEL_ID, MEDIATOR_ID));

        verifyPresent(ActualActivationState.INITIALIZED, ActualActivationState.INITIALIZING, NeConnectionBehavior::setInitializing);

        verifyAbsent(ActualActivationState.INITIALIZED, NeConnectionBehavior::setInitialized);

        verifyPresent(ActualActivationState.INITIALIZED, ActualActivationState.DISCONNECTED, behavior -> behavior.setDisconnected(alarms));
        verify(notifications).notifyChanges(isA(NeDisconnectedEvent.class));
        verify(alarms).clearConnectionLost(anyInt(), anyBoolean());

        verifyPresent(ActualActivationState.INITIALIZED, ActualActivationState.INITIALIZING, NeConnectionBehavior::resynchronize);
        verify(notifications, times(2)).notifyChanges(isA(NeInitializingEvent.class)); // initializing & resynchronize

        verifyPresent(ActualActivationState.INITIALIZED, ActualActivationState.DISCONNECTING, NeConnectionBehavior::setDisconnecting);
        verify(notifications).notifyChanges(isA(NeDisconnectingEvent.class));
    }

    @SuppressWarnings("unchecked")
    @Test
    public void disconnecting_transitions() {
        verifyPresent(ActualActivationState.DISCONNECTING, ActualActivationState.FAILED, behavior -> behavior.setFailed("descr", alarms));
        verify(notifications).notifyChanges(isA(NeActivationFailedEvent.class));
        verify(alarms).raiseConnectionLost(anyInt(), any(Optional.class));

        verifyAbsent(ActualActivationState.DISCONNECTING, NeConnectionBehavior::setConnecting);

        verifyAbsent(ActualActivationState.DISCONNECTING, behavior -> behavior.setConnected(alarms, CHANNEL_ID, MEDIATOR_ID));

        verifyAbsent(ActualActivationState.DISCONNECTING, NeConnectionBehavior::setInitializing);

        verifyAbsent(ActualActivationState.DISCONNECTING, NeConnectionBehavior::setInitialized);

        verifyAbsent(ActualActivationState.DISCONNECTING, NeConnectionBehavior::setDisconnecting);

        verifyPresent(ActualActivationState.DISCONNECTING, ActualActivationState.DISCONNECTED, behavior -> behavior.setDisconnected(alarms));

        verify(notifications).notifyChanges(isA(NeDisconnectedEvent.class));
        verify(alarms).clearConnectionLost(anyInt(), anyBoolean());

        verifyAbsent(ActualActivationState.DISCONNECTING, NeConnectionBehavior::resynchronize);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void failed_transitions() {
        verifyPresent(ActualActivationState.FAILED, ActualActivationState.FAILED, behavior -> behavior.setFailed("descr", alarms));

        verify(notifications).notifyChanges(isA(NeActivationFailedEvent.class));
        verify(alarms).raiseConnectionLost(anyInt(), any(Optional.class));

        verifyAbsent(ActualActivationState.FAILED, behavior -> behavior.setConnected(alarms, CHANNEL_ID, MEDIATOR_ID));

        verifyPresent(ActualActivationState.FAILED, ActualActivationState.INITIALIZING, NeConnectionBehavior::setInitializing);
        verify(notifications).notifyChanges(isA(NeInitializingEvent.class));

        verifyAbsent(ActualActivationState.FAILED, NeConnectionBehavior::setInitialized);

        verifyPresent(ActualActivationState.FAILED, ActualActivationState.DISCONNECTED, behavior -> behavior.setDisconnected(alarms));
        verify(notifications).notifyChanges(isA(NeDisconnectedEvent.class)); // disconnected
        verify(alarms).clearConnectionLost(anyInt(), anyBoolean()); // disconnected


        verifyAbsent(ActualActivationState.FAILED, NeConnectionBehavior::resynchronize);

        verifyPresent(ActualActivationState.FAILED, ActualActivationState.DISCONNECTING, NeConnectionBehavior::setDisconnecting);
        verify(notifications).notifyChanges(isA(NeDisconnectingEvent.class));

        verifyPresent(ActualActivationState.FAILED, ActualActivationState.CONNECTING, NeConnectionBehavior::setConnecting);
        verify(notifications).notifyChanges(isA(NeConnectingEvent.class));
    }

    private interface Trigger extends Function<NeConnectionBehavior, Optional<NeConnectionMutationDescriptor>> { }

    private <T extends NeEvent> void verifyPresent(ActualActivationState actualState, ActualActivationState expectedState,
            Trigger triggerFunction) {
        final NeConnectionBehavior behavior = new NeConnectionBehavior(createData(actualState), notifications);
        final Optional<NeConnectionMutationDescriptor> mutation = triggerFunction.apply(behavior);
        assertThat(mutation, is(present()));
        assertThat(mutation.get().getActivationState(), is(present()));
        assertThat(mutation.get().getActivationState().get(), is(expectedState));

        assertThat(mutation.get().apply().getActivationState(), is(expectedState));

        mutation.get().applied();
    }

    private void verifyAbsent(ActualActivationState actualState, Trigger triggerFunction) {
        final NeConnectionBehavior behavior = new NeConnectionBehavior(createData(actualState), notifications);
        final Optional<NeConnectionMutationDescriptor> mutation = triggerFunction.apply(behavior);
        assertThat(mutation, not(is(present())));
    }

    private NeConnectionData createData(ActualActivationState actualState) {
        return new NeConnectionBuilder()
            .setActivationState(actualState)
            .build(NE_ID, 1);
    }

}
