package com.ossnms.dcn_manager.core.configuration.model;

import com.ossnms.bicnet.bcb.model.emObjMgmt.NeCapabilities;
import com.ossnms.bicnet.bcb.model.emObjMgmt.NeCapability;
import com.ossnms.bicnet.bcb.model.networkMgmt.TransportLayer;
import com.ossnms.bicnet.bcb.model.networkMgmt.TransportLayerSet;
import com.ossnms.dcn_manager.core.jaxb.netype.Config;
import com.ossnms.dcn_manager.core.jaxb.netype.DataTransferSettings;
import com.ossnms.dcn_manager.core.jaxb.netype.Mappings;
import com.ossnms.dcn_manager.core.jaxb.netype.Properties;
import com.ossnms.dcn_manager.core.properties.ne.NeProperty;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class NeTypeTest extends TypeTestBase {

    private Config config;

    @Before
    @SuppressWarnings("unchecked")
    public void setUp() {
        config = new Config();
    }

    @Test
    public void testTypeProperties() {

        config.setName("N");
        config.setTypeProperties(buildTypeProperties(
                "SUPPORTED_LAYERS", "layers",
                "CAPABILITIES", "caps"
        ));

        final NeType type = new NeType(config, null);
        assertThat(type.getCapabilities(), is("caps"));
        assertThat(type.getName(), is("N"));
        assertThat(type.getSupportedLayers(), is("layers"));
        assertThat(type.getTypeProperties(), hasEntry("SUPPORTED_LAYERS", "layers"));
        assertThat(type.getTypeProperties(), hasEntry("CAPABILITIES", "caps"));
    }

    @Test
    public void testPropertyNameMapping() {

        final Properties properties = new Properties();
        final Mappings mappings = new Mappings();
        mappings.setUsesGne("TEST_USES_GNE");
        mappings.setReconnectInterval("TEST_RECONNECT_INTERVAL");

        properties.setMappings(mappings);
        config.setProperties(properties);

        final NeType type = new NeType(config, null);

        assertThat(type.mapIncomingPropertyName("TEST_USES_GNE"), is(NeProperty.USES_GNE.getName()));
        assertThat(type.mapIncomingPropertyName("TEST_RECONNECT_INTERVAL"), is(NeProperty.RECONNECT_INTERVAL.getName()));

        assertThat(type.mapOutgoingPropertyName(NeProperty.USES_GNE.getName()), is("TEST_USES_GNE"));
        assertThat(type.mapOutgoingPropertyName(NeProperty.RECONNECT_INTERVAL.getName()), is("TEST_RECONNECT_INTERVAL"));
    }

    @Test
    public void testPropertyNameDataTransferSettings() {
        final Mappings mappings = new Mappings();

        final DataTransferSettings dataTransferSettings = new DataTransferSettings();
        dataTransferSettings.setIp("TEST_IP");
        dataTransferSettings.setIsSCP("TEST_SCP");
        dataTransferSettings.setPassword("TEST_PASS");
        dataTransferSettings.setPath("TEST_PATH");
        dataTransferSettings.setUserName("TEST_USER");

        final Properties properties = new Properties();
        properties.setDataTransferSettings(dataTransferSettings);
        properties.setMappings(mappings);
        config.setProperties(properties);

        final NeType type = new NeType(config, null);


        assertThat(type.mapIncomingPropertyName("TEST_IP"), is(NeProperty.DATATRANSFER_IP_ADDRESS.getName()));
        assertThat(type.mapIncomingPropertyName("TEST_SCP"), is(NeProperty.DATATRANSFER_IS_SCP.getName()));
        assertThat(type.mapIncomingPropertyName("TEST_PASS"), is(NeProperty.DATATRANSFER_PASSWORD.getName()));
        assertThat(type.mapIncomingPropertyName("TEST_PATH"), is(NeProperty.DATATRANSFER_UPLOADPATH.getName()));
        assertThat(type.mapIncomingPropertyName("TEST_USER"), is(NeProperty.DATATRANSFER_USERNAME.getName()));

        assertThat(type.mapOutgoingPropertyName(NeProperty.DATATRANSFER_IP_ADDRESS.getName()), is("TEST_IP"));
        assertThat(type.mapOutgoingPropertyName(NeProperty.DATATRANSFER_IS_SCP.getName()), is("TEST_SCP"));
        assertThat(type.mapOutgoingPropertyName(NeProperty.DATATRANSFER_PASSWORD.getName()), is("TEST_PASS"));
        assertThat(type.mapOutgoingPropertyName(NeProperty.DATATRANSFER_UPLOADPATH.getName()), is("TEST_PATH"));
        assertThat(type.mapOutgoingPropertyName(NeProperty.DATATRANSFER_USERNAME.getName()), is("TEST_USER"));
    }

    @Ignore("This test is used only for manual tests")
    @Test public void toolToChangeCapabilities() {
        String originalCapabilities = "111000100000000001000000101010000000001011";
        NeCapabilities neCapabilities = NeCapabilities.fromDbString(originalCapabilities);
        neCapabilities.add(NeCapability.GCT_CAPABLE);
        System.out.println(neCapabilities.toDbString());
    }

    @Ignore("This test is used only for manual tests")
    @Test public void toolToChangeSupportedLayers() {
        String originalSupportedLayers = "0010100010000000001000000000000000000000000000000000000000000000000000000000000000000000000000000111000000000000000000000000000000";

        TransportLayerSet layers = TransportLayerSet.fromDbString(originalSupportedLayers);
        layers.add(TransportLayer.OTS);
//        layers.remove(TransportLayer.OTS);

        assertThat(layers.toDbString(), is("1010100010000000001000000000000000000000000000000000000000000000000000000000000000000000000000000111000000000000000000000000000000000000000000000000000000000000000000000"));
    }
}
