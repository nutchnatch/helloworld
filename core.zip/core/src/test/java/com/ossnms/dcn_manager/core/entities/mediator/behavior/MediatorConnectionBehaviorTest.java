package com.ossnms.dcn_manager.core.entities.mediator.behavior;

import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionData.MediatorConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorDeactivatingEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class MediatorConnectionBehaviorTest {

    private static final String ERROR = "error";

    private MediatorNotifications notifications;

    @Before
    public void setUp() {
        notifications = mock(MediatorNotifications.class);
    }

    private MediatorConnectionData newConnectionData(ActualActivationState state) {
        return new MediatorConnectionBuilder().setActualActivationState(state).setAdditionalInfo("??").build(1, 1);
    }

    @Test
    public void testSetActivating_fromInactive() {
        final MediatorConnectionData originalData = newConnectionData(ActualActivationState.INACTIVE);
        final Optional<MediatorConnectionMutationDescriptor> mutation =
            new MediatorConnectionBehavior(originalData)
                .setActivating(notifications);

        verifyMutationToState(mutation, ActualActivationState.ACTIVATING);
        verify(notifications).notifyChanges(isA(MediatorActivatingEvent.class));
    }

    @Test
    public void testSetActivating_fromFailed() {
        final MediatorConnectionData originalData = newConnectionData(ActualActivationState.FAILED);
        final Optional<MediatorConnectionMutationDescriptor> mutation =
            new MediatorConnectionBehavior(originalData)
                .setActivating(notifications);

        verifyMutationToState(mutation, ActualActivationState.ACTIVATING);
        verify(notifications).notifyChanges(isA(MediatorActivatingEvent.class));
    }

    @Test
    public void testSetActivating_fromActivating() {
        final MediatorConnectionData originalData = newConnectionData(ActualActivationState.ACTIVATING);
        final Optional<MediatorConnectionMutationDescriptor> mutation =
            new MediatorConnectionBehavior(originalData)
                .setActivating(notifications);

        assertThat(mutation, is(absent()));
    }

    @Test
    public void testSetActive_fromActivating() {
        final MediatorConnectionData originalData = newConnectionData(ActualActivationState.ACTIVATING);
        final Optional<MediatorConnectionMutationDescriptor> mutation =
            new MediatorConnectionBehavior(originalData)
                .setActive(notifications);

        verifyActivation(originalData, mutation);
    }

    @Test
    public void testSetActive_fromActive() {
        final MediatorConnectionData originalData = newConnectionData(ActualActivationState.ACTIVE);
        final Optional<MediatorConnectionMutationDescriptor> mutation =
            new MediatorConnectionBehavior(originalData)
                .setActive(notifications);

        assertThat(mutation, is(absent()));
    }

    @Test
    public void testSetDeactivating_fromActive() {
        final MediatorConnectionData originalData = newConnectionData(ActualActivationState.ACTIVE);
        final Optional<MediatorConnectionMutationDescriptor> mutation =
            new MediatorConnectionBehavior(originalData)
                .setDeactivating(notifications);

        verifyMutationToState(mutation, ActualActivationState.DEACTIVATING);
        verify(notifications).notifyChanges(isA(MediatorDeactivatingEvent.class));
    }

    @Test
    public void testSetDeactivating_fromDeactivating() {
        final MediatorConnectionData originalData = newConnectionData(ActualActivationState.DEACTIVATING);
        final Optional<MediatorConnectionMutationDescriptor> mutation =
            new MediatorConnectionBehavior(originalData)
                .setDeactivating(notifications);

        assertThat(mutation, is(absent()));
    }

    @Test
    public void testSetDeactivating_fromActivating() {
        final MediatorConnectionData originalData = newConnectionData(ActualActivationState.ACTIVATING);
        final Optional<MediatorConnectionMutationDescriptor> mutation =
            new MediatorConnectionBehavior(originalData)
                .setDeactivating(notifications);

        verifyMutationToState(mutation, ActualActivationState.DEACTIVATING);
        verify(notifications).notifyChanges(isA(MediatorDeactivatingEvent.class));
    }


    @Test
    public void testSetInactive_fromInactive() {
        final MediatorConnectionData originalData = newConnectionData(ActualActivationState.INACTIVE);
        final Optional<MediatorConnectionMutationDescriptor> mutation =
            new MediatorConnectionBehavior(originalData)
                .setInactive(notifications);

        assertThat(mutation, is(absent()));
    }

    @Test
    public void testSetInactive_fromFailed() {
        final MediatorConnectionData originalData = newConnectionData(ActualActivationState.FAILED);
        final Optional<MediatorConnectionMutationDescriptor> mutation =
            new MediatorConnectionBehavior(originalData)
                .setInactive(notifications);

        verifyMutationToState(mutation, ActualActivationState.INACTIVE);
    }

    @Test
    public void testSetInactive_fromDeactivating() {
        final MediatorConnectionData originalData = newConnectionData(ActualActivationState.DEACTIVATING);
        final Optional<MediatorConnectionMutationDescriptor> mutation =
            new MediatorConnectionBehavior(originalData)
                .setInactive(notifications);

        verifyDeactivation(originalData, mutation);
    }

    @Test
    public void testSetFailed_fromInactive() {
        final MediatorConnectionData originalData = newConnectionData(ActualActivationState.INACTIVE);
        final Optional<MediatorConnectionMutationDescriptor> mutation =
            new MediatorConnectionBehavior(originalData)
                .setFailed(notifications, ERROR);

        verifyActivationFailed(originalData, mutation, ERROR);
    }

    @Test
    public void testSetFailed_fromActive() {
        final MediatorConnectionData originalData = newConnectionData(ActualActivationState.ACTIVE);
        final Optional<MediatorConnectionMutationDescriptor> mutation =
            new MediatorConnectionBehavior(originalData)
                .setFailed(notifications, ERROR);

        verifyActivationFailed(originalData, mutation, ERROR);
    }

    @Test
    public void testSetFailed_fromFailed() {
        final MediatorConnectionData originalData = newConnectionData(ActualActivationState.FAILED);
        final Optional<MediatorConnectionMutationDescriptor> mutation =
            new MediatorConnectionBehavior(originalData)
                .setFailed(notifications, ERROR);

        verifyActivationFailed(originalData, mutation, ERROR);
    }

    private void verifyActivation(final MediatorConnectionData originalData,
            final Optional<MediatorConnectionMutationDescriptor> mutation) {
        final MediatorConnectionData newData = verifyMutationToState(mutation, ActualActivationState.ACTIVE);

        final ArgumentCaptor<MediatorActivatedEvent> eventCaptor = ArgumentCaptor.forClass(MediatorActivatedEvent.class);
        verify(notifications).notifyChanges(eventCaptor.capture());
        final MediatorActivatedEvent event = eventCaptor.getValue();
        assertThat(event.getMediatorId(), is(originalData.getId()));
        assertThat(event.getDetailedDescription(), is(newData.getAdditionalInfo()));
    }

    private void verifyDeactivation(final MediatorConnectionData originalData,
            final Optional<MediatorConnectionMutationDescriptor> mutation) {
        final MediatorConnectionData newData = verifyMutationToState(mutation, ActualActivationState.INACTIVE);

        final ArgumentCaptor<MediatorDeactivatedEvent> eventCaptor = ArgumentCaptor.forClass(MediatorDeactivatedEvent.class);
        verify(notifications).notifyChanges(eventCaptor.capture());
        final MediatorDeactivatedEvent event = eventCaptor.getValue();
        assertThat(event.getMediatorId(), is(originalData.getId()));
        assertThat(event.getDetailedDescription(), is(newData.getAdditionalInfo()));
    }

    public MediatorConnectionData verifyMutationToState(
            final Optional<MediatorConnectionMutationDescriptor> mutation, ActualActivationState state) {
        assertThat(mutation, is(present()));

        final MediatorConnectionData newData = mutation.get().apply();
        assertThat(newData.getAdditionalInfo(), is(""));
        assertThat(newData.getActualActivationState(), is(state));
        assertThat(newData.getVersion(), is(2));

        mutation.get().applied();
        return newData;
    }

    private void verifyActivationFailed(final MediatorConnectionData originalData,
                                        final Optional<MediatorConnectionMutationDescriptor> mutation, String description) {
        assertThat(mutation.isPresent(), is(true));

        final MediatorConnectionData newData = mutation.get().apply();
        assertThat(newData.getAdditionalInfo(), is(description));
        assertThat(newData.getActualActivationState(), is(ActualActivationState.FAILED));
        assertThat(newData.getVersion(), is(2));

        mutation.get().applied();
        final ArgumentCaptor<MediatorActivationFailedEvent> eventCaptor = ArgumentCaptor.forClass(MediatorActivationFailedEvent.class);
        verify(notifications).notifyChanges(eventCaptor.capture());
        final MediatorActivationFailedEvent event = eventCaptor.getValue();
        assertThat(event.getMediatorId(), is(originalData.getId()));
        assertThat(event.getDetailedDescription(), is(newData.getAdditionalInfo()));
    }

}
