package com.ossnms.dcn_manager.core.configuration.model;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.core.configuration.loaders.TypeLoaderChannel;
import com.ossnms.dcn_manager.core.jaxb.mediatortype.Config;
import com.ossnms.dcn_manager.core.jaxb.mediatortype.SupportedChannels;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;

import static com.google.common.collect.Iterables.getOnlyElement;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;

public class MediatorTypeTest extends TypeTestBase {

    private Config config;
    private Types<NeType> neTypes;
    private DefaultPropertyValues defaultValues;

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() {
        neTypes = mock(Types.class);
        defaultValues = mock(DefaultPropertyValues.class);

        config = new Config();
    }

    @Test
    public void testTypeProperties() {

        config.setName("N");
        config.setTypeProperties(buildTypeProperties(
                "PROVIDER_CLASS", "class",
                "GUI_LABEL_SHORT", "gls",
                "GUI_LABEL_LONG", "gll",
                "ENCRYPTION_SUPPORT", "true"
            ));

        final MediatorType type = new MediatorType(config, null, null);
        assertThat(type.getName(), is("N"));
        assertThat(type.getConnectionManagerProviderClass(), is("class"));
        assertThat(type.getGuiLabelShort(), is("gls"));
        assertThat(type.getGuiLabelLong(), is("gll"));
        assertThat(type.getTypeProperties(), hasEntry("ENCRYPTION_SUPPORT", "true"));
    }

    @Test
    public void testSupportedMediators() {

        final ClassLoader classLoader = getClass().getClassLoader();
        final Types<ChannelType> types = new TypeLoaderChannel(neTypes, defaultValues).load(
                ImmutableList.of(classLoader.getResource("emtype/EmTypeLoadTest.xml"), classLoader.getResource("emtype/EmTypeWithoutDiscovery.xml")));

        final SupportedChannels supportedChannels = new SupportedChannels();
        supportedChannels.getChannel().add("channel-type-name-1");
        supportedChannels.getChannel().add("UNO");

        config.setSupportedChannels(supportedChannels);

        final MediatorType type = new MediatorType(config, defaultValues, types);

        final Iterable<ChannelType> channelTypes = type.getSupportedChannelTypes();
        assertThat(channelTypes, is(notNullValue()));
        assertThat(channelTypes, is(Matchers.<ChannelType>iterableWithSize(1)));
        assertThat(getOnlyElement(channelTypes).getName(), is("UNO"));
    }
}
