package com.ossnms.dcn_manager.core.entities.ne.data;

import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.properties.ne.NeDirectRouteProperties;
import com.ossnms.dcn_manager.core.properties.ne.NeProperties;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasEntry;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

public class NeCreateDescriptorTest {

    private NeType type;

    @Before
    public void setUp() {
        type = MockFactory.mockNeType();
    }

    @Test
    public void testCreation_withDefaultIcon() {
        when(type.getDefaultIcon()).thenReturn("defaultIcon");

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(1, type);

        final NeInfoData infoData = new NeInfoData(1, 1, 1, descriptor.getInfo());

        assertThat(infoData.getIconId(), hasValue("defaultIcon"));
    }

    @Test
    public void testCreation_withoutIcon() {

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(1, type);

        final NeInfoData infoData = new NeInfoData(1, 1, 1, descriptor.getInfo());

        assertThat(infoData.getIconId(), is(absent()));
    }

    @Test
    public void testCreation_withSpecificIcon() {
        when(type.getDefaultIcon()).thenReturn("defaultIcon");

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(1, type);
        descriptor.getInfo().setIconId(Optional.of("myIcon"));

        final NeInfoData infoData = new NeInfoData(1, 1, 1, descriptor.getInfo());

        assertThat(infoData.getIconId(), hasValue("myIcon"));
    }

    @Test
    public void testProperties() throws InvalidMutationException {

        final NeCreateDescriptor descriptor = new NeCreateDescriptor(1, type);

        when(type.getDirectRouteAddressKeySource()).thenReturn(Optional.<String>empty());

        new NeProperties().setProperty(type, descriptor.getPreferences(), "abc", "123");
        new NeDirectRouteProperties().set(type, descriptor, descriptor.getPreferences(), "ip_address", "456");

        assertThat(descriptor.getAllOpaqueProperties(), allOf(hasEntry("abc", "123"), hasEntry("ip_address", "456")));
    }

}
