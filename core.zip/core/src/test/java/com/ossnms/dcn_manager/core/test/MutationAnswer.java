package com.ossnms.dcn_manager.core.test;

import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import java.util.Optional;

public class MutationAnswer<T extends BusinessObjectData> implements
        Answer<Optional<T>> {

    @Override
    public Optional<T> answer(InvocationOnMock invocation) {
        @SuppressWarnings("unchecked")
        final MutationDescriptor<T, ?> mutation = (MutationDescriptor<T, ?>) invocation.getArguments()[0];
        if (null != mutation) {
            final T result = mutation.apply();
            mutation.applied();
            return Optional.of(result);
        } else {
            return null;
        }
    }

}