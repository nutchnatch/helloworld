package com.ossnms.dcn_manager.core.entities.channel.data;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.both;
import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertThat;

import org.junit.Before;
import org.junit.Test;

import com.ossnms.dcn_manager.core.entities.DomainObjectDataTestBase;
import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;

public class ChannelConnectionDataTest extends DomainObjectDataTestBase<ChannelConnectionData> {

	private static final String INFO = "Some info";
	private static final ActualActivationState ACTIVATION_STATE = ActualActivationState.ACTIVE;

	private ChannelConnectionData createChannelConnectionData(int id, int version) {
		return new ChannelConnectionBuilder()
		    .setActivation(ACTIVATION_STATE)
		    .setAdditionalInfo(INFO)
		    .build(id, version);
	}

	@Before
	@Override
	public void setUp() throws Exception {
		domainObjectOne = createChannelConnectionData(ONE_ID, ONE_VERSION);
		domainObjectOneCopy = createChannelConnectionData(ONE_ID, ONE_VERSION);
		domainObjectOneMutated = createChannelConnectionData(ONE_ID, ONE_VERSION + 1);
		domainObjectTwo = createChannelConnectionData(TWO_ID, TWO_VERSION);
	}

	@Test
	public void toString_inAValidInstance_producesAStringWithTheCorrectContent() {
		// The following string literals must match the ones used in ChannelInfoData.toString()
		// Public constant fields was not used to prevent polluting the type's public interface

        assertThat(domainObjectOne.toString(),
    		allOf(
        		both(containsString("additional_info")).and(containsString(INFO)),
        		both(containsString("activation_state")).and(containsString(ACTIVATION_STATE.toString()))
        	)
        );
	}
}
