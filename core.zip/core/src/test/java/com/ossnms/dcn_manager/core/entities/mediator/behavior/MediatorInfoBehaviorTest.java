package com.ossnms.dcn_manager.core.entities.mediator.behavior;

import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.ActivateMediatorEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.DeactivateMediatorEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collections;
import java.util.Optional;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class MediatorInfoBehaviorTest {

    private MediatorNotifications notifications;

    @Before
    public void setUp() {
        notifications = mock(MediatorNotifications.class);
    }

    private MediatorInfoData newInfo(boolean activationRequired) {
        return new MediatorInfoBuilder()
            .setName("name")
            .setTypeName("type")
            .setDescription(Optional.of("desc"))
            .setActivationRequired(activationRequired)
            .build(1, 1);
    }

    @Test
    public void testActivationRequired_fromInactive() {
        final int instanceId = 34;
        final MediatorInfoData originalData = newInfo(false);
        final Optional<MediatorInfoMutationDescriptor> mutation =
            new MediatorInfoBehavior(originalData)
                .activationRequired(notifications, instanceId);

        assertThat(mutation.isPresent(), is(true));

        final MediatorInfoData newData = mutation.get().apply();
        assertThat(newData.getId(), is(originalData.getId()));
        assertThat(newData.getName(), is(originalData.getName()));
        assertThat(newData.getTypeName(), is(originalData.getTypeName()));
        assertThat(newData.getDescription(), is(originalData.getDescription()));
        assertThat(newData.isActivationRequired(), is(true));
        assertThat(newData.getVersion(), is(2));

        mutation.get().applied();
        final ArgumentCaptor<ActivateMediatorEvent> eventCaptor = ArgumentCaptor.forClass(ActivateMediatorEvent.class);
        verify(notifications).notifyChanges(eventCaptor.capture());
        final ActivateMediatorEvent event = eventCaptor.getValue();
        assertThat(event.getMediatorId(), is(originalData.getId()));
        assertThat(event.getMediatorInstanceIdentifiers(), is(Collections.singleton(34)));
    }

    @Test
    public void testActivationRequired_fromActive() {
        final MediatorInfoData originalData = newInfo(true);
        final Optional<MediatorInfoMutationDescriptor> mutation =
            new MediatorInfoBehavior(originalData)
                .activationRequired(notifications, 1);

        assertThat(mutation.isPresent(), is(false));
    }

    @Test
    public void testDeactivationRequired_fromInactive() {
        final MediatorInfoData originalData = newInfo(false);
        final Optional<MediatorInfoMutationDescriptor> mutation =
            new MediatorInfoBehavior(originalData)
                .deactivationRequired(notifications, Collections.singleton(1));

        assertThat(mutation.isPresent(), is(false));
    }

    @Test
    public void testDeactivationRequired_fromActive() {
        final int instanceId = 34;
        final MediatorInfoData originalData = newInfo(true);
        final Optional<MediatorInfoMutationDescriptor> mutation =
            new MediatorInfoBehavior(originalData)
                .deactivationRequired(notifications, Collections.singleton(instanceId));

        assertThat(mutation.isPresent(), is(true));

        final MediatorInfoData newData = mutation.get().apply();
        assertThat(newData.getId(), is(originalData.getId()));
        assertThat(newData.getName(), is(originalData.getName()));
        assertThat(newData.getDescription(), is(originalData.getDescription()));
        assertThat(newData.isActivationRequired(), is(false));
        assertThat(newData.getVersion(), is(2));

        mutation.get().applied();
        final ArgumentCaptor<DeactivateMediatorEvent> eventCaptor = ArgumentCaptor.forClass(DeactivateMediatorEvent.class);
        verify(notifications).notifyChanges(eventCaptor.capture());
        final DeactivateMediatorEvent event = eventCaptor.getValue();
        assertThat(event.getMediatorId(), is(originalData.getId()));
        assertThat(event.getMediatorInstanceIdentifiers(), is(Collections.singleton(instanceId)));
    }

}
