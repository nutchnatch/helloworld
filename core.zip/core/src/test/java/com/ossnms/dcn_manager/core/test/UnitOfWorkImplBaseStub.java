package com.ossnms.dcn_manager.core.test;

import com.ossnms.dcn_manager.core.storage.uow.UnitOfWorkImplBase;
import com.ossnms.dcn_manager.core.storage.uow.UowContext;
import com.ossnms.dcn_manager.exceptions.DcnManagerException;

import java.util.Collection;

import static org.mockito.Mockito.mock;

public final class UnitOfWorkImplBaseStub<T> extends UnitOfWorkImplBase<T> {

    public UnitOfWorkImplBaseStub(T accumulator) {
        super(accumulator);
    }

    @Override
    protected void executeSteps(Collection<UowStep<?>> uowSteps) throws DcnManagerException {
        UowContext ctx = mock(UowContext.class);
        for (UowStep<?> step : uowSteps) {
            step.execute(ctx);
        }
    }
}
