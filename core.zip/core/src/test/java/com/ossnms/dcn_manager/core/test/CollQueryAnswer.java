package com.ossnms.dcn_manager.core.test;

import java.util.Arrays;
import java.util.List;

import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.mysema.query.collections.CollQuery;
import com.mysema.query.collections.CollQueryFactory;
import com.mysema.query.types.path.EntityPathBase;

public final class CollQueryAnswer<T> implements Answer<CollQuery> {
    private final List<T> rows;
    public CollQueryAnswer(@SuppressWarnings("unchecked") T... rows) {
        this.rows = Arrays.asList(rows);
    }
    @Override
    public CollQuery answer(InvocationOnMock invocation) throws Throwable {
        @SuppressWarnings("unchecked")
        final EntityPathBase<T> path = (EntityPathBase<T>) invocation.getArguments()[0];
        return null == path ? null : CollQueryFactory.from(path, rows);
    }

}