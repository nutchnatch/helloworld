package com.ossnms.dcn_manager.core.policies.impl;

import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.policies.common.PolicyJob;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;
import java.util.function.Supplier;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;

public class JobWrapperTest {

    private Supplier<Optional<PolicyJob<? extends NeEvent>>> supplier;

    @Before
    @SuppressWarnings("unchecked")
    public void setUp() throws Exception {
        supplier = mock(Supplier.class);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void runOriginalItem_andThenRequestsMore() throws Exception {

        final PolicyJob<NeEvent> firstJob = mock(PolicyJob.class);
        final PolicyJob<NeEvent> secondJob = mock(PolicyJob.class);
        final PolicyJob<NeEvent> thirdJob = mock(PolicyJob.class);

        when(supplier.get()).thenReturn(Optional.of(secondJob), Optional.of(thirdJob), Optional.empty());

        new JobWrapper<>(firstJob, supplier).run();

        verify(firstJob).run();
        verify(secondJob).run();
        verify(thirdJob).run();
    }

    @Test
    @SuppressWarnings("unchecked")
    public void runMoreThanOneItem_keepsOriginalInformation() throws Exception {

        final PolicyJob<NeEvent> firstJob = mock(PolicyJob.class);
        when(firstJob.getPriority()).thenReturn(PolicyJob.Priority.MEDIUM);
        final PolicyJob<NeEvent> secondJob = mock(PolicyJob.class);

        when(supplier.get()).thenReturn(Optional.of(secondJob), Optional.empty());

        final JobWrapper<NeEvent> wrapper = new JobWrapper<>(firstJob, supplier);
        wrapper.run();

        assertThat(wrapper.getOriginatingEvent(), is(firstJob.getOriginatingEvent()));
        assertThat(wrapper.getPriority(), is(firstJob.getPriority()));
    }

    @Test
    @SuppressWarnings("unchecked")
    public void delegatesBehaviorToOriginalItem() throws Exception {

        final PolicyJob<NeEvent> firstJob = mock(PolicyJob.class);

        when(supplier.get()).thenReturn(Optional.empty());

        final JobWrapper<NeEvent> wrapper = new JobWrapper<>(firstJob, supplier);
        wrapper.run();

        wrapper.cancel();
        verify(firstJob).cancel();

        wrapper.compareTo(firstJob);
        verify(firstJob).compareTo(firstJob);
    }
}