package com.ossnms.dcn_manager.core.configuration.model;

import com.ossnms.dcn_manager.core.configuration.loaders.TypeLoaderNe;
import org.junit.Before;
import org.junit.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;

import static java.util.Collections.singleton;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;

public class NeTypesTest {

    private DefaultPropertyValues defaultValues;

    @Before
    public void setUp() {
        defaultValues = mock(DefaultPropertyValues.class);
    }

    @Test
    public void testLoading() {
        final ClassLoader classLoader = getClass().getClassLoader();
        final Types<NeType> types = new TypeLoaderNe(defaultValues).load(Collections.singleton(classLoader.getResource("netype/NeTypeLoadTest.xml")));

        assertFalse(types.isEmpty());
        assertTrue(types.containsKey("UNO 1.0"));
        assertThat(types.get("UNO 1.0").getName(), is("UNO 1.0"));
    }

    @Test
    public void testLoadingBadURL() throws MalformedURLException {
        final Types<NeType> types = new TypeLoaderNe(defaultValues).load(singleton(new URL("file:///xpto")));
        assertTrue(types.isEmpty());
    }

}
