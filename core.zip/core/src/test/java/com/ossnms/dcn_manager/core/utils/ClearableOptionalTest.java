package com.ossnms.dcn_manager.core.utils;

import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;


public class ClearableOptionalTest {

    @Test
    public void absentAlternative() {
        final ClearableOptional<Object> clearable = ClearableOptional.absent();
        final Optional<Object> alternative = Optional.of(42);

        assertThat(clearable.or(alternative), is(alternative));
    }

    @Test
    public void presentAlternative() {
        final ClearableOptional<Integer> clearable = ClearableOptional.of(89);
        final Optional<Integer> alternative = Optional.of(42);

        assertThat(clearable.or(alternative), is(clearable.asOptional()));
    }

    @Test
    public void clearAlternative() {
        final ClearableOptional<Integer> clearable = ClearableOptional.clear();
        final Optional<Integer> alternative = Optional.of(42);

        assertThat(clearable.or(alternative), is(Optional.<Integer>empty()));
    }

    @Test
    public void presence() {
        final ClearableOptional<Object> clear = ClearableOptional.clear();
        final ClearableOptional<Object> absent = ClearableOptional.absent();
        final ClearableOptional<Object> present = ClearableOptional.of(6);

        assertThat(clear.isPresent(), is(true));
        assertThat(absent.isPresent(), is(false));
        assertThat(present.isPresent(), is(true));
    }

    @Test(expected=IllegalStateException.class)
    public void getOnClear() {
        final ClearableOptional<Object> clear = ClearableOptional.clear();
        clear.get();
    }

    @Test(expected=IllegalStateException.class)
    public void getOnAbsent() {
        final ClearableOptional<Object> absent = ClearableOptional.absent();
        absent.get();
    }

    @Test
    public void getOnPresent() {
        final ClearableOptional<Integer> present = ClearableOptional.of(6);
        assertThat(present.get(), is(6));
    }

    @Test
    public void clearAsOptional() {
        final ClearableOptional<Object> clear = ClearableOptional.clear();
        assertThat(clear.asOptional(), is(Optional.empty()));
    }

    @Test
    public void absentAsOptional() {
        final ClearableOptional<Object> absent = ClearableOptional.absent();
        assertThat(absent.asOptional(), is(Optional.empty()));
    }

    @Test
    public void presentAsOptional() {
        final ClearableOptional<Integer> present = ClearableOptional.of(6);
        assertThat(present.asOptional(), is(Optional.of(6)));
    }

    @Test
    public void orNull() {
        assertThat(ClearableOptional.clear().orNull(), is(nullValue()));
        assertThat(ClearableOptional.absent().orNull(), is(nullValue()));
        assertThat(ClearableOptional.of(87).orNull(), is(87));

        assertThat(ClearableOptional.of(Optional.of(98)).orNull(), is(98));
        assertThat(ClearableOptional.of(Optional.empty()).orNull(), is(nullValue()));
    }

    @Test
    public void equality() {
        final ClearableOptional<Object> clear = ClearableOptional.clear();
        final ClearableOptional<Object> absent = ClearableOptional.absent();
        final ClearableOptional<Object> presentA = ClearableOptional.of(6);
        final ClearableOptional<Object> presentB = ClearableOptional.of(7);

        assertThat(clear, not(is(absent)));
        assertThat(clear, not(is(presentA)));
        assertThat(clear, not(is(presentB)));
        assertThat(clear, is(ClearableOptional.clear()));

        assertThat(absent, not(is(clear)));
        assertThat(absent, not(is(presentA)));
        assertThat(absent, not(is(presentB)));
        assertThat(absent, is(ClearableOptional.absent()));

        assertThat(presentA, not(is(absent)));
        assertThat(presentA, not(is(clear)));
        assertThat(presentA, not(is(presentB)));
        assertThat(presentA, is(ClearableOptional.<Object>of(6)));

        assertThat(presentB, not(is(absent)));
        assertThat(presentB, not(is(presentA)));
        assertThat(presentB, not(is(clear)));
        assertThat(presentB, is(ClearableOptional.<Object>of(7)));
    }

    @Test
    public void hashCodeGeneration() {
        final ClearableOptional<Object> clear = ClearableOptional.clear();
        final ClearableOptional<Object> absent = ClearableOptional.absent();
        final ClearableOptional<Object> presentA = ClearableOptional.of(6);
        final ClearableOptional<Object> presentB = ClearableOptional.of(7);

        assertThat(clear.hashCode(), not(is(absent.hashCode())));
        assertThat(clear.hashCode(), not(is(presentA.hashCode())));
        assertThat(clear.hashCode(), not(is(presentB.hashCode())));
        assertThat(clear.hashCode(), is(ClearableOptional.clear().hashCode()));

        assertThat(absent.hashCode(), not(is(clear.hashCode())));
        assertThat(absent.hashCode(), not(is(presentA.hashCode())));
        assertThat(absent.hashCode(), not(is(presentB.hashCode())));
        assertThat(absent.hashCode(), is(ClearableOptional.absent().hashCode()));

        assertThat(presentA.hashCode(), not(is(absent.hashCode())));
        assertThat(presentA.hashCode(), not(is(clear.hashCode())));
        assertThat(presentA.hashCode(), not(is(presentB.hashCode())));
        assertThat(presentA.hashCode(), is(ClearableOptional.<Object>of(6).hashCode()));

        assertThat(presentB.hashCode(), not(is(absent.hashCode())));
        assertThat(presentB.hashCode(), not(is(presentA.hashCode())));
        assertThat(presentB.hashCode(), not(is(clear.hashCode())));
        assertThat(presentB.hashCode(), is(ClearableOptional.<Object>of(7).hashCode()));
    }

}
