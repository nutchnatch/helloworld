package com.ossnms.dcn_manager.core.utils.matchers;

import org.hamcrest.Description;
import org.hamcrest.TypeSafeMatcher;

import com.ossnms.dcn_manager.core.entities.BusinessObjectData;

/**
 * <p>Matcher used to verify if a given domain object instance is a valid mutation of 
 * another. An instance is considered a valid mutation if its identifier is the same
 * and its version is not.</p> 
 *
 * @param <T> The domain object concrete type
 * @see org.hamcrest.TypeSafeMatcher<T>
 */
class MutationOf<T extends BusinessObjectData> extends TypeSafeMatcher<T> {

	private final T one;
	
	public MutationOf(T argument) {
		this.one = argument;
	}
	
	/** {@inheritDoc} */
	@Override
	public boolean matchesSafely(T other) {
		return one.getId() == other.getId() && one.getVersion() != other.getVersion(); 
	}

	/** {@inheritDoc} */
	@Override
	public void describeTo(Description description) {
		description.appendText("not a valid mutation");
	}
}