package com.ossnms.dcn_manager.core.entities.mediator.behavior;

import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData.ChannelPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.channel.ChannelEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorDeactivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorShuttingDownEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorStartingUpEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.DeactivateMediatorEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.policies.MediatorInteractionManager;
import com.ossnms.dcn_manager.i18n.Message;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import java.util.Collection;
import java.util.Collections;
import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.hasValue;
import static com.ossnms.dcn_manager.test.util.OtherMatchers.present;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class MediatorPhysicalConnectionBehaviorTest {

    private static final String ERROR = "error";

    private static final int CHANNEL_ID = 1;
    private static final int CHANNEL_INSTANCE = 2;
    private static final int MEDIATOR_INSTANCE = 3;

    private MediatorInteractionManager activationManager;
    private MediatorNotifications notifications;

    private MessageSource<ChannelEvent> channelEvents;
    private final Collection<ChannelPhysicalConnectionData> childChannelsForActuation = Collections.singleton(
            new ChannelPhysicalConnectionBuilder().build(CHANNEL_INSTANCE, MEDIATOR_INSTANCE, CHANNEL_ID, 0));

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() {
        notifications = mock(MediatorNotifications.class);
        activationManager = mock(MediatorInteractionManager.class);
        channelEvents = mock(MessageSource.class);
    }

    private MediatorPhysicalConnectionData newConnectionData(ActualActivationState state) {
        return new MediatorPhysicalConnectionBuilder().setActualActivationState(state).setAdditionalInfo("??").build(1, 1, 1);
    }

    @Test
    public void testSetStartingUp_fromInactive() {
        final MediatorPhysicalConnectionData originalData = newConnectionData(ActualActivationState.INACTIVE);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
            new MediatorPhysicalConnectionBehavior(originalData)
                .setStartingUp(notifications, activationManager);

        verifyMutationToState(mutation, ActualActivationState.STARTINGUP);
        verify(notifications).notifyChanges(isA(MediatorStartingUpEvent.class));
    }

    @Test
    public void testSetActivating_fromStartingUp() {
        final MediatorPhysicalConnectionData originalData = newConnectionData(ActualActivationState.STARTINGUP);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
            new MediatorPhysicalConnectionBehavior(originalData)
                .setActivating(notifications);

        verifyMutationToState(mutation, ActualActivationState.ACTIVATING);
        verify(notifications).notifyChanges(isA(MediatorActivatingEvent.class));

        assertThat(mutation.get().getActivationAttemptsCounter(), hasValue(1));
    }

    @Test
    public void testSetActivating_fromInactive() {
        final MediatorPhysicalConnectionData originalData = newConnectionData(ActualActivationState.INACTIVE);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
            new MediatorPhysicalConnectionBehavior(originalData)
                .setActivating(notifications);

        verifyMutationToState(mutation, ActualActivationState.ACTIVATING);
        verify(notifications).notifyChanges(isA(MediatorActivatingEvent.class));

        assertThat(mutation.get().getActivationAttemptsCounter(), hasValue(1));
    }


    @Test
    public void testSetStartingUp_fromFailed() {
        final MediatorPhysicalConnectionData originalData = newConnectionData(ActualActivationState.FAILED);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
            new MediatorPhysicalConnectionBehavior(originalData)
                .setStartingUp(notifications, activationManager);

        verifyMutationToState(mutation, ActualActivationState.STARTINGUP);
        verify(notifications).notifyChanges(isA(MediatorStartingUpEvent.class));
    }

    @Test
    public void testSetActivating_fromActivating() {
        final MediatorPhysicalConnectionData originalData = newConnectionData(ActualActivationState.ACTIVATING);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
            new MediatorPhysicalConnectionBehavior(originalData)
                .setActivating(notifications);

        assertThat(mutation, is(absent()));
    }

    @Test
    public void testSetActive_fromActivating() {
        final MediatorPhysicalConnectionData originalData = newConnectionData(ActualActivationState.ACTIVATING);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
            new MediatorPhysicalConnectionBehavior(originalData)
                .setActive(notifications, activationManager);

        verifyActivation(originalData, mutation);
    }

    @Test
    public void testSetActive_fromActive() {
        final MediatorPhysicalConnectionData originalData = newConnectionData(ActualActivationState.ACTIVE);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
            new MediatorPhysicalConnectionBehavior(originalData)
                .setActive(notifications, activationManager);

        assertThat(mutation, is(absent()));
    }

    @Test
    public void testSetDeactivating_fromShuttingDown() {
        final MediatorPhysicalConnectionData originalData = newConnectionData(ActualActivationState.SHUTTINGDOWN);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
            new MediatorPhysicalConnectionBehavior(originalData)
                .setDeactivating(notifications);

        verifyMutationToState(mutation, ActualActivationState.DEACTIVATING);
        verify(notifications).notifyChanges(isA(MediatorDeactivatingEvent.class));
    }

    @Test
    public void testSetDeactivating_fromDeactivating() {
        final MediatorPhysicalConnectionData originalData = newConnectionData(ActualActivationState.DEACTIVATING);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
            new MediatorPhysicalConnectionBehavior(originalData)
                .setDeactivating(notifications);

        assertThat(mutation, is(absent()));
    }

    @Test
    public void testSetInactive_fromInactive() {
        final MediatorPhysicalConnectionData originalData = newConnectionData(ActualActivationState.INACTIVE);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
            new MediatorPhysicalConnectionBehavior(originalData)
                .setInactive(notifications, activationManager, channelEvents, childChannelsForActuation);

        assertThat(mutation, is(absent()));
    }

    @Test
    public void testSetInactive_fromDeactivating() {
        final MediatorPhysicalConnectionData originalData = newConnectionData(ActualActivationState.DEACTIVATING);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
            new MediatorPhysicalConnectionBehavior(originalData)
                .setInactive(notifications, activationManager, channelEvents, childChannelsForActuation);

        verifyDeactivation(originalData, mutation);
    }

    @Test
    public void testSetFailed_fromInactive() {
        final MediatorPhysicalConnectionData originalData = newConnectionData(ActualActivationState.INACTIVE);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
            new MediatorPhysicalConnectionBehavior(originalData)
                .setFailed(notifications, activationManager, ERROR, channelEvents, childChannelsForActuation);

        assertThat(mutation, is(absent()));
    }

    @Test
    public void testSetFailed_fromActivating() {
        final MediatorPhysicalConnectionData originalData =
                new MediatorPhysicalConnectionBuilder().setActualActivationState(ActualActivationState.ACTIVATING).setActivationAttemptsCounter(1).build(1, 1, 1);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
            new MediatorPhysicalConnectionBehavior(originalData)
                .setFailed(notifications, activationManager, ERROR, channelEvents, childChannelsForActuation);

        verifyActivationFailed(originalData, mutation, ERROR);
        assertThat(mutation.get().getResult().getActivationAttemptsCounter(), is(1));
    }

    @Test
    public void testSetFailed_fromActive() {
        final MediatorPhysicalConnectionData originalData = newConnectionData(ActualActivationState.ACTIVE);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
            new MediatorPhysicalConnectionBehavior(originalData)
                .setFailed(notifications, activationManager, ERROR, channelEvents, childChannelsForActuation);

        verifyActivationFailed(originalData, mutation, ERROR);
    }

    @Test
    public void testSetFailed_fromFailed() {
        final MediatorPhysicalConnectionData originalData = newConnectionData(ActualActivationState.FAILED);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
            new MediatorPhysicalConnectionBehavior(originalData)
                .setFailed(notifications, activationManager, ERROR, channelEvents, childChannelsForActuation);

        verifyActivationFailed(originalData, mutation, ERROR);
    }

    @Test
    public void testSetShuttingDown_FromActive() {
        final MediatorPhysicalConnectionData originalData = newConnectionData(ActualActivationState.ACTIVE);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
            new MediatorPhysicalConnectionBehavior(originalData)
                .setShuttingDown(notifications, activationManager);

        verifyMutationToState(mutation, ActualActivationState.SHUTTINGDOWN);
        verify(notifications).notifyChanges(isA(MediatorShuttingDownEvent.class));
        verify(activationManager).scheduleDeactivation(isA(DeactivateMediatorEvent.class));
    }

    @Test
    public void testSetShuttingDown_FromFailed() {
        final MediatorPhysicalConnectionData originalData = newConnectionData(ActualActivationState.FAILED);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
            new MediatorPhysicalConnectionBehavior(originalData)
                .setShuttingDown(notifications, activationManager);

        verifyMutationToState(mutation, ActualActivationState.SHUTTINGDOWN);
        verify(notifications).notifyChanges(isA(MediatorShuttingDownEvent.class));
        verify(activationManager).scheduleDeactivation(isA(DeactivateMediatorEvent.class));
    }

    @Test
    public void testSetShuttingDown_FromActivating() {
        final MediatorPhysicalConnectionData originalData = newConnectionData(ActualActivationState.ACTIVATING);
        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation =
            new MediatorPhysicalConnectionBehavior(originalData)
                .setShuttingDown(notifications, activationManager);

        verifyMutationToState(mutation, ActualActivationState.SHUTTINGDOWN);
        verify(notifications).notifyChanges(isA(MediatorShuttingDownEvent.class));
        verify(activationManager).scheduleDeactivation(isA(DeactivateMediatorEvent.class));
    }




    private void verifyActivation(final MediatorPhysicalConnectionData originalData,
            final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation) {
        final MediatorPhysicalConnectionData newData = verifyMutationToState(mutation, ActualActivationState.ACTIVE);
        assertThat(newData.getActivationAttemptsCounter(), is(0));

        final ArgumentCaptor<MediatorActivatedEvent> eventCaptor = ArgumentCaptor.forClass(MediatorActivatedEvent.class);
        verify(notifications).notifyChanges(eventCaptor.capture());
        final MediatorActivatedEvent event = eventCaptor.getValue();
        assertThat(event.getMediatorId(), is(originalData.getId()));
        assertThat(event.getDetailedDescription(), is(newData.getAdditionalInfo()));

        verify(activationManager).onMediatorInteractionEnded(isA(MediatorActivatedEvent.class));
    }

    private void verifyDeactivation(final MediatorPhysicalConnectionData originalData,
            final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation) {
        final MediatorPhysicalConnectionData newData = verifyMutationToState(mutation, ActualActivationState.INACTIVE);
        assertThat(newData.getActivationAttemptsCounter(), is(0));

        final ArgumentCaptor<MediatorDeactivatedEvent> eventCaptor = ArgumentCaptor.forClass(MediatorDeactivatedEvent.class);
        verify(notifications).notifyChanges(eventCaptor.capture());
        final MediatorDeactivatedEvent event = eventCaptor.getValue();
        assertThat(event.getMediatorId(), is(originalData.getId()));
        assertThat(event.getDetailedDescription(), is(newData.getAdditionalInfo()));

        verify(activationManager).onMediatorInteractionEnded(any(MediatorDeactivatedEvent.class));
        verify(channelEvents).push(new PhysicalChannelDeactivatedEvent(CHANNEL_INSTANCE, CHANNEL_ID, false));
    }

    public MediatorPhysicalConnectionData verifyMutationToState(
            final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation, ActualActivationState state) {
        assertThat(mutation, is(present()));

        final MediatorPhysicalConnectionData newData = mutation.get().apply();
        assertThat(newData.getAdditionalInfo(), is(""));
        assertThat(newData.getActualActivationState(), is(state));
        assertThat(newData.getVersion(), is(2));

        mutation.get().applied();
        return newData;
    }

    private void verifyActivationFailed(final MediatorPhysicalConnectionData originalData,
                                        final Optional<MediatorPhysicalConnectionMutationDescriptor> mutation, String description) {
        assertThat(mutation.isPresent(), is(true));

        final MediatorPhysicalConnectionData newData = mutation.get().apply();
        assertThat(newData.getAdditionalInfo(), is(description));
        assertThat(newData.getActualActivationState(), is(ActualActivationState.FAILED));
        assertThat(newData.getVersion(), is(2));
        assertThat(newData.getLastFailureTimestamp().orElse(null), is(notNullValue()));

        mutation.get().applied();
        final ArgumentCaptor<MediatorActivationFailedEvent> eventCaptor = ArgumentCaptor.forClass(MediatorActivationFailedEvent.class);
        verify(notifications).notifyChanges(eventCaptor.capture());
        final MediatorActivationFailedEvent event = eventCaptor.getValue();
        assertThat(event.getMediatorId(), is(originalData.getId()));
        assertThat(event.getDetailedDescription(), is(newData.getAdditionalInfo()));

        verify(activationManager).onMediatorInteractionEnded(any(MediatorActivationFailedEvent.class));
        verify(channelEvents).push(new PhysicalChannelActivationFailedEvent(CHANNEL_INSTANCE, CHANNEL_ID, false, Message.MEDIATOR_FAILED.toString()));
    }

}
