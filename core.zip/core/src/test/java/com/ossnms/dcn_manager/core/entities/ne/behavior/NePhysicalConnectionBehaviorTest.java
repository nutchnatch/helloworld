package com.ossnms.dcn_manager.core.entities.ne.behavior;

import com.google.common.base.Function;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.*;
import com.ossnms.dcn_manager.core.events.ne.NeSynchronizationEvent;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.*;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.*;

public class NePhysicalConnectionBehaviorTest {

    private static final int NE_ID = 1;
    private static final int NE_INSTANCE_ID = 10;
    private static final int CHANNEL_ID = 78;
    private static final int MEDIATOR_ID = 42;

    private NetworkElementInteractionManager activationManager;
    private NetworkElementNotifications notifications;

    @Before
    public void setUp() {
        notifications = mock(NetworkElementNotifications.class);
        activationManager = mock(NetworkElementInteractionManager.class);
    }

    @Test
    public void disconnected_transitions() {
        verifyAbsent(ActualActivationState.DISCONNECTED, behavior -> behavior.setFailed("descr", activationManager));

        verifyPresent(ActualActivationState.DISCONNECTED, ActualActivationState.STARTUP, behavior -> behavior.startUp(activationManager, MEDIATOR_ID));
        verify(notifications).notifyChanges(isA(NeStartingUpEvent.class));
        verify(activationManager).cancelDeactivations(new Activate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, false));
        verify(activationManager).cancelSynchronizations(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_ID, MEDIATOR_ID, false));
        verify(activationManager).scheduleActivation(new Activate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, false));

        verifyPresent(ActualActivationState.DISCONNECTED, ActualActivationState.CONNECTING, NePhysicalConnectionBehavior::setConnecting);

        verifyAbsent(ActualActivationState.DISCONNECTED, behavior -> behavior.setConnected(activationManager, CHANNEL_ID, MEDIATOR_ID));

        verifyAbsent(ActualActivationState.DISCONNECTED, NePhysicalConnectionBehavior::setInitializing);

        verifyAbsent(ActualActivationState.DISCONNECTED, behavior -> behavior.setInitialized(activationManager));

        verifyAbsent(ActualActivationState.DISCONNECTED, behavior -> behavior.setDisconnecting(activationManager));

        verifyAbsent(ActualActivationState.DISCONNECTED, behavior -> behavior.setDisconnected(activationManager));

        verifyAbsent(ActualActivationState.DISCONNECTED, behavior -> behavior.shutdown(activationManager, MEDIATOR_ID));
    }

    @Test
    public void startingUp_shutdownTransition_onActive_notifiesPhysicalAndLogical() throws Exception {

        final NePhysicalConnectionBehavior behavior = new NePhysicalConnectionBehavior(
                new NePhysicalConnectionBuilder()
                        .setActive(true)
                        .setActivationState(ActualActivationState.STARTUP)
                        .build(NE_INSTANCE_ID, NE_ID, CHANNEL_ID, 1),
                notifications);

        final Optional<NePhysicalConnectionMutationDescriptor> mutation =
                behavior.shutdown(activationManager, MEDIATOR_ID);
        assertThat(mutation, is(present()));

        mutation.get().apply();
        mutation.get().applied();

        // one notification for the physical instance and another for the logical instance
        verify(notifications, times(2)).notifyChanges(isA(NeDisconnectedEvent.class));
    }

    @Test
    public void startingUp_transitions() {
        NePhysicalConnectionMutationDescriptor result;

        result = verifyPresent(ActualActivationState.STARTUP, ActualActivationState.FAILED, behavior -> behavior.setFailed("descr", activationManager));
        verify(notifications).notifyChanges(isA(NeActivationFailedEvent.class));
        verify(activationManager).onNeInteractionEnded(isA(NeActivationFailedEvent.class));
        assertThat(result.getActivationMode(), hasValue(ActualActivationMode.STANDARD));

        result = verifyPresent(ActualActivationState.STARTUP, ActualActivationState.CONNECTING, NePhysicalConnectionBehavior::setConnecting);
        verify(notifications).notifyChanges(isA(NeConnectingEvent.class));
        assertThat(result.getActivationMode(), hasValue(ActualActivationMode.STANDARD));

        verifyAbsent(ActualActivationState.STARTUP, NePhysicalConnectionBehavior::setInitializing);

        verifyAbsent(ActualActivationState.STARTUP, behavior -> behavior.setInitialized(activationManager));

        result = verifyPresent(ActualActivationState.STARTUP, ActualActivationState.DISCONNECTED, behavior -> behavior.shutdown(activationManager, MEDIATOR_ID));
        verify(notifications).notifyChanges(isA(NeDisconnectedEvent.class));
        verify(activationManager).cancelActivations(new Deactivate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, false));
        verify(activationManager).cancelSynchronizations(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_ID, MEDIATOR_ID, false));
        verify(activationManager).onNeInteractionEnded(isA(NeDisconnectedEvent.class));
        assertThat(result.getActivationMode(), hasValue(ActualActivationMode.STANDARD));

        verifyAbsent(ActualActivationState.STARTUP, behavior -> behavior.setDisconnected(activationManager));

        verifyAbsent(ActualActivationState.STARTUP, behavior -> behavior.resynchronize(activationManager, 77, 88));

        verifyAbsent(ActualActivationState.STARTUP, behavior -> behavior.setDisconnecting(activationManager));

        verifyAbsent(ActualActivationState.STARTUP, behavior -> behavior.setConnected(activationManager, CHANNEL_ID, MEDIATOR_ID));

        verifyAbsent(ActualActivationState.STARTUP, behavior -> behavior.startUp(activationManager, MEDIATOR_ID));
    }

    @Test
    public void shuttingDown_transitions() {
        verifyPresent(ActualActivationState.SHUTDOWN, ActualActivationState.FAILED, behavior -> behavior.setFailed("descr", activationManager));
        verify(notifications).notifyChanges(isA(NeActivationFailedEvent.class));

        verifyAbsent(ActualActivationState.SHUTDOWN, NePhysicalConnectionBehavior::setConnecting);

        verifyAbsent(ActualActivationState.SHUTDOWN, NePhysicalConnectionBehavior::setInitializing);

        verifyAbsent(ActualActivationState.SHUTDOWN, behavior -> behavior.setInitialized(activationManager));

        verifyAbsent(ActualActivationState.SHUTDOWN, behavior -> behavior.shutdown(activationManager, MEDIATOR_ID));

        verifyAbsent(ActualActivationState.SHUTDOWN, behavior -> behavior.setDisconnected(activationManager));
        verify(activationManager).onNeInteractionEnded(isA(ActualNeStateEvent.class));

        verifyAbsent(ActualActivationState.SHUTDOWN, behavior -> behavior.resynchronize(activationManager, 77, 88));

        verifyPresent(ActualActivationState.SHUTDOWN, ActualActivationState.DISCONNECTING, behavior -> behavior.setDisconnecting(activationManager));
        verify(notifications).notifyChanges(isA(NeDisconnectingEvent.class));

        verifyAbsent(ActualActivationState.SHUTDOWN, behavior -> behavior.setConnected(activationManager, CHANNEL_ID, MEDIATOR_ID));

        verifyPresent(ActualActivationState.SHUTDOWN, ActualActivationState.STARTUP, behavior -> behavior.startUp(activationManager, MEDIATOR_ID));
        verify(notifications).notifyChanges(isA(NeStartingUpEvent.class));
        verify(activationManager).cancelDeactivations(new Activate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, false));
        verify(activationManager).cancelSynchronizations(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_ID, MEDIATOR_ID, false));
        verify(activationManager).scheduleActivation(new Activate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, false));
    }

    @Test
    public void connecting_transitions() {
        verifyPresent(ActualActivationState.CONNECTING, ActualActivationState.FAILED, behavior -> behavior.setFailed("descr", activationManager));
        verify(notifications).notifyChanges(isA(NeActivationFailedEvent.class));
        verify(activationManager).onNeInteractionEnded(isA(NeActivationFailedEvent.class));

        verifyAbsent(ActualActivationState.CONNECTING, NePhysicalConnectionBehavior::setConnecting);

        verifyPresent(ActualActivationState.CONNECTING, ActualActivationState.CONNECTED, behavior -> behavior.setConnected(activationManager, CHANNEL_ID, MEDIATOR_ID));
        verify(notifications).notifyChanges(isA(NeConnectedEvent.class));
        //verify().clearConnectionLost(anyInt()); --> verified below

        verifyAbsent(ActualActivationState.CONNECTING, NePhysicalConnectionBehavior::setInitializing);

        verifyAbsent(ActualActivationState.CONNECTING, behavior -> behavior.setInitialized(activationManager));

        final NePhysicalConnectionMutationDescriptor result =
                verifyPresent(ActualActivationState.CONNECTING, ActualActivationState.SHUTDOWN, behavior -> behavior.shutdown(activationManager, MEDIATOR_ID));
        verify(notifications).notifyChanges(isA(NeShuttingDownEvent.class));
        verify(activationManager).cancelActivations(new Deactivate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, false));
        verify(activationManager).cancelSynchronizations(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_ID, MEDIATOR_ID, false));
        verify(activationManager).scheduleDeactivation(new Deactivate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, false));
        assertThat(result.getActivationMode(), hasValue(ActualActivationMode.STANDARD));

        verifyAbsent(ActualActivationState.CONNECTING, behavior -> behavior.setDisconnected(activationManager));

        verifyAbsent(ActualActivationState.CONNECTING, behavior -> behavior.resynchronize(activationManager, 77, 88));

        verifyAbsent(ActualActivationState.CONNECTING, behavior -> behavior.setDisconnecting(activationManager));

        verifyAbsent(ActualActivationState.CONNECTING, behavior -> behavior.startUp(activationManager, MEDIATOR_ID));
    }

    @Test
    public void connected_transitions() {
        verifyPresent(ActualActivationState.CONNECTED, ActualActivationState.FAILED, behavior -> behavior.setFailed("descr", activationManager));

        verifyAbsent(ActualActivationState.CONNECTED, NePhysicalConnectionBehavior::setConnecting);

        verifyAbsent(ActualActivationState.CONNECTED, behavior -> behavior.setConnected(activationManager, CHANNEL_ID, MEDIATOR_ID));

        verifyPresent(ActualActivationState.CONNECTED, ActualActivationState.INITIALIZING, NePhysicalConnectionBehavior::setInitializing);
        verify(notifications).notifyChanges(isA(NeInitializingEvent.class));

        verifyAbsent(ActualActivationState.CONNECTED, behavior -> behavior.setInitialized(activationManager));

        final NePhysicalConnectionMutationDescriptor result =
                verifyPresent(ActualActivationState.CONNECTED, ActualActivationState.SHUTDOWN, behavior -> behavior.shutdown(activationManager, MEDIATOR_ID));
        verify(activationManager).cancelActivations(new Deactivate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, false));
        verify(activationManager).cancelSynchronizations(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_ID, MEDIATOR_ID, false));
        verify(activationManager).scheduleDeactivation(new Deactivate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, false));
        verify(notifications).notifyChanges(isA(NeShuttingDownEvent.class));
        assertThat(result.getActivationMode(), hasValue(ActualActivationMode.STANDARD));

        verifyAbsent(ActualActivationState.CONNECTED, behavior -> behavior.setDisconnected(activationManager));

        verifyAbsent(ActualActivationState.CONNECTED, behavior -> behavior.resynchronize(activationManager, 77, 88));

        verifyPresent(ActualActivationState.CONNECTED, ActualActivationState.FAILED, behavior -> behavior.setDisconnecting(activationManager));
        verify(notifications, times(2)).notifyChanges(isA(NeActivationFailedEvent.class));
        verify(activationManager, times(2)).onNeInteractionEnded(isA(NeActivationFailedEvent.class));

        verifyAbsent(ActualActivationState.CONNECTED, behavior -> behavior.startUp(activationManager, MEDIATOR_ID));
    }

    @Test
    public void initializing_transitions() {
        NePhysicalConnectionMutationDescriptor result;

        result = verifyPresent(ActualActivationState.INITIALIZING, ActualActivationState.FAILED, behavior -> behavior.setFailed("descr", activationManager));
        verify(notifications).notifyChanges(isA(NeActivationFailedEvent.class));
        verify(activationManager).onNeInteractionEnded(isA(NeActivationFailedEvent.class));
        assertThat(result.getActivationMode(), is(Optional.of(ActualActivationMode.INIT_RECOVER)));
        assertThat(result.getInitStageStartTime(), is(present()));

        verifyAbsent(ActualActivationState.INITIALIZING, NePhysicalConnectionBehavior::setConnecting);

        verifyAbsent(ActualActivationState.INITIALIZING, behavior -> behavior.setConnected(activationManager, CHANNEL_ID, MEDIATOR_ID));

        result = verifyPresent(ActualActivationState.INITIALIZING, ActualActivationState.INITIALIZING, NePhysicalConnectionBehavior::setInitializing);
        assertThat(result.getInitStageStartTime(), is(present()));

        result = verifyPresent(ActualActivationState.INITIALIZING, ActualActivationState.INITIALIZED, behavior -> behavior.setInitialized(activationManager));
        verify(notifications).notifyChanges(isA(NeInitializedEvent.class));
        verify(activationManager).onNeInteractionEnded(isA(NeInitializedEvent.class));
        assertThat(result.getActivationMode(), hasValue(ActualActivationMode.STANDARD));
        assertThat(result.getRetryCounter(), hasValue(0));

        result = verifyPresent(ActualActivationState.INITIALIZING, ActualActivationState.SHUTDOWN, behavior -> behavior.shutdown(activationManager, MEDIATOR_ID));
        verify(activationManager).cancelActivations(new Deactivate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, false));
        //verify(activationManager).cancelSynchronizations(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_ID, MEDIATOR_ID));
        verify(activationManager).scheduleDeactivation(new Deactivate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, false));
        verify(notifications).notifyChanges(isA(NeShuttingDownEvent.class));
        assertThat(result.getActivationMode(), hasValue(ActualActivationMode.STANDARD));

        verifyAbsent(ActualActivationState.INITIALIZING, behavior -> behavior.setDisconnected(activationManager));

        verifyPresent(ActualActivationState.INITIALIZING, ActualActivationState.INITIALIZING, behavior -> behavior.resynchronize(activationManager, CHANNEL_ID, MEDIATOR_ID));
        verify(activationManager, times(2)).cancelSynchronizations(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_ID, MEDIATOR_ID, false));
        verify(notifications).notifyChanges(isA(NeInitializingEvent.class));
        verify(activationManager).scheduleSynchronization(isA(NeSynchronizationEvent.class));

        verifyAbsent(ActualActivationState.INITIALIZING, behavior -> behavior.setDisconnecting(activationManager));

        verifyAbsent(ActualActivationState.INITIALIZING, behavior -> behavior.startUp(activationManager, 88));
    }

    @Test
    public void initializing_fromConnected_setsInitTime() throws Exception {

        final NePhysicalConnectionData data = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.CONNECTED)
                .build(NE_INSTANCE_ID, NE_ID, CHANNEL_ID, 0);

        final Optional<NePhysicalConnectionMutationDescriptor> mutation =
                new NePhysicalConnectionBehavior(data, notifications).setInitializing();

        assertThat(mutation, is(present()));
        assertThat(mutation.get().getInitStageStartTime(), is(present()));
    }

    @Test
    public void initializing_fromInitializing_setsInitTime() throws Exception {

        final NePhysicalConnectionData data = new NePhysicalConnectionBuilder()
                .setActivationState(ActualActivationState.INITIALIZING)
                .build(NE_INSTANCE_ID, NE_ID, CHANNEL_ID, 0);

        final Optional<NePhysicalConnectionMutationDescriptor> mutation =
                new NePhysicalConnectionBehavior(data, notifications).setInitializing();

        assertThat(mutation, is(present()));
        assertThat(mutation.get().getInitStageStartTime(), is(present()));
    }

    @Test
    public void initialized_transitions() {
        NePhysicalConnectionMutationDescriptor result;

        result = verifyPresent(ActualActivationState.INITIALIZED, ActualActivationState.FAILED, behavior -> behavior.setFailed("descr", activationManager));
        assertThat(result.getActivationMode(), hasValue(ActualActivationMode.CONNECT_RECOVER));

        verifyAbsent(ActualActivationState.INITIALIZED, NePhysicalConnectionBehavior::setConnecting);

        verifyAbsent(ActualActivationState.INITIALIZED, behavior -> behavior.setConnected(activationManager, CHANNEL_ID, MEDIATOR_ID));

        verifyAbsent(ActualActivationState.INITIALIZED, NePhysicalConnectionBehavior::setInitializing);

        verifyAbsent(ActualActivationState.INITIALIZED, behavior -> behavior.setInitialized(activationManager));

        result = verifyPresent(ActualActivationState.INITIALIZED, ActualActivationState.SHUTDOWN, behavior -> behavior.shutdown(activationManager, MEDIATOR_ID));
        assertThat(result.getActivationMode(), hasValue(ActualActivationMode.STANDARD));

        result = verifyPresent(ActualActivationState.INITIALIZED, ActualActivationState.SHUTDOWN, behavior -> behavior.restart(activationManager, MEDIATOR_ID));
        assertThat(result.getActivationMode(), hasValue(ActualActivationMode.RESTART));
        verify(activationManager, times(2)).cancelActivations(new Deactivate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, false)); // shutdown & restart
        verify(activationManager, times(2)).cancelSynchronizations(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_ID, MEDIATOR_ID, false)); // shutdown & restart
        verify(activationManager, times(2)).scheduleDeactivation(new Deactivate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, false)); // shutdown & restart
        verify(notifications, times(2)).notifyChanges(isA(NeShuttingDownEvent.class)); // shutdown & restart

        verifyAbsent(ActualActivationState.INITIALIZED, behavior -> behavior.setDisconnected(activationManager));

        result = verifyPresent(ActualActivationState.INITIALIZED, ActualActivationState.INITIALIZING, behavior -> behavior.resynchronize(activationManager, 77, 88));
        verify(notifications).notifyChanges(isA(NeInitializingEvent.class));
        verify(activationManager).scheduleSynchronization(isA(NeSynchronizationEvent.class));
        assertThat(result.getActivationMode(), is(absent()));

        verifyAbsent(ActualActivationState.INITIALIZED, behavior -> behavior.startUp(activationManager, MEDIATOR_ID));

        result = verifyPresent(ActualActivationState.INITIALIZED, ActualActivationState.FAILED, behavior -> behavior.setDisconnecting(activationManager));
        verify(notifications, times(2)).notifyChanges(isA(NeActivationFailedEvent.class));
        verify(activationManager, times(2)).onNeInteractionEnded(isA(NeActivationFailedEvent.class));
        assertThat(result.getActivationMode(), hasValue(ActualActivationMode.CONNECT_RECOVER));
    }

    @Test
    public void disconnecting_transitions() {
        verifyAbsent(ActualActivationState.DISCONNECTING, behavior -> behavior.setFailed("descr", activationManager));

        verifyAbsent(ActualActivationState.DISCONNECTING, NePhysicalConnectionBehavior::setConnecting);

        verifyAbsent(ActualActivationState.DISCONNECTING, behavior -> behavior.setConnected(activationManager, CHANNEL_ID, MEDIATOR_ID));

        verifyAbsent(ActualActivationState.DISCONNECTING, NePhysicalConnectionBehavior::setInitializing);

        verifyAbsent(ActualActivationState.DISCONNECTING, behavior -> behavior.setInitialized(activationManager));

        verifyAbsent(ActualActivationState.DISCONNECTING, behavior -> behavior.setDisconnecting(activationManager));

        verifyPresent(ActualActivationState.DISCONNECTING, ActualActivationState.DISCONNECTED, behavior -> behavior.setDisconnected(activationManager));
        verify(notifications).notifyChanges(isA(NeDisconnectedEvent.class));
        verify(activationManager).onNeInteractionEnded(isA(NeDisconnectedEvent.class));

        verifyAbsent(ActualActivationState.DISCONNECTING, behavior -> behavior.resynchronize(activationManager, 77, 88));
    }

    @Test
    public void failed_transitions() {
        verifyPresent(ActualActivationState.FAILED, ActualActivationState.FAILED, behavior -> behavior.setFailed("new descr", activationManager));
        verify(notifications).notifyChanges(isA(NeActivationFailedEvent.class));
        verify(activationManager).onNeInteractionEnded(isA(NeActivationFailedEvent.class));

        verifyAbsent(ActualActivationState.FAILED, behavior -> behavior.setConnected(activationManager, CHANNEL_ID, MEDIATOR_ID));

        verifyPresent(ActualActivationState.FAILED, ActualActivationState.INITIALIZING, NePhysicalConnectionBehavior::setInitializing);
        verify(notifications).notifyChanges(isA(NeInitializingEvent.class));

        verifyAbsent(ActualActivationState.FAILED, behavior -> behavior.setInitialized(activationManager));

        verifyPresent(ActualActivationState.FAILED, ActualActivationState.STARTUP, behavior -> behavior.startUp(activationManager, MEDIATOR_ID));
        verify(activationManager).cancelDeactivations(new Activate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, false));
        verify(activationManager).scheduleActivation(new Activate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, false));
        verify(notifications).notifyChanges(isA(NeStartingUpEvent.class));

        verifyAbsent(ActualActivationState.FAILED, behavior -> behavior.setDisconnected(activationManager));

        verifyAbsent(ActualActivationState.FAILED, behavior -> behavior.resynchronize(activationManager, 77, 88));

        verifyPresent(ActualActivationState.FAILED, ActualActivationState.SHUTDOWN, behavior -> behavior.shutdown(activationManager, MEDIATOR_ID));
        verify(activationManager).cancelActivations(new Deactivate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, false));
        verify(activationManager, times(2)).cancelSynchronizations(new NeSynchronizationEvent(NE_ID, NE_INSTANCE_ID, CHANNEL_ID, MEDIATOR_ID, false)); // startup + shutdown
        verify(activationManager).scheduleDeactivation(new Deactivate(NE_ID, CHANNEL_ID, MEDIATOR_ID, NE_INSTANCE_ID, false));
        verify(notifications).notifyChanges(isA(NeShuttingDownEvent.class));

        verifyPresent(ActualActivationState.FAILED, ActualActivationState.CONNECTING, NePhysicalConnectionBehavior::setConnecting);
        verify(notifications).notifyChanges(isA(NeConnectingEvent.class));
        
        verifyPresent(ActualActivationState.FAILED, ActualActivationState.DISCONNECTING, behavior -> behavior.setDisconnecting(activationManager));
        verify(notifications).notifyChanges(isA(NeDisconnectingEvent.class));
        
    }

    private interface Trigger extends Function<NePhysicalConnectionBehavior, Optional<NePhysicalConnectionMutationDescriptor>> { }

    private NePhysicalConnectionMutationDescriptor verifyPresent(
            ActualActivationState actualState, ActualActivationState expectedState, Trigger triggerFunction) {
        final NePhysicalConnectionBehavior behavior = new NePhysicalConnectionBehavior(createData(actualState), notifications);

        final Optional<NePhysicalConnectionMutationDescriptor> result = triggerFunction.apply(behavior);
        assertThat(result, is(present()));
        final NePhysicalConnectionMutationDescriptor mutation = result.get();

        assertThat(mutation.apply().getActualActivationState(), is(expectedState));

        mutation.applied();

        return mutation;
    }

    private void verifyAbsent(ActualActivationState actualState, Trigger triggerFunction) {
        final NePhysicalConnectionBehavior behavior = new NePhysicalConnectionBehavior(createData(actualState), notifications);
        final Optional<NePhysicalConnectionMutationDescriptor> mutation = triggerFunction.apply(behavior);
        assertThat(mutation, not(is(present())));
    }

    private NePhysicalConnectionData createData(ActualActivationState actualState) {
        return new NePhysicalConnectionBuilder()
            .setActivationState(actualState)
            .setActivationMode(ActualActivationMode.RESTART) // choose the less used mode to force changes on mutations
            .build(NE_INSTANCE_ID, NE_ID, CHANNEL_ID, 1);
    }

}
