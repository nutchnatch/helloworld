package com.ossnms.dcn_manager.core.properties.ne;

import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationMutationDescriptor;
import com.ossnms.dcn_manager.core.test.MockFactory;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;


public class NeOperationalPropertiesTest extends PropertiesTestBase {

    private NeType type;
    private NeOperationalProperties neProperties;

    @Before
    public void setUp() {
        type = MockFactory.mockNeType();
        neProperties = new NeOperationalProperties();
    }

    @Test
    public void testSetProperty() throws InvalidMutationException {

        final NeOperationMutationDescriptor mutator = new NeOperationMutationDescriptor(new NeOperationData.NeOperationBuilder().build(NEID, VERSION));

        neProperties.setProperty(type, mutator, NeOperationalProperty.NEIGHBOURHOOD_ID, "NE NAME ON THE NETWORK");

        assertThat(mutator.getNeighbourhoodId().get(), is("NE NAME ON THE NETWORK"));
    }
}