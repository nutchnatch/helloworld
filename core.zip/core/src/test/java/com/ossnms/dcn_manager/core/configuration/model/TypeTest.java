package com.ossnms.dcn_manager.core.configuration.model;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.core.configuration.loaders.DefaultPropertyLoader;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFiles;
import com.ossnms.dcn_manager.core.jaxb.type.TypeProperties;
import org.junit.Test;

import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.emptyIterable;
import static org.hamcrest.Matchers.hasEntry;
import static org.junit.Assert.assertThat;

public class TypeTest extends TypeTestBase {

    private static class MyType extends Type {

        protected MyType(DefaultPropertyValues defaultValues) {
            super(defaultValues);
        }

        private PropertyPageFiles propertyPageFiles;
        private TypeProperties typeProperties;

        @Override
        public String getName() {
            return "";
        }

        @Override
        protected TypeProperties getSupportedTypeProperties() {
            return typeProperties;
        }

        @Override
        protected PropertyPageFiles getSupportedPropertyFiles() {
            return propertyPageFiles;
        }

        private void setSupportedPropertyPageFiles(PropertyPageFiles propertyPageFiles) {
            this.propertyPageFiles = propertyPageFiles;
        }

        private void setSupportedTypeProperties(TypeProperties typeProperties) {
            this.typeProperties = typeProperties;
        }

    }

    @Test
    public void testTypePropertiesAbsent() {

        final MyType type = new MyType(null);

        assertThat(type.getGuiLabelLong(), is(nullValue()));
        assertThat(type.getGuiLabelShort(), is(nullValue()));
        assertThat(type.getTypeProperties().values(), is(emptyIterable()));
    }

    @Test
    public void testTypePropertiesEmpty() {

        final MyType type = new MyType(null);
        type.setSupportedTypeProperties(new TypeProperties());

        assertThat(type.getGuiLabelLong(), is(nullValue()));
        assertThat(type.getGuiLabelShort(), is(nullValue()));
        assertThat(type.getTypeProperties().values(), is(emptyIterable()));
    }

    @Test
    public void testTypeProperties() {

        final MyType type = new MyType(null);
        type.setSupportedTypeProperties(buildTypeProperties(
                "GUI_LABEL_SHORT", "UNO 1.0 NE",
                "GUI_LABEL_LONG", "UNO 1.0 Network Element",
                "blah", "bleh"
            ));

        assertThat(type.getGuiLabelLong(), is("UNO 1.0 Network Element"));
        assertThat(type.getGuiLabelShort(), is("UNO 1.0 NE"));

        assertThat(type.getTypeProperties(), hasEntry("GUI_LABEL_SHORT", "UNO 1.0 NE"));
        assertThat(type.getTypeProperties(), hasEntry("GUI_LABEL_LONG", "UNO 1.0 Network Element"));
        assertThat(type.getTypeProperties(), hasEntry("blah", "bleh"));
    }

    @Test
    public void testDefaultPropertyValues() {
        final ClassLoader classLoader = getClass().getClassLoader();
        final DefaultPropertyValues defaultPropertyValues = new DefaultPropertyLoader().load(ImmutableList.of(
                    classLoader.getResource("defaultproperties/AnotherDefaultsLoadTest.xml"),
                    classLoader.getResource("defaultproperties/DefaultsLoadTest.xml")
                ));

        final MyType type = new MyType(defaultPropertyValues);
        type.setSupportedPropertyPageFiles(buildPropertyPageFiles("DefaultsLoadTest", "AnotherDefaultsLoadTest"));

        final Map<String, String> defaults = type.getSupportedPropertyDefaultValues();

        assertThat(defaults, allOf(
                hasEntry("Enable_Scaled_Startup", "true"), hasEntry("SwitchBackTime", "600"), hasEntry("Computer_Name", "127.0.0.1")));
    }

}
