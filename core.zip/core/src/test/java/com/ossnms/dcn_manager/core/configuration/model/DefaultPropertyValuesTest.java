package com.ossnms.dcn_manager.core.configuration.model;

import com.google.common.collect.ImmutableList;
import com.ossnms.dcn_manager.core.configuration.loaders.DefaultPropertyLoader;
import com.ossnms.dcn_manager.core.jaxb.defaultproperties.Default;
import org.junit.Test;

import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.hasKey;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

public class DefaultPropertyValuesTest {

    private static final ClassLoader CLASS_LOADER = DefaultPropertyValuesTest.class.getClassLoader();
    private static final String DEFAULTS_LOAD_TEST_XML = "DefaultsLoadTest";
    private static final String OTHER_DEFAULTS_LOAD_TEST_XML = "AnotherDefaultsLoadTest";

    private static final Iterable<URL> FILES =
            ImmutableList.of(
                    CLASS_LOADER.getResource("defaultproperties/" + DEFAULTS_LOAD_TEST_XML + ".xml"),
                    CLASS_LOADER.getResource("defaultproperties/" + OTHER_DEFAULTS_LOAD_TEST_XML + ".xml"));

    @Test
    public void testLoading() {
        final DefaultPropertyValues defaultPropertyValues = new DefaultPropertyLoader().load(FILES);

        assertThat(defaultPropertyValues, allOf(hasKey(DEFAULTS_LOAD_TEST_XML), hasKey(OTHER_DEFAULTS_LOAD_TEST_XML)));

        List<Default> defaults = defaultPropertyValues.get(DEFAULTS_LOAD_TEST_XML).getDefault();
        assertDefaultValues(defaults.get(0), "Enable_Scaled_Startup", "true");
        assertDefaultValues(defaults.get(1), "SwitchBackTime", "600");

        defaults = defaultPropertyValues.get(OTHER_DEFAULTS_LOAD_TEST_XML).getDefault();
        assertDefaultValues(defaults.get(0), "Computer_Name", "127.0.0.1");
    }

    @Test
    public void testMerging() {
        final DefaultPropertyValues defaultPropertyValues = new DefaultPropertyLoader().load(FILES);

        final Map<String, String> defaults =
                defaultPropertyValues.getAllDefaults(ImmutableList.of(DEFAULTS_LOAD_TEST_XML, OTHER_DEFAULTS_LOAD_TEST_XML));

        assertThat(defaults, allOf(
            hasEntry("Enable_Scaled_Startup", "true"), hasEntry("SwitchBackTime", "600"), hasEntry("Computer_Name", "127.0.0.1")));
    }

    private void assertDefaultValues(Default def, String key, String value) {
        assertTrue(Objects.equals(def.getKey(), key));
        assertTrue(Objects.equals(def.getValue(), value));
    }
}
