package com.ossnms.dcn_manager.core.configuration.model;

import com.google.common.collect.ImmutableSet;
import com.ossnms.dcn_manager.core.configuration.loaders.TypeLoaderMediator;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collection;
import java.util.Collections;
import java.util.Map.Entry;
import java.util.Set;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.hasItem;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class MediatorTypesTest {

    private DefaultPropertyValues defaultValues;
    private Types<ChannelType> channelTypes;

    @Before
    public void setUp() {
        defaultValues = mock(DefaultPropertyValues.class);
        channelTypes = mock(Types.class);
    }

    @Test
    public void testLoading() {

        final Entry<String, ChannelType> entrySomething = buildEntry("UNO");
        final Set<Entry<String, ChannelType>> entrySet = ImmutableSet.of(buildEntry("EM-BLAH"), entrySomething);
        when(channelTypes.entrySet()).thenReturn(entrySet);

        final ClassLoader classLoader = getClass().getClassLoader();
        final Types<MediatorType> types =  new TypeLoaderMediator(channelTypes, defaultValues).load(Collections.singleton(classLoader.getResource("mediatortype/MediatorTypeLoadTest.xml")));

        assertFalse(types.isEmpty());
        assertTrue(types.containsKey("UNO"));

        final MediatorType mediatorType = types.get("UNO");
        assertThat(mediatorType.getName(), is("UNO"));

        final Collection<ChannelType> supportedChannelTypes = mediatorType.getSupportedChannelTypes();
        assertThat(supportedChannelTypes, is(Matchers.<ChannelType>iterableWithSize(1)));
        assertThat(supportedChannelTypes, hasItem(entrySomething.getValue()));
    }

    private Entry<String, ChannelType> buildEntry(final String name) {
        return new Entry<String, ChannelType>() {
            private final ChannelType type = mock(ChannelType.class);
            @Override
            public String getKey() {
                return name;
            }
            @Override
            public ChannelType getValue() {
                return type;
            }
            @Override
            public ChannelType setValue(ChannelType value) {
                return null;
            }

        };
    }

    @Test
    public void testLoadingBadURL() throws MalformedURLException {
        final Types<MediatorType> types = new TypeLoaderMediator(channelTypes, defaultValues).load(Collections.singleton(new URL("file:///xpto")));
        assertTrue(types.isEmpty());
    }

}
