package com.ossnms.dcn_manager.core.utils.matchers;

import org.hamcrest.Factory;
import org.hamcrest.Matcher;

import com.ossnms.dcn_manager.core.entities.BusinessObjectData;

/**
 * <p>Convenience class that aggregates factory methods for the custom Matchers used 
 * in the core module unit tests. </p>
 */
public class Matchers {

	@Factory
	public static <T extends BusinessObjectData> Matcher<T> mutationOf(T argument) { 
		return new MutationOf<>(argument);
	}
}
