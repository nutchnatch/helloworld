package com.ossnms.dcn_manager.core.entities.channel.behavior;

import com.ossnms.dcn_manager.core.entities.channel.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent.ChannelDeactivatingEvent;
import com.ossnms.dcn_manager.core.events.channel.ChannelEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent;
import com.ossnms.dcn_manager.core.events.ne.NeEvent;
import com.ossnms.dcn_manager.core.outbound.ChannelNotifications;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import org.junit.Before;
import org.junit.Test;

import java.util.Collection;
import java.util.Collections;

import static com.ossnms.dcn_manager.test.util.OtherMatchers.absent;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

public class ChannelConnectionBehaviorTest {

    private static final int CHANNEL_ID = 67;
    private static final int NE_ID = 12;

    private ChannelInteractionManager activationManager;
    private ChannelNotifications notifications;
    private MessageSource<NeEvent> neEventSource;

    private final Collection<Integer> childNesForActuation =
            Collections.singleton(NE_ID);

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() {
        notifications = mock(ChannelNotifications.class);
        activationManager = mock(ChannelInteractionManager.class);
        neEventSource = mock(MessageSource.class);
    }

    private ChannelConnectionData newData(ActualActivationState state) {
        return new ChannelConnectionBuilder()
            .setActivation(state)
            .setAdditionalInfo("")
            .build(CHANNEL_ID, 0);
    }

    @Test
    public void testInactive() {
        final ChannelConnectionData state = newData(ActualActivationState.INACTIVE);
        final ChannelConnectionBehavior behavior = new ChannelConnectionBehavior(state, notifications);

        verifyCreating(behavior);
        assertThat(behavior.setActivating(), is(absent()));
        assertThat(behavior.setActive(activationManager), is(absent()));
        assertThat(behavior.setDeactivating(), is(absent()));
        assertThat(behavior.setInactive(activationManager, neEventSource), is(absent()));
        assertThat(behavior.setFailed(activationManager, neEventSource, Collections.emptyList(), ""), is(absent()));
    }

    @Test(expected=IllegalStateException.class)
    public void testStartingUp() {
        new ChannelConnectionBehavior(newData(ActualActivationState.STARTINGUP), notifications);
    }

    @Test
    public void testCreating() {
        final ChannelConnectionData state = newData(ActualActivationState.CREATING);
        final ChannelConnectionBehavior behavior = new ChannelConnectionBehavior(state, notifications);

        assertThat(behavior.setCreating(), is(absent()));
        assertThat(behavior.setActivating(), is(absent()));
        assertThat(behavior.setActive(activationManager), is(absent()));

        // verify created
        final ChannelConnectionMutationDescriptor mutation = behavior.setCreated(activationManager).get();
        final ChannelActivatedEvent event = new ChannelActivatedEvent(CHANNEL_ID);
        verifyMutation(mutation, ActualActivationState.ACTIVE, event);
        verify(notifications).notifyChanges(event);
        verify(activationManager).onChannelInteractionEnded(event);

        assertThat(behavior.setDeactivating(), is(absent()));
        assertThat(behavior.setInactive(activationManager, neEventSource), is(absent()));
        verifyFailure(behavior);
    }

    @Test
    public void testActivating() {
        final ChannelConnectionData state = newData(ActualActivationState.ACTIVATING);
        final ChannelConnectionBehavior behavior = new ChannelConnectionBehavior(state, notifications);

        assertThat(behavior.setCreating(), is(absent()));
        assertThat(behavior.setActivating(), is(absent()));
        verifyActive(behavior);
        verifyDeactivating(behavior);
        assertThat(behavior.setInactive(activationManager, neEventSource), is(absent()));
        verifyFailure(behavior);
    }

    @Test
    public void testActive() {
        final ChannelConnectionData state = newData(ActualActivationState.ACTIVE);
        final ChannelConnectionBehavior behavior = new ChannelConnectionBehavior(state, notifications);

        assertThat(behavior.setCreating(), is(absent()));
        assertThat(behavior.setActivating(), is(absent()));
        assertThat(behavior.setActive(activationManager), is(absent()));
        verifyDeactivating(behavior);
        assertThat(behavior.setInactive(activationManager, neEventSource), is(absent()));
        verifyFailure(behavior);
    }

    @Test(expected=IllegalStateException.class)
    public void testShuttingDown() {
        new ChannelConnectionBehavior(newData(ActualActivationState.SHUTTINGDOWN), notifications);
    }

    @Test
    public void testDeactivating() {
        final ChannelConnectionData state = newData(ActualActivationState.DEACTIVATING);
        final ChannelConnectionBehavior behavior = new ChannelConnectionBehavior(state, notifications);

        assertThat(behavior.setCreating(), is(absent()));
        assertThat(behavior.setActivating(), is(absent()));
        assertThat(behavior.setActive(activationManager), is(absent()));
        assertThat(behavior.setDeactivating(), is(absent()));
        verifyInactive(behavior);
        verifyFailure(behavior);
    }

    @Test
    public void testFailed() {
        final ChannelConnectionData state = newData(ActualActivationState.FAILED);
        final ChannelConnectionBehavior behavior = new ChannelConnectionBehavior(state, notifications);

        final ChannelActivatingEvent event = new ChannelActivatingEvent(CHANNEL_ID);
        verifyMutation(behavior.setCreating().get(), ActualActivationState.CREATING, event);
        verifyMutation(behavior.setActivating().get(), ActualActivationState.ACTIVATING, event);
        verify(notifications, times(2)).notifyChanges(event); // creating + activating

        assertThat(behavior.setActive(activationManager), is(absent()));
        verifyDeactivating(behavior);
        assertThat(behavior.setInactive(activationManager, neEventSource), is(absent()));
        verifyFailure(behavior);
    }

    private void verifyCreating(ChannelConnectionBehavior behavior) {
        final ChannelConnectionMutationDescriptor mutation = behavior.setCreating().get();
        verifyMutation(mutation, ActualActivationState.CREATING);
        verify(notifications).notifyChanges(new ChannelActivatingEvent(mutation.getTarget().getId()));
    }

    private void verifyActivating(ChannelConnectionBehavior behavior) {
        final ChannelConnectionMutationDescriptor mutation =
            behavior.setActivating().get();
        final ChannelActivatingEvent event = new ChannelActivatingEvent(mutation.getTarget().getId());
        verifyMutation(mutation, ActualActivationState.ACTIVATING, event);
        verify(notifications).notifyChanges(event);
    }

    private void verifyActive(ChannelConnectionBehavior behavior) {
        final ChannelConnectionMutationDescriptor mutation =
            behavior.setActive(activationManager).get();
        final ChannelActivatedEvent event = new ChannelActivatedEvent(mutation.getTarget().getId());
        verifyMutation(mutation, ActualActivationState.ACTIVE, event);
        verify(notifications).notifyChanges(event);
        verify(activationManager).onChannelInteractionEnded(event);
    }

    private void verifyDeactivating(ChannelConnectionBehavior behavior) {
        final ChannelConnectionMutationDescriptor mutation =
            behavior.setDeactivating().get();
        final ChannelDeactivatingEvent event = new ChannelDeactivatingEvent(mutation.getTarget().getId());
        verifyMutation(mutation, ActualActivationState.DEACTIVATING, event);
        verify(notifications).notifyChanges(event);
    }

    private void verifyInactive(ChannelConnectionBehavior behavior) {
        final ChannelConnectionMutationDescriptor mutation =
                behavior.setInactive(activationManager, neEventSource).get();
        final ChannelDeactivatedEvent event = new ChannelDeactivatedEvent(mutation.getTarget().getId());
        verifyMutation(mutation, ActualActivationState.INACTIVE, event);
        verify(notifications).notifyChanges(event);
        verify(activationManager).onChannelInteractionEnded(event);
        verify(neEventSource, never()).push(isA(ActualNeStateEvent.NeDisconnectedEvent.class));
    }

    private void verifyMutation(ChannelConnectionMutationDescriptor mutation, ActualActivationState desiredState,
            ChannelEvent event) {
        assertThat(mutation.getActualActivationState().get(), is(desiredState));
        assertThat(mutation.getAdditionalInfo().get(), is(event.getDetailedDescription()));
        mutation.apply();
        mutation.applied();
    }

    private void verifyMutation(ChannelConnectionMutationDescriptor mutation, ActualActivationState desiredState) {
        assertThat(mutation.getActualActivationState().get(), is(desiredState));
        mutation.apply();
        mutation.applied();
    }

    private void verifyFailure(ChannelConnectionBehavior behavior) {
        final ChannelConnectionMutationDescriptor mutation =
                behavior.setFailed(activationManager, neEventSource, childNesForActuation, "descr").get();
        assertThat(mutation.getAdditionalInfo().get(), is("descr"));
        final ChannelActivationFailedEvent event = new ChannelActivationFailedEvent(mutation.getTarget().getId(),
                mutation.getAdditionalInfo().get());
        verifyMutation(mutation, ActualActivationState.FAILED, event);
        verify(notifications).notifyChanges(event);
        verify(activationManager).onChannelInteractionEnded(event);
        verify(neEventSource).push(isA(ActualNeStateEvent.NeActivationFailedEvent.class));
    }
}
