package com.ossnms.dcn_manager.core.entities;

import com.ossnms.dcn_manager.core.entities.emne.DiscoveryPolicy;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettingsMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.emne.SettingsProperties;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import org.junit.Before;
import org.junit.Test;

import java.util.Map;

import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

public class SettingsPropertiesTest {

    private static final int ID = 23;
    private static final int VERSION = 1;

    private GlobalSettings settings;

    @Before
    public void setUp() {
        settings = GlobalSettings.build()
                    .setMediatorRetries(1)
                    .setChannelRetries(2)
                    .setNeRetries(3)
                    .setRetryInterval(4)
                    .setScaledStartupLimit(5)
                    .setDiscoveryPolicy(DiscoveryPolicy.DISCOVER_ALL_NETWORK)
                    .setEnableScheduledStartup(true)
                    .setShowNativeNeNaming(true)
                    .toGlobalSettings(ID, VERSION);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testGetProperties() {
        final Map<String, String> properties = SettingsProperties.getProperties(settings);
        assertThat(properties, allOf(
                hasEntry(SettingsProperties.RETRY_MEDIATOR.getName(), "1"),
                hasEntry(SettingsProperties.RETRY_CHANNEL.getName(), "2"),
                hasEntry(SettingsProperties.RETRY_NE.getName(), "3"),
                hasEntry(SettingsProperties.RETRY_INTERVAL.getName(), "4"),
                hasEntry(SettingsProperties.SCALED_STARTUP_LIMIT.getName(), "5"),
                hasEntry(SettingsProperties.DISCOVERY_POLICY.getName(), DiscoveryPolicy.DISCOVER_ALL_NETWORK.toString()),
                hasEntry(SettingsProperties.ENABLE_SCHEDULED_STARTUP.getName(), "true"),
                hasEntry(SettingsProperties.ENABLE_NATIVE_NE_NAMING.getName(), "true")
            ));
    }

    @Test
    public void testGetProperty() {
        assertThat(SettingsProperties.getProperty(settings, SettingsProperties.RETRY_MEDIATOR.getName()).get(), is("1"));
        assertThat(SettingsProperties.getProperty(settings, "blah").isPresent(), is(false));
    }

    @Test
    public void testGetPropertyValue() {
        assertThat(SettingsProperties.RETRY_NE.getPropertyValue(settings).get(), is("3"));
    }

    @Test(expected=InvalidMutationException.class)
    public void testSetNullDiscoveryPolicyProperty() throws InvalidMutationException {
        final GlobalSettingsMutationDescriptor mutation = new GlobalSettingsMutationDescriptor(settings);
        SettingsProperties.setProperty(mutation, SettingsProperties.DISCOVERY_POLICY.getName(), null);
    }

    @Test(expected=InvalidMutationException.class)
    public void testSetInvalidDiscoveryPolicyProperty() throws InvalidMutationException {
        final GlobalSettingsMutationDescriptor mutation = new GlobalSettingsMutationDescriptor(settings);
        SettingsProperties.setProperty(mutation, SettingsProperties.DISCOVERY_POLICY.getName(), "xpto");
    }

    @Test(expected=InvalidMutationException.class)
    public void testSetUnknownProperty() throws InvalidMutationException {
        final GlobalSettingsMutationDescriptor mutation = new GlobalSettingsMutationDescriptor(settings);
        SettingsProperties.setProperty(mutation, "blah", "xpto");
    }

    @Test
    public void testSetProperty() throws InvalidMutationException {
        final GlobalSettingsMutationDescriptor mutation = new GlobalSettingsMutationDescriptor(settings);
        SettingsProperties.setProperty(mutation, SettingsProperties.RETRY_MEDIATOR.getName(), "89");
        SettingsProperties.setProperty(mutation, SettingsProperties.RETRY_CHANNEL.getName(), "79");
        SettingsProperties.setProperty(mutation, SettingsProperties.RETRY_NE.getName(), "69");
        SettingsProperties.setProperty(mutation, SettingsProperties.RETRY_INTERVAL.getName(), "49");
        SettingsProperties.setProperty(mutation, SettingsProperties.SCALED_STARTUP_LIMIT.getName(), "98");
        SettingsProperties.setProperty(mutation, SettingsProperties.DISCOVERY_POLICY.getName(), DiscoveryPolicy.NO_DISCOVERY.toString());
        SettingsProperties.setProperty(mutation, SettingsProperties.ENABLE_SCHEDULED_STARTUP.getName(), "false");
        SettingsProperties.setProperty(mutation, SettingsProperties.ENABLE_NATIVE_NE_NAMING.getName(), "false");

        assertThat(mutation.getMediatorRetries().get(), is(89));
        assertThat(mutation.getChannelRetries().get(), is(79));
        assertThat(mutation.getNeRetries().get(), is(69));
        assertThat(mutation.getRetryInterval().get(), is(49));
        assertThat(mutation.getScaledStartupLimit().get(), is(98));
        assertThat(mutation.getDiscoveryPolicy().get(), is(DiscoveryPolicy.NO_DISCOVERY));
        assertThat(mutation.getEnableScheduledStartup().get(), is(false));
        assertThat(mutation.getShowNativeNeNaming().get(), is(false));
    }

    @Test(expected=InvalidMutationException.class)
    public void testSetInvalidPropertyValue() throws InvalidMutationException {
        final GlobalSettingsMutationDescriptor mutation = new GlobalSettingsMutationDescriptor(settings);
        SettingsProperties.setProperty(mutation, SettingsProperties.RETRY_MEDIATOR.getName(), "xyxyxyxy");
    }

    @Test
    public void testSetPropertyValue() throws InvalidMutationException {
        final GlobalSettingsMutationDescriptor mutation = new GlobalSettingsMutationDescriptor(settings);
        SettingsProperties.RETRY_INTERVAL.setPropertyValue(mutation, "98");
        assertThat(mutation.getRetryInterval().get(), is(98));
    }

    @Test(expected=InvalidMutationException.class)
    public void testSetPropertyValueError() throws InvalidMutationException {
        final GlobalSettingsMutationDescriptor mutation = new GlobalSettingsMutationDescriptor(settings);
        SettingsProperties.RETRY_MEDIATOR.setPropertyValue(mutation, "xyxyxyxy");
    }

    @Test
    public void testToString() {
        assertThat(SettingsProperties.RETRY_MEDIATOR.toString(), not(nullValue()));
    }
}
