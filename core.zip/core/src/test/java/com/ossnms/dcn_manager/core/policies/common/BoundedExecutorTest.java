package com.ossnms.dcn_manager.core.policies.common;

import com.ossnms.dcn_manager.core.policies.common.BoundedExecutor.Signaller;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class BoundedExecutorTest {


    private PolicyJob<?> workItem;
    private BoundedExecutor<PolicyJob<?>> boundedExecutor;
    private Executor executor;

    private static final int UPPER_BOUND = 4;

    @Before
    public void setUp() {
        workItem = mock(PolicyJob.class);
        executor = mock(Executor.class);

        doAnswer(invocation -> {
            ((Runnable) invocation.getArguments()[0]).run();
            return null;
        }).when(executor).execute(any(Runnable.class));

        boundedExecutor = new BoundedExecutor<>("TEST", executor, UPPER_BOUND);
    }

    @Test(expected=IllegalArgumentException.class)
    public void instantiation_withNonPositiveMaxWorkItems_throwsException() {
        new BoundedExecutor<>("TEST", executor, -1);
    }

    @Test(expected=IllegalArgumentException.class)
    public void upperBoundConfiguration_withNonPositiveMaxWorkItems_throwsException() {
        boundedExecutor.setMaxWorkItemCount(-1);
    }

    @Test
    public void trySubmit_whenSubmittedWorkIsBelowUpperBound_executesWork() {

        final boolean accepted = boundedExecutor.trySubmitWorkItem(workItem);

        assertTrue(accepted);
        assertThat(boundedExecutor.getWorkItemCount(), is(equalTo(1)));
        verify(workItem, times(1)).run();
    }

    @Test
    public void trySubmit_whenSubmittedWorkIsBelowUpperBound_andExecutorRejectsWork_rejectsWork() {

        doThrow(new RejectedExecutionException()).when(executor).execute(any(Runnable.class));
        final boolean accepted = boundedExecutor.trySubmitWorkItem(workItem);

        assertFalse(accepted);
        assertThat(boundedExecutor.getWorkItemCount(), is(equalTo(0)));
        verify(workItem, never()).run();
    }

    @Test
    public void trySubmit_whenSubmittedWorkIsEqualToUpperBound_rejectsWork() {

        // Fill executor capacity
        for(int count = 0; count < UPPER_BOUND; ++count) {
            boundedExecutor.trySubmitWorkItem(workItem);
        }

        final boolean accepted = boundedExecutor.trySubmitWorkItem(workItem);

        assertFalse(accepted);
        assertThat(boundedExecutor.getWorkItemCount(), is(equalTo(UPPER_BOUND)));
        verify(workItem, times(UPPER_BOUND)).run();
    }

    @Test
    public void trySubmit_whenSubmittedWorkIsEqualToUpperBound_runsHighPriorityWork() {

        // Fill executor capacity
        for(int count = 0; count < UPPER_BOUND; ++count) {
            boundedExecutor.trySubmitWorkItem(workItem);
        }

        when(workItem.getPriority()).thenReturn(PolicyJob.Priority.HIGH);
        final boolean accepted = boundedExecutor.trySubmitWorkItem(workItem);

        assertTrue(accepted);
        assertThat(boundedExecutor.getWorkItemCount(), is(equalTo(UPPER_BOUND + 1)));
        verify(workItem, times(UPPER_BOUND + 1)).run();
    }

    @Test
    public void signalWorkCompletion_withAMatchingSelector_decrementsWorkCount() {

        // Fill executor capacity
        for(int count = 0; count < UPPER_BOUND; ++count) {
            boundedExecutor.trySubmitWorkItem(workItem);
        }

        final Optional<?> workItem = boundedExecutor.signalWorkItemCompletion(input -> {
            return true; // Any work item suits our purpose
        });

        assertThat(boundedExecutor.getWorkItemCount(), is(equalTo(UPPER_BOUND-1)));
        assertTrue(workItem.isPresent());
    }

    @Test
    public void signalWorkCompletion_withANonMatchingSelector_doesNotDecrementWorkCount() {

        // Fill executor capacity
        for(int count = 0; count < UPPER_BOUND; ++count) {
            boundedExecutor.trySubmitWorkItem(workItem);
        }

        final Optional<?> workItem = boundedExecutor.signalWorkItemCompletion(input -> {
            return false; // None of the work items suits us
        });

        assertThat(boundedExecutor.getWorkItemCount(), is(equalTo(UPPER_BOUND)));
        assertFalse(workItem.isPresent());
    }

    @Test
    public void signalWorkCancellation_withAMatchingSelector_cancelsAndDecrementsWorkCount() {

        // Fill executor capacity
        for(int count = 0; count < UPPER_BOUND; ++count) {
            boundedExecutor.trySubmitWorkItem(workItem);
        }

        boundedExecutor.signalWorkItemCancellation(i -> true);

        assertThat(boundedExecutor.getWorkItemCount(), is(0));

        verify(workItem, times(UPPER_BOUND)).cancel();
    }

    @Test
    public void signalWorkCancellation_withANonMatchingSelector_doesNotCancelAndDecrementWorkCount() {

        // Fill executor capacity
        for(int count = 0; count < UPPER_BOUND; ++count) {
            boundedExecutor.trySubmitWorkItem(workItem);
        }

        boundedExecutor.signalWorkItemCancellation(i -> false);

        assertThat(boundedExecutor.getWorkItemCount(), is(UPPER_BOUND));

        verify(workItem, never()).cancel();
    }

    @Test
    public void signalWorkItem_callsSignalOnItemFoundAndSubmitsReturnedCode() {
        @SuppressWarnings("unchecked")
        final Signaller<PolicyJob<?>> signaller = mock(Signaller.class);
        final Runnable additionalWork = mock(Runnable.class);

        boundedExecutor.trySubmitWorkItem(workItem);

        when(signaller.select(workItem)).thenReturn(true);
        when(signaller.signal(workItem)).thenReturn(Optional.of(additionalWork));

        final boolean signalled = boundedExecutor.signalWorkItem(signaller);

        assertThat(signalled, is(true));
        verify(executor).execute(additionalWork);
    }

    @Test
    public void signalWorkItem_noItemsRunning_returnsFalse() throws Exception {
        @SuppressWarnings("unchecked")
        final Signaller<PolicyJob<?>> signaller = mock(Signaller.class);

        final boolean signalled = boundedExecutor.signalWorkItem(signaller);
        assertThat(signalled, is(false));
    }

    @Test
    public void signalWorkItem_noItemsMatched_returnsFalse() throws Exception {
        @SuppressWarnings("unchecked")
        final Signaller<PolicyJob<?>> signaller = mock(Signaller.class);

        boundedExecutor.trySubmitWorkItem(workItem);

        final boolean signalled = boundedExecutor.signalWorkItem(signaller);
        assertThat(signalled, is(false));
    }

    @Test
    public void setMaxWorkItemCount_withHigherValueThanCurrent_increasesCapacity() {

        // Fill executor capacity
        for(int count = 0; count < UPPER_BOUND; ++count) {
            boundedExecutor.trySubmitWorkItem(workItem);
        }

        boundedExecutor.setMaxWorkItemCount(UPPER_BOUND + 1);
        assertThat(boundedExecutor.getMaxWorkItemCount(), is(equalTo(UPPER_BOUND + 1)));
        assertThat(boundedExecutor.getWorkItemCount(), is(equalTo(UPPER_BOUND)));

        final boolean extraAccepted = boundedExecutor.trySubmitWorkItem(workItem);
        assertTrue(extraAccepted);
        assertThat(boundedExecutor.getWorkItemCount(), is(equalTo(UPPER_BOUND + 1)));
        verify(workItem, times(UPPER_BOUND + 1)).run();
    }
}
