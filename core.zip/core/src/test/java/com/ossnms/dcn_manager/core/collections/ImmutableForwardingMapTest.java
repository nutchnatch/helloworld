package com.ossnms.dcn_manager.core.collections;

import java.util.Map;

import org.junit.Test;

import com.ossnms.dcn_manager.core.collections.ImmutableForwardingMap;

public class ImmutableForwardingMapTest {

    private final ImmutableForwardingMap<Object, Object> map = new ImmutableForwardingMap<Object, Object>() {      
        @Override
        protected Map<Object, Object> delegate() {
            return null;
        }
    };
    
    @Test(expected=UnsupportedOperationException.class)
    public void testPutImmutability() {
        map.put(null, null);
    }
    
    @Test(expected=UnsupportedOperationException.class)
    public void testPutAllImmutability() {
        map.putAll(null);
    }
    
    @Test(expected=UnsupportedOperationException.class)
    public void testRemoveImmutability() {
        map.remove(null);
    }

}
