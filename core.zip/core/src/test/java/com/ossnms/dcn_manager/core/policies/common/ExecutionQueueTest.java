package com.ossnms.dcn_manager.core.policies.common;

import org.junit.Before;
import org.junit.Test;

import java.util.Optional;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.function.Function;
import java.util.function.Predicate;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;

public class ExecutionQueueTest {

    private Executor executionPolicy;
    private PolicyJob<?> workItem;
    private ExecutionQueue<PolicyJob<?>> workExecutionQueue;

    private static final int WORK_COUNT_UPPER_BOUND = 4;
    private static final int PENDING_WORK_COUNT = 6;

    private Predicate<PolicyJob<?>> cancelationSelectorNone;
    private Predicate<PolicyJob<?>> completionSelectorAny;
    private Function<Predicate<PolicyJob<?>>, Optional<PolicyJob<?>>> workSupplier;

    private void scheduleWorkItems(int count) {
        while(count-- != 0) {
            workExecutionQueue.scheduleWorkItem(workItem, cancelationSelectorNone);
        }
    }

    @SuppressWarnings("unchecked")
    @Before
    public void setUp() {
        executionPolicy = mock(Executor.class);
        workItem = mock(PolicyJob.class);
        workSupplier = mock(Function.class);

        doAnswer(invocation -> {
            ((Runnable) invocation.getArguments()[0]).run();
            return null;
        }).when(executionPolicy).execute(any(Runnable.class));

        workExecutionQueue = new ExecutionQueue<>(WORK_COUNT_UPPER_BOUND, "TEST", executionPolicy, workSupplier);

        cancelationSelectorNone = input -> false;

        completionSelectorAny = input -> true;
    }

    @Test
    public void scheduleWorkItem_whenUpperBoundNotReached_executesWork() {
        final int COUNT = 1;
        scheduleWorkItems(COUNT);
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(equalTo(COUNT)));
        verify(workItem, times(COUNT)).run();
    }

    @Test
    public void scheduleWorkItem_whenUpperBoundReached_retainsItem() {

        // Fill executor capacity
        scheduleWorkItems(WORK_COUNT_UPPER_BOUND);

        // Throw in additional work
        scheduleWorkItems(PENDING_WORK_COUNT);

        // Verify behavior
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(equalTo(WORK_COUNT_UPPER_BOUND)));
        verify(workItem, times(WORK_COUNT_UPPER_BOUND)).run();
        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(equalTo(PENDING_WORK_COUNT)));
    }

    @Test
    public void scheduleWorkItem_withCancellation_whenRetainedWorkItemsExist_cancelsAndRemovesOneRetained() {
        // Fill executor capacity
        scheduleWorkItems(WORK_COUNT_UPPER_BOUND);
        // Throw in additional work
        scheduleWorkItems(PENDING_WORK_COUNT);

        // Signal cancellation
        workExecutionQueue.scheduleWorkItem(workItem, completionSelectorAny);
            // (this means that the item being scheduled may cancel *one* pending item)

        // Verify behavior
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(equalTo(WORK_COUNT_UPPER_BOUND)));
        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(equalTo(PENDING_WORK_COUNT - 1)));
        verify(workItem).cancel(); // items are removed from queue and cancelled in case a race condition executes them
    }

    @Test
    public void signalWorkItemCompletion_whenRetainedWorkItemsExist_dispatchesRetainedWorkExecution() {
        // Fill executor capacity
        scheduleWorkItems(WORK_COUNT_UPPER_BOUND);

        // Throw in additional work
        scheduleWorkItems(PENDING_WORK_COUNT);
        // Signal completion
        workExecutionQueue.signalWorkItemCompletion(completionSelectorAny);
        // Verify behavior
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(equalTo(WORK_COUNT_UPPER_BOUND)));
        verify(workItem, times(WORK_COUNT_UPPER_BOUND + 1)).run();
        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(equalTo(PENDING_WORK_COUNT - 1)));
    }

    @Test
    public void signalCapacityAvailable_whenNoHighPriorityRetainedWorkItemsExist_doesNotDisptachRetainedWorkExecution() {
        // Fill executor capacity
        scheduleWorkItems(WORK_COUNT_UPPER_BOUND);

        // Throw in additional work
        scheduleWorkItems(1);
        // Signal capacity available
        workExecutionQueue.signalCapacityIsAvailable();
        // Verify behavior
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(equalTo(WORK_COUNT_UPPER_BOUND)));
        verify(workItem, times(WORK_COUNT_UPPER_BOUND)).run();
        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(equalTo(1)));
    }

    @Test
    public void signalCapacityAvailable_whenHighPriorityRetainedWorkItemsExist_disptachesRetainedWorkExecution() {

        final PolicyJob<?> highPriorityJob = mock(PolicyJob.class);
        when(highPriorityJob.getPriority()).thenReturn(PolicyJob.Priority.HIGH);

        // Fill executor capacity
        doThrow(new RejectedExecutionException()).when(executionPolicy).execute(highPriorityJob);
        scheduleWorkItems(WORK_COUNT_UPPER_BOUND);

        // Throw in additional work
        workExecutionQueue.scheduleWorkItem(highPriorityJob, cancelationSelectorNone);
        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(equalTo(1)));

        // Signal capacity available
        doAnswer(invocation -> {
            if (invocation != null)
                ((PolicyJob<?>)invocation.getArguments()[0]).run();
            return null;
        }).when(executionPolicy).execute(highPriorityJob);
        workExecutionQueue.signalCapacityIsAvailable();

        // Verify behavior
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(equalTo(WORK_COUNT_UPPER_BOUND + 1)));
        verify(workItem, times(WORK_COUNT_UPPER_BOUND)).run();
        verify(highPriorityJob).run();
        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(equalTo(0)));
    }

    @Test
    public void signalWorkItemCancellation_whenRetainedWorkItemsExist_cancelsAndRemoves() {
        // Fill executor capacity
        scheduleWorkItems(WORK_COUNT_UPPER_BOUND);
        // Throw in additional work
        scheduleWorkItems(PENDING_WORK_COUNT);

        // Signal cancellation
        workExecutionQueue.signalWorkItemCancellation(completionSelectorAny);

        // Verify behavior
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(equalTo(0)));
        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(equalTo(0)));
        verify(workItem, times(WORK_COUNT_UPPER_BOUND)).cancel();
    }

    @Test
    public void signalWorkItemCancellation_withANonMatchingSelector_doesNothing() {
        // Fill executor capacity
        scheduleWorkItems(WORK_COUNT_UPPER_BOUND);
        // Throw in additional work
        scheduleWorkItems(PENDING_WORK_COUNT);

        // Signal cancellation
        workExecutionQueue.signalWorkItemCancellation(cancelationSelectorNone);

        // Verify behavior
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(equalTo(WORK_COUNT_UPPER_BOUND)));
        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(equalTo(PENDING_WORK_COUNT)));
        verify(workItem, never()).cancel();
    }

    @Test
    public void setMaxWorkItemCount_whenRetainedWorkItemsExist_disptachesRetainedWorkExecution() {
        // Fill executor capacity
        scheduleWorkItems(WORK_COUNT_UPPER_BOUND);

        // Throw in additional work
        scheduleWorkItems(PENDING_WORK_COUNT);
        // Increase capacity
        final int CAPACITY_DELTA = 2;
        final int INCREASED_CAPACITY = WORK_COUNT_UPPER_BOUND + CAPACITY_DELTA;
        workExecutionQueue.setMaxOngoingWorkItemCount(INCREASED_CAPACITY);
        // Verify behavior
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(equalTo(INCREASED_CAPACITY)));
        verify(workItem, times(INCREASED_CAPACITY)).run();
        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(equalTo(PENDING_WORK_COUNT - CAPACITY_DELTA)));
    }

    @Test
    public void pullWork_capacityAvailable_pendingAvailable_providesWork() throws Exception {

        workExecutionQueue.setMaxOngoingWorkItemCount(1);

        doThrow(new RejectedExecutionException()).when(executionPolicy).execute(isA(Runnable.class));

        scheduleWorkItems(1);

        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(1));
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(0));

        final Optional<PolicyJob<?>> workForExecution = workExecutionQueue.getRetainedWorkForExecution();

        assertThat(workForExecution.isPresent(), is(true));
        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(0));
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(1));
        verifyZeroInteractions(workSupplier);
    }

    @Test
    public void pullWork_capacityAvailable_pendingAvailable_selectorMatches_providesCorrectWorkItem() throws Exception {

        workExecutionQueue.setMaxOngoingWorkItemCount(1);

        doThrow(new RejectedExecutionException()).when(executionPolicy).execute(isA(Runnable.class));

        final Job job1 = mock(Job.class);
        final Job job2 = mock(Job.class);

        workExecutionQueue.scheduleWorkItem(job1, cancelationSelectorNone);
        workExecutionQueue.scheduleWorkItem(job2, cancelationSelectorNone);

        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(2));
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(0));

        final Optional<PolicyJob<?>> workForExecution = workExecutionQueue.getRetainedWorkForExecution(job -> job.equals(job2));

        assertThat(workForExecution, is(Optional.of(job2)));
        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(1));
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(1));
        verifyZeroInteractions(workSupplier);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void pullWork_capacityAvailable_pendingAvailable_selectorDoesNotMatch_doesNotProvideWork() throws Exception {

        workExecutionQueue.setMaxOngoingWorkItemCount(1);

        when(workSupplier.apply(any(Predicate.class))).thenReturn(Optional.empty());
        doThrow(new RejectedExecutionException()).when(executionPolicy).execute(isA(Runnable.class));

        scheduleWorkItems(2);

        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(2));
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(0));

        final Predicate<PolicyJob<?>> selector = job -> false;
        final Optional<PolicyJob<?>> workForExecution = workExecutionQueue.getRetainedWorkForExecution(selector);

        assertThat(workForExecution, is(Optional.empty()));
        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(2));
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(0));
        verify(workSupplier).apply(selector);
    }

    @Test
    public void pullWork_capacityUnavailable_doesNotProvideWork() throws Exception {

        workExecutionQueue.setMaxOngoingWorkItemCount(1);

        scheduleWorkItems(1);

        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(0));
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(1));

        final Optional<PolicyJob<?>> workForExecution = workExecutionQueue.getRetainedWorkForExecution();

        assertThat(workForExecution, is(Optional.empty()));
        verifyZeroInteractions(workSupplier);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void pullWork_capacityAvailable_noPendingAvailable_providesWorkFromSupplier() throws Exception {

        workExecutionQueue.setMaxOngoingWorkItemCount(1);

        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(0));
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(0));

        when(workSupplier.apply(any(Predicate.class))).thenReturn(Optional.of(workItem));

        final Optional<PolicyJob<?>> workForExecution = workExecutionQueue.getRetainedWorkForExecution();

        assertThat(workForExecution.isPresent(), is(true));
        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(0));
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(1));
        verify(workSupplier).apply(any(Predicate.class));
    }

    @Test
    @SuppressWarnings("unchecked")
    public void pullWork_capacityAvailable_noPendingAvailable_supplierWithoutWork_doesNotProvideWork() throws Exception {

        workExecutionQueue.setMaxOngoingWorkItemCount(1);

        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(0));
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(0));

        when(workSupplier.apply(any(Predicate.class))).thenReturn(Optional.empty());

        final Optional<PolicyJob<?>> workForExecution = workExecutionQueue.getRetainedWorkForExecution();

        assertThat(workForExecution, is(Optional.empty()));
        assertThat(workExecutionQueue.getPendingWorkItemCount(), is(0));
        assertThat(workExecutionQueue.getOngoingWorkItemCount(), is(0));
        verify(workSupplier).apply(any(Predicate.class));
    }

    @Test
    public void testContendedCorrectness() {
        // TODO:
        // Throw the dogs at it and verify if the invariant is preserved: no work is retained when
        // the policy allows its execution
    }
}
