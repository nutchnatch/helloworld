package com.ossnms.dcn_manager.core.properties.ne;

import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.properties.ne.NeDomainProperties.NeDomain;
import com.ossnms.dcn_manager.core.properties.ne.NeDomainProperties.Status;

public class NeDomainPropertiesTest {

    @Test
    public void testPropertyParsing() {

        final Iterable<NeDomain> domains = new NeDomainProperties().parseProperties(
                ImmutableMap.<String,String>builder()
                .put("", "")
                .put("blah", "bleh")
                .put("DHCP_NAME_000", "domain")
                .put("DHCP_NAME_001", "domain2")
                .put("DHCP_STATUS_001", "NEW")
                .put("DHCP_NAME_002", "")
                .put("DHCP_STATUS_002", "blah")
                .put("SOMETHING_ELSE_002", "stuff")
                .build());

        assertThat(domains, containsInAnyOrder(new NeDomain("domain", Status.UNKNOWN), new NeDomain("domain2", Status.NEW)));
    }

}
