package com.ossnms.dcn_manager.core.entities.channel.data;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.both;
import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertThat;

import org.junit.Before;
import org.junit.Test;

import com.ossnms.dcn_manager.core.entities.DomainObjectDataTestBase;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;

public class ChannelInfoDataTest extends DomainObjectDataTestBase<ChannelInfoData> {

	private static final int MEDIATOR_ID = 1;
	private static final String TYPE = "A type";
	private static final String CORE_ID = "A core id";
	private static final boolean ACTIVATION_REQUIRED = true;

	private ChannelInfoData createChannelInfoData(int id, int version) {
		return new ChannelInfoBuilder()
		    .setType(TYPE)
		    .setCoreId(CORE_ID)
		    .setActivationRequired(ACTIVATION_REQUIRED)
		    .build(id, version, MEDIATOR_ID);
	}

	@Before
	@Override
	public void setUp() throws Exception {
		domainObjectOne = createChannelInfoData(ONE_ID, ONE_VERSION);
		domainObjectOneCopy = createChannelInfoData(ONE_ID, ONE_VERSION);
		domainObjectOneMutated = createChannelInfoData(ONE_ID, ONE_VERSION + 1);
		domainObjectTwo = createChannelInfoData(TWO_ID, TWO_VERSION);
	}

	@Test
	public void toString_inAValidInstance_producesAStringWithTheCorrectContent() {
		// The following string literals must match the ones used in ChannelInfoData.toString()
		// Public constant fields was not used to prevent polluting the type's public interface
        assertThat(domainObjectOne.toString(),
    		allOf(
        		both(containsString("mediatorId")).and(containsString(Integer.toString(MEDIATOR_ID))),
        		both(containsString("type")).and(containsString(TYPE)),
        		both(containsString("coreId")).and(containsString(CORE_ID)),
        		both(containsString("activation_required")).and(containsString(Boolean.toString(ACTIVATION_REQUIRED)))
        	)
        );
	}
}
