package com.ossnms.dcn_manager.core.policies;

/**
 * Configures job scheduling per channel, i.e., the number of jobs that
 * may be executing simultaneously against specific channels.
 *
 * Also provides access to runtime information about the job load on all
 * channels.
 */
public interface ChannelSchedulingConfiguration {

    /**
     * @return The number of pending jobs, regardless of the Channel partition.
     */
    int getPendingChannelJobCount();

    /**
     * @return The number of ongoing jobs regardless of the Channel partition.
     */
    int getOngoingChannelJobCount();

    /**
     * Sets the maximum allowed number of simultaneous work items in the execution queue
     * associated to the given channel. This configuration change may not have immediate
     * effect, meaning, ongoing work items will not be cancelled.
     * @param channelId The channel identifier.
     * @param maximumOngoingJobCount The new maximum number of allowed simultaneous work items.
     * @throws IllegalArgumentException If {@literal maximumOngoingJobCount} is not greater
     * than {@value 0}.
     */
    void setMaxOngoingChannelJobCount(int channelId, int maximumOngoingJobCount);

    /**
     * Informs the scheduler that a channel has been removed from the system.
     * This allows to release any resources that may be held in connection with the
     * channel.
     * @param channelId The channel identifier.
     */
    void onChannelRemoved(int channelId);
}
