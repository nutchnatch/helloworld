/**
 * Contains the definition of events related to the NE domain entity.
 * 
 * <p>Package that contains the definition of events related to the NE domain entity. NE
 * related events are classified in the following  main groups, as depicted in the class diagram:
 * 
 * <ul>
 *  <li>Events pertaining to the NE's required state 
 *  ({@link com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent});</li>
 *  <li>Events pertaining to the channel's actual state 
 *  ({@link com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent});</li>
 *  <li>Events pertaining to the modification of the NE's dynamic properties 
 *  ({@link com.ossnms.dcn_manager.core.events.ne.NePropertiesChangedEvent});</li>
 * </ul>
 * 
 * <p> <figure>
 * <img src="doc-files/ne_event-class.png">
 * <figcaption>class diagram of NE related events</figcaption>
 * </figure> </p>
 * 
 * <p>The abstract classes that materialize each of these  groups are, in turn, base classes for the concrete 
 * event types of that group. Instead of materializing these concrete event types has derived 
 * top-level classes, which would increase the overall solution's complexity (i.e. the total number of 
 * top-level classes), concrete event types are materialized as static nested classes, leading to a curious 
 * coding pattern in which derived classes are public nested classes of its super class. <br />
 * Despite being a curious coding pattern, the resulting solution reduces overall complexity and increases
 * readability: all related types are contained within the same compilation unit, which, given its small size,
 * is not affected by significant complexity increase. </p>
 * 
 * <p> The description of these hierarchies is therefore presented in the documentation of each base class.</p>   
 */
/*
 * @startuml doc-files/ne_event-class.png
 * package emne.events {
 *   abstract class EntityEvent <<Immutable>> {
 *      -int entityId
 *      -String detailedDescription
 *      +EntityEvent(int entityId)
 *      +EntityEvent(int entityId, String detailedDescription)
 *      #int getEntityId()
 *      +String getDetailedDescription()
 *      +String toString()
 *      +boolean equals(Object obj)
 *      +int hashCode()
 *      }
 *  interface Event 
 *  hide Event members
 *  Event <|.. EntityEvent 
 * }
 
 * package emne.events.ne {
 *  abstract class NeEvent <<Immutable>> {
 *      +NeEvent(int neId)
 *      +NeEvent(int neId, String detailedDescription)
 *      +int getNeId()
 *  }
 *  NeEvent --|> EntityEvent
 *  abstract class ActualNeStateEvent <<Immutable>> --|> NeEvent
 *  abstract class RequiredNeStateEvent <<Immutable>> --|> NeEvent
 *  abstract class NePropertiesChangedEvent <<Immutable>> --|> NeEvent
 *  hide ActualNeStateEvent members 
 *  hide RequiredNeStateEvent members 
 *  hide NePropertiesChangedEvent members 
 * @enduml
 */
package com.ossnms.dcn_manager.core.events.ne;