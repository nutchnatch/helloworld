package com.ossnms.dcn_manager.core.properties;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.core.configuration.model.Type;

/**
 * Utility class for instantiating property handlers that always handle properties
 * of a specific name.
 *
* @param <TYPE> Base domain entity type.
* @param <ENTITY> Property handler base domain object type.
* @param <MUTATION_DESCRIPTOR> Mutation descriptor class for the domain object.
*
* @see EntityPropertyHandler
 */
public abstract class NamedPropertyHandler<TYPE extends Type, ENTITY, MUTATION_DESCRIPTOR>
        extends EntityPropertyHandler<TYPE, ENTITY, MUTATION_DESCRIPTOR> {

    private final String propertyName;

    protected NamedPropertyHandler(String name) {
        propertyName = name;
    }

    /**
     * @return Always returns true if the property name matches the one configured upon creation.
     */
    @Override
    public boolean handles(@Nonnull TYPE type, @Nonnull String name) {
        return propertyName.equals(name);
    }

    protected String getName() {
        return propertyName;
    }
}
