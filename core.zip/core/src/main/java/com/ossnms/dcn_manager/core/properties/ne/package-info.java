/**
 * <p>Contains companion objects that know how to access unstructured
 * data within NE Entities. Also know how to transform these entities
 * into unstructured data blocks and back.</p>
 *
 * <p>These unstructured data blocks are known as properties, and only
 * supported properties will be interpreted. All others will be
 * treated as-is.</p>
 *
 * <p><img src="doc-files/package-dependencies.png"/></p>
 */
/*
 * @startuml doc-files/package-dependencies.png
 *
 * title Bird's-eye view of dependencies
 *
 * class NeGatewayRouteProperties
 * class NeProperties
 * class NeProperty
 * class NeType
 * class NeEntity
 * class NeEntityMutationDescriptor
 *
 * NeType <.. NeProperties
 * NeEntity <.. NeProperties
 * NeEntityMutationDescriptor <.. NeProperties
 * NeProperty <.. NeProperties
 *
 * NeType <.. NeGatewayRouteProperties
 * NeEntity <.. NeGatewayRouteProperties
 * NeEntityMutationDescriptor <.. NeGatewayRouteProperties
 *
 * @enduml
 */
package com.ossnms.dcn_manager.core.properties.ne;

