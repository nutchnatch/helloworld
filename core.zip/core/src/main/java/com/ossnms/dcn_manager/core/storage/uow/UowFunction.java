package com.ossnms.dcn_manager.core.storage.uow;

import com.ossnms.dcn_manager.exceptions.DcnManagerException;

import javax.annotation.Nonnull;

/**
 * Unit of Work function object. This represents an operation within
 * a Unit of Work that produces a result.
 *
 * @param <R> Function result type.
 */
@FunctionalInterface
public interface UowFunction<R> {

    /**
     * Applies this function to the given argument.
     *
     * @param context Current Unit of Work execution context.
     * @return The function result.
     * @throws DcnManagerException When the function execution has failed.
     */
    R apply(@Nonnull UowContext context) throws DcnManagerException;

}
