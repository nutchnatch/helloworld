/**
 * Contains the definition of events related to the Channel domain entity.
 * 
 * <p>Package that contains the definition of events related to the Channel domain entity. Channel 
 * related events are classified in the following  main groups, as depicted in the class diagram:
 * <ul>
 *  <li>Events pertaining to the channel's required state 
 *  ({@link com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent});</li>
 *  <li>Events pertaining to the channel's actual state 
 *  ({@link com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent});</li>
 *  <li>Events pertaining to the modification of the channel's dynamic properties 
 *  ({@link com.ossnms.dcn_manager.core.events.channel.ChannelPropertiesChangedEvent});</li>
 * </ul>
 * 
 * <p> <figure>
 * <img src="doc-files/channel_event-class.png">
 * <figcaption>Class diagram of channel related events</figcaption>
 * </figure> </p>
 * 
 * <p>The abstract classes that materialize required channel state events 
 * (i.e. {@link com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent}) and actual state events 
 * (i.e. {@link com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent}) are, in turn, base classes 
 * for the concrete event types of that group. Instead of materializing these concrete event types as derived 
 * top-level classes, thereby increasing complexity of the overall solution (i.e. the total number of top-level 
 * classes), concrete event types are materialized as static nested classes, leading to a curious coding pattern 
 * in which derived classes are public nested classes of its super class. </p>
 * 
 * <p>Despite being a curious coding pattern, the resulting solution reduces overall complexity and increases
 * readability: all related types are contained within the same compilation unit, which, given its small size,
 * is not affected by significant complexity increase.</p>
 * 
 * <p>The description of these specific hierarchies is therefore presented in the documentation of each base 
 * class.</p>
 * 
 * @see com.ossnms.dcn_manager.core.events.channel.ChannelEvent
 * @see com.ossnms.dcn_manager.core.events.channel.ChannelPropertiesChangedEvent
 * @see com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent
 * @see com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent
 */
/*
 * @startuml doc-files/channel_event-class.png
 * package emne.events {
 *   abstract class EntityEvent <<Immutable>> {
 *      -int entityId
 *      -String detailedDescription
 *      +EntityEvent(int entityId)
 *      +EntityEvent(int entityId, String detailedDescription)
 *      #int getEntityId()
 *      +String getDetailedDescription()
 *      +String toString()
 *      +boolean equals(Object obj)
 *      +int hashCode()
 *      }
 *  interface Event 
 *  hide Event members
 *  Event <|.. EntityEvent 
 * }
 
 * package emne.events.channel {
 *  abstract class ChannelEvent <<Immutable>> {
 *      +ChannelEvent(int channelId)
 *      +ChannelEvent(int channelId, String detailedDescription)
 *      +int getChannelId()
 *  }
 *  ChannelEvent --|> EntityEvent
 *  abstract class ActualChannelStateEvent <<Immutable>> --|> ChannelEvent
 *  abstract class RequiredChannelStateEvent <<Immutable>> --|> ChannelEvent
 *  class ChannelPropertiesChangedEvent <<Immutable>> --|> ChannelEvent
 *  hide ActualChannelStateEvent members 
 *  hide RequiredChannelStateEvent members 
 *  hide ChannelPropertiesChangedEvent members 
 * @enduml
 */
package com.ossnms.dcn_manager.core.events.channel;