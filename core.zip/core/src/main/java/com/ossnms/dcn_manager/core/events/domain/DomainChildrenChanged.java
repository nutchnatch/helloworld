package com.ossnms.dcn_manager.core.events.domain;

import com.google.common.collect.ImmutableCollection;
import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

/**
 * Informs that the list of domain children has changed for a given domain.
 */
@Immutable
public class DomainChildrenChanged extends DomainEvent {

    /** The affected Domain. */
    private final DomainInfoData domain;
    /** The list of children NE identifiers. */
    private final ImmutableCollection<Integer> childrenIds;

    /**
     * Initiates an instance with the affected Domain and child NE identifiers.
     * @param domain The affected Domain instance.
     * @param childrenIds The child NE identifiers.
     */
    public DomainChildrenChanged(@Nonnull DomainInfoData domain, @Nonnull ImmutableCollection<Integer> childrenIds) {
        super(domain.getId());
        this.domain = domain;
        this.childrenIds = childrenIds;
    }

    /**
     * @return Domain information.
     */
    public DomainInfoData getDomain() {
        return domain;
    }

    /**
     * @return All children NE identifiers.
     */
    public Iterable<Integer> getChildrenIds() {
        return childrenIds;
    }

}
