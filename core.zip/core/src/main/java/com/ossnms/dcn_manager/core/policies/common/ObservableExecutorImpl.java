package com.ossnms.dcn_manager.core.policies.common;

import javax.annotation.Nonnull;
import java.util.Observable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * Wrapper around a standard {@link Executor} that allows listening to task completion notifications.
 * When a task completes any observers are notified. This invocation means that capacity may eventually
 * be available and occurs within the context of any thread, probably the thread that ran the command.
 *
 * @see Executor
 */
public class ObservableExecutorImpl extends Observable implements ObservableExecutor {

    private final Executor delegateExecutor;

    /**
     * Constructs a new object.
     *
     * @param delegate Delegate executor.
     */
    public ObservableExecutorImpl(@Nonnull Executor delegate) {
        this.delegateExecutor = delegate;
    }

    /**
     * {@inheritDoc}
     *
     * <p>When the command given is complete, a registered observer will be notified of
     * potentially available capacity.
     *
     * The notification will occur from within the thread that executed the command.</p>
     *
     */
    @Override
    public void execute(@Nonnull Runnable command) {
        CompletableFuture
                .supplyAsync(() -> runWorkItem(command), delegateExecutor)
                .thenRun(this::notifyTaskCompletion);
    }

    private Void runWorkItem(Runnable workItem) {
        workItem.run();
        return null;
    }

    private void notifyTaskCompletion() {
        setChanged();
        notifyObservers();
    }
}
