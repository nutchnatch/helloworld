package com.ossnms.dcn_manager.core.entities.mediator.data;

import com.google.common.base.MoreObjects;
import com.google.common.base.MoreObjects.ToStringHelper;
import com.mysema.query.annotations.QueryEntity;
import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import org.apache.commons.lang3.builder.EqualsBuilder;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.time.Instant;
import java.util.Objects;
import java.util.Optional;

/**
 * Contains information about the actual (current) connection
 * to the Mediator server. It is known as its actual activation
 * state of the PHYSICAL connection.
 */
@QueryEntity
public final class MediatorPhysicalConnectionData extends BusinessObjectData {

    private final int mediatorId;
    private final ActualActivationState actualActivationState;
    private final String additionalInfo;
    private final boolean active;
    private final Instant lastFailureTimestamp;
    private final int activationAttemptsCounter;

    /**
     * Creates a new object with default values (inactive).
     * @param mediatorInstanceId The Physical Mediator ID.
     * @param mediatorId The Logical Mediator ID.
     * @param version This instances' version number.
     * @param prototype Initial instance data.
     */
    public MediatorPhysicalConnectionData(int mediatorInstanceId, int mediatorId, int version, MediatorPhysicalConnectionPrototype<?> prototype) {
        super(mediatorInstanceId, version);
        this.mediatorId = mediatorId;
        this.actualActivationState = prototype.actualActivationState;
        this.additionalInfo = prototype.additionalInfo;
        this.active = prototype.active;
        this.lastFailureTimestamp = prototype.lastFailureTimestamp;
        this.activationAttemptsCounter = prototype.activationAttemptsCounter;
    }

    /**
     * @return Whether the Mediator is currently active.
     */
    public ActualActivationState getActualActivationState() {
        return actualActivationState;
    }

    /**
     * @return Additional state description. May be empty.
     */
    public String getAdditionalInfo() {
        return additionalInfo;
    }

    /**
     * @return Logical Mediator ID.
     */
    public int getLogicalMediatorId() {
        return mediatorId;
    }

    /**
     * @return Whether this is the Active Mediator instance, within the context of redundancy
     *  (Active vs. Standby).
     */
    public boolean isActive() {
        return active;
    }

    /**
     * @return The timestamp of the last recorded failure.
     */
    public Optional<Instant> getLastFailureTimestamp() {
        return Optional.ofNullable(lastFailureTimestamp);
    }

    /**
     * @return The count of activation attempts. It is incremented when an activation starts and
     * reset when the activation succeeds.
     */
    public int getActivationAttemptsCounter() {
        return activationAttemptsCounter;
    }

    @Override
    public int hashCode() {
        return Objects.hash(mediatorId, actualActivationState, additionalInfo, active,
                lastFailureTimestamp, activationAttemptsCounter);
    }

    /* (non-Javadoc)
     * @see com.ossnms.bicnet.emne.core.entities.BusinessObjectData#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (null == other || getClass() != other.getClass()) {
            return false;
        }
        final MediatorPhysicalConnectionData rhs = (MediatorPhysicalConnectionData) other;
        return new EqualsBuilder()
                .append(mediatorId, rhs.mediatorId)
                .append(actualActivationState, rhs.actualActivationState)
                .append(additionalInfo, rhs.additionalInfo)
                .append(active, rhs.active)
                .append(lastFailureTimestamp, rhs.lastFailureTimestamp)
                .append(activationAttemptsCounter, rhs.activationAttemptsCounter)
                .isEquals();
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        final ToStringHelper helper = MoreObjects.toStringHelper(this);
        helper.addValue(super.toString());
        helper.add("mediatorId", getLogicalMediatorId());
        helper.add("active", isActive());
        helper.add("activation_state", getActualActivationState());
        helper.add("additional_info", getAdditionalInfo());
        helper.add("lastFailureTimestamp", lastFailureTimestamp);
        helper.add("activationAttemptsCounter", activationAttemptsCounter);
        return helper.toString();
    }

    private abstract static class MediatorPhysicalConnectionPrototype<T extends MediatorPhysicalConnectionPrototype<T>> {

        private int activationAttemptsCounter;
        private Instant lastFailureTimestamp;
        private ActualActivationState actualActivationState = ActualActivationState.INACTIVE;
        private String additionalInfo = "";
        private boolean active;

        protected MediatorPhysicalConnectionPrototype() {

        }

        protected abstract T self();

        /**
         * @param actualActivationState Whether the Mediator is currently active.
         */
        public T setActualActivationState(ActualActivationState actualActivationState) {
            this.actualActivationState = actualActivationState;
            return self();
        }

        /**
         * @param additionalInfo Additional state description. May be empty.
         */
        public T setAdditionalInfo(String additionalInfo) {
            this.additionalInfo = additionalInfo;
            return self();
        }

        /**
         * @param isActive Whether this is the Active Mediator instance, within the context of redundancy
         *  (Active vs. Standby).
         */
        public T setActive(boolean isActive) {
            this.active = isActive;
            return self();
        }

        /**
         * @param newFailureTimestamp The timestamp of the last recorded failure.
         */
        public T setLastFailureTimestamp(@Nullable Instant newFailureTimestamp) {
            this.lastFailureTimestamp = newFailureTimestamp;
            return self();
        }

        /**
         * @param newFailureTimestamp The timestamp of the last recorded failure.
         */
        public T setLastFailureTimestamp(@Nonnull Optional<Instant> newFailureTimestamp) {
            this.lastFailureTimestamp = newFailureTimestamp.orElse(null);
            return self();
        }

        /**
         * @param newActivationAttemptsCount The new counter value.
         */
        public T setActivationAttemptsCounter(int newActivationAttemptsCount) {
            this.activationAttemptsCounter = newActivationAttemptsCount;
            return self();
        }
    }

    /**
     * Contains initial data values for the data object (it's a parameter object).
     */
    public static final class MediatorPhysicalConnectionInitialData extends MediatorPhysicalConnectionPrototype<MediatorPhysicalConnectionInitialData> {

        @Override
        protected MediatorPhysicalConnectionInitialData self() {
            return this;
        }

    }

    /**
     * Helps building a new instance of {@link MediatorPhysicalConnectionData} with
     * predefined attribute values.
     */
    public static final class MediatorPhysicalConnectionBuilder extends MediatorPhysicalConnectionPrototype<MediatorPhysicalConnectionBuilder> {

        /**
         * Creates a new instance with values defined in this builder object.
         * @param mediatorInstanceId The Physical Mediator ID.
         * @param logicalMediatorId The Logical Mediator ID.
         * @param version The new instances' version number.
         * @return A new instance of {@link MediatorPhysicalConnectionData}.
         */
        public MediatorPhysicalConnectionData build(int mediatorInstanceId, int logicalMediatorId, int version) {
            return new MediatorPhysicalConnectionData(mediatorInstanceId, logicalMediatorId, version, this);
        }

        @Override
        protected MediatorPhysicalConnectionBuilder self() {
            return this;
        }

    }
}
