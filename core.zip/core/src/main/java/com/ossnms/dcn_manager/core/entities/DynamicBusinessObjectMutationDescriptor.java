package com.ossnms.dcn_manager.core.entities;

import com.google.common.base.MoreObjects;
import com.google.common.base.MoreObjects.ToStringHelper;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.NotThreadSafe;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>Abstract class that is the base class for all mutation descriptors that are to be applied
 * on domain objects which have a dynamic facet.</p>
 *
 * @param <T> the concrete type of the domain object to which the mutation refers to
 * @param <M> the concrete mutation descriptor type, to enable compile time type
 */
@NotThreadSafe
public abstract class DynamicBusinessObjectMutationDescriptor<T extends DynamicBusinessObjectData, M extends DynamicBusinessObjectMutationDescriptor<T, M>>
			extends MutationDescriptor<T, M> {

	/** Holds the set of dynamic properties */
	// Implementation note: We do not use an absent Optional instance to represent the absence of
	// properties' mutations. Instead, we use an empty map, because the instantiation cost is negligible.
    private final Map<String, String> propertyBag;

	/**
	 * Initiates an instance that will be used to mutate the given domain object instance
	 * @param target the domain object instance to which the mutation will be applied
	 */
	public DynamicBusinessObjectMutationDescriptor(@Nonnull T target) {
		super(target);
		propertyBag = new HashMap<>();
	}

    /**
     * Stores a new property for the object. It will be stored in the property bag
     * without further handling.
     * @param name The name of the property to change.
     * @param value The new property value.
     */
    public M setProperty(@Nonnull String name, @Nullable String value) {
        propertyBag.put(name, value);
        return self();
    }

    /**
     * @param properties A map of property values to add or replace in the current set of properties.
     */
    public M setProperties(@Nonnull Map<String, String> properties) {
        propertyBag.putAll(properties);
        return self();
    }

    /** @return The modified properties. Will be empty if no properties were modified. */
    public Map<String, String> getProperties() {
        return propertyBag;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        final ToStringHelper helper = MoreObjects.toStringHelper(this);
        helper.addValue(super.toString());
        if (!propertyBag.isEmpty()) {
            helper.add("new properties", propertyBag);
        }
        return helper.toString();
    }
}
