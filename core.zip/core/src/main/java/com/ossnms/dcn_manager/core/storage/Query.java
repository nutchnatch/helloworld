package com.ossnms.dcn_manager.core.storage;

import com.mysema.query.Projectable;
import com.mysema.query.SimpleQuery;
import com.mysema.query.types.Predicate;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

public interface Query<Q extends Query<Q>> extends Projectable, SimpleQuery<Q>, AutoCloseable {

    Q where(Predicate o);

    @Override
    Q where(Predicate... o);

    @Override
    void close() throws RepositoryException;
}
