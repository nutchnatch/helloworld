package com.ossnms.dcn_manager.core.entities.ne.data;

import java.util.Optional;

import javax.annotation.Nonnull;

import com.google.common.base.MoreObjects;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.CommissioningMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.GatewayMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.OperationalMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.TpGroupSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.types.WriteAccessMode;

/**
 * Contains all data that should be changed on {@link NeOperationData},
 * when applied as a single atomic mutation by the repository.
 */
public class NeOperationMutationDescriptor extends MutationDescriptor<NeOperationData, NeOperationMutationDescriptor> implements NeOperationPropertySetters<NeOperationMutationDescriptor> {

    private Optional<WriteAccessMode> writeAccess = Optional.empty();
    private Optional<OperationalMode> operational = Optional.empty();
    private Optional<Boolean> eventForwardingMode = Optional.empty();
    private Optional<CommissioningMode> commissioning = Optional.empty();
    private Optional<String> family = Optional.empty();
    private Optional<String> mainRelease = Optional.empty();
    private Optional<String> maintenanceRelease = Optional.empty();
    private Optional<TpGroupSettings> tpGroupMode = Optional.empty();
    private Optional<Long> tpGroupMask = Optional.empty();
    private Optional<String> neSubType = Optional.empty();
    private Optional<String> neSubTypeDescription = Optional.empty();
    private Optional<String> neType = Optional.empty();
    private Optional<String> neSpecificType = Optional.empty();
    private Optional<String> realNeName = Optional.empty();
    private Optional<String> iconId = Optional.empty();
    private Optional<String> neighbourhoodId = Optional.empty();
    private Optional<String> location = Optional.empty();
    private Optional<String> additionalTypeInfo = Optional.empty();
    private Optional<GatewayMode> gatewayMode = Optional.empty();
    

    public NeOperationMutationDescriptor(NeOperationData target) {
        super(target);
    }

    @Override
    protected NeOperationMutationDescriptor self() {
        return this;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .omitNullValues()
                .add("writeAccess", writeAccess.orElse(null))
                .add("operational", operational.orElse(null))
                .add("eventForwardingMode", eventForwardingMode.orElse(null))
                .add("commissioning", commissioning.orElse(null))
                .add("family", family.orElse(null))
                .add("mainRelease", mainRelease.orElse(null))
                .add("maintenanceRelease", maintenanceRelease.orElse(null))
                .add("tpGroupMode", tpGroupMode.orElse(null))
                .add("tpGroupMask", tpGroupMask.orElse(null))
                .add("neType", neType.orElse(null))
                .add("neSubType", neSubType.orElse(null))
                .add("neSubTypeDescription", neSubTypeDescription.orElse(null))
                .add("neSpecificType", getNeSpecificType().orElse(null))
                .add("realNeName", realNeName.orElse(null))
                .add("neighbourhoodId", neighbourhoodId.orElse(null))
                .add("iconId", getIconId().orElse(null))
                .add("location", location.orElse(null))
                .add("gatewayMode", gatewayMode.orElse(null))
                .add("additionalTypeInfo", additionalTypeInfo.orElse(null))
                .toString();
    }

    @Override
    protected NeOperationData doApply() {
        return shouldCreateNewObject()
                    ? new NeOperationBuilder()
                        .setWriteAccess(or(writeAccess, getTarget().getWriteAccess()))
                        .setOperational(or(operational ,getTarget().getOperational()))
                        .setEventForwardingMode(or(eventForwardingMode, getTarget().isEventForwardingActive()))
                        .setCommissioning(or(commissioning, getTarget().getCommissioning()))
                        .setFamily(or(family, getTarget().getFamily()))
                        .setMainRelease(or(mainRelease, getTarget().getMainRelease()))
                        .setMaintenanceRelease(or(maintenanceRelease, getTarget().getMaintenanceRelease()))
                        .setTpGroupMode(or(tpGroupMode, getTarget().getTpGroupMode()))
                        .setTpGroupMask(or(tpGroupMask, getTarget().getTpGroupMask()))
                        .setNeSubType(or(neSubType, getTarget().getNeSubType()))
                        .setNeSubTypeDescription(or(neSubTypeDescription, getTarget().getNeSubTypeDescription()))
                        .setNeType(or(neType, getTarget().getNeType()))
                        .setNeSpecificType(or(neSpecificType, getTarget().getNeSpecificType()))
                        .setRealNeName(or(realNeName, getTarget().getRealNeName()))
                        .setNeighbourhoodId(or(neighbourhoodId, getTarget().getNeighbourhoodId()))
                        .setIconId(or(iconId, getTarget().getIconId()))
                        .setLocation(or(location, getTarget().getLocation()))
                        .setGatewayMode(or(gatewayMode, getTarget().getGatewayMode()))
                        .setAdditionalTypeInfo(or(additionalTypeInfo,getTarget().getAdditionalTypeInfo()))
                        .build(getTarget().getId(), getTarget().getVersion())
                    : getTarget();
    }

    private <T> Optional<T> or(Optional<T> first, Optional<T> last) {
        return first.map(Optional::of).orElse(last);
    }

    private boolean shouldCreateNewObject() {
        return  isAnyTypeInfoSet() || isAnyConfigInfoSet() || isAnyGenericInfoSet() || isAnyIdentificationInfoSet();
    }

    private boolean isAnyGenericInfoSet() {
        return operational.isPresent() || commissioning.isPresent() || mainRelease.isPresent() || maintenanceRelease.isPresent();
    }

    private boolean isAnyConfigInfoSet() {
        final boolean isTpConfigPresent = tpGroupMode.isPresent() || tpGroupMask.isPresent();
        final boolean isAccessControlPresent = writeAccess.isPresent() || eventForwardingMode.isPresent();
        final boolean isNeInfoPresent = gatewayMode.isPresent() || realNeName.isPresent() || location.isPresent();

        return isTpConfigPresent || isAccessControlPresent || isNeInfoPresent;
    }

    private boolean isAnyTypeInfoSet() {
        return family.isPresent() || neSubType.isPresent() || neType.isPresent() || getNeSpecificType().isPresent() || additionalTypeInfo.isPresent();
    }

    private boolean isAnyIdentificationInfoSet() {
        return neighbourhoodId.isPresent();
    }

    /**
     * @return The current write access status.
     */
    public Optional<WriteAccessMode> getWriteAccess() {
        return writeAccess;
    }

    /**
     * @param writeAccess New write access status.
     */
    public NeOperationMutationDescriptor setWriteAccess(@Nonnull WriteAccessMode writeAccess) {
        this.writeAccess = Optional.of(writeAccess);
        return self();
    }

    /**
     * @return The current operational mode.
     */
    public Optional<OperationalMode> getOperationalMode() {
        return operational;
    }

    /**
     * @param operational New operational mode.
     */
    public NeOperationMutationDescriptor setOperationalMode(@Nonnull OperationalMode operational) {
        this.operational = Optional.of(operational);
        return self();
    }

    /**
     * @return Whether event forwarding is active.
     */
    public Optional<Boolean> isEventForwardingActive() {
        return eventForwardingMode;
    }

    /**
     * @param eventForwardingMode New event forwarding activation status.
     */
    public NeOperationMutationDescriptor setEventForwardingActive(boolean eventForwardingMode) {
        this.eventForwardingMode = Optional.of(eventForwardingMode);
        return self();
    }

    /**
     * @return The current commissioning status.
     */
    public Optional<CommissioningMode> getCommissioning() {
        return commissioning;
    }

    /**
     * @param commissioning New commissioning status.
     */
    public NeOperationMutationDescriptor setCommissioning(@Nonnull CommissioningMode commissioning) {
        this.commissioning = Optional.of(commissioning);
        return self();
    }

    /**
     * @return NE family name.
     */
    public Optional<String> getFamily() {
        return family;
    }

    /**
     * @param family New NE family name.
     */
    public NeOperationMutationDescriptor setFamily(@Nonnull String family) {
        this.family = Optional.of(family);
        return self();
    }

    /**
     * @return Software main release identifier.
     */
    public Optional<String> getMainRelease() {
        return mainRelease;
    }

    /**
     * @param mainRelease New software main release identifier.
     */
    public NeOperationMutationDescriptor setMainRelease(@Nonnull String mainRelease) {
        this.mainRelease = Optional.of(mainRelease);
        return self();
    }

    /**
     * @return Software maintenance release identifier.
     */
    public Optional<String> getMaintenanceRelease() {
        return maintenanceRelease;
    }

    /**
     * @param maintenanceRelease New software maintenance release.
     */
    public NeOperationMutationDescriptor setMaintenanceRelease(@Nonnull String maintenanceRelease) {
        this.maintenanceRelease = Optional.of(maintenanceRelease);
        return self();
    }

    /**
     * @return TP grouping configuration.
     */
    public Optional<TpGroupSettings> getTpGroupMode() {
        return tpGroupMode;
    }

    /**
     * Changes TP grouping configuration.
     */
    public NeOperationMutationDescriptor setTpGroupMode(boolean alwaysCompatible, boolean multipleGroupMembership,
            boolean subgroupsMustBeEqual, boolean multipleSubgroupMembership) {
        this.tpGroupMode = Optional.of(new TpGroupSettings(alwaysCompatible, multipleGroupMembership,
                subgroupsMustBeEqual, multipleSubgroupMembership));
        return self();
    }

    /**
     * @return TP grouping.
     */
    public Optional<Long> getTpGroupMask() {
        return tpGroupMask;
    }

    /**
     * @param tpGroupMask New TP grouping.
     */
    public NeOperationMutationDescriptor setTpGroupMask(long tpGroupMask) {
        this.tpGroupMask = Optional.of(tpGroupMask);
        return self();
    }

    /**
     * @return NE sub type name.
     */
    public Optional<String> getNeSubType() {
        return neSubType;
    }

    /**
     * @param neSubType New NE sub type name.
     */
    public NeOperationMutationDescriptor setNeSubType(@Nonnull String neSubType) {
        this.neSubType = Optional.of(neSubType);
        return self();
    }

    /**
     * @return NE sub type description.
     */
    public Optional<String> getNeSubTypeDescription() {
        return neSubTypeDescription;
    }

    /**
     * @param neSubTypeDescription New NE sub type description.
     */
    public NeOperationMutationDescriptor setNeSubTypeDescription(@Nonnull String neSubTypeDescription) {
        this.neSubTypeDescription = Optional.of(neSubTypeDescription);
        return self();
    }

    /**
     * @return NE type name.
     */
    public Optional<String> getNeType() {
        return neType;
    }

    /**
     * @param neType New NE type name.
     */
    public NeOperationMutationDescriptor setNeType(@Nonnull String neType) {
        this.neType = Optional.of(neType);
        return self();
    }

    /**
     * @return NE specific type.
     */
    public Optional<String> getNeSpecificType() {
        return neSpecificType;
    }

    /**
     * @param neSpecificType New NE specific type.
     */
    public NeOperationMutationDescriptor setNeSpecificType(@Nonnull String neSpecificType) {
        this.neSpecificType = Optional.of(neSpecificType);
        return this;
    }

    /**
     * @return NE name, as set in the hardware.
     */
    public Optional<String> getRealNeName() {
        return realNeName;
    }

    /**
     * @param realNeName New NE name, as set in the hardware.
     */
    public NeOperationMutationDescriptor setRealNeName(@Nonnull String realNeName) {
        this.realNeName = Optional.of(realNeName);
        return self();
    }

    /**
     * @return NE Neighbourhood ID name.
     */
    public Optional<String> getNeighbourhoodId() {
        return neighbourhoodId;
    }

    /**
     * @param neighbourhoodId New Neighbourhood ID name, as set by the mediation.
     */
    public NeOperationMutationDescriptor setNeighbourhoodId(String neighbourhoodId) {
        this.neighbourhoodId = Optional.ofNullable(neighbourhoodId);
        return self();
    }

    /**
     * @return The new NE icon identifier.
     */
    public Optional<String> getIconId() {
        return iconId;
    }

    /**
     * @param iconId The new NE icon identifier to set.
     */
    public NeOperationMutationDescriptor setIconId(@Nonnull String iconId) {
        this.iconId = Optional.of(iconId);
        return self();
    }

    public NeOperationMutationDescriptor setLocation(@Nonnull String location) {
        this.location = Optional.of(location);
        return self();
    }

    public Optional<String> getLocation() {
        return location;
    }
    
    /**
     * @return NE additional type info.
     */
    public Optional<String> getAdditionalTypeInfo() {
        return additionalTypeInfo;
    }

    /**
     * @param additionalTypeInfo New NE additional type info, as provided by mediation.
     */
    public NeOperationMutationDescriptor setAdditionalTypeInfo(String additionalTypeInfo) {
        this.additionalTypeInfo = Optional.ofNullable(additionalTypeInfo);
        return self();
    }

    /**
     * @return NE gateway role.
     */
    public Optional<GatewayMode> getGatewayMode() {
        return gatewayMode;
    }

    /**
     * @param additionalTypeInfo New NE gateway role, as provided by mediation.
     */
    public NeOperationMutationDescriptor setGatewayMode(@Nonnull GatewayMode gatewayMode) {
        this.gatewayMode = Optional.of(gatewayMode);
        return self();
    }
}
