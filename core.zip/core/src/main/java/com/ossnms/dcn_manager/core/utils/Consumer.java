package com.ossnms.dcn_manager.core.utils;

/**
 * Represents an operation that accepts a single input argument and returns no result.
 *
 * <p>
 * <strong>Note:</strong>
 * This interface is based on its Java 8 homonymous. Once the solution is ported to Java 8,
 * it will become unnecessary.
 * </p>
 */
public interface Consumer<T> {

	/**
	 * Performs an operation on the given argument
	 * @param in the argument on which the operation will be performed
	 */
	void accept(T in);
}
