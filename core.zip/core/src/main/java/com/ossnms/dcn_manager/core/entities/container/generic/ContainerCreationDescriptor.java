package com.ossnms.dcn_manager.core.entities.container.generic;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.core.entities.container.ContainerCreationDescriptorBase;

/**
 * Contains all information required to create a new DCN Container.
 */
public final class ContainerCreationDescriptor extends ContainerCreationDescriptorBase<ContainerCreationDescriptor> {

    /**
     * Creates a new object.
     * @param containerName DCN Container name. Must not be empty.
     * @throws IllegalArgumentException If the name is null or empty.
     */
    public ContainerCreationDescriptor(@Nonnull String containerName) {
        super(containerName);
    }

    /**
     * Creates a new object.
     * @param parentContainer Parent DCN Container identifier. Must be positive.
     * @param containerName DCN Container name. Must not be empty.
     * @throws IllegalArgumentException If the name is null or empty or if the parent identifier is zero or negative.
     */
    public ContainerCreationDescriptor(int parentContainer, @Nonnull String containerName) {
        super(parentContainer, containerName);
    }

    @Override
    protected ContainerCreationDescriptor self() {
        return this;
    }
}
