package com.ossnms.dcn_manager.core.entities.channel.data;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Strings.isNullOrEmpty;

import com.google.common.base.MoreObjects;
import com.google.common.base.MoreObjects.ToStringHelper;
import com.ossnms.dcn_manager.core.entities.BusinessObjectData;

/**
 * <p> Class that implements the data dimension of the domain object that describes the persisted channel
 * state or, in other words, the channel's information and required activation state. This means
 * that the application must ensure that the actual channel state converges to the required one. </p>
 *
 * <p>As all types that implement domain objects' data dimension, instances of this class are immutable,
 * and are therefore thread-safe.</p>
 */
public final class ChannelInfoData extends BusinessObjectData {

    /** The identifier of this channels' parent mediator. */
    private final int mediatorId;

    /** The channel's type name*/
    private final String type;

    /** The channel's ID in TNMS Core, used in the import from TNMS Core use-case */
    private final String coreId;

    /** the channel required activation state */
    private final boolean isActivationRequired;



    /** Boolean constants defined to increase readability at the constructor's call site. */
    public static final boolean ACTIVATION_REQUIRED = true;
    public static final boolean ACTIVATION_NOT_REQUIRED = false;

    /**
     * Creates an instance with the given arguments.
     *
     * @param id the channel identifier
     * @param version the domain object's version number
     * @param mediatorId parent mediator ID
     * @param type the channel type
     * @param prototype initial data values
     * @throws IllegalStateException if the channel type is empty or null
     */
    public ChannelInfoData(int id, int version, int mediatorId, ChannelInfoPrototype<?> prototype) {
        super(id, version);
        checkArgument(!isNullOrEmpty(prototype.type), "Channels must have a type.");
        this.mediatorId = mediatorId;
        this.type = prototype.type;
        this.coreId = prototype.coreId;
        this.isActivationRequired = prototype.isActivationRequired;
    }

    /** @return The channel's type */
    public String getType() {
        return type;
    }

    /** @return The channel's ID in TNMS Core, used in the import from TNMS Core use-case */
    public String getCoreId() {
        return coreId;
    }

    /**
     * @return A boolean value indicating whether the channel is required to be active or not
     */
    public boolean isActivationRequired() {
        return isActivationRequired;
    }

    /**
     * @return The parent mediator ID.
     */
    public int getMediatorId() {
        return mediatorId;
    }




    /** {@inheritDoc} */
	@Override
	public String toString() {
        final ToStringHelper helper = MoreObjects.toStringHelper(this);
        helper.addValue(super.toString());
        helper.add("mediatorId", getMediatorId());
        helper.add("type", getType());
        helper.add("coreId", getCoreId());
        helper.add("activation_required", isActivationRequired());
        return helper.toString();
	}

    /**
     * Facilitates the creation of a data object by allowing
     * individual attributes to be set easily.
     */
	public static final class ChannelInfoBuilder extends ChannelInfoPrototype<ChannelInfoBuilder> {

	    public ChannelInfoData build(int id, int version, int mediatorId) {
	        return new ChannelInfoData(id, version, mediatorId, this);
	    }

        @Override
        protected ChannelInfoBuilder self() {
            return this;
        }

	}

    /**
     * Facilitates the creation of a data object by allowing
     * individual attributes to be set easily.
     */
	public static final class ChannelInfoInitialData extends ChannelInfoPrototype<ChannelInfoInitialData> {

        @Override
        protected ChannelInfoInitialData self() {
            return this;
        }

	}

	public abstract static class ChannelInfoPrototype<T extends ChannelInfoPrototype<T>> {

	    private String type;
	    private String coreId;
	    private boolean isActivationRequired = ACTIVATION_NOT_REQUIRED;


	    protected ChannelInfoPrototype() {

	    }

	    protected ChannelInfoPrototype(ChannelInfoPrototype<?> prototype) {
            this.type = prototype.type;
            this.coreId = prototype.coreId;
            this.isActivationRequired = prototype.isActivationRequired;

        }

        protected abstract T self();

        /**
         * @param type The channel's type name
         */
        public T setType(String type) {
            this.type = type;
            return self();
        }



        /**
         * @param coreId The channel's ID in TNMS Core, used in the import from TNMS Core use-case
         */
        public T setCoreId(String coreId) {
            this.coreId = coreId;
            return self();
        }

        /**
         * @param isActivationRequired the channel required activation state
         */
        public T setActivationRequired(boolean isActivationRequired) {
            this.isActivationRequired = isActivationRequired;
            return self();
        }
	}
}
