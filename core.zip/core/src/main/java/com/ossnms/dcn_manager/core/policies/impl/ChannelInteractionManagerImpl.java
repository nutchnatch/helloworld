package com.ossnms.dcn_manager.core.policies.impl;

import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.outbound.ChannelConnectionManager;
import com.ossnms.dcn_manager.core.policies.ChannelInteractionManager;
import com.ossnms.dcn_manager.core.policies.common.ExecutionQueue;
import com.ossnms.dcn_manager.core.policies.common.Job;
import com.ossnms.dcn_manager.core.policies.common.ObservableExecutor;
import com.ossnms.dcn_manager.core.policies.common.PolicyJob;

import javax.annotation.Nonnull;
import java.util.Observer;
import java.util.Optional;

import static com.google.common.collect.Iterables.tryFind;

/**
 * Implementation of a policy for interaction with Channels. At this time it is generally
 * believed that these interactions do not force a significant load in the system, hence
 * there is no regulation.
 */
public class ChannelInteractionManagerImpl implements ChannelInteractionManager {

    private final ChannelConnectionManager connectionManager;
    private final ExecutionQueue<PolicyJob<? extends RequiredChannelStateEvent>> execution;

    private final Observer observer;
    private final ObservableExecutor executionPolicy;

    /**
     * Creates a new object.
     */
    public ChannelInteractionManagerImpl(
            @Nonnull ChannelConnectionManager connectionManager,
            @Nonnull ObservableExecutor executionPolicy) {
        this.connectionManager = connectionManager;
        this.execution = new ExecutionQueue<>(Integer.MAX_VALUE, "CHANNEL", executionPolicy, p -> Optional.empty());
        //The following observer was created to ensure that rejected tasks are resubmitted to the executor to be processed.
        //the observer will be invoked after each processed task, if there are rejected tasks in executionQueue
        //they will be resubmitted to the bounded executor
        // look at TNMSCM-11194
        this.observer = (obs, o) -> this.execution.signalCapacityIsAvailable();
        this.executionPolicy = executionPolicy;
        this.executionPolicy.addObserver(observer);
    }

    @Override
    public void scheduleActivation(@Nonnull Activate event) {
        execution.scheduleWorkItem(
            new JobWrapper<>(new ChannelActivationJob(event), execution::getRetainedWorkForExecution),
            job -> job.getOriginatingEvent().getChannelInstanceIdentifiers().equals(event.getChannelInstanceIdentifiers())
        );
    }

    @Override
    public void scheduleDeactivation(@Nonnull Deactivate event) {
        execution.scheduleWorkItem(
                new JobWrapper<>(new ChannelDeactivationJob(event), execution::getRetainedWorkForExecution),
            job -> job.getOriginatingEvent().getChannelInstanceIdentifiers().equals(event.getChannelInstanceIdentifiers())
        );
    }

    @Override
    public void cancelDeactivations(@Nonnull RequiredChannelStateEvent event) {
        execution.signalWorkItemCancellation(
            job -> Deactivate.class.equals(job.getOriginatingEvent().getClass()) &&
                    job.getOriginatingEvent().getChannelInstanceIdentifiers().equals(event.getChannelInstanceIdentifiers())
        );
    }

    @Override
    public void cancelActivations(@Nonnull RequiredChannelStateEvent event) {
        execution.signalWorkItemCancellation(
                job -> Activate.class.equals(job.getOriginatingEvent().getClass()) &&
                        job.getOriginatingEvent().getChannelInstanceIdentifiers().equals(event.getChannelInstanceIdentifiers())
        );
    }

    @Override
    public void onChannelInteractionEnded(@Nonnull ActualChannelStateEvent channelStateEvent) {
        execution.signalWorkItemCompletion(
            job -> tryFind(
                job.getOriginatingEvent().getChannelInstanceIdentifiers(),
                id -> id.equals(channelStateEvent.getOriginatingPhysicalEvent().map(PhysicalChannelStateEvent::getChannelId).orElse(0))
            ).isPresent()
        );
    }

    @Override
    public int getPendingJobCount() {
        return execution.getPendingWorkItemCount();
    }

    @Override
    public int getOngoingJobCount() {
        return execution.getOngoingWorkItemCount();
    }

    @Override
    public int getPendingJobCount(int mediatorId) {
        return 0;
    }

    @Override
    public int getOngoingJobCount(int mediatorId) {
        return 0;
    }

    @Override
    public int getMaxOngoingJobCount(int mediatorId) {
        return 0;
    }

    @Override
    public void setMaxOngoingJobCount(int mediatorId, int newMaxInteractions) {

    }

    @Override
    public void close() {
        this.executionPolicy.deleteObserver(this.observer);
    }

    private final class ChannelActivationJob extends Job<Activate> {

        public ChannelActivationJob(@Nonnull Activate requestEvent) {
            super(requestEvent, Priority.MEDIUM);
        }

        @Override
        public void runJob() {
            getOriginatingEvent().getChannelInstanceIdentifiers()
                    .forEach(connectionManager::connect);
        }
    }

    private final class ChannelDeactivationJob extends Job<Deactivate> {

        public ChannelDeactivationJob(@Nonnull Deactivate requestEvent) {
            super(requestEvent, Priority.HIGH);
        }

        @Override
        public void runJob() {
            getOriginatingEvent().getChannelInstanceIdentifiers()
                    .forEach(connectionManager::disconnect);
        }
    }

}
