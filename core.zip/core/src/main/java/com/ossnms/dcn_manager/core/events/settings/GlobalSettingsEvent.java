package com.ossnms.dcn_manager.core.events.settings;

import com.ossnms.dcn_manager.core.events.Event;

/**
 * This is the base class for all Global Settings events, declared to
 * enforce type restrictions on event management classes.
 */
public abstract class GlobalSettingsEvent implements Event {

}
