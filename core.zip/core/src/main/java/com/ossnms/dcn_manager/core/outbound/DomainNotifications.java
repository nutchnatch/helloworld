package com.ossnms.dcn_manager.core.outbound;

import com.ossnms.dcn_manager.core.entities.domain.DomainInfoData;
import com.ossnms.dcn_manager.core.events.domain.*;

import javax.annotation.Nonnull;

/**
 * Describes an API for sending notifications to other components about domain deletion, creation
 * and modification.
 *
 * Creation and deletion operations are only applied to the aggregate.
 */
public interface DomainNotifications {

    /**
     * Notifies other components that a domain has been deleted.
     * @param domain The deleted domain.
     */
    void notifyDelete(@Nonnull DomainInfoData domain);

    /**
     * Notifies other components that a domain has been created.
     * @param domain The new domain.
     */
    void notifyCreate(@Nonnull DomainInfoData domain);

    /**
     * Notifies other components that the list of children has changed for a domain.
     * @param event Domain children changed event.
     */
    void notifyChanges(@Nonnull DomainChildrenChanged event);

    /**
     * Notifies other components that the list of children has changed for a domain.
     * @param event Domain participation changed event.
     */
    void notifyChanges(@Nonnull DomainParticipationAdded event);

    /**
     * Notifies other components that the list of children has changed for a domain.
     * @param event Domain participation changed event.
     */
    void notifyChanges(@Nonnull DomainParticipationDeleted event);

    /**
     * Notifies other components that the policy regarding automatic NE activation
     * during discovery has changed for a given domain.
     * @param event Domain policy changed event.
     */
    void notifyChanges(@Nonnull DomainNeActivationPolicyChanged event);

    /**
     * Notifies other components that the name has changed for a given domain.
     * @param event Domain name changed event.
     */
    void notifyChanges(@Nonnull DomainRenamed event);
}
