/**
 * Package that contains the abstractions that specify the contracts to be supported by
 * DCN interaction management policies. These abstractions serve the purpose of segregating 
 * technology specific requirements (e.g. life-cycle management services that require 
 * the use of proxies, and therefore a no-argument constructor) from the requirements 
 * pertaining to the problem domain.
 */
package com.ossnms.dcn_manager.core.policies;