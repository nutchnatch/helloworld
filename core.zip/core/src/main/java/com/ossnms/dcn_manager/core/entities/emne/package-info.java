/**
 * Contains classes describing domain entities for the EM/NE component.
 * For example, global configuration settings will be stored in these entities.
 */
package com.ossnms.dcn_manager.core.entities.emne;