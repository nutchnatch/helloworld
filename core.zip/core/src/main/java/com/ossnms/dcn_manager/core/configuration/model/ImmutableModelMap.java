package com.ossnms.dcn_manager.core.configuration.model;

import com.ossnms.dcn_manager.core.collections.ImmutableForwardingMap;

import java.util.Map;


public class ImmutableModelMap<V> extends ImmutableForwardingMap<String, V> {

    private final Map<String, V> map;

    protected ImmutableModelMap(Map<String, V> map) {
        this.map = map;
    }

    @Override
    protected Map<String, V> delegate() {
        return map;
    }

}
