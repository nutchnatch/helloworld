package com.ossnms.dcn_manager.core.entities.mediator.data;

/**
 * Contains the minimum amount of information necessary to delete
 * an existing Mediator physical instance.
 */
public final class MediatorInstanceDeleteDescriptor {

    private final int id;

    /**
     * Creates a new object.
     * @param id The identifier of the physical Mediator to delete.
     */
    public MediatorInstanceDeleteDescriptor(int id) {
        this.id = id;
    }

    /**
     * @return The identifier of the physical Mediator to delete.
     */
    public int getId() {
        return id;
    }

}
