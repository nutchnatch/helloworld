/**
 * This package contains all the abstractions required to support all out-bound 
 * interactions, that is, the abstractions used to specify the contracts to be supported 
 * by implementations that will provide outside world runtime dependencies. 
 * 
 * These abstractions are designed according to the convenience of the current module, meaning,
 * they model the outside world has the current module needs to perceive it.
 * Any required adaptations (i.e. between reality and perception) must be provided 
 * by the abstractions's implementations. These implementations are materialized in external 
 * layers (e.g. connectors layer) 
 */
package com.ossnms.dcn_manager.core.outbound;