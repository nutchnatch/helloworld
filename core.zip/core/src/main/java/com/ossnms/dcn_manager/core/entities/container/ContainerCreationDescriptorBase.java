package com.ossnms.dcn_manager.core.entities.container;

import javax.annotation.Nonnull;

import java.util.Optional;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Strings.isNullOrEmpty;

/**
 * Contains all information required to create a new Container.
 */
public abstract class ContainerCreationDescriptorBase<T extends ContainerCreationDescriptorBase<T>> {

    private final String name;
    private final Optional<Integer> parentIdentifier;
    private Optional<String> description = Optional.empty();
    private Optional<String> userText = Optional.empty();

    protected abstract T self();

    /**
     * Creates a new object.
     * @param containerName Container name. Must not be empty.
     * @throws IllegalArgumentException If the name is null or empty.
     */
    protected ContainerCreationDescriptorBase(@Nonnull String containerName) {
        checkArgument(!isNullOrEmpty(containerName), "A Container name must not be empty!");
        name = containerName;
        parentIdentifier = Optional.empty();
    }

    /**
     * Creates a new object.
     * @param parentContainer Parent Container identifier. Must be positive.
     * @param containerName Container name. Must not be empty.
     * @throws IllegalArgumentException If the name is null or empty or if the parent identifier is zero or negative.
     */
    protected ContainerCreationDescriptorBase(int parentContainer, @Nonnull String containerName) {
        checkArgument(parentContainer >= 0, "A Container ID must be positive!");
        checkArgument(!isNullOrEmpty(containerName), "A Container name must not be empty!");
        name = containerName;
        parentIdentifier = Optional.of(parentContainer);
    }

    /**
     * @return The new Container name.
     */
    public String getName() {
        return name;
    }

    /**
     * @return The parent container identifier.
     */
    public Optional<Integer> getParentIdentifier() {
        return parentIdentifier;
    }

    /**
     * @return The new Container description.
     */
    public Optional<String> getDescription() {
        return description;
    }

    /**
     * @param description The new Container description.
     */
    public T setDescription(@Nonnull Optional<String> description) {
        this.description = description;
        return self();
    }

    /**
     * @return The new container user text.
     */
    public Optional<String> getUserText() {
        return userText;
    }

    /**
     * @param userText The new Container user text.
     */
    public T setUserText(Optional<String> userText) {
        this.userText = userText;
        return self();
    }
}
