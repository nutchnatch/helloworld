package com.ossnms.dcn_manager.core.utils;

import java.util.stream.Stream;
import java.util.stream.StreamSupport;

public enum Streams {
    ;

    /**
     * @return of items from iterable
     */
    public static <T> Stream<T> stream(Iterable<T> iterable) {
        return StreamSupport.stream(iterable.spliterator(), false);
    }
}
