package com.ossnms.dcn_manager.core.events.domain;

import com.google.common.base.Objects;

/**
 * Informs that domain membership (participation) has been added for a given NE.
 */
public class DomainParticipationAdded extends DomainEvent {

    private final int neId;

    /**
     * Creates a new object.
     * @param domainId The affected domain ID.
     * @param neId The NE identifier being added to the domain.
     */
    public DomainParticipationAdded(int domainId, int neId) {
        super(domainId);
        this.neId = neId;
    }

    /**
     * @return The NE identifier being added to the domain.
     */
    public int getNeId() {
        return neId;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(super.hashCode(), neId);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final DomainParticipationAdded rhs = (DomainParticipationAdded) obj;
        return getDomainId() == rhs.getDomainId() && neId == rhs.neId;
    }
}
