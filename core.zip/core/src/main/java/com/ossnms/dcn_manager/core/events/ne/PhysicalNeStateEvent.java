package com.ossnms.dcn_manager.core.events.ne;

import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.Immutable;
import java.util.Objects;
import java.util.Optional;


/**
 * <p>Used to signal physical NE activation state changes on a specific mediator server. Derived classes
 * represent specific NE activation events. This class follows closely the implementation of
 * {@link ActualNeStateEvent} because the logical state mirrors the physical state (or a combination
 * thereof, depending on the strategy).</p>
 *
 * @see ActualNeStateEvent
 */
@Immutable
public abstract class PhysicalNeStateEvent extends NeEvent {

    private final int logicalNeId;
    private final boolean instanceActive;

    /**
     * Initiates an instance with the given arguments.
     * @param neId The affected physical NE identifier.
     * @param logicalNeId The affected logical NE identifier.
     * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
     * standby instance).
     */
    protected PhysicalNeStateEvent(int neId, int logicalNeId, boolean instanceActive) {
        super(neId);
        this.logicalNeId = logicalNeId;
        this.instanceActive = instanceActive;
    }

    /**
     * Initiates an instance with the given arguments.
     * @param neId The affected physical NE identifier.
     * @param logicalNeId The affected logical NE identifier.
     * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
     * standby instance).
     * @param detailedDescription Human-readable event description.
     */
    protected PhysicalNeStateEvent(int neId, int logicalNeId, boolean instanceActive, @Nonnull String detailedDescription) {
        super(neId, detailedDescription);
        this.logicalNeId = logicalNeId;
        this.instanceActive = instanceActive;
    }

    /**
     * Obtains the affected logical NE identifier. The main event NE Identifier refers to the physical NE instance.
     * @return The affected logical NE identifier.
     */
    public int getLogicalNeId() {
        return logicalNeId;
    }

    /**
     * @return Whether this refers to the physical mediator server instance that is currently active (as opposed to the
     * standby instance).
     */
    public boolean isInstanceActive() {
        return instanceActive;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNeId(), getDetailedDescription(), logicalNeId, instanceActive);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final PhysicalNeStateEvent rhs = (PhysicalNeStateEvent) obj;
        return new EqualsBuilder()
                .append(getNeId(), rhs.getNeId())
                .append(getDetailedDescription(), rhs.getDetailedDescription())
                .append(logicalNeId, rhs.logicalNeId)
                .append(instanceActive, rhs.instanceActive)
                .isEquals();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("logicalNeId", logicalNeId)
                .append("instanceActive", instanceActive)
                .toString();
    }

    @Immutable
    public abstract static class PhysicalNeStateEventWithCounters extends PhysicalNeStateEvent {
        private final NeSynchronizationData synchronizationCounters;

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         */
        public PhysicalNeStateEventWithCounters(int physicalNeId, int logicalNeId, boolean instanceActive) {
            super(physicalNeId, logicalNeId, instanceActive);
            this.synchronizationCounters = null;
        }

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         * @param synchronizationCounters Any NE synchronization counters received from mediation. May be null.
         */
        public PhysicalNeStateEventWithCounters(int physicalNeId, int logicalNeId, boolean instanceActive,
                                          @Nullable NeSynchronizationData synchronizationCounters) {
            super(physicalNeId, logicalNeId, instanceActive);
            this.synchronizationCounters = synchronizationCounters;
        }

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         * @param detailedDescription Human-readable event description.
         */
        public PhysicalNeStateEventWithCounters(int physicalNeId, int logicalNeId, boolean instanceActive, String detailedDescription) {
            super(physicalNeId, logicalNeId, instanceActive, detailedDescription);
            this.synchronizationCounters = null;
        }

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         * @param synchronizationCounters Any NE synchronization counters received from mediation. May be null.
         */
        public PhysicalNeStateEventWithCounters(int physicalNeId, int logicalNeId, boolean instanceActive,
                String detailedDescription, @Nullable NeSynchronizationData synchronizationCounters) {
            super(physicalNeId, logicalNeId, instanceActive, detailedDescription);
            this.synchronizationCounters = synchronizationCounters;
        }


        /**
         * @return Any NE synchronization counters received from mediation.
         */
        public Optional<NeSynchronizationData> getSynchronizationCounters() {
            return Optional.ofNullable(synchronizationCounters);
        }

        @Override
        public int hashCode() {
            return Objects.hash(super.hashCode(), synchronizationCounters);
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (null == obj || !getClass().equals(obj.getClass())) {
                return false;
            }
            final PhysicalNeStateEventWithCounters rhs = (PhysicalNeStateEventWithCounters) obj;
            return new EqualsBuilder()
                    .append(getNeId(), rhs.getNeId())
                    .append(getDetailedDescription(), rhs.getDetailedDescription())
                    .append(getLogicalNeId(), rhs.getLogicalNeId())
                    .append(isInstanceActive(), rhs.isInstanceActive())
                    .append(synchronizationCounters, rhs.synchronizationCounters)
                    .isEquals();
        }

        @Override
        public String toString() {
            return new ToStringBuilder(this)
                    .appendSuper(super.toString())
                    .append("synchronizationCounters", synchronizationCounters)
                    .toString();
        }
    }
    
    
    
    /**
     * Class whose instances represent events used to signal that a NE is disconnecting.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalNeDisconnectingEvent extends PhysicalNeStateEvent {

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         */
        public PhysicalNeDisconnectingEvent(int physicalNeId, int logicalNeId, boolean instanceActive) {
            super(physicalNeId, logicalNeId, instanceActive);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         * @param detailedDescription Human-readable event description.
         */
        public PhysicalNeDisconnectingEvent(int physicalNeId, int logicalNeId, boolean instanceActive, String detailedDescription) {
            super(physicalNeId, logicalNeId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a NE has disconnected.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalNeDisconnectedEvent extends PhysicalNeStateEvent {

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         */
        public PhysicalNeDisconnectedEvent(int physicalNeId, int logicalNeId, boolean instanceActive) {
            super(physicalNeId, logicalNeId, instanceActive);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         * @param detailedDescription Human-readable event description.
         */
        public PhysicalNeDisconnectedEvent(int physicalNeId, int logicalNeId, boolean instanceActive, String detailedDescription) {
            super(physicalNeId, logicalNeId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a NE has connected.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalNeConnectedEvent extends PhysicalNeStateEvent {

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         */
        public PhysicalNeConnectedEvent(int physicalNeId, int logicalNeId, boolean instanceActive) {
            super(physicalNeId, logicalNeId, instanceActive);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         * @param detailedDescription Human-readable event description.
         */
        public PhysicalNeConnectedEvent(int physicalNeId, int logicalNeId, boolean instanceActive, String detailedDescription) {
            super(physicalNeId, logicalNeId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a NE is connecting.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalNeConnectingEvent extends PhysicalNeStateEvent {

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         */
        public PhysicalNeConnectingEvent(int physicalNeId, int logicalNeId, boolean instanceActive) {
            super(physicalNeId, logicalNeId, instanceActive);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         * @param detailedDescription Human-readable event description.
         */
        public PhysicalNeConnectingEvent(int physicalNeId, int logicalNeId, boolean instanceActive, String detailedDescription) {
            super(physicalNeId, logicalNeId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a NE is initializing.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalNeInitializingEvent extends PhysicalNeStateEvent {

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         */
        public PhysicalNeInitializingEvent(int physicalNeId, int logicalNeId, boolean instanceActive) {
            super(physicalNeId, logicalNeId, instanceActive);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         * @param detailedDescription Human-readable event description.
         */
        public PhysicalNeInitializingEvent(int physicalNeId, int logicalNeId, boolean instanceActive, String detailedDescription) {
            super(physicalNeId, logicalNeId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a NE is initialized.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalNeInitializedEvent extends PhysicalNeStateEventWithCounters {

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         */
        public PhysicalNeInitializedEvent(int physicalNeId, int logicalNeId, boolean instanceActive) {
            super(physicalNeId, logicalNeId, instanceActive);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         * @param synchronizationCounters Any NE synchronization counters received from mediation. May be null.
         */
        public PhysicalNeInitializedEvent(int physicalNeId, int logicalNeId, boolean instanceActive,
                                          @Nullable NeSynchronizationData synchronizationCounters) {
            super(physicalNeId, logicalNeId, instanceActive, synchronizationCounters);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         * @param detailedDescription Human-readable event description.
         */
        public PhysicalNeInitializedEvent(int physicalNeId, int logicalNeId, boolean instanceActive, String detailedDescription) {
            super(physicalNeId, logicalNeId, instanceActive, detailedDescription);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         * @param detailedDescription Human-readable event description.
         */
        public PhysicalNeInitializedEvent(int physicalNeId, int logicalNeId, boolean instanceActive, String detailedDescription, @Nullable NeSynchronizationData synchronizationCounters) {
            super(physicalNeId, logicalNeId, instanceActive, detailedDescription, synchronizationCounters);
        }
    }

    /**
     * Class whose instances represent events used to signal that a NE is starting up (pending connection).
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalNeStartingUpEvent extends PhysicalNeStateEvent {

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         */
        public PhysicalNeStartingUpEvent(int physicalNeId, int logicalNeId, boolean instanceActive) {
            super(physicalNeId, logicalNeId, instanceActive);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         * @param detailedDescription Human-readable event description.
         */
        public PhysicalNeStartingUpEvent(int physicalNeId, int logicalNeId, boolean instanceActive, String detailedDescription) {
            super(physicalNeId, logicalNeId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a NE is shutting down (pending disconnection).
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalNeShuttingDownEvent extends PhysicalNeStateEvent {

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         */
        public PhysicalNeShuttingDownEvent(int physicalNeId, int logicalNeId, boolean instanceActive) {
            super(physicalNeId, logicalNeId, instanceActive);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         * @param detailedDescription Human-readable event description.
         */
        public PhysicalNeShuttingDownEvent(int physicalNeId, int logicalNeId, boolean instanceActive, String detailedDescription) {
            super(physicalNeId, logicalNeId, instanceActive, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that the mediation has lost synchronization of its
     * state against an NE. This is not necessarily a failure even though it requires recovery actions.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class PhysicalNeSynchronizationLostEvent extends PhysicalNeStateEventWithCounters {
        
        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         */
        public PhysicalNeSynchronizationLostEvent(int physicalNeId, int logicalNeId, boolean instanceActive) {
            super(physicalNeId, logicalNeId, instanceActive);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         * @param detailedDescription Human-readable event description.
         */
        public PhysicalNeSynchronizationLostEvent(int physicalNeId, int logicalNeId, boolean instanceActive, String detailedDescription) {
            this(physicalNeId, logicalNeId, instanceActive, detailedDescription, null);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         * @param detailedDescription Human-readable event description.
         * @param synchronizationCounters Any NE synchronization counters received from mediation. May be null.
         */
        public PhysicalNeSynchronizationLostEvent(int physicalNeId, int logicalNeId, boolean instanceActive, @Nullable NeSynchronizationData synchronizationCounters) {
            super(physicalNeId, logicalNeId, instanceActive, synchronizationCounters);
        }


        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         * @param detailedDescription Human-readable event description.
         * @param synchronizationCounters Any NE synchronization counters received from mediation. May be null.
         */
        public PhysicalNeSynchronizationLostEvent(int physicalNeId, int logicalNeId, boolean instanceActive, String detailedDescription, @Nullable NeSynchronizationData synchronizationCounters) {
            super(physicalNeId, logicalNeId, instanceActive, detailedDescription, synchronizationCounters);
        }

    }

    /**
     * Maps all mediation failure events related to activation: connection
     * failure, initialization failure, synchronization lost... As far as
     * we're concerned, an NE is in a failed state regardless of the exact
     * failure condition.
     */
    @Immutable
    public static final class PhysicalNeActivationFailedEvent extends PhysicalNeStateEvent {

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         */
        public PhysicalNeActivationFailedEvent(int physicalNeId, int logicalNeId, boolean instanceActive) {
            super(physicalNeId, logicalNeId, instanceActive);
        }

        /**
         * Initiates an instance with the given arguments.
         * @param physicalNeId The affected physical NE identifier.
         * @param logicalNeId The affected logical NE identifier.
         * @param instanceActive Whether this refers to the physical mediator server instance that is currently active (as opposed to the
         * standby instance).
         * @param detailedDescription Human-readable event description.
         */
        public PhysicalNeActivationFailedEvent(int physicalNeId, int logicalNeId, boolean instanceActive, String detailedDescription) {
            super(physicalNeId, logicalNeId, instanceActive, detailedDescription);
        }
    }
}
