package com.ossnms.dcn_manager.core.entities.ne.data;

import com.ossnms.dcn_manager.core.entities.PropertyBag;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationInitialData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.GatewayMode;

import java.util.Optional;

/**
 * Defines the contract that must be fulfilled by all objects that intend to supply
 * values for NE properties. Well known properties are materialized in the concrete
 * domain objects, which means that they must be exposed as attribute getters in
 * this interface. Other properties continue to be exposed through {@link PropertyBag}.
 */
public interface NePropertySource extends PropertyBag {

    /**
     * @return An instance of a property source related to the NE Info domain object.
     */
    NeInfoPropertySource getInfo();

    /**
     * @return An instance of a property source related to the NE Preferences domain object.
     */
    NePreferencesPropertySource getPreferences();

    /**
     * @return An instance of a property source related to the NE Operation domain object.
     */
    NeOperationPropertySource getOperation();

    /**
     * Defines the attributes that are accessible through properties, also known as
     * "well known properties", from the NE Info domain object.
     * @see com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames
     */
    interface NeInfoPropertySource {

        String getProxyType();

    }

    /**
     * Defines the attributes that are accessible through properties, also known as
     * "well known properties", from the NE Operation domain object.
     * @see WellKnownNePropertyNames
     */
    interface NeOperationPropertySource {

        Optional<String> getRealNeName();

        Optional<String> getNeighbourhoodId();
        
        Optional<String> getAdditionalTypeInfo();
        
       Optional<GatewayMode> getGatewayMode();
    }

    /**
     * Defines the attributes that are accessible through properties, also known as
     * "well known properties", from the NE Preferences domain object.
     * @see WellKnownNePropertyNames
     */
    interface NePreferencesPropertySource extends PropertyBag {

        PropertyBag getDirectRoute();

        String getName();

        boolean usesGne();

        boolean usesFlatIp();

        int getReconnectInterval();

        Optional<String> getGlobalId();

        Optional<String> getPassword();

        Optional<String> getUserName();

        RouteSortingMode getRouteSortingMode();
        
        NeDataTransferSettings getDataTransferSettings();

        Optional<String> getUserText();
    }
}
