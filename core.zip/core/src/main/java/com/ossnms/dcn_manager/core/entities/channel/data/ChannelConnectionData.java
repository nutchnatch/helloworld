package com.ossnms.dcn_manager.core.entities.channel.data;

import com.google.common.base.MoreObjects;
import com.google.common.base.MoreObjects.ToStringHelper;
import com.mysema.query.annotations.QueryEntity;
import com.ossnms.dcn_manager.core.entities.BusinessObjectData;

/**
 * <p> Class that implements the data dimension of the domain object that describes the channel's
 * connection state or, in other words, the solution's connectivity to the given channel. </p>
 *
 * <p>As all types that implement domain objects' data dimension, instances of this class are immutable,
 * and are therefore thread-safe.</p>
 */
@QueryEntity
public final class ChannelConnectionData extends BusinessObjectData {

    /** Actual connection state. */
    private final ActualActivationState activation;

    /** Annotation information associated to the channel's connection state. */
    private final String additionalInfo;

    /**
     * Initiates an instance with the given initial data.
     * @param channelId The domain object identifier (i.e. the same as its domain entity instance)
     * @param version The domain object's version number
     * @param prototype Initial instance data.
     */
    public ChannelConnectionData(int channelId, int version, ChannelConnectionPrototype<?> prototype) {
        super(channelId, version);
        this.activation = prototype.activation;
        this.additionalInfo = prototype.additionalInfo;
    }

    /** @return The actual activation state. This means that the connection to the mediator and the actual channel is alive. */
    public ActualActivationState getActualActivationState() {
        return activation;
    }

    /** @return User-friendly state description. */
    public String getAdditionalInfo() {
        return additionalInfo;
    }

    /** @return A boolean value indicating whether the channel is currently connected to the mediator */
    public boolean isActive() {
        return activation == ActualActivationState.ACTIVE;
    }

    /** @return A boolean value indicating whether the channel is currently failed */
    public boolean isFailed() {
        return activation == ActualActivationState.FAILED;
    }

    /** {@inheritDoc} */
	@Override
	public String toString() {
        final ToStringHelper helper = MoreObjects.toStringHelper(this);
        helper.addValue(super.toString());
        helper.add("additional_info", getAdditionalInfo());
        helper.add("activation_state", getActualActivationState());
        return helper.toString();
	}

    /**
     * Facilitates the creation of a data object by allowing
     * individual attributes to be set easily.
     */
    public static final class ChannelConnectionBuilder extends ChannelConnectionPrototype<ChannelConnectionBuilder> {

        public ChannelConnectionData build(int channelId, int version) {
            return new ChannelConnectionData(channelId, version, this);
        }

        @Override
        protected ChannelConnectionBuilder self() {
            return this;
        }

    }

    /**
     * Contains initial data values for the data object (it's a parameter object).
     */
	public static final class ChannelConnectionInitialData extends ChannelConnectionPrototype<ChannelConnectionInitialData> {

        @Override
        protected ChannelConnectionInitialData self() {
            return this;
        }

	}

	private abstract static class ChannelConnectionPrototype<T extends ChannelConnectionPrototype<T>> {

	    private ActualActivationState activation = ActualActivationState.INACTIVE;
	    private String additionalInfo = "";

	    protected ChannelConnectionPrototype() {

	    }

	    protected abstract T self();

        /**
         * @param activation The actual activation state.
         */
        public T setActivation(ActualActivationState activation) {
            this.activation = activation;
            return self();
        }

        /**
         * @param additionalInfo Annotation information associated with the channel's connection state.
         */
        public T setAdditionalInfo(String additionalInfo) {
            this.additionalInfo = additionalInfo;
            return self();
        }


	}
}
