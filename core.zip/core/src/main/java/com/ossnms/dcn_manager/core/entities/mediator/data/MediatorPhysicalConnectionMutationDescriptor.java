package com.ossnms.dcn_manager.core.entities.mediator.data;

import com.google.common.base.MoreObjects;
import com.google.common.base.MoreObjects.ToStringHelper;
import com.google.common.base.Objects;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData.MediatorPhysicalConnectionBuilder;

import javax.annotation.Nonnull;
import java.time.Instant;
import java.util.Optional;

/**
 * <p>Describes all changes requested to an instance of {@link MediatorPhysicalConnectionData}.</p>
 * <p>Like all mutation descriptors, this class is not thread safe.</p>
 */
public class MediatorPhysicalConnectionMutationDescriptor
        extends MutationDescriptor<MediatorPhysicalConnectionData, MediatorPhysicalConnectionMutationDescriptor> {

    private Optional<ActualActivationState> activeState = Optional.empty();
    private Optional<String> additionalInfo = Optional.empty();
    private Optional<Boolean> active = Optional.empty();
    private Optional<Instant> failureTimestamp = Optional.empty();
    private Optional<Integer> activationAttemptsCounter = Optional.empty();

    /**
     * Creates a new mutation descriptor object.
     * @param target Target instance for the mutation.
     */
   public MediatorPhysicalConnectionMutationDescriptor(@Nonnull MediatorPhysicalConnectionData target) {
        super(target);
    }

    @Override
    protected MediatorPhysicalConnectionMutationDescriptor self() {
        return this;
    }

    @Override
    protected MediatorPhysicalConnectionData doApply() {
        final boolean stateChanged = activeState.isPresent() || additionalInfo.isPresent() || active.isPresent();
        final boolean activationCountersChanged = failureTimestamp.isPresent() || activationAttemptsCounter.isPresent();
        return stateChanged || activationCountersChanged
                ? new MediatorPhysicalConnectionBuilder()
                    .setActualActivationState(activeState.orElse(getTarget().getActualActivationState()))
                    .setAdditionalInfo(additionalInfo.orElse(getTarget().getAdditionalInfo()))
                    .setActive(active.orElse(getTarget().isActive()))
                    .setLastFailureTimestamp(failureTimestamp.map(Optional::of).orElse(getTarget().getLastFailureTimestamp()))
                    .setActivationAttemptsCounter(activationAttemptsCounter.orElse(getTarget().getActivationAttemptsCounter()))
                    .build(getTarget().getId(), getTarget().getLogicalMediatorId(), getTarget().getVersion() + 1)
                : getTarget();
    }

    /**
     * @return The new current activation state of the Mediator.
     */
    public Optional<ActualActivationState> getActiveState() {
        return activeState;
    }

    /**
     * @param activeState The new current activation state of the Mediator.
     */
    public MediatorPhysicalConnectionMutationDescriptor setActiveState(@Nonnull ActualActivationState activeState) {
        if (!Objects.equal(this.activeState.orElse(getTarget().getActualActivationState()), activeState)) {
            this.activeState = Optional.of(activeState);
        }
        return this;
    }

    /**
     * @return New additional state description.
     */
    public Optional<String> getAdditionalInfo() {
        return additionalInfo;
    }

    /**
     * @param additionalInfo New additional state description.
     * @throws NullPointerException If additionalInfo is null.
     */
    public MediatorPhysicalConnectionMutationDescriptor setAdditionalInfo(@Nonnull String additionalInfo) {
        if (!Objects.equal(this.additionalInfo.orElse(getTarget().getAdditionalInfo()), additionalInfo)) {
            this.additionalInfo = Optional.of(additionalInfo);
        }
        return this;
    }

    /**
     * @return Whether this is will be the Active Mediator instance, within the context of redundancy
     *  (Active vs. Standby).
     */
    public Optional<Boolean> isActive() {
        return active;
    }

    /**
     * @param active Whether this is will be the Active Mediator instance, within the context of redundancy
     *  (Active vs. Standby).
     */
    public MediatorPhysicalConnectionMutationDescriptor setActive(boolean active) {
        if (this.active.orElse(getTarget().isActive()) != active) {
            this.active = Optional.of(active);
        }
        return this;
    }

    /**
     * @param newFailureTimestamp New timestamp of the last recorded failure.
     * @throws NullPointerException If newFailureTimestamp is null.
     */
    public MediatorPhysicalConnectionMutationDescriptor setLastFailureTimestamp(@Nonnull Instant newFailureTimestamp) {
        if (!Objects.equal(failureTimestamp.map(Optional::of).orElse(getTarget().getLastFailureTimestamp()).orElse(null), newFailureTimestamp)) {
            failureTimestamp = Optional.of(newFailureTimestamp);
        }
        return this;
    }

    /**
     * @return New timestamp of the last recorded failure.
     */
    public Optional<Instant> getLastFailureTimestamp() {
        return failureTimestamp;
    }

    /**
     * @param newCounterValue New activation attempts counter value.
     */
    public MediatorPhysicalConnectionMutationDescriptor setActivationAttemptsCounter(int newCounterValue) {
        if (activationAttemptsCounter.orElse(getTarget().getActivationAttemptsCounter()) != newCounterValue) {
            activationAttemptsCounter = Optional.of(newCounterValue);
        }
        return this;
    }

    /**
     * @return New activation attempts counter value.
     */
    public Optional<Integer> getActivationAttemptsCounter() {
        return activationAttemptsCounter;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        final ToStringHelper helper = MoreObjects.toStringHelper(this);
        helper.addValue(super.toString());
        if (activeState.isPresent()) {
            helper.add("activeState", activeState.get());
        }
        if (additionalInfo.isPresent()) {
            helper.add("additionalInfo", additionalInfo.get());
        }
        if (active.isPresent()) {
            helper.add("active", active.get());
        }
        return helper.toString();
    }
}
