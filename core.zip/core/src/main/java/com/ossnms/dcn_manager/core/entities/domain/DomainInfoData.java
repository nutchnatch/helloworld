package com.ossnms.dcn_manager.core.entities.domain;

import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import java.util.Objects;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Strings.isNullOrEmpty;

/**
 * Contains information about a Domain. Domains represent the logical grouping of NEs
 * in the network. They abstract away the underlying organization method: DHCP, Autonomous
 * Systems, EONs, etc.
 */
public final class DomainInfoData extends BusinessObjectData {

    private final String name;
    private final boolean automaticNeActivationPermitted;

    /**
     * Creates a new object.
     * @param domainId Numeric domain identifier.
     * @param version Object version.
     * @param domainName Domain name. Must not be empty.
     * @throws IllegalArgumentException If the name is null or empty.
     */
    public DomainInfoData(int domainId, int version, @Nonnull String domainName) {
        this(domainId, version, domainName, false);
    }

    /**
     * Creates a new object.
     * @param domainId Numeric domain identifier.
     * @param version Object version.
     * @param domainName Domain name. Must not be empty.
     * @param automaticNeActivationPermitted Whether automatic activation of freshly discovered NEs is permitted
     *  within this domain.
     * @throws IllegalArgumentException If the name is null or empty.
     */
    public DomainInfoData(int domainId, int version, @Nonnull String domainName, boolean automaticNeActivationPermitted) {
        super(domainId, version);
        checkArgument(!isNullOrEmpty(domainName), "A domain name must not be empty!");
        this.name = domainName;
        this.automaticNeActivationPermitted = automaticNeActivationPermitted;
    }

    /**
     * @return The domain name.
     */
    public String getName() {
        return name;
    }

    /**
     * @return Whether automatic activation of freshly discovered NEs is permitted
     *  within this domain.
     */
    public boolean isAutomaticNeActivationPermitted() {
        return automaticNeActivationPermitted;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
            .appendSuper(super.toString())
            .append("name", name)
            .append("automaticNeActivationPermitted", isAutomaticNeActivationPermitted())
            .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), name, automaticNeActivationPermitted);
    }

    /* (non-Javadoc)
     * @see com.ossnms.dcn_manager.core.entities.BusinessObjectData#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object theOther) {
        if (this == theOther) {
            return true;
        }
        if (theOther == null || !getClass().equals(theOther.getClass())) {
            return false;
        }

        final DomainInfoData other = (DomainInfoData) theOther;
        return super.equals(theOther) &&
            Objects.equals(name, other.name) && automaticNeActivationPermitted == other.automaticNeActivationPermitted;
    }

}
