package com.ossnms.dcn_manager.core.properties.ne;

import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.properties.EntityPropertyOperations;

/**
 * Contains well known DCN Manager operational property names as mentioned in the user interface description files.
 */
public enum NeOperationalProperty implements EntityPropertyOperations {

    /* Well known NE properties. */

    NEIGHBOURHOOD_ID(new NePropertyOperations(WellKnownNePropertyNames.NEIGHBOURHOOD_ID)),

    NETWORK_NAME(new NePropertyOperations(WellKnownNePropertyNames.SYSNAME)),
    
    ADDITIONAL_TYPE_INFO(new NePropertyOperations(WellKnownNePropertyNames.ADDITIONAL_TYPE_INFO));
    
    

    private final NePropertyOperations delegate;

    private NeOperationalProperty(NePropertyOperations delegate) {
        this.delegate = delegate;
    }

    @Override
    public String getName() {
        return delegate.getName();
    }

    @Override
    public Scope getScope() {
        return delegate.getScope();
    }

    @Override
    public String toString() {
        return delegate.toString();
    }
}
