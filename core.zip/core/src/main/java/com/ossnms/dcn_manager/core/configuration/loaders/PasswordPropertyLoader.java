package com.ossnms.dcn_manager.core.configuration.loaders;

import com.ossnms.dcn_manager.core.configuration.model.PasswordPropertyMetadata;
import com.ossnms.dcn_manager.migration.jaxb.passwordproperties.Properties;

import java.net.URL;

class PasswordPropertyLoader extends ModelLoader<Properties> {
    public PasswordPropertyMetadata load(Iterable<URL> filesToLoad) {
        return new PasswordPropertyMetadata(loadValues(Properties.class, filesToLoad));
    }
}
