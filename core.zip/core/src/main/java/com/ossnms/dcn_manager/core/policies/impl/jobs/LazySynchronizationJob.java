package com.ossnms.dcn_manager.core.policies.impl.jobs;

import com.ossnms.dcn_manager.core.events.ne.NeSynchronizationEvent;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;

import javax.annotation.Nonnull;

/**
 * Class whose instances represent jobs that trigger a lazy initialization of a given NE.
 * Should be used when responding to a recently connected NE.
 */
public class LazySynchronizationJob extends NeJob<NeSynchronizationEvent> {

    private final NeConnectionManager connectionManager;

    public LazySynchronizationJob(
            @Nonnull NeSynchronizationEvent requestEvent, @Nonnull NeConnectionManager connectionManager) {
        super(requestEvent, Priority.MEDIUM);
        this.connectionManager = connectionManager;
    }

    /** {@inheritDoc} */
    @Override
    protected void runJob() {
        connectionManager.lazyInitialize(getOriginatingEvent());
    }

}