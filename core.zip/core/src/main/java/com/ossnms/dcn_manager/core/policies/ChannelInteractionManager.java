package com.ossnms.dcn_manager.core.policies;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.core.events.channel.ActualChannelStateEvent;
import com.ossnms.dcn_manager.core.events.channel.RequiredChannelStateEvent;

/**
 * <p>Contract to be supported by classes that implement channel interaction management policies,
 * whose instances are responsible for managing interactions between the component and mediation
 * (i.e. through Connection Manager). The goal of such policies is to regulate DCN load imposed
 * by those interactions, in particular, between the component and multiple channels in a given
 * mediation.</p>
 *
 * <p>Although it is not expected that multiple policy implementations coexist, the definition of this
 * interface enables the complete characterization of the provided service without compromising concrete
 * implementations with lifetime management issues imposed by connectors.</p>
 *
 * <p>Operations that return channel interaction metrics (e.g. {@link #getPendingJobCount()}) are
 * merely informative and are not required to produce exact counts. This relaxation is important because
 * it enables the use of optimistic approaches to concurrency. Note that using pessimistic approaches would
 * be overkill because software components that would use those values to make decisions regarding interaction
 * regulation, would be broken by definition; check-and-act races would be inevitable. It is therefore the
 * job of {@link ChannelInteractionManager} implementations to make those decisions.</p>
 */
public interface ChannelInteractionManager {

	/**
	 * Schedules the actual activation of the channel whose activation as just been marked as required.
	 * @param event the event bearing the relevant information
	 */
	void scheduleActivation(@Nonnull RequiredChannelStateEvent.Activate event);

	/**
	 * Schedules the actual deactivation of the channel whose deactivation as just been marked as required.
	 * @param event the event bearing the relevant information
	 */
	void scheduleDeactivation(@Nonnull RequiredChannelStateEvent.Deactivate event);

    /**
     * Cancels all pending and ongoing deactivations for a channel with the given identifier.
     * @param event event bearing Channel identification information.
     */
    void cancelDeactivations(@Nonnull RequiredChannelStateEvent event);

    /**
     * Cancels all pending and ongoing activations for a channel with the given identifier.
     * @param event event bearing Channel identification information.
     */
    void cancelActivations(@Nonnull RequiredChannelStateEvent event);

    /**
     * Informs that a channel interaction has ended.
     * @param channelStateEvent Event information.
     */
	void onChannelInteractionEnded(@Nonnull ActualChannelStateEvent channelStateEvent);

    /**
     * @return The number of pending jobs (activation and deactivation interactions), regardless of
     * the channel's mediator.
     */
    int getPendingJobCount();

    /**
     * @return The number of ongoing jobs (activation and deactivation interactions), regardless of
     * the channel's mediator.
     */
    int getOngoingJobCount();

    /**
     * Gets the number of pending jobs (activation and deactivation channel interactions), for the
     * given mediation.
     * @param mediatorId The mediation identifier.
     * @return The number of pending jobs, or {@value 0} if the identifier is not recognized
     * by the implementation.
     */
    int getPendingJobCount(int mediatorId);

    /**
     * Gets the number of ongoing jobs (activation and deactivation interactions), for the
     * given mediation.
     * @param mediatorId The mediation identifier.
     * @return The number of ongoing jobs, or {@value 0} if the identifier is not recognized
     * by the implementation.
     */
    int getOngoingJobCount(int mediatorId);

    /**
     * Gets the maximum number of allowed simultaneous jobs (i.e. channel interactions), for the
     * given mediation.
     * @param mediatorId The mediation identifier.
     * @return The maximum number of allowed simultaneous jobs.
     */
    int getMaxOngoingJobCount(int mediatorId);

    /**
     * Sets the maximum number of allowed simultaneous jobs (i.e. channel interactions) for the given mediation.
     * This configuration change may not have immediate effect, meaning, ongoing jobs will not be cancelled.
     * @param mediatorId The mediation identifier.
     * @param newMaxInteractions The new maximum number of allowed simultaneous jobs.
     * @throws IllegalArgumentException If {@literal newMaxInteractions} is not greater
     * than {@value 0}.
     */
    void setMaxOngoingJobCount(int mediatorId, int newMaxInteractions);

    /**
     * close all resources
     *
     */
    void close();
}
