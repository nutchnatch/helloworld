package com.ossnms.dcn_manager.core.entities.ne.data;

import java.util.Optional;

import com.ossnms.dcn_manager.core.entities.ne.data.types.GatewayMode;

/**
 * Defines a contract that must be common across all classes that can set operation  property
 * data. It is intended to allow property management objects to set values both on
 * the mutation descriptors and initial domain object data parameter objects.
 *
 * @param <T> The final implementing type, to allow for a fluent API.
 */
public interface NeOperationPropertySetters<T extends NeOperationPropertySetters<T>> {

    Optional<String> getNeighbourhoodId();

    T setNeighbourhoodId(String neighbourhoodId);
    
    T setAdditionalTypeInfo(String additionalTypeInfo);
    
    T setGatewayMode(GatewayMode gatewayRole);

    Optional<String> getRealNeName();

    T setRealNeName(String networkName);

}