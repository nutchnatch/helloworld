package com.ossnms.dcn_manager.core.entities.container.system;

import com.ossnms.dcn_manager.core.entities.container.ContainerDeletionDescriptorBase;

/**
 * Contains all information required to delete an existing System Container.
 */
public final class SystemDeletionDescriptor extends ContainerDeletionDescriptorBase {

    /**
     * Creates a new object.
     * @param systemId System Container identifier.
     * @throws IllegalArgumentException If the identifier is invalid.
     */
    public SystemDeletionDescriptor(int systemId) {
        super(systemId);
    }

}
