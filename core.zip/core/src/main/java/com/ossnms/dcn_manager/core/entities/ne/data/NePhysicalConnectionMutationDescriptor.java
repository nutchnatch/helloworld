package com.ossnms.dcn_manager.core.entities.ne.data;

import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;

import javax.annotation.Nonnull;
import java.time.Instant;
import java.util.Optional;

/**
 * Contains all data that should be changed on {@link NePhysicalConnectionData},
 * when applied as a single atomic mutation by the repository.
 */
public class NePhysicalConnectionMutationDescriptor
        extends MutationDescriptor<NePhysicalConnectionData, NePhysicalConnectionMutationDescriptor> {

    private Optional<Boolean> active = Optional.empty();
    private Optional<ActualActivationState> activationState = Optional.empty();
    private Optional<String> additionalInfo = Optional.empty();
    private Optional<Integer> retryCounter = Optional.empty();
    private Optional<Instant> initStageStartTime = Optional.empty();
    private Optional<ActualActivationMode> activationMode = Optional.empty();
    private Optional<Integer> channelInstanceId = Optional.empty();

    public NePhysicalConnectionMutationDescriptor(NePhysicalConnectionData target) {
        super(target);
    }

    @Override
    protected NePhysicalConnectionMutationDescriptor self() {
        return this;
    }

    @Override
    protected NePhysicalConnectionData doApply() {
        NePhysicalConnectionData target = getTarget();
        final boolean isActivationInfoSet = activationState.isPresent() || additionalInfo.isPresent() ||
                activationMode.isPresent() || active.isPresent();
        return isActivationInfoSet || retryCounter.isPresent() || initStageStartTime.isPresent() || channelInstanceId.isPresent()
                ? new NePhysicalConnectionBuilder()
                    .setActivationState(activationState.orElse(target.getActualActivationState()))
                    .setActivationMode(activationMode.orElse(target.getActualActivationMode()))
                    .setAdditionalInfo(additionalInfo.orElse(target.getAdditionalInfo()))
                    .setActive(active.orElse(target.isActive()))
                    .setRetryCounter(retryCounter.orElse(target.getRetryCounter()))
                    .setInitStartTime(initStageStartTime.map(Optional::of).orElse(target.getInitStageStartTime()))
                    .build(target.getId(), target.getLogicalNeId(), channelInstanceId.orElse(target.getChannelInstanceId()), target.getVersion())
                : target;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .omitNullValues()
                .add("additionalInfo", additionalInfo.orElse(null))
                .add("active", active.orElse(null))
                .add("activationState", activationState.orElse(null))
                .add("activationMode", activationMode.orElse(null))
                .add("retryCounter", retryCounter.orElse(null))
                .add("initStageStartTime", initStageStartTime.orElse(null))
                .add("channelId", channelInstanceId.orElse(null))
                .toString();
    }

    /**
     * @return Additional connection information to display to the operator.
     */
    public Optional<String> getAdditionalInfo() {
        return additionalInfo;
    }

    /**
     * @param additionalInfo Additional connection information for the operator.
     */
    public NePhysicalConnectionMutationDescriptor setAdditionalInfo(@Nonnull String additionalInfo) {
        final Optional<String> newAdditionalInfo = Optional.of(additionalInfo);
        if (!Objects.equal(this.additionalInfo.orElse(getTarget().getAdditionalInfo()), additionalInfo)) {
            this.additionalInfo = newAdditionalInfo;
        }
        return self();
    }

    /**
     * @return Actual NE activation state.
     */
    public Optional<ActualActivationState> getActivationState() {
        return activationState;
    }

    /**
     * @param activationState New actual NE activation state.
     */
    public NePhysicalConnectionMutationDescriptor setActivationState(@Nonnull ActualActivationState activationState) {
        if (!Objects.equal(this.activationState.orElse(getTarget().getActualActivationState()), activationState)) {
            this.activationState = Optional.of(activationState);
        }
        return self();
    }

    /**
     * @return Actual NE activation mode.
     */
    public Optional<ActualActivationMode> getActivationMode() {
        return activationMode;
    }

    /**
     * @param activationMode New actual NE activation mode.
     * @see NePhysicalConnectionData#getActualActivationMode()
     */
    public NePhysicalConnectionMutationDescriptor setActivationMode(@Nonnull ActualActivationMode activationMode) {
        if (!Objects.equal(this.activationMode.orElse(getTarget().getActualActivationMode()), activationMode)) {
            this.activationMode = Optional.of(activationMode);
        }
        return self();
    }

    /**
     * @return Whether this is will be the Active NE instance, within the context of redundancy
     * (Active vs. Standby).
     */
    public Optional<Boolean> isActive() {
        return active;
    }

    /**
     * @param active Whether this is will be the Active NE instance, within the context of redundancy
     *               (Active vs. Standby).
     */
    public NePhysicalConnectionMutationDescriptor setActive(boolean active) {
        if (this.active.orElse(getTarget().isActive()) != active) {
            this.active = Optional.of(active);
        }
        return self();
    }

    /**
     * @return The current retry counter value.
     */
    public Optional<Integer> getRetryCounter() {
        return retryCounter;
    }

    /**
     * @param retryCounter New retry counter value.
     */
    public NePhysicalConnectionMutationDescriptor setRetryCounter(int retryCounter) {
        this.retryCounter = Optional.of(retryCounter);
        return self();
    }

    /**
     * @return The time at which the NE initialization last changed status
     * to started (initializing) or failed. Context is inferred from
     * the current combination of actual activation state and mode.
     */
    public Optional<Instant> getInitStageStartTime() {
        return initStageStartTime;
    }

    /**
     * @param initStageStartTime New time at which the NE initialization last changed status
     *                           to started (initializing) or failed.
     */
    public NePhysicalConnectionMutationDescriptor setInitStageStartTime(@Nonnull Instant initStageStartTime) {
        this.initStageStartTime = Optional.of(initStageStartTime);
        return self();
    }

    /**
     * @return Returns the channel id for this physical ne
     */
    public Optional<Integer> getChannelInstanceId() {
        return channelInstanceId;
    }

    /**
     * Set channel id for this physical ne
     *
     * @return The mutation instance to enable fluent use.
     */
    public NePhysicalConnectionMutationDescriptor setChannelId(int channelId) {
        if (channelInstanceId.orElse(getTarget().getChannelInstanceId()) != channelId) {
            channelInstanceId = Optional.of(channelId);
        }
        return this;
    }

}
