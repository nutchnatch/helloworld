package com.ossnms.dcn_manager.core.storage;

import com.ossnms.dcn_manager.exceptions.RepositoryException;

/**
 * <p>Contract to be supported by all domain entity repositories.</p>
 *
 * @param <T> The domain entity's concrete type
 * @param <C> The domain entity's creation descriptor concrete type
 * @param <D> The domain entity's deletion descriptor concrete type
 */
public interface BusinessEntityRepository<T, C, D> {

	/**
	 * Creates a new entity.
	 *
	 * @param descriptor Entity creation descriptor instance.
	 * @return The new entity instance, after it is stored in the repository.
     * @throws RepositoryException If an error occurs while dealing with the
     *  underlying data source.
	 */
	T create(C descriptor) throws RepositoryException;

	/**
	 * Deletes an existing entity.
	 * This is an idempotent operation.
	 *
	 * @param descriptor Entity deletion descriptor instance.
     * @throws RepositoryException If an error occurs while dealing with the
     *  underlying data source.
	 */
	void delete(D descriptor) throws RepositoryException;
}
