/**
 * <p>Contains data and behavior concerning the management of all NE Domain domain entities.</p>
 *
 * <p>Domains have simple rules:</p>
 * <ul>
 * <li>They have unique names.</li>
 * <li>They may contain zero or more NEs.</li>
 * <li>They are not associated to Channels or Mediators.</li>
 * </ul>
 */
package com.ossnms.dcn_manager.core.entities.domain;

