package com.ossnms.dcn_manager.core.storage.mediator;

import com.mysema.query.collections.CollQuery;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstanceCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalDataMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.QMediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.storage.BusinessObjectRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * <p>Contract to be supported by all Physical/Instance Mediator entity repositories.</p>
 *
 * <p>Physical (or Instance) Mediator entities refer to the actual mediator servers
 * within a redundant system. This is directly related to the System and Mediator Failover
 * features.</p>
 *
 * <p>In a nutshell, one system (or logical) Mediator entity will be materialized in at least
 * one actual Mediator server running somewhere. This server may be supported by a back up
 * server with identical configuration. In this case the system Mediator will be materialized
 * in two actual Mediator servers, the primary and the secondary. Hence we'll get one
 * MediatorEntity and two related MediatorInstance objects.</p>
 *
 * <p>Note that this repository does not provide creation and deletion operations.
 * Because physical mediator instances are strongly connected to their system Mediator
 * counterparts, their lifecycles should also be strongly linked. Hence physical mediator
 * instances are created and deleted together with the main logical Mediator entities.</p>
 */
public interface MediatorInstanceEntityRepository {

    /** Contract to be supported by all repositories of {@link MediatorPhysicalData} domain object instances */
    interface MediatorPhysicalDataRepository
        extends BusinessObjectRepository<MediatorPhysicalData, MediatorPhysicalDataMutationDescriptor> {

        /**
         * Gets the physical instance of a mediator associated with the given host name, if one exists
         * @param hostName The host name.
         * @throws RepositoryException When an error occurs while working with the
         * underlying data storage.
         * @return An {@link Optional} instance bearing the domain object, or an
         * absent {@link Optional} if no domain object exists with the given
         * name.
         */
        Optional<MediatorPhysicalData> queryByHost(String hostName)
                throws RepositoryException;

    }

    /** Contract to be supported by all repositories of {@link MediatorPhysicalConnectionData} domain object instances */
    interface MediatorPhysicalConnectionRepository
        extends BusinessObjectRepository<MediatorPhysicalConnectionData, MediatorPhysicalConnectionMutationDescriptor> {

        /**
         * Provides a query builder object for conducting ad-hoc searches.
         * @param info Query metadata.
         * @return An instance of a query builder object.
         */
        CollQuery query(QMediatorPhysicalConnectionData info);

        /**
         * Gets the sequence composed of all mediator physical instance connections associated
         * with a specific logical mediator.
         *
         * @param logicalMediatorId Identifier of the logical mediator containing the
         *  physical connections we're interested in.
         * @return An {@link Iterable} representing the sequence.
         */
        Iterable<MediatorPhysicalConnectionData> queryAll(int logicalMediatorId);
    }

    /**
     * Gets the repository for the entity's MediatorPhysicalData domain object.
     * @return The corresponding repository instance.
     */
    MediatorPhysicalDataRepository getMediatorPhysicalDataRepository();

    /**
     * Gets the repository for the entity's MediatorPhysicalConnection domain object.
     * @return The corresponding repository instance.
     */
    MediatorPhysicalConnectionRepository getMediatorPhysicalConnectionRepository();

    /**
     * Updates instance information for a Mediator by changing existing configurations and/or creating new ones.
     *
     * @param logicalMediatorId The logical mediator identifier.
     * @param changes Changes that need to be applied to existing physical instance configurations.
     * @param creations Physical instance configurations that need to be created.
     * @throws RepositoryException When an error occurs while working with the
     * underlying data storage.
     */
    MediatorInstanceUpdates updateInstance(int logicalMediatorId,
        @Nonnull Iterable<MediatorPhysicalDataMutationDescriptor> changes, @Nonnull Iterable<MediatorInstanceCreateDescriptor> creations)
            throws RepositoryException;

    /**
     * Deletes a physical Mediator server instance.
     * @param physicalInstanceId Physical Mediator server instance identifier.
     * @throws RepositoryException When an error occurs while working with the
     * underlying data storage.
     */
    void deleteInstance(int physicalInstanceId) throws RepositoryException;

    /**
     * Gets the physical mediator instance with the given identifier, if one exists
     * @param physicalMediatorId The mediator identifier.
     * @throws RepositoryException When an error occurs while working with the
     * underlying data storage.
     * @return An {@link Optional} instance bearing the physical mediator instance, or
     * an absent {@link Optional} if no domain object exists with the given
     * identifier.
     */
    Optional<MediatorInstance> query(int physicalMediatorId) throws RepositoryException;

    /**
     * Gets the sequence composed of all physical mediator instances.
     *
     * @throws RepositoryException When an error occurs while working with the
     * underlying data storage.
     * @return An {@link Iterable} representing the sequence.
     * @see MediatorEntityRepository#queryAll()
     */
    Iterable<MediatorInstance> queryAll() throws RepositoryException;

    /**
     * Gets the sequence composed of all physical mediator instances associated with a logical mediator.
     *
     * @param logicalMediatorId The logical mediator identifier.
     * @throws RepositoryException When an error occurs while working with the
     * underlying data storage.
     * @return An {@link Iterable} representing the sequence.
     * @see MediatorEntityRepository#queryAll()
     */
    Iterable<MediatorInstance> queryAll(int logicalMediatorId) throws RepositoryException;
}
