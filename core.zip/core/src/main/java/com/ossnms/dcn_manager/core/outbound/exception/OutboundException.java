package com.ossnms.dcn_manager.core.outbound.exception;

import com.ossnms.dcn_manager.exceptions.DcnManagerException;

public class OutboundException extends DcnManagerException {

    private static final long serialVersionUID = 8074364527015839349L;

    /**
     * @see Exception#Exception()
     */
    public OutboundException() {

    }

    /**
     * @see Exception#Exception(String)
     */
    public OutboundException(String message) {
        super(message);
    }

    /**
     * @see Exception#Exception(Throwable)
     */
    public OutboundException(Throwable cause) {
        super(cause);
    }

    /**
     * @see Exception#Exception(String,Throwable)
     */
    public OutboundException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @see Exception#Exception(String,Throwable,boolean,boolean)
     */
    public OutboundException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /**
     * @see DcnManagerException#DcnManagerException(String,Object[])
     */
    public OutboundException(String format, Object... formatParameters) {
        super(format, formatParameters);
    }
}
