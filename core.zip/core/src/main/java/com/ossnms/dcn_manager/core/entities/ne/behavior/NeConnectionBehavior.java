package com.ossnms.dcn_manager.core.entities.ne.behavior;

import com.google.common.base.Strings;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeConnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeConnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeDisconnectedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeDisconnectingEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializedEvent;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.NeInitializingEvent;
import com.ossnms.dcn_manager.core.outbound.Alarms;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.i18n.Message;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import java.util.Optional;

import static com.google.common.base.Preconditions.checkArgument;
import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * <p>Class that implements the behavior dimension of the domain object that describes the volatile
 * NE state or, in other words, the NEs' actual activation state. </p>
 *
 * <p>The implementation is based on the State Machine design pattern to deal with required activation
 * state transitions. The state machine is depicted in the following figure. Notice that the
 * representation of start and end states is merely illustrative of the expected flow: NEs
 * are originally created in the deactivated state. State transitions are triggered by the depicted
 * domain object operations. </p>
 *
 * <p><figure>
 * <img src="doc-files/neConnection_actual_activation_state-state.png">
 * <figcaption>State diagram of the actual activation state state machine</figcaption>
 * </figure></p>
 *
 * <p> The state machine is materialized in the following class hierarchy, only relevant to the domain
 * object implementation. For this reason the hierarchy is implemented as a set of static nested
 * classes not accessible from the outside. This solution has the merit of reducing overall
 * complexity (i.e. reducing the number of top-level classes) at the expense of increasing
 * file level complexity (i.e. its size). Nevertheless, and considering the actual file size, the
 * tradeoff is positive. In the case that the current file size increases, this approach must be
 * reevaluated. </p>
 *
 * <p> <figure>
 * <img src="doc-files/neConnection_actual_activation_state-class.png">
 * <figcaption>Class diagram of the actual activation state hierarchy</figcaption>
 * </figure> </p>
 *
 * <ul> Design decisions:
 * <li> Each state transition is materialized in an independent method,
 * to be overridden in concrete state classes; </li>
 * <li> Invalid transitions are signaled by producing an absent {@link Optional} instance,
 * instead of throwing an exception. Note that the exact reaction to an invalid
 * transition depends on the specific use case, and therefore throwing an exception
 * would be inappropriate; </li>
 * <li> Transitions are not applied on the on the domain object instance, due to its
 * immutable nature. Instead, state transitions produce a description of the resulting
 * mutation, which will be later applied on the repository. </li>
 * <li> Transitions may have side effects that depend on the actual state implementation. </li>
 * </ul>
 *
 * <p> As all types that implement domain objects' behavior dimension, this class instances are
 * not thread-safe, and therefore cannot be shared by multiple threads without explicit synchronization.
 * </p>
 */
/*
 * @startuml doc-files/neConnection_actual_activation_state-state.png
 * [*] --> Disconnected
 * Disconnected --> Connecting : setConnecting
 * Connecting --> Connected : setConnected
 * Connecting --> Failed : setFailed
 * Connecting --> Disconnecting : setDisconnecting
 * Connecting --> Disconnected : setDisconnected
 * Connected --> Initializing : setInitializing
 * Connected --> Failed : setFailed
 * Connected --> Disconnecting : setDisconnecting
 * Connected --> Disconnected : setDisconnected
 * Initializing --> Initialized : setInitialized
 * Initializing --> Failed : setFailed
 * Initializing --> Disconnecting : setDisconnecting
 * Initializing --> Disconnected : setDisconnected
 * Initialized --> Disconnecting : setDisconnecting
 * Initialized --> Failed : setFailed
 * Initialized --> Disconnected : setDisconnected
 * Initialized --> Initializing : resynchronize
 * Disconnecting --> Disconnected : setDisconnected
 * Disconnecting --> Failed : setFailed
 * Failed --> Disconnected : setDisconnected
 * Failed --> Connecting : setConnecting
 * Failed --> Initializing : setInitializing
 * @enduml
 */
/*
 * @startuml doc-files/neConnection_actual_activation_state-class.png
 * class ActualActivation <<abstract>> {
 *      # setConnected() : Optional<NeConnectionMutationDescriptor>
 *      # setConnecting() : Optional<NeConnectionMutationDescriptor>
 *      # setDisconnected() : Optional<NeConnectionMutationDescriptor>
 *      # setDisconnecting() : Optional<NeConnectionMutationDescriptor>
 *      # setInitialized() : Optional<NeConnectionMutationDescriptor>
 *      # setInitializing() : Optional<NeConnectionMutationDescriptor>
 *      # setFailed() : Optional<NeConnectionMutationDescriptor>
 *      # resynchronize() : Optional<NeConnectionMutationDescriptor>
 * }
 * ActualActivation <|-- Connected
 * ActualActivation <|-- Connecting
 * ActualActivation <|-- Disconnected
 * ActualActivation <|-- Disconnecting
 * ActualActivation <|-- Initialized
 * ActualActivation <|-- Initializing
 * ActualActivation <|-- Failed
 * hide fields
 * @enduml
 */
public class NeConnectionBehavior {

    private final NeConnectionData data;
    private final NetworkElementNotifications notifications;

    /**
     * Creates a new instance.
     *
     * @param data Actual connection state which will be used as a starting point for the state change.
     * @param notifications Outbound NE notifications connector instance.
     */
    public NeConnectionBehavior(@Nonnull NeConnectionData data, @Nonnull NetworkElementNotifications notifications) {
        this.data = data;
        this.notifications = notifications;
    }

    /**
     * Attempts to change into the CONNECTING state.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NeConnectionMutationDescriptor> setConnecting() {
        return behaviorFor(data.getActivationState()).connecting();
    }

    /**
     * Attempts to change into the DISCONNECTING state.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NeConnectionMutationDescriptor> setDisconnecting() {
        return behaviorFor(data.getActivationState()).disconnecting();
    }

    /**
     * Attempts to change into the CONNECTED state.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NeConnectionMutationDescriptor> setConnected(@Nonnull Alarms alarms, int channelId, int mediatorId) {
        return behaviorFor(data.getActivationState()).connected(alarms, channelId, mediatorId);
    }

    /**
     * Attempts to change into the DISCONNECTED state.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NeConnectionMutationDescriptor> setDisconnected(@Nonnull Alarms alarms) {
        return behaviorFor(data.getActivationState()).disconnected(alarms);
    }

    /**
     * Attempts to change into the INITIALIZING state.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NeConnectionMutationDescriptor> setInitializing() {
        return behaviorFor(data.getActivationState()).initializing();
    }

    /**
     * Attempts to change into the INITIALIZED state.
     * Will emit a new outbound NE Initialized event towards listening components.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NeConnectionMutationDescriptor> setInitialized() {
        return behaviorFor(data.getActivationState()).initialized();
    }

    /**
     * Attempts to change into the INITIALIZED state, forwarding an existing event outwards.
     * @param  synchronizationCounterDifferences Calculated differences between any new and existing
     *                                           synchronization counters.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     * @throws IllegalArgumentException If the counter differences does not relate to the current NE.
     */
    public Optional<NeConnectionMutationDescriptor> setInitialized(@Nonnull NeSynchronizationData synchronizationCounterDifferences) {
        checkArgument(synchronizationCounterDifferences.getId() == data.getId());
        return behaviorFor(data.getActivationState()).initialized(synchronizationCounterDifferences);
    }

    /**
     * Attempts to trigger a resynchronization. This will cause a change into the INITIALIZING state.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NeConnectionMutationDescriptor> resynchronize() {
        return behaviorFor(data.getActivationState()).resynchronize();
    }


    /**
     * Attempts to change into the FAILED state.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NeConnectionMutationDescriptor> setFailed(@Nullable String description, @Nonnull Alarms alarms) {
        return behaviorFor(data.getActivationState()).failed(description, alarms);
    }

    private ActualActivation behaviorFor(ActualActivationState currentState) {
        final ActualActivation behavior;
        switch (currentState) {
        case DISCONNECTED:
            behavior = new Disconnected();
            break;
        case CONNECTING:
            behavior = new Connecting();
            break;
        case CONNECTED:
            behavior = new Connected();
            break;
        case INITIALIZING:
            behavior = new Initializing();
            break;
        case INITIALIZED:
            behavior = new Initialized();
            break;
        case DISCONNECTING:
            behavior = new Disconnecting();
            break;
        case FAILED:
            behavior = new Failed();
            break;
        default:
            throw new IllegalStateException("No behavior found for " + currentState);
        }
        return behavior;
    }

    protected NetworkElementNotifications getNotifications() {
        return notifications;
    }

    private abstract class ActualActivation {

        protected Optional<NeConnectionMutationDescriptor> connecting() {
            return Optional.empty();
        }

        protected Optional<NeConnectionMutationDescriptor> disconnecting() {
            return Optional.empty();
        }

        protected Optional<NeConnectionMutationDescriptor> connected(@Nonnull Alarms alarms, int channelId, int mediatorId) {
            return Optional.empty();
        }

        protected Optional<NeConnectionMutationDescriptor> disconnected(@Nonnull final Alarms alarms) {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.DISCONNECTED)
                    .whenApplied(in -> {
                        final NeDisconnectedEvent event =
                            new NeDisconnectedEvent(in.getResult().getId());
                        getNotifications().notifyChanges(event);
                        alarms.clearConnectionLost(event.getNeId(), true);
                    }));
        }

        protected Optional<NeConnectionMutationDescriptor> initializing() {
            return Optional.empty();
        }

        protected Optional<NeConnectionMutationDescriptor> initialized() {
            return Optional.empty();
        }

        protected Optional<NeConnectionMutationDescriptor> initialized(
                @Nonnull NeSynchronizationData synchronizationCounterDifferences) {
            return Optional.empty();
        }

        protected Optional<NeConnectionMutationDescriptor> resynchronize() {
            return Optional.empty();
        }

        protected Optional<NeConnectionMutationDescriptor> failed(@Nullable String description, @Nonnull Alarms alarms) {
            return Optional.empty();
        }

        protected NeConnectionMutationDescriptor buildStateMutationDescriptor(@Nonnull ActualActivationState newState) {
            return new NeConnectionMutationDescriptor(data)
                .setActivationState(newState)
                .setAdditionalInfo(""); // clear the additional info on state change; actual implementations may set a message later if necessary.
        }
    }

    private abstract class FailingState extends ActualActivation {

        @Override
        protected Optional<NeConnectionMutationDescriptor> failed(@Nullable String description, @Nonnull final Alarms alarms) {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.FAILED)
                    .setAdditionalInfo(Strings.nullToEmpty(description))
                    .whenApplied(in -> {
                        final NeActivationFailedEvent event =
                            new NeActivationFailedEvent(
                                in.getResult().getId(),
                                    in.getResult().getAdditionalInfo().orElse(null));
                        getNotifications().notifyChanges(event);
                        alarms.raiseConnectionLost(in.getResult().getId(), in.getResult().getAdditionalInfo());
                    }));
        }

    }

    private abstract class CancellableState extends FailingState {

        @Override
        protected Optional<NeConnectionMutationDescriptor> disconnecting() {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.DISCONNECTING)
                    .whenApplied(in ->
                        getNotifications().notifyChanges(new NeDisconnectingEvent(in.getResult().getId()))
                    ));
        }

    }

    private abstract class RestartableState extends CancellableState {

        @Override
        protected Optional<NeConnectionMutationDescriptor> connecting() {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.CONNECTING)
                    .setAdditionalInfo(tr(Message.CONNECTING))
                    .whenApplied(in ->
                        getNotifications().notifyChanges(new NeConnectingEvent(in.getResult().getId(), in.getResult().getAdditionalInfo().orElse("")))
                    ));
        }

    }

    private final class Failed extends RestartableState {

        @Override
        protected Optional<NeConnectionMutationDescriptor> initializing() {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.INITIALIZING)
                    .setAdditionalInfo(tr(Message.INITIALIZING))
                    .whenApplied(in ->
                        getNotifications().notifyChanges(new NeInitializingEvent(in.getResult().getId(), in.getResult().getAdditionalInfo().orElse("")))
                    ));
        }

    }

    /*
    Allow the logical NE to transition from DISCONNECTED to FAILED because early startup errors may occur with the physical instance
    before it has a chance to change the logical NE to CONNECTING.
     */
    private final class Disconnected extends FailingState {

        @Override
        protected Optional<NeConnectionMutationDescriptor> connecting() {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.CONNECTING)
                    .setAdditionalInfo(tr(Message.CONNECTING))
                    .whenApplied(in ->
                        getNotifications().notifyChanges(new NeConnectingEvent(in.getResult().getId(), in.getResult().getAdditionalInfo().orElse("")))
                    ));
        }

        @Override
        protected Optional<NeConnectionMutationDescriptor> disconnected(@Nonnull Alarms alarms) {
            /*
            It may happen that physical connections begin connecting and are shut down before this logical
            instance state has changed. In this case they will request a change to the Disconnected state on
            the logical instance, which will be rejected because it is already disconnected. However the
            client is sensitive to intermediate startup and shutdown states so we need to issue a notification
            nevertheless.
             */
            getNotifications().notifyChanges(new NeDisconnectedEvent(data.getId()));
            return Optional.empty();
        }

    }

    private final class Connecting extends CancellableState {

        @Override
        protected Optional<NeConnectionMutationDescriptor> connected(@Nonnull final Alarms alarms, final int channelId, int mediatorId) {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.CONNECTED)
                    .setAdditionalInfo(tr(Message.INITIALIZATION_PENDING))
                    .whenApplied(in -> {
                        final int neId = in.getResult().getId();
                        getNotifications().notifyChanges(new NeConnectedEvent(neId, in.getResult().getAdditionalInfo().orElse("")));
                        alarms.clearConnectionLost(neId, false);
                    }));
        }

    }

    private final class Connected extends CancellableState {

        @Override
        protected Optional<NeConnectionMutationDescriptor> initializing() {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.INITIALIZING)
                    .setAdditionalInfo(tr(Message.INITIALIZING))
                    .whenApplied(in ->
                        getNotifications().notifyChanges(new NeInitializingEvent(in.getResult().getId(), in.getResult().getAdditionalInfo().orElse("")))
                    ));
        }

    }

    private final class Initializing extends CancellableState {

        @Override
        protected Optional<NeConnectionMutationDescriptor> initialized() {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.INITIALIZED)
                    .whenApplied(in ->
                        getNotifications().notifyChanges(new NeInitializedEvent(in.getResult().getId()))
                    ));
        }

        @Override
        protected Optional<NeConnectionMutationDescriptor> initialized(
                @Nonnull NeSynchronizationData synchronizationCounterDifferences) {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.INITIALIZED)
                    .whenApplied(in ->
                        getNotifications().notifyChanges(
                            new NeInitializedEvent(in.getResult().getId(), synchronizationCounterDifferences))
                    ));
        }

    }

    private final class Initialized extends CancellableState {

        @Override
        protected Optional<NeConnectionMutationDescriptor> initializing() {
            return resynchronize();
        }

        @Override
        protected Optional<NeConnectionMutationDescriptor> resynchronize() {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.INITIALIZING)
                    .setAdditionalInfo(tr(Message.INITIALIZING))
                    .whenApplied(in ->
                        getNotifications().notifyChanges(new NeInitializingEvent(in.getResult().getId(), in.getResult().getAdditionalInfo().orElse("")))
                    ));
        }

    }

    private final class Disconnecting extends FailingState {

        @Override
        protected Optional<NeConnectionMutationDescriptor> disconnecting() {
            return Optional.empty();
        }
    }
}
