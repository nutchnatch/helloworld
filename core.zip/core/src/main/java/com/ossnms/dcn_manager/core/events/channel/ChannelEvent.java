package com.ossnms.dcn_manager.core.events.channel;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

import com.ossnms.dcn_manager.core.events.EntityEvent;

/**
 * Base class for all events related to the Channel domain entity.
 */
@Immutable
public abstract class ChannelEvent extends EntityEvent  {

    /**
     * Creates a new object.
     * @param channelId The affected channel ID.
     */
    public ChannelEvent(int channelId) {
        super(channelId);
    }

    /**
     * Creates a new object.
     * @param channelId The affected channel ID.
     * @param detailedDescription Human-readable event description.
     */
    public ChannelEvent(int channelId, @Nonnull String detailedDescription) {
        super(channelId, detailedDescription);
    }

    /**
     * @return The affected Channel ID.
     */
    public int getChannelId() {
        return getEntityId();
    }
}
