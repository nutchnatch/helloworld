package com.ossnms.dcn_manager.core.policies.common;

import com.ossnms.dcn_manager.core.policies.PartitionedJobsInfo;
import com.ossnms.dcn_manager.core.policies.common.BoundedExecutor.Signaller;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.ThreadSafe;
import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

import static com.google.common.base.Preconditions.checkState;

/**
 * <p>Base class for lock-free implementations of partitioned interaction management policies.
 * The implementation does not ensure FIFO order execution of jobs, that is, activation and
 * deactivation sequences (a.k.a. jobs) are not necessarily performed in the same order they were
 * scheduled.</p>
 *
 * <p>Regarding the problem domain, the implementation does not ensure elimination of redundant
 * interactions, e.g. two simultaneous activation requests for the same channel. This concern
 * must be expressed elsewhere because it is not a fundamental concern of an interaction
 * management policy. Instead, it's about reacting to unexpected external stimuli and must
 * therefore be addressed on the component's outer layers (i.e. command's layer) .
 *
 * <p>Although derived classes are responsible for regulating DCN load, they do not perform processing
 * load regulation, which is a distinct concern; this regulation is performed by the execution
 * policy ([{@link Executor} instance) received upon construction.</p>
 *
 * <p> Implementation notes: </p>
 * <p>The partitioning criteria is a responsibility of the derived classes</p>
 * TODO: Document
 * TODO: Add object diagram
 *
 * @param <T> The concrete type of interaction jobs.
 */
@ThreadSafe
public abstract class PartitionedInteractionManager<T extends PolicyJob<?>> implements PartitionedJobsInfo {

    /** The execution queues. There will be an execution queue per identifier.*/
    private final ConcurrentHashMap<Integer, ExecutionQueue<T>> executionQueues;
    /** The default value for maximum allowed simultaneous interactions for each execution queue. */
    private final int defaultMaxInteractions;
    /** The executor instance shared by all execution queues. */
    private final Executor executionPolicy;
    /** Manager tag "name". */
    private final String classifier;
    /** Supplier of work items that will provide work when this manager has queues with capacity but empty. */
    private final BiFunction<Integer, Predicate<T>, Optional<T>> upstreamWorkSupplier;

    /**
     * Initiates an instance with the required dependencies.
     *
     * @param maxSimultaneousInteractions The maximum allowed number of simultaneous interactions.
     * @param executionPolicy             The executor instance to be used to schedule request servicing execution.
     * @param upstreamWorkSupplier        Supplier of work items that will provide work when this manager has
     *                                    queues with capacity but empty.
     * @throws IllegalArgumentException If {@literal maxSimultaneousInteractions} is not greater
     *                                  than 0.
     */
    protected PartitionedInteractionManager(
            int maxSimultaneousInteractions,
            @Nonnull String classifier,
            @Nonnull Executor executionPolicy,
            @Nonnull BiFunction<Integer, Predicate<T>, Optional<T>> upstreamWorkSupplier) {
        this.classifier = classifier;
        this.upstreamWorkSupplier = upstreamWorkSupplier;

        if (maxSimultaneousInteractions <= 0) {
            throw new IllegalArgumentException();
        }

        this.defaultMaxInteractions = maxSimultaneousInteractions;
        this.executionPolicy = executionPolicy;
        this.executionQueues = new ConcurrentHashMap<>();
    }

    /**
     * <p>Obtain and mark as ongoing one pending work item from the underlying partitions, if at least
     * one of them has spare capacity, i.e., the number of ongoing jobs has not reached the configured
     * maximum. The work item returned will be executed under the responsibility of the caller.</p>
     *
     * <p>This is used to implement a work "pull" model, which will complement the work "push" model
     * that remains the fundamental operating mode of these queues.</p>
     *
     * @return A work item for execution, if any is available.
     * @see ExecutionQueue::getRetainedWorkForExecution
     */
    public Optional<T> getRetainedWorkForExecution(@Nonnull Predicate<T> selector) {

        return executionQueues.values().stream()
                .sorted((l, r) -> l.getPendingWorkItemCount() - r.getPendingWorkItemCount())
                .map(queue -> queue.getRetainedWorkForExecution(selector))
                .filter(Optional::isPresent).map(Optional::get)
                .findFirst();

    }

    /**
     * Fetches the execution queue associated to the given partition identifier, creating the queue
     * if needed.
     * @param partitionId The partition identifier to which the queue is associated.
     * @return The execution queue instance.
     */
    private ExecutionQueue<T> getExecutionQueue(int partitionId) {

        ExecutionQueue<T> queue = executionQueues.get(partitionId);
        if (queue == null) {
            // First job submitted to the given partition. Let's create the execution queue.
            // Because of the check-and-act, we must deal with possible races, hence the use of
            // putIfAbsent.

            // Notice that execution queues may be unnecessarily created when the conditional put
            // fails, but this is not actually a problem: they are discarded once the put fails and
            // their instantiation is not expensive.

            // The real problem here would be the use of different execution queue instances for jobs
            // pertaining to the same partition, because this would hinder the effectiveness of the
            // interaction management policy.
            final ExecutionQueue<T> newCandidateQueue = new ExecutionQueue<>(
                    defaultMaxInteractions, String.format("%s.%d", classifier, partitionId),
                    executionPolicy, predicate -> upstreamWorkSupplier.apply(partitionId, predicate));
            final ExecutionQueue<T> existingQueue = executionQueues.putIfAbsent(partitionId, newCandidateQueue);
            // If there wasn't a queue instance associated to the given key (existingQueue == null),
            // then we won the race. If not, we lost it and we must return the queue already stored,
            // discarding the one we created.
            queue = existingQueue == null ? newCandidateQueue : existingQueue;
        }

        return queue;
    }

    /**
     * Schedules for execution the given interaction job. If there is any pending job in the given partition
     * that is canceled by the submitted one, then the cancelled job is removed from the retention queue and
     * the submitted job is discarded.
     * @param partitionId         The partition identifier.
     * @param job                 The interaction job to be executed.
     * @param cancelationSelector The predicate used to verify if any pending job is canceled by the submitted
     *                            one.
     */
    protected void schedulePartitionInteraction(int partitionId, @Nonnull T job, Predicate<T> cancelationSelector) {
        // Add job to the queue, passing in the predicate to be used to check if the given job
        // cancels any pending one
        getExecutionQueue(partitionId).scheduleWorkItem(job, cancelationSelector);
    }

    /**
     * Signals the completion of an interaction, thereby updating the internal estimate of ongoing
     * interactions. The interaction for which completion is signaled is selected by using the
     * received predicate and may be related to any partition.
     * Notice that this operation searches all partitions until a matching ongoing interaction is
     * found.
     * @param interactionSelector The predicate used to select the interaction whose completion is
     *                            to be signaled.
     */
    protected void onInteractionEnded(@Nonnull Predicate<T> interactionSelector) {
        for (final Entry<Integer, ExecutionQueue<T>> entry : executionQueues.entrySet()) {
            // Signal job completion
            entry.getValue().signalWorkItemCompletion(interactionSelector);
        }
    }

    /**
     * Removes from the given partition schedule the first work item to which the given predicate applies.
     * @param partitionId          The partition identifier.
     * @param cancellationSelector The predicate used to select a potential cancelled work item.
     */
    protected void unschedulePartitionInteraction(int partitionId, Predicate<T> cancellationSelector) {
        getExecutionQueue(partitionId).signalWorkItemCancellation(cancellationSelector);
    }

    /**
     * Removes from the any partition schedule the first work item to which the given predicate applies.
     * @param cancellationSelector The predicate used to select a potential cancelled work item.
     */
    protected void unscheduleInteraction(Predicate<T> cancellationSelector) {
        for (final Entry<Integer, ExecutionQueue<T>> entry : executionQueues.entrySet()) {
            entry.getValue().signalWorkItemCancellation(cancellationSelector);
        }
    }

    /**
     * Signals the occurrence of an event that may be of interest to work items.
     * Notice that this operation searches all partitions until a matching ongoing interaction is
     * found. Whenever possible {@link #onEvent(int, Signaller)} should be used
     * instead.
     * @param signaller The signal instance.
     * @return True if a work item has been signalled.
     */
    protected boolean onEvent(@Nonnull Signaller<T> signaller) {
        for (final Entry<Integer, ExecutionQueue<T>> entry : executionQueues.entrySet()) {
            // Signal job completion
            if (entry.getValue().signalWorkItem(signaller)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Signals the occurrence of an event that may be of interest to work items.
     * @param signaller The signal instance.
     */
    protected void onEvent(int partitionId, @Nonnull Signaller<T> signaller) {
        // Signal job completion
        final ExecutionQueue<T> queue = executionQueues.get(partitionId);
        // Ignore event if the corresponding queue does not exist
        if (queue != null) {
            queue.signalWorkItem(signaller);
        }
    }

    /**
     * @return The number of pending work items.
     */
    public int getPendingJobCount() {
        int total = 0;
        for (final ExecutionQueue<T> queue : executionQueues.values()) {
            total += queue.getPendingWorkItemCount();
        }
        return total;
    }

    /**
     * @return The number of ongoing work items.
     */
    public int getOngoingJobCount() {
        int total = 0;
        for (final ExecutionQueue<T> queue : executionQueues.values()) {
            total += queue.getOngoingWorkItemCount();
        }
        return total;
    }

    /**
     * Gets the current number of pending work items currently in the execution queue
     * associated to the given partition.
     * @param partitionId The partition identifier.
     * @return The number of pending work items.
     */
    public int getPendingJobCount(int partitionId) {
        final ExecutionQueue<T> queue = executionQueues.get(partitionId);
        return queue != null ? queue.getPendingWorkItemCount() : 0;
    }

    /**
     * Gets the current number of ongoing work items currently in the execution queue
     * associated to the given partition.
     * @param partitionId The partition identifier.
     * @return The number of ongoing work items.
     */
    public int getOngoingJobCount(int partitionId) {
        final ExecutionQueue<T> queue = executionQueues.get(partitionId);
        return queue != null ? queue.getOngoingWorkItemCount() : 0;
    }

    /**
     * Gets the maximum allowed number of simultaneous work items in the execution queue
     * associated to the given partition.
     * @param partitionId The partition identifier.
     * @return The maximum allowed number of simultaneous work items.
     */
    public int getMaxOngoingJobCount(int partitionId) {
        final ExecutionQueue<T> queue = executionQueues.get(partitionId);
        return queue != null ? queue.getMaxOngoingWorkItemCount() : defaultMaxInteractions;
    }

    /**
     * Sets the maximum allowed number of simultaneous work items in the execution queue
     * associated to the given partition. This configuration change may not have immediate
     * effect, meaning, ongoing work items will not be cancelled.
     * @param partitionId        The partition identifier.
     * @param newMaxInteractions The new maximum number of allowed simultaneous work items.
     * @throws IllegalArgumentException If {@literal newMaxOngoingWorkItemCount} is not greater
     *                                  than 0.
     */
    public void setMaxOngoingJobCount(int partitionId, int newMaxInteractions) {
        // We must create the execution queue, if it does not exist yet. If someone is asking us to
        // parameterize the partition, then the queue will eventually be needed.
        getExecutionQueue(partitionId).setMaxOngoingWorkItemCount(newMaxInteractions);
    }

    /**
     * Removes a partition from management. Can be used to ensure that system resources
     * are released when it is known that a partition will no longer be necessary.
     * @param partitionId The partition identifier.
     * @throws IllegalStateException If a partition has been removed with ongoing work.
     */
    public void removePartition(int partitionId) {
        final ExecutionQueue<T> removedQueue = executionQueues.remove(partitionId);
        /*
         * We check the queue after removing it to be sure of it state. If we attempt to
         * make all checks before removing the queue, there is no guarantee that we'll be
         * reading valid data. Besides, such an event represents a runtime error anyway.
         */
        checkState(removedQueue == null || removedQueue.getOngoingWorkItemCount() == 0,
                "Removed a queue with ongoing work for partition {} on {}!", partitionId, getClass().getSimpleName());
    }

    /**
     * Gets all ongoing work items
     *
     * @return ongoing work items
     */
    public Stream<PolicyJob<?>> getOngoingJobs() {
        return getWorkItems(executionQueues.values().stream(), ExecutionQueue::getOnGoingWorkItems);
    }

    /**
     * Gets ongoing work items for the given partition identifiers
     * @param partitionIds partition identifiers
     * @return ongoing work items
     */
    public Stream<PolicyJob<?>> getOngoingJobs(int... partitionIds) {
        return getWorkItems(getExecutionQueuesForIdentifiers(partitionIds), ExecutionQueue::getOnGoingWorkItems);
    }

    /**
     * Gets all pending work items
     * @return pending work items
     */
    public Stream<PolicyJob<?>> getPendingJobs() {
        return getWorkItems(executionQueues.values().stream(), ExecutionQueue::getPendingWorkItems);
    }

    /**
     * Gets pending work items for the given partition identifiers
     * @param partitionIds partition identifiers
     * @return pending work items
     */
    public Stream<PolicyJob<?>> getPendingJobs(int... partitionIds) {
        return getWorkItems(getExecutionQueuesForIdentifiers(partitionIds), ExecutionQueue::getPendingWorkItems);
    }

    /**
     * Gets the work items for each one of execution queues
     * @param executionQueues to collect the workItems
     * @return the work items for each one of execution queues
     */
    private Stream<PolicyJob<?>> getWorkItems(final Stream<ExecutionQueue<T>> executionQueues,
                                              final Function<ExecutionQueue, Stream<T>> workItemsSelector) {
        return executionQueues.flatMap(workItemsSelector);
    }

    /**
     * Gets the execution queues related to the given partition identifiers
     * @return execution queue collection
     */
    private Stream<ExecutionQueue<T>> getExecutionQueuesForIdentifiers(int... partitionIds) {
        return Arrays.stream(partitionIds)
                .mapToObj(executionQueues::get)
                .filter(Objects::nonNull);
    }
}
