package com.ossnms.dcn_manager.core.entities.ne.data;

/**
 * Describes an NE deletion event. Contains all information necessary to delete a NE.
 */
public final class NeDeleteDescriptor {

    private final int neId;

    public NeDeleteDescriptor(int neId) {
        this.neId = neId;
    }

    /**
     * @return The identifier of the NE that should be deleted.
     */
    public int getId() {
        return neId;
    }

    @Override
    public int hashCode() {
        return neId;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        return neId == ((NeDeleteDescriptor) obj).neId;
    }
}
