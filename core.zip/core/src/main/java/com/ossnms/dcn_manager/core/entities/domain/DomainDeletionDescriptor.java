package com.ossnms.dcn_manager.core.entities.domain;

import static com.google.common.base.Preconditions.checkArgument;

import javax.annotation.concurrent.Immutable;

/**
 * Contains all information required to delete an existing Domain.
 */
@Immutable
public final class DomainDeletionDescriptor {

    private final int id;

    /**
     * Creates a new object.
     * @param domainId Domain identifier.
     * @throws IllegalArgumentException If the identifier is invalid.
     */
    public DomainDeletionDescriptor(int domainId) {
        checkArgument(domainId > 0, "A domain ID must be positive!");
        this.id = domainId;
    }

    /**
     * @return The domain identifier.
     */
    public int getId() {
        return id;
    }

    @Override
    public int hashCode() {
        return id;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || getClass() != obj.getClass()) {
            return false;
        }
        final DomainDeletionDescriptor other = (DomainDeletionDescriptor) obj;
        return (id == other.id);
    }

}
