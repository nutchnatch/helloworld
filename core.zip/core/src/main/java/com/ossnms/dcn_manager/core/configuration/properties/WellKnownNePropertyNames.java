package com.ossnms.dcn_manager.core.configuration.properties;

/**
 * Contains constants with the names of "well known" NE properties, i.e.,
 * properties that must be mapped to NE entity attributes or that have
 * some special meaning (or must be ignored).
 */
public final class WellKnownNePropertyNames {

    public static final String USES_GNE = "NE_USES_GNE";
    public static final String USES_FLAT_IP = "USE_FLAT_IP";
    public static final String GATEWAY_MODE = "GATEWAY_MODE";
    public static final String RECONNECT_INTERVAL = "NE_RECONNECT_INTERVAL";

    public static final String ADDITIONAL_TYPE_INFO = "ADDITIONAL_TYPE_INFO";

    public static final String ID_NAME = "BCB-Attribute/NE/idName";
    public static final String NE_TYPE = "BCB-Attribute/NE/neProxyType";

    public static final String GLOBAL_NE_ID = "GlobalNeIdentifier";

    public static final String USER_NAME = "BCB-Attribute/NE/loginUserName";
    public static final String USER_PASSWORD = "BCB-Attribute/NE/loginPassword";

    public static final String USE_DEFAULT_ROUTE_SORTING = "USE_DEFAULTORDER";

    public static final String PARENT_NE_CONTAINER = "NEContainer";

    public static final String INTERNAL_ENABLE_PRIORITY_SWAP = "ENABLE_PRIORITY_SWAP";

    public static final String NEIGHBOURHOOD_ID = "NEIGHBOURHOOD_ID";

    public static final String SYSNAME = "SYSNAME";

    public static final String TL1_ID = "TL1_NE_TARGET_ID";

    public static final String TL1_NE_TYPE = "TL1_NE_TYPE";

    public static final String SNMP_USE_TL1_AUTHENTICATION = "SNMP_USE_TL1_AUTHENTICATION";
                
    public static final String SNMP_USER_NAME = "SNMP_USER_NAME";
    
    public static final String SNMP_PRIVACY_PASSWORD = "SNMP_PRIVACY_PASSWORD";
    
    public static final String SNMP_AUTHENTICATION_PASSWORD = "SNMP_AUTHENTICATION_PASSWORD";
    
    public static final String SNMP_AUTHENTICATION_PROTOCOL = "SNMP_AUTHENTICATION_PROTOCOL";
    
    public static final String SNMP_PRIVACY_PROTOCOL = "SNMP_PRIVACY_PROTOCOL";
    
    public static final String NE_POLLING_INTERVAL = "BD4B7A2F-1406-4617-B163-39D1AF00EF03/PollingIntervall";
    
    public static final String NE_TELEGRAM_TIMEOUT = "BD4B7A2F-1406-4617-B163-39D1AF00EF03/Timeout";
    
    public static final String SNMP_TELEGRAM_TIMEOUT = "SNMP_TELEGRAM_TIMEOUT";
    
    public static final String SNMP_TELEGRAM_RETRIES = "SNMP_TELEGRAM_RETRIES";
    
    /**
     * Marker property received from mediation when we need to run a restart on the NE connection (GX1813).
     */
    public static final String RESTART_NE = "RESTART_NE";

    /**
     * Marker property received from the client with the total number of
     * NE gateway route rows.
     */
    public static final String INTERNAL_ROUTE_ROW_COUNT = "ROUTE_ROW_COUNT";

    public static final String DEPRECATED_NUM_OF_DHCP = "NUM_OF_DHCP";
    public static final String DEPRECATED_NUM_OF_ADD_NSAPS = "BD4B7A2F-1406-4617-B163-39D1AF00EF03/NUM_OF_ADD_NSAPS";
    public static final String DEPRECATED_DOMAIN_NAME_FOR_NE = "DOMAIN_NAME_FOR_NE";
    public static final String USER_TEXT = "38250635-F75A-4f6b-8D66-50A014D40A55/UserText1";

    private WellKnownNePropertyNames() {

    }

}
