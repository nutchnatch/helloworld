package com.ossnms.dcn_manager.core.configuration.transformations;

import com.google.common.base.Function;
import com.ossnms.dcn_manager.core.configuration.model.ChannelType;

/**
 * Transforms instances of {@link ChannelType} into their names.
 */
public final class GetChannelTypeName implements Function<ChannelType, String> {

    @Override
    public String apply(ChannelType input) {
        return null != input ? input.getName() : null;
    }

}