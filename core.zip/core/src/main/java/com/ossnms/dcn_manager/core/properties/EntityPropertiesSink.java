package com.ossnms.dcn_manager.core.properties;

import com.ossnms.dcn_manager.core.configuration.model.Type;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;

import javax.annotation.Nonnull;
import java.util.Map;

/**
 * Manage property storage from a merged set of Type and Instance (entity)
 * properties.
 *
 * @param <P> Well known entity properties enum
 * @param <T> Entity Type class
 * @param <E> Entity Instance class
 * @param <M> Entity Instance Mutation Descriptor class
 */

public abstract class EntityPropertiesSink <P extends Enum<?> & EntityPropertyOperations, T extends Type, E, M> {
    /**
     * <p>Registers a change request for an entity property on an entity mutation
     * descriptor instance.</p>
     *
     * <p>Type properties are read-only, trying to set a type property will not
     * cause any modifications to the mutation provided.</p>
     *
     * <p><img src="doc-files/setProperty-sequence.png" /></p>
     *
     * @param type Entity type, as configured.
     * @param mutation The current entity.
     * @param name Property name.
     * @param value New property value.
     * @throws InvalidMutationException If the new property value is not acceptable.
     */
    /*
     * @startuml doc-files/setProperty-sequence.png
     * actor Caller
     * participant EntityProperties
     * participant T << Entity Type >>
     * entity mutation << Mutation Provided >>
     * Caller --> EntityProperties : setProperty(type, mutation, name, value)
     * EntityProperties --> T : mapPropertyName(name)
     * activate T
     * T --> EntityProperties : internalName
     * deactivate T
     * EntityProperties --> mutation : register mutation (internalName, value)
     * deactivate EntityProperties
     * @enduml
     */
    public void setProperty(T type, M mutation, String name, String value) throws InvalidMutationException {
        final String normalizedName = type.mapIncomingPropertyName(name);
        doSet(type, mutation, normalizedName, value);
    }

    /**
     * Registers a change request for a property on an entity instance.
     *
     * @param type Entity type, as configured.
     * @param mutator The current entity.
     * @param property The well known property enum.
     * @param value New property value.
     * @throws InvalidMutationException If the new property value is not acceptable.
     */
    public void setProperty(T type, M mutator, P property, String value) throws InvalidMutationException {
        doSet(type, mutator, property.getName(), value);
    }

    /**
     * Registers a change request for a set of properties on an entity.
     * @param type Entity type, as configured.
     * @param mutation The current entity.
     * @param properties Well known property name/value pairs.
     * @throws InvalidMutationException If some new property value is not acceptable.
     */
    public void setProperties(T type, M mutation, Map<String, String> properties) throws InvalidMutationException {
        for (final Map.Entry<String, String> property : properties.entrySet()) {
            setProperty(type, mutation, property.getKey(), property.getValue());
        }
    }

    private boolean doSet(T type, M mutation, String name, String value) throws InvalidMutationException {
        if (!type.getTypeProperties().containsKey(name)) { // Type properties are read-only and do not allow overrides.
            for (final EntityPropertyHandler<T, E, M> handler : getHandlers()) {
                if (handler.handles(type, name)) {
                    handler.set(type, mutation, name, value);
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Specific property handlers are used because some properties are necessary for
     * EM/NE operation and are therefore not stored in a property bag. They are stored
     * in object attributes instead.
     * @return A chain of property handlers.
     */
    @Nonnull
    protected abstract EntityPropertyHandler<T, E, M>[] getHandlers();
}
