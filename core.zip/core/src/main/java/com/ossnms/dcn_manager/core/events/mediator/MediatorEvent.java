package com.ossnms.dcn_manager.core.events.mediator;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

import com.ossnms.dcn_manager.core.events.EntityEvent;

/**
 * Base class for all events related to the Mediator domain entity.
 */
@Immutable
public abstract class MediatorEvent extends EntityEvent {

    /**
     * Creates a new object.
     * @param mediatorId Affected Mediator ID.
     */
    public MediatorEvent(int mediatorId) {
        super(mediatorId);
    }

    /**
     * Creates a new object.
     * @param mediatorId Affected Mediator ID.
     * @param detailedDescription Human readable event description.
     */
    public MediatorEvent(int mediatorId, @Nonnull String detailedDescription) {
        super(mediatorId, detailedDescription);
    }

    /**
     * @return The affected Mediator ID.
     */
    public int getMediatorId() {
        return getEntityId();
    }
}
