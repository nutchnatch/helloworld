package com.ossnms.dcn_manager.core.events.container;

/**
 * Base class for events that affect a container.
 */
public class ContainerSystemAssignmentRemovedEvent extends ContainerEvent {

    private final int systemID;

    /**
     * Creates a new object.
     *
     * @param containerId The affected container ID.
     */
    public ContainerSystemAssignmentRemovedEvent(int containerId, int systemID) {
        super(containerId);
        this.systemID = systemID;
    }

    public int getContainerId() { return getEntityId(); }

    public int getSystemID() {
        return systemID;
    }
}
