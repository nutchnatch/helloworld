package com.ossnms.dcn_manager.core.entities.ne.data;

import com.mysema.query.annotations.QueryEntity;
import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.time.Instant;
import java.util.Objects;
import java.util.Optional;


/**
 * <p> Class that implements the data dimension of the domain object that describes the NE's
 * PHYSICAL connection state or, in other words, the solution's real connectivity to the given
 * NE. </p>
 *
 * <p>As all types that implement domain objects' data dimension, instances of this class are immutable,
 * and are therefore thread-safe.</p>
 */
@QueryEntity
public final class NePhysicalConnectionData extends BusinessObjectData {

    private final int neId;
    private final int channelInstanceId;
    private final boolean active;
    private final ActualActivationState activationState;
    private final ActualActivationMode activationMode;
    private final String additionalInfo;
    private final int retryCounter;
    private final Instant initStageStartTime; // epoch time stamp

    /**
     * Initiates an instance with the given initial data.
     *
     * @param physicalNeId The domain object identifier (i.e. the same as its domain entity instance).
     * @param logicalNeId Identifier of the logical NE to which this connection is related.
     * @param channelInstanceId Identifier of the physical Channel that manages this physical NE.
     * @param version The domain object's version number
     * @param initialData Initial instance data.
     */
    public NePhysicalConnectionData(int physicalNeId, int logicalNeId, int channelInstanceId, int version, NePhysicalConnectionPrototype<?> initialData) {
        super(physicalNeId, version);
        this.neId = logicalNeId;
        this.channelInstanceId = channelInstanceId;
        this.additionalInfo = initialData.additionalInfo;
        this.activationState = initialData.activationState;
        this.active = initialData.active;
        this.retryCounter = initialData.retryCounter;
        this.initStageStartTime = initialData.initStartTime;
        this.activationMode = initialData.activationMode;
    }

    /**
     * @return Human readable additional state information.
     */
    public String getAdditionalInfo() {
        return additionalInfo;
    }

    /**
     * @return Actual NE activation state.
     */
    public ActualActivationState getActualActivationState() {
        return activationState;
    }

    /**
     * The activation mode allows decisions to be made during processing of activation state
     * events. It effectively parametrizes the component activation behavior.
     *
     * @return Actual NE activation mode.
     */
    public ActualActivationMode getActualActivationMode() {
        return activationMode;
    }

    /**
     * @return Whether this is the Active NE instance, within the context of redundancy
     *  (Active vs. Standby).
     */
    public boolean isActive() {
        return active;
    }

    /**
     * @return The logical NE identifier.
     */
    public int getLogicalNeId() {
        return neId;
    }

    /**
     * @return Identifier of the physical Channel that manages this physical NE.
     */
    public int getChannelInstanceId() {
        return channelInstanceId;
    }

    /**
     * @return The current retry counter value. It's the number of times
     *  that a connection to the NE has been tried and has failed.
     */
    public int getRetryCounter() {
        return retryCounter;
    }

    /**
     * @return The time at which the NE initialization last changed status
     *         to started (initializing) or failed. Context is inferred from
     *         the current combination of actual activation state and mode.
     */
    public Optional<Instant> getInitStageStartTime() {
        return Optional.ofNullable(initStageStartTime);
    }

    /**
     * @return Whether there is a valid connection to this NE.
     */
    public boolean isConnected() {
        return ActualActivationState.CONNECTED == activationState ||
               ActualActivationState.INITIALIZING == activationState ||
               ActualActivationState.INITIALIZED == activationState;
    }

    /**
     * @return Whether the NE is in an active, i.e., fully initialized state.
     */
    public boolean isActiveState() {
        return ActualActivationState.INITIALIZED == activationState;
    }

    /**
     * @return Whether the NE is currently being activated.
     */
    public boolean isUndergoingActivation() {
        return ActualActivationState.STARTUP == activationState ||
               ActualActivationState.CONNECTING == activationState ||
               ActualActivationState.INITIALIZING == activationState;
    }

    /**
     * @return Whether the NE is currently being deactivated.
     */
    public boolean isUndergoingDeactivation() {
        return ActualActivationState.SHUTDOWN == activationState ||
               ActualActivationState.DISCONNECTING == activationState;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("logicalNeId", neId)
                .append("channelInstanceId", channelInstanceId)
                .append("active", active)
                .append("activationState", activationState)
                .append("activationMode", activationMode)
                .append("additionalInfo", additionalInfo)
                .append("retryCounter", retryCounter)
                .append("initStageStartTime", initStageStartTime)
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), neId, channelInstanceId, active,
                activationState, additionalInfo, retryCounter, initStageStartTime);
    }

    @Override
    public boolean equals(Object theOther) {
        if (this == theOther) {
            return true;
        }
        if (null == theOther || !getClass().equals(theOther.getClass())) {
            return false;
        }
        final NePhysicalConnectionData rhs = (NePhysicalConnectionData) theOther;
        return new EqualsBuilder()
                .appendSuper(super.equals(theOther))
                .append(neId, rhs.neId)
                .append(channelInstanceId, rhs.channelInstanceId)
                .append(active, rhs.active)
                .append(activationState, rhs.activationState)
                .append(additionalInfo, rhs.additionalInfo)
                .append(retryCounter, rhs.retryCounter)
                .append(initStageStartTime, rhs.initStageStartTime)
                .isEquals();
    }

    /**
     * Helps building a new instance of {@link NePhysicalConnectionData} with
     * predefined attribute values.
     */
    public static final class NePhysicalConnectionBuilder extends NePhysicalConnectionPrototype<NePhysicalConnectionBuilder> {

        /**
         * Creates a new instance of {@link NePhysicalConnectionData} with information
         * extracted from the current attribute values.
         *
         * @param physicalNeId The Physical NE ID.
         * @param logicalNeId The Logical NE ID.
         * @param channelInstanceId Identifier of the physical Channel that manages this physical NE.
         * @param version The new instances' version number.
         * @return A new instance of {@link NePhysicalConnectionData}.
         */
        public NePhysicalConnectionData build(int physicalNeId, int logicalNeId, int channelInstanceId, int version) {
            return new NePhysicalConnectionData(physicalNeId, logicalNeId, channelInstanceId, version, this);
        }

        @Override
        protected NePhysicalConnectionBuilder self() {
            return this;
        }

    }

    /**
     * Contains initial data values for the data object (it's a parameter object).
     */
    public static final class NePhysicalConnectionInitialData extends NePhysicalConnectionPrototype<NePhysicalConnectionInitialData> {

        @Override
        protected NePhysicalConnectionInitialData self() {
            return this;
        }

    }

    /**
     * Builder/prototype class. Used to help building instances of {@link NePhysicalConnectionData}.
     */
    private abstract static class NePhysicalConnectionPrototype<T extends NePhysicalConnectionPrototype<T>> {

        private boolean active;
        private ActualActivationState activationState = ActualActivationState.DISCONNECTED;
        private String additionalInfo = "";
        private int retryCounter = 0;
        private Instant initStartTime; // epoch time stamp
        private ActualActivationMode activationMode = ActualActivationMode.STANDARD;

        protected NePhysicalConnectionPrototype() {

        }

        protected abstract T self();

        /**
         * @param activationMode New NE activation mode.
         */
        public T setActivationMode(@Nonnull ActualActivationMode activationMode) {
            this.activationMode = activationMode;
            return self();
        }

        /**
         * @param activationState New NE activation state.
         */
        public T setActivationState(@Nonnull ActualActivationState activationState) {
            this.activationState = activationState;
            return self();
        }

        /**
         * @param additionalInfo New human readable state information string.
         */
        public T setAdditionalInfo(@Nullable String additionalInfo) {
            this.additionalInfo = additionalInfo;
            return self();
        }

        /**
         * @param active Whether this is the Active NE instance, within the context of redundancy
         * (Active vs. Standby).
         */
        public T setActive(boolean active) {
            this.active = active;
            return self();
        }

        /**
         * @param retryCounter New retry counter value.
         */
        public T setRetryCounter(int retryCounter) {
            this.retryCounter = retryCounter;
            return self();
        }

        /**
         * @param initStartTime The time at which the NE started the last initialization.
         */
        public T setInitStartTime(Optional<Instant> initStartTime) {
            this.initStartTime = initStartTime.orElse(null);
            return self();
        }

    }

}
