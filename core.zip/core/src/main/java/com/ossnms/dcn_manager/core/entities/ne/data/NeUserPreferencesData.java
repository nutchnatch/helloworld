package com.ossnms.dcn_manager.core.entities.ne.data;

import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.entities.DynamicBusinessObjectData;
import com.ossnms.dcn_manager.core.entities.DynamicBusinessObjectPrototype;
import com.ossnms.dcn_manager.core.entities.PropertyBag;
import com.ossnms.dcn_manager.core.entities.ne.data.NeDirectRouteData.NeDirectRouteBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySetters.NeDataTransferSettingsAdapter;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySetters.NeRoutePropertyAdapter;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySource.NePreferencesPropertySource;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static com.google.common.base.Preconditions.checkArgument;

/**
 * Persisted information about the user preferences.
 * This is information that is mostly dependent on the operator.
 */
public final class NeUserPreferencesData extends DynamicBusinessObjectData implements NePreferencesPropertySource {

    private final String idName;
    private final boolean usesGne;
    private final boolean usesFlatIp;
    private final int reconnectInterval;
    private final RouteSortingMode routeSortingMode;
    private final Optional<String> globalId;
    private final Optional<String> userName;
    private final Optional<String> userText;
    private final Optional<String> password;
    private final NeDirectRouteData directRoute;
    private final Optional<Integer> containerId;
    private final NeDataTransferSettings dataTransferSettings;

    public NeUserPreferencesData(int neId, int version, @Nonnull NeUserPreferencesPrototype<?> prototype) {
        super(neId, version, ImmutableMap.copyOf(prototype.getPropertyBag()));

        checkArgument(!Strings.isNullOrEmpty(prototype.name), "NE must have a name!");

        idName = prototype.name;
        usesGne = prototype.usesGne;
        usesFlatIp = prototype.usesFlatIp;
        reconnectInterval = prototype.reconnectInterval;
        globalId = prototype.globalId;
        userName = prototype.userName;
        userText = prototype.userText;
        password = prototype.password;
        routeSortingMode = prototype.routeSortingMode;
        containerId = prototype.containerId;
        dataTransferSettings = new NeDataTransferSettings(prototype.dataTransferSettingsAdapter);

        directRoute = new NeDirectRouteBuilder()
                .setKey(prototype.routeKey)
                .setProperties(prototype.routePropertyBag)
                .build(neId, version);
    }

    /**
     * @return NE name.
     */
    @Override
    public String getName() {
        return idName;
    }

    /**
     * @return Whether the NE is behind a GNE.
     */
    @Override
    public boolean usesGne() {
        return usesGne;
    }

    @Override
    public boolean usesFlatIp() {
        return usesFlatIp;
    }

    /**
     * @return Time to wait between reconnection attempts.
     */
    @Override
    public int getReconnectInterval() {
        return reconnectInterval;
    }

    /**
     * @return Global identifier.
     */
    @Override
    public Optional<String> getGlobalId() {
        return globalId;
    }

    /**
     * @return The direct connection route to this NE.
     */
    @Override
    public NeDirectRouteData getDirectRoute() {
        return directRoute;
    }

    /**
     * @return NE login user name.
     */
    @Override
    public Optional<String> getUserName() {
        return userName;
    }

    /**
     * @return NE login password.
     */
    @Override
    public Optional<String> getPassword() {
        return password;
    }

    /**
     * @return Whether routes should be sorted according to an auto priority
     * algorithm or if it will follow default ordering.
     */
    @Override
    public RouteSortingMode getRouteSortingMode() {
        return routeSortingMode;
    }

    /**
     * @return The Data Transfer Settings optional attributes.
     */
    @Override
    public NeDataTransferSettings getDataTransferSettings() {
        return dataTransferSettings;
    }

    /**
     * @return Parent NE container identifier.
     */
    public Optional<Integer> getContainerId() {
        return containerId;
    }


    @Override
    public Optional<String> getUserText() {
        return userText;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
                .append(idName)
                .append(usesGne)
                .append(usesFlatIp)
                .append(reconnectInterval)
                .append(routeSortingMode)
                .append(globalId)
                .append(userName)
                .append(userText)
                .append(password)
                .append(directRoute)
                .append(containerId)
                .append(dataTransferSettings)
                .appendSuper(super.hashCode())
                .toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (other == null || getClass() != other.getClass()) {
            return false;
        }
        final NeUserPreferencesData rhs = (NeUserPreferencesData) other;
        return new EqualsBuilder()
                .append(idName, rhs.idName)
                .append(usesGne, rhs.usesGne)
                .append(usesFlatIp, rhs.usesFlatIp)
                .append(reconnectInterval, rhs.reconnectInterval)
                .append(routeSortingMode, rhs.routeSortingMode)
                .append(globalId, rhs.globalId)
                .append(userName, rhs.userName)
                .append(userText, rhs.userText)
                .append(password, rhs.password)
                .append(directRoute, rhs.directRoute)
                .append(containerId, rhs.containerId)
                .append(dataTransferSettings, rhs.dataTransferSettings)
                .append(getId(), rhs.getId())
                .append(getVersion(), rhs.getVersion())
                .append(getAllOpaqueProperties(), rhs.getAllOpaqueProperties())
                .build();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("idName", idName)
                .append("usesGne", usesGne)
                .append("usesFlatIp", usesFlatIp)
                .append("reconnectInterval", reconnectInterval)
                .append("globalId", globalId)
                .append("userName", userName)
                .append("userText", userText)
                .append("routeSortingMode", routeSortingMode)
                .append("directRoute", directRoute)
                .append("containerId", containerId)
                .append("dataTransferSettings", dataTransferSettings)
                .toString();
    }

    public static final class NeUserPreferencesBuilder extends NeUserPreferencesPrototype<NeUserPreferencesBuilder> {

        public NeUserPreferencesData build(int neId, int version) {
            return new NeUserPreferencesData(neId, version, this);
        }

        @Override
        protected NeUserPreferencesBuilder self() {
            return this;
        }
    }

    public static final class NeUserPreferencesInitialData
            extends NeUserPreferencesPrototype<NeUserPreferencesInitialData>
            implements NePreferencesPropertySource {

        @Override
        protected NeUserPreferencesInitialData self() {
            return this;
        }

        @Override
        public Optional<String> getOpaqueProperty(String name) {
            return Optional.ofNullable(getPropertyBag().get(name));
        }

        @Override
        public Map<String, String> getAllOpaqueProperties() {
            return getPropertyBag();
        }

        @Override
        public PropertyBag getDirectRoute() {
            return new PropertyBag() {
                @Override
                public Optional<String> getOpaqueProperty(String name) {
                    return Optional.ofNullable(NeUserPreferencesInitialData.super.routePropertyBag.get(name));
                }

                @Override
                public Map<String, String> getAllOpaqueProperties() {
                    return NeUserPreferencesInitialData.super.routePropertyBag;
                }
            };
        }

        @Override
        public String getName() {
            return super.name;
        }

        @Override
        public boolean usesGne() {
            return super.usesGne;
        }

        @Override
        public boolean usesFlatIp() {
            return super.usesFlatIp;
        }

        @Override
        public int getReconnectInterval() {
            return super.reconnectInterval;
        }

        @Override
        public Optional<String> getGlobalId() {
            return super.globalId;
        }

        @Override
        public Optional<String> getUserName() {
            return super.userName;
        }

        @Override
        public Optional<String> getPassword() {
            return super.password;
        }

        @Override
        public RouteSortingMode getRouteSortingMode() {
            return super.routeSortingMode;
        }

        @Override
        public NeDataTransferSettings getDataTransferSettings() {
            return new NeDataTransferSettings(super.dataTransferSettingsAdapter);
        }

        @Override
        public Optional<String> getUserText() {
            return super.userText;
        }
    }

    /**
     * Facilitates the creation of a {@link NeUserPreferencesData} object by allowing
     * individual attributes to be set easily.
     */
    public abstract static class NeUserPreferencesPrototype<T extends NeUserPreferencesPrototype<T>>
            extends DynamicBusinessObjectPrototype<T>
            implements NePropertySetters<T> {
        public static final int UNSIGNED = 0;

        private String name;
        private boolean usesGne;
        private boolean usesFlatIp;
        private int reconnectInterval;
        private RouteSortingMode routeSortingMode = RouteSortingMode.AUTO_PRIORITY;
        private Optional<String> globalId = Optional.empty();
        private Optional<String> password = Optional.empty();
        private Optional<String> userName = Optional.empty();
        private Optional<String> userText = Optional.empty();
        private Optional<Integer> containerId = Optional.of(UNSIGNED);

        private DataTransferSettingsAdapter dataTransferSettingsAdapter = new DataTransferSettingsAdapter();
        private final Map<String, String> routePropertyBag = new HashMap<>();
        private String routeKey;

        protected NeUserPreferencesPrototype() {
        }

        protected NeUserPreferencesPrototype(@Nonnull NeUserPreferencesPrototype<?> other) {
            super(other);

            name = other.name;
            usesGne = other.usesGne;
            usesFlatIp = other.usesFlatIp;
            reconnectInterval = other.reconnectInterval;
            routeSortingMode = other.routeSortingMode;
            globalId = other.globalId;
            password = other.password;
            userName = other.userName;
            containerId = other.containerId;
            dataTransferSettingsAdapter = other.dataTransferSettingsAdapter;
            userText = other.userText;

            routeKey = other.routeKey;
            routePropertyBag.putAll(other.getPropertyBag());
        }

        @Override
        protected abstract T self();

        /**
         * @param name NE name.
         */
        @Override
        public T setName(String name) {
            this.name = name;
            return self();
        }

        /**
         * @param usesGne Whether a GNE is used to reach this NE.
         */
        @Override
        public T setUsesGne(boolean usesGne) {
            this.usesGne = usesGne;
            return self();
        }

        /**
         * @param usesFlatIp Whether the NE is connected by a Flat IP.
         */
        @Override public T setUsesFlatIp(boolean usesFlatIp) {
            this.usesFlatIp = usesFlatIp;
            return self();
        }

        /**
         * @param reconnectInterval New reconnect interval.
         */
        @Override
        public T setReconnectInterval(int reconnectInterval) {
            this.reconnectInterval = reconnectInterval;
            return self();
        }

        /**
         * @param globalId New global identifier.
         */
        @Override
        public T setGlobalId(Optional<String> globalId) {
            this.globalId = globalId;
            return self();
        }

        /**
         * @param userName New login user name.
         */
        @Override
        public T setUserName(Optional<String> userName) {
            this.userName = userName;
            return self();
        }

        /**
         * @param password New login password.
         */
        @Override
        public T setPassword(Optional<String> password) {
            this.password = password;
            return self();
        }


        @Override
        public T setUserText(@Nonnull Optional<String> userText) {
            this.userText = userText;
            return self();
        }

        /**
         * @param sortByUsage New gateway route sorting mode.
         */
        @Override
        public T enableRouteSortingByUsage(@Nonnull boolean sortByUsage) {
            if (routeSortingMode != RouteSortingMode.NONE) {
                routeSortingMode =
                        sortByUsage ? RouteSortingMode.AUTO_PRIORITY : RouteSortingMode.DEFAULT;
            }
            return self();
        }

        /**
         * @param enabled Whether gateway route sorting should be enabled or disabled.
         */
        @Override
        public T enableRouteSorting(boolean enabled) {
            if (!enabled) {
                routeSortingMode = RouteSortingMode.NONE;
            } else {
                if (routeSortingMode == RouteSortingMode.NONE) {
                    routeSortingMode = RouteSortingMode.DEFAULT;
                }
            }
            return self();
        }

        /**
         * @param containerId New parent NE container identifier.
         */
        @Override
        public T setContainerId(Optional<Integer> containerId) {
            this.containerId = containerId;
            return self();
        }

        /**
         * @param dataTransferSettingsAdapter DataTransferSettings values.
         */
        @Override
        public T setDataTransferSettings(@Nonnull NeDataTransferSettingsAdapter<?> dataTransferSettingsAdapter) {
            this.dataTransferSettingsAdapter = (DataTransferSettingsAdapter) dataTransferSettingsAdapter;
            return self();
        }

        /**
         * @return An instance of {@link NeRoutePropertyAdapter} for the NE direct route.
         */
        @Override
        public NeRoutePropertyAdapter<DirectRouteAdapter> getDirectRouteAdapter() {
            return new DirectRouteAdapter(routePropertyBag) {
                @Override
                public DirectRouteAdapter setKey(String newKey) {
                    routeKey = newKey;
                    return this;
                }

                @Override
                public Optional<String> getKey() {
                    return Optional.ofNullable(routeKey);
                }
            };
        }

        @Override
        public NeDataTransferSettingsAdapter<? extends NeDataTransferSettingsAdapter> getDataTransferSettingsAdapter() {
            return dataTransferSettingsAdapter;
        }
    }

    abstract static class DirectRouteAdapter implements NeRoutePropertyAdapter<DirectRouteAdapter> {

        private final Map<String, String> routePropertyBag;

        DirectRouteAdapter(Map<String, String> routePropertyBag) {
            this.routePropertyBag = routePropertyBag;
        }

        @Override
        public Optional<String> getCost() {
            return Optional.empty();
        }

        @Override
        public Optional<String> getPriority() {
            return Optional.empty();
        }

        @Override
        public Optional<String> isUsed() {
            return Optional.empty();
        }

        @Override
        public Optional<String> getDomain() {
            return Optional.empty();
        }

        @Override
        public Optional<String> getGneName() {
            return Optional.empty();
        }

        @Override
        public Optional<String> getProperty(String name) {
            return Optional.ofNullable(routePropertyBag.get(name));
        }

        @Override
        public Map<String, String> getProperties() {
            return routePropertyBag;
        }

        @Override
        public DirectRouteAdapter setProperty(String name, String value) {
            routePropertyBag.put(name, value);
            return this;
        }

        @Override
        public DirectRouteAdapter setProperties(Map<String, String> properties) {
            routePropertyBag.putAll(properties);
            return this;
        }
    }

    public static class DataTransferSettingsAdapter implements NeDataTransferSettingsAdapter<DataTransferSettingsAdapter> {

        private Optional<String> uploadPath = Optional.empty();
        private Optional<String> username = Optional.empty();
        private Optional<String> password = Optional.empty();
        private Optional<String> ipAddress = Optional.empty();
        private Optional<Boolean> isScp = Optional.empty();

        public DataTransferSettingsAdapter() {
        }

        public DataTransferSettingsAdapter mergeWith(@Nonnull final NeDataTransferSettings target) {
            DataTransferSettingsAdapter mutation = new DataTransferSettingsAdapter();

            mutation.setUploadpath(uploadPath.map(Optional::of).orElse(target.getUploadPath()));
            mutation.setUsername(username.map(Optional::of).orElse(target.getUsername()));
            mutation.setPassword(password.map(Optional::of).orElse(target.getPassword()));
            mutation.setIpAddress(ipAddress.map(Optional::of).orElse(target.getIpAddress()));
            mutation.setIsScp(isScp.map(Optional::of).orElse(Optional.of(target.getIsScp())));

            return mutation;
        }


        @Override
        public Optional<String> getUploadpath() {
            return uploadPath;
        }

        @Override
        public Optional<String> getUsername() {
            return username;
        }

        @Override
        public Optional<String> getPassword() {
            return password;
        }

        @Override
        public Optional<String> getIpAddress() {
            return ipAddress;
        }

        @Override
        public Optional<Boolean> getIsScp() {
            return isScp;
        }

        @Override
        public DataTransferSettingsAdapter setUploadpath(Optional<String> uploadPath) {
            this.uploadPath = uploadPath;
            return this;
        }

        @Override
        public DataTransferSettingsAdapter setUsername(Optional<String> username) {
            this.username = username;
            return this;
        }

        @Override
        public DataTransferSettingsAdapter setPassword(Optional<String> password) {
            this.password = password;
            return this;
        }

        @Override
        public DataTransferSettingsAdapter setIpAddress(Optional<String> ipAddress) {
            this.ipAddress = ipAddress;
            return this;
        }

        @Override
        public DataTransferSettingsAdapter setIsScp(Optional<Boolean> isScp) {
            this.isScp = isScp;
            return this;
        }

    }
}
