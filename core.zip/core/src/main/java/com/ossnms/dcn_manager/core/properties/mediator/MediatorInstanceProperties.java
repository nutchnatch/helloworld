package com.ossnms.dcn_manager.core.properties.mediator;

import com.ossnms.dcn_manager.core.configuration.properties.WellKnownMediatorPropertyNames;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstanceCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalDataMutationDescriptor;
import com.ossnms.dcn_manager.exceptions.DataUpdateException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Strings.isNullOrEmpty;
import static com.google.common.collect.Iterables.tryFind;
import static com.ossnms.dcn_manager.i18n.T.tr;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * <p>Maps Mediator Instance properties to object attributes.</p>
 *
 * <p>Setting Mediator Instance property values will result in a set of three action
 * lists: mutations, creations and removals. They will be populated depending on the
 * current repository state and the value being set. User code must then apply those
 * actions.</p>
 */
public class MediatorInstanceProperties {

    private static final Logger LOGGER = getLogger(MediatorInstanceProperties.class);

    private final Iterable<MediatorInstance> existingInstances;
    private final int activePriority;

    private final List<MediatorPhysicalDataMutationDescriptor> dataMutations;
    private final List<MediatorInstanceCreateDescriptor> dataCreations;
    private final List<Integer> dataRemovals;


    /**
     * Creates a new object.
     * @param existingInstances Existing physical Mediator server instances to consider for
     * calculating updates, creations and removals.
     * @param activePriority Priority index to be considered active on creation operations.
     */
    public MediatorInstanceProperties(Iterable<MediatorInstance> existingInstances, int activePriority) {
        this.existingInstances = existingInstances;
        this.activePriority = activePriority;
        this.dataCreations = new LinkedList<>();
        this.dataMutations = new LinkedList<>();
        this.dataRemovals = new LinkedList<>();
    }

    /**
     * Examines a property name and determines whether this class is responsible for
     * handling it.
     * @param propertyName Property name.
     * @return True if the property with the name given should be handled by this class.
     */
    public static boolean isMediatorInstanceProperty(@Nullable String propertyName) {
        return WellKnownMediatorPropertyNames.PRIMARY_HOST_NAME.equals(propertyName) ||
               WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME.equals(propertyName);
    }

    /**
     * @return True if nothing needs to be changed.
     */
    public boolean noChanges() {
        return dataCreations.isEmpty() && dataMutations.isEmpty() && dataRemovals.isEmpty();
    }

    /**
     * @return Creation descriptors about physical Mediator server instances that should be created.
     */
    public List<MediatorInstanceCreateDescriptor> getDataCreations() {
        return dataCreations;
    }

    /**
     * @return Mutation descriptors against Mediator server instances that were modified.
     */
    public List<MediatorPhysicalDataMutationDescriptor> getDataMutations() {
        return dataMutations;
    }

    /**
     * @return Identifiers of physical Mediator server instances that should be deleted.
     */
    public List<Integer> getDataRemovals() {
        return dataRemovals;
    }

    /**
     * Process a collection of instances in order to provide their data as a set of properties.
     * @param existingInstances Collection of instances to transform.
     * @return Mediator instance properties.
     * @throws IllegalStateException If there are instances in the collection with duplicate priorities.
     */
    public static Map<String, String> getProperties(Iterable<MediatorInstance> existingInstances) {
        return StreamSupport.stream(existingInstances.spliterator(), false)
                .map(MediatorInstance::getPhysicalInfo)
                .collect(
                    Collectors.toMap(
                        (i) -> i.getPriority() == MediatorInstance.PRIMARY_PRIORITY_LEVEL
                            ? WellKnownMediatorPropertyNames.PRIMARY_HOST_NAME
                            : WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME,
                        MediatorPhysicalData::getHost)
                    );
    }

    /**
     * Processes a Mediator Instance property and determines the appropriate course of action
     * by adding an element to one of the three action lists.
     * @param name Property name.
     * @param value Property value.
     */
    public void setProperty(@Nonnull String name, @Nullable String value)
            throws DataUpdateException {
        checkArgument(!isNullOrEmpty(name), "Property name must not be null!");

        /*
         * The current UI supports only two physical instances at the most.
         * Therefore we restrict the scope to that usage in order to simplify.
         */
        final int priority;
        switch (name) {
            case WellKnownMediatorPropertyNames.PRIMARY_HOST_NAME:
                priority = MediatorInstance.PRIMARY_PRIORITY_LEVEL;
                break;
            case WellKnownMediatorPropertyNames.SECONDARY_HOST_NAME:
                priority = MediatorInstance.PRIMARY_PRIORITY_LEVEL + 1;
                break;
            default:
                return;
        }

        LOGGER.debug("Set mediator instance #{} {} to {}", priority, name, value);

        final Optional<MediatorInstance> existingInstance = StreamSupport.stream(existingInstances.spliterator(), false)
                .filter((i) -> i != null && i.getPhysicalInfo().getPriority() == priority).findFirst();
        if (existingInstance.isPresent()) {
            final MediatorInstance instance = existingInstance.get();
            if (isNullOrEmpty(value)) {
                if (instance.getConnection().isActive()) {
                    throw new DataUpdateException(tr(Message.MEDIATOR_ACTIVE_CANT_BE_REMOVED));
                }
                dataRemovals.add(instance.getPhysicalInfo().getId());
            } else {
                tryFind(dataMutations, (m) -> m.getTarget().getPriority() == priority)
                        .or(() -> buildMutationDescriptor(instance.getPhysicalInfo()))
                    .setHost(value);
            }
        } else if (!isNullOrEmpty(value)) {
            tryFind(dataCreations, (c) -> c.getInitialData().getPriority() == priority)
                    .or(() -> buildCreateDescriptor(priority, value))
                .getInitialData().setHost(value);
        }
    }

    private MediatorPhysicalDataMutationDescriptor buildMutationDescriptor(MediatorPhysicalData data) {
        final MediatorPhysicalDataMutationDescriptor mutation = new MediatorPhysicalDataMutationDescriptor(data);
        dataMutations.add(mutation);
        return mutation;
    }

    private MediatorInstanceCreateDescriptor buildCreateDescriptor(int priority, String host) {
        final MediatorInstanceCreateDescriptor create = new MediatorInstanceCreateDescriptor(host);
        create.getInitialData().setPriority(priority);
        create.getConnectionInitialData().setActive(priority == activePriority);
        dataCreations.add(create);
        return create;
    }
}
