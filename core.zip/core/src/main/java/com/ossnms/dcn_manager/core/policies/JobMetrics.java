package com.ossnms.dcn_manager.core.policies;


/**
 * Interface with job related metrics
 */
public interface JobMetrics {

    String ONGOING = "Ongoing";

    String PENDING = "Pending";

    /**
     * @return the number of ongoing jobs
     */
    int getOngoingJobCount();

    /**
     * @return the number of pending jobs
     */
    int getPendingJobCount();

}
