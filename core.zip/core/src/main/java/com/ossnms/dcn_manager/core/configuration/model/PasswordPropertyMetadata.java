package com.ossnms.dcn_manager.core.configuration.model;

import com.ossnms.dcn_manager.migration.jaxb.passwordproperties.Properties;

import java.util.Map;

public class PasswordPropertyMetadata extends ImmutableModelMap<Properties> {
    public PasswordPropertyMetadata(Map<String, Properties> map) {
        super(map);
    }
    
}
