package com.ossnms.dcn_manager.core.configuration.model;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.ImmutableBiMap.Builder;
import com.google.common.collect.Lists;
import com.ossnms.dcn_manager.core.jaxb.type.Element;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFile;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFiles;
import com.ossnms.dcn_manager.core.jaxb.type.TypeProperties;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.google.common.base.Strings.isNullOrEmpty;
import static com.google.common.collect.Iterables.find;

public abstract class Type {

    private static final Element EMPTY_ELEMENT = new Element();

    private final DefaultPropertyValues defaultPropertyValues;

    protected Type(@Nonnull DefaultPropertyValues defaultPropertyValues) {
        this.defaultPropertyValues = defaultPropertyValues;
    }

    /** @return The Type name. */
    public abstract String getName();

    /** @return The Type GUI label (short version). */
    public String getGuiLabelShort() {
        return getPropertyValue("GUI_LABEL_SHORT");
    }

    /** @return The Type GUI label (long version). */
    public String  getGuiLabelLong() {
        return getPropertyValue("GUI_LABEL_LONG");
    }

    /**
     * @return A map of all properties which have default values defined.
     */
    public Map<String, String> getSupportedPropertyDefaultValues() {
        return defaultPropertyValues.getAllDefaults(getSupportedPropertyFileNames());
    }

    /** @return The set of Type properties as name/value pairs. */
    public Map<String, String> getTypeProperties() {
        final TypeProperties typeProperties = getSupportedTypeProperties();
        return null == typeProperties
                ? Collections.<String, String>emptyMap()
                : typePropertiesElementsToMap(typeProperties.getElement());
    }

    /**
     * Given a property name as it is defined for a specific Type,
     * produce the normalized internal name. If no normalization
     * exists, return the original name.
     *
     * @param name Property name.
     * @return Normalized name or the original name if no normalization exists.
     */
    public String mapIncomingPropertyName(String name) {
        return name;
    }

    /**
     * Given a normalized property name, produce the name as it is
     * defined for a specific Type. If no specialization exists,
     * return the original name.
     *
     * @param name Normalized property name.
     * @return Specific name or the original name if no specialization exists.
     */
    public String mapOutgoingPropertyName(String name) {
        return name;
    }

    private Map<String, String> typePropertiesElementsToMap(@Nonnull List<Element> typePropertiesElements) {
        final Map<String, String> map = new HashMap<>(typePropertiesElements.size());
        for (final Element element : typePropertiesElements) {
            map.put(element.getKey(), element.getContent());
        }
        return map;
    }

    protected abstract TypeProperties getSupportedTypeProperties();

    protected abstract PropertyPageFiles getSupportedPropertyFiles();

    /**
     * @return A collection of file names related to properties.
     */
    public Collection<String> getSupportedPropertyFileNames() {
        final PropertyPageFiles propertyPageFiles = getSupportedPropertyFiles();
        return null == propertyPageFiles
            ? Collections.<String>emptyList()
            : Lists.transform(
                    propertyPageFiles.getPropertyPageFile(),
                    new GetPropertyPageFileName()
                );
    }

    /**
     * Retrieves the value of a NE Type property. These are not the same as the NE
     * configuration properties.
     * @param propertyName The NE Type property name.
     * @return The property value, or null if the property could not be found.
     */
    protected String getPropertyValue(final String propertyName) {
        final TypeProperties typeProperties = getSupportedTypeProperties();
        return typeProperties != null
                ? find(typeProperties.getElement(), new ElementKeyEquals(propertyName), EMPTY_ELEMENT).getContent()
                : null;
    }

    /*
     * Predicates and transformation functions
     */

    private static final class ElementKeyEquals implements Predicate<Element> {
        private final String propertyName;

        private ElementKeyEquals(String propertyName) {
            this.propertyName = propertyName;
        }

        @Override
        public boolean apply(@Nonnull Element input) {
            return input.getKey().equals(propertyName);
        }
    }

    private static final class GetPropertyPageFileName implements Function<PropertyPageFile, String> {
        @Override
        public String apply(@Nonnull PropertyPageFile input) {
            return input.getName();
        }
    }

    protected void putIfValid(Builder<String, String> mapBuilder, String key, String value) {
        if (!isNullOrEmpty(value)) {
            mapBuilder.put(key, value);
        }
    }

}
