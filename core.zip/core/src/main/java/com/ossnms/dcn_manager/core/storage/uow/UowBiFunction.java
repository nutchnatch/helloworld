package com.ossnms.dcn_manager.core.storage.uow;

import com.ossnms.dcn_manager.exceptions.DcnManagerException;

import javax.annotation.Nonnull;

/**
 * Unit of Work function object. This represents an operation within
 * a Unit of Work that receives an argument and produces a result.
 *
 * @param <T> Function parameter type.
 * @param <R> Function result type.
 */
@FunctionalInterface
public interface UowBiFunction<T, R> {

    /**
     * Applies this function to the given arguments.
     *
     * @param context Current Unit of Work execution context.
     * @param t The other function argument.
     * @return The function result.
     * @throws DcnManagerException When the function execution has failed.
     */
    R apply(@Nonnull UowContext context, T t) throws DcnManagerException;

}
