package com.ossnms.dcn_manager.core.events.ne;

import com.google.common.base.Objects;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;

/**
 * Represents the occurrence of an event against an NE, including
 * the identification of the NEs' Channel and of that Channels' Mediator.
 */
public abstract class IdentifiedNeEvent extends NeEvent {

    private final int physicalChannelId;
    private final int physicalMediatorId;
    private final int physicalNeId;
    private final boolean activeInstance;

    /**
     * Creates a new instance.
     * @param neId NE identifier.
     * @param physicalChannelId Parent Channel identifier.
     * @param physicalMediatorId Parent Mediator identifier.
     * @param physicalNeId Physical NE identifier.
     * @param activeInstance Whether this refers to the physical NE instance that is
     * currently active (as opposed to the standby instance).
     */
    public IdentifiedNeEvent(int neId, int physicalChannelId, int physicalMediatorId, int physicalNeId, boolean activeInstance) {
        super(neId);
        this.physicalChannelId = physicalChannelId;
        this.physicalMediatorId = physicalMediatorId;
        this.physicalNeId = physicalNeId;
        this.activeInstance = activeInstance;
    }

    /**
     * Creates a new object.
     * @param neId The affected NE ID.
     * @param physicalChannelId Parent Channel identifier.
     * @param physicalMediatorId Parent Mediator identifier.
     * @param physicalNeId Physical NE identifier.
     * @param detailedDescription Detailed event description for human consumption.
     * @param activeInstance Whether this refers to the physical NE instance that is
     * currently active (as opposed to the standby instance).
     */
    public IdentifiedNeEvent(int neId, int physicalChannelId, int physicalMediatorId, int physicalNeId, boolean activeInstance, @Nonnull String detailedDescription) {
        super(neId, detailedDescription);
        this.physicalChannelId = physicalChannelId;
        this.physicalMediatorId = physicalMediatorId;
        this.physicalNeId = physicalNeId;
        this.activeInstance = activeInstance;
    }

    /**
     * @return The parent Channel identifier.
     */
    public int getPhysicalChannelId() {
        return physicalChannelId;
    }

    /**
     * @return The identifier of the mediator to which the Channel is associated.
     */
    public int getPhysicalMediatorId() {
        return physicalMediatorId;
    }

    /**
     * @return Physical NE connection instance identifier.
     */
    public int getPhysicalNeId() {
        return physicalNeId;
    }

    /**
     * @return Whether this refers to the physical NE instance that is
     * currently active (as opposed to the standby instance).
     */
    public boolean isActiveInstance() {
        return activeInstance;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(physicalChannelId, physicalMediatorId, physicalNeId,
                getDetailedDescription(), getEntityId(), activeInstance);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        final IdentifiedNeEvent rhs = (IdentifiedNeEvent) obj;
        return new EqualsBuilder()
            .append(getEntityId(), rhs.getEntityId())
            .append(getDetailedDescription(), rhs.getDetailedDescription())
            .append(getPhysicalChannelId(), rhs.getPhysicalChannelId())
            .append(getPhysicalMediatorId(), rhs.getPhysicalMediatorId())
            .append(getPhysicalNeId(), rhs.getPhysicalNeId())
            .append(isActiveInstance(), rhs.isActiveInstance())
            .isEquals();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("physicalNeId", physicalNeId)
                .append("physicalChannelId", physicalChannelId)
                .append("physicalMediatorId", physicalMediatorId)
                .append("isActiveInstance", activeInstance)
                .toString();
    }
}
