package com.ossnms.dcn_manager.core.entities.channel.data;

import com.ossnms.dcn_manager.core.entities.PropertyBag;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Optional;

/**
 * Aggregation class for the different facets of the channel entity. Each facet is
 * itself materialized as a domain object that represents the corresponding subset of
 * data and functionality.
 *
 * Instances are immutable, and are therefore thread-safe.
 */
public final class ChannelEntity implements PropertyBag {

    /** Holds the facet that represents the channel's required state */
    private final ChannelInfoData info;

    /** Holds the facet that represents the channel's actual connection state */
    private final ChannelConnectionData connectionState;

    /** Holds the facet that represents the channel's preferences */
    private final ChannelUserPreferencesData userPreferences;

    /**
     * Creates a new aggregate object with the given facet instances.
     * @param state Entity state.
     * @param connState Connection state.
     * @param userPrefs User preferences.
     */
    public ChannelEntity(@Nonnull ChannelInfoData state, @Nonnull ChannelConnectionData connState, @Nonnull ChannelUserPreferencesData userPrefs) {
        info = state;
        connectionState = connState;
        userPreferences = userPrefs;
    }

    /** @return The entity state. */
    public ChannelInfoData getInfo() {
        return info;
    }

    /** @return The connection state. */
    public ChannelConnectionData getConnectionState() {
        return connectionState;
    }

    /** @return The user preferences. */
    public ChannelUserPreferencesData getUserPreferences() {
        return userPreferences;
    }

    /** {@inheritDoc} */
    @Override
    public Optional<String> getOpaqueProperty(String name) {
        return getUserPreferences().getOpaqueProperty(name);
    }

    /** {@inheritDoc} */
    @Override
    public Map<String, String> getAllOpaqueProperties() {
        return getUserPreferences().getAllOpaqueProperties();
    }
}
