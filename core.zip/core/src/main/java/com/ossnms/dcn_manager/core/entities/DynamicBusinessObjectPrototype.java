package com.ossnms.dcn_manager.core.entities;

import com.google.common.base.Strings;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

/**
 * <p>Abstract class that is the base class for all object prototypes that are to be used
 * to initialize domain objects which have a dynamic facet.</p>
 *
 * @param <T> the concrete type of the derived class
 */
public abstract class DynamicBusinessObjectPrototype<T extends DynamicBusinessObjectPrototype<T>> {

    private final Map<String,String> propertyBag = new HashMap<>();

    protected DynamicBusinessObjectPrototype() {

    }

    protected DynamicBusinessObjectPrototype(@Nonnull DynamicBusinessObjectPrototype<?> other) {
        setProperties(other.propertyBag);
    }

    protected abstract T self();

    /**
     * @return The current mutable property bag.
     */
    public Map<String, String> getPropertyBag() {
        return propertyBag;
    }

    /**
     * Sets or removes a property value from the current property bag.
     * Property values are removed if they are {@code null} or empty.
     *
     * @param name Property name.
     * @param value New property value.
     */
    public T setProperty(@Nonnull String name, @Nullable String value) {
        if (Strings.isNullOrEmpty(value)) {
            propertyBag.remove(name);
        } else {
            propertyBag.put(name, value);
        }
        return self();
    }

    /**
     * Sets or removes several property values from the current property bag.
     * Property values are removed if they are {@code null} or empty.
     *
     * @param properties Property names and new values.
     */
    public T setProperties(@Nonnull Map<String, String> properties) {
        for (final Entry<String, String> entry : properties.entrySet()) {
            setProperty(entry.getKey(), entry.getValue());
        }
        return self();
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("propertyBag", propertyBag)
                .toString();
    }
}
