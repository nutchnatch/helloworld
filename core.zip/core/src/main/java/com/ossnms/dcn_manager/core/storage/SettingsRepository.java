package com.ossnms.dcn_manager.core.storage;

import com.ossnms.dcn_manager.core.entities.emne.GlobalSettings;
import com.ossnms.dcn_manager.core.entities.emne.GlobalSettingsMutationDescriptor;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import java.util.Optional;

/**
 * Describes the contract that must be respected by implementations of the
 * DCN Manager settings repository.
 *
 * This repository is responsible for storing the DCN Manager configuration.
 */
public interface SettingsRepository {

    /**
     * @return The current DCN Manager configuration.
     */
    GlobalSettings getSettings();

    /**
     * Attempts to update the DCN Manager configuration.
     * @param mutation Describes the changes that must be applied to the existing
     *  configuration.
     * @return The DCN Manager configuration after the update, if successful.
     * @throws RepositoryException If an error occurs while working with the
     *  underlying data storage.
     */
    Optional<GlobalSettings> tryUpdateSettings(GlobalSettingsMutationDescriptor mutation)
        throws RepositoryException;

    /**
     * Read-only access to a configuration parameter that is managed elsewhere.
     * @return Whether connections to non-active physical managed object instances are allowed.
     */
    boolean areStandbyConnectionsAllowed();

}
