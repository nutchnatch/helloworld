package com.ossnms.dcn_manager.core.events.mediator;

import java.util.Objects;
import java.util.Optional;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * <p>Used to signal actual mediator activation state changes. Derived class instances
 * represent specific mediator activation events, namely, activation completed, deactivation completed and
 * activation failure events. The following figure depicts the class hierarchy.</p>
 *
 * <p> <figure>
 * <img src="doc-files/mediator_actual_activation_state_event-class.png">
 * <figcaption>Class diagram of the events related to operations performed on actual mediator state domain
 * objects</figcaption>
 * </figure> </p>
 *
 * <p>The abstract base class ({@link ActualMediatorStateEvent}) defines the information associated to all
 * concrete events. Instead of materializing these concrete event types as derived top-level classes, thus
 * increasing the overall solution's complexity (i.e. the total number of top-level classes), concrete event
 * types are materialized as static nested classes, leading to a curious coding pattern in which derived
 * classes are public nested classes of its super class.</p>
 *
 * <p>Despite being a curious coding pattern, the resulting solution reduces overall complexity and increases
 * readability: all related types are contained within the same compilation unit which, given its small size,
 * is not affected by significant complexity increase.</p>
 */
/*
 * @startuml doc-files/mediator_actual_activation_state_event-class.png
 * abstract class ActualMediatorStateEvent <<Immutable>> {
 *      # ActualMediatorStateEvent(id: int)
 *      # ActualMediatorStateEvent(id: int, description: String)
 * }
 * class MediatorActivatingEvent <<Immutable>> {
 *      + MediatorActivatingEvent(id: int, type: String)
 *      + MediatorActivatingEvent(id: int, description: String)
 * }
 * class MediatorActivatedEvent <<Immutable>> {
 *      + MediatorActivatedEvent(id: int)
 *      + MediatorActivatedEvent(id: int, description: String)
 * }
 * class MediatorDeactivatingEvent <<Immutable>> {
 *      + MediatorDeactivatingEvent(id: int, type: String)
 *      + MediatorDeactivatingEvent(id: int, description: String)
 * }
 * class MediatorDeactivatedEvent <<Immutable>> {
 *      + MediatorDeactivatedEvent(id: int)
 *      + MediatorDeactivatedEvent(id: int, description: String)
 * }
 * class MediatorActivationFailedEvent <<Immutable>> {
 *      + MediatorActivationFailedEvent(id: int)
 *      + MediatorActivationFailedEvent(id: int, description: String)
 * }
 * abstract MediatorEvent <<Immutable>> <|-- ActualMediatorStateEvent
 * hide MediatorEvent members
 * ActualMediatorStateEvent <|-- MediatorDeactivatedEvent
 * ActualMediatorStateEvent <|-- MediatorActivatedEvent
 * ActualMediatorStateEvent <|-- MediatorDeactivatingEvent
 * ActualMediatorStateEvent <|-- MediatorActivatingEvent
 * ActualMediatorStateEvent <|-- MediatorActivationFailedEvent
 * @enduml
 */
@Immutable
public abstract class ActualMediatorStateEvent extends MediatorEvent {

    private final PhysicalMediatorStateEvent originatingPhysicalEvent;

    /**
     * Initiates an instance with the given arguments.
     * @param id The affected mediator identifier.
     */
    protected ActualMediatorStateEvent(int mediatorId) {
        super(mediatorId);
        this.originatingPhysicalEvent = null;
    }

    /**
     * Initiates an instance with the given arguments.
     * @param channelId The affected mediator identifier.
     * @param detailedDescription Human-readable event description.
     */
    protected ActualMediatorStateEvent(int mediatorId, @Nonnull String detailedDescription) {
        super(mediatorId, detailedDescription);
        this.originatingPhysicalEvent = null;
    }

    /**
     * Initiates an instance with the given arguments.
     * @param id The affected mediator identifier.
     */
    protected ActualMediatorStateEvent(int mediatorId, @Nonnull PhysicalMediatorStateEvent originatingPhysicalEvent) {
        super(mediatorId);
        this.originatingPhysicalEvent = originatingPhysicalEvent;
    }

    /**
     * Initiates an instance with the given arguments.
     * @param channelId The affected mediator identifier.
     * @param detailedDescription Human-readable event description.
     */
    protected ActualMediatorStateEvent(int mediatorId, @Nonnull PhysicalMediatorStateEvent originatingPhysicalEvent, @Nonnull String detailedDescription) {
        super(mediatorId, detailedDescription);
        this.originatingPhysicalEvent = originatingPhysicalEvent;
    }

    /**
     * @return the originatingPhysicalEvent
     */
    public Optional<PhysicalMediatorStateEvent> getOriginatingPhysicalEvent() {
        return Optional.ofNullable(originatingPhysicalEvent);
    }

    @Override
    public int hashCode() {
        return Objects.hash(getMediatorId(), getDetailedDescription(), originatingPhysicalEvent);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final ActualMediatorStateEvent rhs = (ActualMediatorStateEvent) obj;
        return new EqualsBuilder()
                .append(getMediatorId(), rhs.getMediatorId())
                .append(getDetailedDescription(), rhs.getDetailedDescription())
                .append(originatingPhysicalEvent, rhs.originatingPhysicalEvent)
                .isEquals();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("originatingPhysicalEvent", originatingPhysicalEvent)
                .toString();
    }

    /**
     * Class whose instances represent events used to signal that a mediation activation has been initiated.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class MediatorActivatingEvent extends ActualMediatorStateEvent {

        public MediatorActivatingEvent(int mediatorId) {
            super(mediatorId);
        }

        public MediatorActivatingEvent(int mediatorId, @Nonnull String detailedDescription) {
            super(mediatorId, detailedDescription);
        }

        public MediatorActivatingEvent(int mediatorId, @Nonnull PhysicalMediatorStateEvent originatingPhysicalEvent) {
            super(mediatorId, originatingPhysicalEvent);
        }

        public MediatorActivatingEvent(int mediatorId, @Nonnull PhysicalMediatorStateEvent originatingPhysicalEvent, @Nonnull String detailedDescription) {
            super(mediatorId, originatingPhysicalEvent, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a mediation activation is going to be scheduled.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class MediatorStartingUpEvent extends ActualMediatorStateEvent {

        public MediatorStartingUpEvent(int mediatorId) {
            super(mediatorId);
        }

        public MediatorStartingUpEvent(int mediatorId, @Nonnull String detailedDescription) {
            super(mediatorId, detailedDescription);
        }

        public MediatorStartingUpEvent(int mediatorId, @Nonnull PhysicalMediatorStateEvent originatingPhysicalEvent) {
            super(mediatorId, originatingPhysicalEvent);
        }

        public MediatorStartingUpEvent(int mediatorId, @Nonnull PhysicalMediatorStateEvent originatingPhysicalEvent, @Nonnull String detailedDescription) {
            super(mediatorId, originatingPhysicalEvent, detailedDescription);
        }
    }


    
    /**
     * Class whose instances represent events used to signal that a mediation activation has succeeded.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class MediatorActivatedEvent extends ActualMediatorStateEvent {

        public MediatorActivatedEvent(int mediatorId) {
            super(mediatorId);
        }

        public MediatorActivatedEvent(int mediatorId, @Nonnull String detailedDescription) {
            super(mediatorId, detailedDescription);
        }

        public MediatorActivatedEvent(int mediatorId, @Nonnull PhysicalMediatorStateEvent originatingPhysicalEvent) {
            super(mediatorId, originatingPhysicalEvent);
        }

        public MediatorActivatedEvent(int mediatorId, @Nonnull PhysicalMediatorStateEvent originatingPhysicalEvent, @Nonnull String detailedDescription) {
            super(mediatorId, originatingPhysicalEvent, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a mediation activation has failed.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
   public static final class MediatorActivationFailedEvent extends ActualMediatorStateEvent {

        public MediatorActivationFailedEvent(int mediatorId) {
            super(mediatorId);
        }

        public MediatorActivationFailedEvent(int mediatorId, @Nonnull String detailedDescription) {
            super(mediatorId, detailedDescription);
        }

        public MediatorActivationFailedEvent(int mediatorId, @Nonnull PhysicalMediatorStateEvent originatingPhysicalEvent) {
            super(mediatorId, originatingPhysicalEvent);
        }

        public MediatorActivationFailedEvent(int mediatorId, @Nonnull PhysicalMediatorStateEvent originatingPhysicalEvent, @Nonnull String detailedDescription) {
            super(mediatorId, originatingPhysicalEvent, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a mediation deactivation has been initiated.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
   public static final class MediatorDeactivatingEvent extends ActualMediatorStateEvent {

        public MediatorDeactivatingEvent(int mediatorId) {
            super(mediatorId);
        }

        public MediatorDeactivatingEvent(int mediatorId, @Nonnull String detailedDescription) {
            super(mediatorId, detailedDescription);
        }

        public MediatorDeactivatingEvent(int mediatorId, @Nonnull PhysicalMediatorStateEvent originatingPhysicalEvent) {
            super(mediatorId, originatingPhysicalEvent);
        }

        public MediatorDeactivatingEvent(int mediatorId, @Nonnull PhysicalMediatorStateEvent originatingPhysicalEvent, @Nonnull String detailedDescription) {
            super(mediatorId, originatingPhysicalEvent, detailedDescription);
        }
    }

    /**
     * Class whose instances represent events used to signal that a mediation deactivation has completed.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class MediatorDeactivatedEvent extends ActualMediatorStateEvent {

        public MediatorDeactivatedEvent(int mediatorId) {
            super(mediatorId);
        }

        public MediatorDeactivatedEvent(int mediatorId, @Nonnull String detailedDescription) {
            super(mediatorId, detailedDescription);
        }

        public MediatorDeactivatedEvent(int mediatorId, @Nonnull PhysicalMediatorStateEvent originatingPhysicalEvent) {
            super(mediatorId, originatingPhysicalEvent);
        }

        public MediatorDeactivatedEvent(int mediatorId, @Nonnull PhysicalMediatorStateEvent originatingPhysicalEvent, @Nonnull String detailedDescription) {
            super(mediatorId, originatingPhysicalEvent, detailedDescription);
        }
    }
    
    /**
     * Class whose instances represent events used to signal that a mediation de-activation is going to be scheduled.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
    public static final class MediatorShuttingDownEvent extends ActualMediatorStateEvent {

        public MediatorShuttingDownEvent(int mediatorId) {
            super(mediatorId);
        }

        public MediatorShuttingDownEvent(int mediatorId, @Nonnull String detailedDescription) {
            super(mediatorId, detailedDescription);
        }

        public MediatorShuttingDownEvent(int mediatorId, @Nonnull PhysicalMediatorStateEvent originatingPhysicalEvent) {
            super(mediatorId, originatingPhysicalEvent);
        }

        public MediatorShuttingDownEvent(int mediatorId, @Nonnull PhysicalMediatorStateEvent originatingPhysicalEvent, @Nonnull String detailedDescription) {
            super(mediatorId, originatingPhysicalEvent, detailedDescription);
        }
    }



}
