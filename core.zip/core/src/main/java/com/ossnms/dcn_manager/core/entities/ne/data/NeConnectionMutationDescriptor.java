package com.ossnms.dcn_manager.core.entities.ne.data;

import com.google.common.base.MoreObjects;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Contains all data that should be changed on {@link NeConnectionData},
 * when applied as a single atomic mutation by the repository.
 */
public class NeConnectionMutationDescriptor
        extends MutationDescriptor<NeConnectionData, NeConnectionMutationDescriptor> {

    private Optional<ActualActivationState> activationState = Optional.empty();
    private Optional<String> additionalInfo = Optional.empty();
    private Optional<String> connectedVia = Optional.empty();

    public NeConnectionMutationDescriptor(NeConnectionData target) {
        super(target);
    }

    @Override
    protected NeConnectionMutationDescriptor self() {
        return this;
    }

    @Override
    protected NeConnectionData doApply() {
        final boolean isActivationInfoSet = activationState.isPresent() || additionalInfo.isPresent();
        return isActivationInfoSet || connectedVia.isPresent()
                   ? new NeConnectionBuilder()
                        .setActivationState(activationState.orElse(getTarget().getActivationState()))
                        .setConnectedVia(connectedVia.map(Optional::of).orElse(getTarget().getConnectedVia()))
                        .setAdditionalInfo(additionalInfo.map(Optional::of).orElse(getTarget().getAdditionalInfo()))
                        .build(getTarget().getId(), getTarget().getVersion())
                   : getTarget();
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .omitNullValues()
                .add("additionalInfo", additionalInfo.orElse(null))
                .add("connectedVia", connectedVia.orElse(null))
                .add("activationState", activationState.orElse(null))
                .toString();
    }

    /**
     * @return The text that describes the currently connected route.
     */
    public Optional<String> getConnectedVia() {
        return connectedVia;
    }

    /**
     * @param connectedVia New current route description.
     */
    public NeConnectionMutationDescriptor setConnectedVia(Optional<String> connectedVia) {
        this.connectedVia = connectedVia;
        return self();
    }

    /**
     * @return Additional connection information to display to the operator.
     */
    public Optional<String> getAdditionalInfo() {
        return additionalInfo;
    }

    /**
     * @param additionalInfo Additional connection information for the operator.
     */
    public NeConnectionMutationDescriptor setAdditionalInfo(@Nonnull String additionalInfo) {
        this.additionalInfo = Optional.of(additionalInfo);
        return self();
    }

    /**
     * @return Actual NE activation state.
     */
    public Optional<ActualActivationState> getActivationState() {
        return activationState;
    }

    /**
     * @param activationState New actual NE activation state.
     */
    public NeConnectionMutationDescriptor setActivationState(@Nonnull ActualActivationState activationState) {
        this.activationState = Optional.of(activationState);
        return self();
    }

}
