package com.ossnms.dcn_manager.core.entities.ne.data;

import com.ossnms.dcn_manager.core.entities.ne.data.NeDirectRouteData.NeDirectRouteBuilder;

public class NeDirectRouteMutationDescriptor extends NeConnectionRouteMutationDescriptor<NeDirectRouteData, NeDirectRouteMutationDescriptor> {

    public NeDirectRouteMutationDescriptor(NeDirectRouteData target) {
        super(target);
    }

    @Override
    protected NeDirectRouteData doApply() {
        final boolean areAnyFieldsSet =
                areSortingAttributesChanged() || getKey().isPresent() ||
                getDomain().isPresent();
        return areAnyFieldsSet || !getProperties().isEmpty()
                   ? new NeDirectRouteBuilder()
                        .setProperties(getTarget().getAllOpaqueProperties())
                        .setProperties(getProperties())
                        .setPriority(getPriority().orElse(getTarget().getPriority()))
                        .setCost(getCost().orElse(getTarget().getCost()))
                        .setUsed(getUsed().orElse(getTarget().isUsed()))
                        .setKey(getKey().orElse(getTarget().getKey()))
                        .setDomain(getDomain().or(getTarget().getDomain()))
                        .build(getTarget().getId(), getTarget().getVersion())
                   : getTarget();
    }

    private boolean areSortingAttributesChanged() {
        return getPriority().isPresent() || getCost().isPresent() || getUsed().isPresent();
    }

    @Override
    protected NeDirectRouteMutationDescriptor self() {
        return this;
    }
}
