package com.ossnms.dcn_manager.core.properties.ne;

import java.util.Map;

import javax.annotation.Nonnull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.ne.data.NeCreateDescriptor;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;

/**
 * Utility methods for managing NE properties.
 *
 * Contains operations that span more than one of the different NE property domains:
 * NE, Gateway Route, Direct Route, etc.
 */
public final class NePropertyUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(NePropertyUtils.class);

    private NePropertyUtils() {

    }

    /**
     * Given an NE creation descriptor, apply to itself the default property values
     * defined by the corresponding NE type.
     *
     * @param createDescriptor NE creation descriptor.
     * @param neProperties NE Property management.
     * @param directRouteProperties NE Direct Route Property management.
     */
    public static void applyDefaultProperties(NeCreateDescriptor createDescriptor,
            NeProperties neProperties, NeDirectRouteProperties directRouteProperties) {
        final NeType neType = createDescriptor.getType();
        for (final Map.Entry<String, String> entry : neType.getSupportedPropertyDefaultValues().entrySet()) {
            try {
                if (directRouteProperties.handles(neType, entry.getKey())) {
                    directRouteProperties.set(neType, createDescriptor, createDescriptor.getPreferences(), entry.getKey(), entry.getValue());
                } else {
                    neProperties.setProperty(neType, createDescriptor.getPreferences(), entry.getKey(), entry.getValue());
                }
            } catch (final InvalidMutationException e) {
                LOGGER.warn("Failed to apply default property {}: {}", entry, e);
            }
        }
    }

    public static void applyAdditionalControlProperties(NeCreateDescriptor createDescriptor, NeOperationalProperties neProperties, @Nonnull Map<String, String> updatedProperties) {
        Map<String, String> controlMap = ImmutableMap.<String, String>builder()
                .putAll(createDescriptor.getType().getIdentificationControlMap())
                .putAll(createDescriptor.getType().getAdditionalTypeInfoControlMap())
                .build();
        LOGGER.debug("Got Map: {}", controlMap);
        for (final Map.Entry<String, String> idControlEntry: controlMap.entrySet() ) {
            if (updatedProperties.containsKey(idControlEntry.getValue())) {
                try {
                    neProperties.setProperty(createDescriptor.getType(), createDescriptor.getOperation(), idControlEntry.getKey(), updatedProperties.get(idControlEntry.getValue()));
                }
                catch (final InvalidMutationException e) {
                    LOGGER.warn("Failed to apply ne control property {}: {}", idControlEntry, e);
                }
            }
        }
    }
}
