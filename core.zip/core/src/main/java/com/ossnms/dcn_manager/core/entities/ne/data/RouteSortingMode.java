package com.ossnms.dcn_manager.core.entities.ne.data;

public enum RouteSortingMode {
    /** The mediation has switched the "auto priority" mode from DEFAULT. */
    AUTO_PRIORITY,
    /** Standard ordering. */
    DEFAULT,
    /** Operator has disabled route "auto priority". */
    NONE
}