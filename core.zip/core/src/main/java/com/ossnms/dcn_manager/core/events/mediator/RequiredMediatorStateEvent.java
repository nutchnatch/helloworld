package com.ossnms.dcn_manager.core.events.mediator;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;
import java.util.Collections;
import java.util.Objects;

/**
 * <p>Used to signal required mediator activation state changes. Derived class instances
 * represent specific mediator activation events, namely, activation requested and
 * deactivation requested. The following figure depicts the class hierarchy.</p>
 *
 * <p> <figure>
 * <img src="doc-files/mediator_required_activation_state_event-class.png">
 * <figcaption>Class diagram of the events related to operations performed on required mediator state domain
 * objects</figcaption>
 * </figure> </p>
 *
 * <p>The abstract base class ({@link RequiredMediatorStateEvent}) defines the information associated to all
 * concrete events. Instead of materializing these concrete event types as derived top-level classes, thus
 * increasing the overall solution's complexity (i.e. the total number of top-level classes), concrete event
 * types are materialized as static nested classes, leading to a curious coding pattern in which derived
 * classes are public nested classes of its super class.</p>
 *
 * <p>Despite being a curious coding pattern, the resulting solution reduces overall complexity and increases
 * readability: all related types are contained within the same compilation unit which, given its small size,
 * is not affected by significant complexity increase.</p>
 */
/*
 * @startuml doc-files/mediator_required_activation_state_event-class.png
 * abstract class RequiredMediatorStateEvent <<Immutable>> {
 *      # RequiredMediatorStateEvent(id: int)
 *      # RequiredMediatorStateEvent(id: int, description: String)
 * }
 * class ActivateMediatorEvent <<Immutable>> {
 *      + ActivateMediatorEvent(id: int)
 * }
 * class DeactivateMediatorEvent <<Immutable>> {
 *      + DeactivateMediatorEvent(id: int)
 * }
 * abstract MediatorEvent <<Immutable>> <|-- RequiredMediatorStateEvent
 * hide MediatorEvent members
 * RequiredMediatorStateEvent <|-- ActivateMediatorEvent
 * RequiredMediatorStateEvent <|-- DeactivateMediatorEvent
 * @enduml
 */
@Immutable
public abstract class RequiredMediatorStateEvent extends MediatorEvent {

    private final Iterable<Integer> mediatorInstanceIdentifiers;

    /**
     * Initiates an instance with the given arguments.
     * @param mediatorId The affected mediator identifier.
     * @param mediatorInstances Mediator instances upon which the required state must be enforced.
     */
    protected RequiredMediatorStateEvent(int mediatorId, @Nonnull Iterable<Integer> mediatorInstances) {
        super(mediatorId);
        this.mediatorInstanceIdentifiers = mediatorInstances;
    }

    /**
     * @return Mediator instances upon which the required state must be enforced.
     */
    public Iterable<Integer> getMediatorInstanceIdentifiers() {
        return mediatorInstanceIdentifiers;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getMediatorId(), getDetailedDescription(), mediatorInstanceIdentifiers);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final RequiredMediatorStateEvent rhs = (RequiredMediatorStateEvent) obj;
        return new EqualsBuilder()
                .append(getMediatorId(), rhs.getMediatorId())
                .append(getDetailedDescription(), rhs.getDetailedDescription())
                .append(mediatorInstanceIdentifiers, rhs.mediatorInstanceIdentifiers)
                .isEquals();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("mediatorInstanceIdentifiers", mediatorInstanceIdentifiers)
                .toString();
    }

    /**
     * Class whose instances represent events used to signal that a mediation activation is required.
     * Initiation parameters have the same semantics of the initiation parameters of the base class.
     */
    @Immutable
     public static final class ActivateMediatorEvent extends RequiredMediatorStateEvent {

        public ActivateMediatorEvent(int mediatorId, int mediatorInstance) {
            super(mediatorId, Collections.singleton(mediatorInstance));
        }
    }

     /**
      * Class whose instances represent events used to signal that a mediation deactivation is required.
      * Initiation parameters have the same semantics of the initiation parameters of the base class.
      */
    @Immutable
    public static final class DeactivateMediatorEvent extends RequiredMediatorStateEvent {

        public DeactivateMediatorEvent(int mediatorId, @Nonnull Iterable<Integer> mediatorInstances) {
            super(mediatorId, mediatorInstances);
        }

         public DeactivateMediatorEvent(int mediatorId, int mediatorInstance) {
             super(mediatorId, Collections.singleton(mediatorInstance));
         }
    }
}
