package com.ossnms.dcn_manager.core.events.container;

import com.ossnms.dcn_manager.core.entities.container.assignment.AssignmentType;

/**
 * Base class for events that affect a container.
 */
public class ContainerSystemAssignmentUpdatedEvent extends ContainerEvent {

    private final int systemId;
    private final AssignmentType assignmentType;

    /**
     * Creates a new object.
     *
     * @param containerId The affected container ID.
     */
    public ContainerSystemAssignmentUpdatedEvent(int containerId, int systemId, AssignmentType assignmentType) {
        super(containerId);
        this.systemId = systemId;
        this.assignmentType = assignmentType;
    }

    public int getSystemId() {
        return systemId;
    }

    public int getContainerId() { return getEntityId(); }

    public AssignmentType getAssignmentType() {
        return assignmentType;
    }
}
