package com.ossnms.dcn_manager.core.properties.ne;

import javax.annotation.Nonnull;

import com.google.common.base.Function;

/**
 * Provides an index for a property information class.
 */
final class PropertyInfoIndex implements
        Function<PropertyInfo, Integer> {

    @Override
    public Integer apply(@Nonnull PropertyInfo input) {
        return input.getIndex();
    }
}