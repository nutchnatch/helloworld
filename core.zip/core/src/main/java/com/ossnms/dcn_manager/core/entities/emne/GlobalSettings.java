package com.ossnms.dcn_manager.core.entities.emne;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.ossnms.dcn_manager.core.entities.BusinessObjectData;

/**
 * Global DCN Manager configuration.
 */
public final class GlobalSettings extends BusinessObjectData {

    private final int mediatorRetries;
    private final int channelRetries;
    private final int neRetries;
    private final int retryInterval;
    private final int scaledStartupLimit;
    private final DiscoveryPolicy discoveryPolicy;
    private final boolean enableScheduledStartup;
    private final boolean showNativeNeNaming;
    private final String defaultContainerName;

    /**
     * Begins creation of a new object. Provides a prototype builder that will be
     * used to instantiate the new GlobalSettings instance later on.
     *
     * @return An instance of a GlobalSettings builder class.
     */
    public static Builder build() {
        return new Builder();
    }

    /**
     * Creates a new object.
     * @param id Instance identifier.
     * @param version Instance version number.
     * @param builder Prototype information.
     */
    private GlobalSettings(int id, int version, @Nonnull Builder builder) {
        super(id, version);
        this.mediatorRetries = builder.mediatorRetries;
        this.channelRetries = builder.channelRetries;
        this.neRetries = builder.neRetries;
        this.retryInterval = builder.retryInterval;
        this.scaledStartupLimit = builder.scaledStartupLimit;
        this.discoveryPolicy = builder.discoveryPolicy;
        this.enableScheduledStartup = builder.enableScheduledStartup;
        this.showNativeNeNaming = builder.showNativeNeNaming;
        this.defaultContainerName = builder.defaultContainerName;
    }

    /** @return Mediator connection retry limit. Zero means infinite. */
    public int getMediatorRetries() {
        return mediatorRetries;
    }

    /** @return Channel connection retry limit. Zero means infinite. */
    public int getChannelRetries() {
        return channelRetries;
    }

    /** @return NE connection retry limit. Zero means infinite. */
    public int getNeRetries() {
        return neRetries;
    }

    /** @return Retry interval. */
    public int getRetryInterval() {
        return retryInterval;
    }

    /** @return Scaled startup limit value. */
    public int getScaledStartupLimit() {
        return scaledStartupLimit;
    }

    /** @return The network discovery policy. */
    public DiscoveryPolicy getDiscoveryPolicy() {
        return discoveryPolicy;
    }

    /**
     * @return Whether a scheduled startup algorithm must be used during connection and
     * initialization of EM/NE objects.
     */
    public boolean isScheduledStartupEnabled() {
        return enableScheduledStartup;
    }

    /**
     * @return Whether components should show the Native Name.
     */
    public boolean isNativeNeNamingEnabled() {
        return showNativeNeNaming;
    }

    /**
     * @return The Default NE Container IdName.
     */
    public String getDefaultContainerName() {
        return defaultContainerName;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
                .appendSuper(super.hashCode())
                .append(mediatorRetries)
                .append(channelRetries)
                .append(neRetries)
                .append(retryInterval)
                .append(scaledStartupLimit)
                .append(discoveryPolicy)
                .append(enableScheduledStartup)
                .append(showNativeNeNaming)
                .append(defaultContainerName)
                .toHashCode();
    }

    @Override
    public boolean equals(Object theOther) {
        if (this == theOther) {
            return true;
        }
        if (null == theOther || getClass() != theOther.getClass()) {
            return false;
        }
        final GlobalSettings o = (GlobalSettings) theOther;
        return new EqualsBuilder()
                .append(getId(), o.getId())
                .append(getVersion(), o.getVersion())
                .append(mediatorRetries, o.mediatorRetries)
                .append(channelRetries, o.channelRetries)
                .append(neRetries, o.neRetries)
                .append(retryInterval, o.retryInterval)
                .append(scaledStartupLimit, o.scaledStartupLimit)
                .append(discoveryPolicy, o.discoveryPolicy)
                .append(enableScheduledStartup, o.enableScheduledStartup)
                .append(showNativeNeNaming, o.showNativeNeNaming)
                .append(defaultContainerName, o.defaultContainerName)
                .isEquals();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("mediatorRetries",mediatorRetries)
                .append("channelRetries",channelRetries)
                .append("neRetries",neRetries)
                .append("retryInterval",retryInterval)
                .append("scaledStartupLimit",scaledStartupLimit)
                .append("discoveryPolicy",discoveryPolicy)
                .append("enableScheduledStartup",enableScheduledStartup)
                .append("showNativeNeNaming",showNativeNeNaming)
                .append("defaultContainerName", defaultContainerName)
                .toString();
    }

    /**
     * Prototype and builder class to help creating new instances of {@link GlobalSettings}.
     */
    public static class Builder {

        /** Retry interval. */
        private static final int DEFAULT_RETRY_INTERVAL = 1;
        /** Mediator connection retry limit. Zero means infinite. */
        private static final int DEFAULT_MEDIATOR_RETRY = 0;
        /** Channel connection retry limit. Zero means infinite. */
        private static final int DEFAULT_CHANNEL_RETRY = 0;
        /** NE connection retry limit. Zero means infinite. */
        private static final int DEFAULT_NE_RETRY = 0;
        private static final int DEFAULT_SCALED_STARTUP_LIMIT = 21;
        private static final DiscoveryPolicy DEFAULT_DISCOVERY_POLICY = DiscoveryPolicy.DISCOVERY_BY_DOMAIN;
        private static final boolean DEFAULT_SCALED_STARTUP_ENABLE_STATUS = true;
        private static final String DEFAULT_CONTAINER_NAME = "Default Ne Container";

        private int mediatorRetries;
        private int channelRetries;
        private int neRetries;
        private int retryInterval;
        private int scaledStartupLimit;
        private DiscoveryPolicy discoveryPolicy;
        private boolean enableScheduledStartup;
        private boolean showNativeNeNaming;
        private String defaultContainerName;

        protected Builder() {
            retryInterval = DEFAULT_RETRY_INTERVAL;
            mediatorRetries = DEFAULT_MEDIATOR_RETRY;
            channelRetries = DEFAULT_CHANNEL_RETRY;
            neRetries = DEFAULT_NE_RETRY;
            scaledStartupLimit = DEFAULT_SCALED_STARTUP_LIMIT;
            discoveryPolicy = DEFAULT_DISCOVERY_POLICY;
            enableScheduledStartup = DEFAULT_SCALED_STARTUP_ENABLE_STATUS;
            defaultContainerName = DEFAULT_CONTAINER_NAME;
        }

        protected Builder(@Nonnull GlobalSettings other) {
            retryInterval = other.retryInterval;
            mediatorRetries = other.mediatorRetries;
            channelRetries = other.channelRetries;
            neRetries = other.neRetries;
            scaledStartupLimit = other.scaledStartupLimit;
            discoveryPolicy = other.discoveryPolicy;
            enableScheduledStartup = other.enableScheduledStartup;
            showNativeNeNaming = other.showNativeNeNaming;
            defaultContainerName = other.defaultContainerName;
        }

        /**
         * @return A new instance of {@link GlobalSettings} initialized with current attribute values.
         */
        public GlobalSettings toGlobalSettings(int id, int version) {
            return new GlobalSettings(id, version, this);
        }

        /**
         * Sets the Mediator connection retry limit.
         * @param mediatorRetries The new limit. Zero means infinite.
         */
        public Builder setMediatorRetries(int mediatorRetries) {
            this.mediatorRetries = mediatorRetries;
            return this;
        }

        /**
         * Sets the Channel connection retry limit.
         * @param channelRetries The new limit. Zero means infinite.
         */
        public Builder setChannelRetries(int channelRetries) {
            this.channelRetries = channelRetries;
            return this;
        }

        /**
         * Sets the NE connection retry limit.
         * @param neRetries The new limit. Zero means infinite.
         */
        public Builder setNeRetries(int neRetries) {
            this.neRetries = neRetries;
            return this;
        }

        /**
         * Sets the interval between connection retries.
         * @param retryInterval The new interval, in minutes.
         */
        public Builder setRetryInterval(int retryInterval) {
            this.retryInterval = retryInterval;
            return this;
        }

        /**
         * Sets how many objects should be connecting or initializing at any given time.
         * @param scaledStartupLimit The new value.
         */
        public Builder setScaledStartupLimit(int scaledStartupLimit) {
            this.scaledStartupLimit = scaledStartupLimit;
            return this;
        }

        /**
         * Sets the new network discovery policy.
         * @param discoveryPolicy The new value.
         */
        public Builder setDiscoveryPolicy(DiscoveryPolicy discoveryPolicy) {
            this.discoveryPolicy = discoveryPolicy;
            return this;
        }

        /**
         * Defines whether scheduled startup limits should be applied.
         * @param enableScheduledStartup The new value.
         */
        public Builder setEnableScheduledStartup(boolean enableScheduledStartup) {
            this.enableScheduledStartup = enableScheduledStartup;
            return this;
        }

        /**
         * @param showNativeNeNaming Whether components should show the Native Name.
         */
        public Builder setShowNativeNeNaming(boolean showNativeNeNaming) {
            this.showNativeNeNaming = showNativeNeNaming;
            return this;
        }

        /**
         * Defines the Default NE container IdName.
         * @param defaultContainerName The new value
         */
        public Builder setDefaultContainerName(String defaultContainerName) {
            this.defaultContainerName = defaultContainerName;
            return this;
        }
    }
}
