package com.ossnms.dcn_manager.core.events.system;

import com.ossnms.dcn_manager.core.events.EntityEvent;

/**
 * Base class for events that affect a system container.
 */
public abstract class SystemEvent extends EntityEvent {

    /**
     * Creates a new object.
     * @param systemId The affected system container ID.
     */
    public SystemEvent(int systemId) {
        super(systemId);
    }

    /**
     * Creates a new object.
     * @param systemId The affected system container ID.
     * @param detailedDescription Detailed event description for human consumption.
     */
    public SystemEvent(int systemId, String detailedDescription) {
        super(systemId, detailedDescription);
    }

}
