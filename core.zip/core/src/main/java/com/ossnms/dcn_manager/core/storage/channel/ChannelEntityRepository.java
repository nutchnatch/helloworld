package com.ossnms.dcn_manager.core.storage.channel;

import com.mysema.query.collections.CollQuery;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelCreateDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelDeleteDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelEntity;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.QChannelConnectionData;
import com.ossnms.dcn_manager.core.storage.BusinessEntityRepository;
import com.ossnms.dcn_manager.core.storage.BusinessObjectRepository;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.Optional;

/**
 * Contract to be supported by all Channel Entity repositories.
 * <p>
 * {@see DomainEntityRepository}
 */
public interface ChannelEntityRepository extends BusinessEntityRepository<ChannelEntity, ChannelCreateDescriptor, ChannelDeleteDescriptor> {

    /**
     * Contract to be supported by all repositories of Channel Info domain object instances.
     * The main goal here is to increase readability by getting generics out of the way, while preserving
     * compile time type checks.
     */
    interface ChannelInfoRepository extends BusinessObjectRepository<ChannelInfoData, ChannelInfoMutationDescriptor> {

        /**
         * Obtains a collection of Channel identifiers within the context of a given Mediator.
         *
         * @param mediatorId Parent Mediator identifier.
         * @return A collection of children Channel IDs.
         * @throws RepositoryException When an error occurs while working with the
         *                             underlying data storage.
         */
        Collection<Integer> queryChannelIdsUnderMediator(int mediatorId) throws RepositoryException;

        /**
         * Obtains a collection of Channel Information objects for this Channels with a given
         * Activation Required state, within the context of a given Mediator.
         *
         * @param mediatorId         Parent Mediator identifier.
         * @param activationRequired The desired activation required state.
         * @return A collection of {@link ChannelInfoData}.
         * @throws RepositoryException When an error occurs while working with the
         *                             underlying data storage.
         */
        Collection<ChannelInfoData> queryActivationRequiredIs(int mediatorId, boolean activationRequired) throws RepositoryException;

        /**
         * Checks if there are any child Channels for a given Mediator.
         *
         * @param mediatorId Parent Mediator identifier.
         * @return True if the Mediator provided has child Channels.
         * @throws RepositoryException When an error occurs while working with the
         *                             underlying data storage.
         */
        boolean channelsExist(int mediatorId) throws RepositoryException;

    }

    /**
     * Contract to be supported by all repositories of Channel Connection domain object instances.
     * The goal here is to increase readability by getting generics out of the way, while preserving
     * compile time type checks.
     */
    interface ChannelConnectionRepository extends BusinessObjectRepository<ChannelConnectionData, ChannelConnectionMutationDescriptor> {

        /**
         * Provides a query builder object for conducting ad-hoc searches.
         *
         * @param info Query metadata.
         * @return An instance of a query builder object.
         */
        CollQuery query(QChannelConnectionData info);

    }

    /**
     * Contract to be supported by all repositories of Channel User Preferences domain object instances.
     * The goal here is to increase readability by getting generics out of the way, while preserving
     * compile time type checks.
     */
    interface ChannelUserPreferencesRepository extends BusinessObjectRepository<ChannelUserPreferencesData, ChannelUserPreferencesMutationDescriptor> {

        /**
         * Gets the channel with the given name, if one exists
         *
         * @param channelName The channel name.
         * @return An {@link Optional} instance bearing the domain object, or an
         * absent {@link Optional} if no domain object exists with the given
         * name.
         * @throws RepositoryException When an error occurs while working with the
         *                             underlying data storage.
         */
	    Optional<ChannelUserPreferencesData> query(@Nonnull String channelName) throws RepositoryException;

    }

    /**
     * Creates a new channel in the repository.
     *
     * @param createEvent The creation event describing the new channel.
     * @return An instance of the channel just created.
     * @throws RepositoryException When an error occurs while working with the underlying data storage.
     */
    @Override
    ChannelEntity create(ChannelCreateDescriptor createEvent) throws RepositoryException;

    /**
     * Attempts to delete an existing channel from the repository.
     *
     * @param deleteEvent The deletion event describing the request.
     * @throws RepositoryException When an error occurs while working with the underlying data storage.
     */
    @Override
    void delete(ChannelDeleteDescriptor deleteEvent) throws RepositoryException;

    /**
     * Gets the repository for the entity's Channel Info domain object.
     *
     * @return The repository for the entity's Channel Info domain object.
     */
    ChannelInfoRepository getChannelInfoRepository();

    /**
     * Gets the repository for the entity's Channel Connection domain object
     *
     * @return The repository for the entity's Channel Connection domain object.
     */
    ChannelConnectionRepository getChannelConnectionRepository();

    /**
     * Gets the repository for the entity's Channel User Preferences domain object
     *
     * @return The repository for the entity's Channel User Preferences domain object.
     */
    ChannelUserPreferencesRepository getChannelUserPreferencesRepository();

    /**
     * Gets the Channel Entity instance with the given identifier, if one exists
     *
     * @param channelId The Channel Entity identifier.
     * @return An {@link Optional} instance bearing the Channel Entity instance, or an
     * absent {@link Optional} if no Channel Entity exists with the given identifier.
     * @throws RepositoryException When an error occurs while working with the underlying data storage.
     */
    Optional<ChannelEntity> queryChannel(int channelId) throws RepositoryException;

    /**
     * Retrieves all Channel Entity instances present in the repository.
     *
     * @return An instance of an iterable over all known Channel Entity instances.
     * @throws RepositoryException When an error occurs while working with the underlying data storage.
     */
    Iterable<ChannelEntity> queryAll() throws RepositoryException;

    /**
     * Gets the name of the Channel Entity instance with the given identifier, if one exists
     *
     * @param channelId The Channel Entity identifier.
     * @return An {@link Optional} instance bearing the Channel Entity instance name, or an
     * absent {@link Optional} if no Channel Entity exists with the given identifier.
     * @throws RepositoryException When an error occurs while working with the underlying data storage.
     */
    Optional<String> queryChannelName(int channelId) throws RepositoryException;

    /**
     * Obtains a collection of Channel Information objects for Channels with a given
     * Activation Required state under a specific Mediator.
     *
     * @param parentMediatorId   Parent Mediator identifier.
     * @param activationRequired The desired activation required state.
     * @return A collection of {@link ChannelInfoData}.
     * @throws RepositoryException When an error occurs while working with the
     *                             underlying data storage.
     */
    Iterable<ChannelInfoData> queryActivationRequiredIs(int parentMediatorId, boolean activationRequired)
            throws RepositoryException;
}
