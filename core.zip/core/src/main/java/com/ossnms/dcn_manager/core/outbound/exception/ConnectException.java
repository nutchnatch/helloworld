package com.ossnms.dcn_manager.core.outbound.exception;

import org.slf4j.helpers.MessageFormatter;

/**
 * Exceptions for Channels and NE connections.
 */
public class ConnectException extends OutboundException {

    private static final long serialVersionUID = -1068417700004888870L;

    /** 
     * @see Exception#Exception() 
     */
    public ConnectException() {

    }

    /** 
     * @see Exception#Exception(String) 
     */
    public ConnectException(String message) {
        super(message);
    }

    /** 
     * @see Exception#Exception(Throwable) 
     */
    public ConnectException(Throwable cause) {
        super(cause);
    }

    /** 
     * @see Exception#Exception(String,Throwable) 
     */
    public ConnectException(String message, Throwable cause) {
        super(message, cause);
    }

    /** 
     * @see Exception#Exception(String,Throwable,boolean,boolean)
     */
    public ConnectException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
    
    /**
     * Constructs a new exception with a detail message built from the given format
     * string and parameters.
     * @param format A format string.
     * @param formatParameters Parameters referenced by format specifiers in the format string.
     *
     * @see MessageFormatter#arrayFormat(String, Object[])
     * @see CommandException#CommandException(String)
     */
    public ConnectException(String format, Object... formatParameters) {
        super(MessageFormatter.arrayFormat(format, formatParameters).getMessage());
    }
}
