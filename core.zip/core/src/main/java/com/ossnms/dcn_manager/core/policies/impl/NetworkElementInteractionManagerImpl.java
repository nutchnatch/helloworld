package com.ossnms.dcn_manager.core.policies.impl;

import com.google.common.collect.Iterators;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent;
import com.ossnms.dcn_manager.core.events.ne.IdentifiedNeEvent;
import com.ossnms.dcn_manager.core.events.ne.NeSynchronizationEvent;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.outbound.NeConnectionManager;
import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManagerStage;
import com.ossnms.dcn_manager.core.policies.common.PartitionedInteractionManager;
import com.ossnms.dcn_manager.core.policies.common.PolicyJob;
import com.ossnms.dcn_manager.core.policies.impl.jobs.ActivationJob;
import com.ossnms.dcn_manager.core.policies.impl.jobs.DeactivationJob;
import com.ossnms.dcn_manager.core.policies.impl.jobs.LazySynchronizationJob;
import com.ossnms.dcn_manager.core.policies.impl.jobs.SynchronizationJob;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.ThreadSafe;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.Optional;
import java.util.function.Predicate;

import static com.google.common.base.Throwables.getStackTraceAsString;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * The implementation's first stage, which uses a partitioned approach based on the NE's channel identifier.
 */
@ThreadSafe
public class NetworkElementInteractionManagerImpl
        extends PartitionedInteractionManager<PolicyJob<? extends IdentifiedNeEvent>>
        implements NetworkElementInteractionManager {

	private static final Logger LOGGER = getLogger(NetworkElementInteractionManagerImpl.class);

    /** The instance used to interact with mediation. */
    private final NeConnectionManager connectionManager;

    /**
     * Holds the chain of remaining stages that support the implementation. The actual chain configuration is
     * provided upon construction.
     */
    private final NetworkElementInteractionManagerStage[] stagesChain;

	/**
	 * Initiates an instance with the required dependencies.
	 *
     * @param maxSimultaneousInteractions The maximum allowed number of simultaneous interactions.
	 * @param chain The remaining  chain of regulation stages. The order in the chain is relevant for dispatching
	 * purposes. At least one element is required in the chain.
	 * @param connectionManager The instance used to interact with the solution's Connection Manager
     * (i.e. the out-bound abstraction).
     *
     * @throws IndexOutOfBoundsException If the chain is empty.
	 */
    public NetworkElementInteractionManagerImpl(
            int maxSimultaneousInteractions,
    		@Nonnull NetworkElementInteractionManagerStage[] chain,
    		@Nonnull NeConnectionManager connectionManager) {
    	super(maxSimultaneousInteractions, "NE.CHANNEL", chain[0], (i, p) -> Optional.empty());
        this.connectionManager = connectionManager;
        // Using defensive copying to increase overall robustness
        stagesChain = Arrays.copyOf(chain, chain.length);
    }

    /** {@inheritDoc} */
	@Override
	public Iterator<NetworkElementInteractionManagerStage> iterator() {
	    return Iterators.forArray(stagesChain);
	}

	/**
	 * Utility class whose instances are used as predicates to select jobs that may be canceled by the ones
	 * being submitted.
	 */
    private static final class IsJobEventOfTypeAndForNeId implements Predicate<PolicyJob<? extends IdentifiedNeEvent>> {

        private final Class<? extends IdentifiedNeEvent>[] clazzes;
        private final int neId;

        @SafeVarargs
        protected IsJobEventOfTypeAndForNeId(int neId, Class<? extends IdentifiedNeEvent>... eventTypeClazzes) {
            this.clazzes = eventTypeClazzes;
            this.neId = neId;
        }

        private boolean oneTypeMatches(@Nonnull IdentifiedNeEvent input) {
            for (final Class<? extends IdentifiedNeEvent> clazz : clazzes) {
                if (clazz.isInstance(input)) {
                    return true;
                }
            }
            return false;
        }

        @Override
        public boolean test(@Nonnull PolicyJob<? extends IdentifiedNeEvent> input) {
            return neId == input.getOriginatingEvent().getPhysicalNeId() && oneTypeMatches(input.getOriginatingEvent());
        }

    }

    /**
     * Helper method used to eventually cancel jobs retained in the remaining interaction stages.
     * @param cancelationSelector The predicate used to select the job to be cancelled.
     */
	private void tryUnscheduleJobInRemainingStages(@Nonnull Predicate<PolicyJob<? extends IdentifiedNeEvent>> cancelationSelector) {
		// Cancel pending jobs, if any, starting at the last interaction regulation stage
		// In the remaining stages we cannot use the partitioned approach, that is, we cannot merely try to unschedule
		// the job from a given partition because we are not aware of the partitioning strategy being used.
    	for(int stageIndex = stagesChain.length - 1; stageIndex >= 0; --stageIndex) {
            stagesChain[stageIndex].unscheduleNeInteraction(cancelationSelector);
        }
	}

	/**
	 * Helper method that schedules the given job to be executed in the given partition.
	 * @param partitionId Target partition number.
	 * @param job Job to execute.
	 * @param cancellationSelector Predicate used to identify jobs to be cancelled by the current job.
	 */
	private void scheduleJob(int partitionId, @Nonnull PolicyJob<? extends IdentifiedNeEvent> job, @Nonnull Predicate<PolicyJob<? extends IdentifiedNeEvent>> cancellationSelector) {
		LOGGER.debug("Scheduling job {} on partition {}.", job, partitionId);
		// Check if the job cancels any pending jobs in the remaining stages
		tryUnscheduleJobInRemainingStages(cancellationSelector);
        // Add the job to the first regulation stage of the chain (the this instance), passing in the predicate to be used to check if the created job
        // cancels any pending job on the first stage. Notice that it is possible that such a job has already left the first stage. In this case,
    	// it has already been cancelled by the previous step (i.e. tryUnscheduleJobInRemainingStages).
        this.schedulePartitionInteraction(partitionId, job, cancellationSelector);
	}

	/**
	 * Helper method that attempts to remove a job from the execution queues of the given partition.
	 * @param partitionId Target partition number.
	 * @param cancellationSelector Predicate used to identify the job to be cancelled.
	 */
	private void unscheduleJob(int partitionId, @Nonnull Predicate<PolicyJob<? extends IdentifiedNeEvent>> cancellationSelector) {
		// Check if the job cancels any pending jobs in the remaining stages. We cannot use the partition identifier
		// because we are not aware of it.
		tryUnscheduleJobInRemainingStages(cancellationSelector);
		// Cancel job in the first node of the chain (i.e. the this instance).
        this.unschedulePartitionInteraction(partitionId, cancellationSelector);
	}

	/** {@inheritDoc} */
	@Override
	public void scheduleActivation(@Nonnull Activate event) {
    	scheduleJob(
    			event.getPhysicalChannelId(),
    			new ActivationJob(event, connectionManager),
				job -> job.getOriginatingEvent().getPhysicalNeId() == event.getPhysicalNeId()
    	);
	}

	/** {@inheritDoc} */
	@Override
	public void cancelActivations(@Nonnull RequiredNeStateEvent event) {
    	unscheduleJob(event.getPhysicalChannelId(), new IsJobEventOfTypeAndForNeId(event.getPhysicalNeId(), Activate.class));
	}

	/** {@inheritDoc} */
	@Override
	public void scheduleDeactivation(@Nonnull Deactivate event) {
		scheduleJob(
    			event.getPhysicalChannelId(),
    			new DeactivationJob(event, connectionManager),
				job -> job.getOriginatingEvent().getPhysicalNeId() == event.getPhysicalNeId()
    	);
	}

	/** {@inheritDoc} */
	@Override
	public void cancelDeactivations(@Nonnull RequiredNeStateEvent event) {
    	unscheduleJob(event.getPhysicalChannelId(), new IsJobEventOfTypeAndForNeId(event.getPhysicalNeId(), Deactivate.class));
	}

	/** {@inheritDoc} */
	@Override
	public void scheduleSynchronization(@Nonnull NeSynchronizationEvent event) {
    	scheduleJob(
    			event.getPhysicalChannelId(),
    			new SynchronizationJob(event, connectionManager),
    			new IsJobEventOfTypeAndForNeId(event.getPhysicalNeId(), NeSynchronizationEvent.class)
    	);
	}

	/** {@inheritDoc} */
	@Override
	public void cancelSynchronizations(@Nonnull NeSynchronizationEvent event) {
		unscheduleSynchronizations(event);
	}

	/** Cancel and remove from queues all synchronization jobs. */
	private void unscheduleSynchronizations(IdentifiedNeEvent event) {
		unscheduleJob(event.getPhysicalChannelId(),
                new IsJobEventOfTypeAndForNeId(event.getPhysicalNeId(), NeSynchronizationEvent.class));
	}

	@Override
	public void onNeInteractionEnded(@Nonnull final ActualNeStateEvent neStateEvent) {
        onInteractionEnded(
            ongoingJob -> neStateEvent.getOriginatingPhysicalEvent()
                .map(physicalEvent -> ongoingJob.getOriginatingEvent().getPhysicalNeId() == physicalEvent.getNeId())
                .orElse(false));
	}

    @Override
    protected void onInteractionEnded(@Nonnull Predicate<PolicyJob<? extends IdentifiedNeEvent>> jobSelector) {

        // Signal job completion on all regulation stages, starting on the last one in the chain.
    	for (int stageIndex = stagesChain.length - 1; stageIndex >= 0; --stageIndex) {
            stagesChain[stageIndex].onNeInteractionEnded(jobSelector);
        }

    	// Signal job completion in the first node
    	super.onInteractionEnded(jobSelector);
    }

	/**
	 * {@inheritDoc}
	 *
	 * <p>Synchronization is triggered upon reception of a NE Connected event as a separate job
	 * instead of a continuation of an ActivationJob.
	 * This prevents spurious connection errors from keeping NEs in Connected state forever as a
	 * result of the running ActivationJobs being cancelled when the error event arrives.</p>
	 */
	@Override
	public void onNeConnected(@Nonnull NeSynchronizationEvent event) {

	    // Complete any running activation
	    onInteractionEnded(new IsJobEventOfTypeAndForNeId(event.getPhysicalNeId(), Activate.class));

	    // Start an initialization
        scheduleJob(
                event.getPhysicalChannelId(),
                new LazySynchronizationJob(event, connectionManager),
                new IsJobEventOfTypeAndForNeId(event.getPhysicalNeId(), NeSynchronizationEvent.class)
        );

	}

    /**
     * {@inheritDoc}
     *
     * <p>This implementation executes inline, however nothing prevents us from following an async strategy.</p>
     */
	@Override
	public void onNePropertiesUpdated(
			@Nonnull NeEntity ne,
			@Nonnull NePhysicalConnectionData neInstance,
			@Nonnull NeUserPreferencesMutationDescriptor newPreferences) {
        try {
            connectionManager.updateNeProperties(ne, neInstance, newPreferences, Collections.emptyMap());
        } catch (ConnectException e) {
            getLogger(NetworkElementInteractionManagerImpl.class)
                .warn("Failed to send updated properties for NE instance {}: {}",
                        neInstance, getStackTraceAsString(e));
        }
    }

}
