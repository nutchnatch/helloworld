package com.ossnms.dcn_manager.core.entities.mediator.data;

import com.google.common.base.Objects;
import com.google.common.base.Strings;
import com.ossnms.dcn_manager.core.entities.DynamicBusinessObjectMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInfoData.MediatorInfoBuilder;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * <p>Describes all changes requested to an instance of {@link MutationInfoData}.</p>
 * <p>Like all mutation descriptors, this class is not thread safe.</p>
 */
public class MediatorInfoMutationDescriptor
        extends DynamicBusinessObjectMutationDescriptor<MediatorInfoData, MediatorInfoMutationDescriptor>
        implements MediatorPropertySetters<MediatorInfoMutationDescriptor> {

    private Optional<String> name = Optional.empty();
    private Optional<String> description = Optional.empty();
    private Optional<Boolean> activationRequired = Optional.empty();
    private Optional<String> userText = Optional.empty();

    private Optional<Boolean> concurrentActivationsLimited = Optional.empty();
    private Optional<Integer> concurrentActivationsLimit = Optional.empty();
    private Optional<Integer> reconnectAttemptInterval = Optional.empty();

    /**
     * Creates a new mutation descriptor object.
     * @param target Target instance for the mutation.
     */
    public MediatorInfoMutationDescriptor(@Nonnull MediatorInfoData target) {
        super(target);
    }

    @Override
    protected MediatorInfoMutationDescriptor self() {
        return this;
    }

    @Override
    protected MediatorInfoData doApply() {
        return isIdentificationChanged() || isActivationLimitChanged() ||
                reconnectAttemptInterval.isPresent() || !getProperties().isEmpty()
                ? new MediatorInfoBuilder()
                    .setName(name.orElse(getTarget().getName()))
                    .setTypeName(getTarget().getTypeName())
                    .setDescription(description.map(Optional::of).orElse(getTarget().getDescription()))
                    .setUserText(userText.map(Optional::of).orElse(getTarget().getUserText()))
                    .setActivationRequired(activationRequired.orElse(getTarget().isActivationRequired()))
                    .setConcurrentActivationsLimited(concurrentActivationsLimited.orElse(getTarget().isConcurrentActivationsLimited()))
                    .setConcurrentActivationsLimit(concurrentActivationsLimit.orElse(getTarget().getConcurrentActivationsLimit()))
                    .setReconnectAttemptInterval(reconnectAttemptInterval.orElse(getTarget().getReconnectAttemptInterval()))
                    .setProperties(getTarget().getAllOpaqueProperties())
                    .setProperties(getProperties())
                    .build(getTarget().getId(), getTarget().getVersion() + 1)
                : getTarget();
    }

    private boolean isIdentificationChanged() {
        return name.isPresent() || description.isPresent() || userText.isPresent() || activationRequired.isPresent();
    }

    private boolean isActivationLimitChanged() {
        return concurrentActivationsLimited.isPresent() || concurrentActivationsLimit.isPresent();
    }

    /**
     * @return New mediator name.
     */
    public Optional<String> getName() {
        return name;
    }

    /**
     * @param name New mediator name.
     * @throws InvalidMutationException If the new mediator name is empty.
     */
    @Override
    public MediatorInfoMutationDescriptor setName(@Nonnull String name) throws InvalidMutationException {
        if (Strings.isNullOrEmpty(name)) {
            throw new InvalidMutationException("Mediator name must not be empty.");
        }
        final Optional<String> newValue = Optional.of(name);
        if (!Objects.equal(this.name, newValue)) {
            this.name = newValue;
        }
        return this;
    }

    /**
     * @return New description.
     */
    public Optional<String> getDescription() {
        return description;
    }


    public Optional<String> getUserText() {
        return userText;
    }

    @Override
    public MediatorInfoMutationDescriptor setUserText(Optional<String> userText) {
        final Optional<String> newValue = userText;
        if (!Objects.equal(this.userText, newValue)) {
            this.userText = newValue;
        }
        return this;
    }

    /**
     * @param description New description.
     */
    @Override
    public MediatorInfoMutationDescriptor setDescription(@Nonnull Optional<String> description) {
        final Optional<String> newValue = description;
        if (!Objects.equal(this.description, newValue)) {
            this.description = newValue;
        }
        return this;
    }

    /**
     * @return Whether activation will be required for this mediator.
     */
    public Optional<Boolean> getActivationRequired() {
        return activationRequired;
    }

    /**
     * @param activationRequired Whether activation will be required for this mediator.
     */
    @Override
    public MediatorInfoMutationDescriptor setActivationRequired(boolean activationRequired) {
        final Optional<Boolean> newValue = Optional.of(activationRequired);
        if (!Objects.equal(this.activationRequired, newValue)) {
            this.activationRequired = newValue;
        }
        return this;
    }

    /**
     * @return Whether the number of concurrent activations should now be limited.
     */
    public Optional<Boolean> getConcurrentActivationsLimited() {
        return concurrentActivationsLimited;
    }

    /**
     * @param concurrentActivationsLimited Whether the number of concurrent activations should now be limited.
     */
    @Override
    public MediatorInfoMutationDescriptor setConcurrentActivationsLimited(boolean concurrentActivationsLimited) {
        final Optional<Boolean> newValue = Optional.of(concurrentActivationsLimited);
        if (!Objects.equal(this.concurrentActivationsLimited, newValue)) {
            this.concurrentActivationsLimited = newValue;
        }
        return this;
    }

    /**
     * @return The new maximum number of concurrent activations that can be in progress
     *  at any time. Enforced only if {@code concurrentActivationsLimited} is true.
     */
    public Optional<Integer> getConcurrentActivationsLimit() {
        return concurrentActivationsLimit;
    }

    /**
     * @param concurrentActivationsLimit The new maximum number of concurrent activations that can be in progress
     *  at any time. Enforced only if {@code concurrentActivationsLimited} is true.
     */
    @Override
    public MediatorInfoMutationDescriptor setConcurrentActivationsLimit(int concurrentActivationsLimit) {
        final Optional<Integer> newValue = Optional.of(concurrentActivationsLimit);
        if (!Objects.equal(this.concurrentActivationsLimit, newValue)) {
            this.concurrentActivationsLimit = newValue;
        }
        return this;
    }

    /**
     * @return New amount of time to wait between automatic reconnection attempts,
     *  in minutes.
     */
    public Optional<Integer> getReconnectAttemptInterval() {
        return reconnectAttemptInterval;
    }

    /**
     * @param reconnectAttemptInterval New amount of time to wait between automatic reconnection attempts,
     *  in minutes.
     */
    @Override
    public MediatorInfoMutationDescriptor setReconnectAttemptInterval(int reconnectAttemptInterval) {
        final Optional<Integer> newValue = Optional.of(reconnectAttemptInterval);
        if (!Objects.equal(this.reconnectAttemptInterval, newValue)) {
            this.reconnectAttemptInterval = newValue;
        }
        return this;
    }

}
