package com.ossnms.dcn_manager.core.entities.domain;

import com.google.common.base.Objects;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;

import javax.annotation.Nonnull;

import java.util.Optional;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Strings.isNullOrEmpty;

public class DomainInfoMutationDescriptor extends MutationDescriptor<DomainInfoData, DomainInfoMutationDescriptor> {

    private Optional<String> name = Optional.empty();
    private Optional<Boolean> automaticNeActivationPermitted = Optional.empty();

    public DomainInfoMutationDescriptor(DomainInfoData target) {
        super(target);
    }

    @Override
    protected DomainInfoMutationDescriptor self() {
        return this;
    }

    @Override
    protected DomainInfoData doApply() {
        return name.isPresent() || automaticNeActivationPermitted.isPresent()
                ? new DomainInfoData(getTarget().getId(), getTarget().getVersion() + 1,
                name.orElse(getTarget().getName()),
                getAutomaticNeActivationPermitted().orElse(getTarget().isAutomaticNeActivationPermitted()))
                : getTarget();
    }

    /**
     * @return The new domain name.
     */
    public Optional<String> getName() {
        return name;
    }

    /**
     * @param name The new domain name.
     * @throws IllegalArgumentException If the new name is null or empty.
     */
    public DomainInfoMutationDescriptor setName(@Nonnull String name) {
        checkArgument(!isNullOrEmpty(name), "Domain names must not be empty.");
        final Optional<String> newValue = Optional.of(name);
        if (!Objects.equal(this.name, newValue)) {
            this.name = newValue;
        }
        return self();
    }

    /**
     * @return Whether automatic activation of freshly discovered NEs is permitted
     *  within this domain.
     */
    public Optional<Boolean> getAutomaticNeActivationPermitted() {
        return automaticNeActivationPermitted;
    }

    /**
     * @param automaticNeActivationPermitted Whether automatic activation of freshly
     *  discovered NEs is permitted within this domain.
     */
    public DomainInfoMutationDescriptor setAutomaticNeActivationPermitted(boolean automaticNeActivationPermitted) {
        final Optional<Boolean> newValue = Optional.of(automaticNeActivationPermitted);
        if (!Objects.equal(this.automaticNeActivationPermitted, newValue)) {
            this.automaticNeActivationPermitted = newValue;
        }
        return this;
    }

}
