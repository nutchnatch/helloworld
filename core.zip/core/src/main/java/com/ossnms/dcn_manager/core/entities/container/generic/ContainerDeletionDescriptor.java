package com.ossnms.dcn_manager.core.entities.container.generic;

import com.ossnms.dcn_manager.core.entities.container.ContainerDeletionDescriptorBase;

/**
 * Contains all information required to delete an existing DCN Container.
 */
public final class ContainerDeletionDescriptor extends ContainerDeletionDescriptorBase {

    /**
     * Creates a new object.
     * @param containerId DCN Container identifier.
     * @throws IllegalArgumentException If the identifier is invalid.
     */
    public ContainerDeletionDescriptor(int containerId) {
        super(containerId);
    }

}
