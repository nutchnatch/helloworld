package com.ossnms.dcn_manager.core.properties.mediator;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.core.properties.EntityProperty;

class MediatorPropertyOperations extends EntityProperty {

    public MediatorPropertyOperations(@Nonnull String name) {
        super(name);
    }

}
