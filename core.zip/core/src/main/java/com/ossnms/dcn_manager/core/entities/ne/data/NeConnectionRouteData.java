package com.ossnms.dcn_manager.core.entities.ne.data;

import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.entities.DynamicBusinessObjectData;
import com.ossnms.dcn_manager.core.entities.DynamicBusinessObjectPrototype;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Optional;
import java.util.function.Function;

import static com.google.common.base.Strings.nullToEmpty;

/**
 * <p>
 * Base class that describes all connection routes towards an NE.
 * An NE can have two kinds of connection routes: direct and indirect
 * (through a gateway NE). However both routes <b>are</b> connection
 * routes although with different semantics and cardinality.
 * </p>
 * <p><img src="doc-files/NeConnectionRouteData-class.png" /></p>
 */
/*
@startuml doc-files/NeConnectionRouteData-class.png

class NeDirectRouteData
class NeGatewayRouteData
class NeConnectionRouteData

NeConnectionRouteData <|-- NeDirectRouteData
NeConnectionRouteData <|-- NeGatewayRouteData

@enduml
*/
public class NeConnectionRouteData extends DynamicBusinessObjectData {

    private final int priority;
    private final int cost;
    private final boolean used;
    private final String key;
    private final String gneName;
    private final Optional<String> domain;

    protected NeConnectionRouteData(int neId, int version, @Nonnull NeConnectionRoutePrototype<?, ?> prototype) {
        super(neId, version, ImmutableMap.copyOf(prototype.getPropertyBag()));
        priority = prototype.priority;
        cost = prototype.cost;
        used = prototype.used;
        key = prototype.key;
        domain = prototype.domain;
        gneName = prototype.gneName;
    }

    /**
     * @return The name of the GNE that provides the current route.
     */
    public String getGneName() {
        return nullToEmpty(gneName);
    }

    /**
     * @return The route priority. Used for sorting routes.
     */
    public int getPriority() {
        return priority;
    }

    /**
     * @return Route cost. Used for sorting routes.
     */
    public int getCost() {
        return cost;
    }

    /**
     * @return System wide unique route key.
     */
    public String getKey() {
        return key;
    }

    /**
     * @return Whether the route is in use, i.e., it is the active route.
     */
    public boolean isUsed() {
        return used;
    }

    /**
     * @return The domain name associated with the route, if any.
     */
    public Optional<String> getDomain() {
        return domain;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || o.getClass() != getClass()) {
            return false;
        }
        if (o == this) {
            return true;
        }
        final NeConnectionRouteData rhs = (NeConnectionRouteData) o;
        return new EqualsBuilder()
            .append(priority, rhs.priority)
            .append(cost, rhs.cost)
            .append(used, rhs.used)
            .append(key, rhs.key)
            .append(gneName, rhs.gneName)
            .append(getPropertyBag(), rhs.getPropertyBag())
            .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(priority)
            .append(cost)
            .append(used)
            .append(key)
            .append(gneName)
            .append(getPropertyBag())
            .toHashCode();
    }

     // TODO: Once the decision referred in the class documentation is made, this is the implementation
     // of {@link #toString()} if this is, in fact, a domain object.
    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("priority", priority)
                .append("cost", cost)
                .append("used", used)
                .append("key", key)
                .append("domain", domain)
                .append("gneName", gneName)
                .toString();
    }

    /** Obtains the domain name from a connection route object. For usage with transformation streams. */
    public static final Function<NeConnectionRouteData, Optional<String>> GET_DOMAIN_NAME =
            input -> null != input ? input.getDomain() : null;

    /** Obtains the route key from a connection route object. For usage with transformation streams. */
    public static final Function<NeConnectionRouteData, String> GET_ROUTE_KEY =
            input -> null != input ? input.getKey() : null;

    abstract static class NeConnectionRouteBuilder<E, T extends NeConnectionRouteBuilder<E, T>>
        extends NeConnectionRoutePrototype<E, T> {

    }

    public abstract static class NeConnectionRoutePrototype<E, T extends NeConnectionRoutePrototype<E, T>>
            extends DynamicBusinessObjectPrototype<T>
            implements NeConnectionRouteSetters<T> {

        private int priority;
        private int cost;
        private boolean used;
        private String key = "";
        private Optional<String> domain = Optional.empty();
        private String gneName = "";

        protected NeConnectionRoutePrototype() {

        }

        protected NeConnectionRoutePrototype(@Nonnull NeConnectionRoutePrototype<?, ?> other) {
            super(other);
            priority = other.priority;
            cost = other.cost;
            used = other.used;
            key = other.key;
            domain = other.domain;
            gneName = other.gneName;
        }

        @Override
        protected abstract T self();

        protected boolean isKeyPresent() {
            return !Strings.isNullOrEmpty(key);
        }

        protected String getKey() {
            return key;
        }

        /**
         * @param priority New route priority.
         */
        @Override
        public T setPriority(int priority) {
            this.priority = priority;
            return self();
        }

        /**
         * @param cost New route cost.
         */
        @Override
        public T setCost(int cost) {
            this.cost = cost;
            return self();
        }

        /**
         * @param used New route usage information.
         */
        @Override
        public T setUsed(boolean used) {
            this.used = used;
            return self();
        }

        /**
         * @param key New route key.
         */
        @Override
        public T setKey(@Nullable String key) {
            this.key = key;
            return self();
        }

        /**
         * @param domain New route domain name.
         */
        @Override
        public T setDomain(@Nonnull Optional<String> domain) {
            this.domain = domain;
            return self();
        }

        /**
         * @param gneName New provider GNE name.
         */
        @Override public T setGneName(String gneName) {
            this.gneName = gneName;
            return self();
        }

        /** Obtains the route key from a connection route builder object. For usage with transformation streams. */
        public static final Function<NeConnectionRoutePrototype<?, ?>, String> GET_ROUTE_KEY =
                input -> null != input ? input.key : null;

        /** Obtains the domain name from a connection route builder object. For usage with transformation streams. */
        public static final Function<NeConnectionRoutePrototype<?, ?>, Optional<String>> GET_DOMAIN =
                input -> null != input ? input.domain : Optional.empty();

    }
}
