package com.ossnms.dcn_manager.core.properties.ne;

import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Nonnull;

import com.google.common.base.Function;

/**
 * Transforms a property key/value pair into a
 * {@link PropertyInfo} instance containing information
 * about the property name, value and index.
 */
final class ParsePropertyInfo implements
        Function<Map.Entry<String, String>, PropertyInfo> {

    @Override
    public PropertyInfo apply(@Nonnull Entry<String, String> entry) {
        return new PropertyInfo(entry.getKey(), entry.getValue());
    }
}