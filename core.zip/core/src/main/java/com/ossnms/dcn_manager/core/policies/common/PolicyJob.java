package com.ossnms.dcn_manager.core.policies.common;

/**
 * Created by vveloso on 22-02-2016.
 */
public interface PolicyJob<RB> extends Runnable, Cancellable, Comparable<PolicyJob<?>> {
    /**
     * @return The event instance that corresponds to the current job.
     */
    RB getOriginatingEvent();

    /**
     * @return The current job priority.
     */
    Priority getPriority();

    public enum Priority {
        HIGH,
        MEDIUM,
        LOW
    }
}
