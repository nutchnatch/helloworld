/**
 * Contains exclusively classes that describe and implement the domain entity behavior.
 */
package com.ossnms.dcn_manager.core.entities.mediator.behavior;