package com.ossnms.dcn_manager.core.entities.channel.data;

import com.google.common.base.MoreObjects;
import com.google.common.base.MoreObjects.ToStringHelper;
import com.google.common.base.Objects;
import com.google.common.base.Strings;
import com.ossnms.dcn_manager.core.entities.DynamicBusinessObjectMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelUserPreferencesData.ChannelUserPreferencesBuilder;

import javax.annotation.Nonnull;

import java.util.Optional;

import static com.google.common.base.Preconditions.checkArgument;

/**
 * Describes a mutation request that should be applied to the user preferences
 * of a channel. Will contain only the new data to store.
 */
public class ChannelUserPreferencesMutationDescriptor
        extends DynamicBusinessObjectMutationDescriptor<ChannelUserPreferencesData, ChannelUserPreferencesMutationDescriptor>
        implements ChannelPropertySetters<ChannelUserPreferencesMutationDescriptor> {

	/** The channel's human friendly name */
    private Optional<String> name;

    /** The channel's reconnect interval, expressed in minutes */
    private Optional<Integer> reconnectInterval;

    /** Do we limit the number of concurrent interactions against this channel? */
    private Optional<Boolean> concurrentActivationsLimited = Optional.empty();

    /** How many concurrent interactions are allowed against this channel? */
    private Optional<Integer> concurrentActivationsLimit = Optional.empty();

    private Optional<String> userText = Optional.empty();

    /**
	 * Initiates an instance that will be used to mutate the given domain object instance
	 * @param target the domain object instance to which the mutation will be applied
     */
    public ChannelUserPreferencesMutationDescriptor(ChannelUserPreferencesData target) {
    	super(target);
        name = Optional.empty();
        reconnectInterval = Optional.empty();
    }

    /** {@inheritDoc} */
    @Override
    protected ChannelUserPreferencesMutationDescriptor self() {
        return this;
    }

    /** {@inheritDoc} */
    @Override
    protected ChannelUserPreferencesData doApply() {

    	final ChannelUserPreferencesData target = getTarget();

		return preferencesChanged() && getProperties().isEmpty() && !isActivationLimitChanged()
	        ? target
            : new ChannelUserPreferencesBuilder()
		        .setReconnectInterval(reconnectInterval.orElse(target.getReconnectInterval()))
		        .setName(name.orElse(target.getName()))
                .setConcurrentActivationsLimited(concurrentActivationsLimited.orElse(getTarget().isConcurrentActivationsLimited()))
                .setConcurrentActivationsLimit(concurrentActivationsLimit.orElse(getTarget().getConcurrentActivationsLimit()))
                .setProperties(target.getAllOpaqueProperties())
		        .setProperties(getProperties())
                .setUserText(userText.map(Optional::of).orElse(target.getUserText()))
		        .build(target.getId(), target.getVersion() + 1);
    }

    private boolean preferencesChanged() {
        return !name.isPresent() && !reconnectInterval.isPresent() && !userText.isPresent();
    }

    private boolean isActivationLimitChanged() {
        return concurrentActivationsLimit.isPresent() || concurrentActivationsLimited.isPresent();
    }

    /**
     * Sets the mutation's new name, to be assigned to the target channel.
     * @param newName The new name.
     * @throws IllegalArgumentException If the channel name is empty or null.
     */
    @Override
    public ChannelUserPreferencesMutationDescriptor setName(@Nonnull String newName) {
        checkArgument(!Strings.isNullOrEmpty(newName), "The channel name must not be empty.");
        final Optional<String> newValue = Optional.of(newName);
        if (!Objects.equal(name, newValue)) {
            name = newValue;
        }
        return this;
    }

    @Override
    public ChannelUserPreferencesMutationDescriptor setUserText(Optional<String> userText) {
        this.userText = userText;
        return this;
    }

    /** @return an {@link Optional<Boolean>} instance with the mutation's new channel name. */
    public Optional<String> getName() {
        return name;
    }

    /** @return an {@link Optional<Boolean>} instance with the mutation's new reconnect interval, expressed in minutes */
    public Optional<Integer> getReconnectInterval() {
        return reconnectInterval;
    }


    public Optional<String> getUserText() {
        return userText;
    }

    /**
     * Sets the mutation's new reconnect interval (expressed in minutes), to be assigned to the target channel.
     * @param reconnectInterval The new reconnect interval.
     */
    @Override
    public ChannelUserPreferencesMutationDescriptor setReconnectInterval(int reconnectInterval) {
        final Optional<Integer> newValue = Optional.of(reconnectInterval);
        if (!Objects.equal(this.reconnectInterval, newValue)) {
            this.reconnectInterval = newValue;
        }
        return this;
    }

    /**
     * @return Whether the number of concurrent activations should now be limited.
     */
    public Optional<Boolean> getConcurrentActivationsLimited() {
        return concurrentActivationsLimited;
    }

    /**
     * @param concurrentActivationsLimited Whether the number of concurrent activations should now be limited.
     */
    @Override
    public ChannelUserPreferencesMutationDescriptor setConcurrentActivationsLimited(boolean concurrentActivationsLimited) {
        final Optional<Boolean> newValue = Optional.of(concurrentActivationsLimited);
        if (!Objects.equal(this.concurrentActivationsLimited, newValue)) {
            this.concurrentActivationsLimited = newValue;
        }
        return this;
    }

    /**
     * @return The new maximum number of concurrent activations that can be in progress
     *  at any time. Enforced only if {@code concurrentActivationsLimited} is true.
     */
    public Optional<Integer> getConcurrentActivationsLimit() {
        return concurrentActivationsLimit;
    }

    /**
     * @param concurrentActivationsLimit The new maximum number of concurrent activations that can be in progress
     *  at any time. Enforced only if {@code concurrentActivationsLimited} is true.
     */
    @Override
    public ChannelUserPreferencesMutationDescriptor setConcurrentActivationsLimit(int concurrentActivationsLimit) {
        final Optional<Integer> newValue = Optional.of(concurrentActivationsLimit);
        if (!Objects.equal(this.concurrentActivationsLimit, newValue)) {
            this.concurrentActivationsLimit = newValue;
        }
        return this;
    }


    /** {@inheritDoc} */
    @Override
    public String toString() {
        final ToStringHelper helper = MoreObjects.toStringHelper(this);
        helper.addValue(super.toString());
        if (name.isPresent()) {
            helper.add("new name", name.get());
        }
        if (reconnectInterval.isPresent()) {
            helper.add("new reconnectInterval", reconnectInterval.get());
        }
        if (concurrentActivationsLimited.isPresent()) {
            helper.add("new concurrentActivationsLimited", concurrentActivationsLimited.get());
        }
        if (concurrentActivationsLimit.isPresent()) {
            helper.add("new concurrentActivationsLimit", concurrentActivationsLimit.get());
        }
        return helper.toString();
    }
}
