package com.ossnms.dcn_manager.core.entities.channel.data;

import com.google.common.base.MoreObjects;
import com.google.common.base.MoreObjects.ToStringHelper;
import com.google.common.base.Objects;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelInfoData.ChannelInfoBuilder;

import java.util.Optional;

/**
 * Describes a mutation request that should be applied to the required state
 * of a given channel. Will contain only the new data to store.
 */
public class ChannelInfoMutationDescriptor extends MutationDescriptor<ChannelInfoData, ChannelInfoMutationDescriptor> {

	/** The channel's new activation state, if present */
    private Optional<Boolean> active;

    /**
     * Channel´s new mediator id, if preent.
     */
    private Optional<Integer> mediatorId = Optional.empty();

	/**
	 * Initiates an instance that will be used to mutate the given domain object instance
	 * @param target the domain object instance to which the mutation will be applied
	 */
    public ChannelInfoMutationDescriptor(ChannelInfoData target) {
    	super(target);
    	active = Optional.empty();
    }

    /** {@inheritDoc} */
    @Override
    protected ChannelInfoMutationDescriptor self() {
    	return this;
    }

    /** {@inheritDoc} */
    @Override
    protected ChannelInfoData doApply() {
    	final ChannelInfoData target = getTarget();
    	return active.isPresent() || mediatorId.isPresent()
    	        ? new ChannelInfoBuilder()
                    .setType(target.getType())
                    .setCoreId(target.getCoreId())
                    .setActivationRequired(active.orElse(target.isActivationRequired()))
                    .build(target.getId(), target.getVersion() + 1, mediatorId.orElse(target.getMediatorId()))

                : target;
    }

    /** @return an {@link Optional<Boolean>} instance with the mutation's required activation state */
    public Optional<Boolean> getActive() {
        return active;
    }

    /** @return an {@link Optional<Integer>} instance with the mutation´s required mediator id */
    public Optional<Integer> getMediatorId() {
        return mediatorId;
    }

    /**
     * Sets the mutation's required activation state.
     * @param active a boolean value indicating whether the mutation specifies that an activation is required
     * (i.e. {@code true}), or that a deactivation is required (i.e. {@code false})
     * @return the mutation instance, to enable fluent use
     */
    public ChannelInfoMutationDescriptor setActive(boolean active) {
        final Optional<Boolean> newValue = Optional.of(active);
        if (!Objects.equal(this.active, newValue)) {
            this.active = newValue;
        }
        return this;
    }

    /**
     * Set and return channel´s mediator id.
     * @param mediatorId mediator id
     */
    public ChannelInfoMutationDescriptor setMediatorId(int mediatorId){
        final Optional<Integer> newValue = Optional.of(mediatorId);
        if(!Objects.equal(this.mediatorId, newValue)){
            this.mediatorId = newValue;
        }
        return this;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        final ToStringHelper helper = MoreObjects.toStringHelper(this);
        helper.addValue(super.toString());
        if (active.isPresent()) {
            helper.add("active", active.get());
        }
        return helper.toString();
    }
}
