package com.ossnms.dcn_manager.core.events.ne;

import javax.annotation.Nonnull;

public class NeInfoDataChangedEvent extends NeEvent{

    private String iconId;

    /**
     * Creates new Event
     * @param neId The affected NE identifier
     * @param newIconId The new identification of NE Icon
     */
    public NeInfoDataChangedEvent(int neId, @Nonnull String newIconId){
        super(neId);
        this.iconId = newIconId;
    }

    /**
     * @return The the new IconId
     */
    public String getIconId() {
        return iconId;
    }
}
