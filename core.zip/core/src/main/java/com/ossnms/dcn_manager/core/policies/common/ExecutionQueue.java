package com.ossnms.dcn_manager.core.policies.common;

import com.ossnms.dcn_manager.core.policies.common.BoundedExecutor.Signaller;
import org.slf4j.Logger;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.concurrent.Executor;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

import static org.slf4j.LoggerFactory.getLogger;

/**
 * <p>Lock-free implementation of a bounded execution queue, that ensures that a given
 * maximum number of simultaneous work items is not exceeded. Once the maximum capacity is
 * exceeded, submitted work items are retained until execution becomes possible. </p>
 *
 * <p>The implementation is composed of a retention queue (a {@link PrunableQueue}
 * instance) and a bounded executor, that is, an executor that rejects work once the specified
 * threshold is exceeded (a {@link BoundedExecutor} instance). Work items are retained
 * (in the retention queue) until the conditions required for their execution are met. Once
 * those conditions are met, i.e. the number of ongoing work items is lower than the specified
 * threshold, one of the retained items is scheduled for execution by being forwarded to the
 * bounded executor, which maintains a conservative estimate of ongoing work.</p>
 *
 * <p>While on the retention queue, work items can be cancelled by subsequently submitted work.
 * To support this functionality, work submission includes the appropriate cancellation selector,
 * an instance of {@link Predicate<T>}. Cancellation of ongoing work, on the other hand,  is not
 * supported.</p>
 *
 * <p>FIFO order execution of work items is not ensured, that is, work is not necessarily
 * performed in the same order that it was submitted.</p>
 *
 * @param <T> The concrete type of work items (i.e. {@link Job} realizations) that will be executed.
 */
public final class ExecutionQueue<T extends PolicyJob<?>> {

    private final Logger logger;

    /** The bounded executor. */
    private final BoundedExecutor<T> workExecutor;
    /** The queue used to retain work items while their execution is not allowed. */
    private final PrunableQueue<T> workRetainer;
    private final Function<Predicate<T>, Optional<T>> upstreamWorkSupplier;

    /**
     * Initiates an instance with the given thread execution policy and maximum number of
     * ongoing simultaneous work items allowed.
     * @param maxSimultaneousInteractions The maximum number of allowed simultaneous work items.
     * @param executionPolicy The executor instance to be used to schedule work item execution.
     * @param upstreamWorkSupplier Supplier of work items that will provide work when this queue has
     *                             capacity but is empty.
     */
    public ExecutionQueue(int maxSimultaneousInteractions, @Nonnull String classifier,
                          @Nonnull Executor executionPolicy,
                          @Nonnull Function<Predicate<T>, Optional<T>> upstreamWorkSupplier) {
        this.logger = getLogger(getClass().getName() + "." + classifier);
        this.upstreamWorkSupplier = upstreamWorkSupplier;
        this.workRetainer = new PrunableQueue<>();
        this.workExecutor = new BoundedExecutor<>(classifier, executionPolicy, maxSimultaneousInteractions);
    }

    /**
     * <p>Obtain and mark as ongoing one pending work item, if the queue has spare capacity, i.e., the
     * number of ongoing jobs has not reached the configured maximum and if there is any pending work item
     * that satisfies a predicate. The work item returned will be executed under the responsibility of
     * the caller.</p>
     *
     * <p>This is used to implement a work "pull" model, which will complement the work "push" model
     * that remains the fundamental operating mode of these queues.</p>
     *
     * @param selector A predicate used to narrow the scope of work items eligible.
     * @return A work item for execution, if any is available.
     */
    public Optional<T> getRetainedWorkForExecution(@Nonnull Predicate<T> selector) {
        if (workExecutor.reserveWorkCapacity()) {
            Optional<T> workItem = workRetainer.tryDequeue(selector);
            if (!workItem.isPresent()) {
                workItem = upstreamWorkSupplier.apply(selector);
            }
            if (workItem.isPresent()) {
                workExecutor.setItemAsOngoing(workItem.get());
                return workItem;
            } else {
                workExecutor.releaseWorkCapacity();
            }
        }
        return Optional.empty();
    }

    /**
     * <p>Obtain and mark as ongoing one pending work item, if the queue has spare capacity, i.e., the
     * number of ongoing jobs has not reached the configured maximum. The work item returned will be
     * executed under the responsibility of the caller.</p>
     *
     * <p>This is used to implement a work "pull" model, which will complement the work "push" model
     * that remains the fundamental operating mode of these queues.</p>
     *
     * @return A work item for execution, if any is available.
     */
    public Optional<T> getRetainedWorkForExecution() {
        return getRetainedWorkForExecution(item -> true);
    }

    /**
     * Method that tries to submit for execution as many retained work items as possible.
     * @return True if all retained work items were submitted.
     */
    private boolean trySubmitRetainedWorkItems() {
        Optional<T> nextWorkItem;
        while((nextWorkItem = workRetainer.tryDequeue()).isPresent()) {
            // A work item is available. Lets try to execute it.
            if(!workExecutor.trySubmitWorkItem(nextWorkItem.get())) {
                // Execution submission failed. Return the work item to the retention queue.
                workRetainer.enqueue(nextWorkItem.get());
                return false;
            }
        }
        return true;
    }

    /**
     * Tells the queue that the execution policy may have capacity available for executing new
     * jobs. This is a best-effort notification; concurrency may cause the capacity to be exhausted
     * by the time new submissions are attempted by this queue.
     *
     * The queue will try to submit any retained work items. The bounded executor associated with
     * it may, however, be saturated. In this case no new jobs will be submitted to the execution
     * policy regardless of its capacity.
     *
     * @return True if all retained work items were submitted. It does not mean that any jobs started
     * execution, rather it means that no work item was rejected for any reason.
     */
    public boolean signalCapacityIsAvailable() {
        return trySubmitRetainedWorkItems();
    }

    /**
     * Schedules the given work item for execution, if possible. Any retained work item which is
     * cancelled by the received one shall be removed from the pending queue.
     * @param workItem The work item to be scheduled for execution.
     * @param workItemCancelationSelector The predicate used to select a potential cancelled work item.
     */
    public void scheduleWorkItem(@Nonnull T workItem, @Nonnull Predicate<T> workItemCancelationSelector) {

        logger.debug("Pruning & scheduling job {}", workItem);

        // If a pending work item is canceled by the received one, cancel it. Otherwise, schedule it
        final Optional<T> cancelledWorkItem = workRetainer.prune(workItemCancelationSelector);

        if(!cancelledWorkItem.isPresent()) {
            // Schedule work execution
            if(!workExecutor.trySubmitWorkItem(workItem)) {
                // Execution submission failed. Add the work item to the retention queue.
                workRetainer.enqueue(workItem);
                // If a race occurred (i.e. interleaving of
                // workExecutor.trySubmitWorkItem -> signalWorkItemCompletion -> workRetainer.enqueue)
                // trying to forward retained work items will
                trySubmitRetainedWorkItems();
            }
        } else {
            cancelledWorkItem.get().cancel();
            logger.debug("Job {} cancelled {} : dropping it.",
                    workItem, cancelledWorkItem.get());
        }
    }

    /**
     * Signals the completion of the work item for which the given predicate applies, removing it from
     * the current estimate of ongoing work.
     * @param selector The predicate to be used to select the work item for which completion is being signaled.
     */
    public void signalWorkItemCompletion(@Nonnull Predicate<T> selector) {
        // Update the estimate of ongoing work ... (one may have just ended)
        workExecutor.signalWorkItemCompletion(selector);
        // ... and dispatch as many work items for execution as possible
        trySubmitRetainedWorkItems();
    }

    /**
     * <p>Signals the cancellation of work items for which the given predicate applies, removing them from
     * the current estimate of ongoing and retained work.</p>
     * @param selector The predicate to be used to select the work items for which cancellation is being signaled.
     */
    public void signalWorkItemCancellation(@Nonnull Predicate<T> selector) {
        // Update the estimate of pending work ...
        workRetainer.pruneAll(selector)
            .forEach(T::cancel);
        // ... update the estimate of ongoing work ... (one may have just ended)
        workExecutor.signalWorkItemCancellation(selector);
        // ... and dispatch as many work items for execution as possible
        trySubmitRetainedWorkItems();
    }

    public boolean signalWorkItem(@Nonnull Signaller<T> signaller) {
        return workExecutor.signalWorkItem(signaller);
    }

    /**
     * @return The number of pending work items.
     */
    public int getPendingWorkItemCount() {
        return workRetainer.getSize();
    }

    /**
     * @return The number of ongoing work items.
     */
    public int getOngoingWorkItemCount() {
        return workExecutor.getWorkItemCount();
    }

    /**
     * @return The maximum allowed number of simultaneous work items.
     */
    public int getMaxOngoingWorkItemCount() {
        return workExecutor.getMaxWorkItemCount();
    }

    /**
     * Sets the maximum allowed number of simultaneous work items. This configuration change may not
     * have immediate effect, meaning, ongoing work items will not be cancelled.
     * @param newMaxOngoingWorkItemCount The new maximum number of allowed simultaneous work items.
     * @throws IllegalArgumentException If {@literal newMaxOngoingWorkItemCount} is not greater
     * than 0.
     */
    public void setMaxOngoingWorkItemCount(int newMaxOngoingWorkItemCount) {
        workExecutor.setMaxWorkItemCount(newMaxOngoingWorkItemCount);
        // dispatch as many jobs for execution as possible
        trySubmitRetainedWorkItems();
    }

    public Stream<T> getOnGoingWorkItems(){
        return workExecutor.getOngoingWorkItems();
    }

    public Stream<T> getPendingWorkItems(){
        return workRetainer.getElements();
    }
}
