package com.ossnms.dcn_manager.core.entities.mediator.data;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.entities.DynamicBusinessObjectData;
import com.ossnms.dcn_manager.core.entities.DynamicBusinessObjectPrototype;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import java.util.Optional;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Strings.isNullOrEmpty;

/**
 * Basic Mediator information.
 */
public final class MediatorInfoData extends DynamicBusinessObjectData {

    private static final int DEFAULT_RECONNECT_ATTEMPT_INTERVAL = 10;
    private static final int DEFAULT_ACTIVATIONS_LIMIT = 20;

    private final String name;
    private final Optional<String> description;
    private final boolean activationRequired;
    private final String typeName;
    private final Optional<String> userText;

    private final boolean concurrentActivationsLimited;
    private final int concurrentActivationsLimit;
    private final int reconnectAttemptInterval;

    /**
     * Creates a new object.
     * @param id Mediator ID.
     * @param version The Mediator instance's version number.
     * @param prototype Initial instance data.
     * @throws IllegalArgumentException If either the new name or type name is null.
     */
    public MediatorInfoData(int id, int version, MediatorInfoPrototype<?> prototype) {
        super(id, version, ImmutableMap.copyOf(prototype.getPropertyBag()));

        checkArgument(!isNullOrEmpty(prototype.name), "A mediator must have a name!");
        checkArgument(!isNullOrEmpty(prototype.typeName), "A mediator must have a type!");

        this.name = prototype.name;
        this.typeName = prototype.typeName;
        this.description = prototype.description;
        this.activationRequired = prototype.activationRequired;
        this.userText = prototype.userText;

        this.concurrentActivationsLimited = prototype.concurrentActivationsLimited;
        this.concurrentActivationsLimit = prototype.concurrentActivationsLimit;
        this.reconnectAttemptInterval = prototype.reconnectAttemptInterval;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("name", name)
                .append("typeName", typeName)
                .append("activationRequired", activationRequired)
                .append("concurrentActivationsLimited", concurrentActivationsLimited)
                .append("concurrentActivationsLimit", concurrentActivationsLimit)
                .append("reconnectAttemptInterval", reconnectAttemptInterval)
                .append("description", description)
                .append("userText", userText)
                .toString();
    }

    /**
     * @return Mediator name.
     */
    public String getName() {
        return name;
    }

    /**
     * @return Mediator description. May be empty.
     */
    public Optional<String> getDescription() {
        return description;
    }

    /**
     * @return userText. May be empty.
     */
    public Optional<String> getUserText() {
        return userText;
    }

    /**
     * @return Whether activation is required for this Mediator.
     */
    public boolean isActivationRequired() {
        return activationRequired;
    }

    /**
     * @return The Mediator type name.
     */
    public  String  getTypeName() {
        return typeName;
    }

    /**
     * @return Whether the number of concurrent activations should be limited.
     */
    public boolean isConcurrentActivationsLimited() {
        return concurrentActivationsLimited;
    }

    /**
     * @return The maximum number of concurrent activations that can be in progress
     *  at any time. Enforced only if {@code concurrentActivationsLimited} is true.
     */
    public int getConcurrentActivationsLimit() {
        return concurrentActivationsLimit;
    }

    /**
     * @return Amount of time to wait between automatic reconnection attempts,
     *  in minutes.
     */
    public int getReconnectAttemptInterval() {
        return reconnectAttemptInterval;
    }

    /**
     * Facilitates the creation of a data object by allowing
     * individual attributes to be set easily.
     */
    public static final class MediatorInfoBuilder extends MediatorInfoPrototype<MediatorInfoBuilder> {

        public MediatorInfoData build(int id, int version) {
            return new MediatorInfoData(id, version, this);
        }

        @Override
        protected MediatorInfoBuilder self() {
            return this;
        }

    }

    /**
     * Contains initial data values for the data object (it's a parameter object).
     */
    public static final class MediatorInfoInitialData extends MediatorInfoPrototype<MediatorInfoInitialData> {

        @Override
        protected MediatorInfoInitialData self() {
            return this;
        }

        /**
         * @return The future mediator name.
         */
        public String getName() {
            return super.name;
        }

    }

    public abstract static class MediatorInfoPrototype<T extends MediatorInfoPrototype<T>>
            extends DynamicBusinessObjectPrototype<T>
            implements MediatorPropertySetters<T> {

        private String name;
        private Optional<String> description = Optional.empty();
        private boolean activationRequired;
        private String typeName;
        private Optional<String> userText = Optional.empty();

        private boolean concurrentActivationsLimited = true;
        private int concurrentActivationsLimit = DEFAULT_ACTIVATIONS_LIMIT;
        private int reconnectAttemptInterval = DEFAULT_RECONNECT_ATTEMPT_INTERVAL;

        protected MediatorInfoPrototype() {

        }

        protected MediatorInfoPrototype(MediatorInfoPrototype<?> prototype) {
            super(prototype);

            this.name = prototype.name;
            this.typeName = prototype.typeName;
            this.description = prototype.description;
            this.activationRequired = prototype.activationRequired;
            this.userText = prototype.userText;

            this.concurrentActivationsLimited = prototype.concurrentActivationsLimited;
            this.concurrentActivationsLimit = prototype.concurrentActivationsLimit;
            this.reconnectAttemptInterval = prototype.reconnectAttemptInterval;
        }

        @Override
        protected abstract T self();

        /**
         * @param name Mediator name.
         */
        @Override
        public T setName(String name) {
            this.name = name;
            return self();
        }

        /**
         * @param description Mediator description. May be empty.
         */
        @Override
        public T setDescription(@Nonnull Optional<String> description) {
            this.description = description;
            return self();
        }

        /**
         * @param activationRequired Whether activation is required for this Mediator.
         */
        @Override
        public T setActivationRequired(boolean activationRequired) {
            this.activationRequired = activationRequired;
            return self();
        }

        /**
         * @param typeName The Mediator type name.
         */
        public T setTypeName(String typeName) {
            this.typeName = typeName;
            return self();
        }

        /**
         * @param concurrentActivationsLimited Whether the number of concurrent activations should be limited.
         */
        @Override
        public T setConcurrentActivationsLimited(boolean concurrentActivationsLimited) {
            this.concurrentActivationsLimited = concurrentActivationsLimited;
            return self();
        }

        /**
         * @param concurrentActivationsLimit The maximum number of concurrent activations that can be in progress
         *      at any time. Enforced only if {@code concurrentActivationsLimited} is true.
         */
        @Override
        public T setConcurrentActivationsLimit(int concurrentActivationsLimit) {
            this.concurrentActivationsLimit = concurrentActivationsLimit;
            return self();
        }

        /**
         * @param reconnectAttemptInterval  Amount of time to wait between automatic reconnection attempts,
         *    in minutes.
         */
        @Override
        public T setReconnectAttemptInterval(int reconnectAttemptInterval) {
            this.reconnectAttemptInterval = reconnectAttemptInterval;
            return self();
        }

        @Override
        public T setUserText(Optional<String> userText) {
            this.userText = userText;
            return self();
        }

        /** {@inheritDoc} */
        @Override
        public String toString() {
            return new ToStringBuilder(this)
                    .append("name", name)
                    .append("typeName", typeName)
                    .append("activationRequired", activationRequired)
                    .append("concurrentActivationsLimited", concurrentActivationsLimited)
                    .append("concurrentActivationsLimit", concurrentActivationsLimit)
                    .append("reconnectAttemptInterval", reconnectAttemptInterval)
                    .append("description", description)
                    .appendSuper(super.toString())
                    .toString();
        }

    }
}
