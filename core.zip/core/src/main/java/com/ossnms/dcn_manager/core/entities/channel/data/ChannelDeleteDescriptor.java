package com.ossnms.dcn_manager.core.entities.channel.data;

/**
 * Describes an EM deletion event. Contains all information necessary to delete an EM.
 */
public final class ChannelDeleteDescriptor {

    private final int emId;

    public ChannelDeleteDescriptor(int emId) {
        this.emId = emId;
    }

    public int getId() {
        return emId;
    }

}
