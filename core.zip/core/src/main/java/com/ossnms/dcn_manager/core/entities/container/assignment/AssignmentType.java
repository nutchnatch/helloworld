package com.ossnms.dcn_manager.core.entities.container.assignment;

public enum AssignmentType {
    /** The owner parent container is the principal container of the all relationship */
    PRIMARY,
    /** The secondaries parent containers is considered logical associations */
    LOGICAL;

    /**
     * Factory method from bcb flag
     * @see com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment#getPrimary
     * @see com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment#getPrimary
     */
    public static AssignmentType fromFlag(boolean primary) {
        return primary ? PRIMARY : LOGICAL;
    }

    /**
     * BCB flag
     * @see com.ossnms.bicnet.bcb.model.emObjMgmt.ISystemGenericContainerAssignment#getPrimary
     * @see com.ossnms.bicnet.bcb.model.emObjMgmt.INeGenericContainerAssignment#getPrimary
     */
    public boolean toFlag() {
        return this == PRIMARY;
    }
}