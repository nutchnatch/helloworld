package com.ossnms.dcn_manager.core.policies;


import com.ossnms.dcn_manager.core.policies.common.PolicyJob;

import java.util.stream.Stream;

/**
 * Interface with job related info
 */
public interface JobsInfo extends JobMetrics {

    /**
     * Gets the ongoing jobs, regardless of the partition.
     *
     * @return ongoing jobs
     */
    Stream<PolicyJob<?>> getOngoingJobs();

    /**
     * Gets the pending jobs, regardless of the partition.
     *
     * @return pending jobs
     */
    Stream<PolicyJob<?>> getPendingJobs();
}
