package com.ossnms.dcn_manager.exceptions;


/**
 * Thrown when user code tries to apply a mutation that is semantically
 * invalid or that violates some business logic.
 */
public class InvalidMutationException extends DcnManagerException {

    private static final long serialVersionUID = 4428468442905195707L;

    public InvalidMutationException() {

    }

    public InvalidMutationException(String message) {
        super(message);
    }

    public InvalidMutationException(Throwable cause) {
        super(cause);
    }

    public InvalidMutationException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidMutationException(String message, Throwable cause, boolean enableSuppression,
            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public InvalidMutationException(String format, Object... formatParameters) {
        super(format, formatParameters);
    }

    public InvalidMutationException(String format, Throwable cause, Object... formatParameters) {
        super(format, cause, formatParameters);
    }
}
