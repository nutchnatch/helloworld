package com.ossnms.dcn_manager.core.entities.mediator.behavior;

import com.ossnms.dcn_manager.core.entities.channel.data.ChannelPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.ActualActivationState;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.events.MessageSource;
import com.ossnms.dcn_manager.core.events.channel.ChannelEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.channel.PhysicalChannelStateEvent.PhysicalChannelDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorDeactivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorShuttingDownEvent;
import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent.MediatorStartingUpEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorActivationFailedEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorDeactivatedEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorDeactivatingEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorShuttingDownEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent.PhysicalMediatorStartingUpEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.ActivateMediatorEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.DeactivateMediatorEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorNotifications;
import com.ossnms.dcn_manager.core.policies.MediatorInteractionManager;
import com.ossnms.dcn_manager.i18n.Message;

import javax.annotation.Nonnull;
import java.time.Instant;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * <p>Class that implements the behavior dimension of the domain object that describes the solution's connectivity
 * to a specific mediator server. This means that the application must ensure that the actual mediator activation
 * state converges to the required one, managing as many physical connections as necessary.</p>
 *
 * <p>The implementation follows closely the one in {@link MediatorConnectionBehavior}. </p>
 *
 * <p><figure>
 * <img src="doc-files/mediatorPhysicalConnection_actual_activation_state-state.png">
 * <figcaption>State diagram of the actual activation state state machine</figcaption>
 * </figure></p>
 *
 * @see MediatorConnectionBehavior
 */
/*
 * @startuml doc-files/mediatorPhysicalConnection_actual_activation_state-state.png
 * [*] --> Inactive
 * Inactive --> StartingUp : startUp
 * StartingUp --> Failed : setFailed
 * StartingUp --> ShuttingDown : shutdown
 * StartingUp --> Activating : setActivating
 * Activating --> Active : activated
 * Activating --> ShuttingDown : shutdown
 * Active --> ShuttingDown : shutdown
 * ShuttingDown --> Deactivating : deactivating
 * ShuttingDown --> Failed : failed
 * Deactivating --> Inactive : deactivated
 * Activating --> Failed : failed
 * Active --> Failed : failed
 * Deactivating --> Failed : failed
 * Inactive --> Failed : failed
 * Failed --> StartingUp : startUp
 * Failed --> ShuttingDown : shutdown
 * Failed --> Failed : failed
 * @enduml
 */
public class MediatorPhysicalConnectionBehavior {

    private final MediatorPhysicalConnectionData connectionData;

    /**
     * Creates a new behavior object for manipulating a target instance of data.
     *
     * @param connectionData Target data instance.
     */
    public MediatorPhysicalConnectionBehavior(@Nonnull MediatorPhysicalConnectionData connectionData) {
        this.connectionData = connectionData;
    }

    /**
     * Signals a mediator as having started the activation process.
     *
     * @param notifications Instance of the class responsible for sending notifications about mediators.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<MediatorPhysicalConnectionMutationDescriptor> setActivating(@Nonnull MediatorNotifications notifications) {
        return behaviorForState().activating(notifications);
    }

    /**
     * Signals a mediator as having been successfully activated.
     *
     * @param notifications Instance of the class responsible for sending notifications about mediators.
     * @param activationManager Instance of the class responsible for the activation policies.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<MediatorPhysicalConnectionMutationDescriptor> setActive(@Nonnull MediatorNotifications notifications,
                                                                                      @Nonnull MediatorInteractionManager activationManager) {
        return behaviorForState().activated(notifications, activationManager);
    }

    /**
     * Signals a mediator as having started the deactivation process.
     *
     * @param notifications Instance of the class responsible for sending notifications about mediators.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<MediatorPhysicalConnectionMutationDescriptor> setDeactivating(@Nonnull MediatorNotifications notifications) {
        return behaviorForState().deactivating(notifications);
    }

    /**
     * Signals a mediator as having been successfully deactivated.
     * @param notifications Instance of the class responsible for sending notifications about mediators.
     * @param activationManager Instance of the class responsible for the activation policies.
     * @param channelMessageSource Channel event injection point.
     * @param channelList List of channel identifiers that should be marked failed as consequence of the mediator failing.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<MediatorPhysicalConnectionMutationDescriptor> setInactive(@Nonnull MediatorNotifications notifications,
                                                                                        @Nonnull MediatorInteractionManager activationManager, @Nonnull final MessageSource<ChannelEvent> channelMessageSource,
                                                                                        @Nonnull final Iterable<ChannelPhysicalConnectionData> channelList) {
        return behaviorForState().deactivated(notifications, activationManager, channelMessageSource, channelList);
    }


    /**
     * Signals a mediator as having an activation process to be scheduled.
     *
     * @param notifications Instance of the class responsible for sending notifications about mediators.
     * @param activationManager Instance of the class responsible for the activation policies.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<MediatorPhysicalConnectionMutationDescriptor> setStartingUp(@Nonnull MediatorNotifications notifications,
                                                                                          @Nonnull MediatorInteractionManager activationManager) {
        return behaviorForState().startingUp(notifications, activationManager);
    }

    /**
     * Signals a mediator as having an deactivation process to be scheduled.
     *
     * @param notifications Instance of the class responsible for sending notifications about mediators.
     * @param activationManager Instance of the class responsible for the activation policies.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<MediatorPhysicalConnectionMutationDescriptor> setShuttingDown(@Nonnull MediatorNotifications notifications,
                                                                                            @Nonnull MediatorInteractionManager activationManager) {
    	return behaviorForState().shuttingDown(notifications, activationManager);
    }

    /**
     * Signals that activation of a mediator has failed.
     * @param notifications Instance of the class responsible for sending notifications about mediators.
     * @param activationManager Instance of the class responsible for the activation policies.
     * @param description Human readable failure description. Will be eventually forwarded to the operator.
     * @param channelMessageSource Channel event injection point.
     * @param channelList List of channel identifiers that should be marked failed as consequence of the mediator failing.
     * @return A mutation descriptor ready for committing the status change to the repository.
     *  Will be absent if the status change is not possible.
     */
    public Optional<MediatorPhysicalConnectionMutationDescriptor> setFailed(
            @Nonnull MediatorNotifications notifications, @Nonnull final MediatorInteractionManager activationManager,
            @Nonnull String description, @Nonnull final MessageSource<ChannelEvent> channelMessageSource,
            @Nonnull final Iterable<ChannelPhysicalConnectionData> channelList) {
        return behaviorForState().failed(notifications, activationManager, description, channelMessageSource, channelList);
    }

    private ActualActivation behaviorForState() {
        switch (connectionData.getActualActivationState()) {
        case ACTIVATING:
            return new Activating();
        case ACTIVE:
            return new Active();
        case DEACTIVATING:
            return new Deactivating();
        case INACTIVE:
            return new Inactive();
        case FAILED:
            return new Failed();
        case STARTINGUP:
        	return new StartingUp();
        case SHUTTINGDOWN:
        	return new ShuttingDown();

        default:
            throw new UnsupportedOperationException();
        }
    }

    private abstract class ActualActivation {

        protected Optional<MediatorPhysicalConnectionMutationDescriptor> startingUp(@Nonnull MediatorNotifications notifications,
                                                                                              @Nonnull MediatorInteractionManager activationManager) {
            return Optional.empty();
        }

        protected Optional<MediatorPhysicalConnectionMutationDescriptor> shuttingDown(@Nonnull MediatorNotifications notifications,
                                                                                                @Nonnull MediatorInteractionManager activationManager) {
            return Optional.empty();
        }

        protected Optional<MediatorPhysicalConnectionMutationDescriptor> activating(@Nonnull MediatorNotifications notifications) {
            return Optional.empty();
        }

        protected Optional<MediatorPhysicalConnectionMutationDescriptor> activated(@Nonnull MediatorNotifications notifications,
                                                                                             @Nonnull MediatorInteractionManager activationManager) {
            return Optional.empty();
        }

        protected Optional<MediatorPhysicalConnectionMutationDescriptor> deactivating(@Nonnull MediatorNotifications notifications) {
            return Optional.empty();
        }

        protected Optional<MediatorPhysicalConnectionMutationDescriptor> deactivated(@Nonnull MediatorNotifications notifications,
                                                                                               @Nonnull MediatorInteractionManager activationManager, @Nonnull final MessageSource<ChannelEvent> channelMessageSource,
                                                                                               @Nonnull final Iterable<ChannelPhysicalConnectionData> channelList) {
            return Optional.empty();
        }

        protected Optional<MediatorPhysicalConnectionMutationDescriptor> failed(
                @Nonnull MediatorNotifications notifications, @Nonnull MediatorInteractionManager activationManager,
                @Nonnull String description, @Nonnull MessageSource<ChannelEvent> channelMessageSource,
                @Nonnull Iterable<ChannelPhysicalConnectionData> channelList) {
            return Optional.empty();
        }


    }

    private abstract class CancellableState extends FailingActivationState {
        @Override
        public Optional<MediatorPhysicalConnectionMutationDescriptor> shuttingDown(@Nonnull final MediatorNotifications notifications,
                                                                                             @Nonnull final MediatorInteractionManager activationManager) {

            return Optional.of(new MediatorPhysicalConnectionMutationDescriptor(connectionData)
                    .setActiveState(ActualActivationState.SHUTTINGDOWN)
                    .setAdditionalInfo("")
                    .whenApplied(in -> {
                            final MediatorShuttingDownEvent event = new MediatorShuttingDownEvent(in.getResult().getLogicalMediatorId(),
                                    new PhysicalMediatorShuttingDownEvent(in.getResult().getId(), in.getResult().getLogicalMediatorId(), in.getResult().isActive()));
                            notifications.notifyChanges(event);
                            final DeactivateMediatorEvent deactivateMediatorEvent = new DeactivateMediatorEvent(in.getResult().getLogicalMediatorId(), in.getResult().getId());
                            activationManager.scheduleDeactivation(deactivateMediatorEvent);
                        }
                    ));
            }
        
    }
    
    private abstract class FailingActivationState extends ActualActivation {

        @Override
        protected Optional<MediatorPhysicalConnectionMutationDescriptor> failed(
                @Nonnull final MediatorNotifications notifications, @Nonnull final MediatorInteractionManager activationManager,
                @Nonnull String description, @Nonnull final MessageSource<ChannelEvent> channelMessageSource,
                @Nonnull final Iterable<ChannelPhysicalConnectionData> channelList) {
            return Optional.of(new MediatorPhysicalConnectionMutationDescriptor(connectionData)
                .setActiveState(ActualActivationState.FAILED)
                .setAdditionalInfo(description)
                .setLastFailureTimestamp(Instant.now())
                .whenApplied(in -> {
                    final MediatorActivationFailedEvent event = new MediatorActivationFailedEvent(in.getResult().getLogicalMediatorId(),
                        new PhysicalMediatorActivationFailedEvent(in.getResult().getId(), in.getResult().getLogicalMediatorId(),
                            in.getResult().isActive(), in.getResult().getAdditionalInfo()),
                        description);
                    notifications.notifyChanges(event);
                    activationManager.onMediatorInteractionEnded(event);
                    for (final ChannelPhysicalConnectionData channel : channelList) {
                        channelMessageSource.push(new PhysicalChannelActivationFailedEvent(
                                channel.getId(), channel.getLogicalChannelId(), channel.isActive(), tr(Message.MEDIATOR_FAILED)));
                    }
                })
            );
        }

    }

    private final class Activating extends CancellableState {

        @Override
        protected Optional<MediatorPhysicalConnectionMutationDescriptor> activated(@Nonnull final MediatorNotifications notifications,
                                                                                             @Nonnull final MediatorInteractionManager activationManager) {
            return Optional.of(new MediatorPhysicalConnectionMutationDescriptor(connectionData)
                .setActiveState(ActualActivationState.ACTIVE)
                .setActivationAttemptsCounter(0)
                .setAdditionalInfo("")
                .whenApplied(in -> {
                        final MediatorActivatedEvent event =
                            new MediatorActivatedEvent(in.getResult().getLogicalMediatorId(),
                                    new PhysicalMediatorActivatedEvent(in.getResult().getId(), in.getResult().getLogicalMediatorId(),
                                            in.getResult().isActive(), in.getResult().getAdditionalInfo()));
                        notifications.notifyChanges(event);
                        activationManager.onMediatorInteractionEnded(event);
                    }
                )
            );
        }

    }

    private final class Active extends CancellableState {


    }

    private final class Deactivating extends RestartableState {

        @Override
        protected Optional<MediatorPhysicalConnectionMutationDescriptor> deactivated(@Nonnull final MediatorNotifications notifications,
                                                                                               @Nonnull final MediatorInteractionManager activationManager, @Nonnull final MessageSource<ChannelEvent> channelMessageSource,
                                                                                               @Nonnull final Iterable<ChannelPhysicalConnectionData> channelList) {
            return Optional.of(new MediatorPhysicalConnectionMutationDescriptor(connectionData)
                .setActiveState(ActualActivationState.INACTIVE)
                .setActivationAttemptsCounter(0)
                .setAdditionalInfo("")
                .whenApplied(in -> {
                        final MediatorDeactivatedEvent event =
                            new MediatorDeactivatedEvent(in.getResult().getLogicalMediatorId(),
                                    new PhysicalMediatorDeactivatedEvent(in.getResult().getId(), in.getResult().getLogicalMediatorId(),
                                        in.getResult().isActive(), in.getResult().getAdditionalInfo()));
                        notifications.notifyChanges(event);
                        activationManager.onMediatorInteractionEnded(event);
                        for (final ChannelPhysicalConnectionData channel : channelList) {
                            channelMessageSource.push(new PhysicalChannelDeactivatedEvent(
                                    channel.getId(), channel.getLogicalChannelId(), channel.isActive()));
                        }
                    }
                )
            );
        }

    }

    private class Inactive extends ActualActivation {

        @Override
        protected Optional<MediatorPhysicalConnectionMutationDescriptor> startingUp(@Nonnull final MediatorNotifications notifications,
                                                                                              @Nonnull final MediatorInteractionManager activationManager) {
        	return doStartingUp(notifications, activationManager);
        }
        
        // Allow mediation to activate even tough starting up event has been lost due to message loss.
        @Override
        protected Optional<MediatorPhysicalConnectionMutationDescriptor> activating(@Nonnull final MediatorNotifications notifications) {
            return Optional.of(new MediatorPhysicalConnectionMutationDescriptor(connectionData)
                .setActiveState(ActualActivationState.ACTIVATING)
                .setActivationAttemptsCounter(connectionData.getActivationAttemptsCounter() + 1)
                .setAdditionalInfo("")
                .whenApplied(in -> notifications.notifyChanges(
                    new MediatorActivatingEvent(in.getResult().getLogicalMediatorId(),
                        new PhysicalMediatorActivatingEvent(in.getResult().getId(), in.getResult().getLogicalMediatorId(),
                            in.getResult().isActive(), in.getResult().getAdditionalInfo()))))
            );
        }

    }

    private abstract class RestartableState extends FailingActivationState {
    
        @Override
        protected Optional<MediatorPhysicalConnectionMutationDescriptor> startingUp(@Nonnull final MediatorNotifications notifications,
                                                                                              @Nonnull final MediatorInteractionManager activationManager) {
            return doStartingUp(notifications, activationManager);

        }
    }
    
    private final class Failed extends RestartableState {

        @Override
        protected Optional<MediatorPhysicalConnectionMutationDescriptor> shuttingDown(@Nonnull final MediatorNotifications notifications,
                                                                                                @Nonnull final MediatorInteractionManager activationManager) {
            return Optional.of(new MediatorPhysicalConnectionMutationDescriptor(connectionData)
                    .setActiveState(ActualActivationState.SHUTTINGDOWN)
                    .setAdditionalInfo("")
                    .whenApplied(in -> {
                            final MediatorShuttingDownEvent event = new MediatorShuttingDownEvent(in.getResult().getLogicalMediatorId(),
                                    new PhysicalMediatorShuttingDownEvent(in.getResult().getId(), in.getResult().getLogicalMediatorId(), in.getResult().isActive()));
                            notifications.notifyChanges(event);
                            final DeactivateMediatorEvent deactivateMediatorEvent = new DeactivateMediatorEvent(in.getResult().getLogicalMediatorId(), in.getResult().getId());
                            activationManager.scheduleDeactivation(deactivateMediatorEvent);
                        }
                    ));
        }
    }

    private final class StartingUp extends CancellableState {

        @Override
        protected Optional<MediatorPhysicalConnectionMutationDescriptor> activating(@Nonnull final MediatorNotifications notifications) {
            return Optional.of(new MediatorPhysicalConnectionMutationDescriptor(connectionData)
                .setActiveState(ActualActivationState.ACTIVATING)
                .setActivationAttemptsCounter(connectionData.getActivationAttemptsCounter() + 1)
                .setAdditionalInfo("")
                .whenApplied(in -> notifications.notifyChanges(
                    new MediatorActivatingEvent(in.getResult().getLogicalMediatorId(),
                        new PhysicalMediatorActivatingEvent(in.getResult().getId(), in.getResult().getLogicalMediatorId(),
                            in.getResult().isActive(), in.getResult().getAdditionalInfo()))))
            );
        }
    }


    private final class ShuttingDown extends RestartableState {
        @Override
        protected Optional<MediatorPhysicalConnectionMutationDescriptor> deactivating(@Nonnull final MediatorNotifications notifications) {
            return Optional.of(new MediatorPhysicalConnectionMutationDescriptor(connectionData)
                .setActiveState(ActualActivationState.DEACTIVATING)
                .setAdditionalInfo("")
                .whenApplied(in -> notifications.notifyChanges(
                    new MediatorDeactivatingEvent(in.getResult().getLogicalMediatorId(),
                            new PhysicalMediatorDeactivatingEvent(in.getResult().getId(), in.getResult().getLogicalMediatorId(),
                                in.getResult().isActive(), in.getResult().getAdditionalInfo()))))
            );
        }
    }

    private Optional<MediatorPhysicalConnectionMutationDescriptor> doStartingUp(@Nonnull final MediatorNotifications notifications,
                                                                                          @Nonnull final MediatorInteractionManager activationManager)  {

        return Optional.of(new MediatorPhysicalConnectionMutationDescriptor(connectionData)
                .setActiveState(ActualActivationState.STARTINGUP)
                .setAdditionalInfo("")
                .whenApplied(in -> {
                        final MediatorStartingUpEvent event =
                            new MediatorStartingUpEvent(in.getResult().getLogicalMediatorId(),
                                new PhysicalMediatorStartingUpEvent(in.getResult().getId(), in.getResult().getLogicalMediatorId(),
                                    in.getResult().isActive(), in.getResult().getAdditionalInfo()));
                        notifications.notifyChanges(event);

                        final ActivateMediatorEvent activateMediatorEvent = new ActivateMediatorEvent(in.getResult().getLogicalMediatorId(), in.getResult().getId());

                        activationManager.scheduleActivation(activateMediatorEvent);
                    }
                )
            );

    }
}
