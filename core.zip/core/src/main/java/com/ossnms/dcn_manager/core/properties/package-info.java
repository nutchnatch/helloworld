/**
 * <p>There is data associated with some domain entities other than their natural attributes.
 * This data is not type-safe in any way and has no specific semantics. Moreover, it varies among entity types.
 * For example, different types of NEs may require different sets of additional data.
 * It assumes the form of (name, value) pairs in our internal representation.</p>
 *
 * <p>Hence it is usual to use the term "properties" when referring to such a data set, which implies
 * a mental image of an opaque bag of information containing labelled boxes. The same term is used
 * in other components, such as Connection Manager or the mediators, to refer to unstructured entity
 * specific data.</p>
 *
 * <p>It was necessary to attach semantics to some of these pairs because EM/NE was tasked with data
 * manipulation duties over them. Therefore we decided to map them to entity attributes to ensure
 * type safety, documentation and semantics.</p>
 *
 * <p>This means that the "properties" term has evolved to actually represent an unstructured view over
 * a subset of entity data, or an alternate representation if you prefer. When exposing property bags
 * beyond its borders, EM/NE must fetch values from its entities' well defined attributes as well as
 * property bags. This is bijective: updates to these properties coming from the outside may affect
 * entity attributes in addition to property bag contents.</p>
 *
 * <p>Properties are therefore not accessed directly. Each domain entity aggregator will have a companion
 * object that possesses the knowledge and API to access properties as a coherent set.</p>
 *
 * @see com.ossnms.dcn_manager.core.properties.channel
 * @see com.ossnms.dcn_manager.core.properties.ne
 */
package com.ossnms.dcn_manager.core.properties;
