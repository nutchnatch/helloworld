package com.ossnms.dcn_manager.core.entities.ne.data.types;

public enum CommissioningMode {
    NOT_COMMISSIONED,
    PARTIALLY_COMMISSIONED,
    COMMISSIONED;

}
