package com.ossnms.dcn_manager.core.entities.emne;

import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownSettingsPropertyNames;
import com.ossnms.dcn_manager.core.entities.PropertyHandlerBase;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

import static com.ossnms.dcn_manager.i18n.Message.GLOBAL_CONFIG_DEFAULT_CONTAINER_NAME;
import static com.ossnms.dcn_manager.i18n.Message.GLOBAL_CONFIG_DISCOVERY_POLICY;
import static com.ossnms.dcn_manager.i18n.Message.GLOBAL_CONFIG_ENABLE_NATIVE_NE_NAMING;
import static com.ossnms.dcn_manager.i18n.Message.GLOBAL_CONFIG_ENABLE_SCHEDULED_STARTUP;
import static com.ossnms.dcn_manager.i18n.Message.GLOBAL_CONFIG_RETRY_CHANNEL;
import static com.ossnms.dcn_manager.i18n.Message.GLOBAL_CONFIG_RETRY_INTERVAL;
import static com.ossnms.dcn_manager.i18n.Message.GLOBAL_CONFIG_RETRY_MEDIATOR;
import static com.ossnms.dcn_manager.i18n.Message.GLOBAL_CONFIG_RETRY_NE;
import static com.ossnms.dcn_manager.i18n.Message.GLOBAL_CONFIG_SCALED_STARTUP_LIMIT;

/**
 * Contains well known EM/NE property names as mentioned in the user interface description files.
 * These property names refer to global EM/NE settings.
 */
public enum SettingsProperties {
    /** Mediator connection retry limit. Zero means infinite. */
    RETRY_MEDIATOR(WellKnownSettingsPropertyNames.RETRY_MEDIATOR, GLOBAL_CONFIG_RETRY_MEDIATOR.toString()),
    /** Channel connection retry limit. Zero means infinite. */
    RETRY_CHANNEL(WellKnownSettingsPropertyNames.RETRY_CHANNEL, GLOBAL_CONFIG_RETRY_CHANNEL.toString()),
    /** NE connection retry limit. Zero means infinite. */
    RETRY_NE(WellKnownSettingsPropertyNames.RETRY_NE, GLOBAL_CONFIG_RETRY_NE.toString()),
    /** Retry interval. */
    RETRY_INTERVAL(WellKnownSettingsPropertyNames.RETRY_INTERVAL, GLOBAL_CONFIG_RETRY_INTERVAL.toString()),
    SCALED_STARTUP_LIMIT(WellKnownSettingsPropertyNames.SCALED_STARTUP_LIMIT, GLOBAL_CONFIG_SCALED_STARTUP_LIMIT.toString()),
    DISCOVERY_POLICY(WellKnownSettingsPropertyNames.DISCOVERY_POLICY, GLOBAL_CONFIG_DISCOVERY_POLICY.toString()),
    ENABLE_SCHEDULED_STARTUP(WellKnownSettingsPropertyNames.ENABLE_SCHEDULED_STARTUP, GLOBAL_CONFIG_ENABLE_SCHEDULED_STARTUP.toString()),
    ENABLE_NATIVE_NE_NAMING(WellKnownSettingsPropertyNames.ENABLE_NATIVE_NE_NAMING, GLOBAL_CONFIG_ENABLE_NATIVE_NE_NAMING.toString()),
    DEFAULT_CONTAINER_NAME(WellKnownSettingsPropertyNames.DEFAULT_CONTAINER_NAME, GLOBAL_CONFIG_DEFAULT_CONTAINER_NAME.toString());

    private final String name;
    private final String description;

    SettingsProperties(@Nonnull final String name, @Nonnull final String description) {
        this.name = name;
        this.description = description;
    }

    /** @return The property name as it is used in XML files. */
    public String getName() {
        return name;
    }

    /** @return The description of the property. */
    public String getDescription() {
        return description;
    }

    public static Optional<SettingsProperties> of(@Nonnull final String name) {
        return Stream.of(SettingsProperties.values())
                .filter(property -> Objects.equals(property.getName(), name))
                .findAny();
    }

    @Override
    public String toString() {
        return String.format("%s[%s]", super.toString(), name);
    }

    /**
     * Returns a property map with all global EM/NE settings for the user interface.
     * @param entity Settings domain entity.
     * @return A map of name/value pairs.
     */
    @Nonnull
    public static Map<String, String> getProperties(@Nonnull GlobalSettings entity) {
        final Map<String, String> map = new HashMap<>();
        for (final SettingsProperties property : SettingsProperties.values()) {
            final Optional<String> value = property.getPropertyValue(entity);
            if (value.isPresent()) {
                map.put(property.getName(), value.get());
            }
        }
        return map;
    }

    /**
     * Retrieves the value of a property.
     * @param entity Settings domain entity.
     * @param name The desired property name.
     * @return The property value, if present.
     */
    @Nonnull
    public static Optional<String> getProperty(@Nonnull GlobalSettings entity, @Nonnull String name) {
        final SettingsPropertyHandler handler = PROPERTY_HANDLERS.get(name);
        return handler != null ? Optional.ofNullable(handler.get(entity, name)) : Optional.<String>empty();
    }

    /**
     * Retrieves the value of a property.
     * @param entity Channel entity.
     * @return The property value, if present.
     */
    @Nonnull
    public Optional<String> getPropertyValue(@Nonnull GlobalSettings entity) {
        return getProperty(entity, name);
    }

    /**
     * Registers a change request for a property on a global settings entity.
     * @param entity The current settings entity.
     * @param name Property name.
     * @param value New property value.
     * @throws InvalidMutationException If the new property value is not acceptable.
     */
    public static void setProperty(GlobalSettingsMutationDescriptor entity, String name, String value)
            throws InvalidMutationException {
        final SettingsPropertyHandler handler = PROPERTY_HANDLERS.get(name);
        if (null == handler) {
            throw new InvalidMutationException("Global settings property '{}' not supported.", name);
        }
        handler.set(entity, name, value);
    }

    /**
     * Registers a change request for a property on a global settings entity.
     * @param entity The current settings entity.
     * @param value New property value.
     * @throws InvalidMutationException If the new property value is not acceptable.
     */
    public void setPropertyValue(GlobalSettingsMutationDescriptor entity, String value)
            throws InvalidMutationException {
        setProperty(entity, name, value);
    }

    private abstract static class SettingsPropertyHandler extends PropertyHandlerBase {

        abstract void set(@Nonnull GlobalSettingsMutationDescriptor descriptor, @Nonnull String name, @Nullable String value)
            throws InvalidMutationException;

        abstract String get(@Nonnull GlobalSettings entity, @Nonnull String name);

    }

    private static final Map<String, SettingsPropertyHandler> PROPERTY_HANDLERS =
        ImmutableMap.<String, SettingsPropertyHandler>builder()
            .put(RETRY_MEDIATOR.getName(), new SettingsPropertyHandler() {
                @Override
                void set(GlobalSettingsMutationDescriptor descriptor, String name, String value) throws InvalidMutationException {
                    descriptor.setMediatorRetries(integerValueOf(value, name));
                }
                @Override
                String get(GlobalSettings entity, String name) {
                    return String.valueOf(entity.getMediatorRetries());
                }
            })
            .put(RETRY_CHANNEL.getName(), new SettingsPropertyHandler() {
                @Override
                void set(GlobalSettingsMutationDescriptor descriptor, String name, String value) throws InvalidMutationException {
                    descriptor.setChannelRetries(integerValueOf(value, name));
                }
                @Override
                String get(GlobalSettings entity, String name) {
                    return String.valueOf(entity.getChannelRetries());
                }
            })
            .put(RETRY_NE.getName(), new SettingsPropertyHandler() {
                @Override
                void set(GlobalSettingsMutationDescriptor descriptor, String name, String value) throws InvalidMutationException {
                    descriptor.setNeRetries(integerValueOf(value, name));
                }
                @Override
                String get(GlobalSettings entity, String name) {
                    return String.valueOf(entity.getNeRetries());
                }
            })
            .put(RETRY_INTERVAL.getName(), new SettingsPropertyHandler() {
                @Override
                void set(GlobalSettingsMutationDescriptor descriptor, String name, String value) throws InvalidMutationException {
                    descriptor.setRetryInterval(integerValueOf(value, name));
                }
                @Override
                String get(GlobalSettings entity, String name) {
                    return String.valueOf(entity.getRetryInterval());
                }
            })
            .put(SCALED_STARTUP_LIMIT.getName(), new SettingsPropertyHandler() {
                @Override
                void set(GlobalSettingsMutationDescriptor descriptor, String name, String value) throws InvalidMutationException {
                    descriptor.setScaledStartupLimit(integerValueOf(value, name));
                }
                @Override
                String get(GlobalSettings entity, String name) {
                    return String.valueOf(entity.getScaledStartupLimit());
                }
            })
            .put(DISCOVERY_POLICY.getName(), new SettingsPropertyHandler() {
                @Override
                void set(GlobalSettingsMutationDescriptor descriptor, String name, String value) throws InvalidMutationException {
                    try {
                        if (null == value) {
                            throw new InvalidMutationException("Null discovery policy value.");
                        }
                        descriptor.setDiscoveryPolicy(DiscoveryPolicy.valueOfGuiLabel(value));
                    } catch (final IllegalArgumentException e) {
                        throw new InvalidMutationException("Bad discovery policy value.", e);
                    }
                }
                @Override
                String get(GlobalSettings entity, String name) {
                    return entity.getDiscoveryPolicy().toString();
                }
            })
            .put(ENABLE_SCHEDULED_STARTUP.getName(), new SettingsPropertyHandler() {
                @Override
                void set(GlobalSettingsMutationDescriptor descriptor, String name, String value) throws InvalidMutationException {
                    descriptor.setEnableScheduledStartup(booleanValueOf(value, name));
                }
                @Override
                String get(GlobalSettings entity, String name) {
                    return String.valueOf(entity.isScheduledStartupEnabled());
                }
            })
            .put(ENABLE_NATIVE_NE_NAMING.getName(), new SettingsPropertyHandler() {
                @Override
                void set(GlobalSettingsMutationDescriptor descriptor, String name, String value) throws InvalidMutationException {
                    descriptor.setShowNativeNeNaming(booleanValueOf(value, name));
                }
                @Override
                String get(GlobalSettings entity, String name) {
                    return String.valueOf(entity.isNativeNeNamingEnabled());
                }
            })
            .put(DEFAULT_CONTAINER_NAME.getName(), new SettingsPropertyHandler() {
                @Override
                void set(GlobalSettingsMutationDescriptor descriptor, String name, String value) throws InvalidMutationException {
                    if (null == value) {
                        throw new InvalidMutationException("Null Default Container name value.");
                    }
                    descriptor.setDefaultContainerName(value);
                }
                @Override
                String get(GlobalSettings entity, String name) {
                    return String.valueOf(entity.getDefaultContainerName());
                }
            })
            .build();

}
