/**
 * <p>Contains the definition of the component's events. </p>
 * 
 * <p>This package contains the definition of events used by the component, that is, both its in-bound 
 * and out-bound events: in-bound events describe occurrences (e.g. state changes) that were detected by 
 * some other component and that may require some sort of reaction (i.e. associated computation); out-bound 
 * events describe internally detected occurrences that are to be forwarded to interested parties (e.g. other 
 * components).</p>
 * 
 * <p>In general terms, and given the purpose of this component in the overall TNMS solution, in-bound events 
 * usually describe operational state changes (i.e. using TNMS idiom, actual state changes), while out-bound
 * events usually describe configuration state changes (i.e. in TNMS terminology, required state changes).</p>
 * 
 * <p>From the previous description, two design constraints naturally emerge:
 * <ul>
 * <li>Event instances are <a href="#Immutability">immutable</a>, because they describe a specific occurrence;</li>
 * <li>Events that describe state changes are <a href="#EventHierarchy">always associated to the domain entity</a>
 * to which the state change description refers to.</li>
 * </ul></p>
 * 
 * <p>Conforming to the previous design constraints requires both understanding and coding discipline. This is why 
 * a detailed explanation follows. Note that non-compliance may hinder overall component robustness.</p>
 *    
 * <a name="Immutability"></a>
 * <h4>Immutability</h4>
 * 
 * <p>As previously stated, event instances are immutable, a decision that stems naturally from their purpose: to 
 * describe a specific occurrence that requires some sort of computation. This decision has several consequences,
 * namely, event instances may be safely shared by multiple threads and, even if that's not the case, it increases 
 * robustness because it inhibits the propagation of modifications accidentally made by an event handler.</p>
 * 
 * <p>Although the consequences and technical aspects of immutabillity are profusely documented 
 * (e.g. <a href="https://docs.oracle.com/javase/tutorial/essential/concurrency/imstrat.html">here</a> and
 * <a href="http://www.javapractices.com/topic/TopicAction.do?Id=29">here</a>), our design assumes that immutability 
 * means that, for all event classes:
 * <ol>
 * <li>All fields are final;</li>
 * <li>All referred objects are themselves immutable (e.g. immutable collections);</li>
 * <li>All classes in the event class hierarchy are immutable; (yes, we do allow inheritance, but only if derived 
 * classes are themselves immutable);</li>
 * <li>And, finally, all event classes must be annotated with {@link javax.annotation.concurrent.Immutable}.</li>
 * </ol>
 * 
 * <p>Summing up, all event objects must be 
 * <a href="https://docs.oracle.com/javase/tutorial/essential/concurrency/immutable.html">immutable objects</a>, 
 * that is, their state cannot change after their construction.</a>
 * 
 * <a name="EventHierarchy"></a>
 * <h4>Event Hierarchy</h4>
 * 
 * <p>The purpose of the event class hierarchy is to model domain related occurrences that are relevant for this 
 * component. By defining such an hierarchy, we make the set of occurrences explicit and we increase code readability, 
 * while enabling static verification (i.e. compile-time) of correctness.</p>
 *  
 * <p>Considering that events describing state changes are always associated to a given domain entity, the package 
 * is organized in sub-packages, according to which domain entities the events are related to. The design decisions
 * pertaining to each of them are documented in the corresponding package.</p>
 * <ul>
 * <li>{@link com.ossnms.dcn_manager.core.events.mediator}</li>
 * <li>{@link com.ossnms.dcn_manager.core.events.channel}</li>
 * <li>{@link com.ossnms.dcn_manager.core.events.domain}</li>
 * <li>{@link com.ossnms.dcn_manager.core.events.ne}</li>
 * </ul>
 * 
 * <p>Regardless of the design decisions presented in each sub-package, all instances of events related to 
 * domain entities must include the associated domain entity identifier, specified upon initiation. This constraint 
 * is materialized by imposing {@link com.ossnms.dcn_manager.core.events.EntityEvent} as the base class for all 
 * domain entity related events. This class also materializes event type's canonical methods (i.e. {@link java.lang.Object}'s 
 * methods).</p> 
 * 
 * @see com.ossnms.dcn_manager.core.events.EntityEvent
 * @see com.ossnms.dcn_manager.core.events.mediator
 * @see com.ossnms.dcn_manager.core.events.channel
 * @see com.ossnms.dcn_manager.core.events.domain
 * @see com.ossnms.dcn_manager.core.events.ne
 */
package com.ossnms.dcn_manager.core.events;