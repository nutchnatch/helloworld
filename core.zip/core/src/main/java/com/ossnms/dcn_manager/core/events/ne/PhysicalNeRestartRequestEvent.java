package com.ossnms.dcn_manager.core.events.ne;

import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.concurrent.Immutable;

/**
 * <p>Represents a request received from a mediator to run a restart sequence
 * (shutdown followed by restart) against a specific NE.</p>
 *
 * <p>Also known as the GX1813 solution.</p>
 *
 * <p>This is modelled as an independent class because it does not represent
 * a simple state change. It is instead meant to initiate a specific use case.</p>
 */
@Immutable
public final class PhysicalNeRestartRequestEvent extends NeEvent {

    private final int physicalNeId;

    /**
     * Constructs a new object.
     * @param logicalNeId Affected logical NE identifier.
     * @param physicalNeId Affected physical NE identifier.
     */
    public PhysicalNeRestartRequestEvent(int logicalNeId, int physicalNeId) {
        super(logicalNeId);
        this.physicalNeId = physicalNeId;
    }

    /**
     * @return Affected physical NE identifier.
     */
    public int getPhysicalNeId() {
        return physicalNeId;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("physicalNeId", physicalNeId)
                .toString();
    }
}
