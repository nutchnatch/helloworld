package com.ossnms.dcn_manager.core.entities.ne.data;

import com.google.common.base.MoreObjects;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationBuilder;
import com.ossnms.dcn_manager.core.utils.ClearableOptional;
import org.apache.commons.lang3.builder.EqualsBuilder;

import java.util.Objects;
import java.util.Optional;

/**
 * Contains all data that should be changed on {@link NeSynchronizationData},
 * when applied as a single atomic mutation by the repository.
 */
public class NeSynchronizationMutationDescriptor
        extends MutationDescriptor<NeSynchronizationData, NeSynchronizationMutationDescriptor>{

    private ClearableOptional<Long> all = ClearableOptional.absent();
    private ClearableOptional<Long> alarms = ClearableOptional.absent();
    private ClearableOptional<Long> packet = ClearableOptional.absent();

    /**
     * Creates a new instance.
     * @param target the {@link NeSynchronizationData} instance to which the mutation will be applied
     */
    public NeSynchronizationMutationDescriptor(NeSynchronizationData target) {
        super(target);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .omitNullValues()
                .add("all", all.orNull())
                .add("alarms", alarms.orNull())
                .add("packet", packet.orNull())
                .addValue(super.toString())
                .toString();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getTarget(), all, alarms, packet);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final NeSynchronizationMutationDescriptor rhs = (NeSynchronizationMutationDescriptor) obj;
        return new EqualsBuilder()
                .append(getTarget(), rhs.getTarget())
                .append(all, rhs.all)
                .append(alarms, rhs.alarms)
                .append(packet, rhs.packet)
                .isEquals();
    }

    /* (non-Javadoc)
             * @see com.ossnms.dcn_manager.core.entities.MutationDescriptor#self()
             */
    @Override
    protected NeSynchronizationMutationDescriptor self() {
        return this;
    }

    /* (non-Javadoc)
     * @see com.ossnms.dcn_manager.core.entities.MutationDescriptor#doApply()
     */
    @Override
    protected NeSynchronizationData doApply() {
        if (all.isPresent() || alarms.isPresent() || packet.isPresent()) {
            return new NeSynchronizationBuilder()
                .setAlarms(alarms.or(getTarget().getAlarms()))
                .setAll(all.or(getTarget().getAll()))
                .setPacket(packet.or(getTarget().getPacket()))
                .build(getTarget().getId(), getTarget().getVersion());
        }
        return getTarget();
    }

    /**
     * @return "All" synchronization category stamp value.
     */
    public Optional<Long> getAll() {
        return all.asOptional();
    }

    /**
     * @return "Alarm" synchronization category stamp value.
     */
    public Optional<Long> getAlarms() {
        return alarms.asOptional();
    }

    /**
     * @return "Packet" synchronization category stamp value.
     */
    public Optional<Long> getPacket() {
        return packet.asOptional();
    }

    /**
     * @param all New "all" synchronization category stamp value.
     */
    public NeSynchronizationMutationDescriptor setAll(long all) {
        final ClearableOptional<Long> newValue = ClearableOptional.of(all);
        if (!newValue.asOptional().equals(getTarget().getAll())) {
            this.all = newValue;
        }
        return self();
    }

    /**
     * @param alarms New "alarms" synchronization category stamp value.
     */
    public NeSynchronizationMutationDescriptor setAlarms(long alarms) {
        final ClearableOptional<Long> newValue = ClearableOptional.of(alarms);
        if (!newValue.asOptional().equals(getTarget().getAlarms())) {
            this.alarms = newValue;
        }
        return self();
    }

    /**
     * @param packet New "packet" synchronization category stamp value.
     */
    public NeSynchronizationMutationDescriptor setPacket(long packet) {
        final ClearableOptional<Long> newValue = ClearableOptional.of(packet);
        if (!newValue.asOptional().equals(getTarget().getPacket())) {
            this.packet = newValue;
        }
        return self();
    }

    /**
     * Clears all counter values.
     */
    public NeSynchronizationMutationDescriptor clearCounters() {
        all = ClearableOptional.clear();
        alarms = ClearableOptional.clear();
        packet = ClearableOptional.clear();
        return self();
    }
}
