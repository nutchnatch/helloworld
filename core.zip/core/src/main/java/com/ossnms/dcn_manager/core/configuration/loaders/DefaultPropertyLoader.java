package com.ossnms.dcn_manager.core.configuration.loaders;

import com.ossnms.dcn_manager.core.configuration.model.DefaultPropertyValues;
import com.ossnms.dcn_manager.core.jaxb.defaultproperties.Defaults;

import java.net.URL;

public class DefaultPropertyLoader extends ModelLoader<Defaults> {
    public DefaultPropertyValues load(Iterable<URL> filesToLoad) {
        return new DefaultPropertyValues(loadValues(Defaults.class, filesToLoad));
    }
}
