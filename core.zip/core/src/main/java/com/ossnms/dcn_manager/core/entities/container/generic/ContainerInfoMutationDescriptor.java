package com.ossnms.dcn_manager.core.entities.container.generic;

import com.ossnms.dcn_manager.core.entities.container.ContainerInfoMutationDescriptorBase;

import java.util.Optional;

/**
 * Generic DCN container mutation descriptor.
 *
 * @see ContainerInfo
 */
public class ContainerInfoMutationDescriptor
        extends ContainerInfoMutationDescriptorBase<ContainerInfo, ContainerInfoMutationDescriptor> {

    /**
     * Creates a new object.
     *
     * @param target Business object instance that represents the object to be modified.
     */
    public ContainerInfoMutationDescriptor(ContainerInfo target) {
        super(target);
    }

    @Override
    protected ContainerInfoMutationDescriptor self() {
        return this;
    }

    @Override
    protected ContainerInfo doApply() {
        return getName().isPresent() || getParentId().isPresent() || getDescription().isPresent() || getUserText().isPresent()
                ? new ContainerInfo(getTarget().getId(), getTarget().getVersion() + 1,
                getParentId().map(Optional::of).orElse(getTarget().getParentId()),
                getName().orElse(getTarget().getName()),
                getDescription().map(Optional::of).orElse(getTarget().getDescription()),
                getUserText().map(Optional::of).orElse(getTarget().getUserText()))
                : getTarget();
    }

}
