package com.ossnms.dcn_manager.core.configuration.properties;


/**
 * Contains constants with the names of "well known" EM/NE property names
 * as mentioned in the user interface description files.
 */
public final class WellKnownSettingsPropertyNames {

    public static final String RETRY_MEDIATOR = "RetryMediator";
    public static final String RETRY_CHANNEL = "RetryChannel";
    public static final String RETRY_NE = "RetryNe";
    public static final String RETRY_INTERVAL = "TimeIntervalForScheduler";
    public static final String USER_TEXT = "Subtitle";
    public static final String DESCRIPTION = "Description";
    public static final String SCALED_STARTUP_LIMIT = "GlobalScheduleStartup";
    public static final String DISCOVERY_POLICY = "DiscoveryPolicy";
    public static final String ENABLE_SCHEDULED_STARTUP = "ActiveScheduleStartup";
    public static final String ENABLE_NATIVE_NE_NAMING = "NativeNeNaming";
    public static final String DEFAULT_CONTAINER_NAME = "DefaultContainerName";

    private WellKnownSettingsPropertyNames() {

    }

}
