package com.ossnms.dcn_manager.core.policies;

import com.ossnms.dcn_manager.core.events.ne.IdentifiedNeEvent;
import com.ossnms.dcn_manager.core.policies.common.BoundedExecutor.Signaller;
import com.ossnms.dcn_manager.core.policies.common.PolicyJob;

import javax.annotation.Nonnull;
import java.util.concurrent.Executor;
import java.util.function.Predicate;

/**
 * <p>Contract to be supported by implementations of policies that are part of the chain
 * that promotes DCN load regulation for NE interactions (e.g., activation and deactivation interactions).
 * Individual nodes of the chain may, internally, use different DCN partitioning approaches.</p>
 *
 * <p>Operations that return NE interaction metrics (e.g. {@link #getPendingJobCount()}) are
 * merely informative and are not required to produce exact counts. This relaxation is important because
 * it enables the use of optimistic approaches to concurrency. Note that using pessimistic approaches would
 * be overkill because software components that would use those values to make decisions regarding interaction
 * regulation, would be broken by definition; check-and-act races would be inevitable. It is therefore the
 * job of {@link NetworkElementInteractionManagerStage} implementations to make those decisions.</p>
 */
public interface NetworkElementInteractionManagerStage extends Executor, PartitionedJobsInfo {

	/**
	 * Removes all (if any) NE interaction jobs for which the given predicate applies from any job scheduling partition.
     * @param cancelationSelector the predicate to be used to select the job to be unscheduled.
     */
	void unscheduleNeInteraction(Predicate<PolicyJob<? extends IdentifiedNeEvent>> cancelationSelector);

	/**
     * Informs that the NE interaction has ended.The interaction for which completion is signaled is
     * selected by using the received predicate and may be related to any partition.
     * Notice that this operation searches all partitions until a matching ongoing interaction is
     * found.
     * @param interactionSelector The predicate used to select the interaction whose completion is
     * to be signaled.
     */
	void onNeInteractionEnded(@Nonnull Predicate<PolicyJob<? extends IdentifiedNeEvent>> interactionSelector);

    /**
     * Signals the occurrence of an event that may be of interest to work items.
     * Notice that this operation searches all partitions until a matching ongoing interaction is
     * found.
     * @param signaller The signal instance.
     */
    boolean onEvent(@Nonnull Signaller<PolicyJob<? extends IdentifiedNeEvent>> signaller);

    /**
     * Sets the maximum number of allowed simultaneous jobs (i.e. NE interactions) for the given partition.
     * This configuration change may not have immediate effect, meaning, ongoing jobs will not be cancelled.
     * @param partitionId The partition identifier.
     * @param newMaxInteractions The new maximum number of allowed simultaneous jobs.
     * @throws IllegalArgumentException If {@literal newMaxInteractions} is not greater
     * than 0.
     */
    void setMaxOngoingJobCount(int partitionId, int newMaxInteractions);
}
