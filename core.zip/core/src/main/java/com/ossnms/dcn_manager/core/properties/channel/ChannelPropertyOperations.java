package com.ossnms.dcn_manager.core.properties.channel;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.core.properties.EntityProperty;

class ChannelPropertyOperations
    extends EntityProperty {

    protected ChannelPropertyOperations(@Nonnull String name) {
        super(name);
    }

}