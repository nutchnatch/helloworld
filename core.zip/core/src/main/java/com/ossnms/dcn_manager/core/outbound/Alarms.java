package com.ossnms.dcn_manager.core.outbound;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Manages alarms associated with objects managed by our component.
 */
public interface Alarms {

    /**
     * Raises an alarm reporting a problem with the NE actual activation state.
     *
     * @param neId NE identifier.
     * @param description Alarm description.
     * @return Whether if it was possible to raise the alarm.
     */
    boolean raiseConnectionLost(int neId, @Nonnull Optional<String> description);

    /**
     * Clears an existing alarm related with the actual NE activation state.
     *
     * @param neId NE identifier.
     * @param forceSynchronizationWithFault flag indicating if we should force the synchronization with fault
     * @return Whether it was possible to clear the alarm.
     */
    boolean clearConnectionLost(int neId, boolean forceSynchronizationWithFault);
}
