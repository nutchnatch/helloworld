package com.ossnms.dcn_manager.core.events;

public interface Event {

}
