package com.ossnms.dcn_manager.core.storage.ne;

import com.mysema.query.collections.CollQuery;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData.NePhysicalConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.QNePhysicalConnectionData;
import com.ossnms.dcn_manager.core.storage.BusinessObjectRepository;

/**
 * Contract to be supported by all repositories of physical connection information against
 * NEs when accessed through different Mediator servers.
 */
public interface NePhysicalConnectionRepository
    extends BusinessObjectRepository<NePhysicalConnectionData, NePhysicalConnectionMutationDescriptor> {

    CollQuery query(QNePhysicalConnectionData neConnection);

    /**
     * Inserts information about a physical NE connection in the repository.
     * @param initialConnectionData Initial domain object data.
     * @param neId The logical NE identifier this connection is related to.
     * @param channelInstanceId Identifier of the physical Channel that manages this physical NE.
     * @return The newly inserted NE connection information.
     */
    NePhysicalConnectionData insert(NePhysicalConnectionInitialData initialConnectionData, int neId, int channelInstanceId);

    /**
     * Retrieves all physical NE connection information related to a logical NE instance.
     * @param logicalNeId Logical NE identifier.
     * @return All physical NE connection information found.
     */
    Iterable<NePhysicalConnectionData> queryAll(int logicalNeId);

    /**
     * Deletes physical NE connection information from the repository.
     * @param instanceId Physical NE connection identifier.
     */
    void remove(int instanceId);
}
