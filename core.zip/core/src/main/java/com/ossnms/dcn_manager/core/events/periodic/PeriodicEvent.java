package com.ossnms.dcn_manager.core.events.periodic;

import com.ossnms.dcn_manager.core.events.Event;

/**
 * This event represents something that happens periodically. :-)
 */
public abstract class PeriodicEvent implements Event {

}
