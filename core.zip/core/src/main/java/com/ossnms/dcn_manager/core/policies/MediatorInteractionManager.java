package com.ossnms.dcn_manager.core.policies;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.ActivateMediatorEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.DeactivateMediatorEvent;

/**
 * <p>Contract to be supported by classes that implement mediator interaction management policies, 
 * whose instances are responsible for managing interactions between the component and mediation 
 * (i.e. through Connection Manager). The goal of such policies is to regulate DCN load imposed 
 * by those interactions, in particular, between the component and multiple instances of mediation.</p>
 * 
 * <p>Although it is not expected that multiple policy implementations coexist, the definition of this interface
 * enables the complete characterization of the provided service without compromising concrete implementations
 * with lifetime management issues imposed by connectors.<p>
 * 
 * <p>Operations that return mediation interaction metrics (e.g. {@link #getPendingJobCount()}) are 
 * merely informative and are not required to produce exact counts. This relaxation is important because 
 * it enables the use of optimistic approaches to concurrency. Note that using pessimistic approaches would 
 * be overkill because software components that would use those values to make decisions regarding interaction
 * regulation, would be broken by definition: check-and-act races would be inevitable. It is therefore the 
 * job of {@link MediatorInteractionManager} implementations to make those decisions.</p>  
*/
public interface MediatorInteractionManager {

    /**
     * Schedules the actual activation of the mediator whose activation has just been marked as required.
     * @param event The event bearing the relevant information.
     */
    void scheduleActivation(@Nonnull final ActivateMediatorEvent event);

    /**
     * Schedules the actual deactivation of the mediator whose deactivation as just been marked as required.
     * @param event The event bearing the relevant information.
     */
    void scheduleDeactivation(@Nonnull final DeactivateMediatorEvent event);

    /**
     * Informs that a mediator interaction has ended.
     * @param mediatorStateEvent Event information.
     */
    void onMediatorInteractionEnded(@Nonnull ActualMediatorStateEvent mediatorStateEvent);

    /**
     * @return The number of pending jobs (activation and deactivation interactions).
     */
    int getPendingJobCount();

    /**
     * @return The number of ongoing jobs (activation and deactivation interactions).
     */
    int getOngoingJobCount();

    /**
     * @return The maximum number of allowed simultaneous jobs (i.e. mediator interactions).
     */
    int getMaxOngoingJobCount();

    /**
     * Sets the maximum number of allowed simultaneous jobs (i.e. mediator interactions). This
     * configuration change may not have immediate effect, meaning, ongoing jobs will not be cancelled.
     * @param newMaxInteractions The new maximum number of allowed simultaneous jobs.
     * @throws IllegalArgumentException If {@literal newMaxInteractions} is not greater
     * than {@value 0}.
     */
    void setMaxOngoingJobCount(int newMaxInteractions);

    /**
     * close all resources
     *
     */
    void close();
}
