package com.ossnms.dcn_manager.core.entities.ne.data.types;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.google.common.base.MoreObjects;

public final class TpGroupSettings implements Serializable {

    private static final long serialVersionUID = 7312918194890790842L;

    private final boolean alwaysCompatible;
    private final boolean multipleGroupMembership;
    private final boolean subgroupsMustBeEqual;
    private final boolean multipleSubgroupMembership;

    public TpGroupSettings(boolean alwaysCompatible, boolean multipleGroupMembership,
            boolean subgroupsMustBeEqual, boolean multipleSubgroupMembership) {
        this.alwaysCompatible = alwaysCompatible;
        this.multipleGroupMembership = multipleGroupMembership;
        this.subgroupsMustBeEqual = subgroupsMustBeEqual;
        this.multipleSubgroupMembership = multipleSubgroupMembership;
    }

    /**
     * <p>If true, then all Tps of this NE may be regarded as interconnectible, whithout performing further checks.</p><p>This flag should be set to true if either there are really no connection limitations in this NE (non-blocking swicth fabric),
       or if the connection limitations are simply unknown (e.g. TMF interface does not model this)</p>
     */
    public boolean isAlwaysCompatible() {
        return alwaysCompatible;
    }

    /**
     * If true, then a Tp may belong to more than one group.
       The group ids are in this case given by the position of one-bits in the Tp's GroupId attribute, having masked-out all sub-group-id bits.
       The maximum number of groups with multiple membership is therefore 64.
       If the flag is not set, then a TP may only belong to one group.
     */
    public boolean isMultipleGroupMembership() {
        return multipleGroupMembership;
    }

    /**
     * This flag defines whether the subgroup id of two Tps must be equal for the Tps to be connectable.
       If false, then the subgroup id of two Tps must be different for the Tps to be connectable.
     */
    public boolean isSubgroupsMustBeEqual() {
        return subgroupsMustBeEqual;
    }

    /**
     * If true, then a Tp may belong to more than one sub-group.
       The sub-group ids are in this case given by the position of one-bits in the Tp's GroupId attribute, having masked-out all group-id bits.
       The maximum number of sub-groups with multiple membership is therefore 64.
       If the flag is not set, then a TP may only belong to one sub-group.
     */
    public boolean isMultipleSubgroupMembership() {
        return multipleSubgroupMembership;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
            .add("alwaysCompatible", alwaysCompatible)
            .add("multipleGroupMembership", multipleGroupMembership)
            .add("subgroupsMustBeEqual", subgroupsMustBeEqual)
            .add("multipleSubgroupMembership", multipleSubgroupMembership)
            .toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(alwaysCompatible)
            .append(multipleGroupMembership)
            .append(subgroupsMustBeEqual)
            .append(multipleSubgroupMembership)
            .toHashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || o.getClass() != getClass()) {
            return false;
        }
        if (o == this) {
            return true;
        }
        final TpGroupSettings rhs = (TpGroupSettings) o;
        return new EqualsBuilder()
            .append(alwaysCompatible, rhs.alwaysCompatible)
            .append(multipleGroupMembership, rhs.multipleGroupMembership)
            .append(subgroupsMustBeEqual, rhs.subgroupsMustBeEqual)
            .append(multipleSubgroupMembership, rhs.multipleSubgroupMembership)
            .isEquals();
    }
}