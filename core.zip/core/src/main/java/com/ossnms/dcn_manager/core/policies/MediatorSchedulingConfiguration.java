package com.ossnms.dcn_manager.core.policies;

/**
 * Configures job scheduling per mediator, i.e., the number of jobs that
 * may be executing simultaneously against specific mediators.
 *
 * Also provides access to runtime information about the job load on all
 * mediators.
 */
public interface MediatorSchedulingConfiguration {

    /**
     * @return The number of pending jobs, regardless of the Channel partition.
     */
    int getPendingMediatorJobCount();

    /**
     * @return The number of ongoing jobs regardless of the Channel partition.
     */
    int getOngoingMediatorJobCount();

    /**
     * Sets the maximum allowed number of simultaneous work items in the execution queue
     * associated to the given mediator. This configuration change may not have immediate
     * effect, meaning, ongoing work items will not be cancelled.
     * @param mediatorId The mediator identifier.
     * @param maximumOngoingJobCount The new maximum number of allowed simultaneous work items.
     * @throws IllegalArgumentException If {@literal maximumOngoingJobCount} is not greater
     * than {@value 0}.
     */
    void setMaxOngoingMediatorJobCount(int mediatorId, int maximumOngoingJobCount);

    /**
     * Informs the scheduler that a mediator has been removed from the system.
     * This allows to release any resources that may be held in connection with the
     * mediator.
     * @param mediatorId The mediator identifier.
     */
    void onMediatorRemoved(int mediatorId);
}
