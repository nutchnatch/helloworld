package com.ossnms.dcn_manager.core.entities.mediator.data;

import com.ossnms.dcn_manager.core.entities.PropertyBag;

import java.util.Map;
import java.util.Optional;

/**
 * Aggregator class for all objects part of the Mediator object domain.
 * Note that it implements {@link PropertyBag} to fulfill restrictions
 * imposed by the properties view, even though additional properties
 * are not supported.
 */
public final class MediatorEntity implements PropertyBag {

    private final MediatorInfoData info;
    private final MediatorConnectionData connection;

    public MediatorEntity(MediatorInfoData info, MediatorConnectionData connection) {
        this.info = info;
        this.connection = connection;
    }

    /**
     * @return Mediator identification and information related.
     */
    public MediatorInfoData getInfo() {
        return info;
    }

    /**
     * @return Actual connection/activation status.
     */
    public MediatorConnectionData getConnection() {
        return connection;
    }

    @Override
    public Optional<String> getOpaqueProperty(String name) {
        return info.getOpaqueProperty(name);
    }

    @Override
    public Map<String, String> getAllOpaqueProperties() {
        return info.getAllOpaqueProperties();
    }

}
