package com.ossnms.dcn_manager.core.configuration.model;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.annotation.Nonnull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableBiMap.Builder;
import com.google.common.collect.Maps;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNeDataTransferPropertyNames;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.jaxb.netype.Attribute;
import com.ossnms.dcn_manager.core.jaxb.netype.Config;
import com.ossnms.dcn_manager.core.jaxb.netype.DataTransferSettings;
import com.ossnms.dcn_manager.core.jaxb.netype.DoNotUpdateOnDiscovery;
import com.ossnms.dcn_manager.core.jaxb.netype.Mappings;
import com.ossnms.dcn_manager.core.jaxb.netype.NeAdditionalTypeInfoControl;
import com.ossnms.dcn_manager.core.jaxb.netype.NeIdentificationControl;
import com.ossnms.dcn_manager.core.jaxb.netype.Properties;
import com.ossnms.dcn_manager.core.jaxb.netype.Route;
import com.ossnms.dcn_manager.core.jaxb.type.PropertyPageFiles;
import com.ossnms.dcn_manager.core.jaxb.type.TypeProperties;

/**
 * Provides the description of an DCN Manager NE Type.
 */
public class NeType extends Type {

    private static final Logger LOGGER = LoggerFactory.getLogger(NeType.class);

    private final Config configuration;
    private final BiMap<String, String> propertyMapping;
    private final Map<String, Attribute> gatewayRouteAttributes;
    private final Map<String, Attribute> directRouteAttributes;
    private final BiMap<String, String> dataTransferSettings;
    private final BiMap<String, String> neIdentificationControl;
    private final BiMap<String, String> additionalTypeInfoControl;

    /**
     * Creates a new object.
     * @param configuration Deserialized XML configuration.
     * @param defaultPropertyValues All default property values known by
 *  EM/NE. They will be filtered according to the EM Type configuration.
     */
    public NeType(Config configuration, @Nonnull DefaultPropertyValues defaultPropertyValues) {
        super(defaultPropertyValues);
        this.configuration = configuration;
        propertyMapping = readPropertyMapping(this.configuration);
        gatewayRouteAttributes = readGatewayRouteAttributes(this.configuration);
        directRouteAttributes = readDirectRouteAttributes(this.configuration);
        dataTransferSettings = readDataTransferSettings(this.configuration);
        neIdentificationControl = readNeIdentificationControl(this.configuration);
        additionalTypeInfoControl = readAdditionalTypeInfoControl(this.configuration);
        
        LOGGER.debug("{} property mapping: {}", this.configuration.getName(), propertyMapping);
        LOGGER.debug("{} gateway route attributes: {}", this.configuration.getName(), gatewayRouteAttributes);
        LOGGER.debug("{} direct route attributes: {}", this.configuration.getName(), directRouteAttributes);
        LOGGER.debug("{} dataTransferSettings mapping: {}", this.configuration.getName(), dataTransferSettings);
        LOGGER.debug("{} neIdentificationControl mapping: {}", this.configuration.getName(), neIdentificationControl);
        LOGGER.debug("{} additionalTypeInfoControl mapping: {}", this.configuration.getName(), additionalTypeInfoControl);
    }

    private Map<String, Attribute> readGatewayRouteAttributes(Config config) {
        final Properties properties = config.getProperties();
        final Route route = properties != null ? properties.getGatewayRoute() : null;
        if (null == route) {
            LOGGER.warn("No gateway route attribute information for NE Type {}.", config.getName());
        }
        return readRouteAttributes(route);
    }

    private Map<String, Attribute> readDirectRouteAttributes(Config config) {
        final Properties properties = config.getProperties();
        final Route route = properties != null ? properties.getDirectRoute() : null;
        if (null == route) {
            LOGGER.warn("No direct route attribute information for NE Type {}.", config.getName());
        }
        return readRouteAttributes(route);
    }

    
    private Map<String, Attribute> readRouteAttributes(final Route route) {
        final List<Attribute> attributes = route != null ? route.getAttribute() : Collections.<Attribute>emptyList();
        return Maps.uniqueIndex(attributes, input -> null != input ? input.getName() : null);
    }

    private BiMap<String, String> readPropertyMapping(Config config) {
        final Builder<String,String> builder = ImmutableBiMap.<String, String>builder();
        final Properties properties = config.getProperties();
        final Mappings mappings = properties != null ? properties.getMappings() : null;
        if (null != mappings) {
            putIfValid(builder, WellKnownNePropertyNames.USES_GNE, mappings.getUsesGne());
            putIfValid(builder, WellKnownNePropertyNames.USES_FLAT_IP, mappings.getUsesFlatIp());
            putIfValid(builder, WellKnownNePropertyNames.RECONNECT_INTERVAL, mappings.getReconnectInterval());
            putIfValid(builder, WellKnownNePropertyNames.USER_NAME, mappings.getUserName());
            putIfValid(builder, WellKnownNePropertyNames.USER_PASSWORD, mappings.getUserPassword());
            putIfValid(builder, WellKnownNePropertyNames.USE_DEFAULT_ROUTE_SORTING, mappings.getUseDefaultOrder());
        } else {
            LOGGER.warn("No property mapping found for NE Type {}.", config.getName());
        }
        return builder.build();
    }

    private BiMap<String, String> readDataTransferSettings(Config config) {
        final Builder<String,String> builder = ImmutableBiMap.<String, String>builder();
        final Properties properties = config.getProperties();
        final DataTransferSettings dataTransfer = properties != null ? properties.getDataTransferSettings() : null;
        if (null != dataTransfer) {
            putIfValid(builder, WellKnownNeDataTransferPropertyNames.USERNAME,     dataTransfer.getUserName());
            putIfValid(builder, WellKnownNeDataTransferPropertyNames.PASSWORD,     dataTransfer.getPassword());
            putIfValid(builder, WellKnownNeDataTransferPropertyNames.UPLOADPATH,   dataTransfer.getPath());
            putIfValid(builder, WellKnownNeDataTransferPropertyNames.IP_ADDRESS,   dataTransfer.getIp());
            putIfValid(builder, WellKnownNeDataTransferPropertyNames.IS_SCP,       dataTransfer.getIsSCP());
            putIfValid(builder, WellKnownNeDataTransferPropertyNames.IS_FTP,       dataTransfer.getIsFTP());
            putIfValid(builder, WellKnownNeDataTransferPropertyNames.PROFILE_NAME, dataTransfer.getProfileName());
        } else {
            LOGGER.warn("No property dataTransferSettings found for NE Type {}.", config.getName());
        }
        return builder.build();
    }

    private BiMap<String, String> readNeIdentificationControl(Config config) {
        final Builder<String,String> builder = ImmutableBiMap.builder();
        final Properties properties = config.getProperties();
        final NeIdentificationControl neIdentification = properties != null ? properties.getNeIdentificationControl() : null;
        if (null != neIdentification) {
            putIfValid(builder, WellKnownNePropertyNames.NEIGHBOURHOOD_ID, neIdentification.getNeighbourhoodId());
        } else {
            LOGGER.warn("No property NeIdentificationControl found for NE Type {}.", config.getName());
        }
        return builder.build();
    }

    private BiMap<String, String> readAdditionalTypeInfoControl(Config config) {
        final Builder<String,String> builder = ImmutableBiMap.builder();
        final Properties properties = config.getProperties();
        final NeAdditionalTypeInfoControl neAdditionalTypeInfo = properties != null ? properties.getNeAdditionalTypeInfoControl() : null;
        if (null != neAdditionalTypeInfo) {
            putIfValid(builder, WellKnownNePropertyNames.ADDITIONAL_TYPE_INFO, neAdditionalTypeInfo.getAdditionalTypeInfo());
        } else {
            LOGGER.warn("No property NeAdditionalTypeInfoControl found for NE Type {}.", config.getName());
        }
        return builder.build();
    }

    
    /** @return The NE Type name. */
    @Override
    public String getName() {
        return configuration.getName();
    }

    /** @return The layers supported by this NE Type (bit set). */
    public String  getSupportedLayers() {
        return getPropertyValue("SUPPORTED_LAYERS");
    }

    /** @return The NE Type capabilities (bit set). */
    public String  getCapabilities() {
        return getPropertyValue("CAPABILITIES");
    }

    /** @return Network scope name. Groups NEs that are related. Does not necessarily relate to the BCB Family.
     * Is used for matching NE names on discovery, for example. */
    public String getNetworkScope() {
        return configuration.getNetworkScope();
    }

    /**
     * @return A map with direct route attribute metadata.
     */
    public Map<String, Attribute> getDirectRouteAttributes() {
        return directRouteAttributes;
    }

    /**
     * @return A scripted value which defines how the Direct Route Key is constructed from NE property values.
     */
    public Optional<String> getDirectRouteAddressKeySource() {
        final Properties properties = configuration.getProperties();
        final Route directRoute = properties != null ? properties.getDirectRoute() : null;
        return Optional.ofNullable(directRoute != null ? directRoute.getAddressKey() : null);
    }

    /**
     * @return A map with gateway route attribute metadata.
     */
    public Map<String, Attribute> getGatewayRouteAttributes() {
        return gatewayRouteAttributes;
    }

    /**
     * @return A scripted value which defines how each Gateway Route Key is constructed from NE property values.
     */
    public Optional<String> getGatewayRouteAddressKeySource() {
        final Properties properties = configuration.getProperties();
        final Route gatewayRoute = properties != null ? properties.getGatewayRoute() : null;
        return Optional.ofNullable(gatewayRoute != null ? gatewayRoute.getAddressKey() : null);
    }

    /**
     * Given a property name as it is defined for a specific NE Type,
     * produce the normalized internal name. If no normalization
     * exists, return the original name.
     *
     * @param name NE property name.
     * @return Normalized name or the original name if no normalization exists.
     */
    @Override
    public String mapIncomingPropertyName(String name) {
        String mappedName = propertyMapping.inverse().getOrDefault(name, dataTransferSettings.inverse().get(name));
        return mappedName != null ? mappedName : name;
    }

    /**
     * Given a normalized property name, produce the name as it is
     * defined for a specific NE Type. If no specialization exists,
     * return the original name.
     *
     * @param name Normalized property name.
     * @return NE name or the original name if no specialization exists.
     */
    @Override
    public String mapOutgoingPropertyName(String name) {
        String mappedName = propertyMapping.getOrDefault(name, dataTransferSettings.get(name));
        return mappedName != null ? mappedName : name;
    }

    /**
     * @return The default network icon name.
     */
    @Nonnull
    public String getDefaultIcon() {
        return configuration.getDefaultIcon().getName();
    }

    /**
     * @return A string with the name of the main communications protocol used by this NE type.
     */
    public String getProtocol() {
        return getPropertyValue("PROTOCOL");
    }

    @Override
    protected TypeProperties getSupportedTypeProperties() {
        return configuration.getTypeProperties();
    }

    @Override
    protected PropertyPageFiles getSupportedPropertyFiles() {
        return configuration.getPropertyPageFiles();
    }

    public BiMap<String, String> getIdentificationControlMap() {
        return neIdentificationControl;
    }

    public BiMap<String, String> getAdditionalTypeInfoControlMap() {
        return additionalTypeInfoControl;
    }


    /**
     * A list of property names that are to be ignored if ever sent by mediation inside a Network Element
     * Discovered notification, iif this notification will be used to update an already managed Network Element.
     * This list does not apply if a new Network Element will be created instead.
     * @return A list of property names.
     */
    public List<String> getPropertyNamesToIgnoreOnDiscoveryUpdates() {
        final Properties properties = configuration.getProperties();
        final DoNotUpdateOnDiscovery onDiscovery = null != properties ? properties.getDoNotUpdateOnDiscovery() : null;
        return onDiscovery != null ? onDiscovery.getPropertyName() : Collections.emptyList();
    }

    public Map<String, String> getDataTransferSettings() {
        return dataTransferSettings;
    }
}
