package com.ossnms.dcn_manager.core.outbound;

import com.ossnms.dcn_manager.core.entities.container.system.SystemInfo;
import com.ossnms.dcn_manager.core.entities.container.system.SystemInfoMutationDescriptor;

/**
 * Describes an API for sending notifications to other components about
 * system container deletion, creation and modification.
 */
public interface SystemNotifications {

    /**
     * Notifies other components that a system has been deleted.
     * @param system The deleted system container.
     */
    void notifyDelete(SystemInfo system);

    /**
     * Notifies other components that a system has been created.
     * @param system The new system container.
     */
    void notifyCreate(SystemInfo system);

    /**
     * Notifies other components that a system has been changed.
     *
     * @param changes Changes applied to the system.
     */
    void notifyChanges(SystemInfoMutationDescriptor changes);
}
