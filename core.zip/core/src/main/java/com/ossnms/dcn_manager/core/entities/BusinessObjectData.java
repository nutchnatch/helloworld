package com.ossnms.dcn_manager.core.entities;

import com.google.common.base.Function;
import com.mysema.query.annotations.QueryEntity;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.concurrent.Immutable;
import javax.persistence.Id;
import javax.persistence.Version;
import java.util.Objects;

/**
 * <p>Base class for the data dimension of all domain objects.</p>
 *
 * <p>Domain objects' identity is materialized as an integer value, thus enabling
 * persistent storage. This means that multiple Java objects may refer to the same
 * domain object instance (i.e. they will have the same id value). </p>
 *
 * <p>Domain objects are also versioned, meaning, each instance has an associated
 * version number which is used to trivially compute equivalence and to easily identify
 * concurrent operations.</p>
 *
 * Canonical methods (i.e. {@link #hashCode()} and {@link #equals(Object)}) have the
 * following semantics:
 * <ul>
 * <li>two instances are equivalent if they have the same identifier and version
 * number;</li>
 * <li>{@link #hashCode()} value is obtained directly from the domain object's identifier.
 * This approach has the merit of reducing the computational cost of the operation at the
 * expense of, eventually, reducing the function's dispersion factor if we choose to
 * store multiple versions of the same domain object. </li>
 * </ul>
 */
@QueryEntity
@Immutable
public abstract class BusinessObjectData {

	/** The version number*/
    @Version
	private final int versionNumber;

	/** The integer value which identifies the domain object */
	@Id
	private final int id;

	/**
	 * Initiates an instance with the given identifier and version number.
	 *
	 * @param id The instance's identifier
	 * @param version The instance's version number
	 */
	protected BusinessObjectData(int id, int version) {
		versionNumber = version;
		this.id = id;
	}

	/** {@inheritDoc} */
	@Override
	public int hashCode() {
		return Objects.hash(id, versionNumber);
	}

	/**
	 * Compares for equality (i.e. equivalence) the specified object with this instance.
	 * Two instances are considered equivalent if they are of the same concrete type and
	 * they have the same identifier and version number values.
	 *
	 * @param theOther The object to be compared for equality with this one.
     * @return  {@code true} if this object is equivalent to {@code theOther} argument,
     * {@code false} otherwise.
	 */
	@Override
	public boolean equals(Object theOther) {
	    if (this == theOther) {
	        return true;
	    }
		if (theOther == null || !getClass().isInstance(theOther)) {
			return false;
		}

		final BusinessObjectData other = (BusinessObjectData) theOther;
		return id == other.id && versionNumber == other.versionNumber;
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
        final ToStringBuilder helper = new ToStringBuilder(this);
        helper.append("id", getId());
        helper.append("version_number", getVersion());
        return helper.toString();
	}

	/**
	 * @return The instance's identifier
	 */
	public int getId() {
		return id;
	}

	/**
	 * @return The instance's version number
	 */
	public int getVersion() {
		return versionNumber;
	}

    public static final Function<BusinessObjectData, Integer> GET_ID =
			input -> null != input ? input.getId() : null;

}

