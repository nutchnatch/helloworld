
/**
 * Contains all definitions necessary to represent the full set of NE
 * domain objects.
 */
/*
 * @startuml doc-files/ne-entities-class.png
 * class NeEntity <<immutable>> {
 * }
 * class NeConnectionData <<immutable>> {
 *  + neId
 *  + activationState
 *  + additionalInfo
 *  + connectedVia
 *  + initStartTime
 *  + retryCounter
 * }
 * class NeDirectRouteData <<immutable>> {
 * }
 * class NeInfoData <<immutable>> {
 *  + neId
 *  + channelId
 *  + commsLostAlarmRaised
 *  + coreId
 *  + iconId
 *  + proxyType
 *  + requiredActivationState
 *  + usedBy
 * }
 * class NeOperationData <<immutable>> {
 *  + neId
 *  + ...
 * }
 * class NeUserPreferencesData <<immutable>> {
 *  + neId
 *  + containerId
 *  + globalId
 *  + idName
 *  + userName
 *  + password
 *  + reconnectInterval
 *  + routeSortingMode
 *  + usesGne
 * }
 * class NeSynchronizationData <<immutable>> {
 *  + neId
 *  + neInstanceId
 *  + alarms
 *  + packet
 *  + all
 * }
 * NeConnectionData "1" --* NeEntity
 * NeInfoData "1" --* NeEntity
 * NeOperationData "1" --* NeEntity
 * NeDirectRouteData "0..1" --* NeUserPreferencesData
 * NeUserPreferencesData "1" --* NeEntity
 * NeSynchronizationData "1" --* NeEntity
 * class NeInstance <<immutable>> {
 * }
 * class NePhysicalConnectionData <<immutable>> {
 *  + neId
 *  + neInstanceId
 *  + channelInstanceId
 *  + active
 *  + activationState
 *  + additionalInfo
 * }
 * NeInstance *-- "1" NePhysicalConnectionData
 * NeEntity *.. "1..n" NeInstance : Indirect relation\nthrough separate\nrepository.
 * @enduml
 */
package com.ossnms.dcn_manager.core.entities.ne;

