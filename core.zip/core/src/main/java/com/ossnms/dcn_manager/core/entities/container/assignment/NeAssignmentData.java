package com.ossnms.dcn_manager.core.entities.container.assignment;

import com.ossnms.dcn_manager.core.entities.container.generic.ContainerInfo;
import org.apache.commons.lang3.builder.EqualsBuilder;

import java.util.Objects;

/**
 * Contains information about a Network Element x Container association.
 * Only one association must be a primary assignment.
 * @see AssignmentType#PRIMARY
 */
public class NeAssignmentData extends AssignmentBase {
    private final int neId;

    public NeAssignmentData(final ContainerInfo containerInfo, final int neId, final AssignmentType assignmentType) {
        super(containerInfo, assignmentType);
        this.neId = neId;
    }

    public int getNeId() {
        return neId;
    }

    @Override public int hashCode() {
        return Objects.hash(getContainerInfo().getId(), neId);
    }

    @Override public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (null == obj || !getClass().equals(obj.getClass())) {
            return false;
        }
        final NeAssignmentData rhs = (NeAssignmentData) obj;
        return new EqualsBuilder()
                .append(getContainerInfo().getId(), rhs.getContainerInfo().getId())
                .append(neId, rhs.neId)
                .isEquals();
    }
}
