package com.ossnms.dcn_manager.core.storage;

import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import com.ossnms.dcn_manager.core.storage.uow.UowContext;
import com.ossnms.dcn_manager.exceptions.RepositoryException;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * <p>Contract to be supported by all domain object repositories. Notice the
 * absence of creation and deletion operations. This is due to the need to ensure
 * that these operations can only be performed through the repository that contains
 * the domain entity (i.e. the concrete domain object's aggregate).</p>
 *
 * @param <T> The domain object concrete type
 * @param <M> The domain object's mutation descriptor concrete type
 */
public interface BusinessObjectRepository<T extends BusinessObjectData, M extends MutationDescriptor<T, M>> {

    /**
     * Gets the domain object with the given identifier, if one exists
     *
     * @param id The domain object identifier.
     * @return An {@link Optional} instance bearing the domain object, or an
     * absent {@link Optional} if no domain object exists with the given
     * identifier.
     * @throws RepositoryException When an error occurs while working with the
     *                             underlying data storage.
     */
    Optional<T> query(int id) throws RepositoryException;

    /**
     * Gets the sequence composed of all domain objects. Note that the sequence
     * may be implemented using a lazy technique, meaning, the produced sequence
     * does not require that domain object instances are all simultaneously held
     * in volatile memory.
     *
     * @return An {@link Iterable} representing the sequence
     * @throws RepositoryException When an error occurs while working with the
     *                             underlying data storage.
     */
    Iterable<T> queryAll() throws RepositoryException;

    /**
     * Conditionally updates the domain object with the given mutation. The mutation
     * is only deemed successful if the Domain Object instance has not been concurrently
     * modified. Concurrent modifications are detected through versioning, thereby
     * enabling optimistic concurrency control.
     * <p>
     * The mutation continuation callback is called after a successful change.
     *
     * @param mutation The object that describes the mutation to be applied
     * @return An {@link Optional} bearing the mutation result, if it succeeded,
     * or an absent {@link Optional} if the mutation failed
     * @throws RepositoryException When an error occurs while working with the
     *                             underlying data storage.
     */
    Optional<T> tryUpdate(M mutation) throws RepositoryException;

    /**
     * Conditionally updates the domain object with the given mutation. The mutation
     * is only deemed successful if the Domain Object instance has not been concurrently
     * modified. Concurrent modifications are detected through versioning, thereby
     * enabling optimistic concurrency control.
     * <p>
     * Because this method is intended for usage within a Unit of Work, the mutation
     * continuation callback is not called immediately. Instead, the Unit of Work manager
     * is reponsible for handling continuations.
     *
     * @param context  Unit of Work execution context.
     * @param mutation The object that describes the mutation to be applied
     * @return An {@link Optional} bearing the mutation result, if it succeeded,
     * or an absent {@link Optional} if the mutation failed
     */
	Optional<T> tryUpdate(@Nonnull UowContext context, @Nonnull M mutation);
}
