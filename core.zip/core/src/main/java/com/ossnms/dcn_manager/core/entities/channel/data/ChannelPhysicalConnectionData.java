package com.ossnms.dcn_manager.core.entities.channel.data;

import com.google.common.base.MoreObjects;
import com.google.common.base.MoreObjects.ToStringHelper;
import com.mysema.query.annotations.QueryEntity;
import com.ossnms.dcn_manager.core.entities.BusinessObjectData;

/**
 * <p> Class that implements the data dimension of the domain object that describes the channel's
 * PHYSICAL connection state or, in other words, the solution's real connectivity to the given
 * channel. </p>
 *
 * <p>As all types that implement domain objects' data dimension, instances of this class are immutable,
 * and are therefore thread-safe.</p>
 */
@QueryEntity
public final class ChannelPhysicalConnectionData extends BusinessObjectData {

    /** Identifier of the logical Channel, which is the actual object managed by the solution. */
    private final int channelId;

    /**
     *  Whether this is the Active Channel instance, within the context of redundancy
     *  (Active vs. Standby).
     */
    private final boolean active;

    /** Identifier of the physical Mediator that manages this physical Channel. */
    private final int mediatorInstanceId;

    /** Actual connection state. */
    private final ActualActivationState activation;

    /** Annotation information associated to the channel's connection state. */
    private final String additionalInfo;

    /**
     * Initiates an instance with the given initial data.
     * @param channelInstanceId The domain object identifier (i.e. the same as its domain entity instance)
     * @param mediatorInstanceId Identifier of the physical Mediator that manages this physical Channel.
     * @param channelId The domain object identifier (i.e. the same as its domain entity instance)
     * @param version The domain object's version number
     * @param prototype Initial instance data.
     */
    public ChannelPhysicalConnectionData(int channelInstanceId, int mediatorInstanceId, int channelId, int version, ChannelPhysicalConnectionPrototype<?> prototype) {
        super(channelInstanceId, version);
        this.channelId = channelId;
        this.mediatorInstanceId = mediatorInstanceId;
        this.activation = prototype.activation;
        this.additionalInfo = prototype.additionalInfo;
        this.active = prototype.active;
    }

    /** @return The actual activation state. This means that the connection to the mediator and the actual channel is alive. */
    public ActualActivationState getActualActivationState() {
        return activation;
    }

    /** @return User-friendly state description. */
    public String getAdditionalInfo() {
        return additionalInfo;
    }

    /** @return A boolean value indicating whether the channel is currently connected to the mediator */
    public boolean isStateActive() {
        return activation == ActualActivationState.ACTIVE;
    }

    /**
     * @return Identifier of the logical Channel, which is the actual object managed by the solution.
     */
    public int getLogicalChannelId() {
        return channelId;
    }

    /**
     * @return Identifier of the physical Mediator that manages this physical Channel.
     */
    public int getMediatorInstanceId() {
        return mediatorInstanceId;
    }

    /**
     * @return Whether this is the Active Channel instance, within the context of redundancy
     *  (Active vs. Standby).
     */
    public boolean isActive() {
        return active;
    }

    /** {@inheritDoc} */
	@Override
	public String toString() {
        final ToStringHelper helper = MoreObjects.toStringHelper(this);
        helper.addValue(super.toString());
        helper.add("channelId", getLogicalChannelId());
        helper.add("active", isActive());
        helper.add("activation_state", getActualActivationState());
        helper.add("additional_info", getAdditionalInfo());
        return helper.toString();
	}

    /**
     * Facilitates the creation of a data object by allowing
     * individual attributes to be set easily.
     */
    public static final class ChannelPhysicalConnectionBuilder extends ChannelPhysicalConnectionPrototype<ChannelPhysicalConnectionBuilder> {

        /**
         * Creates a new instance with values defined in this builder object.
         * @param channelInstanceId The Physical Channel ID.
         * @param mediatorInstanceId Identifier of the physical Mediator that manages this physical Channel.
         * @param logicalChannelId The Logical Channel ID.
         * @param version The new instances' version number.
         * @return A new instance of {@link ChannelPhysicalConnectionData}.
         */
        public ChannelPhysicalConnectionData build(int channelInstanceId, int mediatorInstanceId, int logicalChannelId, int version) {
            return new ChannelPhysicalConnectionData(channelInstanceId, mediatorInstanceId, logicalChannelId, version, this);
        }

        @Override
        protected ChannelPhysicalConnectionBuilder self() {
            return this;
        }

    }

    /**
     * Contains initial data values for the data object (it's a parameter object).
     */
	public static final class ChannelConnectionInitialData extends ChannelPhysicalConnectionPrototype<ChannelConnectionInitialData> {

        @Override
        protected ChannelConnectionInitialData self() {
            return this;
        }

	}

	private abstract static class ChannelPhysicalConnectionPrototype<T extends ChannelPhysicalConnectionPrototype<T>> {

	    private ActualActivationState activation = ActualActivationState.INACTIVE;
	    private String additionalInfo = "";
	    private boolean active;

	    protected ChannelPhysicalConnectionPrototype() {

	    }

	    protected abstract T self();

        /**
         * @param activation The actual activation state.
         */
        public T setActivation(ActualActivationState activation) {
            this.activation = activation;
            return self();
        }

        /**
         * @param additionalInfo Annotation information associated with the channel's connection state.
         */
        public T setAdditionalInfo(String additionalInfo) {
            this.additionalInfo = additionalInfo;
            return self();
        }

        /**
         * @param active Whether this is the Active Channel instance, within the context of redundancy
         * (Active vs. Standby).
         */
        public T setActive(boolean active) {
            this.active = active;
            return self();
        }
	}
}
