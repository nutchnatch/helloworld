package com.ossnms.dcn_manager.core.properties.mediator;

import com.ossnms.dcn_manager.core.configuration.properties.WellKnownMediatorPropertyNames;
import com.ossnms.dcn_manager.core.properties.EntityPropertyOperations;

/**
 * Contains well known mediator property names as mentioned in the user interface description files.
 * Is also able to manage property retrieval from a merged set of Mediator Type and Mediator Instance
 * (Mediator entity) properties.
 */
public enum MediatorProperty implements EntityPropertyOperations {
    ID_NAME(new MediatorPropertyOperations(WellKnownMediatorPropertyNames.ID_NAME)),
    DESCRIPTION(new MediatorPropertyOperations(WellKnownMediatorPropertyNames.DESCRIPTION)),
    RECONNECT_INTERVAL(new MediatorPropertyOperations(WellKnownMediatorPropertyNames.RECONNECT_INTERVAL)),
    CONCURRENT_ACTIVATIONS_LIMITED(new MediatorPropertyOperations(WellKnownMediatorPropertyNames.CONCURRENT_ACTIVATIONS_LIMITED)),
    CONCURRENT_ACTIVATIONS_LIMIT(new MediatorPropertyOperations(WellKnownMediatorPropertyNames.CONCURRENT_ACTIVATIONS_LIMIT)),
    USER_TEXT(new MediatorPropertyOperations(WellKnownMediatorPropertyNames.USER_TEXT));

    private final MediatorPropertyOperations delegate;

    private MediatorProperty(MediatorPropertyOperations delegate) {
        this.delegate = delegate;
    }

    @Override
    public String getName() {
        return delegate.getName();
    }

    @Override
    public Scope getScope() {
        return delegate.getScope();
    }

}
