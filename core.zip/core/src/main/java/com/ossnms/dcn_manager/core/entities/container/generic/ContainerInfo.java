package com.ossnms.dcn_manager.core.entities.container.generic;

import com.ossnms.dcn_manager.core.entities.container.ContainerInfoBase;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Contains information about a DCN Container. DCN Containers represent a logical grouping
 * of NEs in the management system. They may also group other containers.
 */
public final class ContainerInfo extends ContainerInfoBase {

    /**
     * Creates a new object.
     * @param containerId Numeric system identifier.
     * @param version Object version.
     * @param containerName Container name. Must not be empty.
     * @throws IllegalArgumentException If the name is null or empty.
     */
    public ContainerInfo(int containerId, int version, @Nonnull String containerName) {
        super(containerId, version, containerName);
    }

    /**
     * Creates a new object.
     * @param containerId Numeric system identifier.
     * @param version Object version.
     * @param parentId Parent container identifier. Must be positive.
     * @param containerName Container name. Must not be empty.
     * @param description Human readable description.
     * @throws IllegalArgumentException If the name is null or empty.
     */
    public ContainerInfo(int containerId, int version, @Nonnull Optional<Integer> parentId,
                         @Nonnull String containerName, @Nonnull Optional<String> description, @Nonnull Optional<String> userText) {
        super(containerId, version, parentId, containerName, description, userText);
    }
}
