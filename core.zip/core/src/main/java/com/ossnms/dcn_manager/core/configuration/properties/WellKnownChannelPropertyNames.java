package com.ossnms.dcn_manager.core.configuration.properties;


/**
 * Contains constants with the names of "well known" Channel Type properties, i.e.,
 * properties that are required to be present in Channel Type XML files.
 */
public final class WellKnownChannelPropertyNames {

    public static final String ID_NAME = "BCB-Attribute/EM/idName";
    public static final String DISPLAY_ADDRESS = "display-address-rule";
    public static final String RECONNECT_INTERVAL = "BCB-Attribute/EM/ReconnectInterval";
    public static final String CONCURRENT_ACTIVATIONS_LIMITED = "Enable_Scaled_Startup";
    public static final String CONCURRENT_ACTIVATIONS_LIMIT = "BCB-Attribute/EM/ScheduledStartup";
    public static final String USER_TEXT = "UserText";

    private WellKnownChannelPropertyNames() {

    }

}
