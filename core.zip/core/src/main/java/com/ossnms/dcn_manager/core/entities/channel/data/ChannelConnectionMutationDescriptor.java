package com.ossnms.dcn_manager.core.entities.channel.data;

import com.google.common.base.MoreObjects;
import com.google.common.base.MoreObjects.ToStringHelper;
import com.google.common.base.Objects;
import com.ossnms.dcn_manager.core.entities.MutationDescriptor;
import com.ossnms.dcn_manager.core.entities.channel.data.ChannelConnectionData.ChannelConnectionBuilder;

import javax.annotation.Nonnull;
import java.util.Optional;

/**
 * Describes a mutation request that should be applied to the connection state
 * of a given channel. Will contain only the new data to store.
 */
public class ChannelConnectionMutationDescriptor extends MutationDescriptor<ChannelConnectionData, ChannelConnectionMutationDescriptor> {

	/** The channel's new connection state */
	private Optional<ActualActivationState> connection;

	/** The channel's new additional info */
	private Optional<String> additionalInfo;

	/**
	 * Initiates an instance that will be used to mutate the given domain object instance
	 * @param target the domain object instance to which the mutation will be applied
	 */
    public ChannelConnectionMutationDescriptor(@Nonnull ChannelConnectionData target) {
		super(target);
		connection = Optional.empty();
		additionalInfo = Optional.empty();
	}

    /** @return an {@link Optional<Boolean>} instance with the mutation's actual activation state */
    public Optional<ActualActivationState> getActualActivationState() {
        return connection;
    }

    /**
     * Sets the mutation's actual activation state.
     * @param connection The new activation state.
     * @return The mutation instance, to enable fluent use.
     */
    public ChannelConnectionMutationDescriptor setConnection(ActualActivationState connection) {
        final Optional<ActualActivationState> newValue = Optional.of(connection);
        if (!Objects.equal(this.connection, newValue)) {
            this.connection = newValue;
        }
        return this;
    }

    /** @return an {@link Optional<Boolean>} instance with the mutation's additional info */
    public Optional<String> getAdditionalInfo() {
        return additionalInfo;
    }

    /**
     * Sets the mutation's additional info.
     * @param additionalInfo The new additional info.
     * @return The mutation instance, to enable fluent use.
     */
    public ChannelConnectionMutationDescriptor setAdditionalInfo(String additionalInfo) {
        final Optional<String> newValue = Optional.ofNullable(additionalInfo);
        if (!Objects.equal(this.additionalInfo, newValue)) {
            this.additionalInfo = newValue;
        }
        return this;
    }

    /** {@inheritDoc} */
	@Override
	protected ChannelConnectionMutationDescriptor self() {
		return this;
	}

    /** {@inheritDoc} */
	@Override
	protected ChannelConnectionData doApply() {
		final ChannelConnectionData target = getTarget();
		return !connection.isPresent() && !additionalInfo.isPresent() ? target :
			new ChannelConnectionBuilder()
		        .setActivation(connection.orElse(target.getActualActivationState()))
		        .setAdditionalInfo(additionalInfo.orElse(target.getAdditionalInfo()))
		        .build(target.getId(), target.getVersion() + 1);
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		final ToStringHelper helper = MoreObjects.toStringHelper(this);
        helper.addValue(super.toString());
		if (connection.isPresent()) {
			helper.add("connected", connection.get());
		}
		if (additionalInfo.isPresent()) {
			helper.add("additionalInfo", additionalInfo.get());
		}
		return helper.toString();
	}
}
