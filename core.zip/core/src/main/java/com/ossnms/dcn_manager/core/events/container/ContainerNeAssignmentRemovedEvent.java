package com.ossnms.dcn_manager.core.events.container;

/**
 * Base class for events that affect a container.
 */
public class ContainerNeAssignmentRemovedEvent extends ContainerEvent {

    private final int neId;

    /**
     * Creates a new object.
     *
     * @param containerId The affected container ID.
     */
    public ContainerNeAssignmentRemovedEvent(int containerId, int neId) {
        super(containerId);
        this.neId = neId;
    }

    public int getContainerId() { return getEntityId(); }

    public int getNeId() {
        return neId;
    }
}
