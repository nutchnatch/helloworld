package com.ossnms.dcn_manager.core.properties.ne;

import com.ossnms.dcn_manager.core.entities.PropertyBag;
import com.ossnms.dcn_manager.core.entities.ne.data.NeDataTransferSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySource;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.RouteSortingMode;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class NePropertySourceWithFallback implements NePropertySource {

    private final class NePreferencesPropertySourceWithFallback
            implements NePreferencesPropertySource {

        private final NePreferencesPropertySource preferencesFallback = fallback.getPreferences();

        @Override
        public Optional<String> getOpaqueProperty(String name) {
            return Optional.ofNullable(source.getProperties().get(name)).map(Optional::of).orElse(preferencesFallback.getOpaqueProperty(name));
        }

        @Override
        public Map<String, String> getAllOpaqueProperties() {
            final HashMap<String, String> properties = new HashMap<>();
            properties.putAll(preferencesFallback.getAllOpaqueProperties());
            properties.putAll(source.getProperties());
            return properties;
        }

        @Override
        public boolean usesGne() {
            return source.getUsesGne().orElse(preferencesFallback.usesGne());
        }

        @Override public boolean usesFlatIp() {
            return source.getUsesFlatIp().orElse(preferencesFallback.usesFlatIp());
        }

        @Override
        public Optional<String> getUserName() {
            return source.getUserName().map(Optional::of).orElse(preferencesFallback.getUserName());
        }

        @Override
        public RouteSortingMode getRouteSortingMode() {
            return source.getRouteSortingMode().orElse(preferencesFallback.getRouteSortingMode());
        }

        @Override
        public int getReconnectInterval() {
            return source.getReconnectInterval().orElse(preferencesFallback.getReconnectInterval());
        }

        @Override
        public Optional<String> getPassword() {
            return source.getPassword().map(Optional::of).orElse(preferencesFallback.getPassword());
        }

        @Override
        public String getName() {
            return source.getName().orElse(preferencesFallback.getName());
        }

        @Override
        public Optional<String> getGlobalId() {
            return source.getGlobalId().map(Optional::of).orElse(preferencesFallback.getGlobalId());
        }

        @Override
        public PropertyBag getDirectRoute() {
            return preferencesFallback.getDirectRoute();
        }

        @Override
        public NeDataTransferSettings getDataTransferSettings() {
            return preferencesFallback.getDataTransferSettings();
        }

        @Override
        public Optional<String> getUserText() {
            return preferencesFallback.getUserText();
        }
    }

    private final NeUserPreferencesMutationDescriptor source;
    private final NePropertySource fallback;
    private final NePreferencesPropertySourceWithFallback nePreferencesPropertySourceWithFallback;

    public NePropertySourceWithFallback(NeUserPreferencesMutationDescriptor source, NePropertySource fallback) {
        this.source = source;
        this.fallback = fallback;
        nePreferencesPropertySourceWithFallback = new NePreferencesPropertySourceWithFallback();
    }

    @Override
    public Optional<String> getOpaqueProperty(String name) {
        return Optional.ofNullable(source.getProperties().get(name)).map(Optional::of).orElse(fallback.getOpaqueProperty(name));
    }

    @Override
    public Map<String, String> getAllOpaqueProperties() {
        final HashMap<String, String> properties = new HashMap<>();
        properties.putAll(fallback.getAllOpaqueProperties());
        properties.putAll(source.getProperties());
        return properties;
    }

    @Override
    public NePreferencesPropertySource getPreferences() {
        return nePreferencesPropertySourceWithFallback;
    }

    @Override
    public NeInfoPropertySource getInfo() {
        return fallback.getInfo();
    }

    @Override
    public NeOperationPropertySource getOperation() {
        return fallback.getOperation();
    }

}
