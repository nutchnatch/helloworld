package com.ossnms.dcn_manager.exceptions;


/**
 * DcnManagerException thrown by repositories when an error occurs.
 * @see DcnManagerException
 */
public class RepositoryException extends DcnManagerException {

    private static final long serialVersionUID = -6927775173048496950L;

    /** @see DcnManagerException#DcnManagerException() */
    public RepositoryException() {

    }

    /** @see DcnManagerException#DcnManagerException(String) */
    public RepositoryException(String message) {
        super(message);
    }

    /** @see DcnManagerException#DcnManagerException(Throwable) */
    public RepositoryException(Throwable cause) {
        super(cause);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable) */
    public RepositoryException(String message, Throwable cause) {
        super(message, cause);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable,boolean,boolean) */
    public RepositoryException(String message, Throwable cause, boolean enableSuppression,
            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /** @see DcnManagerException#DcnManagerException(String,Object[]) */
    public RepositoryException(String format, Object... formatParameters) {
        super(format, formatParameters);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable,Object[]) */
    public RepositoryException(String format, Throwable cause, Object... formatParameters) {
        super(format, cause, formatParameters);
    }
}
