package com.ossnms.dcn_manager.core.storage.mediator;

import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorInstance;

/**
 * Contains all mediator instance creations and updates done during a composite update.
 * @see MediatorInstanceEntityRepository#updateInstance(int, Iterable, Iterable)
 */
public final class MediatorInstanceUpdates {

    private final Iterable<MediatorInstance> updatedInstances;
    private final Iterable<MediatorInstance> createdInstances;

    /**
     * Initializes a new object.
     * @param updatedInstances Mediator instances updated.
     * @param createdInstances Mediator instances created.
     */
    public MediatorInstanceUpdates(Iterable<MediatorInstance> updatedInstances,
            Iterable<MediatorInstance> createdInstances) {
        this.updatedInstances = updatedInstances;
        this.createdInstances = createdInstances;
    }

    /**
     * @return The updated mediator instances.
     */
    public Iterable<MediatorInstance> getUpdatedInstances() {
        return updatedInstances;
    }

    /**
     * @return The created mediator instances.
     */
    public Iterable<MediatorInstance> getCreatedInstances() {
        return createdInstances;
    }
}
