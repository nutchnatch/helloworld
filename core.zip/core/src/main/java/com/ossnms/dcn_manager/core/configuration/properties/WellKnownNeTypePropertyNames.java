package com.ossnms.dcn_manager.core.configuration.properties;


/**
 * Contains constants with the names of "well known" NE Type properties, i.e.,
 * properties that are required to be present in NE Type XML files.
 */
public final class WellKnownNeTypePropertyNames {

    public static final String DISPLAY_ADDRESS = "display-address-rule";
    public static final String GLOBAL_NE_ID = "global-ne-id-rule";
    public static final String CAPABILITIES = "CAPABILITIES";
    public static final String SUPPORTED_LAYERS = "SUPPORTED_LAYERS";
    public static final String SECURITY_POLICY = "SECURITY_POLICY";

    private WellKnownNeTypePropertyNames() {

    }

}
