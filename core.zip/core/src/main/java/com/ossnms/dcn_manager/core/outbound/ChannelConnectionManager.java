package com.ossnms.dcn_manager.core.outbound;

import java.util.Map;

import javax.annotation.Nonnull;

import com.ossnms.dcn_manager.core.outbound.exception.ConnectException;

/**
 * Manages the Channels connections..
 *
 * TODO: Review...
 */
public interface ChannelConnectionManager {

    /**
     * <p>Connects the channel.</p>
     *
     * <p>This is an asynchronous operation. Its result will be reported under the form
     * of a channel event.</p>
     *
     * @param channelId Target channel identifier.
     */
    void connect(int channelId);

    /**
     * <p>Disconnects the channel.</p>
     *
     * <p>This is an asynchronous operation. Its result will be reported under the form
     * of a channel event.</p>
     *
     * @param channelId Target channel identifier.
     */
    void disconnect(int channelId);

    /**
     * Sends a set of changed property values to the mediator.
     *
     * @param context Call context.
     * @param channelId Channel identifier.
     * @param properties A map of properties to send.
     * @throws ConnectException Should an error occur while communicating with the mediator
     * or south-bound components.
     */
    void updateChannelProperties(int channelId, @Nonnull Map<String, String> properties)  throws ConnectException;
}
