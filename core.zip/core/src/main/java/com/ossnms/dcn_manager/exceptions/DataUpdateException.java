package com.ossnms.dcn_manager.exceptions;

/**
 * Thrown when it was not possible to update a domain object.
 */
public class DataUpdateException extends DcnManagerException {

    private static final long serialVersionUID = -4062129733975571048L;

    /** @see DcnManagerException#DcnManagerException() */
    public DataUpdateException() {

    }

    /** @see DcnManagerException#DcnManagerException(String) */
    public DataUpdateException(String message) {
        super(message);
    }

    /** @see DcnManagerException#DcnManagerException(Throwable) */
    public DataUpdateException(Throwable cause) {
        super(cause);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable) */
    public DataUpdateException(String message, Throwable cause) {
        super(message, cause);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable,boolean,boolean) */
    public DataUpdateException(String message, Throwable cause, boolean enableSuppression,
            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /** @see DcnManagerException#DcnManagerException(String,Object[]) */
    public DataUpdateException(String format, Object... formatParameters) {
        super(format, formatParameters);
    }

    /** @see DcnManagerException#DcnManagerException(String,Throwable,Object[]) */
    public DataUpdateException(String format, Throwable cause, Object... formatParameters) {
        super(format, cause, formatParameters);
    }

}
