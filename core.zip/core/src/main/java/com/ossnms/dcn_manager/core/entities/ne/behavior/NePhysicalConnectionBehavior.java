package com.ossnms.dcn_manager.core.entities.ne.behavior;

import com.google.common.base.Strings;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePhysicalConnectionMutationDescriptor;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.ActualActivationState;
import com.ossnms.dcn_manager.core.events.ne.ActualNeStateEvent.*;
import com.ossnms.dcn_manager.core.events.ne.NeSynchronizationEvent;
import com.ossnms.dcn_manager.core.events.ne.PhysicalNeStateEvent.*;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Activate;
import com.ossnms.dcn_manager.core.events.ne.RequiredNeStateEvent.Deactivate;
import com.ossnms.dcn_manager.core.outbound.NetworkElementNotifications;
import com.ossnms.dcn_manager.core.policies.NetworkElementInteractionManager;
import com.ossnms.dcn_manager.i18n.Message;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.time.Instant;
import java.util.Optional;

import static com.ossnms.dcn_manager.i18n.T.tr;

/**
 * <p>Class that implements the behavior dimension of the domain object that describes the volatile
 * NE state or, in other words, the NEs' actual activation state. </p>
 *
 * <p>The implementation is based on the State Machine design pattern to deal with required activation
 * state transitions. The state machine is depicted in the following figure. Notice that the
 * representation of start and end states is merely illustrative of the expected flow: NEs
 * are originally created in the deactivated state. State transitions are triggered by the depicted
 * domain object operations. </p>
 *
 * <p><figure>
 * <img src="doc-files/neConnection_actual_activation_state-state.png">
 * <figcaption>State diagram of the actual activation state state machine</figcaption>
 * </figure></p>
 *
 * <p> The state machine is materialized in the following class hierarchy, only relevant to the domain
 * object implementation. For this reason the hierarchy is implemented as a set of static nested
 * classes not accessible from the outside. This solution has the merit of reducing overall
 * complexity (i.e. reducing the number of top-level classes) at the expense of increasing
 * file level complexity (i.e. its size). Nevertheless, and considering the actual file size, the
 * tradeoff is positive. In the case that the current file size increases, this approach must be
 * reevaluated. </p>
 *
 * <p> <figure>
 * <img src="doc-files/neConnection_actual_activation_state-class.png">
 * <figcaption>Class diagram of the actual activation state hierarchy</figcaption>
 * </figure> </p>
 *
 * <ul> Design decisions:
 * <li> Each state transition is materialized in an independent method,
 * to be overridden in concrete state classes; </li>
 * <li> Invalid transitions are signaled by producing an absent {@link Optional} instance,
 * instead of throwing an exception. Note that the exact reaction to an invalid
 * transition depends on the specific use case, and therefore throwing an exception
 * would be inappropriate; </li>
 * <li> Transitions are not applied on the on the domain object instance, due to its
 * immutable nature. Instead, state transitions produce a description of the resulting
 * mutation, which will be later applied on the repository. </li>
 * <li> Transitions may have side effects that depend on the actual state implementation. </li>
 * </ul>
 *
 * <p> As all types that implement domain objects' behavior dimension, this class instances are
 * not thread-safe, and therefore cannot be shared by multiple threads without explicit synchronization.
 * </p>
 */
/*
 * @startuml doc-files/neConnection_actual_activation_state-state.png
 * [*] --> Inactive
 * Inactive --> StartingUp : startUp
 * StartingUp --> Failed : setFailed
 * StartingUp --> Inactive : shutDown
 * StartingUp --> Connecting : setConnecting
 * Connecting --> Connected : setConnected
 * Connecting --> Failed : setFailed
 * Connecting --> ShuttingDown : shutdown
 * Connected --> Initializing : setInitializing
 * Connected --> Failed : setFailed
 * Connected --> Failed : setDisconnecting
 * Connected --> ShuttingDown : shutdown
 * Initializing --> Active : setInitialized
 * Initializing --> Failed : setFailed
 * Initializing --> ShuttingDown : shutdown
 * Active --> ShuttingDown : shutdown
 * Active --> Failed : setFailed
 * Active --> Failed : setDisconnecting
 * Active --> Initializing : resynchronize
 * ShuttingDown --> Disconnecting : setDisconnecting
 * Disconnecting --> Inactive : setDisconnected
 * Disconnecting --> Failed : setFailed
 * Failed --> ShuttingDown : shutdown
 * Failed --> StartingUp : startUp
 * Failed --> Connecting : setConnecting
 * Failed --> Initializing : setInitializing
 * Failed --> Failed : setFailed
 * Failed --> Disconnecting : setDisconnecting
 * @enduml
 */
/*
 * @startuml doc-files/neConnection_actual_activation_state-class.png
 * class ActualActivation <<abstract>> {
 *      # setConnected() : Optional<NePhysicalConnectionMutationDescriptor>
 *      # setConnecting() : Optional<NePhysicalConnectionMutationDescriptor>
 *      # setDisconnected() : Optional<NePhysicalConnectionMutationDescriptor>
 *      # setDisconnecting() : Optional<NePhysicalConnectionMutationDescriptor>
 *      # setInitialized() : Optional<NePhysicalConnectionMutationDescriptor>
 *      # setInitializing() : Optional<NePhysicalConnectionMutationDescriptor>
 *      # setFailed() : Optional<NePhysicalConnectionMutationDescriptor>
 *      # startUp() : Optional<NePhysicalConnectionMutationDescriptor>
 *      # shutdown() : Optional<NePhysicalConnectionMutationDescriptor>
 *      # resynchronize() : Optional<NePhysicalConnectionMutationDescriptor>
 *      # restart() : Optional<NePhysicalConnectionMutationDescriptor>
 * }
 * ActualActivation <|-- Connected
 * ActualActivation <|-- Connecting
 * ActualActivation <|-- Disconnected
 * ActualActivation <|-- Disconnecting
 * ActualActivation <|-- Initialized
 * ActualActivation <|-- Initializing
 * ActualActivation <|-- Failed
 * ActualActivation <|-- StartingUp
 * ActualActivation <|-- ShuttingDown
 * hide fields
 * @enduml
 */
public class NePhysicalConnectionBehavior {

    private final NePhysicalConnectionData data;
    private final NetworkElementNotifications notifications;

    /**
     * Creates a new instance.
     *
     * @param data Actual connection state which will be used as a starting point for the state change.
     * @param notifications Outbound NE notifications connector instance.
     */
    public NePhysicalConnectionBehavior(@Nonnull NePhysicalConnectionData data, @Nonnull NetworkElementNotifications notifications) {
        this.data = data;
        this.notifications = notifications;
    }

    /**
     * Attempts to change into the CONNECTING state.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NePhysicalConnectionMutationDescriptor> setConnecting() {
        return behaviorFor(data.getActualActivationState()).connecting();
    }

    /**
     * Attempts to change into the DISCONNECTING state.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NePhysicalConnectionMutationDescriptor> setDisconnecting(@Nonnull NetworkElementInteractionManager activationManager) {
        return behaviorFor(data.getActualActivationState()).disconnecting(activationManager);
    }

    /**
     * Attempts to change into the CONNECTED state.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NePhysicalConnectionMutationDescriptor> setConnected(@Nonnull NetworkElementInteractionManager activationManager,
                                                                                   int channelId, int mediatorId) {
        return behaviorFor(data.getActualActivationState()).connected(activationManager, channelId, mediatorId);
    }

    /**
     * Attempts to change into the DISCONNECTED state.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NePhysicalConnectionMutationDescriptor> setDisconnected(@Nonnull NetworkElementInteractionManager activationManager) {
        return behaviorFor(data.getActualActivationState()).disconnected(activationManager);
    }

    /**
     * Attempts to change into the INITIALIZING state.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NePhysicalConnectionMutationDescriptor> setInitializing() {
        return behaviorFor(data.getActualActivationState()).initializing();
    }

    /**
     * Attempts to change into the INITIALIZED state.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NePhysicalConnectionMutationDescriptor> setInitialized(@Nonnull NetworkElementInteractionManager activationManager) {
        return behaviorFor(data.getActualActivationState()).initialized(activationManager);
    }

    /**
     * Attempts to trigger a resynchronization. This will cause a change into the INITIALIZING state.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NePhysicalConnectionMutationDescriptor> resynchronize(@Nonnull NetworkElementInteractionManager activationManager,
                                                                                    int channelId, int mediatorId) {
        return behaviorFor(data.getActualActivationState()).resynchronize(activationManager, channelId, mediatorId);
    }

    /**
     * Attempts to trigger a restart. This will cause a SHUTDOWN and will set the connection to RESTART mode.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NePhysicalConnectionMutationDescriptor> restart(@Nonnull NetworkElementInteractionManager activationManager,
                                                                              int physicalMediatorId) {
        return behaviorFor(data.getActualActivationState()).shutdown(activationManager, physicalMediatorId).map(mutation -> mutation.setActivationMode(ActualActivationMode.RESTART));
    }

    /**
     * Attempts to change into the STARTINGUP state.
     * Also tries to schedule the actual NE activation.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NePhysicalConnectionMutationDescriptor> startUp(@Nonnull NetworkElementInteractionManager activationManager,
                                                                              int physicalMediatorId) {
        return behaviorFor(data.getActualActivationState()).startUp(activationManager, physicalMediatorId);
    }

    /**
     * Attempts to change into the SHUTTINGDOWN state.
     * Also tries to schedule the actual NE deactivation.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NePhysicalConnectionMutationDescriptor> shutdown(@Nonnull NetworkElementInteractionManager activationManager,
                                                                               int physicalMediatorId) {
        return behaviorFor(data.getActualActivationState()).shutdown(activationManager, physicalMediatorId);
    }

    /**
     * Attempts to change into the FAILED state.
     * @return A mutation descriptor describing the new data,
     *  or an absent value if the change is not possible from the current state.
     */
    public Optional<NePhysicalConnectionMutationDescriptor> setFailed(@Nullable String description,
                                                                                @Nonnull NetworkElementInteractionManager activationManager) {
        return behaviorFor(data.getActualActivationState()).failed(description, activationManager);
    }

    private ActualActivation behaviorFor(ActualActivationState currentState) {
        final ActualActivation behavior;
        switch (currentState) {
        case DISCONNECTED:
            behavior = new Disconnected();
            break;
        case CONNECTING:
            behavior = new Connecting();
            break;
        case CONNECTED:
            behavior = new Connected();
            break;
        case INITIALIZING:
            behavior = new Initializing();
            break;
        case INITIALIZED:
            behavior = new Initialized();
            break;
        case DISCONNECTING:
            behavior = new Disconnecting();
            break;
        case FAILED:
            behavior = new Failed();
            break;
        case STARTUP:
            behavior = new StartingUp();
            break;
        case SHUTDOWN:
            behavior = new ShuttingDown();
            break;
        default:
            throw new IllegalStateException("No behavior found for " + currentState);
        }
        return behavior;
    }

    protected NetworkElementNotifications getNotifications() {
        return notifications;
    }

    private abstract class ActualActivation {

        protected Optional<NePhysicalConnectionMutationDescriptor> connecting() {
            return Optional.empty();
        }

        protected Optional<NePhysicalConnectionMutationDescriptor> disconnecting(@Nonnull NetworkElementInteractionManager activationManager) {
            return Optional.empty();
        }

        protected Optional<NePhysicalConnectionMutationDescriptor> connected(@Nonnull NetworkElementInteractionManager activationManager,
                                                                                       int channelId, int mediatorId) {
            return Optional.empty();
        }

        protected Optional<NePhysicalConnectionMutationDescriptor> disconnected(@Nonnull final NetworkElementInteractionManager activationManager) {
            return Optional.empty();
        }

        protected Optional<NePhysicalConnectionMutationDescriptor> initializing() {
            return Optional.empty();
        }

        protected Optional<NePhysicalConnectionMutationDescriptor> initialized(@Nonnull NetworkElementInteractionManager activationManager) {
            return Optional.empty();
        }

        protected Optional<NePhysicalConnectionMutationDescriptor> resynchronize(@Nonnull NetworkElementInteractionManager activationManager,
                                                                                           final int channelId, int mediatorId) {
            return Optional.empty();
        }

        protected Optional<NePhysicalConnectionMutationDescriptor> failed(@Nullable String description,
                                                                                    @Nonnull NetworkElementInteractionManager activationManager) {
            return Optional.empty();
        }

        protected Optional<NePhysicalConnectionMutationDescriptor> startUp(@Nonnull NetworkElementInteractionManager activationManager,
                                                                                     int physicalMediatorId) {
            return Optional.empty();
        }

        protected Optional<NePhysicalConnectionMutationDescriptor> shutdown(@Nonnull NetworkElementInteractionManager activationManager,
                                                                                      int physicalMediatorId) {
            return Optional.empty();
        }

        NePhysicalConnectionMutationDescriptor buildStateMutationDescriptor(@Nonnull ActualActivationState newState) {
            return new NePhysicalConnectionMutationDescriptor(data)
                .setActivationState(newState)
                .setAdditionalInfo(""); // clear the additional info on state change; actual implementations may set a message later if necessary.
        }

        Optional<NePhysicalConnectionMutationDescriptor> doResynchronize(@Nonnull NetworkElementInteractionManager activationManager, int channelId, int mediatorId) {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.INITIALIZING)
                    .setInitStageStartTime(Instant.MAX) // don't allow expiration, it will be set when initialization starts
                    .whenApplied(in -> {
                        final NeInitializingEvent event = new NeInitializingEvent(in.getResult().getLogicalNeId(),
                                new PhysicalNeInitializingEvent(in.getResult().getId(), in.getResult().getLogicalNeId(), in.getResult().isActive()));
                        getNotifications().notifyChanges(event);
                        final NeSynchronizationEvent synchronizationEvent =
                                new NeSynchronizationEvent(in.getResult().getLogicalNeId(), in.getResult().getId(), channelId, mediatorId, in.getResult().isActive());
                        activationManager.cancelSynchronizations(synchronizationEvent);
                        activationManager.scheduleSynchronization(synchronizationEvent);
                    }));
        }
    }

    private abstract class FailingState extends ActualActivation {

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> failed(@Nullable String description,
                                                                                    @Nonnull final NetworkElementInteractionManager activationManager) {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.FAILED)
                    .setAdditionalInfo(Strings.nullToEmpty(description))
                    .whenApplied(in -> {
                        final NeActivationFailedEvent event = new NeActivationFailedEvent(in.getResult().getLogicalNeId(),
                                new PhysicalNeActivationFailedEvent(in.getResult().getId(), in.getResult().getLogicalNeId(), in.getResult().isActive(),
                                        in.getResult().getAdditionalInfo()),
                                in.getResult().getAdditionalInfo());
                        getNotifications().notifyChanges(event);
                        activationManager.onNeInteractionEnded(event);
                    }));
        }

    }

    private abstract class CancellableState extends FailingState {

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> shutdown(
                @Nonnull final NetworkElementInteractionManager activationManager, final int physicalMediatorId) {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.SHUTDOWN)
                    .setActivationMode(ActualActivationMode.STANDARD)
                    .whenApplied(in -> {
                        final NeShuttingDownEvent event = new NeShuttingDownEvent(in.getResult().getLogicalNeId(),
                                new PhysicalNeShuttingDownEvent(in.getResult().getId(), in.getResult().getLogicalNeId(), in.getResult().isActive()),
                                tr(Message.DEACTIVATION_PENDING));
                        getNotifications().notifyChanges(event);
                        final Deactivate deactivationEvent = new Deactivate(in.getResult().getLogicalNeId(), in.getResult().getChannelInstanceId(), physicalMediatorId,
                                in.getResult().getId(), in.getResult().isActive());
                        activationManager.cancelActivations(deactivationEvent);
                        activationManager.cancelSynchronizations(new NeSynchronizationEvent(in.getResult().getLogicalNeId(), in.getResult().getId(),
                                in.getResult().getChannelInstanceId(), physicalMediatorId, in.getResult().isActive()));
                        activationManager.scheduleDeactivation(deactivationEvent);
                    }));
        }

    }

    private abstract class RestartableState extends FailingState {

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> startUp(@Nonnull NetworkElementInteractionManager activationManager, int mediatorId) {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.STARTUP)
                    .whenApplied(in -> {
                        getNotifications().notifyChanges(new NeStartingUpEvent(in.getResult().getLogicalNeId(),
                                new PhysicalNeStartingUpEvent(in.getResult().getId(), in.getResult().getLogicalNeId(), in.getResult().isActive()),
                                tr(Message.CONNECTION_PENDING)));
                        final Activate activationEvent = new Activate(in.getResult().getLogicalNeId(), in.getResult().getChannelInstanceId(), mediatorId,
                                in.getResult().getId(), in.getResult().isActive());
                        activationManager.cancelDeactivations(activationEvent);
                        activationManager.cancelSynchronizations(new NeSynchronizationEvent(in.getResult().getLogicalNeId(), in.getResult().getId(),
                                in.getResult().getChannelInstanceId(), mediatorId, in.getResult().isActive()));
                        activationManager.scheduleActivation(activationEvent);
                    }));
        }

    }

    private final class Failed extends RestartableState {

        /**
         * {@inheritDoc}
         *
         * <p>Mediations will recover failed NEs automatically, so we need to allow a switch from Failed to Connecting
         * without it going through the scheduler.</p>
         */
        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> connecting() {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.CONNECTING)
                    .whenApplied(in ->
                        getNotifications().notifyChanges(new NeConnectingEvent(in.getResult().getLogicalNeId(),
                                new PhysicalNeConnectingEvent(in.getResult().getId(), in.getResult().getLogicalNeId(), in.getResult().isActive())))
                    ));
        }

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> initializing() {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.INITIALIZING)
                    .whenApplied(in ->
                        getNotifications().notifyChanges(new NeInitializingEvent(in.getResult().getLogicalNeId(),
                                new PhysicalNeInitializingEvent(in.getResult().getId(), in.getResult().getLogicalNeId(), in.getResult().isActive())))
                    ));
            
            
        }

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> shutdown(
                @Nonnull final NetworkElementInteractionManager activationManager, final int physicalMediatorId) {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.SHUTDOWN)
                    .setActivationMode(ActualActivationMode.STANDARD)
                    .whenApplied(in -> {
                        final NeShuttingDownEvent event = new NeShuttingDownEvent(in.getResult().getLogicalNeId(),
                            new PhysicalNeShuttingDownEvent(in.getResult().getId(), in.getResult().getLogicalNeId(), in.getResult().isActive()),
                                    tr(Message.DEACTIVATION_PENDING));
                        getNotifications().notifyChanges(event);
                        final Deactivate deactivationEvent = new Deactivate(in.getResult().getLogicalNeId(), in.getResult().getChannelInstanceId(), physicalMediatorId,
                                in.getResult().getId(), in.getResult().isActive());
                        activationManager.cancelActivations(deactivationEvent);
                        activationManager.cancelSynchronizations(new NeSynchronizationEvent(in.getResult().getLogicalNeId(), in.getResult().getId(),
                                in.getResult().getChannelInstanceId(), physicalMediatorId, in.getResult().isActive()));
                        activationManager.scheduleDeactivation(deactivationEvent);
                    }));
        }
        
        /**
        * {@inheritDoc}
        * 
        *  <p>While shutting down a failed NE and before mediation interaction occurs, mediation can retry connection establishment,
        *  if it fails again state goes back to Failed. So Failed state must be able to properly react to disconnecting events.</p>
        */
        
       @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> disconnecting(@Nonnull NetworkElementInteractionManager activationManager) {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.DISCONNECTING)
                    .whenApplied(in ->
                        getNotifications().notifyChanges(new NeDisconnectingEvent(in.getResult().getLogicalNeId(),
                            new PhysicalNeDisconnectingEvent(in.getResult().getId(), in.getResult().getLogicalNeId(), in.getResult().isActive())))
                    ));
        }
    }

    private final class Disconnected extends ActualActivation {

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> startUp(@Nonnull NetworkElementInteractionManager activationManager, int physicalMediatorId) {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.STARTUP)
                    .whenApplied(in -> {
                        getNotifications().notifyChanges(new NeStartingUpEvent(in.getResult().getLogicalNeId(),
                                new PhysicalNeStartingUpEvent(in.getResult().getId(), in.getResult().getLogicalNeId(), in.getResult().isActive()),
                                tr(Message.CONNECTION_PENDING)));
                        final Activate activationEvent = new Activate(in.getResult().getLogicalNeId(), in.getResult().getChannelInstanceId(), physicalMediatorId,
                                in.getResult().getId(), in.getResult().isActive());
                        activationManager.cancelDeactivations(activationEvent);
                        activationManager.cancelSynchronizations(new NeSynchronizationEvent(in.getResult().getLogicalNeId(), in.getResult().getId(),
                                in.getResult().getChannelInstanceId(), physicalMediatorId, in.getResult().isActive()));
                        activationManager.scheduleActivation(activationEvent);
                    }));
        }

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> connecting() {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.CONNECTING)
                    .whenApplied(in ->
                            getNotifications().notifyChanges(new NeConnectingEvent(in.getResult().getLogicalNeId(),
                                    new PhysicalNeConnectingEvent(in.getResult().getId(), in.getResult().getLogicalNeId(), in.getResult().isActive())))
                    ));
        }

    }

    private final class StartingUp extends FailingState {

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> connecting() {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.CONNECTING)
                    .setActivationMode(ActualActivationMode.STANDARD)
                    .whenApplied(in ->
                        getNotifications().notifyChanges(new NeConnectingEvent(in.getResult().getLogicalNeId(),
                            new PhysicalNeConnectingEvent(in.getResult().getId(), in.getResult().getLogicalNeId(), in.getResult().isActive())))
                    ));
        }

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> shutdown(
                @Nonnull final NetworkElementInteractionManager activationManager, final int physicalMediatorId) {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.DISCONNECTED)
                    .setActivationMode(ActualActivationMode.STANDARD)
                    .whenApplied(in -> {
                        final NePhysicalConnectionData connectionData = in.getResult();
                        final NeDisconnectedEvent actualDesiredStateEvent = new NeDisconnectedEvent(connectionData.getLogicalNeId(),
                                new PhysicalNeDisconnectedEvent(connectionData.getId(), connectionData.getLogicalNeId(), connectionData.isActive()));
                        getNotifications().notifyChanges(actualDesiredStateEvent);
                        if (connectionData.isActive()) {
                            // We need to force a notification on the logical NE as well, since we're cancelling an activation that hasn't even started.
                            getNotifications().notifyChanges(new NeDisconnectedEvent(connectionData.getLogicalNeId()));
                        }
                        // Cancel any pending interactions with this NE.
                        activationManager.cancelActivations(new Deactivate(connectionData.getLogicalNeId(), connectionData.getChannelInstanceId(), physicalMediatorId,
                                connectionData.getId(), in.getResult().isActive()));
                        activationManager.cancelSynchronizations(new NeSynchronizationEvent(connectionData.getLogicalNeId(), connectionData.getId(),
                                connectionData.getChannelInstanceId(), physicalMediatorId, in.getResult().isActive()));
                        // End any jobs that may have slipped into execution and are being cancelled.
                        activationManager.onNeInteractionEnded(actualDesiredStateEvent);
                    }));
        }

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> failed(@Nullable String description, @Nonnull NetworkElementInteractionManager activationManager) {
            return super.failed(description, activationManager)
                    .map(mutation -> mutation.setActivationMode(ActualActivationMode.STANDARD));
        }
    }

    private final class Connecting extends CancellableState {

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> connected(@Nonnull final NetworkElementInteractionManager activationManager,
                                                                                       final int channelId, int mediatorId) {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.CONNECTED)
                    .whenApplied(in -> {
                        getNotifications().notifyChanges(new NeConnectedEvent(in.getResult().getLogicalNeId(),
                                new PhysicalNeConnectedEvent(in.getResult().getId(), in.getResult().getLogicalNeId(), in.getResult().isActive())));
                        activationManager.onNeConnected(new NeSynchronizationEvent(in.getResult().getLogicalNeId(), in.getResult().getId(), channelId,
                                mediatorId, in.getResult().isActive()));
                    }));
        }

    }

    private final class Connected extends CancellableState {

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> initializing() {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.INITIALIZING)
                    .setInitStageStartTime(Instant.now())
                    .whenApplied(in ->
                        getNotifications().notifyChanges(new NeInitializingEvent(in.getResult().getLogicalNeId(),
                            new PhysicalNeInitializingEvent(in.getResult().getId(), in.getResult().getLogicalNeId(), in.getResult().isActive())))
                    ));
        }

        /**
         * Allow mediations to request a transition from Initialized to Disconnecting.
         * As per TNMSCM-8254, this transition is valid in cases of GNE switch back.
         * DCN manager needs to be able to cope with this transition outside the scope of connection shutdown by the user.
         * It will consider these as service interruptions (failures).
         */
        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> disconnecting(@Nonnull NetworkElementInteractionManager activationManager) {
            return failed(tr(Message.CONNECTION_PENDING), activationManager);
        }
    }

    private final class Initializing extends CancellableState {

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> initialized(@Nonnull final NetworkElementInteractionManager activationManager) {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.INITIALIZED)
                    .setRetryCounter(0)
                    .setActivationMode(ActualActivationMode.STANDARD)
                    .whenApplied(in -> {
                        final NeInitializedEvent event = new NeInitializedEvent(in.getResult().getLogicalNeId(),
                                new PhysicalNeInitializedEvent(in.getResult().getId(), in.getResult().getLogicalNeId(), in.getResult().isActive()));
                        getNotifications().notifyChanges(event);
                        activationManager.onNeInteractionEnded(event);
                    }));
        }

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> initializing() {
            // since we're being told that we're initializing, update the start time so the timeout will be as accurate as possible.
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.INITIALIZING)
                    .setInitStageStartTime(Instant.now()));
        }

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> resynchronize(@Nonnull final NetworkElementInteractionManager activationManager,
                                                                                           final int channelId, final int mediatorId) {
            return doResynchronize(activationManager, channelId, mediatorId);
        }

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> failed(@Nullable String description, @Nonnull NetworkElementInteractionManager activationManager) {
            return super.failed(description, activationManager)
                    .map(mutation ->
                            mutation
                                .setActivationMode(ActualActivationMode.INIT_RECOVER)
                                .setInitStageStartTime(Instant.now()));
        }
    }

    private final class Initialized extends CancellableState {

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> resynchronize(@Nonnull final NetworkElementInteractionManager activationManager,
                                                                                           final int channelId, final int mediatorId) {
            return doResynchronize(activationManager, channelId, mediatorId);
        }

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> failed(@Nullable String description, @Nonnull NetworkElementInteractionManager activationManager) {
            return super.failed(description, activationManager)
                    .map(mutation -> mutation.setActivationMode(ActualActivationMode.CONNECT_RECOVER));
        }

        /**
         * Allow mediations to request a transition from Initialized to Disconnecting.
         * As per TNMSCM-8254, this transition is valid in cases of GNE switch back.
         * DCN manager needs to be able to cope with this transition outside the scope of connection shutdown by the user.
         * It will consider these as service interruptions (failures).
         */
        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> disconnecting(@Nonnull NetworkElementInteractionManager activationManager) {
            return failed(tr(Message.CONNECTION_PENDING), activationManager);
        }
    }

    private final class ShuttingDown extends RestartableState {

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> disconnecting(@Nonnull NetworkElementInteractionManager activationManager) {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.DISCONNECTING)
                    .whenApplied(in ->
                        getNotifications().notifyChanges(new NeDisconnectingEvent(in.getResult().getLogicalNeId(),
                            new PhysicalNeDisconnectingEvent(in.getResult().getId(), in.getResult().getLogicalNeId(), in.getResult().isActive())))
                    ));
        }

    }

    private final class Disconnecting extends ActualActivation {

        @Override
        protected Optional<NePhysicalConnectionMutationDescriptor> disconnected(@Nonnull NetworkElementInteractionManager activationManager) {
            return Optional.of(buildStateMutationDescriptor(ActualActivationState.DISCONNECTED)
                    .whenApplied(in -> {
                        final NeDisconnectedEvent event = new NeDisconnectedEvent(in.getResult().getLogicalNeId(),
                                new PhysicalNeDisconnectedEvent(in.getResult().getId(), in.getResult().getLogicalNeId(), in.getResult().isActive()));
                        getNotifications().notifyChanges(event);
                        activationManager.onNeInteractionEnded(event);
                    }));
        }

    }
}
