package com.ossnms.dcn_manager.core.events.domain;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

/**
 * Informs the name of a natural domain that has been added at the NE.
 */
@Immutable
public final class DomainAdded extends DomainEvent {

    private final int neId;
    private final String newDomainName;

    /**
     * Constructs a new object instance.
     * @param neId Identifier of the NE that has received the new natural domain.
     * @param newDomainName New domain name.
     */
    public DomainAdded(int neId, @Nonnull String newDomainName) {
        super(0);
        this.neId = neId;
        this.newDomainName = newDomainName;
    }

    /**
     * @throws IllegalStateException Always. Added domains have not been inserted and have no identifier yet.
     */
    @Override
    public int getDomainId() {
        throw new IllegalStateException();
    }

    /**
     * @return Identifier of the NE that has received the new natural domain.
     */
    public int getNeId() {
        return neId;
    }

    /**
     * @return The new domain name desired.
     */
    public String getNewDomainName() {
        return newDomainName;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("neId", neId)
                .append("newDomainName", newDomainName)
                .toString();
    }

    /** {@inheritDoc} */
    @Override
    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        final DomainAdded rhs = (DomainAdded) obj;
        return new EqualsBuilder()
                .append(neId, rhs.neId)
                .append(newDomainName, rhs.getNewDomainName())
                .isEquals();
    }

    /** {@inheritDoc} */
    @Override
    public int hashCode() {
        return new HashCodeBuilder()
                .append(neId)
                .append(newDomainName)
                .hashCode();
    }
}
