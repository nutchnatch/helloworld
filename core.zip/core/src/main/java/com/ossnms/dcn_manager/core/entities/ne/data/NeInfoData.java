package com.ossnms.dcn_manager.core.entities.ne.data;

import com.google.common.base.MoreObjects;
import com.google.common.base.Strings;
import com.ossnms.dcn_manager.core.entities.BusinessObjectData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySource.NeInfoPropertySource;
import com.ossnms.dcn_manager.core.entities.ne.data.types.RequiredActivationState;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;

import java.util.Optional;

import static com.google.common.base.Preconditions.checkArgument;

/**
 * Persisted information about the NE.
 * It is comprised of its identifying information: IDs,
 * names, etc.
 */
public final class NeInfoData extends BusinessObjectData implements NeInfoPropertySource {

    private final int channelId;
    private final String proxyType;
    private final Optional<String> coreId;
    private final Optional<String> usedBy;
    private final Optional<String> iconId;

    private final RequiredActivationState requiredActivationState;
    private final boolean commsLostAlarmRaised;

    public NeInfoData(int neId, int channelId, int version, @Nonnull NeInfoPrototype<?> prototype) {
        super(neId, version);
        checkArgument(neId > 0, "An NE ID must be defined!");
        checkArgument(channelId > 0, "A parent Channel ID must be defined!");
        checkArgument(!Strings.isNullOrEmpty(prototype.proxyType), "A proxy type must be defined!");
        this.channelId = channelId;
        this.proxyType = prototype.proxyType;
        this.coreId = prototype.coreId;
        this.usedBy = prototype.usedBy;
        this.iconId = prototype.iconId;
        this.requiredActivationState = prototype.requiredActivationState;
        this.commsLostAlarmRaised = prototype.commsLostAlarmRaised;
    }

    /**
     * @return NE identifier.
     */
    public int getNeId() {
        return super.getId();
    }

    /**
     * @return Parent Channel identifier.
     */
    public int getChannelId() {
        return channelId;
    }

    /**
     * @return NE proxy type name.
     */
    @Override
    public String getProxyType() {
        return proxyType;
    }


    /**
     * @return TNMS Core identifier.
     */
    public Optional<String> getCoreId() {
        return coreId;
    }

    /**
     * <p>Represents usage of the NE by other BiCNet components.</p>
     *
     * <p>This is a case of accidental complexity leaking through our layers.
     * We do our best to remain ignorant of this information, which is not
     * relevant to actual NE management.</p>
     *
     * @return NE usage by TNMS components.
     */
    public Optional<String> getUsedBy() {
        return usedBy;
    }

    /**
     * @return NE icon identifier in TNMS.
     */
    public Optional<String> getIconId() {
        return iconId;
    }

    /**
     * @return Whether a loss of communications alarm has been raised.
     */
    public boolean isCommsLostAlarmRaised() {
        return commsLostAlarmRaised;
    }

    /**
     * @return Whether this NE has been activated.
     */
    public boolean isActive() {
        return RequiredActivationState.ACTIVE == requiredActivationState;
    }

    /**
     * @return Required NE activation state.
     */
    public RequiredActivationState getRequiredActivationState() {
        return requiredActivationState;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("channelId", channelId)
                .append("coreId", coreId)
                .append("iconId", iconId)
                .append("proxyType", proxyType)
                .append("usedBy", usedBy)
                .append("commsLostAlarmRaised", commsLostAlarmRaised)
                .append("requiredActivationState", requiredActivationState)
                .toString();
    }

    public static final class NeInfoBuilder extends NeInfoPrototype<NeInfoBuilder> {

        public NeInfoData build(int neId, int channelId, int version) {
            return new NeInfoData(neId, channelId, version, this);
        }

        @Override
        protected NeInfoBuilder self() {
            return this;
        }
    }

    public static final class NeInfoInitialData extends NeInfoPrototype<NeInfoInitialData> implements NeInfoPropertySource {

        @Override
        protected NeInfoInitialData self() {
            return this;
        }

        @Override
        public String getProxyType() {
            return super.proxyType;
        }
    }

    /**
     * Facilitates the creation of a {@link NeInfoData} object by allowing individual attributes
     * to be set easily.
     */
    public abstract static class NeInfoPrototype<T extends NeInfoPrototype<T>> {

        private String proxyType;
        private Optional<String> coreId = Optional.empty();
        private Optional<String> usedBy = Optional.empty();
        private Optional<String> iconId = Optional.empty();
        private Optional<String> userText = Optional.empty();
        private RequiredActivationState requiredActivationState = RequiredActivationState.INACTIVE;
        private boolean commsLostAlarmRaised = false;

        protected NeInfoPrototype() {

        }

        protected NeInfoPrototype(@Nonnull NeInfoPrototype<?> other) {
            proxyType = other.proxyType;
            coreId = other.coreId;
            usedBy = other.usedBy;
            iconId = other.iconId;
            requiredActivationState = other.requiredActivationState;
            commsLostAlarmRaised = other.commsLostAlarmRaised;
            this.userText = other.userText;
        }

        protected abstract T self();

        @Override
        public String toString() {
            return MoreObjects.toStringHelper(this)
                    .add("proxyType", proxyType)
                    .add("coreId", coreId)
                    .add("usedBy", usedBy)
                    .add("iconId", iconId)
                    .add("requiredActivationState", requiredActivationState)
                    .add("commsLostAlarmRaised", commsLostAlarmRaised)
                    .toString();
        }

        /**
         * @param proxyType New NE proxy type name.
         */
        public T setProxyType(String proxyType) {
            this.proxyType = proxyType;
            return self();
        }

        /**
         * @param coreId New TNMS Core identifier.
         */
        public T setCoreId(Optional<String> coreId) {
            this.coreId = coreId;
            return self();
        }

        /**
         * @param usedBy New NE usage by TNMS components.
         */
        public T setUsedBy(Optional<String> usedBy) {
            this.usedBy = usedBy;
            return self();
        }

        /**
         * @param iconId New NE icon identifier in TNMS.
         */
        public T setIconId(Optional<String> iconId) {
            this.iconId = iconId;
            return self();
        }

        /**
         * @param activationState Required NE activation state.
         */
        public T setRequiredActivationState(@Nonnull RequiredActivationState activationState) {
            this.requiredActivationState= activationState;
            return self();
        }

        /**
         * @param commsLostAlarmRaised Whether a loss of communications alarm has been raised.
         */
        public T setCommsLostAlarmRaised(boolean commsLostAlarmRaised) {
            this.commsLostAlarmRaised = commsLostAlarmRaised;
            return self();
        }

        public T setUserText(Optional<String> userText) {
            this.userText = userText;
            return self();
        }
    }

}
