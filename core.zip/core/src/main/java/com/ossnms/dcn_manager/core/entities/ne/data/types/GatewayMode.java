package com.ossnms.dcn_manager.core.entities.ne.data.types;

public enum GatewayMode {
    NONE,
    PRIMARY,
    SECONDARY;
}
