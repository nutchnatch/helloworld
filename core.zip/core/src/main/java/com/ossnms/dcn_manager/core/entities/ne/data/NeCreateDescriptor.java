package com.ossnms.dcn_manager.core.entities.ne.data;

import com.google.common.base.MoreObjects;
import com.google.common.collect.ImmutableMap;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionData.NeConnectionInitialData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData.NeGatewayRouteBuilder;
import com.ossnms.dcn_manager.core.entities.ne.data.NeInfoData.NeInfoInitialData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeOperationData.NeOperationInitialData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeSynchronizationData.NeSynchronizationInitialData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData.NeUserPreferencesInitialData;

import javax.annotation.Nonnull;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Optional;

/**
 * Contains the minimum amount of information necessary to create
 * a new instance of an {@link NeEntity} in the repository.
 */
public final class NeCreateDescriptor implements NePropertySource {

    private final NeType type;
    private final int channelId;

    private final NeConnectionInitialData connection;
    private final NeInfoInitialData info;
    private final NeOperationInitialData operation;
    private final NeUserPreferencesInitialData userPreferences;
    private final NeSynchronizationInitialData synchronization;
    private final Collection<NeGatewayRouteBuilder> gatewayRoutes;

    /**
     * Creates a new descriptor object.
     * @param channelId Parent Channel identifier.
     * @param type NE type name.
     */
    public NeCreateDescriptor(int channelId, NeType type) {
        this.channelId = channelId;
        this.type = type;
        this.connection = new NeConnectionInitialData();
        this.info = new NeInfoInitialData()
                .setProxyType(type.getName())
                .setIconId(Optional.ofNullable(type.getDefaultIcon()));
        this.operation = new NeOperationInitialData();
        this.userPreferences = new NeUserPreferencesInitialData();
        this.synchronization = new NeSynchronizationInitialData();
        this.gatewayRoutes = new LinkedHashSet<>();
    }

    /**
     * @return A mutable collection of gateway route builders that will represent the initial
     *  set of gateway routes for the new NE.
     */
    public Collection<NeGatewayRouteBuilder> getGatewayRoutes() {
        return gatewayRoutes;
    }

    /**
     * Appends gateway routes to the initial set of the new NE gateway routes.
     *
     * @param additionalRoutes Routes to append.
     */
    public NeCreateDescriptor putGatewayRoutes(@Nonnull Collection<NeGatewayRouteBuilder> additionalRoutes) {
        gatewayRoutes.addAll(additionalRoutes);
        return this;
    }

    /**
     * @return A mutable instance of {@link NeConnectionInitialData} that contains
     *  the initial set of actual connection state information for the new NE.
     */
    public NeConnectionInitialData getConnection() {
        return connection;
    }

    /**
     * @return A mutable instance of {@link NeInfoInitialData} that contains
     *  the initial set of basic information for the new NE.
     */
    @Override
    public NeInfoInitialData getInfo() {
        return info;
    }

    /**
     * @return A mutable instance of {@link NeUserPreferencesInitialData} that contains
     *  the initial set of user preferences and properties for the new NE.
     */
    @Override
    public NeUserPreferencesInitialData getPreferences() {
        return userPreferences;
    }

    /**
     * @return A mutable instance of {@link NeOperationInitialData} that contains
     *  the initial set of operational information for the new NE.
     */
    @Override
    public NeOperationInitialData getOperation() {
        return operation;
    }

    /**
     * @return A mutable instance of {@link NeSynchronizationInitialData} that contains
     *  the initial set of synchronization stamps for the new NE.
     */
    public NeSynchronizationInitialData getSynchronization() {
        return synchronization;
    }

    /** @return NE type. */
    public NeType getType() {
        return type;
    }

    /** @return NE type name. */
    public String getTypeName() {
        return type.getName();
    }

    /** @return Parent Channel identifier. */
    public int getChannelId() {
        return channelId;
    }

    /** @return A map of key/value pairs with default property values. */
    public Map<String, String> getDefaultProperties() {
        return type.getSupportedPropertyDefaultValues();
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("channelId", channelId)
                .add("type", type)
                .add("info", info)
                .add("operation", operation)
                .add("connection", connection)
                .add("preferences", userPreferences)
                .add("routes", gatewayRoutes)
                .toString();
    }

    @Override
    public Optional<String> getOpaqueProperty(String name) {
        return getPreferences().getOpaqueProperty(name).map(Optional::of).orElse(getPreferences().getDirectRoute().getOpaqueProperty(name));
    }

    @Override
    public Map<String, String> getAllOpaqueProperties() {
        return ImmutableMap.<String, String>builder()
                .putAll(getPreferences().getAllOpaqueProperties())
                .putAll(getPreferences().getDirectRoute().getAllOpaqueProperties())
                .build();
    }
}
