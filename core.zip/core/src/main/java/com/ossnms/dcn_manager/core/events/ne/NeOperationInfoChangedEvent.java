package com.ossnms.dcn_manager.core.events.ne;

import java.util.Optional;

import javax.annotation.Nonnull;

import com.google.common.base.MoreObjects;
import com.ossnms.dcn_manager.core.entities.ne.data.types.CommissioningMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.GatewayMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.OperationalMode;
import com.ossnms.dcn_manager.core.entities.ne.data.types.TpGroupSettings;
import com.ossnms.dcn_manager.core.entities.ne.data.types.WriteAccessMode;

/**
 * Aggregates information received from mediators regarding NE operational data for later processing.
 */
public class NeOperationInfoChangedEvent extends NeEvent {

    private Optional<GatewayMode> gatewayMode = Optional.empty();
    private Optional<String> realNeName = Optional.empty();
    private Optional<String> neighbourhoodId = Optional.empty();
    private Optional<Boolean> eventForwardingActive = Optional.empty();
    private Optional<Long> tpGroupMask = Optional.empty();
    private Optional<TpGroupSettings> tpGroupMode = Optional.empty();
    private Optional<String> family = Optional.empty();
    private Optional<String> mainRelease = Optional.empty();
    private Optional<String> maintenanceRelease = Optional.empty();
    private Optional<String> neSubType = Optional.empty();
    private Optional<String> neSubTypeDescription = Optional.empty();
    private Optional<String> neType = Optional.empty();
    private Optional<String> neSpecificType = Optional.empty();
    private Optional<OperationalMode> operationalMode = Optional.empty();
    private Optional<WriteAccessMode> writeAccess = Optional.empty();
    private Optional<CommissioningMode> commissioning = Optional.empty();
    private Optional<String> location = Optional.empty();

    /**
     * Creates a new object.
     * @param neId The affected NE ID.
     */
    public NeOperationInfoChangedEvent(int neId) {
        super(neId);
    }

    /**
     * Creates a new object.
     * @param neId The affected NE ID.
     * @param detailedDescription Detailed event description for human consumption.
     */
    public NeOperationInfoChangedEvent(int neId, String detailedDescription) {
        super(neId, detailedDescription);
    }

    /**
     * @return The gateway mode the NE is providing.
     */
    public Optional<GatewayMode> getGatewayMode() {
        return gatewayMode;
    }

    /**
     * @param gatewayMode The new gateway mode
     */
    public NeOperationInfoChangedEvent setGatewayMode(GatewayMode gatewayMode) {
        this.gatewayMode = Optional.of(gatewayMode);
        return this;
    }

    /**
     * @return NE name, as set in the hardware.
     */
    public Optional<String> getRealNeName() {
        return realNeName;
    }

    /**
     * @param realNeName New NE name, as set in the hardware.
     */
    public NeOperationInfoChangedEvent setRealNeName(String realNeName) {
        this.realNeName = Optional.ofNullable(realNeName);
        return this;
    }

    /**
     * @return The new neighbourhoodId , if the NE supports this protocol.
     */
    public Optional<String> getNeighbourhoodId() {
        return neighbourhoodId;
    }

    /**
     * @param neighbourhoodId The new neighbourhoodId, if the NE supports this protocol.
     */
    public NeOperationInfoChangedEvent setNeighbourhoodId(String neighbourhoodId) {
        this.neighbourhoodId = Optional.ofNullable(neighbourhoodId);
        return this;
    }

    /**
     * @return Event forwarding activation status.
     */
    public Optional<Boolean> getEventForwardingActive() {
        return eventForwardingActive;
    }

    /**
     * @param eventForwardingActive New event forwarding activation status.
     */
    public NeOperationInfoChangedEvent setEventForwardingActive(boolean eventForwardingActive) {
        this.eventForwardingActive = Optional.of(eventForwardingActive);
        return this;
    }

    /**
     * @return TP grouping.
     */
    public Optional<Long> getTpGroupMask() {
        return tpGroupMask;
    }

    /**
     * @param tpGroupMask New TP grouping.
     */
    public NeOperationInfoChangedEvent setTpGroupMask(long tpGroupMask) {
        this.tpGroupMask = Optional.of(tpGroupMask);
        return this;
    }

    /**
     * @return TP grouping configuration.
     */
    public Optional<TpGroupSettings> getTpGroupMode() {
        return tpGroupMode;
    }

    /**
     * Changes TP grouping configuration.
     */
    public NeOperationInfoChangedEvent setTpGroupMode(@Nonnull TpGroupSettings tpGroupMode) {
        this.tpGroupMode = Optional.of(tpGroupMode);
        return this;
    }

    /**
     * @return NE family name.
     */
    public Optional<String> getFamily() {
        return family;
    }

    /**
     * @param family New NE family name.
     */
    public NeOperationInfoChangedEvent setFamily(String family) {
        this.family = Optional.ofNullable(family);
        return this;
    }

    /**
     * @return Software main release identifier.
     */
    public Optional<String> getMainRelease() {
        return mainRelease;
    }

    /**
     * @param mainRelease New software main release identifier.
     */
    public NeOperationInfoChangedEvent setMainRelease(String mainRelease) {
        this.mainRelease = Optional.ofNullable(mainRelease);
        return this;
    }

    /**
     * @return Software maintenance release identifier.
     */
    public Optional<String> getMaintenanceRelease() {
        return maintenanceRelease;
    }

    /**
     * @param maintenanceRelease New software maintenance release.
     */
    public NeOperationInfoChangedEvent setMaintenanceRelease(String maintenanceRelease) {
        this.maintenanceRelease = Optional.ofNullable(maintenanceRelease);
        return this;
    }

    /**
     * @return NE sub type name.
     */
    public Optional<String> getNeSubType() {
        return neSubType;
    }

    /**
     * @param neSubType New NE sub type name.
     */
    public NeOperationInfoChangedEvent setNeSubType(String neSubType) {
        this.neSubType = Optional.ofNullable(neSubType);
        return this;
    }

    /**
     * @return NE type name.
     */
    public Optional<String> getNeType() {
        return neType;
    }

    /**
     * @param neType New NE type name.
     */
    public NeOperationInfoChangedEvent setNeType(String neType) {
        this.neType = Optional.ofNullable(neType);
        return this;
    }

    /**
     * @return The Ne SubType Description is based on the NeSpecificType and NeProxyType.
     */
    public Optional<String> getNeSubTypeDescription() {
        return neSubTypeDescription;
    }

    /**
     * @param neSubTypeDescription
     */
    public void setNeSubTypeDescription(String neSubTypeDescription) {
        this.neSubTypeDescription = Optional.ofNullable(neSubTypeDescription);
    }

    /**
     * @return NE specific type.
     */
    public Optional<String> getNeSpecificType() {
        return neSpecificType;
    }

    /**
     * @param neSpecificType New NE specific type.
     */
    public NeOperationInfoChangedEvent setNeSpecificType(String neSpecificType) {
        this.neSpecificType = Optional.ofNullable(neSpecificType);
        return this;
    }

    /**
     * @return The current operational mode.
     */
    public Optional<OperationalMode> getOperationalMode() {
        return operationalMode;
    }

    /**
     * @param operationalMode New operational mode.
     */
    public NeOperationInfoChangedEvent setOperationalMode(@Nonnull OperationalMode operationalMode) {
        this.operationalMode = Optional.of(operationalMode);
        return this;
    }

    /**
     * @return The current write access status.
     */
    public Optional<WriteAccessMode> getWriteAccess() {
        return writeAccess;
    }

    /**
     * @param writeAccess New write access status.
     */
    public NeOperationInfoChangedEvent setWriteAccess(@Nonnull WriteAccessMode writeAccess) {
        this.writeAccess = Optional.of(writeAccess);
        return this;
    }

    /**
     * @return The current commissioning status.
     */
    public Optional<CommissioningMode> getCommissioning() {
        return commissioning;
    }

    /**
     * @param commissioning New commissioning status.
     */
    public NeOperationInfoChangedEvent setCommissioning(@Nonnull CommissioningMode commissioning) {
        this.commissioning = Optional.of(commissioning);
        return this;
    }

    /**
     * @param location new NE location
     */
    public NeOperationInfoChangedEvent setLocation(String location) {
        this.location = Optional.ofNullable(location);
        return this;
    }

    /**
     * @return NE Location
     */
    public Optional<String> getLocation() {
        return location;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
            .addValue(super.toString())
            .add("gatewayMode", gatewayMode)
            .add("realNeName", realNeName)
            .add("neighbourhoodId", neighbourhoodId)
            .add("eventForwardingActive", eventForwardingActive)
            .add("tpGroupMask", tpGroupMask)
            .add("tpGroupMode", tpGroupMode)
            .add("family", family)
            .add("mainRelease", mainRelease)
            .add("maintenanceRelease", maintenanceRelease)
            .add("neSubType", neSubType)
            .add("neSubTypeDescription", neSubTypeDescription)
            .add("neType", neType)
            .add("neSpecificType", neSpecificType)
            .add("operationalMode", operationalMode)
            .add("writeAccess", writeAccess)
            .add("commissioning", commissioning)
            .add("location", location)
            .toString();
    }
}