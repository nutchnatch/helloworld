package com.ossnms.dcn_manager.core.properties.ne;

import com.google.common.base.Strings;
import com.google.common.collect.ImmutableSet;
import com.ossnms.dcn_manager.core.configuration.model.NeType;
import com.ossnms.dcn_manager.core.configuration.properties.WellKnownNePropertyNames;
import com.ossnms.dcn_manager.core.entities.ne.data.NeConnectionRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NeEntity;
import com.ossnms.dcn_manager.core.entities.ne.data.NeGatewayRouteData;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySetters;
import com.ossnms.dcn_manager.core.entities.ne.data.NePropertySource;
import com.ossnms.dcn_manager.core.entities.ne.data.NeUserPreferencesData;
import com.ossnms.dcn_manager.core.entities.ne.data.RouteSortingMode;
import com.ossnms.dcn_manager.core.properties.EntityProperties;
import com.ossnms.dcn_manager.core.properties.NamedPropertyHandler;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;
import com.ossnms.dcn_manager.i18n.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nonnull;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.StreamSupport;

import static com.ossnms.dcn_manager.i18n.T.tr;
import static java.util.Optional.of;

/**
 * Manages property retrieval from a merged set of NE Type and NE Instance
 * (NE entity) properties.
 */
public class NeProperties extends EntityProperties<NeProperty, NeType, NePropertySource, NePropertySetters<?>> {

    public NeProperties() {
        super(NeProperty.values());
    }

    /**
     * @param ne NE entity instance.
     * @param gatewayRoutes Known NE gateway routes.
     * @return A line of user-friendly text that describes the route in use (or that may be used) to
     *  connect to this NE.
     */
    public Optional<String> buildCurrentRouteDescription(@Nonnull NeEntity ne, @Nonnull Iterable<NeGatewayRouteData> gatewayRoutes) {
        return buildCurrentRouteDescription(ne.getConnection().isConnected(), ne.getPreferences(), gatewayRoutes);
    }

    /**
     * @param isConnected Whether the NE is connected.
     * @param gatewayRoutes Known NE gateway routes.
     * @return A line of user-friendly text that describes the route in use (or that may be used) to
     *  connect to this NE.
     */
    public Optional<String> buildCurrentRouteDescription(final boolean isConnected,
                                                                   @Nonnull final NeUserPreferencesData preferences, @Nonnull final Iterable<NeGatewayRouteData> gatewayRoutes) {

        if (isConnected) {
            return of(preferences)
                    .filter(NeUserPreferencesData::usesGne)
                    .flatMap(p -> tryFind(gatewayRoutes, NeConnectionRouteData::isUsed))
                    .map(route -> produceConnectedViaGNE(route) )
                    .orElseGet(() ->  of(tr(preferences.usesFlatIp() ? Message.DIRECT_CONNECTION_BY_FLAT_IP : Message.DIRECT_CONNECTION)));
        }

        return Optional.empty();
    }

    private Optional<String> produceConnectedViaGNE(NeGatewayRouteData route ) {
        
        String tl1GWType = route.getAllOpaqueProperties().get("TL1_TYPE") ;
        String viaGNE = "" ;
        if(null != tl1GWType && tl1GWType.startsWith("GNE_")) {
            viaGNE = " via " + tl1GWType;
        }
        return of(String.format("%s (%s)%s", route.getKey(), tr(route.getPriority() == 1 ? Message.WORKING : Message.PROTECTING), viaGNE));
    }
    
    private <T> Optional<T> tryFind(Iterable<T> iterable, Predicate<T> predicate) {
        return StreamSupport.stream(iterable.spliterator(), false).filter(predicate).findFirst();
    }

    @Override
    protected NePropertyHandler[] getHandlers() {
        return PROPERTY_HANDLERS;
    }

    private abstract static class NePropertyHandler extends NamedPropertyHandler<NeType, NePropertySource, NePropertySetters<?>> {

        protected NePropertyHandler(String name) {
            super(name);
        }

        protected NePropertyHandler() {
            super(null);
        }

    }

    private static final Logger LOGGER = LoggerFactory.getLogger(NeProperties.class);

    private static final NePropertyHandler[] PROPERTY_HANDLERS =
            {
    
                new NePropertyHandler(NeProperty.ID_NAME.getName()) {
                    @Override
                    public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) throws InvalidMutationException {
                        if (Strings.isNullOrEmpty(value)) {
                            throw new InvalidMutationException("NE name must not be null.");
                        }
                        descriptor.setName(value);
                    }
                    @Override
                    public Optional<String> get(NeType type, NePropertySource entity, String name) {
                        return of(entity.getPreferences().getName());
                    }
                },
    
                new NePropertyHandler(NeProperty.NE_TYPE.getName()) {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) {
                        LOGGER.warn("Attribute {} change supported through domain object only.", name);
                    }
                    @Override
                    public Optional<String> get(NeType type, NePropertySource entity, String name) {
                        return of(entity.getInfo().getProxyType());
                    }
                },
    
                new NePropertyHandler(NeProperty.USES_GNE.getName()) {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) throws InvalidMutationException {
                        descriptor.setUsesGne(booleanValueOf(value, name));
                    }
                    @Override
                public Optional<String> get(NeType type, NePropertySource entity, String name) {
                    return Optional.of(String.valueOf(entity.getPreferences().usesGne()));
                    }
                },
    
                new NePropertyHandler(NeProperty.USES_FLAT_IP.getName()) {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) throws InvalidMutationException {
                        descriptor.setUsesFlatIp(booleanValueOf(value, name));
                    }
                    @Override
                public Optional<String> get(NeType type, NePropertySource entity, String name) {
                    return Optional.of(String.valueOf(entity.getPreferences().usesFlatIp()));
                    }
                },
    
                new NePropertyHandler(NeProperty.GATEWAY_MODE.getName()) {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) {
                        LOGGER.warn("Attribute {} change supported through domain object only.", name);
                    }
                    @Override
                public Optional<String> get(NeType type, NePropertySource entity, String name) {
                    return Optional.of(String.valueOf(entity.getOperation().getGatewayMode()));
                    }
                },
    
                new NePropertyHandler(NeProperty.RECONNECT_INTERVAL.getName()) {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) throws InvalidMutationException {
                        descriptor.setReconnectInterval(integerValueOf(value, name));
                    }
                    @Override
                public Optional<String> get(NeType type, NePropertySource entity, String name) {
                    return Optional.of(String.valueOf(entity.getPreferences().getReconnectInterval()));
                    }
                },
    
                new NePropertyHandler(NeProperty.GLOBAL_NE_ID.getName()) {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) throws InvalidMutationException {
                        descriptor.setGlobalId(Optional.ofNullable(value));
                    }
                    @Override
                public Optional<String> get(NeType type, NePropertySource entity, String name) {
                        return entity.getPreferences().getGlobalId();
                    }
                },
    
                new NePropertyHandler(NeProperty.USER_NAME.getName()) {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) throws InvalidMutationException {
                        descriptor.setUserName(Optional.ofNullable(value));
                    }
                    @Override
                public Optional<String> get(NeType type, NePropertySource entity, String name) {
                        return entity.getPreferences().getUserName();
                    }
                },
    
                new NePropertyHandler(NeProperty.USER_PASSWORD.getName()) {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) throws InvalidMutationException {
                        descriptor.setPassword(Optional.ofNullable(value));
                    }
                    @Override
                public Optional<String> get(NeType type, NePropertySource entity, String name) {
                        return entity.getPreferences().getPassword();
                    }
                },
    
                new NePropertyHandler(NeProperty.USE_DEFAULT_ROUTE_SORTING.getName()) {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) throws InvalidMutationException {
                        final Boolean enabled = booleanValueOf(value, name);
                        descriptor.enableRouteSorting(enabled);
                        descriptor.enableRouteSortingByUsage(enabled);
                    }
                    @Override
                public Optional<String> get(NeType type, NePropertySource entity, String name) {
                    return Optional.of(String.valueOf(entity.getPreferences().getRouteSortingMode() != RouteSortingMode.NONE));
                    }
                },
    
                new NePropertyHandler(NeProperty.USER_TEXT.getName()) {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value)
                    throws InvalidMutationException {
                        descriptor.setUserText(Optional.ofNullable(value));
                    }
    
                    @Override
                public Optional<String> get(NeType type, NePropertySource entity, String name) {
                        return entity.getPreferences().getUserText();
                    }
                },
    
                new NePropertyHandler(NeProperty.DATATRANSFER_USERNAME.getName()) {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) throws InvalidMutationException {
                        descriptor.getDataTransferSettingsAdapter().setUsername(Optional.ofNullable(value));
                    }
                    @Override
                public Optional<String> get(NeType type, NePropertySource entity, String name) {
                        return entity.getPreferences().getDataTransferSettings().getUsername();
                    }
                },
                new NePropertyHandler(NeProperty.DATATRANSFER_PASSWORD.getName()) {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) throws InvalidMutationException {
                        descriptor.getDataTransferSettingsAdapter().setPassword(Optional.ofNullable(value));
                    }
                    @Override
                public Optional<String> get(NeType type, NePropertySource entity, String name) {
                        return entity.getPreferences().getDataTransferSettings().getPassword();
                    }
                },
                new NePropertyHandler(NeProperty.DATATRANSFER_UPLOADPATH.getName()) {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) throws InvalidMutationException {
                        descriptor.getDataTransferSettingsAdapter().setUploadpath(Optional.ofNullable(value));
                    }
                    @Override
                public Optional<String> get(NeType type, NePropertySource entity, String name) {
                        return entity.getPreferences().getDataTransferSettings().getUploadPath();
                    }
                },
                new NePropertyHandler(NeProperty.DATATRANSFER_IP_ADDRESS.getName()) {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) throws InvalidMutationException {
                        descriptor.getDataTransferSettingsAdapter().setIpAddress(Optional.ofNullable(value));
                    }
                    @Override
                public Optional<String> get(NeType type, NePropertySource entity, String name) {
                        return entity.getPreferences().getDataTransferSettings().getIpAddress();
                    }
                },
                new NePropertyHandler(NeProperty.DATATRANSFER_IS_SCP.getName()) {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) throws InvalidMutationException {
                        descriptor.getDataTransferSettingsAdapter().setIsScp(Optional.ofNullable(booleanValueOf(value, name)));
                    }
                    @Override
                public Optional<String> get(NeType type, NePropertySource entity, String name) {
                        return of(String.valueOf(entity.getPreferences().getDataTransferSettings().getIsScp()));
                    }
                },
                new NePropertyHandler(NeProperty.DATATRANSFER_PROFILE_NAME.getName()) {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) throws InvalidMutationException {
                        descriptor.setProperty(name, value);
                    }
                    @Override
                public Optional<String> get(NeType type, NePropertySource entity, String name) {
                        return entity.getOpaqueProperty(name);
                    }
                },
                new NePropertyHandler(NeProperty.DATATRANSFER_IS_FTP.getName()) {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) throws InvalidMutationException {
                        descriptor.setProperty(name, value);
                    }
                    @Override
                public Optional<String> get(NeType type, NePropertySource entity, String name) {
                        return entity.getOpaqueProperty(name);
                    }
                },
    
                new NePropertyHandler(WellKnownNePropertyNames.PARENT_NE_CONTAINER) {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) throws InvalidMutationException {
                        descriptor.setContainerId(
                            Strings.isNullOrEmpty(value) ? Optional.empty() : of(integerValueOf(value, name)));
                    }
                    @Override
                public Optional<String> get(NeType type, NePropertySource entity, String name) {
                        /* Retrieval of this value should always happen through the domain object.
                         */
                        return Optional.empty();
                    }
                },
    
                new NePropertyHandler() {
                    /*
                     * These properties are considered deprecated or are for intermediate use only and are thus not stored.
                     */
                    private final Set<String> noOpProperties = ImmutableSet.of(
                            WellKnownNePropertyNames.DEPRECATED_NUM_OF_DHCP,
                            WellKnownNePropertyNames.DEPRECATED_NUM_OF_ADD_NSAPS,
                            WellKnownNePropertyNames.INTERNAL_ROUTE_ROW_COUNT,
                            WellKnownNePropertyNames.INTERNAL_ENABLE_PRIORITY_SWAP,
                            WellKnownNePropertyNames.RESTART_NE
                        );
                @Override public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) {
                        LOGGER.trace("Not storing property '{}'.", name);
                    }
                @Override public Optional<String> get(NeType type, NePropertySource entity, String name) {
                        return Optional.empty();
                    }
                    @Override public boolean handles(NeType type, String name) {
                        return noOpProperties.contains(name);
                    }
                },
    
                new NePropertyHandler() {
                    private final NeDirectRouteProperties routeProperties = new NeDirectRouteProperties();
                @Override public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) {
                        /* NE Direct Route properties need a specific API for setting their values because they
                         * need a context entity should additional information be necessary, according to the
                         * route value source configuration for the NE Type being processed.
                         */
                        LOGGER.trace("Direct NE Route attribute {} change supported through NeDirectRouteProperties only.", name);
                    }
                @Override public Optional<String> get(NeType type, NePropertySource entity, String name) {
                        /* Retrieval of NE Direct Route property values is provided here as a convenience only
                         * because they have been historically considered part of the NE property set.
                         */
                        return routeProperties.get(type, entity, name);
                    }
                    @Override public boolean handles(NeType type, String name) {
                        return NeDirectRouteProperties.isDirectRouteProperty(type, name);
                    }
                },
    
                new NePropertyHandler() {
                    @Override
                public void set(NeType type, NePropertySetters<?> descriptor, String name, String value) {
                        descriptor.setProperty(name, value);
                    }
                    @Override
                public Optional<String> get(NeType type, NePropertySource entity, String name) {
                        return entity.getPreferences().getOpaqueProperty(name);
                    }
                    @Override
                    public boolean handles(NeType type, String name) {
                        /* NE Gateway Route properties are handled differently, they are not supposed to be
                         * set or retrieved individually through this API.
                         */
                        return !NeGatewayRouteProperties.isGatewayRouteProperty(type, name) &&
                               !NeDirectRouteProperties.isDirectRouteProperty(type, name) &&
                               !NeOperationalProperties.isOperationalProperty(type, name) &&
                               !name.startsWith(WellKnownNePropertyNames.DEPRECATED_DOMAIN_NAME_FOR_NE);
                    }
                }
            };

}
