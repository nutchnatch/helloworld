package com.ossnms.dcn_manager.core.properties;

import com.google.common.collect.Maps;
import com.ossnms.dcn_manager.core.configuration.model.Type;
import com.ossnms.dcn_manager.core.entities.PropertyBag;
import com.ossnms.dcn_manager.core.properties.EntityPropertyOperations.Scope;

import javax.annotation.Nonnull;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Manage property retrieval from a merged set of Type and Instance (entity)
 * properties.
 *
 * @param <P> Well known entity properties enum
 * @param <T> Entity Type class
 * @param <E> Entity Instance class
 * @param <M> Entity Instance Mutation Descriptor class
 */
public abstract class EntityProperties<P extends Enum<?> & EntityPropertyOperations, T extends Type, E extends PropertyBag, M>
        extends EntityPropertiesSink<P, T, E, M> {

    private final P[] wellKnownProperties;

    /**
     * Creates a new object.
     * @param wellKnownProperties Property enumeration values.
     */
    protected EntityProperties(P[] wellKnownProperties) { // NOPMD Internal usage only; it's an array of enums, hence immutable.
        this.wellKnownProperties = wellKnownProperties;
    }

    /**
     * <p>Merges entity type and instance property values into a single property map.
     * Only those instance properties with the visibility scope requested are included.
     * Dynamic property values are calculated as necessary.</p>
     *
     * <p><img src="doc-files/getProperties-sequence.png" /></p>
     *
     * @param type Entity type, as configured.
     * @param entity Entity.
     * @param visibilityScope Desired visibility scope of instance properties.
     * @return A map of name/value pairs. It is not guaranteed to be immutable, however
     *  changes made to this map will not affect the originating entity or type.
     */
    /*
     * @startuml doc-files/getProperties-sequence.png
     * actor Caller
     * participant EntityProperties
     * participant T << Entity Type >>
     * entity E << Entity Instance >>
     * Caller --> EntityProperties : getProperties(type, entity)
     * activate EntityProperties
     * EntityProperties --> T : getTypeProperties()
     * activate T
     * T --> EntityProperties : (names and values)
     * deactivate T
     * EntityProperties --> EntityProperties : add to result: (names and values)
     * loop For each well known property name with the desired visibility
     * EntityProperties --> E : getProperty(name)
     * activate E
     * E --> EntityProperties : value
     * deactivate E
     * EntityProperties --> T : mapPropertyName(name)
     * activate T
     * T --> EntityProperties : outsideName
     * deactivate T
     * EntityProperties --> EntityProperties : add to result: (outsideName, value)
     * note right : Internal names are not exposed.
     * end
     * EntityProperties --> E : getOpaqueProperties()
     * activate E
     * E --> EntityProperties : (names and values)
     * deactivate E
     * EntityProperties --> EntityProperties : add to result: (names and values)
     * EntityProperties --> Caller : full set of (names and values)
     * deactivate EntityProperties
     * @enduml
     */
    @Nonnull
    public Map<String, String> getProperties(@Nonnull T type, @Nonnull E entity, @Nonnull Scope visibilityScope) {
        return getProperties(type, entity, Arrays.stream(wellKnownProperties).filter(property -> property.getScope() == visibilityScope));
    }

    /**
     * <p>Merges entity type and instance property values with any visibility
     * into a single property map. Dynamic property values are calculated as necessary.</p>
     *
     * @param type Entity type, as configured.
     * @param entity Entity.
     * @return A map of name/value pairs. It is not guaranteed to be immutable, however
     *  changes made to this map will not affect the originating entity or type.
     * @see #getProperties(Type, PropertyBag, Scope)
     */
    @Nonnull
    public Map<String, String> getProperties(@Nonnull T type, @Nonnull E entity) {
        return getProperties(type, entity, Arrays.stream(wellKnownProperties));
    }

    @Nonnull
    private Map<String, String> getProperties(@Nonnull T type, @Nonnull E entity, @Nonnull Stream<P> propertiesToProcess) {
        final Map<String, String> map = new HashMap<>();
        for (final Map.Entry<String, String> entry : type.getTypeProperties().entrySet()) {
            map.put(entry.getKey(), replacePropertyVariables(entry.getValue(), type, entity));
        }
        propertiesToProcess.forEachOrdered(property -> {
            final String key = property.getName();
            final Optional<String> value = doGet(type, entity, key);
            if (value.isPresent()) {
                map.put(type.mapOutgoingPropertyName(key), value.get());
            }
        });
        map.putAll(
            Maps.transformValues(entity.getAllOpaqueProperties(),
                    value -> replacePropertyVariables(value, type, entity))
        );
        return map;
    }

    /**
     * <p>Retrieves the value of a property, whether it is defined or stored in the
     * entity Type or in the entity Instance. Based on specific property names.
     * Dynamic property values are calculated as necessary.</p>
     *
     * <p><img src="doc-files/getProperty-sequence.png/></p>
     *
     * @param type Entity type, as configured.
     * @param entity Entity instance.
     * @param name The desired property name. Will be normalized before the lookup.
     * @return The property value, if present.
     */
    /*
     * @startuml doc-files/getProperty-sequence.png
     * actor Caller
     * participant EntityProperties
     * participant T << Entity Type >>
     * entity E << Entity Instance >>
     * Caller --> EntityProperties : getProperty(type, entity, name)
     * EntityProperties --> T : mapPropertyName(name)
     * activate T
     * T --> EntityProperties : internalName
     * deactivate T
     * EntityProperties --> T : getTypeProperty(internalName)
     * activate T
     * T --> EntityProperties : value
     * deactivate T
     * alt If no value in Type for the property requested
     * EntityProperties --> E : getProperty(internalName)
     * activate E
     * E --> EntityProperties : value
     * deactivate E
     * end
     * EntityProperties --> Caller : value
     * deactivate EntityProperties
     * @enduml
     */
    @Nonnull
    public Optional<String> getProperty(@Nonnull T type, @Nonnull E entity, @Nonnull String name) {
        final String normalizedName = type.mapIncomingPropertyName(name);
        return getNormalizedProperty(type, entity, normalizedName);
    }

    /**
     * Retrieves the value of a property, whether it is defined or stored in the
     * entity Type or in the entity Instance. Based on well known properties.
     * Dynamic property values are calculated as necessary.
     * @param type Entity type, as configured.
     * @param entity Entity instance.
     * @param property The desired well known property enum. Is already normalized.
     * @return The property value, if present.
     */
    public Optional<String> getProperty(T type, E entity, P property) {
        return getNormalizedProperty(type, entity, property.getName());
    }

    /**
     * Retrieves the value of a property, whether it is defined or stored in the
     * entity Type or in the entity Instance. Based on normalized property names.
     * Dynamic property values are calculated as necessary.
     * @param entity Entity instance.
     * @param normalizedName The desired normalized property name.
     * @return The property value, if present.
     */
    @Nonnull
    private Optional<String> getNormalizedProperty(@Nonnull T type, @Nonnull E entity, @Nonnull String normalizedName) {
        final Optional<String> value = replacePropertyVariables(
                Optional.ofNullable(type.getTypeProperties().get(normalizedName)), type, entity);
        return value.isPresent() ? value : doGet(type, entity, normalizedName);
    }

    /**
     * <p>Regular expression used to replace property name place holders with their values.<p>
     *
     * <p>The group matcher<code> (\$\{Property\.([^\}]+)\}) </code> will match expressions in the format
     * <code>${Property.PROPERTY_NAME}</code>, where <code>PROPERTY_NAME</code> represents the name of
     * the property whose value we want to use instead of the whole expression.</p>
     *
     * <p>For example, a {@link Matcher} built from this pattern will find <code>Computer_Name</code>
     * in group number 2 when applied to the string <code>${Property.Computer_Name}</code>.</p>
     */
    private static final Pattern PROPERTY_VARIABLE_PATTERN =
            Pattern.compile("(\\$\\{Property\\.([^\\}]+)\\})", Pattern.CASE_INSENSITIVE);

    /**
     * <p>Replaces property name place holders in a string with the value of the properties they
     * identify. If there is no value for the target property, the place holder will be replaced
     * by an empty string.</p>
     * <p>Target properties will be looked up in the Channel Type and the current Channel Instance.</p>
     * @param value The string to process.
     * @param type Entity type, as configured.
     * @param entity Current entity instance.
     * @return A string resulting from all replacements, or the original string if no place
     *  holders were found.
     */
    @Nonnull
    private String replacePropertyVariables(@Nonnull String value, @Nonnull T type, @Nonnull E entity) {
        final Matcher matcher = PROPERTY_VARIABLE_PATTERN.matcher(value);
        if (matcher.find()) {
            final StringBuffer buffer = new StringBuffer();
            do {
                final String propertyName = matcher.group(2);
                final Optional<String> replacement = getProperty(type, entity, propertyName);
                matcher.appendReplacement(buffer, replacement.orElse(""));
            } while (matcher.find());
            matcher.appendTail(buffer);
            return buffer.toString();
        } else {
            return value;
        }
    }

    /**
     * Same as {@link #replacePropertyVariables(String, Type, PropertyBag)} but using {@link Optional}
     * references.
     * @param value The string to process.
     * @param type Entity type, as configured.
     * @param entity Current entity instance.
     * @return A string resulting from all replacements, or the original string if no place
     *  holders were found.
     */
    @Nonnull
    private Optional<String> replacePropertyVariables(@Nonnull Optional<String> value, @Nonnull T type, @Nonnull E entity) {
        return value.isPresent()
                ? Optional.of(replacePropertyVariables(value.get(), type, entity))
                : value;
    }

    private Optional<String> doGet(T type, E entity, String name) {
        for (final EntityPropertyHandler<T, E, M> handler : getHandlers()) {
            if (handler.handles(type, name)) {
                final Optional<String> value = handler.get(type, entity, name);
                return replacePropertyVariables(value, type, entity);
            }
        }
        return Optional.empty();
    }

}