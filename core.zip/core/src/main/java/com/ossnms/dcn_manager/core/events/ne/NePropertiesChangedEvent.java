package com.ossnms.dcn_manager.core.events.ne;

import java.util.Map;

import javax.annotation.concurrent.Immutable;

import com.google.common.base.MoreObjects;
import com.google.common.collect.ImmutableMap;

/**
 * Used to signal changes on the NE's dynamic properties.
 *
 * <p>Unlike it's siblings, the class doesn't provide a constructor that receives
 * a human readable description as an argument. The rationale is that the received
 * set of affected dynamic properties is self-describing, hence the redefinition of
 * {@link #toString()}.</p>
 *
 * <p>Also unlike it's siblings, the class is a concrete type (i.e. instead of
 * being an abstract class) and does not include the definition of concrete sub-classes.
 * This difference is due to the fact that dynamic properties are not subject to
 * interpretation, and therefore there is no need to ensure static typing of events
 * pertaining to modifications of these properties.</p>
 */
@Immutable
public class NePropertiesChangedEvent extends NeEvent {

    /** The set of affected dynamic properties. */
    private final ImmutableMap<String, String> propertiesChanged;

    /**
     * Initiates an instance with the given arguments.
     * @param neId The affected NE identifier.
     * @param propertiesChanged The set of affected dynamic properties.
     */
    public NePropertiesChangedEvent(int neId, ImmutableMap<String, String> propertiesChanged) {
        super(neId);
        this.propertiesChanged = propertiesChanged;
    }

    /**
     * @return The set of properties that have changed.
     */
    public Map<String, String> getPropertiesChanged() {
        return propertiesChanged;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
            .addValue(super.toString())
            .add("propertiesChanged", propertiesChanged)
            .toString();
    }
}
