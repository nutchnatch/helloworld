package com.ossnms.dcn_manager.core.properties.mediator;

import com.ossnms.dcn_manager.core.configuration.model.MediatorType;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorEntity;
import com.ossnms.dcn_manager.core.entities.mediator.data.MediatorPropertySetters;
import com.ossnms.dcn_manager.core.properties.EntityProperties;
import com.ossnms.dcn_manager.core.properties.EntityPropertyHandler;
import com.ossnms.dcn_manager.core.properties.NamedPropertyHandler;
import com.ossnms.dcn_manager.exceptions.InvalidMutationException;

import java.util.Optional;


/**
 * Contains well known mediator property names as mentioned in the user interface description files.
 * Is also able to manage property retrieval from a merged set of Mediator Type and Mediator Instance
 * (mediator entity) properties.
 */
public final class MediatorProperties extends EntityProperties<MediatorProperty, MediatorType, MediatorEntity, MediatorPropertySetters<?>> {

    public MediatorProperties() {
        super(MediatorProperty.values());
    }

    @Override
    protected EntityPropertyHandler<MediatorType, MediatorEntity, MediatorPropertySetters<?>>[] getHandlers() {
        return PROPERTY_HANDLERS;
    }

    private abstract static class MediatorPropertyHandler
            extends NamedPropertyHandler<MediatorType, MediatorEntity, MediatorPropertySetters<?>> {

        protected MediatorPropertyHandler(MediatorProperty property) {
            super(property.getName());
        }

        protected MediatorPropertyHandler() {
            super(null);
        }

    }

    private static final MediatorPropertyHandler[] PROPERTY_HANDLERS = {
            new MediatorPropertyHandler(MediatorProperty.CONCURRENT_ACTIVATIONS_LIMIT) {
                @Override
                public void set(MediatorType type, MediatorPropertySetters<?> descriptor,
                                String name, String value) throws InvalidMutationException {
                    descriptor.setConcurrentActivationsLimit(integerValueOf(value, getName()));
                }

                @Override
                public Optional<String> get(MediatorType type, MediatorEntity entity, String name) {
                    return Optional.of(Integer.toString(entity.getInfo().getConcurrentActivationsLimit()));
                }
            },
            new MediatorPropertyHandler(MediatorProperty.CONCURRENT_ACTIVATIONS_LIMITED) {
                @Override
                public void set(MediatorType type, MediatorPropertySetters<?> descriptor,
                                String name, String value) throws InvalidMutationException {
                    descriptor.setConcurrentActivationsLimited(booleanValueOf(value, getName()));
                }

                @Override
                public Optional<String> get(MediatorType type, MediatorEntity entity, String name) {
                    return Optional.of(Boolean.toString(entity.getInfo().isConcurrentActivationsLimited()));
                }
            },
            new MediatorPropertyHandler(MediatorProperty.DESCRIPTION) {
                @Override
                public void set(MediatorType type, MediatorPropertySetters<?> descriptor,
                                String name, String value) throws InvalidMutationException {
                    descriptor.setDescription(Optional.ofNullable(value));
                }

                @Override
                public Optional<String> get(MediatorType type, MediatorEntity entity, String name) {
                    return entity.getInfo().getDescription();
                }
            },
            new MediatorPropertyHandler(MediatorProperty.ID_NAME) {
                @Override
                public void set(MediatorType type, MediatorPropertySetters<?> descriptor,
                                String name, String value) throws InvalidMutationException {
                    if (null != value) {
                        descriptor.setName(value);
                    } else {
                        throw new InvalidMutationException("Mediator name can not be null.");
                    }
                }

                @Override
                public Optional<String> get(MediatorType type, MediatorEntity entity, String name) {
                    return Optional.of(entity.getInfo().getName());
                }
            },
            new MediatorPropertyHandler(MediatorProperty.RECONNECT_INTERVAL) {
                @Override
                public void set(MediatorType type, MediatorPropertySetters<?> descriptor,
                                String name, String value) throws InvalidMutationException {
                    descriptor.setReconnectAttemptInterval(integerValueOf(value, getName()));
                }

                @Override
                public Optional<String> get(MediatorType type, MediatorEntity entity, String name) {
                    return Optional.of(Integer.toString(entity.getInfo().getReconnectAttemptInterval()));
                }
            },
            new MediatorPropertyHandler(MediatorProperty.USER_TEXT) {
                @Override
                public void set(MediatorType type, MediatorPropertySetters<?> descriptor,
                                String name, String value) throws InvalidMutationException {
                    descriptor.setUserText(Optional.ofNullable(value));
                }

                @Override
                public Optional<String> get(MediatorType type, MediatorEntity entity, String name) {
                    return entity.getInfo().getUserText();
                }
            },
            new MediatorPropertyHandler() {
                @Override
                public void set(MediatorType type, MediatorPropertySetters<?> descriptor,
                                String name, String value) throws InvalidMutationException {
                    descriptor.setProperty(name, value);
                }

                @Override
                public Optional<String> get(MediatorType type, MediatorEntity entity, String name) {
                    return entity.getOpaqueProperty(name);
                }

                @Override
                public boolean handles(MediatorType type, String name) {
                    // Handle everything except for physical mediator server instance properties.
                    return !MediatorInstanceProperties.isMediatorInstanceProperty(name);
                }
            },
    };
}
