package com.ossnms.dcn_manager.core.events.domain;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

/**
 * Informs that the name of a natural domain has been removed from the NE.
 */
@Immutable
public final class DomainRemoved extends DomainEvent {

    private final int neId;
    private final String oldDomainName;

    /**
     * Constructs a new object instance.
     * @param neId Identifier of the NE that has lost the natural domain.
     * @param domainId Identifier of the corresponding domain in DCN Manager.
     * @param oldDomainName Removed domain name.
     */
    public DomainRemoved(int neId, int domainId, @Nonnull String oldDomainName) {
        super(domainId);
        this.neId = neId;
        this.oldDomainName = oldDomainName;
    }

    /**
     * @return The name of the removed domain.
     */
    public String getOldDomainName() {
        return oldDomainName;
    }

    /**
     * @return Identifier of the NE that has lost the natural domain.
     */
    public int getNeId() {
        return neId;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .appendSuper(super.toString())
                .append("neId", neId)
                .append("oldDomainName", oldDomainName)
                .toString();
    }

    /** {@inheritDoc} */
    @Override
    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != getClass()) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        final DomainRemoved rhs = (DomainRemoved) obj;
        return new EqualsBuilder()
                .append(getNeId(), rhs.getNeId())
                .append(getDomainId(), rhs.getDomainId())
                .append(getDetailedDescription(), rhs.getDetailedDescription())
                .append(getOldDomainName(), rhs.getOldDomainName())
                .isEquals();
    }

    /** {@inheritDoc} */
    @Override
    public int hashCode() {
        return new HashCodeBuilder()
                .appendSuper(super.hashCode())
                .append(neId)
                .append(oldDomainName)
                .hashCode();
    }
}
