package com.ossnms.dcn_manager.core.policies.impl;

import com.ossnms.dcn_manager.core.events.mediator.ActualMediatorStateEvent;
import com.ossnms.dcn_manager.core.events.mediator.PhysicalMediatorStateEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.ActivateMediatorEvent;
import com.ossnms.dcn_manager.core.events.mediator.RequiredMediatorStateEvent.DeactivateMediatorEvent;
import com.ossnms.dcn_manager.core.outbound.MediatorConnectionManager;
import com.ossnms.dcn_manager.core.policies.MediatorInteractionManager;
import com.ossnms.dcn_manager.core.policies.common.ExecutionQueue;
import com.ossnms.dcn_manager.core.policies.common.Job;
import com.ossnms.dcn_manager.core.policies.common.ObservableExecutor;
import com.ossnms.dcn_manager.core.policies.common.PolicyJob;

import javax.annotation.Nonnull;
import java.util.Observer;
import java.util.Optional;

import static com.google.common.collect.Iterables.tryFind;

/**
 * Implementation of a policy for interaction with Mediators. At this time it is generally
 * believed that these interactions do not force a significant load in the system, hence
 * there is no regulation.
 */
public class MediatorInteractionManagerImpl implements MediatorInteractionManager {

    private final MediatorConnectionManager connectionManager;
    private final ExecutionQueue<PolicyJob<? extends RequiredMediatorStateEvent>> execution;

    private final Observer observer;
    private final ObservableExecutor executionPolicy;

    /**
     * Creates a new object.
     */
    public MediatorInteractionManagerImpl(
            @Nonnull MediatorConnectionManager connectionManager,
            @Nonnull ObservableExecutor executionPolicy) {
        this.connectionManager = connectionManager;
        this.execution = new ExecutionQueue<>(Integer.MAX_VALUE, "MEDIATOR", executionPolicy, p -> Optional.empty());
        //The following observer was created to ensure that rejected tasks are resubmitted to the executor to be processed.
        //the observer will be invoked after each processed task, if there are rejected tasks in executionQueue
        //they will be resubmitted to the bounded executor
        // look at TNMSCM-11194
        this.observer = (obs, o) -> this.execution.signalCapacityIsAvailable();
        this.executionPolicy = executionPolicy;
        this.executionPolicy.addObserver(observer);
    }

    @Override
    public void scheduleActivation(@Nonnull ActivateMediatorEvent event) {
        execution.scheduleWorkItem(
            new JobWrapper<>(new MediatorActivationJob(event), execution::getRetainedWorkForExecution),
            job -> job.getOriginatingEvent().getMediatorInstanceIdentifiers().equals(event.getMediatorInstanceIdentifiers()));
    }

    @Override
    public void scheduleDeactivation(@Nonnull DeactivateMediatorEvent event) {
        execution.scheduleWorkItem(
            new JobWrapper<>(new MediatorDeactivationJob(event), execution::getRetainedWorkForExecution),
            job -> job.getOriginatingEvent().getMediatorInstanceIdentifiers().equals(event.getMediatorInstanceIdentifiers()));
    }

    @Override
    public void onMediatorInteractionEnded(@Nonnull ActualMediatorStateEvent mediatorStateEvent) {
        execution.signalWorkItemCompletion(
            job -> tryFind(
                        job.getOriginatingEvent().getMediatorInstanceIdentifiers(),
                        id -> id.equals(mediatorStateEvent.getOriginatingPhysicalEvent().map(PhysicalMediatorStateEvent::getMediatorId).orElse(0))
                    ).isPresent()
        );
    }

    @Override
    public int getPendingJobCount() {
        return execution.getPendingWorkItemCount();
    }

    @Override
    public int getOngoingJobCount() {
        return execution.getOngoingWorkItemCount();
    }

    @Override
    public int getMaxOngoingJobCount() {
        return execution.getMaxOngoingWorkItemCount();
    }

    @Override
    public void setMaxOngoingJobCount(int newMaxInteractions) {
        execution.setMaxOngoingWorkItemCount(newMaxInteractions);
    }

    @Override
    public void close() {
        this.executionPolicy.deleteObserver(this.observer);
    }

    private final class MediatorActivationJob extends Job<ActivateMediatorEvent> {

        public MediatorActivationJob(@Nonnull ActivateMediatorEvent requestEvent) {
            super(requestEvent, Priority.MEDIUM);
        }

        @Override
        public void runJob() {
            getOriginatingEvent().getMediatorInstanceIdentifiers()
                    .forEach(connectionManager::connect);
        }
    }

    private final class MediatorDeactivationJob extends Job<DeactivateMediatorEvent> {

        public MediatorDeactivationJob(@Nonnull DeactivateMediatorEvent requestEvent) {
            super(requestEvent, Priority.HIGH);
        }

        @Override
        public void runJob() {
            getOriginatingEvent().getMediatorInstanceIdentifiers()
                    .forEach(connectionManager::disconnect);
        }
    }
}
