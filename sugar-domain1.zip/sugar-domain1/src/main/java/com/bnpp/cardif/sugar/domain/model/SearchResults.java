package com.bnpp.cardif.sugar.domain.model;

import java.io.Serializable;
import java.util.List;

import com.google.common.base.Objects;

/**
 * Stands for objects of a search. This object allows to encapsulate both the
 * objects of a search and the total number which can be different according to
 * pagination
 * 
 * @author Christopher Laszczuk
 * 
 * @param <T>
 *            The type of objects
 */
public class SearchResults<T> implements Serializable {
    private static final long serialVersionUID = -9172960828241271829L;

    private List<T> objects;

    private long found;

    private long searchLimit;

    public SearchResults() {
    }

    public SearchResults(List<T> objects, long found) {
        this.objects = objects;
        this.found = found;
    }

    public SearchResults(List<T> objects, long found, long searchLimit) {
        this.objects = objects;
        this.found = found;
        this.searchLimit = searchLimit;
    }

    /**
     * Gets the objects of represented search
     * 
     * @return A list of search objects
     */
    public List<T> getObjects() {
        return objects;
    }

    public void setResults(List<T> results) {
        this.objects = results;
    }

    /**
     * Gets the total number of found results
     * 
     * @return The found number
     */
    public long getFound() {
        return found;
    }

    public void setFound(long found) {
        this.found = found;
    }

    public long getSearchLimit() {
        return searchLimit;
    }

    public void setSearchLimit(long searchLimit) {
        this.searchLimit = searchLimit;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("objects", objects).add("found", found).toString();
    }
}
