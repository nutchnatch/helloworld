package com.bnpp.cardif.sugar.domain.exception;

import java.io.InputStream;

public enum TechnicalErrorCode {
    /**
     * Generic technical error
     */
    T01789,
    /**
     * CallableStatement cannot be prepared
     */
    T00001,
    /**
     * CallableStatement cannot be closed
     */
    T00002,
    /**
     * JDBC Connection cannot be opened
     */
    T00003,
    /**
     * JDBC Connection cannot be closed
     */
    T00004,
    /**
     * JDBC Array cannot be instantiated
     */
    T00005,
    /**
     * JDBC ResultSet cannot be parsed
     */
    T00006,
    /**
     * XML object cannot be parsed from ResultSet
     */
    T00007,
    /**
     * The JDBC ResultSet cannot be closed
     */
    T00008,
    /**
     * JAXBStringWriter cannot be instantiated
     */
    T00009,
    /**
     * JAXBStringWriter cannot be closed
     */
    T00010,
    /**
     * The StringWriter cannot be flushed and closed
     */
    T00011,
    /**
     * Object cannot be marshaled into String through JAXB
     */
    T00012,
    /**
     * String cannot be unmarshaled into Object through JAXB
     */
    T00013,
    /**
     * Failed to free array
     */
    T00014,
    /**
     * Generic error when trying to release a database session for closing
     * cursors
     */
    T00015,

    // Document DAO
    /**
     * Documents cannot be stored
     */
    T00101,
    /**
     * Documents cannot be updated
     */
    T00102,
    /**
     * Documents cannot be fetched
     */
    T00103,
    /**
     * Documents cannot be found
     */
    T00104,
    /**
     * Documents cannot be deleted
     */
    T00105,

    // Document classes DAO
    /**
     * Document classes cannot be stored
     */
    T00201,
    /**
     * Document classes cannot be updated
     */
    T00202,
    /**
     * Document classes cannot be got
     */
    T00203,
    /**
     * Document classes cannot be activated/deactivated
     */
    T00204,
    /**
     * Document classes cannot be removed
     */
    T00205,
    /**
     * Document classes cannot be found
     */
    T00206,

    // Folder DAO
    /**
     * Folder cannot be added
     */
    T00301,
    /**
     * Folder cannot be got
     */
    T00302,
    /**
     * Folder cannot be updated
     */
    T00303,
    /**
     * Folder cannot be found
     */
    T00304,
    /**
     * Folder cannot be got by symbolic name
     */
    T00305,

    // Folder classes DAO
    /**
     * Folder classes cannot be added
     */
    T00401,
    /**
     * Folder classes cannot be got
     */
    T00402,
    /**
     * Folder classes cannot be updated
     */
    T00403,
    /**
     * All folder classes cannot be got
     */
    T00404,
    /**
     * All folder classes cannot be activated/deactivated
     */
    T00405,

    // Baskets / tasks DAO
    /**
     * Baskets cannot be added
     */
    T00501,
    /**
     * Baskets cannot be got
     */
    T00502,
    /**
     * All baskets cannot be got
     */
    T00503,
    /**
     * Baskets cannot be updated
     */
    T00504,
    /**
     * Baskets cannot be deleted
     */
    T00505,
    /**
     * Tasks cannot be stored
     */
    T00506,
    /**
     * Tasks cannot be got
     */
    T00507,
    /**
     * Tasks cannot be got for document
     */
    T00508,
    /**
     * Tasks status cannot be updated
     */
    T00509,
    /**
     * Tasks cannot be locked
     */
    T00510,
    /**
     * Tasks cannot be unlocked
     */
    T00511,
    /**
     * Tasks cannot be transfered
     */
    T00512,
    /**
     * Basket tasks cannot be got
     */
    T00513,

    // Business scopes DAO
    /**
     * BS cannot be added
     */
    T00601,
    /**
     * BS cannot be got from symbolic name
     */
    T00602,
    /**
     * All BS cannot be got
     */
    T00603,
    /**
     * BS cannot be updated
     */
    T00604,

    // Document files DAO
    /**
     * Document files cannot be stored
     */
    T00701,
    /**
     * Document files cannot be fetched
     */
    T00702,
    /**
     * Document files cannot be deleted
     */
    T00703,
    /**
     * {@link InputStream} cannot be extracted from DocumentFile
     */
    T00704,
    /**
     * No temporary file can be stored for uploaded document file
     */
    T00705,

    // Tag classes DAO
    /**
     * Tag classes cannot be stored
     */
    T00801,
    /**
     * Tag classes cannot be got by symbolic name
     */
    T00802,
    /**
     * Tag classes cannot be got
     */
    T00803,
    /**
     * All tag classes cannot be got
     */
    T00804,
    /**
     * Tag classes cannot be updated
     */
    T00805,

    // Reporting DAO
    /**
     * Envelopes and documents flows cannot be got
     */
    T00901,
    /**
     * Envelopes and documents report cannot be got
     */
    T00902,
    /**
     * Envelopes and documents report cannot be generated
     */
    T00903,
    /**
     * Basket closed ratios cannot be got
     */
    T00904,
    /**
     * Basket closed ratio report cannot be got
     */
    T00905,
    /**
     * Basket closed ratio report cannot be generated
     */
    T00906,
    /**
     * Document stock indicators cannot be got
     */
    T00907,
    /**
     * Folder stock indicators cannot be got
     */
    T00908,
    /**
     * Facts cannot be stored
     */
    T00909,
    /**
     * All facts cannot be got
     */
    T00910,
    /**
     * Invalid fact type
     */
    T00911,

    /**
     * ACL cannot be stored
     */
    T01001,
    /**
     * ACL cannot be got
     */
    T01002,
    /**
     * ACL cannot be assigned
     */
    T01003,
    /**
     * ACL mapping cannot be found
     */
    T01004,
    /**
     * ACL mapping cannot be removed
     */
    T01005,
    /**
     * All ACLs cannot be got
     */
    T01006,
    /**
     * No ACL was found for given object
     */
    T01007,

    // Another technical error codes
    /**
     * Non parsable date
     */
    T01101,

    /**
     * Annotations can't be stored
     */
    T01201,
    /**
     * Annotations can't be updated
     */
    T01202,
    /**
     * Annotations can't be deleted
     */
    T01203,
    /**
     * unable to find Annotations
     */
    T01204,
}
