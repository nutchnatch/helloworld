package com.bnpp.cardif.sugar.domain.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "DocumentClassDefinition", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/documentclass/v1")
public class DocumentClassDefinition implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 5509131438459122006L;

    @XmlElement(name = "Tags", namespace = "http://www.arondor.com/schema/flower/calyx")
    private TagsDefinition tagFieldDefinitions = new TagsDefinition();

    @XmlElement(name = "DocumentClass", namespace = "http://ea.assurance.bnpparibas.com/internal/schema/mco/documentclass/v1")
    private DocumentClass documentClass;

    public DocumentClassDefinition() {

    }

    public TagsDefinition getTagFieldDefinitions() {
        return tagFieldDefinitions;
    }

    public void setTagFieldDefinitions(TagsDefinition tagFieldDefinitions) {
        this.tagFieldDefinitions = tagFieldDefinitions;
    }

    public DocumentClass getDocumentClass() {
        return documentClass;
    }

    public void setDocumentClass(DocumentClass documentClass) {
        this.documentClass = documentClass;
    }

}
