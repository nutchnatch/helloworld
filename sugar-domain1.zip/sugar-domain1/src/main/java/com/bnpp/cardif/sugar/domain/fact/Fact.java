package com.bnpp.cardif.sugar.domain.fact;

import java.io.Serializable;
import java.util.Date;

import com.google.common.base.Objects;

public class Fact implements Serializable {
    private static final long serialVersionUID = 758863897411497609L;

    private final Date creationDate;

    private ObjectType type;

    private Action action;

    private Object objectId;

    private String user;

    public Fact() {
        creationDate = new Date();
    }

    public Fact(Date creationDate) {

        if (creationDate != null) {
            this.creationDate = new Date(creationDate.getTime());
        }
        else {
            this.creationDate = null;
        }
    }

    public Fact(ObjectType type, Action action, Object objectId, String user) {
        this(new Date());
        this.type = type;
        this.action = action;
        this.objectId = objectId;
        this.user = user;
    }

    public Date getCreationDate() {
        return new Date(creationDate.getTime());
    }

    public ObjectType getType() {
        return type;
    }

    public void setType(ObjectType type) {
        this.type = type;
    }

    public Action getAction() {
        return action;
    }

    public void setAction(Action action) {
        this.action = action;
    }

    public Object getObjectId() {
        return objectId;
    }

    public void setObjectId(Object objectId) {
        this.objectId = objectId;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("creationDate", creationDate).add("objectType", type)
                .add("action", action).add("objectId", objectId).toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Fact) {
            Fact fact = (Fact) obj;
            return Objects.equal(this.creationDate, fact.creationDate) && Objects.equal(this.type, fact.type)
                    && Objects.equal(this.action, fact.action) && Objects.equal(this.objectId, fact.objectId)
                    && Objects.equal(this.user, fact.user);
        }
        return false;
    }

    @Override
    public int hashCode() {
        int hash = super.hashCode();
        hash += creationDate.hashCode();
        return hash;
    }
}
