package com.bnpp.cardif.sugar.domain.exception;

/**
 * Sugar exception thrown on functional issue
 * 
 * @author Christopher Laszczuk
 * 
 */
public class SugarFunctionalException extends SugarException {
    private static final long serialVersionUID = -8836304566526326040L;

    public SugarFunctionalException() {
    }

    public SugarFunctionalException(String message, Throwable cause) {
        super(message, cause);
    }

    public SugarFunctionalException(String code, String message, Throwable cause) {
        super(code, message, cause);
    }
}
