package com.bnpp.cardif.sugar.domain.exception;

/**
 * Sugar exception thrown on technical issue
 * 
 * @author Christopher Laszczuk
 * 
 */
public class SugarTechnicalException extends SugarException {
    private static final long serialVersionUID = 8115200654309086047L;

    public SugarTechnicalException() {
    }

    public SugarTechnicalException(String message) {
        super(message);
    }

    public SugarTechnicalException(String message, Throwable cause) {
        super(message, cause);
    }

    public SugarTechnicalException(String code, String message, Throwable cause) {
        super(code, message, cause);
    }
}
