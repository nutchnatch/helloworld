package com.bnpp.cardif.sugar.domain.model;

import java.io.Serializable;

import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.google.common.base.Objects;

public class Context implements Serializable {
    private static final long serialVersionUID = -1735468701265989383L;

    private Category category;

    private Phase phase;

    public Context() {
    }

    public Context(Category category, Phase phase) {
        this.category = category;
        this.phase = phase;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Phase getPhase() {
        return phase;
    }

    public void setPhase(Phase phase) {
        this.phase = phase;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((category == null) ? 0 : category.hashCode());
        result = prime * result + ((phase == null) ? 0 : phase.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Context other = (Context) obj;
        if (category == null) {
            if (other.category != null) {
                return false;
            }
        }
        else if (!category.equals(other.category)) {
            return false;
        }
        if (phase == null) {
            if (other.phase != null) {
                return false;
            }
        }
        else if (!phase.equals(other.phase)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("phase", phase).add("category", category).toString();
    }
}