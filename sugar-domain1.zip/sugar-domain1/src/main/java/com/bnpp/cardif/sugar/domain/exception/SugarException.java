package com.bnpp.cardif.sugar.domain.exception;

/**
 * Abstract Sugar exception class
 * 
 * @author Christopher Laszczuk
 *
 */
public abstract class SugarException extends Exception {
    private static final long serialVersionUID = 5093584926530576256L;

    private String code;

    protected SugarException() {
    }

    protected SugarException(String message) {
        super(message);
    }

    protected SugarException(String message, Throwable cause) {
        super(message, cause);
    }

    protected SugarException(String code, String message, Throwable cause) {
        super(message, cause);
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}