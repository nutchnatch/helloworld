package com.bnpp.cardif.sugar.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;

public class AuthenticatedUser implements UserDetails {
    private static final long serialVersionUID = 5237607032448693079L;

    private final String password;

    private final String username;

    private final String firstName;

    private final String lastName;

    private final String token;

    private String requestId;

    private long timeToSpentOnAuthentication;

    private Collection<? extends GrantedAuthority> authorities;

    private List<String> businessScopes = new ArrayList<>();

    private String currentBusinessScope;

    private List<TaskId> lockedTasks = new ArrayList<>();

    private String commercialVersion;

    public AuthenticatedUser(String userName, String password, String token, String firstName, String lastName,
            Collection<? extends GrantedAuthority> grantedAuthorities, String commercialVersion) {
        this.username = userName;
        this.password = password;
        this.token = token;
        this.firstName = firstName;
        this.lastName = lastName;
        this.authorities = grantedAuthorities;
        this.commercialVersion = commercialVersion;
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public String getPassword() {
        return password;
    }

    public String getToken() {
        return token;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    public void setAuthorities(Collection<? extends GrantedAuthority> authorities) {
        this.authorities = authorities;
    }

    @Override
    public boolean isAccountNonExpired() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isAccountNonLocked() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isEnabled() {
        // TODO Auto-generated method stub
        return false;
    }

    public List<String> getBusinessScopes() {
        return businessScopes;
    }

    public void setBusinessScopes(List<String> businessScopes) {
        this.businessScopes = businessScopes;
    }

    public List<TaskId> getLockedTasks() {
        return lockedTasks;
    }

    public void setLockedTasks(List<TaskId> lockedTasks) {
        this.lockedTasks = lockedTasks;
    }

    public String getCurrentBusinessScope() {
        return currentBusinessScope;
    }

    public void setCurrentBusinessScope(String currentBusinessScope) {
        this.currentBusinessScope = currentBusinessScope;
    }

    public long getTimeToSpentOnAuthentication() {
        return timeToSpentOnAuthentication;
    }

    public void setTimeToSpentOnAuthentication(long timeToSpentOnAuthentication) {
        this.timeToSpentOnAuthentication = timeToSpentOnAuthentication;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /**
     * @return the commercialVersion
     */
    public String getCommercialVersion() {
        return commercialVersion;
    }

    /**
     * @param commercialVersion
     *            the commercialVersion to set
     */
    public void setCommercialVersion(String commercialVersion) {
        this.commercialVersion = commercialVersion;
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("AuthenticatedUser [password=");
        builder.append(password);
        builder.append(", username=");
        builder.append(username);
        builder.append(", firstName=");
        builder.append(firstName);
        builder.append(", lastName=");
        builder.append(lastName);
        builder.append(", token=");
        builder.append(token);
        builder.append(", requestId=");
        builder.append(requestId);
        builder.append(", timeToSpentOnAuthentication=");
        builder.append(timeToSpentOnAuthentication);
        builder.append(", authorities=");
        builder.append(authorities);
        builder.append(", businessScopes=");
        builder.append(businessScopes);
        builder.append(", currentBusinessScope=");
        builder.append(currentBusinessScope);
        builder.append(", lockedTasks=");
        builder.append(lockedTasks);
        builder.append(", commercialVersion=");
        builder.append(commercialVersion);
        builder.append("]");
        return builder.toString();
    }

}