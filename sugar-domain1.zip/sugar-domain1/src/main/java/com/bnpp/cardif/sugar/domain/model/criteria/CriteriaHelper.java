package com.bnpp.cardif.sugar.domain.model.criteria;

import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;

/**
 * Helper class for {@link Criterion} allowing to parse and serialize set of
 * criterion
 * 
 * @author Christopher Laszczuk
 * 
 */
public interface CriteriaHelper {
    /**
     * Serializes a set of criteria as a String for a component or a folder
     * 
     * @param criteria
     *            A list of {@link Criteria}
     * @return String the result of serialization.
     */
    String serialize(Criteria criteria);

    /**
     * Parse a String representing a set of criteria
     * 
     * @param criteria
     *            Criteria as a String
     * @return The parsed list of {@link Criterion}
     */
    Criteria parse(String criteria);
}
