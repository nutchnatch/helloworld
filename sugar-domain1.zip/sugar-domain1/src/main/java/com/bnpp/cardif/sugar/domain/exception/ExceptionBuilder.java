package com.bnpp.cardif.sugar.domain.exception;

import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.logging.Logger;

import com.google.common.annotations.GwtIncompatible;

@GwtIncompatible(value = "This exception builder uses Java ResourceBundle and MessageFormat which are GWT incompatible")
public class ExceptionBuilder {
    private static final Logger LOGGER = Logger.getLogger(SugarException.class.getName());

    private static final String BUNDLE_NAME = "SugarErrors";

    private static ResourceBundle errorMessageBundle;

    private ExceptionBuilder() {
        throw new IllegalAccessError("Utility class");
    }

    public static SugarTechnicalException createTechnicalException(TechnicalErrorCode code, Object... params) {
        return new SugarTechnicalException(code.name(), buildMessage(code.name(), params), getCause(params));
    }

    public static SugarFunctionalException createFunctionalException(FunctionalErrorCode code, Object... params) {
        return new SugarFunctionalException(code.name(), buildMessage(code.name(), params), getCause(params));
    }

    private static String buildMessage(String code, Object[] params) {
        return code + ": " + getMessageCaption(code, params);
    }

    private static String getMessageCaption(String code, Object[] param) {
        String message = null;
        try {
            if (getRessourceBundle() == null) {
                return "";
            }

            message = getRessourceBundle().getString(code);
        }
        catch (MissingResourceException mre) {
            LOGGER.warning("Can't find resource error message in " + BUNDLE_NAME + " for error code " + code);
        }
        if (message == null) {
            return "";
        }
        if (param != null) {
            return MessageFormat.format(message, param);
        }
        return message;
    }

    /**
     * get the resource bundle
     * 
     * @return
     */
    private static ResourceBundle getRessourceBundle() {
        if (errorMessageBundle == null) {
            createErrorMessageBundle();
        }
        return errorMessageBundle;
    }

    /**
     * Create a instance of the resource bundle
     * 
     * @return
     */
    private synchronized static void createErrorMessageBundle() {
        if (errorMessageBundle != null) {
            return;
        }

        errorMessageBundle = ResourceBundle.getBundle(BUNDLE_NAME);

        if (errorMessageBundle == null) {
            LOGGER.severe("Error: cannot open bundle " + BUNDLE_NAME);
        }
    }

    private static Throwable getCause(Object[] params) {
        if (params == null || params.length == 0) {
            return null;
        }
        for (Object object : params) {
            if (object instanceof Throwable) {
                return (Throwable) object;
            }
        }
        return null;
    }
}