package com.bnpp.cardif.sugar.domain.tracker;

import java.util.Date;

import org.aspectj.lang.ProceedingJoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StopWatch;

import com.bnpp.cardif.sugar.security.AuthenticatedUser;

public abstract class LoggerInterceptor {
    protected static final String METHOD_ENTRY_PHRASE = "=== IN method : {} ";

    protected static final String METHOD_OUTPUT_PHRASE = "=== OUT method : {} ";

    protected final Logger interceptorLogger = LoggerFactory.getLogger(LoggerInterceptor.class);

    private boolean isPerfLoggingEnabled;

    protected void logAction(ProceedingJoinPoint pjp, StopWatch stopWatch, Date startDate,
            AuthenticatedUser authenticatedUser, boolean success, String errorCode) {
        logAction(pjp, stopWatch, startDate, authenticatedUser, success, errorCode, "");
    }

    protected void logAction(ProceedingJoinPoint pjp, StopWatch stopWatch, Date startDate,
            AuthenticatedUser authenticatedUser, boolean success, String errorCode, String ids) {

        String successResult = (success) ? "OK" : "KO";
        String currentBusinessScope = authenticatedUser.getCurrentBusinessScope();
        if (currentBusinessScope == null) {
            currentBusinessScope = "";
        }
        String requestId = authenticatedUser.getRequestId();
        if (requestId == null) {
            requestId = "";
        }

        StringBuilder actionLog = new StringBuilder();
        actionLog.append(startDate + "\t");
        actionLog.append(authenticatedUser.getUsername() + "\t");
        actionLog.append(pjp.getSignature().toShortString() + "\t");
        actionLog.append(successResult + "\t");
        actionLog.append(errorCode + "\t");
        actionLog.append(currentBusinessScope + "\t");
        actionLog.append(stopWatch.getTotalTimeMillis() + "\t");
        actionLog.append(authenticatedUser.getTimeToSpentOnAuthentication() + "\t");
        actionLog.append(authenticatedUser.getToken() + "\t");
        actionLog.append(requestId + "\t");
        actionLog.append(ids + "\t");
        interceptorLogger.info(actionLog.toString());
    }

    public boolean isPerfLoggingEnabled() {
        return isPerfLoggingEnabled;
    }

    public void setIsPerfLoggingEnabled(boolean isPerfLoggingEnabled) {
        this.isPerfLoggingEnabled = isPerfLoggingEnabled;
    }
}
