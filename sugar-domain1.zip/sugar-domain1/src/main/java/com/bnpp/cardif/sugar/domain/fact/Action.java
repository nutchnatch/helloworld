package com.bnpp.cardif.sugar.domain.fact;

public enum Action {
    CREATE, READ, UPDATE, UPDATE_RETENTION_DATE, DELETE, SEARCH, CLOSE, LOCK, UNLOCK, TRANSFER;
}
