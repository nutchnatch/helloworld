package com.bnpp.cardif.sugar.domain.exception;

/**
 * Defines all error codes
 * 
 * @author Christopher Laszczuk
 * 
 */
public enum FunctionalErrorCode {
    /**
     * Generic error
     */
    G666,

    // Error codes for component

    /**
     * Empty list of component
     */
    F00001,

    /**
     * Cannot delete a component which is attached to a folder
     */
    F00002,

    /**
     * A physical envelope cannot contains another one
     */
    F00003,

    /**
     * Not allowed children class
     */
    F00004,

    /**
     * Invalid component. It must have data
     */
    F00005,
    /**
     * Component scope must be set
     */
    F00006,
    /**
     * Scope must be unique for all component
     */

    F00007,
    /**
     * Component class must be set
     */
    F00008,
    /**
     * Component class must be active
     */
    F00009,
    /**
     * Component must have a first level parent
     */
    F00010,
    /**
     * Component cannot be invalidated
     */

    F00011,
    /**
     * Component not exist
     */
    F00012,
    /**
     * Creation date after updating date
     */
    F00013,
    /**
     * Class must be active
     * 
     */
    F00014,
    /**
     * Componnent category must be set
     * 
     */
    F00015,
    /**
     * Component and class must be of same category
     * 
     */
    F00016,
    /**
     * First level componnent cannot have parent
     */
    F00017,
    /**
     * Component cannot be it own child
     */
    F00018,
    /**
     * Component cannot have its parent as child
     */
    F00019,
    /**
     * Document tag value is not in allowed values
     * 
     */
    F00020,
    /**
     * Document fileData URIs must not be empty
     * 
     */
    F00021,
    /**
     * Document fileData documentFile must be empty
     * 
     */
    F00022,
    /**
     * Criterion operator is not correctly set
     * 
     */
    F00023,
    /**
     * Criterion type is not correctly set
     * 
     */
    F00024,
    /**
     * Criterion level is not correctly set
     * 
     */
    F00025,
    /**
     * Criterion name must not be empty
     * 
     */
    F00026,
    /**
     * Criterion value must not be empty
     * 
     */
    F00027,
    /**
     * Order level is not correctly set
     * 
     */
    F00028,
    /**
     * Order name must not be empty
     * 
     */
    F00029,
    /**
     * Order type must is not set correctly
     * 
     */
    F00030,
    /**
     * Criteria item is not set correctly
     * 
     */
    F00031,
    /**
     * One child component is missing from the request
     * 
     */
    F00032,
    /**
     * Max value must be greater than 0
     * 
     */
    F00033,
    /**
     * Criterion value cannot contains * because it is a protectect char
     * 
     */
    F00034,
    /**
     * Document has a more recent version in database
     */
    F00035,

    /**
     * Document has no valid parent Id
     */
    F00036,
    /**
     * Document has no valid directionCode
     */
    F00037,
    // Error codes for folders
    /**
     * No folder to process
     */
    F00101,

    /**
     * Folder name must be unique
     */
    F00102,

    /**
     * Cannot change folder class if it is not empty
     */
    F00103,
    /**
     * Folder Scope must be set and non empty
     */
    F00104,

    /**
     * Folders should have same scope
     */
    F00105,
    /**
     * Folders to process with same name
     */
    F00106,
    /**
     * Folder data must be set
     */
    F00107,
    /**
     * Not valid folder data
     */

    F00108,
    /**
     * Folder class must be
     */
    F00109,
    /**
     * Folder does not have a mandatory tag
     */

    F00110,
    /**
     * Folder name is not set
     */
    F00111,
    /**
     * Folder owner must be set
     */
    F00112,
    /**
     * Folder class must be set
     */
    F00113,
    /**
     * Folder has invalid pattern for tag
     */
    F00114,
    /**
     * Folder tag value is not in allowed values
     */
    F00115,
    /**
     * Folder is closed, it cannot be updated.
     */
    F00116,
    /**
     * Folder ChildComponent must be set
     */
    F00117,
    /**
     * Folder must only contains tag from set folder class
     */
    F00118,
    // Error codes for classes

    /**
     * Retention duration must be set on document class
     */
    F00201,
    /**
     * Retention duration unit must be set on document class
     */
    F00202,

    /**
     * Invalid retention duration unit
     */
    F00203,

    /**
     * Class symbolic name must be set
     */
    F00204,
    /**
     * Class symbolic name must be unique
     */
    F00205,

    /**
     * Class does not exist
     */
    F00206,

    /**
     * Class symbolic name must not be changed
     */

    F00207,
    /**
     * Provided class list must not be empty
     */
    F00208,
    /**
     * All provided classes must have same scope
     */
    F00209,
    /**
     * Class symbolic name must be unique in provided list
     */
    F00210,
    /**
     * Class scope must be set
     */
    F00211,

    /**
     * 
     * ClassId must not be changed
     */
    F00212,
    /**
     * Class category must be set
     * 
     */
    F00213,
    /**
     * Class retention duration value must be set
     */
    F00214,
    /**
     * Tag class value type must be set
     * 
     */
    F00215,
    /**
     * Class long label must not be changed
     * 
     */
    F00216,

    // Error codes for security

    /**
     * No ACL on business scope
     */
    F00301,

    /**
     * Not allowed to create a basket
     */
    F00302,

    /**
     * Not allowed to get a basket as admin
     */
    F00303,

    /**
     * Not allowed to update a basket
     */
    F00304,

    /**
     * Not allowed to delete a basket
     */
    F00305,

    /**
     * Not allowed to store a component
     */
    F00306,

    /**
     * Not allowed to get a component
     */
    F00307,

    /**
     * Not allowed to update a component
     */
    F00308,

    /**
     * Not allowed to delete a component
     */
    F00309,

    /**
     * Not allowed to create a component class
     */
    F00310,

    /**
     * Not allowed to access to a component class
     */
    F00311,

    /**
     * Not allowed to access to a folder class
     */
    F00312,

    /**
     * Not allowed to create a folder class
     */
    F00313,

    /**
     * No ACL for class instances
     */
    F00314,

    /**
     * Invalid user in security context
     */
    F00315,

    /**
     * User is not allowed in this business scope
     */
    F00316,
    /**
     * User must be admin to create business scope
     */
    F00317,

    // Error codes for tasks and baskets

    /**
     * Symbolic name must be set on basket
     */
    F00401,

    /**
     * Symbolic name of a basket must be unique
     */
    F00402,

    /**
     * Not empty basket cannot be deleted
     */
    F00403,

    /**
     * Task cannot be found
     */
    F00404,
    /**
     * Task is already locked
     */
    F00405,
    /**
     * Task is already unlocked
     */
    F00406,
    /**
     * Basket scope must be set
     */
    F00407,
    /**
     * Provided list must be for one scope
     */
    F00408,
    /**
     * Basket does not exist
     */
    F00409,
    /**
     * Basket symbolic name cannot be changed
     */
    F00410,
    // Error codes for TDS

    /**
     * Cannot fetch business rules file because no business scope
     */
    F00501,

    /**
     * Invalid object pushed to TDS service
     */
    F00502,

    /**
     * Invalid new status for a task
     */
    F00503,

    /**
     * Basket defined in business rules does not exist
     */
    F00504,

    /**
     * Invalid business rules
     */
    F00505,

    // Error codes for Business Scopes

    /**
     * Business scope symbolic name must be unique
     */
    F00601,
    /**
     * Business scope must exist
     */

    F00602,
    /**
     * Business scope symbolic name must not be empty
     */
    F00603,
    /**
     * Business scope symbolic name must be unique in provided list
     */
    F00604,
    /**
     * Provided business scope list must not be empty
     */
    F00605,
    /**
     * Scope id cannot be changed
     */
    F00606,
    // Error codes for DocumentFiles
    /**
     * DocumentFile has no content
     */
    F00701,

    // Error codes for reporting
    /**
     * The starting is after the ending date
     */
    F00801,
    /**
     * The ending date is after the current date
     */
    F00802,
    /**
     * The starting date must be set
     */
    F00803,
    /**
     * The ending date must be set
     */
    F00804,

    /**
     * Language must be set properly
     */
    F00805,

}
