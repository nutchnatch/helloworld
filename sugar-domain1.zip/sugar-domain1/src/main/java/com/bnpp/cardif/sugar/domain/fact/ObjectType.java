package com.bnpp.cardif.sugar.domain.fact;

/**
 * Defines the type of object on which a {@link Fact} can occurs
 * 
 * @author Christopher Laszczuk
 * 
 */
public enum ObjectType {
    DOCUMENT, ENVELOPE, FILE, FOLDER, DOCUMENT_CLASS, ENVELOPE_CLASS, FOLDER_CLASS, TAG_CLASS, BASKET, TASK, BUSINESS_SCOPE;
}
