package com.bnpp.cardif.sugar.domain.model;

import java.io.Serializable;

import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;

public class FolderClassDefinition implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 5509131438459122006L;

    private TagsDefinition tagFieldDefinitions = new TagsDefinition();

    private FolderClass folderClass;

    public FolderClassDefinition() {

    }

    public TagsDefinition getTagFieldDefinitions() {
        return tagFieldDefinitions;
    }

    public void setTagFieldDefinitions(TagsDefinition tagFieldDefinitions) {
        this.tagFieldDefinitions = tagFieldDefinitions;
    }

    public FolderClass getFolderClass() {
        return folderClass;
    }

    public void setFolderClass(FolderClass folderClass) {
        this.folderClass = folderClass;
    }

}
