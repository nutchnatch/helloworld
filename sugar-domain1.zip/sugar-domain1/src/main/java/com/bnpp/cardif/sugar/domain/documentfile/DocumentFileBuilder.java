package com.bnpp.cardif.sugar.domain.documentfile;

import java.util.Date;

import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;

/**
 * According to builder patter, this helper allows to easily instantiate a
 * {@link DocumentFile}
 * 
 * @author Christopher Laszczuk
 * 
 */
public class DocumentFileBuilder {
    private final String scope;

    private String URI;

    private String name;

    private String formatCode;

    private Date createDate;

    private DocumentFileBuilder(String scope) {
        this.scope = scope;
    }

    /**
     * Instantiates the builder according to supplied scope. This parameter is
     * necessary because of a document file must be attached to one.
     * 
     * @param scope
     *            The business scope
     * @return A instance of DocumentBuilder
     */
    public static DocumentFileBuilder scope(String scope) {
        return new DocumentFileBuilder(scope);
    }

    public DocumentFileBuilder URI(String URI) {
        this.URI = URI;
        return this;
    }

    public DocumentFileBuilder name(String name) {
        this.name = name;
        return this;
    }

    public DocumentFileBuilder formatCode(String formatCode) {
        this.formatCode = formatCode;
        return this;
    }

    public DocumentFileBuilder createDate(Date createDate) {
        this.createDate = new Date(createDate.getTime());
        return this;
    }

    /**
     * Instantiates an instance of {@link DocumentFile} according to passed
     * parameters
     * 
     * @return The desired {@link DocumentFile}
     */
    public DocumentFile build() {
        DocumentFile documentFile = new DocumentFile();
        documentFile.setScope(scope);
        documentFile.setURI(URI);
        documentFile.setName(name);
        documentFile.setFormatCode(formatCode);
        documentFile.setCreateDate(createDate);
        return documentFile;
    }
}