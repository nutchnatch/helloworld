package com.bnpp.cardif.sugar.domain.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.arondor.flower.model.fields.FieldDefinition;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "")
@XmlRootElement(name = "TagsDefinition", namespace = "http://www.arondor.com/schema/flower/calyx")
public class TagsDefinition implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1717396808050179558L;

    public TagsDefinition() {

    }

    @XmlElement(name = "TagFieldDefinition", namespace = "http://www.arondor.com/schema/flower/calyx")
    private List<FieldDefinition> tagFieldDefinitions = new ArrayList<FieldDefinition>();

    public List<FieldDefinition> getTagFieldDefinitions() {
        return tagFieldDefinitions;
    }

    public void setTagFieldDefinitions(List<FieldDefinition> tagDefinitions) {
        this.tagFieldDefinitions = tagDefinitions;
    }

    @XmlElement(name = "TagFieldReference", namespace = "http://www.arondor.com/schema/flower/calyx")
    private List<String> tagFieldNames = new ArrayList<String>();

    public List<String> getTagFieldNames() {
        return tagFieldNames;
    }

    public void setTagFieldNames(List<String> tagFieldNames) {
        this.tagFieldNames = tagFieldNames;
    }

}
