package com.bnpp.cardif.sugar.domain.model;

/**
 * 
 * Phase wich can be used for a component or a folder
 * 
 */
public enum Phase {
    INSERT("Insert"), MODIFY("Modify"), PROCESSING("Processing"), READONLY("Read Only");
    private final String value;

    private Phase(String value) {
        this.value = value;
    }

    public String getPhaseValue() {
        return value;
    }
}
