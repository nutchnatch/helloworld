package com.bnpp.cardif.sugar.domain.test;

import java.math.BigInteger;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DocumentStatusCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DocumentStatusType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DurationType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ElectronicDocumentDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tags;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.TimeUnitConstance;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.ChildObject;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.FileData;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.i18n.v1.MCOI18NLabel;
import com.google.common.collect.Lists;

/**
 * Utility class allowing to generate documents for test purposes
 * 
 * @author Christopher Laszczuk
 * 
 */
public class DocumentMockUtil {

    public static AclId getAclInstance() {
        return new AclId("8a1475b1-d5b4-49bb-ad5e-9aa899444021", "Arondor", "DefaultScheme");

    }

    public static DocumentClass buildFakeDocumentClass() {
        DocumentClass documentClass = new DocumentClass();
        documentClass.setActive(true);
        documentClass.setCategory(Category.ENVELOPE);
        ClassId clazzId = new ClassId();
        clazzId.setValue("c79f71c3-c7fd-48bb-a4e8-98ea816a3356");
        clazzId.setIssuer("CARDIF");
        documentClass.setClassId(clazzId);
        documentClass.setCreateDate(new Date());
        documentClass.setScope("Syldavia");
        documentClass.setLongLabel("ITDocumentClass" + UUID.randomUUID());
        documentClass.setRetentionDuration(new DurationType(new BigInteger("1"), TimeUnitConstance.DAY.name()));

        return documentClass;
    }

    public static Basket buildFakeBasket() {
        Basket basket = new Basket();
        basket.setBasketId(new BasketId("c79f71c3-c7fd-48bb-a4e8-98ea816a3356", "CARDIF", "Sugar"));
        basket.setScope("Syldavia");
        basket.setSymbolicName("FakeBasket" + UUID.randomUUID());
        basket.getDisplayName().addAll((Lists.newArrayList(new MCOI18NLabel("Fake basket", "EN"))));
        return basket;
    }

    public static FolderClass buildFakeFolderClass() {

        FolderClass folderClass = new FolderClass();
        folderClass.setLongLabel("FakeFolder");
        folderClass.setActive(true);
        ClassId clazzId = new ClassId();
        clazzId.setValue("c79f71c3-c7fd-48bb-a4e8-98ea816a3356");
        clazzId.setIssuer("CARDIF");
        folderClass.setClassId(clazzId);
        folderClass.setScope("Syldavia");
        folderClass.getShortLabel().addAll((Lists.newArrayList(new MCOI18NLabel("FakeFolder", "EN"))));
        folderClass.setLongLabel("ITFolderClass" + UUID.randomUUID());
        folderClass.setRetentionDuration(new DurationType(new BigInteger("1"), TimeUnitConstance.DAY.name()));
        return folderClass;

    }

    public static Document buildClaimDocument() {
        Document document = new Document();
        document.setScope("Syldavia");
        document.setCategory(Category.DOCUMENT);

        Id id = new Id();
        id.setIssuer("CARDIF");
        id.setScheme("Sugar");
        id.setValue(UUID.randomUUID().toString());
        document.setId(id);

        ElectronicDocumentDataType data = new ElectronicDocumentDataType();
        ClassId clazz = new ClassId();
        clazz.setValue("71c3c79f-c7fd-48bb-a4e8-6a335698ea81");
        clazz.setIssuer("CARDIF");
        data.setClassId(clazz);
        data.setCreatnDate(new Date());
        data.setUpdtDate(new Date());
        data.setName("Auto generated claim");
        data.setValidityCode(ValdtyCode.INVALID);
        data.setRetentionStartDate(dateFor(Calendar.DECEMBER, 12, 2000));
        document.setData(data);
        document.setStatus(new DocumentStatusType());
        document.getStatus().setCode((DocumentStatusCode.NEW.name()));
        document.setChildObject(new ChildObject());
        FileData fileData = new FileData();
        fileData.getURI().add("my fiel.txt");
        document.setFileData(fileData);

        Tags tags = new Tags();
        Tag policy = new Tag();
        policy.setName("policy");
        policy.setValue("ref6859");
        tags.getTag().add(policy);
        Tag subscriberName = new Tag();
        subscriberName.setName("SubscriberName");
        subscriberName.setValue("Mr Smith");
        tags.getTag().add(subscriberName);
        document.setTags(tags);
        return document;
    }

    public static Date dateFor(int month, int day, int year) {
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, day);
        return cal.getTime();
    }

    public static Document buildMedicalReportWithoutId() {
        Document document = new Document();
        document.setScope("Syldavia");
        document.setCategory(Category.DOCUMENT);

        ElectronicDocumentDataType data = new ElectronicDocumentDataType();
        ClassId clazz = new ClassId();
        clazz.setValue("c67c3811-1459-483d-b907-a701ebf47bed");
        clazz.setIssuer("CARDIF");
        data.setClassId(clazz);
        data.setValidityCode(ValdtyCode.INVALID);
        // data.setCreatnDate(new Date());
        document.setData(data);

        FileData fileData = new FileData();
        fileData.getURI().add("my fiel.txt");
        document.setFileData(fileData);

        Tags tags = new Tags();
        Tag policy = new Tag();
        policy.setName("policy");
        policy.setValue("P9344E46431");
        tags.getTag().add(policy);
        Tag contractType = new Tag();
        contractType.setName("ContractType");
        contractType.setValue("life");
        tags.getTag().add(contractType);
        document.setTags(tags);

        return document;
    }

    public static Document buildEnvelope() {
        Document envelope = new Document();
        Id id = new Id();
        id.setValue(UUID.randomUUID().toString());
        id.setIssuer("CARDIF");
        id.setScheme("Sugar");
        envelope.setId(id);
        ElectronicDocumentDataType data = new ElectronicDocumentDataType();
        ClassId clazz = new ClassId();
        clazz.setValue("b21ba156-f5be-407e-a0b5-6c74aedea9ee");
        clazz.setIssuer("CARDIF");
        data.setClassId(clazz);
        data.setValidityCode(ValdtyCode.INVALID);
        Date currentDate = new Date();
        data.setCreatnDate(currentDate);
        envelope.setCategory(Category.ENVELOPE);
        envelope.setData(data);
        envelope.setChildObject(new ChildObject());
        envelope.setScope("Syldavia");
        envelope.setStatus(new DocumentStatusType());
        envelope.getStatus().setCode(DocumentStatusCode.NEW.toString());
        envelope.getData().setUpdtDate(currentDate);
        envelope.getData().setConfdntltyLvl("SECRET");
        envelope.getData().setDirectionCode("IN");
        return envelope;

    }
}
