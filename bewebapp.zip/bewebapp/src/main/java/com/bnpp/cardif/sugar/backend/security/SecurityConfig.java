package com.bnpp.cardif.sugar.backend.security;

import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import com.bnpp.cardif.sugar.security.SugarAclPermissionEvaluator;

/**
 * Configuration object for Spring Security. The SecurityConfig will:
 * 
 * - Require authentication to every URL in your application
 * 
 * - Generate a login form for you
 * 
 * - Allow the user with the Username user and the Password password to
 * authenticate with form based authentication
 * 
 * - Allow the user to logout
 * 
 * - CSRF attack prevention
 * 
 * - Session Fixation protection
 * 
 * - Security Header integration
 * 
 * -- HTTP Strict Transport Security for secure requests
 * 
 * -- X-Content-Type-Options integration
 * 
 * -- Cache Control (can be overridden later by your application to allow
 * caching of your static resources)
 * 
 * -- X-XSS-Protection integration
 * 
 * -- X-Frame-Options integration to help prevent Clickjacking
 * 
 * -Integrate with the following Servlet API methods
 * 
 * -- HttpServletRequest#getRemoteUser()
 * 
 * -- HttpServletRequest.html#getUserPrincipal()
 * 
 * -- HttpServletRequest.html#isUserInRole(java.lang.String)
 * 
 * -- HttpServletRequest.html#login(java.lang.String, java.lang.String)
 * 
 * -- HttpServletRequest.html#logout()
 * 
 * @author 831743
 *
 */
@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true, jsr250Enabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(SecurityConfig.class);

    @Autowired
    AuthenticationProvider backendAuthenticationProvider;

    @Autowired
    AccessDeniedHandler customAccessDeniedHandler;

    @Autowired
    AuthenticationEntryPoint customAuthenticationEntryPoint;

    @Autowired
    SugarAclPermissionEvaluator sugarAclPermissionEvaluator;

    private List<String> getOpenUrlList() {
        List<String> urlList = new ArrayList<>();
        urlList.add("/application/info");
        urlList.add("/application/health");
        return urlList;
    }

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        LOGGER.debug("configureGlobal");
        auth.authenticationProvider(backendAuthenticationProvider);
        auth.eraseCredentials(false);
    }

    /**
     * Configuring the global Web security to ignore some directories.
     */
    @Override
    public void configure(WebSecurity web) throws Exception {
        LOGGER.debug("configure WebSecurity");
        // Spring Security should completely ignore URLs starting with
        // resources for swagger doc
        web.ignoring().antMatchers("/swagger-ui.html").and();
        web.ignoring().antMatchers("/webjars/springfox-swagger-ui/**").and();
        web.ignoring().antMatchers("/swagger-resources/**").and();
        web.ignoring().antMatchers("/v2/api-docs").and();
        web.ignoring().antMatchers("/v2/api-docs/").and();
    }

    /**
     * Configuring the security to specify the various access level of resources
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        LOGGER.debug("configure HttpSecurity");
        // Set Http basic authentication
        http.httpBasic().and();
        // Set custom accessDenied
        http.exceptionHandling().accessDeniedHandler(customAccessDeniedHandler);
        http.exceptionHandling().authenticationEntryPoint(customAuthenticationEntryPoint);
        // Set the specific filter to get Token for authentication
        HeaderTokenAuthenticationFilter filter = new HeaderTokenAuthenticationFilter(this.authenticationManagerBean(),
                customAuthenticationEntryPoint);
        http.addFilterAt(filter, BasicAuthenticationFilter.class);
        // Set the authorized pages for unAuthenticated users
        http.authorizeRequests().antMatchers("/static/index.html", "/static/login.html", "/static/", "/").permitAll()
                .and();
        // Set the services for unAuthenticated users because they have their
        // own authentication check.
        http.authorizeRequests().antMatchers("/services", "/services/**").permitAll().and();
        http.authorizeRequests().antMatchers("/rest/**").permitAll().and();
        // set specific "open" API that don't need authenticated user
        List<String> openUrlList = this.getOpenUrlList();
        for (String url : openUrlList) {
            http.authorizeRequests().antMatchers(url).permitAll().and();
        }
        // Set all other requests requires authentication.
        http.authorizeRequests().anyRequest().authenticated().and();
        // disable csrf
        http.csrf().disable();
    }

}
