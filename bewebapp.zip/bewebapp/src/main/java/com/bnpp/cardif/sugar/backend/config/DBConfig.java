/**
 * 
 */
package com.bnpp.cardif.sugar.backend.config;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.support.lob.DefaultLobHandler;
import org.springframework.jdbc.support.nativejdbc.SimpleNativeJdbcExtractor;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @author 831743
 *
 */
@EnableTransactionManagement(proxyTargetClass = true)
@Configuration
public class DBConfig
{
    private static final Logger LOGGER = LoggerFactory.getLogger(DBConfig.class);

    @Autowired
    private Environment env;

    @Value("${spring.datasource.url}")
    private String datasourceUrl;

    @Value("${spring.datasource.driver-class-name}")
    private String datasourceDriverClassName;

    @Value("${spring.datasource.username}")
    private String datasourceUsername;

    @Value("${spring.datasource.password}")
    private String datasourcePassword;

    @Value("${spring.datasource.tomcat.default-auto-commit}")
    private Boolean defaultAutoCommit;

    @Value("${spring.datasource.tomcat.max-active}")
    private int maxActive;

    @Value("${spring.datasource.tomcat.max-idle}")
    private int maxIdle;

    @Value("${spring.datasource.tomcat.min-idle}")
    private int minIdle;

    @Value("${spring.datasource.tomcat.initial-size}")
    private int initialSize;

    @Value("${spring.datasource.tomcat.max-wait}")
    private int maxWait;

    @Value("${spring.datasource.tomcat.test-on-borrow}")
    private Boolean testOnBorrow;

    @Value("${spring.datasource.tomcat.test-on-return}")
    private Boolean testOnReturn;

    @Value("${spring.datasource.tomcat.test-while-idle}")
    private Boolean testWhileIdle;

    @Value("${spring.datasource.tomcat.time-between-eviction-runs-millis}")
    private int timeBetweenEvictionRunsMillis;

    @Value("${spring.datasource.tomcat.validation-interval}")
    private long validationInterval;
    
    @Value("${spring.datasource.tomcat.validator-class-name}")
    private String validatorClassName;

    @Value("${spring.datasource.tomcat.remove-abandoned}")
    private Boolean removeAbandoned;

    @Value("${spring.datasource.tomcat.remove-abandoned-timeout}")
    private int removeAbandonedTimeout;

    @Value("${spring.datasource.tomcat.log-abandoned}")
    private Boolean logAbandoned;

    @Bean
    public DataSource dataSource()
    {
        LOGGER.debug("configure datasource");
        org.apache.tomcat.jdbc.pool.DataSource datasource = new org.apache.tomcat.jdbc.pool.DataSource();
        // basic settings
        datasource.setUrl(this.datasourceUrl);
        datasource.setDriverClassName(this.datasourceDriverClassName);
        datasource.setUsername(this.datasourceUsername);
        datasource.setPassword(this.datasourcePassword);
        // apache pool settings
        datasource.setDefaultAutoCommit(defaultAutoCommit);
        datasource.setMaxActive(this.maxActive);
        datasource.setMaxIdle(this.maxIdle);
        datasource.setMinIdle(this.minIdle);
        datasource.setInitialSize(this.initialSize);
        datasource.setMaxWait(this.maxWait);
        datasource.setTestOnBorrow(this.testOnBorrow);
        datasource.setTestOnReturn(this.testOnReturn);
        datasource.setTestWhileIdle(this.testWhileIdle);
        datasource.setTimeBetweenEvictionRunsMillis(this.timeBetweenEvictionRunsMillis);
        datasource.setValidationInterval(this.validationInterval);
        datasource.setValidatorClassName(this.validatorClassName);
        datasource.setRemoveAbandoned(this.removeAbandoned);
        datasource.setRemoveAbandonedTimeout(this.removeAbandonedTimeout);
        datasource.setLogAbandoned(this.logAbandoned);

        return datasource;
    }

    @Bean
    public JdbcTemplate jdbcTemplate(DataSource dataSource, SimpleNativeJdbcExtractor nativeJdbcExtractor) {
        LOGGER.debug("configure JdbcTemplate");
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        jdbcTemplate.setNativeJdbcExtractor(nativeJdbcExtractor);
        return jdbcTemplate;
    }

    @Bean
    public DataSourceTransactionManager txManager() {
        LOGGER.debug("configure txManager");
        DataSourceTransactionManager txManager = new DataSourceTransactionManager();
        txManager.setDataSource(dataSource());
        return txManager;
    }
    
    @Bean
    public SimpleNativeJdbcExtractor nativeJdbcExtractor() {
        return new SimpleNativeJdbcExtractor();
    }
    
    @Bean
    public DefaultLobHandler lobHandler() {
        return new DefaultLobHandler();
    }

}
