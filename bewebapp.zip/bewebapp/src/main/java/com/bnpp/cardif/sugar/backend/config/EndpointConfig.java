package com.bnpp.cardif.sugar.backend.config;

import javax.xml.ws.Endpoint;

import org.apache.cxf.Bus;
import org.apache.cxf.bus.spring.SpringBus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.apache.cxf.transport.servlet.CXFServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.bnpp.cardif.sugar.ws.server.acl.SugarAclServer;
import com.bnpp.cardif.sugar.ws.server.basket.SugarBasketServer;
import com.bnpp.cardif.sugar.ws.server.businessscope.SugarBusinessScopeServer;
import com.bnpp.cardif.sugar.ws.server.document.SugarDocumentServer;
import com.bnpp.cardif.sugar.ws.server.documentannotation.SugarDocumentAnnotationServer;
import com.bnpp.cardif.sugar.ws.server.documentclass.SugarDocumentClassServer;
import com.bnpp.cardif.sugar.ws.server.documentfile.SugarDocumentFileServer;
import com.bnpp.cardif.sugar.ws.server.folder.SugarFolderServer;
import com.bnpp.cardif.sugar.ws.server.folderclass.SugarFolderClassServer;
import com.bnpp.cardif.sugar.ws.server.reporting.SugarReportingServer;
import com.bnpp.cardif.sugar.ws.server.tagclass.SugarTagclassServer;
import com.bnpp.cardif.sugar.ws.server.task.SugarTaskServer;

@Configuration
@ComponentScan(basePackages = { "com.bnpp.cardif.sugar.ws.server" })
public class EndpointConfig {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(EndpointConfig.class);
    
    @Autowired
    private SugarAclServer sugarAclServer;
    
    @Autowired
    private SugarBasketServer sugarBasketServer;
    
    @Autowired
    private SugarBusinessScopeServer sugarBusinessScopeServer;
    
    @Autowired
    private SugarDocumentServer sugarDocumentServer;
    
    @Autowired
    private SugarDocumentAnnotationServer sugarDocumentAnnotationServer;
    
    @Autowired
    private SugarDocumentClassServer sugarDocumentClassServer;
    
    @Autowired
    private SugarDocumentFileServer sugarDocumentFileServer;
    
    @Autowired
    private SugarFolderServer sugarFolderServer;
    
    @Autowired
    private SugarFolderClassServer sugarFolderClassServer;
    
    @Autowired
    private SugarReportingServer sugarReportingServer;
    
    @Autowired
    private SugarTagclassServer sugarTagclassServer;
    
    @Autowired
    private SugarTaskServer sugarTaskServer;
    

    @Bean
    public ServletRegistrationBean cxfServlet() {
        LOGGER.debug("EndpointConfig.cxfServlet");
        return new ServletRegistrationBean(new CXFServlet(), "/services/*");
    }

    @Bean(name = Bus.DEFAULT_BUS_ID)
    public SpringBus springBus() {
        LOGGER.debug("EndpointConfig.springBus");
        return new SpringBus();
    }    

    
    @Bean
    public Endpoint sugarAclEndpoint(Bus bus) {
      EndpointImpl endpoint = new EndpointImpl(bus, sugarAclServer);
      endpoint.publish("/SugarAcl");
      return endpoint;
    }
    
    @Bean
    public Endpoint sugarBasketEndpoint(Bus bus) {
      EndpointImpl endpoint = new EndpointImpl(bus, sugarBasketServer);
      endpoint.publish("/SugarBasket");
      return endpoint;
    }
    
    @Bean
    public Endpoint sugarBusinessScopeEndpoint(Bus bus) {
      EndpointImpl endpoint = new EndpointImpl(bus, sugarBusinessScopeServer);
      endpoint.publish("/SugarBusinessScope");
      return endpoint;
    }
    
    @Bean
    public Endpoint sugarDocumentEndpoint(Bus bus) {
      EndpointImpl endpoint = new EndpointImpl(bus, sugarDocumentServer);
      endpoint.publish("/SugarDocument");
      return endpoint;
    }
    
    @Bean
    public Endpoint sugarDocumentAnnotationEndpoint(Bus bus) {
      EndpointImpl endpoint = new EndpointImpl(bus, sugarDocumentAnnotationServer);
      endpoint.publish("/SugarDocumentAnnotation");
      return endpoint;
    }
    
    @Bean
    public Endpoint sugarDocumentClassEndpoint(Bus bus) {
      EndpointImpl endpoint = new EndpointImpl(bus, sugarDocumentClassServer);
      endpoint.publish("/SugarDocumentClass");
      return endpoint;
    }
    
    @Bean
    public Endpoint sugarDocumentFileEndpoint(Bus bus) {
      EndpointImpl endpoint = new EndpointImpl(bus, sugarDocumentFileServer);
      endpoint.publish("/SugarDocumentFile");
      return endpoint;
    }
    
    @Bean
    public Endpoint sugarFolderEndpoint(Bus bus) {
      EndpointImpl endpoint = new EndpointImpl(bus, sugarFolderServer);
      endpoint.publish("/SugarFolder");
      return endpoint;
    }
    
    @Bean
    public Endpoint sugarFolderClassEndpoint(Bus bus) {
      EndpointImpl endpoint = new EndpointImpl(bus, sugarFolderClassServer);
      endpoint.publish("/SugarFolderClass");
      return endpoint;
    }
    
    @Bean
    public Endpoint sugarReportingEndpoint(Bus bus) {
      EndpointImpl endpoint = new EndpointImpl(bus, sugarReportingServer);
      endpoint.publish("/SugarReporting");
      return endpoint;
    }
    
    @Bean
    public Endpoint sugarTagclassEndpoint(Bus bus) {
      EndpointImpl endpoint = new EndpointImpl(bus, sugarTagclassServer);
      endpoint.publish("/SugarTagclass");
      return endpoint;
    }
    
    @Bean
    public Endpoint sugarTaskEndpoint(Bus bus) {
      EndpointImpl endpoint = new EndpointImpl(bus, sugarTaskServer);
      endpoint.publish("/SugarTask");
      return endpoint;
    }

}
