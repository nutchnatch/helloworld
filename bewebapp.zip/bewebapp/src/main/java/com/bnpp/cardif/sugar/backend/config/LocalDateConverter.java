package com.bnpp.cardif.sugar.backend.config;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Created by b48489 on 25-10-2017.
 */
public final class LocalDateConverter implements Converter<String, LocalDate> {

    private final DateTimeFormatter formatter;

    public LocalDateConverter(String dateFormat) {
        this.formatter = DateTimeFormatter.ofPattern(dateFormat);
    }

    @Override public LocalDate convert(String input) {

        return StringUtils.isEmpty(input) ? null : LocalDate.parse(input, formatter);
    }
}
