package com.bnpp.cardif.sugar.backend.config;

import static java.time.format.DateTimeFormatter.ofPattern;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.FormatterRegistry;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

/**
 * This class configure the Spring MVC controller context for the application.
 * 
 * This context should include all the Spring MVC controllers that will handle
 * the requests to the application.
 * 
 * The @ComponentScan is loading all configuration within the same package (and
 * child packages) as WebMvcConfiguration.
 * 
 * @author 831743
 *
 */
@Configuration
// in this component scan annotation, set all the packages that contains your
// MVC controllers classes.
@ComponentScan(basePackages = { "com.bnpp.cardif.sugar.backend.web", "com.bnpp.cardif.sugar.rest.connector.controller",
        "com.bnpp.cardif.sugar.rest.web.api", "com.bnpp.cardif.sugar.rest.connector.facade.delegate" })
public class WebMvcConfiguration {

    private static final Logger LOGGER = LoggerFactory.getLogger(WebMvcConfiguration.class);

    public static final String DATE_FORMAT = "yyyy-MM-dd";

    /**
     * Configure the date format when map Object->Json and Json->Object
     * 
     * @return Jackson2ObjectMapperBuilderCustomizer
     */
    @SuppressWarnings("squid:S1604")
    @Bean
    public Jackson2ObjectMapperBuilderCustomizer jackson2ObjectMapperBuilderCustomizer() {

        return new Jackson2ObjectMapperBuilderCustomizer() {

            @Override
            public void customize(Jackson2ObjectMapperBuilder jacksonObjectMapperBuilder) {
                jacksonObjectMapperBuilder
                        .serializers(new LocalDateSerializer(DateTimeFormatter.ISO_LOCAL_DATE));
                jacksonObjectMapperBuilder
                        .deserializers(new LocalDateDeserializer(DateTimeFormatter.ISO_LOCAL_DATE));
            }

        };
    }

    @Bean
    public WebMvcConfigurer mvcConfigurer() {

        return new WebMvcConfigurerAdapter() {

            /**
             * Specify the cache period for the resources served by the resource
             * handler, in seconds. The default is to not send any cache headers
             * but to rely on last-modified timestamps only. Set to 0 in order
             * to send cache headers that prevent caching, or to a positive
             * number of seconds to send cache headers with the given max-age
             * value.
             */
            private int cachePeriod = 60;

            /**
             * Add handlers to serve static resources such as images, js, and,
             * css files from specific locations under web application root, the
             * classpath, and others.
             */
            @SuppressWarnings("squid:S1192")
            @Override
            public void addResourceHandlers(ResourceHandlerRegistry registry) {
                LOGGER.debug("addResourceHandlers");
                registry.addResourceHandler("/static/**").addResourceLocations("/static/").setCachePeriod(cachePeriod);
                registry.addResourceHandler("/").addResourceLocations("/index.html").setCachePeriod(cachePeriod);
                registry.addResourceHandler("/index.html").addResourceLocations("/index.html")
                        .setCachePeriod(cachePeriod);
                registry.addResourceHandler("/logout.html").addResourceLocations("/logout.html")
                        .setCachePeriod(cachePeriod);
            }

            /**
             * Convenient subclass of UrlBasedViewResolver that supports
             * InternalResourceView (i.e. Servlets and JSPs) and subclasses such
             * as JstlView.
             * 
             * The view class for all views generated by this resolver can be
             * specified via setViewClass. See UrlBasedViewResolver's javadoc
             * for details. The default is InternalResourceView, or JstlView if
             * the JSTL API is present.
             * 
             * BTW, it's good practice to put JSP files that just serve as views
             * under WEB-INF, to hide them from direct access (e.g. via a
             * manually entered URL). Only controllers will be able to access
             * them then.
             * 
             * Note: When chaining ViewResolvers, an
             * InternalResourceViewResolver always needs to be last, as it will
             * attempt to resolve any view name, no matter whether the
             * underlying resource actually exists.
             * 
             * @return InternalResourceViewResolver
             */
            @Bean
            public InternalResourceViewResolver internalResourceViewResolver() {
                LOGGER.debug("create internalResourceViewResolver");
                InternalResourceViewResolver internalResourceViewResolver = new InternalResourceViewResolver();
                internalResourceViewResolver.setViewClass(JstlView.class);
                internalResourceViewResolver.setPrefix("/WEB-INF/jsp/");
                internalResourceViewResolver.setSuffix(".jsp");
                return internalResourceViewResolver;
            }

            @Bean
            public CommonsMultipartResolver multipartResolver() {
                CommonsMultipartResolver resolver = new CommonsMultipartResolver();
                resolver.setDefaultEncoding("utf-8");
                return resolver;
            }

            /**
             * Spring will no longer use the file extension to override the
             * accepts mediaType of the request.
             */
            @Override
            public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
                configurer.favorPathExtension(false);
                configurer.defaultContentType(MediaType.APPLICATION_JSON);
            }

            @Override
            public void extendMessageConverters(List<HttpMessageConverter<?>> converters) {

                for (HttpMessageConverter<?> converter : converters) {
                    if (converter instanceof MappingJackson2HttpMessageConverter) {

                        MappingJackson2HttpMessageConverter jsonMessageConverter = (MappingJackson2HttpMessageConverter) converter;
                        ObjectMapper objectMapper = jsonMessageConverter.getObjectMapper();
                        JavaTimeModule javaTimeModule = new JavaTimeModule();
                        javaTimeModule.addSerializer(LocalDate.class,
                                new LocalDateSerializer(ofPattern(WebMvcConfiguration.DATE_FORMAT)));
                        javaTimeModule.addDeserializer(LocalDate.class,
                                new LocalDateDeserializer(ofPattern(WebMvcConfiguration.DATE_FORMAT)));
                        objectMapper.registerModule(javaTimeModule);
                    }
                }
            }

            @Override
            public void addFormatters(FormatterRegistry registry) {
                registry.addConverter(new LocalDateConverter(DATE_FORMAT));
            }

        };

    }

}
