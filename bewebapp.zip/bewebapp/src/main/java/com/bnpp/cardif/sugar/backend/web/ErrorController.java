package com.bnpp.cardif.sugar.backend.web;

import com.bnpp.cardif.sugar.rest.web.model.Error;
import com.bnpp.cardif.sugar.rest.web.model.ErrorCause;
import com.bnpp.cardif.sugar.rest.web.model.ErrorStack;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Optional;
import java.util.stream.Collectors;

@ControllerAdvice
public class ErrorController extends ResponseEntityExceptionHandler
{

    @Override protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers,
            HttpStatus status, WebRequest request) {

        ErrorStack stack = new ErrorStack()
                .message(Optional.ofNullable(ex.getCause()).isPresent()? ex.getCause().toString() : "" )
                .detail(Arrays.stream(ex.getStackTrace()).map(StackTraceElement::toString).collect(Collectors.toList()));

        ErrorCause errorCause = new ErrorCause()
                .code(Integer.toString(status.value()))
                .errorDate(LocalDate.now())
                .errorType(status.getReasonPhrase())
                .message(ex.getMessage())
                .stack(stack);

        Error restResponse = new Error()
                .status(false)
                .errorCause(errorCause);

        return ResponseEntity.status(status).body(restResponse);
    }
}
