package com.bnpp.cardif.sugar.backend.config;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.web.filter.CharacterEncodingFilter;

import com.bnpp.cardif.sugar.dao.oracle.util.SugarNameSpacePrefixMapper;

/**
 * This class configure the Root Spring context for the application.
 * 
 * This context should include all the application beans except the Spring MVC
 * controllers that will be loaded into the WebMvcConfiguration
 * 
 * The @ComponentScan is loading all configuration within the same package (and
 * child packages) as RootConfiguration. Since SecurityConfig is in this
 * package, it will be loaded with our existing setup.
 * 
 * @author 831743
 *
 */
@Configuration
// In this component scan annotation, set all the packages that contains your
// security, utility, DAO and services classes.
@ComponentScan(basePackages = { "com.bnpp.cardif.sesame.security", "com.bnpp.cardif.sugar",
        "com.bnpp.cardif.sugar.security", "com.bnpp.cardif.sugar.dao.oracle", "com.bnpp.cardif.sugar.core.tsp",
        "com.bnpp.cardif.sugar.ws.webapp" })
// Load an XML config file for the code that doesn't use annotations.
@ImportResource({ "classpath:sugar-ws-webapp.xml", "classpath:acl-context.xml" })
public class RootConfiguration {

    private static final Logger LOGGER = LoggerFactory.getLogger(RootConfiguration.class);

    // To resolve ${} in @Value
    @Bean
    public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public SugarNameSpacePrefixMapper nameSpacePrefixMapper() {
        SugarNameSpacePrefixMapper mapper = new SugarNameSpacePrefixMapper();
        Map<String, String> prefixes = new HashMap<>();
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/businessscope/v1", "businessscope");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/acl/v1", "acl");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolder/v1", "folder");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/casefolderclass/v1", "folderclass");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/basket/v1", "basket");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/task/v1", "task");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/document/v1", "doc");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/documentclass/v1", "docclass");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/documentfile/v1", "file");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/common/v1", "common");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/i18n/v1", "i18n");
        prefixes.put("http://www.arondor.com/schema/flower/calyx", "calyx");
        prefixes.put("http://ea.assurance.bnpparibas.com/internal/schema/mco/xmldao/v1", "colldb");
        mapper.setPrefixes(prefixes);
        return mapper;
    }

    /**
     * Add encoding filter
     * 
     * @return
     */
    @Bean
    public FilterRegistrationBean filterRegistrationBean() {
        FilterRegistrationBean registrationBean = new FilterRegistrationBean();
        CharacterEncodingFilter characterEncodingFilter = new CharacterEncodingFilter();
        characterEncodingFilter.setForceEncoding(true);
        characterEncodingFilter.setEncoding("UTF-8");
        registrationBean.setFilter(characterEncodingFilter);
        return registrationBean;
    }

}
