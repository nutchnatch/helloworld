package com.bnpp.cardif.sugar.security;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.acls.domain.AuditLogger;
import org.springframework.security.acls.model.Acl;
import org.springframework.security.acls.model.AclService;
import org.springframework.security.acls.model.NotFoundException;
import org.springframework.security.acls.model.ObjectIdentity;
import org.springframework.security.acls.model.Sid;

/**
 * Created with IntelliJ IDEA. User: Simon MANQUEST Date: 04/03/14 Time: 16:28
 * To change this template use File | Settings | File Templates.
 */
@Deprecated
public class SugarAclService implements AclService {
    private static final Logger LOGGER = LoggerFactory.getLogger(SugarAclService.class);

    @Autowired
    private ScopeRetrievalStrategy scopeRetrieval;

    @Autowired
    private AuditLogger auditLogger;

    // @Autowired
    // private AclDAO aclDAO;

    public SugarAclService() {
        LOGGER.warn("Instanciate deprecated class " + this.getClass());
    }

    @Override
    public List<ObjectIdentity> findChildren(ObjectIdentity objectIdentity) {
        return null; // To change body of implemented methods use File |
                     // Settings | File Templates.
    }

    @Override
    public Acl readAclById(ObjectIdentity objectIdentity) throws NotFoundException {
        return null; // To change body of implemented methods use File |
                     // Settings | File Templates.
    }

    @Override
    public Map<ObjectIdentity, Acl> readAclsById(List<ObjectIdentity> objectIdentities) throws NotFoundException {
        return null; // To change body of implemented methods use File |
                     // Settings | File Templates.
    }

    @Override
    public Map<ObjectIdentity, Acl> readAclsById(List<ObjectIdentity> objectIdentities, List<Sid> sids)
            throws NotFoundException {
        return null; // To change body of implemented methods use File |
                     // Settings | File Templates.
    }

    @Override
    public Acl readAclById(ObjectIdentity object, List<Sid> sids) throws NotFoundException {
        // TODO Auto-generated method stub
        return null;
    }
}
