package com.bnpp.cardif.sugar.core.tsp.documentfile;

import static com.bnpp.cardif.sugar.domain.fact.Action.CREATE;
import static com.bnpp.cardif.sugar.domain.fact.Action.READ;
import static com.bnpp.cardif.sugar.domain.fact.ObjectType.FILE;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpp.cardif.sugar.core.api.documentfile.DocumentFileService;
import com.bnpp.cardif.sugar.core.api.documentfile.DocumentFileValidator;
import com.bnpp.cardif.sugar.core.tsp.event.Event;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.dao.api.documentfile.DocumentFileDAO;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.URI;

/**
 * Default implementation of {@link DocumentFileService}
 * 
 * @author Christopher Laszczuk
 * 
 */
@Component
public class DocumentFileServiceTSP implements DocumentFileService {
    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentFileServiceTSP.class);

    @Autowired
    private DocumentFileDAO documentFileDAO;

    @Autowired
    private SugarEventBus eventBus;

    @Autowired
    private DocumentFileValidator validator;

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public List<DocumentFile> add(List<DocumentFile> documentFiles)
            throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.debug("Adding a list of {} document files", documentFiles.size());
        validator.checkAddValidity(documentFiles);
        for (DocumentFile file : documentFiles) {
            file.setURI(UUID.randomUUID().toString());
            file.setCreateDate(new Date());
        }
        documentFileDAO.store(documentFiles);
        fireEvents(documentFiles, CREATE);
        for (DocumentFile file : documentFiles) {
            file.setContent(null);
        }
        LOGGER.info("{} document files have been stored", documentFiles.size());
        return documentFiles;
    }

    @Override
    @Transactional(readOnly = true)
    public List<DocumentFile> get(String scope, List<URI> uri)
            throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.debug("Fetching list of {} document files", uri.size());
        validator.checkGetValidity(scope, uri);
        List<DocumentFile> files = documentFileDAO.get(scope, uri);
        fireEvents(files, READ);
        LOGGER.info("{} document files have been fetched", uri.size());
        return files;
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public List<URI> delete(String scope, List<URI> uris) throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.info("Deleting list of {} document files", uris.size());
        validator.checkDeleteValidity(scope, uris);
        List<URI> deletedURIs = new ArrayList<URI>();
        for (URI uri : uris) {
            documentFileDAO.delete(scope, uri.getValue());
            eventBus.post(new Event(scope, FILE, Action.DELETE, uri, uri));
            deletedURIs.add(uri);
        }
        LOGGER.info("{} document files have been deleted", uris.size());
        return deletedURIs;
    }

    private void fireEvents(List<DocumentFile> files, Action action) {
        for (DocumentFile file : files) {
            eventBus.post(new Event(file.getScope(), FILE, action, file, file.getURI()));
        }
    }
}