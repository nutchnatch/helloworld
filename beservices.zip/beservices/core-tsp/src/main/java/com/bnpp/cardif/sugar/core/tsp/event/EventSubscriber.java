package com.bnpp.cardif.sugar.core.tsp.event;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpp.cardif.sugar.domain.fact.ObjectType;
import com.google.common.eventbus.AllowConcurrentEvents;
import com.google.common.eventbus.Subscribe;

/**
 * Abstract class which allows to define an event subscriber. Extending this
 * class allows to subscribe to {@link Event<?>Bus} via {@link Event
 * <?>Bus#register(EventSubscriber)}.
 * 
 * <br/>
 * <br/>
 * <i>In add, this subscriber adds ability to subscribe only to desired
 * events.</i>
 * 
 * 
 * @author Christopher Laszczuk
 * 
 */
public abstract class EventSubscriber {
    private static final Logger LOGGER = LoggerFactory.getLogger(EventSubscriber.class);

    private EnumMap<ObjectType, List<Action>> registeredEvents = new EnumMap<ObjectType, List<Action>>(
            ObjectType.class);

    public EventSubscriber() {
    }

    @Subscribe
    @AllowConcurrentEvents
    public void handleEvent(Event event) throws SugarTechnicalException, SugarFunctionalException {
        if (isRegistered(event)) {
            try {
                onEvent(event);
            }
            catch (SugarTechnicalException | SugarFunctionalException e) {
                LOGGER.warn("The event {} cannot be handled by {} due to functional exception", event, this, e);
                throw (e);
            }
            catch (Exception e) {
                throw new SugarTechnicalException("Sugar subscriber has thrown an exception ", e);
            }
        }
    }

    public Map<ObjectType, List<Action>> getRegisteredEvents() {
        return registeredEvents;
    }

    public void setRegisteredEvents(Map<ObjectType, List<Action>> registeredEvents) {
        this.registeredEvents = new EnumMap<>(registeredEvents);
    }

    private boolean isRegistered(Event event) {
        List<Action> actions = registeredEvents.get(event.getObjectType());
        return actions != null ? actions.contains(event.getAction()) : false;
    }

    protected abstract void onEvent(Event event) throws SugarFunctionalException, SugarTechnicalException;
}
