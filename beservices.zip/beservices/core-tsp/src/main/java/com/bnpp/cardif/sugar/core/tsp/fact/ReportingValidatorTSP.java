package com.bnpp.cardif.sugar.core.tsp.fact;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.fact.ReportingValidator;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;

@Component
public class ReportingValidatorTSP implements ReportingValidator {

    @Autowired
    private BusinessScopeValidator scopeValidator;

    @Override
    public void validateScope(String scope) throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);
    }

    @Override
    public void validateScopeAndDates(String scope, Date startDate, Date endingDate)
            throws SugarTechnicalException, SugarFunctionalException {
        validateScope(scope);
        if (startDate == null) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00803);
        }
        if (endingDate == null) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00804);
        }
        if (startDate.after(endingDate)) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00801, startDate, endingDate);
        }
        Date today = new Date();
        if (endingDate.after(today)) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00802, endingDate, today);
        }
    }
}
