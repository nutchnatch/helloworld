package com.bnpp.cardif.sugar.core.tsp.task;

import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00206;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00504;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00505;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.G666;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00704;
import static com.bnpp.cardif.sugar.domain.fact.Action.CREATE;
import static com.bnpp.cardif.sugar.domain.fact.ObjectType.TASK;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.DecisionTableConfiguration;
import org.drools.builder.DecisionTableInputType;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.definition.KnowledgePackage;
import org.drools.definition.rule.Rule;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.bnpp.cardif.sugar.core.api.basket.BasketService;
import com.bnpp.cardif.sugar.core.api.document.DocumentService;
import com.bnpp.cardif.sugar.core.api.document.IdFactory;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassService;
import com.bnpp.cardif.sugar.core.api.task.TaskGeneratorService;
import com.bnpp.cardif.sugar.core.tsp.event.Event;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.TaskStatus;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.MCOTask.DocID;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;

public class TaskGeneratorServiceDrools implements TaskGeneratorService<Document, String, DocumentFile> {

    private static final Logger LOGGER = LoggerFactory.getLogger(TaskGeneratorServiceDrools.class);

    @Autowired
    private BasketService basketService;

    @Autowired
    private DocumentService documentService;

    @Autowired
    private TaskServiceTSP taskService;

    @Autowired
    private DocumentClassService documentClassService;

    @Autowired
    private SugarEventBus eventBus;

    @Autowired
    private IdFactory idFactory;

    @Value(value = "${drools.dtable.encoding}")
    private String encoding;

    private static final int MAX_RULES_TO_FIRE = 1;

    private String xlsPath;

    private String worksheet;

    private Map<String, KnowledgeBase> knowledgeBaseMap = new HashMap<>();

    protected synchronized KnowledgeBase getKnowledgeBase(String rulesId,
            com.bnpp.cardif.sugar.core.api.task.TaskGeneratorService.TaskGeneratorResolver<String, DocumentFile> resolver)
            throws SugarFunctionalException, SugarTechnicalException {
        KnowledgeBase knowledgeBase = knowledgeBaseMap.get(rulesId);

        if (knowledgeBase != null) {
            return knowledgeBase;
        }

        DocumentFile documentFile = rulesId != null ? resolver.resolve(rulesId) : null;

        if (documentFile != null) {
            knowledgeBase = loadKnowledgeBase(documentFile, getWorksheet(), getEncoding());
        }
        else {
            LOGGER.info("No business rules are stored for the business scope");
            try {
                knowledgeBase = loadKnowledgeBase(getXlsPath(), getWorksheet(), getEncoding());
            }
            catch (IOException e) {
                throw new SugarTechnicalException(
                        "Could not parse Drools table at xlsPath=" + getXlsPath() + ", worksheet=" + getWorksheet(), e);
            }
        }
        knowledgeBaseMap.put(rulesId, knowledgeBase);
        return knowledgeBase;
    }

    protected Task generateBlankTask(Document document) {

        LOGGER.info("------------------------------------------------------------------------------------------------");
        if (document == null) {
            return null;
        }
        LOGGER.info("------------------------------------------------------------------------------------------------");

        Task task = new Task();
        task.setTaskId(idFactory.generateTaskId());
        task.setDocID(new DocID());
        task.getDocID().setId(document.getId());
        task.setScope(document.getScope());
        task.setCreatnDate(new Date());
        task.setStatus(TaskStatus.NEW.name());
        return task;
    }

    @Override
    public void generate(Document document, String rulesId,
            com.bnpp.cardif.sugar.core.api.task.TaskGeneratorService.TaskGeneratorResolver<String, DocumentFile> resolver,
            Action action) throws SugarTechnicalException, SugarFunctionalException {
        KnowledgeBase knowledgeBase = getKnowledgeBase(rulesId, resolver);
        Task task = generateBlankTask(document);

        StatefulKnowledgeSession ksession = knowledgeBase.newStatefulKnowledgeSession();

        try {
            ksession.setGlobal("task", task);
            ksession.setGlobal("service", this);
            ksession.insert(document);
            ksession.insert(action);
            int rulesFired = ksession.fireAllRules(MAX_RULES_TO_FIRE);
            LOGGER.debug("rules fired: " + rulesFired);

        }
        catch (RuntimeException e) {
            LOGGER.error("Document " + document + " : catched runtime exception " + e.getMessage()
                    + " while processing " + knowledgeBase, e);
            throw ExceptionBuilder.createFunctionalException(G666, e);
        }
        finally {
            ksession.dispose();
        }
    }

    private static KnowledgeBase loadKnowledgeBase(DocumentFile documentFile, String worksheet, String encoding)
            throws SugarFunctionalException, SugarTechnicalException {
        try {
            KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
            DecisionTableConfiguration dtconf = KnowledgeBuilderFactory.newDecisionTableConfiguration();
            dtconf.setInputType(DecisionTableInputType.XLS);
            dtconf.setWorksheetName(worksheet);

            System.setProperty("jxl.encoding", encoding);
            InputStream xlsAsBytes = documentFile.getContent().getInputStream();
            kbuilder.add(ResourceFactory.newInputStreamResource(xlsAsBytes), ResourceType.DTABLE, dtconf);
            if (kbuilder.hasErrors()) {
                LOGGER.error(kbuilder.getErrors().toString());
                throw ExceptionBuilder.createFunctionalException(F00505, documentFile.getURI(),
                        kbuilder.getErrors().toString());
            }

            LOGGER.info(
                    "Loaded KnowledgeBase from document file " + documentFile.getName() + ", worksheet=" + worksheet);

            KnowledgeBase knowledgeBase = KnowledgeBaseFactory.newKnowledgeBase();
            knowledgeBase.addKnowledgePackages(kbuilder.getKnowledgePackages());

            LOGGER.info("Rules report:");
            for (KnowledgePackage pkg : kbuilder.getKnowledgePackages()) {
                LOGGER.info("Package: " + pkg.getName() + " contains "
                        + (pkg.getRules() == null ? -1 : pkg.getRules().size()) + " rules");
                for (Rule rule : pkg.getRules()) {
                    LOGGER.debug(
                            "Id: " + rule.getId() + "Name: " + rule.getName() + "Namespace: " + rule.getNamespace());
                    LOGGER.debug("Metadata: " + rule.getMetaData());
                }

            }

            return knowledgeBase;
        }
        catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            throw ExceptionBuilder.createTechnicalException(T00704, documentFile.getURI());
        }
    }

    private static KnowledgeBase loadKnowledgeBase(String xlsPath, String worksheet, String encoding)
            throws IOException, SugarFunctionalException {
        KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
        DecisionTableConfiguration dtconf = KnowledgeBuilderFactory.newDecisionTableConfiguration();
        dtconf.setInputType(DecisionTableInputType.XLS);
        dtconf.setWorksheetName(worksheet);

        System.setProperty("jxl.encoding", encoding);

        try (InputStream inputStream = new File(xlsPath).exists() ? new FileInputStream(xlsPath)
                : Thread.currentThread().getContextClassLoader().getResourceAsStream(xlsPath)) {

            if (inputStream == null) {
                throw new IOException("Could not resolve resource : " + xlsPath);
            }
            byte[] xlsAsBytes = IOUtils.toByteArray(inputStream);

            kbuilder.add(ResourceFactory.newByteArrayResource(xlsAsBytes), ResourceType.DTABLE, dtconf);

        }
        catch (IOException e) {
            throw ExceptionBuilder.createFunctionalException(F00505, xlsPath, e);
        }
        if (kbuilder.hasErrors()) {
            LOGGER.error(kbuilder.getErrors().toString());
            throw ExceptionBuilder.createFunctionalException(F00505, xlsPath, kbuilder.getErrors().toString());
        }

        LOGGER.info("Loaded KnowledgeBase from xlsPath=" + xlsPath + ", worksheet=" + worksheet);

        KnowledgeBase knowledgeBase = KnowledgeBaseFactory.newKnowledgeBase();
        knowledgeBase.addKnowledgePackages(kbuilder.getKnowledgePackages());
        return knowledgeBase;
    }

    public void storeTask(Task task) throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.debug("Storing task {}...", task);
        List<Task> tasks = new ArrayList<>();
        tasks.add(task);
        taskService.create(tasks);
        eventBus.post(new Event(task.getScope(), TASK, CREATE, task, task.getTaskId()));
        LOGGER.info("A task has been stored with id={}", task.getTaskId());
    }

    public void setBasket(Task task, String basketName) throws SugarTechnicalException, SugarFunctionalException {
        String scope = task.getScope();
        List<Basket> baskets = basketService.getAllUnfiltered(scope);

        for (Basket basket : baskets) {
            if (basket != null && basketName.equals(basket.getSymbolicName())) {
                task.setBasketId(basket.getBasketId());
                LOGGER.debug("Set basket {} ({}) for task {}", basketName, basket.getBasketId(), task);
                return;
            }
        }
        LOGGER.error("Could not find basket named '" + basketName + "' for scope '" + scope);
        throw ExceptionBuilder.createFunctionalException(F00504, basketName, scope);
    }

    public String getDocumentClassName(Document doc) throws SugarTechnicalException, SugarFunctionalException {

        List<DocumentClass> documentClasses = documentClassService.search(doc.getScope(), doc.getCategory(), false);
        for (DocumentClass documentClass : documentClasses)

        {
            if (documentClass.getClassId().equals(doc.getData().getClassId())) {
                LOGGER.debug("Document Id : " + doc.getId() + " = > Class : " + documentClass);
                return documentClass.getLongLabel();
            }
        }
        throw ExceptionBuilder.createFunctionalException(F00206, doc.getData().getClassId());
    }

    public String getEncoding() {
        LOGGER.debug("Drools file encoding: " + encoding);
        return encoding;
    }

    public void setEncoding(String encoding) {
        this.encoding = encoding;
    }

    public String getXlsPath() {
        return xlsPath;
    }

    public void setXlsPath(String xlsPath) {
        this.xlsPath = xlsPath;
    }

    public String getWorksheet() {
        return worksheet;
    }

    public void setWorksheet(String worksheet) {
        this.worksheet = worksheet;
    }

}
