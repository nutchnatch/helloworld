package com.bnpp.cardif.sugar.core.tsp.folder;

import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00103;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00602;
import static com.bnpp.cardif.sugar.domain.fact.Action.CREATE;
import static com.bnpp.cardif.sugar.domain.fact.Action.READ;
import static com.bnpp.cardif.sugar.domain.fact.Action.UPDATE;
import static com.bnpp.cardif.sugar.domain.fact.Action.UPDATE_RETENTION_DATE;
import static com.bnpp.cardif.sugar.domain.fact.ObjectType.DOCUMENT;
import static com.bnpp.cardif.sugar.domain.fact.ObjectType.FOLDER;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpp.cardif.sugar.core.api.acl.AclService;
import com.bnpp.cardif.sugar.core.api.document.DocumentService;
import com.bnpp.cardif.sugar.core.api.document.IdFactory;
import com.bnpp.cardif.sugar.core.api.folder.FolderService;
import com.bnpp.cardif.sugar.core.api.folder.FolderValidator;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassService;
import com.bnpp.cardif.sugar.core.tsp.document.DocumentSecurityHelper;
import com.bnpp.cardif.sugar.core.tsp.document.RetentionDateHelper;
import com.bnpp.cardif.sugar.core.tsp.event.Event;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.dao.api.folder.FolderDAO;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpp.cardif.sugar.security.SecurityHelper;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderStatusCodeType;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Item;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Operators;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Types;
import com.google.common.collect.Lists;

@Component
public class FolderServiceTSP implements FolderService {
    private static final Logger LOGGER = LoggerFactory.getLogger(FolderServiceTSP.class);

    @Autowired
    private IdFactory folderIdFactory;

    @Autowired
    private FolderDAO folderDAO;

    @Autowired
    private FolderClassService folderClassService;

    @Autowired
    private DocumentService documentService;

    @Autowired
    private SugarEventBus eventBus;

    @Autowired
    private FolderValidator validator;

    @Autowired
    private DocumentSecurityHelper securityHelper;

    @Autowired
    private AclService aclService;

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public List<Folder> add(List<Folder> foldersToAdd) throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.debug("Storing a list of {} folders", foldersToAdd.size());
        validator.checkCreationValidity(foldersToAdd);
        for (Folder folderToAdd : foldersToAdd) {
            securityHelper.checkStoreValidity(folderToAdd);
            folderToAdd.setFolderId(folderIdFactory.generateFolderID());
            Date currentDate = new Date();
            folderToAdd.getData().setCreatnDate(currentDate);
            folderToAdd.getData().setUpdtDate(currentDate);
            String userName = SecurityHelper.getCurrentUserName();
            folderToAdd.getData().setLastModifier(userName);
            folderToAdd.getData().setCreator(userName);
        }
        assignACLToFolder(foldersToAdd);
        folderDAO.add(foldersToAdd);
        for (Folder folderToUpdate : foldersToAdd) {
            setDocRetentionEndDate(folderToUpdate);
        }
        fireFolderEvents(foldersToAdd, CREATE);
        LOGGER.debug("{} folders have been added", foldersToAdd.size());
        return foldersToAdd;
    }

    private void assignACLToFolder(List<Folder> folders) throws SugarTechnicalException, SugarFunctionalException {
        for (Folder folder : folders) {
            ClassId classId = folder.getData().getClassId();
            AccessControlList instanceAcl = aclService.getByClassId(folder.getScope(), classId, true);
            LOGGER.debug("The ACL {} has been found for document {}", instanceAcl, folder.getFolderId());

            aclService.assignToFolder(folder.getScope(), instanceAcl.getAclId(), folder.getFolderId());
        }
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public List<Folder> update(List<Folder> foldersToUpdate, String scope)
            throws SugarTechnicalException, SugarFunctionalException {
        validator.checkUpdateValidity(foldersToUpdate);
        LOGGER.debug("Updating a list of {} folders", foldersToUpdate.size());
        for (Folder folderToUpdate : foldersToUpdate) {
            securityHelper.checkUpdateValidity(folderToUpdate);
            Folder oldFolder = getOldFolder(folderToUpdate);
            Boolean isClosing = checkIfClosing(folderToUpdate, oldFolder);
            if (!isClosing) {
                checkClassChange(folderToUpdate, oldFolder);
            }
            folderToUpdate.getData().setCreatnDate(oldFolder.getData().getCreatnDate());
            folderToUpdate.getData().setUpdtDate(new Date());
            String userName = SecurityHelper.getCurrentUserName();
            folderToUpdate.getData().setLastModifier(userName);

            setCloseDate(folderToUpdate, isClosing);
            setFolderRetentionEndDate(folderToUpdate);

        }
        List<Folder> updatedFolders = folderDAO.update(foldersToUpdate, scope);
        fireFolderEvents(updatedFolders, UPDATE);
        LOGGER.info("{} folders have been updated", updatedFolders.size());
        /**
         * Doc retentionEndDate must be set after folders are updated (because
         * of closing)
         */
        for (Folder folderToUpdate : foldersToUpdate) {
            setDocRetentionEndDate(folderToUpdate);
        }
        return updatedFolders;
    }

    private void checkClassChange(Folder folderToUpdate, Folder oldFolder) throws SugarFunctionalException {
        if (!(folderToUpdate.getChildComponents().getId().isEmpty())
                || !(folderToUpdate.getChildComponents().getDocument().isEmpty())) {
            if (!(folderToUpdate.getData().getClassId()).getValue()
                    .equals(oldFolder.getData().getClassId().getValue())) {
                throw ExceptionBuilder.createFunctionalException(F00103, folderToUpdate.getData().getName());
            }
        }
    }

    private Folder getOldFolder(Folder folderToUpdate) throws SugarTechnicalException {
        try {
            return folderDAO.get(Lists.newArrayList(folderToUpdate.getFolderId()), folderToUpdate.getScope()).get(0);
        }
        catch (SugarTechnicalException e) {
            throw new SugarTechnicalException("Couldnot get old folder to update", e);
        }
    }

    private void setCloseDate(Folder folderToUpdate, Boolean isClosing) throws SugarTechnicalException {
        LOGGER.debug("Folder {} are closed", folderToUpdate);
        if (isClosing) {
            folderToUpdate.getData().setCloseDate(new Date());
        }
    }

    private Boolean checkIfClosing(Folder folderToUpdate, Folder oldFolder) throws SugarTechnicalException {

        return (FolderStatusCodeType.OPEN.equals(oldFolder.getData().getStatusCode())
                && FolderStatusCodeType.CLOSE.equals(folderToUpdate.getData().getStatusCode()));
    }

    @Override
    @Transactional(readOnly = true)
    public List<Folder> get(List<FolderId> foldersIds, String scope)
            throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.debug("Fetching a list of {} folders", foldersIds.size());
        validator.checkGetValidity(scope);
        checkGetAuthorisation(foldersIds, scope);
        List<Folder> fetchedFolders = folderDAO.get(foldersIds, scope);
        fireFolderEvents(fetchedFolders, READ);
        LOGGER.info("{} folders have been fetched", fetchedFolders.size());
        return fetchedFolders;
    }

    @Override
    @Transactional(readOnly = true)
    public SearchResults<Folder> find(Criteria criteria, OrderClause order, long start, long max)
            throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.debug("Find folders for {} and order clause {} ", criteria, order);
        int scopeindex = -1;
        String scope = null;
        for (int i = 0; i < criteria.getCriterionList().size(); i++) {
            Criterion criterion = criteria.getCriterionList().get(i);
            if ("Scope".equals(criterion.getName())) {
                scopeindex = i;
                if (criterion.getValues() != null && !criterion.getValues().isEmpty()) {
                    scope = criterion.getValues().get(0);
                }
            }
        }
        if (scope == null || scope.trim().isEmpty()) {
            criteria.getCriterionList().remove(scopeindex);
            throw ExceptionBuilder.createFunctionalException(F00602, scope);
        }
        else {
            validator.checkFindValidity(scope, criteria, order, max);
            criteria.getCriterionList().remove(scopeindex);
        }

        return folderDAO.find(scope, criteria, order, start, max);
    }

    @Override
    public List<Folder> getAllFoldersAttached(Document document)
            throws SugarTechnicalException, SugarFunctionalException {
        Criteria criteria = new Criteria();
        criteria.setItem(Item.FOLDER);
        Criterion criterion = new Criterion(Levels.CHILD, "Id", Operators.EQUALS_TO, Types.STRING, Lists
                .newArrayList(document.getId().getIssuer(), document.getId().getScheme(), document.getId().getValue()));

        Criterion scopeCriterion = new Criterion(Levels.ATTRIBUTE, "Scope", Operators.EQUALS_TO, Types.STRING,
                Lists.newArrayList(document.getScope()));

        criteria.getCriterionList().add(scopeCriterion);
        criteria.getCriterionList().add(criterion);

        SearchResults<Folder> searchResults = find(criteria, null, 0, Integer.MAX_VALUE);
        return searchResults.getObjects();
    }

    private void setDocRetentionEndDate(Folder folderToUpdate)
            throws SugarTechnicalException, SugarFunctionalException {
        /**
         * Updating document retention end date
         */
        if (!folderToUpdate.getChildComponents().getId().isEmpty()) {
            LOGGER.debug("Fetching document attached to folder ", folderToUpdate.getFolderId());

            List<Document> documentsToUpdate = documentService.get(folderToUpdate.getScope(),
                    folderToUpdate.getChildComponents().getId(), true, false);
            LOGGER.debug("{} documents have been fetched for {}", documentsToUpdate.size(),
                    folderToUpdate.getFolderId());

            if (!documentsToUpdate.isEmpty()) {

                // firing the events for recalculate the end date asynchronously
                LOGGER.debug("Firing retention date update events for {} documents ", documentsToUpdate.size());
                fireDocumentsUpdateEvents(documentsToUpdate);
            }
        }
    }

    private void setFolderRetentionEndDate(Folder folderToUpdate)
            throws SugarTechnicalException, SugarFunctionalException {
        FolderClass folderClass = folderClassService
                .get(Lists.newArrayList(folderToUpdate.getData().getClassId()), folderToUpdate.getScope()).get(0);
        Date folderRetentionEndDate = RetentionDateHelper.computeRetentionEndDate(folderToUpdate, folderClass);
        folderToUpdate.getData().setRetentionEndDate(folderRetentionEndDate);
    }

    @Override
    @Transactional(readOnly = true)
    public Folder getBySymbolicName(String scope, String symbolicName)
            throws SugarTechnicalException, SugarFunctionalException {
        validator.checkGetBySymbolicName(scope);
        return folderDAO.getBySymbolicName(scope, symbolicName);
    }

    private void fireDocumentsUpdateEvents(List<Document> documents) {
        LOGGER.debug("Firing update retention date event");
        eventBus.post(new Event(documents.get(0).getScope(), DOCUMENT, UPDATE_RETENTION_DATE, documents, null));
    }

    private void fireFolderEvents(List<Folder> folders, Action action) {
        for (Folder folder : folders) {
            eventBus.post(new Event(folder.getScope(), FOLDER, action, folder, folder.getFolderId()));
        }
    }

    private void checkGetAuthorisation(List<FolderId> foldersIds, String scope) throws SugarFunctionalException {
        for (FolderId folderId : foldersIds) {
            Folder folderToCheck = new Folder();
            folderToCheck.setFolderId(folderId);
            folderToCheck.setScope(scope);
            securityHelper.checkGetValidity(folderToCheck);
        }
    }
}
