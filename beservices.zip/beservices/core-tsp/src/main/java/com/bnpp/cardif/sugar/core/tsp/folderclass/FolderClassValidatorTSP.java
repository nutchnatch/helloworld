package com.bnpp.cardif.sugar.core.tsp.folderclass;

import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00204;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassService;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagClassValidator;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DurationType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.TimeUnitConstance;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOTagReference;

@Component
public class FolderClassValidatorTSP implements FolderClassValidator {
    
    @Autowired
    private FolderClassService folderClassService;

    @Autowired
    private TagClassValidator tagValidator;

    @Autowired
    private BusinessScopeValidator businessScopeValidator;

    private static final Logger LOGGER = LoggerFactory.getLogger(FolderClassServiceTSP.class);

    @Override
    public void checkCreationValidity(List<FolderClass> classes)
            throws SugarTechnicalException, SugarFunctionalException {
        if (classes.isEmpty()) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00208);
        }
        List<String> symbolicNames = checkAndComputeSymbolicNames(classes);
        String scope = classes.get(0).getScope();
        verifyScopeAndTagReferences(classes, scope);
        List<FolderClass> fetched = folderClassService.getAll(scope, false);
        List<String> fetchedNames = new ArrayList<String>();
        for (FolderClass clazz : fetched) {
            fetchedNames.add(clazz.getLongLabel());
        }
        for (String name : symbolicNames) {
            if (fetchedNames.contains(name)) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00205, name,
                        classes.get(0).getScope());

            }
        }
        checkRetentionDuration(classes);
    }

    @Override
    public void checkUpdateValidity(List<FolderClass> classes)
            throws SugarTechnicalException, SugarFunctionalException {
        checkAndComputeSymbolicNames(classes);
        String scope = classes.get(0).getScope();
        verifyScopeAndTagReferences(classes, scope);
        checkExistence(classes, scope);
        checkRetentionDuration(classes);

    }

    private void checkRetentionDuration(List<FolderClass> classes) throws SugarFunctionalException {
        for (FolderClass clazz : classes) {
            if (!clazz.isSetRetentionDuration()) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00201, clazz.getLongLabel());
            }
            DurationType retentionDuration = clazz.getRetentionDuration();
            try

            {
                if (!retentionDuration.isSetTimeUnit()) {
                    throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00202, clazz.getLongLabel());

                }
                if (!retentionDuration.isSetValue()) {
                    throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00214, clazz.getLongLabel());
                }

                TimeUnitConstance.fromValue(retentionDuration.getTimeUnit());
            }
            catch (IllegalArgumentException e) {
                LOGGER.warn(FunctionalErrorCode.F00203 + e.getMessage(), e);
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00203,
                        retentionDuration.getTimeUnit(), clazz.getLongLabel());
            }
        }

    }

    private void checkExistence(List<FolderClass> folderClasses, String scope)
            throws SugarTechnicalException, SugarFunctionalException {

        List<ClassId> idsToFetch = new ArrayList<ClassId>();

        for (FolderClass clazz : folderClasses) {
            idsToFetch.add(clazz.getClassId());
        }
        List<FolderClass> fetchedClasses = folderClassService.get(idsToFetch, scope);

        if (fetchedClasses.isEmpty()) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00206, idsToFetch);
        }

    }

    private List<String> checkAndComputeSymbolicNames(List<FolderClass> folderClasses) throws SugarFunctionalException {
        List<String> symbolicNames = new ArrayList<String>();
        for (FolderClass folderClass : folderClasses) {
            String symbolicName = folderClass.getLongLabel();
            if (symbolicName == null || symbolicName.trim().isEmpty()) {
                throw ExceptionBuilder.createFunctionalException(F00204);
            }
            symbolicNames.add(symbolicName);
        }
        return symbolicNames;
    }

    private void verifyScopeAndTagReferences(List<FolderClass> folderClasses, String scope)
            throws SugarTechnicalException, SugarFunctionalException {
        List<MCOTagReference> tagReferences = new ArrayList<MCOTagReference>();
        if (scope == null) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00211,
                    folderClasses.get(0).getLongLabel());
        }
        for (FolderClass clazz : folderClasses) {
            if (!scope.equals(clazz.getScope())) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00209, scope, clazz.getScope());
            }
            tagReferences.addAll(clazz.getTagReference());
        }
        businessScopeValidator.checkExistence(scope);
        if (!tagReferences.isEmpty()) {
            List<String> symbolicNames = new ArrayList<String>();
            for (MCOTagReference ref : tagReferences) {
                symbolicNames.add(ref.getSymbolicName());
            }

            tagValidator.checkExistence(scope, symbolicNames);
        }
    }

    @Override
    public void checkExistence(String scope, List<ClassId> classesToCheck)
            throws SugarTechnicalException, SugarFunctionalException {
        List<FolderClass> fetched = folderClassService.get(classesToCheck, scope);
        List<ClassId> fetchedId = new ArrayList<ClassId>();
        for (FolderClass clazz : fetched) {
            fetchedId.add(clazz.getClassId());

        }
        for (ClassId id : classesToCheck) {
            if (!fetchedId.contains(id)) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00206, id);
            }
        }

    }

    @Override
    public void checkGetValidity(String scope) throws SugarTechnicalException, SugarFunctionalException {
        businessScopeValidator.checkExistence(scope);
    }

    @Override
    public void checkGetAll(String scope) throws SugarTechnicalException, SugarFunctionalException {
        businessScopeValidator.checkExistence(scope);
    }

    @Override
    public void checkActivateValidity(String scope) throws SugarTechnicalException, SugarFunctionalException {
        businessScopeValidator.checkExistence(scope);
    }
}
