package com.bnpp.cardif.sugar.core.tsp.document;

import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00001;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00002;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00306;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00307;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00308;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00309;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00602;
import static com.bnpp.cardif.sugar.domain.fact.Action.CREATE;
import static com.bnpp.cardif.sugar.domain.fact.Action.READ;
import static com.bnpp.cardif.sugar.domain.fact.Action.SEARCH;
import static com.bnpp.cardif.sugar.domain.fact.Action.UPDATE;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpp.cardif.sugar.core.api.acl.AclService;
import com.bnpp.cardif.sugar.core.api.basket.BasketService;
import com.bnpp.cardif.sugar.core.api.document.DocumentService;
import com.bnpp.cardif.sugar.core.api.document.DocumentValidator;
import com.bnpp.cardif.sugar.core.api.document.IdFactory;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassService;
import com.bnpp.cardif.sugar.core.api.documentfile.DocumentFileService;
import com.bnpp.cardif.sugar.core.api.folder.FolderService;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassService;
import com.bnpp.cardif.sugar.core.api.task.TaskService;
import com.bnpp.cardif.sugar.core.tsp.event.Event;
import com.bnpp.cardif.sugar.core.tsp.event.EventSubscriber;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.core.tsp.util.ValidatorHelper;
import com.bnpp.cardif.sugar.dao.api.document.DocumentDAO;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpp.cardif.sugar.domain.fact.ObjectType;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpp.cardif.sugar.security.SecurityHelper;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DocumentStatusCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DocumentStatusType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderStatusCodeType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.TaskStatus;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.MCODocumentType.ParentId;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.URI;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;
import com.google.common.collect.Lists;

/**
 * Default implementation of {@link DocumentService}
 * 
 * @author Christopher Laszczuk
 * 
 */
public class DocumentServiceTSP extends EventSubscriber implements DocumentService {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(DocumentServiceTSP.class);

    @Autowired
    private DocumentDAO documentDAO;

    @Autowired
    private DocumentClassService documentClassService;

    @Autowired
    private AclService aclService;

    @Autowired
    private DocumentFileService documentFileService;

    @Autowired
    private IdFactory documentIdFactory;

    @Autowired
    private DocumentSecurityHelper securityHelper;

    @Autowired
    private SugarEventBus eventBus;

    @Autowired
    private FolderClassService folderClassService;

    @Autowired
    private FolderService folderService;

    @Autowired
    private TaskService taskService;

    @Autowired
    private DocumentValidator validator;

    @Autowired
    private BasketService basketService;

    public void init() {
        eventBus.register(this);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.core.api.document.DocumentService#store(java.util
     * .List)
     */
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public List<Document> store(List<Document> documentsToStore)
            throws SugarFunctionalException, SugarTechnicalException {
        LOGGER.debug("Storing a list of {} documents", documentsToStore.size());
        validator.checkStoreValidity(documentsToStore);

        List<Document> flatDocumentsToStore = preProcessDocumentsToStore(documentsToStore);
        LOGGER.info("Storing a list of {} flaten documents", flatDocumentsToStore.size());
        assignACLToDocument(flatDocumentsToStore, false);

        documentDAO.store(flatDocumentsToStore);
        return flatDocumentsToStore;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.bnpp.cardif.sugar.core.api.document.DocumentService#fireStoreDocEvent
     * (java.util.List)
     */
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public void fireStoreDocEvent(List<Document> flatDocumentsToStore) {
        List<Document> docToNotify = new ArrayList<Document>();
        for (Document document : flatDocumentsToStore) {
            if (!ValdtyCode.UNDER_CONSTRUCTION.equals(document.getData().getValidityCode())) {
                docToNotify.add(document);
            }

        }
        fireEvents(docToNotify, CREATE);
    }

    private List<Document> preProcessDocumentsToStore(List<Document> documentsToStore)
            throws SugarFunctionalException, SugarTechnicalException {
        List<Document> flatDocumentsToStore = getFlatDocuments(documentsToStore);
        checkStorageAuthorization(flatDocumentsToStore);

        String userName = SecurityHelper.getCurrentUserName();
        for (Document document : flatDocumentsToStore) {
            if (document.getId() == null) {
                document.setId(documentIdFactory.generateDocumentID());
            }
            Date currentDate = new Date();
            document.getData().setCreatnDate(currentDate);
            document.getData().setUpdtDate(currentDate);
            if (document.getStatus() == null) {
                document.setStatus(new DocumentStatusType());
            }
            document.getStatus().setCode(DocumentStatusCode.NEW.name());
            document.getData().setCreator(userName);
            document.getData().setLastModifier(userName);

            if (!ValdtyCode.UNDER_CONSTRUCTION.equals(document.getData().getValidityCode())) {
                setRetentionEndDate(document, false);
            }
            validator.computeValidityCode(document, flatDocumentsToStore);
            replaceDocumentFilesByItsURI(document);

        }
        return flatDocumentsToStore;
    }

    private void setRetentionEndDate(Document document, boolean isDocumentUpdate)
            throws SugarTechnicalException, SugarFunctionalException

    {

        DocumentClass documentClass = documentClassService
                .get(document.getScope(), Lists.newArrayList(document.getData().getClassId())).get(0);
        Date retentionEndDate = RetentionDateHelper.computeRetentionEndDate(document, documentClass);
        LOGGER.debug("Retention date found for document is " + retentionEndDate);
        if (isDocumentUpdate && retentionEndDate != null) {
            List<Folder> folders = folderService.getAllFoldersAttached(document);
            for (Folder folder : folders) {
                List<FolderClass> folderClasses = folderClassService
                        .get(Lists.newArrayList(folder.getData().getClassId()), folder.getScope());
                Date folderRetentionEndDate = RetentionDateHelper.computeRetentionEndDate(folder, folderClasses.get(0));

                if (folderRetentionEndDate == null) {
                    retentionEndDate = null;
                    break;
                }
                if (folderRetentionEndDate.after(retentionEndDate)) {
                    retentionEndDate.setTime(folderRetentionEndDate.getTime());
                }
            }
        }
        document.getData().setRetentionEndDate(retentionEndDate);
        LOGGER.debug("Retention date has been set to " + retentionEndDate);
    }

    private void assignACLToDocument(List<Document> flatDocumentsToStore, boolean isReasign)
            throws SugarTechnicalException, SugarFunctionalException {
        for (Document document : flatDocumentsToStore) {
            AclId instanceAcl;
            if (document.getData().getClassId() == null
                    && ValdtyCode.UNDER_CONSTRUCTION.equals(document.getData().getValidityCode())) {
                instanceAcl = aclService.getDefault(document.getScope()).getAclId();
            }
            else {
                ClassId classId = document.getData().getClassId();
                instanceAcl = aclService.getByClassId(document.getScope(), classId, true).getAclId();
            }
            LOGGER.info("The ACL {} has been found for document {}", instanceAcl, document.getId());
            aclService.assignToDocument(document.getScope(), instanceAcl, document.getId(), isReasign);
        }
    }

    /**
     * replaces a physical file by the DB URI reference to it
     * 
     * @param document
     *            the document to remove Document file
     */
    protected void replaceDocumentFilesByItsURI(Document document) {
        if ((document.getFileData() != null) && (!document.getFileData().getDocumentFile().isEmpty())) {
            for (DocumentFile file : document.getFileData().getDocumentFile()) {
                document.getFileData().getURI().add(file.getURI());
            }
            document.getFileData().getDocumentFile().clear();
        }

    }

    @Override
    @Transactional(readOnly = true)
    public List<Document> get(String scope, List<Id> ids, boolean isChildrenInclude, boolean isDocumentFileInclude)
            throws SugarFunctionalException, SugarTechnicalException {

        List<Id> cleanIds = ValidatorHelper.removeDuplicates(ids);
        String includeChildrenDesc = isChildrenInclude ? "including children" : "";
        LOGGER.debug("Getting a list of {} documents for scope={} {}", cleanIds.size(), scope, includeChildrenDesc);
        validator.checkGetValidity(scope);
        checkIsNotEmpty(cleanIds);

        List<Document> fetchedDocuments = documentDAO.fetch(scope, cleanIds);

        fireEvents(fetchedDocuments, READ);
        if (isChildrenInclude) {
            includeChildren(scope, fetchedDocuments);
        }
        checkGetValidity(fetchedDocuments);
        if (isDocumentFileInclude) {
            includeFile(scope, fetchedDocuments);
        }
        LOGGER.info("{} documents have been fetched", fetchedDocuments.size());
        return fetchedDocuments;
    }

    private void includeFile(String scope, List<Document> fetchedDocuments)
            throws SugarTechnicalException, SugarFunctionalException {
        for (Document document : fetchedDocuments) {
            if (document.isSetChildObject()) {
                for (Document child : document.getChildObject().getDocument()) {
                    if (child.isSetFileData()) {
                        List<URI> uris = new ArrayList<URI>();
                        for (String uri : child.getFileData().getURI()) {
                            uris.add(new URI(uri));
                        }
                        child.getFileData().getDocumentFile().addAll(documentFileService.get(scope, uris));
                        child.getFileData().getURI().clear();
                    }
                }
            }
            if (document.isSetFileData()) {
                List<URI> uris = new ArrayList<URI>();
                for (String uri : document.getFileData().getURI()) {
                    uris.add(new URI(uri));
                }
                document.getFileData().getDocumentFile().addAll(documentFileService.get(scope, uris));
                document.getFileData().getURI().clear();
            }
        }
    }

    private void includeChildren(String scope, List<Document> documents)
            throws SugarFunctionalException, SugarTechnicalException {

        /* Compute the list of child document to fetch */
        Map<Id, Document> childIdToDocument = new HashMap<Id, Document>();
        List<Id> childIdsToFetch = new ArrayList<Id>();
        for (Document doc : documents) {
            if ((doc.getChildObject() != null) && (!doc.getChildObject().getId().isEmpty())) {
                for (Id chilIdToFetch : doc.getChildObject().getId()) {
                    childIdsToFetch.add(chilIdToFetch);
                    childIdToDocument.put(chilIdToFetch, doc);
                }
            }

        }
        /* Fetch child documents */
        List<Document> childDocuments = new ArrayList<Document>();
        if (!childIdsToFetch.isEmpty()) {
            childDocuments = get(scope, childIdsToFetch, true, false);
        }

        /* Replace the child Id by the child Document */

        for (Document childDoc : childDocuments) {
            Document document = childIdToDocument.get(childDoc.getId());

            document.getChildObject().getDocument().add(childDoc);
            document.getChildObject().getId().remove(childDoc.getId());
        }
    }

    @Override
    @Transactional(readOnly = true)
    public SearchResults<Document> find(Criteria criteria, OrderClause order, long start, long max)
            throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.debug("Find documents for {} and order clause {} ", criteria, order);
        int scopeindex = -1;
        String scope = null;
        for (int i = 0; i < criteria.getCriterionList().size(); i++) {
            Criterion criterion = criteria.getCriterionList().get(i);
            if ("Scope".equals(criterion.getName())) {
                scopeindex = i;
                if (criterion.getValues() != null && !criterion.getValues().isEmpty()) {
                    scope = criterion.getValues().get(0);
                }
            }
        }
        if (scope == null || scope.trim().isEmpty()) {
            throw ExceptionBuilder.createFunctionalException(F00602, scope);
        }
        else {
            validator.checkFindValidity(scope, criteria, order, max);
            criteria.getCriterionList().remove(scopeindex);
        }
        SearchResults<Document> results = documentDAO.find(scope, criteria, order, start, max);
        fireEvents(results.getObjects(), SEARCH);
        return results;
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public List<Document> update(List<Document> documentsToUpdate)
            throws SugarFunctionalException, SugarTechnicalException {
        LOGGER.debug("Updating a list of {} documents", documentsToUpdate.size());
        List<Document> storedChild = new ArrayList<Document>();

        for (Document document : documentsToUpdate) {
            if (document.getId() == null) {
                LOGGER.error("Document {} has no ID. Use store instead of update", document);
                throw ExceptionBuilder.createTechnicalException(TechnicalErrorCode.T00102);
            }
            storedChild.add(checkAndStoreChildren(document));
        }
        Map<Id, Document> docIdToOldDoc = fetchOldDocuments(documentsToUpdate);
        validator.checkUpdateValidity(documentsToUpdate, docIdToOldDoc);

        // Warning getFlatDocument detach the child document from its parents
        // The given list is altered
        List<Document> flatDocumentsToUpdate = getFlatDocuments(storedChild);

        Map<Document, Action> actions = new HashMap<Document, Action>();

        // user login doesnt change inside the loop.
        String userName = SecurityHelper.getCurrentUserName();

        // lets do all the recursive checks and then do the changes to the files
        for (Document document : flatDocumentsToUpdate) {
            Document oldDoc = docIdToOldDoc.get(document.getId());
            if (document.getData().isSetClassId()) {
                setRetentionEndDate(document, true);
                document.getData().setUpdtDate(new Date());

                document.getData().setLastModifier(userName);
                checkDocumentDates(oldDoc, document);
                document.getData().setValidityCode(null);
                validator.computeValidityCode(document, oldDoc, flatDocumentsToUpdate);
                if (oldDoc != null && !oldDoc.getData().isSetClassId()) {
                    securityHelper.checkStoreValidity(document);
                    assignACLToDocument(Lists.newArrayList(document), true);
                }
            }
            else {
                validator.computeValidityCode(document, flatDocumentsToUpdate);
            }
            checkUpdateValidity(Lists.newArrayList(document));
        }

        // Map each document with an action update or create
        calculateAction(actions, flatDocumentsToUpdate, docIdToOldDoc);

        List<Document> updatedDocuments = documentDAO.update(flatDocumentsToUpdate);
        LOGGER.info("{} documents have been updated", updatedDocuments.size());
        fireEvents(actions);
        return updatedDocuments;
    }

    private Map<Id, Document> fetchOldDocuments(List<Document> flatDocumentsToUpdate)
            throws SugarFunctionalException, SugarTechnicalException {
        /* Fetch all old documents */
        List<Document> oldDocs = get(flatDocumentsToUpdate.get(0).getScope(),
                ValidatorHelper.getSubListOfDocumentId(flatDocumentsToUpdate), true, false);

        /* Index old document with their Id */
        Map<Id, Document> docIdToOldDoc = new HashMap<Id, Document>();
        saveDocInMap(oldDocs, docIdToOldDoc);
        return docIdToOldDoc;
    }

    private void saveDocInMap(List<Document> oldDocs, Map<Id, Document> docIdToOldDoc) {
        for (Document oldDoc : oldDocs) {
            if (oldDoc != null && oldDoc.getId() != null) {
                docIdToOldDoc.put(oldDoc.getId(), oldDoc);
                if (oldDoc.getChildObject() != null && oldDoc.getChildObject().getDocument() != null
                        && !oldDoc.getChildObject().getDocument().isEmpty()) {
                    List<Document> childDocs = oldDoc.getChildObject().getDocument();
                    saveDocInMap(childDocs, docIdToOldDoc);
                }
            }
        }
    }

    private void calculateAction(Map<Document, Action> actions, List<Document> flatDocumentsToUpdate,
            Map<Id, Document> docIdToOldDoc) {
        for (Document document : flatDocumentsToUpdate) {
            Document oldDoc = docIdToOldDoc.get(document.getId());

            if (oldDoc != null && !ValdtyCode.UNDER_CONSTRUCTION.equals(document.getData().getValidityCode())) {

                if (ValdtyCode.UNDER_CONSTRUCTION.equals(oldDoc.getData().getValidityCode())) {
                    actions.put(document, CREATE);
                }
                else {
                    actions.put(document, UPDATE);

                }
            }
        }
    }

    private void fireEvents(Map<Document, Action> actions) {
        List<Document> createDocs = new ArrayList<Document>();
        List<Document> updateDocs = new ArrayList<Document>();
        Iterator<Document> keySetIterator = actions.keySet().iterator();
        while (keySetIterator.hasNext()) {
            Document document = keySetIterator.next();
            if (CREATE.equals(actions.get(document))) {
                createDocs.add(document);
            }
            else if (UPDATE.equals(actions.get(document)))

            {
                updateDocs.add(document);
            }
        }
        if (!createDocs.isEmpty()) {
            fireEvents(createDocs, CREATE);
        }
        if (!updateDocs.isEmpty()) {
            fireEvents(updateDocs, UPDATE);
        }
    }

    /**
     * Checks and reset the creation date on the document is the same as it is
     * on the database Adicional check to see
     * 
     * @param oldDoc
     *            document before de update change
     * @param document
     *            document with the changes
     * @throws SugarFunctionalException
     *             if the document have an update date prior to the create date
     * 
     */
    protected void checkDocumentDates(Document oldDoc, Document document) throws SugarFunctionalException {
        if (oldDoc != null && !(oldDoc.getData().getCreatnDate().equals(document.getData().getCreatnDate()))) {
            document.getData().setCreatnDate(oldDoc.getData().getCreatnDate());
        }

        if (document.getData().getCreatnDate().after(document.getData().getUpdtDate())) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00013, document.getId());
        }
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public List<Document> delete(List<Id> documentsIdToDelete, String scope)
            throws SugarFunctionalException, SugarTechnicalException {

        validator.checkDeleteValidity(scope);
        List<Document> documentsToDelete = get(scope, documentsIdToDelete, false, false);
        checkIsNotEmpty(documentsToDelete);

        Set<Document> flatDocumentsToDelete = new HashSet<Document>();
        Map<Id, Document> flatDocumentsToUpdate = new HashMap<Id, Document>();
        for (Document document : documentsToDelete) {
            List<Document> parentsToDelete = new ArrayList<Document>();
            computeParentsToDelete(scope, document, parentsToDelete, flatDocumentsToUpdate);

            List<Document> docWithItsChildren = get(scope, Lists.newArrayList(document.getId()), true, false);
            List<Document> flattenDocWithItsChildren = getFlatDocuments(docWithItsChildren);
            flattenDocWithItsChildren.remove(0);

            flatDocumentsToDelete.addAll(parentsToDelete);
            flatDocumentsToDelete.addAll(flattenDocWithItsChildren);
        }

        checkDeleteAuhorisation(flatDocumentsToDelete);
        for (Document document : flatDocumentsToDelete) {
            LOGGER.debug("Checking if document is attached to a closed folder " + document.getId());
            if (Category.DOCUMENT.equals(document.getCategory())) {
                checkIsNotAttachedToClosedFolder(document);
                LOGGER.debug("Removing document from attached folder");
                removeFromAttachedFolder(document);
            }
            changeStatus(document, DocumentStatusCode.DELETED);
            closeTasks(scope, document);
        }

        List<Document> toUpdate = new ArrayList<Document>();
        toUpdate.addAll(flatDocumentsToUpdate.values());
        List<Document> toPhysicallyDelete = new ArrayList<Document>();

        for (Document doc : flatDocumentsToDelete) {
            if (ValdtyCode.UNDER_CONSTRUCTION.equals(doc.getData().getValidityCode())) {
                toPhysicallyDelete.add(doc);
            }
            else {
                toUpdate.add(doc);
            }
        }
        List<Document> deletedDocuments = new ArrayList<Document>();

        if (!toUpdate.isEmpty()) {
            LOGGER.info("Updating a list of {} documents", toUpdate.size());
            List<Document> updatedDocuments = documentDAO.update(toUpdate);
            for (Document updatedDocument : updatedDocuments) {
                if (updatedDocument.isSetStatus() && updatedDocument.getStatus().isSetCode()
                        && DocumentStatusCode.DELETED.toString().equals(updatedDocument.getStatus().getCode())) {
                    deletedDocuments.add(updatedDocument);
                }
            }
            LOGGER.info("{} documents have been logically deleted", deletedDocuments.size());
        }
        if (!toPhysicallyDelete.isEmpty()) {
            documentDAO.delete(scope, ValidatorHelper.getSubListOfDocumentId(toPhysicallyDelete));
            deletedDocuments.addAll(toPhysicallyDelete);
        }
        fireEvents(deletedDocuments, Action.DELETE);
        return deletedDocuments;
    }

    private void checkIsNotAttachedToClosedFolder(Document document)
            throws SugarTechnicalException, SugarFunctionalException {
        List<Folder> folders = folderService.getAllFoldersAttached(document);
        for (Folder folder : folders) {
            if (FolderStatusCodeType.CLOSE.equals(folder.getData().getStatusCode())) {
                throw ExceptionBuilder.createFunctionalException(F00002, document.getId(), folder.getFolderId());
            }
        }
    }

    private void removeFromAttachedFolder(Document document) throws SugarTechnicalException, SugarFunctionalException {
        List<Folder> folders = folderService.getAllFoldersAttached(document);
        List<Folder> foldersToUpdate = new ArrayList<Folder>();
        for (Folder folder : folders) {
            if ((FolderStatusCodeType.OPEN.equals(folder.getData().getStatusCode()))
                    && (folder.getChildComponents().getId().contains(document.getId()))) {
                folder.getChildComponents().getId().remove(document.getId());
                foldersToUpdate.add(folder);

            }
        }
        if (!foldersToUpdate.isEmpty()) {
            folderService.update(foldersToUpdate, document.getScope());
        }
    }

    protected void computeParentsToDelete(String scope, Document document, List<Document> toDelete,
            Map<Id, Document> toUpdate) throws SugarFunctionalException, SugarTechnicalException {
        toDelete.add(document);

        if (document.isSetParentId()) {
            Id parentId = document.getParentId().getId();
            Document parent = toUpdate.get(parentId);
            if (parent == null) {
                parent = get(scope, Lists.newArrayList(parentId), false, false).get(0);
            }

            boolean hasToDeleteParent = parent.isSetChildObject() && parent.getChildObject().getId().size() == 1;
            if (hasToDeleteParent) {
                toUpdate.remove(parent.getId());
                parent.getChildObject().getId().remove(document.getId());
                computeParentsToDelete(scope, parent, toDelete, toUpdate);
            }
            else {
                parent.getChildObject().getId().remove(document.getId());
                toUpdate.put(parentId, parent);
            }
        }
    }

    private void changeStatus(Document document, DocumentStatusCode statusCode) {
        if (!document.isSetStatus()) {
            document.setStatus(new DocumentStatusType());
        }
        document.getStatus().setPrevStatus(document.getStatus().getCode());
        document.getStatus().setCode(statusCode.name());
        document.getStatus().setEffctveDate(new Date());
        document.getData().setUpdtDate(new Date());
    }

    private void closeTasks(String scope, Document document) throws SugarTechnicalException, SugarFunctionalException {
        List<Task> tasks = taskService.getTasksForDocument(scope, document.getId());
        List<TaskId> taskIds = new ArrayList<TaskId>();
        for (Task task : tasks) {
            taskIds.add(task.getTaskId());
        }
        taskService.updateStatus(document.getScope(), taskIds, TaskStatus.CLOSE.name());
    }

    private Document checkAndStoreChildren(Document document) throws SugarFunctionalException, SugarTechnicalException {
        List<Document> storedChildren = new ArrayList<Document>();
        if (document.getChildObject() != null) {
            for (Document childDocument : document.getChildObject().getDocument()) {
                childDocument.setParentId(new ParentId(document.getId()));
            }
            LOGGER.debug("Verifying if child documents were already stored");
            storedChildren.addAll(checkIsStored(document.getChildObject().getDocument()));

            document.getChildObject().getDocument().clear();
            document.getChildObject().getDocument().addAll(storedChildren);
        }
        return document;

    }

    /**
     * check if document has ID, if not stores de document in the database and
     * returns it with the generated ID
     * 
     * @param documents
     *            who are to be checked
     * @return checked list with documents without id stored in the database
     * @throws SugarFunctionalException
     *             on database storage validation
     * @throws SugarTechnicalException
     *             on database storage
     */
    private List<Document> checkIsStored(List<Document> documents)
            throws SugarFunctionalException, SugarTechnicalException {
        List<Document> documentsToUpdate = new ArrayList<Document>();
        Iterator<Document> ite = documents.iterator();

        // check one by one if they have ID
        while (ite.hasNext()) {
            Document document = ite.next();
            if (document.getId() == null) {
                // add to list to store in DB
                documentsToUpdate.add(document);

                // remove from list to avoid duplicates
                ite.remove();
            }
        }
        /*
         * COSTLY OPERATION: store on DB the new ones and re-update the list
         */
        if (!documentsToUpdate.isEmpty()) {
            List<Document> updatedDocuments = this.store(documentsToUpdate);
            this.fireStoreDocEvent(updatedDocuments);
            documents.addAll(updatedDocuments);
        }
        return documents;
    }

    /**
     * Flattens out the hierarchical structure of files in favor or a list
     * recursively Also replaces the references to its Document files with is
     * URI If a document has been stored and and ID is not defined an ID is
     * generated
     * 
     * @see Id
     * @see #getFlatDocuments(Document)
     * @see #replaceDocumentFilesByItsURI(Document)
     * @see IdFactory#generateDocumentID()
     * @param documents
     *            List of documents with childs to be flatten
     * @return The flatten out hierarchy in list form
     */
    private List<Document> getFlatDocuments(List<Document> documents) {
        List<Document> flatDocuments = new ArrayList<Document>();
        for (Document doc : documents) {
            flatDocuments.addAll(getFlatDocuments(doc));
        }

        return flatDocuments;
    }

    /**
     * Flattens out the hierarchical structure of files in favor or a list
     * recursively Also replaces the references to its Document files with is
     * URI If a document has been stored and and ID is not defined an ID is
     * generated
     * 
     * @see Id
     * @see #getFlatDocuments(List<Document>)
     * @see #replaceDocumentFilesByItsURI(Document)
     * @see IdFactory#generateDocumentID()
     * @param document
     *            document with childs to be flatten
     * @return The flatten out hierarchy in list form
     */
    private List<Document> getFlatDocuments(Document document) {
        if (document.getId() == null) {
            LOGGER.debug("Setting id to document");
            setDocumentID(document);
        }
        LOGGER.debug("Getting flat document... for document id " + document.getId());
        ArrayList<Document> flatDocuments = Lists.newArrayList(document);
        flatDocuments.addAll(flatteningChildren(document));
        replaceDocumentFilesByItsURI(document);
        LOGGER.debug("Getting flat document...DONE");
        return flatDocuments;
    }

    private List<Document> flatteningChildren(Document document) {
        List<Document> flatDocuments = new ArrayList<Document>();
        if (document.getChildObject() != null) {
            for (Document childDocument : document.getChildObject().getDocument()) {
                LOGGER.debug("setting id for child document");
                setDocumentID(childDocument);

                childDocument.setScope(document.getScope());
                childDocument.setParentId(new ParentId(document.getId()));
                LOGGER.debug("Parent Id have been set with " + childDocument.getParentId().getId());

                document.getChildObject().getId().add(childDocument.getId());
                LOGGER.debug("Flatening document : " + childDocument.getData().getName());
                replaceDocumentFilesByItsURI(document);
                flatDocuments.add(childDocument);
                flatDocuments.addAll(flatteningChildren(childDocument));

            }
            document.getChildObject().unsetDocument();
        }

        return flatDocuments;
    }

    private void setDocumentID(Document document) {
        if (document.getId() == null) {
            document.setId(documentIdFactory.generateDocumentID());
            document.getData().setCreatnDate(new Date());
        }
    }

    private void checkIsNotEmpty(List<?> objects) throws SugarFunctionalException {
        if (objects == null || objects.isEmpty()) {
            throw ExceptionBuilder.createFunctionalException(F00001);
        }
    }

    private void checkStorageAuthorization(List<Document> documents) throws SugarFunctionalException {
        for (Document document : documents) {
            try {
                securityHelper.checkStoreValidity(document);
            }
            catch (AccessDeniedException e) {
                throw ExceptionBuilder.createFunctionalException(F00306, document.getData().getClassId(), e);
            }

        }
    }

    private void checkGetValidity(List<Document> documents) throws SugarFunctionalException {
        for (Document document : documents) {
            try {
                securityHelper.checkGetValidity(document);
            }
            catch (AccessDeniedException e) {
                LOGGER.debug("checkGetValidity AcessDenied", e);
                throw ExceptionBuilder.createFunctionalException(F00307, document.getId(),
                        document.getData().getClassId());
            }
        }
    }

    private void checkUpdateValidity(List<Document> documents) throws SugarFunctionalException {
        for (Document document : documents) {
            try {
                securityHelper.checkUpdateValidity(document);
            }
            catch (AccessDeniedException e) {
                LOGGER.debug("checkUpdateValidity AcessDenied", e);
                throw ExceptionBuilder.createFunctionalException(F00308, document.getId(),
                        document.getData().getClassId());
            }
        }
    }

    private void checkDeleteAuhorisation(Set<Document> documents) throws SugarFunctionalException {
        for (Document document : documents) {
            try {
                securityHelper.checkDeleteAuhorisation(document);
            }
            catch (AccessDeniedException e) {
                LOGGER.debug("checkDeleteAuhorisation AcessDenied", e);
                throw ExceptionBuilder.createFunctionalException(F00309, document.getId(),
                        document.getData().getClassId());
            }
        }
    }

    private void fireEvents(List<Document> documents, Action action) {
        for (Document document : documents) {
            LOGGER.debug("fire document actions " + action);
            boolean isDocument = Category.DOCUMENT.equals(document.getCategory());
            ObjectType type = isDocument ? ObjectType.DOCUMENT : ObjectType.ENVELOPE;
            Event event = new Event(document.getScope(), type, action, document, document.getId());
            eventBus.post(event);
        }
    }

    @Override
    protected void onEvent(Event event) throws SugarFunctionalException, SugarTechnicalException {

        if (Action.UPDATE_RETENTION_DATE.equals(event.getAction())
                && ObjectType.DOCUMENT.equals(event.getObjectType())) {
            List<Document> documentsToUpdate = (List<Document>) event.getObject();
            // firing just one event with all documents to prevent multiple
            // server calls
            LOGGER.debug("Updating retention date for {} documents ", documentsToUpdate.size());
            update(documentsToUpdate);
        }
        else {
            LOGGER.error("Unexpected event fired for {} action and {} object type ", event.getAction(),
                    event.getObjectType());
        }

    }
}
