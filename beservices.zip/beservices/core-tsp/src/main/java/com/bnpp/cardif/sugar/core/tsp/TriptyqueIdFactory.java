package com.bnpp.cardif.sugar.core.tsp;

import java.util.UUID;

import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.core.api.document.IdFactory;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScopeId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;

@Component("documentIdFactory")
public class TriptyqueIdFactory implements IdFactory {
    
    private String issuer = "CARDIF";

    private String scheme = "Sugar";

    @Override
    public Id generateDocumentID() {
        Id id = new Id();
        id.setIssuer(issuer);
        id.setScheme(scheme);
        id.setValue(UUID.randomUUID().toString());
        return id;
    }

    @Override
    public FolderId generateFolderID() {
        FolderId id = new FolderId();
        id.setIssuer(issuer);
        id.setScheme(scheme);
        id.setValue(UUID.randomUUID().toString());
        return id;
    }

    @Override
    public BasketId generateBasketID() {
        BasketId id = new BasketId();
        id.setIssuer(issuer);
        id.setScheme(scheme);
        id.setValue(UUID.randomUUID().toString());
        return id;
    }

    @Override
    public BusinessScopeId generateBusinessScopeId() {
        BusinessScopeId id = new BusinessScopeId();
        id.setIssuer(issuer);
        id.setScheme(scheme);
        id.setValue(UUID.randomUUID().toString());
        return id;
    }

    @Override
    public TaskId generateTaskId() {
        TaskId id = new TaskId();
        id.setIssuer(issuer);
        id.setScheme(scheme);
        id.setValue(UUID.randomUUID().toString());
        return id;
    }

    @Override
    public ClassId generateClassId() {
        ClassId classId = new ClassId();
        classId.setIssuer(issuer);
        classId.setValue(UUID.randomUUID().toString());
        classId.setVersId(0);
        return classId;
    }

    public String getIssuer() {
        return issuer;
    }

    public void setIssuer(String issuer) {
        this.issuer = issuer;
    }

    public String getScheme() {
        return scheme;
    }

    public void setScheme(String scheme) {
        this.scheme = scheme;
    }

}
