package com.bnpp.cardif.sugar.core.tsp.basket;

import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00302;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00303;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00304;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00305;
import static com.bnpp.cardif.sugar.domain.fact.Action.CREATE;
import static com.bnpp.cardif.sugar.domain.fact.Action.DELETE;
import static com.bnpp.cardif.sugar.domain.fact.Action.READ;
import static com.bnpp.cardif.sugar.domain.fact.ObjectType.BASKET;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpp.cardif.sugar.core.api.acl.AclService;
import com.bnpp.cardif.sugar.core.api.basket.BasketService;
import com.bnpp.cardif.sugar.core.api.basket.BasketValidator;
import com.bnpp.cardif.sugar.core.api.document.IdFactory;
import com.bnpp.cardif.sugar.core.tsp.document.DocumentSecurityHelper;
import com.bnpp.cardif.sugar.core.tsp.event.Event;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.dao.api.basket.BasketDAO;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.google.common.base.Function;
import com.google.common.collect.Lists;

@Component
public class BasketServiceTSP implements BasketService {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(BasketServiceTSP.class);

    @Autowired
    private BasketDAO basketDAO;

    @Autowired
    private IdFactory folderIdFactory;

    @Autowired
    private SugarEventBus eventBus;

    @Autowired
    private AclService aclService;

    @Autowired
    private DocumentSecurityHelper documentSecurityHelper;

    @Autowired
    private BasketValidator validator;

    @CacheEvict(value = "Basket", allEntries = true)
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public List<Basket> create(List<Basket> basketsToStore) throws SugarTechnicalException, SugarFunctionalException {
        try {
            validator.checkCreation(basketsToStore);
            checkAdminCreationAuthorisation(basketsToStore);
            LOGGER.debug("Creating {} baskets...", basketsToStore.size());
            for (Basket basketToStore : basketsToStore) {
                basketToStore.setBasketId(folderIdFactory.generateBasketID());
            }
            basketDAO.store(basketsToStore);
            LOGGER.info("{} baskets have been created", basketsToStore.size());
            assignACLToBaskets(basketsToStore);
            fireEvents(basketsToStore, CREATE);
            return basketsToStore;
        }
        catch (AccessDeniedException e) {
            throw ExceptionBuilder.createFunctionalException(F00302, e);
        }
    }

    private void assignACLToBaskets(List<Basket> baskets) throws SugarTechnicalException, SugarFunctionalException {
        for (Basket basket : baskets) {
            aclService.assignDefault(basket.getScope(), basket.getBasketId());
        }
    }

    @Cacheable(value = "Basket")
    @Override
    @Transactional(readOnly = true)
    public List<Basket> getAllUnfiltered(String scope) throws SugarTechnicalException, SugarFunctionalException {
        validator.checkGetAll(scope);
        LOGGER.debug("Getting all basket for scope {}", scope);
        List<Basket> baskets = basketDAO.getAll(scope);
        fireEvents(baskets, Action.READ);
        return baskets;
    }

    @Override
    public List<Basket> filterAllowedBasket(List<Basket> baskets) {
        List<Basket> allowedBaskets = new ArrayList<Basket>();
        for (Basket basket : baskets) {
            try {
                documentSecurityHelper.checkReadAccessibility(basket);
                allowedBaskets.add(basket);
            }
            catch (Exception e) {
                LOGGER.info("User does not have the right to access to this basket {}", basket.getBasketId());
                LOGGER.debug("User does not have the right to access to this basket {} - {}", basket.getBasketId(), e);
            }
        }
        return allowedBaskets;
    }

    @Cacheable("Basket")
    @Override
    @Transactional(readOnly = true)
    public List<Basket> get(List<BasketId> ids, String scope) throws SugarTechnicalException, SugarFunctionalException {
        validator.checkGet(scope);
        try {
            LOGGER.debug("Getting baskets: {} for scope={}...", ids, scope);
            List<Basket> baskets = basketDAO.get(ids, scope);
            LOGGER.info("{} baskets have been fetched for scope {}", baskets.size(), scope);
            fireEvents(baskets, READ);
            return baskets;
        }
        catch (AccessDeniedException e) {
            throw ExceptionBuilder.createFunctionalException(F00303, ids, e);
        }
    }

    @CacheEvict(value = "Basket", allEntries = true)
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public List<Basket> update(List<Basket> basketsToUpdate) throws SugarTechnicalException, SugarFunctionalException {
        try {
            checkAdminAccessibility(basketsToUpdate);
            validator.checkUpdate(basketsToUpdate);
            LOGGER.debug("Updating a list of {} basket...", basketsToUpdate.size());
            basketDAO.update(basketsToUpdate);
            LOGGER.info("{} baskets have been udpated", basketsToUpdate.size());
            fireEvents(basketsToUpdate, Action.UPDATE);
            return basketsToUpdate;
        }
        catch (AccessDeniedException e) {
            throw ExceptionBuilder.createFunctionalException(F00304, getIds(basketsToUpdate), e);
        }
    }

    @CacheEvict(value = "Basket", allEntries = true)
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public void delete(List<BasketId> ids, String scope) throws SugarTechnicalException, SugarFunctionalException {
        validator.checkDelete(ids, scope);
        try {
            checkAdminAccessibility(scope, ids);
            LOGGER.debug("Deleting a list of {} baskets", ids.size());
            for (BasketId basketId : ids) {
                removeAssignedAcl(scope, basketId);
            }
            List<Basket> basketsToDelete = basketDAO.get(ids, scope);

            basketDAO.delete(ids, scope);
            fireEvents(basketsToDelete, DELETE);
            LOGGER.info("{} baskets have been deleted", ids.size());
        }
        catch (AccessDeniedException e) {
            throw ExceptionBuilder.createFunctionalException(F00305, ids, e);
        }
    }

    private void removeAssignedAcl(String scope, BasketId basketId) {
        try {
            aclService.remove(scope, basketId);
        }
        catch (SugarTechnicalException e) {
            LOGGER.error("Cannot remove mapped Acl", e);
        }
    }

    private void fireEvents(List<Basket> baskets, Action action) {
        for (Basket basket : baskets) {
            eventBus.post(new Event(basket.getScope(), BASKET, action, basket, basket.getBasketId()));
        }
    }

    public void checkAdminCreationAuthorisation(List<Basket> baskets) throws SugarFunctionalException {
        LOGGER.debug("Checking admin creation authorisation");
        for (Basket basket : baskets) {
            documentSecurityHelper.checkAdminCreationAuthorisation(basket);
        }
    }

    public void checkAdminAccessibility(String scope, List<BasketId> basketIds) {
        LOGGER.debug("Checking accessibility to access to " + basketIds + " in scope " + scope);
        List<Basket> baskets = new ArrayList<Basket>();
        for (BasketId id : basketIds) {
            Basket basket = new Basket();
            basket.setBasketId(id);
            basket.setScope(scope);
            baskets.add(basket);
        }
        checkAdminAccessibility(baskets);
    }

    @Override
    public void checkReadAccessibility(List<BasketId> ids, String scope) {
        for (BasketId basketId : ids) {
            Basket basket = new Basket();
            basket.setBasketId(basketId);
            basket.setScope(scope);
            documentSecurityHelper.checkReadAccessibility(basket);
        }
    }

    private void checkAdminAccessibility(List<Basket> baskets) {
        for (Basket basket : baskets) {
            documentSecurityHelper.checkAdminAccessibility(basket);
        }
    }

    private List<BasketId> getIds(List<Basket> baskets) {
        return Lists.transform(baskets, new Function<Basket, BasketId>() {
            @Override
            public BasketId apply(Basket basket) {
                return basket.getBasketId();
            }
        });
    }
}
