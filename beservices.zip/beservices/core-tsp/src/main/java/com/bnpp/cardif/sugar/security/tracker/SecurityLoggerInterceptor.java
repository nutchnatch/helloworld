package com.bnpp.cardif.sugar.security.tracker;

import java.util.Date;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.util.StopWatch;

import com.bnpp.cardif.sugar.domain.tracker.LoggerInterceptor;
import com.bnpp.cardif.sugar.security.AuthenticatedUser;

public class SecurityLoggerInterceptor extends LoggerInterceptor {
    public Object logLoginAction(ProceedingJoinPoint pjp) throws Throwable {
        Signature signature = pjp.getSignature();

        StopWatch stopWatch = null;
        Date startDate = new Date();
        if (isPerfLoggingEnabled()) {
            stopWatch = new StopWatch(signature.toShortString());
            stopWatch.start();
        }
        Object returnedValue = null;
        boolean success = true;
        String errorCode = "";
        try {
            interceptorLogger.trace(METHOD_ENTRY_PHRASE, signature.toShortString());
            returnedValue = pjp.proceed();
        }

        catch (Exception e) {
            success = false;
            throw e;
        }
        finally {
            interceptorLogger.trace(METHOD_OUTPUT_PHRASE, signature.toShortString());
            if (isPerfLoggingEnabled()) {
                stopWatch.stop();
                if (returnedValue instanceof UsernamePasswordAuthenticationToken) {
                    AuthenticatedUser authenticatedUser = (AuthenticatedUser) ((UsernamePasswordAuthenticationToken) returnedValue)
                            .getPrincipal();
                    logAction(pjp, stopWatch, startDate, authenticatedUser, success, errorCode);
                }
            }
        }
        return returnedValue;
    }

    public Object logLogoutAction(ProceedingJoinPoint pjp) throws Throwable {
        Signature signature = pjp.getSignature();

        Object[] args = pjp.getArgs();
        Object arg0 = args[2];

        StopWatch stopWatch = null;
        Date startDate = new Date();
        if (isPerfLoggingEnabled()) {
            stopWatch = new StopWatch(signature.toShortString());
            stopWatch.start();
        }

        Object returnedValue = null;
        boolean success = true;
        String errorCode = "";
        try {
            interceptorLogger.trace(METHOD_ENTRY_PHRASE, signature.toShortString());
            returnedValue = pjp.proceed();
        }

        catch (Exception e) {
            success = false;
            throw e;
        }
        finally {
            interceptorLogger.trace(METHOD_OUTPUT_PHRASE, signature.toShortString());

            if (isPerfLoggingEnabled()) {
                stopWatch.stop();

                if (arg0 instanceof UsernamePasswordAuthenticationToken) {
                    AuthenticatedUser authenticatedUser = (AuthenticatedUser) ((UsernamePasswordAuthenticationToken) arg0)
                            .getPrincipal();
                    logAction(pjp, stopWatch, startDate, authenticatedUser, success, errorCode);
                }
            }

        }
        return returnedValue;
    }

}
