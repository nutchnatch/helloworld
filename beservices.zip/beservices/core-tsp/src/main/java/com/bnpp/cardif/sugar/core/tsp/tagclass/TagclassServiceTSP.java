package com.bnpp.cardif.sugar.core.tsp.tagclass;

import static com.bnpp.cardif.sugar.domain.fact.Action.CREATE;
import static com.bnpp.cardif.sugar.domain.fact.Action.READ;
import static com.bnpp.cardif.sugar.domain.fact.Action.UPDATE;
import static com.bnpp.cardif.sugar.domain.fact.ObjectType.TAG_CLASS;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpp.cardif.sugar.core.api.document.IdFactory;
import com.bnpp.cardif.sugar.core.api.tagclass.TagClassValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagclassService;
import com.bnpp.cardif.sugar.core.tsp.document.DocumentSecurityHelper;
import com.bnpp.cardif.sugar.core.tsp.event.Event;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.dao.api.tagclass.TagClassDAO;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;

/**
 * 
 * @author Florian Deruette
 * 
 */
@Component
public class TagclassServiceTSP implements TagclassService {
    private static final Logger LOGGER = LoggerFactory.getLogger(TagclassServiceTSP.class);

    @Autowired
    private TagClassDAO tagclassDAO;

    @Autowired
    private IdFactory idFactory;

    @Autowired
    private TagClassValidator validator;

    @Autowired
    private SugarEventBus eventBus;

    @Autowired
    private DocumentSecurityHelper securityHelper;

    private void checkAdminAccessibility(List<TagClass> classes) {
        for (TagClass tagClass : classes) {
            securityHelper.checkAdminAccessibility(tagClass.getScope());
        }
    }

    @CacheEvict(value = "TagClass", allEntries = true)
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public void store(List<TagClass> classes) throws SugarTechnicalException, SugarFunctionalException {

        LOGGER.debug("Storing {} tag classes", classes.size());
        validator.checkCreationValidity(classes);
        checkAdminAccessibility(classes);
        for (TagClass tagclass : classes) {
            tagclass.setClassId(idFactory.generateClassId());
        }
        tagclassDAO.store(classes);

        LOGGER.info("{} tag classes have been stored", classes.size());
        fireEvents(classes, CREATE);
    }

    @Cacheable("TagClass")
    @Override
    @Transactional(readOnly = true)
    public List<TagClass> getAll(String scope) throws SugarTechnicalException, SugarFunctionalException {
        validator.checkGetAllValidity(scope);
        List<TagClass> classes = tagclassDAO.getAll(scope);
        fireEvents(classes, READ);
        return classes;
    }

    /**
     * @deprecated Use {@link #getBySymbolicName(String, List)} instead
     */
    @Deprecated
    @Override
    @Transactional(readOnly = true)
    public List<TagClass> get(String scope, List<ClassId> ids)
            throws SugarTechnicalException, SugarFunctionalException {
        List<TagClass> classes = tagclassDAO.get(scope, ids);
        fireEvents(classes, READ);
        return classes;
    }

    @Cacheable("TagClass")
    @Override
    @Transactional(readOnly = true)
    public List<TagClass> getBySymbolicName(String scope, List<String> symbolicNames, boolean throwErrorIfNotFound)
            throws SugarTechnicalException, SugarFunctionalException {

        validator.checkGetBySymbolicNameValidity(scope);

        LOGGER.debug("trying to fetch " + symbolicNames.size());
        List<TagClass> classesFound = tagclassDAO.getBySymbolicName(scope, symbolicNames);
        LOGGER.debug(classesFound.size() + " tagclasses have been fetched");
        fireEvents(classesFound, READ);
        if (throwErrorIfNotFound) {
            throwErrorIfNotFound(symbolicNames, classesFound);
        }
        return classesFound;
    }

    private void throwErrorIfNotFound(List<String> symbolicNames, List<TagClass> classesFound)
            throws SugarTechnicalException {
        if (classesFound == null || symbolicNames == null) {
            throw ExceptionBuilder.createTechnicalException(TechnicalErrorCode.T00802, symbolicNames);
        }

        if (classesFound.size() != symbolicNames.size()) {
            List<String> classFoundNames = new ArrayList<String>();
            for (TagClass tag : classesFound) {
                classFoundNames.add(tag.getSymbolicName());
            }
            symbolicNames.removeAll(classFoundNames);
            throw ExceptionBuilder.createTechnicalException(TechnicalErrorCode.T00802, symbolicNames);
        }
    }

    @CacheEvict(value = "TagClass", allEntries = true)
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public void update(List<TagClass> tagClasses) throws SugarTechnicalException, SugarFunctionalException {

        validator.checkUpdateValidity(tagClasses);
        checkAdminAccessibility(tagClasses);
        tagclassDAO.update(tagClasses);
        fireEvents(tagClasses, UPDATE);
    }

    private void fireEvents(List<TagClass> classes, Action action) {
        for (TagClass clazz : classes) {
            eventBus.post(new Event(clazz.getScope(), TAG_CLASS, action, clazz, clazz.getClassId()));
        }
    }

}
