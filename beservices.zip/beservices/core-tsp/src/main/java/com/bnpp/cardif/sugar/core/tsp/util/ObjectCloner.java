package com.bnpp.cardif.sugar.core.tsp.util;

import java.io.Serializable;

import org.springframework.util.SerializationUtils;

public class ObjectCloner {

    private ObjectCloner() {
    }

    @SuppressWarnings("unchecked")
    public static <T extends Serializable> T clone(T obj) {
        return (T) SerializationUtils.deserialize(SerializationUtils.serialize(obj));
    }

}
