/**
 * 
 */
package com.bnpp.cardif.sugar.core.tsp.documentannotation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpp.cardif.sugar.core.api.documentannotation.DocumentAnnotationService;
import com.bnpp.cardif.sugar.core.tsp.documentclass.AbstractClassServiceTSP;
import com.bnpp.cardif.sugar.dao.api.documentannotation.DocumentAnnotationDAO;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentannotation.v1.DocumentAnnotation;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentannotation.v1.Id;

/**
 * @author a69693
 *
 */
@Component
public class DocumentAnnotationServiceTSP extends AbstractClassServiceTSP implements DocumentAnnotationService {

    @Autowired
    private DocumentAnnotationDAO documentAnnotationDAO;

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public List<DocumentAnnotation> create(List<DocumentAnnotation> documentAnnotation)
            throws SugarTechnicalException, SugarFunctionalException {
        List<DocumentAnnotation> createdDocumentAnnotations = documentAnnotationDAO.create(documentAnnotation);
        return createdDocumentAnnotations;
    }

    @Override
    @Transactional(readOnly = true)
    public List<DocumentAnnotation> findByDocumentFileId(List<String> documentFileId)
            throws SugarTechnicalException, SugarFunctionalException {
        List<DocumentAnnotation> documentAnnotations = documentAnnotationDAO.findByDocumentFileId(documentFileId);
        return documentAnnotations;
    }

    @Override
    @Transactional(readOnly = true)
    public List<DocumentAnnotation> get(List<Id> ids) throws SugarTechnicalException, SugarFunctionalException {
        List<DocumentAnnotation> documentAnnotations = documentAnnotationDAO.get(ids);
        return documentAnnotations;
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public List<? extends Boolean> delete(List<DocumentAnnotation> ids)
            throws SugarTechnicalException, SugarFunctionalException {
        List<? extends Boolean> documentAnnotations = documentAnnotationDAO.delete(ids);
        return documentAnnotations;
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public List<DocumentAnnotation> update(List<DocumentAnnotation> documentAnnotation)
            throws SugarTechnicalException, SugarFunctionalException {
        List<DocumentAnnotation> updatedDocumentAnnotations = documentAnnotationDAO.update(documentAnnotation);
        return updatedDocumentAnnotations;
    }

}
