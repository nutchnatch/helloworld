package com.bnpp.cardif.sugar.core.tsp.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criterion;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Item;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Levels;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Operators;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Types;
import com.google.common.base.Function;
import com.google.common.collect.Lists;

public class ValidatorHelper {

    private ValidatorHelper() {
    }

    public static <T> List<T> removeDuplicates(List<T> listToClean) {
        List<T> cleanList = new ArrayList<T>();
        for (T object : listToClean) {
            if (!cleanList.contains(object)) {
                cleanList.add(object);
            }
        }
        return cleanList;
    }

    public static void checkCriteria(Criteria criteria) throws SugarFunctionalException {
        List<Operators> validOperators = getValidOperator();
        for (Criterion criterion : criteria.getCriterionList()) {
            if (criterion.getOperator() == null) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00023, validOperators);
            }
            if (criterion.getValues() == null || criterion.getValues().isEmpty()) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00027);
            }
            else {
                for (String value : criterion.getValues()) {
                    if (value.contains("*")) {
                        throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00034, "*");
                    }
                }
            }
            if (criterion.getType() == null) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00024, getValidTypes());
            }
            if (criterion.getLevel() == null) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00025, getValidLevels());
            }
            if (criterion.getName() == null) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00026);
            }
        }
    }

    private static List<Operators> getValidOperator() {
        List<Operators> validOperators = new ArrayList<Operators>();
        for (int i = 0; i < Operators.values().length; i++) {
            validOperators.add(Operators.values()[i]);
        }
        return validOperators;
    }

    private static List<Types> getValidTypes() {
        List<Types> validTypes = new ArrayList<Types>();
        for (int i = 0; i < Types.values().length; i++) {
            validTypes.add(Types.values()[i]);
        }
        return validTypes;
    }

    private static List<Levels> getValidLevels() {
        List<Levels> validLevels = new ArrayList<Levels>();
        for (int i = 0; i < Levels.values().length; i++) {
            validLevels.add(Levels.values()[i]);
        }
        return validLevels;
    }

    public static void checkOrderClause(OrderClause orderClause) throws SugarFunctionalException {
        if (orderClause != null) {
            if (orderClause.getType() == null) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00030, getValidTypes());
            }
            if (orderClause.getLevel() == null) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00028, getValidLevels());
            }
            if (orderClause.getName() == null) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00029);
            }
        }
    }

    public static void checkItem(Item item, List<Item> validItems) throws SugarFunctionalException {
        if (!validItems.contains(item)) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00031, validItems);
        }
    }

    public static void checkRange(long max) throws SugarFunctionalException {
        if (max < 0) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00033);
        }
    }

    public static List<FolderId> getSubListOfFolderId(List<Folder> folderToStore) {
        List<FolderId> ids = Lists.transform(folderToStore, new Function<Folder, FolderId>() {
            @Override
            public FolderId apply(Folder folder) {
                return folder.getFolderId();
            }
        });
        return ids;
    }

    public static List<Id> getSubListOfDocumentId(List<Document> documents) {
        List<Id> ids = Lists.transform(documents, new Function<Document, Id>() {
            @Override
            public Id apply(Document document) {
                if (document == null) {
                    return null;
                }
                return document.getId();
            }
        });
        return ids;
    }

    public static List<String> getSubListOfSymbolicName(List<BusinessScope> businessScopes) {
        Set<String> scopeSymbolicNames = new TreeSet<String>();
        for (BusinessScope businessScope : businessScopes) {
            scopeSymbolicNames.add(businessScope.getSymbolicName());
        }
        return Lists.newArrayList(scopeSymbolicNames);
    }
}
