package com.bnpp.cardif.sugar.core.tsp.event;

import java.util.Date;

import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpp.cardif.sugar.domain.fact.ObjectType;
import com.google.common.base.Objects;

/**
 * Defines a generic Sugar event and its necessary elements
 * 
 * @see SugarEventBus
 * 
 * @author Christopher Laszczuk
 * 
 */
public class Event {
    private final Date eventDate;

    private final String businessScope;

    private final Object object;

    private final ObjectType objectType;

    private final Action action;

    private final Object id;

    public Event(String businessScope, ObjectType objectType, Action action, Object object, Object id) {
        this.eventDate = new Date();
        this.businessScope = businessScope;
        this.objectType = objectType;
        this.action = action;
        this.object = object;
        this.id = id;
    }

    public Date getEventDate() {
        return new Date(eventDate.getTime());
    }

    public String getBusinessScope() {
        return businessScope;
    }

    public ObjectType getObjectType() {
        return this.objectType;
    }

    public Action getAction() {
        return this.action;
    }

    public Object getObject() {
        return this.object;
    }

    public Object getId() {
        return this.id;
    }

    @Override
    public String toString() {
        return Objects.toStringHelper(this).add("date", eventDate).add("businessScope", businessScope)
                .add("objectType", objectType).add("action", action).add("id", id).toString();
    }

    public static class Builder {
        private Builder(String scope) {
        }

        public Builder type(ObjectType type) {
            return this;
        }

        public static Builder forScope(String scope) {
            return new Builder(scope);
        }

        public void action(Action action) {
            // TODO Auto-generated method stub

        }
    }
}