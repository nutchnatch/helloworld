package com.bnpp.cardif.sugar.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.acls.domain.GrantedAuthoritySid;
import org.springframework.security.acls.domain.PrincipalSid;
import org.springframework.security.acls.model.Sid;
import org.springframework.security.acls.model.SidRetrievalStrategy;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * Created with IntelliJ IDEA. User: Simon MANQUEST Date: 05/03/14 Time: 09:45
 * To change this template use File | Settings | File Templates.
 */
public class SugarSidRetrievalStrategy implements SidRetrievalStrategy {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Override
    public List<Sid> getSids(Authentication authentication) {
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        Collection<? extends GrantedAuthority> authorities = userDetails.getAuthorities();
        List<Sid> sids = new ArrayList<Sid>(authorities.size() + 1);

        sids.add(new PrincipalSid(authentication));

        for (GrantedAuthority authority : authorities) {
            logger.debug("Authority added to SIDs : {}", authority.getAuthority());
            sids.add(new GrantedAuthoritySid(authority));
        }

        return sids;
    }
}
