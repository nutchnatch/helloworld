package com.bnpp.cardif.sugar.core.tsp.documentfile;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.documentfile.DocumentFileValidator;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.URI;

@Component
public class DocumentFileValidatorTSP implements DocumentFileValidator {

    @Autowired
    private BusinessScopeValidator businessScopeValidator;

    @Override
    public void checkAddValidity(List<DocumentFile> documentFiles)
            throws SugarFunctionalException, SugarTechnicalException {
        validateScope(documentFiles);
        for (DocumentFile documentFile : documentFiles) {
            if (documentFile.getContent() == null) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00701);
            }
        }
    }

    private void validateScope(List<DocumentFile> documentFiles)
            throws SugarFunctionalException, SugarTechnicalException {

        String scope = documentFiles.get(0).getScope();
        if (scope == null) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00211, documentFiles.get(0));
        }
        for (DocumentFile documentFile : documentFiles) {

            if (documentFile.getScope() == null) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00211, documentFile);
            }
            if (!scope.equals(documentFile.getScope())) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00209, scope,
                        documentFile.getScope());
            }
        }
        businessScopeValidator.checkExistence(scope);

    }

    @Override
    public void checkGetValidity(String scope, List<URI> uri) throws SugarTechnicalException, SugarFunctionalException {
        businessScopeValidator.checkExistence(scope);
    }

    @Override
    public void checkDeleteValidity(String scope, List<URI> uri)
            throws SugarTechnicalException, SugarFunctionalException {
        businessScopeValidator.checkExistence(scope);
    }
}
