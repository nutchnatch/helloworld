package com.bnpp.cardif.sugar.core.tsp.documentclass;

import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00204;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassService;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagClassValidator;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DurationType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.TimeUnitConstance;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOTagReference;
import com.google.common.collect.Lists;

@Component
public class DocumentClassValidatorTSP implements DocumentClassValidator {
    
    @Autowired
    private DocumentClassService documentClassService;

    @Autowired
    private TagClassValidator tagValidator;

    @Autowired
    private BusinessScopeValidator businessScopeValidator;

    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentClassValidatorTSP.class);

    @Override
    public void checkCreationValidity(List<DocumentClass> classes)
            throws SugarFunctionalException, SugarTechnicalException {
        if (classes.isEmpty()) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00208);
        }
        String scope = classes.get(0).getScope();
        verifyScopeAndTagReferences(classes, scope);
        List<String> symbolicNames = checkAndComputeSymbolicNames(classes);
        checkCategory(classes);
        List<DocumentClass> existingClasses = documentClassService.search(scope, null, false);
        List<String> fetchedNames = new ArrayList<String>();
        for (DocumentClass clazz : existingClasses) {
            fetchedNames.add(clazz.getLongLabel());
        }
        for (String name : symbolicNames) {
            if (fetchedNames.contains(name)) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00205, name,
                        classes.get(0).getScope());
            }
        }
        checkRetentionDuration(classes);
    }

    private void checkRetentionDuration(List<DocumentClass> classes) throws SugarFunctionalException {
        for (DocumentClass clazz : classes) {
            if (!clazz.isSetRetentionDuration()) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00201, clazz.getLongLabel());
            }
            DurationType retentionDuration = clazz.getRetentionDuration();
            try

            {
                if (!retentionDuration.isSetTimeUnit()) {
                    throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00202, clazz.getLongLabel());

                }
                if (!retentionDuration.isSetValue()) {
                    throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00214, clazz.getLongLabel());
                }

                TimeUnitConstance.fromValue(retentionDuration.getTimeUnit());
            }
            catch (IllegalArgumentException e) {
                LOGGER.warn(FunctionalErrorCode.F00203 + e.getMessage(), e);
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00203,
                        retentionDuration.getTimeUnit(), clazz.getLongLabel());
            }
        }

    }

    private void checkCategory(List<DocumentClass> classes) throws SugarFunctionalException {
        for (DocumentClass clazz : classes) {
            if (clazz.getCategory() == null) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00213, clazz.getLongLabel());
            }
        }

    }

    @Override
    public void checkUpdateValidity(List<DocumentClass> classes)
            throws SugarTechnicalException, SugarFunctionalException {
        if (classes.isEmpty()) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00208);
        }
        String scope = classes.get(0).getScope();
        verifyScopeAndTagReferences(classes, scope);
        List<ClassId> classIdsToCheck = new ArrayList<ClassId>();
        checkCategory(classes);
        for (DocumentClass clazz : classes) {
            classIdsToCheck.add(clazz.getClassId());
        }
        checkExistence(classIdsToCheck, scope);
        checkRetentionDuration(classes);
        checkLongLabelIsUnchanged(classes, scope);
    }

    private void checkLongLabelIsUnchanged(List<DocumentClass> classesToCheck, String scope)
            throws SugarTechnicalException, SugarFunctionalException {

        for (DocumentClass documentClazz : classesToCheck) {
            List<DocumentClass> storedClasses = documentClassService.get(scope,
                    Lists.newArrayList(documentClazz.getClassId()));
            if (!storedClasses.isEmpty()) {
                if (!storedClasses.get(0).getLongLabel().equals(documentClazz.getLongLabel())) {
                    throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00216,
                            storedClasses.get(0).getClassId());
                }
            }
        }
    }

    @Override
    public void checkExistence(List<ClassId> classIdsToCheck, String scope)
            throws SugarTechnicalException, SugarFunctionalException {
        List<DocumentClass> fetchedClasses = documentClassService.get(scope, classIdsToCheck);
        List<ClassId> fetchedIds = new ArrayList<ClassId>();
        for (DocumentClass clazz : fetchedClasses) {
            fetchedIds.add(clazz.getClassId());
        }
    }

    private void verifyScopeAndTagReferences(List<DocumentClass> documentClasses, String scope)
            throws SugarFunctionalException, SugarTechnicalException {
        List<MCOTagReference> tagReferences = new ArrayList<MCOTagReference>();
        if (scope == null) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00211,
                    documentClasses.get(0).getLongLabel());
        }
        for (DocumentClass clazz : documentClasses) {
            if (!scope.equals(clazz.getScope())) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00209, scope, clazz.getScope());
            }
            if (clazz.isActive()) {
                tagReferences.addAll(clazz.getTagReference());
            }
        }
        businessScopeValidator.checkExistence(scope);
        if (!tagReferences.isEmpty()) {
            List<String> symbolicNames = new ArrayList<String>();
            for (MCOTagReference ref : tagReferences) {
                symbolicNames.add(ref.getSymbolicName());
            }
            tagValidator.checkExistence(scope, symbolicNames);
        }
    }

    private List<String> checkAndComputeSymbolicNames(List<DocumentClass> documentClasses)
            throws SugarFunctionalException {
        List<String> symbolicNames = new ArrayList<String>();
        for (DocumentClass clazz : documentClasses) {
            String symbolicName = clazz.getLongLabel();
            if (symbolicName == null || symbolicName.trim().isEmpty()) {
                throw ExceptionBuilder.createFunctionalException(F00204);
            }
            if (!symbolicNames.contains(symbolicName)) {
                symbolicNames.add(symbolicName);
            }
            else {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00210, symbolicName);
            }
        }
        return symbolicNames;
    }

    @Override
    public void checkSearchValidity(String scope) throws SugarTechnicalException, SugarFunctionalException {
        businessScopeValidator.checkExistence(scope);
    }

    @Override
    public void checkGetValidity(String scope) throws SugarTechnicalException, SugarFunctionalException {
        businessScopeValidator.checkExistence(scope);
    }

    @Override
    public void checkActivateValidity(String scope) throws SugarTechnicalException, SugarFunctionalException {
        businessScopeValidator.checkExistence(scope);
    }
}