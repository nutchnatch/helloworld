package com.bnpp.cardif.sugar.core.tsp.document;

import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00005;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

/**
 * Warning PreAuthorize annotations are only evaluated on class entry point
 * public methods
 * 
 * @author Francois Barre
 * 
 */
@Component
public class DocumentSecurityHelper {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentSecurityHelper.class);

    @PreAuthorize("hasPermission(#document, T(org.springframework.security.acls.domain.BasePermission).CREATE)")
    public void checkStoreValidity(Document document) throws SugarFunctionalException {
        if (document.getData() == null) {
            throw ExceptionBuilder.createFunctionalException(F00005, document.getId());
        }
    }

    @PreAuthorize("hasPermission(#document, T(org.springframework.security.acls.domain.BasePermission).READ)")
    public void checkGetValidity(Document document) throws SugarFunctionalException {
        LOGGER.debug("Checking get validity for Document with id: " + document.getId());
    }

    @PreAuthorize("hasPermission(#document, T(org.springframework.security.acls.domain.BasePermission).DELETE)")
    public void checkDeleteAuhorisation(Document document) throws SugarFunctionalException {
        LOGGER.debug("Checking get validity for Document with id: " + document.getId());
    }

    @PreAuthorize("hasPermission(#document, T(org.springframework.security.acls.domain.BasePermission).WRITE)")
    public void checkUpdateValidity(Document document) throws SugarFunctionalException {
        LOGGER.debug("Checking update validity for Document with id: " + document.getId());
    }

    @PreAuthorize("hasPermission(#folder, T(org.springframework.security.acls.domain.BasePermission).CREATE)")
    public void checkStoreValidity(Folder folder) throws SugarFunctionalException {
        LOGGER.debug("Checking store validity for Folder with id: " + folder.getFolderId());
    }

    @PreAuthorize("hasPermission(#folder, T(org.springframework.security.acls.domain.BasePermission).READ)")
    public void checkGetValidity(Folder folder) throws SugarFunctionalException {
        LOGGER.debug("Checking get validity for Folder with id: " + folder.getFolderId());
    }

    @PreAuthorize("hasPermission(#folder, T(org.springframework.security.acls.domain.BasePermission).WRITE)")
    public void checkUpdateValidity(Folder folder) throws SugarFunctionalException {
        LOGGER.debug("Checking update validity for Folder with id: " + folder.getFolderId());
    }

    @PreAuthorize("hasPermission(#documentClass, T(org.springframework.security.acls.domain.BasePermission).ADMINISTRATION)")
    public void checkAdminAccessibility(DocumentClass documentClass) {
        LOGGER.debug("Checking admin accessibility for  documentClass with Id: " + documentClass.getClassId());
    }

    @PreAuthorize("hasPermission(#businessScope, T(org.springframework.security.acls.domain.BasePermission).ADMINISTRATION)")
    public void checkAdminAccessibility(String businessScope) {
        LOGGER.debug("Checking admin accessibility in business scope: " + businessScope);
    }

    @PreAuthorize("hasPermission(#documentClass, T(org.springframework.security.acls.domain.BasePermission).CREATE)")
    public void checkAdminCreationAuthorisation(DocumentClass documentClass) {
        LOGGER.debug("Checking admin creation authorisation for documentClass with Id: " + documentClass.getClassId());
    }

    @PreAuthorize("hasPermission(#basket, T(org.springframework.security.acls.domain.BasePermission).CREATE)")
    public void checkAdminCreationAuthorisation(Basket basket) {
        LOGGER.debug("Checking admin creation authorisation for basket with Id: " + basket.getBasketId());
    }

    @PreAuthorize("hasPermission(#basket, T(org.springframework.security.acls.domain.BasePermission).ADMINISTRATION)")
    public void checkAdminAccessibility(Basket basket) {
        LOGGER.debug("Checking admin accessibility for basket with Id: " + basket.getBasketId());
    }

    @PreAuthorize("hasPermission(#basket, T(org.springframework.security.acls.domain.BasePermission).READ)")
    public void checkReadAccessibility(Basket basket) {
        LOGGER.debug("Checking admin accessibility for basket with Id: " + basket.getBasketId());
    }

    @PreAuthorize("hasPermission(#folderClass, T(org.springframework.security.acls.domain.BasePermission).CREATE)")
    public void checkAdminCreationAuthorisation(FolderClass folderClass) {
        LOGGER.debug("Checking admin creation authorisation for folderClass with Id: " + folderClass.getClassId());
    }

    @PreAuthorize("hasPermission(#folderClass, T(org.springframework.security.acls.domain.BasePermission).ADMINISTRATION)")
    public void checkAdminAccessibility(FolderClass folderClass) {
        LOGGER.debug("Checking admin accessibility for folderclass with Id: " + folderClass.getClassId());
    }
}
