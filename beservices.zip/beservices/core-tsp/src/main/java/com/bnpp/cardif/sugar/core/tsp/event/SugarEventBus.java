package com.bnpp.cardif.sugar.core.tsp.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.google.common.eventbus.EventBus;

/**
 * Event bus of Sugar application. This event bus allows to handles specific
 * Sugar events.
 * 
 * <br/>
 * <br/>
 * This bus is based on {@link EventBus} of Guava library.
 * 
 * @see Event
 * @see EventSubscriber
 * 
 * @author Christopher Laszczuk
 * 
 */
@Component
public class SugarEventBus {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(SugarEventBus.class);

    private final EventBus eventBus = new EventBus();

    public void register(EventSubscriber subscriber) {
        eventBus.register(subscriber);
        LOGGER.debug("The subscriber: {} has been registered for the event bus {}", subscriber, this);
    }

    public void post(Event event) {
        LOGGER.trace("Posting: {}", event);
        eventBus.post(event);
    }
}