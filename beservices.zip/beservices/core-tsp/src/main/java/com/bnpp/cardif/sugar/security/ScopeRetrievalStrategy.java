package com.bnpp.cardif.sugar.security;

public interface ScopeRetrievalStrategy {

    String getScope(Object domainObject);

}
