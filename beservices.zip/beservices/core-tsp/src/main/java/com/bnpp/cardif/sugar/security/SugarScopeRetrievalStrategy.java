package com.bnpp.cardif.sugar.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

@Component
public class SugarScopeRetrievalStrategy implements ScopeRetrievalStrategy {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(SugarScopeRetrievalStrategy.class);

    @Override
    public String getScope(Object domainObject) {
        if (domainObject instanceof Document) {
            return ((Document) domainObject).getScope();
        }
        if (domainObject instanceof Folder) {
            return ((Folder) domainObject).getScope();
        }
        if (domainObject instanceof ClassId) {
            throw new IllegalArgumentException("Type invalid : " + domainObject.getClass());
        }
        if (domainObject instanceof DocumentClass) {
            return ((DocumentClass) domainObject).getScope();
        }
        if (domainObject instanceof FolderClass) {
            return ((FolderClass) domainObject).getScope();
        }
        if (domainObject instanceof Basket) {
            return ((Basket) domainObject).getScope();
        }
        if (domainObject instanceof Folder) {
            return ((Folder) domainObject).getScope();
        }
        if (domainObject instanceof String) {
            return (String) domainObject;
        }

        LOGGER.error("Could not retrieve business scope for domain object" + domainObject);
        return null;
    }
}
