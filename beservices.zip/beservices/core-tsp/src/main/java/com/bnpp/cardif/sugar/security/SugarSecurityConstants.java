package com.bnpp.cardif.sugar.security;

public class SugarSecurityConstants {
    public static final String TOKEN_NAMESPACE = "sugar";

    public static final String TOKEN_NAME = "token";
}
