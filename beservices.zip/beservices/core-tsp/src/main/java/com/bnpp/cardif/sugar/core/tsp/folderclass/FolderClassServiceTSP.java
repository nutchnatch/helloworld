package com.bnpp.cardif.sugar.core.tsp.folderclass;

import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00312;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00313;
import static com.bnpp.cardif.sugar.domain.fact.Action.CREATE;
import static com.bnpp.cardif.sugar.domain.fact.Action.UPDATE;
import static com.bnpp.cardif.sugar.domain.fact.ObjectType.FOLDER_CLASS;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpp.cardif.sugar.core.api.acl.AclService;
import com.bnpp.cardif.sugar.core.api.document.IdFactory;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassService;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassValidator;
import com.bnpp.cardif.sugar.core.tsp.document.DocumentSecurityHelper;
import com.bnpp.cardif.sugar.core.tsp.documentclass.AbstractClassServiceTSP;
import com.bnpp.cardif.sugar.core.tsp.event.Event;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.dao.api.folderclass.FolderClassDAO;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.google.common.base.Function;
import com.google.common.collect.Lists;

/**
 * 
 * @author Romain
 * 
 */
@Component
public class FolderClassServiceTSP extends AbstractClassServiceTSP implements FolderClassService {
    private static final Logger LOGGER = LoggerFactory.getLogger(FolderClassServiceTSP.class);

    @Autowired
    private IdFactory folderClassIdFactory;

    @Autowired
    private FolderClassDAO folderClassDAO;

    @Autowired
    private SugarEventBus eventBus;

    @Autowired
    private FolderClassValidator validator;

    @Autowired
    private DocumentSecurityHelper documentSecurityHelper;

    @Autowired
    private AclService aclService;

    @CacheEvict(value = "FolderClass", allEntries = true)
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public List<FolderClass> add(List<FolderClass> folderClassesToAdd)
            throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.debug("Adding a list of {} folder classes", folderClassesToAdd.size());
        validator.checkCreationValidity(folderClassesToAdd);
        checkAdminCreationAuthorisation(folderClassesToAdd);

        for (FolderClass folderClass : folderClassesToAdd) {
            folderClass.setClassId(folderClassIdFactory.generateClassId());
            Date currentDate = new Date();
            folderClass.setCreationDate(currentDate);
            folderClass.setUpdateDate(currentDate);
            aclService.assignDefault(folderClass.getScope(), folderClass.getClassId());
        }
        folderClassDAO.add(folderClassesToAdd);
        LOGGER.debug("{} folder classes have been added", folderClassesToAdd.size());
        fireEvents(folderClassesToAdd, CREATE);

        return folderClassesToAdd;
    }

    @CacheEvict(value = "FolderClass", allEntries = true)
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public List<FolderClass> update(List<FolderClass> folderClassesToUpdate, boolean createNewVersion)
            throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.debug("Updating {} folder classes", folderClassesToUpdate.size());
        validator.checkUpdateValidity(folderClassesToUpdate);
        checkAdminAccessibility(folderClassesToUpdate);

        List<ClassId> previousVersions = new ArrayList<ClassId>();
        for (FolderClass clazz : folderClassesToUpdate) {

            if (createNewVersion) {
                if (clazz.isActive()) {
                    FolderClass actual = get(Lists.newArrayList(clazz.getClassId()), clazz.getScope()).get(0);
                    previousVersions.add(actual.getClassId());
                }
                reportACLsOnNewVersionAndIncrementVersion(clazz.getScope(), clazz.getClassId());
                clazz.setCreationDate(new Date());
            }
            clazz.setUpdateDate(new Date());
        }
        if (createNewVersion) {
            if (!previousVersions.isEmpty()) {
                setActive(previousVersions, false, folderClassesToUpdate.get(0).getScope());
            }
            folderClassDAO.add(folderClassesToUpdate);
            fireEvents(folderClassesToUpdate, Action.CREATE);
        }
        else {
            overWriteCreationDate(folderClassesToUpdate);
            folderClassDAO.update(folderClassesToUpdate);
            fireEvents(folderClassesToUpdate, Action.UPDATE);
        }

        LOGGER.info("{} folder classes have been updated", folderClassesToUpdate.size());

        return folderClassesToUpdate;
    }

    private void overWriteCreationDate(List<FolderClass> folderClassesToUpdate)
            throws SugarTechnicalException, SugarFunctionalException {
        for (FolderClass clazz : folderClassesToUpdate) {
            FolderClass folderClass = get(Lists.newArrayList(clazz.getClassId()), clazz.getScope()).get(0);
            clazz.setCreationDate(folderClass.getCreationDate());
        }

    }

    @Cacheable("FolderClass")
    @Override
    @Transactional(readOnly = true)
    public List<FolderClass> get(List<ClassId> ids, String scope)
            throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.debug("Fetching a list of {} folder classes for the scope {}", ids.size(), scope);
        validator.checkGetValidity(scope);

        // TODO: Cache
        List<FolderClass> fetchedFolderClasses = folderClassDAO.get(ids, scope);
        fireEvents(fetchedFolderClasses, Action.READ);
        LOGGER.info("{} folder classes have been fetched for the scope {}", fetchedFolderClasses.size(), scope);
        return fetchedFolderClasses;
    }

    @Cacheable("FolderClass")
    @Override
    public SearchResults<FolderClass> find(String requestExpression, Criteria criteria, long start, long max,
            String orderExpression) throws SugarTechnicalException, SugarFunctionalException {
        // TODO Auto-generated method stub
        return null;
    }

    @Cacheable("FolderClass")
    @Override
    @Transactional(readOnly = true)
    public List<FolderClass> getAll(String scope, boolean isActiveOnly)
            throws SugarTechnicalException, SugarFunctionalException {
        // TODO: Cache
        LOGGER.debug("Fetching all folder classes for the scope {}", scope);
        validator.checkGetAll(scope);

        List<FolderClass> fetchedClasses = folderClassDAO.getAll(scope, isActiveOnly);

        fireEvents(fetchedClasses, Action.READ);
        LOGGER.info("{} folder classes have been fetched for the scope {}", fetchedClasses.size(), scope);
        return fetchedClasses;
    }

    @CacheEvict(value = "FolderClass", allEntries = true)
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public void setActive(List<ClassId> ids, boolean active, String scope)
            throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.debug("{} folder classes: {} for the scope={}", active ? "Activating" : "Deactivating", ids, scope);
        validator.checkActivateValidity(scope);
        checkClassesHaveInstanceACL(ids, scope);
        checkAdminAccessibility(scope, ids);
        folderClassDAO.setActive(ids, active, scope, new Date());
        if (active) {
            deactivateOtherVersions(ids, scope);
        }
        fireEvents(this.get(ids, scope), UPDATE);
        LOGGER.info("{} folder classes: {} for the scope={}", active ? "Activate" : "Deactivate", ids, scope);
    }

    private void deactivateOtherVersions(List<ClassId> classIds, String scope) throws SugarTechnicalException {
        List<FolderClass> allVersions = folderClassDAO.getAllVersions(classIds, scope);
        getIds(allVersions).removeAll(classIds);
        LOGGER.info("Deactivating {} in scope {}", classIds, scope);
        folderClassDAO.setActive(getIds(allVersions), false, scope, new Date());
    }

    private void fireEvents(List<FolderClass> fetchedFolderClasses, Action action) {
        for (FolderClass folderClass : fetchedFolderClasses) {
            String scope = folderClass.getScope();
            eventBus.post(new Event(scope, FOLDER_CLASS, action, folderClass, folderClass.getClassId()));
        }
    }

    private void checkAdminCreationAuthorisation(List<FolderClass> folderClassesToAdd) throws SugarFunctionalException {
        for (FolderClass folderClass : folderClassesToAdd) {
            try {
                documentSecurityHelper.checkAdminCreationAuthorisation(folderClass);
            }
            catch (AccessDeniedException e) {
                throw ExceptionBuilder.createFunctionalException(F00313, folderClass.getLongLabel(), e);
            }
        }
    }

    public void checkAdminAccessibility(final String scope, List<ClassId> classIds) throws SugarFunctionalException {
        List<FolderClass> classes = Lists.transform(classIds, new Function<ClassId, FolderClass>() {
            @Override
            public FolderClass apply(ClassId classId) {
                FolderClass folderClass = new FolderClass();
                folderClass.setClassId(classId);
                folderClass.setScope(scope);
                return folderClass;
            }
        });
        checkAdminAccessibility(classes);
    }

    public void checkAdminAccessibility(List<FolderClass> classes) throws SugarFunctionalException {
        for (FolderClass clazz : classes) {
            try {
                documentSecurityHelper.checkAdminAccessibility(clazz);
            }
            catch (AccessDeniedException e) {
                String label = clazz.getLongLabel() != null && !clazz.getLongLabel().isEmpty() ? clazz.getLongLabel()
                        : clazz.getClassId().toString();
                throw ExceptionBuilder.createFunctionalException(F00312, label, e);
            }
        }
    }

    private List<ClassId> getIds(List<FolderClass> classes) {
        return Lists.transform(classes, new Function<FolderClass, ClassId>() {
            @Override
            public ClassId apply(FolderClass clazz) {
                return clazz.getClassId();
            }
        });
    }

}
