package com.bnpp.cardif.sugar.security;

import org.springframework.security.acls.model.Permission;

import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;

public interface AclIdRetrievalStrategy {
    AclId getAclId(Object domainObject, String scope, Permission permission);
}
