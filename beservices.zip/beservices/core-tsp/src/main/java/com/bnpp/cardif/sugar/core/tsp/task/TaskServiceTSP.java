package com.bnpp.cardif.sugar.core.tsp.task;

import static com.bnpp.cardif.sugar.domain.fact.Action.CREATE;
import static com.bnpp.cardif.sugar.domain.fact.Action.LOCK;
import static com.bnpp.cardif.sugar.domain.fact.Action.READ;
import static com.bnpp.cardif.sugar.domain.fact.Action.TRANSFER;
import static com.bnpp.cardif.sugar.domain.fact.Action.UNLOCK;
import static com.bnpp.cardif.sugar.domain.fact.Action.UPDATE;
import static com.bnpp.cardif.sugar.domain.fact.ObjectType.TASK;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpp.cardif.sugar.core.api.document.IdFactory;
import com.bnpp.cardif.sugar.core.api.task.TaskService;
import com.bnpp.cardif.sugar.core.api.task.TaskValidator;
import com.bnpp.cardif.sugar.core.tsp.event.Event;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.dao.api.task.TaskDAO;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.TaskStatus;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;

@Component
public class TaskServiceTSP implements TaskService {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(TaskServiceTSP.class);

    @Autowired
    private TaskDAO taskDAO;

    @Autowired
    private SugarEventBus eventBus;

    @Autowired
    private TaskValidator taskValidator;

    @Autowired
    private IdFactory idFactory;

    @Override
    @Transactional(readOnly = true)
    public List<Task> get(String scope, List<TaskId> taskIds) throws SugarTechnicalException, SugarFunctionalException {
        if (taskIds.isEmpty()) {
            LOGGER.debug("Fetching an empty list of TaskIds");
            return new ArrayList<Task>();
        }
        taskValidator.validateGet(scope, taskIds);
        List<Task> tasks = taskDAO.get(scope, taskIds);
        fireEvents(tasks, READ);
        return tasks;
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public String updateStatus(String scope, List<TaskId> taskIds, String status)
            throws SugarTechnicalException, SugarFunctionalException {

        if (taskIds.isEmpty()) {
            LOGGER.debug("Updating an empty list of TaskIds");
            return status;
        }
        taskValidator.validateUpdateStatus(scope, taskIds, status);
        List<Task> tasksToUpdate = get(scope, taskIds);
        Date currentDate = new Date();
        for (Task task : tasksToUpdate) {
            task.setStatus(status);
            task.setUpdtDate(currentDate);
        }

        taskDAO.update(tasksToUpdate);
        if (TaskStatus.CLOSE.name().equals(status)) {
            fireEvents(scope, taskIds, Action.CLOSE);
        }
        else {
            fireEvents(scope, taskIds, UPDATE);
        }
        return status;
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public void lock(String scope, List<TaskId> taskIds, String lockerName)
            throws SugarTechnicalException, SugarFunctionalException {
        if (!taskIds.isEmpty()) {
            List<Task> tasksToLock = get(scope, taskIds);
            Date currentDate = new Date();
            for (Task task : tasksToLock) {
                task.setLockerName(lockerName);
                task.setUpdtDate(currentDate);
            }

            taskValidator.validateLock(scope, taskIds);
            taskDAO.update(tasksToLock);
            fireEvents(scope, taskIds, LOCK);
        }

    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public void unlock(String scope, List<TaskId> taskIds) throws SugarTechnicalException, SugarFunctionalException {
        taskValidator.validateUnLock(scope, taskIds);
        List<Task> tasksToUnlock = get(scope, taskIds);
        Date currentDate = new Date();
        for (Task task : tasksToUnlock) {
            task.setLockerName(null);
            task.setUpdtDate(currentDate);
        }
        taskDAO.update(tasksToUnlock);
        fireEvents(scope, taskIds, UNLOCK);
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public void transfer(String scope, List<TaskId> taskIds, BasketId basketId)
            throws SugarTechnicalException, SugarFunctionalException {
        taskValidator.validateTransfer(scope, taskIds, basketId);
        List<Task> tasksToTransfert = get(scope, taskIds);
        Date currentDate = new Date();
        for (Task task : tasksToTransfert) {
            task.setBasketId(basketId);
            task.setUpdtDate(currentDate);
        }
        taskDAO.update(tasksToTransfert);
        fireEvents(scope, taskIds, TRANSFER);
    }

    @Override
    @Transactional(readOnly = true)
    public SearchResults<Task> getTasksInBasket(String scope, BasketId basketId, int start, int max)
            throws SugarTechnicalException, SugarFunctionalException {
        taskValidator.validateGetTaskInBasket(scope, basketId);
        return taskDAO.getTasksInBasket(scope, basketId, start, max, true);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Task> getTasksForDocument(String scope, Id docId)
            throws SugarTechnicalException, SugarFunctionalException {
        taskValidator.validateGetTaskForDocument(scope, docId);
        return taskDAO.getTasksForDoc(scope, docId);
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public void create(List<Task> tasks) throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.debug("Storing the tasks: {}...", tasks);
        for (Task task : tasks) {
            task.setTaskId(idFactory.generateTaskId());
            task.setStatus(TaskStatus.NEW.toString());
            task.setCreatnDate(new Date());
        }
        taskValidator.validateCreation(tasks);
        taskDAO.storeTasks(tasks);
        fireEvents(tasks, CREATE);
        LOGGER.info("{} tasks have been stored", tasks.size());
    }

    private void fireEvents(String scope, List<TaskId> ids, Action action) throws SugarTechnicalException {
        List<Task> tasks = taskDAO.get(scope, ids);
        fireEvents(tasks, action);
    }

    private void fireEvents(List<Task> tasks, Action action) {
        for (Task task : tasks) {
            eventBus.post(new Event(task.getScope(), TASK, action, task, task.getTaskId()));
        }
    }

    @Override
    public void unlockAll(String scope, String userName) throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.info("Unlocking tasks for user {} in scope {} ", userName, scope);
        List<Task> tasksToUnlock = taskDAO.getByUser(scope, userName);
        if (tasksToUnlock != null && !tasksToUnlock.isEmpty()) {
            List<TaskId> idsToUnlock = new ArrayList<TaskId>();
            for (Task task : tasksToUnlock) {
                idsToUnlock.add(task.getTaskId());
            }
            unlock(scope, idsToUnlock);
        }
    }
}
