package com.bnpp.cardif.sugar.security.spring;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.acls.domain.AccessControlEntryImpl;
import org.springframework.security.acls.domain.AuditLogger;
import org.springframework.security.acls.domain.BasePermission;
import org.springframework.security.acls.domain.DefaultPermissionGrantingStrategy;
import org.springframework.security.acls.domain.GrantedAuthoritySid;
import org.springframework.security.acls.model.AccessControlEntry;
import org.springframework.security.acls.model.Acl;
import org.springframework.security.acls.model.NotFoundException;
import org.springframework.security.acls.model.ObjectIdentity;
import org.springframework.security.acls.model.Permission;
import org.springframework.security.acls.model.PermissionGrantingStrategy;
import org.springframework.security.acls.model.Sid;
import org.springframework.security.acls.model.UnloadedSidException;
import org.springframework.util.Assert;

import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.GrantType;

/**
 * Simple Spring Security Acl implementation for Sugar AccessControlList
 * 
 * @author Francois Barre
 * 
 */
public class SugarAclImpl implements Acl {

    /**
     * 
     */
    private static final long serialVersionUID = 5629361045845950345L;

    private final PermissionGrantingStrategy permissionGrantingStrategy;

    private final AccessControlList accessControlList;

    private List<AccessControlEntry> aces;

    public SugarAclImpl(AccessControlList accessControlList, AuditLogger auditLogger) {
        this.accessControlList = accessControlList;
        this.permissionGrantingStrategy = new DefaultPermissionGrantingStrategy(auditLogger);
    }

    @Override
    public synchronized List<AccessControlEntry> getEntries() {
        if (aces == null) {
            aces = new ArrayList<>();
            for (com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlEntry entry : accessControlList
                    .getAccessControlEntry()) {
                Permission permission = getPermission(entry.getPermission());
                boolean auditSuccess = false;
                boolean auditFailure = false;
                boolean granting = (entry.getGrant() == GrantType.ALLOW);
                for (String principal : entry.getPrincipal()) {
                    Sid sid = new GrantedAuthoritySid(principal);
                    aces.add(new AccessControlEntryImpl("0", this, sid, permission, granting, auditSuccess,
                            auditFailure));
                }
            }
        }
        return aces;
    }

    private Permission getPermission(String permission) {
        switch (permission) {
        case "READ":
            return BasePermission.READ;
        case "WRITE":
            return BasePermission.WRITE;
        case "CREATE":
            return BasePermission.CREATE;
        case "ADMINISTRATION":
            return BasePermission.ADMINISTRATION;
        case "DELETE":
            return BasePermission.DELETE;
        default:
            return null;
        }
    }

    @Override
    public ObjectIdentity getObjectIdentity() {
        return new SugarObjectIdentity(accessControlList.getAclId());
    }

    @Override
    public Sid getOwner() {
        return null; // To change body of implemented methods use File |
                     // Settings | File Templates.
    }

    @Override
    public Acl getParentAcl() {
        return null; // To change body of implemented methods use File |
                     // Settings | File Templates.
    }

    @Override
    public boolean isEntriesInheriting() {
        return false; // To change body of implemented methods use File |
                      // Settings | File Templates.
    }

    @Override
    public boolean isGranted(List<Permission> permission, List<Sid> sids, boolean administrativeMode)
            throws NotFoundException, UnloadedSidException {
        Assert.notEmpty(permission, "Permissions required");
        Assert.notEmpty(sids, "SIDs required");
        return permissionGrantingStrategy.isGranted(this, permission, sids, administrativeMode);
    }

    @Override
    public boolean isSidLoaded(List<Sid> sids) {
        return false; // To change body of implemented methods use File |
                      // Settings | File Templates.
    }
}
