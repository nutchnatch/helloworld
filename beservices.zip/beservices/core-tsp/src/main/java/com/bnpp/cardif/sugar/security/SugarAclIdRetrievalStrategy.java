package com.bnpp.cardif.sugar.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.acls.domain.BasePermission;
import org.springframework.security.acls.model.Permission;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.core.api.acl.AclService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

/**
 * Created with IntelliJ IDEA. User: Simon MANQUEST Date: 04/03/14 Time: 16:49
 * To change this template use File | Settings | File Templates.
 */
@Component
public class SugarAclIdRetrievalStrategy implements AclIdRetrievalStrategy {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(SugarAclIdRetrievalStrategy.class);

    @Autowired
    private AclService aclService;

    public SugarAclIdRetrievalStrategy() {
    }

    /**
     * Get the ACL associated with the domainObject
     * 
     * @param domainObject
     * @return
     */
    @Override
    public AclId getAclId(Object domainObject, String scope, Permission permission) {
        try {
            LOGGER.debug("Trying fetch class of domainObject :" + domainObject);
            if (domainObject instanceof Document) {
                LOGGER.debug("DomainObject is a Document");
                Document document = (Document) domainObject;
                if (BasePermission.CREATE.equals(permission)) {
                    AclId aclId = null;
                    if (ValdtyCode.UNDER_CONSTRUCTION.equals(document.getData().getValidityCode())) {

                        LOGGER.debug("checking security for document under creation");
                        aclId = aclService.getDefault(document.getScope()).getAclId();
                        LOGGER.debug("FETCHED ACL {}", aclId);
                    }
                    else {
                        ClassId classId = document.getData().getClassId();
                        AccessControlList acl = aclService.getByClassId(scope, classId, false);
                        if (acl != null) {
                            aclId = acl.getAclId();
                        }
                    }
                    if (aclId != null) {

                        return aclId;
                    }
                }
                else {
                    Id documentId = document.getId();
                    AccessControlList fetchedAcl = aclService.getByDocumentId(scope, documentId);
                    if (fetchedAcl != null) {
                        return fetchedAcl.getAclId();
                    }
                }
            }
            if (domainObject instanceof Folder) {
                LOGGER.debug("DomainObject is a Folder and permission is " + permission);
                Folder folder = (Folder) domainObject;
                if (BasePermission.CREATE.equals(permission)) {
                    ClassId classId = folder.getData().getClassId();
                    AccessControlList fetchedAcl = aclService.getByClassId(scope, classId, false);
                    if (fetchedAcl != null) {
                        return fetchedAcl.getAclId();
                    }
                }
                else {
                    FolderId folderId = folder.getFolderId();
                    AccessControlList fetchedAcl = aclService.getByFolderId(scope, folderId);
                    if (fetchedAcl != null) {
                        return fetchedAcl.getAclId();
                    }
                }
            }

            else if (domainObject instanceof DocumentClass) {
                LOGGER.debug("DomainObject is a DocumentClass");
                DocumentClass documentClass = (DocumentClass) domainObject;
                if (BasePermission.CREATE.equals(permission)) {
                    return getScopeAcl(scope);
                }
                else {
                    AccessControlList fetchedAcl = aclService.getByClassId(scope, documentClass.getClassId(), false);
                    if (fetchedAcl != null) {
                        return fetchedAcl.getAclId();
                    }
                }
            }
            else if (domainObject instanceof FolderClass) {
                LOGGER.debug("DomainObject is a FolderClass");
                FolderClass folderClass = (FolderClass) domainObject;
                if (BasePermission.CREATE.equals(permission)) {
                    return getScopeAcl(scope);
                }
                else {
                    AccessControlList fetchedAcl = aclService.getByClassId(scope, folderClass.getClassId(), false);
                    if (fetchedAcl != null) {
                        return fetchedAcl.getAclId();
                    }
                }
            }
            if (domainObject instanceof Basket) {
                LOGGER.debug("DomainObject is a Basket");
                Basket basket = (Basket) domainObject;
                if (BasePermission.CREATE.equals(permission)) {
                    return getScopeAcl(scope);
                }
                else {
                    AccessControlList fetchedAcl = aclService.getByBasketId(scope, basket.getBasketId());
                    if (fetchedAcl != null) {
                        return fetchedAcl.getAclId();
                    }
                }
            }
            if (domainObject instanceof String)

            {
                LOGGER.debug("Fetching default ACL");
                return getScopeAcl(scope);
            }

            LOGGER.debug("Could not fetch class of domainObject");
        }
        catch (SugarTechnicalException e) {
            throw new AccessDeniedException("Could not get object ACL for object " + domainObject + " of class: "
                    + domainObject.getClass().getSimpleName(), e);
        }
        catch (SugarFunctionalException e) {
            throw new AccessDeniedException("Could not get object ACL for object " + domainObject + " of class: "
                    + domainObject.getClass().getSimpleName(), e);
        }
        throw new AccessDeniedException("Could not get object ACL for object " + domainObject + " of class: "
                + domainObject.getClass().getSimpleName());
    }

    private AclId getScopeAcl(String scope) throws SugarTechnicalException, SugarFunctionalException {
        return aclService.getByScope(scope).getAclId();
    }

    public AclService getAclService() {
        return aclService;
    }

    public void setAclService(AclService aclService) {
        LOGGER.info("Setting " + this + ".aclService=" + aclService);
        this.aclService = aclService;
    }
}
