package com.bnpp.cardif.sugar.core.tsp.task;

import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00501;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00502;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeService;
import com.bnpp.cardif.sugar.core.api.documentfile.DocumentFileService;
import com.bnpp.cardif.sugar.core.api.task.TaskDistributionSystemService;
import com.bnpp.cardif.sugar.core.api.task.TaskGeneratorService;
import com.bnpp.cardif.sugar.core.tsp.event.Event;
import com.bnpp.cardif.sugar.core.tsp.event.EventSubscriber;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.URI;
import com.google.common.collect.Lists;

public class EventTaskDistributionSystemService extends EventSubscriber implements TaskDistributionSystemService {
    private static final Logger LOGGER = LoggerFactory.getLogger(EventTaskDistributionSystemService.class);

    @Autowired
    private TaskGeneratorService<Document, String, DocumentFile> taskGenerateService;

    @Autowired
    private BusinessScopeService businessScopeService;

    @Autowired
    private DocumentFileService documentFileService;

    @Autowired
    private SugarEventBus eventBus;

    private boolean isPropageExceptionsOnEvent = true;

    public EventTaskDistributionSystemService() {
    }

    public void bind() {
        eventBus.register(this);
    }

    @Override
    protected void onEvent(Event event) throws SugarFunctionalException, SugarTechnicalException {
        try {
            push(event.getObject(), event.getAction());
        }
        catch (SugarTechnicalException e) {
            if (isPropageExceptionsOnEvent) {
                throw (e);
            }
        }
        catch (SugarFunctionalException e) {
            if (isPropageExceptionsOnEvent) {
                throw (e);
            }
        }
    }

    @Override
    public void push(Object object, Action action) throws SugarTechnicalException, SugarFunctionalException {
        final Document envelope = checkIsEnvelope(object);
        LOGGER.info("TDS may generates a new task for envelope id : {} and action {}", envelope.getId(), action);
        final String scope = envelope.getScope();

        TaskGeneratorService.TaskGeneratorResolver<String, DocumentFile> rulesResolver = new TaskGeneratorService.TaskGeneratorResolver<String, DocumentFile>() {
            @Override
            public DocumentFile resolve(String rulesId) throws SugarFunctionalException {
                try {
                    List<URI> uris = Lists.newArrayList(getRulesId(scope));
                    List<DocumentFile> documentFiles = getDocumentFiles(scope, uris);
                    return documentFiles.size() == 1 ? documentFiles.get(0) : null;
                }
                catch (SugarTechnicalException e) {
                    LOGGER.warn(F00501 + e.getMessage(), e);
                    throw ExceptionBuilder.createFunctionalException(F00501, scope);
                }
                catch (SugarFunctionalException e) {
                    LOGGER.warn(F00501 + e.getMessage(), e);
                    throw ExceptionBuilder.createFunctionalException(F00501, scope);
                }
            }

        };

        String rulesId = scope + "#" + getRulesId(scope).getValue();
        taskGenerateService.generate(envelope, rulesId, rulesResolver, action);
    }

    @Cacheable("Drools")
    private List<DocumentFile> getDocumentFiles(final String scope, List<URI> uris)
            throws SugarTechnicalException, SugarFunctionalException {
        List<DocumentFile> documentFiles;
        documentFiles = documentFileService.get(scope, uris);
        return documentFiles;
    }

    private Document checkIsEnvelope(Object object) throws SugarFunctionalException {
        if (object instanceof Document) {
            Document component = (Document) object;
            if (Category.ENVELOPE.equals(component.getCategory())) {
                return component;
            }
        }
        throw ExceptionBuilder.createFunctionalException(F00502, object.getClass().getSimpleName());
    }

    protected URI getRulesId(String scope) throws SugarTechnicalException, SugarFunctionalException {
        List<BusinessScope> businessScopes = businessScopeService.getBySymbolicName(Lists.newArrayList(scope));
        if (businessScopes.size() != 1) {
            throw ExceptionBuilder.createFunctionalException(F00501, scope);
        }
        if (businessScopes.get(0).isSetFileData() && businessScopes.get(0).getFileData().isSetURI()) {
            return new URI(businessScopes.get(0).getFileData().getURI());
        }
        return null;
    }

    public void setPropageExceptionsOnEvent(boolean isPropageExceptionsOnEvent) {
        this.isPropageExceptionsOnEvent = isPropageExceptionsOnEvent;
    }
}
