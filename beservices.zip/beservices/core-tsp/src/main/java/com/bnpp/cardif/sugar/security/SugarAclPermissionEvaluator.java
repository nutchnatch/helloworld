package com.bnpp.cardif.sugar.security;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.acls.domain.AuditLogger;
import org.springframework.security.acls.model.Acl;
import org.springframework.security.acls.model.NotFoundException;
import org.springframework.security.acls.model.Permission;
import org.springframework.security.acls.model.Sid;
import org.springframework.security.acls.model.SidRetrievalStrategy;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.core.api.acl.AclService;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.security.spring.SugarAclImpl;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;

/**
 * Created with IntelliJ IDEA. User: Simon MANQUEST Date: 04/03/14 Time: 16:32
 */
@Component
public class SugarAclPermissionEvaluator implements PermissionEvaluator {

    private static final Logger LOGGER = LoggerFactory.getLogger(SugarAclPermissionEvaluator.class);

    @Autowired
    private AclIdRetrievalStrategy sugarAclIdRetrievalStrategy;

    @Autowired
    private ScopeRetrievalStrategy sugarScopeRetrievalStrategy;

    @Autowired
    private AclService aclService;

    @Autowired
    private SecurityHelper securityHelper;

    private final SidRetrievalStrategy sidRetrievalStrategy = new SugarSidRetrievalStrategy();

    @Autowired
    private AuditLogger auditLogger;

    public SugarAclPermissionEvaluator() {
        LOGGER.trace("New SugarAclPermissionEvaluator");
    }

    @Override
    public boolean hasPermission(Authentication authentication, Object domainObject, Object permission) {
        LOGGER.debug("has permission.... ");
        if (domainObject == null) {
            LOGGER.debug("domain object is null - returning false");
            return false;
        }
        if (!securityHelper.isSecurityEnabled()) {
            LOGGER.debug("Security is disabled: hasPermission returning true");
            return true;
        }
        LOGGER.debug("hasPermission(auth= {} , domainObject= {}, permission= {} )", authentication, domainObject,
                permission);
        String scope = sugarScopeRetrievalStrategy.getScope(domainObject);
        AclId aclId = sugarAclIdRetrievalStrategy.getAclId(domainObject, scope, (Permission) permission);

        if (aclId == null) {
            LOGGER.error("No AclId for object {}, scope {}, permission {}", domainObject, scope, permission);
            return false;
        }

        boolean result = checkPermission(authentication, aclId, scope, (Permission) permission);
        LOGGER.debug("hasPermission(auth= {}, domainObject= {}, permission= {} ) : {}", authentication, domainObject,
                permission, result);
        return result;
    }

    @Override
    public boolean hasPermission(Authentication authentication, Serializable serializable, String s, Object o) {
        return false;
    }

    private boolean checkPermission(Authentication authentication, AclId aclId, String scope, Permission permission) {
        LOGGER.debug("checkPermission(auth={}, aclId={}, scope={}, permission{}", authentication, aclId, scope,
                permission);
        // Obtain the SIDs applicable to the principal
        List<Sid> sids = sidRetrievalStrategy.getSids(authentication);

        List<Permission> requiredPermission = new ArrayList<>();
        requiredPermission.add(permission);

        try {
            // Lookup only ACLs for SIDs we're interested in
            Acl acl = readAclById(aclId, scope);

            if (acl == null) {
                LOGGER.error("No ACL for aclId {}, scope {}", aclId, scope);
                return false;
            }
            if (acl.isGranted(requiredPermission, sids, false)) {
                LOGGER.debug("Access is granted");
                return true;
            }
            LOGGER.debug("Returning false - ACLs returned, but insufficient permissions for this principal");
        }
        catch (NotFoundException nfe) {
            LOGGER.debug("Returning false - no ACLs apply for this principal", nfe);
        }
        return false;
    }

    private Acl readAclById(AclId aclId, String scope) throws NotFoundException {
        try {
            AccessControlList accessControlList = aclService.get(scope, aclId);
            LOGGER.debug("Got for AclId {}, scope{} : {}", aclId, scope, accessControlList);
            return new SugarAclImpl(accessControlList, auditLogger);
        }
        catch (SugarTechnicalException | SugarFunctionalException e) {
            LOGGER.error("Got no Acl for AclId : " + aclId + ", scope=" + scope, e);
            throw new NotFoundException("Could not get Acl for id : " + aclId + ", scope=" + scope, e);
        }
    }

    public AclIdRetrievalStrategy getAclIdRetrievalStrategy() {
        return sugarAclIdRetrievalStrategy;
    }

    public void setAclIdRetrievalStrategy(AclIdRetrievalStrategy aclIdRetrievalStrategy) {
        LOGGER.info("Set sugarAclIdRetrievalStrategy= {}", aclIdRetrievalStrategy);
        this.sugarAclIdRetrievalStrategy = aclIdRetrievalStrategy;
    }

    public ScopeRetrievalStrategy getScopeRetrievalStrategy() {
        return sugarScopeRetrievalStrategy;
    }

    public void setScopeRetrievalStrategy(ScopeRetrievalStrategy scopeRetrievalStrategy) {
        LOGGER.info("Set scopeRetrievalStrategy= {}", scopeRetrievalStrategy);
        this.sugarScopeRetrievalStrategy = scopeRetrievalStrategy;
    }

    public AclService getAclService() {
        return aclService;
    }

    public void setAclService(AclService aclService) {
        LOGGER.info("Set aclService= {}", aclService);
        this.aclService = aclService;
    }
}
