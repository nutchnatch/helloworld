package com.bnpp.cardif.sugar.core.tsp.documentclass;

import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00206;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00310;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00311;
import static com.bnpp.cardif.sugar.domain.fact.Action.UPDATE;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpp.cardif.sugar.core.api.acl.AclService;
import com.bnpp.cardif.sugar.core.api.document.IdFactory;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassService;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassValidator;
import com.bnpp.cardif.sugar.core.tsp.document.DocumentSecurityHelper;
import com.bnpp.cardif.sugar.core.tsp.event.Event;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.dao.api.documentclass.DocumentClassDAO;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpp.cardif.sugar.domain.fact.ObjectType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.google.common.base.Function;
import com.google.common.collect.Lists;

/**
 * Default implementation of {@link DocumentClassService}
 * 
 * @author Romain
 * 
 */
@Component
public class DocumentClassServiceTSP extends AbstractClassServiceTSP implements DocumentClassService {
    private static final Logger LOGGER = LoggerFactory.getLogger(DocumentClassServiceTSP.class);

    @Autowired
    private DocumentClassDAO documentClassDAO;

    @Autowired
    private IdFactory classIdFactory;

    @Autowired
    private DocumentSecurityHelper documentSecurityHelper;

    @Autowired
    private SugarEventBus eventBus;

    @Autowired
    private AclService aclService;

    @Autowired
    private DocumentClassValidator validator;

    public void init() {
        // not in use
    }

    @Cacheable("DocumentClass")
    @Override
    @Transactional(readOnly = true)
    public List<DocumentClass> search(String scope, Category category, boolean isActiveOnly)
            throws SugarTechnicalException, SugarFunctionalException {
        validator.checkSearchValidity(scope);
        List<DocumentClass> fetchedClasses = documentClassDAO.search(scope, category, isActiveOnly);
        LOGGER.info("{} {} document class(es) have been fetch for scope={} and category={}", fetchedClasses.size(),
                isActiveOnly ? "active" : "", scope, category);
        fireEvents(fetchedClasses, Action.SEARCH);
        return fetchedClasses;
    }

    @CacheEvict(value = "DocumentClass", allEntries = true)
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public List<DocumentClass> add(List<DocumentClass> classes)
            throws SugarTechnicalException, SugarFunctionalException {
        validator.checkCreationValidity(classes);
        checkAdminCreationAuthorisation(classes);

        for (DocumentClass clazz : classes) {
            Date creationDate = new Date();
            clazz.setCreateDate(creationDate);
            clazz.setLastUpdateDate(creationDate);
            clazz.setClassId(classIdFactory.generateClassId());
            aclService.assignDefault(clazz.getScope(), clazz.getClassId());
        }

        documentClassDAO.store(classes);
        fireEvents(classes, Action.CREATE);

        return classes;
    }

    @Cacheable("DocumentClass")
    @Override
    @Transactional(readOnly = true)
    public List<DocumentClass> get(String scope, List<ClassId> classIds)
            throws SugarTechnicalException, SugarFunctionalException {

        validator.checkGetValidity(scope);

        List<DocumentClass> classes = documentClassDAO.get(scope, classIds);
        List<ClassId> fetchIds = getIds(classes);

        if (fetchIds != null && fetchIds.containsAll(classIds)) {
            fireEvents(classes, Action.READ);
            return classes;
        }

        classIds.removeAll(fetchIds);
        throw ExceptionBuilder.createFunctionalException(F00206, classIds);
    }

    @CacheEvict(value = "DocumentClass", allEntries = true)
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public List<DocumentClass> update(List<DocumentClass> classes, boolean changeVersion)
            throws SugarTechnicalException, SugarFunctionalException {
        validator.checkUpdateValidity(classes);
        checkAdminAccessibility(classes);

        List<ClassId> previousVersions = new ArrayList<ClassId>();
        for (DocumentClass clazz : classes) {
            if (changeVersion) {
                if (clazz.isActive()) {
                    DocumentClass actual = get(clazz.getScope(), Lists.newArrayList(clazz.getClassId())).get(0);
                    previousVersions.add(actual.getClassId());
                }
                reportACLsOnNewVersionAndIncrementVersion(clazz.getScope(), clazz.getClassId());
                clazz.setCreateDate(new Date());
            }
            clazz.setLastUpdateDate(new Date());
        }
        if (changeVersion) {
            documentClassDAO.store(classes);
            fireEvents(classes, Action.CREATE);
            if (!previousVersions.isEmpty()) {
                activate(classes.get(0).getScope(), previousVersions, false);
            }
        }
        else {
            overWriteCreationDate(classes);
            documentClassDAO.update(classes);
            fireEvents(classes, Action.UPDATE);
        }

        return classes;
    }

    private void overWriteCreationDate(List<DocumentClass> classes)
            throws SugarTechnicalException, SugarFunctionalException {
        for (DocumentClass clazz : classes) {
            DocumentClass fetchedClass = get(clazz.getScope(), Lists.newArrayList(clazz.getClassId())).get(0);
            clazz.setCreateDate(fetchedClass.getCreateDate());
        }
    }

    @CacheEvict(value = "DocumentClass", allEntries = true)
    @Override
    public void activate(String scope, List<ClassId> classIds, boolean activate)
            throws SugarTechnicalException, SugarFunctionalException {
        validator.checkActivateValidity(scope);
        LOGGER.debug("{} {} document classes for scope={} and ids={}", activate ? "Activating" : "Deactivating",
                classIds.size(), scope, classIds);

        checkClassesHaveInstanceACL(classIds, scope);

        List<DocumentClass> documentClasses = this.get(scope, classIds);

        checkAdminAccessibility(documentClasses);
        List<DocumentClass> classesToUpdate = new ArrayList<DocumentClass>();
        for (DocumentClass clazz : documentClasses) {
            clazz.setActive(activate);
            classesToUpdate.add(clazz);
            if (activate) {
                List<DocumentClass> deactivatedVersions = deactivateOtherVersions(scope, clazz.getClassId());
                classesToUpdate.addAll(deactivatedVersions);
            }
        }
        List<DocumentClass> updated = this.update(classesToUpdate, false);

        LOGGER.info("{} document classes have been {} for scope={}", updated.size(),
                activate ? "activated" : "deactivated", scope);
        fireEvents(classesToUpdate, UPDATE);
    }

    private List<DocumentClass> deactivateOtherVersions(String scope, ClassId classId)
            throws SugarTechnicalException, SugarFunctionalException {
        List<DocumentClass> allVersionClazz = documentClassDAO.getAllVersions(scope, Lists.newArrayList(classId));
        List<DocumentClass> deactivatedClazz = new ArrayList<DocumentClass>();
        for (DocumentClass clazz : allVersionClazz) {
            if (clazz.getClassId().getVersId() != classId.getVersId()) {
                clazz.setActive(false);
                deactivatedClazz.add(clazz);
            }
        }
        return deactivatedClazz;
    }

    private void fireEvents(List<DocumentClass> classes, Action action) {
        for (DocumentClass clazz : classes) {
            eventBus.post(new Event(clazz.getScope(), getObjectType(clazz), action, clazz, clazz.getClassId()));
        }
    }

    private ObjectType getObjectType(DocumentClass clazz) {
        boolean isDocument = Category.DOCUMENT.equals(clazz.getCategory());
        return isDocument ? ObjectType.DOCUMENT_CLASS : ObjectType.ENVELOPE_CLASS;
    }

    private void checkAdminCreationAuthorisation(List<DocumentClass> documentClasses) throws SugarFunctionalException {
        for (DocumentClass documentClass : documentClasses) {
            try {
                documentSecurityHelper.checkAdminCreationAuthorisation(documentClass);
            }
            catch (AccessDeniedException e) {
                throw ExceptionBuilder.createFunctionalException(F00310, documentClass.getLongLabel(), e);
            }
        }
    }

    private void checkAdminAccessibility(List<DocumentClass> documentClasses) throws SugarFunctionalException {
        for (DocumentClass documentClass : documentClasses) {
            try {
                documentSecurityHelper.checkAdminAccessibility(documentClass);
            }
            catch (AccessDeniedException e) {
                throw ExceptionBuilder.createFunctionalException(F00311, documentClass.getLongLabel(), e);
            }
        }
    }

    private List<ClassId> getIds(List<DocumentClass> classes) {
        return Lists.transform(classes, new Function<DocumentClass, ClassId>() {
            @Override
            public ClassId apply(DocumentClass clazz) {
                return clazz.getClassId();
            }
        });
    }

}
