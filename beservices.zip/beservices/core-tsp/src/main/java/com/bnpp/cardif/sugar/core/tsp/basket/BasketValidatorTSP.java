package com.bnpp.cardif.sugar.core.tsp.basket;

import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00401;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00402;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00403;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.core.api.basket.BasketService;
import com.bnpp.cardif.sugar.core.api.basket.BasketValidator;
import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.task.TaskService;
import com.bnpp.cardif.sugar.core.tsp.util.ValidatorHelper;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.Basket;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;
import com.google.common.collect.Lists;

@Component
public class BasketValidatorTSP implements BasketValidator {
    @Autowired
    private BusinessScopeValidator scopeValidator;

    @Autowired
    private TaskService taskService;

    @Autowired
    private BasketService service;

    @Override
    public void checkCreation(List<Basket> baskets) throws SugarTechnicalException, SugarFunctionalException {
        checkNotEmpty(baskets);
        checkScope(baskets);
        checkSymbolicName(baskets);

    }

    private void checkNotEmpty(List<Basket> baskets) throws SugarFunctionalException {
        if (baskets == null || baskets.isEmpty()) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.G666);
        }

    }

    @Override
    public void checkUpdate(List<Basket> baskets) throws SugarTechnicalException, SugarFunctionalException {
        checkNotEmpty(baskets);
        String scope = checkScope(baskets);
        checkNameHasNotChange(baskets, scope);

    }

    private void checkNameHasNotChange(List<Basket> baskets, String scope)
            throws SugarTechnicalException, SugarFunctionalException {
        List<BasketId> ids = Lists.newArrayList(getIds(baskets));
        List<Basket> existingBaskets = checkExistence(ids, scope);
        for (Basket basket : baskets) {
            for (Basket existingBasket : existingBaskets) {
                if (existingBasket.getBasketId().equals(basket.getBasketId())
                        && !existingBasket.getSymbolicName().equals(basket.getSymbolicName())) {
                    throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00410,
                            existingBasket.getBasketId());

                }
            }
        }
    }

    private Set<BasketId> getIds(List<Basket> baskets) {
        Set<BasketId> basketIds = new TreeSet<BasketId>(new Comparator<BasketId>() {

            @Override
            public int compare(BasketId o1, BasketId o2) {

                return o1.hashCode() - o2.hashCode();
            }
        });
        for (Basket basket : baskets) {
            basketIds.add(basket.getBasketId());
        }
        return basketIds;
    }

    private String checkScope(List<Basket> baskets) throws SugarTechnicalException, SugarFunctionalException {
        String scope = baskets.get(0).getScope();
        if (scope == null) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00407,
                    baskets.get(0).getSymbolicName());
        }
        for (Basket basket : baskets) {
            if (basket.getScope() == null) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00407, basket.getSymbolicName());

            }
            if (!basket.getScope().equals(scope)) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00408);

            }
            scopeValidator.checkExistence(scope);
        }
        return scope;

    }

    private void checkSymbolicName(List<Basket> baskets) throws SugarTechnicalException, SugarFunctionalException {
        List<Basket> existingBaskets = service.getAllUnfiltered(baskets.get(0).getScope());
        List<String> existingLongLabel = new ArrayList<String>();
        for (Basket existingClass : existingBaskets) {
            existingLongLabel.add(existingClass.getSymbolicName());
        }
        for (Basket basket : baskets) {
            if (basket.getSymbolicName() == null || basket.getSymbolicName().trim().isEmpty()) {
                throw ExceptionBuilder.createFunctionalException(F00401, basket);
            }

            if (existingLongLabel.contains(basket.getSymbolicName())) {
                throw ExceptionBuilder.createFunctionalException(F00402, basket.getSymbolicName(), basket.getScope());
            }
        }
    }

    @Override
    public void checkGet(String scope) throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);
    }

    @Override
    public void checkGetAll(String scope) throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);
    }

    @Override
    public void checkDelete(List<BasketId> ids, String scope) throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);
        for (BasketId basketId : ids) {
            SearchResults<Task> searchResults = taskService.getTasksInBasket(scope, basketId, 0, 1);
            if (!searchResults.getObjects().isEmpty()) {
                throw ExceptionBuilder.createFunctionalException(F00403, basketId);
            }
        }
    }

    @Override
    public List<Basket> checkExistence(List<BasketId> ids, String scope)
            throws SugarTechnicalException, SugarFunctionalException {
        List<BasketId> cleanIds = ValidatorHelper.removeDuplicates(ids);

        List<Basket> fetchedBaskets = service.get(cleanIds, scope);
        if (fetchedBaskets == null) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00409, cleanIds);
        }

        List<BasketId> fetchedBasketIds = new ArrayList<BasketId>();
        for (Basket basket : fetchedBaskets) {
            fetchedBasketIds.add(basket.getBasketId());
        }

        if (fetchedBasketIds.size() != cleanIds.size() || !fetchedBasketIds.containsAll(cleanIds)
                || !cleanIds.containsAll(fetchedBasketIds)) {
            cleanIds.removeAll(getIds(fetchedBaskets));
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00409, cleanIds);
        }
        return fetchedBaskets;
    }

}
