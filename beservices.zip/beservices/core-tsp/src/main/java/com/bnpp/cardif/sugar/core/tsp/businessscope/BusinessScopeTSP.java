package com.bnpp.cardif.sugar.core.tsp.businessscope;

import static com.bnpp.cardif.sugar.domain.fact.Action.CREATE;
import static com.bnpp.cardif.sugar.domain.fact.Action.READ;
import static com.bnpp.cardif.sugar.domain.fact.Action.UPDATE;
import static com.bnpp.cardif.sugar.domain.fact.ObjectType.BUSINESS_SCOPE;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeService;
import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.document.IdFactory;
import com.bnpp.cardif.sugar.core.tsp.event.Event;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.dao.api.businessscope.BusinessScopeDAO;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.google.common.collect.Lists;

/**
 * 
 * @author Florian Deruette
 * 
 */
@Component
public class BusinessScopeTSP implements BusinessScopeService {
    private static final Logger LOGGER = LoggerFactory.getLogger(BusinessScopeTSP.class);

    @Autowired
    private BusinessScopeDAO businessscopeDAO;

    @Autowired
    private SugarEventBus eventBus;

    @Autowired
    private BusinessScopeValidator validator;

    @Autowired
    private IdFactory idFactory;

    public void init() {
        // disused here for retrocompatability
    }

    @CacheEvict(value = "BusinessScope", allEntries = true)
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public void store(List<BusinessScope> scopes) throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.debug("Storing supplied business scopes");

        validator.checkCreationValidity(scopes);
        for (BusinessScope scope : scopes) {
            Date currentDate = new Date();
            scope.setCreationDate(currentDate);
            scope.setUpdateDate(currentDate);
            scope.setBusinessScopeId(idFactory.generateBusinessScopeId());
        }
        businessscopeDAO.store(scopes);
        LOGGER.info("{} business scopes have been stored", scopes.size());
        fireEvents(scopes, CREATE);
    }

    @Cacheable("BusinessScope")
    @Override
    @Transactional(readOnly = true)
    public List<BusinessScope> getAll() throws SugarTechnicalException {
        LOGGER.debug("Getting all business scopes");
        List<BusinessScope> scopes = businessscopeDAO.getAll();
        LOGGER.info("{} business scopes have been fetched", scopes.size());
        fireEvents(scopes, READ);
        return scopes;
    }

    @CacheEvict(value = { "BusinessScope", "Drools" }, allEntries = true)
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public void update(List<BusinessScope> scopes) throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.debug("Trying to update business scope " + scopes);
        validator.checkUpdateValidity(scopes);
        for (BusinessScope scope : scopes) {
            scope.setUpdateDate(new Date());
            overWriteCreationDate(scope);
        }

        businessscopeDAO.update(scopes);
        LOGGER.info("{} business scopes have been updated", scopes.size());
        fireEvents(scopes, UPDATE);
    }

    private void overWriteCreationDate(BusinessScope scope) throws SugarTechnicalException, SugarFunctionalException {

        List<BusinessScope> fetchedScopes = getBySymbolicName(Lists.newArrayList(scope.getSymbolicName()));
        BusinessScope fetched = fetchedScopes.get(0);
        scope.setCreationDate(fetched.getCreationDate());

    }

    @Cacheable("BusinessScope")
    @Override
    @Transactional(readOnly = true)
    public List<BusinessScope> getBySymbolicName(List<String> symbolicNames)
            throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.debug("Trying to get business scopes with symbolic names" + symbolicNames);
        for (String symbolicName : symbolicNames) {
            validator.checkUserIsAllowedAndSetCurrentScope(symbolicName);
        }
        List<BusinessScope> scopes = businessscopeDAO.getBySymbolicName(symbolicNames);
        LOGGER.debug("{} business scopes have been fetched", scopes.size());
        fireEvents(scopes, READ);
        return scopes;
    }

    private void fireEvents(List<BusinessScope> scopes, Action action) {
        for (BusinessScope scope : scopes) {
            eventBus.post(
                    new Event(scope.getSymbolicName(), BUSINESS_SCOPE, action, scope, scope.getBusinessScopeId()));
        }
    }

}
