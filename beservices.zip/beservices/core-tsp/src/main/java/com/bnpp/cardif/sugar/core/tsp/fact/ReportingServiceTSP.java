package com.bnpp.cardif.sugar.core.tsp.fact;

import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00206;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00315;
import static com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode.T00906;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.activation.DataHandler;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpp.cardif.sugar.core.api.basket.BasketService;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassService;
import com.bnpp.cardif.sugar.core.api.fact.ReportingService;
import com.bnpp.cardif.sugar.core.api.fact.ReportingValidator;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassService;
import com.bnpp.cardif.sugar.core.tsp.event.Event;
import com.bnpp.cardif.sugar.core.tsp.event.EventSubscriber;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.dao.api.fact.FactDAO;
import com.bnpp.cardif.sugar.dao.api.reporting.ReportingDAO;
import com.bnpp.cardif.sugar.domain.documentfile.InputStreamDataSource;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpp.cardif.sugar.domain.fact.Fact;
import com.bnpp.cardif.sugar.domain.fact.ObjectType;
import com.bnpp.cardif.sugar.security.AuthenticatedUser;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.BasketRatio;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.DocumentStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.EnvelopeFlows;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.FolderStock;
import com.bnpparibas.assurance.ea.internal.schema.mco.reporting.v1.Summary;
import com.google.common.collect.Lists;

/**
 * 
 * Default implementation of {@link TrackingService} based on event notification
 * mechanism. This service should handle all {@link Event} via
 * {@link SugarEventBus} to reports all facts
 * 
 * @see TrackingService
 * @author Christopher Laszczuk
 * 
 */
public class ReportingServiceTSP extends EventSubscriber implements ReportingService {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(ReportingServiceTSP.class);

    private final SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd");

    private String csvSeparator = ",";

    @Autowired
    private SugarEventBus eventBus;

    @Autowired
    private ReportingValidator validator;

    @Autowired
    private FactDAO factDAO;

    @Autowired
    private ReportingDAO reportingDAO;

    @Autowired
    private BasketService basketService;

    @Autowired
    private DocumentClassService documentClassService;

    @Autowired
    private FolderClassService folderClassService;

    public ReportingServiceTSP() {
        LOGGER.debug("Reporting service has been instantiated !");
    }

    public void init() {
        eventBus.register(this);
    }

    @Override
    protected void onEvent(Event event) throws SugarTechnicalException, SugarFunctionalException {
        LOGGER.debug("An event has been received: {}", event);
        report(event.getBusinessScope(), event.getObjectType(), event.getAction(), event.getId());
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public void report(String scope, ObjectType type, Action action, Object object)
            throws SugarTechnicalException, SugarFunctionalException {
        Object retrievedUser = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (retrievedUser instanceof AuthenticatedUser) {
            AuthenticatedUser user = (AuthenticatedUser) retrievedUser;
            Fact fact = buildFact(type, action, object, user.getUsername());
            factDAO.store(scope, fact);
            LOGGER.debug("A fact has been reported for scope={}, objectType={} and action={}", scope, type, action);
        }
        else {
            throw ExceptionBuilder.createFunctionalException(F00315, retrievedUser);
        }
    }

    private Fact buildFact(ObjectType type, Action action, Object object, String userName)
            throws SugarFunctionalException {
        return new Fact(type, action, object, userName);
    }

    @Override
    @Transactional(readOnly = true)
    public List<EnvelopeFlows> getEnvelopeFlowsByPeriod(String scope, Date startingDate, Date endingDate)
            throws SugarTechnicalException, SugarFunctionalException {
        validator.validateScopeAndDates(scope, startingDate, endingDate);
        startingDate.setTime(startingDate.getTime() - 24 * 3600000);
        endingDate.setTime(endingDate.getTime() + 24 * 3600000);

        String startDate = dateFormater.format(startingDate);
        String endDate = dateFormater.format(endingDate);
        return reportingDAO.getEnvelopesAndDocumentFlow(scope, startDate, endDate);
    }

    @Override
    @Transactional(readOnly = true)
    public List<BasketRatio> getBasketRatio(String scope, Date startDate, Date endingDate)
            throws SugarTechnicalException, SugarFunctionalException {

        validator.validateScopeAndDates(scope, startDate, endingDate);
        startDate.setTime(startDate.getTime() - 24 * 3600000);
        endingDate.setTime(endingDate.getTime() + 24 * 3600000);

        String start = dateFormater.format(startDate);

        String endDate = dateFormater.format(endingDate);

        return reportingDAO.getBasketClosedRatios(scope, start, endDate);
    }

    @Override
    @Transactional(readOnly = true)
    public List<DocumentStock> getDocumentStockIndicators(String scope, Date startingDate, Date endingDate)
            throws SugarTechnicalException, SugarFunctionalException {
        validator.validateScopeAndDates(scope, startingDate, endingDate);
        startingDate.setTime(startingDate.getTime() - 24 * 3600000);
        endingDate.setTime(endingDate.getTime() + 24 * 3600000);
        return reportingDAO.getDocumentStockIndicators(scope, dateFormater.format(startingDate),
                dateFormater.format(endingDate));
    }

    @Override
    @Transactional(readOnly = true)
    public List<FolderStock> getFolderStockIndicators(String scope, Date startingDate, Date endingDate)
            throws SugarTechnicalException, SugarFunctionalException {
        validator.validateScopeAndDates(scope, startingDate, endingDate);
        startingDate.setTime(startingDate.getTime() - 24 * 3600000);
        endingDate.setTime(endingDate.getTime() + 24 * 3600000);
        return reportingDAO.getFolderStockIndicators(scope, dateFormater.format(startingDate),
                dateFormater.format(endingDate));
    }

    @Override
    @Transactional(readOnly = true)
    public DocumentFile getEnvelopeFlowsReport(String scope, Date startingDate, Date endingDate)
            throws SugarTechnicalException, SugarFunctionalException {
        try {
            LOGGER.info("getting envelope flow report" + startingDate + "end  " + endingDate);
            String documentFileName = buildReportFileName(scope, startingDate, endingDate, "envelope");
            LOGGER.info("Getting baskets report for scope={}", scope);
            validator.validateScopeAndDates(scope, startingDate, endingDate);
            startingDate.setTime(startingDate.getTime() - 24 * 3600000);
            endingDate.setTime(endingDate.getTime() + 24 * 3600000);

            List<EnvelopeFlows> envelopeFlows = reportingDAO.getEnvelopesAndDocumentFlow(scope,
                    dateFormater.format(startingDate), dateFormater.format(endingDate));

            StringWriter writer = new StringWriter();
            List<String> columns = Lists.newArrayList("symbolic_name", "direction_code", "created_env",
                    "created_document", "created_file");

            generateCSV(writer, columns);

            List<DocumentClass> classes = documentClassService.search(scope, Category.ENVELOPE, false);

            for (EnvelopeFlows flow : envelopeFlows) {
                List<Object> values = new ArrayList<Object>();
                values.add(findClassByIdValue(scope, classes, flow.getClassId()).getLongLabel());
                values.add(flow.getDirectionCode());
                values.add(flow.getNumberOfEnvelopes());
                values.add(flow.getNumberOfDocuments());
                values.add(Float.valueOf((float) (flow.getSizeOfDocuments() / 1000000.0)));
                generateCSV(writer, values);
            }

            DocumentFile report = new DocumentFile();

            report.setScope(scope);
            report.setCreateDate(new Date());

            report.setName(documentFileName);
            report.setContent(new DataHandler(new InputStreamDataSource(IOUtils.toInputStream(writer.toString()))));

            return report;
        }
        catch (IOException e) {
            throw ExceptionBuilder.createTechnicalException(T00906, scope, startingDate, endingDate, e);

        }
    }

    @Override
    @Transactional(readOnly = true)
    public DocumentFile getBasketRatioReport(String scope, Date startingDate, Date endingDate)
            throws SugarTechnicalException, SugarFunctionalException {
        try {
            LOGGER.info("Getting baskets report for scope={}", scope);
            String documentFileName = buildReportFileName(scope, startingDate, endingDate, "basket");
            validator.validateScopeAndDates(scope, startingDate, endingDate);
            startingDate.setTime(startingDate.getTime() - 24 * 3600000);
            endingDate.setTime(endingDate.getTime() + 24 * 3600000);
            List<BasketRatio> basketClosedRatios = reportingDAO.getBasketClosedRatios(scope,
                    dateFormater.format(startingDate), dateFormater.format(endingDate));

            StringWriter writer = new StringWriter();
            List<String> columns = Lists.newArrayList("symbolic_name", "created_tasks_nbr", "closed_tasks_nbr");

            generateCSV(writer, columns);

            for (BasketRatio ratio : basketClosedRatios) {
                List<Object> values = new ArrayList<Object>();
                values.add(basketService.get(Lists.newArrayList(ratio.getBasketId()), scope).get(0).getSymbolicName());
                values.add(ratio.getNumberOfOpened());
                values.add(ratio.getNumberOfClosed());
                generateCSV(writer, values);
            }

            DocumentFile report = new DocumentFile();

            report.setScope(scope);
            report.setCreateDate(new Date());

            report.setName(documentFileName);
            report.setContent(new DataHandler(new InputStreamDataSource(IOUtils.toInputStream(writer.toString()))));

            return report;
        }
        catch (IOException e) {
            throw ExceptionBuilder.createTechnicalException(T00906, scope, startingDate, endingDate, e);

        }

    }

    @Override
    @Transactional(readOnly = true)
    public DocumentFile getDocumentStockReport(String scope, Date startingDate, Date endingDate)
            throws SugarTechnicalException, SugarFunctionalException {
        try {
            LOGGER.info("Getting documents report for scope={}", scope);
            String documentFileName = buildReportFileName(scope, startingDate, endingDate, "document");
            validator.validateScopeAndDates(scope, startingDate, endingDate);
            startingDate.setTime(startingDate.getTime() - 24 * 3600000);
            endingDate.setTime(endingDate.getTime() + 24 * 3600000);

            List<DocumentStock> documentStocks = reportingDAO.getDocumentStockIndicators(scope,
                    dateFormater.format(startingDate), dateFormater.format(endingDate));

            StringWriter writer = new StringWriter();
            List<String> columns = Lists.newArrayList("symbolic_name", "created_document", "file_size");

            generateCSV(writer, columns);

            List<DocumentClass> classes = documentClassService.search(scope, Category.DOCUMENT, false);

            for (DocumentStock stock : documentStocks) {
                List<Object> values = new ArrayList<Object>();
                values.add(findClassByIdValue(scope, classes, stock.getClassId()).getLongLabel());
                values.add(stock.getNumberOfDocuments());
                values.add(Float.valueOf((float) (stock.getSizeOfFiles() / 1000000.0)));
                generateCSV(writer, values);
            }

            DocumentFile report = new DocumentFile();

            report.setScope(scope);
            report.setCreateDate(new Date());

            report.setName(documentFileName);
            report.setContent(new DataHandler(new InputStreamDataSource(IOUtils.toInputStream(writer.toString()))));

            return report;
        }
        catch (IOException e) {
            throw ExceptionBuilder.createTechnicalException(T00906, scope, startingDate, endingDate, e);

        }
    }

    private DocumentClass findClassByIdValue(String scope, List<DocumentClass> classes, ClassId classId)
            throws SugarTechnicalException, SugarFunctionalException {
        for (DocumentClass clazz : classes) {
            if (clazz.getClassId().getValue().equals(classId.getValue())) {
                return clazz;
            }
        }
        throw ExceptionBuilder.createFunctionalException(F00206,
                new ClassId(classId.getValue(), classId.getIssuer(), -1));
    }

    @Override
    @Transactional(readOnly = true)
    public DocumentFile getFolderStockReport(String scope, Date startingDate, Date endingDate)
            throws SugarTechnicalException, SugarFunctionalException {
        try {
            LOGGER.info("Getting folders report for scope={}", scope);

            String documentFileName = buildReportFileName(scope, startingDate, endingDate, "folder");
            validator.validateScopeAndDates(scope, startingDate, endingDate);
            startingDate.setTime(startingDate.getTime() - 24 * 3600000);
            endingDate.setTime(endingDate.getTime() + 24 * 3600000);
            List<FolderStock> folderStocks = reportingDAO.getFolderStockIndicators(scope,
                    dateFormater.format(startingDate), dateFormater.format(endingDate));

            StringWriter writer = new StringWriter();
            List<String> columns = Lists.newArrayList("symbolic_name", "created_folders");

            generateCSV(writer, columns);

            List<FolderClass> classes = folderClassService.getAll(scope, false);

            for (FolderStock stock : folderStocks) {
                List<Object> values = new ArrayList<Object>();
                values.add(findFolderClassByIdValue(scope, classes, stock.getClassId()).getLongLabel());
                values.add(stock.getNumberOfFolders());
                generateCSV(writer, values);
            }

            DocumentFile report = new DocumentFile();

            report.setScope(scope);
            report.setCreateDate(new Date());

            report.setName(documentFileName);
            report.setContent(new DataHandler(new InputStreamDataSource(IOUtils.toInputStream(writer.toString()))));

            return report;
        }
        catch (IOException e) {
            throw ExceptionBuilder.createTechnicalException(T00906, scope, startingDate, endingDate, e);

        }
    }

    private FolderClass findFolderClassByIdValue(String scope, List<FolderClass> classes, ClassId classId)
            throws SugarTechnicalException, SugarFunctionalException {
        for (FolderClass clazz : classes) {
            if (clazz.getClassId().getValue().equals(classId.getValue())) {
                return clazz;
            }
        }
        throw ExceptionBuilder.createFunctionalException(F00206,
                new ClassId(classId.getValue(), classId.getIssuer(), -1));
    }

    @Override
    @Transactional(readOnly = true)
    public Summary getReportingSummary(String scope) throws SugarTechnicalException {
        return reportingDAO.getReportingSummary(scope);
    }

    private static void generateCSV(Writer writer, List<? extends Object> values) throws IOException {
        for (Object value : values) {
            String adaptedValue = value != null ? value.toString() : "";
            writer.append(adaptedValue);
            if (values.indexOf(value) < (values.size() - 1)) {
                writer.append(',');
            }
        }
        writer.append('\n');
    }

    public String getCsvSeparator() {
        return csvSeparator;
    }

    public void setCsvSeparator(String csvSeparator) {
        this.csvSeparator = csvSeparator;
    }

    private String buildReportFileName(String scope, Date startingDate, Date endingDate, String reportType) {
        String documentFileName = "sugar-" + scope + "-report-" + reportType + "-";
        if (startingDate.getDate() != endingDate.getDate() || startingDate.getMonth() != endingDate.getMonth()
                || startingDate.getYear() != endingDate.getYear()) {
            documentFileName += dateFormater.format(startingDate) + "_";
        }
        documentFileName += dateFormater.format(endingDate) + ".csv";
        return documentFileName;
    }

}
