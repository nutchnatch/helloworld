package com.bnpp.cardif.sugar.core.tsp.businessscope;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeService;
import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.tsp.util.ValidatorHelper;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.security.AuthenticatedUser;
import com.bnpp.cardif.sugar.security.SecurityHelper;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.SugarRoles;
import com.google.common.collect.Lists;

@Component
public class BusinessScopeValidatorTSP implements BusinessScopeValidator {
    
    @Autowired
    private BusinessScopeService businessScopeService;
    
    @Autowired
    private SecurityHelper securityHelper;

    @Override
    public void checkCreationValidity(List<BusinessScope> scopes)
            throws SugarFunctionalException, SugarTechnicalException {
        if (scopes.isEmpty()) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00605);
        }
        checkUserIsAdmin();
        List<String> symbolicNames = checkAndComputeSymbolicNames(scopes);

        List<BusinessScope> fetched = businessScopeService.getBySymbolicName(symbolicNames);
        List<String> fetchedNames = new ArrayList<>();
        for (BusinessScope scope : fetched) {
            fetchedNames.add(scope.getSymbolicName());
        }
        if (!fetchedNames.isEmpty()) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00601, fetchedNames);
        }
    }

    @Override
    public void checkUserIsAllowedAndSetCurrentScope(String scope) throws SugarFunctionalException {
        if (!securityHelper.isUserAllowedInScope(scope)) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00316, scope);
        }
        setCurrentBusinessScope(scope);
    }

    public void checkUserIsAdmin() throws SugarFunctionalException {
        if (!securityHelper.isAdmin()) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00317, SugarRoles.SUGAR_ADMIN);
        }
    }

    @Override
    public void checkExistence(String scope) throws SugarTechnicalException, SugarFunctionalException {
        checkExistence(Lists.newArrayList(scope));
    }

    @Override
    public void checkExistence(List<String> scopes) throws SugarTechnicalException, SugarFunctionalException {
        List<String> unduplicatedScopes = ValidatorHelper.removeDuplicates(scopes);
        List<BusinessScope> fetched = businessScopeService.getBySymbolicName(unduplicatedScopes);
        if (fetched.isEmpty() || fetched.size() != unduplicatedScopes.size()) {
            unduplicatedScopes.removeAll(ValidatorHelper.getSubListOfSymbolicName(fetched));
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00602, unduplicatedScopes);
        }
    }

    private void setCurrentBusinessScope(String scope) {
        Object retrievedUser = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (retrievedUser instanceof AuthenticatedUser) {
            AuthenticatedUser user = (AuthenticatedUser) retrievedUser;
            user.setCurrentBusinessScope(scope);
        }
    }

    private List<String> checkAndComputeSymbolicNames(List<BusinessScope> scopes) throws SugarFunctionalException {
        List<String> symbolicNames = new ArrayList<>();
        for (BusinessScope scope : scopes) {
            String symbolicName = scope.getSymbolicName();
            if (symbolicName == null || symbolicName.trim().isEmpty()) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00603);
            }
            if (!symbolicNames.contains(symbolicName)) {
                symbolicNames.add(symbolicName);
            }
            else {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00604, symbolicName);
            }
        }
        return symbolicNames;
    }

    @Override
    public void checkUpdateValidity(List<BusinessScope> scopes)
            throws SugarFunctionalException, SugarTechnicalException {
        checkExistence(ValidatorHelper.getSubListOfSymbolicName(scopes));
        checkIdNotChanged(scopes);
    }

    private void checkIdNotChanged(List<BusinessScope> scopes)
            throws SugarTechnicalException, SugarFunctionalException {
        for (BusinessScope scope : scopes) {
            BusinessScope existingScope = businessScopeService
                    .getBySymbolicName(Lists.newArrayList(scope.getSymbolicName())).get(0);
            if (!existingScope.getBusinessScopeId().equals(scope.getBusinessScopeId())) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00606, scope.getSymbolicName());
            }

        }

    }
}
