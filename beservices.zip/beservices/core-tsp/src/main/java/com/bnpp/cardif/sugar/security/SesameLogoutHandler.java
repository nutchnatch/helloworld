package com.bnpp.cardif.sugar.security;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutHandler;

import com.bnpp.cardif.sesame.security.SesameWebServiceFactory;
import com.bnpp.cardif.sugar.security.spring.SugarURLRedirectStrategy;
import com.bnppa.sesame.services.standard.proxy.AuthenticationServicesWSP;
import com.bnppa.sesame.services.standard.proxy.InvalidTokenException;
import com.bnppa.sesame.services.standard.proxy.TechnicalException;

public class SesameLogoutHandler extends SugarURLRedirectStrategy implements LogoutHandler {
    private static Logger LOGGER = LoggerFactory.getLogger(SesameLogoutHandler.class.getName());

    @Autowired
    private SesameWebServiceFactory sesameWebServiceFactory;

    @Override
    public void logout(HttpServletRequest request, HttpServletResponse response, Authentication authentication) {
        if (authentication != null) {
            AuthenticatedUser authenticatedUser = (AuthenticatedUser) authentication.getPrincipal();
            invalidateSesameToken(authenticatedUser);
        }

        redirect(request, response);
    }

    private void invalidateSesameToken(AuthenticatedUser authenticatedUser) {
        try {
            if (authenticatedUser.getToken() != null) {
                AuthenticationServicesWSP authenticationServicesWSP = sesameWebServiceFactory
                        .getAuthenticationServicesWSP();
                authenticationServicesWSP.logout(authenticatedUser.getToken());
                LOGGER.debug("The user " + authenticatedUser + "has been logged out from Sesame");
            }
        }
        catch (InvalidTokenException e) {
            LOGGER.error("The user {} cannot be logged out from Sesame because his token is invalid", authenticatedUser,
                    e);
        }
        catch (TechnicalException e) {
            LOGGER.error("The user {} cannot be logged out", authenticatedUser, e);
        }
    }

    private void redirect(HttpServletRequest request, HttpServletResponse response) {
        String url = buildLogoutURL(request);
        try {
            LOGGER.info("On logout, redirecting to url={}", url);
            response.sendRedirect(url);
        }
        catch (IOException e) {
            LOGGER.error("Cannot redirect to destination page: {} on logout", url);
        }
    }
}
