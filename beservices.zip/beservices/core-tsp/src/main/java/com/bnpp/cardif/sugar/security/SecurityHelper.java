package com.bnpp.cardif.sugar.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.SugarRoles;

@Component
public class SecurityHelper {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(SecurityHelper.class);

    @Value("${authentication-provider.is-security-enabled}")
    private boolean isSecurityEnabled;

    public boolean isUserAllowedInScope(String scope) {

        if (!isSecurityEnabled) {
            LOGGER.debug(
                    "Security is not enabled not checking if user is allowed in given business scope. Assuming true");
            return true;
        }
        AuthenticatedUser springAuthenticatedUser = (AuthenticatedUser) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        if (springAuthenticatedUser.getBusinessScopes().contains(scope)) {
            return true;
        }
        return false;
    }

    public static String getUserToken() {
        AuthenticatedUser springAuthenticatedUser = (AuthenticatedUser) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        return springAuthenticatedUser.getToken();
    }

    public boolean isAdmin() {
        if (!isSecurityEnabled) {
            LOGGER.debug("Security is not enabled not checking if user is admin. Assuming true");
            return true;
        }
        AuthenticatedUser springAuthenticatedUser = (AuthenticatedUser) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        for (GrantedAuthority authority : springAuthenticatedUser.getAuthorities()) {
            if ((SugarRoles.SUGAR_ADMIN.name().equals(authority.getAuthority()))) {
                return true;
            }
        }
        return false;
    }

    public static String getCurrentUserName() {
        AuthenticatedUser springAuthenticatedUser = (AuthenticatedUser) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal();
        return springAuthenticatedUser.getUsername();
    }

    public boolean isSecurityEnabled() {
        return isSecurityEnabled;
    }

    public void setIsSecurityEnabled(boolean aisSecurityEnabled) {
        this.isSecurityEnabled = aisSecurityEnabled;
    }
}
