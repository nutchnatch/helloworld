package com.bnpp.cardif.sugar.core.tsp.documentclass;

import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00314;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bnpp.cardif.sugar.core.api.acl.AclService;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;

public class AbstractClassServiceTSP {
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractClassServiceTSP.class);

    @Autowired
    private AclService aclService;

    protected void reportACLsOnNewVersionAndIncrementVersion(String scope, ClassId id)
            throws SugarTechnicalException, SugarFunctionalException {
        AclId classId = aclService.getByClassId(scope, id, false).getAclId();
        AclId instanceId = aclService.getByClassId(scope, id, true).getAclId();
        id.setVersId(id.getVersId() + 1);
        aclService.assignToClass(scope, classId, id, false);
        aclService.assignToClass(scope, instanceId, id, true);
    }

    protected void checkClassesHaveInstanceACL(List<ClassId> ids, String scope) throws SugarFunctionalException {
        LOGGER.debug("Checking if an instance ACL is assigned to supplied document classes: {} for scope={}", ids,
                scope);
        for (ClassId classId : ids) {
            try {
                aclService.getByClassId(scope, classId, true);
            }
            catch (SugarTechnicalException e) {
                throw ExceptionBuilder.createFunctionalException(F00314, ids, scope, e);
            }
        }
    }
}