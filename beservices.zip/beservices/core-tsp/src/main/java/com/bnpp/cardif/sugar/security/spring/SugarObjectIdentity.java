package com.bnpp.cardif.sugar.security.spring;

import java.io.Serializable;

import org.springframework.security.acls.model.ObjectIdentity;
import org.springframework.util.Assert;

import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;

public class SugarObjectIdentity implements ObjectIdentity {
    /**
     * 
     */
    private static final long serialVersionUID = 5824124362505377980L;

    public static final String TYPE = "SugarACL";

    private AclId identifier;

    public SugarObjectIdentity(AclId identifier) {
        Assert.notNull(identifier, "identifier required");
        this.identifier = identifier;
    }

    /**
     * Returns the unique identifier of the ACL object
     * 
     * @return
     */
    @Override
    public Serializable getIdentifier() {
        return identifier;
    }

    @Override
    public String getType() {
        return TYPE;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (!(o instanceof SugarObjectIdentity))
            return false;

        SugarObjectIdentity that = (SugarObjectIdentity) o;

        if (identifier != null ? !identifier.equals(that.identifier) : that.identifier != null)
            return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = identifier != null ? identifier.hashCode() : 0;
        return result;
    }

    @Override
    public String toString() {
        return "SugarObjectIdentity(" + identifier + ")";
    }
}
