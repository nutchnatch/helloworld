package com.bnpp.cardif.sugar.security;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.bnpp.cardif.sesame.security.SesameWebServiceFactory;
import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeService;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnppa.sesame.services.common.model.Joining;
import com.bnppa.sesame.services.standard.proxy.ArrayOfTns3NillableJoining;
import com.bnppa.sesame.services.standard.proxy.AuthorizationServicesWSP;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;

/**
 * According {@link SecurityContextHolder} which provides the current
 * authenticated user and the {@link HttpServletRequest} which provides the
 * business scope, this filter checks if the current user is allowed to access
 * to the requested business scope.
 * 
 * @author Florian Deruette
 * 
 */
public class SesameBusinessScopeFilter extends UsernamePasswordAuthenticationFilter {

    private static final Logger MYLOGGER = LoggerFactory.getLogger(SesameBusinessScopeFilter.class.getName());

    public static final String SCOPE_PARAMETER = "scope";

    private String appDomain = "ICONNECT";

    private String joiningType = "SCOPE";

    @Autowired
    private BusinessScopeService businessScopeService;

    @Autowired
    private SesameWebServiceFactory sesameWebServiceFactory;
    
    @Autowired
    private SecurityHelper securityHelper;

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
            throws AuthenticationException {
        String scope = request.getParameter(SCOPE_PARAMETER);

        MYLOGGER.debug("Attempting to finalize authentication checking the business scope according to query string: "
                + request.getQueryString());

        checkBusinessScope(scope);

        Authentication authentication = super.attemptAuthentication(request, response);
        AuthenticatedUser currentUser = (AuthenticatedUser) authentication.getPrincipal();
        checkScopeExistence(scope, authentication);
        if (securityHelper.isSecurityEnabled()) {
            ArrayOfTns3NillableJoining joinings = fetchUserJoinings(currentUser);
            validateBusinessScopeJoining(currentUser, joinings, scope);
        }

        currentUser.getBusinessScopes().add(scope);
        currentUser.setCurrentBusinessScope(scope);

        return authentication;

    }

    private void checkScopeExistence(String scope, Authentication authentication) {
        SecurityContextHolder.getContext().setAuthentication(authentication);
        try {
            MYLOGGER.debug("Trying to fetch scope {}", scope);

            List<BusinessScope> fetchedScopes = businessScopeService.getAll();
            boolean scopeExists = false;
            for (BusinessScope fetchedScope : fetchedScopes) {
                if (scope.equals(fetchedScope.getSymbolicName())) {
                    scopeExists = true;
                    break;
                }
            }
            if (!scopeExists) {
                MYLOGGER.debug("No business scope was found for {}", scope);
                throw new BadCredentialsException("Business scope " + scope + " does not exist");
            }
        }
        catch (SugarTechnicalException e) {
            MYLOGGER.error("Security : failed when trying to fetch scope {}", scope);
            throw new AuthenticationServiceException(" Error when trying to find business scope " + scope + ": " + e);
        }
    }

    private static void checkBusinessScope(String scope) {
        if (scope == null || scope.isEmpty()) {
            MYLOGGER.error("The supplied business scope is invalid: {}. Cannot allow current user.", scope);
            throw new BadCredentialsException("The supplied business scope is null");
        }
    }

    private ArrayOfTns3NillableJoining fetchUserJoinings(AuthenticatedUser currentUser) {
        try {
            AuthorizationServicesWSP authorizationServicesWSP = sesameWebServiceFactory.getAuthorizationServicesWSP();
            return authorizationServicesWSP.getJoinings(currentUser.getToken(), getAppDomain());
        }
        catch (Exception e) {
            String errorMessage = "Cannot fetch joinging of current user " + currentUser.getUsername();
            MYLOGGER.error(errorMessage, e);
            throw new AuthenticationServiceException(errorMessage, e);
        }
    }

    protected void validateBusinessScopeJoining(AuthenticatedUser authenticatedUser,
            ArrayOfTns3NillableJoining joinings, String scope) {
        MYLOGGER.debug("--SCOPE {}", scope);
        MYLOGGER.debug("getJoiningType {}", getJoiningType());
        MYLOGGER.debug("joinings.getJoining().size {}", joinings.getJoining().size());
        for (Joining joining : joinings.getJoining()) {

            MYLOGGER.debug("joining" + joining.getJoiningType() + joining.getInterv());
            if (joining.getJoiningType().equals(getJoiningType()) && joining.getInterv().equals(scope)) {
                return;
            }
        }
        MYLOGGER.error("The user {} is not allowed for the business scope: {}", authenticatedUser.getUsername(), scope);
        throw new InsufficientAuthenticationException("You are not allowed for the buiness scope: " + scope);
    }

    public String getAppDomain() {
        return appDomain;
    }

    public void setAppDomain(String appDomain) {
        this.appDomain = appDomain;
    }

    public String getJoiningType() {
        return joiningType;
    }

    public void setJoiningType(String joiningType) {
        this.joiningType = joiningType;
    }
}
