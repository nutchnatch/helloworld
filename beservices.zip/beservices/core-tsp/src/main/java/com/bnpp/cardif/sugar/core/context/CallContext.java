package com.bnpp.cardif.sugar.core.context;

/**
 * Created by b48489 on 17-08-2017.
 */
public interface CallContext {
}
