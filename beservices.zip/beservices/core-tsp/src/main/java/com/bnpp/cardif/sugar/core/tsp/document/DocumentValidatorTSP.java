package com.bnpp.cardif.sugar.core.tsp.document;

import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00005;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Pattern;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.document.DocumentService;
import com.bnpp.cardif.sugar.core.api.document.DocumentValidator;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassService;
import com.bnpp.cardif.sugar.core.api.documentclass.DocumentClassValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagClassValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagclassService;
import com.bnpp.cardif.sugar.core.tsp.util.ValidatorHelper;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tags;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ValdtyCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.MCODocumentClassType.AllowedChildren;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Item;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOAllowedValue;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOTagReference;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagValueType;
import com.google.common.base.Objects;
import com.google.common.collect.Lists;

@Component
public class DocumentValidatorTSP implements DocumentValidator {

    @Autowired
    private BusinessScopeValidator businessScopeValidator;

    @Autowired
    private DocumentClassValidator documentClassValidator;

    @Autowired
    private TagClassValidator tagClassValidator;

    @Autowired
    private DocumentClassService documentClassService;

    @Autowired
    private TagclassService tagClassService;

    @Autowired
    private DocumentService documentService;

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(DocumentValidatorTSP.class);

    @Override
    public void checkStoreValidity(List<Document> documents) throws SugarFunctionalException, SugarTechnicalException {
        if (documents.isEmpty()) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00001);
        }

        String scope = documents.get(0).getScope();
        checkScope(scope, documents);
        List<Document> documentsToCheck = new ArrayList<>();
        for (Document document : documents) {
            if (document.getData() != null) {
                if (!ValdtyCode.UNDER_CONSTRUCTION.equals(document.getData().getValidityCode())) {
                    documentsToCheck.add(document);
                }

            }
            else {
                throw ExceptionBuilder.createFunctionalException(F00005, document.getId());

            }
        }
        if (!documentsToCheck.isEmpty()) {

            // recursive but cached
            checkDocumentClassesAndTags(scope, documentsToCheck);
            // uncacheble
            checkHasFirstLevelParent(scope, documentsToCheck);

            // do the gets as late as we can so if other checks fail we dont
            // need to do heavy requests
            Map<Document, List<Document>> sortedChilds = mapChildren(scope, documents);
            // optimized
            checkChildrenClasses(scope, sortedChilds);
            // optimized
            checkFileData(documentsToCheck, sortedChilds);
            checkClassIsActive(scope, documentsToCheck);

        }
    }

    @Override
    public void checkUpdateValidity(List<Document> documents, Map<Id, Document> docIdToOldDoc)
            throws SugarTechnicalException, SugarFunctionalException {
        if (documents.isEmpty()) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00001);
        }

        String scope = documents.get(0).getScope();
        checkScope(scope, documents);
        List<Document> docToCheck = new ArrayList<>();
        for (Document doc : documents) {
            if (!ValdtyCode.UNDER_CONSTRUCTION.equals(doc.getData().getValidityCode())) {
                docToCheck.add(doc);
            }
        }
        checkExistenceAndClassChanging(scope, docToCheck, docIdToOldDoc);

        checkChildIsNotParent(docToCheck);
        // recursive but cached
        checkDocumentClassesAndTags(scope, docToCheck);
        // uncacheble
        checkHasFirstLevelParent(scope, docToCheck);

        // do the gets as late as we can so if other checks fail we dont
        // need to do heavy requests
        Map<Document, List<Document>> sortedChilds = mapChildren(scope, docToCheck);
        // optimized
        checkChildrenClasses(scope, sortedChilds);
        // optimized
        checkFileData(docToCheck, sortedChilds);

        checkNoChildIsRemoved(docToCheck, docIdToOldDoc);
    }

    private void checkHasFirstLevelParent(String scope, List<Document> documents)
            throws SugarTechnicalException, SugarFunctionalException {
        // get parent ids if they exist
        List<Id> parentIdsToFetch = new ArrayList<>();
        for (Document document : documents) {
            if (document.isSetParentId() && document.getParentId().isSetId()) {
                parentIdsToFetch.add(document.getParentId().getId());
            }
        }

        /* Fetching all parents */
        Map<Id, Document> docIdToParent = new HashMap<>();
        if (!parentIdsToFetch.isEmpty()) {
            List<Document> parents = documentService.get(scope, parentIdsToFetch, false, false);
            for (Document parent : parents) {
                docIdToParent.put(parent.getId(), parent);
            }
        }

        for (Document document : documents) {
            DocumentClass currentClass = documentClassService
                    .get(scope, Lists.newArrayList(document.getData().getClassId())).get(0);
            if (!currentClass.isFirstLevel()) {
                if (!document.isSetParentId()) {
                    throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00010,
                            document.getData().getName());
                }
                else {
                    Document parent = docIdToParent.get(document.getParentId().getId());

                    if (parent == null) {
                        throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00036, document.getId(),
                                document.getParentId());
                    }
                    if (ValdtyCode.UNDER_CONSTRUCTION.equals(parent.getData().getValidityCode())) {
                        return;
                    }

                    DocumentClass parentClass = documentClassService
                            .get(scope, Lists.newArrayList(parent.getData().getClassId())).get(0);

                    List<String> allowedIds = extractAllowedIds(parentClass);
                    checkChildClass(parentClass, currentClass, allowedIds);
                    checkHasFirstLevelParent(scope, Lists.newArrayList(parent));
                }
            }
            else {
                if (document.isSetParentId()) {
                    throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00017, document);
                }
            }

        }

    }

    private void checkChildrenClasses(String scope, Map<Document, List<Document>> sortedChildSet)
            throws SugarTechnicalException, SugarFunctionalException {

        for (Entry<Document, List<Document>> entryDoc : sortedChildSet.entrySet()) {
            Document document = entryDoc.getKey();
            List<DocumentClass> fetched = documentClassService.get(scope,
                    Lists.newArrayList(document.getData().getClassId()));
            DocumentClass currentClass = fetched.get(0);
            checkCategory(document, currentClass);
            checkChildrenClass(scope, currentClass, entryDoc.getValue());
        }

    }

    private void checkCategory(Document document, DocumentClass currentClass) throws SugarFunctionalException {
        if (document.getCategory() == null) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00015, document);
        }
        if (!document.getCategory().equals(currentClass.getCategory())) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00016, document,
                    document.getCategory(), currentClass.getLongLabel(), currentClass.getCategory());
        }

    }

    private void checkChildrenClass(String scope, DocumentClass currentClass, List<Document> children)
            throws SugarTechnicalException, SugarFunctionalException {

        if (children == null || children.isEmpty()) {
            return;
        }

        List<String> allowedDocumentIds = extractAllowedIds(currentClass);

        for (Document childDocument : children) {

            if (!childDocument.getData().isSetClassId()
                    && ValdtyCode.UNDER_CONSTRUCTION.equals(childDocument.getData().getValidityCode())) {
                return;
            }
            DocumentClass childClass = documentClassService
                    .get(scope, Lists.newArrayList(childDocument.getData().getClassId())).get(0);

            checkChildClass(currentClass, childClass, allowedDocumentIds);
        }
    }

    private List<String> extractAllowedIds(DocumentClass currentClass) {
        List<String> allowedDocumentIds = new ArrayList<>();
        if (!currentClass.getAllowedChildren().isEmpty()) {
            for (AllowedChildren child : currentClass.getAllowedChildren()) {
                allowedDocumentIds.add(child.getClassId().getValue());
            }
        }
        return allowedDocumentIds;
    }

    private void checkChildClass(DocumentClass parentClass, DocumentClass childClass, List<String> allowedIds)
            throws SugarTechnicalException, SugarFunctionalException {

        if (!allowedIds.isEmpty() && !allowedIds.contains(childClass.getClassId().getValue())) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00004, childClass.getLongLabel(),
                    parentClass.getLongLabel());
        }
        if (parentClass.isFirstLevel() && childClass.isFirstLevel()) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00003, parentClass.getLongLabel(),
                    childClass.getLongLabel());
        }
    }

    private void checkDocumentClassesAndTags(String scope, List<Document> documents)
            throws SugarFunctionalException, SugarTechnicalException {
        List<ClassId> classIdsToCheck = new ArrayList<>();
        Set<String> tagReferencesToCheck = new HashSet<>();
        for (Document document : documents) {
            if (document.getData() == null) {
                throw ExceptionBuilder.createFunctionalException(F00005, document.getId());
            }
            if (ValdtyCode.UNDER_CONSTRUCTION.equals(document.getData().getValidityCode())) {
                continue;
            }
            if (document.getData().getClassId() == null) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00008, document.getId());
            }

            if (Category.ENVELOPE.equals(document.getCategory())
                    && !getAllowedDirectionCodes().contains(document.getData().getDirectionCode())) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00037, document.getId());
            }
            classIdsToCheck.add(document.getData().getClassId());

            if (document.isSetTags()) {
                Tags tags = document.getTags();

                for (Tag tag : tags.getTag()) {
                    tagReferencesToCheck.add(tag.getName());
                }
            }
            if (document.isSetChildObject() && document.getChildObject().isSetDocument()) {
                checkDocumentClassesAndTags(scope, document.getChildObject().getDocument());
            }

        }

        if (!classIdsToCheck.isEmpty()) {
            documentClassValidator.checkExistence(classIdsToCheck, scope);
        }

        if (!tagReferencesToCheck.isEmpty()) {
            tagClassValidator.checkExistence(scope, Lists.newArrayList(tagReferencesToCheck));
        }

    }

    private void checkScope(String scope, List<Document> documents)
            throws SugarFunctionalException, SugarTechnicalException {
        if (scope == null) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00006);
        }

        for (Document document : documents) {
            if (document.getScope() == null) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00006);
            }

            if (!scope.equals(document.getScope())) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00007, scope,
                        document.getScope());
            }
        }
        businessScopeValidator.checkExistence(scope);

    }

    @Override
    public void computeValidityCode(Document document, List<Document> flatDocumentsToUpdate)
            throws SugarTechnicalException, SugarFunctionalException {
        computeValidityCode(document, null, flatDocumentsToUpdate);
    }

    @Override
    public void computeValidityCode(Document document, Document oldDoc, List<Document> flatDocumentsToUpdate)
            throws SugarTechnicalException, SugarFunctionalException {

        if (ValdtyCode.UNDER_CONSTRUCTION.equals(document.getData().getValidityCode())) {
            setChildrenUnderConstruction(document, flatDocumentsToUpdate);
            return;
        }

        boolean dataOk = checkDataValidity(document);
        boolean tagOk = checkTagsValidity(document);
        boolean childrenAreValid = childrenAreValid(document, flatDocumentsToUpdate);
        LOGGER.debug("Computing validity code for doc" + document.getId());
        if (dataOk && tagOk && childrenAreValid) {
            document.getData().setValidityCode(ValdtyCode.VALID);
        }
        // trying to invalidade previously ok document will result in an error
        else if (oldDoc == null && ValdtyCode.VALID.equals(document.getData().getValidityCode())) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00011, document.getId());
        }

        else {
            document.getData().setValidityCode(ValdtyCode.INVALID);
        }

        // trying to invalidate previously OK document will result in an error
        if (oldDoc != null && ValdtyCode.VALID.equals(oldDoc.getData().getValidityCode())
                && ValdtyCode.INVALID.equals(document.getData().getValidityCode())) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00011, document.getId());
        }
    }

    private void setChildrenUnderConstruction(Document document, List<Document> flatDocumentsToUpdate)
            throws SugarFunctionalException, SugarTechnicalException {
        List<Id> documentIds = ValidatorHelper.getSubListOfDocumentId(flatDocumentsToUpdate);
        List<Document> children = new ArrayList<>();
        if (document.isSetChildObject() && !document.getChildObject().getId().isEmpty()) {
            List<Id> childrenToFetch = Lists.newArrayList(document.getChildObject().getId());
            childrenToFetch.removeAll(documentIds);
            if (!childrenToFetch.isEmpty()) {
                children.addAll(documentService.get(document.getScope(), childrenToFetch, true, false));
            }
            for (Document documentToUpdate : flatDocumentsToUpdate) {
                if (document.getChildObject().getId().contains(documentToUpdate.getId())) {
                    children.add(documentToUpdate);
                }
            }
        }
        for (Document child : children) {
            LOGGER.debug("Setting validity code for child " + child.getId() + " of document" + document.getId()
                    + "to UNDER_CONSTRUCTION");
            child.getData().setValidityCode(ValdtyCode.UNDER_CONSTRUCTION);
            setChildrenUnderConstruction(child, flatDocumentsToUpdate);
        }
    }

    private boolean childrenAreValid(Document document, List<Document> flatDocumentsToUpdate)
            throws SugarFunctionalException, SugarTechnicalException {

        if (!Category.ENVELOPE.equals(document.getCategory())) {
            return true;
        }
        Map<Id, Document> idToOldDocument = new HashMap<>();

        // Get every Id document in flatDocumentsToUpdate documents + children
        List<Id> documentIds = ValidatorHelper.getSubListOfDocumentId(flatDocumentsToUpdate);
        List<Document> children = new ArrayList<>();
        if (document.isSetChildObject() && !document.getChildObject().getId().isEmpty()) {
            List<Id> childrenToFetch = Lists.newArrayList(document.getChildObject().getId());

            List<Document> oldChildren = documentService.get(document.getScope(), childrenToFetch, true, false);
            for (Document oldChild : oldChildren) {
                if (oldChild != null && oldChild.getId() != null) {
                    idToOldDocument.put(oldChild.getId(), oldChild);
                }
            }

            // Adding the children that are not in flatDocumentsToUpdate
            childrenToFetch.removeAll(documentIds);

            if (!childrenToFetch.isEmpty()) {
                for (Id childToFetch : childrenToFetch) {
                    Document oldChild = idToOldDocument.get(childToFetch);
                    if (oldChild != null) {
                        children.add(oldChild);
                    }
                }

            }

            // Adding the children that are in flatDocumentsToUpdate
            for (Document documentToUpdate : flatDocumentsToUpdate) {
                if (document.getChildObject().getId().contains(documentToUpdate.getId())) {
                    children.add(documentToUpdate);
                }
            }
        }
        for (Document child : children) {
            LOGGER.debug("Computing validity code for child " + child.getId() + " of document" + document.getId());
            Document oldDoc = idToOldDocument.get(child.getId());
            if (oldDoc == null) {
                computeValidityCode(child, flatDocumentsToUpdate);
            }
            else {
                computeValidityCode(child, oldDoc, flatDocumentsToUpdate);
            }

            if (ValdtyCode.INVALID.equals(child.getData().getValidityCode())) {
                return false;
            }
        }
        return true;
    }

    private boolean checkTagsValidity(Document document) throws SugarTechnicalException, SugarFunctionalException {
        List<DocumentClass> documentClassesfetched = documentClassService.get(document.getScope(),
                Lists.newArrayList(document.getData().getClassId()));
        DocumentClass documentClass = documentClassesfetched.get(0);
        List<String> tagNames = new ArrayList<>();

        // Get the tags of the document

        if (document.isSetTags()) {
            for (Tag tag : document.getTags().getTag()) {
                tagNames.add(tag.getName());
            }
        }

        // Checks if document contains all mandatory tags of its document class
        Set<String> tagSymbolicNames = new HashSet<>();
        List<String> mandatoryTagsList = new ArrayList<>();
        for (MCOTagReference ref : documentClass.getTagReference()) {
            tagSymbolicNames.add(ref.getSymbolicName());

            if (ref.isMandatory()) {
                mandatoryTagsList.add(ref.getSymbolicName());
                if (!tagNames.contains(ref.getSymbolicName())) {
                    return false;
                }
            }

        }

        // Getting tag classes of the document
        List<TagClass> tagClasses = tagClassService.getBySymbolicName(document.getScope(),
                Lists.newArrayList(tagSymbolicNames), true);

        for (TagClass tagClass : tagClasses) {

            String tagValue = getTagValue(document.getTags(), tagClass.getSymbolicName());

            boolean isValueEmpty = tagValue == null || tagValue.trim().isEmpty();

            if (!isValueEmpty) {
                if (tagClass.isSetPattern()) {
                    String pattern = tagClass.getPattern();
                    if (!pattern.trim().isEmpty() && TagValueType.STRING.equals(tagClass.getTagType())
                            && !Pattern.matches(pattern, tagValue)) {
                        return false;

                    }
                }
                if (TagValueType.CHOICELIST.equals(tagClass.getTagType())) {
                    /*
                     * if tagValue.trim().isEmpty() &&
                     * mandatoryTagsList.contains(tagClass.getSymbolicName())
                     * 
                     * throw an Exception
                     * 
                     * if !tagValue.trim().isEmpty() &&
                     * mandatoryTagsList.contains(tagClass.getSymbolicName())
                     * 
                     * do validation
                     * 
                     * if tagValue.trim().isEmpty() &&
                     * !mandatoryTagsList.contains(tagClass.getSymbolicName())
                     * 
                     * continue execution don't do validation
                     * 
                     * if !tagValue.trim().isEmpty() &&
                     * !mandatoryTagsList.contains(tagClass.getSymbolicName())
                     * 
                     * do validation
                     */
                    List<String> key = new ArrayList<>();
                    for (MCOAllowedValue value : tagClass.getAllowedValue()) {
                        key.add(value.getSymbolicName());
                    }
                    if (!key.contains(tagValue)) {
                        throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00020,
                                tagClass.getSymbolicName(), document.getId(), tagValue);
                    }
                }
            }
            if (isValueEmpty && mandatoryTagsList.contains(tagClass.getSymbolicName())) {
                return false;
            }
        }

        return true;
    }

    private String getTagValue(Tags tags, String symbolicName) {
        for (Tag tag : tags.getTag()) {
            if (symbolicName != null && symbolicName.equals(tag.getName())) {
                return tag.getValue();
            }
        }
        return "";
    }

    private boolean checkDataValidity(Document document) {
        if (Category.ENVELOPE.equals(document.getCategory())) {
            if (!document.getData().isSetConfdntltyLvl() || !document.getData().isSetDirectionCode()) {
                return false;
            }

        }
        else if (Category.DOCUMENT.equals(document.getCategory())) {
            if (!document.getData().isSetName() || document.getData().getName().isEmpty()
                    || document.getData().getName().trim().isEmpty()) {
                return false;
            }
        }
        return true;
    }

    private void checkChildIsNotParent(List<Document> documents)
            throws SugarFunctionalException, SugarTechnicalException {
        for (Document document : documents) {

            if (document.isSetChildObject()) {
                if (document.getChildObject().getId().contains(document.getId())) {
                    throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00018, document.getId());
                }
                if (document.isSetParentId()
                        && document.getChildObject().getId().contains(document.getParentId().getId())) {
                    throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00019, document.getId());

                }
            }
        }
    }

    private void checkNoChildIsRemoved(List<Document> documents, Map<Id, Document> docIdToOldDoc)
            throws SugarFunctionalException, SugarTechnicalException {

        for (Document document : documents) {
            Document storedDocument = docIdToOldDoc.get(document.getId());
            if (storedDocument != null) {
                List<Document> children = getChildren(document.getScope(), document);
                if (storedDocument.isSetChildObject() && storedDocument.getChildObject().isSetDocument()) {
                    for (Document storedChild : storedDocument.getChildObject().getDocument()) {
                        if (!ValidatorHelper.getSubListOfDocumentId(children).contains(storedChild.getId())) {
                            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00032,
                                    storedChild.getId(), document.getId());
                        }
                    }
                }

            }
        }
    }

    private void checkClassIsActive(String scope, List<Document> documents)
            throws SugarTechnicalException, SugarFunctionalException {
        for (Document doc : documents) {
            checkClassIsActive(scope, doc);
            if (doc.isSetChildObject()) {
                checkClassIsActive(scope, doc.getChildObject().getDocument());
            }
        }

    }

    public void checkExistenceAndClassChanging(String scope, List<Document> documents, Map<Id, Document> docIdToOldDoc)
            throws SugarFunctionalException, SugarTechnicalException {
        for (Document doc : documents) {
            if (doc.isSetId()) {
                Document oldDoc = docIdToOldDoc.get(doc.getId());
                if (oldDoc != null) {
                    LOGGER.debug("An old doc has been fetched with classid = {} and new classid is = {} ",
                            oldDoc.getData().getClassId(), doc.getData().getClassId());

                    if (ValdtyCode.UNDER_CONSTRUCTION.equals(oldDoc.getData().getValidityCode())
                            || !oldDoc.getData().getClassId().equals(doc.getData().getClassId())) {
                        checkClassIsActive(scope, doc);
                    }
                    if (!oldDoc.getData().getUpdtDate().equals(doc.getData().getUpdtDate())) {
                        LOGGER.info(" old doc" + oldDoc.getData().getUpdtDate().getTime() + "current doc "
                                + doc.getData().getUpdtDate().getTime());
                        throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00035, doc.getId());
                    }
                }
            }
            else {
                checkClassIsActive(scope, doc);
            }
            if (doc.isSetChildObject()) {
                checkExistenceAndClassChanging(scope, doc.getChildObject().getDocument(), docIdToOldDoc);
            }
        }

    }

    @Override
    public void checkExistence(String scope, List<Id> documentIds)
            throws SugarFunctionalException, SugarTechnicalException {
        List<Id> cleanDocumentIds = ValidatorHelper.removeDuplicates(documentIds);
        List<Document> fetched = documentService.get(scope, cleanDocumentIds, false, false);

        if (fetched == null) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00012, documentIds);
        }
        else if (fetched.size() != documentIds.size()) {
            for (Document doc : fetched) {
                documentIds.remove(doc.getId());
            }
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00012, documentIds);
        }
    }

    private void checkClassIsActive(String scope, Document doc)
            throws SugarTechnicalException, SugarFunctionalException {

        LOGGER.info("checking validity for classs {}" + doc.getData().getClassId());
        DocumentClass clazz = documentClassService.get(scope, Lists.newArrayList(doc.getData().getClassId())).get(0);
        if (!clazz.isActive()) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00014, doc.getId(),
                    clazz.getLongLabel()+" in version : "+clazz.getClassId().getVersId());
        }
    }

    private void checkFileData(List<Document> documents, Map<Document, List<Document>> sortedChilds)
            throws SugarFunctionalException, SugarTechnicalException {

        for (Document document : documents) {
            checkFileData(document);

            List<Document> children = sortedChilds.get(document);
            if (children != null) {
                for (Document child : children) {

                    checkFileData(child);
                }
            }
        }
    }

    private void checkFileData(Document document) throws SugarFunctionalException, SugarTechnicalException {
        if (Category.DOCUMENT.equals(document.getCategory())) {
            if (document.getFileData() == null
                    || (document.getFileData().getURI() == null || document.getFileData().getURI().isEmpty())) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00021);
            }
            if (!document.getFileData().getURI().isEmpty()) {
                for (String uri : document.getFileData().getURI()) {
                    if (uri.trim().length() < 1) {
                        throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00021);
                    }
                }
            }
            if (!document.getFileData().getDocumentFile().isEmpty()) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00022);
            }
        }
    }

    /**
     * Fetch ALL childs and their respective childs
     * 
     * <br/>
     * Replaced private List<Document> getChildren(String scope, List<Document>
     * documents) throws SugarFunctionalException, SugarTechnicalException Check
     * GIT for source code
     * 
     * @param scope
     * @param documents
     * @return
     * @throws SugarFunctionalException
     * @throws SugarTechnicalException
     */
    private Map<Document, List<Document>> mapChildren(String scope, List<Document> documents)
            throws SugarFunctionalException, SugarTechnicalException {

        Map<Document, List<Document>> childrenMap = new TreeMap<>(new Comparator<Document>() {

            @Override
            public int compare(Document o1, Document o2) {
                return Integer.compare(Objects.hashCode(o1.getId()), Objects.hashCode(o2.getId()));
            }
        });
        List<Id> parentsWithoutLoadedChilds = new ArrayList<>();
        for (Document document : documents) {

            List<Document> children = new ArrayList<>();
            if (document.isSetChildObject() && !document.getChildObject().getDocument().isEmpty()) {
                children.addAll(document.getChildObject().getDocument());
            }
            if (document.isSetChildObject() && !document.getChildObject().getId().isEmpty()) {
                parentsWithoutLoadedChilds.addAll(document.getChildObject().getId());
            }
            childrenMap.put(document, children);

        }

        if (!parentsWithoutLoadedChilds.isEmpty()) {
            List<Document> unmapedChildren = documentService.get(scope, parentsWithoutLoadedChilds, true, false);
            for (Document child : unmapedChildren) {

                for (Entry<Document, List<Document>> parentEntry : childrenMap.entrySet()) {
                    Document parent = parentEntry.getKey();
                    if (child.getParentId().getId().equals(parent.getId())) {
                        List<Document> childList = parentEntry.getValue();
                        if (childList == null) {
                            childList = new ArrayList<>();
                            parentEntry.setValue(childList);
                        }
                        childList.add(child);
                        break;
                    }
                }
            }
        }

        for (List<Document> children : childrenMap.values()) {
            childrenMap.putAll(mapChildrenR(children));
        }

        return childrenMap;
    }

    private Map<Document, List<Document>> mapChildrenR(List<Document> documents) {
        Map<Document, List<Document>> childrenMap = new HashMap<>();
        for (Document document : documents) {
            if (document.isSetChildObject() && !document.getChildObject().getDocument().isEmpty()) {
                List<Document> children = new ArrayList<>();
                children.addAll(document.getChildObject().getDocument());
                childrenMap.put(document, children);
            }

        }
        return childrenMap;
    }

    private List<Document> getChildren(String scope, Document document)
            throws SugarFunctionalException, SugarTechnicalException {
        List<Document> children = new ArrayList<>();
        if (document.isSetChildObject() && !document.getChildObject().getDocument().isEmpty()) {
            children.addAll(document.getChildObject().getDocument());
        }
        if (document.isSetChildObject() && !document.getChildObject().getId().isEmpty()) {
            children.addAll(
                    documentService.get(scope, Lists.newArrayList(document.getChildObject().getId()), true, false));
        }

        return children;
    }

    @Override
    public void checkGetValidity(String scope) throws SugarFunctionalException, SugarTechnicalException {
        businessScopeValidator.checkExistence(scope);
    }

    @Override
    public void checkFindValidity(String scope, Criteria criteria, OrderClause orderClause, long max)
            throws SugarFunctionalException, SugarTechnicalException {
        businessScopeValidator.checkExistence(scope);
        ValidatorHelper.checkItem(criteria.getItem(), Lists.newArrayList(Item.DOCUMENT, Item.ENVELOPE));
        ValidatorHelper.checkCriteria(criteria);
        ValidatorHelper.checkOrderClause(orderClause);
        ValidatorHelper.checkRange(max);
    }

    @Override
    public void checkDeleteValidity(String scope) throws SugarFunctionalException, SugarTechnicalException {
        businessScopeValidator.checkExistence(scope);
    }

    private static Collection<String> getAllowedDirectionCodes() {
        final String DIRECTION_CODE_IN = "IN";
        final String DIRECTION_CODE_OUT = "OUT";
        final String DIRECTION_CODE_INTERNAL = "INTERN";
        ArrayList<String> result = new ArrayList<>();
        result.add(DIRECTION_CODE_IN);
        result.add(DIRECTION_CODE_OUT);
        result.add(DIRECTION_CODE_INTERNAL);
        return result;
    }
}
