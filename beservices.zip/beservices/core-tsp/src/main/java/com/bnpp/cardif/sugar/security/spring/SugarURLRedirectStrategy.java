package com.bnpp.cardif.sugar.security.spring;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Add ability to build redirect URL with the current URL parameters
 * 
 * @author Christopher Laszczuk
 *
 */
public abstract class SugarURLRedirectStrategy {
    private static final String TARGET_URL = "&targetURL=";

    private String redirectURL = "";

    private static final Logger LOGGER = LoggerFactory.getLogger(SugarURLRedirectStrategy.class);

    private boolean keepParameters = true;

    protected String buildRedirectURL(HttpServletRequest request) {
        String redirectUrl = redirectURL;
        String queryString = request.getQueryString();
        LOGGER.info("Into buildRedirectURL - queryString " + request.getQueryString());
        if (isKeepParameters() && queryString != null) {
            // All parameters are in URL, keep them
            redirectUrl = addParameterToURL(redirectUrl, queryString);
        }
        else {
            // No parameter in the URL, but might be in the content of the
            // request
            // we add them into the redirectUrl
            String scope = request.getParameter("scope");
            if (scope != null && !scope.isEmpty()) {
                redirectUrl = addParameterToURL(redirectUrl, "scope=" + scope);
            }
            String targetURLParameter = request.getParameter("targetURL");
            if (targetURLParameter != null && !targetURLParameter.isEmpty()) {
                try {
                    targetURLParameter = URLEncoder.encode(targetURLParameter, "UTF-8");
                }
                catch (UnsupportedEncodingException e) {
                    LOGGER.error("Impossible to encode ", e);
                }

                redirectUrl = addParameterToURL(redirectUrl, "targetURL=" + targetURLParameter);
            }
        }

        // No targetURL parameter, creating new targetURL
        String targetURLParameter = request.getParameter("targetURL");
        if (targetURLParameter == null || targetURLParameter.isEmpty()) {
            redirectUrl = addParameterToURL(redirectUrl, "targetURL=" + request.getRequestURL());
            redirectUrl = addParameterToURL(redirectUrl, queryString);
        }

        LOGGER.debug("Redirecting to " + redirectUrl);
        return redirectUrl;
    }

    private String addParameterToURL(String redirectUrl, String queryString) {
        redirectUrl += redirectUrl.contains("?") ? '&' : '?';
        redirectUrl += queryString;
        return redirectUrl;
    }

    protected String buildLogoutURL(HttpServletRequest request) {
        String isSessionExpired = request.getParameter("isSessionExpired");
        String scope = request.getParameter("scope");
        String locale = request.getParameter("locale");

        String logoutRedirectUrl = redirectURL + "?scope=" + scope;
        if (locale != null && !locale.isEmpty()) {
            logoutRedirectUrl += "&locale=" + locale;
        }

        String targetURLValue = request.getParameter("EncodedTargetURL");

        LOGGER.debug("Target URL value " + targetURLValue);
        if (Boolean.parseBoolean(isSessionExpired) && targetURLValue != null) {
            try {
                targetURLValue = URLEncoder.encode(targetURLValue, "UTF-8");
            }
            catch (UnsupportedEncodingException e) {
                LOGGER.error("Impossible to encode ", e);
            }

            logoutRedirectUrl += TARGET_URL + targetURLValue;
        }

        LOGGER.debug("Get parameters isExpired " + isSessionExpired);
        LOGGER.debug("Original Request " + request.getQueryString());
        LOGGER.debug("Into buildLogoutURL - Redirecting to " + logoutRedirectUrl);

        return logoutRedirectUrl;
    }

    public String getRedirectURL() {
        return redirectURL;
    }

    public void setRedirectURL(String redirectURL) {
        if (null == redirectURL || "".equals(redirectURL)) {
            throw new RuntimeException("The defined redirectURL parameter cannot be null or empty");
        }
        this.redirectURL = redirectURL;
    }

    public boolean isKeepParameters() {
        return keepParameters;
    }

    public void setKeepParameters(boolean keepParameters) {
        this.keepParameters = keepParameters;
    }
}
