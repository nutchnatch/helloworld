package com.bnpp.cardif.sugar.core.tsp.acl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnpp.cardif.sugar.core.api.acl.AclService;
import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeService;
import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.tsp.document.DocumentSecurityHelper;
import com.bnpp.cardif.sugar.dao.api.acl.AclDAO;
import com.bnpp.cardif.sugar.dao.api.acl.AclDAO.AclContext;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AclId;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.google.common.collect.Lists;

@Component
public class AclServiceTSP implements AclService {
    private static final Logger LOGGER = LoggerFactory.getLogger(AclServiceTSP.class);

    @Autowired
    private AclDAO aclDAO;

    @Autowired
    private BusinessScopeService businessScopeService;

    @Autowired
    private DocumentSecurityHelper documentSecurityHelper;

    @Autowired
    private BusinessScopeValidator scopeValidator;

    public void init() {
        // legacy code that the previous EHCache custom solution used. Should
        // consider remove if no longer necessary
    }

    public void setDocumentSecurityHelper(DocumentSecurityHelper documentSecurityHelper) {
        this.documentSecurityHelper = documentSecurityHelper;
    }

    public DocumentSecurityHelper getDocumentSecurityHelper() {
        if (documentSecurityHelper == null) {
            throw new IllegalArgumentException("AclService : no DocumentSecurityHelper set here !");
        }
        return documentSecurityHelper;
    }

    @Cacheable(value = "AccessControlList", key = "'ACLByClassId'.concat(#scope).concat(#classId.hashCode()).concat(#isInstanceValue)")
    @Override
    @Transactional(readOnly = true)
    public AccessControlList getByClassId(String scope, ClassId classId, boolean isInstanceValue)
            throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);
        AclContext context = isInstanceValue ? AclContext.INSTANCE : AclContext.CLASS;

        AclId aclId = aclDAO.searchAcl(classId, context, scope);

        LOGGER.debug("The ACL {} has been found for class {}", aclId, classId);
        return this.get(scope, aclId);
    }

    @Cacheable(value = "AccessControlList", key = "'ACLByBasketId'.concat(#scope).concat(#id.hashCode())")
    @Override
    @Transactional(readOnly = true)
    public AccessControlList getByBasketId(String scope, BasketId id)
            throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);

        AclId aclId = aclDAO.searchAcl(id, scope);

        LOGGER.debug("The ACL {} has been found for basket {}", aclId, id);
        return this.get(scope, aclId);
    }

    @Cacheable(value = "AccessControlList", key = "'ACLByDocumentId'.concat(#scope).concat(#id.hashCode())")
    @Override
    @Transactional(readOnly = true)
    public AccessControlList getByDocumentId(String scope, Id id)
            throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);

        AclId aclId = aclDAO.searchAcl(id, scope);

        LOGGER.debug("The ACL {} has been found for basket {}", aclId, id);
        return this.get(scope, aclId);
    }

    @Cacheable(value = "AccessControlList", key = "'ACLByFolderId'.concat(#scope).concat(#folderId.hashCode())")
    @Override
    @Transactional(readOnly = true)
    public AccessControlList getByFolderId(String scope, FolderId folderId)
            throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);

        AclId aclId = aclDAO.searchAcl(folderId, scope);

        LOGGER.debug("The ACL {} has been found for folder {}", aclId, folderId);
        return this.get(scope, aclId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AccessControlList> getAll(String scope) throws SugarFunctionalException, SugarTechnicalException {
        scopeValidator.checkExistence(scope);
        List<AccessControlList> fetchedAcls = aclDAO.getAll(scope);
        if (fetchedAcls.isEmpty()) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00301, scope);
        }
        return fetchedAcls;
    }

    @CacheEvict(value = "AccessControlList", key = "'ACLByClassId'.concat(#scope).concat(#classId.hashCode()).concat(#isInstanceValue)")
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public AccessControlList assignToClass(String scope, AclId aclId, ClassId classId, boolean isInstanceValue)
            throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);
        getDocumentSecurityHelper().checkAdminAccessibility(scope);
        AclContext context = isInstanceValue ? AclContext.INSTANCE : AclContext.CLASS;
        this.remove(scope, classId, context);
        aclDAO.assign(aclId, classId, context, scope);
        LOGGER.info("The ACL {} has been assigned to class {}", aclId, classId);
        return this.get(scope, aclId);
    }

    @CacheEvict(value = "AccessControlList", key = "'ACLByDocumentId'.concat(#scope).concat(#documentId.hashCode())")
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public AccessControlList assignToDocument(String scope, AclId aclId, Id documentId, boolean isReasign)
            throws SugarTechnicalException, SugarFunctionalException {
        if (isReasign) {
            remove(scope, documentId);
        }
        aclDAO.assign(aclId, documentId, scope);
        LOGGER.info("The ACL {} has been assigned to document {}", aclId, documentId);
        return this.get(scope, aclId);
    }

    private void remove(String scope, Id documentId) throws SugarTechnicalException {
        aclDAO.remove(documentId, scope);
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public AccessControlList assignToFolder(String scope, AclId aclId, FolderId folderId)
            throws SugarTechnicalException, SugarFunctionalException {
        aclDAO.assign(aclId, folderId, scope);
        LOGGER.info("The ACL {} has been assigned to folder {}", aclId, folderId);
        return this.get(scope, aclId);
    }

    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public AccessControlList assignToBasket(String scope, AclId aclId, BasketId basketId)
            throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);
        getDocumentSecurityHelper().checkAdminAccessibility(scope);
        this.remove(scope, basketId);
        aclDAO.assign(aclId, basketId, scope);
        LOGGER.info("The ACL {} has been assigned to basket {}", aclId, basketId);
        return this.get(scope, aclId);
    }

    @CacheEvict(value = "AccessControlList", key = "'ACLDefault'.concat(#scope)")
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public AccessControlList setDefaultACL(String scope, AclId aclId)
            throws SugarTechnicalException, SugarFunctionalException {
        AccessControlList acl = get(scope, aclId);
        BusinessScope businessScope = businessScopeService.getBySymbolicName(Lists.newArrayList(scope)).get(0);
        aclDAO.remove(scope, businessScope.getBusinessScopeId(), AclContext.DEFAULT);
        aclDAO.assign(aclId, businessScope.getBusinessScopeId(), scope, AclContext.DEFAULT);
        return acl;
    }

    @Override
    public void assignDefault(String scope, BasketId basketId)
            throws SugarTechnicalException, SugarFunctionalException {
        assignToBasket(scope, getByScope(scope).getAclId(), basketId);
    }

    @Override
    public void assignDefault(String scope, ClassId classId) throws SugarTechnicalException, SugarFunctionalException {
        assignToClass(scope, getByScope(scope).getAclId(), classId, false);
        assignToClass(scope, getByScope(scope).getAclId(), classId, true);
    }

    @Cacheable(value = "AccessControlList", key = "'ACLBusinessScope'.concat(#scope)")
    @Override
    @Transactional(readOnly = true)
    public AccessControlList getByScope(String scope) throws SugarTechnicalException, SugarFunctionalException {
        return getScopeACL(scope, AclContext.BUSINESSSCOPE);
    }

    @Cacheable(value = "AccessControlList", key = "'ACLDefault'.concat(#scope)")
    @Override
    @Transactional(readOnly = true)
    public AccessControlList getDefault(String scope) throws SugarTechnicalException, SugarFunctionalException {
        return getScopeACL(scope, AclContext.DEFAULT);
    }

    private AccessControlList getScopeACL(String scope, AclContext context)
            throws SugarTechnicalException, SugarFunctionalException {
        AclId aclId = getScopeACLId(scope, context);
        if (aclId != null) {
            return get(scope, aclId);
        }
        throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00301, scope, context);
    }

    private AclId getScopeACLId(String scope, AclContext context)
            throws SugarTechnicalException, SugarFunctionalException {

        BusinessScope fetchedScope = businessScopeService.getBySymbolicName(Lists.newArrayList(scope)).get(0);

        return aclDAO.searchAcl(fetchedScope.getBusinessScopeId(), scope, context);
    }

    @CacheEvict(value = "AccessControlList", key = "'ACLByBasketId'.concat(#scope).concat(#basketId.hashCode())")
    @Override
    @Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
    public void remove(String scope, BasketId basketId) throws SugarTechnicalException {
        aclDAO.remove(basketId, scope);
    }

    private void remove(String scope, ClassId classId, AclContext context)
            throws SugarTechnicalException, SugarFunctionalException {
        aclDAO.remove(scope, classId, context);
    }

    @Cacheable("AccessControlList")
    @Override
    @Transactional(readOnly = true)
    public AccessControlList get(String scope, AclId id) throws SugarTechnicalException, SugarFunctionalException {

        scopeValidator.checkExistence(scope);
        AccessControlList acls = aclDAO.get(id, scope);
        if (acls == null) {
            throw ExceptionBuilder.createTechnicalException(TechnicalErrorCode.T01002, id);
        }
        return acls;
    }

}
