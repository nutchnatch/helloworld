package com.bnpp.cardif.sugar.core.tsp.document;

import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00201;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00202;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00203;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Category;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.TimeUnitConstance;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;

public class RetentionDateHelper {
    private static final Logger LOGGER = LoggerFactory.getLogger(RetentionDateHelper.class);

    private RetentionDateHelper() {
    }

    public static Date computeRetentionEndDate(Document document, DocumentClass documentClass)
            throws SugarFunctionalException {

        if (document.getData().getRetentionStartDate() == null || Category.ENVELOPE.equals(document.getCategory())) {
            return null;
        }
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTime(document.getData().getRetentionStartDate());
        LOGGER.debug("The document retention duration is " + documentClass.getRetentionDuration());
        if (documentClass.getRetentionDuration() == null) {
            throw ExceptionBuilder.createFunctionalException(F00201, documentClass.getClassId());
        }
        if (documentClass.getRetentionDuration().getTimeUnit() == null) {
            throw ExceptionBuilder.createFunctionalException(F00202, documentClass.getClassId());
        }
        TimeUnitConstance timeUnit = TimeUnitConstance.valueOf(documentClass.getRetentionDuration().getTimeUnit());
        switch (timeUnit) {
        case MONTH:
            calendar.add(Calendar.MONTH, documentClass.getRetentionDuration().getValue().intValue());
            break;
        case DAY:
            calendar.add(Calendar.HOUR, 24 * documentClass.getRetentionDuration().getValue().intValue());
            break;
        case YEAR:
            calendar.add(Calendar.YEAR, documentClass.getRetentionDuration().getValue().intValue());
            break;
        default:
            throw ExceptionBuilder.createFunctionalException(F00203, timeUnit, documentClass.getClassId());
        }
        LOGGER.debug("Computed end retention date for document" + document.getId() + "is " + calendar.getTime());
        return calendar.getTime();
    }

    public static Date computeRetentionEndDate(Date documentRetentionEndDate, Date folderRetentionEndDate)
            throws SugarTechnicalException {
        if (documentRetentionEndDate.after(folderRetentionEndDate)) {
            return documentRetentionEndDate;
        }
        else {
            return folderRetentionEndDate;
        }

    }

    public static Date computeRetentionEndDate(Folder folder, FolderClass folderClass) throws SugarFunctionalException {
        if (folder.getData().getCloseDate() == null) {
            LOGGER.debug("Computed end retention date for folder " + folder.getFolderId() + "is " + null);
            return null;
        }
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTime(folder.getData().getCloseDate());
        LOGGER.debug("Folder retention duration is " + folderClass.getRetentionDuration());
        TimeUnitConstance timeUnit = TimeUnitConstance.valueOf(folderClass.getRetentionDuration().getTimeUnit());
        switch (timeUnit) {
        case MONTH:
            calendar.add(Calendar.MONTH, folderClass.getRetentionDuration().getValue().intValue());
            break;
        case DAY:
            calendar.add(Calendar.HOUR, 24 * folderClass.getRetentionDuration().getValue().intValue());
            break;
        case YEAR:
            calendar.add(Calendar.YEAR, folderClass.getRetentionDuration().getValue().intValue());
            break;
        default:
            throw ExceptionBuilder.createFunctionalException(F00203, timeUnit, folderClass.getClassId());
        }

        LOGGER.debug("Computed end retention date for folder " + folder.getFolderId() + "is " + calendar.getTime());
        return calendar.getTime();
    }
}
