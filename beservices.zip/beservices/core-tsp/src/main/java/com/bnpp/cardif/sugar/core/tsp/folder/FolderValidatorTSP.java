package com.bnpp.cardif.sugar.core.tsp.folder;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.folder.FolderService;
import com.bnpp.cardif.sugar.core.api.folder.FolderValidator;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassService;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagClassValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagclassService;
import com.bnpp.cardif.sugar.core.tsp.util.ValidatorHelper;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderDataType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderStatusCodeType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tag;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.Tags;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Item;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOAllowedValue;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.MCOTagReference;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagValueType;
import com.google.common.collect.Lists;

@Component
public class FolderValidatorTSP implements FolderValidator {
    
    @Autowired
    private FolderService folderService;

    @Autowired
    private BusinessScopeValidator scopeValidator;

    @Autowired
    private TagClassValidator tagValidator;

    @Autowired
    private FolderClassValidator classValidator;

    @Autowired
    private TagclassService tagService;

    @Autowired
    private FolderClassService classService;

    @Override
    public void checkCreationValidity(List<Folder> folders) throws SugarTechnicalException, SugarFunctionalException {
        if (folders == null || folders.isEmpty()) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00101);
        }
        checkScope(folders);
        checkChildComponentIsSet(folders);
        checkIfAlreadyExists(folders);
        checkFoldersData(folders);
        checkFolderClass(folders, true);
        checkFoldersTag(folders);
    }

    @Override
    public void checkUpdateValidity(List<Folder> folders) throws SugarTechnicalException, SugarFunctionalException {
        if (folders == null || folders.isEmpty()) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00101);
        }
        checkScope(folders);
        checkChildComponentIsSet(folders);
        checkIfAlreadyExists(folders);
        checkFoldersData(folders);
        checkFolderClass(folders, false);
        checkFoldersTag(folders);
        checkIfFolderIsClosed(folders);
    }

    private void checkChildComponentIsSet(List<Folder> folders) throws SugarFunctionalException {
        for (Folder folder : folders) {
            if (!folder.isSetChildComponents()) {
               throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00117, folder.getFolderId());
            }
        }
    }

    private void checkIfFolderIsClosed(List<Folder> folders) throws SugarTechnicalException, SugarFunctionalException {
        List<Folder> oldFolders = folderService.get(ValidatorHelper.getSubListOfFolderId(folders),
                folders.get(0).getScope());
        for (Folder folder : oldFolders) {
            if (FolderStatusCodeType.CLOSE.equals(folder.getData().getStatusCode())) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00116, folder.getFolderId());
            }
        }
    }

    private void checkFolderClass(List<Folder> folders, boolean isCreation)
            throws SugarTechnicalException, SugarFunctionalException {
        List<ClassId> classesToCheck = new ArrayList<ClassId>();
        for (Folder folder : folders) {
            classesToCheck.add(folder.getData().getClassId());
        }

        classValidator.checkExistence(folders.get(0).getScope(), classesToCheck);
        List<FolderClass> fetched = classService.get(classesToCheck, folders.get(0).getScope());
        if (isCreation) {
            for (FolderClass clazz : fetched) {
                if (!clazz.isActive()) {
                    throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00109, clazz.getLongLabel());

                }
            }
        }

    }

    private void checkFoldersData(List<Folder> folders) throws SugarFunctionalException {
        for (Folder folder : folders) {
            if (!folder.isSetData()) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00107);

            }
            FolderDataType data = folder.getData();
            if (!data.isSetName() || data.getName().trim().isEmpty()) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00111);
            }
            if (!data.isSetOwner() || data.getOwner().trim().isEmpty()) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00112,
                        folder.getData().getName());

            }
            if (!data.isSetStatusCode()) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00108,
                        folder.getData().getName());

            }
            if (!data.isSetClassId()) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00113,
                        folder.getData().getName());

            }
        }
    }

    private void checkFoldersTag(List<Folder> folders) throws SugarTechnicalException, SugarFunctionalException {

        for (Folder folder : folders) {
            Set<String> tagNames = new HashSet<String>();
            if (folder.isSetTags()) {
                List<Tag> tags = folder.getTags().getTag();
                for (Tag tag : tags) {
                    tagNames.add(tag.getName());
                }
            }
            FolderClass currentClass = classService
                    .get(Lists.newArrayList(folder.getData().getClassId()), folder.getScope()).get(0);

            List<MCOTagReference> tagReference = currentClass.getTagReference();
            List<String> tagRefName = new ArrayList<String>();
            for (MCOTagReference ref : tagReference) {
                tagRefName.add(ref.getSymbolicName());

            }
            for (String name : tagNames) {
                if (!tagRefName.contains(name)) {
                    throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00118,
                            folder.getData().getName(), name, currentClass.getLongLabel());
                }
            }

            for (MCOTagReference ref : tagReference) {
                TagClass tagClass = tagService
                        .getBySymbolicName(folder.getScope(), Lists.newArrayList(ref.getSymbolicName()), true).get(0);
                String tagValue = getTagValue(folder.getTags(), ref.getSymbolicName());
                if (ref.isMandatory()) {
                    if (!tagNames.contains(ref.getSymbolicName())) {
                        throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00110,
                                ref.getSymbolicName(), folder.getData().getName());
                    }

                    if (tagValue == null || tagValue.trim().isEmpty()) {
                        throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00110,
                                ref.getSymbolicName(), folder.getData().getName());
                    }
                    if (tagClass.isSetPattern()) {
                        String pattern = tagClass.getPattern();
                        if (!pattern.trim().isEmpty() && TagValueType.STRING.equals(tagClass.getTagType())) {
                            boolean matches = Pattern.matches(pattern, tagValue);
                            if (!matches) {
                                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00114,
                                        ref.getSymbolicName(), pattern, folder.getData().getName());
                            }
                        }
                    }
                }
                if (TagValueType.CHOICELIST.equals(tagClass.getTagType())) {
                    List<String> key = new ArrayList<String>();
                    for (MCOAllowedValue value : tagClass.getAllowedValue()) {
                        key.add(value.getSymbolicName());
                    }
                    if (!key.contains(tagValue) && !tagValue.trim().isEmpty()) {
                        throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00115,
                                tagClass.getSymbolicName(), folder.getData().getName(), tagValue);
                    }
                }
            }
            if (!tagNames.isEmpty()) {
                tagValidator.checkExistence(folders.get(0).getScope(), Lists.newArrayList(tagNames));
            }
        }

    }

    private String getTagValue(Tags tags, String symbolicName) {
        for (Tag tag : tags.getTag()) {
            if (symbolicName.equals(tag.getName())) {
                return tag.getValue();
            }
        }
        return "";
    }

    private void checkScope(List<Folder> folders) throws SugarFunctionalException, SugarTechnicalException {
        String scope = folders.get(0).getScope();
        for (Folder folder : folders) {
            if (folder.getScope() == null || folder.getScope().trim().isEmpty()) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00104,
                        folder.getData().getName());
            }
            if (!scope.equals(folder.getScope())) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00105, scope, folder.getScope());
            }

        }
        scopeValidator.checkExistence(scope);

    }

    private void checkIfAlreadyExists(List<Folder> folders) throws SugarTechnicalException, SugarFunctionalException {
        List<String> names = new ArrayList<String>();
        for (Folder folder : folders) {
            String name = folder.getData().getName();
            Folder fetched = folderService.getBySymbolicName(folder.getScope(), name);
            if (fetched != null && !fetched.getFolderId().equals(folder.getFolderId())) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00102, folder.getData().getName(),
                        folder.getScope());
            }
            if (names.contains(name)) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00106,
                        folder.getData().getName());
            }
            else {
                names.add(name);
            }
        }
    }

    @Override
    public void checkGetValidity(String scope) throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);
    }

    @Override
    public void checkFindValidity(String scope, Criteria criteria, OrderClause orderClause, long max)
            throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);
        ValidatorHelper.checkItem(criteria.getItem(), Lists.newArrayList(Item.FOLDER));
        ValidatorHelper.checkCriteria(criteria);
        ValidatorHelper.checkOrderClause(orderClause);
        ValidatorHelper.checkRange(max);

    }

    @Override
    public void checkGetBySymbolicName(String scope) throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);
    }
}
