package com.bnpp.cardif.sugar.security;

import java.util.ArrayList;
import java.util.List;

import javax.xml.ws.WebServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.AbstractUserDetailsAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import com.bnpp.cardif.sesame.security.SesameWebServiceFactory;
import com.bnppa.sesame.services.common.model.UserIdentity;
import com.bnppa.sesame.services.standard.proxy.ArrayOfXsdNillableString;
import com.bnppa.sesame.services.standard.proxy.AuthenticationServicesWSP;
import com.bnppa.sesame.services.standard.proxy.AuthorizationServicesWSP;
import com.bnppa.sesame.services.standard.proxy.ExpiredPasswordException;
import com.bnppa.sesame.services.standard.proxy.IdentityServicesWSP;
import com.bnppa.sesame.services.standard.proxy.LockedLoginException;
import com.bnppa.sesame.services.standard.proxy.LoginException;

public class SesameAuthenticationProvider extends AbstractUserDetailsAuthenticationProvider {

    private static final Logger MYLOGGER = LoggerFactory.getLogger(SesameAuthenticationProvider.class.getName());

    private static final String CONTACT_MSG = "Please contact your CI";

    @Autowired
    private SesameWebServiceFactory sesameWebServiceFactory;

    @Autowired
    private SecurityHelper securityHelper;

    @Override
    @Transactional(readOnly = true)
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String username = authentication.getName();
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        AuthenticatedUser authenticatedUser = (AuthenticatedUser) retrieveUser(username,
                (UsernamePasswordAuthenticationToken) authentication);
        stopWatch.stop();
        authenticatedUser.setTimeToSpentOnAuthentication(stopWatch.getTotalTimeMillis());

        return new UsernamePasswordAuthenticationToken(authenticatedUser, null, authenticatedUser.getAuthorities());

    }

    @Override
    protected void additionalAuthenticationChecks(UserDetails userDetails,
            UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
        // No additional checks for now
    }

    @Override
    protected UserDetails retrieveUser(String username, UsernamePasswordAuthenticationToken authentication)
            throws AuthenticationException {

        String password = (String) authentication.getCredentials();

        if (!securityHelper.isSecurityEnabled()) {
            MYLOGGER.debug("Security is not enable not performing check with Sesame");
            List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
            grantedAuthorities.add(new SimpleGrantedAuthority("Empty_Role"));
            return new AuthenticatedUser(username, null, "FakeToken", username, "", grantedAuthorities,
                    sesameWebServiceFactory.getCommercialVersion());
        }
        try {
            AuthenticationServicesWSP authenticationServicesWSP = sesameWebServiceFactory
                    .getAuthenticationServicesWSP();
            String token = authenticationServicesWSP.loginInUserRef(username, password,
                    sesameWebServiceFactory.getAuthType());
            MYLOGGER.debug("Username : {}  got token : {}", username, token);

            AuthorizationServicesWSP authorizationServicesWSP = sesameWebServiceFactory.getAuthorizationServicesWSP();
            ArrayOfXsdNillableString roles = authorizationServicesWSP.getRoles(token,
                    sesameWebServiceFactory.getAppDomain());
            List<GrantedAuthority> grantedAuthorities = buildGrantedAuthorities(roles);

            IdentityServicesWSP identityServicesWSP = sesameWebServiceFactory.getIdentityServicesWSP();
            UserIdentity userIdentity = identityServicesWSP.getUserIdentity(token);
            return new AuthenticatedUser(userIdentity.getLogin(), null, token, userIdentity.getFirstName(),
                    userIdentity.getLastName(), grantedAuthorities, sesameWebServiceFactory.getCommercialVersion());
        }
        catch (ExpiredPasswordException e) {
            throw new BadCredentialsException("Your password is expired. Please reset your password with the Refog");
        }
        catch (LockedLoginException e) {
            throw new BadCredentialsException("Your account is locked. " + CONTACT_MSG);
        }
        catch (LoginException e) {
            throw new BadCredentialsException("The login or the password filled is not correct. " + CONTACT_MSG);
        }
        catch (WebServiceException e) {
            MYLOGGER.error("The connection cannot be established to Sesame. " + CONTACT_MSG, e);
            throw new AuthenticationServiceException("The connection cannot be established to Sesame. " + CONTACT_MSG,
                    e);
        }
        catch (Exception e) {
            throw new AuthenticationServiceException("A technical error occurs during authentication. " + CONTACT_MSG,
                    e);
        }
    }

    private static List<GrantedAuthority> buildGrantedAuthorities(ArrayOfXsdNillableString roles) {
        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        for (String role : roles.getString()) {
            grantedAuthorities.add(new SimpleGrantedAuthority(role));
        }
        return grantedAuthorities;
    }
}
