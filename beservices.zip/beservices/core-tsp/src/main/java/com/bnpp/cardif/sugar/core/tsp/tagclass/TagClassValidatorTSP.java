package com.bnpp.cardif.sugar.core.tsp.tagclass;

import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00204;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00205;
import static com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode.F00206;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagClassValidator;
import com.bnpp.cardif.sugar.core.api.tagclass.TagclassService;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.tagclass.v1.TagClass;
import com.google.common.collect.Lists;

@Component
public class TagClassValidatorTSP implements TagClassValidator {
    
    @Autowired
    private TagclassService tagclassService;

    @Autowired
    private BusinessScopeValidator businessScopeValidator;

    @Override
    public void checkCreationValidity(List<TagClass> tagClasses)
            throws SugarFunctionalException, SugarTechnicalException {
        if (tagClasses.isEmpty()) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00208);
        }
        validateScope(tagClasses);

        String scope = tagClasses.get(0).getScope();
        List<String> computedNames = checkAndComputeSymbolicNames(tagClasses);
        checkType(tagClasses);
        List<TagClass> fetched = tagclassService.getBySymbolicName(scope, computedNames, false);
        if (fetched != null && !fetched.isEmpty()) {
            List<String> fetchedNames = new ArrayList<String>();
            for (TagClass clazz : fetched) {
                fetchedNames.add(clazz.getSymbolicName());
            }
            throw ExceptionBuilder.createFunctionalException(F00205, fetchedNames, tagClasses.get(0).getScope());
        }

    }

    private void checkType(List<TagClass> tagClasses) throws SugarFunctionalException {
        for (TagClass clazz : tagClasses) {
            if (!clazz.isSetTagType()) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00215, clazz.getSymbolicName());
            }
        }

    }

    private void validateScope(List<TagClass> tagClasses) throws SugarFunctionalException, SugarTechnicalException {

        String scope = tagClasses.get(0).getScope();
        if (scope == null) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00211,
                    tagClasses.get(0).getSymbolicName());
        }
        for (TagClass tagClass : tagClasses) {

            if (tagClass.getScope() == null) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00211,
                        tagClass.getSymbolicName());
            }
            if (!scope.equals(tagClass.getScope())) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00209, scope,
                        tagClass.getScope());
            }
        }
        businessScopeValidator.checkExistence(scope);

    }

    private List<String> checkAndComputeSymbolicNames(List<TagClass> tagClasses) throws SugarFunctionalException {
        List<String> symbolicNames = new ArrayList<String>();
        for (TagClass clazz : tagClasses) {
            String symbolicName = clazz.getSymbolicName();
            if (symbolicName == null || symbolicName.trim().isEmpty()) {
                throw ExceptionBuilder.createFunctionalException(F00204);
            }
            if (!symbolicNames.contains(symbolicName)) {
                symbolicNames.add(symbolicName);
            }
            else {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00210, symbolicName);
            }
        }
        return symbolicNames;
    }

    @Override
    public void checkUpdateValidity(List<TagClass> classes) throws SugarTechnicalException, SugarFunctionalException {

        if (classes.isEmpty()) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00208);
        }

        validateScope(classes);
        checkAndComputeSymbolicNames(classes);
        checkType(classes);
        checkExistenceAndNames(classes);
    }

    private void checkExistenceAndNames(List<TagClass> classes)
            throws SugarTechnicalException, SugarFunctionalException {
        for (TagClass tag : classes) {
            List<TagClass> fetched = tagclassService.getBySymbolicName(tag.getScope(),
                    Lists.newArrayList(tag.getSymbolicName()), true);
            if (!fetched.isEmpty()) {
                if (!fetched.get(0).getClassId().equals(tag.getClassId())) {
                    throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00212, tag.getSymbolicName(),
                            fetched.get(0).getClassId(), tag.getClassId());
                }
            }
            else {
                throw ExceptionBuilder.createFunctionalException(F00206, tag.getSymbolicName());

            }
        }
    }

    @Override
    public void checkExistence(String scope, List<String> symbolicNames)
            throws SugarTechnicalException, SugarFunctionalException {

        List<TagClass> fetchedTags = tagclassService.getBySymbolicName(scope, symbolicNames, true);
        if (fetchedTags.isEmpty()) {
            throw ExceptionBuilder.createFunctionalException(F00206, symbolicNames);
        }

        List<String> fetchedSymbolicName = new ArrayList<String>();
        for (TagClass tag : fetchedTags) {
            fetchedSymbolicName.add(tag.getSymbolicName());
        }
        for (String name : symbolicNames) {
            if (!fetchedSymbolicName.contains(name)) {
                throw ExceptionBuilder.createFunctionalException(F00206, name);
            }
        }

    }

    @Override
    public void checkGetAllValidity(String scope) throws SugarTechnicalException, SugarFunctionalException {
        businessScopeValidator.checkExistence(scope);
    }

    @Override
    public void checkGetBySymbolicNameValidity(String scope) throws SugarTechnicalException, SugarFunctionalException {
        businessScopeValidator.checkExistence(scope);
    }
}
