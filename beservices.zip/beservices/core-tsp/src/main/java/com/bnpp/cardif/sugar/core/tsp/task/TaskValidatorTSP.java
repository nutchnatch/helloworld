package com.bnpp.cardif.sugar.core.tsp.task;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnpp.cardif.sugar.core.api.basket.BasketValidator;
import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeValidator;
import com.bnpp.cardif.sugar.core.api.document.DocumentValidator;
import com.bnpp.cardif.sugar.core.api.task.TaskService;
import com.bnpp.cardif.sugar.core.api.task.TaskValidator;
import com.bnpp.cardif.sugar.core.tsp.util.ValidatorHelper;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.FunctionalErrorCode;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.TaskStatus;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.TaskId;
import com.google.common.base.Function;
import com.google.common.collect.Lists;

@Component
public class TaskValidatorTSP implements TaskValidator {
    
    @Autowired
    private BasketValidator basketValidator;

    @Autowired
    private DocumentValidator documentValidator;

    @Autowired
    private TaskService taskService;

    @Autowired
    private BusinessScopeValidator scopeValidator;

    private static final Logger LOGGER = LoggerFactory.getLogger(TaskValidatorTSP.class);

    @Override
    public void validateCreation(List<Task> tasks) throws SugarTechnicalException, SugarFunctionalException {
        List<String> scopes = getSubListOfScope(tasks);
        scopeValidator.checkExistence(scopes);
        if (thereAreDifferentScopes(scopes)) {
            for (Task task : tasks) {
                basketValidator.checkExistence(Lists.newArrayList(task.getBasketId()), task.getScope());
                documentValidator.checkExistence(task.getScope(), getSubListOfDocumentIds(tasks));
            }
        }
        else {
            String scope = scopes.get(0);
            basketValidator.checkExistence(getSubListOfBasketIds(tasks), scope);
            documentValidator.checkExistence(scope, getSubListOfDocumentIds(tasks));
        }
    }

    private List<Id> getSubListOfDocumentIds(List<Task> tasks) {
        List<Id> ids = Lists.transform(tasks, new Function<Task, Id>() {
            @Override
            public Id apply(Task task) {
                return task.getDocID().getId();
            }
        });
        return ids;
    }

    @Override
    public void validateUpdateStatus(String scope, List<TaskId> tasks, String status)
            throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);
        checkStatus(status);
        checkExistence(scope, tasks);
    }

    @Override
    public void validateLock(String scope, List<TaskId> tasks)
            throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);
        List<Task> fetchedTasks = checkExistence(scope, tasks);
        for (Task task : fetchedTasks) {
            if (task.getLockerName() != null && !task.getLockerName().trim().isEmpty()) {
                throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00405, task.getTaskId(),
                        task.getLockerName());
            }
        }
    }

    @Override
    public void validateUnLock(String scope, List<TaskId> tasks)
            throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);
        checkExistence(scope, tasks);
    }

    @Override
    public void validateTransfer(String scope, List<TaskId> taskIds, BasketId basketId)
            throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);
        checkExistence(scope, taskIds);
        basketValidator.checkExistence(Lists.newArrayList(basketId), scope);
    }

    protected List<Task> checkExistence(String scope, List<TaskId> taskIds)
            throws SugarTechnicalException, SugarFunctionalException {
        List<TaskId> uniqueTaskIds = ValidatorHelper.removeDuplicates(taskIds);
        List<Task> fetched = taskService.get(scope, uniqueTaskIds);
        if (fetched == null) {
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00404, uniqueTaskIds);
        }

        if (fetched.size() != uniqueTaskIds.size()) {
            uniqueTaskIds.removeAll(getSubListOfTaskIds(fetched));
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00404, uniqueTaskIds);
        }
        return fetched;
    }

    @Override
    public void validateGetTaskInBasket(String scope, BasketId basketId)
            throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);
        basketValidator.checkExistence(Lists.newArrayList(basketId), scope);
    }

    @Override
    public void validateGetTaskForDocument(String scope, Id docId)
            throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);
        documentValidator.checkExistence(scope, Lists.newArrayList(docId));
    }

    @Override
    public void validateGet(String scope, List<TaskId> taskIds)
            throws SugarTechnicalException, SugarFunctionalException {
        scopeValidator.checkExistence(scope);
    }

    private void checkStatus(String status) throws SugarFunctionalException {
        // allowedValues just used to display readable error
        StringBuilder allowedValues = new StringBuilder();
        for (TaskStatus allowedValue : TaskStatus.values()) {
            allowedValues.append(allowedValue + " ");
        }

        try {
            TaskStatus.valueOf(status);
        }
        catch (IllegalArgumentException e) {
            LOGGER.warn(FunctionalErrorCode.F00503 + e.getMessage(), e);
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00503, status,
                    allowedValues.toString());
        }
        catch (NullPointerException e) {
            LOGGER.warn(FunctionalErrorCode.F00503 + e.getMessage(), e);
            throw ExceptionBuilder.createFunctionalException(FunctionalErrorCode.F00503, status,
                    allowedValues.toString());
        }
    }

    protected boolean thereAreDifferentScopes(List<String> scopes) {
        List<String> scopesCopy = new ArrayList<String>(scopes);
        scopesCopy.removeAll((Lists.newArrayList(scopesCopy.get(0))));
        if (scopesCopy.isEmpty()) {
            return false;
        }
        return true;
    }

    private List<BasketId> getSubListOfBasketIds(List<Task> tasks) {
        List<BasketId> ids = Lists.transform(tasks, new Function<Task, BasketId>() {
            @Override
            public BasketId apply(Task task) {
                return task.getBasketId();
            }
        });
        return ids;
    }

    private List<TaskId> getSubListOfTaskIds(List<Task> tasks) {
        List<TaskId> ids = Lists.transform(tasks, new Function<Task, TaskId>() {
            @Override
            public TaskId apply(Task task) {
                return task.getTaskId();
            }
        });
        return ids;
    }

    private List<String> getSubListOfScope(List<Task> tasks) {
        List<String> ids = Lists.transform(tasks, new Function<Task, String>() {
            @Override
            public String apply(Task task) {
                return task.getScope();
            }
        });
        return ids;
    }

}
