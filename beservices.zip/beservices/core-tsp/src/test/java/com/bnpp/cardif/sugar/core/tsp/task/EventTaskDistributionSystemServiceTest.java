package com.bnpp.cardif.sugar.core.tsp.task;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.businessscope.BusinessScopeService;
import com.bnpp.cardif.sugar.core.api.documentfile.DocumentFileService;
import com.bnpp.cardif.sugar.core.api.task.TaskGeneratorService;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpp.cardif.sugar.domain.test.DocumentMockUtil;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.BusinessScope;
import com.bnpparibas.assurance.ea.internal.schema.mco.businessscope.v1.MCOBusinessScope.FileData;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.DocumentFile;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentfile.v1.URI;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class EventTaskDistributionSystemServiceTest {
    @Mock
    private TaskGeneratorService<Document, String, DocumentFile> taskGenerateService;

    @Mock
    private BusinessScopeService businessScopeService;

    @Mock
    private DocumentFileService documentFileService;

    @Mock
    private SugarEventBus eventBus;

    @InjectMocks
    private final EventTaskDistributionSystemService tdsService = new EventTaskDistributionSystemService();

    @Test(expected = SugarFunctionalException.class)
    public void testPushAString() throws Exception {
        tdsService.push("invalid object", Action.CREATE);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testPushADocument() throws Exception {
        tdsService.push(DocumentMockUtil.buildClaimDocument(), Action.CREATE);
    }

    @Test(expected = SugarFunctionalException.class)
    public void testGetRulesFileForUnknownBusinessScope() throws Exception {
        tdsService.getRulesId("invalid");
    }

    @Test
    public void testGetInternalRulesFile() throws Exception {
        String scope = "invalid";
        mockBackendRulesFile(scope, null);
        assertNull(tdsService.getRulesId(scope));
    }

    @Test
    public void testGetRulesFileForDefinedAtBusinessScopeLevel() throws Exception {
        String scope = "invalid";
        DocumentFile rulesFile = mock(DocumentFile.class);
        URI uri = new URI("My name is Moe");
        Mockito.when(rulesFile.getURI()).thenReturn(uri.getValue());
        mockBackendRulesFile(scope, rulesFile);

        URI fetchRulesId = tdsService.getRulesId(scope);
        assertNotNull(fetchRulesId);
        assertEquals(rulesFile.getURI(), fetchRulesId.getValue());
    }

    @Test
    public void testPushEnvelope() throws Exception {
        Document envelope = DocumentMockUtil.buildEnvelope();
        DocumentFile rulesFile = mock(DocumentFile.class);
        URI uri = new URI("My name is Moe");
        Mockito.when(rulesFile.getURI()).thenReturn(uri.getValue());
        mockBackendRulesFile(envelope.getScope(), rulesFile);

        tdsService.push(envelope, Action.CREATE);

        verify(taskGenerateService).generate(Matchers.eq(envelope), Matchers.anyString(),
                Matchers.any(TaskGeneratorService.TaskGeneratorResolver.class), Matchers.any(Action.class));
    }

    private void mockBackendRulesFile(String scope, DocumentFile rulesFile)
            throws SugarTechnicalException, SugarFunctionalException {
        String uri = rulesFile != null ? rulesFile.getURI() : null;
        BusinessScope businessScope = new BusinessScope();
        FileData fileData = new FileData();
        fileData.setURI(uri);
        businessScope.setFileData(fileData);
        List<BusinessScope> bs = Lists.newArrayList(businessScope);
        when(businessScopeService.getBySymbolicName(Lists.newArrayList(scope))).thenReturn(bs);

        when(documentFileService.get(scope, Lists.newArrayList(new URI(uri))))
                .thenReturn(Lists.newArrayList(rulesFile));
    }

}
