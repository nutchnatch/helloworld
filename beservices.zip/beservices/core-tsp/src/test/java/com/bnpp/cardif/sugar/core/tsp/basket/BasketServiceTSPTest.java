package com.bnpp.cardif.sugar.core.tsp.basket;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyBoolean;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.acl.AclService;
import com.bnpp.cardif.sugar.core.api.basket.BasketValidator;
import com.bnpp.cardif.sugar.core.tsp.document.DocumentSecurityHelper;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.dao.api.basket.BasketDAO;
import com.bnpp.cardif.sugar.dao.api.task.TaskDAO;
import com.bnpp.cardif.sugar.domain.basket.test.BasketMockUtility;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpparibas.assurance.ea.internal.schema.mco.basket.v1.BasketId;
import com.bnpparibas.assurance.ea.internal.schema.mco.task.v1.Task;

@RunWith(MockitoJUnitRunner.class)
public class BasketServiceTSPTest {
    private static final String SCOPE = "myScope";

    @Mock
    private BasketDAO basketDAO;

    @Mock
    private TaskDAO taskDAO;

    @Mock
    private DocumentSecurityHelper documentSecurityHelper;

    @Mock
    private AclService aclService;

    @Mock
    private SugarEventBus eventBus;

    @Mock
    BasketValidator validator;

    @InjectMocks
    private BasketServiceTSP basketServiceTSP;

    @Test
    public void testDelete() throws Exception {
        ArrayList<BasketId> basketsToDelete = new ArrayList<BasketId>();
        basketsToDelete.add(BasketMockUtility.buildBasketId());
        SearchResults<Task> results = new SearchResults<Task>();
        results.setResults(new ArrayList<Task>());
        when(taskDAO.getTasksInBasket(anyString(), any(BasketId.class), anyInt(), anyInt(), anyBoolean()))
                .thenReturn(results);
        basketServiceTSP.delete(basketsToDelete, SCOPE);

        verify(basketDAO).delete(basketsToDelete, SCOPE);
    }

}
