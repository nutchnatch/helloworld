package com.bnpp.cardif.sugar.core.tsp.documentannotation;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.documentannotation.DocumentAnnotationService;
import com.bnpp.cardif.sugar.core.tsp.folder.SecurityContextInitializer;
import com.bnpp.cardif.sugar.dao.api.documentannotation.DocumentAnnotationDAO;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentannotation.v1.DocumentAnnotation;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentannotation.v1.Id;
import com.google.common.collect.Lists;

/**
 * Given that this Service is a simple CRUD for annotations, there arent a lot
 * of "moving parts" to test
 * 
 * Still more test for the coerence and error handling should be performed
 * 
 * @author a69693
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class DocumentAnnotationServiceTSPTest {

    @Mock
    private DocumentAnnotationDAO documentAnnotationDAO;

    @InjectMocks
    private final DocumentAnnotationService documentAnnotationService = new DocumentAnnotationServiceTSP();

    @Before
    public void setUp() throws SugarTechnicalException, SugarFunctionalException {
        SecurityContextInitializer.initContext();
    }

    @Test
    public void testCreate() throws SugarTechnicalException, SugarFunctionalException {
        List<DocumentAnnotation> annotations = Lists.newArrayList(mock(DocumentAnnotation.class));
        documentAnnotationService.create(annotations);
        verify(documentAnnotationDAO, times(1)).create(annotations);
    }

    @Test
    public void testFindByDocumentFileId() throws SugarTechnicalException, SugarFunctionalException {
        List<String> ids = Lists.newArrayList(new String());
        documentAnnotationService.findByDocumentFileId(ids);
        verify(documentAnnotationDAO, times(1)).findByDocumentFileId(ids);
    }

    @Test
    public void testGet() throws SugarTechnicalException, SugarFunctionalException {
        List<Id> ids = Lists.newArrayList(mock(Id.class));
        documentAnnotationService.get(ids);
        verify(documentAnnotationDAO, times(1)).get(ids);
    }

    @Test
    public void testDelete() throws SugarTechnicalException, SugarFunctionalException {
        List<DocumentAnnotation> annotations = Lists.newArrayList(mock(DocumentAnnotation.class));
        documentAnnotationService.delete(annotations);
        verify(documentAnnotationDAO, times(1)).delete(annotations);
    }

    @Test
    public void testUpdate() throws SugarTechnicalException, SugarFunctionalException {
        List<DocumentAnnotation> annotations = Lists.newArrayList(mock(DocumentAnnotation.class));
        documentAnnotationService.update(annotations);
        verify(documentAnnotationDAO, times(1)).update(annotations);
    }
}
