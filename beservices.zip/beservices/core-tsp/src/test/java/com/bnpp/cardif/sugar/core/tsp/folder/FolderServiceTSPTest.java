package com.bnpp.cardif.sugar.core.tsp.folder;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyListOf;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.bnpp.cardif.sugar.core.api.acl.AclService;
import com.bnpp.cardif.sugar.core.api.document.IdFactory;
import com.bnpp.cardif.sugar.core.api.folder.FolderValidator;
import com.bnpp.cardif.sugar.core.api.folderclass.FolderClassService;
import com.bnpp.cardif.sugar.core.tsp.document.DocumentSecurityHelper;
import com.bnpp.cardif.sugar.core.tsp.document.DocumentServiceTSP;
import com.bnpp.cardif.sugar.core.tsp.documentclass.DocumentClassServiceTSP;
import com.bnpp.cardif.sugar.core.tsp.event.Event;
import com.bnpp.cardif.sugar.core.tsp.event.SugarEventBus;
import com.bnpp.cardif.sugar.dao.api.folder.FolderDAO;
import com.bnpp.cardif.sugar.domain.exception.ExceptionBuilder;
import com.bnpp.cardif.sugar.domain.exception.SugarFunctionalException;
import com.bnpp.cardif.sugar.domain.exception.SugarTechnicalException;
import com.bnpp.cardif.sugar.domain.exception.TechnicalErrorCode;
import com.bnpp.cardif.sugar.domain.fact.Action;
import com.bnpp.cardif.sugar.domain.folder.test.FolderMockUtility;
import com.bnpp.cardif.sugar.domain.model.SearchResults;
import com.bnpp.cardif.sugar.domain.test.DocumentMockUtil;
import com.bnpparibas.assurance.ea.internal.schema.mco.acl.v1.AccessControlList;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.Folder;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.FolderId;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolder.v1.MCOFolderType.ChildComponents;
import com.bnpparibas.assurance.ea.internal.schema.mco.casefolderclass.v1.FolderClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.ClassId;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.DurationType;
import com.bnpparibas.assurance.ea.internal.schema.mco.common.v1.FolderStatusCodeType;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Document;
import com.bnpparibas.assurance.ea.internal.schema.mco.document.v1.Id;
import com.bnpparibas.assurance.ea.internal.schema.mco.documentclass.v1.DocumentClass;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.Criteria;
import com.bnpparibas.assurance.ea.internal.schema.mco.search.v1.OrderClause;
import com.google.common.collect.Lists;

@RunWith(MockitoJUnitRunner.class)
public class FolderServiceTSPTest {
    private static final String SCOPE = "myScope";

    @Mock
    private IdFactory folderIdFactory;

    @Mock
    private FolderDAO folderDAO;

    @Mock
    private SugarEventBus eventBus;

    @Mock
    private FolderClassService folderClassService;

    @Mock
    private DocumentClassServiceTSP documentClassServiceTSP;

    @Mock
    private DocumentServiceTSP documentServiceTSP;

    @Mock
    private DocumentSecurityHelper securityHelper;

    @Mock
    private AclService aclService;

    @Mock
    FolderValidator validatator;

    @InjectMocks
    private final FolderServiceTSP folderServiceTSP = new FolderServiceTSP();

    @Captor
    ArgumentCaptor<ArrayList<Folder>> foldersCaptor;

    @Captor
    ArgumentCaptor<ArrayList<Document>> documentsCaptor;

    @Before
    public void init() {
        SecurityContextInitializer.initContext();
    }

    @Test
    public void testAdd() throws SugarTechnicalException, SugarFunctionalException {

        ArrayList<Folder> foldersToAdd = new ArrayList<Folder>();
        Folder folderToAdd = FolderMockUtility.buildClaimFolder(1);
        Document buildClaimDocument = DocumentMockUtil.buildClaimDocument();
        folderToAdd.getChildComponents().getId().add(buildClaimDocument.getId());
        when(folderIdFactory.generateFolderID()).thenReturn(folderToAdd.getFolderId());
        when(documentServiceTSP.get(anyString(), anyListOf(Id.class), Mockito.anyBoolean(), Mockito.anyBoolean()))
                .thenReturn(Lists.newArrayList(buildClaimDocument));
        foldersToAdd.add(folderToAdd);
        when(aclService.getByClassId(anyString(), any(ClassId.class), Mockito.anyBoolean()))
                .thenReturn(new AccessControlList());
        List<Folder> foldersAdded = folderServiceTSP.add(foldersToAdd);

        assertNotNull(foldersAdded);
        assertFalse(foldersAdded.isEmpty());
        assertNotNull(foldersAdded.get(0));
        assertNotNull(foldersAdded.get(0).getData());
        assertEquals(folderToAdd.getData().getName(), foldersAdded.get(0).getData().getName());
        assertNotNull(foldersAdded.get(0).getFolderId());
        assertEquals(folderToAdd.getFolderId().getIssuer(), foldersAdded.get(0).getFolderId().getIssuer());

        ArgumentCaptor<Event> argument = ArgumentCaptor.forClass(Event.class);
        verify(eventBus, Mockito.times(2)).post(argument.capture());
        assertEquals(Action.CREATE, argument.getAllValues().get(1).getAction());
        assertEquals(Action.UPDATE_RETENTION_DATE, argument.getAllValues().get(0).getAction());

    }

    @Test
    public void testAddNameCheck() throws SugarTechnicalException, SugarFunctionalException {
        ArrayList<Folder> foldersToAdd = new ArrayList<Folder>();
        Folder folderToAdd = FolderMockUtility.buildClaimFolder(1);
        when(folderIdFactory.generateFolderID()).thenReturn(folderToAdd.getFolderId());
        when(aclService.getByClassId(anyString(), any(ClassId.class), Mockito.anyBoolean()))
                .thenReturn(new AccessControlList());
        foldersToAdd.add(folderToAdd);

        when(folderDAO.getBySymbolicName(anyString(), anyString()))
                .thenThrow(ExceptionBuilder.createTechnicalException(TechnicalErrorCode.T00402));
        List<Folder> foldersAdded = folderServiceTSP.add(foldersToAdd);

        assertNotNull(foldersAdded);
        assertFalse(foldersAdded.isEmpty());
        assertNotNull(foldersAdded.get(0));
        assertNotNull(foldersAdded.get(0).getData());
        assertEquals(folderToAdd.getData().getName(), foldersAdded.get(0).getData().getName());
        assertNotNull(foldersAdded.get(0).getFolderId());
        assertEquals(folderToAdd.getFolderId().getIssuer(), foldersAdded.get(0).getFolderId().getIssuer());
    }

    @Test
    public void testUpdate() throws SugarTechnicalException, SugarFunctionalException {
        ArrayList<Folder> foldersToStore = new ArrayList<Folder>();
        ArrayList<Folder> foldersToUpdate = new ArrayList<Folder>();
        Folder folderToStore = FolderMockUtility.buildClaimFolder(1);
        folderToStore.getData().setStatusCode(FolderStatusCodeType.OPEN);
        Folder folderToUpdate = FolderMockUtility.buildClaimFolder(1);
        folderToUpdate.setChildComponents(new ChildComponents());
        folderToUpdate.getChildComponents().getId().add(new Id());
        folderToUpdate.getData().setStatusCode(FolderStatusCodeType.CLOSE);
        foldersToUpdate.add(folderToUpdate);
        foldersToStore.add(folderToStore);
        when(folderDAO.update(anyListOf(Folder.class), anyString())).thenReturn(foldersToUpdate);
        when(documentServiceTSP.update(anyListOf(Document.class)))
                .thenReturn(Lists.newArrayList(Mockito.mock(Document.class)));
        updateRetentionEndDate(foldersToStore, folderToUpdate);
        List<Folder> foldersUpdated = folderServiceTSP.update(foldersToUpdate, SCOPE);

        assertNotNull(foldersUpdated);
        assertFalse(foldersUpdated.isEmpty());
        assertNotNull(foldersUpdated.get(0));
        assertNotNull(foldersUpdated.get(0).getData());
        assertNotNull(foldersUpdated.get(0).getData().getUpdtDate());
    }

    @Test
    public void testDateFolderClosing() throws SugarTechnicalException, SugarFunctionalException {
        when(documentServiceTSP.get(anyString(), anyListOf(Id.class), Matchers.anyBoolean(), Matchers.anyBoolean()))
                .thenReturn(Lists.newArrayList(DocumentMockUtil.buildClaimDocument()));

        Folder storedFolder = FolderMockUtility.buildClaimFolder(1);
        storedFolder.getData().setStatusCode(FolderStatusCodeType.OPEN);

        Folder folderToUpdate = FolderMockUtility.buildClaimFolder(1);
        folderToUpdate.setFolderId(storedFolder.getFolderId());
        folderToUpdate.getData().setStatusCode(FolderStatusCodeType.CLOSE);
        folderToUpdate.setChildComponents(new ChildComponents());
        folderToUpdate.getChildComponents().getId().add(new Id());
        ArrayList<Folder> storedFolders = Lists.newArrayList(storedFolder);
        List<Folder> updatedFolders = updateRetentionEndDate(storedFolders, folderToUpdate);

        assertNotNull(updatedFolders);
        assertEquals(storedFolders.size(), 1);
        assertNotNull(updatedFolders.get(0));
        assertNotNull(updatedFolders.get(0).getChildComponents().getId());

        assertNotNull(folderToUpdate.getData().getCloseDate());

    }

    @Test
    public void testUpdateDocWithMultipleFolders() throws SugarTechnicalException, SugarFunctionalException {
        when(documentServiceTSP.get(anyString(), anyListOf(Id.class), Matchers.anyBoolean(), Matchers.anyBoolean()))
                .thenReturn(Lists.newArrayList(DocumentMockUtil.buildClaimDocument()));

        Folder storedFolder = FolderMockUtility.buildClaimFolder(1);
        storedFolder.getData().setStatusCode(FolderStatusCodeType.OPEN);
        storedFolder.getData().setCloseDate(DocumentMockUtil.dateFor(2, 2, 2000));
        Folder storedFolder2 = FolderMockUtility.buildClaimFolder(1);
        storedFolder2.getData().setStatusCode(FolderStatusCodeType.OPEN);
        storedFolder2.getData().setCloseDate(DocumentMockUtil.dateFor(2, 2, 2000));
        ArrayList<Folder> storedFolders = Lists.newArrayList(storedFolder, storedFolder2);

        Folder folderToUpdate = FolderMockUtility.buildClaimFolder(1);
        folderToUpdate.setChildComponents(new ChildComponents());
        folderToUpdate.getChildComponents().getId().add(new Id());
        folderToUpdate.getData().setStatusCode(FolderStatusCodeType.CLOSE);

        folderToUpdate.getData().setCloseDate(DocumentMockUtil.dateFor(2, 2, 2000));

        updateRetentionEndDate(storedFolders, folderToUpdate);

    }

    @Test(expected = SugarFunctionalException.class)
    public void testUpdateNonEmptyFolderClass() throws SugarTechnicalException, SugarFunctionalException {

        ArrayList<Folder> foldersToStore = new ArrayList<Folder>();
        ArrayList<Folder> foldersToUpdate = new ArrayList<Folder>();
        Folder folderToStore = FolderMockUtility.buildClaimFolder(1);
        folderToStore.getData().setStatusCode(FolderStatusCodeType.OPEN);
        Folder folderToUpdate = FolderMockUtility.buildClaimFolder(1);
        folderToStore.getData().getClassId().setValue("ChangedClass");
        folderToUpdate.setChildComponents(new ChildComponents());
        folderToUpdate.getChildComponents().getId().add(new Id());
        foldersToUpdate.add(folderToUpdate);
        foldersToStore.add(folderToStore);
        when(folderDAO.get(anyListOf(FolderId.class), anyString())).thenReturn(foldersToStore);
        when(documentServiceTSP.update(anyListOf(Document.class)))
                .thenReturn(Lists.newArrayList(DocumentMockUtil.buildClaimDocument()));
        updateRetentionEndDate(foldersToStore, folderToUpdate);
        folderServiceTSP.update(foldersToUpdate, SCOPE);

    }

    private List<Folder> updateRetentionEndDate(List<Folder> storedFolders, Folder folderToUpdate)
            throws SugarTechnicalException, SugarFunctionalException {
        when(folderDAO.get(anyListOf(FolderId.class), anyString())).thenReturn(storedFolders);
        when(folderDAO.find(anyString(), any(Criteria.class), any(OrderClause.class), Mockito.any(Long.class),
                Mockito.any(Long.class))).thenReturn(new SearchResults<Folder>(Lists.newArrayList(folderToUpdate), 1));

        DocumentClass mockedDocumentClass = Mockito.mock(DocumentClass.class);
        DurationType defaultDuration = new DurationType(new BigInteger("1"), "MONTH");
        when(mockedDocumentClass.getRetentionDuration()).thenReturn(defaultDuration);
        when(documentClassServiceTSP.get(anyString(), anyListOf(ClassId.class)))
                .thenReturn(Lists.newArrayList(mockedDocumentClass));

        FolderClass mockedFolderClass = Mockito.mock(FolderClass.class);
        when(mockedFolderClass.getRetentionDuration()).thenReturn(new DurationType(new BigInteger("2"), "MONTH"));
        when(folderClassService.get(anyListOf(ClassId.class), anyString()))
                .thenReturn(Lists.newArrayList(mockedFolderClass));

        ArrayList<Folder> foldersToUpdate = Lists.newArrayList(folderToUpdate);
        when(folderDAO.update(anyListOf(Folder.class), anyString())).thenReturn(foldersToUpdate);

        folderServiceTSP.update(foldersToUpdate, SCOPE);

        verify(folderDAO).update(foldersCaptor.capture(), anyString());

        return foldersCaptor.getValue();
    }

    @Test
    public void testGet() throws SugarTechnicalException, SugarFunctionalException {
        ArrayList<FolderId> idOfFolderToGet = new ArrayList<FolderId>();
        FolderId idFolderToGet = FolderMockUtility.buildFolderId();
        idOfFolderToGet.add(idFolderToGet);
        List<Folder> foldersToGet = new ArrayList<Folder>();
        foldersToGet.add(FolderMockUtility.buildClaimFolder(1));
        when(folderDAO.get(anyListOf(FolderId.class), anyString())).thenReturn(foldersToGet);
        List<Folder> foldersGet = folderServiceTSP.get(idOfFolderToGet, SCOPE);

        assertNotNull(foldersGet);
        assertFalse(foldersGet.isEmpty());
        assertNotNull(foldersGet.get(0));
        assertNotNull(foldersGet.get(0).getData());
        assertNotNull(foldersGet.get(0).getData().getUpdtDate());
    }
}
